
#ifndef BOOST_MPL_AT_FWD_HPP_INCLUDED
#define BOOST_MPL_AT_FWD_HPP_INCLUDED

// Copyright Aleksey Gurtovoy 2000-2004
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/mpl for documentation.

// $Id: libs/include/boost/mpl/at_fwd.hpp 1.1 2011/12/08 20:53:56ICT Weissflog Peter (CC-PS/EPS2) (WGP2SI) release  $
// $Date: 2011/12/08 20:53:56ICT $
// $Revision: 1.1 $

namespace boost { namespace mpl {

template< typename Tag > struct at_impl;
template< typename Sequence, typename N > struct at;

}}

#endif // BOOST_MPL_AT_FWD_HPP_INCLUDED
