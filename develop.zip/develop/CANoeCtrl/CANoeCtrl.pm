package CANoeCtrl;

use 5.006;
use strict;
use warnings;
use LIFT_simulation;

require Exporter;
require DynaLoader;

our @ISA = qw(Exporter DynaLoader);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration	use CANoeCtrl ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw(

) ] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
    canoectrl_getPMrevision
    canoectrl_getXSrevision
    canoectrl_getCWrevision
    canoectrl_cnInitialize
    canoectrl_cnConnectToCanoe
    canoectrl_cnDisconnectFromCanoe
    canoectrl_cnLoadConfiguration
    canoectrl_cnStartMeasurement
    canoectrl_cnStopMeasurement
    canoectrl_registerCAPL
    canoectrl_callCAPL
    canoectrl_callCAPL_StopLog
    canoectrl_setOutputSignal
    canoectrl_ResetOutputSignal
    canoectrl_setSoftwareTrigger
    canoectrl_enableOutputTriggers
    canoectrl_cnUninitialize
    canoectrl_setSetSignalNow
    canoectrl_setTimedSignal
    canoectrl_setAnalysisSignal
    canoectrl_setMonitoringTime
    canoectrl_getSignalTimes
	canoectrl_setSysVariablesValues
	canoectrl_getSignalLimts
);
our $VERSION = '0.01';

bootstrap CANoeCtrl $VERSION;

if ( $main::opt_simulation ){
    no strict 'refs';
    # define all functions that should not be redefined (because they work anyway)
    my @exclude = qw(
        
    );
    # redefine all functions for simulation mode with default return values, except the functions in @exclude
    foreach my $function (@EXPORT){
        next if grep {/$function/} @exclude;
        # each function in @EXPORT is redefined using SIM_returnValues
        *{$function} = sub{ return SIM_returnValues($function, 'default', \@_); };
    }

    # define return values table (especially for default values) and pass it to simulation module
    my $returnValuesTable_href = {
          #'VEC_cantool_init' => { 'default' => [1]},
    };
    SIM_addToValuesTable( $returnValuesTable_href );        
};

# Preloaded methods go here.

sub canoectrl_getPMrevision{
    return (q$Revision: 1.5 $);
}

sub canoectrl_getXSrevision{
    my $XSrev = _getXSrevision();
    $XSrev =~ s/\$//g;
    return ($XSrev);
}

sub canoectrl_getCWrevision{
    my $CWrev = _getCWrevision();
    $CWrev =~ s/\$//g;
    return ($CWrev);
}


1;
__END__

=head1 NAME

CANoeCtrl - Perl extension for CANoeCtrl dll

=head1 SYNOPSIS

  use CANoeCtrl;

    my ($version,$status);

    $version = canoectrl_getPMrevision();
    print "PM $version\n";
    $version = canoectrl_getXSrevision();
    print "XS $version\n";
    $version = canoectrl_getCWrevision();
    print "CW $version\n";

    $status = canoectrl_cnInitialize();
    print "perl: ($status)  Initialize";

    $status = canoectrl_cnConnectToCanoe("CanoePC");
    print "perl: ($status)  ConnectToCanoe";

    $status = canoectrl_cnLoadConfiguration( "C:\\CanoeCtrlDLL\\COMDemo.cfg", -1);
    print "perl: ($status)  LoadConfiguration";

    $status = canoectrl_cnStartMeasurement( -1);
    print "perl: ($status)  StartMeasurement";

    $status = canoectrl_cnStopMeasurement( -1);
    print "perl: ($status)  StopMeasurement";

    $func_val = canoectrl_registerCAPL(CaplFunction);
    print "perl: ($func_val)  Register Capl function";

    $status = canoectrl_callCAPL_StopLog(Func_val);
    print "perl: ($status)  Calling Capl function stop logging";

    $status = canoectrl_setOutputSignal( 0, [2,1], cTriggerHard);
    print "perl: ($status)  Set output signal";

    $status = canoectrl_ResetOutputSignal();
    print "perl: ($status) Reset output signal";

    $status = canoectrl_setSoftwareTrigger();
    print "perl : ($status) Set Software trigger";

    $staus = canoectrl_enableOutputTriggers();
    print "perl: ($status) Enable Output Trigger";

    $status = canoectrl_cnDisconnectFromCanoe( 1, -1);
    print "perl: ($status)  DisconnectFromCanoe";

    $status = canoectrl_cnUninitialize();
    print "perl: ($status)  Uninitialize";

    $status = canoectrl_setSetSignalNow(signalName, 100.1);
    print "perl: ($status)  setSetSignalNow";

    $status = canoectrl_setTimedSignal(0, 100.0, 1, 150.0, 500);
    print "perl: ($status)  setTimedSignal";

    $status = canoectrl_setAnalysisSignal(0, 2, 100.0, 0);
    print "perl: ($status)  setAnalysisSignal";

    $status = canoectrl_setMonitoringTime(10);
    print "perl: ($status)  setMonitoringTime";

    $status = canoectrl_getSignalTimes(1);
    print "perl: ($status)  getSignalTimes";

    ($status,$result) = canoectrl_callCAPL(Func_val,0,0,0,0,0,0,0,0);
    print "perl: ($status)  callCAPL";

=head1 DESCRIPTION

All functions are wrapped around CANoeCtrl DLL APIs

=head2 canoectrl_cnInitialize

    Initialize the DLL. This must be done before any other call of a function of the DLL.

=head2 canoectrl_cnConnectToCanoe

    Connect to the CANoe application on the given host name.

=head2 canoectrl_cnDisconnectFromCanoe

    Disconnects from the CANoe application.

=head2 canoectrl_cnLoadConfiguration

    Load configuration. The first parameter is the full path of the CANoe configuration.
    The second parameter is a timeout, the value -1 means that this call blocks until the configuration is loaded, no matter how long it takes.

=head2 canoectrl_cnStartMeasurement

    Start the measurement.

=head2 canoectrl_cnStopMeasurement

    Stop the measurement. The timeout is set to -1, i.e., this call blocks until measurement is stopped.

=head2 canoectrl_registerCAPL

    Register a CAPL function which can be called before start of measurement. If success returns the function pointer.

=head2 canoectrl_callCAPL

    Calls a CAPL function by reading the function pointer and input params of called function which can be done during measurement.

=head2 canoectrl_callCAPL_StopLog

    Calls the function pointer to stop logging the a CAPL function result.

=head2 canoectrl_setOutputSignal

    Defines new values of a signal that shall be sent when the system is triggered.

=head2 canoectrl_ResetOutputSignal

    Resets the output signal.

=head2 canoectrl_setSoftwareTrigger

    Sets the software trigger for output signal.

=head2 canoectrl_enableOutputTriggers

    Enables the signal output triggers.

=head2 canoectrl_cnUninitialize

    Uninitializes the DLL. This must be the last call to the DLL in the program.

=head2 canoectrl_setSetSignalNow

    Immediatelty set a signal to a given value.

=head2 canoectrl_setTimedSignal

    Defines new values of a signal that shall be sent when the system is triggered.

=head2 canoectrl_setAnalysisSignal

   Sets a signal that shall be monitored after the trigger.

=head2 canoectrl_setMonitoringTime

   Sets a maximum monitoring time in milliseconds.

=head2 canoectrl_getSignalTimes

   Gets the response times in milliseconds of the signals configured with SetAnalysisSignal.

=head1 TRACEABILITY FUNCTIONS

=head2 canoectrl_getPMrevision

    $version = canoectrl_getPMrevision();
    returns MKS revision number of .pm file

=head2 canoectrl_getXSrevision

    $version = canoectrl_getXSrevision();
    returns MKS revision number of .xs file

=head2 canoectrl_getCWrevision

    $version = canoectrl_getCWrevision();
    returns MKS revision number of .c file

=cut

=head1 SEE ALSO

Perl documentation


=head1 AUTHOR

G V Sriram, E<lt> VeerabhadraSriram.Grandhi@in.bosch.com E<gt>

=head1 COPYRIGHT AND LICENSE

Copyright (c) 2013  Robert Bosch GmBH

=cut
