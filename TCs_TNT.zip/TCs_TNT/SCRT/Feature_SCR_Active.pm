#### TEST CASE MODULE
package Feature_SCR_Active;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.6 $;
our $HEADER = q$Header: SCRT/Feature_SCR_Active.pm 1.6 2018/01/19 00:14:25ICT Okrusch Thomas (CC-PS/EPS2) (OUT2SI) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_AB12_SCRT 
#TS version in DOORS: 4.1 
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use LIFT_LCT;
use LIFT_TSG4;
use INCLUDES_Project; #necessary
#include further modules here

##################################

our $PURPOSE = "active test cases for SCRT";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

Feature_SCR_Active_MinusS2B

=head1 PURPOSE

active test cases for SCRT

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Switch ECU on with over volltage (18V)

I<B<Stimulation and Measurement>>

1. Create <FaultType> on <Device>	

2. Wait for 60 Secs

3. Read Fault recorder

4. Remove <FaultType> Fault

5. Erase fault recorder

I<B<Evaluation>>
Nothing done here

I<B<Finalisation>>
Nothing done here

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

	SCALAR 'Device' => Name of the device which is configured
	SCALAR 'FaultType' => fault type created on the device example Short2Bat


=head2 PARAMETER EXAMPLES

	#turbolift
	Device = 'AB1FD'
	FaultType =  'Short2Gnd'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Device;
my $tcpar_FaultType;
my $WaitTime = 6000;
my $SCRTWaitTime = 60000;
my $SCRT_Overvoltage = 18;
my $data_HoH = 0;
################ global parameter declaration ###################
#add any global variables here

###############################################################

sub TC_set_parameters {

	$tcpar_Device =  GEN_Read_mandatory_testcase_parameter( 'Device' );
	$tcpar_FaultType =  GEN_Read_mandatory_testcase_parameter( 'FaultType' );

	return 1;
}

sub TC_initialization {

	GEN_printTestStep("Switch ECU on with over volltage (18V)");
	LC_SetVoltage(18);	
    S_wait_ms( $WaitTime,"Wait after overvoltage is set" ); 
    
    LCT_StartMeasurement();
    LCT_SendSWTrigger();
	
    return 1;
}

sub TC_stimulation_and_measurement {

    GEN_printTestStep("Step 1: Create $tcpar_FaultType on $tcpar_Device ", 'blue');
	 my $status = DEVICE_setDeviceState ($tcpar_Device, $tcpar_FaultType);
          
    unless(defined $status and $status == 1){
    	GEN_printTestStep("$tcpar_FaultType is not created successfully! Not proceeding", 'red');
    	$PURPOSE = "Shorting of pins is not created successfully";
    	return 0;
    }
	
	GEN_printTestStep("Step 2. Wait for 60 secs ");
	S_wait_ms( $SCRTWaitTime,"Wait for 60 secs"  ); 
	
	GEN_printTestStep("Step 3.Read Fault recorder:");
    FM_PD_readFaultMemory (); 
	
	GEN_printTestStep("Step 4. Remove Fault $tcpar_FaultType Fault");
	my $status = DEVICE_resetDeviceState ($tcpar_Device, $tcpar_FaultType);
          
    unless(defined $status and $status == 1){
    	GEN_printTestStep("$tcpar_FaultType is not removed successfully! Not proceeding", 'red');
    	$PURPOSE = "removing of Short of pins is not successful";
    	return 0;
    }
	S_wait_ms( $WaitTime,"Wait after fault is removed" ); 
	
    LCT_StopMeasurement();
    $data_HoH = LCT_get_values();
    #$channel_HoA = LCT_get_channel('AB1FD');
    if(defined $data_HoH){
       LCT_plot_values($main::REPORT_PATH."/SQUIBS_LCT.txt.unv");
       S_add_pic2html("file:///".$main::REPORT_PATH."/SQUIBS_LCT.png");
    }

	GEN_printTestStep("Step 5. Erase fault recorder");
    PD_ClearFaultMemory();   
	#TSG4_CloseHW();
	return 1;
}

sub TC_evaluation {
    S_set_verdict(VERDICT_PASS);
	return 1;
}

sub TC_finalization {

	return 1;
}


1;
