#### TEST CASE MODULE
package Feature_SCR_Passive;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.5 $;
our $HEADER = q$Header: SCRT/Feature_SCR_Passive.pm 1.5 2018/01/19 00:14:25ICT Okrusch Thomas (CC-PS/EPS2) (OUT2SI) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_AB12_SCRT 
#TS version in DOORS: 4.1 
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use LIFT_LCT;
use INCLUDES_Project; #necessary
#include further modules here

##################################

our $PURPOSE = "Passive test cases for SCRT";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

Feature_SCR_Passive_S2GPlus

=head1 PURPOSE

Passive test cases for SCRT

=head1 TESTCASE DESCRIPTION

I<B<Initialisation>>

Intial Step Switch ECU off

I<B<Stimulation and Measurement>>

1. Create <FaultType> on <Device>

2. Switch ECU on with undervoltage

3. Wait for 60 Secs

4. Read Fault recorder 	

5. Remove <FaultType> Fault

6. Erase fault recorder

I<B<Evaluation>>
Nothing done here

I<B<Finalisation>>
Nothing done here

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

	SCALAR 'Device' => Name of the device which is configured
	SCALAR 'FaultType' => fault type created on the device example Short2Bat

=head2 PARAMETER EXAMPLES

	#turbolift
	Device = AB1FD
	FaultType =  'Short2Bat_lowSide'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Device;
my $tcpar_FaultType;
my $WaitTime = 6000;
my $SCRTWaitTime = 60000;
my $data_HoH;
################ global parameter declaration ###################
#add any global variables here

###############################################################

sub TC_set_parameters {

	$tcpar_Device =  GEN_Read_mandatory_testcase_parameter( 'Device' );
	$tcpar_FaultType =  GEN_Read_mandatory_testcase_parameter( 'FaultType' );
	return 1;
}

sub TC_initialization {
    GEN_printTestStep("Intial Step Switch ECU off");
    LC_ECU_Off();
	S_wait_ms($WaitTime,"Wait after power off"); 
    LCT_StartMeasurement();
    LCT_SendSWTrigger();	
	return 1;
}

sub TC_stimulation_and_measurement {

 	GEN_printTestStep("Step 1: Create $tcpar_FaultType on $tcpar_Device ", 'blue');
	 my $status = DEVICE_setDeviceState ($tcpar_Device, $tcpar_FaultType);
          
    unless(defined $status and $status == 1){
    	GEN_printTestStep("$tcpar_FaultType is not created successfully! Not proceeding", 'red');
    	$PURPOSE = "Shorting of pins is not created successfully";
    	return 0;
    }
	S_wait_ms( $WaitTime,"Wait after fault is applied" ); 
	
	GEN_printTestStep("Step 2. Switch ECU on with undervoltage");
	LC_SetVoltage('U_BATT_UNDERVOLTAGE');	
	LC_ECU_On();
    
	GEN_printTestStep("Step 3. Wait for 60 secs ");
    S_wait_ms( $SCRTWaitTime,"Wait for 60 secs"  ); 
	PD_ECUlogin();
	
    GEN_printTestStep("Step 4. Read Fault recorder ");
	FM_PD_readFaultMemory (); 
	 
	GEN_printTestStep("Step 5: Remove '$tcpar_FaultType' Fault", 'blue');
	 my $status = DEVICE_resetDeviceState ($tcpar_Device, $tcpar_FaultType);
          
    unless(defined $status and $status == 1){
    	GEN_printTestStep("$tcpar_FaultType is not removed successfully! Not proceeding", 'red');
    	$PURPOSE = "removing of Short of pins is not successful";
    	return 0;
    }
	S_wait_ms( $WaitTime,"Wait after fault is removed" ); 
	
    LCT_StopMeasurement();
    $data_HoH = LCT_get_values();
    #$channel_HoA = LCT_get_channel('AB1FD');
    if(defined $data_HoH){
       LCT_plot_values($main::REPORT_PATH."/SQUIBS_LCT.txt.unv");
       S_add_pic2html("file:///".$main::REPORT_PATH."/SQUIBS_LCT.png");
    }
    
	GEN_printTestStep("Step 6. Erase fault recorder");
    PD_ClearFaultMemory();
    #TSG4_CloseHW();
    
	return 1;
}

sub TC_evaluation {
    S_set_verdict(VERDICT_PASS);
	return 1;
}

sub TC_finalization {

	return 1;
}


1;
