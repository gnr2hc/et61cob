#### TEST CASE MODULE
package Feature_SCR_NominalState;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.5 $;
our $HEADER = q$Header: SCRT/Feature_SCR_NominalState.pm 1.5 2018/01/19 00:14:24ICT Okrusch Thomas (CC-PS/EPS2) (OUT2SI) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_AB12_SCRT 
#TS version in DOORS: 4.1 
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use INCLUDES_Project; #necessary
#include further modules here

##################################

our $PURPOSE = "Set nominal state";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

Feature_SCR_NominalState

=head1 PURPOSE

Set nominal state

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>
Nothing done here

I<B<Stimulation and Measurement>>

1.Set Nominal State 	

2.Erase fault recorder

3.Read Fault recorder


I<B<Evaluation>>
Nothing done here

I<B<Finalisation>>
Nothing done here

=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => gives the purpose of this execution


=head2 PARAMETER EXAMPLES

	purpose='NominalState after Active test cases' 

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $WaitTime = 6000;
################ global parameter declaration ###################
#add any global variables here
my $flt_mem_struct;
###############################################################

sub TC_set_parameters {

	return 1;
}

sub TC_initialization {

	return 1;
}

sub TC_stimulation_and_measurement {

	GEN_printTestStep("Step 1.Set Nominal voltage");
	LC_SetVoltage('U_BATT_DEFAULT');	
    GEN_Power_on_Reset ();
    #LC_ECU_On();
	#S_wait_ms( $WaitTime,"Wait after voltage is set" ); 

	GEN_printTestStep("Step 2.Erase fault recorder");
    PD_ECUlogin();
    S_wait_ms( $WaitTime,"Wait for 6 secs"  );

	PD_ClearFaultMemory();   
	S_wait_ms( 12000,"Wait for 12 secs after clear fault memory"  );
    
	GEN_printTestStep("Step 3.Evaluate Fault recorder: ");
	$flt_mem_struct = FM_PD_readFaultMemory (); 
	FM_evaluateFaults( $flt_mem_struct, [] );
	return 1;
}

sub TC_evaluation {
    S_set_verdict(VERDICT_PASS);
	return 1;
}

sub TC_finalization {

	return 1;
}


1;
