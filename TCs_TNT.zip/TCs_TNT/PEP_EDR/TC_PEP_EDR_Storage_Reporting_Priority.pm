#### TEST CASE MODULE
package TC_PEP_EDR_Storage_Reporting_Priority;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.3 $;
our $HEADER = q$Header: PEP_EDR/TC_PEP_EDR_Storage_Reporting_Priority.pm 1.3 2017/04/13 18:42:43ICT D Souza Deepthi Mariate (RBEI/ESA-PP3) (DDE3KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_PD;
use LIFT_can_access;
use GENERIC_DCOM;
use LIFT_labcar;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;
use Data::Dumper;

##################################

our $PURPOSE = "To check reporting priority";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PEP_EDR_Storage_Reporting_Priority

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFaultNoCT


I<B<Stimulation and Measurement>>

1. Inject <Crashcode1>

2.Wait for <WaitTime_ms>

3. Read <EDR_Type>

4.Inject <Crashcode2>


I<B<Evaluation>>

1. - 

2. - 

3. Diag response must be invalid or incomplete due to crash injection in step 4

<Response> is obtained 4.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'DiagType' => 
	SCALAR 'Crashcode1' => 
	SCALAR 'Crashcode2' => 
	SCALAR 'purpose' => 
	SCALAR 'ResultDB' => 
	SCALAR 'WaitTime_ms' => 
	SCALAR 'EDR_Type' => 
	SCALAR 'Response' => 


=head2 PARAMETER EXAMPLES

	purpose = 'Check PEP EDR Storage and Reporting Priority on receiving a job for storage when handling a job for reporting'
	
	# ---------- Stimulation ------------ 
	ResultDB = 'EDR' # defined in CREIS project constants - will be set to 'DEFAULT' if not given
	WaitTime_ms = 15000
	
	EDR_Type = 'EDR'
	Response = 'PositiveResponse'
	DiagType = 'AKLV'
	Crashcode1 = 'Single_EDR_PedPro_Inflatable;5'
	Crashcode2 = 'Single_EDR_SideLeft_Inflatable;5'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_ResultDB;
my $tcpar_WaitTime_ms;
my $tcpar_EDR_Type;
my $tcpar_Response;
my $tcpar_DiagType;
my $tcpar_Crashcode1;
my $tcpar_Crashcode2;

################ global parameter declaration ###################
#add any global variables here

my ($record_handler, $crashSettings1, $crashSettings2,$response_aref,$Detected_ResponseLength_Normal,$Detected_ResponseLength_Abort);
###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_ResultDB =  S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_WaitTime_ms =  S_read_mandatory_testcase_parameter( 'WaitTime_ms' );
	$tcpar_EDR_Type =  S_read_mandatory_testcase_parameter( 'EDR_Type' );
	$tcpar_Response =  S_read_mandatory_testcase_parameter( 'Response' );
	$tcpar_DiagType =  S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_Crashcode1 =  S_read_mandatory_testcase_parameter( 'Crashcode1' );
	$tcpar_Crashcode2 =  S_read_mandatory_testcase_parameter( 'Crashcode2' );

	return 1;
}

sub TC_initialization {

	S_teststep("Test setup preparation", 'AUTO_NBR');

	#--------------------------------------------------------------
    # INITIALIZE RECORD AND CRASH HANDLER
    #    
	S_w2rep("Initialize Record Handler");
	$record_handler = EDR_init_RecordHandler() || return;

	#--------------------------------------------------------------
    # PREPARE CRASH AND INITIALIZE EQUIPMENT
    #
	S_w2rep("Get crash settings for crash $tcpar_Crashcode1");
    my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode1};
	$crashSettings1 = CSI_GetCrashDataFromMDS($crashDetails_href);

	my $crashDetails2_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode2};
	$crashSettings2 = CSI_GetCrashDataFromMDS($crashDetails2_href);

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log(1, "Crashcode: $tcpar_Crashcode1, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");

	S_w2log(1, "Power on ECU");
    LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	S_w2log(1, "Set environments for crash as per result DB");
	CSI_PrepareEnvironment($crashSettings1, 'init_complete');

	S_w2log(1, "Clear crash recorder");
    PD_ClearCrashRecorder(20000);

	S_w2log(1, "Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);

    GDCOM_init () ; # To fetch info for CD from mapping_diag
	CA_trace_start ( );

	S_w2log(1, "Read and evaluate fault memory before stimulation");
    my $faultsBeforeStimulation = PD_ReadFaultMemory();

    #Fault memory must be empty
    my $faultsVerdict = PD_evaluate_faults( $faultsBeforeStimulation, []);
    return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

	return 1;
}

sub TC_stimulation_and_measurement {

	#--------------------------------------------------------------
    # CRASH PREPARATION
    #

    # Prepare crash
    S_teststep("Prepare crash", 'AUTO_NBR');
    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

    # Prepare crash
    CSI_LoadCrashSensorData2Simulator($crashSettings1);

    # Power ON the ECU
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');
    PD_ECUlogin();

	#--------------------------------------------------------------
    # CRASH INJECTION 1
    #
	S_teststep("Inject first '$tcpar_Crashcode1'.", 'AUTO_NBR');
	CSI_TriggerCrash();

	S_teststep("Wait for '$tcpar_WaitTime_ms'", 'AUTO_NBR');
	S_wait_ms($tcpar_WaitTime_ms);

	S_teststep("Read EDR via PD in normal condition", 'AUTO_NBR', 'PD_read_crashrecorder_normal'); #measurement 1

    $response_aref= PD_ReadCrashRecorder(0x10);
	$response_aref = [1] if ($main::opt_offline);
	$Detected_ResponseLength_Normal =@{$response_aref};

    S_w2rep("Detected Response length in normal condition = $Detected_ResponseLength_Normal");

	# Prepare crash
	CSI_LoadCrashSensorData2Simulator($crashSettings2) unless $main::opt_offline;

	S_teststep("Read EDR via PD in abort condition", 'AUTO_NBR', 'PD_read_crashrecorder_abort'); #measurement 2

	$response_aref =PD_ReadCrashRecorder_NOERROR(0x10);

	S_teststep("Inject '$tcpar_Crashcode2'", 'AUTO_NBR');
	CSI_TriggerCrash();

	$response_aref = [1] if ($main::opt_offline);

	$Detected_ResponseLength_Abort =@{$response_aref};
	S_w2rep("Detected Response length in abort condition = $Detected_ResponseLength_Abort");

	return 1;
}

sub TC_evaluation {

	S_teststep_expected("Diag response in normal condition is obtained ", 'PD_read_crashrecorder_normal');
	S_teststep_detected("Actual length of the response $Detected_ResponseLength_Normal", 'PD_read_crashrecorder_normal'); #evaluation 1

	S_teststep_expected("Diag response must be incomplete due to crash injection (< $Detected_ResponseLength_Normal bytes)",
	                       'PD_read_crashrecorder_abort'); #evaluation 2
	S_teststep_detected("Truncated response is obtained with length $Detected_ResponseLength_Abort",
	                       'PD_read_crashrecorder_abort');
						   
	my $verdict = EVAL_evaluate_value ( "Comparision of diag response length in normal and abort condition" , $Detected_ResponseLength_Abort, '<', $Detected_ResponseLength_Abort );					   

	if ($verdict eq 'VERDICT_PASS'){
		S_w2rep("Detected Response length in abort condition is less than Detected Response length in normal condition");
	}
	else{
		S_w2rep("Detected Response length in abort condition is same as Detected Response length in normal condition");
	}

	return 1;
}

sub TC_finalization {

S_w2rep("Start test case finalization...");

	# Erase EDR
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(2000);

	# Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(10000);

	# Read fault memory after clearing and erasing EDR
    PD_ReadFaultMemory();

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

	return 1;
}


1;
