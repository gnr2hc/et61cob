#### TEST CASE MODULE
package TC_PEP_EDR_Max_LockRecordHandling;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.4 $;
our $HEADER = q$Header: PEP_EDR/TC_PEP_EDR_Max_LockRecordHandling.pm 1.4 2017/04/13 18:42:23ICT D Souza Deepthi Mariate (RBEI/ESA-PP3) (DDE3KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
use LIFT_PD;
use LIFT_can_access;
use GENERIC_DCOM;
use LIFT_labcar;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use LIFT_crash_simulation;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;
use Data::Dumper;

##################################

our $PURPOSE = "To check PEP EDR behaviour when all PEP EDR records are locked";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PEP_EDR_Max_LockRecordHandling

=head1 PURPOSE

<To check PEP EDR behaviour when all PEP EDR records are locked">

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Inject <CrashCode> for (NumberOfEventsToBeStored Events-1) so that 1 unlocked record is avilable.

2. Wait <wait_ms>

3. Read Crash Recorder

4. Inject <CrashCode>

5. Wait <wait_ms>

6. Read Crash Recorder

7.Inject <CrashCode>

8. Wait <wait_ms>

9. Read Crash Recorder 


I<B<Evaluation>>

1. -

2. -

3. total number of crash Telegrams =<expected_nr_of_records_First>
total event, crash number and lock status should have <CompareValues_First>

4.

5. 

6. total number of crash Telegrams= <expected_nr_of_records_Second>

total event, crash number and lock status should have<CompareValues_Second >


7.

8.

9.total number of crash Telegrams= <expected_nr_of_records_Second>
total event, crash number and lock status should have<CompareValues_Third >



I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'ResultDB' => 
	SCALAR 'wait_ms' => 
	SCALAR 'DiagType' => 
	SCALAR 'expected_nr_of_records_First' => 
	SCALAR 'expected_nr_of_records_Second' => 
	HASH 'COMsignalsAfterCrash' => 
	HASH 'CompareValues_First' => 
	HASH 'CompareValues_Second' => 
	HASH 'CompareValues_Third' => 
	SCALAR 'CrashCode' => 


=head2 PARAMETER EXAMPLES

	purpose		 = 'Check the PEP EDR behaviour when all PEP EDR records are locked'
	
	# ---------- Stimulation ------------ 
	
	# general
	
	ResultDB = 'EDR'
	wait_ms = 10000 #ms
	DiagType = 'PEDProEDR'
	#data from SYC
	#NumberOfEventsToBeStored = '<Fetch {V_AB12_JLR_X540_TT}>'
	NumberOfEventsToBeStored = 6 
	expected_nr_of_records_First = 5
	expected_nr_of_records_Second =6
	
	
	COMsignalsAfterCrash = %() # optional parameter which provides COM signals needed to be sent after crash.
	#Eg:COMsignalsAfterCrash = %('ESP_v_Signal' => '0', 'KBI_angez_Geschw' => '0')
	
	CompareValues_First = %('2501' => '5', '2502' => '5','2504'=>'3') 
	CompareValues_Second = %('2501' => '6', '2502' => '6','2504'=>'3') 
	CompareValues_Third = %('2501' => '7', '2502' => '6','2504'=>'3') 
	# ---------- Evaluation ------------ 
	CrashCode = 'Single_EDR_PedPro_Inflatable;5'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_ResultDB;
my $tcpar_wait_ms;
my $tcpar_DiagType;
my $tcpar_expected_nr_of_records_First;
my $tcpar_expected_nr_of_records_Second;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_CompareValues_First;
my $tcpar_CompareValues_Second;
my $tcpar_CompareValues_Third;
my $tcpar_Crashcode;

################ global parameter declaration ###################
#add any global variables here
my ($record_handler,$crashSettings,$PEPedrNumberOfEventsToBeStored);

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_ResultDB =  S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_wait_ms =  S_read_mandatory_testcase_parameter( 'wait_ms' );
	$tcpar_DiagType =  S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_expected_nr_of_records_First =  S_read_mandatory_testcase_parameter( 'expected_nr_of_records_First' );
	$tcpar_expected_nr_of_records_Second =  S_read_mandatory_testcase_parameter( 'expected_nr_of_records_Second' );
	$tcpar_COMsignalsAfterCrash =  S_read_optional_testcase_parameter( 'COMsignalsAfterCrash','byref' );
	$tcpar_CompareValues_First =  S_read_mandatory_testcase_parameter( 'CompareValues_First' ,'byref');
	$tcpar_CompareValues_Second =  S_read_mandatory_testcase_parameter('CompareValues_Second' ,'byref' );
	$tcpar_CompareValues_Third =  S_read_mandatory_testcase_parameter( 'CompareValues_Third' ,'byref' );
	$tcpar_Crashcode =  S_read_mandatory_testcase_parameter( 'CrashCode' );

	return 1;
}

sub TC_initialization {

	S_teststep("Test setup preparation", 'AUTO_NBR');

	#--------------------------------------------------------------
    # INITIALIZE RECORD AND CRASH HANDLER
    #    
	S_w2rep("Initialize Record Handler");
	$record_handler = EDR_init_RecordHandler() || return;

	#--------------------------------------------------------------
    # PREPARE CRASH AND INITIALIZE EQUIPMENT
    #
	S_w2rep("Get crash settings for crash $tcpar_Crashcode");
    my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode};
	$crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
	unless(defined $crashSettings) {
		S_set_error("Crash $tcpar_Crashcode not available in result DB $tcpar_ResultDB. Test case aborted.");
		return;
	}

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log(1, "Crashcode: $tcpar_Crashcode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");

	S_w2log(1, "Power on ECU");
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

	S_w2log(1, "Clear crash recorder");
    PD_ClearCrashRecorder();
    S_wait_ms(2000);

	S_w2log(1, "Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	GDCOM_init () ; # To fetch info for CD from mapping_diag
	CA_trace_start();
	S_wait_ms(2000);

	S_w2log(1, "Set environments for crash as per result DB");
	CSI_PrepareEnvironment($crashSettings, 'init_complete');
	S_wait_ms(2000);

	S_w2log(1, "Read and evaluate fault memory before stimulation");
    my $faultsBeforeStimulation = PD_ReadFaultMemory();
    my $faultsVerdict = PD_evaluate_faults( $faultsBeforeStimulation, []);
 	return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

	return 1;
}

sub TC_stimulation_and_measurement {

	$PEPedrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStoredPEP();
	unless(defined $PEPedrNumberOfEventsToBeStored){
		S_set_error("'NumberOfEventsToBeStoredPEP' not available in SYC - add or overwrite with Custlibrary Function");
		return;
	}


	S_teststep("Inject '$tcpar_Crashcode' for (NumberOfEventsToBeStored Events-1) so that 1 unlocked record is avilable.", 'AUTO_NBR');

	foreach my $crashNumber (1..$PEPedrNumberOfEventsToBeStored-1)
	{

		#--------------------------------------------------------------
		# CRASH PREPARATION AND INJECTION
		#
		S_teststep("Prepare crash", 'AUTO_NBR');
		LC_ECU_Off();
		S_wait_ms('TIMER_ECU_OFF');

		# Prepare crash
		CSI_LoadCrashSensorData2Simulator( $crashSettings );

		# Power ON the ECU
		LC_ECU_On();
		S_wait_ms('TIMER_ECU_READY');

		CSI_TriggerCrash();
		S_wait_ms(8000);

	}

	S_teststep("Wait '$tcpar_wait_ms'", 'AUTO_NBR');
	S_wait_ms($tcpar_wait_ms);

	if (defined $tcpar_COMsignalsAfterCrash){
	    S_w2log(1, "Send post crash COM signals");
		foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
		{
			my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
			S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
			COM_setSignalState($signal,$dataOnCOM);
		}
        S_wait_ms(2000);
	}

	S_teststep("Read Crash Recorder", 'AUTO_NBR', 'read_crash_recorder_First'); #measurement 1
	my $dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_".$tcpar_Crashcode."_OneBufferAvailable";

	PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');
	EDR_PEP_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
									"CrashLabel" => $tcpar_Crashcode."_OneBufferAvailable",
									"NbrOfRecords" =>  $PEPedrNumberOfEventsToBeStored,
									"StoragePath" => $dataStoragePath,
									);

	S_teststep("Inject '$tcpar_Crashcode'", 'AUTO_NBR');
	#--------------------------------------------------------------
	# CRASH PREPARATION
	#
	S_teststep("Prepare crash", 'AUTO_NBR');
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	# Prepare crash
	CSI_LoadCrashSensorData2Simulator( $crashSettings ) unless $main::opt_offline;

	# Power ON the ECU
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	CSI_TriggerCrash();

	S_teststep("Wait '$tcpar_wait_ms'", 'AUTO_NBR');
	S_wait_ms($tcpar_wait_ms);

	S_teststep("Read Crash Recorder", 'AUTO_NBR', 'read_crash_recorder_Second'); #measurement 2
	my $dataStoragePath2 = "$main::REPORT_PATH/".$tcpar_Crashcode."_NoBufferAvailable_1";

	PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');
	EDR_PEP_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
									"CrashLabel" => $tcpar_Crashcode."_NoBufferAvailable_1",
									"NbrOfRecords" =>  $PEPedrNumberOfEventsToBeStored,
									"StoragePath" => $dataStoragePath2,
									);

	#--------------------------------------------------------------
	# CRASH PREPARATION
	#
	S_teststep("Prepare crash", 'AUTO_NBR');
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	# Prepare crash
	CSI_LoadCrashSensorData2Simulator( $crashSettings ) unless $main::opt_offline;

	# Power ON the ECU
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep("Inject '$tcpar_Crashcode'", 'AUTO_NBR');
	CSI_TriggerCrash();

	S_teststep("Wait '$tcpar_wait_ms'", 'AUTO_NBR');
	S_wait_ms($tcpar_wait_ms);

	S_teststep("Read Crash Recorder ", 'AUTO_NBR', 'read_crash_recorder_Third'); #measurement 3
    my $dataStoragePath3 = "$main::REPORT_PATH/".$tcpar_Crashcode."_NoBufferAvailable_2";

	PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');
	EDR_PEP_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
									"CrashLabel" => $tcpar_Crashcode."_NoBufferAvailable_2",
									"NbrOfRecords" =>  $PEPedrNumberOfEventsToBeStored,
									"StoragePath" => $dataStoragePath3,
									);

	# This step is done in order to clear LCT of stored values
	LC_MeasureTraceDigitalStop();
	my $lct_Data = LC_MeasureTraceDigitalGetValues();

	return 1;
}

sub TC_evaluation {

	my $storageOrder = EDR_getStorageOrder ();
	unless(defined $storageOrder) {
		S_set_error("Define storage order in EDR mapping! Must be 'MostRecentFirst' or 'MostRecentLast'");
		return;
	}

    foreach my $crash (1..3)
	{
	    my $record_number;
		$record_number =  1 if ( $storageOrder  eq 'MostRecentFirst');
		$record_number = $PEPedrNumberOfEventsToBeStored if ( $storageOrder  eq 'MostRecentLast');

		my ($evalLabel, $label, $tcpar_expected_nr_of_records, $compareValues);
		if($crash == 1){
			$label= $tcpar_Crashcode."_OneBufferAvailable";
			$evalLabel = 'read_crash_recorder_First';
			$tcpar_expected_nr_of_records=$tcpar_expected_nr_of_records_First;
			$compareValues = $tcpar_CompareValues_First;
		}
		elsif($crash == 2){
			$label= $tcpar_Crashcode."_NoBufferAvailable_1";
			$evalLabel = 'read_crash_recorder_Second';
			$tcpar_expected_nr_of_records=$tcpar_expected_nr_of_records_Second;
			$compareValues = $tcpar_CompareValues_Second;
		}
		else {
			$label= $tcpar_Crashcode."_NoBufferAvailable_2";
			$evalLabel = 'read_crash_recorder_Third';
			$tcpar_expected_nr_of_records=$tcpar_expected_nr_of_records_Second;
			$compareValues = $tcpar_CompareValues_Third;
		}

		my $detectedNbrOfStoredRecords = 0;

		foreach my $recordNumber (1..$PEPedrNumberOfEventsToBeStored)
		{
			my $recordAvailable = $record_handler -> IsRecordAvailable("CrashLabel" => $label, "RecordNumber"=> $recordNumber);
			$detectedNbrOfStoredRecords++ if ($recordAvailable);
		}

		S_teststep_expected("Number of records expected is '$tcpar_expected_nr_of_records'", "$evalLabel"); #evaluation 1
		my $verdict=EVAL_evaluate_value("NumberOfRecords", $detectedNbrOfStoredRecords, '==',$tcpar_expected_nr_of_records);
		S_teststep_detected("Number of stored records is $detectedNbrOfStoredRecords", "$evalLabel");

		if ($verdict eq 'VERDICT_FAIL'){
			S_w2rep("No evaluation of EDIDs will be done since number of expected records is failed",'RED');
			return unless ($main::opt_offline);
		}


		foreach my $rawEDID (keys %{$compareValues})
		{
			my $dataElement = $record_handler -> GetDataElementEDID( "EDIDnr" => $rawEDID,
																	 "RecordNumber" => $record_number,
																	 "CrashLabel" => $label);

			S_teststep("Check EDID $rawEDID ($dataElement) in record $record_number", 'AUTO_NBR', "$evalLabel\_EDID_$rawEDID"); #measurement 2

			my $expectedValue = $compareValues -> {$rawEDID};

			my $edidData = $record_handler -> GetDecodedEDID("CrashLabel" => $label, "RecordNumber" => $record_number,"EDIDnr" => $rawEDID );
			my $detectedvalue = $edidData -> {"DataValue"};
			my $unit = $edidData -> {"ValueUnit"};

			unless(defined $detectedvalue) {
				S_set_error("No data could be obtained for EDID $rawEDID in record $record_number.");
				next;
			}

			EVAL_evaluate_value ( "EDID_$rawEDID\_Evaluation", $detectedvalue,'==', $expectedValue );

			S_teststep_expected("EDID $rawEDID : $expectedValue", "$evalLabel\_EDID_$rawEDID"); #evaluation 2
			S_teststep_detected("EDID $rawEDID : $detectedvalue", "$evalLabel\_EDID_$rawEDID");
		}
	}

	return 1;
}

sub TC_finalization {

	S_w2log(1, "Delete record objects");

	foreach my $record (1..$PEPedrNumberOfEventsToBeStored)
	{
		$record_handler -> DeleteRecord("CrashLabel" => $tcpar_Crashcode."_OneBufferAvailable", "RecordNumber" => $record);
		$record_handler -> DeleteRecord("CrashLabel" => $tcpar_Crashcode."_NoBufferAvailable_1", "RecordNumber" => $record);
		$record_handler -> DeleteRecord("CrashLabel" => $tcpar_Crashcode."_NoBufferAvailable_2", "RecordNumber" => $record);
	}


	#Clearing crash recorder
	PD_ClearCrashRecorder();
	S_wait_ms(2000);

	#Erase Fault memory
	PD_ClearFaultMemory();
	S_wait_ms(2000);

	#Read fault memory after clearing and erasing EDR
	PD_ReadFaultMemory();

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}


1;
