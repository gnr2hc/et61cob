#### TEST CASE MODULE
package TC_PEP_EDR_NHTSA_Priority;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.3 $;
our $HEADER = q$Header: PEP_EDR/TC_PEP_EDR_NHTSA_Priority.pm 1.3 2017/04/13 18:42:37ICT D Souza Deepthi Mariate (RBEI/ESA-PP3) (DDE3KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
use LIFT_PD;
use LIFT_can_access;
use GENERIC_DCOM;
use LIFT_labcar;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use LIFT_crash_simulation;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;
use Data::Dumper;

use constant EDR_STORING_ONGOING => 2;
use constant EDR_IDLE => 6;


##################################

our $PURPOSE = "To check priority between NHTSA and PEP crash";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PEP_EDR_NHTSA_Priority

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFaultNoCT


I<B<Stimulation and Measurement>>

1.Inject <Crashcode>

2. if <Condition> is Autarky

3. Wait for <Crash_T0>

4. Power OFF ECU

5. Wait for <wait_ms>.

6. Power ON ECU 

7.Wait <wait_ms>.

8.Read PEP EDR.


I<B<Evaluation>>

1. 

2.

3.

4.

5.

6.

7.

8.  <expected_nr_of_records> is stored.<FireTime_EDIDs_NHTSA>, <ExpectedValueRaw_EDIDs>, <NonDefault_EDIDs> should have <Values_NHTSA> and <FireTime_EDIDs_PEP> should have<Values_PEP>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Crashcode' => 
	SCALAR 'expected_nr_of_records' => 
	SCALAR 'purpose' => 
	SCALAR 'DiagType' => 
	SCALAR 'ResultDB' => 
	HASH 'COMsignalsAfterCrash' => 
	SCALAR 'NbrOfRecordsExpected' => 
	SCALAR 'DiagType_NHTSA' => 
	SCALAR 'DiagType_PEP' => 
	SCALAR 'Crash_T0' => 
	HASH 'ExpectedValueRaw_EDIDs' => 
	HASH 'PD_Variable_PowerOnCounter' => 
	HASH 'FireTime_EDIDs_NHTSA' => 
	HASH 'NonDefault_EDIDs' => 
	SCALAR 'wait_ms' => 
	HASH 'FireTime_EDIDs_PEP' => 
	SCALAR 'Values_NHTSA' => 
	SCALAR 'Values_PEP' => 


=head2 PARAMETER EXAMPLES

	purpose		 = 'To check storage priority when NHTSA event occur simultaneously with PEP event'
	
	DiagType  = 'PEDProEDR' 
	
	# ---------- Stimulation ------------ 
	ResultDB = 'EDR' # defined in CREIS project constants - will be set to 'DEFAULT' if not given
	
	COMsignalsAfterCrash = %() # optional parameter which provides COM signals needed to be sent after crash.
	
	# ---------- Evaluation ------------ 
	NbrOfRecordsExpected = 2
	
	DiagType_NHTSA = 'AKLV'
	DiagType_PEP = 'PEP_EDR'
	Crash_T0 = ''
	
	ExpectedValueRaw_EDIDs =%('1000' => 'A5',  '45'=> 'MultiEventNumber', '48' => 'TimeFromInitialToCurrent', '75' => 'AWL_Status', '1001' => 'IgnitionCycleEvent', '71' => '01') 
	
	PD_Variable_PowerOnCounter = %('VariableName' => 'rb_tim_EcuOnTimeDataCopyEe_st.POnCounter_u32', 'VariableType' => 'U32')
	
	FireTime_EDIDs_NHTSA = %('51' => 'AB1FD' , '52' => 'AB2FD', '56' => 'AB1FP', '57' =>'AB2FP', '58' => 'AV1FP', '63' => 'BT1FD','67' => 'BT1FP', '109' => 'BT2FD', '110' => 'BT2FP','61' => 'SA1FL', '65' => 'SA1FR', '101' => 'KA1FD','116' => 'ALLFP')
	
	NonDefault_EDIDs = %( '31' => 'FF', '22' => 'FF', '33' => 'FF',  '91' => 'FF', '92' => 'FF','95' => 'FF' )
	
	wait_ms = 10000 #ms
	FireTime_EDIDs_PEP  = %('2017' => 'HOODD', '2018' => 'HOODP','2019' => PPAB1')
	
	Values_NHTSA='NonDefault'
	Values_PEP='NonDefault'
	Crashcode = 'Multi_EDR_Pedestrian_AD_SideDriver_AD;5'
	expected_nr_of_records=2

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_DiagType;
my $tcpar_ResultDB;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_NbrOfRecordsExpected_NHTSA;
my $tcpar_NbrOfRecordsExpected_PEP;
my $tcpar_DiagType_NHTSA;
my $tcpar_DiagType_PEP;
my $tcpar_Crash_T0_NHTSA;
my $tcpar_Crash_T0_PEP;
my $tcpar_ExpectedValueRaw_EDIDs_NHTSA;
my $tcpar_ExpectedValueRaw_EDIDs_PEP;
my $tcpar_Condition;
my $tcpar_FireTime_EDIDs_NHTSA;
my $tcpar_NonDefault_EDIDs_NHTSA;
my $tcpar_NonDefault_EDIDs_PEP;
my $tcpar_wait_ms;
my $tcpar_FireTime_EDIDs_PEP;
my $tcpar_Crashcode1;
my $tcpar_Crashcode2;
my $tcpar_First_Crash;


################ global parameter declaration ###################
#add any global variables here
my ($record_handler, $crashSettings1,$crashSettings2, $PEPedrNumberOfEventsToBeStored,$edrNumberOfEventsToBeStored, $crashLabel);
my $fastDiag;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_Crashcode1 =  S_read_mandatory_testcase_parameter( 'Crashcode1' );
	$tcpar_Crashcode2 =  S_read_optional_testcase_parameter( 'Crashcode2' );
	$tcpar_First_Crash =  S_read_optional_testcase_parameter( 'First_Crash' );
	$tcpar_ResultDB =  S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_COMsignalsAfterCrash =  S_read_optional_testcase_parameter( 'COMsignalsAfterCrash' );
	$tcpar_NbrOfRecordsExpected_NHTSA =  S_read_mandatory_testcase_parameter( 'NbrOfRecordsExpected_NHTSA' );
	$tcpar_NbrOfRecordsExpected_PEP =  S_read_mandatory_testcase_parameter( 'NbrOfRecordsExpected_PEP' );
	$tcpar_DiagType_NHTSA =  S_read_mandatory_testcase_parameter( 'DiagType_NHTSA' );
	$tcpar_DiagType_PEP =  S_read_mandatory_testcase_parameter( 'DiagType_PEP' );
	$tcpar_Crash_T0_NHTSA =  S_read_mandatory_testcase_parameter( 'Crash_T0_NHTSA' );
	$tcpar_Crash_T0_PEP =  S_read_mandatory_testcase_parameter( 'Crash_T0_PEP' );
	$tcpar_ExpectedValueRaw_EDIDs_NHTSA =  S_read_mandatory_testcase_parameter( 'ExpectedValueRawNHTSA_EDIDs','byref');
	$tcpar_ExpectedValueRaw_EDIDs_PEP =  S_read_mandatory_testcase_parameter( 'ExpectedValueRawPEP_EDIDs','byref');
	$tcpar_Condition =  S_read_optional_testcase_parameter( 'Condition' );
	$tcpar_FireTime_EDIDs_NHTSA =  S_read_mandatory_testcase_parameter( 'FireTime_EDIDs_NHTSA','byref');
	$tcpar_NonDefault_EDIDs_NHTSA =  S_read_mandatory_testcase_parameter( 'NonDefault_EDIDs_NHTSA','byref');
	$tcpar_NonDefault_EDIDs_PEP =  S_read_mandatory_testcase_parameter( 'NonDefault_EDIDs_PEP','byref');
	$tcpar_wait_ms =  S_read_mandatory_testcase_parameter( 'wait_ms' );
	$tcpar_FireTime_EDIDs_PEP =  S_read_mandatory_testcase_parameter( 'FireTime_EDIDs_PEP','byref');

	$crashLabel=$tcpar_Crashcode1."_".$tcpar_Crashcode2;

	return 1;
}

sub TC_initialization {

	S_teststep("Test setup preparation", 'AUTO_NBR');

	#--------------------------------------------------------------
    # INITIALIZE RECORD HANDLER
    #    
	S_w2rep("Initialize Record Handler");
	$record_handler = EDR_init_RecordHandler() || return;

	#--------------------------------------------------------------
    # PREPARE CRASH AND INITIALIZE EQUIPMENT
    #
	S_w2rep("Get crash settings for crash $tcpar_Crashcode1");
    my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode1};
	$crashSettings1 = CSI_GetCrashDataFromMDS($crashDetails_href);
	unless(defined $crashSettings1) {
		S_set_error("Crash $tcpar_Crashcode1 not available in result DB $tcpar_ResultDB. Test case aborted.");
		return;
	}

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log(1, "Crashcode: $tcpar_Crashcode1, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");

	if (defined $tcpar_Crashcode2){
		S_w2rep("Get crash settings for crash $tcpar_Crashcode2");
		my $crashDetails2_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode2};
		$crashSettings2 = CSI_GetCrashDataFromMDS($crashDetails2_href);

		unless(defined $crashSettings2) {
			S_set_error("Crash $tcpar_Crashcode2 not available in result DB $tcpar_ResultDB. Test case aborted.");
			return;
		}
	}

    GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start();
    S_wait_ms(2000);

	S_w2log(1, "Power on ECU");
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

	S_w2log(1, "Set environments for crash as per result DB");
	CSI_PrepareEnvironment($crashSettings1, 'init_complete');
	S_wait_ms(2000);

	S_w2log(1, "Clear crash recorder");
    PD_ClearCrashRecorder();

	S_w2log(1, "Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(4000);

	S_w2log(1, "Read and evaluate fault memory before stimulation");
    my $faultsBeforeStimulation = PD_ReadFaultMemory();
    my $faultsVerdict = PD_evaluate_faults( $faultsBeforeStimulation, []);
    return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

	return 1;
}

sub TC_stimulation_and_measurement {

	#--------------------------------------------------------------
	# CRASH PREPARATION AND INJECTION
	#
	S_teststep("Prepare crash", 'AUTO_NBR');
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	# Prepare crash
	CSI_LoadCrashSensorData2Simulator($crashSettings1);
	
	# Power ON the ECU
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	#--------------------------------------------------------------
    # CRASH INJECTION
    #
	S_teststep("Start recording of fire times.", 'AUTO_NBR');
    LC_MeasureTraceDigitalStart();

	S_teststep("Inject '$tcpar_Crashcode1' ", 'AUTO_NBR');
	CSI_TriggerCrash();
	S_set_timer_zero('Crash_Timer');

	if (not defined $tcpar_Crashcode2){
		S_teststep("Start PD fast diagnosis ",'AUTO_NBR', 'FastDiag');
		$fastDiag=  PD_StartFastDiagName( $main::REPORT_PATH."/".S_get_TC_number()."_FastDiag.txt",
		              ['rb_dcrm_StateOfDCS_en','rb_pcrm_StateOfPCS_en'],
		              ['U8', 'U8'],4) if ($tcpar_First_Crash eq "NHTSA");
	}

	my $time_SecondInjection_ms;
	if (defined $tcpar_Crashcode2){
		# Prepare crash
		S_wait_ms(10000);
		CSI_LoadCrashSensorData2Simulator($crashSettings2);
		S_teststep("Inject '$tcpar_Crashcode2' ", 'AUTO_NBR');
		CSI_TriggerCrash();
		$time_SecondInjection_ms = S_read_timer_ms('Crash_Timer');
	}

	if ($tcpar_Condition eq 'Autarky'){
		if ($tcpar_Crash_T0_NHTSA > $tcpar_Crash_T0_PEP){
			S_teststep("Wait for '$tcpar_Crash_T0_NHTSA'", 'AUTO_NBR');
			S_wait_ms($tcpar_Crash_T0_NHTSA);
		}
		else {
			S_teststep("Wait for '$tcpar_Crash_T0_PEP'", 'AUTO_NBR');
			S_wait_ms($tcpar_Crash_T0_PEP);
		}

		S_teststep("Switch off power if condition is '$tcpar_Condition' ", 'AUTO_NBR');

		LC_ECU_Off();
		S_wait_ms('TIMER_ECU_OFF');

		LC_ECU_On();
		S_wait_ms('TIMER_ECU_READY');
	}
	else {

		S_teststep("Wait '$tcpar_wait_ms'.", 'AUTO_NBR');
		S_wait_ms($tcpar_wait_ms);
	}

	if ($fastDiag){
	    PD_StopFastDiag();
	}

	S_teststep("Stop recording of fire times", 'AUTO_NBR');
    LC_MeasureTraceDigitalStop();

	if (defined $time_SecondInjection_ms) {
		S_w2rep("Two crash codes were injected - therefore T0 time of second crash code ".
		          "must be adapted to include the time between first and second injection ($time_SecondInjection_ms ms).");
		# add measured time between first and second injection to T0 of second incident
		if ($tcpar_First_Crash eq 'NHTSA'){
			$tcpar_Crash_T0_PEP = $tcpar_Crash_T0_PEP + $time_SecondInjection_ms;
			S_w2rep("Adapted T0 of second incident in ms: $tcpar_Crash_T0_PEP");
		}
		else {
			$tcpar_Crash_T0_NHTSA = $tcpar_Crash_T0_NHTSA + $time_SecondInjection_ms;
			S_w2rep("Adapted T0 of second incident in ms: $tcpar_Crash_T0_NHTSA");
		}
	}

	S_teststep("Read NHTSA EDR.", 'AUTO_NBR', 'read_NHTSA_edr'); #measurement 1
	my $dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_"."NHTSA_Crash";

	$edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();
	unless(defined $edrNumberOfEventsToBeStored){
		S_set_error("Not available in SYC - add or overwrite with Custlibrary Function");
		return;
	}

	EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType_NHTSA,
								"CrashLabel" => "NHTSA_Crash",
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								);

		
	my $lct_Data = LC_MeasureTraceDigitalGetValues();
	EVAL_dump2UNV( $lct_Data, "$dataStoragePath/LCT_Measurement_$crashLabel.txt.unv" );
	
	S_teststep("Compare Deployment_EDIDs to LCT measurement for NHTSA EDR.", 'AUTO_NBR', 'compare_deployment_edids_NHTSA'); #measurement 2

	# Get list of all measured squib labels
	my $squibLabels_aref;
	foreach my $lctEDID (keys %{$tcpar_FireTime_EDIDs_NHTSA})
	{
		push(@{$squibLabels_aref}, $tcpar_FireTime_EDIDs_NHTSA -> {$lctEDID});
	}

	EDR_addFireTimesToCrashHandler ("LCT_Measurement" => $lct_Data,
									"SquibLabels" => $squibLabels_aref,
									"CrashLabel"  => "NHTSA_Crash");
							

	my $rawEDIDsString;
	foreach my $rawEDID (keys %{$tcpar_ExpectedValueRaw_EDIDs_NHTSA})
	{
		if(defined $rawEDIDsString) {
			$rawEDIDsString .= ", ";
		}
		$rawEDIDsString .= $rawEDID;
	}
	S_teststep("Compare EDIDs $rawEDIDsString to expected values", 'AUTO_NBR', 'compare_all_rawEDIDs_NHTSA'); #measurement 3

    $rawEDIDsString = undef;
	foreach my $rawEDID (keys %{$tcpar_NonDefault_EDIDs_NHTSA})
	{
		if(defined $rawEDIDsString) {
			$rawEDIDsString .= ", ";
		}
		$rawEDIDsString .= $rawEDID;
	}
	S_teststep("Check that EDIDs $rawEDIDsString are stored with non default values", 'AUTO_NBR', 'compare_all_nonDefaultEDIDs_NHTSA'); #measurement 4

	S_teststep("Read PEP EDR.", 'AUTO_NBR', 'read_pep_edr'); #measurement 5
	$dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_"."PEP_Crash";

	$PEPedrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStoredPEP();
	unless(defined $PEPedrNumberOfEventsToBeStored){
		S_set_error("Not available in SYC - add or overwrite with Custlibrary Function");
		return;
	}

	PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');
	EDR_PEP_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType_PEP,
									"CrashLabel" => "PEP_Crash",
									"NbrOfRecords" =>  $PEPedrNumberOfEventsToBeStored,
									"StoragePath" => $dataStoragePath,
									);

	if (not defined $tcpar_Condition){
		S_teststep("Compare Deployment_EDIDs to LCT measurement for PEP EDR.", 'AUTO_NBR', 'compare_deployment_edids_PEP'); #measurement 6

		# Get list of all measured squib labels
		$squibLabels_aref = undef;
		foreach my $lctEDID (keys %{$tcpar_FireTime_EDIDs_PEP})
		{
			push(@{$squibLabels_aref}, $tcpar_FireTime_EDIDs_PEP -> {$lctEDID});
		}

		EDR_addFireTimesToCrashHandler ("LCT_Measurement" => $lct_Data,
										"SquibLabels" => $squibLabels_aref,
										"CrashLabel"  => "PEP_Crash");

		$rawEDIDsString = undef;
		foreach my $rawEDID (keys %{$tcpar_ExpectedValueRaw_EDIDs_PEP})
		{
			if(defined $rawEDIDsString) {
				$rawEDIDsString .= ", ";
			}
			$rawEDIDsString .= $rawEDID;
		}
		S_teststep("Compare EDIDs $rawEDIDsString to expected values", 'AUTO_NBR', 'compare_all_rawEDIDs_PEP'); #measurement 7

        $rawEDIDsString = undef;
		foreach my $rawEDID (keys %{$tcpar_NonDefault_EDIDs_PEP})
		{
			if(defined $rawEDIDsString) {
				$rawEDIDsString .= ", ";
			}
			$rawEDIDsString .= $rawEDID;
		}
		S_teststep("Check that EDIDs $rawEDIDsString are stored with non default values", 'AUTO_NBR', 'compare_all_nonDefaultEDIDs_PEP'); #measurement 8
	}

	return 1;
}

sub TC_evaluation {

    # Fast Diagnosis Evaluation
	if ($fastDiag){
		my $data_HoH = PD_get_FDtrace( $main::REPORT_PATH."/".S_get_TC_number()."_FastDiag.txt");
		my $measure_time_NHTSA_FirstInstance = EVAL_get_time_when ( $data_HoH, 'rb_dcrm_StateOfDCS_en', '==', EDR_STORING_ONGOING);
		my $measure_time_PEP_FirstInstance = EVAL_get_time_when ( $data_HoH , 'rb_pcrm_StateOfPCS_en', '==', EDR_STORING_ONGOING);
		my $measure_time_NHTSA = EVAL_get_time_when ( $data_HoH, 'rb_dcrm_StateOfDCS_en', '==', EDR_IDLE, $measure_time_NHTSA_FirstInstance );
		my $measure_time_PEP = EVAL_get_time_when ( $data_HoH , 'rb_pcrm_StateOfPCS_en', '==', EDR_IDLE, $measure_time_PEP_FirstInstance);

		S_teststep_expected("NHTSA EDR storage should be completed first", 'FastDiag');

		if ( (defined $measure_time_NHTSA) and (defined $measure_time_PEP)){
			S_teststep_detected("NHTSA EDR storage is completed at $measure_time_NHTSA, PEP EDR storage is completed at $measure_time_PEP",
			                     'FastDiag');
								 
			my $storage_verdict = EVAL_evaluate_value ( "Comparision of NHTSA EDR and PEP EDR storage completion time" , $measure_time_NHTSA, '<', $measure_time_PEP );
			if ($storage_verdict eq 'VERDICT_PASS'){
				S_w2rep(" NHTSA EDR storage is completed first, time :$measure_time_NHTSA");
			}
			elsif($storage_verdict eq 'VERDICT_FAIL'){
				S_w2rep(" PEP EDR storage is completed first: $measure_time_PEP");
			}
		}
		else {
			S_teststep_detected(" NHTSA, PEP EDR storage start timings are not available, check if fast diagnosis was active or if EDR is empty", 'FastDiag');
			S_set_error ("Measurement is failed due to non availability of fast diagnosis data ");
			return ;
		}
	}

    #--------------------------------------------------------------
    # NUMBER OF EXPECTED RECORDS
    #
    S_w2rep("");
    S_w2rep("--------------------------------------------------------", 'purple');
    S_w2rep("NUMBER OF EXPECTED RECORDS FOR NHTSA EDR", 'purple');
    my $detectedNbrOfStoredRecords = 0;
    foreach my $recordNumber(1..$edrNumberOfEventsToBeStored)
    {
        my $recordAvailable = $record_handler -> IsRecordAvailable("CrashLabel" => "NHTSA_Crash", "RecordNumber"=> $recordNumber);
        $detectedNbrOfStoredRecords++ if ($recordAvailable);
    }
    S_teststep_expected("Number of records in NHTSA EDR expected is '$tcpar_NbrOfRecordsExpected_NHTSA'", 'read_NHTSA_edr'); #evaluation 1
    my $verdict=EVAL_evaluate_value("NumberOfRecords", $detectedNbrOfStoredRecords, '==',$tcpar_NbrOfRecordsExpected_NHTSA);
    S_teststep_detected("Number of stored records in NHTSA EDR is $detectedNbrOfStoredRecords", 'read_NHTSA_edr');


	if ($verdict eq "VERDICT_PASS" and not $main::opt_offline){
		#--------------------------------------------------------------
		# FIRE TIMES
		#
        S_teststep("--- DEPLOYMENT TIMES FOR NHTSA EDR ---", 'NO_AUTO_NBR');
		S_teststep_expected_NOHTML("--- DEPLOYMENT TIMES FOR NHTSA EDR ---");
        S_teststep_detected_NOHTML("--- DEPLOYMENT TIMES FOR NHTSA EDR ---");
		my $squibVerdict = EDR_Eval_SquibFireTimes("CrashLabel" => "NHTSA_Crash",
												   "EDID_SquibLabels" => $tcpar_FireTime_EDIDs_NHTSA,
												   "CrashTimeZero_ms" => $tcpar_Crash_T0_NHTSA,
												   "FireTimeTolerance_ms" => 3);

		S_teststep_expected("Deployment times stored in EDR are as measured.", 'compare_deployment_edids_NHTSA'); #evaluation 2
		S_teststep_detected("Deployment times in EDR are as measured", 'compare_deployment_edids_NHTSA') if $squibVerdict eq 'VERDICT_PASS';
		S_teststep_detected("Deployment times in EDR are not as measured", 'compare_deployment_edids_NHTSA') if $squibVerdict eq 'VERDICT_FAIL';

		 #--------------------------------------------------------------
		# RAW VALUES
		#
		my $rawValuesVerdict = 'VERDICT_PASS'; #evaluation 3

		S_teststep("--- RAW VALUES FOR NHTSA EDR ---", 'NO_AUTO_NBR');
        S_teststep_expected_NOHTML("--- RAW VALUES FOR NHTSA EDR ---");
        S_teststep_detected_NOHTML("--- RAW VALUES FOR NHTSA EDR ---");
		foreach my $rawEDID (keys %{$tcpar_ExpectedValueRaw_EDIDs_NHTSA})
		{
			my $expectedRawValue = $tcpar_ExpectedValueRaw_EDIDs_NHTSA -> {$rawEDID};
			my $dataElement = $record_handler -> GetDataElementEDID( "EDIDnr" => $rawEDID, "RecordNumber" => 1,
																	 "CrashLabel" => "NHTSA_Crash");

			S_teststep("EDID $rawEDID ($dataElement)", 'NO_AUTO_NBR');
            S_teststep_expected_NOHTML("EDID $rawEDID ($dataElement)");
            S_teststep_detected_NOHTML("EDID $rawEDID ($dataElement)");

			for(my $recordNumber = 1; $recordNumber <= $tcpar_NbrOfRecordsExpected_NHTSA; $recordNumber ++)
			{
				S_teststep_2nd_level("Get EDID $rawEDID data for NHTSA EDR, Record $recordNumber", 'AUTO_NBR', "EDID_$rawEDID\_record_$recordNumber");
				my $detectedEDIDvalue = $record_handler -> GetRawEDID( "EDIDnr" => $rawEDID,
														   "RecordNumber" => $recordNumber,
														   "CrashLabel" => "NHTSA_Crash",
														   "FormatOption" => "HEX");

				$detectedEDIDvalue = 'FF' if($main::opt_offline);

				unless(defined $detectedEDIDvalue) {
					S_set_error("No data could be obtained for EDID $rawEDID.");
					next;
				}
                S_teststep_expected("Record $recordNumber: $expectedRawValue",  "EDID_$rawEDID\_record_$recordNumber");
                S_teststep_detected("Record $recordNumber: $detectedEDIDvalue",  "EDID_$rawEDID\_record_$recordNumber");
				my $rawValueVerdict = EVAL_evaluate_string ( "EDID_$rawEDID\_Evaluation", $expectedRawValue, $detectedEDIDvalue );
				$rawValuesVerdict = 'VERDICT_FAIL' if $verdict eq 'VERDICT_FAIL';
			}
		}

		S_teststep_expected("Value of all EDIDs with fixed expected raw value is as expected.",
		                      'compare_all_rawEDIDs_NHTSA'); #evaluation 4
		S_teststep_detected("Value of all EDIDs with fixed expected raw value is as expected.",
		                      'compare_all_rawEDIDs_NHTSA')  if $rawValuesVerdict eq 'VERDICT_PASS';
		S_teststep_detected("Value of all EDIDs with fixed expected raw value is not as expected.",
		                      'compare_all_rawEDIDs_NHTSA')if $rawValuesVerdict eq 'VERDICT_FAIL';

		#--------------------------------------------------------------
		# NON DEFAULT VALUES
		#
        S_teststep("--- NON DEFAULT VALUE FOR NHTSA EDR ---", 'NO_AUTO_NBR');
        S_teststep_expected_NOHTML("--- NON DEFAULT VALUE FOR NHTSA EDR ---");
        S_teststep_detected_NOHTML("--- NON DEFAULT VALUE FOR NHTSA EDR ---");
		my $nonDefaultValuesVerdict = 'VERDICT_PASS';

        my $nonDefaultEDIDstring;
        foreach my $nonDefaultEDID (keys %{$tcpar_NonDefault_EDIDs_NHTSA})
        {
            if(defined $nonDefaultEDIDstring) {
                $nonDefaultEDIDstring .= ", ";
            }
            $nonDefaultEDIDstring .= $nonDefaultEDID;

    		my $defaultValue = $tcpar_NonDefault_EDIDs_NHTSA -> {$nonDefaultEDID};
    		my $dataElement = $record_handler -> GetDataElementEDID( "EDIDnr" => $nonDefaultEDID, "RecordNumber" => 1,
    																  "CrashLabel" => "NHTSA_Crash");

            S_teststep("EDID $nonDefaultEDID ($dataElement)", 'NO_AUTO_NBR');
            S_teststep_expected_NOHTML("EDID $nonDefaultEDID ($dataElement)");
            S_teststep_detected_NOHTML("EDID $nonDefaultEDID ($dataElement)");

            foreach my $recordNumber (1..$tcpar_NbrOfRecordsExpected_NHTSA)
			{
                S_teststep_2nd_level("Get EDID $nonDefaultEDID data for NHTSA EDR, Record $recordNumber", 'AUTO_NBR',
                                        "EDID_$nonDefaultEDID\_record_$recordNumber");
				S_w2log(1, "Get EDID data for NHTSA EDR, Record $recordNumber");
				my $detectedEDIDvalue = $record_handler -> GetRawEDID( "EDIDnr" => $nonDefaultEDID,
														   "RecordNumber" => $recordNumber,
														   "CrashLabel" => "NHTSA_Crash",
														   "FormatOption" => "HEX");

				$detectedEDIDvalue = 'FF' if($main::opt_offline);

				unless(defined $detectedEDIDvalue) {
					S_set_error("No data could be obtained for EDID $nonDefaultEDID.");
					next;
				}

				S_w2log(1, "Compare expected and detected values", 'AUTO_NBR');
				if(ref $detectedEDIDvalue eq 'ARRAY') {
				    my $detectedString;
					foreach my $edidValue (@{$detectedEDIDvalue})
					{
					   my $verdictThisSample = EVAL_evaluate_string ( "EDID_$nonDefaultEDID\_Evaluation", $defaultValue, $edidValue, '!=');
					   $detectedString .= $edidValue." ";
					   $nonDefaultValuesVerdict = 'VERDICT_FAIL' if $verdictThisSample eq 'VERDICT_FAIL';
					}
                    S_teststep_expected("Record $recordNumber: all samples other than $defaultValue",  "EDID_$nonDefaultEDID\_record_$recordNumber");
                    S_teststep_detected("Record $recordNumber: $detectedString",  "EDID_$nonDefaultEDID\_record_$recordNumber");
				}
				else {
                    S_teststep_expected("Record $recordNumber: other than $defaultValue",  "EDID_$nonDefaultEDID\_record_$recordNumber");
                    S_teststep_detected("Record $recordNumber: $detectedEDIDvalue",  "EDID_$nonDefaultEDID\_record_$recordNumber");
					my $verdictThisEDID = EVAL_evaluate_string ( "EDID_$nonDefaultEDID\_Evaluation", $defaultValue, $detectedEDIDvalue, '!=');
					$nonDefaultValuesVerdict = 'VERDICT_FAIL' if $verdictThisEDID eq 'VERDICT_FAIL';
				}
				
			}#next Record
			
		}#next EDID

		S_teststep_expected("EDIDs $nonDefaultEDIDstring are stored with non-default values.",
		                      'compare_all_nonDefaultEDIDs_NHTSA'); #evaluation 4
		S_teststep_detected("EDIDs $nonDefaultEDIDstring are stored with non-default values.",
		                      'compare_all_nonDefaultEDIDs_NHTSA')  if $nonDefaultValuesVerdict eq 'VERDICT_PASS';
		S_teststep_detected("Not all EDIDs $nonDefaultEDIDstring are stored with non-default values.",
		                      'compare_all_nonDefaultEDIDs_NHTSA')if $nonDefaultValuesVerdict eq 'VERDICT_FAIL';
	}
	else {
		S_w2rep(" Expected number of records for NHTSA EDR do not match with detected records, hence no evaluation will be done further");
	}

	#--------------------------------------------------------------
    # NUMBER OF EXPECTED RECORDS
    #
	S_w2rep("");
	S_w2rep("--------------------------------------------------------", 'purple');
	S_w2rep("NUMBER OF EXPECTED RECORDS FOR PEP EDR", 'purple');
	my $detectedNbrOfStoredRecordsPEP = 0;
	foreach my $recordNumber (1..$PEPedrNumberOfEventsToBeStored)
	{
		my $recordAvailable = $record_handler -> IsRecordAvailable("CrashLabel" => "PEP_Crash", "RecordNumber"=> $recordNumber);
		$detectedNbrOfStoredRecordsPEP++ if ($recordAvailable);
	}
	S_teststep_expected("Number of records expected is '$tcpar_NbrOfRecordsExpected_PEP'", 'read_pep_edr'); #evaluation 5
	my $verdictPEPNbrOfRecords=EVAL_evaluate_value("NumberOfRecords", $detectedNbrOfStoredRecordsPEP, '==',$tcpar_NbrOfRecordsExpected_PEP);
	S_teststep_detected("Number of stored records is $detectedNbrOfStoredRecordsPEP", 'read_pep_edr');
	if ($verdictPEPNbrOfRecords eq "VERDICT_FAIL" and not $main::opt_offline){
		S_w2rep(" Expected number of records do not match with detected records, hence no evaluation will be done further");
		return 1;
	}

	if ($verdictPEPNbrOfRecords eq "VERDICT_PASS" and defined $tcpar_Condition and not $main::opt_offline){
		S_w2rep(" Expected number of records is '$tcpar_NbrOfRecordsExpected_PEP' during autarky, hence no evaluation will be done further");
		return 1;
	}

	if (not defined $tcpar_Condition) {
		#--------------------------------------------------------------
		# FIRE TIMES
		#
        S_teststep("--- DEPLOYMENT TIMES FOR PEP EDR ---", 'NO_AUTO_NBR');
        S_teststep_expected_NOHTML("--- DEPLOYMENT TIMES FOR PEP EDR ---");
        S_teststep_detected_NOHTML("--- DEPLOYMENT TIMES FOR PEP EDR ---");
		my $squibVerdict = EDR_Eval_SquibFireTimes("CrashLabel" => "PEP_Crash",
												   "EDID_SquibLabels" => $tcpar_FireTime_EDIDs_PEP,
												   "CrashTimeZero_ms" => $tcpar_Crash_T0_PEP,
												   "FireTimeTolerance_ms" => 3);

		S_teststep_expected("Deployment times stored in EDR are as measured.", 'compare_deployment_edids_PEP'); #evaluation 2
		S_teststep_detected("Deployment times in EDR are as measured", 'compare_deployment_edids_PEP') if $squibVerdict eq 'VERDICT_PASS';
		S_teststep_detected("Deployment times in EDR are not as measured", 'compare_deployment_edids_PEP') if $squibVerdict eq 'VERDICT_FAIL';

		#--------------------------------------------------------------
		# RAW VALUES
		#
		my $rawValuesVerdict = 'VERDICT_PASS'; #evaluation 3

        S_teststep("--- RAW VALUES FOR PEP EDR ---", 'NO_AUTO_NBR');
        S_teststep_expected_NOHTML("--- RAW VALUES FOR PEP EDR ---");
        S_teststep_detected_NOHTML("--- RAW VALUES FOR PEP EDR ---");
		foreach my $rawEDID (keys %{$tcpar_ExpectedValueRaw_EDIDs_PEP})
		{
			my $expectedRawValue = $tcpar_ExpectedValueRaw_EDIDs_PEP -> {$rawEDID};
			my $dataElement = $record_handler -> GetDataElementEDID( "EDIDnr" => $rawEDID, "RecordNumber" => 1,
																	 "CrashLabel" => "PEP_Crash");

            S_teststep("EDID $rawEDID ($dataElement)", 'NO_AUTO_NBR');
            S_teststep_expected_NOHTML("EDID $rawEDID ($dataElement)");
            S_teststep_detected_NOHTML("EDID $rawEDID ($dataElement)");

			for(my $recordNumber = 1; $recordNumber <= $tcpar_NbrOfRecordsExpected_PEP; $recordNumber ++)
			{

                S_teststep_2nd_level("Get EDID $rawEDID data for NHTSA EDR, Record $recordNumber", 'AUTO_NBR',
                                        "PEP_EDID_$rawEDID\_record_$recordNumber");
				my $detectedEDIDvalue = $record_handler -> GetRawEDID( "EDIDnr" => $rawEDID,
														   "RecordNumber" => $recordNumber,
														   "CrashLabel" => "PEP_Crash",
														   "FormatOption" => "HEX");

				$detectedEDIDvalue = 'FF' if($main::opt_offline);

				unless(defined $detectedEDIDvalue) {
					S_set_error("No data could be obtained for EDID $rawEDID.");
					next;
				}

                S_teststep_expected("Record $recordNumber: $expectedRawValue",  "PEP_EDID_$rawEDID\_record_$recordNumber");
                S_teststep_detected("Record $recordNumber: $detectedEDIDvalue",  "PEP_EDID_$rawEDID\_record_$recordNumber");
				my $thisVerdict = EVAL_evaluate_string ( "EDID_$rawEDID\_Evaluation", $expectedRawValue, $detectedEDIDvalue );
				$rawValuesVerdict = 'VERDICT_FAIL' if $thisVerdict eq 'VERDICT_FAIL';
			}
		}

		S_teststep_expected("Value of all EDIDs with fixed expected raw value is as expected.",
		                      'compare_all_rawEDIDs_PEP'); #evaluation 4
		S_teststep_detected("Value of all EDIDs with fixed expected raw value is as expected.",
		                      'compare_all_rawEDIDs_PEP')  if $rawValuesVerdict eq 'VERDICT_PASS';
		S_teststep_detected("Value of all EDIDs with fixed expected raw value is not as expected.",
		                      'compare_all_rawEDIDs_PEP')if $rawValuesVerdict eq 'VERDICT_FAIL';

		#--------------------------------------------------------------
		# NON DEFAULT VALUES
		#
        S_teststep("--- NON DEFAULT VALUE FOR PEP EDR ---", 'NO_AUTO_NBR');
        S_teststep_expected_NOHTML("--- NON DEFAULT VALUE FOR PEP EDR ---");
        S_teststep_detected_NOHTML("--- NON DEFAULT VALUE FOR PEP EDR ---");

		my $nonDefaultValuesVerdict = 'VERDICT_PASS';
		my $nonDefaultEDIDstring;

		foreach my $nonDefaultEDID (keys %{$tcpar_NonDefault_EDIDs_PEP})
		{
			if(defined $nonDefaultEDIDstring) {
				$nonDefaultEDIDstring .= ", ";
			}
    		$nonDefaultEDIDstring .= $nonDefaultEDID;

    		my $defaultValue = $tcpar_NonDefault_EDIDs_PEP -> {$nonDefaultEDID};
    		my $dataElement = $record_handler -> GetDataElementEDID( "EDIDnr" => $nonDefaultEDID, "RecordNumber" => 1,
    																  "CrashLabel" => "PEP_Crash");

            S_teststep("EDID $nonDefaultEDID ($dataElement)", 'NO_AUTO_NBR');
            S_teststep_expected_NOHTML("EDID $nonDefaultEDID ($dataElement)");
            S_teststep_detected_NOHTML("EDID $nonDefaultEDID ($dataElement)");
    
            foreach my $recordNumber (1..$tcpar_NbrOfRecordsExpected_PEP)
			{
                S_teststep_2nd_level("Get EDID $nonDefaultEDID data for NHTSA EDR, Record $recordNumber", 'AUTO_NBR',
                                        "PEP_EDID_$nonDefaultEDID\_record_$recordNumber");
				my $detectedEDIDvalue = $record_handler -> GetRawEDID( "EDIDnr" => $nonDefaultEDID,
														   "RecordNumber" => $recordNumber,
														   "CrashLabel" => "PEP_Crash",
														   "FormatOption" => "HEX");

				$detectedEDIDvalue = 'FF' if($main::opt_offline);

				unless(defined $detectedEDIDvalue) {
					S_set_error("No data could be obtained for EDID $nonDefaultEDID.");
					next;
				}

				S_w2log(1, "Compare expected and detected values", 'AUTO_NBR');
				if(ref $detectedEDIDvalue eq 'ARRAY') {
                    my $detectedString;
					foreach my $edidValue (@{$detectedEDIDvalue})
					{
					   my $thisSampleVerdict = EVAL_evaluate_string ( "EDID_$nonDefaultEDID\_Evaluation", $defaultValue, $edidValue, '!=');
                       $detectedString .= $edidValue." ";
					   $nonDefaultValuesVerdict = 'VERDICT_FAIL' if $thisSampleVerdict eq 'VERDICT_FAIL';
					}
                    S_teststep_expected("Record $recordNumber: all samples other than $defaultValue",
                                            "PEP_EDID_$nonDefaultEDID\_record_$recordNumber");
                    S_teststep_detected("Record $recordNumber: $detectedString",
                                            "PEP_EDID_$nonDefaultEDID\_record_$recordNumber");

				}
				else {
                    S_teststep_expected("Record $recordNumber: other than $defaultValue",  "PEP_EDID_$nonDefaultEDID\_record_$recordNumber");
                    S_teststep_detected("Record $recordNumber: $detectedEDIDvalue",  "PEP_EDID_$nonDefaultEDID\_record_$recordNumber");
					my $thisVerdict = EVAL_evaluate_string ( "EDID_$nonDefaultEDID\_Evaluation", $defaultValue, $detectedEDIDvalue, '!=');
					$nonDefaultValuesVerdict = 'VERDICT_FAIL' if $thisVerdict eq 'VERDICT_FAIL';
				}
				#next Record
			}
			#next EDID
		}
		S_teststep_expected("EDIDs $nonDefaultEDIDstring are stored with non-default values.", 'compare_all_nonDefaultEDIDs_PEP'); #evaluation 4
		S_teststep_detected("EDIDs $nonDefaultEDIDstring are stored with non-default values.",
		                      'compare_all_nonDefaultEDIDs_PEP')  if $nonDefaultValuesVerdict eq 'VERDICT_PASS';
		S_teststep_detected("Not all EDIDs $nonDefaultEDIDstring are stored with non-default values.",
		                      'compare_all_nonDefaultEDIDs_PEP')if $nonDefaultValuesVerdict eq 'VERDICT_FAIL';
	}
	return 1;
}

sub TC_finalization {

	S_w2rep("Start test case finalization...");

	# Erase EDR
    PD_ClearCrashRecorder();

	# Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(5000);

	# Read fault memory after clearing and erasing EDR
    PD_ReadFaultMemory();
	S_wait_ms(2000);

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

	S_w2rep("Clean up record handler");
    $record_handler -> DeleteAllRecords();

	return 1;
}


1;
