#### TEST CASE MODULE
package TC_PEP_EDR_PedPro_UseCases;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.2 $;
our $HEADER = q$Header: PEP_EDR/TC_PEP_EDR_PedPro_UseCases.pm 1.2 2017/04/13 16:45:05ICT Baeuerle Katharina (CC-PS/EPS2) (ZIK1ABT) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_PD;
use LIFT_can_access;
use GENERIC_DCOM;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;
use Data::Dumper;

##################################

our $PURPOSE = "To check for use case scenarios for Pedestrian Protection";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PEP_EDR_PedPro_UseCases

=head1 PURPOSE

<To check for use case scenarios for Pedestrian Protection>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Start measurement fire times

2. Prepare and Inject PedPro Crash Scenario

3. Stop measurement of fire times

4. Read PEPEDR Record 1

5. Compare Fire times stored in record to those measured with respect to <CrashTimeZero>


I<B<Evaluation>>

1. -

2. -  

3. - 

4. Valid record if <PEP_Record_Expected> equals yes

5. Expect fire times <PEP_TimeToDeploy_Expected >measured and stored to match.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Crashtype' => 
	SCALAR 'PEP_Record_Expected' => 
	SCALAR 'CrashTimeZero' => 
	SCALAR 'purpose' => 
	SCALAR 'EDR_SPECIAL_EVENT_SET' => 
	HASH 'COMsignalsAfterCrash' => 
	SCALAR 'ResultDB' => 
	SCALAR 'wait_ms' => 
	SCALAR 'DiagType' => 
	SCALAR 'EvalTolerance_abs' => 


=head2 PARAMETER EXAMPLES

	purpose		 = 'Perform use case scenarios for Pedestrian Protection.'
	
	# ---------- Stimulation ------------ 
	#data from SYC
	#EDR_SPECIAL_EVENT_SET= '<Fetch {V_AB12_JLR_X540_TT}{(PedPro|Rollover|Front|Side)}>'
	EDR_SPECIAL_EVENT_SET= 'Pedestrian' 
	COMsignalsAfterCrash = %()
	
	ResultDB = 'EDR'
	wait_ms = 15000 #ms
	DiagType = 'PEDProEDR'
	
	# ---------- Evaluation ------------ 
	EvalTolerance_abs = 3 #ms
	Crashtype = 'Single_EDR_PedPro_NoDeployment;5'
	PEP_Record_Expected = '0'
	CrashTimeZero = '46.26'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_ResultDB;
my $tcpar_wait_ms;
my $tcpar_DiagType;
my $tcpar_EvalTolerance_abs;
my $tcpar_Crashcode;
my $tcpar_PEP_Record_Expected;
my $tcpar_CrashTimeZero;
my $tcpar_PEP_TimeToDeploy_Expected;

################ global parameter declaration ###################
#add any global variables here
my ($record_handler, $crashSettings, $PEPedrNumberOfEventsToBeStored);

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_COMsignalsAfterCrash =  S_read_optional_testcase_parameter( 'COMsignalsAfterCrash' ,'byref');
	$tcpar_ResultDB =  S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_wait_ms =  S_read_mandatory_testcase_parameter( 'wait_ms' );
	$tcpar_DiagType =  S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_EvalTolerance_abs =  S_read_mandatory_testcase_parameter( 'EvalTolerance_abs' );
	$tcpar_Crashcode =  S_read_mandatory_testcase_parameter( 'Crashtype' );
	$tcpar_PEP_Record_Expected =  S_read_mandatory_testcase_parameter( 'PEP_Record_Expected' );
	$tcpar_CrashTimeZero =  S_read_mandatory_testcase_parameter( 'CrashTimeZero' );
	$tcpar_PEP_TimeToDeploy_Expected=S_read_optional_testcase_parameter('PEP_TimeToDeploy_Expected','byref');

	return 1;
}

sub TC_initialization {

#--------------------------------------------------------------
    # INITIALIZE RECORD HANDLER
    #    
	S_w2rep("Initialize Record Handler");
	$record_handler = EDR_init_RecordHandler() || return;

	S_w2log(1, "Power on ECU");
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

	S_w2log(1, "Clear crash recorder");
    PD_ClearCrashRecorder();
    S_wait_ms(2000);

	S_w2log(1, "Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);
	
    S_w2log(1, "Init CD and start CAN trace");
	GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start();

	S_w2log(1, "Read and evaluate fault memory before stimulation");
    my $faultsBeforeStimulation = PD_ReadFaultMemory();
    my $faultsVerdict = PD_evaluate_faults_NOVERDICT( $faultsBeforeStimulation, []);
    return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

	#--------------------------------------------------------------
    # CRASH PREPARATION
	S_teststep("Prepare crash", 'AUTO_NBR');

	# PREPARE CRASH AND INITIALIZE EQUIPMENT
	S_w2log(1, "Get crash settings for crash $tcpar_Crashcode");
	my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode};
	$crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
	if(not defined $crashSettings and not $main::opt_offline) {
		S_set_error("Crash code $tcpar_Crashcode not defined in given result DB. Test case will be aborted.", 110);
		return;
	}
	if( $main::opt_offline) {
		$crashSettings -> { 'CRASHNAME' } = $tcpar_Crashcode;
	}

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log(1, "Crashcode: $tcpar_Crashcode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");

	S_w2log(1, "Set environments for crash as per result DB");
	CSI_PrepareEnvironment($crashSettings,'init_complete');
	S_wait_ms('TIMER_ECU_READY');

    S_w2log(1, "Download crash sensor data to simulator");
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_READY');

	#Prepare crash
	CSI_LoadCrashSensorData2Simulator( $crashSettings );
	S_wait_ms(2000);

	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	return 1;
}

sub TC_stimulation_and_measurement {
	
	#--------------------------------------------------------------
    # CRASH INJECTION
    #
	S_teststep("Start recording of fire times.", 'AUTO_NBR');
    LC_MeasureTraceDigitalStart();

	S_teststep("Inject '$tcpar_Crashcode'", 'AUTO_NBR');
	CSI_TriggerCrash();

	S_teststep("Wait for '$tcpar_wait_ms'", 'AUTO_NBR');
    S_wait_ms($tcpar_wait_ms);

	S_teststep("Stop recording of fire times", 'AUTO_NBR');
    LC_MeasureTraceDigitalStop();

	if (defined $tcpar_COMsignalsAfterCrash){
	    S_w2log(1, "Send post crash COM signals");
		foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
		{
			my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
			S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
			COM_setSignalState($signal,$dataOnCOM);
		}
        S_wait_ms(2000);
	}

	#--------------------------------------------------------------
    # MEASUREMENTS
    #

	S_teststep("Read PEPPEP EDR", 'AUTO_NBR','read_pepedr_record'); #measurement 1
	my $dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number().$tcpar_Crashcode;

	$PEPedrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStoredPEP();
	unless(defined $PEPedrNumberOfEventsToBeStored){
		S_set_error("Not available in SYC - add or overwrite with Custlibrary Function");
		return;
	}

	PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');
	EDR_PEP_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
								    "CrashLabel" => $tcpar_Crashcode,
								    "NbrOfRecords" =>  $PEPedrNumberOfEventsToBeStored,
								    "StoragePath" => $dataStoragePath,
								    );


	S_teststep("Compare Fire times stored in record to those measured with respect to '$tcpar_CrashTimeZero'",
	               'AUTO_NBR', 'compare_fire_times'); #measurement 2

    my $lct_Data = LC_MeasureTraceDigitalGetValues();
    EVAL_dump2UNV( $lct_Data, "$dataStoragePath/LCT_Measurement_$tcpar_Crashcode.txt.unv" );

	if(defined $tcpar_PEP_TimeToDeploy_Expected){

		# Get list of all measured squib labels
		my $squibLabels_aref;

		foreach my $lctEDID (keys %{$tcpar_PEP_TimeToDeploy_Expected})
		{
			push(@{$squibLabels_aref}, $tcpar_PEP_TimeToDeploy_Expected -> {$lctEDID});
		}

		EDR_addFireTimesToCrashHandler ("LCT_Measurement" => $lct_Data,
										"SquibLabels" => $squibLabels_aref,
										"CrashLabel"  => $tcpar_Crashcode,
										"StoragePath" => $dataStoragePath);
	}

	return 1;
}

sub TC_evaluation {

	#--------------------------------------------------------------
    # NUMBER OF EXPECTED RECORDS
    #
	S_w2rep("");
	S_w2rep("--------------------------------------------------------", 'purple');
	S_w2rep("NUMBER OF EXPECTED RECORDS", 'purple');
	my $detectedNbrOfStoredRecords = 0;
	foreach my $recordNbr (1..$PEPedrNumberOfEventsToBeStored)
	{
		my $recordAvailable = $record_handler -> IsRecordAvailable("CrashLabel" => $tcpar_Crashcode, "RecordNumber"=> $recordNbr);
		$detectedNbrOfStoredRecords++ if ($recordAvailable);
	}

	S_teststep_expected("Number of records expected is '$tcpar_PEP_Record_Expected'", 'read_pepedr_record'); #evaluation 1
	my $verdict=EVAL_evaluate_value("NumberOfRecords", $detectedNbrOfStoredRecords, '==',$tcpar_PEP_Record_Expected);
	S_teststep_detected("Number of stored records is $detectedNbrOfStoredRecords", 'read_pepedr_record');
	if ($verdict eq "VERDICT_FAIL" and not $main::opt_offline){
		S_w2rep(" Expected number of records do not match with detected records, hence no evaluation will be done further");
		return 1;
	}

	if($tcpar_PEP_Record_Expected == 0 ){
	   S_w2rep(" Injected craah is a noise event, hence no evaluation will be done further");
	   return 1;
	}

	#--------------------------------------------------------------
    # FIRE TIMES
    #
	if(defined $tcpar_PEP_TimeToDeploy_Expected) {

        S_teststep("--- DEPLOYMENT TIMES ---", 'NO_AUTO_NBR');
        S_teststep_expected_NOHTML("--- DEPLOYMENT TIMES ---");
        S_teststep_detected_NOHTML("--- DEPLOYMENT TIMES ---");
		my $squibVerdict = EDR_Eval_SquibFireTimes("CrashLabel" => $tcpar_Crashcode,
		                                           "EDID_SquibLabels" => $tcpar_PEP_TimeToDeploy_Expected,
		                                           "CrashTimeZero_ms" => $tcpar_CrashTimeZero,
		                                           "FireTimeTolerance_ms" => $tcpar_EvalTolerance_abs);

		S_teststep_expected("Deployment times stored in PEPEDR are as measured.", 'compare_fire_times'); #evaluation 2
		S_teststep_detected("Deployment times in PEPEDR are as measured", 'compare_fire_times') if $squibVerdict eq 'VERDICT_PASS';
		S_teststep_detected("Deployment times in PEPEDR are not as measured", 'compare_fire_times') if $squibVerdict eq 'VERDICT_FAIL';
	}

	return 1;
}

sub TC_finalization {

	S_w2rep("Start test case finalization...");

	# Erase EDR
    PD_ClearCrashRecorder();
    S_wait_ms(8000);

	# Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(8000);

	# Read fault memory after clearing and erasing EDR
    PD_ReadFaultMemory();
	S_wait_ms(2000);

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

	S_w2rep("Clean up record and crash handler");
    foreach my $record (1..$PEPedrNumberOfEventsToBeStored)
		{
			$record_handler -> DeleteRecord("CrashLabel" => $tcpar_Crashcode, "RecordNumber" => $record);
		}
	return 1;
}


1;
