#### TEST CASE MODULE
package TC_EDI_AKLV_RDBI_AKLV_RDBI_EDRIdentification;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.3 $;
our $HEADER = q$Header: AKLV/TC_EDI_AKLV_RDBI_AKLV_RDBI_EDRIdentification.pm 1.3 2014/07/07 16:26:26ICT DVR5KOR develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_EDR_DiagnosticInterface
#TS version in DOORS: 0.3
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_CD;
use INCLUDES_Project;
use LIFT_PD;
use GENERIC_DCOM;
use LIFT_evaluation; 


##################################

our $PURPOSE = "To check for EDR Identification";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDI_AKLV_RDBI_AKLV_RDBI_EDRIdentification

=head1 PURPOSE

To check for EDR Identification

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation


I<B<Stimulation and Measurement>>

1.Send Request to enter session enterSession::Default

2.Send request to read number of devices ReadDataByIdentifier :: EDRIdentification

3. Send Request to enter session [enterSession:: Development] 

4. Get the Security access [getSecurity ::OEMDIDsMiniAlgoKey]

5. Send request to read number of devices ReadDataByIdentifier :: OEMspecificEDRIdentification


I<B<Evaluation>>

1. Session is entered

2. Positive response is obtained with 

<OEMIdentification> <EDRVersion>

3. Session is entered

4. --

5. Positive response is obtained with 

<OEMIdentification> <OEMEDRVersion>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => To check for EDR Identification
	SCALAR 'OEMIdentification' => Should receive value based on the Customer Project
	LIST 'EDRVersion' => DRVersion should be EDID-List-Version
	LIST 'OEMEDRVersion' => OEMEDRVersion should be OEM EDID-List-Version


=head2 PARAMETER EXAMPLES

	purpose = 'To check for EDR Identification'
	
	OEMIdentification = 'xx' #Should receive value based on the Customer Project
	EDRVersion = @('yy', 'zz') # EDRVersion should be EDID-List-Version
	OEMEDRVersion = @('mm', 'nn') # OEMEDRVersion should be OEM EDID-List-Version
	 

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_OEMIdentification;
my @tcpar_EDRVersion;
my @tcpar_OEMEDRVersion;

################ global parameter declaration ###################
#add any global variables here


###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_OEMIdentification =  GEN_Read_mandatory_testcase_parameter( 'OEMIdentification' );
	@tcpar_EDRVersion =  GEN_Read_mandatory_testcase_parameter( 'EDRVersion' );
	@tcpar_OEMEDRVersion =  GEN_Read_mandatory_testcase_parameter( 'OEMEDRVersion' );

	return 1;
}

sub TC_initialization {

	GEN_printTestStep("Standard_Preparation");
	GEN_StandardPrepNoFault();
	GDCOM_start_CyclicTesterPresent();

	return 1;
}

sub TC_stimulation_and_measurement {

	GEN_printTestStep("Step 1.Send Request to enter session enterSession::Default");
	
	GDCOM_StartSession ('DefaultSession','CheckActiveSession');

	GEN_printTestStep("Step 2.Send request to read number of devices ReadDataByIdentifier :: EDRIdentification");
	
	my $EDRDevicenumber_GEN= EDR_Identification('GEN');
	
	EVAL_evaluate_value("Evaluvating OEM Identification",@$EDRDevicenumber_GEN[3],'==',$tcpar_OEMIdentification);
	
	for(my $count=4;$count<=5;$count++)
	{
		EVAL_evaluate_value("Evaluvating EDR version",@$EDRDevicenumber_GEN[$count],'==',@tcpar_EDRVersion[$count-4]);
	}

	GEN_printTestStep("Step 3. Send Request to enter session [enterSession:: Development] ");
	
	GDCOM_StartSession ('ExtendedSession','CheckActiveSession');

	GEN_printTestStep("Step 4. Get the Security access [getSecurity ::OEMDIDsMiniAlgoKey]");
	
	GDCOM_SecurityAccess_Unlock('Level3_21');

	GEN_printTestStep("Step 5. Send request to read number of devices ReadDataByIdentifier :: OEMspecificEDRIdentification");
	
	my $EDRDevicenumber_OEM= EDR_Identification('OEM');
	
	EVAL_evaluate_value("Evaluvating OEM Identification",@$EDRDevicenumber_OEM[3],'==',$tcpar_OEMIdentification);
	
	for(my $count=4;$count<=5;$count++)
	{
		EVAL_evaluate_value("Evaluvating OEM EDR version",@$EDRDevicenumber_OEM[$count],'==',@tcpar_OEMEDRVersion[$count-4]);
	}

	return 1;
}

sub TC_evaluation {

	GEN_printTestStep("Evaluation for Step 1. Session is entered");

	GEN_printTestStep("Evaluation for Step 2. Positive response is obtained");

	

	GEN_printTestStep("Evaluation for Step 3. Session is entered");

	GEN_printTestStep("Evaluation for Step 4. Security Access Approved");

	GEN_printTestStep("Evaluation for Step 5. Positive response is obtained");

	
	return 1;
}

sub TC_finalization {

	GDCOM_stop_CyclicTesterPresent();
	
	return 1;
}


1;

