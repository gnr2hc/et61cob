#### TEST CASE MODULE
package TC_EDI_AKLV_RDBI_ReadingEDREntry_Under_Diff_Modes;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.4 $;
our $HEADER  = q$Header: AKLV/TC_EDI_AKLV_RDBI_ReadingEDREntry_Under_Diff_Modes.pm 1.4 2019/11/19 18:23:03ICT Phan Khanh Duy (RBVH/EPS24) (PDA1HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_EDR_DiagnosticInterface
#TS version in DOORS: 0.3
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
use LIFT_CD;
use LIFT_PD;
use GENERIC_DCOM;
use LIFT_evaluation;
use FuncLib_CustLib_DIAG;
use FuncLib_TNT_FM;
use LIFT_crash_simulation;
use LIFT_labcar;

##################################

our $PURPOSE = "To check for Reading different Generic EDR entries under different modes of ECU by calculating signature And CRC";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDI_AKLV_RDBI_ReadingEDREntry_Under_Diff_Modes

=head1 PURPOSE

To check for Reading different Generic EDR entries under different modes of ECU by calculating signature And CRC

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation


I<B<Stimulation and Measurement>>

1.Send Request to enter session [enterSession::<Session_to_be_entered1>]

Send array of requests to read EDR entries

2. Inject a Six Deployment Crashes [FrontInflatableDeployment, SideDriverInflatableDeployment, SidePassengerInflatableDeployment, RearNonInflatableDeployment, RolloverInflatableDeployment, FrontInflatableDeployment]

3. .Create <Condition>

4. Iterate step 5 and step 6 for each values of <EDR_EntryToProcess> 

5. Send start routine control request [routinecontrol :: startRoutine,CalculateSignatureOrCRC,<SelectedFunction>, <EDR_EntryToProcess>] 

6.Send routine result request [routinecontrol :: requestRoutineResults,CalculateSignatureOrCRC] during CompletedSuccessfully Condition

7. Send Request to enter session [enterSession::<Session_to_be_entered2>] 

8. Get the Security access [getSecurity ::<Security_Key>]

9. Send array of requests to read EDR entries [ ReadDataByIdentifier :: DID ] where DID Array <EDR_Entries>


I<B<Evaluation>>

1. Session is entered

All EDR entry are Empty.

2. Crashs are injected Successfully 

3. --

4. --

5. Positive response is obtained for each request with StartRoutineStateOfOperarion as 'Running'

6. Positive response is obtained for each request with StartRoutineStateOfOperarion as 'CompletedSuccessfully '

7.

8. --

9. Responses_Array is obtained. 

EDIDs shall be displayed in an ascending order. 


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => To check for Reading different Generic EDR entries under different modes of ECU by calculating signature And CRC
	LIST 'SelectedFunction' => @('CalculateSignature', 'CalculateCRC')
	LIST 'EDR_EntryToProcess' => @('01', '02', '03', '04', '05', '06')
	SCALAR 'Condition' => InternalFault
	SCALAR 'Security_Key' => NONE
	SCALAR 'Session_to_be_entered1' => ExtendedSession
	SCALAR 'Session_to_be_entered2' => ExtendedSession
	LIST 'EDR_Entries' => @('01', '02', '03', '04', '05', '06')


=head2 PARAMETER EXAMPLES

	purpose = 'To check for Reading different Generic EDR entries under different modes of ECU by calculating signature And CRC '
	
	SelectedFunction = @('CalculateSignature', 'CalculateCRC')
	EDR_EntryToProcess = @('01', '02', '03', '04', '05', '06')
	Condition = '<Test Heading>'
	Security_Key = 'NONE'
	Session_to_be_entered1 = 'ExtendedSession'
	Session_to_be_entered2 = 'ExtendedSession'
	EDR_Entries = @('01', '02', '03', '04', '05', '06')
	# Responses_Array = @('EDRentry06', 'EDRentry05', 'EDRentry04,'EDRentry03', 'EDRentry02', 'EDRentry01')

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_SelectedFunction;
my $tcpar_EDR_EntryToProcess;
my $tcpar_Condition;
my $tcpar_Security_Key;
my $tcpar_Session_to_be_entered1;
my $tcpar_Session_to_be_entered2;
my $tcpar_EDR_Entries;
my $tcpar_CrashScenarioList;
my $tcpar_ResultDB;

################ global parameter declaration ###################
my $status;
my $EDRHeader;
my @EDRHeaderData;
my $faultStatus;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose                = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_SelectedFunction       = S_read_mandatory_testcase_parameter( 'SelectedFunction', 'byref' );
	$tcpar_EDR_EntryToProcess     = S_read_mandatory_testcase_parameter( 'EDR_EntryToProcess', 'byref' );
	$tcpar_Condition              = S_read_mandatory_testcase_parameter('Condition');
	$tcpar_Security_Key           = S_read_mandatory_testcase_parameter('Security_Key');
	$tcpar_Session_to_be_entered1 = S_read_mandatory_testcase_parameter('Session_to_be_entered1');
	$tcpar_Session_to_be_entered2 = S_read_mandatory_testcase_parameter('Session_to_be_entered2');
	$tcpar_EDR_Entries            = S_read_mandatory_testcase_parameter( 'EDR_Entries', 'byref' );
	$tcpar_CrashScenarioList      = S_read_mandatory_testcase_parameter( 'CrashScenarioList', 'byref' );
	$tcpar_ResultDB               = S_read_optional_testcase_parameter('ResultDB');
	$tcpar_ResultDB               = 'DEFAULT' unless ( defined $tcpar_ResultDB );

	return 1;
}

sub TC_initialization {

	S_teststep( "Standard_Preparaion", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();
	GDCOM_start_CyclicTesterPresent();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Step 1.Send Request to enter session ", 'AUTO_NBR' );

	GDCOM_StartSession( $tcpar_Session_to_be_entered1, 'CheckActiveSession' );

	S_teststep( "Send array of requests to read EDR entries", 'AUTO_NBR' );

	foreach my $EDRResponse (@$tcpar_EDR_Entries) {
		my $EDRDiagResponse = DIAG_readEDREntry($EDRResponse);

		$EDRHeader = EDR_CD_readHeader($EDRDiagResponse);

		#@EDRHeaderData= @{$EDRHeader};

		my @lookup = ( '00', '00' );

		GEN_EVAL_CompareNumArrays( \@lookup, \@EDRHeaderData, 'Equal' );    #Checking Header infornmation is Null
	}

	S_teststep( "Step 2. Inject a Six Deployment Crashes [FrontInflatableDeployment, SideDriverInflatableDeployment, SidePassengerInflatableDeployment, RearNonInflatableDeployment, RolloverInflatableDeployment, FrontInflatableDeployment]", 'AUTO_NBR' );

	S_teststep_2nd_level( "Clear crash recorder before crash injection", 'AUTO_NBR' );
	PD_ClearCrashRecorder();
	S_wait_ms(2000);
	foreach (@$tcpar_CrashScenarioList) {

		#--------------------------------------------------------------
		# PREPARE CRASH AND INITIALIZE EQUIPMENT
		#
		S_teststep_2nd_level( "Get crash settings for crash $_", 'AUTO_NBR' );
		my $crashDetails_href = { "RESULTDB" => $tcpar_ResultDB, 'CRASHNAME' => $_ };
		my $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
		unless ( defined $crashSettings ) {
			S_set_error("Crash $_ not available in result DB $tcpar_ResultDB. Test case aborted.");
			return;
		}

		my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
		my $resultDB_Path = $resultDBDetails->{'PATH'};
		S_w2log( 1, "Crashcode: $_, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)" );

		S_w2log( 1, "Set environments for crash as per result DB" );
		CSI_PrepareEnvironment( $crashSettings, 'init_complete' );
		S_wait_ms(2000);

		#--------------------------------------------------------------
		# CRASH PREPARATION
		#
		S_teststep_2nd_level( "Prepare crash", 'AUTO_NBR' );
		LC_ECU_Off();
		S_wait_ms('TIMER_ECU_OFF');

		# Prepare crash
		CSI_LoadCrashSensorData2Simulator($crashSettings);

		# Power ON the ECU
		LC_ECU_On();
		S_wait_ms('TIMER_ECU_READY');

		#--------------------------------------------------------------
		# CRASH INJECTION
		#

		S_teststep_2nd_level( "Inject crash '$_'", 'AUTO_NBR' );
		CSI_TriggerCrash();
		S_teststep( "Wait 10s for crash happen and EDR record complete", 'AUTO_NBR' );
		S_wait_ms(10000);

	}

	#--------------------------------------------------------------
	# CRASH INJECTIONS SECTION IS COMPLETED
	#

	S_teststep( "Step 3. .Create '$tcpar_Condition'", 'AUTO_NBR' );

	if ( $tcpar_Condition eq "InternalFault" ) {
		$faultStatus = FM_createFault('CAN_E_TIMEOUT');

		if ( $faultStatus == 0 ) {
			S_teststep( "Fault is not created Successfully", 'AUTO_NBR' );

			return 0;
		}
	}
	elsif ( $tcpar_Condition eq 'IdleMode' ) {
		$faultStatus = GEN_setECUMode('IdleMode');

		if ( $faultStatus == 0 ) {
			S_teststep( "ECU is not set to Idle Mode", 'AUTO_NBR' );

			return 0;
		}
	}
	elsif ( $tcpar_Condition eq 'UnderVoltage' ) {
		$faultStatus = GEN_setECUMode('UnderVoltage');

		if ( $faultStatus == 0 ) {
			S_teststep( "ECU is not set to UnderVoltage", 'AUTO_NBR' );

			return 0;
		}
	}
	elsif ( $tcpar_Condition eq 'OverVoltage' ) {
		$faultStatus = GEN_setECUMode('OverVoltage');

		if ( $faultStatus == 0 ) {
			S_teststep( "ECU is not set to OverVoltage", 'AUTO_NBR' );

			return 0;
		}
	}
	else {
		S_teststep( "No condition has met, Exiting from execution", 'AUTO_NBR' );
		return 1;
	}

	S_teststep( "Step 5. Send start routine control request [routinecontrol :: startRoutine,CalculateSignatureOrCRC,'$tcpar_SelectedFunction'] ", 'AUTO_NBR' );

	S_teststep( "Step 6.Send routine result request [routinecontrol :: requestRoutineResults,CalculateSignatureOrCRC] during CompletedSuccessfully Condition", 'AUTO_NBR' );

	if ( @$tcpar_SelectedFunction[0] eq 'CalculateSignature' ) {
		foreach my $EDR_EntryToProcess_Sign (@$tcpar_EDR_EntryToProcess) {

			my $SignatureResponse = DIAG_calculateSignature( $EDR_EntryToProcess_Sign, 'CompletedSuccessfully' );

			EVAL_evaluate_value( "Comparing the RoutineResultStateOfOperarion", @$SignatureResponse[6], '==', '0x80' );
		}
	}
	elsif ( @$tcpar_SelectedFunction[0] eq 'CalculateCRC' ) {
		foreach my $EDR_EntryToProcess_CRC (@$tcpar_EDR_EntryToProcess) {

			my $CRCResponse = DIAG_calculateSignature( $EDR_EntryToProcess_CRC, 'CompletedSuccessfully' );

			EVAL_evaluate_value( "Comparing the RoutineResultStateOfOperarion", @$CRCResponse[6], '==', '0x80' );
		}
	}
	else {
		S_teststep( "Invalid selected function, Exiting from Execution", 'AUTO_NBR' );
		return 1;
	}

	S_teststep( "Step 7. Send Request to enter session [enterSession::'$tcpar_Session_to_be_entered2'] ", 'AUTO_NBR' );

	GDCOM_StartSession( $tcpar_Session_to_be_entered2, 'CheckActiveSession' );

	S_teststep("Step 8. Get the Security access [getSecurity ::'$tcpar_Security_Key']");

	if ( $tcpar_Security_Key eq 'NONE' ) {
		S_teststep( "Security Access not Required", 'AUTO_NBR' );
	}
	elsif ( $tcpar_Security_Key eq 'Level3_23' ) {
		GDCOM_SecurityAccess_Unlock($tcpar_Security_Key);
	}

	S_teststep( "Step 9. Send array of requests to read EDR entries [ ReadDataByIdentifier :: DID ] where DID Array ", 'AUTO_NBR' );

	foreach my $EDRResponse (@$tcpar_EDR_Entries) {
		my $EDRDiagResponse = DIAG_readEDREntry($EDRResponse);    #Reading EDR response

		if ( $EDRResponse == 1 || $EDRResponse == 2 || $EDRResponse == 3 || $EDRResponse == 4 || $EDRResponse == 5 || $EDRResponse == 6 )    #Checking Generic EDR entry
		{

			my $EDREDIDdataref = EDR_CD_getEDIDdata( $EDRDiagResponse, 1021 );                                                               #Fetching EDID data for Generic EDR

			my @EDREDIDdata = @$EDREDIDdataref;

			if ( $EDRResponse == 1 )                                                                                                         #Evaluvation of EDID
			{
				my @EventCounter_06 = ( '00', '06' );

				S_w2rep( " Checking the Event Counter Of EDR Entry : $EDRResponse ", 'blue' );

				GEN_EVAL_CompareNumArrays( \@EDREDIDdata, \@EventCounter_06, 'Equal' );
			}
			elsif ( $EDRResponse == 2 ) {
				my @EventCounter_05 = ( '00', '05' );

				S_w2rep( " Checking the Event Counter Of EDR Entry : $EDRResponse ", 'blue' );

				GEN_EVAL_CompareNumArrays( \@EDREDIDdata, \@EventCounter_05, 'Equal' );
			}
			elsif ( $EDRResponse == 3 ) {
				my @EventCounter_04 = ( '00', '04' );

				S_w2rep( " Checking the Event Counter Of EDR Entry : $EDRResponse ", 'blue' );

				GEN_EVAL_CompareNumArrays( \@EDREDIDdata, \@EventCounter_04, 'Equal' );
			}
			elsif ( $EDRResponse == 4 ) {
				my @EventCounter_03 = ( '00', '03' );

				S_w2rep( " Checking the Event Counter Of EDR Entry : $EDRResponse ", 'blue' );

				GEN_EVAL_CompareNumArrays( \@EDREDIDdata, \@EventCounter_03, 'Equal' );
			}
			elsif ( $EDRResponse == 5 ) {
				my @EventCounter_02 = ( '00', '02' );

				S_w2rep( " Checking the Event Counter Of EDR Entry : $EDRResponse ", 'blue' );

				GEN_EVAL_CompareNumArrays( \@EDREDIDdata, \@EventCounter_02, 'Equal' );
			}
			elsif ( $EDRResponse == 6 ) {
				my @EventCounter_01 = ( '00', '01' );

				S_w2rep( " Checking the Event Counter Of EDR Entry : $EDRResponse ", 'blue' );

				GEN_EVAL_CompareNumArrays( \@EDREDIDdata, \@EventCounter_01, 'Equal' );
			}
			else {
				S_set_error( " EDREntries is Invalid!", 0 );
			}
		}
		else {
			my $EDREDIDdataref = EDR_CD_getEDIDdata( $EDRDiagResponse, 1021, m'OEM' );    #Fetching EDID data for OEM EDR

			my @EDREDIDdata = @$EDREDIDdataref;

			if ( $EDRResponse == 81 )                                                     #Evaluvation of EDID
			{
				my @EventCounter_06 = ( '00', '06' );

				S_w2rep( " Checking the Event Counter Of EDR Entry : $EDRResponse ", 'blue' );

				GEN_EVAL_CompareNumArrays( \@EDREDIDdata, \@EventCounter_06, 'Equal' );
			}
			elsif ( $EDRResponse == 82 ) {
				my @EventCounter_05 = ( '00', '05' );

				S_w2rep( " Checking the Event Counter Of EDR Entry : $EDRResponse ", 'blue' );

				GEN_EVAL_CompareNumArrays( \@EDREDIDdata, \@EventCounter_05, 'Equal' );
			}
			elsif ( $EDRResponse == 83 ) {
				my @EventCounter_04 = ( '00', '04' );

				S_w2rep( " Checking the Event Counter Of EDR Entry : $EDRResponse ", 'blue' );

				GEN_EVAL_CompareNumArrays( \@EDREDIDdata, \@EventCounter_04, 'Equal' );
			}
			elsif ( $EDRResponse == 84 ) {
				my @EventCounter_03 = ( '00', '03' );

				S_w2rep( " Checking the Event Counter Of EDR Entry : $EDRResponse ", 'blue' );

				GEN_EVAL_CompareNumArrays( \@EDREDIDdata, \@EventCounter_03, 'Equal' );
			}
			elsif ( $EDRResponse == 85 ) {
				my @EventCounter_02 = ( '00', '02' );

				S_w2rep( " Checking the Event Counter Of EDR Entry : $EDRResponse ", 'blue' );

				GEN_EVAL_CompareNumArrays( \@EDREDIDdata, \@EventCounter_02, 'Equal' );
			}
			elsif ( $EDRResponse == 86 ) {
				my @EventCounter_01 = ( '00', '01' );

				S_w2rep( " Checking the Event Counter Of EDR Entry : $EDRResponse ", 'blue' );

				GEN_EVAL_CompareNumArrays( \@EDREDIDdata, \@EventCounter_01, 'Equal' );
			}
			else {
				S_set_error( " EDREntries is Invalid!", 0 );
			}

		}
	}

	return 1;
}

sub TC_evaluation {

	S_teststep( "Evaluation for Step 1. Session is entered", 'AUTO_NBR' );

	S_teststep( "All EDR entry are Empty.", 'AUTO_NBR' );

	S_teststep( "Evaluation for Step 2. Crashs are injected Successfully ", 'AUTO_NBR' );

	S_teststep( "Evaluation for Step 3.Condition Created Sucessfully", 'AUTO_NBR' );

	S_teststep( "Evaluation for Step 6. Positive response is obtained for each request with StartRoutineStateOfOperarion as 'CompletedSuccessfully '", 'AUTO_NBR' );

	S_teststep( "Evaluation for Step 7. Session entered", 'AUTO_NBR' );

	S_teststep( "Evaluation for Step 8. Security Access Granted", 'AUTO_NBR' );

	S_teststep( "Evaluation for Step 9. Responses_Array is obtained. ", 'AUTO_NBR' );

	S_teststep( "EDIDs shall be displayed in an ascending order. ", 'AUTO_NBR' );

	return 1;
}

sub TC_finalization {

	if ( $tcpar_Condition eq 'IdleMode' ) {
		GEN_setECUMode('RemoveIdleMode');
	}
	elsif ( $tcpar_Condition eq 'UnderVoltage' or $tcpar_Condition eq 'OverVoltage' ) {
		GEN_setECUMode('NormalVoltage');
	}
	elsif ( $tcpar_Condition eq 'InternalFault' ) {
		FM_removeFault('CAN_E_TIMEOUT');
	}

	GDCOM_stop_CyclicTesterPresent();

	return 1;
}

1;
