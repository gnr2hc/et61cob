#### TEST CASE MODULE
package TC_EDI_AKLV_RDBI_ReadingNumberOfEDRDevices;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.3 $;
our $HEADER = q$Header: AKLV/TC_EDI_AKLV_RDBI_ReadingNumberOfEDRDevices.pm 1.3 2014/07/07 16:31:09ICT DVR5KOR develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_EDR_DiagnosticInterface
#TS version in DOORS: 0.3
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
use LIFT_CD;
use LIFT_PD;
use GENERIC_DCOM;
use LIFT_evaluation;
use FuncLib_CustLib_DIAG;

##################################

our $PURPOSE = "To check for number of EDR devices in the vehicle and the storage type";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDI_AKLV_RDBI_ReadingNumberOfEDRDevices

=head1 PURPOSE

'To check for number of EDR devices in the vehicle and the storage type'

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPreparation


I<B<Stimulation and Measurement>>

1. Send Request to Enter Session enterSession::Default

2. Configure via NVM where EDR Storage Type is configured as <EDR_Storage_Type> 

with Number of EDR Devices as <Number_Of_EDR_Devices> 

with corresponding <Request_ID> & <Response_ID>

3. StandardPreparation

4. .Send request to read number of devices ReadDataByIdentifier :: NumberOfEDRDevices through 'DisposalID'

5. Send request to read Address Information ReadDataByIdentifier :: AddressInformation through 'DisposalID'

6. Send Request to enter session [enterSession:: Development] 

7. Get the Security access [getSecurity ::OEMDIDsMiniAlgoKey]

8. Send request to read number of devices ReadDataByIdentifier :: OEMspecificNumberOfEDRDevices 

9. Send request to read number of devices ReadDataByIdentifier :: OEMspecificAddressInformation 


I<B<Evaluation>>

1. Session is entered

2. --

3. --

4. Positive response is obtained with 

<Data_NumberOfEDRDevices>

5. Positive response is obtained with 

<Data_AddressInformation >

6. Session is entered

7. --

8. Positive response is obtained with 

<Data_NumberOfEDRDevices>

9. Positive response is obtained with 

<Data_AddressInformation>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 'To check for number of EDR devices in the vehicle and the storage type'
	SCALAR 'EDR_Storage_Type' => 
	SCALAR 'Data_AddressInformation' => 
	SCALAR 'Number_Of_EDR_Devices' => 
	SCALAR 'Data_NumberOfEDRDevices' => 
	SCALAR 'Request_ID' => 
	SCALAR 'Response_ID' => 


=head2 PARAMETER EXAMPLES

	purpose = 'To check for number of EDR devices in the vehicle and the storage type'
	
	EDR_Storage_Type = '<Test Heading>'
	Data_AddressInformation = 'mm xx xx xx xx yy yy yy yy' # mm -Based on the configured address, xx - Request ID, yy - Response ID
	#Type 1: central and located in EDR-Master
	Number_Of_EDR_Devices = 01
	Data_NumberOfEDRDevices = 0x01
	
	Request_ID = 'xx xx xx xx'
	Response_ID = 'yy yy yy yy'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_EDR_Storage_Type;
my $tcpar_Data_AddressInformation;
my $tcpar_Number_Of_EDR_Devices;
my $tcpar_Data_NumberOfEDRDevices;
my $tcpar_Request_ID;
my $tcpar_Response_ID;

################ global parameter declaration ###################
my $Security_Key='Level3_23';


###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_EDR_Storage_Type =  GEN_Read_mandatory_testcase_parameter( 'EDR_Storage_Type' );
	$tcpar_Data_AddressInformation =  GEN_Read_mandatory_testcase_parameter( 'Data_AddressInformation' );
	$tcpar_Number_Of_EDR_Devices =  GEN_Read_mandatory_testcase_parameter( 'Number_Of_EDR_Devices' );
	$tcpar_Data_NumberOfEDRDevices =  GEN_Read_mandatory_testcase_parameter( 'Data_NumberOfEDRDevices' );
	$tcpar_Request_ID =  GEN_Read_mandatory_testcase_parameter( 'Request_ID' );
	$tcpar_Response_ID =  GEN_Read_mandatory_testcase_parameter( 'Response_ID' );

	return 1;
}

sub TC_initialization {

	GEN_printTestStep("Standard_Preparaion");
	PD_ClearCrashRecorder();
	GEN_StandardPrepNoFault();
	GDCOM_start_CyclicTesterPresent();

	return 1;
}

sub TC_stimulation_and_measurement {

	GEN_printTestStep("Step 1. Send Request to Enter Session enterSession::Default");
	
	GDCOM_StartSession('DefaultSession','CheckActiveSession'); #Default session entered
	
	GEN_printTestStep("Step 4. .Send request to read number of devices ReadDataByIdentifier :: NumberOfEDRDevices'");
	
	my $EDRDeviceNumber= EDR_readEDRdevices('GEN');#Reading number of EDR devices
	
	EVAL_evaluate_value("Evaluvating Number of EDR devices",@$EDRDeviceNumber[0],'==',$tcpar_Number_Of_EDR_Devices);
	
	GEN_printTestStep("Step 5. Send request to read Address Information ReadDataByIdentifier :: AddressInformation '");
	
	my $EDRAddressInformation=EDR_addressInformation('GEN');#Reading Address Information
	
	my @requestAddressArray= splice(@$EDRAddressInformation,3,9); #Extracting Address info from response
	
	my $requestAddress=join("",@requestAddressArray); #Convert Addressinfo from Array to scalar
	
	EVAL_evaluate_value("Evaluvating Address Information",$requestAddress,'==',$tcpar_Data_AddressInformation); #Comparing Address information

	GEN_printTestStep("Step 6. Send Request to enter session [enterSession:: Development] ");
	
	GDCOM_StartSession ('DevelopmentSession','CheckActiveSession');#Entering Development session

	GEN_printTestStep("Step 7. Get the Security access [getSecurity ::OEMDIDsMiniAlgoKey]");
	
	GDCOM_SecurityAccess_Unlock($Security_Key); #Security access Granted

	GEN_printTestStep("Step 8. Send request to read number of devices ReadDataByIdentifier :: OEMspecificNumberOfEDRDevices ");
	
	my $OEMEDRDeviceNumber= EDR_readEDRdevices('OEM');#Reading number of OEM EDR devices

	GEN_printTestStep("Step 9. Send request to read number of devices ReadDataByIdentifier :: OEMspecificAddressInformation ");
	
	my $OEMEDRAdressInfo=EDR_addressInformation('OEM');#Reading Address Information of OEM EDR devices
	
	my @OEMrequestAddressArray=splice(@$OEMEDRAdressInfo,3,9); #Extracting Address info from response
	
	my $OEMrequestAddress=join("",@OEMrequestAddressArray); #Convert Addressinfo from Array to scalar
	
	EVAL_evaluate_value("Evaluvating Address Information",$OEMrequestAddress,'==',$tcpar_Data_AddressInformation);

	return 1;
}

sub TC_evaluation {

	GEN_printTestStep("Evaluation for Step 1. Session is entered");

	GEN_printTestStep("Evaluation for Step 4. Positive response is obtained ");

	GEN_printTestStep("Evaluation for Step 5. Positive response is obtained");

	GEN_printTestStep("Evaluation for Step 6. Session is entered");

	GEN_printTestStep("Evaluation for Step 7. Security Access Granted");

	GEN_printTestStep("Evaluation for Step 8. Positive response is obtained");

	GEN_printTestStep("Evaluation for Step 9. Positive response is obtained ");

	return 1;
}

sub TC_finalization {

	GDCOM_stop_CyclicTesterPresent();
	
	return 1;
}


1;
