#### TEST CASE MODULE
package TC_EDI_CN_EDR_CheckValidValue;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER  = q$Header: AKLV/TC_EDI_CN_EDR_CheckValidValue.pm 1.1 2020/03/20 10:36:09ICT Phan Khanh Duy (RBVH/EPS24) (PDA1HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use GENERIC_DCOM;
use LIFT_can_access;
use FuncLib_EDR_Framework;
##################################

our $PURPOSE = "To verify the response to read EDR data for unaquired value or invalid data";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDI_CN_EDR_CheckValidValue

=head1 PURPOSE

To verify the response to read EDR data for unaquired value or invalid data

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Set Signal <COM_signal> to <State>

2. Wait for <Cyclic_time> of that <COM_signal>

3. Inject <crashcode>.

4. Send request <Read_ChinaEDR> and check obtained response


I<B<Evaluation>>

1. --

2. --

3. --

4.The value of <EDID> obtain in response is <Value>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'COM_Signal' => 
	SCALAR 'State' => 
	SCALAR 'Cyclic_time' => 
	SCALAR 'crashcode' => 
	SCALAR 'EDID' => 
	SCALAR 'Factor' => 
	SCALAR 'Offset' => 
	SCALAR 'Value' => 


=head2 PARAMETER EXAMPLES

	purpose = 'To check response bytes have value FE for invalid value'
	
	COM_Signal = 'VSD_ESPReferenceVelocity'
	State = 'OutOfRangeValue'
	Cyclic_time = '20ms'
	crashcode = 'Single_EDR_Front_Inflatable;5'
	
	#EDID for Vehicle Velocity with factor and offset need to be update ((could be visible in EDR Mapping)
	EDID = '4005'
	Factor = '1'
	Offset = '0'
	
	Value = 'FE'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_COM_Signal;
my $tcpar_COM_Message;
my $tcpar_State;
my $tcpar_Cyclic_time;
my $tcpar_ResultDB;
my $tcpar_Crashcode;
my $tcpar_EDID;
my $tcpar_Factor;
my $tcpar_Offset;
my $tcpar_Value;
my $tcpar_Read_ChinaEDR;
my $tcpar_Protocol;
################ global parameter declaration ###################
#add any global variables here
my $crashSettings;
my $pre_check;
my $readEDR_response_aref;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_State   = S_read_mandatory_testcase_parameter('State');
	$pre_check     = 0;
	if ( $tcpar_State eq "Timeout" ) {
		$tcpar_COM_Message = S_read_mandatory_testcase_parameter('COM_Message');
	}
	elsif ( $tcpar_State eq "OutOfRangeValue" ) {
		$tcpar_COM_Signal = S_read_mandatory_testcase_parameter('COM_Signal');
	}
	else {
		S_set_error( "State $tcpar_State is incorrect, it should be either Timeout or OutOfRangeValue. Test case aborted", 110 );
		$pre_check = 1;
		return 0;

	}

	$tcpar_Cyclic_time   = S_read_mandatory_testcase_parameter('Cyclic_time');
	$tcpar_Crashcode     = S_read_mandatory_testcase_parameter('crashcode');
	$tcpar_EDID          = S_read_mandatory_testcase_parameter('EDID');
	$tcpar_Factor        = S_read_mandatory_testcase_parameter('Factor');
	$tcpar_Offset        = S_read_mandatory_testcase_parameter('Offset');
	$tcpar_Value         = S_read_mandatory_testcase_parameter('Value');
	$tcpar_Protocol      = S_read_optional_testcase_parameter( 'Protocol', "byref", 'CAN' );
	$tcpar_ResultDB      = S_read_optional_testcase_parameter( 'ResultDB', "byref", 'DEFAULT' );
	$tcpar_Read_ChinaEDR = S_read_mandatory_testcase_parameter('Read_ChinaEDR');

	return 1;
}

sub TC_initialization {

	if ($pre_check) {

		S_set_error( "parameter State get error, Stop execution", 110 );
		return 0;
	}

	S_teststep( "Test setup preparation", 'AUTO_NBR' );

	#--------------------------------------------------------------
	# PREPARE CRASH AND INITIALIZE EQUIPMENT
	#
	S_w2rep("Get crash settings for crash $tcpar_Crashcode");
	my $crashDetails_href = { "RESULTDB" => $tcpar_ResultDB, 'CRASHNAME' => $tcpar_Crashcode };
	$crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
	unless ( defined $crashSettings ) {
		S_set_error("Crash $tcpar_Crashcode not available in result DB $tcpar_ResultDB. Test case aborted.");
		return;
	}

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log( 1, "Crashcode: $tcpar_Crashcode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)" );

	S_w2log( 1, "Power on ECU" );
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	S_w2log( 1, "Initialize CD and start CAN trace" );
	GDCOM_init();    # To fetch info for CD from mapping_diag
	CA_trace_start();

	S_w2log( 1, "Set environments for crash as per result DB" );
	CSI_PrepareEnvironment( $crashSettings, 'init_complete' );
	S_wait_ms(2000);

	S_w2log( 1, "Clear crash recorder" );
	PD_ClearCrashRecorder();
	S_wait_ms(2000);

	S_w2log( 1, "Clear fault memory" );
	PD_ClearFaultMemory();
	S_wait_ms(2000);

	S_w2log( 1, "Read and evaluate fault memory before stimulation" );
	my $faultsBeforeStimulation = PD_ReadFaultMemory();

	#Fault memory must be empty
	my $faultsVerdict = PD_evaluate_faults( $faultsBeforeStimulation, [] );
	return 0 unless ( $faultsVerdict eq 'VERDICT_PASS' );

	return 1;
}

sub TC_stimulation_and_measurement {

	#--------------------------------------------------------------
	# PREPARE CRASH INJECTION AND REPORT FILES
	#
	S_teststep( "Prepare crash", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	# Prepare crash
	CSI_LoadCrashSensorData2Simulator($crashSettings);

	# Power ON the ECU
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Set Signal '$tcpar_COM_Signal' to '$tcpar_State'", 'AUTO_NBR' );
	if ( $tcpar_State eq "Timeout" ) {
		S_teststep_2nd_level( "Stop Message $tcpar_COM_Message", 'AUTO_NBR' );
		COM_stopMessages( [$tcpar_COM_Message], $tcpar_Protocol );

		S_teststep_2nd_level( "Wait for '$tcpar_Cyclic_time' of that '$tcpar_COM_Signal'", 'AUTO_NBR' );
		S_wait_ms($tcpar_Cyclic_time);

		S_teststep_2nd_level( "Read fault memory to check vehicle msg timeout", 'AUTO_NBR' );
		my $fault_href = PD_ReadFaultMemory();
	}
	elsif ( $tcpar_State eq "OutOfRangeValue" ) {
		S_teststep_2nd_level( "Set Signal $tcpar_COM_Signal to Out Of Range value (from CAN Mapping)", 'AUTO_NBR' );
		COM_setSignalState( $tcpar_COM_Signal, $tcpar_State, $tcpar_Protocol );

		S_teststep_2nd_level( "Wait for '$tcpar_Cyclic_time' of that '$tcpar_COM_Signal'", 'AUTO_NBR' );
		S_wait_ms($tcpar_Cyclic_time);

		S_teststep_2nd_level( "Read Signal $tcpar_COM_Signal value in hex", 'AUTO_NBR' );
		my ( $sigvalue_hex, $unit ) = CA_read_can_signal( $tcpar_COM_Signal, 'hex' );
		S_w2rep( "Observed raw value '$sigvalue_hex' of signal '$tcpar_COM_Signal'", 'blue' );
	}
	else {
		S_set_error("State $tcpar_State is incorrect, it should be either Timeout or OutOfRangeValue. Test case aborted");
	}

	S_teststep( "Inject '$tcpar_Crashcode'.", 'AUTO_NBR' );
	CSI_TriggerCrash();
	S_wait_ms(15000);

	S_teststep( "Send request '$tcpar_Read_ChinaEDR' and check obtained response", 'AUTO_NBR', 'send_request_read' );    #measurement 1
	$readEDR_response_aref = _read_EDR_record( undef, 'EVAL_SWITCH' );

	return 1;
}

sub TC_evaluation {

	my $recordStructure_href = FuncLib_TNT_EDR::EDR_ReadCHINAEDR_Record_structure_info_from_mapping();
	my $parsing_EDID         = FuncLib_TNT_EDR::EDR_parseEDIDs( $readEDR_response_aref, $recordStructure_href );
	my $edidData_aref        = $parsing_EDID->{$tcpar_EDID};
	my @obtain_data;

	my $count = 0;
	foreach my $data (@$edidData_aref) {
		if ( $data ne $tcpar_Value ) {
			$count++;
		}
		push( @obtain_data, $data );
	}

	S_teststep_expected( "The value of EDID '$tcpar_EDID' obtain in response is '$tcpar_Value'", 'send_request_read' );    #evaluation 1
	S_teststep_detected( "There are '$count' bytes date not equal to '$tcpar_Value'", 'send_request_read' );
	S_teststep_detected("Data of EDID '$tcpar_EDID' is '@obtain_data'");
	EVAL_evaluate_value( "Number of data bytes not equal to '$tcpar_Value' in EDID '$tcpar_EDID'", $count, '==', 0 );

	return 1;
}

sub TC_finalization {

	S_teststep( "Reset manipulated COM signals", 'AUTO_NBR' );
	if ( $tcpar_State eq "Timeout" ) {
		COM_startMessages( [$tcpar_COM_Message], $tcpar_Protocol );
	}
	elsif ( $tcpar_State eq "OutOfRangeValue" ) {
		COM_setSignalState( $tcpar_COM_Signal, 'DefaultValue', $tcpar_Protocol );
	}
	else {
		S_set_error("State $tcpar_State is incorrect, it should be either Timeout or OutOfRangeValue. Test case aborted");
		return;
	}

	S_wait_ms(4000);

	S_teststep( "Erase EDR", 'AUTO_NBR' );
	PD_ClearCrashRecorder_NOERROR();
	S_wait_ms(2000);

	S_teststep( "Erase Fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();
	S_wait_ms(2000);

	S_teststep( "Read fault memory after clearing", 'AUTO_NBR' );
	PD_ReadFaultMemory();

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	return 1;
}

sub _read_EDR_record {

	my $expectedResponse   = shift;
	my $evaluationRequired = shift;

	my $requestLabel;
	$requestLabel = $tcpar_Read_ChinaEDR;

	S_w2log( 3, "\n Sending Diag request to read EDR Entry \n" );

	unless ( defined $expectedResponse ) {
		$expectedResponse = "PR_$requestLabel";
	}
	my $noEvalSwitch;
	$noEvalSwitch = 'NO_EVAL_SWITCH' unless ( defined $evaluationRequired );

	# Send the diagnosis request via GDCOM
	my $response = GDCOM_request_general( "REQ_$requestLabel", $expectedResponse, undef, $noEvalSwitch );
	unless ($response) {
		S_wait_ms(2000);
		S_w2log( 2, "Try to read service again after short wait time" );
		$response = GDCOM_request_general( "REQ_$requestLabel", $expectedResponse, undef, $noEvalSwitch );
	}
	# In case of offline run, no response will be recieved
	return [] if $main::opt_offline;

	# Convert the received diagnosis response (string with hex values, each byte separated by space!) to array of bytes
	my @responseBytes = split( / /, $response );

	return \@responseBytes;
}
1;
