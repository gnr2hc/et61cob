#### TEST CASE MODULE
package TC_EDI_AKLV_RDBI_AKLV_RDBI_AKLV_RDBI_UnsupporetdDIDs;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.5 $;
our $HEADER = q$Header: AKLV/TC_EDI_AKLV_RDBI_AKLV_RDBI_AKLV_RDBI_UnsupporetdDIDs.pm 1.5 2014/07/07 16:25:43ICT DVR5KOR develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_EDR_DiagnosticInterface
#TS version in DOORS: 0.3
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_evaluation; 
use LIFT_PD;
use LIFT_CD;
use GENERIC_DCOM;
use INCLUDES_Project; #necessary
#include further modules here

##################################

our $PURPOSE = "To test the  NR_requestOutOfRange requirements for generic, OEM specific and supplier specific diag services with unsupported DIDs";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDI_AKLV_RDBI_AKLV_RDBI_AKLV_RDBI_UnsupporetdDIDs

=head1 PURPOSE

To test the  NR_requestOutOfRange requirements for generic, OEM specific and supplier specific diag services with unsupported DIDs

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation

Set <Test_Condition>


I<B<Stimulation and Measurement>>

1.Send Request to enter session [enterSession::<Session_to_be_entered>]

2. Send array of requests  [ ReadDataByIdentifier :: DID ] where DID are  <DID_Range> through 'NormalDiagnosticID'


I<B<Evaluation>>

1. Session is entered

2. NR_requestOutOfRange  is obtained 


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => Purpose of the test case
	SCALAR 'Session_to_be_entered' => Session to be entered
	LIST 'DID_Range' => Unsupported DIDs
	SCALAR 'Test_Condition' => Test Precondition 


=head2 PARAMETER EXAMPLES

	purpose = 'To check  for NRC_31'
	
	Session_to_be_entered ='<Test Heading>'
	DID_Range = @('00', '01',  '09', '19', '20','AA','DD','FE','FF')
	
	Test_Condition = 'GENERIC'
	#Sending 22 FA with UnsupporetdDID

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Session_to_be_entered;
my @tcpar_DID_Range;
my $tcpar_Test_Condition;


###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_Session_to_be_entered =  GEN_Read_mandatory_testcase_parameter( 'Session_to_be_entered' );
	@tcpar_DID_Range =  GEN_Read_mandatory_testcase_parameter( 'DID_Range' );
	$tcpar_Test_Condition =  GEN_Read_mandatory_testcase_parameter( 'Test_Condition' );

	return 1;
}

sub TC_initialization {
	
	GEN_printTestStep("Standard_Preparation");
	PD_ClearCrashRecorder();
	GEN_StandardPrepNoFault();
	GDCOM_start_CyclicTesterPresent();

	GEN_printTestStep(" Set Test Condition : '$tcpar_Test_Condition'");
	GEN_printComment ( "This is done in stimulation and measurement section" );
	return 1;
}

sub TC_stimulation_and_measurement {

	GEN_printTestStep("Step 1.Send Request to enter session ");
	if($tcpar_Session_to_be_entered eq 'DevelopmentSession')
	{
		GDCOM_StartSession ($tcpar_Session_to_be_entered,'CheckActiveSession');			
	}
	else
	{
		GDCOM_StartSession ($tcpar_Session_to_be_entered,'CheckActiveSession');			
	}
	
	my $NRCInfo = GDCOM_getNRCfromMapping('ReadDatabyID','NR_requestOutOfRange');
	
	GEN_printComment("Set Test Condition : $tcpar_Test_Condition !");
	if($tcpar_Test_Condition eq 'GENERIC')
	{
		foreach my $Unsupported_DID_Gen(@tcpar_DID_Range)
		{			 
			 GDCOM_request("22 FA $Unsupported_DID_Gen",$NRCInfo->{'Response'}, 'strict') ;											
		}		
	}
	elsif($tcpar_Test_Condition eq 'OEMSPECIFIC')
	{
		foreach my $Unsupported_DID_Oem(@tcpar_DID_Range)
		{			 
			 GDCOM_request("22 10 $Unsupported_DID_Oem",$NRCInfo->{'Response'}, 'strict') ;											
		}		
	}
	elsif($tcpar_Test_Condition eq 'SUPPLIERSPECIFIC')
	{
		foreach my $Unsupported_DID_SupplierSpecific(@tcpar_DID_Range)
		{			 
			 GDCOM_request("22 11 $Unsupported_DID_SupplierSpecific",$NRCInfo->{'Response'}, 'strict') ;											
		}		
	}
	else
	{
		S_set_error( "Test_Condition : $tcpar_Test_Condition is Incorrect. Not proceeding!", 0 );
		return 0;
	}
	

	GEN_printTestStep("Step 2. Send array of requests  [ ReadDataByIdentifier :: DID ] where DID are  '@tcpar_DID_Range' through 'NormalDiagnosticID'");

	return 1;
}

sub TC_evaluation {

	GEN_printTestStep("Evaluation for Step 1. Session is entered");
	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");

	GEN_printTestStep("Evaluation for Step 2. NR_requestOutOfRange  is obtained ");
	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");

	return 1;
}

sub TC_finalization {
	GDCOM_stop_CyclicTesterPresent();

	return 1;
}


1;
