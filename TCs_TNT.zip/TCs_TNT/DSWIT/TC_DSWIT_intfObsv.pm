#### TEST CASE MODULE
package TC_DSWIT_intfObsv;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
use List::MoreUtils qw( uniq );

#----------------------- TEST SPECIFICATION ------------------------------
#### INCLUDE ENGINE MODULES ####

#include further modules here
use LIFT_general;
use LIFT_evaluation;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_FaultMemory;
use LIFT_PD;

# use INCLUDES_Project;    #necessary
##################################

our $PURPOSE = " DSWIT Interface Observation Test ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSWIT_intfObsv

=head1 PURPOSE

Testcase Module for Dynamic SW Integration Test (sub function Interface Observation)

=head1 TESTCASE DESCRIPTION

I<B<Initialisation>>

I<B<Stimulation and Measurement>>

I<B<Finalisation>>

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

	ARRAY 'REF_INTERFACES' => reference to Rhapsody sequ diagram ( for reporting ) 
	ARRAY 'REF_SEQ_DIAGRAM' => reference to Rhapsody interfaces ( for reporting ) 
	SCALAR 'TRG' => testcase trigger of DSWIT in SW
	SCALAR 'STATE' => enviromental state for execution condition of testcase
	SCALAR 'POST_WAIT_TIME_MS' -> time to wait after setting the TRG ( only STEADY state tests) before reading the result

=head2 PARAMETER EXAMPLES

	purpose 		= 'write here for what this test is good for' 
	TRG             = 1
	REF_SEQ_DIAGRAM = @( 'Diagram_Model_xyz' )
	REF_INTERFACES  = @( 'Interface_A' , 'Interface_B'  )
	STATE        	= 'STEADY_STATE'
	POST_WAIT_TIME_MS    = 5000

=cut

#PARAMETERS
################ Parameters from .par file ###################

my (
    $tcpar_REF_INTERFACES_aref,
    $tcpar_REF_SEQ_DIAGRAM_aref,
    $tcpar_STATE,
    $tcpar_TRG,

    $tcpar_PRE_WAIT_TIME_MS,     # TODO : what shall be the default value ?  (currently TIMER_ECU_READY implemented)
    $tcpar_POST_WAIT_TIME_MS,    # TODO : what shall be the default value ?  (currently 2000ms implemented)

    $tcpar_PRE_ERASE_EDR_RECORD,
    $tcpar_POST_ERASE_EDR_RECORD,

    $tcpar_PRE_ERASE_FAULT_RECORDER,
    $tcpar_POST_ERASE_FAULT_RECORDER,

    $tcpar_PRE_RESET,
    $tcpar_POST_RESET,

    $tcpar_READ_FAULT_RECORDER,

);

my $map_intern_DSWIT_result = {
    'TEST_NOT_EXECUTED'   => 0,    # constant. by default the test case is in not executed state
    'TEST_PASSED'         => 1,    # constant. Value if the testcase is passed
    'TEST_FAILED'         => 2,    # constant. Value if the testcase is failed
    'TEST_NOT_APPLICABLE' => 3,    # constant. Value if the testcase is not applicable (due to Compiler settings)
};

my $result_TRG;
my $numberOfFaults;

################ global parameter declaration ###################
#add any global variables here
###############################################################

sub TC_set_parameters {

    $tcpar_TRG = S_read_mandatory_testcase_parameter('TRG') || return;

    $tcpar_REF_INTERFACES_aref  = S_read_optional_testcase_parameter( 'REF_INTERFACES',  'byref', ['NO INTERFACES GIVEN'] );
    $tcpar_REF_SEQ_DIAGRAM_aref = S_read_optional_testcase_parameter( 'REF_SEQ_DIAGRAM', 'byref', ['NO SEQ DIAGRAM GIVEN'] );
    $tcpar_STATE                = S_read_optional_testcase_parameter( 'STATE',           'byref', ['NO TEST STATE GIVEN'] );

    $tcpar_PRE_WAIT_TIME_MS          = S_read_optional_testcase_parameter( 'PRE_WAIT_TIME_MS',          'byref', 'TIMER_ECU_READY' );    # done
    $tcpar_POST_WAIT_TIME_MS         = S_read_optional_testcase_parameter( 'POST_WAIT_TIME_MS',         'byref', 2000 );                 # done
    $tcpar_PRE_RESET                 = S_read_optional_testcase_parameter( 'PRE_RESET',                 'byref', 0 );                    # done
    $tcpar_POST_RESET                = S_read_optional_testcase_parameter( 'POST_RESET',                'byref', 0 );                    # done
    $tcpar_PRE_ERASE_FAULT_RECORDER  = S_read_optional_testcase_parameter( 'PRE_ERASE_FAULT_RECORDER',  'byref', 1 );                    # done
    $tcpar_POST_ERASE_FAULT_RECORDER = S_read_optional_testcase_parameter( 'POST_ERASE_FAULT_RECORDER', 'byref', 0 );                    # done
    $tcpar_PRE_ERASE_EDR_RECORD      = S_read_optional_testcase_parameter( 'PRE_ERASE_EDR_RECORD',      'byref', 0 );                    # done
    $tcpar_POST_ERASE_EDR_RECORD     = S_read_optional_testcase_parameter( 'POST_ERASE_EDR_RECORD',     'byref', 0 );                    # done
    $tcpar_READ_FAULT_RECORDER       = S_read_optional_testcase_parameter( 'READ_FAULT_RECORDER',       'byref', 1 );                    # done
    return 1;
}

sub TC_initialization {

    if ($tcpar_PRE_ERASE_EDR_RECORD) {

        my $sw_label__StateOfDCS = "rb_dcrm_StateOfDCS_en";
        S_teststep( "TEMP CHECK : Read_Memory('$sw_label__StateOfDCS') must be 6 (Idle)", 'AUTO_NBR' );
        DSWIT_read_evaluate_SW_label( $sw_label__StateOfDCS, '==', '0x06' );

        my $sw_label__StatusFirCtrl = "rb_fcl_StatusFirCtrl_u8";
        S_teststep( "TEMP CHECK : Read_Memory('$sw_label__StatusFirCtrl')", 'AUTO_NBR' );
        DSWIT_read_evaluate_SW_label($sw_label__StatusFirCtrl);

        S_teststep( "Clear EDR Crash Recorder (PRE_ERASE_EDR_RECORD) ", 'AUTO_NBR' );
        PD_ClearCrashRecorder();

        #        S_wait_ms(2000);
    }

    if ($tcpar_PRE_ERASE_FAULT_RECORDER) {
        S_teststep( "Clear FCM (PRE_ERASE_FAULT_RECORDER)", 'AUTO_NBR' );
        PD_ClearFaultMemory();

        #        S_wait_ms('TIMER_ECU_READY');
    }

    if ($tcpar_PRE_RESET) {
        S_teststep( "Reset ECU (PRE_RESET)", 'AUTO_NBR' );
        S_teststep_2nd_level( "Switch ECU Off", 'AUTO_NBR' );
        LC_ECU_Off();
        S_teststep_2nd_level( "Wait", 'AUTO_NBR' );
        S_wait_ms('TIMER_ECU_OFF');
        S_teststep_2nd_level( "Switch ECU On", 'AUTO_NBR' );
        LC_ECU_On();
        S_teststep_2nd_level( "Wait $tcpar_PRE_WAIT_TIME_MS ms (PRE_WAIT_TIME_MS)", 'AUTO_NBR' );
        S_wait_ms($tcpar_PRE_WAIT_TIME_MS);
    }

    $numberOfFaults = 0;

    return 1;
}

sub TC_stimulation_and_measurement {

    S_teststep( " Printout Rhapsody Reference Sequence Diagrams: " . join( " ", @$tcpar_REF_SEQ_DIAGRAM_aref ), 'AUTO_NBR' );
    foreach my $seqDiagr (@$tcpar_REF_SEQ_DIAGRAM_aref) {
        S_add2eval_collection( 'REF_SEQU_DIAGRAMS', $seqDiagr );
    }
    S_w2rep("\n");

    S_teststep( " Printout Rhapsody Info about affected SW interfaces: ", 'AUTO_NBR' );
    my @uniq_list_REF_INTERFACES = uniq(@$tcpar_REF_INTERFACES_aref);
    foreach my $swIntf (@uniq_list_REF_INTERFACES) {
        S_teststep_2nd_level( " Tested SW interface: $swIntf", 'AUTO_NBR' );
        S_add2eval_collection( 'REF_SW_INTERFACES', $swIntf );
    }
    S_w2rep("\n");

    S_teststep( "Execute D-SWIT Testcase for state: '$tcpar_STATE'", 'AUTO_NBR' );

    S_teststep_2nd_level( "DSWIT_startTestcaseByTrigger($tcpar_TRG)", 'AUTO_NBR' );
    DSWIT_startTestcaseByTrigger($tcpar_TRG) || return;

    if ( $tcpar_STATE eq "INIT" ) {
        S_teststep_2nd_level( "Wait 1 sec before ECU Soft Reset", 'AUTO_NBR' );
        S_wait_ms(1000);
        S_teststep_2nd_level( "PRD_ECU_Reset( {'resetType'=>'SOFT'} )", 'AUTO_NBR' );
        PRD_ECU_Reset( { 'resetType' => 'SOFT' } );
        S_teststep_2nd_level( "Wait timer 'TIMER_ECU_READY' after ECU Soft Reset", 'AUTO_NBR' );
        S_wait_ms( 'TIMER_ECU_READY', 'wait in order to let SW initializing' );
    }

    S_teststep_2nd_level( "Wait $tcpar_POST_WAIT_TIME_MS msec (POST_WAIT_TIME_MS)", 'AUTO_NBR' );
    S_wait_ms($tcpar_POST_WAIT_TIME_MS);

    S_teststep_2nd_level( "DSWIT_readResultVar($tcpar_TRG) and create Execution VERDICT", 'AUTO_NBR' );
    $result_TRG = DSWIT_readResultVar($tcpar_TRG);

    S_teststep( "Evaluate TRG Result and set VERDICT", 'AUTO_NBR' );
    if    ( $result_TRG == $map_intern_DSWIT_result->{'TEST_PASSED'} )         { S_set_verdict(VERDICT_PASS) }
    elsif ( $result_TRG == $map_intern_DSWIT_result->{'TEST_FAILED'} )         { S_set_verdict(VERDICT_FAIL) }
    elsif ( $result_TRG == $map_intern_DSWIT_result->{'TEST_NOT_APPLICABLE'} ) { S_set_warning("TEST_NOT_APPLICABLE"); S_set_verdict(VERDICT_NONE) }
    elsif ( $result_TRG == $map_intern_DSWIT_result->{'TEST_NOT_EXECUTED'} )   { S_set_warning("TEST_NOT_EXECUTED"); S_set_verdict(VERDICT_NONE) }
    else                                                                       { S_set_error("UNEXPECTED RESULT VALUE: $result_TRG") }

    if ($tcpar_READ_FAULT_RECORDER) {
        S_teststep( "Read FCM (READ_FAULT_RECORDER)", 'AUTO_NBR' );

        S_teststep_2nd_level( "Read FCM 'Bosch'", 'AUTO_NBR', 'read_Bosch_FCM' );
        my $fcm_Bosch_obj = LIFT_FaultMemory->read_fault_memory('Bosch');
        $numberOfFaults = $fcm_Bosch_obj->get_number_of_faults();

        my $entry_obj_aref = $fcm_Bosch_obj->get_faults_with_properties( { 'DecodedStatus' => { 'TestFailed' => 1 } } );
        foreach my $fault_obj (@$entry_obj_aref) {
            S_teststep_detected( "Qualified (BOSCH) Fault entry (BOSCH)" . $fault_obj->FaultName, 'read_Bosch_FCM' );
        }

        S_teststep_2nd_level( "Read FCM 'Disturbance'", 'AUTO_NBR' );
        my $fcm_Disturb_obj = LIFT_FaultMemory->read_fault_memory('Disturbance');
        $numberOfFaults += $fcm_Disturb_obj->get_number_of_faults();

        S_teststep_2nd_level( "Read FCM 'Plant'", 'AUTO_NBR' );
        my $fcm_Plant_obj = LIFT_FaultMemory->read_fault_memory('Plant');
        $numberOfFaults += $fcm_Plant_obj->get_number_of_faults();

        S_teststep_2nd_level( "Read FCM 'Primary'", 'AUTO_NBR' );
        my $fcm_Primary_obj = LIFT_FaultMemory->read_fault_memory('Primary');
        $numberOfFaults += $fcm_Primary_obj->get_number_of_faults();

        if ($numberOfFaults) {
            S_w2rep( "FCM is not empty -> POST_RESET and POST_ERASE_FAULT_RECORDER will be activated\n", 'grey' );
            $tcpar_POST_ERASE_FAULT_RECORDER = 1;
            $tcpar_POST_RESET                = 1;
        }

    }

    return 1;
}

#sub TC_evaluation {
#
#    return 1;
#}

sub TC_finalization {

    if ($tcpar_POST_RESET) {
        S_teststep( "Reset ECU (POST_RESET)", 'AUTO_NBR' );
        S_teststep_2nd_level( "Switch ECU Off", 'AUTO_NBR' );
        LC_ECU_Off();
        S_teststep_2nd_level( "Wait", 'AUTO_NBR' );
        S_wait_ms('TIMER_ECU_OFF');
        S_teststep_2nd_level( "Switch ECU On", 'AUTO_NBR' );
        LC_ECU_On();
        S_teststep_2nd_level( "Wait 'TIMER_ECU_ON' ms", 'AUTO_NBR' );
        S_wait_ms('TIMER_ECU_READY');
    }

    if ($tcpar_POST_ERASE_EDR_RECORD) {

        my $sw_label__StateOfDCS = "rb_dcrm_StateOfDCS_en";
        S_teststep( "TEMP CHECK : Read_Memory('$sw_label__StateOfDCS') must be 6 (Idle)", 'AUTO_NBR' );
        DSWIT_read_evaluate_SW_label( $sw_label__StateOfDCS, '==', '0x06' );

        my $sw_label__StatusFirCtrl = "rb_fcl_StatusFirCtrl_u8";
        S_teststep( "TEMP CHECK : Read_Memory('$sw_label__StatusFirCtrl')", 'AUTO_NBR' );
        DSWIT_read_evaluate_SW_label($sw_label__StatusFirCtrl);

        S_teststep( "Clear EDR Crash Recorder (POST_ERASE_EDR_RECORD)", 'AUTO_NBR' );
        PD_ClearCrashRecorder();

        #        S_wait_ms(2000);
    }

    if ($tcpar_POST_ERASE_FAULT_RECORDER) {
        S_teststep( "Clear FCM (POST_ERASE_FAULT_RECORDER)", 'AUTO_NBR' );
        PD_ClearFaultMemory();

        #        S_wait_ms('TIMER_ECU_READY');
    }

    return 1;
}

sub DSWIT_startTestcaseByTrigger {
    my $trigger_nbr                    = shift;
    my $control_labels_TestCaseTrigger = "rb_DSWITTestcaseTrigger_u32";

    S_w2log( 3, " DSWIT_startTestcaseByTrigger: PRD_Write_Memory( $control_labels_TestCaseTrigger, $trigger_nbr \n ", 'grey' );
    PRD_Write_Memory( $control_labels_TestCaseTrigger, $trigger_nbr ) || return;

    #    S_wait_ms(100);
    my $check_value_str = S_aref2hex( PRD_Read_Memory($control_labels_TestCaseTrigger) );
    S_w2log( 3, " DSWIT_startTestcaseByTrigger: Read Symbol $control_labels_TestCaseTrigger => $check_value_str (might be reset already) \n", 'grey' );

    # PD_WriteMemoryByName( $control_labels_TestCaseTrigger, $memoryContents_aref ) || return;
    return 1;

}

sub DSWIT_readResultVar {
    my $trigger_nbr = shift;

    my $control_labels_ResultVar = "rb_DSWITTestcaseResult_au8($trigger_nbr)";

    S_w2log( 3, " DSWIT_readResultVar PRD_Read_Memory( $control_labels_ResultVar, [$trigger_nbr] \n ", 'grey' );
    my $data_aref = PRD_Read_Memory( $control_labels_ResultVar, { 'NbrOfBytes' => 1 } );

    # my $data_aref = PD_ReadMemoryByName($control_labels_ResultVar);

    S_w2log( 3, " DSWIT_readResultVar: ResultVar content : " . join( ' ', @$data_aref ) . "\n" );

    my $result_trigger = shift(@$data_aref);

    return $result_trigger;
}

sub DSWIT_read_evaluate_SW_label {
    my $sw_label  = shift;
    my $operator  = shift;
    my $exp_value = shift;

    my $check_value_str = S_aref2hex( PRD_Read_Memory($sw_label) );
    S_teststep_detected("$sw_label = $check_value_str");
    $check_value_str = hex $check_value_str;

    unless ( defined $operator ) {
        S_w2rep( "No evaluation for '$sw_label' \n", 'grey' );
        return VERDICT_NONE;
    }

    S_teststep_expected("$sw_label := $exp_value");
    $exp_value = hex $exp_value if $exp_value =~ /0x/;

    my $verdict = EVAL_evaluate_value( "SW label '$sw_label'", $check_value_str, '==', $exp_value );

    return $verdict;
}

1;
