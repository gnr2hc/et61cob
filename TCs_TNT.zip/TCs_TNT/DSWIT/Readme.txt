DSWIT testcases are stored and developed ONLY in RTC SCM
in component : rbh.ab12.TCs_DSWIT_common

storage in MKS here is only for informal reason

