#### TEST CASE MODULE
package TC_COM_CAN_Busoff;


#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.6 $;
our $HEADER = q$Header: COM/TC_COM_CAN_Busoff.pm 1.6 2017/07/30 00:16:31ICT Satish N (RBEI/ESM6) (stn3kor) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_COM_Application
#TS version in DOORS: 4.22
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
use LIFT_can_access;
use LIFT_labcar;
use GENERIC_DCOM;
use LIFT_PD;
use LIFT_CD;
use LIFT_evaluation;

 #necessary
#include further modules here

##################################

our $PURPOSE = "<To create a bus off and checking the fault status under different voltage conditions and different ECU modes>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_COM_CAN_Busoff

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation


I<B<Stimulation and Measurement>>

1. Set ECU Mode <ECU_Mode>

2.  Set the ECU Supply Voltage at <VoltageCondition_V>

 

3. Switch OFF the ECU.

4. Wait till ECU goes to Off State

5. Switch ON the ECU.

6. Wait till ECU intialization period completes

7. Create Bus off condition by <Method> 

8. Remove Bus off condition and wait till <BusOffRecoveryTime_ms>

9. Read the fault recorder by PD after Fault DeQualification

10. Read the fault recorder by CD after Fault DeQualification


I<B<Evaluation>>

1.

2.

3.

4.

5.

6.

7.

8.

9a. Fault <faultname>   status  must have <FaultDeQualistatus> 

9b. Warning lamp <SysWL_SigLabel>  is <WL_FaultDequali>

10. Fault <faultname>   status  must have <FaultDeQualistatus>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Faulthandling' => 
	SCALAR 'faultname' => 
	SCALAR 'FaultDeQualistatus' => 
	SCALAR 'WL_FaultDequali' => 
	SCALAR 'purpose' => 
	SCALAR 'ECU_Mode' => 
	SCALAR 'VoltageCondition_V' => 
	SCALAR 'SysWL_SigLabel' => 
	SCALAR 'Method' => 
	SCALAR 'BusOffRecoveryTime_ms' => 
	SCALAR 'CANterminal' => 


=head2 PARAMETER EXAMPLES

	# ---------- Stimulation ------------
	purpose = 'To check Faults management when Bus off occurs'
	ECU_Mode = '<Test Heading 1>'
	VoltageCondition_V = '<Test Heading 2>' # Volt
	SysWL_SigLabel = 'TBD'
	Method = '<Test Heading 3>'
	BusOffRecoveryTime_ms = 'TBD'
	CANterminal = 'TBD'
	# ---------- Evaluation ------------ 
	
	Faulthandling = 'TBD'
	faultname = 'TBD'
	FaultDeQualistatus = 'TBD'
	WL_FaultDequali = 'TBD'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_ECU_Mode;
my $tcpar_VoltageCondition_V;
my $tcpar_Method;
my $tcpar_BusOffRecoveryTime_ms;
my $tcpar_Faulthandling;
my $tcpar_Fault; 
my $sysWLAtFltDeQuali;                     
my %flt_mem_struct_pd;
my %flt_mem_struct_cd;
my $unit;
my $tcpar_SysWL_SigLabel;             
my $tcpar_WL_FaultDequali;
my $tcpar_FaultDeQualiStatus;
my $tcpar_CDFaultDeQualistatus;  
my (@tcpar_Accepted_Flts); 
my $tcpar_CANterminal;     

################ global parameter declaration ###################


###############################################################

sub TC_set_parameters {


    $tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_ECU_Mode =  GEN_Read_optional_testcase_parameter( 'ECU_Mode' );
    $tcpar_VoltageCondition_V =  GEN_Read_mandatory_testcase_parameter( 'VoltageCondition_V' );
    $tcpar_Method =  GEN_Read_mandatory_testcase_parameter( 'Method' );
    $tcpar_BusOffRecoveryTime_ms =  GEN_Read_optional_testcase_parameter( 'BusOffRecoveryTime_ms' );       
    $tcpar_Faulthandling =  GEN_Read_mandatory_testcase_parameter( 'Faulthandling' );
    $tcpar_SysWL_SigLabel = GEN_Read_mandatory_testcase_parameter( 'SysWL_SigLabel' );                    
    $tcpar_Fault =  GEN_Read_mandatory_testcase_parameter( 'faultname' );           
    $tcpar_WL_FaultDequali =  GEN_Read_mandatory_testcase_parameter( 'WL_FaultDequali' );
    $tcpar_FaultDeQualiStatus = GEN_Read_mandatory_testcase_parameter( 'FaultDeQualistatus' );
	$tcpar_CDFaultDeQualistatus = GEN_Read_mandatory_testcase_parameter( 'CDFaultDeQualistatus' );
	@tcpar_Accepted_Flts = GEN_Read_optional_testcase_parameter('Accepted_Flts');
	$tcpar_CANterminal = GEN_Read_mandatory_testcase_parameter( 'CANterminal' );

	unless( defined $tcpar_ECU_Mode ) {
  		S_w2rep(" -->  Missing optional parameter 'ECU_Mode'. Assuming it as 'NormalMode' \n");
  		$tcpar_ECU_Mode = 'NormalMode';
    };	
	
	unless( defined $tcpar_BusOffRecoveryTime_ms ) {
  		S_w2rep(" -->  Missing optional parameter 'BusOffRecoveryTime_ms'. Assuming it as '60000' ms \n");
  		$tcpar_BusOffRecoveryTime_ms = '60000';
    };
	
	
    unless( $tcpar_Faulthandling =~ /yes|no/i ) {
        S_set_error( "Unexpected setting for parameter 'FaultHandling'; use YES or NO "); return 0;
    }
    $tcpar_Faulthandling = 'YES' if $tcpar_Faulthandling =~ /yes/i;
	

	if(($tcpar_VoltageCondition_V >='6.5') and ($tcpar_VoltageCondition_V <= '20'))
	{
		S_w2rep("Set Voltage $tcpar_VoltageCondition_V within range(between 6.5 and 20 volts)\n"); 		
	}
	else
	{
		S_set_error( "Voltage out of range, set proper voltage "); 
		return 0;
	}
	
	return 1;
}

sub TC_initialization {

    S_teststep("Standard_Preparation", 'NO_AUTO_NBR');          
    GEN_StandardPrepNoFault();
    S_wait_ms(5000);

    return 1;
}

sub TC_stimulation_and_measurement {
################################################################## SET THE DIFFERENT ECU MODE ################################################################

    S_teststep("Set ECU Mode '$tcpar_ECU_Mode'", 'AUTO_NBR');
 
    if($tcpar_ECU_Mode eq 'Productionmode')
    {
        GEN_setECUMode('PlantMode10_SuppressComFaults');
    }
    elsif($tcpar_ECU_Mode eq 'Idlemode')
    {
        GEN_setECUMode('IdleMode');
    }
	else
	{
		S_w2rep(" No specific handling is required for Normal modes \n");
	}

############################################################### SET THE POWER SUPLLY VOLTAGE ###############################################################     

    S_teststep("Set the ECU Supply Voltage at '$tcpar_VoltageCondition_V'", 'AUTO_NBR');
    LC_SetVoltage( $tcpar_VoltageCondition_V);		
    
############################################################# RESET THE ECU ############################################################################################
    S_teststep("Switch OFF the ECU.", 'AUTO_NBR');
    LC_ECU_Off();
    
    S_teststep("Wait till ECU goes to Off State", 'AUTO_NBR');
    S_wait_ms('TIMER_ECU_OFF');
    
    S_teststep("Switch ON the ECU.", 'AUTO_NBR');
    LC_ECU_On($tcpar_VoltageCondition_V);
    
    S_teststep("Wait till ECU intialization period completes", 'AUTO_NBR');
    S_wait_ms('TIMER_ECU_READY');
########################################################## CREATE THE FAULT #########################################################################################    
    S_teststep("Create Bus off condition by shorting '$tcpar_Method' terminals", 'AUTO_NBR');
	#LC_ShortLines( [$tcpar_CANterminal . "-", 'B+'], 100 );
	LC_ShortLines( [$tcpar_CANterminal . "-", $tcpar_CANterminal . "+"], 100 );
	S_wait_ms(5000);
	LC_UndoShortLines();
    S_teststep("Wait $tcpar_BusOffRecoveryTime_ms ms for BusOff Recovery", 'AUTO_NBR');
    S_wait_ms($tcpar_BusOffRecoveryTime_ms);
	
    S_teststep("Read the fault recorder by PD after Qualification and DeQualification", 'AUTO_NBR', 'Read_PD_Faults_1'); 
    $flt_mem_struct_pd{'FaultStatus_afterDeQualification'} = PD_ReadFaultMemory();     
 
    S_teststep("Read the fault recorder by CD after Qualification and DeQualification", 'AUTO_NBR', 'Read_CD_Faults_1'); 
    $flt_mem_struct_cd{'FaultStatus_afterDeQualification'} = CD_read_DTC('02','08');  
    ($sysWLAtFltDeQuali,$unit) = CA_read_can_signal($tcpar_SysWL_SigLabel, 'hex' );                        #Read the warning Lamp status after fault qualification
                                                                    
    return 1;
}

sub TC_evaluation {
    if($tcpar_Faulthandling eq 'YES')         
    {    
        
        my $detected_PD_status = PD_get_fault_status( $flt_mem_struct_pd{'FaultStatus_afterDeQualification'}, $tcpar_Fault );        
        S_teststep_detected("Fault Status read by PD: $detected_PD_status (Faultname: $tcpar_Fault)", 'Read_PD_Faults_1');    
        S_teststep_expected("Fault Status read by PD: $tcpar_FaultDeQualiStatus (Faultname:$tcpar_Fault)", 'Read_PD_Faults_1');    
        PD_check_fault_status($flt_mem_struct_pd{'FaultStatus_afterDeQualification'}, $tcpar_Fault, $tcpar_FaultDeQualiStatus);
    
        my $detected_CD_status = CD_get_fault_status($flt_mem_struct_cd{'FaultStatus_afterDeQualification'}, $tcpar_Fault);      
        S_teststep_detected("Fault Status read by CD: $detected_CD_status (Faultname: $tcpar_Fault)", 'Read_CD_Faults_1');    
        S_teststep_expected("Fault Status read by CD: $tcpar_CDFaultDeQualistatus (Faultname:$tcpar_Fault)", 'Read_CD_Faults_1');    
        CD_check_fault_status($flt_mem_struct_cd{'FaultStatus_afterDeQualification'}, $tcpar_Fault, $tcpar_CDFaultDeQualistatus);
        
        S_teststep_detected("Detected Warning lamp status after dequalification : $sysWLAtFltDeQuali (Faultname:$tcpar_Fault) ", 'Read_PD_Faults_1');
		S_teststep_expected("Expected Warning lamp status after dequalification: $tcpar_WL_FaultDequali (Faultname:$tcpar_Fault)", 'Read_PD_Faults_1');
        EVAL_evaluate_value( "System warning lamp status after fault Dequalification : ", $sysWLAtFltDeQuali, '==', $tcpar_WL_FaultDequali ); #Evalute the WL status
                
    }
    else
    {
            

        my $CD_flt_mem_struct = CD_read_DTC('02','08'); 
		CD_evaluate_faults( $CD_flt_mem_struct, [@tcpar_Accepted_Flts] ); 
		
		my $PD_flt_mem_struct = PD_ReadFaultMemory();
		PD_evaluate_faults( $PD_flt_mem_struct, [@tcpar_Accepted_Flts] );      
    
    }

    return 1;
}

sub TC_finalization {
    
    S_w2rep("TC FINALIZATION\n"); 
    
         
    if($tcpar_ECU_Mode eq 'Productionmode')
    {
        GEN_setECUMode('RemovePlantModes');
        S_wait_ms (5000);
    }
    
    if($tcpar_ECU_Mode eq 'Idlemode')
    {
        GEN_setECUMode('RemoveIdleMode');
        S_wait_ms (5000);
    }
	
	PD_ClearFaultMemory();
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
    
    return 1;
}


1;
