#### TEST CASE MODULE
package TC_COM_CommunicationFaultHandlingByDiagnosticServicewithinVoltageRange;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.3 $;
our $HEADER = q$Header: COM/TC_COM_CommunicationFaultHandlingByDiagnosticServicewithinVoltageRange.pm 1.3 2017/07/30 00:16:38ICT Satish N (RBEI/ESM6) (stn3kor) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_COM_Application
#TS version in DOORS: 4.22
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use INCLUDES_Project;
use LIFT_can_access;
use LIFT_labcar;
use GENERIC_DCOM;
use LIFT_PD;
use LIFT_CD;
use LIFT_evaluation;

##################################

our $PURPOSE = "To Check functionality of CommunicationControl service";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_COM_CommunicationFaultHandlingByDiagnosticServicewithinVoltageRange

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation


I<B<Stimulation and Measurement>>

1. Send Request to <Enter_Session>

2. Send request to <EnableDisable> 

3. Create a  <COM_Fault> fault

4. Wait for <QualificationTime> 

5. Read Fault Recorder through PD after fault qualification

6.Read Fault Recorder through CD after fault qualification

7. Read Warning lamp after fault qualification

8. Remove <COM_Fault>  and wait for <DequalificationTime> 

9. Read Fault Recorder through PD after fault dequalification

10. Read Fault Recorder through CD after fault dequalification

11. Read Warning lamp after fault dequalification

12. Clear Fault recorder

13. Read Fault Recorder through PD after erasure

14. Read Fault Recorder through CD after erasure

15. Read Warning lamp status after fault erasure


I<B<Evaluation>>

1. Session entry is successful.

2. Positive Response is obtained

3.

4.

5.The Fault <faultname>  should have <FaultQualiStatus> 

6. The Fault <faultname>  should have <FaultQualiStatus >

7. Warning lamp <SysWL_SigLabel> should have the status <SysWLQualiStatus>

8.

9.  The Fault <faultname>  should have <FaultDequaliStatus>

10. The Fault <faultname>  should have <FaultDequaliStatus>

11. Warning lamp <SysWL_SigLabel> should have the status <SysWLDequaliStatus>

12.

13. Fault recorder should be empty. 

14.Fault recorder should be empty. 

15. System warning lamp status after fault erasure should be <WL_Faulterasure>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'faultname' => 
	SCALAR 'FaultQualiStatus' => 
	SCALAR 'SysWLQualiStatus' => 
	SCALAR 'FaultDequaliStatus' => 
	SCALAR 'SysWLDequaliStatus' => 
	SCALAR 'MessageName' => 
	SCALAR 'purpose' => 
	SCALAR 'Enter_Session' => 
	SCALAR 'EnableDisable' => 
	SCALAR 'SysWL_SigLabel' => 
	SCALAR 'COM_Fault' => 
	SCALAR 'WL_Faulterasure' => 
	SCALAR 'Protocol' => 


=head2 PARAMETER EXAMPLES

	purpose = 'To Check functionality of CommunicationControl service'
	
	Enter_Session =  'ExtendedSession'
	EnableDisable = '<Test Heading 1>'
	SysWL_SigLabel = 'TBD'
	COM_Fault = '<Test Heading 2>'
	WL_Faulterasure = '0'
	Protocol = 'can'
	faultname = 'TBD'
	FaultQualiStatus = 'TBD'
	SysWLQualiStatus = 'TBD'
	FaultDequaliStatus = 'TBD'
	SysWLDequaliStatus = 'TBD'
	MessageName = 'TBD'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Enter_Session;
my $tcpar_EnableDisable;
my $tcpar_COM_Fault;
my $tcpar_faultname;
my $tcpar_NbOfCycles;
my $tcpar_MessageName;
my $tcpar_Protocol;
my $tcpar_Method;
my $QualificationTime;
my $tcpar_signal;
my $tcpar_physicalValue;
my $tcpar_SysWL_SigLabel;
my $DequalificationTime;
my $tcpar_WL_Faultquali;
my $tcpar_WL_FaultDequali;
my $tcpar_mode;
my $tcpar_physicalValueValid;
my $tcpar_Faulthandling;
my $tcpar_FaultQualiStatus;
my $tcpar_FaultDequaliStatus;
################ global parameter declaration ###################
my %flt_mem_struct_ProductionDisable_qualification;
my %flt_mem_struct_CustomerDisable_qualification;
my %flt_mem_struct_ProductionDisable_dequalification;
my %flt_mem_struct_CustomerDisable_dequalificaiton;
my %flt_mem_struct_Production_erase;
my %flt_mem_struct_Customer_erase;

my $sysWLAtFltQuali;
my $sysWLAtFltDequali;
my $unit;
my $MyMsgInfo;
my $detected_PD_status;
my $detected_CD_status;
my $TP_handle;
my $tcpar_WL_Faulterasure;
my $sysWLAtFlterasure;
my $InvalidCRCValue = 1;
my $ValidCRCValue = 0;
my $CRCEnVarName;
my $InvalidBZValue = 1;
my $ValidBZValue = 0;
my $BZEnVarName;
my $faultproperty;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_Enter_Session =  S_read_mandatory_testcase_parameter( 'Enter_Session' );
	$tcpar_EnableDisable =  S_read_mandatory_testcase_parameter( 'EnableDisable' );
	$tcpar_COM_Fault =  S_read_mandatory_testcase_parameter( 'COM_Fault' );
	$tcpar_faultname =  S_read_mandatory_testcase_parameter( 'faultname' );
	$tcpar_Method = S_read_optional_testcase_parameter( 'Method' ); 
	unless( defined $tcpar_Method ) 
	{
			S_w2rep(" -->  Missing optional parameter 'Method', By default script uses 'Constant' as the method. \n");
			$tcpar_Method = 'Constant';
			
	};
	$tcpar_NbOfCycles = GEN_Read_optional_testcase_parameter('NbOfCycles');	 
	$tcpar_Protocol = S_read_mandatory_testcase_parameter( 'Protocol' );
	$tcpar_MessageName = GEN_Read_optional_testcase_parameter('MessageName');	 
	$tcpar_signal = S_read_mandatory_testcase_parameter('signal');	
	$tcpar_physicalValue = S_read_mandatory_testcase_parameter('physicalValue');
	$tcpar_SysWL_SigLabel = S_read_mandatory_testcase_parameter('SysWL_SigLabel');
	$DequalificationTime = S_read_mandatory_testcase_parameter('DequalificationTime');
	$QualificationTime = S_read_mandatory_testcase_parameter('QualificationTime');
	$tcpar_WL_Faultquali = S_read_mandatory_testcase_parameter('WL_Faultquali');
	$tcpar_WL_FaultDequali = S_read_mandatory_testcase_parameter('WL_FaultDequali');
	$tcpar_mode = S_read_mandatory_testcase_parameter('mode');
	$tcpar_physicalValueValid = S_read_mandatory_testcase_parameter('physicalValueValid');
	$tcpar_Faulthandling = S_read_mandatory_testcase_parameter('Faulthandling');
	$tcpar_FaultQualiStatus =  S_read_mandatory_testcase_parameter( 'FaultQualiStatus' );
	$tcpar_FaultDequaliStatus =  S_read_mandatory_testcase_parameter( 'FaultDequaliStatus' );
	$tcpar_WL_Faulterasure = 0;
	return 1;
}

sub TC_initialization {

	S_teststep("Standard_Preparation", 'NO_AUTO_NBR');          
    GEN_StandardPrepNoFault();
    S_wait_ms(5000);
	
	my $CAN_Mapping = S_get_contents_of_hash( ['Mapping_CAN'] );	
	$CRCEnVarName = $CAN_Mapping->{'CAN_MESSAGES'}{$tcpar_MessageName}{'CANOE_VALIDCRC'};
	
	$CAN_Mapping = S_get_contents_of_hash( ['Mapping_CAN'] );	
	$BZEnVarName = $CAN_Mapping->{'CAN_MESSAGES'}{$tcpar_MessageName}{'CANOE_VALIDBZ'};
	
	
	# Fetching of Fault Quali and dequli times from the Fault mapping file
	$faultproperty = FM_fetchFaultInfo($tcpar_faultname);
		
	unless ( keys(%$faultproperty) )
	{                                                     #check if keys are read successfully from mapping file
		S_set_error( "Details are not read successfully from fault mapping file", 10 );    #Error!
		return undef;
	}
	$QualificationTime  = $faultproperty->{'CyclicQualificationtime'};
	$DequalificationTime  = $faultproperty->{'CyclicDequalificationtime'};

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Send Request to '$tcpar_Enter_Session'", 'AUTO_NBR', 'send_request_to_EnterSession');			#measurement 1
	GDCOM_set_addressing_mode($tcpar_mode);
	$TP_handle = GDCOM_start_CyclicTesterPresent();
	if( $tcpar_Enter_Session eq 'ExtendedSession')
	{		
		GDCOM_request_general ('REQ_StartSession_ExtendedSession','PR_StartSession_ExtendedSession');
	}
	S_wait_ms(500);	

	S_teststep("Send request to '$tcpar_EnableDisable'  ", 'AUTO_NBR', 'send_request_to_Enable_Disable');			#measurement 2
	if($tcpar_EnableDisable eq 'enableRxAndTx')
	{
		GDCOM_request_general('REQ_CommunicationControl_EnableRxAndTx','PR_CommunicationControl_EnableRxAndTx');	
	}
	elsif($tcpar_EnableDisable eq 'disableRxAndTx')
	{
		GDCOM_request_general('REQ_CommunicationControl_DisableRxAndTx','PR_CommunicationControl_DisableRxAndTx');	
		
	}
	elsif($tcpar_EnableDisable eq 'enableRxAndDisableTx')
	{
		GDCOM_request_general('REQ_CommunicationControl_EnableRxAndDisableTx','PR_CommunicationControl_EnableRxAndDisableTx');	
	}
	elsif($tcpar_EnableDisable eq 'DisableRxAndEnableTx')
	{
		GDCOM_request_general('REQ_CommunicationControl_DisableRxAndEnableTx','PR_CommunicationControl_DisableRxAndEnableTx');
	
	}
	S_teststep("Create a  '$tcpar_COM_Fault' Fault", 'AUTO_NBR');
	if($tcpar_COM_Fault eq 'Timeout')
	{
		COM_stopMessages( [$tcpar_MessageName], $tcpar_Protocol );
	}
	elsif($tcpar_COM_Fault eq 'InvalidSignal')
	{
		COM_setSignalState ($tcpar_signal, $tcpar_physicalValue, $tcpar_Protocol);
	}
	elsif($tcpar_COM_Fault eq 'CRC')
	{		
		#CA_set_invalidCRC($tcpar_MessageName,$tcpar_Method);
		CA_set_EnvVar_value ( $CRCEnVarName, $InvalidCRCValue);
	}
	elsif($tcpar_COM_Fault eq 'AliveCntr')
	{
		#CA_set_invalidBZ($tcpar_MessageName,$tcpar_Method,$tcpar_NbOfCycles);
		CA_set_EnvVar_value ( $BZEnVarName, $InvalidBZValue);
	}

	S_teststep("Wait for '$QualificationTime' ", 'AUTO_NBR');
	S_wait_ms($QualificationTime);	
	
	S_teststep("Read Fault Recorder through PD after fault qualification", 'AUTO_NBR', 'CD_FaultStatus_afterQualification');			#measurement 4
	$flt_mem_struct_ProductionDisable_qualification{'FaultStatus_afterQualification'} = PD_ReadFaultMemory();
	S_wait_ms (2000);
	S_teststep("Read Fault Recorder through CD after fault qualification", 'AUTO_NBR', 'PD_FaultStatus_afterQualification');
	$flt_mem_struct_CustomerDisable_qualification{'FaultStatus_afterQualification'} = CD_read_DTC('02','08');
	
	S_teststep("Read Warning lamp after fault qualification", 'AUTO_NBR', 'WL_status_after_Fault_qualification');
	S_w2rep("  System warning lamp value received from CAN after fault Qualification  : $sysWLAtFltQuali \n");	#Read the warning Lamp status after fault Dequalification
	($sysWLAtFltQuali,$unit) = CA_read_can_signal($tcpar_SysWL_SigLabel, 'hex' );	
	
	S_teststep("Remove '$tcpar_COM_Fault'  and wait for '$DequalificationTime' ", 'AUTO_NBR');
	if($tcpar_COM_Fault eq 'Timeout')
	{
		COM_startMessages( [$tcpar_MessageName], $tcpar_Protocol );
	}
	elsif($tcpar_COM_Fault eq 'InvalidSignal')
	{
		COM_setSignalState ($tcpar_signal, $tcpar_physicalValueValid, $tcpar_Protocol);
	}
	elsif($tcpar_COM_Fault eq 'CRC')
	{
		#CA_set_validCRC($tcpar_MessageName);
		CA_set_EnvVar_value ( $CRCEnVarName, $ValidCRCValue);
	}
	elsif($tcpar_COM_Fault eq 'AliveCntr')
	{
		#CA_set_validBZ($tcpar_MessageName);
		CA_set_EnvVar_value ( $BZEnVarName, $ValidBZValue);
	}
	S_wait_ms ($DequalificationTime);	
	
	S_teststep("Read Fault Recorder through PD after fault dequalification", 'AUTO_NBR', 'PD_FaultStatus_afterDeQualification');			#measurement 4
	$flt_mem_struct_ProductionDisable_dequalification{'FaultStatus_afterDeQualification'} = PD_ReadFaultMemory();
	S_wait_ms (2000);
	S_teststep("Read Fault Recorder through CD after dequalification", 'AUTO_NBR', 'CD_FaultStatus_afterDeQualification');
	$flt_mem_struct_CustomerDisable_dequalificaiton{'FaultStatus_afterDeQualification'} = CD_read_DTC('02','08');
	
	S_teststep("Read Warning lamp after fault dequalification", 'AUTO_NBR', 'WL_status_after_Fault_dequalification');
	S_w2rep("  System warning lamp value received from CAN after fault dequalification  : $sysWLAtFltDequali \n");	#Read the warning Lamp status after fault Dequalification
	($sysWLAtFltDequali,$unit) = CA_read_can_signal($tcpar_SysWL_SigLabel, 'hex' );	

	S_teststep("Clear Fault Recorder.", 'AUTO_NBR', 'clear_fault_recorder');			#measurement 5
	PD_ClearFaultMemory();
	S_wait_ms (2000);
	
	S_teststep("Read Fault Recorder through CD after erasure", 'AUTO_NBR', 'PD_Fault_status_after_Fault_erasure');
	$flt_mem_struct_Production_erase{'PD_Fault_status_after_Fault_erasure'} = PD_ReadFaultMemory();
	S_wait_ms (2000);
	
	S_teststep("Read Fault Recorder through CD after erasure", 'AUTO_NBR', 'CD_Fault_status_after_Fault_erasure');
	$flt_mem_struct_Customer_erase{'CD_Fault_status_after_Fault_erasure'} = CD_read_DTC('02','08');
	
	S_teststep("Read Warning lamp status after fault erasure", 'AUTO_NBR', 'WL_status_after_Fault_erasure');
	S_w2rep("  System warning lamp value received from CAN after fault erasure  : $sysWLAtFlterasure \n");	
	($sysWLAtFlterasure,$unit) = CA_read_can_signal($tcpar_SysWL_SigLabel, 'hex' );	
	return 1;
}

sub TC_evaluation {

	S_teststep_expected("Session entry is successful.", 'send_request_to_EnterSession');			#evaluation 1
	S_teststep_detected("Refer trace for the request and response", 'send_request_to_EnterSession');

	S_teststep_expected("Positive Response is obtained", 'send_request_to_Enable_Disable');			#evaluation 2
	S_teststep_detected("Refer traces for request and response ", 'send_request_to_Enable_Disable');	

	if($tcpar_Faulthandling eq 'NO')
	{	
		#qualification
		PD_evaluate_faults($flt_mem_struct_ProductionDisable_qualification{'FaultStatus_afterQualification'}, []);        
		S_teststep_detected("Refer traces for the PD fault status", 'PD_FaultStatus_afterQualification');
		S_teststep_expected("Fault Recorder should be empty", 'PD_FaultStatus_afterQualification');	
					
		CD_evaluate_faults($flt_mem_struct_CustomerDisable_qualification{'FaultStatus_afterQualification'}, []);        
		S_teststep_detected("Refer traces for the PD fault status", 'CD_FaultStatus_afterQualification');
		S_teststep_expected("Fault Recorder should be empty", 'CD_FaultStatus_afterQualification');	
		
		S_teststep_detected("Detected Warning lamp status after fault qualification : $sysWLAtFltQuali  ", 'WL_status_after_Fault_qualification');
		S_teststep_expected("Expected Warning lamp status fault qualification: $tcpar_WL_Faultquali ", 'WL_status_after_Fault_qualification');
		EVAL_evaluate_value( "System warning lamp status after fault qualification : ", $sysWLAtFltQuali, '==', $tcpar_WL_Faultquali );
		
		#dequalificaiton
		PD_evaluate_faults($flt_mem_struct_ProductionDisable_dequalification{'FaultStatus_afterDeQualification'}, []);		
		S_teststep_detected("Refer traces for the PD fault status", 'PD_FaultStatus_afterDeQualification');
		S_teststep_expected("Fault Recorder should be empty", 'PD_FaultStatus_afterDeQualification');	
					
		CD_evaluate_faults($flt_mem_struct_CustomerDisable_dequalificaiton{'FaultStatus_afterDeQualification'}, []);        
		S_teststep_detected("Refer traces for the PD fault status ", 'CD_FaultStatus_afterDeQualification');
		S_teststep_expected("Fault Recorder should be empty", 'CD_FaultStatus_afterDeQualification');	
		
		S_teststep_detected("Detected Warning lamp status after dequalification : $sysWLAtFltDequali  ", 'WL_status_after_Fault_dequalification');
		S_teststep_expected("Expected Warning lamp status after dequalification: $tcpar_WL_FaultDequali ", 'WL_status_after_Fault_dequalification');
		EVAL_evaluate_value( "System warning lamp status after fault dequalificaiton : ", $sysWLAtFltDequali, '==', $tcpar_WL_FaultDequali );
	}
	elsif($tcpar_Faulthandling eq 'YES')
	{
	
		$detected_PD_status = PD_get_fault_status( $flt_mem_struct_ProductionDisable_qualification{'FaultStatus_afterQualification'}, $tcpar_faultname );        
		S_teststep_detected("Fault Status read by PD: $detected_PD_status ", 'PD_FaultStatus_afterQualification');
		S_teststep_expected("Fault Status read by PD: $tcpar_FaultQualiStatus ", 'PD_FaultStatus_afterQualification');
		PD_check_fault_status($flt_mem_struct_ProductionDisable_qualification{'FaultStatus_afterQualification'}, $tcpar_faultname, $tcpar_FaultQualiStatus);			# Evalute the DTC Status after fault qualification
				
		$detected_CD_status = CD_get_fault_status( $flt_mem_struct_CustomerDisable_qualification{'FaultStatus_afterQualification'}, $tcpar_faultname );        
		S_teststep_detected("Fault Status read by CD: $detected_CD_status ", 'CD_FaultStatus_afterQualification');
		S_teststep_expected("Fault Status read by CD: $tcpar_FaultQualiStatus ", 'CD_FaultStatus_afterQualification');
		CD_check_fault_status($flt_mem_struct_CustomerDisable_qualification{'FaultStatus_afterQualification'}, $tcpar_faultname, $tcpar_FaultQualiStatus);	
		
		S_teststep_detected("Detected Warning lamp status after qualification : $sysWLAtFltQuali  ", 'WL_status_after_Fault_qualification');
		S_teststep_expected("Expected Warning lamp status after qualification: $tcpar_WL_Faultquali ", 'WL_status_after_Fault_qualification');
		EVAL_evaluate_value( "System warning lamp status after fault qualification : ", $sysWLAtFltQuali, '==', $tcpar_WL_Faultquali );
		
		$detected_PD_status = PD_get_fault_status( $flt_mem_struct_ProductionDisable_dequalification{'FaultStatus_afterDeQualification'}, $tcpar_faultname );        
		S_teststep_detected("Fault Status read by PD: $detected_PD_status ", 'PD_FaultStatus_afterDeQualification');
		S_teststep_expected("Fault Status read by PD: $tcpar_FaultDequaliStatus ", 'PD_FaultStatus_afterDeQualification');
		PD_check_fault_status($flt_mem_struct_ProductionDisable_dequalification{'FaultStatus_afterDeQualification'}, $tcpar_faultname, $tcpar_FaultDequaliStatus);			# Evalute the DTC Status after fault qualification
				
		$detected_CD_status = CD_get_fault_status( $flt_mem_struct_CustomerDisable_dequalificaiton{'FaultStatus_afterDeQualification'}, $tcpar_faultname );        
		S_teststep_detected("Fault Status read by CD: $detected_CD_status ", 'CD_FaultStatus_afterDeQualification');
		S_teststep_expected("Fault Status read by CD: $tcpar_FaultDequaliStatus ", 'CD_FaultStatus_afterDeQualification');
		CD_check_fault_status($flt_mem_struct_CustomerDisable_dequalificaiton{'FaultStatus_afterDeQualification'}, $tcpar_faultname, $tcpar_FaultDequaliStatus);	
		
		S_teststep_detected("Detected Warning lamp status after dequalification : $sysWLAtFltDequali  ", 'WL_status_after_Fault_dequalification');
		S_teststep_expected("Expected Warning lamp status after dequalification: $tcpar_WL_FaultDequali ", 'WL_status_after_Fault_dequalification');
		EVAL_evaluate_value( "System warning lamp status after fault dequalificaiton : ", $sysWLAtFltDequali, '==', $tcpar_WL_FaultDequali );
	}	
	
		
	PD_evaluate_faults($flt_mem_struct_Production_erase{'PD_Fault_status_after_Fault_erasure'}, []);        
    S_teststep_detected("Refer traces for the PD fault status ", 'PD_Fault_status_after_Fault_erasure');
	S_teststep_expected("Fault Recorder should be empty", 'PD_Fault_status_after_Fault_erasure');	
				
	CD_evaluate_faults($flt_mem_struct_Customer_erase{'CD_Fault_status_after_Fault_erasure'}, []);        
    S_teststep_detected("Refer traces for the PD fault status ", 'CD_Fault_status_after_Fault_erasure');
	S_teststep_expected("Fault Recorder should be empty", 'CD_Fault_status_after_Fault_erasure');
    	
		
	S_teststep_detected("Detected Warning lamp status after fault erasure : $sysWLAtFlterasure  ", 'WL_status_after_Fault_erasure');
	S_teststep_expected("Expected Warning lamp status after fault erasure: should be zero", 'WL_status_after_Fault_erasure');
	EVAL_evaluate_value( "System warning lamp status after fault erasure : ", $sysWLAtFlterasure, '==', $tcpar_WL_Faulterasure );

	return 1;
}

sub TC_finalization {

	GDCOM_stop_CyclicTesterPresent($TP_handle);
	PD_ClearFaultMemory();
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	return 1;
}


1;
