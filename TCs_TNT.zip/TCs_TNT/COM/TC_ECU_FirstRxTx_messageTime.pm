#### TEST CASE MODULE
package TC_ECU_FirstRxTx_messageTime;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.6 $;
our $HEADER = q$Header: COM/TC_ECU_FirstRxTx_messageTime.pm 1.6 2017/07/30 00:16:52ICT Satish N (RBEI/ESM6) (stn3kor) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_COM_Application
#TS version in DOORS: 4.22
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
use LIFT_can_access;
use LIFT_labcar;
use GENERIC_DCOM;
use LIFT_PD;
use LIFT_CD;
use LIFT_evaluation;
#include further modules here

##################################

our $PURPOSE = "<To test First Rx message recieved (with respect to tool) time after Power up>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_ECU_FirstRxTx_messageTime

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation


I<B<Stimulation and Measurement>>

1. Set ECU Mode <ECU_Mode>

2.  Set the ECU Supply Voltage at <Low_Volt>

 

3. Switch OFF the ECU.

4. Wait till ECU goes to Off State

5. Switch ON the ECU.

6. Mesure the Time  at which first <Message_ID> received by PD tool,Oscilloscope or Canoe after ECU ECU Power ON.

7.  Set the ECU Supply Voltage at <Normal_Volt>

 

8. Switch OFF the ECU.

9. Wait till ECU goes to Off State

10. Switch ON the ECU.

11. Mesure the Time  at which first <Message_ID> received by PD tool,Oscilloscope or Canoe after ECU ECU Power ON.

12.  Set the ECU Supply Voltage at <High_Volt>

 

13. Switch OFF the ECU.

14. Wait till ECU goes to Off State

15. Switch ON the ECU.

16. Mesure the Time at which first <Message_ID> received by PD tool,Oscilloscope or Canoe after ECU ECU Power ON.

17.  Set the ECU Supply Voltage at <Over_Volt>

 

18. Switch OFF the ECU.

19. Wait till ECU goes to Off State

20. Switch ON the ECU.

21. Mesure the Time  at which first <Message_ID> received by PD tool,Oscilloscope or Canoe after ECU ECU Power ON.

Note: Time can be calculated using oscilloscope or CAN Trace


I<B<Evaluation>>

1. 

2.

3.

4.

5.

6. Measuerd time is  less than or equal to <Expected_Time_ms>

7.

8.

9.

10.

11. Measuerd time is  less than or equal to <Expected_Time_ms>

12.

13.

14.

15.

16. Measuerd time is  less than or equal to <Expected_Time_ms>

17.

18.

19.

20.

21. Measuerd time is  less than or equal to <Expected_Time_ms> 


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Tx_Rx' => 
	SCALAR 'purpose' => 
	SCALAR 'ECU_Mode' => 
	SCALAR 'Low_Volt' => 
	SCALAR 'Normal_Volt' => 
	SCALAR 'High_Volt' => 
	SCALAR 'Over_Volt' => 
	SCALAR 'ECU_off_Time_ms' => 
	SCALAR 'Message_ID' => 
	SCALAR 'Expected_Time_ms' => 


=head2 PARAMETER EXAMPLES

	# ---------- Stimulation ------------
	purpose	 = 'To Measure  first RX/TX time after CAN init'
	
	ECU_Mode = '<Test Heading 1>'
	
	Low_Volt = '8'#Volt
	Normal_Volt = '13'#Volt
	High_Volt = '18'#Volt
	Over_Volt = '20'#Volt
	
	ECU_off_Time_ms = '8000' # ms
	
	Message_ID = '<Fetch {Object Heading} {(.*)}>'
	
	Expected_Time_ms = '<Fetch {Init time [ms]}>'
	Tx_Rx = 'Rx'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_ECU_Mode;
my $tcpar_Expected_Time_ms;
my $tcpar_purpose;
my ($TracePath, $MyData, $MyMsgInfo, $MySigInfo, $CycleTime);
my $tcpar_Message;
my $tcpar_Tx_Rx;
my @Initial_powon_time;
my @First_msg_rec_time;
my @Testcondition = ('8','13','18');

################ global parameter declaration ###################
#add any global variables here
my %first_msg_received_time;

###############################################################

sub TC_set_parameters {

	$tcpar_ECU_Mode =  GEN_Read_mandatory_testcase_parameter( 'ECU_Mode' );
	$tcpar_Message =  GEN_Read_mandatory_testcase_parameter( 'Message_ID' );
	$tcpar_Expected_Time_ms =  GEN_Read_mandatory_testcase_parameter( 'Expected_Time_ms' );
	$tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_Tx_Rx = GEN_Read_mandatory_testcase_parameter( 'Tx_Rx' );
	
	 unless( defined $tcpar_ECU_Mode ) {
  		S_w2rep(" -->  Missing optional parameter 'ECU_Mode'. Assuming it as 'NormalMode' \n");
  		$tcpar_ECU_Mode = 'NormalMode';
    };	

	return 1;
}

sub TC_initialization {

		
    S_teststep("Standard_Preparation", 'NO_AUTO_NBR');
    CA_trace_start();	
    GEN_StandardPrepNoFault();
    S_wait_ms(5000);
		
	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Set ECU Mode '$tcpar_ECU_Mode'", 'AUTO_NBR');
	
	if($tcpar_ECU_Mode eq 'Productionmode')
	{
		GEN_setECUMode('PlantMode10_SuppressComFaults');
	}
	elsif($tcpar_ECU_Mode eq 'Idlemode')
	{
		GEN_setECUMode('IdleMode');
	}
	else
	{
		S_w2rep(" No specific handling is required for Normal modes \n");
	}
	
	
	foreach my $condition (@Testcondition)
	{
		S_teststep("Set the ECU Supply Voltage at '$condition'", 'AUTO_NBR');
		LC_SetVoltage($condition);
		S_teststep("Switch OFF the ECU.", 'AUTO_NBR');
		LC_ECU_Off();
		S_teststep("Wait till ECU goes to Off State", 'AUTO_NBR');
		S_wait_ms('TIMER_ECU_OFF');
		CA_trace_start();
		#S_wait_ms (3000);
		S_teststep("Switch ON the ECU.", 'AUTO_NBR');
		LC_ECU_On($condition);
		S_teststep("Mesure the time at which first '$tcpar_Message' received by PD tool,Oscilloscope or Canoe after ECU ECU Power ON.", 'AUTO_NBR', $condition);			#measurement 1
		
		CA_set_EnvVar_value ('Env_Dummy', 1 );	 #Dummy variable
		S_wait_ms (5000);	
		
		$TracePath = GEN_printLink(CA_trace_store(GEN_generateUniqueTraceName())); 
			
		CA_trace_stop();
		
		open(FH,$TracePath) or die "Cant open $!";
		while(<FH>)
		{
			if($_ =~/Env_Dummy/)	#Dummy variable
			{
				@Initial_powon_time = split(/\s+/,$_);
				S_w2rep("Power on timeline $_ ");
				S_w2rep("Power on timeline value $Initial_powon_time[1] ");
				if($tcpar_Tx_Rx eq 'Rx')
				{
					while(my $data = <FH>)
					{
						if($data =~/(\d+\.\d+)\s\d+\s(.*)\s+Rx/) 
						{
							my $value = $2;
							$value=~s/^\s+//;
							$value=~s/\s+$//;
							S_w2rep("reference purpose ID = $value ");
							if($value eq $tcpar_Message)
							{
								S_w2rep("First message received timeline  = $data ");
								@First_msg_rec_time = split(/\s+/,$data);
								S_w2rep("First message received time =  $First_msg_rec_time[1] ");
								last;
							}
						}
					}
				}
				elsif($tcpar_Tx_Rx eq 'Tx')
				{
					while(my $data = <FH>)
					{
						if($data =~/(\d+\.\d+)\s\d+\s(.*)\s+Tx/) 
						{
							my $value = $2;
							$value=~s/^\s+//;
							$value=~s/\s+$//;
							S_w2rep("reference purpose ID = $value ");
							if($value eq $tcpar_Message)
							{
								S_w2rep("First message received timeline  = $data ");
								@First_msg_rec_time = split(/\s+/,$data);
								S_w2rep("First message received time =  $First_msg_rec_time[1] ");
								last;
							}
						}
					}
				}
			}		
		}
		close(FH);
		
		$first_msg_received_time{$condition} = ($First_msg_rec_time[1] - $Initial_powon_time[1])*1000;
		S_w2rep("First message received time after power on is $first_msg_received_time{$condition} milliseconds");
		S_w2rep("Note: Time can be calculated using oscilloscope or CAN Trace",'pink');
	}
	
	return 1;
}

sub TC_evaluation {

	foreach my $condition (@Testcondition)
	{
		S_teststep_detected("Measure time value for the voltage condition $condition is: $first_msg_received_time{$condition}", $condition);
		S_teststep_expected("Measure time value for the voltage condition $condition is $tcpar_Expected_Time_ms", $condition);	
		
		EVAL_evaluate_value ("Measure time value for the voltage condition $condition is", $first_msg_received_time{$condition}, '<=',$tcpar_Expected_Time_ms );
		
	}
	return 1;
}

sub TC_finalization {
	 
	S_w2rep("TC FINALIZATION\n"); 	
	 
	if($tcpar_ECU_Mode eq 'Productionmode')
	{
		GEN_setECUMode('RemovePlantModes');
		S_wait_ms (5000);
	}
	
	if($tcpar_ECU_Mode eq 'Idlemode')
	{
		GEN_setECUMode('RemoveIdleMode');
		S_wait_ms (5000);
	}
	PD_ClearFaultMemory();
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}


1;
