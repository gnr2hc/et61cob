#### TEST CASE MODULE
package TC_COM_Verificationof_MessagFrame;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER = q$Header: COM/TC_COM_Verificationof_MessagFrame.pm 1.1 2017/07/12 12:44:12ICT Satish N (RBEI/ESM6) (stn3kor) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_COM_Application
#TS version in DOORS: 4.16
#-------------------------------------------------------------------------

use LIFT_general;
use INCLUDES_Project;
use LIFT_can_access;
use LIFT_labcar;
use GENERIC_DCOM;
use LIFT_PD;
use LIFT_CD;
use LIFT_evaluation;
use LIFT_vector_cantool;
##################################

our $PURPOSE = "To verify the message frame";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_COM_App_VerificationofPaddingBytes_DLC

=head1 PURPOSE

To veiry the message frame

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Verify the DLC for the Tx messages  <MessageName>

2. Verify the Data frame of the transmitted Tx message "


I<B<Evaluation>>

1. The DLC of the transmitted message <<MessageName> should be <lengthofMessage>

2. The length of the data frame should be <lengthofMessage>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Purpose' => 
	SCALAR 'MessageName' => 
	SCALAR 'lengthofMessage' => 


=head2 PARAMETER EXAMPLES

	Purpose= 'To test the padding of Tx messages and verification DLC of Tx messages'
	
	MessageName= '<Test Heading>'
	lengthofMessage = 'TBD'
	
	#Exmple
	#MessageName= 'Msg_VehicleSpeed'
	#lengthofMessage = '8'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_MessageName;
my $tcpar_lengthofMessage;

################ global parameter declaration ###################
my $messageRef; 
my $obtainedDLC; 
my $obtainedDATA;
my $LengtheofobtainedDATA;

###############################################################

sub TC_set_parameters {

	$tcpar_Purpose =  GEN_Read_mandatory_testcase_parameter( 'Purpose' );
	$tcpar_MessageName =  GEN_Read_mandatory_testcase_parameter( 'MessageName' );
	$tcpar_lengthofMessage =  GEN_Read_mandatory_testcase_parameter( 'lengthofMessage' );
	return 1;
}

sub TC_initialization {

	S_teststep("Standard_Preparation", 'NO_AUTO_NBR');          
    GEN_StandardPrepNoFault();
    S_wait_ms(5000);

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Verify the DLC for the Tx messages  '$tcpar_MessageName'", 'AUTO_NBR', 'verify_the_dlc');			#measurement 1
	
	my $Trace_StoredfilePath = GEN_getTraceNameWithTeststep('verify_the_dlc');
	GDCOM_CA_trace_start();
	S_wait_ms( 'TIMER_ECU_READY' );
	GDCOM_CA_trace_stop($Trace_StoredfilePath);

	$messageRef = CA_trace_get_dataref( $Trace_StoredfilePath, [$tcpar_MessageName] );	
	my @timestamps = keys %$messageRef;
	$obtainedDLC = $messageRef->{ $timestamps[0] }{$tcpar_MessageName}{'DLC'};
	$obtainedDATA = $messageRef->{ $timestamps[0] }{$tcpar_MessageName}{'DATA'};

	S_teststep("Verify the Data frame of the transmitted Tx message '$tcpar_MessageName'", 'AUTO_NBR', 'check_the_value');			#measurement 2
	S_w2rep("The data is $obtainedDATA");	
	my @splitdata = split(' ',$obtainedDATA);	
	$LengtheofobtainedDATA = scalar(@splitdata);	
	S_w2rep("lengtht of the Transmitted Message Frame is : $LengtheofobtainedDATA");

	return 1;
}

sub TC_evaluation {

	S_teststep_expected("The DLC of the transmitted message '$tcpar_MessageName' should be '$tcpar_lengthofMessage'", 'verify_the_dlc');			#evaluation 1
	S_teststep_detected("Detected length of the message ID is $obtainedDLC", 'verify_the_dlc');
	EVAL_evaluate_value( "DLC check for $tcpar_MessageName: ", $obtainedDLC, '==', $tcpar_lengthofMessage );

	S_teststep_expected("Expected length of the Transmitted Message '$tcpar_MessageName' Frame is  should be '$tcpar_lengthofMessage'", 'check_the_value');			#evaluation 1
	S_teststep_detected("Detected length of the message '$tcpar_MessageName' Frame is $LengtheofobtainedDATA", 'check_the_value');
	EVAL_evaluate_value( "DLC check for $tcpar_MessageName: ", $LengtheofobtainedDATA, '==', $tcpar_lengthofMessage );
	
}

sub TC_finalization {
	GDCOM_CA_trace_start();
	S_wait_ms('TIMER_ECU_OFF');
	PD_ClearFaultMemory();
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	return 1;
}


1;
