#### TEST CASE MODULE
package TC_COM_BIT_Identifier;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.3 $;
our $HEADER = q$Header: COM/TC_COM_BIT_Identifier.pm 1.3 2017/07/30 00:16:50ICT Satish N (RBEI/ESM6) (stn3kor) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_COM_Application
#TS version in DOORS: 4.22
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; 
use LIFT_CD_CAN;
use LIFT_can_access;
use LIFT_labcar;
use GENERIC_DCOM;
use LIFT_PD;
use LIFT_CD;
use LIFT_evaluation;
use LIFT_vector_cantool;

##################################

our $PURPOSE = "To Check that all the Tx and Rx messages and diagnotics id's are  using 11 bit identifiers";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_COM_BIT_Identifier

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Check that all the Tx and Rx messages <tcpar_MessageName> and diagnotics id's are  using 11 or 29  bit identifiers.


I<B<Evaluation>>

11 bit Idebtifiers.

1. ECU should responded with  11  bit identifiers are used  for all the Tx and Rx messages

29 bit Idebtifiers.

1. ECU should responded with  29  bit identifiers are used  for all the Tx and Rx messages


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'MessageName' => 
	SCALAR 'Bit_identifier' => 
	SCALAR 'Purpose' => 


=head2 PARAMETER EXAMPLES

	Purpose= 'To test the Supported identifier of Tx and Rx messages'
	MessageName = 'TBD'
	Bit_identifier = 'TBD'
	
	
	#Example :
	#MessageName = 'ESC_VehSpd_GW'
	#Bit_identifier = '0x0B'


=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_MessageName;

################ global parameter declaration ###################
my $obtainedID;
my $ElevenBitIdentfier = '0x0B';
my $TwentynineBitIdentfier = '0x1D';
my $tcpar_Bit_identifier;

###############################################################

sub TC_set_parameters {

	$tcpar_Purpose =  S_read_mandatory_testcase_parameter( 'Purpose' );
	$tcpar_MessageName = S_read_mandatory_testcase_parameter('MessageName');
	$tcpar_Bit_identifier = S_read_mandatory_testcase_parameter('Bit_identifier');
	

	return 1;
}

sub TC_initialization {

	S_teststep("Standard_Preparation", 'NO_AUTO_NBR'); 
	CA_trace_start();
    GEN_StandardPrepNoFault();
    S_wait_ms(5000);

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Check that all the Tx and Rx messages '$tcpar_MessageName' and diagnotics id's are  using 11 bit identifiers.", 'AUTO_NBR', 'Bit_Identifiers');			#measurement 1
	my $Trace_StoredfilePath = GEN_printLink(CA_trace_store(GEN_generateUniqueTraceName()));
	CA_trace_start();
	S_wait_ms('TIMER_ECU_READY');
	CA_trace_stop($Trace_StoredfilePath);
	open(FH,$Trace_StoredfilePath) or die "Cant open $!";
		while(<FH>)
		{			
			if($_ =~m/$tcpar_MessageName.*Tx.*?ID = (\d+)/)
			{
				S_w2rep("detected response $1");				
				$obtainedID = sprintf("0x%X", $1);
				last;
			}		
		}
		close(FH);		
	
	return 1;
}

sub TC_evaluation {

	if( $tcpar_Bit_identifier eq $ElevenBitIdentfier)
	{
	
		S_teststep_expected("ECU should responded with  11  bit identifiers are used  for all the Tx and Rx messages", 'Bit_Identifiers');			#evaluation 1
		S_teststep_detected("Detected identifiers value is $obtainedID", 'Bit_Identifiers');
		if($obtainedID >0x7FF)
		{
			S_set_verdict ('VERDICT_FAIL');
		}
		else
		{
			S_set_verdict ('VERDICT_PASS');
		}
	
	}
	elsif( $tcpar_Bit_identifier eq $TwentynineBitIdentfier)
	{
	
		S_teststep_expected("ECU should responded with  29  bit identifiers are used  for all the Tx and Rx messages", 'Bit_Identifiers');			#evaluation 1
		S_teststep_detected("Detected identifiers value is $obtainedID", 'Bit_Identifiers');
		if($obtainedID <0x1FFFFFFF)
		{
			S_set_verdict ('VERDICT_FAIL');
		}
		else
		{
			S_set_verdict ('VERDICT_PASS');
		}
	
	}

	

	return 1;
}

sub TC_finalization {

	CA_trace_start();
	PD_ClearFaultMemory();
	S_wait_ms(5000);
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}


1;
