#### TEST CASE MODULE
package TC_Tx_InitValues;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.6 $;
our $HEADER = q$Header: COM/TC_Tx_InitValues.pm 1.6 2017/07/30 00:16:51ICT Satish N (RBEI/ESM6) (stn3kor) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_COM_Application
#TS version in DOORS: 4.22
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
use LIFT_can_access;
use LIFT_labcar;
use GENERIC_DCOM;
use LIFT_PD;
use LIFT_CD;
use LIFT_evaluation;

##################################

our $PURPOSE = "<To check the init values of Tx signals under different voltage conditions and different ECU modes>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_Tx_InitValues

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation


I<B<Stimulation and Measurement>>

1. Set ECU Mode <ECU_Mode>

2.  Set the ECU Supply Voltage at <Low_Volt>

 

3. Switch OFF the ECU.

4. Wait till ECU goes to Off State

5. Switch ON the ECU.

6. Check <SigName> transmitted on the bus during init time of the ECU. ( Consider the first message transmitted for init )

7.  Set the ECU Supply Voltage at <Normal_Volt>

 

8. Switch OFF the ECU.

9. Wait till ECU goes to Off State

10. Switch ON the ECU.

11. Check <SigName> transmitted on the bus during init time of the ECU. ( Consider the first message transmitted for init )

12.  Set the ECU Supply Voltage at <High_Volt>

 

13. Switch OFF the ECU.

14. Wait till ECU goes to Off State

15. Switch ON the ECU.

16. Check <SigName> transmitted on the bus during init time of the ECU. ( Consider the first message transmitted for init )

17.  Set the ECU Supply Voltage at <Over_Volt>

 

18. Switch OFF the ECU.

19. Wait till ECU goes to Off State

20. Switch ON the ECU.

21. Check <SigName> transmitted on the bus during init time of the ECU. ( Consider the first message transmitted for init )


I<B<Evaluation>>

1. 

2.

3.

4.

5.

6. The init values of <Message_Signal_Name> recorded as  <Expected_InitValue> respectively during init

7.

8.

9.

10.

11. The init values of <Message_Signal_Name> recorded as  <Expected_InitValue> respectively during init

12.

13.

14.

15.

16. The init values of <Message_Signal_Name> recorded as  <Expected_InitValue> respectively during init

17.

18.

19.

20.

21. The init values of <Message_Signal_Name> recorded as  <Expected_InitValue> respectively during init


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'ECU_Mode' => 
	SCALAR 'Low_Volt' => 
	SCALAR 'Normal_Volt' => 
	SCALAR 'High_Volt' => 
	SCALAR 'Over_Volt' => 
	SCALAR 'Message_Signal_Name' => 
	SCALAR 'Expected_InitValue' => 


=head2 PARAMETER EXAMPLES

	# ---------- Stimulation ------------
	
	purpose	 = 'check Init Values for signal  <Test Heading>'
	
	ECU_Mode = '<Test Heading 1>'
	
	Low_Volt = '8'#Volt
	Normal_Volt = '13'#Volt
	High_Volt = '18'#Volt
	Over_Volt = '20'#Volt
	
	Message_Signal_Name = '<Fetch {Object Heading} {(.*)}>'
	Expected_InitValue = '<Fetch {Tx_signal_bus_init_value}>'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_ECU_Mode;
my $tcpar_Message_Signal_Name;
my $tcpar_Expected_InitValue;
my ($TracePath, $MyMsgInfo, $MySigInfo);
my @Testcondition = ('8','13','18');


################ global parameter declaration ###################
#add any global variables here
my %MyData;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_ECU_Mode =  GEN_Read_optional_testcase_parameter( 'ECU_Mode' );
	$tcpar_Message_Signal_Name = GEN_Read_mandatory_testcase_parameter( 'Message_Signal_Name' );
	$tcpar_Expected_InitValue = GEN_Read_optional_testcase_parameter( 'Expected_InitValue' );
	$MySigInfo = CA_get_can_signal_info($tcpar_Message_Signal_Name); 
	$MyMsgInfo = CA_get_can_message_info($MySigInfo->{'MESSAGE'});
	
	 unless( defined $tcpar_ECU_Mode ) {
  		S_w2rep(" -->  Missing optional parameter 'ECU_Mode'. Assuming it as 'NormalMode' \n");
  		$tcpar_ECU_Mode = 'NormalMode';
    };
	
	return 1;
}

sub TC_initialization {

	S_teststep("Standard_Preparation", 'NO_AUTO_NBR');
	CA_trace_start();
    GEN_StandardPrepNoFault();
    S_wait_ms(5000);

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Set ECU Mode '$tcpar_ECU_Mode'", 'AUTO_NBR');
	if($tcpar_ECU_Mode eq 'Productionmode')
	{
		GEN_setECUMode('PlantMode10_SuppressComFaults');
	}
	elsif($tcpar_ECU_Mode eq 'Idlemode')
	{
		GEN_setECUMode('IdleMode');
	}
	else
	{
		S_w2rep(" No specific handling is required for Normal modes \n");
	}
	

	foreach my $condition (@Testcondition)
	
	{
		S_teststep("Set the ECU Supply Voltage at '$condition'", 'AUTO_NBR');
		LC_SetVoltage($condition);
		S_teststep("Switch OFF the ECU.", 'AUTO_NBR');
		LC_ECU_Off();
		S_teststep("Wait till ECU goes to Off State", 'AUTO_NBR');
		S_wait_ms('TIMER_ECU_OFF');
		CA_trace_start();     
		S_teststep("Switch ON the ECU.", 'AUTO_NBR');
		LC_ECU_On($condition);
		S_wait_ms('TIMER_ECU_READY');
		S_teststep("Check '$tcpar_Message_Signal_Name' transmitted on the bus during init time of the ECU. ( Consider the first message transmitted during init )", 'AUTO_NBR',$condition);			#measurement 1
		$TracePath = GEN_printLink(CA_trace_store(GEN_generateUniqueTraceName())); 
		$MyData{$condition} = CA_trace_get_dataref($TracePath,[$tcpar_Message_Signal_Name]);
		my $current_testcase_name;
        $current_testcase_name =$main::CURRENT_TC;
        $current_testcase_name=~ s/\./-/g; 
		S_dump2pmFile ("VariableToDump" => $MyData{$condition},
                         "VariableName" => "CanTraceData",
                         "PackageName" => "$current_testcase_name\_$condition",
                         "StoragePath" => "$main::REPORT_PATH/");
		
	}
	
	return 1;
}

sub TC_evaluation {

	foreach my $condition (@Testcondition)
	
	{
			
		#evaluation 1
						
		my $PhysicalValue = CA_calc_hex_to_phys($MySigInfo,$tcpar_Expected_InitValue);

		my @SortedTime  = sort {$a <=> $b} (keys (%{$MyData{$condition}}));	
		
		S_teststep_detected("Detected Init value for the voltage condition $condition is: $MyData{$condition}->{$SortedTime[0]}{$tcpar_Message_Signal_Name}", $condition);
		S_teststep_expected("Expected Init value  is $PhysicalValue", $condition);

		EVAL_evaluate_value("Measured init value for the signal name $tcpar_Message_Signal_Name under voltage condition $condition is",$MyData{$condition}->{$SortedTime[0]}{$tcpar_Message_Signal_Name} ,"==",$PhysicalValue);
	}
	return 1;
}

sub TC_finalization {

	S_w2rep("TC FINALIZATION\n");

	if($tcpar_ECU_Mode eq 'Productionmode')
	{
		GEN_setECUMode('RemovePlantModes');
		S_wait_ms (5000);
	}
	
	if($tcpar_ECU_Mode eq 'Idlemode')
	{
		GEN_setECUMode('RemoveIdleMode');
		S_wait_ms (5000);
	}
	
	PD_ClearFaultMemory();
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}


1;
