#### TEST CASE MODULE
package TC_COM_ComunicationControl_During_Autarky;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.3 $;
our $HEADER = q$Header: COM/TC_COM_ComunicationControl_During_Autarky.pm 1.3 2017/07/30 00:16:41ICT Satish N (RBEI/ESM6) (stn3kor) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_COM_Application
#TS version in DOORS: 4.22
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
use LIFT_can_access;
use LIFT_labcar;
use GENERIC_DCOM;
use LIFT_PD;
use LIFT_CD;
use LIFT_evaluation;

##################################

our $PURPOSE = "To check the ECU Diag request and response handling during Autarky period";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_COM_ComunicationControl_During_Autarky

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Send Request to <Enter_Session>

2. Create an Autarky state by switching OFF the ECU

3. During Autarky state, Send the Request <Req_CommCtrl> and check the response with communication type <CommType>


I<B<Evaluation>>

1. Positive response should receive

2.

3. ECU should respond with <Response_Type>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Purpose' => 
	SCALAR 'Req_CommCtrl' => 
	SCALAR 'Response_Type' => 
	SCALAR 'CommType' => 
	SCALAR 'Enter_Session' => 
	SCALAR 'Addressingmode' => 


=head2 PARAMETER EXAMPLES

	Purpose= 'To check the ECU Diag request and response handling during Autarky period'
	
	Response_Type = 'TBD'
	
	CommType = '<Test Heading 2>'
	
	Enter_Session = 'ExtendedSession'
	
	Addressingmode = 'physical'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_Response_Type;
my $tcpar_CommType;
my $tcpar_Addressingmode;
my $tcpar_Enter_Session;

################ global parameter declaration ###################
#add any global variables here


###############################################################

sub TC_set_parameters {

	$tcpar_Purpose =  S_read_mandatory_testcase_parameter( 'Purpose' );
	$tcpar_Response_Type =  S_read_mandatory_testcase_parameter( 'Response_Type' );
	$tcpar_CommType =  S_read_mandatory_testcase_parameter( 'CommType' );
	$tcpar_Addressingmode = S_read_mandatory_testcase_parameter( 'Addressingmode' );
	$tcpar_Enter_Session = S_read_mandatory_testcase_parameter( 'Enter_Session' );
	return 1;
}

sub TC_initialization {

	S_teststep("Standard_Preparation", 'NO_AUTO_NBR');          
    GEN_StandardPrepNoFault();
    S_wait_ms(5000);

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Send Request to '$tcpar_Enter_Session'", 'AUTO_NBR', 'send_request_to_A');			#measurement 1
	GDCOM_set_addressing_mode($tcpar_Addressingmode);
	if( $tcpar_Enter_Session eq 'ExtendedSession')
	{		
		GDCOM_request_general ('REQ_StartSession_ExtendedSession','PR_StartSession_ExtendedSession');
	}
	S_wait_ms(500);
	GDCOM_start_CyclicTesterPresent();

	S_teststep("Create an Autarky state by switching OFF the ECU", 'AUTO_NBR');
	LC_ECU_Off();
	S_wait_ms(150);
	S_teststep("During Autarky state, Send the Request Communication control and check the response with communication type '$tcpar_CommType'", 'AUTO_NBR', 'in_autarky_state');			#measurement 1
	
	if($tcpar_CommType == '0')
	{	
		GDCOM_request_general ('REQ_CommunicationControl_EnableRxAndTx',$tcpar_Response_Type);
	
	}
	elsif($tcpar_CommType eq '1')
	{
		GDCOM_request_general ('REQ_CommunicationControl_EnableRxAndDisableTx',$tcpar_Response_Type);
	
	}
	elsif($tcpar_CommType eq '2')
	{
		GDCOM_request_general ('REQ_CommunicationControl_DisableRxAndEnableTx',$tcpar_Response_Type);
	
	}
	elsif($tcpar_CommType eq '3')
	{
		GDCOM_request_general ('REQ_CommunicationControl_DisableRxAndTx',$tcpar_Response_Type);
	
	}
	return 1;
}

sub TC_evaluation {

	S_teststep_expected("ECU should respond with '$tcpar_Response_Type'", 'in_autarky_state');			#evaluation 1
	S_teststep_detected("Request and Responses handled in stimulation and measurement section, Refer traces", 'in_autarky_state');

	return 1;
}

sub TC_finalization {

	LC_ECU_On();	
	S_wait_ms('TIMER_ECU_READY');
	GDCOM_stop_CyclicTesterPresent();
	PD_ClearFaultMemory();
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}


1;
