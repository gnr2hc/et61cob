#### TEST CASE MODULE
package TC_COM_ComFaultHandlingBusOff;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.3 $;
our $HEADER = q$Header: COM/TC_COM_ComFaultHandlingBusOff.pm 1.3 2017/07/30 00:16:45ICT Satish N (RBEI/ESM6) (stn3kor) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_COM_Application
#TS version in DOORS: 4.22
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
use LIFT_can_access;
use LIFT_labcar;
use GENERIC_DCOM;
use LIFT_PD;
use LIFT_CD;
use LIFT_evaluation;

##################################

our $PURPOSE = "To check the COMM fault handling during busoff";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_COM_ComFaultHandlingBusOff

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Create the CANBusOFF condition by shorting CANH or CANL terminals to Vbat

2. Create <COM_Fault> and wait for Qualificaiton Time

3. Remove <COM_Fault> Faults and wait for Dequalification Time

4. Remove the CANBusOff condition and wait for <BusOffRecoveryTime>

5. Read the fault recorder through PD

6. Read the fault recorder through CD

7. Read the Warning lamp status after fault dequalification


I<B<Evaluation>>

1. 

2. 

3. 

4.

5.  Fault <faultname>   status  should have <FaultDeQualistatus>. Fault memory should have only Bus off fault and no other COM faults

6.  Fault <faultname>   status  should have <FaultDeQualistatus>. Fault memory should have only Bus off fault and no other COM faults

7. Warning lamp <SysWL_SigLabel>  should have  <WL_FaultDequali>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'MessageName' => 
	SCALAR 'faultname' => 
	SCALAR 'SysWLDequaliStatus' => 
	SCALAR 'FaultDequalistatus' => 
	SCALAR 'Purpose' => 
	SCALAR 'COM_Fault' => 
	SCALAR 'BusOffRecoveryTime' => 
	SCALAR 'SysWL_SigLabel' => 
	SCALAR 'Protocol' => 


=head2 PARAMETER EXAMPLES

	Purpose= 'To check the COMM fault handling during busoff'
	
	
	
	COM_Fault= '<Test Heading>'
	BusOffRecoveryTime = 'TBD'
	SysWL_SigLabel = 'TBD'
	Protocol = 'can'
	MessageName = 'TBD'
	faultname = 'TBD'
	SysWLDequaliStatus = 'TBD'
	FaultDequalistatus = 'TBD'
	 

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_COM_Fault;
my $tcpar_faultname;
my $tcpar_FaultDeQualistatus;
my $tcpar_CDFaultDeQualistatus;
my $tcpar_WL_FaultDequali;
my $tcpar_BusOffRecoveryTime;
my $tcpar_CANterminal;
my $tcpar_MessageName;
my $tcpar_NbOfCycles;
my $tcpar_Protocol;
my $tcpar_Method;
my $tcpar_signal;
my $tcpar_physicalValue;

my $tcpar_SysWL_SigLabel;
my $tcpar_BusOffRecoveryTime_ms;
my $tcpar_physicalValueValid;
################ global parameter declaration ###################
my %flt_mem_struct_pd;
my %flt_mem_struct_cd;
my $sysWLAtFltQuali;
my $sysWLAtFltDequali;
my $unit;
my $detected_PD_status;
my $detected_CD_status;
my $InvalidCRCValue = 1;
my $ValidCRCValue = 0;
my $CRCEnVarName;
my $InvalidBZValue = 1;
my $ValidBZValue = 0;
my $BZEnVarName;
my $DequalificationTime;
my $QualificationTime;
my $faultproperty;
###############################################################

sub TC_set_parameters {

	$tcpar_Purpose =  S_read_mandatory_testcase_parameter( 'Purpose' );
	$tcpar_COM_Fault =  S_read_mandatory_testcase_parameter( 'COM_Fault' );
	$tcpar_faultname =  S_read_mandatory_testcase_parameter( 'faultname' );
	$tcpar_FaultDeQualistatus =  S_read_mandatory_testcase_parameter( 'FaultDeQualistatus' );
	$tcpar_CDFaultDeQualistatus =  S_read_mandatory_testcase_parameter( 'CDFaultDeQualistatus' );
	$tcpar_WL_FaultDequali =  S_read_mandatory_testcase_parameter( 'WL_FaultDequali' );
	$tcpar_SysWL_SigLabel = S_read_mandatory_testcase_parameter('SysWL_SigLabel');
	$tcpar_BusOffRecoveryTime =  S_read_mandatory_testcase_parameter( 'BusOffRecoveryTime' );
	$tcpar_CANterminal = S_read_mandatory_testcase_parameter( 'CANterminal' );
	$tcpar_Method = S_read_optional_testcase_parameter( 'Method' ); 
	unless( defined $tcpar_Method ) 
	{
			S_w2rep(" -->  Missing optional parameter 'Method', By default script uses 'Constant' as the method. \n");
			$tcpar_Method = 'Constant';
			
	};
	$tcpar_NbOfCycles = S_read_mandatory_testcase_parameter('NbOfCycles');	
	$tcpar_Protocol = S_read_mandatory_testcase_parameter( 'Protocol' );
	$tcpar_MessageName = S_read_mandatory_testcase_parameter('MessageName');
	$tcpar_signal = S_read_mandatory_testcase_parameter('signal');
	$tcpar_physicalValue = S_read_mandatory_testcase_parameter('physicalValue');
	$tcpar_BusOffRecoveryTime_ms = S_read_mandatory_testcase_parameter('BusOffRecoveryTime_ms');
	$tcpar_physicalValueValid = S_read_mandatory_testcase_parameter('physicalValueValid');
	return 1;
}

sub TC_initialization {

	S_teststep("Standard_Preparation", 'NO_AUTO_NBR');          
    GEN_StandardPrepNoFault();
    S_wait_ms(5000);
	
	my $CAN_Mapping = S_get_contents_of_hash( ['Mapping_CAN'] );	
	$CRCEnVarName = $CAN_Mapping->{'CAN_MESSAGES'}{$tcpar_MessageName}{'CANOE_VALIDCRC'};
	
	$CAN_Mapping = S_get_contents_of_hash( ['Mapping_CAN'] );	
	$BZEnVarName = $CAN_Mapping->{'CAN_MESSAGES'}{$tcpar_MessageName}{'CANOE_VALIDBZ'};
	
	# Fetching of Fault Quali and dequli times from the Fault mapping file
	$faultproperty = FM_fetchFaultInfo($tcpar_faultname);
	
	unless ( keys(%$faultproperty) )
	{                                                     #check if keys are read successfully from mapping file
		S_set_error( "Details are not read successfully from fault mapping file", 10 );    #Error!
		return undef;
	}
	$QualificationTime  = $faultproperty->{'CyclicQualificationtime'};
	$DequalificationTime  = $faultproperty->{'CyclicDequalificationtime'};

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Create the CANBusOFF condition by shorting CANH or CANL terminals to Vbat ", 'AUTO_NBR');
	LC_ShortLines( [$tcpar_CANterminal . "-", 'B+'], 100 );
	S_wait_ms(5000);

	S_teststep("Create '$tcpar_COM_Fault' and wait for Qualificaiton Time", 'AUTO_NBR');
	if($tcpar_COM_Fault eq 'Timeout')
	{
		COM_stopMessages( [$tcpar_MessageName], $tcpar_Protocol );
	}
	elsif($tcpar_COM_Fault eq 'InvalidSignal')
	{
		COM_setSignalState ($tcpar_signal, $tcpar_physicalValue, $tcpar_Protocol);
	}
	elsif($tcpar_COM_Fault eq 'CRC')
	{		
		#CA_set_invalidCRC($tcpar_MessageName,$tcpar_Method);
		CA_set_EnvVar_value ( $CRCEnVarName, $InvalidCRCValue);
	}
	elsif($tcpar_COM_Fault eq 'AliveCntr')
	{
		#CA_set_invalidBZ($tcpar_MessageName,$tcpar_Method,$tcpar_NbOfCycles);
		CA_set_EnvVar_value ( $BZEnVarName, $InvalidBZValue);
	}
	S_wait_ms($QualificationTime);

	S_teststep("Remove '$tcpar_COM_Fault' Faults and wait for Dequalification Time", 'AUTO_NBR');
	if($tcpar_COM_Fault eq 'Timeout')
	{
		COM_startMessages( [$tcpar_MessageName], $tcpar_Protocol );
	}
	elsif($tcpar_COM_Fault eq 'InvalidSignal')
	{
		COM_setSignalState ($tcpar_signal, $tcpar_physicalValueValid, $tcpar_Protocol);
	}
	elsif($tcpar_COM_Fault eq 'CRC')
	{
		#CA_set_validCRC($tcpar_MessageName);
		CA_set_EnvVar_value ( $CRCEnVarName, $ValidCRCValue);
	}
	elsif($tcpar_COM_Fault eq 'AliveCntr')
	{
		#CA_set_validBZ($tcpar_MessageName);
		CA_set_EnvVar_value ( $BZEnVarName, $ValidBZValue);
	}
	S_wait_ms ($DequalificationTime);

	S_teststep("Remove the CANBusOff condition and wait for '$tcpar_BusOffRecoveryTime'", 'AUTO_NBR');
	LC_UndoShortLines();
    S_wait_ms($tcpar_BusOffRecoveryTime_ms);

	S_teststep("Read the fault recorder through PD", 'AUTO_NBR', 'PD_Status_after_dequalification');			#measurement 1
	$flt_mem_struct_pd{'FaultStatus_afterDeQualification'} = PD_ReadFaultMemory();
	S_wait_ms (2000);
	S_teststep("Read the fault recorder through CD", 'AUTO_NBR', 'CD_Status_after_dequalification');	
	$flt_mem_struct_cd{'FaultStatus_afterDeQualification'} = CD_read_DTC('02','08'); 

	S_teststep("Read the Warning lamp status after fault dequalification", 'AUTO_NBR', 'WL_Status_after_dequalification');
    ($sysWLAtFltDequali,$unit) = CA_read_can_signal($tcpar_SysWL_SigLabel, 'hex' ); 

	return 1;
}

sub TC_evaluation {	
	
	$detected_PD_status = PD_get_fault_status( $flt_mem_struct_pd{'FaultStatus_afterDeQualification'}, $tcpar_faultname );        
	S_teststep_detected("Fault Status read by PD: $detected_PD_status ", 'PD_Status_after_dequalification');    
	S_teststep_expected("Fault Status read by PD: $tcpar_FaultDeQualistatus ", 'PD_Status_after_dequalification');    
	PD_check_fault_status($flt_mem_struct_pd{'FaultStatus_afterDeQualification'}, $tcpar_faultname, $tcpar_FaultDeQualistatus);

	$detected_CD_status = CD_get_fault_status($flt_mem_struct_cd{'FaultStatus_afterDeQualification'}, $tcpar_faultname);      
	S_teststep_detected("Fault Status read by CD: $detected_CD_status ", 'CD_Status_after_dequalification');    
	S_teststep_expected("Fault Status read by CD: $tcpar_CDFaultDeQualistatus ", 'CD_Status_after_dequalification');    
	CD_check_fault_status($flt_mem_struct_cd{'FaultStatus_afterDeQualification'}, $tcpar_faultname, $tcpar_CDFaultDeQualistatus);

	S_teststep_detected("Detected Warning lamp status after dequalification : $sysWLAtFltDequali  ", 'WL_Status_after_dequalification');
	S_teststep_expected("Expected Warning lamp status after dequalification: $tcpar_WL_FaultDequali ", 'WL_Status_after_dequalification');
	EVAL_evaluate_value( "System warning lamp status after fault Dequalification : ", $sysWLAtFltDequali, '==', $tcpar_WL_FaultDequali );
	
	return 1;
}

sub TC_finalization {

	return 1;
}


1;
