#### TEST CASE MODULE
package TC_COM_CommunicationHandlingByDiagnosticService;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.4 $;
our $HEADER = q$Header: COM/TC_COM_CommunicationHandlingByDiagnosticService.pm 1.4 2017/08/10 14:00:22ICT Satish N (RBEI/ESM6) (stn3kor) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_COM_Application
#TS version in DOORS: 4.22
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
use LIFT_can_access;
use LIFT_labcar;
use GENERIC_DCOM;
use LIFT_PD;
use LIFT_CD;
use LIFT_evaluation;

##################################

our $PURPOSE = "To Check message transmission/reception status during normal and abnormal volatage condition";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_COM_CommunicationHandlingByDiagnosticService

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation


I<B<Stimulation and Measurement>>

1. Set <Addressing_Mode> for <Protocol>

2. Send Request to <Enter_Session>

3. Set ECU to <Normal_Voltage> volt

4. Send request to <EnableDisable>  

5. Check for all Tx messages which is received by the ECU

6. Check for all Rx messages which is transmitted by the ECU

7. Set ECU to <Abnormal_Voltage> volt

8. Set ECU to <Normal_Voltage> volt and wait for <Transition_Delay> ms 

9. Check for all Tx messages which is received  by the ECU

10. Check for all Rx messages which is transmitted  by the ECU


I<B<Evaluation>>

1.

2. Session entry is successful.

3.

4. Positive Response is obtained  

5 . The transmission of the message should be <TxMessageStatus>

6 . The reception of the message should be <RxMessgeStatus>

7.

8. 

9 . The transmission of the message should be <Normal_TxMessageStatus>

10 . The reception of the message should be <Normal_RxMessgeStatus>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'TxMessageStatus' => 
	SCALAR 'RxMessgeStatus' => 
	SCALAR 'Normal_TxMessageStatus' => 
	SCALAR 'Normal_RxMessgeStatus' => 
	SCALAR 'purpose' => 
	SCALAR 'Enter_Session' => 
	SCALAR 'EnableDisable' => 
	SCALAR 'Normal_Voltage' => 
	SCALAR 'Abnormal_Voltage' => 


=head2 PARAMETER EXAMPLES

	purpose = 'To Check functionality of CommunicationControl service'
	
	Enter_Session =  'ExtendedSession'
	EnableDisable = '<Test Heading 1>'
	Normal_Voltage = '13' # Volt
	Abnormal_Voltage = '<Test Heading 2>'
	TxMessageStatus = 'Disabled'
	RxMessgeStatus = 'Disabled'
	Normal_TxMessageStatus = 'Enabled'
	Normal_RxMessgeStatus = 'Enabled'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Enter_Session;
my $tcpar_EnableDisable;
my $tcpar_Normal_Voltage;
my $tcpar_Low_Voltage;
my $tcpar_High_Voltage;
my $tcpar_Abnormal_Voltage;
my $tcpar_TxMessageStatus;
my $tcpar_RxMessgeStatus;
my $tcpar_Normal_TxMessageStatus;
my $tcpar_Normal_RxMessgeStatus;
my $tcpar_Addressing_Mode;
my @tcpar_RxMessage_Labels;
my @tcpar_TxMessage_Labels;
my $tcpar_Transition_Delay;
my $tcpar_Protocol;


################ global parameter declaration ###################
my @RxmsgNames;
my @TxmsgNames;
my $TxMsgTransmissionStatus;
my $RxMsgTransmissionStatus;
my $TxMsgTransmissionStatus_Abnormal;
my $RxMsgTransmissionStatus_Abnormal;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_Enter_Session =  S_read_mandatory_testcase_parameter( 'Enter_Session' );
	$tcpar_EnableDisable =  S_read_mandatory_testcase_parameter( 'EnableDisable' );
	$tcpar_Normal_Voltage =  S_read_mandatory_testcase_parameter( 'Normal_Voltage' );
	$tcpar_Abnormal_Voltage =  S_read_mandatory_testcase_parameter( 'Abnormal_Voltage' );
	$tcpar_TxMessageStatus =  S_read_mandatory_testcase_parameter( 'TxMessageStatus' );
	$tcpar_RxMessgeStatus =  S_read_mandatory_testcase_parameter( 'RxMessgeStatus' );
	$tcpar_Normal_TxMessageStatus =  S_read_mandatory_testcase_parameter( 'Normal_TxMessageStatus' );
	$tcpar_Normal_RxMessgeStatus =  S_read_mandatory_testcase_parameter( 'Normal_RxMessgeStatus' );
	@tcpar_TxMessage_Labels = S_read_mandatory_testcase_parameter('TxMessage_Labels');
	@tcpar_RxMessage_Labels = S_read_mandatory_testcase_parameter('RxMessage_Labels');
	$tcpar_Addressing_Mode = S_read_mandatory_testcase_parameter('Addressing_Mode');
	$tcpar_Transition_Delay = S_read_mandatory_testcase_parameter('Transition_Delay');
	$tcpar_Protocol = S_read_mandatory_testcase_parameter( 'Protocol' );	
	return 1;
}

sub TC_initialization {

	S_teststep("Standard_Preparation", 'NO_AUTO_NBR');	
    GEN_StandardPrepNoFault();
    S_wait_ms(5000);

	return 1;
}

sub TC_stimulation_and_measurement {

	foreach my $msg (@tcpar_TxMessage_Labels)
	{
		push( @TxmsgNames, COM_fetchMessageByLabel($msg) );
	}
	
	foreach my $msg (@tcpar_RxMessage_Labels)
	{
		push( @RxmsgNames, COM_fetchMessageByLabel($msg) );
	}

	S_teststep("Set addressing mode '$tcpar_Addressing_Mode' for '$tcpar_Protocol' protocol", 'AUTO_NBR');
	GDCOM_set_addressing_mode($tcpar_Addressing_Mode);

	S_teststep("Send Request to '$tcpar_Enter_Session'", 'AUTO_NBR', 'Request_to_enter_Session');			#measurement 1
	if( $tcpar_Enter_Session eq 'ExtendedSession')
	{		
		GDCOM_request_general ('REQ_StartSession_ExtendedSession','PR_StartSession_ExtendedSession');
	}
	S_wait_ms(500);
	GDCOM_start_CyclicTesterPresent();

	S_teststep("Set ECU to '$tcpar_Normal_Voltage' Volts", 'AUTO_NBR');
	LC_SetVoltage($tcpar_Normal_Voltage);

	S_teststep("Send request to '$tcpar_EnableDisable'  ", 'AUTO_NBR', 'Request_Enable_Disable');			#measurement 2	
	
	if($tcpar_EnableDisable eq 'enableRxAndTx')
	{
		GDCOM_request_general('REQ_CommunicationControl_EnableRxAndTx','PR_CommunicationControl_EnableRxAndTx');	
	}
	elsif($tcpar_EnableDisable eq 'disableRxAndTx')
	{
		GDCOM_request_general('REQ_CommunicationControl_DisableRxAndTx','PR_CommunicationControl_DisableRxAndTx');	
		
	}
	elsif($tcpar_EnableDisable eq 'enableRxAndDisableTx')
	{
		GDCOM_request_general('REQ_CommunicationControl_EnableRxAndDisableTx','PR_CommunicationControl_EnableRxAndDisableTx');	
	}
	elsif($tcpar_EnableDisable eq 'disableRxAndEnableTx')
	{
		GDCOM_request_general('REQ_CommunicationControl_DisableRxAndEnableTx','PR_CommunicationControl_DisableRxAndEnableTx');
	
	}

	S_teststep("Check for all Tx messages which is received by the ECU", 'AUTO_NBR', 'Verify_Tx_Messages_before_voltageTransition');			#measurement 3
	S_teststep("Check for all Rx messages which is transmitted by the ECU", 'AUTO_NBR', 'Verify_Rx_Messages_before_voltageTransition');
	my $traceStoredfilePath = GEN_generateUniqueTraceName();
	GEN_printLink($traceStoredfilePath);
	GDCOM_CA_trace_start();
	S_wait_ms( 'TIMER_ECU_READY' );
	GDCOM_CA_trace_stop($traceStoredfilePath);
	$TxMsgTransmissionStatus = COM_checkCommunication( $traceStoredfilePath, @TxmsgNames );	
	$RxMsgTransmissionStatus = COM_checkCommunication( $traceStoredfilePath, @RxmsgNames );
		
	S_teststep("Set ECU to '$tcpar_Abnormal_Voltage' volts", 'AUTO_NBR');
	LC_SetVoltage($tcpar_Abnormal_Voltage);
	S_wait_ms( 'TIMER_ECU_READY' );
	S_teststep("Set ECU to '$tcpar_Normal_Voltage' volts and wait for '$tcpar_Transition_Delay' ms ", 'AUTO_NBR', 'set_ecu_to');			#measurement 4
	LC_SetVoltage($tcpar_Normal_Voltage);
	S_wait_ms($tcpar_Transition_Delay);
	
	S_teststep("Check for all Tx messages which is received by the ECU", 'AUTO_NBR', 'Verify_Tx_Messages_after_voltageTransition');			#measurement 5
	S_teststep("Check for all Rx messages which is transmitted by the ECU", 'AUTO_NBR', 'Verify_Rx_Messages_after_voltageTransition');
	my $traceStoredfilePath = GEN_generateUniqueTraceName();
	GEN_printLink($traceStoredfilePath);
	GDCOM_CA_trace_start();
	S_wait_ms( 'TIMER_ECU_READY' );
	GDCOM_CA_trace_stop($traceStoredfilePath);
	$TxMsgTransmissionStatus_Abnormal = COM_checkCommunication( $traceStoredfilePath, @TxmsgNames );
	$RxMsgTransmissionStatus_Abnormal = COM_checkCommunication( $traceStoredfilePath, @RxmsgNames );
	return 1;
}

sub TC_evaluation {

	S_teststep_expected("Session entry is successful.", 'Request_to_enter_Session');			#evaluation 1
	S_teststep_detected("Refer traces", 'Request_to_enter_Session');

	S_teststep_expected("Positive Response is obtained  ", 'Request_Enable_Disable');			#evaluation 2
	S_teststep_detected("Refer traces", 'Request_Enable_Disable');
	
	if($tcpar_EnableDisable eq 'disableRxAndTx')
	{
	
		S_teststep_expected("The transmission of the message should be '$tcpar_TxMessageStatus'", 'Verify_Tx_Messages_before_voltageTransition');			#evaluation 3
		S_teststep_detected("Detected Message transmisson status is $TxMsgTransmissionStatus ", 'Verify_Tx_Messages_before_voltageTransition');
		if($TxMsgTransmissionStatus eq 'Not Transmitted')
		{
			S_set_verdict ('VERDICT_PASS'); 
		}
		else
		{
			S_set_verdict ('VERDICT_FAIL');
		}		
		
		S_teststep_expected("The reception of the message should be '$tcpar_RxMessgeStatus'", 'Verify_Rx_Messages_before_voltageTransition');			#evaluation 6
		S_teststep_detected("Detected Message reception status is $RxMsgTransmissionStatus", 'Verify_Rx_Messages_before_voltageTransition');
		if($RxMsgTransmissionStatus eq 'Not Transmitted')
		{
			S_set_verdict ('VERDICT_PASS'); 
		}
		else
		{
			S_set_verdict ('VERDICT_FAIL');
		}		
	
	}
	elsif($tcpar_EnableDisable eq 'enableRxAndDisableTx')
	{
	
		S_teststep_expected("The transmission of the message should be '$tcpar_TxMessageStatus'", 'Verify_Tx_Messages_before_voltageTransition');			#evaluation 3
		S_teststep_detected("Detected Message transmisson status is $TxMsgTransmissionStatus ", 'Verify_Tx_Messages_before_voltageTransition');
		if($TxMsgTransmissionStatus eq 'Not Transmitted')
		{
			S_set_verdict ('VERDICT_PASS'); 
		}
		else
		{
			S_set_verdict ('VERDICT_FAIL');
		}		
		
		S_teststep_expected("The reception of the message should be '$tcpar_RxMessgeStatus'", 'Verify_Rx_Messages_before_voltageTransition');			#evaluation 6
		S_teststep_detected("Detected Message reception status is $RxMsgTransmissionStatus", 'Verify_Rx_Messages_before_voltageTransition');
		if($RxMsgTransmissionStatus eq 'Transmitted')
		{
			S_set_verdict ('VERDICT_PASS'); 
		}
		else
		{
			S_set_verdict ('VERDICT_FAIL');
		}		
	
	}
	elsif($tcpar_EnableDisable eq 'disableRxAndEnableTx')
	{
	
		S_teststep_expected("The transmission of the message should be '$tcpar_TxMessageStatus'", 'Verify_Tx_Messages_before_voltageTransition');			#evaluation 3
		S_teststep_detected("Detected Message transmisson status is $TxMsgTransmissionStatus ", 'Verify_Tx_Messages_before_voltageTransition');
		if($TxMsgTransmissionStatus eq 'Transmitted')
		{
			S_set_verdict ('VERDICT_PASS'); 
		}
		else
		{
			S_set_verdict ('VERDICT_FAIL');
		}		
		
		S_teststep_expected("The reception of the message should be '$tcpar_RxMessgeStatus'", 'Verify_Rx_Messages_before_voltageTransition');			#evaluation 6
		S_teststep_detected("Detected Message reception status is $RxMsgTransmissionStatus", 'Verify_Rx_Messages_before_voltageTransition');
		if($RxMsgTransmissionStatus eq 'Not Transmitted')
		{
			S_set_verdict ('VERDICT_PASS'); 
		}
		else
		{
			S_set_verdict ('VERDICT_FAIL');
		}		
	
	}
	elsif($tcpar_EnableDisable eq 'enableRxAndTx')
	{
	
		S_teststep_expected("The transmission of the message should be '$tcpar_TxMessageStatus'", 'Verify_Tx_Messages_before_voltageTransition');			#evaluation 3
		S_teststep_detected("Detected Message transmisson status is $TxMsgTransmissionStatus ", 'Verify_Tx_Messages_before_voltageTransition');
		if($TxMsgTransmissionStatus eq 'Transmitted')
		{
			S_set_verdict ('VERDICT_PASS'); 
		}
		else
		{
			S_set_verdict ('VERDICT_FAIL');
		}		
		
		S_teststep_expected("The reception of the message should be '$tcpar_RxMessgeStatus'", 'Verify_Rx_Messages_before_voltageTransition');			#evaluation 6
		S_teststep_detected("Detected Message reception status is $RxMsgTransmissionStatus", 'Verify_Rx_Messages_before_voltageTransition');
		if($RxMsgTransmissionStatus eq 'Transmitted')
		{
			S_set_verdict ('VERDICT_PASS'); 
		}
		else
		{
			S_set_verdict ('VERDICT_FAIL');
		}		
	
	}
	
	S_teststep_expected("The transmission of the message should be '$tcpar_Normal_TxMessageStatus'  after voltage transition", 'Verify_Tx_Messages_after_voltageTransition');			#evaluation 3
	S_teststep_detected("Detected Message transmisson status is '$TxMsgTransmissionStatus_Abnormal' after voltage transition ", 'Verify_Tx_Messages_after_voltageTransition');
	if($TxMsgTransmissionStatus_Abnormal eq 'Transmitted')
	{
		S_set_verdict ('VERDICT_PASS'); 
	}
	else
	{
		S_set_verdict ('VERDICT_FAIL');
	}		
	
	S_teststep_expected("The reception of the message should be '$tcpar_Normal_RxMessgeStatus'    after voltage transition", 'Verify_Rx_Messages_after_voltageTransition');			#evaluation 3
	S_teststep_detected("Detected Message reception status is '$RxMsgTransmissionStatus_Abnormal' after voltage transition ", 'Verify_Rx_Messages_after_voltageTransition');
	if($RxMsgTransmissionStatus_Abnormal eq 'Transmitted')
	{
		S_set_verdict ('VERDICT_PASS'); 
	}
	else
	{
		S_set_verdict ('VERDICT_FAIL');
	}
		
	
		

	return 1;
}

sub TC_finalization {

	GDCOM_CA_trace_start();
	GDCOM_stop_CyclicTesterPresent();
	PD_ClearFaultMemory();
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	return 1;
}


1;
