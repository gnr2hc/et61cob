#### TEST CASE MODULE
package TC_COM_AliveCounter_Check;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER = q$Header: COM/TC_COM_AliveCounter_Check.pm 1.1 2018/02/05 17:21:17ICT Satish N (RBEI/ESM6) (stn3kor) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#Test specification : TS_COM_Application
#Version : 4.26
#TS path: https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-M-00116340?doors.view=00000006
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
use LIFT_LIN_Access;
use LIFT_flexray_access;
use LIFT_can_access;
use LIFT_labcar;
use GENERIC_DCOM;
use LIFT_PD;
use LIFT_CD;
use LIFT_evaluation;

##################################

our $PURPOSE = "<Check behaviour of N- bit alive counter in Tx and Rx signals>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_COM_AliveCounter_Check

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation


I<B<Stimulation and Measurement>>

1. Set ECU Mode <ECU_Mode> 

2.  Set the ECU Supply Voltage at <VoltageCondition_V> 

3. Switch OFF the ECU.

4. Wait till ECU goes to Off State

5. Switch ON the ECU.

6. Observe the Initial value of alive counter over the protocol <Protocol> on the signal name <SignalName> . 

7. Wait till ECU intialization period completes

8. Monitor the message <MessageName> for <Number_of_cycles> cycles.


I<B<Evaluation>>

1.

2.

3.

4.

5.

6.The Initial value of alive counter <SignalName> is <Init_AliveCounterValue>.

7.

8. The alive counter <SignalName> increments cyclically to  <Max_AliveCounterValue> and then resets to <Min_AliveCounterValue>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'SignalName' => 
	SCALAR 'purpose' => 
	SCALAR 'ECU_Mode' => 
	SCALAR 'VoltageCondition_V' => 
	SCALAR 'Min_AliveCounterValue' => 
	SCALAR 'Max_AliveCounterValue' => 
	SCALAR 'Number_of_cycles' => 
	SCALAR 'Init_AliveCounterValue' => 
	SCALAR 'Protocol' => 


=head2 PARAMETER EXAMPLES

	purpose = 'Check behaviour of N- bit alive counter in Tx and Rx signals'
	#  parameters
	
	ECU_Mode = '<Test Heading 1>'
	VoltageCondition_V = '<Test Heading 2>' # Volt
	Min_AliveCounterValue = '0'
	Max_AliveCounterValue = '15'
	Number_of_cycles = '100'
	Init_AliveCounterValue = '0'
	Protocol = 'flexray'
	SignalName = 'TBD'


=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_ECU_Mode;
my $tcpar_VoltageCondition_V;
my $tcpar_Min_AliveCounterValue;
my $tcpar_Max_AliveCounterValue;
my $tcpar_Init_AliveCounterValue;
my $tcpar_Protocol;
my $tcpar_SignalName;
my $tcpar_StepCount;
################ global parameter declaration ###################
#add any global variables here
my $obtainedInitValue;
my $TracePath;
my $MyData;
my $MySigInfo;

###############################################################

sub TC_set_parameters {
################################################################## Parameters ########################################
	$tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_ECU_Mode =  GEN_Read_mandatory_testcase_parameter( 'ECU_Mode' );
	$tcpar_VoltageCondition_V =  GEN_Read_mandatory_testcase_parameter( 'VoltageCondition_V' );
	$tcpar_Min_AliveCounterValue =  GEN_Read_optional_testcase_parameter('Min_AliveCounterValue ');
	unless( defined $tcpar_Min_AliveCounterValue ) 
	{
		GEN_printComment(" -->  Missing Optional parameter 'MinValue ' , Setting it to value 0.\n");
		$tcpar_Min_AliveCounterValue =0;
	};
	$tcpar_Max_AliveCounterValue =  GEN_Read_mandatory_testcase_parameter( 'Max_AliveCounterValue' );
	$tcpar_Init_AliveCounterValue =  GEN_Read_mandatory_testcase_parameter( 'Init_AliveCounterValue' );
	$tcpar_Protocol =  GEN_Read_mandatory_testcase_parameter( 'Protocol' );
	$tcpar_SignalName =  GEN_Read_mandatory_testcase_parameter( 'SignalName' );
	$tcpar_StepCount = GEN_Read_optional_testcase_parameter('StepCount');
	unless( defined $tcpar_StepCount ) 
	{
		GEN_printComment(" -->  Missing Optional parameter 'StepSize' , Setting it to value 1 .\n");
		$tcpar_StepCount =1;
	};
	
	if ( $tcpar_Protocol eq 'flexray' ) {
		$MySigInfo = FR_get_flxr_signal_info($tcpar_SignalName);
	}

	return 1;
}

sub TC_initialization {
################################################################## Intialization ########################################

	S_teststep( "Standard_Preparation", 'NO_AUTO_NBR' );
	GEN_StandardPrepNoFault();
	S_wait_ms(5000);
	
	return 1;
}

sub TC_stimulation_and_measurement {
################################################################## SET THE DIFFERENT ECU MODE ########################################
	S_teststep( "Set ECU Mode '$tcpar_ECU_Mode'", 'AUTO_NBR' );
	if ( $tcpar_ECU_Mode eq 'Productionmode' ) {
		GEN_setECUMode('PlantMode10_SuppressComFaults');
	}
	elsif ( $tcpar_ECU_Mode eq 'Idlemode' ) {
		GEN_setECUMode('IdleMode');
	}
	else {
		S_w2rep(" No specific handling is required for Normal modes \n");
	}
################################################################## SET THE DIFFERENT ECU MODE ########################################
	S_teststep( "Set the ECU Supply Voltage at '$tcpar_VoltageCondition_V'", 'AUTO_NBR' );
	LC_SetVoltage($tcpar_VoltageCondition_V);

	$TracePath = GEN_printLink(CA_trace_store(GEN_generateUniqueTraceName())); 
	S_teststep( "Switch OFF the ECU.", 'AUTO_NBR' );
	LC_ECU_Off();	

	S_teststep( "Wait till ECU goes to Off State", 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_OFF');
	if ( $tcpar_Protocol eq 'flexray' ) {
			FR_trace_start();
	}
	elsif ( $tcpar_Protocol eq 'lin' ) {
			LIN_trace_start();
	}
	elsif ( $tcpar_Protocol eq 'can' ) {
			CA_trace_start();
	}
	S_wait_ms(5000);

	S_teststep( "Switch ON the ECU.", 'AUTO_NBR' );
	LC_ECU_On($tcpar_VoltageCondition_V);
	
	S_teststep("Wait till ECU intialization period completes", 'AUTO_NBR');
	S_wait_ms('TIMER_ECU_READY');	
	
	if ( $tcpar_Protocol eq 'flexray' ) 
	{
		FR_trace_stop($TracePath);
	}
	elsif ( $tcpar_Protocol eq 'lin' ) {
		LIN_trace_stop($TracePath);
	}
	elsif ( $tcpar_Protocol eq 'can' ) {
		CA_trace_stop($TracePath);
	}	

	S_teststep("Observe the Initial value of alive counter over the protocol '$tcpar_Protocol' on the signal name '$tcpar_SignalName' . ", 'AUTO_NBR', 'Init_value');			#measurement 1
	if ( $tcpar_Protocol eq 'flexray' )
	{
		$TracePath = GEN_printLink(FR_trace_store(GEN_generateUniqueTraceName())); 
		$MyData = FR_trace_get_dataref($TracePath,[$tcpar_SignalName]);
	}
	elsif ( $tcpar_Protocol eq 'lin' )
	{
		$TracePath = GEN_printLink(LIN_trace_store(GEN_generateUniqueTraceName())); 
		$MyData = LIN_trace_get_dataref($TracePath,[$tcpar_SignalName]);
	}
	elsif ( $tcpar_Protocol eq 'can' )
	{
		$TracePath = GEN_printLink(CA_trace_store(GEN_generateUniqueTraceName())); 
		$MyData = CA_trace_get_dataref($TracePath,[$tcpar_SignalName]);
	}	
	my @timestamps = sort { $a <=> $b } ( keys( %{ $MyData } ) );  #@timestamps        = sort keys %$MyData;
	$obtainedInitValue = $MyData->{ $timestamps[0] }{$tcpar_SignalName};	

	S_teststep("Verify the alive counter values for the signal name $tcpar_SignalName ", 'AUTO_NBR', 'Alive_counter');			#measurement 2

	return 1;
}

sub TC_evaluation {
################################################################## Evaluation########################################
	my $PhysicalValue = CA_calc_hex_to_phys($MySigInfo,$tcpar_Init_AliveCounterValue);
	S_teststep_expected("Expected Init value  is $PhysicalValue", 'Init_value');
	S_teststep_detected("Detected Init value for the voltage condition $tcpar_VoltageCondition_V is: $obtainedInitValue", 'Init_value');			
	EVAL_evaluate_value( "Init value check", $obtainedInitValue, '==', $PhysicalValue );	
	
	S_teststep_expected("Evaluate response for Alive counter done at stimulation and measurement(Refer the traces or html report)\n",'Alive_counter');
	S_teststep_detected("Evaluate response for Alive counter done at stimulation and measurement(Refer the traces or html report)\n",'Alive_counter');
	EVAL_evaluate_alive_counter($MyData,$tcpar_SignalName,$tcpar_StepCount,$tcpar_Min_AliveCounterValue,$tcpar_Max_AliveCounterValue);	

	return 1;
}

sub TC_finalization {
S_w2rep("TC FINALIZATION\n");

	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	if ( $tcpar_ECU_Mode eq 'Productionmode' ) {
		GEN_setECUMode('RemovePlantModes');
		S_wait_ms(5000);
	}

	if ( $tcpar_ECU_Mode eq 'Idlemode' ) {
		GEN_setECUMode('RemoveIdleMode');
		S_wait_ms(5000);
	}

	PD_ClearFaultMemory();
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}


1;
