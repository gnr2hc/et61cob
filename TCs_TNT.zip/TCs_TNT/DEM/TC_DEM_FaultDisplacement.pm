#### TEST CASE MODULE
package TC_DEM_FaultDisplacement;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.9 $;
our $HEADER = q$Header: DEM/TC_DEM_FaultDisplacement.pm 1.9 2018/04/16 12:25:57ICT D Souza Deepthi Mariate (RBEI/ESA-PP3) (DDE3KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general;
use LIFT_evaluation;
use LIFT_PD;
use LIFT_labcar;
use LIFT_CANoe;
use LIFT_labcar;
use LIFT_DCOM;
use LIFT_equipment;
use GENERIC_DCOM;
use LIFT_can_access;
use LIFT_FaultMemory;
use INCLUDES_Project;
use File::Basename;
use Data::Dumper;
use FuncLib_SYC_INTERFACE;

use Readonly;

# Maximum fault quali / dequali times
Readonly my $MAX_FAULT_QUALIFICATION_TIME_MS => 12000;
Readonly my $MAX_FAULT_DEQUALIFICATION_TIME_MS => 12000;


##################################

our $PURPOSE = "To check fault overwriting strategy in all the fault memories";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DEM_FaultDisplacement

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Create <number_internal_fault> <internal_faults>

2. Create <number_external_fault_prio2> <external_faults_priority2>

3. Create <number_external_fault_prio3> <external_faults_priority3>

4. Wait for qualification time

5. Read fault memory <fault_memory_type>

6. Remove <nbr_dequali_internal> <internal_faults> in <dequalification_order>

7. Remove <nbr_dequali_ext_prio2><external_faults_priority2> in <dequalification_order>

8. Remove <nbr_dequali_ext_prio3> <external_faults_priority3> in <dequalification_order>

9.Wait for dequalification time and reset ECU if applicable

10.Create <additional_fault>

11. Wait for qualification time

12. Read fault memory <fault_memory_type> and DTC status bits via CD

13.Create <aged_fault>

14.Remove <aged_fault> and perform ECU reset

15.Reset ECU for <aging_threshold>-1 times

16.Read fault memory <fault_memory_type> and DTC status bits via CD

17.Remove all the remaining faults

18.Reset ECU

19.Clear fault memory via PD


I<B<Evaluation>>

1. -

2. -

3. 

4. -

5.  All faults are in qualified state

6. -

7. -

8.

9. -

10. 

11. -

12. If external faults are stored

a.<Displaced_fault> is overwriiten by <additional_fault> in BFM.

b.Bit 3 of <Displaced_fault> is cleared in PFM

c.<additional_fault> is not present in DFM

d.<Displaced_fault> bit status is reported as active but not stored,

<additional_fault> DTC status is stored and active

If external faults are not stored

a.No fault will be overwritten in PFM,BFM,DFM

b.<additional_fault> is not present in BFM

13.

14.

15.

16.If fault is overwrriten in step 12

a.<Additional_fault> is present in PFM, BFM (could not be stored before)

b.<Additional_fault> DTC bit status is reported as stored and active

If fault is not overwrriten in step 12

a.<Displaced_fault> is present in PFM, BFM

b.<Displaced_fault> bit status is reported as stored


I<B<Finalisation>>

Reset/Remove the test condition Qualified in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

    SCALAR 'number_internal_fault' => 
    SCALAR 'number_external_fault_prio2' => 
    SCALAR 'number_external_fault_prio3' => 
    SCALAR 'nbr_dequali_internal' => 
    SCALAR 'nbr_dequali_ext_prio2' => 
    SCALAR 'nbr_dequali_ext_prio3' => 
    SCALAR 'additional_fault' => 
    SCALAR 'aged_fault' => 
    SCALAR 'purpose' => 
    SCALAR 'aging_threshold' => 
    SCALAR 'dequalification_order' => 
    SCALAR 'fault_memory_type' => 


=head2 PARAMETER EXAMPLES

    purpose      = 'To check fault overwriting strategy in all the fault memories.'
    aging_threshold='40'
    dequalification_order='Oldest'
    fault_memory_type='BFM_PFM_DFM'
    #Displaced_fault: This is handled in test script
    number_internal_fault='25'
    number_external_fault_prio2='0'
    number_external_fault_prio3='0'
    nbr_dequali_internal='0'
    nbr_dequali_ext_prio2='0'
    nbr_dequali_ext_prio3='0'
    
    additional_fault='rb_pom_VerVignCoupling_flt'
    aged_fault='rb_swm_UndefinedBLFD_flt'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_aging_threshold;
my $tcpar_dequalification_order;
my $tcpar_fault_memory_type;
my $tcpar_number_internal_fault;
my $tcpar_number_external_fault_prio2;
my $tcpar_number_external_fault_prio3;
my $tcpar_nbr_dequali_internal;
my $tcpar_nbr_dequali_ext_prio2;
my $tcpar_nbr_dequali_ext_prio3;
my $tcpar_additional_fault;
my $tcpar_aged_fault;
my $tcpar_aging_allowed;

################ global parameter declaration ###################

# aging related variables
my ($fault_mem_primary_afterAging,
    $fault_mem_bosch_afterAging,
    $fault_status_CD_aging,
    $expectedFaults_primary_aging,
    $expectedFaults_bosch_aging,
    $expectedFaults_CD_aging);

# overwriting expected related variables
my ($displaced_fault,
    $expectedFaults_bosch_overwriting,
    $expectedFaults_primary_overwriting,
    $expectedFaults_bosch_no_overwriting,
    $expectedFaults_primary_no_overwriting,
    $expected_faultstatus_CD_afterDisplcmt,
    $expected_faultstatus_CD_noDisplcmt,
	$displaced_fault_status);

# overwriting detected related variables
my ($BoschMemorySize,
    $demMaxNumberEventEntryPrimary,
    $DemDisturbanceMemorySize,
    $fault_mem_primary_afterDisplacmt,
    $fault_mem_bosch_afterDisplacmt,
    $faultstatus_CD_afterDisplcmt,
    $priority_additional_fault,
    $fault_overwritten_PFM,
    $fault_overwritten_BFM);

my (@Priority2FaultsQualified, 
	@Priority3FaultsQualified,
	@Priority2FaultsDequalified, 
	@Priority3FaultsDequalified,
	@temp_allfaults_qualified,
    @aging_dequalifiedfaults,
    @AllFaultsQualified,
    @AllFaultsDequalified);

# fault memories after dequalification
my ($fault_mem_primary_afterDequali,
    $fault_mem_bosch_afterDequali,
    $fault_mem_disturbance_afterDequali,
    $expectedFaults_primary_afterDequali,
    $expectedFaults_bosch_afterDequali);

# fault memories after qualification
my ($fault_mem_primary_afterQuali,
    $fault_mem_bosch_afterQuali,
    $fault_mem_disturbance_afterQuali,
    $expectedFaults_primary_afterQuali,
    $expectedFaults_bosch_afterQuali,
    $expectedFaults_disturbance_afterQuali);

# fault presence
my ($faultPresence_primary,
    $faultPresence_bosch,
    $faultPresence_primary_displaced,
    $faultPresence_primary_additional,
    $faultPresence_bosch_displaced,
    $faultPresence_bosch_additional);

# fault presence aging
my ($faultPresence_primary_aging,
    $faultPresence_bosch_aging,
    $faultPresence_primary_aged,
    $faultPresence_bosch_aged,
    $faultPresence_bosch_aged_displaced,
    $faultPresence_primary_aged_displaced,
    $faultPresence_bosch_aged_additional_fault,
    $faultPresence_primary_aged_additional_fault);

###############################################################

sub TC_set_parameters {

    $tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
    $tcpar_aging_threshold =  S_read_mandatory_testcase_parameter( 'aging_threshold' );
    $tcpar_dequalification_order =  S_read_mandatory_testcase_parameter( 'dequalification_order' );
    $tcpar_fault_memory_type =  S_read_mandatory_testcase_parameter( 'fault_memory_type' );
    $tcpar_number_internal_fault =  S_read_mandatory_testcase_parameter( 'number_internal_fault' );
    $tcpar_number_external_fault_prio2 =  S_read_mandatory_testcase_parameter( 'number_external_fault_prio2' );
    $tcpar_number_external_fault_prio3 =  S_read_optional_testcase_parameter( 'number_external_fault_prio3' );
    $tcpar_nbr_dequali_internal =  S_read_mandatory_testcase_parameter( 'nbr_dequali_internal' );
    $tcpar_nbr_dequali_ext_prio2 =  S_read_mandatory_testcase_parameter( 'nbr_dequali_ext_prio2' );
    $tcpar_nbr_dequali_ext_prio3 =  S_read_optional_testcase_parameter( 'nbr_dequali_ext_prio3' );
    $tcpar_additional_fault =  S_read_mandatory_testcase_parameter( 'additional_fault' );
    $tcpar_aging_allowed =  S_read_mandatory_testcase_parameter( 'aging_allowed' );
    if ($tcpar_aging_allowed eq 'true'){
        $tcpar_aged_fault =  S_read_mandatory_testcase_parameter( 'aged_fault' );
    }
    else{
        $tcpar_aged_fault =  S_read_optional_testcase_parameter( 'aged_fault' );
    }
    (my $result,$BoschMemorySize) = SYC_FLT_get_BoschMemorySize();
    ($result,$demMaxNumberEventEntryPrimary) = SYC_FLT_get_DemMaxNumberEventEntryPrimary();
    ($result,$DemDisturbanceMemorySize) = SYC_FLT_get_DemDisturbanceMemorySize();
    return 1;
}

sub TC_initialization {

    S_w2log(1, "Power on ECU");
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

    S_w2log(1, "Initialize CD and start CAN trace");
    GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start ();
    S_w2log(1, "Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);

    S_w2log(1, "Read and evaluate fault memory before stimulation");
    my $faultsBeforeStimulation = LIFT_FaultMemory -> read_fault_memory('Primary');

    my $faultsVerdict = $faultsBeforeStimulation->evaluate_faults({});   #Fault memory must be empty
    return 0 if ($faultsVerdict eq 'VERDICT_FAIL' and (not $main::opt_offline));

    return 1;
}

sub TC_stimulation_and_measurement {
	my (@InternalFaults,
		@Priority2Faults, 
		@Priority3Faults, 
		@Priority1FaultsQualified, 
		@Priority2FaultsQualified, 
		@Priority3FaultsQualified,
		@Priority1FaultsDequalified, 
		@Priority2FaultsDequalified, 
		@Priority3FaultsDequalified); 

    @InternalFaults = @{ $main::ProjectDefaults->{'Mapping_FAULT_extension'}{'PRIORITY1_FAULTS'} };
    my $number_internal_fault_available=scalar(@InternalFaults);
    if ($number_internal_fault_available <$tcpar_number_internal_fault){
        S_set_error ( "Number of prio1 faults($number_internal_fault_available) given in mapping_fault_extension is less than expected number of faults from TS($tcpar_number_internal_fault)");
        return;
    }
    S_teststep("Create '$tcpar_number_internal_fault' internal_faults", 'AUTO_NBR');
    foreach my $faultname (@InternalFaults){
		my $currentNumberOfQualified = @Priority1FaultsQualified;
        last if($currentNumberOfQualified == $tcpar_number_internal_fault);
        FM_createFault($faultname);
        S_wait_ms(1000);
        push(@Priority1FaultsQualified, $faultname);
    }

    @Priority2Faults = @{ $main::ProjectDefaults->{'Mapping_FAULT_extension'}{'PRIORITY2_FAULTS'} };
    my $number_faultprio2_available=scalar(@Priority2Faults);
    if ($number_faultprio2_available <$tcpar_number_external_fault_prio2){
        S_set_error (" Number of prio2 faults($number_faultprio2_available) given in mapping_fault_extension is less than expected number of faults from TS($tcpar_number_internal_fault)");
        return;
    }

    S_teststep("Create '$tcpar_number_external_fault_prio2' priority2_faults", 'AUTO_NBR');
    foreach my $faultname (@Priority2Faults){
		my $currentNumberOfQualified = @Priority2FaultsQualified;
        last if($currentNumberOfQualified == $tcpar_number_external_fault_prio2);
		FM_createFault($faultname);
        S_wait_ms(1000);
        push(@Priority2FaultsQualified, $faultname);
    }

    if (defined $tcpar_number_external_fault_prio3){
        @Priority3Faults = @{ $main::ProjectDefaults->{'Mapping_FAULT_extension'}{'PRIORITY3_FAULTS'} } ;
        my $number_faultprio3_available=scalar(@Priority3Faults);
        if ($number_faultprio3_available <$tcpar_number_external_fault_prio3){
            S_set_error (" Number of prio3 faults($number_faultprio3_available) given in mapping_fault_extension is less than expected number of faults from TS($tcpar_number_internal_fault)");
            return;
        }

        S_teststep("Create '$tcpar_number_external_fault_prio3' priority3_faults", 'AUTO_NBR');

       foreach my $faultname (@Priority3Faults){
            my $currentNumberOfQualified = @Priority3FaultsQualified;
			last if($currentNumberOfQualified == $tcpar_number_external_fault_prio3);
			FM_createFault($faultname);
			S_wait_ms(1000);
			push(@Priority3FaultsQualified, $faultname);
		}
        push(@AllFaultsQualified,@Priority3FaultsQualified)
    }

    push(@AllFaultsQualified,@Priority1FaultsQualified);
    push(@AllFaultsQualified,@Priority2FaultsQualified);

    S_teststep("Wait for qualification time $MAX_FAULT_QUALIFICATION_TIME_MS", 'AUTO_NBR');
    S_wait_ms($MAX_FAULT_QUALIFICATION_TIME_MS);

    S_teststep("Read fault memory 'DFM' after fault qualification", 'AUTO_NBR', 'read_fault_memory_disturbance_quali');
	_Get_expected_disturbanceflts();

    S_teststep("Reset ECU", 'AUTO_NBR');
    _Ecu_reset();

    if ($tcpar_fault_memory_type eq 'BFM_PFM_DFM'){
        S_teststep("Read fault memory 'PFM' after fault qualification", 'AUTO_NBR', 'read_fault_memory_primary_quali'); #measurement 1
        $fault_mem_primary_afterQuali = LIFT_FaultMemory -> read_fault_memory('Primary');
        S_teststep("Read fault memory 'BFM' after fault qualification", 'AUTO_NBR', 'read_fault_memory_bosch_quali');
        $fault_mem_bosch_afterQuali = LIFT_FaultMemory -> read_fault_memory('Bosch');
    }
    elsif ($tcpar_fault_memory_type eq 'BFM'){
        S_teststep("Read fault memory 'BFM' after fault qualification", 'AUTO_NBR', 'read_fault_memory_bosch_quali');
        $fault_mem_bosch_afterQuali = LIFT_FaultMemory -> read_fault_memory('Bosch');
    }
    elsif ($tcpar_fault_memory_type eq 'PFM'){
        S_teststep("Read fault memory PFM' after fault qualification", 'AUTO_NBR', 'read_fault_memory_primary_quali');
        $fault_mem_primary_afterQuali = LIFT_FaultMemory -> read_fault_memory('Primary');
    }
	my $faultNumber=1;
    foreach my $fault (@AllFaultsQualified){
        $expectedFaults_primary_afterQuali-> {'mandatory'} -> {$fault} = {'DecodedStatus' => {'TestFailed' => 1},}if ($faultNumber<=$demMaxNumberEventEntryPrimary);
        $expectedFaults_bosch_afterQuali-> {'mandatory'} -> {$fault} = {'DecodedStatus' => {'TestFailed' => 1},}if ($faultNumber<=$BoschMemorySize);
		$faultNumber++;
   }

    S_teststep("Remove '$tcpar_nbr_dequali_internal' internal_faults in '$tcpar_dequalification_order' dequalification_order", 'AUTO_NBR');

    my $no_flt_qualified= scalar(@Priority1FaultsQualified);
    if ($tcpar_dequalification_order eq 'Oldest'){
        foreach my $fault (@Priority1FaultsQualified){
            my $currentNumberOfDequalified = @Priority1FaultsDequalified;
            last if($currentNumberOfDequalified >= $tcpar_nbr_dequali_internal);
            FM_removeFault($fault);
			S_wait_ms(1000);					
            push(@Priority1FaultsDequalified, $fault);
        }
    }

    if ($tcpar_dequalification_order eq 'MostRecent'){
        foreach my $fault (reverse @Priority1FaultsQualified){
            my $currentNumberOfDequalified = @Priority1FaultsDequalified;
            last if($currentNumberOfDequalified >= $tcpar_nbr_dequali_internal);
            FM_removeFault($fault);
			S_wait_ms(1000);
            push(@Priority1FaultsDequalified, $fault);
        }
    }

    S_teststep("Remove '$tcpar_nbr_dequali_ext_prio2' external_priority2_faults in '$tcpar_dequalification_order' dequalification_order", 'AUTO_NBR');
    $no_flt_qualified= scalar(@Priority2FaultsQualified);
    if ($tcpar_dequalification_order eq 'Oldest'){
        foreach my $fault (@Priority2FaultsQualified){
            my $currentNumberOfDequalified = @Priority2FaultsDequalified;
            last if($currentNumberOfDequalified >= $tcpar_nbr_dequali_ext_prio2);
            FM_removeFault($fault);
			S_wait_ms(1000);
            push(@Priority2FaultsDequalified, $fault);
        }
    }

    if ($tcpar_dequalification_order eq 'MostRecent'){
        foreach my $fault (reverse @Priority2FaultsQualified){
            my $currentNumberOfDequalified = @Priority2FaultsDequalified;
            last if($currentNumberOfDequalified >= $tcpar_nbr_dequali_ext_prio2);
            FM_removeFault($fault);
			S_wait_ms(1000);
            push(@Priority2FaultsDequalified, $fault);
        }
    }

    if (defined $tcpar_nbr_dequali_ext_prio3){
        S_teststep("Remove '$tcpar_nbr_dequali_ext_prio3' external_priority3_faults in '$tcpar_dequalification_order' dequalification_order", 'AUTO_NBR');
        $no_flt_qualified= scalar(@Priority3FaultsQualified);

        if ($tcpar_dequalification_order eq 'Oldest'){
            foreach my $fault (@Priority3FaultsQualified){
	            my $currentNumberOfDequalified = @Priority3FaultsDequalified;
	            last if($currentNumberOfDequalified >= $tcpar_nbr_dequali_ext_prio3);
	            FM_removeFault($fault);
				S_wait_ms(1000);
	            push(@Priority3FaultsDequalified, $fault);
        	}
        }

        if ($tcpar_dequalification_order eq 'MostRecent'){
            foreach my $fault (reverse @Priority3FaultsQualified){
	            my $currentNumberOfDequalified = @Priority3FaultsDequalified;
	            last if($currentNumberOfDequalified >= $tcpar_nbr_dequali_ext_prio3);
	            FM_removeFault($fault);
				S_wait_ms(1000);
	            push(@Priority3FaultsDequalified, $fault);
        	}
        }
        push(@AllFaultsDequalified,@Priority3FaultsDequalified);
		push(@aging_dequalifiedfaults,@Priority3FaultsDequalified);
    }

    push(@AllFaultsDequalified,@Priority1FaultsDequalified);
    push(@AllFaultsDequalified,@Priority2FaultsDequalified);

	push(@aging_dequalifiedfaults,@Priority2FaultsDequalified);


    S_teststep("Wait for dequalification time $MAX_FAULT_DEQUALIFICATION_TIME_MS", 'AUTO_NBR');
    S_wait_ms($MAX_FAULT_DEQUALIFICATION_TIME_MS);

    S_teststep("Reset ECU", 'AUTO_NBR');
    _Ecu_reset();

    if ($tcpar_fault_memory_type eq 'BFM_PFM_DFM'){
        S_teststep("Read fault memory 'PFM' after fault dequalification", 'AUTO_NBR', 'read_fault_memory_primary_dequali');  #measurement 2
        $fault_mem_primary_afterDequali = LIFT_FaultMemory -> read_fault_memory('Primary');
        S_teststep("Read fault memory 'BFM' after fault dequalification", 'AUTO_NBR', 'read_fault_memory_bosch_dequali');
        $fault_mem_bosch_afterDequali = LIFT_FaultMemory -> read_fault_memory('Bosch');

    }
    elsif ($tcpar_fault_memory_type eq 'BFM'){
        S_teststep("Read fault memory '$tcpar_fault_memory_type' after fault dequalification", 'AUTO_NBR', 'read_fault_memory_bosch_dequali');
        $fault_mem_bosch_afterDequali = LIFT_FaultMemory -> read_fault_memory('Bosch');
    }
    elsif ($tcpar_fault_memory_type eq 'PFM'){
        S_teststep("Read fault memory '$tcpar_fault_memory_type' after fault dequalification", 'AUTO_NBR', 'read_fault_memory_primary_dequali');
        $fault_mem_primary_afterDequali = LIFT_FaultMemory -> read_fault_memory('Primary');
    }

    my (@remaining_faults_notdequalified);

    my $hash_of_allfaultsdequalified;
    foreach my $data (@AllFaultsDequalified){
        $hash_of_allfaultsdequalified->{$data} = 1;
    }
    foreach my $flt (@AllFaultsQualified){
        if(not exists $hash_of_allfaultsdequalified->{$flt}){
            push(@remaining_faults_notdequalified, $flt);
        }

    }
    my $no_notdequalified_flts;

    $no_notdequalified_flts=scalar (@remaining_faults_notdequalified);
    if ($no_notdequalified_flts==0){
        @remaining_faults_notdequalified=@AllFaultsQualified;
    }

    $expectedFaults_primary_afterDequali={};
    $expectedFaults_bosch_afterDequali={};
	my $faultNumberDequalified=1;
    foreach my $fault (@AllFaultsDequalified){
        $expectedFaults_primary_afterDequali-> {'mandatory'} -> {$fault} = {'DecodedStatus' => {'TestFailed' => 0},}if ($faultNumberDequalified<=$demMaxNumberEventEntryPrimary);
        $expectedFaults_bosch_afterDequali-> {'mandatory'} -> {$fault} = {'DecodedStatus' => {'TestFailed' => 0},}if ($faultNumberDequalified<=$BoschMemorySize);
		$faultNumberDequalified++;
   }

    foreach my $fault (@remaining_faults_notdequalified){
        $expectedFaults_primary_afterDequali-> {'mandatory'} -> {$fault} = {'DecodedStatus' => {'TestFailed' => 1},}if ($faultNumberDequalified<=$demMaxNumberEventEntryPrimary);
        $expectedFaults_bosch_afterDequali-> {'mandatory'} -> {$fault} = {'DecodedStatus' => {'TestFailed' => 1},}if ($faultNumberDequalified<=$BoschMemorySize);
		$faultNumberDequalified++;
	}


    S_teststep("Create '$tcpar_additional_fault'", 'AUTO_NBR');
    FM_createFault($tcpar_additional_fault);

    S_teststep("Wait for qualification time $MAX_FAULT_QUALIFICATION_TIME_MS", 'AUTO_NBR');
    S_wait_ms($MAX_FAULT_QUALIFICATION_TIME_MS);

    S_teststep("Reset ECU", 'AUTO_NBR');
    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_READY');
    if($tcpar_additional_fault eq 'rb_pom_VbatLow_flt'){
        LC_ECU_On('LowVoltage') ;
        S_wait_ms($MAX_FAULT_QUALIFICATION_TIME_MS);
    }
    elsif($tcpar_additional_fault eq 'rb_pom_VbatHigh_flt'){
        LC_ECU_On('HighVoltage') ;
        S_wait_ms(4000);
    }
    else{
        LC_ECU_On();
        S_wait_ms('TIMER_ECU_READY');
    }

    if ($tcpar_fault_memory_type eq 'BFM_PFM_DFM'){
        S_teststep("Read fault memory 'PFM' after new fault creation", 'AUTO_NBR', 'read_fault_memory_primary_displaced');  #measurement 3
        $fault_mem_primary_afterDisplacmt = LIFT_FaultMemory -> read_fault_memory('Primary');
        S_teststep("Read fault memory 'BFM' after new fault creation", 'AUTO_NBR', 'read_fault_memory_bosch_displaced');
        $fault_mem_bosch_afterDisplacmt = LIFT_FaultMemory -> read_fault_memory('Bosch');
    }
    elsif ($tcpar_fault_memory_type eq 'BFM'){
        S_teststep("Read fault memory 'BFM' after new fault creation", 'AUTO_NBR', 'read_fault_memory_bosch_displaced');
        $fault_mem_bosch_afterDisplacmt = LIFT_FaultMemory -> read_fault_memory('Bosch');
    }
    elsif ($tcpar_fault_memory_type eq 'PFM'){
        S_teststep("Read fault memory 'PFM' after new fault creation", 'AUTO_NBR', 'read_fault_memory_primary_displaced');
        $fault_mem_primary_afterDisplacmt = LIFT_FaultMemory -> read_fault_memory('Primary');
    }

    S_teststep("Read fault status via CD after new fault creation", 'AUTO_NBR', 'read_fault_status_displaced');
    $faultstatus_CD_afterDisplcmt = LIFT_FaultMemory -> read_fault_memory('Customer');

    my $faultproperty = FM_fetchFaultInfo($tcpar_additional_fault);      #get the info from Fault mapping file
    $priority_additional_fault = $faultproperty->{'Faultpriority'};
    if (not defined $priority_additional_fault){
        S_set_error(" priority is not defined for $tcpar_additional_fault in Mapping_fault.pm, hence testcase is aborted");
        return 0;
    }

    $fault_overwritten_BFM=1;
	$fault_overwritten_PFM=1;
	@temp_allfaults_qualified=@AllFaultsQualified;

    _Overwriting_expected_BFM();
	_Overwriting_expected_PFM_CD();

    if ($tcpar_aging_allowed eq 'true'){
		_Aging_fault();
    }

    push (@remaining_faults_notdequalified, $tcpar_additional_fault);
    S_teststep("Remove all the remaining faults", 'AUTO_NBR');
    foreach my $flt (@remaining_faults_notdequalified){
        FM_removeFault($flt);
    }

    S_teststep("Reset ECU", 'AUTO_NBR');
    _Ecu_reset();

    S_teststep("Clear fault memory via PD", 'AUTO_NBR');
    PD_ClearFaultMemory();
    S_wait_ms(10000);

    return 1;
}

sub TC_evaluation {
    
	S_w2rep ("----- Fault evaluation after fault QUALIFICATION -----,'cyan'");

    # ----- Fault evaluation after fault QUALIFICATION -----
    if ($tcpar_fault_memory_type eq 'BFM_PFM_DFM'){
        $fault_mem_primary_afterQuali -> evaluate_faults($expectedFaults_primary_afterQuali,"read_fault_memory_primary_quali");  #evaluation 1 
        $fault_mem_bosch_afterQuali -> evaluate_faults($expectedFaults_bosch_afterQuali,"read_fault_memory_bosch_quali");
    }
    elsif ($tcpar_fault_memory_type eq 'BFM'){
        $fault_mem_bosch_afterQuali -> evaluate_faults($expectedFaults_bosch_afterQuali,"read_fault_memory_bosch_quali");
    }
    elsif ($tcpar_fault_memory_type eq 'PFM'){
        $fault_mem_primary_afterQuali -> evaluate_faults($expectedFaults_primary_afterQuali,"read_fault_memory_primary_quali");
    }

	$fault_mem_disturbance_afterQuali -> evaluate_faults($expectedFaults_disturbance_afterQuali,"read_fault_memory_disturbance_quali");

	S_w2rep ("----- Fault evaluation after fault DEQUALIFICATION -----,'cyan'");
    # ----- Fault evaluation after fault DEQUALIFICATION -----
    if ($tcpar_fault_memory_type eq 'BFM_PFM_DFM'){
        $fault_mem_primary_afterDequali -> evaluate_faults($expectedFaults_primary_afterDequali,"read_fault_memory_primary_dequali");  #evaluation 2
        $fault_mem_bosch_afterDequali -> evaluate_faults($expectedFaults_bosch_afterDequali,"read_fault_memory_bosch_dequali");
    }
    elsif ($tcpar_fault_memory_type eq 'BFM'){
        $fault_mem_bosch_afterDequali -> evaluate_faults($expectedFaults_bosch_afterDequali,"read_fault_memory_bosch_dequali");
    }
    elsif ($tcpar_fault_memory_type eq 'PFM'){
        $fault_mem_primary_afterDequali -> evaluate_faults($expectedFaults_primary_afterDequali,"read_fault_memory_primary_dequali");
    }

    # ----- Fault evaluation after fault DISPLACEMENT -----
	if (($fault_overwritten_PFM ==1) and ($fault_overwritten_BFM==1)){
		$faultPresence_primary = $fault_mem_primary_afterDisplacmt -> check_fault_presence ([$displaced_fault,$tcpar_additional_fault]);
		$faultPresence_primary_displaced = ${$faultPresence_primary}{$displaced_fault};
        $faultPresence_primary_additional = ${$faultPresence_primary}{$tcpar_additional_fault};
		$faultPresence_bosch = $fault_mem_bosch_afterDisplacmt -> check_fault_presence ([$displaced_fault,$tcpar_additional_fault]);
        $faultPresence_bosch_displaced = ${$faultPresence_bosch}{$displaced_fault};
        $faultPresence_bosch_additional = ${$faultPresence_bosch}{$tcpar_additional_fault};
	}
    elsif (($fault_overwritten_PFM ==0) and ($fault_overwritten_BFM==0)){

        $faultPresence_primary = $fault_mem_primary_afterDisplacmt -> check_fault_presence ($tcpar_additional_fault);
        $faultPresence_bosch = $fault_mem_bosch_afterDisplacmt -> check_fault_presence ($tcpar_additional_fault);

    }
    elsif (($fault_overwritten_PFM ==1) and ($fault_overwritten_BFM==0)){
        $faultPresence_primary = $fault_mem_primary_afterDisplacmt -> check_fault_presence ([$displaced_fault,$tcpar_additional_fault]);
		$faultPresence_primary_displaced = ${$faultPresence_primary}{$displaced_fault};
        $faultPresence_primary_additional = ${$faultPresence_primary}{$tcpar_additional_fault};
		$faultPresence_bosch = $fault_mem_bosch_afterDisplacmt -> check_fault_presence ($tcpar_additional_fault);
    }


    S_w2rep ("----- Fault evaluation after fault DISPLACEMENT -----,'cyan'");
    if (($fault_overwritten_PFM ==1) and ($fault_overwritten_BFM==1)){                                                                                                         #evaluation 3

        if ($tcpar_fault_memory_type eq 'BFM_PFM_DFM'){

            $fault_mem_primary_afterDisplacmt -> evaluate_faults($expectedFaults_primary_overwriting,"read_fault_memory_primary_displaced");
            $fault_mem_bosch_afterDisplacmt -> evaluate_faults($expectedFaults_bosch_overwriting,"read_fault_memory_bosch_displaced");
            S_teststep_expected ("$displaced_fault is overwritten by '$tcpar_additional_fault' in primary fault memory", 'read_fault_memory_primary_displaced' );
            S_teststep_detected ("$displaced_fault is '$faultPresence_primary_displaced', $tcpar_additional_fault is '$faultPresence_primary_additional' in primary fault memory", 'read_fault_memory_primary_displaced' );
            if (($faultPresence_primary_displaced eq 'not_present') and ($faultPresence_primary_additional eq 'present'))   {
                S_set_verdict('VERDICT_PASS');
            }
            else{
                S_set_verdict('VERDICT_FAIL');
            }

            S_teststep_expected ("$displaced_fault is overwritten by '$tcpar_additional_fault' in bosch fault memory", 'read_fault_memory_bosch_displaced' );
            S_teststep_detected ("$displaced_fault is '$faultPresence_bosch_displaced', $tcpar_additional_fault is '$faultPresence_bosch_additional' in bosch fault memory", 'read_fault_memory_bosch_displaced' );
            if (($faultPresence_bosch_displaced eq 'not_present') and ($faultPresence_bosch_additional eq 'present'))   {
                S_set_verdict('VERDICT_PASS');
            }
            else{
                S_set_verdict('VERDICT_FAIL');
            }

        }
        elsif ($tcpar_fault_memory_type eq 'BFM'){
            $fault_mem_bosch_afterDisplacmt -> evaluate_faults($expectedFaults_bosch_overwriting,"read_fault_memory_bosch_displaced");
            S_teststep_expected ("$displaced_fault is overwritten by '$tcpar_additional_fault' in bosch fault memory", 'read_fault_memory_bosch_displaced' );
            S_teststep_detected ("$displaced_fault is '$faultPresence_bosch_displaced', $tcpar_additional_fault is '$faultPresence_bosch_additional' in bosch fault memory", 'read_fault_memory_bosch_displaced' );
            if (($faultPresence_bosch_displaced eq 'not_present') and ($faultPresence_bosch_additional eq 'present'))   {
                S_set_verdict('VERDICT_PASS');
            }
            else{
                S_set_verdict('VERDICT_FAIL');
            }

        }
        elsif ($tcpar_fault_memory_type eq 'PFM'){
            $fault_mem_primary_afterDisplacmt -> evaluate_faults($expectedFaults_primary_overwriting,"read_fault_memory_primary_displaced");
            S_teststep_expected ("$displaced_fault is overwritten by '$tcpar_additional_fault' in primary fault memory", 'read_fault_memory_primary_displaced' );
            S_teststep_detected ("$displaced_fault is '$faultPresence_primary_displaced', $tcpar_additional_fault is '$faultPresence_primary_additional' in primary fault memory", 'read_fault_memory_primary_displaced' );
            if (($faultPresence_primary_displaced eq 'not_present') and ($faultPresence_primary_additional eq 'present'))   {
                S_set_verdict('VERDICT_PASS');
            }
            else{
                S_set_verdict('VERDICT_FAIL');
            }
        }

        $faultstatus_CD_afterDisplcmt -> evaluate_faults($expected_faultstatus_CD_afterDisplcmt,"read_fault_status_displaced");

    }
    elsif(($fault_overwritten_PFM ==0) and ($fault_overwritten_BFM==0)) {

        if ($tcpar_fault_memory_type eq 'BFM_PFM_DFM'){

            $fault_mem_primary_afterDisplacmt -> evaluate_faults($expectedFaults_primary_no_overwriting,"read_fault_memory_primary_displaced");
            $fault_mem_bosch_afterDisplacmt -> evaluate_faults($expectedFaults_bosch_no_overwriting,"read_fault_memory_bosch_displaced");
            S_teststep_expected ("No overwriting in primary fault memory", 'read_fault_memory_primary_displaced' );
            S_teststep_detected ("$tcpar_additional_fault is '$faultPresence_primary' in primary fault memory", 'read_fault_memory_primary_displaced' );
            S_set_verdict('VERDICT_PASS') if ($faultPresence_primary eq 'not_present');
            S_set_verdict('VERDICT_FAIL') if ($faultPresence_primary eq 'present');
            S_teststep_expected ("No overwriting in bosch fault memory", 'read_fault_memory_bosch_displaced' );
            S_teststep_detected ("$tcpar_additional_fault is '$faultPresence_bosch' in bosch fault memory", 'read_fault_memory_bosch_displaced' );
            S_set_verdict('VERDICT_PASS') if ($faultPresence_bosch eq 'not_present');
            S_set_verdict('VERDICT_FAIL') if ($faultPresence_bosch eq 'present');
        }
        elsif ($tcpar_fault_memory_type eq 'BFM'){
            $fault_mem_bosch_afterDisplacmt -> evaluate_faults($expectedFaults_bosch_no_overwriting,"read_fault_memory_bosch_displaced");
            S_teststep_expected ("No overwriting in bosch fault memory", 'read_fault_memory_bosch_displaced' );
            S_teststep_detected ("$tcpar_additional_fault is '$faultPresence_bosch' in bosch fault memory", 'read_fault_memory_bosch_displaced' );
            S_set_verdict('VERDICT_PASS') if ($faultPresence_bosch eq 'not_present');
            S_set_verdict('VERDICT_FAIL') if ($faultPresence_bosch eq 'present');
        }
        elsif ($tcpar_fault_memory_type eq 'PFM'){
            $fault_mem_primary_afterDisplacmt -> evaluate_faults($expectedFaults_primary_no_overwriting,"read_fault_memory_primary_displaced");
            S_teststep_expected ("No overwriting in primary fault memory", 'read_fault_memory_primary_displaced' );
            S_teststep_detected ("$tcpar_additional_fault is '$faultPresence_primary'  in primary fault memory", 'read_fault_memory_primary_displaced' );
            S_set_verdict('VERDICT_PASS') if ($faultPresence_primary eq 'not_present');
            S_set_verdict('VERDICT_FAIL') if ($faultPresence_primary eq 'present');
        }

        $faultstatus_CD_afterDisplcmt -> evaluate_faults($expected_faultstatus_CD_noDisplcmt,"read_fault_status_displaced");

    }
	elsif(($fault_overwritten_PFM ==1) and ($fault_overwritten_BFM==0)){
		 if ($tcpar_fault_memory_type eq 'BFM_PFM_DFM'){

            $fault_mem_primary_afterDisplacmt -> evaluate_faults($expectedFaults_primary_overwriting,"read_fault_memory_primary_displaced");
            $fault_mem_bosch_afterDisplacmt -> evaluate_faults($expectedFaults_bosch_no_overwriting,"read_fault_memory_bosch_displaced");
            S_teststep_expected ("$displaced_fault is overwritten by '$tcpar_additional_fault' in primary fault memory", 'read_fault_memory_primary_displaced' );
            S_teststep_detected ("$displaced_fault is '$faultPresence_primary_displaced', $tcpar_additional_fault is '$faultPresence_primary_additional' in primary fault memory", 'read_fault_memory_primary_displaced' );
            if (($faultPresence_primary_displaced eq 'not_present') and ($faultPresence_primary_additional eq 'present'))   {
                S_set_verdict('VERDICT_PASS');
            }
            else{
                S_set_verdict('VERDICT_FAIL');
            }
            S_teststep_expected ("No overwriting in bosch fault memory", 'read_fault_memory_bosch_displaced' );
            S_teststep_detected ("$tcpar_additional_fault is '$faultPresence_bosch' in bosch fault memory", 'read_fault_memory_bosch_displaced' );
            S_set_verdict('VERDICT_PASS') if ($faultPresence_bosch eq 'not_present');
            S_set_verdict('VERDICT_FAIL') if ($faultPresence_bosch eq 'present');
        }
        elsif ($tcpar_fault_memory_type eq 'BFM'){
            $fault_mem_bosch_afterDisplacmt -> evaluate_faults($expectedFaults_bosch_no_overwriting,"read_fault_memory_bosch_displaced");
            S_teststep_expected ("No overwriting in bosch fault memory", 'read_fault_memory_bosch_displaced' );
            S_teststep_detected ("$tcpar_additional_fault is '$faultPresence_bosch' in bosch fault memory", 'read_fault_memory_bosch_displaced' );
            S_set_verdict('VERDICT_PASS') if ($faultPresence_bosch eq 'not_present');
            S_set_verdict('VERDICT_FAIL') if ($faultPresence_bosch eq 'present');
        }
        elsif ($tcpar_fault_memory_type eq 'PFM'){
            $fault_mem_primary_afterDisplacmt -> evaluate_faults($expectedFaults_primary_overwriting,"read_fault_memory_primary_displaced");
           S_teststep_expected ("$displaced_fault is overwritten by '$tcpar_additional_fault' in primary fault memory", 'read_fault_memory_primary_displaced' );
            S_teststep_detected ("$displaced_fault is '$faultPresence_primary_displaced', $tcpar_additional_fault is '$faultPresence_primary_additional' in primary fault memory", 'read_fault_memory_primary_displaced' );
            if (($faultPresence_primary_displaced eq 'not_present') and ($faultPresence_primary_additional eq 'present'))   {
                S_set_verdict('VERDICT_PASS');
            }
            else{
                S_set_verdict('VERDICT_FAIL');
            }
        }

        $faultstatus_CD_afterDisplcmt -> evaluate_faults($expected_faultstatus_CD_afterDisplcmt,"read_fault_status_displaced");
	}

	S_w2rep ("----- Fault evaluation after fault AGING -----,'cyan'");
    # ----- Fault evaluation after fault AGING -----
    if ($tcpar_aging_allowed eq 'true'){
        _Aging_evaulation();
    }


    return 1;
}

sub TC_finalization {

    # Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(10000);

    # Read fault memory after clearing and erasing EDR
    PD_ReadFaultMemory();
    S_wait_ms(2000);

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

    return 1;
}

sub _Ecu_reset{

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');
    LC_ECU_On() ;
    S_wait_ms('TIMER_ECU_READY');
    return 1;
}

sub _Get_expected_disturbanceflts{

	$fault_mem_disturbance_afterQuali = LIFT_FaultMemory -> read_fault_memory('Disturbance');
	my $fault_properties = {"DecodedStatus" => {'TestDisturbed' => 1}};
	my $found_entries =$fault_mem_disturbance_afterQuali -> get_faults_with_properties($fault_properties);

	my $numberOfEntriesFound = @{$found_entries};

	foreach my $fltIndex (1..$numberOfEntriesFound){
		my $faultName = $found_entries -> [$fltIndex-1] -> FaultName;
		$expectedFaults_disturbance_afterQuali-> {'mandatory'} -> {$faultName} = {'DecodedStatus' => {'TestDisturbed' => 1},};
	}

	foreach my $fltIndex (1..$DemDisturbanceMemorySize - $numberOfEntriesFound ){
		my $faultName = $AllFaultsQualified [$fltIndex-1];
		$expectedFaults_disturbance_afterQuali-> {'mandatory'} -> {$faultName} = {'DecodedStatus' => {'TestCurrent' => 1},};
	}

    return 1;

}


sub _Overwriting_expected_BFM{

	if ($priority_additional_fault ==1){
		S_w2rep (" new fault '$tcpar_additional_fault' has priority $priority_additional_fault");
		if ((defined  $tcpar_number_external_fault_prio3) and $tcpar_number_external_fault_prio3>=1){
			S_w2rep (" External faults of prio 3 are stored in fault memory, hence there is overwriting");

			if ($tcpar_nbr_dequali_ext_prio3>=1){
				S_w2rep (" External faults of prio 3 are stored in dequalified state in fault memory");
				$displaced_fault_status='dequalified';
				$displaced_fault=$Priority3FaultsDequalified[0] if($tcpar_dequalification_order eq 'Oldest');
				$displaced_fault=$Priority3FaultsDequalified[$tcpar_nbr_dequali_ext_prio3-1] if($tcpar_dequalification_order eq 'MostRecent');
			}
			else {
				$displaced_fault_status='qualified';
				$displaced_fault=$Priority3FaultsQualified[0];
			}

			S_w2rep("displaced fault in BFM,PFM=$displaced_fault");

			$expectedFaults_bosch_overwriting -> {'mandatory'} -> {$tcpar_additional_fault} = {'DecodedStatus' => {'TestFailed' => 1},};
			$expectedFaults_primary_overwriting -> {'mandatory'} -> {$tcpar_additional_fault} = {'DecodedStatus' => {'ConfirmedDTC' => 1},};

			$expected_faultstatus_CD_afterDisplcmt-> {'mandatory'} -> {$displaced_fault} = {'DecodedStatus' => {'ConfirmedDTC' => 0},};
			$expected_faultstatus_CD_afterDisplcmt-> {'mandatory'} -> {$tcpar_additional_fault} = {'DecodedStatus' => {'ConfirmedDTC' => 1,'TestFailed' => 1},};


			my $array_index = 0;
			$array_index++ until $AllFaultsQualified[$array_index] eq $displaced_fault;
			splice(@AllFaultsQualified, $array_index, 1);

			foreach my $fault (@AllFaultsQualified){
				$expectedFaults_primary_overwriting-> {'mandatory'} -> {$fault} = {'DecodedStatus' => {'ConfirmedDTC' => 1},};
				$expectedFaults_bosch_overwriting-> {'mandatory'} -> {$fault} = {};
				$expected_faultstatus_CD_afterDisplcmt-> {'mandatory'} -> {$fault} = {'DecodedStatus' => {'ConfirmedDTC' => 1},};
			}

		}
		elsif ($tcpar_number_external_fault_prio2>=1){
			S_w2rep (" External faults of prio 2 are stored in fault memory,hence there is overwriting");
			if ($tcpar_nbr_dequali_ext_prio2>=1){
				S_w2rep (" External faults of prio 2 are stored in dequalified state in fault memory");
				$displaced_fault_status='dequalified';
				$displaced_fault=$Priority2FaultsDequalified[0] if($tcpar_dequalification_order eq 'Oldest');
				$displaced_fault=$Priority2FaultsDequalified[$tcpar_nbr_dequali_ext_prio2-1] if($tcpar_dequalification_order eq 'MostRecent');
			}
			else {
					$displaced_fault=$Priority2FaultsQualified[0];
					$displaced_fault_status='qualified';
			}
			S_w2rep("displaced fault in BFM,PFM=$displaced_fault");

			$expectedFaults_bosch_overwriting -> {'mandatory'} -> {$tcpar_additional_fault} = {'DecodedStatus' => {'TestFailed' => 1},};
			$expectedFaults_primary_overwriting -> {'mandatory'} -> {$tcpar_additional_fault} = {'DecodedStatus' => {'ConfirmedDTC' => 1},};

			$expected_faultstatus_CD_afterDisplcmt-> {'mandatory'} -> {$displaced_fault} = {'DecodedStatus' => {'ConfirmedDTC' => 0},};
			$expected_faultstatus_CD_afterDisplcmt-> {'mandatory'} -> {$tcpar_additional_fault} = {'DecodedStatus' => {'ConfirmedDTC' => 1,'TestFailed' => 1},};


			my $array_index = 0;
			$array_index++ until $AllFaultsQualified[$array_index] eq $displaced_fault;
			splice(@AllFaultsQualified, $array_index, 1);

			
			foreach my $fault (@AllFaultsQualified){
				$expectedFaults_primary_overwriting-> {'mandatory'} -> {$fault} = {'DecodedStatus' => {'ConfirmedDTC' => 1},};
				$expectedFaults_bosch_overwriting-> {'mandatory'} -> {$fault} = {};
				$expected_faultstatus_CD_afterDisplcmt-> {'mandatory'} -> {$fault} = {'DecodedStatus' => {'ConfirmedDTC' => 1},};

			}
		}

		else {
			S_w2rep (" External faults are NOT stored in fault memory, hence no overwriting");
			$expected_faultstatus_CD_noDisplcmt-> {'mandatory'} -> {$tcpar_additional_fault} = {'DecodedStatus' => {'ConfirmedDTC' => 0,'TestFailed' => 1},};
			$fault_overwritten_BFM=0;
			
			foreach my $fault (@AllFaultsQualified){
				$expectedFaults_primary_no_overwriting-> {'mandatory'} -> {$fault} = {'DecodedStatus' => {'ConfirmedDTC' => 1},};
				$expectedFaults_bosch_no_overwriting-> {'mandatory'} -> {$fault} = {};
				$expected_faultstatus_CD_noDisplcmt-> {'mandatory'} -> {$fault} = {'DecodedStatus' => {'ConfirmedDTC' => 1},};
				
			}
		}

	}
	else {
		S_w2rep ("BFM: new fault '$tcpar_additional_fault' has priority $priority_additional_fault, hence no overwriting in BOSCH fault memory");

		foreach my $fault (@AllFaultsQualified){
			$expectedFaults_bosch_no_overwriting-> {'mandatory'} -> {$fault} = {};
			
		}
			$fault_overwritten_BFM=0;
	}

	return 1;

}

sub _Overwriting_expected_PFM_CD{

	return 1 unless($priority_additional_fault >1);

	if ((defined  $tcpar_number_external_fault_prio3) and $tcpar_number_external_fault_prio3>=1){
		 S_w2rep (" External faults of prio 3 are stored in fault memory, hence there is overwriting in primary fault memory");

		if ($tcpar_nbr_dequali_ext_prio3>=1){
			S_w2rep (" External faults of prio 3 are stored in dequalified state in fault memory");
			$displaced_fault_status='dequalified';
			$displaced_fault=$Priority3FaultsDequalified[0] if($tcpar_dequalification_order eq 'Oldest');
			$displaced_fault=$Priority3FaultsDequalified[$tcpar_nbr_dequali_ext_prio3-1] if($tcpar_dequalification_order eq 'MostRecent');
			S_w2rep("displaced fault in PFM=$displaced_fault");
			$expectedFaults_primary_overwriting -> {'mandatory'} -> {$tcpar_additional_fault} = {'DecodedStatus' => {'ConfirmedDTC' => 1},};
			$expected_faultstatus_CD_afterDisplcmt-> {'mandatory'} -> {$displaced_fault} = {'DecodedStatus' => {'ConfirmedDTC' => 0},};
			$expected_faultstatus_CD_afterDisplcmt-> {'mandatory'} -> {$tcpar_additional_fault} = {'DecodedStatus' => {'ConfirmedDTC' => 1,'TestFailed' => 1},};
		}
		else {
		   if($priority_additional_fault==2){
				S_w2rep (" External faults of prio 3 are stored in qualified state in primary fault memory, hence there is overwriting in primary fault memory");
				$displaced_fault=$Priority3FaultsQualified[0];
				$displaced_fault_status='qualified';
				S_w2rep("displaced fault in PFM=$displaced_fault");
				$expectedFaults_primary_overwriting -> {'mandatory'} -> {$tcpar_additional_fault} = {'DecodedStatus' => {'ConfirmedDTC' => 1},};
				$expected_faultstatus_CD_afterDisplcmt-> {'mandatory'} -> {$displaced_fault} = {'DecodedStatus' => {'ConfirmedDTC' => 0},};
				$expected_faultstatus_CD_afterDisplcmt-> {'mandatory'} -> {$tcpar_additional_fault} = {'DecodedStatus' => {'ConfirmedDTC' => 1,'TestFailed' => 1},};

			}
			elsif($priority_additional_fault==3) {
				S_w2rep (" External faults of prio 3 are stored in qualified state in primary fault memory, hence there is NO overwriting in primary fault memory");
				$fault_overwritten_PFM=0;
				$expected_faultstatus_CD_noDisplcmt-> {'mandatory'} -> {$tcpar_additional_fault} = {'DecodedStatus' => {'ConfirmedDTC' => 0,'TestFailed' => 1},};
				foreach my $fault (@temp_allfaults_qualified){
					$expectedFaults_primary_no_overwriting-> {'mandatory'} -> {$fault} = {'DecodedStatus' => {'ConfirmedDTC' => 1},};
					$expected_faultstatus_CD_noDisplcmt-> {'mandatory'} -> {$fault} = {'DecodedStatus' => {'ConfirmedDTC' => 1},};
				}
			}
		}

		if (defined $displaced_fault ){
			my $array_index = 0;
			$array_index++ until $AllFaultsQualified[$array_index] eq $displaced_fault;
			splice(@temp_allfaults_qualified, $array_index, 1);
		}

		foreach my $fault (@temp_allfaults_qualified){
			$expectedFaults_primary_overwriting-> {'mandatory'} -> {$fault} = {'DecodedStatus' => {'ConfirmedDTC' => 1},};
			$expected_faultstatus_CD_afterDisplcmt-> {'mandatory'} -> {$fault} = {'DecodedStatus' => {'ConfirmedDTC' => 1},};
		}

	}
	elsif ($tcpar_number_external_fault_prio2>=1){
		S_w2rep (" External faults of prio 2 are stored in primary fault memory");
		if ($tcpar_nbr_dequali_ext_prio2>=1){
			S_w2rep (" External faults of prio 2 are stored in dequalified state in fault memory");
			$displaced_fault_status='dequalified';
			$displaced_fault=$Priority2FaultsDequalified[0] if($tcpar_dequalification_order eq 'Oldest');
			$displaced_fault=$Priority2FaultsDequalified[$tcpar_nbr_dequali_ext_prio2-1] if($tcpar_dequalification_order eq 'MostRecent');
			S_w2rep("displaced fault in PFM=$displaced_fault");
			$expectedFaults_primary_overwriting -> {'mandatory'} -> {$tcpar_additional_fault} = {'DecodedStatus' => {'ConfirmedDTC' => 1},};
			$expected_faultstatus_CD_afterDisplcmt-> {'mandatory'} -> {$displaced_fault} = {'DecodedStatus' => {'ConfirmedDTC' => 0},};
			$expected_faultstatus_CD_afterDisplcmt-> {'mandatory'} -> {$tcpar_additional_fault} = {'DecodedStatus' => {'ConfirmedDTC' => 1,'TestFailed' => 1},};
		}
		else {
			if($priority_additional_fault==2){
				S_w2rep (" External faults of prio 3 are stored in qualified state in primary fault memory, hence there is overwriting in primary fault memory");
				$displaced_fault=$Priority2FaultsQualified[0];
				$displaced_fault_status='qualified';
				S_w2rep("displaced fault in PFM=$displaced_fault");
				$expectedFaults_primary_overwriting -> {'mandatory'} -> {$tcpar_additional_fault} = {'DecodedStatus' => {'ConfirmedDTC' => 1},};
				$expected_faultstatus_CD_afterDisplcmt-> {'mandatory'} -> {$displaced_fault} = {'DecodedStatus' => {'ConfirmedDTC' => 0},};
				$expected_faultstatus_CD_afterDisplcmt-> {'mandatory'} -> {$tcpar_additional_fault} = {'DecodedStatus' => {'ConfirmedDTC' => 1,'TestFailed' => 1},};

			}
			elsif($priority_additional_fault==3) {
				S_w2rep (" External faults of prio 3 are stored in qualified state in primary fault memory, hence there is NO overwriting in primary fault memory");
				$fault_overwritten_PFM=0;
				$expected_faultstatus_CD_noDisplcmt-> {'mandatory'} -> {$tcpar_additional_fault} = {'DecodedStatus' => {'ConfirmedDTC' => 0,'TestFailed' => 1},};
				foreach my $fault (@temp_allfaults_qualified){
					$expectedFaults_primary_no_overwriting-> {'mandatory'} -> {$fault} = {'DecodedStatus' => {'ConfirmedDTC' => 1},};
					$expected_faultstatus_CD_noDisplcmt-> {'mandatory'} -> {$fault} = {'DecodedStatus' => {'ConfirmedDTC' => 1},};
				}
			}
		}

		if (defined $displaced_fault ){
			my $array_index = 0;
			$array_index++ until $AllFaultsQualified[$array_index] eq $displaced_fault;
			splice(@temp_allfaults_qualified, $array_index, 1);
		}

		foreach my $fault (@temp_allfaults_qualified){
			$expectedFaults_primary_overwriting-> {'mandatory'} -> {$fault} = {'DecodedStatus' => {'ConfirmedDTC' => 1},};
			$expected_faultstatus_CD_afterDisplcmt-> {'mandatory'} -> {$fault} = {'DecodedStatus' => {'ConfirmedDTC' => 1},};

		}

	}

	else {
		S_w2rep (" Only Internal faults are stored in fault memory, hence no overwriting");
		$expected_faultstatus_CD_noDisplcmt-> {'mandatory'} -> {$tcpar_additional_fault} = {'DecodedStatus' => {'ConfirmedDTC' => 0,'TestFailed' => 1},};
		$fault_overwritten_PFM=0;

		foreach my $fault (@temp_allfaults_qualified){
			$expectedFaults_primary_no_overwriting-> {'mandatory'} -> {$fault} = {'DecodedStatus' => {'ConfirmedDTC' => 1},};
			$expected_faultstatus_CD_noDisplcmt-> {'mandatory'} -> {$fault} = {'DecodedStatus' => {'ConfirmedDTC' => 1},};
		}

	}

	return 1;
}


sub _Aging_fault{

	S_teststep("Create '$tcpar_aged_fault'", 'AUTO_NBR');
	FM_createFault($tcpar_aged_fault);
	S_wait_ms($MAX_FAULT_QUALIFICATION_TIME_MS);

	S_teststep("Remove '$tcpar_aged_fault' and perform ECU reset", 'AUTO_NBR');
	FM_removeFault($tcpar_aged_fault);
	S_wait_ms($MAX_FAULT_DEQUALIFICATION_TIME_MS);
	my $value_aref = S_aref2dec (PD_ReadMemoryByName('rb_tim_EcuOnTimeDataEe_st.POnCounter_u32'), U32);
	S_w2rep("Current Power on cycle = $value_aref");
	

	S_teststep("Reset ECU for '$tcpar_aging_threshold' times", 'AUTO_NBR');
	foreach my $ecuReset (1..$tcpar_aging_threshold){
		S_teststep("Reset ECU ($ecuReset)", 'AUTO_NBR');
		_Ecu_reset();
		my $value_aref = S_aref2dec (PD_ReadMemoryByName('rb_tim_EcuOnTimeDataEe_st.POnCounter_u32'), U32);
		S_w2rep("VPower on cycle after '$ecuReset' ECU reset= $value_aref");
	}
	
	S_teststep("Reset ECU ($tcpar_aging_threshold + 1)", 'AUTO_NBR');

   _Ecu_reset();

	S_teststep("Read fault memory 'PFM' after fault aging", 'AUTO_NBR', 'read_fault_memory_primary_aging');            #measurement 4
	$fault_mem_primary_afterAging = LIFT_FaultMemory -> read_fault_memory('Primary');
	S_teststep("Read fault memory 'BFM' after fault aging", 'AUTO_NBR', 'read_fault_memory_bosch_aging');
	$fault_mem_bosch_afterAging = LIFT_FaultMemory -> read_fault_memory('Bosch');

	S_teststep("Read fault status via CD after fault aging", 'AUTO_NBR', 'read_fault_status_aging');
	$fault_status_CD_aging = LIFT_FaultMemory -> read_fault_memory('Customer');

	if ($fault_overwritten_BFM==1){
		$expectedFaults_bosch_aging -> {'mandatory'} -> {$tcpar_additional_fault} = {'DecodedStatus' => {'TestFailed' => 1},};

		foreach my $fault (@AllFaultsQualified){
			$expectedFaults_bosch_aging-> {'mandatory'} -> {$fault} = {};

		}
	}
	else{

		foreach my $fault (@AllFaultsQualified){
			$expectedFaults_bosch_aging-> {'mandatory'} -> {$fault} = {};
		}
	}

	my @array_expected_faults_after_aging;
	my $array_index = 0;
	$array_index++ until $temp_allfaults_qualified[$array_index] eq $tcpar_aged_fault;
	splice(@temp_allfaults_qualified, $array_index, 1);

	if ($fault_overwritten_PFM==1){

		$expectedFaults_primary_aging -> {'mandatory'} -> {$displaced_fault} = {'DecodedStatus' => {'ConfirmedDTC' => 1},} if ($displaced_fault_status eq 'qualified');
		$expectedFaults_primary_aging -> {'mandatory'} -> {$tcpar_additional_fault} = {'DecodedStatus' => {'ConfirmedDTC' => 1},};
		$expectedFaults_CD_aging -> {'mandatory'} -> {$displaced_fault} = {'DecodedStatus' => {'ConfirmedDTC' => 1 },}if ($displaced_fault_status eq 'qualified');
		$expectedFaults_CD_aging -> {'mandatory'} -> {$displaced_fault} = {'DecodedStatus' => {'ConfirmedDTC' => 0 },}if ($displaced_fault_status eq 'dequalified');
		$expectedFaults_CD_aging -> {'mandatory'} -> {$tcpar_additional_fault} = {'DecodedStatus' => {'ConfirmedDTC' => 1 },};
		$expectedFaults_CD_aging -> {'mandatory'} -> {$tcpar_aged_fault} = {'DecodedStatus' => {'ConfirmedDTC' => 0,'TestFailed'=>0},};
	}
	else {

		$expectedFaults_primary_aging -> {'mandatory'} -> {$tcpar_additional_fault} = {'DecodedStatus' => {'ConfirmedDTC' => 1},};
		$expectedFaults_CD_aging -> {'mandatory'} -> {$tcpar_additional_fault} = {'DecodedStatus' => {'ConfirmedDTC' => 1,'TestFailed'=>1},};
		$expectedFaults_CD_aging -> {'mandatory'} -> {$tcpar_aged_fault} = {'DecodedStatus' => {'ConfirmedDTC' => 0,'TestFailed'=>0},};
	}
	my @remaining_faults_qualified;
	my $no_of_aging_dequalifiedfaults= scalar (@aging_dequalifiedfaults);
	if ($no_of_aging_dequalifiedfaults==0){
		@array_expected_faults_after_aging=@temp_allfaults_qualified;
	}
	elsif ($no_of_aging_dequalifiedfaults>0){
		my $hash_of_agingfaultsdequalified;
		foreach my $data (@aging_dequalifiedfaults){
			$hash_of_agingfaultsdequalified->{$data} = 1;
		}
		foreach my $flt (@temp_allfaults_qualified){
			if(not exists $hash_of_agingfaultsdequalified->{$flt}){
				push(@remaining_faults_qualified, $flt);
			}
		}
		@array_expected_faults_after_aging=@remaining_faults_qualified;
	}

	foreach my $fault (@array_expected_faults_after_aging){
		$expectedFaults_primary_aging-> {'mandatory'} -> {$fault} = {'DecodedStatus' => {'ConfirmedDTC' =>1},};
		$expectedFaults_CD_aging-> {'mandatory'} -> {$fault} = {'DecodedStatus' => {'ConfirmedDTC' => 1},};

	}

	foreach my $fault (@aging_dequalifiedfaults){
		$expectedFaults_CD_aging-> {'mandatory'} -> {$fault} = {'DecodedStatus' => {'ConfirmedDTC' => 0},};

	}
	
	
	return 1;
}


sub _Aging_evaulation{

	$fault_mem_primary_afterAging -> evaluate_faults($expectedFaults_primary_aging,"read_fault_memory_primary_aging");  #evaluation 4
    $fault_mem_bosch_afterAging -> evaluate_faults($expectedFaults_bosch_aging,"read_fault_memory_bosch_aging");
    $fault_status_CD_aging -> evaluate_faults($expectedFaults_CD_aging,"read_fault_status_aging");

    if (($fault_overwritten_PFM ==1) and ($fault_overwritten_BFM==1)){
     	$faultPresence_primary_aging = $fault_mem_primary_afterAging -> check_fault_presence ([$tcpar_aged_fault,$displaced_fault]);
        $faultPresence_bosch_aging = $fault_mem_bosch_afterAging -> check_fault_presence ([$tcpar_aged_fault,$displaced_fault]);
        $faultPresence_primary_aged = ${$faultPresence_primary_aging}{$tcpar_aged_fault};
        $faultPresence_bosch_aged = ${$faultPresence_bosch_aging}{$tcpar_aged_fault};
        $faultPresence_primary_aged_displaced = ${$faultPresence_primary_aging}{$displaced_fault};
        $faultPresence_bosch_aged_displaced = ${$faultPresence_bosch_aging}{$displaced_fault};
        S_teststep_expected ("$tcpar_aged_fault ages and $displaced_fault is stored in primary fault memory", 'read_fault_memory_primary_aging' )if ($displaced_fault_status eq 'qualified');
		S_teststep_expected ("$tcpar_aged_fault ages and $displaced_fault is NOT stored in primary fault memory , since its $displaced_fault_status ", 'read_fault_memory_primary_aging' )if ($displaced_fault_status eq 'dequalified');
        S_teststep_detected ("$tcpar_aged_fault is '$faultPresence_primary_aged' ,$displaced_fault is  ' $faultPresence_primary_aged_displaced ' in primary fault memory", 'read_fault_memory_primary_aging' );
        if (($faultPresence_primary_aged eq 'not_present') and ($faultPresence_primary_aged_displaced eq 'present'))    {
            S_set_verdict('VERDICT_PASS');
        }
        elsif (($faultPresence_primary_aged eq 'not_present') and ($faultPresence_primary_aged_displaced eq 'not_present'))   {
			S_set_verdict('VERDICT_PASS')if ($displaced_fault_status eq 'dequalified');
            S_set_verdict('VERDICT_FAIL') if ($displaced_fault_status eq 'qualified');
        }
		else {
			S_set_verdict('VERDICT_FAIL');
		}
        S_teststep_expected ("$tcpar_aged_fault  does not age and $displaced_fault is NOT stored in BOSCH fault memory", 'read_fault_memory_bosch_aging' );
        S_teststep_detected ("$tcpar_aged_fault is '$faultPresence_bosch_aged',$displaced_fault is '$faultPresence_bosch_aged_displaced' in BOSCH fault memory", 'read_fault_memory_bosch_aging' );
        if (($faultPresence_bosch_aged eq 'present') and ($faultPresence_bosch_aged_displaced eq 'not_present'))    {
            S_set_verdict('VERDICT_PASS');
        }
        else{
            S_set_verdict('VERDICT_FAIL');
        }
    }
    elsif(($fault_overwritten_PFM ==0) and ($fault_overwritten_BFM==0)) {
        $faultPresence_primary_aging = $fault_mem_primary_afterAging -> check_fault_presence ([$tcpar_aged_fault,$tcpar_additional_fault]);
        $faultPresence_bosch_aging = $fault_mem_bosch_afterAging -> check_fault_presence ([$tcpar_aged_fault,$tcpar_additional_fault]);
        $faultPresence_primary_aged = ${$faultPresence_primary_aging}{$tcpar_aged_fault};
        $faultPresence_bosch_aged = ${$faultPresence_bosch_aging}{$tcpar_aged_fault};
        $faultPresence_primary_aged_additional_fault = ${$faultPresence_primary_aging}{$tcpar_additional_fault};
        $faultPresence_bosch_aged_additional_fault = ${$faultPresence_bosch_aging}{$tcpar_additional_fault};
        S_teststep_expected ("$tcpar_aged_fault ages and $tcpar_additional_fault is stored in primary fault memory", 'read_fault_memory_primary_aging' );
        S_teststep_detected ("$tcpar_aged_fault is '$faultPresence_primary_aged' ,$tcpar_additional_fault is '$faultPresence_primary_aged_additional_fault'  in primary fault memory", 'read_fault_memory_primary_aging' );
        if (($faultPresence_primary_aged eq 'not_present') and ($faultPresence_primary_aged_additional_fault eq 'present')) {
            S_set_verdict('VERDICT_PASS');
        }
        else{
            S_set_verdict('VERDICT_FAIL');
        }
        S_teststep_expected ("$tcpar_aged_fault does NOT age and $tcpar_additional_fault is NOT stored in BOSCH fault memory", 'read_fault_memory_bosch_aging' );
        S_teststep_detected ("$tcpar_aged_fault is '$faultPresence_bosch_aged',$tcpar_additional_fault is '$faultPresence_bosch_aged_additional_fault' in bosch fault memory", 'read_fault_memory_bosch_aging' );
        if (($faultPresence_bosch_aged eq 'present') and ($faultPresence_bosch_aged_additional_fault eq 'not_present')) {
            S_set_verdict('VERDICT_PASS');
        }
        else{
            S_set_verdict('VERDICT_FAIL');
        }
    }
	elsif(($fault_overwritten_PFM ==1) and ($fault_overwritten_BFM==0)) {
        $faultPresence_primary_aging = $fault_mem_primary_afterAging -> check_fault_presence ([$tcpar_aged_fault,$displaced_fault]);
        $faultPresence_bosch_aging = $fault_mem_bosch_afterAging -> check_fault_presence ([$tcpar_aged_fault,$tcpar_additional_fault]);
        $faultPresence_primary_aged = ${$faultPresence_primary_aging}{$tcpar_aged_fault};
        $faultPresence_bosch_aged = ${$faultPresence_bosch_aging}{$tcpar_aged_fault};
        $faultPresence_primary_aged_displaced = ${$faultPresence_primary_aging}{$displaced_fault};
        $faultPresence_bosch_aged_additional_fault = ${$faultPresence_bosch_aging}{$tcpar_additional_fault};
        S_teststep_expected ("$tcpar_aged_fault ages and $displaced_fault is stored in primary fault memory", 'read_fault_memory_primary_aging' )if ($displaced_fault_status eq 'qualified');
		S_teststep_expected ("$tcpar_aged_fault ages and $displaced_fault is NOT stored in primary fault memory , since its $displaced_fault_status ", 'read_fault_memory_primary_aging' )if ($displaced_fault_status eq 'dequalified');
        S_teststep_detected ("$tcpar_aged_fault is '$faultPresence_primary_aged' ,$displaced_fault is '$faultPresence_primary_aged_displaced'  in primary fault memory", 'read_fault_memory_primary_aging' );

		if (($faultPresence_primary_aged eq 'not_present') and ($faultPresence_primary_aged_displaced eq 'present'))    {
            S_set_verdict('VERDICT_PASS');
        }
        elsif (($faultPresence_primary_aged eq 'not_present') and ($faultPresence_primary_aged_displaced eq 'not_present'))   {
			S_set_verdict('VERDICT_PASS')if ($displaced_fault_status eq 'dequalified');
            S_set_verdict('VERDICT_FAIL') if ($displaced_fault_status eq 'qualified');
        }
		else {
			S_set_verdict('VERDICT_FAIL');
		}
   
        S_teststep_expected ("$tcpar_aged_fault does NOT age and $tcpar_additional_fault is NOT stored in BOSCH fault memory", 'read_fault_memory_bosch_aging' );
        S_teststep_detected ("$tcpar_aged_fault is '$faultPresence_bosch_aged',$tcpar_additional_fault is '$faultPresence_bosch_aged_additional_fault' in bosch fault memory", 'read_fault_memory_bosch_aging' );

        if (($faultPresence_bosch_aged eq 'present') and ($faultPresence_bosch_aged_additional_fault eq 'not_present')) {
            S_set_verdict('VERDICT_PASS');
        }
        else{
            S_set_verdict('VERDICT_FAIL');
        }
    }

    return 1;
}

1;
