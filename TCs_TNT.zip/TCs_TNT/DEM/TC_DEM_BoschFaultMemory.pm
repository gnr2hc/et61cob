#### TEST CASE MODULE
package TC_DEM_BoschFaultMemory;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.3 $;
our $HEADER = q$Header: DEM/TC_DEM_BoschFaultMemory.pm 1.3 2018/04/16 12:25:42ICT D Souza Deepthi Mariate (RBEI/ESA-PP3) (DDE3KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_evaluation;
use LIFT_PD;
use LIFT_labcar;
use LIFT_CANoe;
use LIFT_labcar;
use LIFT_DCOM;
use LIFT_equipment;
use GENERIC_DCOM;
use LIFT_can_access;
use LIFT_FaultMemory;
use INCLUDES_Project;
use File::Basename;
use Data::Dumper;
use Readonly;
# Maximum fault quali / dequali times
Readonly my $MAX_FAULT_QUALIFICATION_TIME_MS => 32000;
Readonly my $MAX_FAULT_DEQUALIFICATION_TIME_MS => 32000;
Readonly my $CONVERSION_ASIC_TEMP_TO_DEG => 0.1;
Readonly my $SECONDS_TO_MILISECONDS => 1000;
Readonly my $GENERAL_WAIT_TIME => 6000;
Readonly my $TOLERANCE_RELATIVE => 10;
##################################

our $PURPOSE = "To check BOSCH fault memory staus under fault qualified, dequalified, re-qualified,re-dequalified conditions";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DEM_BoschfaultMemory

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1.Read PD variable <Var_PowerOn_Counter>, <Var_Operating_Time>,<Var_MasterASIC_Temp>;

# Var_PowerOn_Counter= PowerOnCounter_A;

# Var_Operating_Time= OperatingTime_A;

# Var_MasterASIC_Temp= MasterASICTemp_A;

2.Create <External_fault_name> with <fault_monitoring_type>

3.Create <Internal_erasable_fault_name> with <fault_monitoring_type>

4.Create <Internal_non_erasable_fault_name> with <fault_monitoring_type>

5.Wait for fault qualification

6.Read BOSCH fault memory(BFM)

7.Read PFM

8.Reset ECU

9.Read BOSCH fault memory(BFM)

10.Read PFM

11.Read PD variable  <Var_PowerOn_Counter>, <Var_Operating_Time>

# Var_PowerOn_Counter= PowerOnCounter_B;

# Var_Operating_Time= OperatingTime_B;

12.Remove all faults, wait for dequalification time

13.Read BOSCH fault memory(BFM)

14.Read PFM

15.Reset ECU

16. Re-create all the faults in step2-4,wait for quali time

17.Read BFM

18.Read PFM

19.Read PD variable <Var_PowerOn_Counter>, <Var_Operating_Time>,

# Var_PowerOn_Counter= PowerOnCounter_C;

# Var_Operating_Time= OperatingTime_C;

20.Remove all the faults in step2-4

21.Read BFM

22.Read PFM

23.Erase all faults memory via PD

24.Read PD variable <Var_PowerOn_Counter>, <Var_Operating_Time>,<Var_MasterASIC_Temp>;

# Var_PowerOn_Counter= PowerOnCounter_D;

# Var_Operating_Time= OperatingTime_D;

# Var_MasterASIC_Temp= MasterASICTemp_D;

25. Re-create all the faults in step2-4,wait for quali time

26.Read BFM

27.Read PFM

28.Remove all faults

29.Erase all faults memory via PD

30. Read all faults memory


I<B<Evaluation>>

1.

2.

3.

4.

5.

6. 

QualificationTime_Step6 =  (OperatingTime_A + fault quali time)  with 10% tolerance;

DequalificationTime = 0;

QualificationPowerOnCycle = PowerOnCounter_A, if fault_type is cyclic;

QualificationPowerOnCycle = PowerOnCounter_A+1, if fault_type is init;

DequalificationPowerOnCycle = 0;

OccurrenceCounter =1;

MasterASICTemp_Step6 = MasterASICTemp_A with 10% tolerance;

7. All faults are in qualified state;

9.

QualificationTime_Step9 =  QualificationTime_Step6

DequalificationTime = 0;

QualificationPowerOnCycle = PowerOnCounter_A, if fault_type is cyclic;

QualificationPowerOnCycle =  PowerOnCounter_A+1, if fault_type is init;

DequalificationPowerOnCycle = 0;

OccurrenceCounter =1;

MasterASICTemp_Step9 = MasterASICTemp_Step6;

10. All faults are in qualified state;

13. 

QualificationTime_Step13 =  QualificationTime_Step6

DequalificationTime_Step13 = OperatingTime_B+ fault dequali time;

QualificationPowerOnCycle = PowerOnCounter_A, if fault_type is cyclic;

QualificationPowerOnCycle = PowerOnCounter_A+1, if fault_type is init;

DequalificationPowerOnCycle = PowerOnCounter_B, if fault_type is cyclic;

DequalificationPowerOnCycle = PowerOnCounter_B+1, if fault_type is init;

OccurrenceCounter =1;

MasterASICTemp_Step13 = MasterASICTemp_Step6;

14.  All faults are in dequalified state;

17. 

QualificationTime_Step17 =  QualificationTime_Step6

DequalificationTime_Step17 = DequalificationTime_Step13;

QualificationPowerOnCycle = PowerOnCounter_A, if fault_type is cyclic;

QualificationPowerOnCycle = PowerOnCounter_A+1, if fault_type is init;

DequalificationPowerOnCycle = PowerOnCounter_B, if fault_type is cyclic;

DequalificationPowerOnCycle = PowerOnCounter_B+1, if fault_type is init;

OccurrenceCounter =2;

MasterASICTemp_Step17 = MasterASICTemp_Step6;

18.  All faults are in qualified state;

21.

QualificationTime_Step21 =  QualificationTime_Step6

DequalificationTime_Step21= OperatingTime_C+ fault dequali time;

QualificationPowerOnCycle = PowerOnCounter_A, if fault_type is cyclic;

QualificationPowerOnCycle = PowerOnCounter_A+1, if fault_type is init;

DequalificationPowerOnCycle = PowerOnCounter_C, if fault_type is cyclic;

DequalificationPowerOnCycle =PowerOnCounter_C+1, if fault_type is init;

OccurrenceCounter =2;

MasterASICTemp_Step21 = MasterASICTemp_Step6;

22. All faults are in dequalified state;

26.

QualificationTime_Step26 =  (QualificationTime_D + fault quali time) with 10% tolerance

DequalificationTime_Step26= 0

QualificationPowerOnCycle = PowerOnCounter_D, if fault_type is cyclic;

QualificationPowerOnCycle = PowerOnCounter_D+1, if fault_type is init;

DequalificationPowerOnCycle = 0

OccurrenceCounter =1;

MasterASICTemp_Step26 = MasterASICTemp_D  with 10% tolerance;

27. All faults are in qualified state;

30. All fault memory shall be empty;


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

    SCALAR 'External_fault_name' => 
    SCALAR 'fault_monitoring_type' => 
    SCALAR 'purpose' => 
    SCALAR 'Var_PowerOn_Counter' => 
    SCALAR 'Var_Operating_Time' => 
    SCALAR 'Var_MasterASIC_Temp' => 
    SCALAR 'Internal_erasable_fault_name' => 
    SCALAR 'Internal_non_erasable_fault_name' => 


=head2 PARAMETER EXAMPLES

    purpose ='To check BOSCH fault memory staus under fault qualified dequalified re-qualified re-dequalified conditions'
    
    
    #Default parameters
    Var_PowerOn_Counter= 'rb_tim_EcuOnTimeDataEe_nvmst.POnCounter_u32'
    Var_Operating_Time= 'rb_tim_EcuOnTimeDataEe_nvmst.PoOnTime_u32'
    Var_MasterASIC_Temp= 'rb_sqmm_AsicTemperature_s16'
    Internal_erasable_fault_name= ''
    Internal_non_erasable_fault_name= ''
    External_fault_name='rb_acc_ParameterLayoutIDInvalid_flt'
    fault_monitoring_type='Init'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my (
        $tcpar_Var_PowerOn_Counter,
        $tcpar_Var_Operating_Time,
        $tcpar_Var_MasterASIC_Temp,
   );
my (
        $tcpar_External_fault_name,
        $tcpar_Internal_erasable_fault_name,
        $tcpar_Internal_non_erasable_fault_name,
        $tcpar_fault_monitoring_type,
   );

################ global parameter declaration ###################
#add any global variables here
my (
       $FaultQualiTime_Extenal,
       $FaultDequaliTime_Extenal,
       $FaultQualiTime_Extenal_CC,
       $FaultDequaliTime_Extenal_CC,
       $FaultQualiTime_InternalNonErasble,
       $FaultDequaliTime_InternalNonErasble,
       $FaultQualiTime_InternalErasble,
       $FaultDequaliTime_InternalErasble,
   );
my (
       $CC_flt,

       #Default general status
       $Default_GeneralStatus_href,
       $expected_primary_DecodedStatus_href,

       #quali/dequali poweron cycle
       $qualification_poweron_cycle,
       $dequalification_poweron_cycle,

       #quali/dequali time
       $qualiTime_FirstQuali,
       $deQualiTime_SecondQuali,

       #operating time
       $OperatingTime_InitialValue,
       $OperatingTime_QualiResetFirstTimeValue,
       $OperatingTime_RequaliFirstTimeValue,
       $OperatingTime_ErasingFaultValue,

       #$MasterASICTemp
       $MasterASICTemp_InitialValue,
       $MasterASICTemp_ErasingFaultValue,
       $masterASICTemp_FirstQuali,
       $masterASICTemp_FirstQuali_CC,
       $masterASICTemp_FirstQuali_InterErasbale,
       $masterASICTemp_FirstQuali_InterNonErasble,

       #expected PFM
       $expectedFaults_primary_QualiFirstTime,
       $expectedFaults_primary_ResetAfterFirstQuali,
       $expectedFaults_primary_RemoveAfterQualiResetFirstTime,
       $expectedFaults_primary_RequaliAfterRemovingFirstTime,
       $expectedFaults_primary_RemoveAfterRequaliFirstTime,
       $expectedFaults_primary_RequaliAfterErasingFaultsByPD,

       #expected BFM
       $expectedFaults_bosch_QualiFirstTime,
       $expectedFaults_bsoch_ResetAfterFirstQuali,
       $expectedFaults_bosch_RemoveAfterQualiResetFirstTime,
       $expectedFaults_bosch_RequaliAfterRemovingFirstTime,
       $expectedFaults_bosch_RemoveAfterRequaliFirstTime,
       $expectedFaults_bosch_RequaliAfterErasingFaultsByPD,

       #detected BFM
       $fault_mem_bosch_QualiFirstTime,
       $fault_mem_bosch_ResetAfterFirstQuali,
       $fault_mem_bosch_RemoveAfterQualiResetFirstTime,
       $fault_mem_bosch_RequaliAfterRemovingFirstTime,
       $fault_mem_bosch_RemoveAfterRequaliFirstTime,
       $fault_mem_bosch_RequaliAfterErasingFaultsByPD,
       $fault_mem_bosch_AfterErasingAllFaultsByPD,

       #deteced PFM
       $fault_mem_primary_QualiFirstTime,
       $fault_mem_primary_ResetAfterFirstQuali,
       $fault_mem_primary_RemoveAfterQualiResetFirstTime,
       $fault_mem_primary_RequaliAfterRemovingFirstTime,
       $fault_mem_primary_RemoveAfterRequaliFirstTime,
       $fault_mem_primary_RequaliAfterErasingFaultsByPD,
       $fault_mem_primary_AfterErasingAllFaultsByPD,

       #expected values needs tolerance evaluation in BFM
       $expectedValue_bosch_QualiFirstTime_href,
       $expectedValue_bosch_RemoveAfterQualiResetFirstTime_href,
       $expectedValue_bosch_RemoveAfterRequaliFirstTime_href,
       $expectedValue_bosch_RequaliAfterErasingFaultsByPD_href,

       #getected values needs tolerance evaluation in BFM
       $detectedValue_bosch_QualiFirstTime_href,
       $detectedValue_bosch_RemoveAfterQualiResetFirstTime_href,
       $detectedValue_bosch_RemoveAfterRequaliFirstTime_href,
       $detectedValue_bosch_RequaliAfterErasingFaultsByPD_href,

    );




###############################################################

sub TC_set_parameters {

    $tcpar_purpose                             =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
    $tcpar_Var_PowerOn_Counter                 =  GEN_Read_mandatory_testcase_parameter( 'Var_PowerOn_Counter' );
    $tcpar_Var_Operating_Time                  =  GEN_Read_mandatory_testcase_parameter( 'Var_Operating_Time' );
    $tcpar_Var_MasterASIC_Temp                 =  GEN_Read_mandatory_testcase_parameter( 'Var_MasterASIC_Temp' );
    $tcpar_Internal_erasable_fault_name        =  GEN_Read_optional_testcase_parameter( 'Internal_erasable_fault_name' );
    $tcpar_Internal_non_erasable_fault_name    =  GEN_Read_optional_testcase_parameter( 'Internal_non_erasable_fault_name' );
    $tcpar_External_fault_name                 =  GEN_Read_optional_testcase_parameter( 'External_fault_name' );
    $tcpar_fault_monitoring_type               =  lc(S_read_mandatory_testcase_parameter( 'fault_monitoring_type' ));

    if($tcpar_fault_monitoring_type ne 'init' && $tcpar_fault_monitoring_type ne 'cyclic')
    {
          S_set_error("Mandatory parameter 'fault_monitoring_type' is not valid, should be 'init' or 'cyclic'");
    }
    unless( defined $tcpar_Internal_erasable_fault_name || defined $tcpar_Internal_non_erasable_fault_name || defined $tcpar_External_fault_name)
    {
         S_set_error("There shall be alt least one type of fault exist in the paremeter");
    }

    $Default_GeneralStatus_href = {
                                        'reserved'                  => 0,
                                        'Squib_fired_current_POC'   => 0,
                                        'DIS_ALP_enabled'           => 1,
                                        'Algo_active'               => 0,
                                        'IdleMode_active'           => 0,
    };

    return 1;
}

sub TC_initialization {

    S_w2log(1, "Initialize CD and start CAN trace");
    GDCOM_init(); # To fetch info for CD from mapping_diag
    CA_trace_start ();

    S_teststep("StandardPrepNoFault", 'AUTO_NBR');
    GEN_StandardPrepNoFault();


    return 1;
}

sub TC_stimulation_and_measurement {

   my ($powerOnCounter_InitialValue, $powerOnCounter_QualiResetFirstTimeValue, $powerOnCounter_RequaliFirstTimeValue, $powerOnCounter_ErasingFaultValue);
  # ---- Step1: READ PD variables ----
    S_teststep("Read PD variable '$tcpar_Var_PowerOn_Counter','$tcpar_Var_Operating_Time','$tcpar_Var_MasterASIC_Temp' ", 'AUTO_NBR');
    $powerOnCounter_InitialValue = S_aref2dec(PD_ReadMemoryByName($tcpar_Var_PowerOn_Counter),'U32');
    $OperatingTime_InitialValue  = S_aref2dec(PD_ReadMemoryByName($tcpar_Var_Operating_Time),'U32');
    $MasterASICTemp_InitialValue = $CONVERSION_ASIC_TEMP_TO_DEG * S_aref2dec(PD_ReadMemoryByName($tcpar_Var_MasterASIC_Temp),'S32');
    S_w2rep("$tcpar_Var_PowerOn_Counter : $powerOnCounter_InitialValue\n", 'blue');
    S_w2rep("$tcpar_Var_Operating_Time  : $OperatingTime_InitialValue seconds\n", 'blue');
    S_w2rep("$tcpar_Var_MasterASIC_Temp : $MasterASICTemp_InitialValue degree\n", 'blue');

    $qualification_poweron_cycle = $powerOnCounter_InitialValue;
    $qualification_poweron_cycle += 1 if($tcpar_fault_monitoring_type eq 'init');
    $dequalification_poweron_cycle =0;

# ---- Step2-4: Creat External/Internal erasable/internal non-erasable Faults ----
    _CreatFault_FirstTime();

# ---- Step5: Wait for fault qualification ----
    S_teststep("Wait for fault qualification", 'AUTO_NBR');
    _Trigger_quali_dequali_fault('Qualification');

# ---- Step6: Read BFM when fault qualifed first time ----
    S_teststep("Read BOSCH fault memory(BFM) after fault qualifed the first time", 'AUTO_NBR', 'read_bosch_fltmem_QualiFirstTime');
    $fault_mem_bosch_QualiFirstTime = LIFT_FaultMemory -> read_fault_memory('Bosch');
     # Quali time and Master ASIC temperature needs addtional evaluation, detected values shall be read for external/internal faults before evaluation
    $detectedValue_bosch_QualiFirstTime_href = _GetDetectedValue_FaultAttribute($fault_mem_bosch_QualiFirstTime, ['QualificationTime','ASIC_Temperature']);

# ---- Step7: Read Priamry fault Memory when fault qualifed first time ----
    S_teststep("Read PFM after fault qualifed the first time", 'AUTO_NBR', 'read_primary_fltmem_QualiFirstTime');
    $fault_mem_primary_QualiFirstTime =  LIFT_FaultMemory -> read_fault_memory('Primary');

# ---- Step8: Reset ECU ----
    S_teststep("Reset ECU after fault qualifed the first time", 'AUTO_NBR');
    # can't use LC_ECU_Off() LC_ECU_On(), because it will dequalify VbatLow/High fault
    LC_PowerDisconnect();
    S_wait_ms('TIMER_ECU_OFF');
    LC_PowerConnect();
    S_wait_ms('TIMER_ECU_READY');

# ---- Step9: Read BFM after reset fault qualifed first time and reset----
    S_teststep("Read BOSCH fault memory(BFM) after fault qualifed and reset the first time", 'AUTO_NBR', 'read_bosch_fltmem_ResetAfterFirstQuali');
    _SetExpectedValues_BFMandPFM_ResetAfterQualiFirstTime();
    $fault_mem_bosch_ResetAfterFirstQuali = LIFT_FaultMemory -> read_fault_memory('Bosch');

# ---- Step10: Read PFM after reset after fault qualifed first time ----
    S_teststep("Read PFM after fault qualifed and reset the first time", 'AUTO_NBR', 'read_primary_fltmem_ResetAfterFirstQuali');           #measurement 2
    $fault_mem_primary_ResetAfterFirstQuali =  LIFT_FaultMemory -> read_fault_memory('Primary');

# ---- Step11: Read PD variables after reset after fault qualifed first time ----
    S_teststep("Read PD variable  '$tcpar_Var_PowerOn_Counter', '$tcpar_Var_Operating_Time' after fault qualifed and reset first time", 'AUTO_NBR');
    $powerOnCounter_QualiResetFirstTimeValue = S_aref2dec(PD_ReadMemoryByName($tcpar_Var_PowerOn_Counter),'U32');
    $OperatingTime_QualiResetFirstTimeValue  = S_aref2dec(PD_ReadMemoryByName($tcpar_Var_Operating_Time),'U32');
    S_w2rep("$tcpar_Var_PowerOn_Counter : $powerOnCounter_QualiResetFirstTimeValue\n", 'blue');
    S_w2rep("$tcpar_Var_Operating_Time  : $OperatingTime_QualiResetFirstTimeValue seconds\n", 'blue');

# ---- Step12: Remove all faults after first qualificaiton and reset----
    $dequalification_poweron_cycle = $powerOnCounter_QualiResetFirstTimeValue;
    $dequalification_poweron_cycle += 1 if($tcpar_fault_monitoring_type eq 'init');
    S_teststep("Remove all faults, wait for dequalification time", 'AUTO_NBR');
    _RemoveFault_AfterResetAndQualiFirstTime();
    _Trigger_quali_dequali_fault('Dequalification');

# ---- Step13:  Read BFM after removing all faults first time ----
    S_teststep("Read BOSCH fault memory(BFM) after removing all faults first time", 'AUTO_NBR','read_bosch_fltmem_RemoveAfterQualiResetFirstTime');
    $fault_mem_bosch_RemoveAfterQualiResetFirstTime = LIFT_FaultMemory -> read_fault_memory('Bosch');
     # DeQuali time needs addtional evaluation, detected values shall be read for external/internal faults before evaluation
    $detectedValue_bosch_RemoveAfterQualiResetFirstTime_href = _GetDetectedValue_FaultAttribute($fault_mem_bosch_RemoveAfterQualiResetFirstTime, ['DequalificationTime']);

# ---- Step14: Read PFM after removing all faults first time ----
    S_teststep("Read PFM after removing all faults first time", 'AUTO_NBR', 'read_primary_fltmem_RemoveAfterQualiResetFirstTime');
    $fault_mem_primary_RemoveAfterQualiResetFirstTime = LIFT_FaultMemory -> read_fault_memory('Primary');

# ---- Step15: Reset ECU after removing all faults first time ----
    S_teststep("Reset ECU  after removing all faults first time", 'AUTO_NBR');
    # can't use LC_ECU_Off() LC_ECU_On(), because it will dequalify VbatLow/High fault
    LC_PowerDisconnect();
    S_wait_ms('TIMER_ECU_OFF');
    LC_PowerConnect();
    S_wait_ms('TIMER_ECU_READY');

# ---- Step16: Re-create all the faults after after removing all faults and reset ----
    S_teststep("Re-create all the faults in step2-4, wait for quali time", 'AUTO_NBR');
    _RecreateFaults_AfterDequaliAndReset();
   _Trigger_quali_dequali_fault('Qualification');

# ---- Step17:  Read BFM after requalify all tyhe faults first time ----
    S_teststep("Read BFM after requlify all the faults first time", 'AUTO_NBR','read_bosch_fltmem_RequaliAfterRemovingFirstTime');
    $fault_mem_bosch_RequaliAfterRemovingFirstTime = LIFT_FaultMemory -> read_fault_memory('Bosch');

# ---- Step18:  Read PFM after requalify all tyhe faults first time ----
    S_teststep("Read PFM after requlify all the faults first time", 'AUTO_NBR', 'read_primary_fltmem_RequaliAfterRemovingFirstTime');
    $fault_mem_primary_RequaliAfterRemovingFirstTime =  LIFT_FaultMemory -> read_fault_memory('Primary');

# ---- Step19: Read PD variables after reset after fault qualifed first time ----
    S_teststep("Read PD variable  '$tcpar_Var_PowerOn_Counter', '$tcpar_Var_Operating_Time' after fault requalifed first time ", 'AUTO_NBR');
    $powerOnCounter_RequaliFirstTimeValue = S_aref2dec(PD_ReadMemoryByName($tcpar_Var_PowerOn_Counter),'U32');
    $OperatingTime_RequaliFirstTimeValue  = S_aref2dec(PD_ReadMemoryByName($tcpar_Var_Operating_Time),'U32');
    S_w2rep("$tcpar_Var_PowerOn_Counter : $powerOnCounter_RequaliFirstTimeValue\n", 'blue');
    S_w2rep("$tcpar_Var_Operating_Time  : $OperatingTime_RequaliFirstTimeValue seconds\n", 'blue');

# ---- Step20: Remove all the faults second time ----
    S_teststep("Remove all the faults in step2-4 after requalify the faults", 'AUTO_NBR');
    $dequalification_poweron_cycle = $powerOnCounter_RequaliFirstTimeValue;
    $dequalification_poweron_cycle += 1 if($tcpar_fault_monitoring_type eq 'init');
    _RemoveFault_AfterRequalify();
    _Trigger_quali_dequali_fault('Dequalification');

# ---- Step21: Read BFM after requlify and remove the faults first time ----
    S_teststep("Read BFM after requlify and remove the faults first time", 'AUTO_NBR','read_bosch_fltmem_RemoveAfterRequaliFirstTime');
    $fault_mem_bosch_RemoveAfterRequaliFirstTime = LIFT_FaultMemory -> read_fault_memory('Bosch');
    $detectedValue_bosch_RemoveAfterRequaliFirstTime_href =  _GetDetectedValue_FaultAttribute($fault_mem_bosch_RemoveAfterRequaliFirstTime, ['DequalificationTime']);

# ---- Step22: Read PFM after requlify and remove the faults first time ----
    S_teststep("Read PFM after requlify and remove the faults first time", 'AUTO_NBR', 'read_primary_fltmem_RemoveAfterRequaliFirstTime');
    $fault_mem_primary_RemoveAfterRequaliFirstTime =  LIFT_FaultMemory -> read_fault_memory('Primary');

# ---- Step23: Erase all faults memory via PD ----
    S_teststep("Erase all faults memory via PD", 'AUTO_NBR');
    PD_ClearFaultMemory();
    S_wait_ms($GENERAL_WAIT_TIME);

# ---- Step24: Read PD variables after reset after fault qualifed first time ----
    S_teststep("Read PD variable '$tcpar_Var_PowerOn_Counter', '$tcpar_Var_Operating_Time','$tcpar_Var_MasterASIC_Temp' after erasing fault by PD;", 'AUTO_NBR');
    $powerOnCounter_ErasingFaultValue  = S_aref2dec(PD_ReadMemoryByName($tcpar_Var_PowerOn_Counter),'U32');
    $OperatingTime_ErasingFaultValue   = S_aref2dec(PD_ReadMemoryByName($tcpar_Var_Operating_Time),'U32');
    $MasterASICTemp_ErasingFaultValue  = $CONVERSION_ASIC_TEMP_TO_DEG * S_aref2dec(PD_ReadMemoryByName($tcpar_Var_MasterASIC_Temp),'S32');
    S_w2rep("$tcpar_Var_PowerOn_Counter : $powerOnCounter_ErasingFaultValue\n", 'blue');
    S_w2rep("$tcpar_Var_Operating_Time  : $OperatingTime_ErasingFaultValue seconds\n", 'blue');
    S_w2rep("$tcpar_Var_MasterASIC_Temp : $MasterASICTemp_ErasingFaultValue degree\n", 'blue');

# ---- Step25: Re-create all the faults after after erasing the faults by PD ----
    S_teststep("Re-create all the faults in step2-4,wait for quali time", 'AUTO_NBR');
    $qualification_poweron_cycle = $powerOnCounter_ErasingFaultValue;
    $qualification_poweron_cycle += 1 if($tcpar_fault_monitoring_type eq 'init');
    _RecreateFaults_AfterErasingbyPD();
   _Trigger_quali_dequali_fault('Qualification');

# ---- Step26: Read BFM after erasing and requlify ----
    S_teststep("Read BFM after erasing by PD and requlify", 'AUTO_NBR','read_bosch_fltmem_QualiAfterErasingByPD');
    $fault_mem_bosch_RequaliAfterErasingFaultsByPD = LIFT_FaultMemory -> read_fault_memory('Bosch');
    $detectedValue_bosch_RequaliAfterErasingFaultsByPD_href =  _GetDetectedValue_FaultAttribute($fault_mem_bosch_RequaliAfterErasingFaultsByPD, ['QualificationTime', 'ASIC_Temperature']);

# ---- Step27: Read PFM after erasing and requlify ----
    S_teststep("Read PFM after erasing by PD and requlify", 'AUTO_NBR', 'read_primary_fltmem_QualiAfterErasingByPD');           #measurement 6
    $fault_mem_primary_RequaliAfterErasingFaultsByPD =  LIFT_FaultMemory -> read_fault_memory('Primary');

# ---- Step28: Remove all faults ----
    S_teststep("Remove all faults", 'AUTO_NBR');
    if (defined $tcpar_External_fault_name)
    {
        S_teststep_2nd_level("Remove '$tcpar_External_fault_name', wait for dequalification time", 'AUTO_NBR');
        FM_removeFault($tcpar_External_fault_name);
    }
    if (defined $tcpar_Internal_erasable_fault_name)
    {
        S_teststep_2nd_level("Remove '$tcpar_Internal_erasable_fault_name'", 'AUTO_NBR');
        FM_removeFault($tcpar_Internal_erasable_fault_name);
    }
    if (defined $tcpar_Internal_non_erasable_fault_name )
    {
        S_teststep_2nd_level("Remove '$tcpar_Internal_non_erasable_fault_name'", 'AUTO_NBR');
        FM_removeFault($tcpar_Internal_non_erasable_fault_name);
    }
    _Trigger_quali_dequali_fault('Dequalification');

# ---- Step29: Erase all faults memory via PD ----
    S_teststep("Erase all faults memory via PD", 'AUTO_NBR');
    PD_ClearFaultMemory();
    S_wait_ms($GENERAL_WAIT_TIME);

    S_teststep("Read all faults memory", 'AUTO_NBR', 'read all faults after erasing');          #measurement 7
    $fault_mem_bosch_AfterErasingAllFaultsByPD   =  LIFT_FaultMemory -> read_fault_memory('Bosch');
    $fault_mem_primary_AfterErasingAllFaultsByPD =  LIFT_FaultMemory -> read_fault_memory('Primary');


    return 1;
}

sub TC_evaluation {

    S_w2rep("");
    S_w2rep("------------------------ Evaluation:  read bosch fault memory after Qualified for the first time ------------------------\n",'purple'); #Step6
    S_teststep_NOHTML("---- Evaluation:  read bosch fault memory after Qualified for the first time -----\n", 'NO_AUTO_NBR');
    $fault_mem_bosch_QualiFirstTime  -> evaluate_faults($expectedFaults_bosch_QualiFirstTime,"read_bosch_fltmem_QualiFirstTime");
    _Evalutate_FaultAttribute_WithToleracne($detectedValue_bosch_QualiFirstTime_href, $expectedValue_bosch_QualiFirstTime_href,['QualificationTime','ASIC_Temperature'],$TOLERANCE_RELATIVE);

    S_w2rep("");
    S_w2rep("------------------------ Evaluation:  read primary fault memory after Qualified for the first time ------------------------\n",'orange'); #Step7
    S_teststep_NOHTML("---- Evaluation:  read primary fault memory after Qualified for the first time -----\n", 'NO_AUTO_NBR');
    $fault_mem_primary_QualiFirstTime -> evaluate_faults($expectedFaults_primary_QualiFirstTime,"read_primary_fltmem_QualiFirstTime");

    S_w2rep("");
    S_w2rep("------------------------ Evaluation:  read bosch fault memory after fault Qualified and reset the first time ------------------------\n",'purple'); #Step9
    S_teststep_NOHTML("---- Evaluation:  read bosch fault memory after fault Qualified and reset the first time -----\n", 'NO_AUTO_NBR');
    $fault_mem_bosch_ResetAfterFirstQuali  -> evaluate_faults($expectedFaults_bsoch_ResetAfterFirstQuali,"read_bosch_fltmem_ResetAfterFirstQuali");

    S_w2rep("");
    S_w2rep("------------------------ Evaluation:  read primary fault memory after fault Qualified and reset the first time ------------------------\n",'orange'); #Step10
    S_teststep_NOHTML("---- Evaluation:  read primary fault memory after fault Qualified and reset the first time -----\n", 'NO_AUTO_NBR');
    $fault_mem_primary_ResetAfterFirstQuali -> evaluate_faults($expectedFaults_primary_ResetAfterFirstQuali,"read_primary_fltmem_ResetAfterFirstQuali");

    S_w2rep("");
    S_w2rep("------------------------ Evaluation:  read bosch fault memory after removing faults first time ------------------------\n",'purple'); #Step13
    S_teststep_NOHTML("---- Evaluation:  read bosch fault memory after removing faults first time -----\n", 'NO_AUTO_NBR');
    $fault_mem_bosch_RemoveAfterQualiResetFirstTime  -> evaluate_faults($expectedFaults_bosch_RemoveAfterQualiResetFirstTime,"read_bosch_fltmem_RemoveAfterQualiResetFirstTime");
    _Evalutate_FaultAttribute_WithToleracne($detectedValue_bosch_RemoveAfterQualiResetFirstTime_href, $expectedValue_bosch_RemoveAfterQualiResetFirstTime_href,['DequalificationTime'],$TOLERANCE_RELATIVE);

    S_w2rep("");
    S_w2rep("------------------------ Evaluation:  read primary fault memory after removing faults first time ------------------------\n",'orange'); #Step14
    S_teststep_NOHTML("---- Evaluation:  read primary fault memory after removing faults first time -----\n", 'NO_AUTO_NBR');
    $fault_mem_primary_RemoveAfterQualiResetFirstTime -> evaluate_faults($expectedFaults_primary_RemoveAfterQualiResetFirstTime,"read_primary_fltmem_RemoveAfterQualiResetFirstTime");

    S_w2rep("");
    S_w2rep("------------------------ Evaluation:  read bosch fault memory after requalifying all the faults first ------------------------\n",'purple'); #Step17
    S_teststep_NOHTML("---- Evaluation: read bosch fault memory after requalifying all the faults first -----\n", 'NO_AUTO_NBR');
    $fault_mem_bosch_RequaliAfterRemovingFirstTime  -> evaluate_faults($expectedFaults_bosch_RequaliAfterRemovingFirstTime,"read_bosch_fltmem_RequaliAfterRemovingFirstTime");

    S_w2rep("");
    S_w2rep("------------------------ Evaluation:  read primary fault memory after requalifying all the faults first time ------------------------\n",'orange'); #Step18
    S_teststep_NOHTML("---- Evaluation: read primary fault memory after requalifying all the faults first time -----\n", 'NO_AUTO_NBR');
    $fault_mem_primary_RequaliAfterRemovingFirstTime -> evaluate_faults($expectedFaults_primary_RequaliAfterRemovingFirstTime,"read_primary_fltmem_RequaliAfterRemovingFirstTime");

    S_w2rep("");
    S_w2rep("------------------------ Evaluation:  read bosch fault memory after requalify and removing faults first time ------------------------\n",'purple');  #Step21
    S_teststep_NOHTML("---- Evaluation: read bosch fault memory after requalify and removing faults first time -----\n", 'NO_AUTO_NBR');
    $fault_mem_bosch_RemoveAfterRequaliFirstTime  -> evaluate_faults($expectedFaults_bosch_RemoveAfterRequaliFirstTime,"read_bosch_fltmem_RemoveAfterRequaliFirstTime");
    _Evalutate_FaultAttribute_WithToleracne($detectedValue_bosch_RemoveAfterRequaliFirstTime_href, $expectedValue_bosch_RemoveAfterRequaliFirstTime_href,['DequalificationTime'],$TOLERANCE_RELATIVE);

    S_w2rep("");
    S_w2rep("------------------------ Evaluation:  read primary fault memory after requalify and removing faults first time ------------------------\n",'orange');  #Step22
    S_teststep_NOHTML("---- Evaluation: read primary fault memory after requalify and removing faults first time -----\n", 'NO_AUTO_NBR');
    $fault_mem_primary_RemoveAfterRequaliFirstTime -> evaluate_faults($expectedFaults_primary_RemoveAfterRequaliFirstTime,"read_primary_fltmem_RemoveAfterRequaliFirstTime");

    S_w2rep("");
    S_w2rep("------------------------ Evaluation:  read bosch fault memory after erasing by PD and qualify faults again ------------------------\n",'purple'); #Step26
    S_teststep_NOHTML("---- Evaluation: read bosch fault memory after erasing by PD and qualify faults again -----\n", 'NO_AUTO_NBR');
    $fault_mem_bosch_RequaliAfterErasingFaultsByPD  -> evaluate_faults($expectedFaults_bosch_RequaliAfterErasingFaultsByPD,"read_bosch_fltmem_QualiAfterErasingByPD");
    _Evalutate_FaultAttribute_WithToleracne($detectedValue_bosch_RequaliAfterErasingFaultsByPD_href, $expectedValue_bosch_RequaliAfterErasingFaultsByPD_href,['QualificationTime',,'ASIC_Temperature'],$TOLERANCE_RELATIVE);

    S_w2rep("");
    S_w2rep("------------------------ Evaluation:  read primary fault memory after erasing by PD and qualify faults again ------------------------\n",'orange'); #Step27
    S_teststep_NOHTML("---- Evaluation: read primary fault memory after erasing by PD and qualify faults again -----\n", 'NO_AUTO_NBR');
    $fault_mem_primary_RequaliAfterErasingFaultsByPD -> evaluate_faults($expectedFaults_primary_RequaliAfterErasingFaultsByPD,"read_primary_fltmem_QualiAfterErasingByPD");

    S_w2rep("");
    S_w2rep("------------------------ Evaluation:  read all fault memory after erasing by PD ------------------------\n",'purple'); #Step30
    S_teststep_NOHTML("---- Evaluation: read all fault memory after erasing by PD -----\n", 'NO_AUTO_NBR');
    my $numberOfFaults_bosch    = $fault_mem_bosch_AfterErasingAllFaultsByPD -> get_number_of_faults();
    my $numberOfFaults_primary  = $fault_mem_primary_AfterErasingAllFaultsByPD -> get_number_of_faults();
    S_teststep_expected( "Number of bosch and primary faults shall both be empty",'read all faults after erasing' );
    S_teststep_detected( "Numbe rof  bosch faults: $numberOfFaults_bosch Number of primary faults: $numberOfFaults_primary", 'read all faults after erasing' );
    EVAL_evaluate_value ("Numbe off bsoch fault memory after removing and erasing",  $numberOfFaults_bosch,    '==',  0);
    EVAL_evaluate_value ("Numbe off primary fault memory after removing and erasing",  $numberOfFaults_primary,    '==',  0);

    return 1;
}

sub TC_finalization {

    return 1;
}

sub _GetCrosscoupledFault
{

    my $fltname    = shift;
    my (
          $crosscoupled_device,
          $searchCondition_href,
          $matchedfaults_aref,
        );
    my @devices;
    #get the type from Fault mapping file
    my $faultproperty   = FM_fetchFaultInfo($fltname);
    my $condition       = $faultproperty->{'Condition'};
    my $device          = $faultproperty->{'Device'};
    my $devicetype      = $faultproperty->{'DeviceType'};
    my $testHW          = $LIFT_config::LIFT_Testbench->{'Functions'}{'PERIPHERIE'}{'device'};

    if ( $devicetype =~ m/Switch/i )
    {
        @devices = LC_Get_names('SWITCHES')    if ( $testHW eq ('MLC' or 'LabCar'));
        @devices = LC_Get_names('BELT_LOCKS')  if ( $testHW eq 'TSG4' );
    }
    elsif ( $devicetype =~ m/Squib/i )
    {
        @devices = LC_Get_names('SQUIBS');
    }
    elsif ( $devicetype =~ m/PAS/i )
    {
        @devices = LC_Get_names('PAS')        if ( $testHW eq ('MLC' or 'LabCar'));
        @devices = LC_Get_names('PAS_LINES')  if ( $testHW eq 'TSG4' );
    }

    if ( $device eq $devices[0] )
    {
        $crosscoupled_device= $devices[1];
    }
    else
    {
        $crosscoupled_device= $devices[0];
    }

    $searchCondition_href->{'Device'} = $crosscoupled_device;
    $searchCondition_href->{'Condition'} = $condition;
    $matchedfaults_aref = FM_fetchFaultName($searchCondition_href);

    return  ${$matchedfaults_aref}[0];
}

sub _Trigger_quali_dequali_fault
{
    my $triggerType = shift;
    my $wait_time_quali=$MAX_FAULT_QUALIFICATION_TIME_MS;
    my $wait_time_dequali=$MAX_FAULT_DEQUALIFICATION_TIME_MS;
    if ($tcpar_fault_monitoring_type eq 'init')
    {
        S_teststep_2nd_level("Reset ECU", 'AUTO_NBR');
        # can't use LC_ECU_Off() LC_ECU_On(), because it will dequalify VbatLow/High fault
        LC_PowerDisconnect();
        S_wait_ms('TIMER_ECU_OFF');
        LC_PowerConnect();
        S_wait_ms('TIMER_ECU_READY');
    }
    else
    {
        S_teststep_2nd_level("Wait for $triggerType time of fault", 'AUTO_NBR');
        S_wait_ms($wait_time_dequali) if($triggerType eq 'Dequalification');
        S_wait_ms($wait_time_quali) if($triggerType eq 'Qualification');
    }
    return 1;
}

sub _GetDetectedValue_FaultAttribute
{
    my $fault_memory =shift;
    my $fault_attribute_aref =shift;
    my $detected_href;
    my ($value_External,$value_ExternalCC,$value_IntenalErasble,$value_IntenalNonErasble);
    foreach my $fault_attribute (@$fault_attribute_aref)
    {
       if (defined $tcpar_External_fault_name && $tcpar_External_fault_name ne '')
       {
            $detected_href -> {'External_Fault'}->{$fault_attribute} = $fault_memory -> get_fault_attribute({"FaultName" => $tcpar_External_fault_name, "Attribute" => $fault_attribute});
            $value_External = $detected_href -> {'External_Fault'}->{$fault_attribute};
            S_w2rep("$tcpar_External_fault_name - $fault_attribute in BFM: $value_External\n",'blue');
            if( $tcpar_External_fault_name =~ m/Crosscoupling/i )
            {
                $detected_href -> {'External_Fault_CC'}->{$fault_attribute} = $fault_memory -> get_fault_attribute({"FaultName" => $CC_flt, "Attribute" => $fault_attribute});
                $value_ExternalCC = $detected_href -> {'External_Fault_CC'}->{$fault_attribute};
                S_w2rep("$CC_flt - $fault_attribute in BFM: $value_ExternalCC\n",'blue');
            }
       }
       if (defined $tcpar_Internal_erasable_fault_name && $tcpar_Internal_erasable_fault_name ne '')
       {
            $detected_href -> {'InternalEraseble_Fault'}->{$fault_attribute} = $fault_memory -> get_fault_attribute({"FaultName" => $tcpar_Internal_erasable_fault_name, "Attribute" => $fault_attribute});
            $value_IntenalErasble = $detected_href -> {'InternalEraseble_Fault'}->{$fault_attribute};
            S_w2rep("$tcpar_Internal_erasable_fault_name - $fault_attribute in BFM: $value_IntenalErasble\n",'blue');
       }
       if (defined $tcpar_Internal_non_erasable_fault_name && $tcpar_Internal_non_erasable_fault_name ne '')
       {
            $detected_href -> {'InternalNonEraseble_Fault'}->{$fault_attribute} = $fault_memory -> get_fault_attribute({"FaultName" => $tcpar_Internal_non_erasable_fault_name, "Attribute" => $fault_attribute});
            $value_IntenalNonErasble = $detected_href -> {'InternalNonEraseble_Fault'}->{$fault_attribute};
            S_w2rep("$tcpar_Internal_non_erasable_fault_name - $fault_attribute in BFM: $value_IntenalNonErasble\n",'blue');
       }
    }
    return $detected_href;

}

sub _Evalutate_FaultAttribute_WithToleracne
{
    my $detectedValue_href      =   shift;
    my $expectedValue_href      =   shift;
    my $fault_attribute_aref    =   shift;
    my $toleracne               =   shift;
    foreach my $fault_type (keys %{$detectedValue_href})
    {
        unless (exists $detectedValue_href -> {$fault_type})
        {
            S_set_error("no $fault_type exist in detected fault memory\n")
        }
         unless (exists $expectedValue_href -> {$fault_type})
        {
            S_set_error("no $fault_type set in expected fault memory\n")
        }
        foreach my $fault_attribute (@$fault_attribute_aref)
        {
            unless (defined $detectedValue_href -> {$fault_type}->{$fault_attribute})
            {
                S_set_error("$fault_type: no $fault_attribute info in detected fault memory\n")
            }
            unless (defined $expectedValue_href -> {$fault_type}->{$fault_attribute})
            {
                S_set_error("$fault_type: no $fault_attribute info in expected fault memory\n")
            }
            EVAL_evaluate_value (
                                    "$fault_type : $fault_attribute",
                                    $detectedValue_href -> {$fault_type}->{$fault_attribute},
                                    '==',
                                    $expectedValue_href-> {$fault_type}->{$fault_attribute},
                                    $toleracne,
                                    
                                );
        } #fault attribute
    } #fault type
    return 1;
}

sub _Getfault_QualiDequaliTime
{
    my $fault = shift;
    my $fm_cyclicqualitime   = FM_fetchFaultInfo( $fault, 'CyclicQualificationtime' );
    my $fm_cyclicdequalitime = FM_fetchFaultInfo( $fault, 'CyclicDequalificationtime' );
    if($tcpar_fault_monitoring_type eq 'cyclic')
    {
       unless ( defined $fm_cyclicqualitime and defined $fm_cyclicdequalitime )
      {
        S_w2rep("'CyclicQualificationtime' and 'CyclicDequalificationtime' properties are not found in Mapping_FAULT file. Checking if old attributes 'Qualificationtime' and 'Dequalificationtime' are found...");
        #check for old attributes
        $fm_cyclicqualitime   = FM_fetchFaultInfo( $fault, 'Qualificationtime' );
        $fm_cyclicdequalitime = FM_fetchFaultInfo( $fault, 'Dequalificationtime' );
        unless ( defined $fm_cyclicqualitime and defined $fm_cyclicdequalitime )
        {
            S_set_error( "Not proceeding due to error in fault mapping file: Attributes for Qualification and Dequalification time are not found.", 0 );
            return 0;
        }
        if( $fm_cyclicqualitime =~ m/init/i  )
        {
            S_w2rep("Value for Qualification time is 'Init' ms. Read ITM Init time from ProjectConst");
            $fm_cyclicqualitime = S_get_contents_of_hash( [ 'VEHICLE', 'ITM_Init_Time_ms' ] );
            unless( defined $fm_cyclicqualitime )
            {
                S_set_error( "Not proceeding due to missing attribute 'VEHICLE'-> 'ITM_Init_Time_ms' in ProjectConst.", 0 );
                return 0;
            }
        }
        if( $fm_cyclicdequalitime =~ m/init/i  )
        {
                S_w2rep("Value for Dequalification time is 'Init' ms. Read ITM Init time from ProjectConst");
                $fm_cyclicdequalitime = S_get_contents_of_hash( [ 'VEHICLE', 'ITM_Init_Time_ms' ] );
                unless( defined $fm_cyclicdequalitime )
                {
                    S_set_error( "Not proceeding due to missing attribute 'VEHICLE'-> 'ITM_Init_Time_ms' in ProjectConst.", 0 );
                    return 0;
                }
         }
       }
       $MAX_FAULT_QUALIFICATION_TIME_MS =$fm_cyclicqualitime if($fm_cyclicqualitime > $MAX_FAULT_QUALIFICATION_TIME_MS);
       $MAX_FAULT_DEQUALIFICATION_TIME_MS =$fm_cyclicqualitime if($fm_cyclicdequalitime > $MAX_FAULT_DEQUALIFICATION_TIME_MS);
       return ($fm_cyclicqualitime/$SECONDS_TO_MILISECONDS,$fm_cyclicdequalitime/$SECONDS_TO_MILISECONDS);
    } #cyclic fault
    elsif($tcpar_fault_monitoring_type eq 'init')
    {
         #check for init Q/DQ time attributes
        my $fm_initqualitime   = FM_fetchFaultInfo( $fault, 'InitQualificationtime' );
        unless( defined $fm_initqualitime )
        {
            S_w2rep( "'InitQualificationtime' property is not found in Mapping_FAULT file. Checking if old attribute 'Qualificationtime' is found..." );
            $fm_initqualitime   = FM_fetchFaultInfo( $fault, 'Qualificationtime' );
        }
        #still not found or given as 'init'
        if( not defined lc($fm_initqualitime) or lc($fm_initqualitime) =~ m/init/i  )
        {
            S_w2rep("Value for Qualification time is not found in Mapping_FAULT file. Default time is 'Init' ms. Read ITM Init time from ProjectConst");
            $fm_initqualitime = S_get_contents_of_hash( [ 'VEHICLE', 'ITM_Init_Time_ms' ] );
            unless( defined $fm_initqualitime )
            {
                S_set_error( "Not proceeding due to missing attribute 'VEHICLE'-> 'ITM_Init_Time_ms' in ProjectConst.", 0 );
                return 0;
            }
        }
        my $fm_initdequalitime = FM_fetchFaultInfo( $fault, 'InitDequalificationtime' );
        unless( defined $fm_initdequalitime )
        {
            S_w2rep( "'InitDequalificationtime' property is not found in Mapping_FAULT file. Checking if old attribute 'Dequalificationtime' is found..." );
            $fm_initdequalitime   = FM_fetchFaultInfo( $fault, 'Dequalificationtime' );
            #still not found or given as 'init'
            if( not defined lc($fm_initdequalitime) or lc($fm_initdequalitime) =~ m/init/i )
            {
                S_w2rep("Value for Dequalification time is not found in Mapping_FAULT file. Default time is 'Init' ms. Read ITM Init time from ProjectConst");
                $fm_initdequalitime = S_get_contents_of_hash( [ 'VEHICLE', 'ITM_Init_Time_ms' ] );
                unless( defined $fm_initdequalitime )
                {
                    S_set_error( "Not proceeding due to missing attribute 'VEHICLE'-> 'ITM_Init_Time_ms' in ProjectConst.", 0 );
                    return 0;
                }
                S_w2rep("Found 'ITM_Init_Time_ms' = $fm_initdequalitime. This value will be used as expected init dequali time");
            }
        }
        $MAX_FAULT_QUALIFICATION_TIME_MS = $fm_cyclicqualitime if($fm_initqualitime > $MAX_FAULT_QUALIFICATION_TIME_MS);
        $MAX_FAULT_DEQUALIFICATION_TIME_MS = $fm_cyclicqualitime if($fm_initdequalitime > $MAX_FAULT_DEQUALIFICATION_TIME_MS);
        return ($fm_initqualitime/$SECONDS_TO_MILISECONDS,$fm_initdequalitime/$SECONDS_TO_MILISECONDS);
    }#init fault     
}

sub _Prepare_expected_DecodedStatus
{
    my $fault = shift;
    my $condition =shift;
    my $return_DecodedStatus_href;
    my
    (
        $testFailed_value,
        $testFailedThisOperationCycl_value,
        $pendingDTC_value,
        $confirmedDTC_value,
        $testNotCompletedSinceLastClear_value,
        $testFailedSinceLastClear_value,
        $testNotCompletedThisOperationCycle_value,
        $warningLamp_value,
        $wLStatus_expected,
    );
    unless(defined $fault)
    {
         S_set_error( "Missing mandatory parameter: fault name.", 0 );
    }
    unless(defined $condition)
    {
         S_set_error( "Missing mandatory parameter: fault condition.", 0 );
    }
    if($condition eq 'CREATE_FAULT_CONDITION' || $condition eq 'RESET_AFTER_FAULT_CREATION')
    {
        $wLStatus_expected = FM_fetchExpectedWLStatus($fault, $condition );
        if($wLStatus_expected =~ /Lamp On/i)
        {
            $wLStatus_expected=1;
        }
        elsif($wLStatus_expected =~ /Lamp Off/i)
        {
             $wLStatus_expected=0;
        }
        else
        {
            S_set_error( "Can not get warning lamp status, please check the fault type and other infos in mappinf_fault.pm.", 0 );
        }
        $testFailed_value                               =1;
        $testFailedThisOperationCycl_value              =1;
        $pendingDTC_value                               =1;
        $confirmedDTC_value                             =1;
        $testNotCompletedSinceLastClear_value           =0;
        $testFailedSinceLastClear_value                 =1;
        $testNotCompletedThisOperationCycle_value       =0;
        $warningLamp_value                              =$wLStatus_expected;
    }
    elsif($condition eq 'REMOVE_FAULT_CONDITION' || $condition eq 'RESET_AFTER_FAULT_REMOVAL')
    {
        $wLStatus_expected = FM_fetchExpectedWLStatus($fault, $condition );
        if($wLStatus_expected =~ /Lamp On/i)
        {
            $wLStatus_expected=1;
        }
        elsif($wLStatus_expected =~ /Lamp Off/i)
        {
             $wLStatus_expected=0;
        }
        else
        {
            S_set_error( "Can not get warning lamp status, please check the fault type and other infos in mappinf_fault.pm.", 0 );
        }
        $testFailed_value                               =0;
        $testFailedThisOperationCycl_value              =1 if ($tcpar_fault_monitoring_type eq 'cyclic');
        $testFailedThisOperationCycl_value              =0 if ($tcpar_fault_monitoring_type eq 'init');
        $pendingDTC_value                               =1;
        $confirmedDTC_value                             =1;
        $testNotCompletedSinceLastClear_value           =0;
        $testFailedSinceLastClear_value                 =1;
        $testNotCompletedThisOperationCycle_value       =0;
        $warningLamp_value                              =$wLStatus_expected;
    }
     $return_DecodedStatus_href = {
                                      'TestFailed'                          => $testFailed_value,
                                      'TestFailedThisOperationCycle'        => $testFailedThisOperationCycl_value,
                                      'PendingDTC'                          => $pendingDTC_value,
                                      'ConfirmedDTC'                        => $confirmedDTC_value,
                                      'TestNotCompletedSinceLastClear'      => $testNotCompletedSinceLastClear_value,
                                      'TestFailedSinceLastClear'            => $testFailedSinceLastClear_value,
                                      'TestNotCompletedThisOperationCycle'  => $testNotCompletedThisOperationCycle_value,
                                      'WarningLamp'                         => $warningLamp_value,
                                };
   return $return_DecodedStatus_href;
 }

 sub _CreatFault_FirstTime
 {
    my $fault_number=1;
    if (defined $tcpar_External_fault_name && $tcpar_External_fault_name ne '')
    {
        ($FaultQualiTime_Extenal,$FaultDequaliTime_Extenal)   = _Getfault_QualiDequaliTime($tcpar_External_fault_name);
        S_w2rep("---- Fualt: $tcpar_External_fault_name -----\n",'blue');
        S_w2rep("Qualification Time (s)    : $FaultQualiTime_Extenal\n",'blue');
        S_w2rep("Dequalification Time (s)  : $FaultDequaliTime_Extenal\n",'blue');

        S_teststep("Create '$tcpar_External_fault_name' with '$tcpar_fault_monitoring_type'", 'AUTO_NBR');
        FM_createFault($tcpar_External_fault_name);
        #expected result for PFM
        $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($tcpar_External_fault_name,'CREATE_FAULT_CONDITION')     if ($tcpar_fault_monitoring_type eq 'cyclic');
        $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($tcpar_External_fault_name,'RESET_AFTER_FAULT_CREATION') if ($tcpar_fault_monitoring_type eq 'init');
        $expectedFaults_primary_QualiFirstTime -> {'mandatory'} -> {$tcpar_External_fault_name} = {
                                                                          'FaultName'     => $tcpar_External_fault_name,
                                                                          'DecodedStatus' => $expected_primary_DecodedStatus_href,
        };
        #expected result for BFM
        $expectedFaults_bosch_QualiFirstTime -> {'mandatory'} -> {$tcpar_External_fault_name} = {
                                                                          'FaultName'                       => $tcpar_External_fault_name,
                                                                          'OccurrenceCounter'               => 1,
                                                                          'DequalificationTime'             => 0,
                                                                          'Dequalification_poweron_cycle'   => $dequalification_poweron_cycle,
                                                                          'Qualification_poweron_cycle'     => $qualification_poweron_cycle,
                                                                          'DecodedGeneralStatus'            => $Default_GeneralStatus_href,
                                                                       };
        # Quali time and Master ASIC temperature needs addtional evaluation
        $expectedValue_bosch_QualiFirstTime_href -> {'External_Fault'}->{'QualificationTime'} = $OperatingTime_InitialValue + $FaultQualiTime_Extenal;
        $expectedValue_bosch_QualiFirstTime_href -> {'External_Fault'}->{'ASIC_Temperature'} = $MasterASICTemp_InitialValue;

        # Crosscoupling fault can cause several defects
        if ($tcpar_External_fault_name=~m/Crosscoupling/i)
        {
            $fault_number++;
            $CC_flt = _GetCrosscoupledFault($tcpar_External_fault_name);
            ($FaultQualiTime_Extenal_CC,$FaultDequaliTime_Extenal_CC)   = _Getfault_QualiDequaliTime( $tcpar_External_fault_name);
            S_w2rep("---- Fualt: $CC_flt -----\n",'blue');
            S_w2rep("Qualification Time (s)    : $FaultQualiTime_Extenal_CC\n",'blue');
            S_w2rep("Dequalification Time (s)   : $FaultDequaliTime_Extenal_CC\n",'blue');
            #expected result for PFM
            $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($CC_flt,'CREATE_FAULT_CONDITION')        if ($tcpar_fault_monitoring_type eq 'cyclic');
            $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($CC_flt,'RESET_AFTER_FAULT_CREATION')    if ($tcpar_fault_monitoring_type eq 'init');

            $expectedFaults_primary_QualiFirstTime -> {'mandatory'} -> {$CC_flt} = {
                                                                                'FaultName' => $CC_flt,
                                                                                'DecodedStatus' => $expected_primary_DecodedStatus_href,
                                                                             };
            #expected result for BFM
            $expectedFaults_bosch_QualiFirstTime -> {'mandatory'} -> {$CC_flt} = {
                                                                            'FaultName'                       => $CC_flt,
                                                                            'OccurrenceCounter'               => 1,
                                                                            'DequalificationTime'             => 0,
                                                                            'Dequalification_poweron_cycle'   => $dequalification_poweron_cycle,
                                                                            'Qualification_poweron_cycle'     => $qualification_poweron_cycle,
                                                                            'DecodedGeneralStatus'            => $Default_GeneralStatus_href,
                                                                            };
            # Quali time and Master ASIC temperature needs addtional evaluation
            $expectedValue_bosch_QualiFirstTime_href -> {'External_Fault_CC'}->{'QualificationTime'} = $OperatingTime_InitialValue + $FaultQualiTime_Extenal_CC;
            $expectedValue_bosch_QualiFirstTime_href -> {'External_Fault_CC'}->{'ASIC_Temperature'} = $MasterASICTemp_InitialValue;
        }# crosscouploing fault
    }
    if (defined $tcpar_Internal_erasable_fault_name && $tcpar_Internal_erasable_fault_name ne '')
    {
         $fault_number++;
        ($FaultQualiTime_InternalErasble, $FaultDequaliTime_InternalErasble)  = _Getfault_QualiDequaliTime( $tcpar_Internal_erasable_fault_name);
        S_w2rep("---- Fualt: $tcpar_Internal_erasable_fault_name -----\n",'blue');
        S_w2rep("Qualification Time (s)   : $FaultQualiTime_InternalErasble\n",'blue');
        S_w2rep("Dequalification Time (s)  : $FaultDequaliTime_InternalErasble\n",'blue');

        S_teststep("Create '$tcpar_Internal_erasable_fault_name' with '$tcpar_fault_monitoring_type'", 'AUTO_NBR');
        FM_createFault($tcpar_Internal_erasable_fault_name);
        #expected result for PFM
        $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($tcpar_Internal_erasable_fault_name,'CREATE_FAULT_CONDITION')        if ($tcpar_fault_monitoring_type eq 'cyclic');
        $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($tcpar_Internal_erasable_fault_name,'RESET_AFTER_FAULT_CREATION')    if ($tcpar_fault_monitoring_type eq 'init');
        $expectedFaults_primary_QualiFirstTime -> {'mandatory'} -> { $tcpar_Internal_erasable_fault_name} = {
                                                                            'FaultName' => $tcpar_Internal_erasable_fault_name,
                                                                            'DecodedStatus' => $expected_primary_DecodedStatus_href,
                                                                         };
        #expected result for BFM                                                                                                                
        $expectedFaults_bosch_QualiFirstTime -> {'mandatory'} -> {$tcpar_Internal_erasable_fault_name} = {
                                                                            'FaultName'                       => $tcpar_Internal_erasable_fault_name,
                                                                            'OccurrenceCounter'               => 1,
                                                                            'DequalificationTime'             => 0,
                                                                            'Dequalification_poweron_cycle'   => $dequalification_poweron_cycle,
                                                                            'Qualification_poweron_cycle'     => $qualification_poweron_cycle,
                                                                            'DecodedGeneralStatus'      => $Default_GeneralStatus_href,
                                                                       };
            # Quali time and Master ASIC temperature needs addtional evaluation
        $expectedValue_bosch_QualiFirstTime_href -> {'InternalEraseble_Fault'}->{'QualificationTime'} = $OperatingTime_InitialValue + $FaultQualiTime_InternalErasble;
        $expectedValue_bosch_QualiFirstTime_href -> {'InternalEraseble_Fault'}->{'ASIC_Temperature'} = $MasterASICTemp_InitialValue;
    }
    if (defined $tcpar_Internal_non_erasable_fault_name && $tcpar_Internal_non_erasable_fault_name ne '')
    {
        $fault_number++;
        ($FaultQualiTime_InternalNonErasble,$FaultDequaliTime_InternalNonErasble) = _Getfault_QualiDequaliTime($tcpar_Internal_non_erasable_fault_name);
        S_w2rep("---- Fualt: $tcpar_Internal_non_erasable_fault_name -----\n",'blue');
        S_w2rep("Qualification Time (s)   : $FaultQualiTime_InternalNonErasble\n",'blue');
        S_w2rep("Dequalification Time (s)  : $FaultDequaliTime_InternalNonErasble\n",'blue');

        S_teststep("Create '$tcpar_Internal_non_erasable_fault_name' with '$tcpar_fault_monitoring_type'", 'AUTO_NBR');
        FM_createFault($tcpar_Internal_non_erasable_fault_name);
        #expected result for PFM
        $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($tcpar_Internal_non_erasable_fault_name,'CREATE_FAULT_CONDITION')        if ($tcpar_fault_monitoring_type eq 'cyclic');
        $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($tcpar_Internal_non_erasable_fault_name,'RESET_AFTER_FAULT_CREATION')    if ($tcpar_fault_monitoring_type eq 'init');
        $expectedFaults_primary_QualiFirstTime -> {'mandatory'} -> {$tcpar_Internal_non_erasable_fault_name} = {
                                                                            'FaultName'     =>      $tcpar_Internal_non_erasable_fault_name,
                                                                            'DecodedStatus' =>      $expected_primary_DecodedStatus_href,
                                                                         };
        #expected result for BFM                                                                                                                
        $expectedFaults_bosch_QualiFirstTime -> {'mandatory'} -> {$tcpar_Internal_non_erasable_fault_name} = {
                                                                            'FaultName'                       => $tcpar_Internal_non_erasable_fault_name,
                                                                            'OccurrenceCounter'               => 1,
                                                                            'DequalificationTime'             => 0,
                                                                            'Dequalification_poweron_cycle'   => $dequalification_poweron_cycle,
                                                                            'Qualification_poweron_cycle'     => $qualification_poweron_cycle,
                                                                            'DecodedGeneralStatus'      => $Default_GeneralStatus_href,
                                                                       };
        $expectedValue_bosch_QualiFirstTime_href -> {'InternalNonEraseble_Fault'}->{'QualificationTime'} = $OperatingTime_InitialValue + $FaultQualiTime_InternalNonErasble;
        $expectedValue_bosch_QualiFirstTime_href -> {'InternalNonEraseble_Fault'}->{'ASIC_Temperature'} = $MasterASICTemp_InitialValue;
    }
    return 1;
 }

sub _SetExpectedValues_BFMandPFM_ResetAfterQualiFirstTime
{
    my $fault_number=1;
    if (defined $tcpar_External_fault_name && $tcpar_External_fault_name ne '')
    {
        #expected result for PFM
       $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($tcpar_External_fault_name,'RESET_AFTER_FAULT_CREATION');
       $expectedFaults_primary_ResetAfterFirstQuali -> {'mandatory'} -> {$tcpar_External_fault_name} = {
                                                                                'FaultName'     => $tcpar_External_fault_name,
                                                                                'DecodedStatus' => $expected_primary_DecodedStatus_href,
                                                                                };

        #expected result for BFM
        $masterASICTemp_FirstQuali   = $detectedValue_bosch_QualiFirstTime_href->{'External_Fault'}->{'ASIC_Temperature'};
        $qualiTime_FirstQuali        = $detectedValue_bosch_QualiFirstTime_href->{'External_Fault'}->{'QualificationTime'};
        $expectedFaults_bsoch_ResetAfterFirstQuali -> {'mandatory'} -> {$tcpar_External_fault_name} = {
                                                                          'FaultName'                       => $tcpar_External_fault_name,
                                                                          'OccurrenceCounter'               => 1,
                                                                          'DequalificationTime'             => 0,
                                                                          'Dequalification_poweron_cycle'   => 0,
                                                                          'Qualification_poweron_cycle'     => $qualification_poweron_cycle,
                                                                          'DecodedGeneralStatus'            => $Default_GeneralStatus_href,
                                                                          'ASIC_Temperature'                => $masterASICTemp_FirstQuali,
                                                                          'QualificationTime'               => $qualiTime_FirstQuali,
                                                                  };														      
        if ($tcpar_External_fault_name=~m/Crosscoupling/i)
        {
            $fault_number++;
            #expected result for PFM
            $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($CC_flt,'RESET_AFTER_FAULT_CREATION');
            $expectedFaults_primary_ResetAfterFirstQuali -> {'mandatory'} -> {$CC_flt} = {
                                                                                'FaultName' => $CC_flt,
                                                                                'DecodedStatus' => $expected_primary_DecodedStatus_href,
                                                                             };
            #expected result for BFM
            $masterASICTemp_FirstQuali_CC   = $detectedValue_bosch_QualiFirstTime_href->{'External_Fault_CC'}->{'ASIC_Temperature'};
            $qualiTime_FirstQuali        = $detectedValue_bosch_QualiFirstTime_href->{'External_Fault_CC'}->{'QualificationTime'};
            $expectedFaults_bsoch_ResetAfterFirstQuali -> {'mandatory'} -> {$CC_flt} = {
                                                                            'FaultName'                       => $CC_flt,
                                                                            'OccurrenceCounter'               => 1,
                                                                            'DequalificationTime'             => 0,
                                                                            'Dequalification_poweron_cycle'   => 0,
                                                                            'Qualification_poweron_cycle'     => $qualification_poweron_cycle,
                                                                            'DecodedGeneralStatus'            => $Default_GeneralStatus_href,
                                                                            'ASIC_Temperature'                => $masterASICTemp_FirstQuali_CC,
                                                                             'QualificationTime'              => $qualiTime_FirstQuali,
                                                                            };
        }# crosscouploing fault
    }# external fault
    if (defined $tcpar_Internal_erasable_fault_name && $tcpar_Internal_erasable_fault_name ne '')
    {
        $fault_number++;
         #expected result for PFM
         $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($tcpar_Internal_erasable_fault_name,'RESET_AFTER_FAULT_CREATION');
         $expectedFaults_primary_ResetAfterFirstQuali -> {'mandatory'} -> {$tcpar_Internal_erasable_fault_name} = {
                                                                                'FaultName'     => $tcpar_Internal_erasable_fault_name,
                                                                                'DecodedStatus' => $expected_primary_DecodedStatus_href,
                                                                                };

        #expected result for BFM
        $masterASICTemp_FirstQuali_InterErasbale   = $detectedValue_bosch_QualiFirstTime_href->{'InternalEraseble_Fault'}->{'ASIC_Temperature'};
        $qualiTime_FirstQuali        = $detectedValue_bosch_QualiFirstTime_href->{'InternalEraseble_Fault'}->{'QualificationTime'};
        $expectedFaults_bsoch_ResetAfterFirstQuali -> {'mandatory'} -> {$tcpar_Internal_erasable_fault_name} = {
                                                                          'FaultName'                       => $tcpar_Internal_erasable_fault_name,
                                                                          'OccurrenceCounter'               => 1,
                                                                          'DequalificationTime'             => 0,
                                                                          'Dequalification_poweron_cycle'   => 0,
                                                                          'Qualification_poweron_cycle'     => $qualification_poweron_cycle,
                                                                          'DecodedGeneralStatus'            => $Default_GeneralStatus_href,
                                                                          'ASIC_Temperature'                => $masterASICTemp_FirstQuali_InterErasbale,
                                                                          'QualificationTime'               => $qualiTime_FirstQuali,
                                                                       };
    } # Internal erasable fault
    if (defined $tcpar_Internal_non_erasable_fault_name && $tcpar_Internal_non_erasable_fault_name ne '')
    {
        $fault_number++;
        #expected result for PFM
        $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($tcpar_Internal_non_erasable_fault_name,'RESET_AFTER_FAULT_CREATION');
        $expectedFaults_primary_ResetAfterFirstQuali -> {'mandatory'} -> {$tcpar_Internal_non_erasable_fault_name} = {
                                                                                'FaultName'     => $tcpar_Internal_non_erasable_fault_name,
                                                                                'DecodedStatus' => $expected_primary_DecodedStatus_href,
                                                                                };
        #expected result for BFM
        $masterASICTemp_FirstQuali_InterNonErasble   = $detectedValue_bosch_QualiFirstTime_href->{'InternalNonEraseble_Fault'}->{'ASIC_Temperature'};
        $qualiTime_FirstQuali        = $detectedValue_bosch_QualiFirstTime_href->{'InternalNonEraseble_Fault'}->{'QualificationTime'};
        $expectedFaults_bsoch_ResetAfterFirstQuali -> {'mandatory'} -> {$tcpar_Internal_non_erasable_fault_name} = {
                                                                                'FaultName'                       => $tcpar_Internal_non_erasable_fault_name,
                                                                                'OccurrenceCounter'               => 1,
                                                                                'DequalificationTime'             => 0,
                                                                                'Dequalification_poweron_cycle'   => 0,
                                                                                'Qualification_poweron_cycle'     => $qualification_poweron_cycle,
                                                                                'DecodedGeneralStatus'            => $Default_GeneralStatus_href,
                                                                                'ASIC_Temperature'                => $masterASICTemp_FirstQuali_InterNonErasble,
                                                                                'QualificationTime'               => $qualiTime_FirstQuali,
                                                                            };
    }# Internal none erasable fault
    return 1;
}

sub _RemoveFault_AfterResetAndQualiFirstTime
{
    my $fault_number=1;
    if (defined $tcpar_External_fault_name)
    {
        S_teststep_2nd_level("Remove '$tcpar_External_fault_name', wait for dequalification time", 'AUTO_NBR');
        FM_removeFault($tcpar_External_fault_name);
        #expected result for PFM
        $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($tcpar_External_fault_name,'REMOVE_FAULT_CONDITION')        if ($tcpar_fault_monitoring_type eq 'cyclic');
        $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($tcpar_External_fault_name,'RESET_AFTER_FAULT_REMOVAL')    if ($tcpar_fault_monitoring_type eq 'init');
        $expectedFaults_primary_RemoveAfterQualiResetFirstTime -> {'mandatory'} -> {$tcpar_External_fault_name} = {
                                                                                            'FaultName'     => $tcpar_External_fault_name,
                                                                                            'DecodedStatus' => $expected_primary_DecodedStatus_href,
                                                                                          };
        #expected result for BFM
		$qualiTime_FirstQuali        = $detectedValue_bosch_QualiFirstTime_href->{'External_Fault'}->{'QualificationTime'};
        $expectedFaults_bosch_RemoveAfterQualiResetFirstTime -> {'mandatory'} -> {$tcpar_External_fault_name} = {
                                                                                            'FaultName'                       => $tcpar_External_fault_name,
                                                                                            'OccurrenceCounter'               => 1,
                                                                                            'Dequalification_poweron_cycle'   => $dequalification_poweron_cycle,
                                                                                            'Qualification_poweron_cycle'     => $qualification_poweron_cycle,
                                                                                            'DecodedGeneralStatus'            => $Default_GeneralStatus_href,
                                                                                            'ASIC_Temperature'                => $masterASICTemp_FirstQuali,
                                                                                            'QualificationTime'               => $qualiTime_FirstQuali,
                                                                                        };
        # DeQuali time needs addtional evaluation
        $expectedValue_bosch_RemoveAfterQualiResetFirstTime_href -> {'External_Fault'}->{'DequalificationTime'} = $OperatingTime_QualiResetFirstTimeValue + $FaultDequaliTime_Extenal;
        if ($tcpar_External_fault_name=~m/Crosscoupling/i)
        {
            $fault_number++;
             #expected result for PFM
            $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($CC_flt,'REMOVE_FAULT_CONDITION')        if ($tcpar_fault_monitoring_type eq 'cyclic');
            $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($CC_flt,'RESET_AFTER_FAULT_REMOVAL')     if ($tcpar_fault_monitoring_type eq 'init');
            $expectedFaults_primary_RemoveAfterQualiResetFirstTime -> {'mandatory'} -> {$CC_flt} = {
                                                                                                'FaultName'     => $CC_flt,
                                                                                                'DecodedStatus' => $expected_primary_DecodedStatus_href,
                                                                                            };
            #expected result for BFM
			$qualiTime_FirstQuali        = $detectedValue_bosch_QualiFirstTime_href->{'External_Fault_CC'}->{'QualificationTime'};
            $expectedFaults_bosch_RemoveAfterQualiResetFirstTime -> {'mandatory'} -> {$CC_flt} = {
                                                                                                'FaultName'                       => $CC_flt,
                                                                                                'OccurrenceCounter'               => 1,
                                                                                                'Dequalification_poweron_cycle'   => $dequalification_poweron_cycle,
                                                                                                'Qualification_poweron_cycle'     => $qualification_poweron_cycle,
                                                                                                'DecodedGeneralStatus'            => $Default_GeneralStatus_href,
                                                                                                'ASIC_Temperature'                => $masterASICTemp_FirstQuali_CC,
                                                                                                'QualificationTime'               => $qualiTime_FirstQuali,
                                                                                            };
           # DeQuali time needs addtional evaluation
            $expectedValue_bosch_RemoveAfterQualiResetFirstTime_href -> {'External_Fault_CC'}->{'DequalificationTime'} = $OperatingTime_QualiResetFirstTimeValue + $FaultDequaliTime_Extenal_CC;
        }
    }
    if (defined $tcpar_Internal_erasable_fault_name)
    {
        $fault_number++;
        S_teststep_2nd_level("Remove '$tcpar_Internal_erasable_fault_name'", 'AUTO_NBR');
        FM_removeFault($tcpar_Internal_erasable_fault_name);
        #expected result for PFM
        $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($tcpar_Internal_erasable_fault_name,'REMOVE_FAULT_CONDITION')        if ($tcpar_fault_monitoring_type eq 'cyclic');
        $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($tcpar_Internal_erasable_fault_name,'RESET_AFTER_FAULT_REMOVAL')    if ($tcpar_fault_monitoring_type eq 'init');
        $expectedFaults_primary_RemoveAfterQualiResetFirstTime -> {'mandatory'} -> {$tcpar_Internal_erasable_fault_name} = {
                                                                                                'FaultName'     => $tcpar_Internal_erasable_fault_name,
                                                                                                'DecodedStatus' => $expected_primary_DecodedStatus_href,
                                                                                            };
        #expected result for BFM
		$qualiTime_FirstQuali        = $detectedValue_bosch_QualiFirstTime_href->{'InternalEraseble_Fault'}->{'QualificationTime'};
        $expectedFaults_bosch_RemoveAfterQualiResetFirstTime -> {'mandatory'} -> {$tcpar_Internal_erasable_fault_name} = {
                                                                                            'FaultName'                       => $tcpar_Internal_erasable_fault_name,
                                                                                            'OccurrenceCounter'               => 1,
                                                                                            'Dequalification_poweron_cycle'   => $dequalification_poweron_cycle,
                                                                                            'Qualification_poweron_cycle'     => $qualification_poweron_cycle,
                                                                                            'DecodedGeneralStatus'            => $Default_GeneralStatus_href,
                                                                                            'ASIC_Temperature'                => $masterASICTemp_FirstQuali_InterErasbale,
                                                                                            'QualificationTime'               => $qualiTime_FirstQuali,
                                                                                        };
        # DeQuali time needs addtional evaluation
        $expectedValue_bosch_RemoveAfterQualiResetFirstTime_href -> {'InternalEraseble_Fault'}->{'DequalificationTime'} = $OperatingTime_QualiResetFirstTimeValue + $FaultDequaliTime_InternalErasble;
    }
    if (defined $tcpar_Internal_non_erasable_fault_name )
    {
        $fault_number++;
        S_teststep_2nd_level("Remove '$tcpar_Internal_non_erasable_fault_name'", 'AUTO_NBR');
        FM_removeFault($tcpar_Internal_non_erasable_fault_name);
         #expected result for PFM
        $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($tcpar_Internal_non_erasable_fault_name,'REMOVE_FAULT_CONDITION')        if ($tcpar_fault_monitoring_type eq 'cyclic');
        $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($tcpar_Internal_non_erasable_fault_name,'RESET_AFTER_FAULT_REMOVAL')    if ($tcpar_fault_monitoring_type eq 'init');
        $expectedFaults_primary_RemoveAfterQualiResetFirstTime -> {'mandatory'} -> {$tcpar_Internal_non_erasable_fault_name} = {
                                                                                                'FaultName'     => $tcpar_Internal_non_erasable_fault_name,
                                                                                                'DecodedStatus' => $expected_primary_DecodedStatus_href,
                                                                                            };
        #expected result for BFM
		$qualiTime_FirstQuali        = $detectedValue_bosch_QualiFirstTime_href->{'InternalNonEraseble_Fault'}->{'QualificationTime'};
        $expectedFaults_bosch_RemoveAfterQualiResetFirstTime -> {'mandatory'} -> {$tcpar_Internal_non_erasable_fault_name} = {
                                                                                            'FaultName'                       => $tcpar_Internal_non_erasable_fault_name,
                                                                                            'OccurrenceCounter'               => 1,
                                                                                            'Dequalification_poweron_cycle'   => $dequalification_poweron_cycle,
                                                                                            'Qualification_poweron_cycle'     => $qualification_poweron_cycle,
                                                                                            'DecodedGeneralStatus'            => $Default_GeneralStatus_href,
                                                                                            'ASIC_Temperature'                => $masterASICTemp_FirstQuali_InterNonErasble,
                                                                                            'QualificationTime'               => $qualiTime_FirstQuali,
                                                                                        };
        # DeQuali time needs addtional evaluation
        $expectedValue_bosch_RemoveAfterQualiResetFirstTime_href -> {'InternalNonEraseble_Fault'}->{'DequalificationTime'} = $OperatingTime_QualiResetFirstTimeValue + $FaultDequaliTime_InternalNonErasble;
    }
    return 1;
}

sub _RecreateFaults_AfterDequaliAndReset
{
    my $fault_number=1;
    if (defined $tcpar_External_fault_name && $tcpar_External_fault_name ne '')
    {
        S_teststep_2nd_level("Create '$tcpar_External_fault_name' with '$tcpar_fault_monitoring_type'", 'AUTO_NBR');
        FM_createFault($tcpar_External_fault_name);
        #expected result for PFM
        $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($tcpar_External_fault_name,'CREATE_FAULT_CONDITION')     if ($tcpar_fault_monitoring_type eq 'cyclic');
        $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($tcpar_External_fault_name,'RESET_AFTER_FAULT_CREATION') if ($tcpar_fault_monitoring_type eq 'init');
        $expectedFaults_primary_RequaliAfterRemovingFirstTime -> {'mandatory'} -> {$tcpar_External_fault_name} = {
                                                                                            'FaultName'     => $tcpar_External_fault_name,
                                                                                            'DecodedStatus' => $expected_primary_DecodedStatus_href,
                                                                                        };
        #expected result for BFM
        $deQualiTime_SecondQuali    = $detectedValue_bosch_RemoveAfterQualiResetFirstTime_href->{'External_Fault'}->{'DequalificationTime'};
		$qualiTime_FirstQuali        = $detectedValue_bosch_QualiFirstTime_href->{'External_Fault'}->{'QualificationTime'}; 
        $expectedFaults_bosch_RequaliAfterRemovingFirstTime -> {'mandatory'} -> {$tcpar_External_fault_name} = {
                                                                                            'FaultName'                       => $tcpar_External_fault_name,
                                                                                            'OccurrenceCounter'               => 2,
                                                                                            'DequalificationTime'             => $deQualiTime_SecondQuali,
                                                                                            'Dequalification_poweron_cycle'   => $dequalification_poweron_cycle,
                                                                                            'Qualification_poweron_cycle'     => $qualification_poweron_cycle,
                                                                                            'DecodedGeneralStatus'            => $Default_GeneralStatus_href,
                                                                                            'ASIC_Temperature'                => $masterASICTemp_FirstQuali,
                                                                                            'QualificationTime'               => $qualiTime_FirstQuali,
                                                                                      };

        # Crosscoupling fault can cause several defects
        if ($tcpar_External_fault_name=~m/Crosscoupling/i)
        {
            $fault_number++;
            #expected result for PFM
            $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($CC_flt,'CREATE_FAULT_CONDITION')     if ($tcpar_fault_monitoring_type eq 'cyclic');
            $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($CC_flt,'RESET_AFTER_FAULT_CREATION') if ($tcpar_fault_monitoring_type eq 'init');
            $expectedFaults_primary_RequaliAfterRemovingFirstTime -> {'mandatory'} -> {$CC_flt} = {
                                                                                            'FaultName' => $CC_flt,
                                                                                            'DecodedStatus' => $expected_primary_DecodedStatus_href,
                                                                                            };
            #expected result for BFM
            $deQualiTime_SecondQuali    = $detectedValue_bosch_RemoveAfterQualiResetFirstTime_href->{'External_Fault_CC'}->{'DequalificationTime'};
			$qualiTime_FirstQuali        = $detectedValue_bosch_QualiFirstTime_href->{'External_Fault_CC'}->{'QualificationTime'};
            $expectedFaults_bosch_RequaliAfterRemovingFirstTime -> {'mandatory'} -> {$CC_flt} = {
                                                                                            'FaultName'                       => $CC_flt,
                                                                                            'OccurrenceCounter'               => 2,
                                                                                             'QualificationTime'              => $qualiTime_FirstQuali,
                                                                                            'DequalificationTime'             => $deQualiTime_SecondQuali,
                                                                                            'Dequalification_poweron_cycle'   => $dequalification_poweron_cycle,
                                                                                            'Qualification_poweron_cycle'     => $qualification_poweron_cycle,
                                                                                            'DecodedGeneralStatus'            => $Default_GeneralStatus_href,
                                                                                            'ASIC_Temperature'                => $masterASICTemp_FirstQuali_CC,
                                                                            };
        }# crosscouploing fault
    }
    if (defined $tcpar_Internal_erasable_fault_name)
    {
        $fault_number++;
         S_teststep_2nd_level("Create '$tcpar_Internal_erasable_fault_name' with '$tcpar_fault_monitoring_type'", 'AUTO_NBR');
         FM_createFault($tcpar_Internal_erasable_fault_name);
         #expected result for PFM
         $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($tcpar_Internal_erasable_fault_name,'CREATE_FAULT_CONDITION')     if ($tcpar_fault_monitoring_type eq 'cyclic');
         $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($tcpar_Internal_erasable_fault_name,'RESET_AFTER_FAULT_CREATION') if ($tcpar_fault_monitoring_type eq 'init');
         $expectedFaults_primary_RequaliAfterRemovingFirstTime -> {'mandatory'} -> {$tcpar_Internal_erasable_fault_name} = {
                                                                                            'FaultName'     => $tcpar_Internal_erasable_fault_name,
                                                                                            'DecodedStatus' => $expected_primary_DecodedStatus_href,
                                                                                        };
        #expected result for BFM
        $deQualiTime_SecondQuali    = $detectedValue_bosch_RemoveAfterQualiResetFirstTime_href->{'InternalEraseble_Fault'}->{'DequalificationTime'};
		$qualiTime_FirstQuali        = $detectedValue_bosch_QualiFirstTime_href->{'InternalEraseble_Fault'}->{'QualificationTime'};
        $expectedFaults_bosch_RequaliAfterRemovingFirstTime -> {'mandatory'} -> {$tcpar_Internal_erasable_fault_name} = {
                                                                                            'FaultName'                       => $tcpar_Internal_erasable_fault_name,
                                                                                            'OccurrenceCounter'               => 2,
                                                                                            'DequalificationTime'             => $deQualiTime_SecondQuali,
                                                                                            'Dequalification_poweron_cycle'   => $dequalification_poweron_cycle,
                                                                                            'Qualification_poweron_cycle'     => $qualification_poweron_cycle,
                                                                                            'DecodedGeneralStatus'            => $Default_GeneralStatus_href,
                                                                                            'ASIC_Temperature'                => $masterASICTemp_FirstQuali_InterErasbale,
                                                                                            'QualificationTime'               => $qualiTime_FirstQuali,
                                                                                      };
    }
    if (defined $tcpar_Internal_non_erasable_fault_name && $tcpar_Internal_non_erasable_fault_name ne '')
    {
        $fault_number++;
        S_teststep_2nd_level("Create '$tcpar_Internal_non_erasable_fault_name' with '$tcpar_fault_monitoring_type'", 'AUTO_NBR');
        FM_createFault($tcpar_Internal_non_erasable_fault_name);
         #expected result for PFM
        $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($tcpar_Internal_non_erasable_fault_name,'CREATE_FAULT_CONDITION')     if ($tcpar_fault_monitoring_type eq 'cyclic');
        $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($tcpar_Internal_non_erasable_fault_name,'RESET_AFTER_FAULT_CREATION') if ($tcpar_fault_monitoring_type eq 'init');
        $expectedFaults_primary_RequaliAfterRemovingFirstTime -> {'mandatory'} -> {$tcpar_Internal_non_erasable_fault_name} = {
                                                                                            'FaultName'     => $tcpar_Internal_non_erasable_fault_name,
                                                                                            'DecodedStatus' => $expected_primary_DecodedStatus_href,
                                                                                        };
        #expected result for BFM
        $deQualiTime_SecondQuali    = $detectedValue_bosch_RemoveAfterQualiResetFirstTime_href->{'InternalNonEraseble_Fault'}->{'DequalificationTime'};
		$qualiTime_FirstQuali        = $detectedValue_bosch_QualiFirstTime_href->{'InternalNonEraseble_Fault'}->{'QualificationTime'};
        $expectedFaults_bosch_RequaliAfterRemovingFirstTime -> {'mandatory'} -> {$tcpar_Internal_non_erasable_fault_name} = {
                                                                                            'FaultName'                       => $tcpar_Internal_non_erasable_fault_name,
                                                                                            'OccurrenceCounter'               => 2,
                                                                                            'DequalificationTime'             => $deQualiTime_SecondQuali,
                                                                                            'Dequalification_poweron_cycle'   => $dequalification_poweron_cycle,
                                                                                            'Qualification_poweron_cycle'     => $qualification_poweron_cycle,
                                                                                            'DecodedGeneralStatus'            => $Default_GeneralStatus_href,
                                                                                            'ASIC_Temperature'                => $masterASICTemp_FirstQuali_InterNonErasble,
                                                                                            'QualificationTime'               => $qualiTime_FirstQuali,
                                                                                      };
    }
    return 1;
}

sub _RemoveFault_AfterRequalify
{
    my $fault_number=1;
    if (defined $tcpar_External_fault_name)
    {
        S_teststep_2nd_level("Remove '$tcpar_External_fault_name', wait for dequalification time", 'AUTO_NBR');
        FM_removeFault($tcpar_External_fault_name);
        #expected result for PFM
        $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($tcpar_External_fault_name,'REMOVE_FAULT_CONDITION')        if ($tcpar_fault_monitoring_type eq 'cyclic');
        $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($tcpar_External_fault_name,'RESET_AFTER_FAULT_REMOVAL')     if ($tcpar_fault_monitoring_type eq 'init');
        $expectedFaults_primary_RemoveAfterRequaliFirstTime -> {'mandatory'} -> {$tcpar_External_fault_name} = {
                                                                                            'FaultName'     => $tcpar_External_fault_name,
                                                                                            'DecodedStatus' => $expected_primary_DecodedStatus_href,
                                                                                          };
        #expected result for BFM
		$qualiTime_FirstQuali        = $detectedValue_bosch_QualiFirstTime_href->{'External_Fault'}->{'QualificationTime'};  
        $expectedFaults_bosch_RemoveAfterRequaliFirstTime -> {'mandatory'} -> {$tcpar_External_fault_name} = {
                                                                                            'FaultName'                       => $tcpar_External_fault_name,
                                                                                            'OccurrenceCounter'               => 2,
                                                                                            'Dequalification_poweron_cycle'   => $dequalification_poweron_cycle,
                                                                                            'Qualification_poweron_cycle'     => $qualification_poweron_cycle,
                                                                                            'DecodedGeneralStatus'            => $Default_GeneralStatus_href,
                                                                                            'ASIC_Temperature'                => $masterASICTemp_FirstQuali,
                                                                                            'QualificationTime'               => $qualiTime_FirstQuali,
                                                                                        };
        # DeQuali time needs addtional evaluation
        $expectedValue_bosch_RemoveAfterRequaliFirstTime_href -> {'External_Fault'}->{'DequalificationTime'} = $OperatingTime_RequaliFirstTimeValue + $FaultDequaliTime_Extenal;
        if ($tcpar_External_fault_name=~m/Crosscoupling/i)
        {
            $fault_number++;
             #expected result for PFM
            $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($CC_flt,'REMOVE_FAULT_CONDITION')        if ($tcpar_fault_monitoring_type eq 'cyclic');
            $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($CC_flt,'RESET_AFTER_FAULT_REMOVAL')     if ($tcpar_fault_monitoring_type eq 'init');
            $expectedFaults_primary_RemoveAfterRequaliFirstTime -> {'mandatory'} -> {$CC_flt} = {
                                                                                                'FaultName'     => $CC_flt,
                                                                                                'DecodedStatus' => $expected_primary_DecodedStatus_href,
                                                                                            };
            #expected result for BFM
			$qualiTime_FirstQuali        = $detectedValue_bosch_QualiFirstTime_href->{'External_Fault_CC'}->{'QualificationTime'};
            $expectedFaults_bosch_RemoveAfterRequaliFirstTime -> {'mandatory'} -> {$CC_flt} = {
                                                                                                'FaultName'                       => $CC_flt,
                                                                                                'OccurrenceCounter'               => 2,
                                                                                                'Dequalification_poweron_cycle'   => $dequalification_poweron_cycle,
                                                                                                'Qualification_poweron_cycle'     => $qualification_poweron_cycle,
                                                                                                'DecodedGeneralStatus'            => $Default_GeneralStatus_href,
                                                                                                'ASIC_Temperature'                => $masterASICTemp_FirstQuali_CC,
                                                                                                'QualificationTime'               => $qualiTime_FirstQuali,
                                                                                            };
           # DeQuali time needs addtional evaluation
            $expectedValue_bosch_RemoveAfterRequaliFirstTime_href -> {'External_Fault_CC'}->{'DequalificationTime'} = $OperatingTime_RequaliFirstTimeValue + $FaultDequaliTime_Extenal_CC;
        }
    }
    if (defined $tcpar_Internal_erasable_fault_name)
    {
        $fault_number++;
        S_teststep_2nd_level("Remove '$tcpar_Internal_erasable_fault_name'", 'AUTO_NBR');
        FM_removeFault($tcpar_Internal_erasable_fault_name);
        #expected result for PFM
        $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($tcpar_Internal_erasable_fault_name,'REMOVE_FAULT_CONDITION')        if ($tcpar_fault_monitoring_type eq 'cyclic');
        $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($tcpar_Internal_erasable_fault_name,'RESET_AFTER_FAULT_REMOVAL')     if ($tcpar_fault_monitoring_type eq 'init');
        $expectedFaults_primary_RemoveAfterRequaliFirstTime -> {'mandatory'} -> {$tcpar_Internal_erasable_fault_name} = {
                                                                                                'FaultName'     => $tcpar_Internal_erasable_fault_name,
                                                                                                'DecodedStatus' => $expected_primary_DecodedStatus_href,
                                                                                            };
        #expected result for BFM
		$qualiTime_FirstQuali        = $detectedValue_bosch_QualiFirstTime_href->{'InternalEraseble_Fault'}->{'QualificationTime'};
        $expectedFaults_bosch_RemoveAfterRequaliFirstTime -> {'mandatory'} -> {$tcpar_Internal_erasable_fault_name} = {
                                                                                            'FaultName'                       => $tcpar_Internal_erasable_fault_name,
                                                                                            'OccurrenceCounter'               => 2,
                                                                                            'Dequalification_poweron_cycle'   => $dequalification_poweron_cycle,
                                                                                            'Qualification_poweron_cycle'     => $qualification_poweron_cycle,
                                                                                            'DecodedGeneralStatus'            => $Default_GeneralStatus_href,
                                                                                            'ASIC_Temperature'                => $masterASICTemp_FirstQuali_InterErasbale,
                                                                                            'QualificationTime'               => $qualiTime_FirstQuali,
                                                                                        };
        # DeQuali time needs addtional evaluation
        $expectedValue_bosch_RemoveAfterRequaliFirstTime_href -> {'InternalEraseble_Fault'}->{'DequalificationTime'} = $OperatingTime_RequaliFirstTimeValue + $FaultDequaliTime_InternalErasble;
    }
    if (defined $tcpar_Internal_non_erasable_fault_name )
    {
        $fault_number++;
        S_teststep_2nd_level("Remove '$tcpar_Internal_non_erasable_fault_name'", 'AUTO_NBR');
        FM_removeFault($tcpar_Internal_non_erasable_fault_name);
         #expected result for PFM
        $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($tcpar_Internal_non_erasable_fault_name,'REMOVE_FAULT_CONDITION')        if ($tcpar_fault_monitoring_type eq 'cyclic');
        $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($tcpar_Internal_non_erasable_fault_name,'RESET_AFTER_FAULT_REMOVAL')    if ($tcpar_fault_monitoring_type eq 'init');
        $expectedFaults_primary_RemoveAfterRequaliFirstTime -> {'mandatory'} -> {$tcpar_Internal_non_erasable_fault_name} = {
                                                                                                'FaultName'     => $tcpar_Internal_non_erasable_fault_name,
                                                                                                'DecodedStatus' => $expected_primary_DecodedStatus_href,
                                                                                        };
        #expected result for BFM
		$qualiTime_FirstQuali        = $detectedValue_bosch_QualiFirstTime_href->{'InternalNonEraseble_Fault'}->{'QualificationTime'};
        $expectedFaults_bosch_RemoveAfterRequaliFirstTime -> {'mandatory'} -> {$tcpar_Internal_non_erasable_fault_name} = {
                                                                                            'FaultName'                       => $tcpar_Internal_non_erasable_fault_name,
                                                                                            'OccurrenceCounter'               => 2,
                                                                                            'Dequalification_poweron_cycle'   => $dequalification_poweron_cycle,
                                                                                            'Qualification_poweron_cycle'     => $qualification_poweron_cycle,
                                                                                             'DecodedGeneralStatus'           => $Default_GeneralStatus_href,
                                                                                            'ASIC_Temperature'                => $masterASICTemp_FirstQuali_InterNonErasble,
                                                                                            'QualificationTime'               => $qualiTime_FirstQuali,
                                                                                        };
        # DeQuali time needs addtional evaluation
        $expectedValue_bosch_RemoveAfterRequaliFirstTime_href -> {'InternalNonEraseble_Fault'}->{'DequalificationTime'} = $OperatingTime_RequaliFirstTimeValue + $FaultDequaliTime_InternalNonErasble;
    }
    return 1;
}

sub _RecreateFaults_AfterErasingbyPD
{
    my $fault_number=1;
    if (defined $tcpar_External_fault_name && $tcpar_External_fault_name ne '')
    {
        S_teststep_2nd_level("Create '$tcpar_External_fault_name' with '$tcpar_fault_monitoring_type'", 'AUTO_NBR');
        FM_createFault($tcpar_External_fault_name);
        #expected result for PFM
        $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($tcpar_External_fault_name,'CREATE_FAULT_CONDITION')     if ($tcpar_fault_monitoring_type eq 'cyclic');
        $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($tcpar_External_fault_name,'RESET_AFTER_FAULT_CREATION') if ($tcpar_fault_monitoring_type eq 'init');
        $expectedFaults_primary_RequaliAfterErasingFaultsByPD -> {'mandatory'} -> {$tcpar_External_fault_name} = {
                                                                                            'FaultName'     => $tcpar_External_fault_name,
                                                                                            'DecodedStatus' => $expected_primary_DecodedStatus_href,
                                                                                        };
        #expected result for BFM
        $expectedFaults_bosch_RequaliAfterErasingFaultsByPD -> {'mandatory'} -> {$tcpar_External_fault_name} = {
                                                                                            'FaultName'                       => $tcpar_External_fault_name,
                                                                                            'OccurrenceCounter'               => 1,
                                                                                            'DequalificationTime'             => 0,
                                                                                            'Dequalification_poweron_cycle'   => 0,
                                                                                            'Qualification_poweron_cycle'     => $qualification_poweron_cycle,
                                                                                            'DecodedGeneralStatus'            => $Default_GeneralStatus_href,
                                                                                      };
        # Quali time and Master ASIC temperature needs addtional evaluation
        $expectedValue_bosch_RequaliAfterErasingFaultsByPD_href -> {'External_Fault'}->{'QualificationTime'} = $OperatingTime_ErasingFaultValue + $FaultQualiTime_Extenal;
        $expectedValue_bosch_RequaliAfterErasingFaultsByPD_href -> {'External_Fault'}->{'ASIC_Temperature'}  = $MasterASICTemp_ErasingFaultValue;

        # Crosscoupling fault can cause several defects
        if ($tcpar_External_fault_name=~m/Crosscoupling/i)
        {
            $fault_number++;
            #expected result for PFM
            $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($CC_flt,'CREATE_FAULT_CONDITION')     if ($tcpar_fault_monitoring_type eq 'cyclic');
            $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($CC_flt,'RESET_AFTER_FAULT_CREATION') if ($tcpar_fault_monitoring_type eq 'init');
            $expectedFaults_primary_RequaliAfterErasingFaultsByPD -> {'mandatory'} -> {$CC_flt} = {
                                                                                            'FaultName' => $CC_flt,
                                                                                            'DecodedStatus' => $expected_primary_DecodedStatus_href,
                                                                                            };
            #expected result for BFM;
            $expectedFaults_bosch_RequaliAfterErasingFaultsByPD -> {'mandatory'} -> {$CC_flt} = {
                                                                                            'FaultName'                       => $CC_flt,
                                                                                            'OccurrenceCounter'               => 1,
                                                                                            'DequalificationTime'             => 0,
                                                                                            'Dequalification_poweron_cycle'   => 0,
                                                                                            'Qualification_poweron_cycle'     => $qualification_poweron_cycle,
                                                                                            'DecodedGeneralStatus'            => $Default_GeneralStatus_href,
                                                                            };
        # Quali time and Master ASIC temperature needs addtional evaluation
        $expectedValue_bosch_RequaliAfterErasingFaultsByPD_href -> {'External_Fault_CC'}->{'QualificationTime'} = $OperatingTime_ErasingFaultValue + $CC_flt;
        $expectedValue_bosch_RequaliAfterErasingFaultsByPD_href -> {'External_Fault_CC'}->{'ASIC_Temperature'}  = $MasterASICTemp_ErasingFaultValue;
        }# crosscouploing fault
    }
    if (defined $tcpar_Internal_erasable_fault_name)
    {
        $fault_number++;
         S_teststep_2nd_level("Create '$tcpar_Internal_erasable_fault_name' with '$tcpar_fault_monitoring_type'", 'AUTO_NBR');
         FM_createFault($tcpar_Internal_erasable_fault_name);
         #expected result for PFM
         $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($tcpar_Internal_erasable_fault_name,'CREATE_FAULT_CONDITION')     if ($tcpar_fault_monitoring_type eq 'cyclic');
         $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($tcpar_Internal_erasable_fault_name,'RESET_AFTER_FAULT_CREATION') if ($tcpar_fault_monitoring_type eq 'init');
         $expectedFaults_primary_RequaliAfterErasingFaultsByPD -> {'mandatory'} -> {$tcpar_Internal_erasable_fault_name} = {
                                                                                            'FaultName'     => $tcpar_Internal_erasable_fault_name,
                                                                                            'DecodedStatus' => $expected_primary_DecodedStatus_href,
                                                                                        };
        #expected result for BFM
        $expectedFaults_bosch_RequaliAfterErasingFaultsByPD -> {'mandatory'} -> {$tcpar_Internal_erasable_fault_name} = {
                                                                                            'FaultName'                       => $tcpar_Internal_erasable_fault_name,
                                                                                            'OccurrenceCounter'               => 1,
                                                                                            'DequalificationTime'             => 0,
                                                                                            'Dequalification_poweron_cycle'   => 0,
                                                                                            'Qualification_poweron_cycle'     => $qualification_poweron_cycle,
                                                                                            'DecodedGeneralStatus'            => $Default_GeneralStatus_href,
                                                                                    };
        # Quali time and Master ASIC temperature needs addtional evaluation
        $expectedValue_bosch_RequaliAfterErasingFaultsByPD_href -> {'InternalEraseble_Fault'}->{'QualificationTime'} = $OperatingTime_ErasingFaultValue + $tcpar_Internal_erasable_fault_name;
        $expectedValue_bosch_RequaliAfterErasingFaultsByPD_href -> {'InternalEraseble_Fault'}->{'ASIC_Temperature'}  = $MasterASICTemp_ErasingFaultValue;
    }
    if (defined $tcpar_Internal_non_erasable_fault_name && $tcpar_Internal_non_erasable_fault_name ne '')
    {
        $fault_number++;
        S_teststep_2nd_level("Create '$tcpar_Internal_non_erasable_fault_name' with '$tcpar_fault_monitoring_type'", 'AUTO_NBR');
        FM_createFault($tcpar_Internal_non_erasable_fault_name);
         #expected result for PFM
        $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($tcpar_Internal_non_erasable_fault_name,'CREATE_FAULT_CONDITION')     if ($tcpar_fault_monitoring_type eq 'cyclic');
        $expected_primary_DecodedStatus_href = _Prepare_expected_DecodedStatus($tcpar_Internal_non_erasable_fault_name,'RESET_AFTER_FAULT_CREATION') if ($tcpar_fault_monitoring_type eq 'init');
        $expectedFaults_primary_RequaliAfterErasingFaultsByPD -> {'mandatory'} -> {$tcpar_Internal_non_erasable_fault_name} = {
                                                                                            'FaultName'     => $tcpar_Internal_non_erasable_fault_name,
                                                                                            'DecodedStatus' => $expected_primary_DecodedStatus_href,
        };
        #expected result for BFM
        $expectedFaults_bosch_RequaliAfterErasingFaultsByPD -> {'mandatory'} -> {$tcpar_Internal_non_erasable_fault_name} = {
                                                                                            'FaultName'                       => $tcpar_Internal_non_erasable_fault_name,
                                                                                            'OccurrenceCounter'               => 1,
                                                                                            'DequalificationTime'             => 0,
                                                                                            'Dequalification_poweron_cycle'   => 0,
                                                                                            'Qualification_poweron_cycle'     => $qualification_poweron_cycle,
                                                                                            'DecodedGeneralStatus'            => $Default_GeneralStatus_href,
                                                                                        };
        # Quali time and Master ASIC temperature needs addtional evaluation
        $expectedValue_bosch_RequaliAfterErasingFaultsByPD_href -> {'InternalNonEraseble_Fault'}->{'QualificationTime'} = $OperatingTime_ErasingFaultValue + $tcpar_Internal_non_erasable_fault_name;
        $expectedValue_bosch_RequaliAfterErasingFaultsByPD_href -> {'InternalNonEraseble_Fault'}->{'ASIC_Temperature'}  = $MasterASICTemp_ErasingFaultValue;
    }
    return 1;
}
1;
