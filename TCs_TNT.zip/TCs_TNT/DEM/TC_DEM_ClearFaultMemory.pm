#### TEST CASE MODULE
package TC_DEM_ClearFaultMemory;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.6 $;
our $HEADER = q$Header: DEM/TC_DEM_ClearFaultMemory.pm 1.6 2018/01/29 17:22:34ICT D Souza Deepthi Mariate (RBEI/ESA-PP3) (DDE3KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_evaluation;
use LIFT_PD;
use LIFT_labcar;
use LIFT_CANoe;
use LIFT_labcar;
use LIFT_DCOM;
use LIFT_equipment;
use GENERIC_DCOM;
use LIFT_can_access;
use LIFT_FaultMemory;
use INCLUDES_Project;
use File::Basename;
use Data::Dumper;

use Readonly;

# Maximum fault quali / dequali times
Readonly my $MAX_FAULT_QUALIFICATION_TIME_MS => 12000;
Readonly my $MAX_FAULT_DEQUALIFICATION_TIME_MS => 12000;

##################################

our $PURPOSE = "To check fault erasure using customer diagnosis on creating external and internal faults";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DEM_ClearFaultMemory

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1.Read PD variable <Erase_Counter> if applicable.

2.Create <External_fault_name> with <fault_monitoring_type>

3.Create <Internal_erasable_fault_name> with <fault_monitoring_type>

4.Create <Internal_non_erasable_fault_name> with <fault_monitoring_type>

5.Wait for qualification time of faults

6.Read Primary fault memory(PFM)

7.Erase PFM

8.Read PFM

9.Reset ECU

10.Read PFM

11.Remove <External_fault_name>, wait for dequalification time

12.Reset ECU

13.Read PFM

14.Erase PFM

15.Read PFM, BFM

16.Remove <Internal_erasable_fault_name>,<Internal_non_erasable_fault_name>

17.Reset ECU

18.Read PFM

19.Erase PFM

20.Read PFM,BFM

21. Erase PFM,BFM via PD

22.Read PD variable <Erase_Counter> if applicable.

23.Perform Step 2 to Step 22 till <Erase_Counter>=<Erase_Counter_Limit>

24.Create <Internal_erasable_fault_name>

25.Read PFM

26.Remove <Internal_erasable_fault_name>

27.Read PFM

28.Erase PFM

29.Erase PFM via PD


I<B<Evaluation>>

1.

2.

3.

4.

5.

6. All faults are in qualified state

7.

8. All CYCLIC faults and <Internal_non_erasable_fault_name>are in qualified state, All init faults are erased from fault memory.

9.

10. All faults are in qualified state

11.

12.

13. <External_fault_name> are in dequalified state, <Internal_erasable_fault_name>,<Internal_non_erasable_fault_name> faults if defined ,are in qualified state

14.

15. a.PFM,BFM is empty if there are no<Internal_erasable_fault_name>,<Internal_non_erasable_fault_name> faults.

b.<External_fault_name> are in dequalified state, <Internal_erasable_fault_name>,<Internal_non_erasable_fault_name> faults if defined ,are in qualified state in PFM,BFM

16.

17.

18.All faults are in dequalified state

19.

20.a.PFM is empty if there are no <Internal_non_erasable_fault_name> faults.

b.All faults are in dequalified state if<Internal_non_erasable_fault_name> faults are defined in PFM,BFM

c.BFM shall have internal erasable faults in dequalified state if defined <Internal_erasable_fault_name> .

21.All dequalified faults are erased.

22.

23.

24.

25.<Internal_erasable_fault_name> is in qualified state

26.

27.<Internal_erasable_fault_name> is in dequalified state

28.<Internal_erasable_fault_name> is in dequalified state

29.Fault memory is empty


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'External_fault_name' => 
	SCALAR 'fault_monitoring_type' => 
	SCALAR 'purpose' => 
	SCALAR 'Erase_Counter' => 
	SCALAR 'Erase_Counter_Limit' => 


=head2 PARAMETER EXAMPLES

	purpose	='To check fault erasure using customer diagnosis on creating external and internal faults'
	
	#Default parameters
	
	Erase_Counter=''
	Erase_Counter_Limit=''
	External_fault_name='rb_acc_ParameterLayoutIDInvalid_flt'
	fault_monitoring_type='Init'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Erase_Counter;
my $tcpar_Erase_Counter_Limit;
my $tcpar_External_fault_name;
my $tcpar_fault_monitoring_type;
my $tcpar_Internal_erasable_fault_name;
my $tcpar_Internal_non_erasable_fault_name;

################ global parameter declaration ###################
#add any global variables here
my ($CC_flt,$EraseCounter_InitialValue,$related_fault,$EraseCounter_CurrentValue,$expectedFaults_primary_afterQuali,$fault_mem_primary_afterQuali,$fault_mem_primary_afterErase,$expectedFaults_primary_afterErase,$fault_mem_primary_afterEraseReset);
my($fault_mem_primary_ExtFltRemoval,$expectedFaults_primary_ExtFltRemoval,$fault_mem_primary_ExtFltRemovalErase,$fault_mem_bosch_ExtFltRemovalErase,$expectedFaults_primary_ExtFltRemovalErase,$expectedFaults_bosch_ExtFltRemovalErase);
my($expectedFaults_primary_IntFltRemoval,$fault_mem_primary_IntFltRemoval,$fault_mem_bosch_IntFltRemovalErase,$expectedFaults_primary_IntFltRemovalErase,$expectedFaults_bosch_IntFltRemovalErase);
my ($fault_mem_primary_IntFltRemovalErase,$fault_mem_primary_ErasePD,$expectedFaults_primary_ErasePD,$fault_mem_primary_EqualEraseCntr,$fault_mem_primary_ExceedEraseCntr,$expectedFaults_primary_EqualEraseCntr,$expectedFaults_primary_ExceedEraseCntr);
my $FM_Device = 'Device';
###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_Erase_Counter =  S_read_optional_testcase_parameter( 'Erase_Counter' );
	$tcpar_Erase_Counter_Limit =  S_read_optional_testcase_parameter( 'Erase_Counter_Limit' );
	$tcpar_External_fault_name =  S_read_optional_testcase_parameter( 'External_fault_name' );
	$tcpar_Internal_erasable_fault_name =  S_read_optional_testcase_parameter( 'Internal_erasable_fault_name' );
	$tcpar_Internal_non_erasable_fault_name =  S_read_optional_testcase_parameter( 'Internal_non_erasable_fault_name' );
	$tcpar_fault_monitoring_type =  S_read_mandatory_testcase_parameter( 'fault_monitoring_type' );

	return 1;
}

sub TC_initialization {

	S_teststep("StandardPrepNoFault", 'AUTO_NBR');
	GEN_StandardPrepNoFault();

	S_w2log(1, "Power on ECU");
    LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

    S_w2log(1, "Initialize CD and start CAN trace");
    GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start ();

	S_w2log(1, "Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	S_w2log(1, "Read and evaluate fault memory before stimulation");

	my $faultsBeforeStimulation = LIFT_FaultMemory -> read_fault_memory('Primary');
	my $faultsVerdict=$faultsBeforeStimulation->evaluate_faults({});   #Fault memory must be empty

    return 0 if ($faultsVerdict eq 'VERDICT_FAIL');

	return 1;
}

sub TC_stimulation_and_measurement {

    # READ ERASE COUNTER
	if (defined $tcpar_Erase_Counter){
		S_teststep("Read PD variable '$tcpar_Erase_Counter'", 'AUTO_NBR');
		$EraseCounter_InitialValue = S_aref2dec(PD_ReadMemoryByName($tcpar_Erase_Counter),'U8');
	}


  # ---- CREATE FAULTS ---

    # External Faults
	if (defined $tcpar_External_fault_name){
		S_teststep("Create '$tcpar_External_fault_name' with '$tcpar_fault_monitoring_type'", 'AUTO_NBR');
		FM_createFault($tcpar_External_fault_name);

		$expectedFaults_primary_afterQuali -> {'mandatory'} -> {$tcpar_External_fault_name} = {'DecodedStatus' => {'TestFailed' => 1},};

		if ($tcpar_External_fault_name=~m/Crosscoupling/i){
			$CC_flt = _getCrosscoupledFault($tcpar_External_fault_name);
			$expectedFaults_primary_afterQuali -> {'mandatory'} -> {$CC_flt} = {'DecodedStatus' => {'TestFailed' => 1},};
		}
	}

    # Internal erasable faults
	if (defined $tcpar_Internal_erasable_fault_name){
		S_teststep("Create '$tcpar_Internal_erasable_fault_name' with '$tcpar_fault_monitoring_type'", 'AUTO_NBR');
		FM_createFault($tcpar_Internal_erasable_fault_name);
		$expectedFaults_primary_afterQuali -> {'mandatory'} -> {$tcpar_Internal_erasable_fault_name} = {'DecodedStatus' => {'TestFailed' => 1},};
		if ($tcpar_Internal_erasable_fault_name  =~ m/LowsidePowerstage/i) {
			my $faultproperty = FM_fetchFaultInfo($tcpar_Internal_erasable_fault_name);
			my $device    = $faultproperty->{$FM_Device}; 
			$related_fault='rb_sqm_SquibResistanceOpen' . $device . '_flt';
			$expectedFaults_primary_afterQuali -> {'mandatory'} -> {$related_fault} = {'DecodedStatus' => {'TestFailed' => 1},};
		}
	}

    # internal non-erasable faults
	if (defined $tcpar_Internal_non_erasable_fault_name){
		S_teststep("Create '$tcpar_Internal_non_erasable_fault_name' with '$tcpar_fault_monitoring_type'", 'AUTO_NBR');
		FM_createFault($tcpar_Internal_non_erasable_fault_name);
		$expectedFaults_primary_afterQuali -> {'mandatory'} -> {$tcpar_Internal_non_erasable_fault_name} = {'DecodedStatus' => {'TestFailed' => 1},};
	}

    # Wait for fault qualification
    _trigger_quali_dequali_fault('Qualification');


  # --- READ FAULT MEMORY ---
	S_teststep("Read Primary fault memory(PFM)", 'AUTO_NBR', 'read_primary_fltmem_afterQuali'); #measurement 1
	$fault_mem_primary_afterQuali = LIFT_FaultMemory -> read_fault_memory('Primary');

  # --- ERASE FAULT MEMORY ---
	S_teststep("Erase PFM", 'AUTO_NBR');
	if (defined $tcpar_Internal_non_erasable_fault_name){
		DCOM_request ('14 FF FF FF', '7F 14 22', 'relax', 'erase fault memory with CD');
	}
	else{
		DCOM_request ('14 FF FF FF', '54', 'relax', 'erase fault memory with CD') ;
	}

	S_teststep("Wait for requalification of faults", 'AUTO_NBR');
	S_wait_ms($MAX_FAULT_QUALIFICATION_TIME_MS);

	S_teststep("Read PFM after erasure", 'AUTO_NBR', 'read_primary_fltmem_afterErase');    #measurement 2
	$fault_mem_primary_afterErase = LIFT_FaultMemory -> read_fault_memory('Primary');

	S_teststep("Reset ECU", 'AUTO_NBR');
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep("Read PFM after reset", 'AUTO_NBR', 'read_primary_fltmem_afterEraseReset'); #measurement 3
	$fault_mem_primary_afterEraseReset = LIFT_FaultMemory -> read_fault_memory('Primary');


  # --- REMOVE FAULTS AND ERASE FAULT MEMORY ---

    # External faults
	if (defined $tcpar_External_fault_name){
	    S_teststep("Remove and erase external fault", 'AUTO_NBR');
        _remove_and_erase_external_faults();
	}

    # Internal faults
    if ((defined $tcpar_Internal_erasable_fault_name) or (defined $tcpar_Internal_non_erasable_fault_name)){
        S_teststep("Remove and erase internal faults", 'AUTO_NBR');      
    }

	if (defined $tcpar_Internal_erasable_fault_name){
		S_teststep_2nd_level("Remove '$tcpar_Internal_erasable_fault_name'", 'AUTO_NBR');
		FM_removeFault($tcpar_Internal_erasable_fault_name);
		$expectedFaults_primary_IntFltRemoval -> {'mandatory'} -> {$tcpar_Internal_erasable_fault_name} = {'DecodedStatus' => {'ConfirmedDTC' => 1,'TestFailed'=>0},};
		$expectedFaults_primary_IntFltRemoval -> {'mandatory'} -> {$related_fault} = {'DecodedStatus' => {'ConfirmedDTC' => 1,'TestFailed' => 0},} if ($tcpar_Internal_erasable_fault_name  =~ m/LowsidePowerstage/i);
	}

	if (defined $tcpar_Internal_non_erasable_fault_name ){
		S_teststep_2nd_level("Remove '$tcpar_Internal_non_erasable_fault_name'", 'AUTO_NBR');
		FM_removeFault($tcpar_Internal_non_erasable_fault_name);
		$expectedFaults_primary_IntFltRemoval -> {'mandatory'} -> {$tcpar_Internal_non_erasable_fault_name} = {'DecodedStatus' => {'ConfirmedDTC' => 1,'TestFailed'=>0},};
	}

	if ((defined $tcpar_Internal_erasable_fault_name) or (defined $tcpar_Internal_non_erasable_fault_name)){

        _trigger_quali_dequali_fault('Dequalification');       
        _erase_internal_faults();
	}

	S_teststep("Erase PFM,BFM via PD", 'AUTO_NBR','clear_via_PD'); #measurement 10
	PD_ClearFaultMemory();
	S_wait_ms(6000);
	$fault_mem_primary_ErasePD = LIFT_FaultMemory -> read_fault_memory('Primary');
	$expectedFaults_primary_ErasePD = {};

	if ((defined $tcpar_Erase_Counter) and (defined $tcpar_Internal_erasable_fault_name))
	{
		S_teststep("Read PD variable '$tcpar_Erase_Counter'", 'AUTO_NBR');
		$EraseCounter_CurrentValue = S_aref2dec(PD_ReadMemoryByName($tcpar_Erase_Counter),'U8');

		S_teststep_2nd_level ("Perform Step 2 to Step 22 till '$tcpar_Erase_Counter'='$tcpar_Erase_Counter_Limit'", 'AUTO_NBR');

		foreach my $numberOfInternalFaultErasures (2..$tcpar_Erase_Counter_Limit + 1)
		{
			S_teststep("Create '$tcpar_Internal_erasable_fault_name'", 'AUTO_NBR');
			FM_createFault($tcpar_Internal_erasable_fault_name);
            _trigger_quali_dequali_fault('Qualification');

			S_teststep("Read PFM after qualifying fault for $numberOfInternalFaultErasures times ", 'AUTO_NBR');
			LIFT_FaultMemory -> read_fault_memory('Primary');

			S_teststep("Remove '$tcpar_Internal_erasable_fault_name'", 'AUTO_NBR');
			FM_removeFault($tcpar_Internal_erasable_fault_name);
            _trigger_quali_dequali_fault('Dequalification');

			S_teststep("Read PFM after dequalifying fault for $numberOfInternalFaultErasures times", 'AUTO_NBR');
            LIFT_FaultMemory -> read_fault_memory('Primary');

			S_teststep("Erase PFM", 'AUTO_NBR');
            S_wait_ms(3000); #wait time after sending PD service before calling CD
    		DCOM_request ('14 FF FF FF', '54', 'relax', 'erase fault memory with CD');

			if ($numberOfInternalFaultErasures == $tcpar_Erase_Counter_Limit){
				S_teststep("Read PFM after erasing $tcpar_Erase_Counter_Limit time", 'read_pfm_erasecount_equal'); #measurement 11
				$fault_mem_primary_EqualEraseCntr = LIFT_FaultMemory -> read_fault_memory('Primary');
				$expectedFaults_primary_EqualEraseCntr ={};
			}
		}

		S_teststep("Read PFM after erasing $tcpar_Erase_Counter_Limit + 1 time", 'read_pfm_erasecounter_exceed'); #measurement 12
		$fault_mem_primary_ExceedEraseCntr = LIFT_FaultMemory -> read_fault_memory('Primary');
		$expectedFaults_primary_ExceedEraseCntr -> {'mandatory'} -> {$tcpar_Internal_erasable_fault_name} = {'DecodedStatus' => {'ConfirmedDTC' => 1,'TestFailed'=>0},};

		S_teststep("Erase PFM via PD", 'AUTO_NBR');
		PD_ClearFaultMemory();
		S_wait_ms(6000);
	}

	return 1;
}

sub TC_evaluation {


	$fault_mem_primary_afterQuali -> evaluate_faults($expectedFaults_primary_afterQuali,"read_primary_fltmem_afterQuali");  #evaluation 1 

	if (lc($tcpar_fault_monitoring_type) eq 'init' and (defined $tcpar_Internal_non_erasable_fault_name) )
	{
		$fault_mem_primary_afterErase -> evaluate_faults($expectedFaults_primary_afterQuali,"read_primary_fltmem_afterErase");   #evaluation 2
	}
	elsif (lc($tcpar_fault_monitoring_type) eq 'init'){
		$expectedFaults_primary_afterErase = {};
		$fault_mem_primary_afterErase -> evaluate_faults($expectedFaults_primary_afterErase,"read_primary_fltmem_afterErase");
	}
	elsif (lc($tcpar_fault_monitoring_type) eq 'cyclic') {
		$fault_mem_primary_afterErase -> evaluate_faults($expectedFaults_primary_afterQuali,"read_primary_fltmem_afterErase");
	}

	$fault_mem_primary_afterEraseReset -> evaluate_faults($expectedFaults_primary_afterQuali,"read_primary_fltmem_afterEraseReset"); #evaluation 3

	if (defined $tcpar_External_fault_name){

		$fault_mem_primary_ExtFltRemoval -> evaluate_faults($expectedFaults_primary_ExtFltRemoval,"read_primary_fltmem_ExtFltRemoval"); #evaluation 4

		$fault_mem_primary_ExtFltRemovalErase -> evaluate_faults($expectedFaults_primary_ExtFltRemovalErase,"read_primary_ExtFltRemovalErase"); #evaluation 5

		$fault_mem_bosch_ExtFltRemovalErase -> evaluate_faults($expectedFaults_bosch_ExtFltRemovalErase,"read_bosch_ExtFltRemovalErase"); #evaluation 6
	}

	if ((defined $tcpar_Internal_erasable_fault_name) or (defined $tcpar_Internal_non_erasable_fault_name)){

		$fault_mem_primary_IntFltRemoval -> evaluate_faults($expectedFaults_primary_IntFltRemoval,"read_primary_fltmem_IntFltRemoval"); #evaluation 7

		$fault_mem_primary_IntFltRemovalErase -> evaluate_faults($expectedFaults_primary_IntFltRemovalErase,"read_primary_IntFltRemovalErase"); #evaluation 8

		$fault_mem_bosch_IntFltRemovalErase -> evaluate_faults($expectedFaults_bosch_IntFltRemovalErase,"read_bosch_IntFltRemovalErase"); #evaluation 9
	}

	$fault_mem_primary_ErasePD -> evaluate_faults($expectedFaults_primary_ErasePD,"clear_via_PD"); #evaluation 10

	if ((defined $tcpar_Erase_Counter) and (defined $tcpar_Internal_erasable_fault_name)){

		$fault_mem_primary_EqualEraseCntr -> evaluate_faults($expectedFaults_primary_EqualEraseCntr,'read_pfm_erasecount_equal'); #evaluation 11

		$fault_mem_primary_ExceedEraseCntr -> evaluate_faults($expectedFaults_primary_ExceedEraseCntr,'read_pfm_erasecount_exceed'); #evaluation 12
	}

	return 1;
}

sub TC_finalization {

	# Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(6000);

	# Read fault memory after clearing and erasing EDR
    PD_ReadFaultMemory();
	S_wait_ms(2000);

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

	return 1;
}


sub _getCrosscoupledFault{

	my $fltname    = shift;
    my ($crosscoupled_device,$SearchCondition_href,$matchedfaults_aref);
	my @devices;

	my $faultproperty = FM_fetchFaultInfo($fltname);      #get the type from Fault mapping file
	my $condition = $faultproperty->{'Condition'};
	my $device    = $faultproperty->{'Device'};
	my $devicetype = $faultproperty->{'DeviceType'};
	my $DeviceMapping = S_get_contents_of_hash(['Mapping_DEVICE']);
	my $TestHW        = $LIFT_config::LIFT_Testbench->{'Functions'}{'PERIPHERIE'}{'device'};

	if ( $devicetype =~ m/Switch/i ) {
		@devices = LC_Get_names('SWITCHES')    if ( $TestHW eq ('MLC' or 'LabCar'));
		@devices = LC_Get_names('BELT_LOCKS') if ( $TestHW eq 'TSG4' );
	}
	elsif ( $devicetype =~ m/Squib/i ) {
		@devices = LC_Get_names('SQUIBS');
	}
	elsif ( $devicetype =~ m/PAS/i ) {
		@devices = LC_Get_names('PAS')        if ( $TestHW eq ('MLC' or 'LabCar'));
		@devices = LC_Get_names('PAS_LINES') if ( $TestHW eq 'TSG4' );
	}

	if ( $device eq $devices[0] ) {
		$crosscoupled_device= $devices[1];
	}
	else {
		$crosscoupled_device= $devices[0];
	}

	$SearchCondition_href->{'Device'} = $crosscoupled_device;
	$SearchCondition_href->{'Condition'} = $condition;
	$matchedfaults_aref = FM_fetchFaultName($SearchCondition_href);

	return  ${$matchedfaults_aref}[0];
}


sub _remove_and_erase_external_faults {
    
    S_teststep_2nd_level("Remove '$tcpar_External_fault_name', wait for dequalification time", 'AUTO_NBR');
    FM_removeFault($tcpar_External_fault_name);
    _trigger_quali_dequali_fault('Dequalification');

    S_teststep_2nd_level("Read PFM after external fault removal", 'AUTO_NBR', 'read_primary_fltmem_ExtFltRemoval'); #measurement 4
    $fault_mem_primary_ExtFltRemoval = LIFT_FaultMemory -> read_fault_memory('Primary');
    $expectedFaults_primary_ExtFltRemoval -> {'mandatory'} -> {$tcpar_External_fault_name} = {'DecodedStatus' => {'TestFailed' => 0},};
    if ($tcpar_External_fault_name=~m/Crosscoupling/i){
        $expectedFaults_primary_ExtFltRemoval -> {'mandatory'} -> {$CC_flt} = {'DecodedStatus' => {'TestFailed' => 0},};
    }
    if (defined $tcpar_Internal_erasable_fault_name){
        $expectedFaults_primary_ExtFltRemoval -> {'mandatory'} -> {$tcpar_Internal_erasable_fault_name} = {'DecodedStatus' => {'TestFailed' => 1},};
    }
    if (defined $tcpar_Internal_non_erasable_fault_name){
        $expectedFaults_primary_ExtFltRemoval -> {'mandatory'} -> {$tcpar_Internal_non_erasable_fault_name} = {'DecodedStatus' => {'TestFailed' => 1},};
    }

    S_teststep_2nd_level("Erase PFM after external fault removal", 'AUTO_NBR');
    if (defined $tcpar_Internal_non_erasable_fault_name){
        DCOM_request ('14 FF FF FF', '7F 14 22', 'relax', 'erase fault memory with CD');
    }
    else{
        DCOM_request ('14 FF FF FF', '54', 'relax', 'erase fault memory with CD') ;
    }

    S_teststep_2nd_level("Read PFM after fault erasure", 'AUTO_NBR', 'read_primary_ExtFltRemovalErase'); #measurement 5

    $fault_mem_primary_ExtFltRemovalErase = LIFT_FaultMemory -> read_fault_memory('Primary');

    S_teststep_2nd_level("Read BFM after fault erasure", 'AUTO_NBR', 'read_bosch_ExtFltRemovalErase'); #measurement 6
    $fault_mem_bosch_ExtFltRemovalErase = LIFT_FaultMemory -> read_fault_memory('Bosch');
    $expectedFaults_primary_ExtFltRemovalErase={};
    $expectedFaults_bosch_ExtFltRemovalErase={};

    if (defined $tcpar_Internal_erasable_fault_name){
        $expectedFaults_primary_ExtFltRemovalErase -> {'mandatory'} -> {$tcpar_External_fault_name} = {'DecodedStatus' => {'ConfirmedDTC' => 1,'TestFailed'=>0},};
        $expectedFaults_primary_ExtFltRemovalErase -> {'mandatory'} -> {$tcpar_Internal_erasable_fault_name} = {'DecodedStatus' => {'ConfirmedDTC' => 1,'TestFailed'=>1},};
        $expectedFaults_primary_ExtFltRemovalErase -> {'mandatory'} -> {$CC_flt} = {'DecodedStatus' => {'ConfirmedDTC' => 1,'TestFailed'=>0},} if ($tcpar_External_fault_name=~m/Crosscoupling/i);
        $expectedFaults_bosch_ExtFltRemovalErase -> {'mandatory'} -> {$tcpar_External_fault_name} = {'DecodedStatus' => {'TestFailed'=>0},};
        $expectedFaults_bosch_ExtFltRemovalErase -> {'mandatory'} -> {$tcpar_Internal_erasable_fault_name} = {'DecodedStatus' => {'TestFailed'=>1},};
        $expectedFaults_bosch_ExtFltRemovalErase -> {'mandatory'} -> {$CC_flt} = {'DecodedStatus' => {'TestFailed'=>0},}if ($tcpar_External_fault_name=~m/Crosscoupling/i);
    }
    if (defined $tcpar_Internal_non_erasable_fault_name){
        $expectedFaults_primary_ExtFltRemovalErase -> {'mandatory'} -> {$tcpar_External_fault_name} = {'DecodedStatus' => {'ConfirmedDTC' => 1,'TestFailed'=>0},};
        $expectedFaults_primary_ExtFltRemovalErase -> {'mandatory'} -> {$tcpar_Internal_non_erasable_fault_name} = {'DecodedStatus' => {'ConfirmedDTC' => 1,'TestFailed'=>1},};
        $expectedFaults_primary_ExtFltRemovalErase -> {'mandatory'} -> {$CC_flt} = {'DecodedStatus' => {'ConfirmedDTC' => 1,'TestFailed'=>0},} if ($tcpar_External_fault_name=~m/Crosscoupling/i);
        $expectedFaults_bosch_ExtFltRemovalErase -> {'mandatory'} -> {$tcpar_External_fault_name} = {'DecodedStatus' => {'TestFailed'=>0},};
        $expectedFaults_bosch_ExtFltRemovalErase -> {'mandatory'} -> {$tcpar_Internal_non_erasable_fault_name} = {'DecodedStatus' => {'TestFailed'=>1},};
        $expectedFaults_bosch_ExtFltRemovalErase -> {'mandatory'} -> {$CC_flt} = {'DecodedStatus' => {'TestFailed'=>0},}if ($tcpar_External_fault_name=~m/Crosscoupling/i);
    }
    
    return 1;
}

sub _erase_internal_faults {

    S_teststep_2nd_level("Read PFM after internal faults removal", 'AUTO_NBR', 'read_primary_fltmem_IntFltRemoval'); #measurement 7
    $fault_mem_primary_IntFltRemoval = LIFT_FaultMemory -> read_fault_memory('Primary');
    if (defined $tcpar_External_fault_name){
        $expectedFaults_primary_IntFltRemoval -> {'mandatory'} -> {$tcpar_External_fault_name} = {'DecodedStatus' => {'ConfirmedDTC' => 1,'TestFailed'=>0},};
        $expectedFaults_bosch_IntFltRemovalErase-> {'mandatory'} -> {$tcpar_External_fault_name} = {'DecodedStatus' => {'TestFailed'=>0},};
    }
    if (defined $tcpar_External_fault_name and ($tcpar_External_fault_name=~m/Crosscoupling/i)){
        $expectedFaults_primary_IntFltRemoval -> {'mandatory'} -> {$CC_flt} = {'DecodedStatus' => {'ConfirmedDTC' => 1,'TestFailed'=>0},};
        $expectedFaults_bosch_IntFltRemovalErase -> {'mandatory'} -> {$CC_flt} = {'DecodedStatus' => {'TestFailed'=>0},};
    }

    S_teststep_2nd_level("Erase PFM after internal faults removal", 'AUTO_NBR');
    if (defined $tcpar_Internal_non_erasable_fault_name){
        DCOM_request ('14 FF FF FF', '7F 14 22', 'relax', 'erase fault memory with CD');
    }
    else{
        DCOM_request ('14 FF FF FF', '54', 'relax', 'erase fault memory with CD') ;
    }

    S_teststep_2nd_level("Read PFM after fault erasure", 'AUTO_NBR', 'read_primary_IntFltRemovalErase'); #measurement 8
    $fault_mem_primary_IntFltRemovalErase = LIFT_FaultMemory -> read_fault_memory('Primary');
    $expectedFaults_primary_IntFltRemovalErase={};
    if (defined $tcpar_Internal_non_erasable_fault_name){
        $expectedFaults_primary_IntFltRemovalErase -> {'mandatory'} -> {$tcpar_External_fault_name} = {'DecodedStatus' => {'ConfirmedDTC' => 1,'TestFailed'=>0},} if (defined $tcpar_External_fault_name);
        $expectedFaults_primary_IntFltRemovalErase -> {'mandatory'} -> {$tcpar_Internal_erasable_fault_name} = {'DecodedStatus' => {'ConfirmedDTC' => 1,'TestFailed'=>0},}if (defined $tcpar_Internal_erasable_fault_name);
        $expectedFaults_primary_IntFltRemovalErase -> {'mandatory'} -> {$tcpar_Internal_non_erasable_fault_name} = {'DecodedStatus' => {'ConfirmedDTC' => 1,'TestFailed'=>0},};
        $expectedFaults_primary_IntFltRemovalErase -> {'mandatory'} -> {$CC_flt} = {'DecodedStatus' => {'ConfirmedDTC' => 1,'TestFailed'=>0},} if (defined $tcpar_External_fault_name and ($tcpar_External_fault_name=~m/Crosscoupling/i));
    }

    S_teststep_2nd_level("Read BFM after fault erasure", 'AUTO_NBR', 'read_bosch_IntFltRemovalErase'); #measurement 9
    $fault_mem_bosch_IntFltRemovalErase = LIFT_FaultMemory -> read_fault_memory('Bosch');
    if (defined $tcpar_Internal_erasable_fault_name){
        $expectedFaults_bosch_IntFltRemovalErase-> {'mandatory'} -> {2} = {'FaultName' => $tcpar_Internal_erasable_fault_name,'DecodedStatus' => {'TestFailed'=>0},};
    }

    if (defined $tcpar_Internal_non_erasable_fault_name){
        $expectedFaults_bosch_IntFltRemovalErase -> {'mandatory'} -> {$tcpar_External_fault_name} = {'DecodedStatus' => {'TestFailed'=>0},} if (defined $tcpar_External_fault_name);
        $expectedFaults_bosch_IntFltRemovalErase -> {'mandatory'} -> {$tcpar_Internal_erasable_fault_name} = {'DecodedStatus' => {'TestFailed'=>0},}if (defined $tcpar_Internal_erasable_fault_name);
        $expectedFaults_bosch_IntFltRemovalErase -> {'mandatory'} -> {$tcpar_Internal_non_erasable_fault_name} = {'DecodedStatus' => {'TestFailed'=>0},};
        $expectedFaults_bosch_IntFltRemovalErase -> {'mandatory'} -> {$CC_flt} = {'DecodedStatus' => {'TestFailed'=>0},} if (defined $tcpar_External_fault_name and ($tcpar_External_fault_name=~m/Crosscoupling/i));
    }
    
    return 1;
}

sub _trigger_quali_dequali_fault{
    my $triggerType = shift;

    if (lc($tcpar_fault_monitoring_type) eq 'init'){
        S_teststep_2nd_level("Reset ECU", 'AUTO_NBR');
        LC_ECU_Off();
        S_wait_ms('TIMER_ECU_OFF');
        LC_ECU_On();
        S_wait_ms('TIMER_ECU_READY');
    }
    else {
        S_teststep_2nd_level("Wait for $triggerType time of fault", 'AUTO_NBR');
        S_wait_ms($MAX_FAULT_DEQUALIFICATION_TIME_MS) if($triggerType eq 'Dequalification');
        S_wait_ms($MAX_FAULT_QUALIFICATION_TIME_MS) if($triggerType eq 'Qualification');
    }
    
    return 1;
    
}

1;
