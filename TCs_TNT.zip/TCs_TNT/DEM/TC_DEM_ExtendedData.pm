#### TEST CASE MODULE
package TC_DEM_ExtendedData;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.3 $;
our $HEADER  = q$Header: DEM/TC_DEM_ExtendedData.pm 1.3 2018/04/05 15:57:26ICT D Souza Deepthi Mariate (RBEI/ESA-PP3) (DDE3KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_evaluation;
use LIFT_PD;
use LIFT_labcar;
use LIFT_DCOM;
use LIFT_equipment;
use FuncLib_SYC_INTERFACE;
use LIFT_FaultMemory;
use INCLUDES_Project;
use LIFT_NET_access;
use File::Basename;
use Data::Dumper;
use Readonly;

# Maximum fault quali / dequali times
Readonly my $MAX_FAULT_QUALIFICATION_TIME_MS   => 32000;
Readonly my $MAX_FAULT_DEQUALIFICATION_TIME_MS => 32000;

##################################

our $PURPOSE = "To check extended record for all faults through customer diagnosis";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DEM_ExtendedData

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1.Stimulate all the required extended data.
<ExtendedData_FirstTimeQuali>

2.Create <External_fault_name> 

3.Create <Internal_erasable_fault_name>
 
4.Create <Internal_non_erasable_fault_name>

5.Wait for qualification time of faults

6.Read Primary fault memory(PFM)

7.Read extended data via CD

8.Reset ECU

9.Read extended data via CD

10.Stimulate all the required extended data.
<ExtendedData_FirstTimeDequali>

11.Remove <External_fault_name>

12.Remove <Internal_erasable_fault_name>,<Internal_non_erasable_fault_name>, wait for dequalification time, perform ECU reset

13.Read PFM

14.Read extended data via CD

15.Stimulate all the required extended data with different values
<ExtendedData_SecondTimeQuali>.

16.Recreate faults from step 2 to step 4.

17.Create <additional_fault> with DTC identical to any one of the faults created in step 16.

18.Read PFM

19.Read extended data via CD

20.Remove all the faults

21.Erase PFM via CD

22.Read DTC status bits via CD

23.Erase PFM via PD


I<B<Evaluation>>

1.

2.

3.

4.

5.

6. All faults are in qualified state

7. All the stimulated extended data in step 1 should be reported for every fault created.

8. 

9.All the stimulated extended data in step 1 should be reported for every fault created.

10.
 
11.

12.
 
13.All faults are in dequalified state

14.All the stimulated extended data in step 1 should be reported for every fault created.

16.

17.

18.All faults are in qualified state

19.All the stimulated extended data in step 15 should be reported for  <External_fault_name><Internal_erasable_fault_name>,<Internal_non_erasable_fault_name>,
<additional_fault> except for the fault with DTC similar to <additional_fault>

20.

21.

22.a.DTC status bits are cleared  for <External_fault_name>,<Internal_erasable_fault_name>,<additional_fault>  if there are no <Internal_non_erasable_fault_name> faults.
b.DTC status bits are NOT cleared for any fault if<Internal_non_erasable_fault_name> faults are defined in PFM

23.

I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

    SCALAR 'External_fault_name' => External fault to be created/qualified
    HASH 'ExtendedData_FirstTimeQuali' => Extended data to be stimulated before first time fault qualification
    HASH 'ExtendedData_ReQuali' => Extended data to be stimulated before fault requalification
    SCALAR 'additional_fault' => Another fault to be qualified (depending on testcase , this fault has DTC identical/non identical to any other faults already created)
    SCALAR 'purpose' => To check extended record for all faults through customer diagnosis
    HASH 'ExtendedData_FirstTimeDequali' => Extended data to be stimulated before first time fault dequalification


=head2 PARAMETER EXAMPLES

    purpose ='To check extended record for all faults through customer diagnosis'
    #Examples of other types of extended data stimulation
    #ExtendedData_FirstTimeQuali=%('AgingCounter'=>'46', 'EventCounter'=>'1','PDVariable_PowerOncounter'=>'367','PDVariable_ECUTimeStamp'=>'read','Voltage'=>'12','OperationalMode'=>'3','KeyIgnitionstate'=>'2','GlobalRealTime'=>'read','TripCounter'=>'read_from_diagnostics','BLFD'=>'PositionA','DTC_LowByte'=>'Mapping_Fault')
    ExtendedData_FirstTimeDequali=%()
    External_fault_name='rb_pom_VbatLow_flt'
    ExtendedData_FirstTimeQuali=%('OccurenceCounter'=>'4', 'GeneralStatusFlag'=>'32')
    ExtendedData_ReQuali=%('OccurenceCounter'=>'5', 'GeneralStatusFlag'=>'32')
    additional_fault=''

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_ExtendedData_FirstTimeDequali;
my $tcpar_External_fault_name;
my $tcpar_Internal_erasable_fault_name;
my $tcpar_ExtendedData_FirstTimeQuali;
my $tcpar_Internal_non_erasable_fault_name;
my $tcpar_ExtendedData_ReQuali;
my $tcpar_additional_fault;
my $tcpar_fault_monitoring_type;
my $tcpar_ExtendedRecordNbr;
my $tcpar_ExtendedData_Quali_Reset;

################ global parameter declaration ###################
#add any global variables here
my $CC_flt;

my $aging_counter          = 'false';
my $additional_stimulation = 'false';

# additional stimulation variables
my ( @extendedStimultn, @additional_extendedStimultn );

# fault memory read variables
my ( $fault_mem_primary_afterQuali, $customer_faultmem_firstQuali, $customer_faultmem_reset, $fault_mem_primary_FltRemoval,
     $customer_faultmem_FltRemoval, $fault_mem_primary_addtnalflt, $customer_faultmem_addtnalflt, $faultstatus_CD_afterErase );

# expected fault mem variables
my ( $expectedFaults_primary_afterQuali, $expectedFaults_primary_FltRemoval, $expectedFaults_primary_addtnalflt, $expectedfaultstatus_CD_afterErase );

# fault creation variables
my ( @faults_created, $faults_stored );
my $Internal_non_erasable_fault_name='false';

# expected extended data variables
my ( $extendedData_firstquali, $extendedData_firstdequali, $extendedData_secondquali, $current_read_data );

my $dispatchTable ||= {
    Occurence_Counter   => \&_Occurence_stimulation,
    AgingCounter        => \&_Aging_stimulation,
    EventCounter        => \&_Aging_stimulation,
    AgingCounterOnCOM   => \&_AgingCounterCOM_stimulation,
    DTCpriority         => \&_DTC_Priority,
    Event_Debug_Status  => \&_DebugData_stimulation,
    General_Status_Flag => \&_GeneralStatus_stimulation,

};

###############################################################

sub TC_set_parameters {

    $tcpar_purpose                          = S_read_mandatory_testcase_parameter('purpose');
    $tcpar_ExtendedData_FirstTimeDequali    = S_read_mandatory_testcase_parameter('ExtendedData_FirstTimeDequali','byref');
    $tcpar_Internal_erasable_fault_name     = S_read_optional_testcase_parameter('Internal_erasable_fault_name');
    $tcpar_Internal_non_erasable_fault_name = S_read_optional_testcase_parameter('Internal_non_erasable_fault_name');
    $tcpar_External_fault_name              = S_read_optional_testcase_parameter('External_fault_name');
    $tcpar_ExtendedData_FirstTimeQuali      = S_read_mandatory_testcase_parameter('ExtendedData_FirstTimeQuali','byref');
    $tcpar_ExtendedData_Quali_Reset         = S_read_optional_testcase_parameter('ExtendedData_Quali_Reset', 'byref');
    $tcpar_ExtendedData_ReQuali             = S_read_mandatory_testcase_parameter('ExtendedData_ReQuali','byref');
    $tcpar_additional_fault                 = S_read_optional_testcase_parameter('additional_fault');
    $tcpar_fault_monitoring_type            = S_read_mandatory_testcase_parameter('fault_monitoring_type');
    $tcpar_ExtendedRecordNbr                = S_read_optional_testcase_parameter('ExtendedRecordNbr','byref');
    if ( not defined $tcpar_ExtendedRecordNbr ) {
        foreach my $data_element ( keys %{$tcpar_ExtendedData_FirstTimeQuali} ) {
            $tcpar_ExtendedRecordNbr->{$data_element} = 255;
        }
    }

    return 1;
}

sub TC_initialization {

    S_teststep( "Power on ECU, clear all faults", 'AUTO_NBR' );

    S_w2log( 1, "Power on ECU" );
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

    S_w2log( 1, "Initialize CD and start CAN trace" );
    DCOM_init();    # To fetch info for CD from mapping_diag
    NET_trace_start();

    S_w2log( 1, "Clear fault memory" );
    PD_ClearFaultMemory();
    S_wait_ms(2000);

    S_w2log( 1, "Read and evaluate fault memory before stimulation" );

    my $faultsBeforeStimulation = LIFT_FaultMemory->read_fault_memory('Primary');
    $faultsBeforeStimulation->evaluate_faults( {} );    #Fault memory must be empty

    return 1;
}

sub TC_stimulation_and_measurement {

    S_teststep( "Stimulate all the required extended data first time for fault qualification.", 'AUTO_NBR' );

    $current_read_data = _Read_ExtendedData_CurrentValues();
    if ($current_read_data) {
        ( $extendedData_firstquali, $additional_stimulation ) = _Stimulate_extendeddata( $tcpar_ExtendedData_FirstTimeQuali, 'FirstQuali' );
    }
    else {
        S_set_error(" Reading of current data on COM and PD was not successful, hence testcase aborted");
        return 0;
    }

    # ---- CREATE FAULTS ---

    _Qualify_all_faults();
    # Wait for fault qualification
    _Trigger_quali_dequali_fault('Qualification');

    # External Faults
    if ( defined $tcpar_External_fault_name ) {
        push( @faults_created, $tcpar_External_fault_name );
        $expectedFaults_primary_afterQuali->{'mandatory'}->{$tcpar_External_fault_name} = { 'DecodedStatus' => { 'TestFailed' => 1 }, };
    }

    # Internal erasable faults
    if ( defined $tcpar_Internal_erasable_fault_name ) {
        push( @faults_created, $tcpar_Internal_erasable_fault_name );
        $expectedFaults_primary_afterQuali->{'mandatory'}->{$tcpar_Internal_erasable_fault_name} = { 'DecodedStatus' => { 'TestFailed' => 1 }, };
    }

    # internal non-erasable faults
    if ( defined $tcpar_Internal_non_erasable_fault_name ) {
        push( @faults_created, $tcpar_Internal_non_erasable_fault_name );
        $expectedFaults_primary_afterQuali->{'mandatory'}->{$tcpar_Internal_non_erasable_fault_name} = { 'DecodedStatus' => { 'TestFailed' => 1 }, };
    }

    S_teststep( "Read Primary fault memory(PFM) after fault qualification", 'AUTO_NBR', 'read_primary_fault_firstquali' );           #measurement 1
    $fault_mem_primary_afterQuali = LIFT_FaultMemory->read_fault_memory('Primary');

    S_teststep( "Read extended data via CD after first time fault qualification", 'AUTO_NBR', 'read_extendeddata_firstquali' );      #measurement 2
    foreach my $data_element ( keys %{$tcpar_ExtendedData_FirstTimeQuali} ) {
        my $recordnbr         = $tcpar_ExtendedRecordNbr->{$data_element};
        my $customer_faultmem = LIFT_FaultMemory->read_fault_memory('Customer');
        $customer_faultmem->read_extended_data( 'all', $recordnbr );
        $customer_faultmem_firstQuali->{$recordnbr} = $customer_faultmem;
    }

    S_teststep( "Reset ECU", 'AUTO_NBR' );
    _Ecu_reset() if ( $aging_counter eq 'false' );             # If 'aging counter' is stimulated, then ecu reset is not required

    S_teststep( "Read extended data via CD after ECU reset", 'AUTO_NBR', 'read_extendeddata_reset' );                              #measurement 3
    foreach my $data_element ( keys %{$tcpar_ExtendedData_FirstTimeQuali} ) {
        my $recordnbr                = $tcpar_ExtendedRecordNbr->{$data_element};
        my $customer_faultmem_reset1 = LIFT_FaultMemory->read_fault_memory('Customer');
        $customer_faultmem_reset1->read_extended_data( 'all', $recordnbr );
        $customer_faultmem_reset->{$recordnbr} = $customer_faultmem_reset1;
    }

    S_teststep( "Stimulate all the required extended data with different values before fault dequalification", 'AUTO_NBR' );
    $extendedData_firstdequali = _Stimulate_extendeddata( $tcpar_ExtendedData_FirstTimeDequali, 'FirstDequali' );

    # ---- REMOVE FAULTS ---
    _Remove_all_faults();
    # Wait time for fault dequalification
    _Trigger_quali_dequali_fault('Dequalification');

    # External faults
    if ( defined $tcpar_External_fault_name ) {
        $expectedFaults_primary_FltRemoval->{'mandatory'}->{ $tcpar_External_fault_name, } = { 'DecodedStatus' => { 'ConfirmedDTC' => 1, 'TestFailed' => 0 }, };
    }

    # Internal faults
    if ( defined $tcpar_Internal_erasable_fault_name ) {
        $expectedFaults_primary_FltRemoval->{'mandatory'}->{$tcpar_Internal_erasable_fault_name} = { 'DecodedStatus' => { 'ConfirmedDTC' => 1, 'TestFailed' => 0 }, };
    }

    if ( defined $tcpar_Internal_non_erasable_fault_name ) {
        $expectedFaults_primary_FltRemoval->{'mandatory'}->{$tcpar_Internal_non_erasable_fault_name} = { 'DecodedStatus' => { 'ConfirmedDTC' => 1, 'TestFailed' => 0 }, };
    }

    S_teststep( "Read PFM after all faults removal", 'AUTO_NBR', 'read_primary_fltmem_FltRemoval' );                        #measurement 4
    $fault_mem_primary_FltRemoval = LIFT_FaultMemory->read_fault_memory('Primary');

    S_teststep( "Read extended data via CD  after internal fault removal", 'AUTO_NBR', 'read_extendeddata_FltRemoval' );    #measurement 5
    foreach my $data_element ( keys %{$tcpar_ExtendedData_FirstTimeQuali} ) {
        my $recordnbr         = $tcpar_ExtendedRecordNbr->{$data_element};
        my $customer_faultmem = LIFT_FaultMemory->read_fault_memory('Customer');
        $customer_faultmem->read_extended_data( 'all', $recordnbr );
        $customer_faultmem_FltRemoval->{$recordnbr} = $customer_faultmem;
    }

    S_teststep( "Stimulate all the required extended data with different values before fault requalification", 'AUTO_NBR' );
    ( $extendedData_secondquali, $additional_stimulation ) = _Stimulate_extendeddata( $tcpar_ExtendedData_ReQuali, 'SecondQuali' );

    # ---- CREATE FAULTS ---

    _Qualify_all_faults();

    if ( defined $tcpar_additional_fault ) {
        S_teststep( "Create '$tcpar_additional_fault' with DTC identical to any one of the faults created in step 18.", 'AUTO_NBR' );
        FM_createFault($tcpar_additional_fault);

        # Wait for fault qualification
        _Trigger_quali_dequali_fault('Qualification');
        S_teststep( "Read PFM after creating all faults and additional fault ", 'AUTO_NBR', 'read_primary_fltmem_addtnlflt' );                          #measurement 6
        $fault_mem_primary_addtnalflt = LIFT_FaultMemory->read_fault_memory('Primary');
    }
    else {
        # Wait for fault qualification
        _Trigger_quali_dequali_fault('Qualification');

    }

    S_teststep( "Read extended data via CD after creating all faults and additional fault if defined", 'AUTO_NBR', 'read_extendeddata_addtnlflt' );    #measurement 7
    foreach my $data_element ( keys %{$tcpar_ExtendedData_FirstTimeQuali} ) {
        my $recordnbr         = $tcpar_ExtendedRecordNbr->{$data_element};
        my $customer_faultmem = LIFT_FaultMemory->read_fault_memory('Customer');
        $customer_faultmem->read_extended_data( 'all', $recordnbr );
        $customer_faultmem_addtnalflt->{$recordnbr} = $customer_faultmem;
    }

    S_teststep( "Reset all the stimulated extended data back to valid/default values", 'AUTO_NBR' );
    _Reset_stimulated_extendeddata();

    # ---- REMOVE FAULTS ---
    _Remove_all_faults();
    
    # Additional fault
    if ( defined $tcpar_additional_fault ) {
        S_teststep_2nd_level( "Remove '$tcpar_additional_fault'", 'AUTO_NBR' );
       
        FM_removeFault($tcpar_additional_fault) if ($Internal_non_erasable_fault_name eq 'false');
        # Wait time for fault dequalification
        _Trigger_quali_dequali_fault('Dequalification');
    }
    else{
        # Wait time for fault dequalification
        _Trigger_quali_dequali_fault('Dequalification');
    }

    S_teststep( "Erase PFM via CD", 'AUTO_NBR' );
    if ( defined $tcpar_Internal_non_erasable_fault_name ) {
        DCOM_request( '14 FF FF FF', '7F 14 22', 'relax', 'erase fault memory with CD' );
        $expectedfaultstatus_CD_afterErase->{'mandatory'}->{$tcpar_Internal_non_erasable_fault_name} = { 'DecodedStatus' => { 'ConfirmedDTC' => 1}, };
        $expectedfaultstatus_CD_afterErase->{'mandatory'}->{$tcpar_External_fault_name}              = { 'DecodedStatus' => { 'ConfirmedDTC' => 1}, } if ( defined $tcpar_External_fault_name );
        $expectedfaultstatus_CD_afterErase->{'mandatory'}->{$CC_flt}              = { 'DecodedStatus' => { 'ConfirmedDTC' => 1}, } if ( defined $CC_flt );
        $expectedfaultstatus_CD_afterErase->{'mandatory'}->{$tcpar_Internal_erasable_fault_name}     = { 'DecodedStatus' => { 'ConfirmedDTC' => 1}, } if ( defined $tcpar_Internal_erasable_fault_name );
    }
    else {
        DCOM_request( '14 FF FF FF', 'undef', 'relax', 'erase fault memory with CD' );
        $expectedfaultstatus_CD_afterErase = {};
    }

    S_teststep( "Read DTC status bits via CD", 'AUTO_NBR', 'read_dtc_status_afterErasure' );    #measurement 8
    $faultstatus_CD_afterErase = LIFT_FaultMemory->read_fault_memory('Customer');

    S_teststep( "Erase PFM via PD", 'AUTO_NBR' );
    PD_ClearFaultMemory();
    S_wait_ms(6000);

    return 1;
}

sub TC_evaluation {

    $faults_stored = \@faults_created;                                                          # get the array reference to pass as parameter into subroutine

    $fault_mem_primary_afterQuali->evaluate_faults( $expectedFaults_primary_afterQuali, "read_primary_fault_firstquali" );    #evaluation 1
    
# EVALUATION OF EXTENDED DATA AFTER FAULT QUALIFICATION    
    foreach my $data_element (@extendedStimultn) {
        my $recordnbr = $tcpar_ExtendedRecordNbr->{$data_element};
        _Evaluate_extendeddata(
            $data_element,                                                                                                    #evaluation 2
            $customer_faultmem_firstQuali->{$recordnbr},
            $faults_stored,
            $extendedData_firstquali,
            $recordnbr,
            "read_extendeddata_firstquali");
    }
    if ( $additional_stimulation eq 'true' ) {
        foreach my $data_element (@additional_extendedStimultn) {
            my $recordnbr = $tcpar_ExtendedRecordNbr->{$data_element};
            FM_Extendeddata_evaluation(
                $data_element, 
                $customer_faultmem_firstQuali->{$recordnbr},
                $faults_stored, $extendedData_firstquali,
                $recordnbr,
                "read_extendeddata_firstquali" );

        }
    }
# EVALUATION OF EXTENDED DATA AFTER FAULT QUALIFICATION AND RESET
    $tcpar_ExtendedData_Quali_Reset = $extendedData_firstquali if ( not defined $tcpar_ExtendedData_Quali_Reset );
    foreach my $data_element (@extendedStimultn) {
        my $recordnbr = $tcpar_ExtendedRecordNbr->{$data_element};
        _Evaluate_extendeddata(
            $data_element,                                                                                                    #evaluation 3
            $customer_faultmem_reset->{$recordnbr},
            $faults_stored,
            $tcpar_ExtendedData_Quali_Reset,
            $recordnbr,
            "read_extendeddata_reset");
    }
    if ( $additional_stimulation eq 'true' ) {
        foreach my $data_element (@additional_extendedStimultn) {
            my $recordnbr = $tcpar_ExtendedRecordNbr->{$data_element};
            FM_Extendeddata_evaluation(
                $data_element,
                $customer_faultmem_reset->{$recordnbr},
                $faults_stored,
                $tcpar_ExtendedData_Quali_Reset,
                $recordnbr,
                "read_extendeddata_reset" );
        }
    }

    $fault_mem_primary_FltRemoval->evaluate_faults( $expectedFaults_primary_FltRemoval, "read_primary_fltmem_FltRemoval" );    #evaluation 4
    
# EVALUATION OF EXTENDED DATA AFTER FAULT DEQUALIFICATION
$tcpar_ExtendedData_Quali_Reset = $extendedData_firstquali if ( not defined $tcpar_ExtendedData_Quali_Reset );
    foreach my $data_element (@extendedStimultn) {
        my $recordnbr = $tcpar_ExtendedRecordNbr->{$data_element};
        _Evaluate_extendeddata(
            $data_element,                                                                                                     #evaluation 5
            $customer_faultmem_FltRemoval->{$recordnbr},
            $faults_stored,
            $tcpar_ExtendedData_Quali_Reset,
            $recordnbr,
            "read_extendeddata_FltRemoval");
    }
    if ( $additional_stimulation eq 'true' ) {
        foreach my $data_element (@additional_extendedStimultn) {
            my $recordnbr = $tcpar_ExtendedRecordNbr->{$data_element};
            FM_Extendeddata_evaluation(
                $data_element,
                $customer_faultmem_FltRemoval->{$recordnbr},
                $faults_stored,
                $tcpar_ExtendedData_Quali_Reset,
                $recordnbr,
                "read_extendeddata_FltRemoval" );
        }
    }

    my $faults_to_evaluate;
    if ( defined $tcpar_additional_fault ) {
        $faults_to_evaluate = _Additional_flt_evaluate_extendeddata($faults_stored);                                            #evaluation 6
    }
    else {
        $faults_to_evaluate = $faults_stored;
    }
# EVALUATION OF EXTENDED DATA AFTER PREVIOUS FAULT REQUALIFICATION AND ADDITIONAL FAULT QUALIFICATION
    foreach my $data_element (@extendedStimultn) {
        my $recordnbr = $tcpar_ExtendedRecordNbr->{$data_element};
        _Evaluate_extendeddata(
            $data_element,                                                                                                      #evaluation 7
            $customer_faultmem_addtnalflt->{$recordnbr},
            $faults_to_evaluate,
            $extendedData_secondquali,
            $recordnbr,
            "read_extendeddata_addtnlflt");
    }
    if ( $additional_stimulation eq 'true' ) {
        foreach my $data_element (@additional_extendedStimultn) {
            my $recordnbr = $tcpar_ExtendedRecordNbr->{$data_element};
            FM_Extendeddata_evaluation(
                $data_element,
                $customer_faultmem_addtnalflt->{$recordnbr},
                $faults_to_evaluate,
                $extendedData_secondquali,
                $recordnbr,
                "read_extendeddata_addtnlflt" );
        }
    }

    $faultstatus_CD_afterErase->evaluate_faults( $expectedfaultstatus_CD_afterErase, "read_dtc_status_afterErasure" );          #evaluation 8

    return 1;
}

sub TC_finalization {

    # Erase Fault memory
    PD_ClearFaultMemory();

    # Read fault memory after clearing fault memory
    PD_ReadFaultMemory();
    S_wait_ms(2000);

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

    return 1;
}

sub _Evaluate_extendeddata {
    my $data_element          = shift;
    my $custflt_mem           = shift;
    my $faults_qualified      = shift;
    my $expected_extendeddata = shift;
    my $extended_recordNbr    = shift;
    my $keyword               = shift;

    # local variables
    my ( $expected_data, $detected_value );

    foreach my $faultName (@$faults_qualified) {

        # Get the detected data  for $data_element for $faultName
        S_w2rep( " ***************Extended record data validation('$keyword') for fault '$faultName' *************", 'magenta' );
        S_w2rep( " ***************Data element $data_element validation *******",                                    'magenta' );
        S_teststep_2nd_level( "Check the extended data for $data_element for fault '$faultName' ", 'AUTO_NBR' );
        $detected_value = $custflt_mem->get_extended_data_value_decoded( $faultName, $data_element, $extended_recordNbr );

        $expected_data = $expected_extendeddata->{$data_element};

        EVAL_evaluate_value( $faultName . "_" . $data_element, $detected_value, '==', $expected_data );
        S_teststep_expected( "Expected $data_element for fault $faultName : $expected_data", $keyword );
        S_teststep_detected( "Detected $data_element for fault $faultName : $detected_value", $keyword );
    }

    return 1;
}

sub _Additional_flt_evaluate_extendeddata {

    my (@faults_without_sameDTC);
    $expectedFaults_primary_addtnalflt = $expectedFaults_primary_afterQuali;
    $expectedFaults_primary_addtnalflt->{'mandatory'}->{$tcpar_additional_fault} = { 'DecodedStatus' => { 'ConfirmedDTC' => 1, 'TestFailed' => 1 }, };
    $fault_mem_primary_addtnalflt->evaluate_faults( $expectedFaults_primary_addtnalflt, "read_primary_fltmem_addtnlflt" );

    my $faultproperty        = FM_fetchFaultInfo($tcpar_additional_fault);    #get the info from Fault mapping file
    my $additional_fault_DTC = $faultproperty->{'DTC'};

    foreach my $fault (@$faults_stored) {

        # Get DTC of every stored fault to check with DTC of additional fault
        my $additionalfaultproperty = FM_fetchFaultInfo($fault);
        my $fault_DTC     = $additionalfaultproperty->{'DTC'};
        if ( $fault_DTC eq $additional_fault_DTC ) {
            S_w2rep("$fault and $tcpar_additional_fault have same DTC $fault_DTC , hence extended record for $tcpar_additional_fault will be stored ");
        }
        else {
            # list of all faults except the one with DTC identical to additional fault
            push( @faults_without_sameDTC, $fault );
        }
    }
    push( @faults_without_sameDTC, $tcpar_additional_fault );
    return ( \@faults_without_sameDTC );

}

sub _Qualify_all_faults {

    # ---- CREATE FAULTS ---
    return if ( $aging_counter eq 'true' );
    S_teststep( "Create all faults", 'AUTO_NBR' );

    # External Faults
    if ( defined $tcpar_External_fault_name ) {
        S_teststep_2nd_level( "Create '$tcpar_External_fault_name'  ", 'AUTO_NBR' );
        FM_createFault($tcpar_External_fault_name);
        if ( $tcpar_External_fault_name =~ m/Crosscoupling/i ) {
            $CC_flt = FM_Fetch_CrosscoupledFault($tcpar_External_fault_name);
            S_w2rep("cross coupling fault=$CC_flt");
            $expectedFaults_primary_afterQuali->{'mandatory'}->{$CC_flt} = { 'DecodedStatus' => { 'TestFailed' => 1 }, };
        }
    }

    # Internal erasable faults
    if ( defined $tcpar_Internal_erasable_fault_name ) {
        S_teststep_2nd_level( "Create '$tcpar_Internal_erasable_fault_name' ", 'AUTO_NBR' );
        FM_createFault($tcpar_Internal_erasable_fault_name);
    }

    # internal non-erasable faults
    if ( defined $tcpar_Internal_non_erasable_fault_name ) {
        S_teststep_2nd_level( "Create '$tcpar_Internal_non_erasable_fault_name' ", 'AUTO_NBR' );
        FM_createFault($tcpar_Internal_non_erasable_fault_name);
        $Internal_non_erasable_fault_name='true';
    }

    return 1;

}

sub _Remove_all_faults {

    return if ( $aging_counter eq 'true' );
    S_teststep( "Remove all faults ", 'AUTO_NBR' );

    # External faults
    if ( defined $tcpar_External_fault_name ) {
        S_teststep_2nd_level( "Remove '$tcpar_External_fault_name', wait for dequalification time", 'AUTO_NBR' );
        FM_removeFault($tcpar_External_fault_name);
        $expectedFaults_primary_FltRemoval->{'mandatory'}->{$CC_flt} = { 'DecodedStatus' => { 'ConfirmedDTC' => 1, 'TestFailed' => 0 }, } if ( defined $CC_flt );
    }

    # Internal faults
    if ( defined $tcpar_Internal_erasable_fault_name ) {
        S_teststep_2nd_level( "Remove '$tcpar_Internal_erasable_fault_name'", 'AUTO_NBR' );
        FM_removeFault($tcpar_Internal_erasable_fault_name);
    }

    if ( defined $tcpar_Internal_non_erasable_fault_name ) {
        S_teststep_2nd_level( "Remove '$tcpar_Internal_non_erasable_fault_name'", 'AUTO_NBR' );
        FM_removeFault($tcpar_Internal_non_erasable_fault_name);
    }

    return 1;

}

sub _Read_ExtendedData_CurrentValues {
    my $read_values;
    foreach my $data_element ( keys %{$tcpar_ExtendedData_FirstTimeQuali} ) {

        #Get the data source for every data element from Mapping_CustomerData.pm
        my $data_source_read = $main::ProjectDefaults->{'Mapping_ExtendedData'}{'MEMBER_DATA_DEFINITION'}{$data_element}{'DataSource'};
        unless ( defined $data_source_read ) {
            S_set_error(" Data source is not defined for $data_element, testcase aborted.
                Please define data source in 'Mapping_CustomerData' for all the members mentioned in testcase parameters ");
            return 0;
        }

        if ( $data_source_read eq 'AgingCounterOnCOM' ) {

            S_teststep_2nd_level( "Read $data_element($data_source_read) current values", 'AUTO_NBR' );

            # Get the COM signal name from Mapping_CustomerData.pm
            my $bus_signal_name = $main::ProjectDefaults->{'Mapping_ExtendedData'}{'MEMBER_DATA_DEFINITION'}{$data_element}{'Signal_name'};

            # Read the current value on COM signal
            my ( $signalvalue, $unit ) = NET_read_signal($bus_signal_name);

            # Store the read value
            $read_values->{$data_element} = $signalvalue;
        }
        elsif ( $data_source_read eq 'COM_Signal' ) {

            # Get the COM signal name from Mapping_CustomerData.pm
            my $bus_signal_name = $main::ProjectDefaults->{'Mapping_ExtendedData'}{'MEMBER_DATA_DEFINITION'}{$data_element}{'Signal_name'};

            # Read the current value on COM signal
            my ( $signalvalue, $unit ) = NET_read_signal($bus_signal_name);

            # Store the read value
            $read_values->{$data_element} = $signalvalue;

        }
    }
    return ( \%$read_values );

}

sub _Stimulate_extendeddata {
    my $stimulated_extendeddata = shift;
    my $keyword                 = shift;

    my ( $stimulatedData, $current_stimulateddata );

    foreach my $data_element ( keys %{$stimulated_extendeddata} ) {
        my $data = $stimulated_extendeddata->{$data_element};

        #Get the data source for every data element from Mapping_CustomerData.pm
        my $data_source = $main::ProjectDefaults->{'Mapping_ExtendedData'}{'MEMBER_DATA_DEFINITION'}{$data_element}{'DataSource'};
        unless ( defined $data_source ) {
            S_set_error(" data source is not defined for $data_element, testcase aborted ");
            return;
        }
        S_w2rep("Data_element =$data_element,Data source= $data_source stimulation");

        if ( ( $keyword eq 'FirstDequali' ) and ( $data_source eq ( 'Occurence_Counter' or 'Aging_Counter' or 'Event_Counter' ) ) ) {
            S_w2rep(" Fault is already dequalified, hence no stimulation required before fault dequalification");
            return 1;

        }
        elsif ( ( $keyword eq 'SecondQuali' ) and ( $data_source eq ( 'Occurence_Counter' or 'Aging_Counter' or 'Event_Counter' ) ) ) {
            my $previous_stimulateddata = $tcpar_ExtendedData_FirstTimeQuali->{$data_element};
            $current_stimulateddata = abs( $previous_stimulateddata - $data );

        }
        $current_stimulateddata = $data if ( not defined $current_stimulateddata );
        if ( exists $dispatchTable->{$data_source} ) {
            $dispatchTable->{$data_source}->( $data_element, $current_stimulateddata,$keyword );
            push( @extendedStimultn, $data_element ) if ( $keyword eq 'FirstQuali' );
        }
        else {
            $stimulatedData->{$data_element} = FM_extended_stimulation( $data_source, $data_element, $data );
            $additional_stimulation = 'true';
            push( @additional_extendedStimultn, $data_element ) if ( $keyword eq 'FirstQuali' );
        }
        $stimulatedData->{$data_element} = $data;
    }
    return ($stimulatedData);

}

sub _AgingCounterCOM_stimulation {

    my $element_under_test = shift;
    my $data_to_stimulate  = shift;
    my $data_sent_COM;
    S_teststep_2nd_level( "Set $element_under_test to $data_to_stimulate", 'AUTO_NBR' );

    _Qualify_all_faults();
    _Trigger_quali_dequali_fault('Qualification');

    # Get the COM signal name from Mapping_CustomerData.pm
    my $bus_signal_name = $main::ProjectDefaults->{'Mapping_ExtendedData'}{'MEMBER_DATA_DEFINITION'}{$element_under_test}{'Signal_name'};

    # Write the COM signal with data defined in TS.

    NET_write_signal( $bus_signal_name, $data_to_stimulate );
    S_wait_ms(2000);
    _Remove_all_faults();
    _Trigger_quali_dequali_fault('Dequalification');

    if ( $data_to_stimulate < 215 ) {
        $data_sent_COM = $data_to_stimulate + 40;
    }
    elsif ( $data_to_stimulate >= 215 ) {
        $data_sent_COM = $data_to_stimulate + 41;
    }

    # Store the written value
    return ($data_sent_COM);
}

sub _Occurence_stimulation {
    my $element_under_test = shift;
    my $data_to_stimulate  = shift;
    my $keyword=shift;
    
    S_teststep_2nd_level( "Set $element_under_test to $data_to_stimulate", 'AUTO_NBR' );
    if ( $data_to_stimulate < 2 ) { 
        S_w2rep("Since fault $element_under_test is '$data_to_stimulate', no additional stimulation is required ");
        return ($data_to_stimulate);

    }
    foreach ( 1 .. $data_to_stimulate - 1 ) {
        _Qualify_all_faults();
        _Trigger_quali_dequali_fault('Qualification');
        _Remove_all_faults();
        _Trigger_quali_dequali_fault('Dequalification');
    }
    if(defined $tcpar_additional_fault and ( $keyword eq 'SecondQuali')){
        my $current_stimulateddata = $tcpar_ExtendedData_ReQuali->{$element_under_test};
        foreach ( 1 .. $current_stimulateddata - 1 ){
            FM_createFault($tcpar_additional_fault);
            _Trigger_quali_dequali_fault('Qualification');
            FM_removeFault($tcpar_additional_fault);
            _Trigger_quali_dequali_fault('Dequalification');
        }   
    }

    return ($data_to_stimulate);
}

sub _Aging_stimulation {

    my $element_under_test = shift;
    my $data_to_stimulate  = shift;
    S_teststep_2nd_level( "Set $element_under_test to $data_to_stimulate", 'AUTO_NBR' );
    _Qualify_all_faults();
    _Trigger_quali_dequali_fault('Qualification');
    _Remove_all_faults();
    _Trigger_quali_dequali_fault('Dequalification');
    S_teststep_2nd_level( "Reset ECU for updating aging counter", 'AUTO_NBR' );
    foreach ( 1 .. $data_to_stimulate ) {
        _Ecu_reset();
    }
    $aging_counter = 'true';
    return ($data_to_stimulate);
}

sub _DTC_Priority {
    my $element_under_test = shift;
    my $data_to_stimulate  = shift;
    my $fault_DTC;
    S_teststep_2nd_level( "Get $element_under_test ", 'AUTO_NBR' );

    # Get DTC priority info from mapping fault
    foreach my $fault (@$faults_stored) {
        my $faultproperty = FM_fetchFaultInfo($fault);
        my $DTC_priority  = $faultproperty->{'Faultpriority'};

        #Store the DTC Priority info
        $fault_DTC->{$fault} = $DTC_priority;
    }
    return ($fault_DTC);
}

sub _GeneralStatus_stimulation {
    my $element_under_test = shift;
    my $data_to_stimulate  = shift;
    S_teststep( "No stimulation is required, give expected general status flag for every fault in testcase parameter ", 'AUTO_NBR' );
    return ($data_to_stimulate);
}

sub _DebugData_stimulation {
    my $element_under_test = shift;
    my $data_to_stimulate  = shift;
    S_teststep( "No stimulation is required, give expected event debug status for every fault in testcase parameter ", 'AUTO_NBR' );
    return ($data_to_stimulate);
}

sub _Reset_stimulated_extendeddata {

    $aging_counter = 'false';

    foreach my $data_element ( keys %{$tcpar_ExtendedData_FirstTimeQuali} ) {    
        #Get the data source for every data element from Mapping_CustomerData.pm
        my $data_source_reset = $main::ProjectDefaults->{'Mapping_ExtendedData'}{'MEMBER_DATA_DEFINITION'}{$data_element}{'DataSource'};
        unless ( defined $data_source_reset ) {
            S_set_error(" data source is not defined for $data_element, testcase aborted ");
        }
        if ( $data_source_reset eq 'COM_Signal' ) {
        
            # Get the COM signal name from Mapping_CustomerData.pm
            my $bus_signal_name = $main::ProjectDefaults->{'Mapping_ExtendedData'}{'MEMBER_DATA_DEFINITION'}{$data_element}{'Signal_name'};
            my $signalvalue     = $current_read_data->{$data_element};
            S_w2rep("Data_element =$data_element,Data=$signalvalue");

            # Write the COM signal with data stored earlier.
            NET_write_signal( $bus_signal_name, $signalvalue );
            S_wait_ms(2000);
        }
        elsif ( $data_source_reset eq 'AgingCounterOnCOM' ) {
            # Get the COM signal name from Mapping_CustomerData.pm
            my $bus_signal_name = $main::ProjectDefaults->{'Mapping_ExtendedData'}{'MEMBER_DATA_DEFINITION'}{$data_element}{'Signal_name'};
            my $signalvalue     = $current_read_data->{$data_element};
            S_w2rep("Data_element =$data_element,Data=$signalvalue");

            # Write the COM signal with data stored earlier.
            NET_write_signal( $bus_signal_name, $signalvalue );     
            S_wait_ms(2000);
        }
    }

    return 1;

}

sub _Trigger_quali_dequali_fault {
    my $triggerType = shift;

    if ( lc($tcpar_fault_monitoring_type) eq 'init' ) {
        S_teststep_2nd_level( "Reset ECU", 'AUTO_NBR' );
        LC_ECU_Off();
        S_wait_ms('TIMER_ECU_OFF');
        LC_ECU_On();
        S_wait_ms('TIMER_ECU_READY');
    }
    else {
        S_teststep_2nd_level( "Wait for $triggerType time of fault", 'AUTO_NBR' );
        S_wait_ms($MAX_FAULT_DEQUALIFICATION_TIME_MS) if ( $triggerType eq 'Dequalification' );
        S_wait_ms($MAX_FAULT_QUALIFICATION_TIME_MS)   if ( $triggerType eq 'Qualification' );
    }

    return 1;

}

sub _Ecu_reset {

    # can't use LC_ECU_Off() LC_ECU_On(), because it will dequalify VbatLow/High fault
    LC_PowerDisconnect();
    S_wait_ms('TIMER_ECU_OFF');
    LC_PowerConnect();
    S_wait_ms('TIMER_ECU_READY');
    return 1;
}

1;
