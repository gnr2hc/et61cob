#### TEST CASE MODULE
package TC_DEM_SnapshotData;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.5 $;
our $HEADER  = q$Header: DEM/TC_DEM_SnapshotData.pm 1.5 2018/03/21 13:36:52ICT D Souza Deepthi Mariate (RBEI/ESA-PP3) (DDE3KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_evaluation;
use LIFT_PD;
use LIFT_labcar;
use LIFT_CANoe;
use LIFT_labcar;
use LIFT_DCOM;
use LIFT_equipment;
use FuncLib_SYC_INTERFACE;
use GENERIC_DCOM;
use LIFT_can_access;
use LIFT_FaultMemory;
use INCLUDES_Project;
use LIFT_NET_access;
use File::Basename;
use Data::Dumper;
use Readonly;

# Maximum fault quali / dequali times
Readonly my $MAX_FAULT_QUALIFICATION_TIME_MS   => 32000;
Readonly my $MAX_FAULT_DEQUALIFICATION_TIME_MS => 32000;

##################################

our $PURPOSE = "To check snapshot record for all faults through customer diagnosis";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DEM_SnapshotData

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1.Stimulate all the required snapshot data.
<SnapshotData_FirstTimeQuali>

2.Create <External_fault_name> 

3.Create <Internal_erasable_fault_name> 

4.Create <Internal_non_erasable_fault_name>

5.Wait for qualification time of faults

6.Read Primary fault memory(PFM)

7.Read snapshot data <SnapshotRecordNbr>via CD

8.Reset ECU

9.Read snapshot data via CD

10.Stimulate all the required snapshot data with different values
<SnapshotData__FirstTimeDequali>.

11.Remove <External_fault_name>, wait for dequalification time

12.Remove <Internal_erasable_fault_name>,<Internal_non_erasable_fault_name>

13.Read PFM

14.Read snapshot data via CD

15.Stimulate all the required snapshot data with different values
<SnapshotData_ReQuali>.

16.Recreate faults from step 2 to step 4.

17.Create <additional_fault> with DTC identical to any one of the faults created in step 18.

18.Read PFM

19.Read snapshot data via CD

20.Remove all the faults

21.Erase PFM via CD

22.Read DTC status bits via CD

23.Erase PFM via PD


I<B<Evaluation>>

1.

2.

3.

4.

5.

6. All faults are in qualified state

7. All the stimulated snapshot data in step 1 should be reported for every fault created.

8. 

9.All the stimulated snapshot data in step 1 should be reported for every fault created.

10. 

11.

12.

13. All faults are in dequalified state

14.All the stimulated snapshot data in step 1 should be reported for all faults 

15. 

16 

17.

18.All faults are in qualified state

19.All the stimulated snapshot data in step 1 should be reported for  <External_fault_name><Internal_erasable_fault_name>,<Internal_non_erasable_fault_name> except for the fault with DTC similar to <additional_fault>
Stimulated snapshot data in step 17 should be reported for <additional_fault>

20.

21.

22.a.DTC status bits are cleared  for <External_fault_name>,<Internal_erasable_fault_name>,<additional_fault> and  if there are no <Internal_non_erasable_fault_name> faults.
b.DTC status bits are NOT cleared for any fault if<Internal_non_erasable_fault_name> faults are defined in PFM

23.




I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

    SCALAR 'External_fault_name' => 
    HASH 'SnapshotData_FirstTimeQuali' => 
    HASH 'SnapshotData_ReQuali' => 
    SCALAR 'additional_fault' => 
    SCALAR 'purpose' => 
    HASH 'SnapshotData_FirstTimeDequali' => 


=head2 PARAMETER EXAMPLES

    purpose ='To check snapshot record for all faults through customer diagnosis'
    #Examples of other types of snapshot data stimulation
    #SnapshotData_FirstTimeQuali=%('SquibResistance'=>'2', 'SwitchResistance'=>'400','PDVariable_PowerOncounter'=>'367','PDVariable_ECUTimeStamp'=>'read','Voltage'=>'12','OperationalMode'=>'3','KeyIgnitionstate'=>'2','GlobalRealTime'=>'read','TripCounter'=>'read_from_diagnostics','BLFD'=>'PositionA','DTC_LowByte'=>'Mapping_Fault')
    SnapshotData_FirstTimeDequali=%('VehicleSpeed'=>'100', 'Temperature'=>'25')
    External_fault_name='rb_pom_VbatLow_flt'
    fault_monitoring_type='Cyclic'
    SnapshotData_ReQuali=%('VehicleSpeed'=>'65', 'Temperature'=>'90')
    additional_fault=''
    SnapshotData_FirstTimeDequali=%('VehicleSpeed'=>'117', 'Temperature'=>'75')

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_SnapshotData_FirstTimeDequali;
my $tcpar_External_fault_name;
my $tcpar_Internal_erasable_fault_name;
my $tcpar_SnapshotData_FirstTimeQuali;
my $tcpar_Internal_non_erasable_fault_name;
my $tcpar_SnapshotData_ReQuali;
my $tcpar_additional_fault;
my $tcpar_fault_monitoring_type;
my $tcpar_SnapshotRecordNbr;

################ global parameter declaration ###################
#add any global variables here
my $CC_flt;

# read variables
my ( $COMread_values, $PDread_values );

# additional stimulation variables
my ( @snapshotstimultn, @additional_snapshotstimultn );

# fault memory read variables
my ( $fault_mem_primary_afterQuali, $customer_faultmem_firstQuali, $customer_faultmem_reset, $fault_mem_primary_FltRemoval, $customer_faultmem_FltRemoval, $fault_mem_primary_addtnalflt, $customer_faultmem_addtnalflt, $faultstatus_CD_afterErase );

# expected fault mem  variables
my ( $expectedFaults_primary_afterQuali, $expectedFaults_primary_FltRemoval, $expectedFaults_primary_addtnalflt, $expectedfaultstatus_CD_afterErase );

#expected snapshot data variables
my ( $Snapshotdata_firstquali, $Snapshotdata_secondquali, $current_read_data );

# stimulation of fault variables
my ( @faults_created, $faults_stored );

my $additional_stimulation = 'false';
my $Internal_non_erasable_fault_name='false';

my $dispatchTable ||= {
    COM_Signal       => \&_COM_stimulation,                 #global/ local/same name
    PDVariable       => \&_PD_stimulation,
    SquibResistance  => \&_Squib_resistance_stimulation,
    SwitchResistance => \&_Switch_resistance_stimulation,
    Voltage          => \&_Voltage_stimulation,
    SwitchState      => \&_SwitchState_stimulation,
    DTC              => \&_Fetch_DTC,
};

###############################################################

sub TC_set_parameters {

    $tcpar_purpose                          = S_read_mandatory_testcase_parameter('purpose');
    $tcpar_SnapshotData_FirstTimeDequali    = S_read_mandatory_testcase_parameter( 'SnapshotData_FirstTimeDequali', 'byref' );
    $tcpar_Internal_erasable_fault_name     = S_read_optional_testcase_parameter('Internal_erasable_fault_name');
    $tcpar_Internal_non_erasable_fault_name = S_read_optional_testcase_parameter('Internal_non_erasable_fault_name');
    $tcpar_External_fault_name              = S_read_optional_testcase_parameter('External_fault_name');
    $tcpar_SnapshotData_FirstTimeQuali      = S_read_mandatory_testcase_parameter( 'SnapshotData_FirstTimeQuali', 'byref' );
    $tcpar_SnapshotData_ReQuali             = S_read_mandatory_testcase_parameter( 'SnapshotData_ReQuali', 'byref' );
    $tcpar_additional_fault                 = S_read_optional_testcase_parameter('additional_fault');
    $tcpar_fault_monitoring_type            = S_read_mandatory_testcase_parameter('fault_monitoring_type');
    $tcpar_SnapshotRecordNbr                = S_read_optional_testcase_parameter( 'SnapshotRecordNbr', 'byref' );
    $tcpar_SnapshotRecordNbr->{'Record_1'} = 255 if ( not defined $tcpar_SnapshotRecordNbr );

    return 1;
}

sub TC_initialization {

    S_teststep( "Power on ECU, clear all faults", 'AUTO_NBR' );

    S_w2log( 1, "Power on ECU" );
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

    S_w2log( 1, "Initialize CD and start CAN trace" );
    GDCOM_init();    # To fetch info for CD from mapping_diag
    CA_trace_start();

    S_w2log( 1, "Clear fault memory" );
    PD_ClearFaultMemory();
    S_wait_ms(2000);

    S_w2log( 1, "Read and evaluate fault memory before stimulation" );

    my $faultsBeforeStimulation = LIFT_FaultMemory->read_fault_memory('Primary');
    $faultsBeforeStimulation->evaluate_faults( {} );    #Fault memory must be empty

    return 1;
}

sub TC_stimulation_and_measurement {

    S_teststep( "Stimulate all the required snapshot data first time for fault qualification.", 'AUTO_NBR' );

    $current_read_data = _Read_SnapshotData_CurrentValues();
    if ($current_read_data) {
        ( $Snapshotdata_firstquali, $additional_stimulation ) = _Stimulate_snapshotdata( $tcpar_SnapshotData_FirstTimeQuali, 'FirstQuali' );
    }
    else {
        S_set_error(" Reading of current data on COM and PD was not successful, hence testcase aborted");
        return 0;
    }
    
    # ---- CREATE FAULTS ---
    S_teststep( "Create all faults for first time", 'AUTO_NBR' );
    _Qualify_all_faults();

    # Wait for fault qualification
    _Trigger_quali_dequali_fault('Qualification');

    # External Faults
    if ( defined $tcpar_External_fault_name ) {
        push( @faults_created, $tcpar_External_fault_name );
        $expectedFaults_primary_afterQuali->{'mandatory'}->{$tcpar_External_fault_name} = { 'DecodedStatus' => { 'TestFailed' => 1 }, };
    }

    # Internal erasable faults
    if ( defined $tcpar_Internal_erasable_fault_name ) {
        push( @faults_created, $tcpar_Internal_erasable_fault_name );
        $expectedFaults_primary_afterQuali->{'mandatory'}->{$tcpar_Internal_erasable_fault_name} = { 'DecodedStatus' => { 'TestFailed' => 1 }, };
    }

    # internal non-erasable faults
    if ( defined $tcpar_Internal_non_erasable_fault_name ) {
        push( @faults_created, $tcpar_Internal_non_erasable_fault_name );
        $expectedFaults_primary_afterQuali->{'mandatory'}->{$tcpar_Internal_non_erasable_fault_name} = { 'DecodedStatus' => { 'TestFailed' => 1 }, };
    }

    S_teststep( "Read Primary fault memory(PFM) after fault qualification", 'AUTO_NBR', 'read_primary_fault_firstquali' );    #measurement 1
    $fault_mem_primary_afterQuali = LIFT_FaultMemory->read_fault_memory('Primary');

    S_teststep( "Read snapshot data via CD after first time fault qualification", 'AUTO_NBR', 'read_snapshotdata_firstquali' );    #measurement 2
    foreach my $record_label ( keys %{$tcpar_SnapshotRecordNbr} ) {
        my $recordnbr         = $tcpar_SnapshotRecordNbr->{$record_label};
        my $customer_faultmem = LIFT_FaultMemory->read_fault_memory('Customer');
        $customer_faultmem->read_snapshot_data( 'all', $recordnbr );
        $customer_faultmem_firstQuali->{$recordnbr} = $customer_faultmem;
    }

    S_teststep( "Reset ECU", 'AUTO_NBR' );
    _Ecu_reset();

    S_teststep( "Read snapshot data via CD after ECU reset", 'AUTO_NBR', 'read_snapshotdata_reset' );                              #measurement 3
                                                                                                                                 
    foreach my $record_label ( keys %{$tcpar_SnapshotRecordNbr} ) {
        my $recordnbr         = $tcpar_SnapshotRecordNbr->{$record_label};
        my $customer_faultmem = LIFT_FaultMemory->read_fault_memory('Customer');
        $customer_faultmem->read_snapshot_data( 'all', $recordnbr );
        $customer_faultmem_reset->{$recordnbr} = $customer_faultmem;
    }

    S_teststep( "Stimulate all the required snapshot data with different values before fault dequalification", 'AUTO_NBR' );
    my $snapshotdata_firstdequali = _Stimulate_snapshotdata($tcpar_SnapshotData_FirstTimeDequali);

    # ---- REMOVE FAULTS ---
    S_teststep( "Remove all faults for first time", 'AUTO_NBR' );
    _Remove_all_faults();
    # Wait time for fault dequalification
    _Trigger_quali_dequali_fault('Dequalification');

    # External faults
    if ( defined $tcpar_External_fault_name ) {
        $expectedFaults_primary_FltRemoval->{'mandatory'}->{ $tcpar_External_fault_name, } = { 'DecodedStatus' => { 'ConfirmedDTC' => 1, 'TestFailed' => 0 }, };
    }

    # Internal faults
    if ( defined $tcpar_Internal_erasable_fault_name ) {
        $expectedFaults_primary_FltRemoval->{'mandatory'}->{$tcpar_Internal_erasable_fault_name} = { 'DecodedStatus' => { 'ConfirmedDTC' => 1, 'TestFailed' => 0 }, };
    }

    if ( defined $tcpar_Internal_non_erasable_fault_name ) {
        $expectedFaults_primary_FltRemoval->{'mandatory'}->{$tcpar_Internal_non_erasable_fault_name} = { 'DecodedStatus' => { 'ConfirmedDTC' => 1, 'TestFailed' => 0 }, };
    }

    S_teststep( "Read PFM after all faults removal", 'AUTO_NBR', 'read_primary_fltmem_FltRemoval' );                        #measurement 4
    $fault_mem_primary_FltRemoval = LIFT_FaultMemory->read_fault_memory('Primary');

    S_teststep( "Read snapshot data via CD  after internal fault removal", 'AUTO_NBR', 'read_snapshotdata_FltRemoval' );    #measurement 5
    foreach my $record_label ( keys %{$tcpar_SnapshotRecordNbr} ) {
        my $recordnbr         = $tcpar_SnapshotRecordNbr->{$record_label};
        my $customer_faultmem = LIFT_FaultMemory->read_fault_memory('Customer');
        $customer_faultmem->read_snapshot_data( 'all', $recordnbr );
        $customer_faultmem_FltRemoval->{$recordnbr} = $customer_faultmem;
    }

    S_teststep( "Stimulate all the required snapshot data with different values before fault requalification", 'AUTO_NBR' );
    ( $Snapshotdata_secondquali, $additional_stimulation ) = _Stimulate_snapshotdata($tcpar_SnapshotData_ReQuali);

    S_teststep( "Recreate faults from step 2 to step 4.", 'AUTO_NBR' );

    # ---- CREATE FAULTS ---
    S_teststep( "Create all faults once again", 'AUTO_NBR' );
    _Qualify_all_faults();

    if ( defined $tcpar_additional_fault ) {
        S_teststep( "Create '$tcpar_additional_fault' with DTC identical to any one of the faults created in step 18.", 'AUTO_NBR' );
        FM_createFault($tcpar_additional_fault);

        # Wait for fault qualification
        _Trigger_quali_dequali_fault('Qualification');
        S_teststep( "Read PFM after creating after creating all faults and additional fault ", 'AUTO_NBR', 'read_primary_fltmem_addtnlflt' );    #measurement 6
        $fault_mem_primary_addtnalflt = LIFT_FaultMemory->read_fault_memory('Primary');
    }
    else {
        # Wait for fault qualification
        _Trigger_quali_dequali_fault('Qualification');
    }

    S_teststep( "Read snapshot data via CD after creating all faults and additional fault if defined", 'AUTO_NBR', 'read_snapshotdata_addtnlflt' );    #measurement 7
    foreach my $record_label ( keys %{$tcpar_SnapshotRecordNbr} ) {
        my $recordnbr         = $tcpar_SnapshotRecordNbr->{$record_label};
        my $customer_faultmem = LIFT_FaultMemory->read_fault_memory('Customer');
        $customer_faultmem->read_snapshot_data( 'all', $recordnbr );
        $customer_faultmem_addtnalflt->{$recordnbr} = $customer_faultmem;
    }

    S_teststep( "Remove all the faults", 'AUTO_NBR' );

    # ---- REMOVE FAULTS ---
    S_teststep( "Remove all faults created once again", 'AUTO_NBR' );
    _Remove_all_faults();
    
    # Additional fault
    if ( defined $tcpar_additional_fault ) {
        S_teststep_2nd_level( "Remove '$tcpar_additional_fault'", 'AUTO_NBR' );
        FM_removeFault($tcpar_additional_fault) if ($Internal_non_erasable_fault_name eq 'false');
        # Wait time for fault dequalification
        _Trigger_quali_dequali_fault('Dequalification');
    }
    else{
        # Wait time for fault dequalification
        _Trigger_quali_dequali_fault('Dequalification');
    }

    S_teststep( "Reset all the stimulated snapshot data back to valid/default values", 'AUTO_NBR' );
   _Reset_stimulated_snapshotdata();

    S_teststep( "Erase PFM via CD", 'AUTO_NBR' );
    if ( defined $tcpar_Internal_non_erasable_fault_name ) {
        DCOM_request( '14 FF FF FF', '7F 14 22', 'relax', 'erase fault memory with CD' );
        $expectedfaultstatus_CD_afterErase->{'mandatory'}->{$tcpar_Internal_non_erasable_fault_name} = { 'DecodedStatus' => { 'ConfirmedDTC' => 1}, };
        $expectedfaultstatus_CD_afterErase->{'mandatory'}->{$tcpar_External_fault_name}              = { 'DecodedStatus' => { 'ConfirmedDTC' => 1 }, } if ( defined $tcpar_External_fault_name );
        $expectedfaultstatus_CD_afterErase->{'mandatory'}->{$tcpar_Internal_erasable_fault_name}     = { 'DecodedStatus' => { 'ConfirmedDTC' => 1}, } if ( defined $tcpar_Internal_erasable_fault_name );
    }
    else {
        DCOM_request( '14 FF FF FF', 'undef', 'relax', 'erase fault memory with CD' );
        $expectedfaultstatus_CD_afterErase = {};
    }

    S_teststep( "Read DTC status bits via CD", 'AUTO_NBR', 'read_dtc_status_afterErasure' );    #measurement 8
    $faultstatus_CD_afterErase = LIFT_FaultMemory->read_fault_memory('Customer');

    S_teststep( "Erase PFM via PD", 'AUTO_NBR' );
    PD_ClearFaultMemory();
    S_wait_ms(6000);

    return 1;
}

sub TC_evaluation {

    $faults_stored = \@faults_created;                                                          # get the array reference to pass as parameter into subroutine
    $fault_mem_primary_afterQuali->evaluate_faults( $expectedFaults_primary_afterQuali, "read_primary_fault_firstquali" );    #evaluation 1

# EVALUATION OF SNAPSHOT DATA AFTER FAULT QUALIFICATION
    foreach my $record_label ( keys %{$tcpar_SnapshotRecordNbr} ) {
        my $recordnbr = $tcpar_SnapshotRecordNbr->{$record_label};
        foreach my $data_element (@snapshotstimultn) {
            _Evaluate_snapshotdata(
                $data_element,                                                                                                #evaluation 2
                $customer_faultmem_firstQuali->{$recordnbr},
                $faults_stored,
                $Snapshotdata_firstquali,
                $recordnbr,
                "read_snapshotdata_firstquali");
        }
        if ( $additional_stimulation eq 'true' ) {
            foreach my $data_element (@additional_snapshotstimultn) {
                FM_snapshotdata_evaluation( $data_element, $customer_faultmem_firstQuali->{$recordnbr}, $faults_stored, $Snapshotdata_firstquali, $recordnbr, "read_snapshotdata_firstquali" );
            }
        }
    }
    
# EVALUATION OF SNAPSHOT DATA AFTER FAULT QUALIFICATION AND RESET
    foreach my $record_label ( keys %{$tcpar_SnapshotRecordNbr} ) {
        my $recordnbr = $tcpar_SnapshotRecordNbr->{$record_label};
        foreach my $data_element (@snapshotstimultn) {
            _Evaluate_snapshotdata(
                $data_element,                                                                                                  #evaluation 3
                $customer_faultmem_reset->{$recordnbr},
                $faults_stored,
                $Snapshotdata_firstquali,
                $recordnbr,
                "read_snapshotdata_reset");
        }
        if ( $additional_stimulation eq 'true' ) {
            foreach my $data_element (@additional_snapshotstimultn) {
                FM_snapshotdata_evaluation( $data_element, $customer_faultmem_reset->{$recordnbr}, $faults_stored, $Snapshotdata_firstquali, $recordnbr, "read_snapshotdata_reset" );
            }
        }
    }
    
# EVALUATION OF SNAPSHOT DATA AFTER FAULT DEQUALIFICATION
    $fault_mem_primary_FltRemoval->evaluate_faults( $expectedFaults_primary_FltRemoval, "read_primary_fltmem_FltRemoval" );    #evaluation 4
    foreach my $record_label ( keys %{$tcpar_SnapshotRecordNbr} ) {
        my $recordnbr = $tcpar_SnapshotRecordNbr->{$record_label};
        foreach my $data_element (@snapshotstimultn) {
            _Evaluate_snapshotdata(
                $data_element,                                                                                                 #evaluation 5
                $customer_faultmem_FltRemoval->{$recordnbr},
                $faults_stored,
                $Snapshotdata_firstquali,
                $recordnbr,
                "read_snapshotdata_FltRemoval");
        }
        if ( $additional_stimulation eq 'true' ) {
            foreach my $data_element (@additional_snapshotstimultn) {
                FM_snapshotdata_evaluation( $data_element, $customer_faultmem_FltRemoval->{$recordnbr}, $faults_stored, $Snapshotdata_firstquali, $recordnbr, "read_snapshotdata_FltRemoval" );
            }
        }
    }

    my ( $faults_to_evaluate, $oldestfault_sameDTC );
    if ( defined $tcpar_additional_fault ) {
        ( $faults_to_evaluate, $oldestfault_sameDTC ) = _Additional_flt_evaluate_snapshotdata($faults_stored);                  #evaluation 6
    }
    else {
        $faults_to_evaluate = $faults_stored;

    }
# EVALUATION OF SNAPSHOT DATA AFTER PREVIOUS FAULT REQUALIFICATION    
    foreach my $record_label ( keys %{$tcpar_SnapshotRecordNbr} ) {
        my $recordnbr = $tcpar_SnapshotRecordNbr->{$record_label};
        foreach my $data_element (@snapshotstimultn) {
            _Evaluate_snapshotdata(
                $data_element,                                                                                                  #evaluation 7
                $customer_faultmem_addtnalflt->{$recordnbr},
                $faults_to_evaluate,
                $Snapshotdata_firstquali,
                $recordnbr,
                "read_snapshotdata_addtnlflt");
        }
       if ( $additional_stimulation eq 'true' ) {
            foreach my $data_element (@additional_snapshotstimultn) {
                FM_snapshotdata_evaluation( $data_element, $customer_faultmem_addtnalflt->{$recordnbr}, $faults_to_evaluate, $Snapshotdata_firstquali, $recordnbr, "read_snapshotdata_addtnlflt" );
            }
        }
    }
# EVALUATION OF SNAPSHOT DATA AFTER ADDITIONAL FAULT QUALIFICATION     
    if ( defined $tcpar_additional_fault ) {
        my @additionalfaults;
        my $additionalfaults_to_evaluate;
        S_w2rep(" reading addtnl flt");
        foreach my $record_label ( keys %{$tcpar_SnapshotRecordNbr} ) {
            my $recordnbr = $tcpar_SnapshotRecordNbr->{$record_label};
            foreach my $data_element (@snapshotstimultn) {
                push( @additionalfaults, $tcpar_additional_fault ) if ( $recordnbr eq '1' );
                push( @additionalfaults, $oldestfault_sameDTC ) if ( defined $oldestfault_sameDTC and $recordnbr eq '0' );
                $additionalfaults_to_evaluate = \@additionalfaults;
                _Evaluate_snapshotdata(
                    $data_element,    #evaluation 7
                    $customer_faultmem_addtnalflt->{$recordnbr},
                    $additionalfaults_to_evaluate,
                    $Snapshotdata_firstquali,
                    $recordnbr,
                    "read_snapshotdata_addtnlflt");
            }
            if ( $additional_stimulation eq 'true' ) {
                foreach my $data_element (@additional_snapshotstimultn) {
                    FM_snapshotdata_evaluation( $data_element, $customer_faultmem_addtnalflt->{$recordnbr}, $additionalfaults_to_evaluate, $Snapshotdata_firstquali, $recordnbr, "read_snapshotdata_addtnlflt" );
                }
            }
        }
    }

    $faultstatus_CD_afterErase->evaluate_faults( $expectedfaultstatus_CD_afterErase, "read_dtc_status_afterErasure" );              #evaluation 8

    return 1;
}

sub TC_finalization {

    # Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(10000);

    # Read fault memory after clearing fault memory
    PD_ReadFaultMemory();
    S_wait_ms(2000);

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

    return 1;
}

sub _Evaluate_snapshotdata {
    my $data_element          = shift;
    my $custflt_mem           = shift;
    my $faults_qualified      = shift;
    my $expected_snapshotdata = shift;
    my $snapshot_recordNbr    = shift;
    my $keyword               = shift;

    # local variables
    my ( $expected_data, $detected_value );

    foreach my $faultName (@$faults_qualified) {

        #Get the data source and tolerance for every data element from Mapping_CustomerData.pm
        my $source_data_element = $main::ProjectDefaults->{'Mapping_SnapshotData'}{'MEMBER_DATA_DEFINITION'}{$data_element}{'DataSource'};

        # Get the detected data  for $data_element for $faultName
        S_w2rep( " ***************Snapshot record data validation($keyword) for fault '$faultName' *************", 'magenta' );
        S_w2rep( " ***************Data element $data_element validation *******",                                  'magenta' );
        S_teststep_2nd_level( "Check the snapshot data for $data_element ($source_data_element) for fault '$faultName' ", 'AUTO_NBR' );
        $detected_value = $custflt_mem->get_snapshot_data_value_decoded( $faultName, $data_element, $snapshot_recordNbr );
        my $tolerance = $main::ProjectDefaults->{'Mapping_SnapshotData'}{'MEMBER_DATA_DEFINITION'}{$data_element}{'Tolerance'};

        if ( $source_data_element eq 'SquibResistance' ) {

            # Get the list of all configured squibs for variant under test
            my ( $result, $configured_squibs_aref ) = SYC_SQUIB_get_all_configured();
            foreach my $squib ( @{$configured_squibs_aref} ) {

                # Get expected value of squib resistance for every squib
                $expected_data = $expected_snapshotdata->{$data_element}{$squib};
                EVAL_evaluate_value( $faultName . "_" . $squib, $detected_value, '==', $expected_data, $tolerance, 'relative' );
                S_teststep_expected( "Expected resistance for $squib for fault $faultName : $expected_data", $keyword );
                S_teststep_detected( "Detected resistance for $squib for fault $faultName with relative tolerance  $tolerance : $detected_value", $keyword );
            }
        }
        elsif ( $source_data_element =~ /Switch/ ) {
            if ( $source_data_element eq 'SwitchState' ) {
                $expected_data = $expected_snapshotdata->{$data_element};
                EVAL_evaluate_string( $faultName . "_" . $data_element . "State", $expected_data, $detected_value );
                S_teststep_expected( "Expected SwitchState for $data_element for fault $faultName : $expected_data", $keyword );
                S_teststep_detected( "Detected SwitchState for $data_element for fault $faultName : $detected_value", $keyword );
            }
            elsif ( $source_data_element eq 'SwitchResistance' ) {

                # Get the list of all configured switches for variant under test
                my ( $result, $configured_switches_aref ) = SYC_SWITCH_get_all_configured();
                foreach my $switch ( @{$configured_switches_aref} ) {

                    # Get expected value of switch resistance/switchstate for every switch
                    $expected_data = $expected_snapshotdata->{$data_element}{$switch};
                    EVAL_evaluate_value( $faultName . "_" . $switch . "resistance", $detected_value, '==', $expected_data, $tolerance, 'relative' );
                    S_teststep_expected( "Expected SwitchResistance for $switch for fault $faultName : $expected_data", $keyword );
                    S_teststep_detected( "Detected SwitchResistance for $switch for fault $faultName with relative tolerance  $tolerance : $detected_value", $keyword );
                }
            }
        }
        else {
            if ( $source_data_element eq 'DTC' ) {
                $expected_data = $expected_snapshotdata->{$data_element}{$faultName};
            }
            else {
                $expected_data = $expected_snapshotdata->{$data_element};
            }
            EVAL_evaluate_value( $faultName . "_" . $data_element, $detected_value, '==', $expected_data, $tolerance, 'relative' );
            S_teststep_expected( "Expected $data_element for fault $faultName : $expected_data", $keyword );
            S_teststep_detected( "Detected $data_element for fault $faultName with relative tolerance  $tolerance : $detected_value", $keyword );
        }
    }
    return 1;
}

sub _Additional_flt_evaluate_snapshotdata {

    my (@faults_without_sameDTC);
    my $oldestfault_sameDTC;
    $expectedFaults_primary_addtnalflt = $expectedFaults_primary_afterQuali;
    $expectedFaults_primary_addtnalflt->{'mandatory'}->{$tcpar_additional_fault} = { 'DecodedStatus' => { 'ConfirmedDTC' => 1, 'TestFailed' => 1 }, };
    $fault_mem_primary_addtnalflt->evaluate_faults( $expectedFaults_primary_addtnalflt, "read_primary_fltmem_addtnlflt" );

    my $faultproperty        = FM_fetchFaultInfo($tcpar_additional_fault);    #get the info from Fault mapping file
    my $additional_fault_DTC = $faultproperty->{'DTC'};

    foreach my $fault (@$faults_stored) {

        # Get DTC of every stored fault to check with DTC of additional fault
        my $faultproperty = FM_fetchFaultInfo($fault);
        my $fault_DTC     = $faultproperty->{'DTC'};
        if ( $fault_DTC eq $additional_fault_DTC ) {
            S_w2rep("$fault and $tcpar_additional_fault have same DTC $fault_DTC , hence snapshot record for $tcpar_additional_fault will be stored ");
            $oldestfault_sameDTC = $fault;
        }
        else {
            # list of all faults except the one with DTC identical to additional fault
            push( @faults_without_sameDTC, $fault );
        }
    }
    return ( \@faults_without_sameDTC, $oldestfault_sameDTC );
}

sub _Qualify_all_faults {

    # ---- CREATE FAULTS ---

    # External Faults
    if ( defined $tcpar_External_fault_name ) {
        S_teststep_2nd_level( "Create '$tcpar_External_fault_name'  ", 'AUTO_NBR' );
        FM_createFault($tcpar_External_fault_name);
        if ( $tcpar_External_fault_name =~ m/Crosscoupling/i ) {
            $CC_flt = FM_Fetch_CrosscoupledFault($tcpar_External_fault_name);
            S_w2rep("cross coupling fault=$CC_flt");
            $expectedFaults_primary_afterQuali->{'mandatory'}->{$CC_flt} = { 'DecodedStatus' => { 'TestFailed' => 1 }, };
        }
    }

    # Internal erasable faults
    if ( defined $tcpar_Internal_erasable_fault_name ) {
        S_teststep_2nd_level( "Create '$tcpar_Internal_erasable_fault_name' ", 'AUTO_NBR' );
        FM_createFault($tcpar_Internal_erasable_fault_name);
    }

    # internal non-erasable faults
    if ( defined $tcpar_Internal_non_erasable_fault_name ) {
        S_teststep_2nd_level( "Create '$tcpar_Internal_non_erasable_fault_name' ", 'AUTO_NBR' );
        FM_createFault($tcpar_Internal_non_erasable_fault_name);
        $Internal_non_erasable_fault_name='true';
    }
    return 1;

}

sub _Remove_all_faults {

    # External faults
    if ( defined $tcpar_External_fault_name ) {
        S_teststep_2nd_level( "Remove '$tcpar_External_fault_name', wait for dequalification time", 'AUTO_NBR' );
        FM_removeFault($tcpar_External_fault_name);
        $expectedFaults_primary_FltRemoval->{'mandatory'}->{$CC_flt} = { 'DecodedStatus' => { 'ConfirmedDTC' => 1, 'TestFailed' => 0 }, } if ( defined $CC_flt );
    }

    # Internal faults
    if ( defined $tcpar_Internal_erasable_fault_name ) {
        S_teststep_2nd_level( "Remove '$tcpar_Internal_erasable_fault_name'", 'AUTO_NBR' );
        FM_removeFault($tcpar_Internal_erasable_fault_name);
    }

    if ( defined $tcpar_Internal_non_erasable_fault_name ) {
        S_teststep_2nd_level( "Remove '$tcpar_Internal_non_erasable_fault_name'", 'AUTO_NBR' );
        FM_removeFault($tcpar_Internal_non_erasable_fault_name);
    }

    return 1;

}

sub _Read_SnapshotData_CurrentValues {
    my $read_values;
    foreach my $data_element ( keys %{$tcpar_SnapshotData_FirstTimeQuali} ) {

        #Get the data source for every data element from Mapping_CustomerData.pm
        my $data_source_read = $main::ProjectDefaults->{'Mapping_SnapshotData'}{'MEMBER_DATA_DEFINITION'}{$data_element}{'DataSource'};
        unless ( defined $data_source_read ) {
            S_set_error(" Data source is not defined for $data_element, testcase aborted. Please define data source in 'Mapping_CustomerData' for all the members mentioned in testcase parameters ");
            return 0;
        }
        S_teststep_2nd_level( "Read $data_element($data_source_read) current values", 'AUTO_NBR' );
        if ( $data_source_read eq 'COM_Signal' ) {

            # Get the COM signal name from Mapping_CustomerData.pm
            my $bus_signal_name = $main::ProjectDefaults->{'Mapping_SnapshotData'}{'MEMBER_DATA_DEFINITION'}{$data_element}{'Signal_name'};

            # Read the current value on COM signal
            my ( $signalvalue, $unit ) = NET_read_signal($bus_signal_name);

            # Store the read value
            $read_values->{$data_element} = $signalvalue;

        }
        elsif ( $data_source_read eq 'PDVariable' ) {

            # Get the PD variable name from Mapping_CustomerData.pm
            my $variable_name = $main::ProjectDefaults->{'Mapping_SnapshotData'}{'MEMBER_DATA_DEFINITION'}{$data_element}{'Variable_name'};

            # Get the PD variable type from Mapping_CustomerData.pm
            my $variable_type = $main::ProjectDefaults->{'Mapping_SnapshotData'}{'MEMBER_DATA_DEFINITION'}{$data_element}{'Variable_type'};

            # Read the current value of PD variable
            my $value_read = S_aref2dec( PD_ReadMemoryByName($variable_name), $variable_type );

            # Store the read value
            $read_values->{$data_element} = $value_read;
        }
    }
    return ( \%$read_values );

}

sub _Stimulate_snapshotdata {
    my $stimulated_snapshotdata = shift;
    my $keyword                 = shift;
    my $stimulatedData;

    foreach my $data_element ( keys %{$stimulated_snapshotdata} ) {
        my $data = $stimulated_snapshotdata->{$data_element};

        #Get the data source for every data element from Mapping_CustomerData.pm
        my $data_source = $main::ProjectDefaults->{'Mapping_SnapshotData'}{'MEMBER_DATA_DEFINITION'}{$data_element}{'DataSource'};
        unless ( defined $data_source ) {
            S_set_error(" data source is not defined for $data_element, testcase aborted ");
            return;
        }
        S_w2rep("Data_element =$data_element,Data source= $data_source");
        if ( exists $dispatchTable->{$data_source} ) {
            $stimulatedData->{$data_element} = $dispatchTable->{$data_source}->( $data_element, $data );
            push( @snapshotstimultn, $data_element ) if ( $keyword eq 'FirstQuali' );
        }
        else {
            $stimulatedData->{$data_element} = FM_snapshot_stimulation( $data_source, $data_element, $data );
            $additional_stimulation = 'true';
            push( @additional_snapshotstimultn, $data_element ) if ( $keyword eq 'FirstQuali' );

        }
        $stimulatedData->{$data_element} = $data;
    }
    return ($stimulatedData);

}

sub _COM_stimulation {

    my $element_under_test = shift;
    my $data_to_stimulate  = shift;
    S_teststep_2nd_level( "Set $element_under_test to $data_to_stimulate", 'AUTO_NBR' );

    # Get the COM signal name from Mapping_CustomerData.pm
    my $bus_signal_name = $main::ProjectDefaults->{'Mapping_SnapshotData'}{'MEMBER_DATA_DEFINITION'}{$element_under_test}{'Signal_name'};

    # Write the COM signal with data defined in TS.
    NET_write_signal( $bus_signal_name, $data_to_stimulate ) unless ( $data_to_stimulate eq 'read' );
    $data_to_stimulate = $COMread_values->{$element_under_test} if ( $data_to_stimulate eq 'read' );

    # Store the written value
    S_wait_ms(2000);
    return ($data_to_stimulate);
}

sub _PD_stimulation {

    my $element_under_test = shift;
    my $data_to_stimulate  = shift;
    S_teststep_2nd_level( "Set $element_under_test to $data_to_stimulate", 'AUTO_NBR' );

    # Get the PD variable name from Mapping_CustomerData.pm
    my $variable_name = $main::ProjectDefaults->{'Mapping_SnapshotData'}{'MEMBER_DATA_DEFINITION'}{$element_under_test}{'Variable_name'};

    # Get the PD variable type from Mapping_CustomerData.pm
    my $variable_type = $main::ProjectDefaults->{'Mapping_SnapshotData'}{'MEMBER_DATA_DEFINITION'}{$element_under_test}{'Variable_type'};
    if ( $data_to_stimulate ne 'read' ) {
        my $aref = S_dec2aref( $data_to_stimulate, $variable_type );

        # Write the PD variable with data defined in TS.
        PD_WriteMemoryByName( $variable_name, $aref );
    }
    else {
        $data_to_stimulate = $PDread_values->{$element_under_test};
    }

    # Store the written value
    return ($data_to_stimulate);
}

sub _Squib_resistance_stimulation {

    my $data_to_stimulate = shift;
    my $squib_resistance_faultquali;
    my ( $result, $configured_squibs_aref ) = SYC_SQUIB_get_all_configured();
    foreach my $squib ( @{$configured_squibs_aref} ) {
        S_teststep_2nd_level( "Set $squib to $data_to_stimulate", 'AUTO_NBR' );
        LC_SetResistance( $squib, $data_to_stimulate );
        S_wait_ms(1000);

        # Store the set resistance value
        $squib_resistance_faultquali->{$squib} = $data_to_stimulate;
    }
    return ($squib_resistance_faultquali);
}

sub _Switch_resistance_stimulation {
    my $data_to_stimulate = shift;
    my $switch_resistance_faultquali;
    my ( $result_configured, $configured_switches_aref ) = SYC_SWITCH_get_all_configured();
    foreach my $switch ( @{$configured_switches_aref} ) {
        S_teststep_2nd_level( "Set $switch to $data_to_stimulate", 'AUTO_NBR' );

        my ( $result_state, $state_value, $state_unit ) = SYC_SWITCH_get_state( $switch, 'PositionA' );

        # Set the resistance/current for each switch based on switch type
        LC_SetResistance( $switch, $data_to_stimulate ) if ( $state_unit eq 'R' );
        LC_SetCurrent( $switch, $data_to_stimulate ) if ( $state_unit eq 'I' );
        S_wait_ms(1000);
        $switch_resistance_faultquali->{$switch} = $data_to_stimulate;
    }
    return ($switch_resistance_faultquali);
}

sub _Voltage_stimulation {
    my $element_under_test = shift;
    my $data_to_stimulate  = shift;
    S_teststep_2nd_level( "Set $element_under_test to $data_to_stimulate", 'AUTO_NBR' );

    # Set the ECU voltage
    LC_SetVoltage($data_to_stimulate);
    S_wait_ms(2000);

    #Store the voltage info
    my $voltage_faultquali->{$element_under_test} = $data_to_stimulate;
    return ($data_to_stimulate);
}

sub _SwitchState_stimulation {
    my $element_under_test = shift;
    my $data_to_stimulate  = shift;
    S_teststep_2nd_level( "Set $element_under_test to $data_to_stimulate", 'AUTO_NBR' );
    _Set_device_state( $element_under_test, $data_to_stimulate );

    # Store the set switch state value
    my $switch_state_faultquali->{$element_under_test} = $data_to_stimulate;
    S_wait_ms(2000);
    return ($data_to_stimulate);
}

sub _Fetch_DTC {
    my $element_under_test = shift;
    my $data_to_stimulate  = shift;
    my $data_fetched;
    my $fault_DTC;
    S_teststep_2nd_level( "Get $element_under_test from $data_to_stimulate", 'AUTO_NBR' );

    # Get DTC info from mapping fault
    foreach my $fault (@$faults_stored) {
        my $faultproperty = FM_fetchFaultInfo($fault);
        my $DTC           = $faultproperty->{'DTC'};
        if ( $element_under_test eq 'DTC_LowByte' ) {
            $data_fetched = substr( $DTC, 6 );
        }
        else {
            $data_fetched = $DTC;
        }

        #Store the DTC info
        $fault_DTC->{$fault} = $data_fetched;
    }
    return ($fault_DTC);
}

sub _Set_device_state {
    my $switch_name = shift;
    my $condition   = shift;

    #checking whether switch is Mechanical or not
    my ( $switchTypeResult, $switch_type ) = SYC_SWITCH_get_type($switch_name);
    if ( ( $switch_type =~ /mechanical/ ) and ( $condition =~ m/Short2Gnd|OpenLine|Undefined|CrossCouple/ ) ) {
        S_set_error(" Switch $switch_name is of type $switch_type and hence faults cannot be created for this switch ");
        return 0;
    }

    #Append "Value" to $data for fetching info from SYC
    if ( $condition =~ m/Short2Gnd|OpenLine|Undefined/ ) {
        $condition = $condition . "Value";
        S_w2rep("SwitchState = $condition");
    }

    # Get the unit for each switch, unit can be R or I
    if ( ( $condition =~ m/PositionA|PositionB|Short2Gnd|OpenLine|Undefined/ ) and not( $switch_type =~ /mechanical/ ) ) {
        my ( $result, $state_value, $state_unit ) = SYC_SWITCH_get_state( $switch_name, $condition );
        LC_SetResistance( $switch_name, $state_value ) if ( $state_unit eq 'R' );
        LC_SetCurrent( $switch_name, $state_value ) if ( $state_unit eq 'I' );
    }
    elsif ( ( $condition =~ /Short2Bat/ ) and not( $switch_type =~ /mechanical/ ) ) {
        LC_ShortLines( [ $switch_name . '+', 'B+' ] );
    }
    elsif ( $condition =~ /CrossCouple/ ) {
        my @devices = LC_Get_names('BELT_LOCKS');

        if ( $switch_name eq $devices[0] ) {
            LC_ShortLines( [ $switch_name . '+', $devices[1] . '+' ] );
        }
        else {
            LC_ShortLines( [ $switch_name . '+', $devices[0] . '+' ] );
        }
        PD_ECUreset();
        S_wait_ms('TIMER_ECU_READY');
    }
    elsif ( $switch_type =~ /mechanical/ ) {
        if ( $condition eq 'PositionA' ) {
            LC_ConnectLine($switch_name);
        }
        elsif ( $condition eq 'PositionB' ) {
            LC_DisconnectLine($switch_name);
        }
        elsif ( $condition =~ /Short2Bat/ ) {
            LC_DisconnectLine($switch_name);
            LC_ShortLines( [ $switch_name . '+', 'B+' ] );
        }

    }
    else {
        S_set_error( "Switch state $condition not supported for this switch\n" . "Check Project constant under TSG4 Defaults" );
    }
    $condition = 'Faulty' unless ( $condition == ~/Position/ );

    return 1;
}

sub _Reset_stimulated_snapshotdata {

    foreach my $data_element ( keys %{$tcpar_SnapshotData_FirstTimeQuali} ) {
        my $data_type = $tcpar_SnapshotData_FirstTimeQuali->{$data_element};

        #Get the data source for every data element from Mapping_CustomerData.pm
        my $data_source_reset = $main::ProjectDefaults->{'Mapping_SnapshotData'}{'MEMBER_DATA_DEFINITION'}{$data_element}{'DataSource'};
        unless ( defined $data_source_reset ) {
            S_set_error(" data source is not defined for $data_element, testcase aborted ");
        }
        if ( $data_source_reset eq 'COM_Signal' ) {
            if ( $data_type ne 'read' ) {

                # Get the COM signal name from Mapping_CustomerData.pm
                my $bus_signal_name = $main::ProjectDefaults->{'Mapping_SnapshotData'}{'MEMBER_DATA_DEFINITION'}{$data_element}{'Signal_name'};
                my $signalvalue     = $current_read_data->{$data_element};
                S_w2rep("Data_element =$data_element,Data=$signalvalue");

                # Write the COM signal with data stored earlier.
                NET_write_signal( $bus_signal_name, $signalvalue );
            }
            S_wait_ms(2000);
        }
        elsif ( $data_source_reset eq 'PDVariable' ) {
            if ( $data_type ne 'read' ) {

                # Get the PD variable name from Mapping_CustomerData.pm
                my $variable_name = $main::ProjectDefaults->{'Mapping_SnapshotData'}{'MEMBER_DATA_DEFINITION'}{$data_element}{'Variable_name'};

                # Get the PD variable type from Mapping_CustomerData.pm
                my $variable_type = $main::ProjectDefaults->{'Mapping_SnapshotData'}{'MEMBER_DATA_DEFINITION'}{$data_element}{'Variable_type'};
                my $value_read    = $current_read_data->{$data_element};
                my $aref          = S_dec2aref( $value_read, $variable_type );

                # Write the PD variable with data stored earlier.
                PD_WriteMemoryByName( $variable_name, $aref );
            }
        }
        elsif ( $data_source_reset eq 'SquibResistance' ) {

            # Get the list of all configured squibs for variant under test
            my ( $result, $configured_squibs_aref ) = SYC_SQUIB_get_all_configured();
            foreach my $squib ( @{$configured_squibs_aref} ) {

                # Set the resistance of each squib to default '2 ohm'
                LC_SetResistance( $squib, '2' );
                S_wait_ms(1000);
            }
        }
        elsif ( ( $data_source_reset =~ /SwitchResistance/ ) or ( $data_source_reset eq 'SwitchState' ) ) {

            # Get the list of all configured switches for variant under test
            my ( $result, $configured_switches_aref ) = SYC_SWITCH_get_all_configured();
            foreach my $switch ( @{$configured_switches_aref} ) {

                # Set the state of each switch to default condition
                my ( $result, $default_condition ) = SYC_SWITCH_get_DefaultCondition($switch);
                LC_SetLogicalState( $switch, $default_condition );
                S_wait_ms(1000);
            }
        }
        elsif ( $data_source_reset eq 'Voltage' ) {

            # Set the ECU voltage to default
            LC_SetVoltage('U_BATT_DEFAULT');
            S_wait_ms(2000);
        }
    }

    return 1;

}

sub _Trigger_quali_dequali_fault {
    my $triggerType = shift;

    if ( lc($tcpar_fault_monitoring_type) eq 'init' ) {
        S_teststep_2nd_level( "Reset ECU", 'AUTO_NBR' );
        LC_ECU_Off();
        S_wait_ms('TIMER_ECU_OFF');
        LC_ECU_On();
        S_wait_ms('TIMER_ECU_READY');
    }
    else {
        S_teststep_2nd_level( "Wait for $triggerType time of fault", 'AUTO_NBR' );
        S_wait_ms($MAX_FAULT_DEQUALIFICATION_TIME_MS) if ( $triggerType eq 'Dequalification' );
        S_wait_ms($MAX_FAULT_QUALIFICATION_TIME_MS)   if ( $triggerType eq 'Qualification' );
    }

    return 1;

}

sub _Ecu_reset {

    # can't use LC_ECU_Off() LC_ECU_On(), because it will dequalify VbatLow/High fault
    LC_PowerDisconnect();
    S_wait_ms('TIMER_ECU_OFF');
    LC_PowerConnect();
    S_wait_ms('TIMER_ECU_READY');
    return 1;
}

1;
