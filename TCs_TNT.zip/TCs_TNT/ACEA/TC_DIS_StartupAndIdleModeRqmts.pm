#### TEST CASE MODULE
package TC_DIS_StartupAndIdleModeRqmts;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
###-------------------------------
our $VERSION = q$Revision: 1.18 $;
our $HEADER = q$Header: ACEA/TC_DIS_StartupAndIdleModeRqmts.pm 1.18 2014/03/05 12:44:06ICT BAA1BMH develop  $;
##################################

#### INCLUDE ENGINE MODULES ####
use LIFT_general;   
use LIFT_PD; 
use LIFT_CD; 
use LIFT_evaluation;
use GENERIC_DCOM;
use FuncLib_TNT_GEN;
use FuncLib_Project_GEN;
use FuncLib_ACEA_TNT;

##################################

our $PURPOSE = "To test ACEA deployemnt during idle mode condition and to verify deployment loop status during initialization phase";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

#-> update documentation that somebody else can use the test without asking you
#-> delete parameter section if no paramteres are used
#-> note that POD documentation needs entirely empty lines before and after keywords (e.g. =head1, =cut ...) 

=head1 TESTCASE MODULE

TC_template  $Revision: 1.18 $

=head1 PURPOSE



=head1 TESTCASE DESCRIPTION

	[parameter used]
    Testcase Parameter:
	purpose
	SystemMode
	ACLSupported
	ExpResp_DLT_Init_BeforeSquibFiring
	ExpResp_DLT_BeforeSquibFiring
	ExpResp_DLT_Init_AfterSquibFiring
	ExpResp_DLT_AfterSquibFiring
	Exp_DeploymentloopStatusInEEPROM_Init_BeforeSquibFiring
	Exp_DeploymentloopStatusInEEPROM_BeforeSquibFiring
	Exp_DeploymentloopStatusInEEPROM_Init_AfterSquibFiring
	Exp_DeploymentloopStatusInEEPROM_AfterSquibFiring

    [initialisation]
	Step 1: Re-initialize EEPROM
	Step 2: Standard Preparation
	Step 3: NoACLConnected
	Step 4: SendTesterPresentCyclically
	Step 5: SetSystemMode


    [stimulation & measurement]
	Execute Step 1-2 if SystemMode = 'Init',
	Step 1:Power on reset
	Step 2: Read default deployment loop
	Step 2: Read default loop status from EEPROM
	Execute Step 3 if SystemMode = 'Idle',
	Step 3: Read default deployment loop table
	Step 3: Read default loop status from EEPROM
	Step 4: Enter into safety sysyem diagnostic session
	Step 5: Getting security access for ACEA
	Step 6: Execute disposal Program loader
	Execute Step 7 if ACLSupported ='yes',
	Step 7: Connecting the ACL PWM signal
	Step 8: Fire a squib
	Execute Step 9 if SystemMode = 'Init',
	Step 9:Power on reset
	Step 10: Read default deployment loop table
	Step 10: Read default loop status from EEPROM
	Step 11 & 12: Read deployment loop table
	Step 11 & 12: Read loop status from EEPROM

    [evaluation]
	Step 1:Power on reset - No evaluation
	Step 2: Read default deployment loop table
	Step 2: Read default loop status from EEPROM
	Execute Step 3 if SystemMode = 'Idle',
	Step 3: Read default deployment loop table
	Step 3: Read default loop status from EEPROM
	Step 4: Evaluate response for Enter into safety sysyem diagnostic session
	Step 5: Evaluate response for Getting security access for ACEA
	Step 6: Evaluate response for Execute disposal Program loader
	Step 7: No evaluation
	Step 8: Evaluate response for Fire a squib
	Step 9: No evaluation
	Step 10: Evaluate default deployment loop table
	Step 10: Evaluate default loop status from EEPROM
	Step 11 & 12: Evaluate deployment loop table
	Step 11 & 12: Evaluate loop status from EEPROM

    [finalisation]
	Bring back the system to normal state

=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR purpose : Purpose of the test
	SCALAR SystemMode : System mode to test
	SCALAR ACLSupported : I ACL supported?
	SCALAR ExpResp_DLT_Init_BeforeSquibFiring : Expeced Response Read DLT during Init and Before Squib Firing
	SCALAR ExpResp_DLT_BeforeSquibFiring : Expeced Response Read DLT after Init and Before Squib Firing
	SCALAR ExpResp_DLT_Init_AfterSquibFiring : Expeced Response Read DLT suring Init and after Squib Firing
	SCALAR ExpResp_DLT_AfterSquibFiring : Expeced Response Read DLT after Init and after Squib Firing
	SCALAR Exp_DeploymentloopStatusInEEPROM_Init_BeforeSquibFiring : Expeced Response Read DeploymentloopStatusInEEPROM during Init and Before Squib Firing
	SCALAR Exp_DeploymentloopStatusInEEPROM_BeforeSquibFiring : Expeced Response Read DeploymentloopStatusInEEPROM after Init and Before Squib Firing
	SCALAR Exp_DeploymentloopStatusInEEPROM_Init_AfterSquibFiring : Expeced Response Read DeploymentloopStatusInEEPROM suring Init and after Squib Firing
	SCALAR Exp_DeploymentloopStatusInEEPROM_AfterSquibFiring : Expeced Response Read DeploymentloopStatusInEEPROM after Init and after Squib Firing

=head2 PARAMETER EXAMPLES

    [TC_template.dummy]
	purpose  = 'To test ACEA deployemnt during idle mode condition and to verify deployment loop status during initialization phase'
	SystemMode = '<Test Heading>'
	ACLSupported = 'yes' #'yes' or 'no'
	ExpResp_DLT_Init_BeforeSquibFiring = '0x00'
	ExpResp_DLT_BeforeSquibFiring = '0x00'
	ExpResp_DLT_Init_AfterSquibFiring = '0x20'
	ExpResp_DLT_AfterSquibFiring = '0x20'
	Exp_DeploymentloopStatusInEEPROM_Init_BeforeSquibFiring = '0x0000000000000000'
	Exp_DeploymentloopStatusInEEPROM_BeforeSquibFiring = '0x0000000000000000'
	Exp_DeploymentloopStatusInEEPROM_Init_AfterSquibFiring = '0x0000000000000001'
	Exp_DeploymentloopStatusInEEPROM_AfterSquibFiring = '0x0000000000000001'

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#-> Input parameters for test defination.
my ($tcpar_SystemMode,
	$tcpar_ACLSupported,
	$tcpar_ExpResp_DLT_Init_BeforeSquibFiring,
	$tcpar_ExpResp_DLT_BeforeSquibFiring,
	$tcpar_ExpResp_DLT_Init_AfterSquibFiring,
	$tcpar_ExpResp_DLT_AfterSquibFiring,
	$tcpar_Exp_DeploymentloopStatusInEEPROM_Init_BeforeSquibFiring,
	$tcpar_Exp_DeploymentloopStatusInEEPROM_BeforeSquibFiring,
	$tcpar_Exp_DeploymentloopStatusInEEPROM_Init_AfterSquibFiring,
	$tcpar_Exp_DeploymentloopStatusInEEPROM_AfterSquibFiring);
	
#-> Parameters for test verification.
my ($Resp_ReadDLT_Init_BeforeSquibFiring,
	$DPLStatus_EEPROM_Init_BeforeSquibFiring,
	$Resp_ReadDLT_BeforeSquibFiring,
	$DPLStatus_EEPROM_BeforeSquibFiring,
	$Resp_FireSquib,
	$Resp_ReadDLT_Init_AfterSquibFiring,
	$DPLStatus_EEPROM_Init_AfterSquibFiring,
	$Resp_ReadDLT_AfterSquibFiring,
	$DPLStatus_EEPROM_AfterSquibFiring);
	my $TP_handle;
	
my ($projpar_LoopID,
	$projpar_LoopStatus_BitPosition);	
	
my ($ExecuteSPL_With_Conversion);	
	
	$ExecuteSPL_With_Conversion = '01';	
	
my ($IdleMode_var, 
	$Value);
	
my $FaultMapping = $LIFT_PROJECT::Defaults->{'Mapping_FAULT'};	
	
sub TC_set_parameters {

	#-> Input parameters for test defination.
	$tcpar_SystemMode = GEN_Read_mandatory_testcase_parameter( 'SystemMode' );
	$tcpar_ACLSupported = GEN_Read_mandatory_testcase_parameter( 'ACLSupported' );
	$tcpar_ExpResp_DLT_Init_BeforeSquibFiring = GEN_Read_mandatory_testcase_parameter( 'ExpResp_DLT_Init_BeforeSquibFiring' );
	$tcpar_ExpResp_DLT_BeforeSquibFiring = GEN_Read_mandatory_testcase_parameter( 'ExpResp_DLT_BeforeSquibFiring' );
	$tcpar_ExpResp_DLT_Init_AfterSquibFiring = GEN_Read_mandatory_testcase_parameter( 'ExpResp_DLT_Init_AfterSquibFiring' );
	$tcpar_ExpResp_DLT_AfterSquibFiring = GEN_Read_mandatory_testcase_parameter( 'ExpResp_DLT_AfterSquibFiring' );
	$tcpar_Exp_DeploymentloopStatusInEEPROM_Init_BeforeSquibFiring = GEN_Read_mandatory_testcase_parameter( 'Exp_DeploymentloopStatusInEEPROM_Init_BeforeSquibFiring' );
	$tcpar_Exp_DeploymentloopStatusInEEPROM_BeforeSquibFiring = GEN_Read_mandatory_testcase_parameter( 'Exp_DeploymentloopStatusInEEPROM_BeforeSquibFiring' );
	$tcpar_Exp_DeploymentloopStatusInEEPROM_Init_AfterSquibFiring = GEN_Read_mandatory_testcase_parameter( 'Exp_DeploymentloopStatusInEEPROM_Init_AfterSquibFiring' );
	$tcpar_Exp_DeploymentloopStatusInEEPROM_AfterSquibFiring = GEN_Read_mandatory_testcase_parameter( 'Exp_DeploymentloopStatusInEEPROM_AfterSquibFiring' );
  
	#parameters reading from project_constants file
	$projpar_LoopID = S_read_project_parameter('LoopId');
	$projpar_LoopStatus_BitPosition = S_read_project_parameter('LoopStatus_BitPosition');  
  
return 1;
}


#### INITIALIZE TC #####
sub TC_initialization {

	CA_trace_start();

	S_w2rep("Set the preconditions for this test case", 'blue');
	my $msg_aref = $LIFT_PROJECT::Defaults->{"CUSTOMER_DIAGNOSIS"}{"TesterPresent_SupressPosResp"}{"Requests"}{"REQ_TesterPresent_SupressPosResp"}{'Requests'};
	my $msg_ID = $LIFT_PROJECT::Defaults->{"CUSTOMER_DIAGNOSIS"}{'RequestID_disposal'};
	my $cycle  = 4500;

	#Taking the EEPROM dump from fault free setup and Initializating EEPROM.
	if(not defined ($LIFT_PROJECT::Defaults->{'TEMP'}{'Count'}))
	{
	S_w2rep("Step 1: Re-initialize EEPROM", 'blue');		
	GEN_printComment("Taking the EEPROM dump from fault free setup for the 1st time");
	PD_DumpEEPROM('$LIFT_PRJCFG_path/../reports/Temp_EEPROM_Dump.hex');
	S_wait_ms(2000);
	$LIFT_PROJECT::Defaults->{'TEMP'}{'Count'} = 0x01; #Count to take EEPROM dump for only 1st time.	
	} 
	
	S_w2rep("Step 2: Standard Preparation", 'blue');
	GEN_StandardPrepNoFault();
	GEN_ProjectSpecificSettings();	
	
	S_w2rep("Step 3: NoACLConnected", 'blue');
	my $status = ACEA_SetACLConnection ('Disconnect');
	
	#Setting the request ID and response ID for ACEA.
	GDCOM_set_addressing_mode("disposal");    #Setting disposal request ID and response ID
	
	S_w2rep("Step 4: SendTesterPresentCyclically", 'blue');
	$TP_handle = GDCOM_start_CyclicTesterPresent($msg_aref,$msg_ID,$cycle);

	S_w2rep("Step 5: SetSystemMode", 'blue');
	($IdleMode_var, $Value) = ACEA_SetECUMode ($tcpar_SystemMode); 
	
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	#remove 0x from loop id. 0x01 --> 01
	$projpar_LoopID =~ s/0x//;

	if($tcpar_SystemMode eq 'Init')
	{
		S_w2rep("Step 1:Power on reset", 'blue');
		GEN_Power_on_Reset('NO_WAIT');
		#S_wait_ms(500);
		S_w2rep("Step 2: Read default deployment loop table", 'blue');
		$Resp_ReadDLT_Init_BeforeSquibFiring = ACEA_Read_DiploymentLoopTable();

		S_w2rep("Step 2: Read default loop status from EEPROM", 'blue');
		$DPLStatus_EEPROM_Init_BeforeSquibFiring = ACEA_ReadDPLStatusEEPROM();

		S_wait_ms( 'TIMER_ECU_READY' );	
	}
	elsif($tcpar_SystemMode eq 'Idle')
	{
		S_w2rep("Step 3: Read default deployment loop table", 'blue');
		$Resp_ReadDLT_BeforeSquibFiring = ACEA_Read_DiploymentLoopTable();

		S_w2rep("Step 3: Read default loop status from EEPROM", 'blue');
		$DPLStatus_EEPROM_BeforeSquibFiring = ACEA_ReadDPLStatusEEPROM();
	}
	else
	{
		#Set warning for Invalid system mode.
		S_set_error("Invalid system mode $tcpar_SystemMode", 0); #warning!
	}

	S_w2rep("Step 4: Enter into safety sysyem diagnostic session", 'blue');
	GDCOM_StartSession('DisposalSession');
	
	S_w2rep("Step 5: Getting security access for ACEA", 'blue');
	ACEA_Get_SecurityAccess();
	
	S_w2rep("Step 6: Execute disposal Program loader", 'blue');
	ACEA_ExecuteDisposalProgramLoader($ExecuteSPL_With_Conversion);

	if($tcpar_ACLSupported eq 'yes'){
			
		S_w2rep("Step 7: Connecting the ACL PWM signal", 'blue');
		ACEA_SetACLConnection('Connect');			
	}		

	S_w2rep("Step 8: Fire a squib", 'blue');
	$Resp_FireSquib = ACEA_FireSquib($projpar_LoopID);

	if($tcpar_SystemMode eq 'Init')
	{
		S_w2rep("Step 9:Power on reset", 'blue');
		GEN_Power_on_Reset('NO_WAIT');
		S_w2rep("Step 10: Read deployment loop table", 'blue');
		$Resp_ReadDLT_Init_AfterSquibFiring = ACEA_Read_DiploymentLoopTable();
		S_wait_ms(2000); #wait
		S_w2rep("Step 10: Read loop status from EEPROM", 'blue');
		$DPLStatus_EEPROM_Init_AfterSquibFiring = ACEA_ReadDPLStatusEEPROM();

		S_wait_ms( 'TIMER_ECU_READY' );	
	}
	else
	{
		#Set warning for Invalid system mode.
		S_set_error("Invalid system mode $tcpar_SystemMode", 0); #warning!
	}	
	S_w2rep("Step 11 & 12: Read deploym	ent loop table", 'blue');
	$Resp_ReadDLT_AfterSquibFiring = ACEA_Read_DiploymentLoopTable();
	S_wait_ms(2000); #wait
	S_w2rep("Step 11 & 12: Read loop status from EEPROM", 'blue');
	$DPLStatus_EEPROM_AfterSquibFiring = ACEA_ReadDPLStatusEEPROM();

		
return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	#remove 0x from loop id. 0x01 --> 01
	$projpar_LoopID =~ s/0x//;

	$tcpar_ExpResp_DLT_Init_BeforeSquibFiring =~ s/0x//;
	$tcpar_ExpResp_DLT_BeforeSquibFiring =~ s/0x//;
	$tcpar_ExpResp_DLT_Init_AfterSquibFiring =~ s/0x//;
	$tcpar_ExpResp_DLT_AfterSquibFiring =~ s/0x//;

	if($tcpar_SystemMode eq 'Init')
	{
		S_w2rep("Step 1:Power on reset - No evaluation", 'blue');
	
		S_w2rep("Step 2: Evaluate default deployment loop table", 'blue'); 
		$Resp_ReadDLT_Init_BeforeSquibFiring = ACEA_ExtractRespDataToBeEvaluated($Resp_ReadDLT_Init_BeforeSquibFiring, 18);
		ACEA_EvaluateDLTForGivenLoopId($Resp_ReadDLT_Init_BeforeSquibFiring, $tcpar_ExpResp_DLT_Init_BeforeSquibFiring, $projpar_LoopID);

		S_w2rep("Step 2: Evaluate default loop status from EEPROM", 'blue');
		$DPLStatus_EEPROM_Init_BeforeSquibFiring = hex($DPLStatus_EEPROM_Init_BeforeSquibFiring) >> $projpar_LoopStatus_BitPosition;
		EVAL_evaluate_value("", $DPLStatus_EEPROM_Init_BeforeSquibFiring, '==', $tcpar_Exp_DeploymentloopStatusInEEPROM_Init_BeforeSquibFiring);
	}
	elsif($tcpar_SystemMode eq 'Idle')
	{
		S_w2rep("Step 3: Evaluate default deployment loop table", 'blue'); 
		$Resp_ReadDLT_BeforeSquibFiring = ACEA_ExtractRespDataToBeEvaluated($Resp_ReadDLT_BeforeSquibFiring, 18);
		ACEA_EvaluateDLTForGivenLoopId($Resp_ReadDLT_BeforeSquibFiring, $tcpar_ExpResp_DLT_BeforeSquibFiring, $projpar_LoopID);

		S_w2rep("Step 3: Evaluate default loop status from EEPROM", 'blue');
		$DPLStatus_EEPROM_BeforeSquibFiring = hex($DPLStatus_EEPROM_BeforeSquibFiring) >> $projpar_LoopStatus_BitPosition;
		EVAL_evaluate_value("", $DPLStatus_EEPROM_BeforeSquibFiring, '==', $tcpar_Exp_DeploymentloopStatusInEEPROM_BeforeSquibFiring);		
	}
	else
	{
		#Set warning for Invalid system mode.
		S_set_error("Invalid system mode $tcpar_SystemMode", 0); #warning!
	}

	S_w2rep("Step 4: Enter into safety sysyem diagnostic session - No evaluation, positive response is evaluated in TC_stimulation_and_measurement", 'blue');
	
	S_w2rep("Step 5: Getting security access for ACEA - No evaluation, positive response is evaluated in TC_stimulation_and_measurement", 'blue');
	
	S_w2rep("Step 6: Execute disposal Program loader - No evaluation, positive response is evaluated in TC_stimulation_and_measurement", 'blue');

	if($tcpar_ACLSupported eq 'yes'){
			
		S_w2rep("Step 7: Connecting the ACL PWM signal - No evaluation", 'blue');
	}		

	S_w2rep("Step 8: Fire a squib", 'blue');
	my $Resp_FireSquib = ACEA_ExtractRespDataToBeEvaluated($Resp_FireSquib, 18);
	EVAL_evaluate_string( "", $tcpar_ExpResp_DLT_AfterSquibFiring, $Resp_FireSquib);		

	if($tcpar_SystemMode eq 'Init')
	{
		S_w2rep("Step 9:Power on reset : No evaluation", 'blue');

		S_w2rep("Step 10: Evaluate deployment loop table", 'blue'); 
		$Resp_ReadDLT_Init_AfterSquibFiring = ACEA_ExtractRespDataToBeEvaluated($Resp_ReadDLT_Init_AfterSquibFiring, 18);
		ACEA_EvaluateDLTForGivenLoopId($Resp_ReadDLT_Init_AfterSquibFiring, $tcpar_ExpResp_DLT_Init_AfterSquibFiring, $projpar_LoopID);

		S_w2rep("Step 10: Evaluate loop status from EEPROM", 'blue');
		$DPLStatus_EEPROM_Init_AfterSquibFiring = hex($DPLStatus_EEPROM_Init_AfterSquibFiring) >> $projpar_LoopStatus_BitPosition;
		EVAL_evaluate_value("", $DPLStatus_EEPROM_Init_AfterSquibFiring, '==', $tcpar_Exp_DeploymentloopStatusInEEPROM_Init_AfterSquibFiring);		
	}
	elsif($tcpar_SystemMode eq 'Idle')
	{
		#Do nothing
	}	
	else
	{
		#Set warning for Invalid system mode.
		S_set_error("Invalid system mode $tcpar_SystemMode", 0); #warning!
	}	
	
	S_w2rep("Step 11 & 12: Evaluate  deployment loop table", 'blue'); 
	$Resp_ReadDLT_AfterSquibFiring = ACEA_ExtractRespDataToBeEvaluated($Resp_ReadDLT_AfterSquibFiring, 18);
	ACEA_EvaluateDLTForGivenLoopId($Resp_ReadDLT_AfterSquibFiring, $tcpar_ExpResp_DLT_AfterSquibFiring, $projpar_LoopID);

	S_w2rep("Step 11 & 12: Evaluate loop status from EEPROM", 'blue');
	$DPLStatus_EEPROM_AfterSquibFiring = hex($DPLStatus_EEPROM_AfterSquibFiring) >> $projpar_LoopStatus_BitPosition;
	EVAL_evaluate_value("", $DPLStatus_EEPROM_AfterSquibFiring, '==', $tcpar_Exp_DeploymentloopStatusInEEPROM_AfterSquibFiring);		

return 1;
}


#### TC FINALIZATION #####
sub TC_finalization {

	ACEA_ResetECUMode($tcpar_SystemMode, $IdleMode_var, $Value);
	#Stop the TP seding cyclically
	GDCOM_stop_CyclicTesterPresent($TP_handle);
	#Initializating EEPROM to make fault free setup.
	PD_InitEEPROM ('$LIFT_PRJCFG_path/../reports/Temp_EEPROM_Dump.hex');
	S_wait_ms(2000);
	GEN_Power_on_Reset();

return 1;
}


1;

__END__

