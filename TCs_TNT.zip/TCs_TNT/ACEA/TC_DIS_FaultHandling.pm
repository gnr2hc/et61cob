#### TEST CASE MODULE
package TC_DIS_FaultHandling;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
###-------------------------------
our $VERSION = q$Revision: 1.23 $;
our $HEADER = q$Header: ACEA/TC_DIS_FaultHandling.pm 1.23 2014/11/05 11:43:42ICT DVR5KOR develop  $;
##################################

#### INCLUDE ENGINE MODULES ####
use LIFT_general;   
use LIFT_PD; 
use LIFT_evaluation;
use GENERIC_DCOM;
use INCLUDES_Project;
use LIFT_can_access;


##################################

our $PURPOSE = "To test fault handling during ACEA deployment procedure";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DIS_FaultHandling  $Revision: 1.23 $

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:
    
	default parameters: 
	purpose
	TestCondition
	ACLSupported
	Squib_Loopids
	PowerOnTimer_var
	FirstDeploymentTimeStamp_var
	
	testcase parameters
	Fault1_ExpName
	Fault2_ExpName
	Fault1_ExpStatus_DisposalSessionEntry
	Fault2_ExpStatus_DisposalSessionEntry
	Fault1_ExpStatus_FirstFiring
	Fault2_ExpStatus_FirstFiring
	Fault1_ExpStatus_AllSquibsFired
	Fault2_ExpStatus_AllSquibsFired

    [initialisation]
	1. Standard Preparation
	2. No ACL connected
	3. Tester present diag service is transmitted cyclically to keep diagnostics active

    [stimulation & measurement]

	1. Read First Deployment Time Stamp before ACEA deplyment
	2. Read fault memory before entering to disposal session
		
		- Execute steps 3 to 12 for all supported squibs
		- skip DPL activation i.e. step 3 to 6 if ECU reset is not performed
	3. Initiate Safety System Diagnostic Session
	4. Read fault memory after disposal session is entered
	5. Obtain security access to download and activateDPL 
	6. Download and activate DPL
	7. Connect ACL PWM signal, if ACL check is done by the SW for ACEA deployment 
	8. Perform ACEA deployement
	   Read power on timer immediately after first squib deployment
	9. Perform ECU reset if required
	10. Read fault memory after each squib deployment
	11 & 12. Read First Deployment Time Stamp after each squib deplyment
	13. Perform ECU reset if required after all squibs deployed	
	14 & 15. Read fault memory after all squibs are deplyed
	
	[evaluation]
    
	1. Evaluate First Deployment Time Stamp before ACEA deplyment
	2. Evaluate fault memory data read before entering to disposal session
		
		- Execute steps 3 to 12 for all supported squibs
		- skip DPL activation i.e. step 3 to 6 if ECU reset is not performed
	3. Evaluate positive response for diag service "Initiate Safety System Diagnostic Session"
	4. Read fault memory after disposal session is entered
	5. Evaluate positive response for diag service "Obtain security access to download and activateDPL" 
	6. Evaluate positive response for diag service "Download and activate DPL""
	7.  
	8. Evaluate positive response for diag service "Perform ACEA deployement"
	9. 
	10 & 11. Evaluate fault memory data read after each squib deployment
	12. First Deployment Time Stamp = power on timer read after first squib deployment
	13. 	
	14 & 15. Evaluate fault memory data read after all squibs are deplyed


    [finalisation]
    

=head1 PARAMETER

=head2 PARAMETER NAMES

	default parameters: 
	SCALAR 'purpose'	-->    purpose of the test
	SCALAR 'TestCondition'	-->    condition for the test
	SCALAR 'ACLSupported'	-->    Is ACl supported by SW under test
	SCALAR 'Squib_LoopIds'	-->    list of squibs and loop ids supported by SW
	SCALAR 'PowerOnTimer_var'	-->    variable to read power on timer
	SCALAR 'FirstDeploymentTimeStamp_var'	-->    variable to read First Deployment Time Stamp
	
	testcase parameters: 
	SCALAR 'Fault1_ExpName'	-->    name of the fault 1
	SCALAR 'Fault2_ExpName'	-->    name of the fault 1
	SCALAR 'Fault1_ExpStatus_DisposalSessionEntry'	-->    expected fault status of fault 1 after disposal session entry
	SCALAR 'Fault2_ExpStatus_DisposalSessionEntry'	-->    expected fault status of fault 2 after disposal session entry
	SCALAR 'Fault1_ExpStatus_FirstFiring'	-->    expected fault status of fault 1 after first squib firing
	SCALAR 'Fault2_ExpStatus_FirstFiring'	-->    expected fault status of fault 2 after first squib firing
	SCALAR 'Fault1_ExpStatus_AllSquibsFired'	-->    expected fault status of fault 1 before all squib are fired
	SCALAR 'Fault2_ExpStatus_AllSquibsFired'	-->    expected fault status of fault 2 before all squib are fired

=head2 PARAMETER EXAMPLES

    [TC_DIS_FaultHandling.DoubleFaultStrategy_NoReset]
	purpose  = 'To test fault handling during ACEA deployment procedure'
	TestCondition = 'NoReset'
	ACLSupported = 'yes' #'Yes' or 'No'
	Squib_LoopIds = 'AB1FD => 0x01\nAB2FD => 0x04\nAB1FP => 0x0A\nAB2FP => 0x0B\nBT1FD => 0x12\nBT1FP => 0x18\nSA1FD => 0x43\nSA1FP => 0x44\nWI1FD => 0x3B\nWI1FP => 0x3C\nBT1RD => 0x22\nBT1RP => 0x24\nSA1RD => 0x49\nSA1RP => 0x4A\nBATD1 => 0x69\nBATD2 => 0x6A'
	Fault1_ExpName = 'FltACEANotCompleted'
	Fault2_ExpName = 'FltACEAComplete'
	Fault1_ExpStatus_DisposalSessionEntry = '0x00'
	Fault2_ExpStatus_DisposalSessionEntry = '0x00'
	Fault1_ExpStatus_FirstFiring = '0x1F'
	Fault2_ExpStatus_FirstFiring = '0x00'
	Fault1_ExpStatus_AllSquibsFired = '0x26'
	Fault2_ExpStatus_AllSquibsFired = '0x1F'
	
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
# default parameters
my ($defaultpar_purpose,
	$defaultpar_TestCondition,
	$defaultpar_ACLSupported,
	$defaultpar_Squib_LoopIds,);

# testcase parameters
my	($tcpar_Fault1_ExpName,
	$tcpar_Fault2_ExpName,
	$tcpar_Fault1_ExpStatus_FirstFiring,
	$tcpar_Fault1_ExpStatus_FirstFiringWithReset,
	$tcpar_Fault2_ExpStatus_FirstFiring,
	$tcpar_Fault2_ExpStatus_FirstFiringWithReset,
	$tcpar_Fault1_ExpStatus_AllSquibsFired,
	$tcpar_Fault1_ExpStatus_AllSquibsFiredWithReset,
	$tcpar_Fault2_ExpStatus_AllSquibsFired,
	$tcpar_Fault2_ExpStatus_AllSquibsFiredWithReset,
	$tcpar_Fault1_ExpStatus_DisposalSessionEntry,
	$tcpar_Fault2_ExpStatus_DisposalSessionEntry);

my ($FirstDeploymentTimeStamp_1,
	$FirstDeploymentTimeStamp_2,
	$PowerOnTimer,
	$flt_mem_struct_1,
	@flt_mem_struct_2,
	@flt_mem_struct_3,
	$flt_mem_struct_4,
	$NumberOfIterations,
	@SquibNames,
	@LoopIds);
	
	my $ExecuteSPL_Without_Conversion = '00';
	my $ExecuteSPL_With_Conversion = '01';
	my $TP_handle;



sub TC_set_parameters {

	$defaultpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	$defaultpar_TestCondition =  GEN_Read_mandatory_testcase_parameter( 'TestCondition' );
	$defaultpar_ACLSupported =  GEN_Read_mandatory_testcase_parameter( 'ACLSupported' );
	$defaultpar_Squib_LoopIds =  GEN_Read_mandatory_testcase_parameter( 'Squib_LoopIds' );
	
	$tcpar_Fault1_ExpName =  GEN_Read_mandatory_testcase_parameter( 'Fault1_ExpName' );
	$tcpar_Fault2_ExpName =  GEN_Read_mandatory_testcase_parameter( 'Fault2_ExpName' );
	$tcpar_Fault1_ExpStatus_FirstFiring =  GEN_Read_mandatory_testcase_parameter( 'Fault1_ExpStatus_FirstFiring' );
	$tcpar_Fault2_ExpStatus_FirstFiring =  GEN_Read_mandatory_testcase_parameter( 'Fault2_ExpStatus_FirstFiring' );
	$tcpar_Fault1_ExpStatus_AllSquibsFired =  GEN_Read_mandatory_testcase_parameter( 'Fault1_ExpStatus_AllSquibsFired' );
	$tcpar_Fault2_ExpStatus_AllSquibsFired =  GEN_Read_mandatory_testcase_parameter( 'Fault2_ExpStatus_AllSquibsFired' );
	$tcpar_Fault1_ExpStatus_DisposalSessionEntry = GEN_Read_mandatory_testcase_parameter( 'Fault1_ExpStatus_DisposalSessionEntry' );
	$tcpar_Fault2_ExpStatus_DisposalSessionEntry = GEN_Read_mandatory_testcase_parameter( 'Fault2_ExpStatus_DisposalSessionEntry' );
	
	my $ProjConst_notSupported_Squibs = $LIFT_PROJECT::Defaults->{'notSupported_Squibs'};
	
	my @Squib_LoopIds = split(/\\n/, $defaultpar_Squib_LoopIds);
	my @Temp_Squib_LoopIds;
	my $skip = 0;
	my $notSupported_Squib;
	foreach my $Squib_LoopIds (@Squib_LoopIds){
		$skip = 0;
		@Temp_Squib_LoopIds = split(/=>/, $Squib_LoopIds);
		foreach (@Temp_Squib_LoopIds){
			$_ =~ s/\s*//;
		}		
		foreach $notSupported_Squib (@$ProjConst_notSupported_Squibs){
			if($notSupported_Squib eq $Temp_Squib_LoopIds[0]){
				$skip = 1;
				last;
			}
		}
		if($skip == 0){
			push (@SquibNames, $Temp_Squib_LoopIds[0]);
			push (@LoopIds, $Temp_Squib_LoopIds[1]);
		}
	}

return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	CA_trace_start();

	S_w2rep("Set the preconditions for this test case", 'blue');
	my $msg_aref = $LIFT_PROJECT::Defaults->{"CUSTOMER_DIAGNOSIS"}{"TesterPresent_SupressPosResp"}{"Requests"}{"REQ_TesterPresent_SupressPosResp"}{'Requests'};
	my $msg_ID = $LIFT_PROJECT::Defaults->{"CUSTOMER_DIAGNOSIS"}{'RequestID_disposal'};
	my $cycle  = 4500;
	
	#Taking the EEPROM dump from fault free setup.
	if(not defined ($LIFT_PROJECT::Defaults->{'TEMP'}{'Count'}))
	{
	S_w2rep("Step 1: Re-initialize EEPROM", 'blue');		
	GEN_printComment("Taking the EEPROM dump from fault free setup for the 1st time");
	PD_DumpEEPROM('$LIFT_PRJCFG_path/../reports/Temp_EEPROM_Dump.hex');
	S_wait_ms(2000);
	$LIFT_PROJECT::Defaults->{'TEMP'}{'Count'} = 0x01; #Count to take EEPROM dump for only 1st time.
	} 

	S_w2rep("Step 2: Standard Preparation", 'blue');	
	GEN_StandardPrepNoFault();
	GEN_ProjectSpecificSettings();	

	S_w2rep("Step 3: NoACLConnected", 'blue');
	ACEA_SetACLConnection('Disconnect');

	#Setting the request ID and response ID for ACEA.
	GDCOM_set_addressing_mode("disposal");    #Setting disposal request ID and response ID
	
	S_w2rep("Step 4: SendTesterPresentCyclically", 'blue');
	$TP_handle = GDCOM_start_CyclicTesterPresent($msg_aref,$msg_ID,$cycle);
	
return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	#Read First Deployment Time Stamp before ACEA deplyment
	S_w2rep ("Step 1", 'blue');
	$FirstDeploymentTimeStamp_1 = ACEA_ReadFirstDeploymentTimeStamp();

	#Read fault memory before entering to disposal session
	S_w2rep ("Step 2", 'blue');	
	$flt_mem_struct_1 = FM_PD_readFaultMemory('extended');
	
	#loop index for loop id for a specific squib to be deployed
	my $SquibIndex = 0;	
	#Loop to deploy all supported squibs 
	my $Squib = '';
	foreach $Squib (@SquibNames) {
		
		S_w2rep ("ACEA deplyment for $Squib", 'blue');
		
		#To skip DPL activation if ECU reset is not performed
		if(($defaultpar_TestCondition eq 'ResetAfterEachSquibFiring') || ($SquibIndex == 0)){

			#Initiate Safety System Diagnostic Session
			S_w2rep ("Step 3", 'blue');			
			GDCOM_StartSession('DisposalSession');

			#Read fault memory after disposal session is entered
			S_w2rep ("Step 4", 'blue');			
			$flt_mem_struct_2[$SquibIndex] = FM_PD_readFaultMemory('extended');

			#Obtain security access to download and activateDPL 
			S_w2rep ("Step 5", 'blue');			
			ACEA_Get_SecurityAccess();
			
			#Download and activate DPL
			S_w2rep ("Step 6", 'blue');			
			ACEA_ExecuteDisposalProgramLoader($ExecuteSPL_Without_Conversion);
			ACEA_ExecuteDisposalProgramLoader($ExecuteSPL_With_Conversion);	
		
		}

		#Connect ACL only once
		if($SquibIndex == 0){
		#Check is ACL check is done by the SW for ACEA deployment 
			if($defaultpar_ACLSupported eq 'yes'){
				#Connect ACL PWM signal
				S_w2rep ("Step 7", 'blue');
				ACEA_SetACLConnection('Connect');
				S_wait_ms(3000);
			}
		}

		S_w2rep ("Step 8", 'blue');		
		#Perform ACEA deployement
		my $LoopId = $LoopIds[$SquibIndex];
		$LoopId =~ s/0x//;
		ACEA_FireSquib($LoopId);	
		S_wait_ms(100);		
		#read power on timer immediately after first squib deployment
		if($SquibIndex == 0){
			$PowerOnTimer = ACEA_ReadPowerOnTimer();
		}
		
		#Check if ECU reset is required or not after each squib deplyment		
		if($defaultpar_TestCondition eq 'ResetAfterEachSquibFiring'){
			#Perform ECU reset
			S_w2rep ("Step 9", 'blue');			
			GEN_Power_on_Reset();
		}

		#Read fault memory after each squib deployment
		S_w2rep ("Step 10 & 11", 'blue');	
		$flt_mem_struct_3[$SquibIndex] = FM_PD_readFaultMemory('extended');

		#Read First Deployment Time Stamp after each squib deplyment
		S_w2rep ("Step 12", 'blue');		
		$FirstDeploymentTimeStamp_2 = ACEA_ReadFirstDeploymentTimeStamp();

		#value of loop index for loop id for a next squib to be deployed	
		$SquibIndex++;
	
	}

	#Check if ECU reset is required or not after all squibs deplyed	
	if($defaultpar_TestCondition eq 'ResetAfterAllSquibFiring'){
		#Perform ECU reset
		S_w2rep ("Step 13", 'blue');			
		GEN_Power_on_Reset();
	}

	#Read fault memory after all squibs are deplyed
	S_w2rep ("Step 14 & 15", 'blue');
	$flt_mem_struct_4 = FM_PD_readFaultMemory('extended');


return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	#Evaluate First Deployment Time Stamp before ACEA deplyment
	S_w2rep ("Step 1", 'blue');
	EVAL_evaluate_value ("First Deployment Time Stamp before ACEA deplyment", $FirstDeploymentTimeStamp_1, '==', '0xFFFFFFFF');

	#Evaluate fault memory data read before entering to disposal session
	S_w2rep ("Step 2 : Fault memory is empty", 'blue');	
	PD_evaluate_faults($flt_mem_struct_1, [] );

	my $Squib;
	#loop index for loop id for a specific squib to be deployed
	my $SquibIndex = 0;
	
	#Loop to deploy all supported squibs 
	foreach $Squib (@SquibNames) {
		
		if($Squib eq ''){
			last;
		}
		
		S_w2rep ("ACEA deplyment for $Squib", 'blue');

		#To skip DPL activation if ECU reset is not performed
		if(($defaultpar_TestCondition eq 'ResetAfterEachSquibFiring') || ($SquibIndex == 0)){

			#Diag response evaluation is already done in TC_stimulation_and_measurement()
			#Initiate Safety System Diagnostic Session
			S_w2rep ("Step 3 : No evaluation - Diag response evaluation is already done in TC_stimulation_and_measurement - Diag response evaluation is already done in TC_stimulation_and_measurement", 'blue');			
		
			#Evaluate fault memory data read after disposal session is entered
			S_w2rep ("Step 4 :", 'blue');
			if($SquibIndex == 0){
				S_w2rep ("Step 4 : Fault memory is empty", 'blue');	
				PD_evaluate_faults($flt_mem_struct_2[$SquibIndex], [] );
			}	
			else{
				if($tcpar_Fault1_ExpStatus_DisposalSessionEntry ne '0x00'){
					EVAL_check_fault_status($flt_mem_struct_2[$SquibIndex], $tcpar_Fault1_ExpName, $tcpar_Fault1_ExpStatus_DisposalSessionEntry);
				}
				elsif($tcpar_Fault1_ExpStatus_DisposalSessionEntry eq '0x00'){
					EVAL_evaluate_value("Fault $tcpar_Fault1_ExpName is not present in fault memory", PD_count_fault($flt_mem_struct_2[$SquibIndex], $tcpar_Fault1_ExpName), '==', 0);
				}
				if($tcpar_Fault2_ExpStatus_DisposalSessionEntry ne '0x00'){
					EVAL_check_fault_status($flt_mem_struct_2[$SquibIndex], $tcpar_Fault2_ExpName, $tcpar_Fault2_ExpStatus_DisposalSessionEntry);
				}
				elsif($tcpar_Fault2_ExpStatus_DisposalSessionEntry eq '0x00'){
					EVAL_evaluate_value("Fault $tcpar_Fault2_ExpName is not present in fault memory", PD_count_fault($flt_mem_struct_2[$SquibIndex], $tcpar_Fault2_ExpName), '==', 0);
				}
			}
			
			#Diag response evaluation is already done in TC_stimulation_and_measurement()
			#Obtain security access to download and activateDPL 
			S_w2rep ("Step 5 : No evaluation - Diag response evaluation is already done in TC_stimulation_and_measurement", 'blue');			
			
			#Diag response evaluation is already done in TC_stimulation_and_measurement()
			#Download and activate DPL
			S_w2rep ("Step 6 : No evaluation - Diag response evaluation is already done in TC_stimulation_and_measurement", 'blue');			
		}

		#Check is ACL check is done by the SW for ACEA deployment 
		if($defaultpar_ACLSupported eq 'yes'){
			#No evaluation - Diag response evaluation is already done in TC_stimulation_and_measurement
			S_w2rep ("Step 7: No evaluation - Diag response evaluation is already done in TC_stimulation_and_measurement", 'blue');	
		}

		S_w2rep ("Step 8 : No evaluation - Diag response evaluation is already done in TC_stimulation_and_measurement", 'blue');	
		#Diag response evaluation is already done in TC_stimulation_and_measurement()	
		#Perform ACEA deployement
		
		#Read power on timer immediately after squib deployment
		#No evaluation - Diag response evaluation is already done in TC_stimulation_and_measurement

		#Check if ECU reset is required or not after each squib deplyment		
		if($defaultpar_TestCondition eq 'ResetAfterEachSquibFiring'){
			#No evaluation - Diag response evaluation is already done in TC_stimulation_and_measurement
			S_w2rep ("Step 9 : No evaluation - Diag response evaluation is already done in TC_stimulation_and_measurement", 'blue');		
		}

		#Evaluate fault memory data read after each squib deployment
		S_w2rep ("Step 10 & 11", 'blue');
		
		if($SquibIndex != (scalar(@SquibNames)-1)){
			if($tcpar_Fault1_ExpStatus_FirstFiring  ne '0x00'){
				EVAL_check_fault_status($flt_mem_struct_3[$SquibIndex], $tcpar_Fault1_ExpName, $tcpar_Fault1_ExpStatus_FirstFiring);
			}
			elsif($tcpar_Fault1_ExpStatus_FirstFiring  eq '0x00'){
				EVAL_evaluate_value("Fault $tcpar_Fault1_ExpName is not present in fault memory", PD_count_fault($flt_mem_struct_3[$SquibIndex], $tcpar_Fault1_ExpName), '==', 0);
			}
			
			if($tcpar_Fault2_ExpStatus_FirstFiring  ne '0x00'){			
				EVAL_check_fault_status($flt_mem_struct_3[$SquibIndex], $tcpar_Fault2_ExpName, $tcpar_Fault2_ExpStatus_FirstFiring);
			}
			elsif($tcpar_Fault2_ExpStatus_FirstFiring  eq '0x00'){	
				EVAL_evaluate_value("Fault $tcpar_Fault2_ExpName is not present in fault memory", PD_count_fault($flt_mem_struct_3[$SquibIndex], $tcpar_Fault2_ExpName), '==', 0);
			}
		}
		
		#Read First Deployment Time Stamp after each squib deplyment
		S_w2rep ("Step 12", 'blue');		
		EVAL_evaluate_value ("First Deployment Time Stamp after each squib deplyment", $FirstDeploymentTimeStamp_2, '==', $PowerOnTimer, 5, 'absolute');

		#value of loop index for loop id for a next squib to be deployed		
		$SquibIndex++; 
	}

	if($defaultpar_TestCondition eq 'ResetAfterEachSquibFiring'){
		#No evaluation - Diag response evaluation is already done in TC_stimulation_and_measurement
		S_w2rep ("Step 13 : No evaluation - Diag response evaluation is already done in TC_stimulation_and_measurement", 'blue');		
	}

	#Evaluate fault memory data read after all squibs are deplyed
	S_w2rep ("Step 14 & 15", 'blue');
	if($tcpar_Fault1_ExpStatus_AllSquibsFired  ne '0x00'){				
		EVAL_check_fault_status($flt_mem_struct_4, $tcpar_Fault1_ExpName, $tcpar_Fault1_ExpStatus_AllSquibsFired);
	}
	elsif($tcpar_Fault1_ExpStatus_AllSquibsFired  eq '0x00'){	
		EVAL_evaluate_value("Fault $tcpar_Fault1_ExpName is not present in fault memory", PD_count_fault($flt_mem_struct_4, $tcpar_Fault1_ExpName), '==', 0);
	}
	
	if($tcpar_Fault2_ExpStatus_AllSquibsFired  ne '0x00'){			
		EVAL_check_fault_status($flt_mem_struct_4, $tcpar_Fault2_ExpName, $tcpar_Fault2_ExpStatus_AllSquibsFired);
	}
	elsif($tcpar_Fault2_ExpStatus_AllSquibsFired  eq '0x00'){		
		EVAL_evaluate_value("Fault $tcpar_Fault2_ExpName is not present in fault memory", PD_count_fault($flt_mem_struct_4, $tcpar_Fault2_ExpName), '==', 0);
	}	


return 1;
}


#### TC FINALIZATION #####
sub TC_finalization {

	#Stop the TP seding cyclically
	GDCOM_stop_CyclicTesterPresent($TP_handle);
	
	#Initializating EEPROM to make fault free setup.
	PD_InitEEPROM ('$LIFT_PRJCFG_path/../reports/Temp_EEPROM_Dump.hex');
	S_wait_ms(2000);
	GEN_Power_on_Reset();

return 1;
}


1;

__END__
