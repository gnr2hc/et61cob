#### TEST CASE MODULE
package TC_DIS_GeneralTest;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
###-------------------------------
our $VERSION = q$Revision: 1.25 $;
our $HEADER = q$Header: ACEA/TC_DIS_GeneralTest.pm 1.25 2014/11/05 11:39:58ICT DVR5KOR develop  $;
##################################

#### INCLUDE ENGINE MODULES ####
use LIFT_general;   
use LIFT_PD; 
use LIFT_evaluation;
use GENERIC_DCOM;
use FuncLib_TNT_GEN;
use FuncLib_Project_GEN;
use FuncLib_ACEA_TNT;
use LIFT_can_access;

##################################

our $PURPOSE = "To test ACEA deployement flow under various different conditions";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_template  $Revision: 1.25 $

=head1 PURPOSE



=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:
	purpose
	ACLSupported
	TestCondition
	Exp1_DeploymentloopStatusInEEPROM
	Exp2_DeploymentloopStatusInEEPROM
	Exp3_DeploymentloopStatusInEEPROM
	ExpResp1_DeploymentloopStatus
	ExpResp2_DeploymentloopStatus
	ExpResp3_DeploymentloopStatus
	ExpResp4_DeploymentloopStatus
	Exp1_AlgoStatus
	Exp2_AlgoStatus
	Exp1_WLStatus
	Exp2_WLStatus
	Exp1_DecryptionKeyInRAM
	Exp2_DecryptionKeyInRAM
	Write_DismantlerInfo_First
	Write_DismantlerInfo_Second
	Write_DismantlerInfo_Third
	ExpResp_Write_DismantlerInfo_Second
	ExpResp_Write_DismantlerInfo_Third
	ExpResp_Read_DismantlerInfo_Second
	ExpResp_Read_DismantlerInfo_Third

    [initialisation]
	Step 1: Re-initialize EEPROM
	Step 2: Standard Preparation
	Step 3: NoACLConnected
	Step 4: SendTesterPresentCyclically
	Step 5: SetTestCondition
	
    [stimulation & measurement]	
	Step 1: Read HW deploypemt method
	Step 2: Read Number of PCU's in the Vehicle
	Step 3: Read address information of PCU's
	Step 4: Read VIN
	Step 5: Read default dismantler information
	Step 6: write dismantler information for the first time
	tep 7: write dismantler information for the second time
	Step 8: Read dismantler information after rewriting dismantler information
	Step 9: Read default deployment loop table
	Step 9: Read default loop status from EEPROM
	Step 10: Enter into safety system diagnostic session
	Step 11: Read Algo status after Entering into safety sysyem diagnostic session
	Step 11: ReadWL status after Entering into safety sysyem diagnostic session
	Step 12: Read Default Disposal key stored at RAM
	Step 13: Obtain  security access
	Step 14: Read Disposal key stored at RAM after Activating DPL
	Step 15: Read disable line status
	Step 16: Execute disposal Program loader 
	Step 17: Execute disposal Program loader once again
	Step 18: Read disable line status
	Step 19: Read Algo status after Activating DPL
	Step 19: Read WL status after Activating DPL
	Step 20: Read deployment loop table after Activating DPL
	Step 20: Read Deployment loop status from EEPROM after Activating DPL
	Step 21: Read Routine Result before firing the squib
	Execute Step 20 and 21 if ACLSupported == 'Yes',
	Step 22: Fire a squib without ACL connected
	Step 23: Connecting the ACL PWM signal
	Step 24: Fire a squib
	Step 25: Writ dismantler information after each squib fired
	Step 26: Read dismantler information after each squib fired
	Step 27: Read deployment loop table after firing the squib
	Step 27: Read Deployment loop status from EEPROM after firing the squib
	Step 28: Read Request Routine Result after firiing the squib
	Step 29: Reset ECU
	Step 30: Read deployment loop table after Resetting ECU
	Step 30: Read Deployment loop status from EEPROM after Resetting ECU

    [evaluation]	
	Step 1: Evaluate HW deploypemt method
	Step 2: Evaluate Number of PCU's in the Vehicle
	Step 3: Evaluate address information of PCU's
	Step 4: Evaluate VIN
	Step 5: Evaluate dismantler information
	Step 6: Evaluate response for write dismantler information for the first time
	Step 7: Evaluate response for write dismantler information for the second time
	Step 8: Evaluate response for Read dismantler information after rewriting
	Step 9: Read default deployment loop table
	Step 9: Read default loop status from EEPROM
	Step 10: Evaluate response for Enter into safety sysyem diagnostic session 
	Step 11: Evaluate Algo status read after Entering into safety sysyem diagnostic session
	Step 11: Evaluate WL status read after Entering into safety sysyem diagnostic session
	Step 12: Evaluate Default Disposal key stored at RAM
	Step 13: Evaluate response for Obtain security access
	Step 14: Evaluate Disposal key stored at RAM read after Activating DPL
	Step 15: Expected disable line status = DISABLED
	Step 16: Evaluate response for Execute disposal Program loader
	Step 17: Evaluate response for Execute disposal Program loader once again
	Step 18: Expected disable line status = ENABLED
	Step 19: Evaluate Algo status read after Activating DPL
	Step 19: Evaluate WL status read after Activating DPL
	Step 20: Evaluate deployment loop table after Activating DPL
	Step 20: Evaluate Deployment loop status from EEPROM read before Firing the squib
	Step 21: Evaluate Routine Result read before firing the squib
	Step 22: Evaluate response for Fire a squib without ACL connected
	Step 23: No evaluation
	Step 24: Evaluate response for Fire a squib
	Step 25: Evaluate response for writing dismantler information after first squib fired
	Step 26: Evaluate response for Read dismantler information after first squib fired
	Step 27: Reading deployment loop table after firing the squib
	Step 27: Evaluate Deployment loop status from EEPROM read after firing the squib
	Step 28: Evaluate Request Routine Result read after firiing the squib
	Step 29: Reseting the ECU - No evaluation
	Step 30: Evaluate deployment loop table read after Restarting ECU.
	Step 30: Evaluate Deployment loop status from EEPROM read after Restarting ECU.

    [finalisation]
	Bring back the system to normal state

=head1 PARAMETER

=head2 PARAMETER NAMES

	Scalar purpose  : purpose of the test
	Scalar ACLSupported : Is ACL supported/
	Scalar TestCondition ; Condition fo the test
	Scalar Exp1_DeploymentloopStatusInEEPROM : expected Deployment loop Status In EEPROM before DPL activation
	Scalar Exp2_DeploymentloopStatusInEEPROM : expected Deployment loop Status In EEPROM after DPL activation
	Scalar Exp3_DeploymentloopStatusInEEPROM : expected Deployment loop Status In EEPROM after squib firing
	Scalar ExpResp1_DeploymentloopStatus : expected Deployment loop Status in diag response  before DPL activation
	Scalar ExpResp2_DeploymentloopStatus : expected Deployment loop Status in diag response  after DPL activation
	Scalar ExpResp3_DeploymentloopStatus : expected Deployment loop Status in diag response  after squib firing
	Scalar ExpResp4_DeploymentloopStatus : expected Deployment loop Status in diag response  after reset
	Scalar Exp1_AlgoStatus : Expected Algo Status before DPL activation
	Scalar Exp2_AlgoStatus : Expected Algo Status after DPL activation
	Scalar Exp1_WLStatus : Expected WL Status before DPL activation
	Scalar Exp2_WLStatus : Expected WL Status after DPL activation
	Scalar Exp1_DecryptionKeyInRAM : Expected Decryption Key In RAM before obtaining security access
	Scalar Exp2_DecryptionKeyInRAM : Expected Decryption Key In RAM after obtaining security access
	Scalar Write_DismantlerInfo_First : Dismantler Info to write for the first time
	Scalar Write_DismantlerInfo_Second : Dismantler Info to write for the second time
	Scalar Write_DismantlerInfo_Third : Dismantler Info to write for the second time
	Scalar ExpResp_Write_DismantlerInfo_Second : expected response for write dismantler info for the second time
	Scalar ExpResp_Write_DismantlerInfo_Third : expected response for write dismantler info for the third time
	Scalar ExpResp_Read_DismantlerInfo_Second : expected response for read dismantler info for the second time
	Scalar ExpResp_Read_DismantlerInfo_Third : expected response for read dismantler info for the third time

=head2 PARAMETER EXAMPLES

    [TC_template.NoFlt_DismantlerInfoRewriting_Strategy1]
	purpose  = 'To test ACEA deployement flow under various different conditions'
	ACLSupported = 'Yes' #'Yes' or 'No'
	TestCondition = '<Test Heading 1>'
	Exp1_DeploymentloopStatusInEEPROM = '0x0000000000000000'
	Exp2_DeploymentloopStatusInEEPROM = '0x0000000000000000'
	Exp3_DeploymentloopStatusInEEPROM = '0x0000000000000001'
	ExpResp1_DeploymentloopStatus = '00'
	ExpResp2_DeploymentloopStatus = '00'
	ExpResp3_DeploymentloopStatus = '20'
	ExpResp4_DeploymentloopStatus = '20'
	Exp1_AlgoStatus = '0x60'
	Exp2_AlgoStatus = '0x60'
	Exp1_WLStatus = '0x01'
	Exp2_WLStatus = '0x01'
	Exp1_DecryptionKeyInRAM = '0x0000'
	Exp2_DecryptionKeyInRAM = '0x39AF'
	Write_DismantlerInfo_First = '00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F'
	Write_DismantlerInfo_Second = '0F 0F 0F 0F 0F 0F 0F 0F 0F 0F 0F 0F 0F 0F 0F 0F'
	Write_DismantlerInfo_Third = 'FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF'
	ExpResp_Write_DismantlerInfo_Second = 'PR_WriteDatabyID_WriteDismantlerInfo'
	ExpResp_Write_DismantlerInfo_Third = 'NR_WriteDatabyID_WriteDismantlerInfo_conditionsNotCorrect'
	ExpResp_Read_DismantlerInfo_Second = '0F 0F 0F 0F 0F 0F 0F 0F 0F 0F 0F 0F 0F 0F 0F 0F'
	ExpResp_Read_DismantlerInfo_Third = '0F 0F 0F 0F 0F 0F 0F 0F 0F 0F 0F 0F 0F 0F 0F 0F'

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#-> Input parameters for test defination.
my ($tcpar_purpose,
	$tcpar_ACLSupported,
	$tcpar_TestCondition,
	$tcpar_Exp1_DeploymentloopStatusInEEPROM,
	$tcpar_Exp2_DeploymentloopStatusInEEPROM,
	$tcpar_Exp3_DeploymentloopStatusInEEPROM,
	$tcpar_ExpResp1_DeploymentloopStatus,
	$tcpar_ExpResp2_DeploymentloopStatus,
	$tcpar_ExpResp3_DeploymentloopStatus,
	$tcpar_ExpResp4_DeploymentloopStatus,
	$tcpar_Exp1_AlgoStatus,
	$tcpar_Exp2_AlgoStatus,
	$tcpar_Exp1_WLStatus,
	$tcpar_Exp2_WLStatus,
	$tcpar_Exp1_DecryptionKeyInRAM,
	$tcpar_Exp2_DecryptionKeyInRAM,
	$tcpar_Write_DismantlerInfo_First,
	$tcpar_Write_DismantlerInfo_Second,
	$tcpar_Write_DismantlerInfo_Third,
	$tcpar_ExpResp_Write_DismantlerInfo_Second,
	$tcpar_ExpResp_Write_DismantlerInfo_Third,
	$tcpar_ExpResp_Read_DismantlerInfo_Second,
	$tcpar_ExpResp_Read_DismantlerInfo_Third);
		
my ($projpar_SquibName,
	$projpar_RefSquibName,
	$projpar_LoopID,
	$projpar_LoopStatus_BitPosition);

#-> Parameters for test verification.
my ($Resp_HWDeploymentMethod,
	$Resp_NumberOfPCUs,
	$Resp_PCUAddressInfo,
	$Resp_ReadVIN,
	$Resp_ReadDismantlerInfo_Default,
	$Resp_WriteDismantlerInfo_Rewrite,
	$Resp_ReadDismantlerInfo_AfterRewrite,
	$Resp_ReadDLT_BeforeSPLActivation,
	$DPLStatus_EEPROM_BeforeSPLActivation,
	$Algo_Status_BeforeSPLActivation,
	$WL_Status_BeforeSPLActivation,
	$DisposalKey_BeforeSPLActivation,
	$Algo_Status_AfterSPLActivation,
	$WL_Status_AfterSPLActivation,
	$DisposalKey_AfterSPLActivation,
	$Resp_ReadDLT_AfterSPLActivation,
	$DPLStatus_EEPROM_AfterSPLActivation,
	$Resp_RequestRoutineResult_AfterSPLActivation,
	$Resp_FireSquib_WithOutACL,
	$Resp_FireSquib_WithACL,
	$Resp_WriteDismantlerInfo_AfterFiring,
	$Resp_ReadDismantlerInfo_AfterFiring,
	$SquibAct_Status_EEPROMAfterFiring,
	$Resp_ReadDLT_AfterFiring,
	$AfterFire_DPLStatus_EEPROM,
	$Resp_RequestRoutineResult_AfterFiring,
	$SquibAct_Status_EEPROM_AfterReset,
	$Resp_ReadDLT_AfterReset,
	$DPLStatus_EEPROM_AfterReset,
	$DisLnStatus_beforeDPLactivation,
	$DisLnStatus_afterDPLactivation,
	$DisLnStatus_afterACLConnection);
	my $TP_handle;
my ($ExecuteSPL_With_Conversion);	
	
	$ExecuteSPL_With_Conversion = '01';
	
sub TC_set_parameters {

	#parameters reading from TC_.par file
	$tcpar_ACLSupported = GEN_Read_mandatory_testcase_parameter( 'ACLSupported' );
	$tcpar_TestCondition = GEN_Read_mandatory_testcase_parameter( 'TestCondition' );
	$tcpar_Exp1_DeploymentloopStatusInEEPROM = GEN_Read_mandatory_testcase_parameter( 'Exp1_DeploymentloopStatusInEEPROM' );    
	$tcpar_Exp2_DeploymentloopStatusInEEPROM = GEN_Read_mandatory_testcase_parameter( 'Exp2_DeploymentloopStatusInEEPROM' );
	$tcpar_Exp3_DeploymentloopStatusInEEPROM = GEN_Read_mandatory_testcase_parameter( 'Exp3_DeploymentloopStatusInEEPROM' );  
	$tcpar_ExpResp1_DeploymentloopStatus = GEN_Read_mandatory_testcase_parameter( 'ExpResp1_DeploymentloopStatus' );
	$tcpar_ExpResp2_DeploymentloopStatus = GEN_Read_mandatory_testcase_parameter( 'ExpResp2_DeploymentloopStatus' );
	$tcpar_ExpResp3_DeploymentloopStatus = GEN_Read_mandatory_testcase_parameter( 'ExpResp3_DeploymentloopStatus' );
	$tcpar_ExpResp4_DeploymentloopStatus = GEN_Read_mandatory_testcase_parameter( 'ExpResp4_DeploymentloopStatus' );
	$tcpar_Exp1_AlgoStatus = GEN_Read_mandatory_testcase_parameter( 'Exp1_AlgoStatus' );
	$tcpar_Exp2_AlgoStatus = GEN_Read_mandatory_testcase_parameter( 'Exp2_AlgoStatus' );
	$tcpar_Exp1_WLStatus = GEN_Read_mandatory_testcase_parameter( 'Exp1_WLStatus' );
	$tcpar_Exp2_WLStatus = GEN_Read_mandatory_testcase_parameter( 'Exp2_WLStatus' );
	$tcpar_Exp1_DecryptionKeyInRAM = GEN_Read_mandatory_testcase_parameter( 'Exp1_DecryptionKeyInRAM' );
	$tcpar_Exp2_DecryptionKeyInRAM = GEN_Read_mandatory_testcase_parameter( 'Exp2_DecryptionKeyInRAM' );
	$tcpar_Write_DismantlerInfo_First = GEN_Read_mandatory_testcase_parameter( 'Write_DismantlerInfo_First' );
	$tcpar_Write_DismantlerInfo_Second = GEN_Read_mandatory_testcase_parameter( 'Write_DismantlerInfo_Second' );
	$tcpar_Write_DismantlerInfo_Third = GEN_Read_mandatory_testcase_parameter( 'Write_DismantlerInfo_Third' );
	$tcpar_ExpResp_Write_DismantlerInfo_Second = GEN_Read_mandatory_testcase_parameter( 'ExpResp_Write_DismantlerInfo_Second' );
	$tcpar_ExpResp_Write_DismantlerInfo_Third = GEN_Read_mandatory_testcase_parameter( 'ExpResp_Write_DismantlerInfo_Third' );
	$tcpar_ExpResp_Read_DismantlerInfo_Second = GEN_Read_mandatory_testcase_parameter( 'ExpResp_Read_DismantlerInfo_Second' );
	$tcpar_ExpResp_Read_DismantlerInfo_Third = GEN_Read_mandatory_testcase_parameter( 'ExpResp_Read_DismantlerInfo_Third' );	
	
	#parameters reading from project.par file
	$projpar_SquibName = S_read_project_parameter('SquibName');
	$projpar_LoopID = S_read_project_parameter('LoopId');
	$projpar_LoopStatus_BitPosition = S_read_project_parameter('LoopStatus_BitPosition');
	$projpar_RefSquibName = S_read_project_parameter('RefSquibName');

return 1;
}


#### INITIALIZE TC #####
sub TC_initialization {
	
	CA_trace_start();

	S_w2rep("Set the preconditions for this test case", 'blue');
	my $msg_aref = $LIFT_PROJECT::Defaults->{"CUSTOMER_DIAGNOSIS"}{"TesterPresent_SupressPosResp"}{"Requests"}{"REQ_TesterPresent_SupressPosResp"}{'Requests'};
	my $msg_ID = $LIFT_PROJECT::Defaults->{"CUSTOMER_DIAGNOSIS"}{'RequestID_disposal'};
	my $cycle  = 4500;
		
	#Taking the EEPROM dump from fault free setup and Initializating EEPROM.
	if(not defined ($LIFT_PROJECT::Defaults->{'TEMP'}{'Count'}))
	{
	S_w2rep("Step 1: Re-initialize EEPROM", 'blue');
	GEN_printComment("Taking the EEPROM dump from fault free setup for the 1st time");
	PD_DumpEEPROM('$LIFT_PRJCFG_path/../reports/Temp_EEPROM_Dump.hex');
	S_wait_ms(2000);
	$LIFT_PROJECT::Defaults->{'TEMP'}{'Count'} = 0x01; #Count to take EEPROM dump for only 1st time.	
	}
	
	S_w2rep("Step 2: Standard Preparation", 'blue');
	GEN_StandardPrepNoFault ();
	GEN_ProjectSpecificSettings();

	S_w2rep("Step 3: NoACLConnected", 'blue');
	my $status = ACEA_SetACLConnection ('Disconnect');
	
	#Setting the request ID and response ID for ACEA.
	GDCOM_set_addressing_mode("disposal");    #Setting disposal request ID and response ID	
	
	S_w2rep("Step 4: SendTesterPresentCyclically", 'blue');
	$TP_handle = GDCOM_start_CyclicTesterPresent($msg_aref,$msg_ID,$cycle);
	
	S_w2rep("Step 5: SetTestCondition", 'blue');
	if($tcpar_TestCondition ne 'NoFlt'){
		ACEA_SetTestCondition ($projpar_SquibName, $tcpar_TestCondition, $projpar_RefSquibName);
	}
	
return 1;	
}


### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	#remove 0x from loop id. 0x01 --> 01
	$projpar_LoopID =~ s/0x//i;
	
	S_w2rep("Step 1: Read HW deploypemt method", 'blue');
	$Resp_HWDeploymentMethod = ACEA_Read_HWDeploymentMethod();

	S_w2rep("Step 2: Read Number of PCU's in the Vehicle", 'blue');
	$Resp_NumberOfPCUs = ACEA_Read_NumberOfPCUs();
	
	S_w2rep("Step 3: Read address information of PCU's", 'blue');
	$Resp_PCUAddressInfo = ACEA_Read_ECUAddressInfo();

	S_w2rep("Step 4: Read VIN", 'blue');
	$Resp_ReadVIN = ACEA_Read_VIN();

	S_w2rep("Step 5: Read default dismantler information", 'blue');
	$Resp_ReadDismantlerInfo_Default = ACEA_ReadDismantlerInfo();

	S_w2rep("Step 6: write dismantler information for the first time", 'blue');
	ACEA_WriteDismantlerInfo($tcpar_Write_DismantlerInfo_First, undef, undef);

	S_w2rep("Step 7: write dismantler information for the second time", 'blue');
	$Resp_WriteDismantlerInfo_Rewrite = ACEA_WriteDismantlerInfo($tcpar_Write_DismantlerInfo_Second, $tcpar_ExpResp_Write_DismantlerInfo_Second, 'NO_EVAL_SWITCH');

	S_w2rep("Step 8: Read dismantler information after rewriting dismantler information", 'blue');
	$Resp_ReadDismantlerInfo_AfterRewrite = ACEA_ReadDismantlerInfo('NO_EVAL_SWITCH');

	S_w2rep("Step 9: Read default deployment loop table", 'blue');
	$Resp_ReadDLT_BeforeSPLActivation = ACEA_Read_DiploymentLoopTable();

	S_w2rep("Step 9: Read default loop status from EEPROM", 'blue');
	$DPLStatus_EEPROM_BeforeSPLActivation = ACEA_ReadDPLStatusEEPROM();

	S_w2rep("Step 10: Enter into safety system diagnostic session", 'blue');
	GDCOM_StartSession('DisposalSession');

	S_w2rep("Step 11: Read Algo status after Entering into safety sysyem diagnostic session", 'blue');
    $Algo_Status_BeforeSPLActivation = ACEA_ReadAlgoStatus();

	S_w2rep("Step 11: ReadWL status after Entering into safety sysyem diagnostic session", 'blue');
    $WL_Status_BeforeSPLActivation = ACEA_ReadWLStatus();

	S_w2rep("Step 12: Read Default Disposal key stored at RAM", 'blue');
	
	$DisposalKey_BeforeSPLActivation = ACEA_ReadDecryptionKeyInRAM();
	
	S_w2rep("Step 13: Obtain  security access", 'blue');
	ACEA_Get_SecurityAccess();

	S_w2rep("Step 14: Read Disposal key stored at RAM after Activating DPL", 'blue');
	$DisposalKey_AfterSPLActivation = ACEA_ReadDecryptionKeyInRAM();

	S_w2rep("Step 15: Read disable line status before DPL activation", 'blue');
	$DisLnStatus_beforeDPLactivation = ACEA_ReadDisableLineStatus();

	S_w2rep("Step 16: Execute disposal Program loader once again", 'blue');
	ACEA_ExecuteDisposalProgramLoader($ExecuteSPL_With_Conversion);

	S_w2rep("Step 17: Execute disposal Program loader", 'blue');
	ACEA_ExecuteDisposalProgramLoader($ExecuteSPL_With_Conversion);
	
	S_w2rep("Step 18: Read disable line status", 'blue');
	$DisLnStatus_afterDPLactivation = ACEA_ReadDisableLineStatus();
		
	S_w2rep("Step 19: Read Algo status after Activating DPL", 'blue');
    $Algo_Status_AfterSPLActivation = ACEA_ReadAlgoStatus();

	S_w2rep("Step 19: Read WL status after Activating DPL", 'blue');
    $WL_Status_AfterSPLActivation = ACEA_ReadWLStatus();

	S_w2rep("Step 20: Read deployment loop table after Activating DPL", 'blue');
	$Resp_ReadDLT_AfterSPLActivation = ACEA_Read_DiploymentLoopTable();

	S_w2rep("Step 21: Read Deployment loop status from EEPROM before Firing the squib", 'blue');
	$DPLStatus_EEPROM_AfterSPLActivation = ACEA_ReadDPLStatusEEPROM();

	S_w2rep("Step 21: Read Routine Result before firing the squib", 'blue');
	$Resp_RequestRoutineResult_AfterSPLActivation = ACEA_RequestRoutineResults($projpar_LoopID);

	if($tcpar_ACLSupported eq 'Yes'){
		S_w2rep("Step 22: Fire a squib without ACL connected", 'blue');
		$Resp_FireSquib_WithOutACL = ACEA_FireSquib($projpar_LoopID);
			
		S_w2rep("Step 23: Connecting the ACL PWM signal", 'blue');
		ACEA_SetACLConnection('Connect');			
	}		

	S_w2rep("Step 24: Read disable line status after DPL activation and ACL connection", 'blue');
	$DisLnStatus_afterACLConnection = ACEA_ReadDisableLineStatus();

	S_w2rep("Step 25: Fire a squib", 'blue');
	$Resp_FireSquib_WithACL = ACEA_FireSquib($projpar_LoopID);

	S_w2rep("Step 26: Writ dismantler information after first squib fired", 'blue');
	$Resp_WriteDismantlerInfo_AfterFiring = ACEA_WriteDismantlerInfo($tcpar_Write_DismantlerInfo_Third, $tcpar_ExpResp_Write_DismantlerInfo_Third, 'NO_EVAL_SWITCH');
	
	S_w2rep("Step 27: Read dismantler information after squib fired", 'blue');
	$Resp_ReadDismantlerInfo_AfterFiring = ACEA_ReadDismantlerInfo('NO_EVAL_SWITCH');

	S_w2rep("Step 28: Read deployment loop table after firing the squib", 'blue');
	$Resp_ReadDLT_AfterFiring = ACEA_Read_DiploymentLoopTable();

	S_w2rep("Step 28: Read Deployment loop status from EEPROM after firing the squib", 'blue');
	$AfterFire_DPLStatus_EEPROM = ACEA_ReadDPLStatusEEPROM();

	S_w2rep("Step 29: Read Request Routine Result after firiing the squib", 'blue');
	$Resp_RequestRoutineResult_AfterFiring = ACEA_RequestRoutineResults($projpar_LoopID);

	S_w2rep("Step 30: Reset ECU", 'blue');
	GEN_Power_on_Reset();

	S_w2rep("Step 31: Read deployment loop table after Restarting ECU.", 'blue');
	$Resp_ReadDLT_AfterReset = ACEA_Read_DiploymentLoopTable();

	S_w2rep("Step 31: Read Deployment loop status from EEPROM after Restarting ECU.", 'blue');
	$DPLStatus_EEPROM_AfterReset = ACEA_ReadDPLStatusEEPROM();
											
return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {
	#remove 0x from loop id. 0x01 --> 01
	$projpar_LoopID =~ s/0x//i;
	
	S_w2rep("Step 1: Evaluate HW deploypemt methodNo evaluation, positive response is evaluated in TC_stimulation_and_measurement", 'blue');

	S_w2rep("Step 2: Evaluate Number of PCU's in the VehicleNo evaluation, positive response is evaluated in TC_stimulation_and_measurement", 'blue');

	S_w2rep("Step 3: Evaluate address information of PCU'sNo evaluation, positive response is evaluated in TC_stimulation_and_measurement", 'blue');

	S_w2rep("Step 4: Evaluate VINNo evaluation, positive response is evaluated in TC_stimulation_and_measurement", 'blue');

	S_w2rep("Step 5: Evaluate dismantler information", 'blue');
	my $Resp_ReadDismantlerInfo_Default = ACEA_ExtractRespDataToBeEvaluated($Resp_ReadDismantlerInfo_Default, 9);
	EVAL_evaluate_string( "", '00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00', $Resp_ReadDismantlerInfo_Default);	

	S_w2rep("Step 6: write dismantler information for the first time - No evaluation, positive response is evaluated in TC_stimulation_and_measurement", 'blue');

	S_w2rep("Step 7: Evaluate response for write dismantler information for the second time - No evaluation, response is evaluated in TC_stimulation_and_measurement", 'blue');
	#EVAL_evaluate_string( "", $tcpar_ExpResp_Write_DismantlerInfo_Second, $Resp_WriteDismantlerInfo_Rewrite);			

	S_w2rep("Step 8: Evaluate response for Read dismantler information after rewriting", 'blue');
	$Resp_ReadDismantlerInfo_AfterRewrite = ACEA_ExtractRespDataToBeEvaluated($Resp_ReadDismantlerInfo_AfterRewrite, 9);
	EVAL_evaluate_string( "", $tcpar_ExpResp_Read_DismantlerInfo_Second, $Resp_ReadDismantlerInfo_AfterRewrite);			

	S_w2rep("Step 9: Read default deployment loop table", 'blue'); 
	$Resp_ReadDLT_BeforeSPLActivation = ACEA_ExtractRespDataToBeEvaluated($Resp_ReadDLT_BeforeSPLActivation, 18);
	ACEA_EvaluateDLTForGivenLoopId($Resp_ReadDLT_BeforeSPLActivation, $tcpar_ExpResp1_DeploymentloopStatus, $projpar_LoopID,$tcpar_TestCondition);

	S_w2rep("Step 9: Read default loop status from EEPROM", 'blue');
	$tcpar_Exp1_DeploymentloopStatusInEEPROM = hex($tcpar_Exp1_DeploymentloopStatusInEEPROM) << $projpar_LoopStatus_BitPosition;
	EVAL_evaluate_value("", $DPLStatus_EEPROM_BeforeSPLActivation, '==', $tcpar_Exp1_DeploymentloopStatusInEEPROM);

	S_w2rep("Step 10: Enter into safety sysyem diagnostic session - No evaluation, positive response is evaluated in TC_stimulation_and_measurement", 'blue');

	S_w2rep("Step 11: Evaluate Algo status read after Entering into safety sysyem diagnostic session", 'blue');
	ACEA_EvaluateAlgoStatus($Algo_Status_BeforeSPLActivation, $tcpar_Exp1_AlgoStatus);

	S_w2rep("Step 11: Evaluate WL status read after Entering into safety sysyem diagnostic session", 'blue');
	ACEA_EvaluateWLStatus($WL_Status_BeforeSPLActivation, $tcpar_Exp1_WLStatus);

	S_w2rep("Step 12: Evaluate Default Disposal key stored at RAM", 'blue');
	EVAL_evaluate_value("", $DisposalKey_BeforeSPLActivation, '==',$tcpar_Exp1_DecryptionKeyInRAM);	
	
	S_w2rep("Step 13: Obtain security access - No evaluation, positive response is evaluated in TC_stimulation_and_measurement", 'blue');

	S_w2rep("Step 14: Evaluate Disposal key stored at RAM read after Activating DPL", 'blue');
	EVAL_evaluate_value("", $DisposalKey_AfterSPLActivation, '==',$tcpar_Exp2_DecryptionKeyInRAM);

	S_w2rep("Step 15: evaluate disable line status before DPL activation", 'blue');
	ACEA_EvaluateDisableLineStatus('DISABLED', $DisLnStatus_beforeDPLactivation);
	
	S_w2rep("Step 16: Execute disposal Program loader - No evaluation, positive response is evaluated in TC_stimulation_and_measurement", 'blue');

	S_w2rep("Step 17: Execute disposal Program loader once again - No evaluation, positive response is evaluated in TC_stimulation_and_measurement", 'blue');
	
	if($tcpar_ACLSupported eq 'Yes'){
	S_w2rep("Step 18: evaluate disable line status after ACL connection", 'blue');
	ACEA_EvaluateDisableLineStatus('ENABLED_EXCEPT_DISAHP', $DisLnStatus_afterDPLactivation);
	}
	else{
	S_w2rep("Step 18: evaluate disable line status", 'blue');
	ACEA_EvaluateDisableLineStatus('ENABLED', $DisLnStatus_afterDPLactivation);
	}
		
	S_w2rep("Step 19: Evaluate Algo status read after Activating DPL", 'blue');
	ACEA_EvaluateAlgoStatus($Algo_Status_AfterSPLActivation, $tcpar_Exp2_AlgoStatus);

	S_w2rep("Step 19: Evaluate WL status read after Activating DPL", 'blue');
	ACEA_EvaluateWLStatus($WL_Status_AfterSPLActivation, $tcpar_Exp2_WLStatus);

	S_w2rep("Step 20: Evaluate deployment loop table after Activating DPL", 'blue');
	$Resp_ReadDLT_AfterSPLActivation = ACEA_ExtractRespDataToBeEvaluated($Resp_ReadDLT_AfterSPLActivation, 18);
	S_w2rep("Resp_ReadDLT_AfterSPLActivation = $Resp_ReadDLT_AfterSPLActivation");
	S_w2rep("projpar_LoopID = $projpar_LoopID");
	ACEA_EvaluateDLTForGivenLoopId($Resp_ReadDLT_AfterSPLActivation, $tcpar_ExpResp2_DeploymentloopStatus, $projpar_LoopID,$tcpar_TestCondition);
	

	S_w2rep("Step 20: Evaluate Deployment loop status from EEPROM read before Firing the squib", 'blue');
	$tcpar_Exp2_DeploymentloopStatusInEEPROM = hex($tcpar_Exp2_DeploymentloopStatusInEEPROM) << $projpar_LoopStatus_BitPosition;
	EVAL_evaluate_value("", $DPLStatus_EEPROM_AfterSPLActivation, '==',$tcpar_Exp2_DeploymentloopStatusInEEPROM);

	S_w2rep("Step 21: Evaluate Routine Result read before firing the squib", 'blue');
	my $Resp_RequestRoutineResult_AfterSPLActivation = ACEA_ExtractRespDataToBeEvaluated($Resp_RequestRoutineResult_AfterSPLActivation, 18);
	EVAL_evaluate_string( "", $tcpar_ExpResp2_DeploymentloopStatus, $Resp_RequestRoutineResult_AfterSPLActivation);	

	if($tcpar_ACLSupported eq 'Yes'){
		S_w2rep("Step 22: Evaluate response for Fire a squib without ACL connected", 'blue');		
		my $Resp_FireSquib_WithOutACL = ACEA_ExtractRespDataToBeEvaluated($Resp_FireSquib_WithOutACL, 18);
		EVAL_evaluate_string( "", $tcpar_ExpResp2_DeploymentloopStatus, $Resp_FireSquib_WithOutACL);			
			
		S_w2rep("Step 23: Connecting the ACL PWM signal - No evaluation", 'blue');		
	}		

	S_w2rep("Step 24: evaluate disable line status after DPL activation", 'blue');
	ACEA_EvaluateDisableLineStatus('ENABLED', $DisLnStatus_afterACLConnection);

	S_w2rep("Step 25: Evaluate response for Fire a squib", 'blue');
	my $Resp_FireSquib_WithACL = ACEA_ExtractRespDataToBeEvaluated($Resp_FireSquib_WithACL, 18);
	EVAL_evaluate_string( "", $tcpar_ExpResp3_DeploymentloopStatus, $Resp_FireSquib_WithACL);		

	S_w2rep("Step 26: Evaluate response for writing dismantler information after first squib fired - No evaluation, response is evaluated in TC_stimulation_and_measurement", 'blue');			

	S_w2rep("Step 27: Evaluate response for Read dismantler information after first squib fired", 'blue');
	$Resp_ReadDismantlerInfo_AfterFiring = ACEA_ExtractRespDataToBeEvaluated($Resp_ReadDismantlerInfo_AfterFiring, 9);
	EVAL_evaluate_string( "", $tcpar_ExpResp_Read_DismantlerInfo_Third, $Resp_ReadDismantlerInfo_AfterFiring);			

	S_w2rep("Step 28: Reading deployment loop table after firing the squib", 'blue');
	$Resp_ReadDLT_AfterFiring = ACEA_ExtractRespDataToBeEvaluated($Resp_ReadDLT_AfterFiring, 18);
	ACEA_EvaluateDLTForGivenLoopId($Resp_ReadDLT_AfterFiring, $tcpar_ExpResp3_DeploymentloopStatus, $projpar_LoopID,$tcpar_TestCondition);

	S_w2rep("Step 28: Evaluate Deployment loop status from EEPROM read after firing the squib", 'blue');
	my $DeploymentloopStatusInEEPROM_BeforeReset = hex($tcpar_Exp3_DeploymentloopStatusInEEPROM) << $projpar_LoopStatus_BitPosition;
	EVAL_evaluate_value("", $AfterFire_DPLStatus_EEPROM, '==', $DeploymentloopStatusInEEPROM_BeforeReset);

	S_w2rep("Step 29: Evaluate Request Routine Result read after firiing the squib", 'blue');	
	my $Resp_RequestRoutineResult_AfterFiring = ACEA_ExtractRespDataToBeEvaluated($Resp_RequestRoutineResult_AfterFiring, 18);
	EVAL_evaluate_string( "", $tcpar_ExpResp3_DeploymentloopStatus, $Resp_RequestRoutineResult_AfterFiring);

	S_w2rep("Step 30: Reseting the ECU - No evaluation", 'blue');

	S_w2rep("Step 31: Evaluate deployment loop table read after Restarting ECU.", 'blue');
	$Resp_ReadDLT_AfterReset = ACEA_ExtractRespDataToBeEvaluated($Resp_ReadDLT_AfterReset, 18);
	ACEA_EvaluateDLTForGivenLoopId($Resp_ReadDLT_AfterReset, $tcpar_ExpResp4_DeploymentloopStatus, $projpar_LoopID,$tcpar_TestCondition);

	S_w2rep("Step 31: Evaluate Deployment loop status from EEPROM read after Restarting ECU.", 'blue');
	my $DeploymentloopStatusInEEPROM_AfterReset = hex($tcpar_Exp3_DeploymentloopStatusInEEPROM) << $projpar_LoopStatus_BitPosition;
	EVAL_evaluate_value("", $DPLStatus_EEPROM_AfterReset, '==',$DeploymentloopStatusInEEPROM_AfterReset);
	
return 1;
}

#### TC FINALIZATION #####
sub TC_finalization {

	ACEA_ResetTestCondition($projpar_SquibName, $tcpar_TestCondition);

	#Stop the TP seding cyclically
	GDCOM_stop_CyclicTesterPresent($TP_handle);
	
	#Initializating EEPROM to make fault free setup.
	PD_InitEEPROM ('$LIFT_PRJCFG_path/../reports/Temp_EEPROM_Dump.hex');
	S_wait_ms(2000);
	GEN_Power_on_Reset();
		
return 1;
}

1;

__END__