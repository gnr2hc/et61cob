#### TEST CASE MODULE
package TC_DIS_ECUresetHandling;
#-> package name has to match file name ! case sensitive !

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
###-------------------------------
our $VERSION = q$Revision: 1.16 $;
our $HEADER = q$Header: ACEA/TC_DIS_ECUresetHandling.pm 1.16 2014/03/05 12:41:53ICT BAA1BMH develop  $;
##################################

#### INCLUDE ENGINE MODULES ####
use LIFT_general;   
use LIFT_PD;
use LIFT_CD_CAN;
use LIFT_evaluation;
use GENERIC_DCOM;
use FuncLib_TNT_GEN;
use FuncLib_Project_GEN;
use FuncLib_ACEA_TNT;
use LIFT_can_access;


##################################

our $PURPOSE = "To test reset handling by ACEA under various different conditions";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

#-> update documentation that somebody else can use the test without asking you
#-> delete parameter section if no paramteres are used
#-> note that POD documentation needs entirely empty lines before and after keywords (e.g. =head1, =cut ...) 

=head1 TESTCASE MODULE

TC_template  $Revision: 1.16 $

=head1 PURPOSE



=head1 TESTCASE DESCRIPTION

	[parameter used]
    Testcase Parameter:
	purpose
	ResetStrategy
	TestCondition
	DiagCommunicationStopMethod
	SPLActivation
	Exp_DecryptionKeyInRAM
	PowerOnCounter_var
	SessionExpiryTimeDuration
	Val_PonCntr

    [initialisation]
	Step 1: Re-initialize EEPROM
	Step 2: Standard Preparation
	Step 3: NoACLConnected
	Step 4: SendTesterPresentCyclically

    [stimulation & measurement]
	Step 1: Enter into safety sysyem diagnostic session
	execute Step 2 - 7 if ResetStrategy = 'Stategy2' and SPLActivation = 'ActivateSPL',
	Step 2: Reading Disposal key stored at RAM"
	Step 3: Reading Disposal commands stored at RAM
	Step 4: obtain security access for ACEA"
	Step 5: Activate DPL
	Step 6: Reading Disposal key stored at RAM
	Step 7: Reading Disposal commands stored at RAM
	Step 8: Reading power ON counter
	Step 9-15: Set <TestCondition>.
	Step 16: Reading power ON counter
	Step 17: Reading Disposal key stored at RAM
	Step 18: Reading Disposal commands stored at RAM

	    [evaluation]
	Step 1: Evaluate response for Enter into safety sysyem diagnostic session
	execute Step 2 - 7 if ResetStrategy = 'Stategy2' and SPLActivation = 'ActivateSPL',
	Step 2: Evaluate Disposal key stored at RAM"
	Step 3: Evaluate Disposal commands stored at RAM
	Step 4: Evaluate response for obtain security access for ACEA"
	Step 5: Evaluate response for Activate DPL
	Step 6: Evaluate Disposal key stored at RAM
	Step 7: Evaluate Disposal commands stored at RAM
	Step 8: No evaluation
	Step 9-15: No evaluation
	Step 16: power ON counter = power ON counter read in step 8 + 1
	Step 17: Evaluate Disposal key stored at RAM
	Step 18: Evaluate Disposal commands stored at RAM

    [finalisation]
	Bring back the system to normal state

=head1 PARAMETER

=head2 PARAMETER NAMES

	SCALAR purpose : Purpose of the test
	SCALAR ResetStrategy : configured reset strategy
	SCALAR TestCondition : Test condition
	SCALAR DiagCommunicationStopMethod : Diag Communication Stop Method
	SCALAR SPLActivation : Is SPL Activation required
	SCALAR DecryptionKeyInRAM_var : Variable for Decryption Key In RAM
	LIST DecryptedCommandsInRAM_var : Variable for Decrypted Commands In RAM
	SCALAR Exp_DecryptionKeyInRAM : expected Decryption Key In RAM after security access obtained.
	SCALAR PowerOnCounter_var : Variable Power On Counter
	SCALAR SessionExpiryTimeDuration : Session Expiry Time Duration
	SCALAR Val_PonCntr : Valuse Pon Cntr after reset

=head2 PARAMETER EXAMPLES

    [TC_template.dummy]
	purpose  = 'To test reset handling by ACEA under various different conditions'
	ResetStrategy = '<Test Heading 1>'
	TestCondition = '<Test Heading 2>' 
	DiagCommunicationStopMethod = '<Test Heading 3>' 
	SPLActivation = '<Test Heading 4>' 
	Exp_DecryptionKeyInRAM = '0x39AF'
	PowerOnCounter_var = 'V_POnCounter_U32E'
	SessionExpiryTimeDuration = 5000 #ms
	Val_PonCntr = 1

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#-> Input parameters for test defination.
my ($defaultpar_ResetStrategy,
	$defaultpar_TestCondition,
	$defaultpar_DiagCommunicationStopMethod,
	$defaultpar_SPLActivation,
	$defaultpar_SessionExpiryTimeDuration,
	$tcpar_Exp_DecryptionKeyInRAM,
	$tcpar_ECUResetBehavior,
	$tcconst_ECUSession_Var,
	$tcconst_ECUSession_Val_Disposal, 
	$tcconst_ECUSession_Val_Default);
  
my ($DecryptionKeyInRAM_1,
	$DecryptionKeyInRAM_2,
	$DecryptionKeyInRAM_3,
	$DisposalcommandsInRAM_1_ref,
	$DisposalcommandsInRAM_2_ref,
	$DisposalcommandsInRAM_3_ref,
	$FDdata,
	$MeasuredTimeDiff,
	$DefaultSesssionTime,
	$DisposalSesssionTime,
	$ActiveDiagSession_beforeReset,
	$ActiveDiagSession_afterReset,
	$ActiveDiagSession_untilReset,
	$TimeStamp_ResetTrigger,
	$TimeStamp_afterReset,
	$TP_handle,
	$TP_stopFlag);  
	
	$TP_stopFlag = 'None';
		my $Handle;
  my $RoutineControlOption = '01';	
	
sub TC_set_parameters {	

	$defaultpar_ResetStrategy = GEN_Read_mandatory_testcase_parameter( 'ResetStrategy' );
	$defaultpar_TestCondition = GEN_Read_mandatory_testcase_parameter( 'TestCondition' );
	$defaultpar_DiagCommunicationStopMethod = GEN_Read_mandatory_testcase_parameter( 'DiagCommunicationStopMethod' );
	$defaultpar_SPLActivation = GEN_Read_mandatory_testcase_parameter( 'SPLActivation' );
	$defaultpar_SessionExpiryTimeDuration = GEN_Read_mandatory_testcase_parameter( 'SessionExpiryTimeDuration' );
	$tcpar_Exp_DecryptionKeyInRAM = GEN_Read_mandatory_testcase_parameter( 'Exp_DecryptionKeyInRAM' );
	$tcpar_ECUResetBehavior = GEN_Read_mandatory_testcase_parameter( 'ECUResetBehavior' ); 
	
	$tcconst_ECUSession_Var = $LIFT_PROJECT::Defaults->{'ECUSESSION'}{'ECUSession_Var'};
	$tcconst_ECUSession_Val_Disposal = $LIFT_PROJECT::Defaults->{'ECUSESSION'}{'ECUSessionVal_Disposal'};
	$tcconst_ECUSession_Val_Default = $LIFT_PROJECT::Defaults->{'ECUSESSION'}{'ECUSessionVal_Default'};
  S_w2rep("$tcconst_ECUSession_Var, $tcconst_ECUSession_Val_Disposal, $tcconst_ECUSession_Val_Default");
return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	CA_trace_start();

	S_w2rep("Set the preconditions for this test case", 'blue');
	my $msg_aref = $LIFT_PROJECT::Defaults->{"CUSTOMER_DIAGNOSIS"}{"TesterPresent_SupressPosResp"}{"Requests"}{"REQ_TesterPresent_SupressPosResp"}{'Requests'};
	my $msg_ID = $LIFT_PROJECT::Defaults->{"CUSTOMER_DIAGNOSIS"}{'RequestID_disposal'};
	my $cycle  = 4500;

	#Taking the EEPROM dump from fault free setup and Initializating EEPROM.
	if(not defined ($LIFT_PROJECT::Defaults->{'TEMP'}{'Count'}))
	{
	S_w2rep("Step 1: Re-initialize EEPROM", 'blue');		
	GEN_printComment("Taking the EEPROM dump from fault free setup for the 1st time");
	PD_DumpEEPROM('$LIFT_PRJCFG_path/../reports/Temp_EEPROM_Dump.hex');
	S_wait_ms(2000);
	$LIFT_PROJECT::Defaults->{'TEMP'}{'Count'} = 0x01; #Count to take EEPROM dump for only 1st time.	
	} 

	S_w2rep("Step 2: Standard Preparation", 'blue');
	GEN_StandardPrepNoFault ();
	GEN_ProjectSpecificSettings();	
	
	S_w2rep("Step 3: NoACLConnected", 'blue');
	ACEA_SetACLConnection ('Disconnect');
	
	#Setting the request ID and response ID for ACEA.
	GDCOM_set_addressing_mode("disposal");    #Setting disposal request ID and response ID	
	
	S_w2rep("Step 4: SendTesterPresentCyclically", 'blue');
	$TP_handle = GDCOM_start_CyclicTesterPresent($msg_aref,$msg_ID,$cycle);
	
	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	S_w2rep("Step 1: Enter into safety sysyem diagnostic session", 'blue');
	GDCOM_StartSession('DisposalSession');

	if(($defaultpar_ResetStrategy eq 'Stategy2') && ($defaultpar_SPLActivation eq 'ActivateSPL')){
		S_w2rep("Step 2: Reading Disposal key stored at RAM", 'blue');
		$DecryptionKeyInRAM_1 = ACEA_ReadDecryptionKeyInRAM();

		S_w2rep("Step 3: Reading Disposal commands stored at RAM", 'blue');
		$DisposalcommandsInRAM_1_ref = ACEA_ReadDecryptedCommandsInRAM();
		
		S_w2rep("Step 4: obtain security access for ACEA", 'blue');
		ACEA_Get_SecurityAccess();
		
		S_w2rep("Step 5: Activate DPL", 'blue');
		ACEA_ExecuteDisposalProgramLoader($RoutineControlOption);
		
		S_w2rep("Step 6: Reading Disposal key stored at RAM", 'blue');
		$DecryptionKeyInRAM_2 = ACEA_ReadDecryptionKeyInRAM();

		S_w2rep("Step 7: Reading Disposal commands stored at RAM", 'blue');
		$DisposalcommandsInRAM_2_ref = ACEA_ReadDecryptedCommandsInRAM();

	}
	elsif(($defaultpar_ResetStrategy ne 'Stategy1')
			&& ($defaultpar_ResetStrategy ne 'Stategy2') 
			&& ($defaultpar_SPLActivation ne 'ActivateSPL')
			&& ($defaultpar_SPLActivation ne 'NoActivateSPL')){
		#Set warning for Invalid Reset Strategy or Invalid SPL Activation.
		S_set_error("Invalid parameter values : Reset Strategy - $defaultpar_ResetStrategy or SPL Activation - $defaultpar_SPLActivation", 0);
	}

	S_w2rep("Step 8: Read active diag session", 'blue');
	$ActiveDiagSession_beforeReset = S_aref2hex (PD_ReadMemoryByName($tcconst_ECUSession_Var));
	
	if($defaultpar_TestCondition eq 'DiagSesssionChange'){
		S_w2rep("Step 9: Entering into default session", 'blue');
		GDCOM_StartSession('DefaultSession');
	}
	elsif($defaultpar_TestCondition eq 'SpecialTestMode'){
		S_w2rep("Step 15: Set ECU to special test mode", 'blue');
		GEN_printTestStep("Creating this condition is not possible");
		
	}
	elsif($defaultpar_TestCondition eq 'StopDiagCommunication'){
		if($defaultpar_DiagCommunicationStopMethod eq 'StopDiagandTesterPresent'){
			S_w2rep("Step 10: Stopping tester present", 'blue');
			CD_stop_message($TP_handle);
			$TP_stopFlag = 'STOPPED'; #Clear handle

			S_w2rep("Step 11: Reading VIN", 'blue');
			ACEA_Read_VIN();	
			GEN_printComment("Geting the time stamp when request to VIN is sent");
			$TimeStamp_ResetTrigger = S_get_TC_time();	
		}
		elsif($defaultpar_DiagCommunicationStopMethod eq 'StopOnlyTestPresent'){
			S_w2rep("Step 13: Stopping tester present", 'blue');
			CD_stop_message($TP_handle);
			$TP_stopFlag = 'STOPPED'; #Clear handle
			GEN_printComment("Geting the time stamp when tester present is stopped");
			$TimeStamp_ResetTrigger = S_get_TC_time();			
		}
		else{
			#Set warning, As Can't creat this Diag Communication Stop Method	=> Step 15 in SRTP.
			S_set_error("Invalid parameter value : Diag Communication Stop Method = $defaultpar_DiagCommunicationStopMethod", 0); #warning!
		}
	}
	else{
		#Set warning for Invalid test condition.
		S_set_error("Invalid parameter value : test condition = $defaultpar_TestCondition", 0); #warning!
	}	

	if(($defaultpar_TestCondition eq 'StopDiagCommunication') && ($defaultpar_SPLActivation ne 'NoActivateSPL')){
		S_w2rep("Step 12 & 14: Measure Time Difference Between last Diag and ECUreset", 'blue');
		$ActiveDiagSession_untilReset = S_aref2hex (PD_ReadMemoryByName($tcconst_ECUSession_Var));
		$TimeStamp_afterReset = S_get_TC_time();
		my $ExpiryTime = $TimeStamp_afterReset + 10;
		while(($ActiveDiagSession_untilReset eq '0x10') && ($TimeStamp_afterReset < $ExpiryTime)){
			$ActiveDiagSession_untilReset = S_aref2hex (PD_ReadMemoryByName($tcconst_ECUSession_Var));
			$TimeStamp_afterReset = S_get_TC_time();
		}
		
		$MeasuredTimeDiff = $TimeStamp_afterReset - $TimeStamp_ResetTrigger;
	}
	
	S_w2rep("Step 16: reading active diag session after reset", 'blue');	
	S_wait_ms('TIMER_ECU_READY');
	$ActiveDiagSession_afterReset = S_aref2hex(PD_ReadMemoryByName($tcconst_ECUSession_Var));

	if(($defaultpar_ResetStrategy eq 'Stategy2') && ($defaultpar_SPLActivation eq 'ActivateSPL')){
		S_w2rep("Step 17: Reading Disposal key stored at RAM", 'blue');		
		$DecryptionKeyInRAM_3 = ACEA_ReadDecryptionKeyInRAM();
		
		# Read Disposal commands stored at RAM.		=> Step 3 in SRTP.
		S_w2rep("Step 18: Reading Disposal commands stored at RAM", 'blue');
		 $DisposalcommandsInRAM_3_ref = ACEA_ReadDecryptedCommandsInRAM();
	}
	elsif($defaultpar_ResetStrategy eq 'Stategy1'){
		#Do nothing.
	}
	else{
		#Set warning for Invalid Reset Strategy
		S_set_error("Invalid parameter value ; Reset Strategy = $defaultpar_ResetStrategy", 0); 
	}
		
return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	S_w2rep("Step 1: Enter into safety sysyem diagnostic session, No evaluation - Diag response evaluation is already done in TC_stimulation_and_measurement", 'blue');

	if(($defaultpar_ResetStrategy eq 'Stategy2') && ($defaultpar_SPLActivation eq 'ActivateSPL')){
		S_w2rep("Step 2: power on counter  in RAM before SPL activation", 'blue');
		EVAL_evaluate_value("Decryption Key in RAM before SPL activation", $DecryptionKeyInRAM_1, '==', 0);

		S_w2rep("Step 3: disposal commands in RAM before SPL activation", 'blue');
		ACEA_EvaluateDecryptedCommandsInRAM($DisposalcommandsInRAM_1_ref, 'ZERO');

		S_w2rep("Step 4: obtain security access, No evaluation - Diag response evaluation is already done in TC_stimulation_and_measurement", 'blue');

		S_w2rep("Step 5: Activate DPL, No evaluation - Diag response evaluation is already done in TC_stimulation_and_measurement", 'blue');

		S_w2rep("Step 6: Reading Disposal key stored at RAM", 'blue');
		EVAL_evaluate_value("Decryption Key in RAM after SPL activation", $DecryptionKeyInRAM_2, '==', $tcpar_Exp_DecryptionKeyInRAM);

		# Read Disposal commands stored at RAM.		=> Step 3 in SRTP.
		S_w2rep("Step 7: Reading Disposal commands stored at RAM", 'blue');
		ACEA_EvaluateDecryptedCommandsInRAM($DisposalcommandsInRAM_2_ref, 'NONZERO');
	}

	S_w2rep("Step 8: Active diag session", 'blue');
	if($defaultpar_SPLActivation eq 'NoActivateSPL'){
		EVAL_evaluate_value("",$ActiveDiagSession_beforeReset, '==', $tcconst_ECUSession_Val_Default);
	}
	else{
		EVAL_evaluate_value("",$ActiveDiagSession_beforeReset, '==', $tcconst_ECUSession_Val_Disposal);
	}

	if($defaultpar_TestCondition eq 'DiagSesssionChange'){
		S_w2rep("Step 9: No evaluation - Diag response evaluation is already done in TC_stimulation_and_measurement", 'blue');
	}
	elsif($defaultpar_TestCondition eq 'SpecialTestMode'){
		S_w2rep("Step 15: No evaluation", 'blue');
	}
	elsif($defaultpar_TestCondition eq 'StopDiagCommunication'){
		if($defaultpar_DiagCommunicationStopMethod eq 'StopDiagandTesterPresent'){
			S_w2rep("Step 10: No evaluation ", 'blue');
			S_w2rep("Step 11: No evaluation - Diag response evaluation is already done in TC_stimulation_and_measurement", "blue");
			if(($defaultpar_SPLActivation ne 'NoActivateSPL')){
				S_w2rep("Step 12: Measure Time Difference Between last DIag Service and ECUreset", 'blue');
				EVAL_evaluate_value("Time Difference Between last DIag Service and ECUreset",($MeasuredTimeDiff * 1000) , '==', $defaultpar_SessionExpiryTimeDuration, 700, 'absolute');
			}
		}
		elsif($defaultpar_DiagCommunicationStopMethod eq 'StopOnlyTestPresent'){
			S_w2rep("Step 13: No evaluation ", 'blue');
			if(($defaultpar_SPLActivation ne 'NoActivateSPL')){
				S_w2rep("Step 14: Measure Time Difference Between tester present stop and ECUreset", 'blue');
				EVAL_evaluate_value("Time Difference Between tester present stop and ECUreset",($MeasuredTimeDiff * 1000) , '==', $defaultpar_SessionExpiryTimeDuration, 700, 'absolute');
			}			
		}
	}

	S_w2rep("Step 16: Active Diag session", 'blue');
	EVAL_evaluate_value("",$ActiveDiagSession_afterReset, '==', $tcconst_ECUSession_Val_Default);

	if(($defaultpar_ResetStrategy eq 'Stategy2') && ($defaultpar_SPLActivation eq 'ActivateSPL')){
		S_w2rep("Step 17: Reading Disposal key stored at RAM after ECU reset", 'blue');
		EVAL_evaluate_value("Decryption Key in RAM after ECU reset", $DecryptionKeyInRAM_3, '==', 0);
		# Read Disposal commands stored at RAM.		=> Step 3 in SRTP.
		S_w2rep("Step 18: Reading Disposal commands stored in RAM after ECU reset", 'blue');
		ACEA_EvaluateDecryptedCommandsInRAM($DisposalcommandsInRAM_3_ref, 'ZERO');		
	}

return 1;
}


#### TC FINALIZATION #####
sub TC_finalization {

	if($TP_stopFlag ne 'STOPPED'){
		GDCOM_stop_CyclicTesterPresent($TP_handle);	# Stop only when TP is not stopped.
	}

	#Initializating EEPROM to make fault free setup.
	PD_InitEEPROM ('$LIFT_PRJCFG_path/../reports/Temp_EEPROM_Dump.hex');
	S_wait_ms(2000);
	GEN_Power_on_Reset();

return 1;
}


1;

__END__