#### TEST CASE MODULE
package TC_DIS_ECUStatus_DifferentModes;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DISP_Disposal
#TS version in DOORS: 3.104
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; 
use GENERIC_DCOM ;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_labcar;
##################################

our $PURPOSE = "Verification of Enabling saftey path when PSCS is in different modes(Init Modes,Idle mode etc)";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_ECUStatus_DifferentModes

=head1 PURPOSE

Enablling saftey path when PSCS is in different modes

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation


I<B<Stimulation and Measurement>>

1. Set <Electronic_Firing_Mode>  to <Value>

2. Reset ECU

3. Create <Condition>

4.  Enable saftey path by PD <Request>

5. Read ECU status by PD <Req_ReadECUStatus>


I<B<Evaluation>>

1. 

2.  ECU should be in Electronic Firing Mode

3. 

4. <Response>

 is obtained 

5. Expected <Resp_ReadECUStatus> with ECU status as <Status> at 5th byte of response.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => Purpose of test case to be define
	SCALAR 'Electronic_Firing_Mode' => Electronic firing mode to be set
	SCALAR 'Value' => Value to be set
	SCALAR 'Condition' => Condition to be set
	SCALAR 'Request' => Request to be set
	SCALAR 'Req_ReadECUStatus' => Request of Read ECU Status to be set
	SCALAR 'Resp_ReadECUStatus' => Respones of Read ECU status to be set


=head2 PARAMETER EXAMPLES

	purpose  = 'it is not possible to Enable saftey path when PSCS is in different modes.'
	
	Electronic_Firing_Mode = 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8' 
	Value = '40'
	Condition='<Test Heading>'
	Request = 'Enable_Safety_Path'
	Req_ReadECUStatus = 'REQ_ECU_Status'
	Resp_ReadECUStatus ='PR_ECU_Status'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Electronic_Firing_Mode;
my $tcpar_Value;
my $tcpar_Condition;
my $tcpar_Request;
my $tcpar_Req_ReadECUStatus;
my $tcpar_Status;

################ global parameter declaration ###################

#add any global variables here

my $EnableSafetyPathID = '0x18';
my $EnableSafetyPath_Response_Title = '0x58';
my $Detected_SafetyPath_Response;
my $Detected_PD_Response;
my $NRC_ConditionNotCorrect = '0x22';
my $NegativeResponseIdentification = '0x7F';
my $Modified_Request;
my @request_bytes;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_Electronic_Firing_Mode =  S_read_mandatory_testcase_parameter( 'Electronic_Firing_Mode' );
	$tcpar_Value =  S_read_mandatory_testcase_parameter( 'Value' );
	$tcpar_Condition =  S_read_mandatory_testcase_parameter( 'Condition' );
	$tcpar_Request =  S_read_mandatory_testcase_parameter( 'Request' );
	$tcpar_Req_ReadECUStatus =  S_read_mandatory_testcase_parameter( 'Req_ReadECUStatus' );
	$tcpar_Status =  S_read_mandatory_testcase_parameter( 'Status' );

	return 1;
}

sub TC_initialization {

	S_w2rep("Standard_Preparation");	
	GEN_StandardPrepNoFault();		

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Set '$tcpar_Electronic_Firing_Mode'  to '$tcpar_Value'", 'AUTO_NBR');
	GEN_setECUMode ("PlantMode7_ElectronicFiringMode");	

	S_teststep("Reset ECU", 'AUTO_NBR', 'reset_ecu');			#measurement 1
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');
	
	
	S_teststep("Create '$tcpar_Condition'", 'AUTO_NBR');
	if($tcpar_Condition eq "INIT")
	{
		LC_ECU_Off();
	    S_wait_ms('TIMER_ECU_OFF');
	    LC_ECU_On();
		S_wait_ms(500);
		PD_ECUlogin();
	    S_wait_ms(100);
		
		$Modified_Request=GDCOM_getRequestLabelValue("REQ_$tcpar_Request");	
		@request_bytes = split(/ /, $Modified_Request);	
		S_teststep("Enable saftey path by PD '$tcpar_Request'", 'AUTO_NBR', 'enable_saftey_path');			#measurement 2
		$Detected_SafetyPath_Response = GEN_hexaref2byteString(PD_send_request_wait_response(\@request_bytes));		
		S_wait_ms(100);
		$Modified_Request=GDCOM_getRequestLabelValue("$tcpar_Req_ReadECUStatus");	
		@request_bytes = split(/ /, $Modified_Request); 	
		S_teststep("Read ECU status by PD '$tcpar_Req_ReadECUStatus'", 'AUTO_NBR', 'read_ecu_status');			#measurement 3
		$Detected_PD_Response = GEN_hexaref2byteString(PD_send_request_wait_response(\@request_bytes));
	
	}
	elsif($tcpar_Condition eq "IDLE")
	{
		ACEA_SetECUMode ("Idle");
		S_wait_ms('TIMER_ECU_READY');
		PD_ECUlogin();
	    S_wait_ms(100);
		
		$Modified_Request=GDCOM_getRequestLabelValue("REQ_$tcpar_Request");	
		@request_bytes = split(/ /, $Modified_Request);	
		S_teststep("Enable saftey path by PD '$tcpar_Request'", 'AUTO_NBR', 'enable_saftey_path');			#measurement 2
		$Detected_SafetyPath_Response = GEN_hexaref2byteString(PD_send_request_wait_response(\@request_bytes));
		S_wait_ms(1000);
		$Modified_Request=GDCOM_getRequestLabelValue("$tcpar_Req_ReadECUStatus");	
		@request_bytes = split(/ /, $Modified_Request); 	
		S_teststep("Read ECU status by PD '$tcpar_Req_ReadECUStatus'", 'AUTO_NBR', 'read_ecu_status');			#measurement 3
		$Detected_PD_Response = GEN_hexaref2byteString(PD_send_request_wait_response(\@request_bytes));
	
	}
	elsif($tcpar_Condition eq "Normal")
	{
		PD_ECUlogin();
		S_wait_ms('TIMER_ECU_READY');
		
		$Modified_Request=GDCOM_getRequestLabelValue("REQ_$tcpar_Request");	
		@request_bytes = split(/ /, $Modified_Request);	
		S_teststep("Enable saftey path by PD '$tcpar_Request'", 'AUTO_NBR', 'enable_saftey_path');			#measurement 2
		$Detected_SafetyPath_Response = GEN_hexaref2byteString(PD_send_request_wait_response(\@request_bytes));
		
		S_wait_ms('TIMER_ECU_READY');

		$Modified_Request=GDCOM_getRequestLabelValue("$tcpar_Req_ReadECUStatus");	
		@request_bytes = split(/ /, $Modified_Request); 	
		S_teststep("Read ECU status by PD '$tcpar_Req_ReadECUStatus'", 'AUTO_NBR', 'read_ecu_status');			#measurement 3
		$Detected_PD_Response = GEN_hexaref2byteString(PD_send_request_wait_response(\@request_bytes));	
	
	}	
	

	return 1;
}

sub TC_evaluation {

	S_teststep_detected("Evaluation done in Stimulation and Measurement Refer the traces or html report\n ", 'reset_ecu'); #evaluation 1
	S_teststep_expected("Evaluation done in Stimulation and Measurement Refer the traces or html report\n ", 'reset_ecu');
	

	if($tcpar_Condition eq "INIT")
	{	
		S_teststep_expected("Expected Enable safety path Response is Positive Response\n ",'enable_saftey_path');  #evaluation 2
		S_teststep_detected("Detected Enable safety path Response is $Detected_SafetyPath_Response \n",'enable_saftey_path');
		my @Obtained_Response = split( / /, "$Detected_SafetyPath_Response" );
		if (("0x".$Obtained_Response[0] eq $NegativeResponseIdentification ) && ("0x".$Obtained_Response[1] eq $EnableSafetyPathID)&& ("0x".$Obtained_Response[2] eq $NRC_ConditionNotCorrect))
		{
			S_set_verdict('VERDICT_PASS');
		}
		else
		{
			S_set_verdict('VERDICT_FAIL'); 
		}	
	}
	if(($tcpar_Condition eq "IDLE") ||($tcpar_Condition eq "Normal"))
	{	
		S_teststep_expected("Expected Enable safety path Response is Positive Response\n ",'enable_saftey_path');  #evaluation 2
		S_teststep_detected("Detected Enable safety path Response is $Detected_SafetyPath_Response \n",'enable_saftey_path');
		my @Obtained_Response = split( / /, "$Detected_SafetyPath_Response" );
		if (("0x".$Obtained_Response[0] eq $EnableSafetyPath_Response_Title ))
		{
			S_set_verdict('VERDICT_PASS');
		}
		else
		{
			S_set_verdict('VERDICT_FAIL'); 
		}	
	}
	
	my @Obtained_Response = split( / /, "$Detected_PD_Response" );
	S_teststep_expected("Expected ECU status as '$tcpar_Status' at 5th byte of response.\n", 'read_ecu_status');			#evaluation 3
	S_teststep_detected("Detected ECU Status is $Obtained_Response[4]\n", 'read_ecu_status');
	if ("0x".$Obtained_Response[4] eq $tcpar_Status ) 
	{
		S_set_verdict('VERDICT_PASS');
	}
	else
	{
		S_set_verdict('VERDICT_FAIL'); 
	}

	return 1;
}

sub TC_finalization {

	if($tcpar_Condition eq "IDLE")
	{
		ACEA_ResetECUMode ("Idle");
		S_wait_ms('TIMER_ECU_OFF');
	}	
	GEN_setECUMode ("RemovePlantModes");
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}


1;
