#### TEST CASE MODULE
package TC_DIS_UnknownVehicleSpeed;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_Disp_Disposal
#TS version in DOORS: 3.104
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
use GENERIC_DCOM;
use LIFT_can_access;
use LIFT_labcar;

##################################

our $PURPOSE = "check disposal session is started if conditions are unknown to the system";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DIS_UnknownVehicleSpeed

=head1 PURPOSE

check disposal session is started if conditions are unknown to the system

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

1. Standard_Preparation
2. Send Tester Present continously

I<B<Stimulation and Measurement>>

1. Stop Vehicle speed CAN message

2. Enter into Session


I<B<Evaluation>>

1. Vehicle speed CAN message stoppped

2. Positive response obtained


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => Purpose of the test case
	SCALAR 'Session' => Enter session mentioned



=head2 PARAMETER EXAMPLES

	purpose='check disposal session is started if conditions are unknown to the system.'
	Session = 'DisposalSession'


=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Session;

################ global parameter declaration ###################
my $TP_handle;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose   = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_Session   = S_read_mandatory_testcase_parameter('Session');

	return 1;
}

sub TC_initialization {

	S_w2rep("Start of Precondition");
	
	S_w2rep("Standard Preparation");
	GEN_StandardPrepNoFault();
	
	S_w2rep("Set addressing mode");
	GDCOM_set_addressing_mode("disposal");
	
	S_w2rep("Send Tester Present Cyclically");	
	$TP_handle = ACEA_Send_TesterPresent_Cyclically();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Stop Vehicle speed CAN message",'AUTO_NBR','STEP_1');	
	COM_stopMessages("Veh_Speed_dashboard");
	
	S_teststep("Enter into '$tcpar_Session'",'AUTO_NBR','STEP_2');
	GDCOM_StartSession($tcpar_Session);

	return 1;
}

sub TC_evaluation {

	S_teststep_expected("No Evaluation\n",'STEP_1');
	S_teststep_detected("No Evaluation\n",'STEP_1');
	
	S_teststep_expected("Evaluation for Request and Response Refer the html report or traces \n",'STEP_2');
	S_teststep_detected("Evaluation for Request and Response Refer the html report or traces \n",'STEP_2');

	return 1;
}

sub TC_finalization {

	ACEA_Stop_TesterPresent($TP_handle);
	S_wait_ms(2000);
	COM_startMessages("Veh_Speed_dashboard");
	GEN_Power_on_Reset();
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	return 1;
}

1;
