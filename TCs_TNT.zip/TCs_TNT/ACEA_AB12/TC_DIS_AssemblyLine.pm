#### TEST CASE MODULE
package TC_DIS_AssemblyLine;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DISP_Disposal
#TS version in DOORS: 3.104
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; 
use GENERIC_DCOM ;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_labcar;

##################################

our $PURPOSE = "To test Assembly Line Deployment during Invalid key";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_AssemblyLine

=head1 PURPOSE

To test Assembly Line Deployment during Invalid key

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation


I<B<Stimulation and Measurement>>

1. Monitor all the SPI of all the ASIC's

2. ACL is <Signal> and <Line>

3. Set Electronic Firing Mode to <Status>

4. Set Decryptionkey to <Key>

5. Request to enable the safety path <PD_Enable_SaftyPath>

6. Read safety path status <PD_Read_SafetyPath_Status>

7. Fire Squibs <PD_Fire_Squib>

8. Read Fault memory.


I<B<Evaluation>>

1.

2.

3.

4.

5. Expected <Resp_Enable_SaftyPath>

6. Expected <Resp_SafetyPath_Status>

7. Expected <Resp_Fire_Squib> with the responce data bytes as<Resp_Fire_Squib_Bytes> with firing counters should be non zero value in the responce data.

Firing request <Firing_Req_SPIData> to all the ASIC's must be observed with minimum delay of  <Delay_Time>

8. Fault memory empty


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => Purpose of the test case
	SCALAR 'PD_Enable_SaftyPath' => Request Enable_SaftyPath to be set
	SCALAR 'Resp_Enable_SaftyPath' => Response of Enable safety path to be set
	SCALAR 'Status' => Satus to be set
	SCALAR 'Key' => Key to be set
	SCALAR 'Signal' => Signal to be set
	SCALAR 'Line' =>  Line to be set
	SCALAR 'PD_Read_SafetyPath_Status' => Request of Safety path status to be set
	SCALAR 'Resp_SafetyPath_Status' => Response of Safet path to be set
	SCALAR 'PD_Fire_Squib' => Request of Fire squib to be set
	SCALAR 'Resp_Fire_Squib' => Response of Fire squib to be set
	SCALAR 'Resp_Fire_Squib_Bytes' => Response of Fire squib bytes to be set
	SCALAR 'Delay_Time' => Delay time to be set


=head2 PARAMETER EXAMPLES

	Status =  'Enabled'
	Key =  'Invalid'
	Signal =  'Supported'
	Line =  'Connected'
	PD_Read_SafetyPath_Status = 'None'
	Resp_SafetyPath_Status = 'None'
	PD_Fire_Squib = 'None'
	Resp_Fire_Squib = 'None'
	Resp_Fire_Squib_Bytes = 'None'
	Firing_Req_SPIData = 'None'
	Delay_Time = 'None'
	purpose  = 'To test Assembly Line Deployment during Invalid key'	
	PD_Enable_SaftyPath = 'REQ_Enable_Safety_Path'
	Resp_Enable_SaftyPath = 'NR_conditionsNotCorrect'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Status;
my $tcpar_Key;
my $tcpar_Signal;
my $tcpar_Line;
my $tcpar_PD_Read_SafetyPath_Status;
my $tcpar_PD_Fire_Squib;
my @tcpar_Resp_Fire_Squib_Bytes = 0;
my $tcpar_purpose;
my $tcpar_PD_Enable_SaftyPath;
my $tcpar_Resp_Enable_SaftyPath;

################ global parameter declaration ###################
#add any global variables here
my $PR_ECUStatus = '0x49';
my $FireDeviceID = '0x19';
my $EnableSafetyPath_BlockLength = '0x04';
my $EnableSafetyPathID = '0x18';
my $EnableSafetyPath_High = '0xAB';
my $EnableSafetyPath_Invalid_Low = '0x14';
my $EnableSafetyPath_InvalidChecksum = '0xDB';
my $EnableSafetyPath_Response_Title = '0x58';
my $Detected_SafetyPath_Response;
my $Detected_ECUStatus_Response;
my $Detected_FireDevice_Response;
my $Faultmemorystate;
my $NRC_ConditionNotCorrect = '0x22';
my $NegativeResponseIdentification = '0x7F';
my $verdict;
my $Modified_Request;
my @request_bytes;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_Status =  S_read_mandatory_testcase_parameter( 'Status' );
	$tcpar_Key =  S_read_mandatory_testcase_parameter( 'Key' );
	$tcpar_Signal =  S_read_mandatory_testcase_parameter( 'Signal' );
	$tcpar_Line =  S_read_mandatory_testcase_parameter( 'Line' );
	$tcpar_PD_Read_SafetyPath_Status =  S_read_mandatory_testcase_parameter( 'PD_Read_SafetyPath_Status' );
	$tcpar_PD_Fire_Squib =  S_read_mandatory_testcase_parameter( 'PD_Fire_Squib' );
	@tcpar_Resp_Fire_Squib_Bytes =  S_read_mandatory_testcase_parameter( 'Resp_Fire_Squib_Bytes' );
	$tcpar_PD_Enable_SaftyPath =  S_read_mandatory_testcase_parameter( 'PD_Enable_SaftyPath' );
	$tcpar_Resp_Enable_SaftyPath =  S_read_mandatory_testcase_parameter( 'Resp_Enable_SaftyPath' );
	return 1;
}

sub TC_initialization {

	S_w2rep("Standard_Preparation");	
	GEN_StandardPrepNoFault();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("ACL is '$tcpar_Signal' and '$tcpar_Line'", 'AUTO_NBR');
	ACEA_SetACLConnection('Connect');

	S_teststep("Set Electronic Firing Mode to '$tcpar_Status'", 'AUTO_NBR');
	if($tcpar_Status eq 'Enabled')
	{
		GEN_setECUMode ("PlantMode7_ElectronicFiringMode");
		S_wait_ms('TIMER_ECU_READY');
		PD_ECUlogin();
		S_wait_ms(2000);	
	}

	S_teststep("Set Decryptionkey to '$tcpar_Key'", 'AUTO_NBR');
	if($tcpar_Key eq 'Invalid')
	{
		$Detected_SafetyPath_Response = GEN_hexaref2byteString(PD_send_request_wait_response([$EnableSafetyPath_BlockLength,$EnableSafetyPathID,$EnableSafetyPath_High,$EnableSafetyPath_Invalid_Low,$EnableSafetyPath_InvalidChecksum]));
		S_wait_ms('TIMER_ECU_READY');
	}
	elsif($tcpar_Key eq 'Valid')
	{
		$Modified_Request=GDCOM_getRequestLabelValue("$tcpar_PD_Enable_SaftyPath");	
	    @request_bytes = split(/ /, $Modified_Request);
		$Detected_SafetyPath_Response = GEN_hexaref2byteString(PD_send_request_wait_response(\@request_bytes));
		S_wait_ms('TIMER_ECU_READY');
	}

	$Modified_Request=GDCOM_getRequestLabelValue("$tcpar_PD_Enable_SaftyPath");	
	@request_bytes = split(/ /, $Modified_Request);
	S_teststep("Request to enable the safety path '$tcpar_PD_Enable_SaftyPath'", 'AUTO_NBR', 'request_to_enable');			#measurement 1
	$Detected_SafetyPath_Response = GEN_hexaref2byteString(PD_send_request_wait_response(\@request_bytes));

	$Modified_Request=GDCOM_getRequestLabelValue("$tcpar_PD_Read_SafetyPath_Status");	
	@request_bytes = split(/ /, $Modified_Request);
	S_teststep("Read safety path status '$tcpar_PD_Read_SafetyPath_Status'", 'AUTO_NBR', 'read_safety_path');			#measurement 2
	$Detected_ECUStatus_Response = GEN_hexaref2byteString(PD_send_request_wait_response(\@request_bytes));
		
	$Modified_Request=GDCOM_getRequestLabelValue("$tcpar_PD_Fire_Squib");	
	@request_bytes = split(/ /, $Modified_Request);
	S_teststep("Fire Squibs '$tcpar_PD_Fire_Squib'", 'AUTO_NBR', 'fire_squibs_pd');			#measurement 3
	$Detected_FireDevice_Response = GEN_hexaref2byteString(PD_send_request_wait_response(\@request_bytes));	

	S_teststep("Read Fault memory.", 'AUTO_NBR', 'read_fault_memory');			#measurement 4
	$Faultmemorystate=FM_PD_readFaultMemory();

	return 1;
}

sub TC_evaluation {

	if(($tcpar_Status eq 'Enabled') && ($tcpar_Key eq 'Invalid'))
	{
		my @Obtained_Response = split( / /, "$Detected_SafetyPath_Response" );
		S_teststep_expected("Expected Enable safety path response is '$tcpar_Resp_Enable_SaftyPath'", 'request_to_enable');			#evaluation 1
		S_teststep_detected("Detected Safety path Response is $Detected_SafetyPath_Response", 'request_to_enable');
		
		if (("0x".$Obtained_Response[0] eq $NegativeResponseIdentification ) && ("0x".$Obtained_Response[1] eq $EnableSafetyPathID)&& ("0x".$Obtained_Response[2] eq $NRC_ConditionNotCorrect))
		{
			S_set_verdict('VERDICT_PASS');
		}
		else
		{
			S_set_verdict('VERDICT_FAIL'); 
		}		
		
		my @Obtained_Response = split( / /, "$Detected_FireDevice_Response" );
		S_teststep_expected("Expected: Negative Respone of Fire Device is 22(NRC)", 'fire_squibs_pd');			#evaluation 3
		S_teststep_detected("Detected Safety path Response is $Detected_SafetyPath_Response", 'fire_squibs_pd');
		
		if (("0x".$Obtained_Response[0] eq $NegativeResponseIdentification ) && ("0x".$Obtained_Response[1] eq $FireDeviceID)&& ("0x".$Obtained_Response[2] eq $NRC_ConditionNotCorrect))
		{
			S_set_verdict('VERDICT_PASS');
		}
		else
		{
			S_set_verdict('VERDICT_FAIL'); 
		}		
		
	}
	
	if(($tcpar_Status eq 'NotEnabled') && ($tcpar_Key eq 'Valid'))
	{
		my @Obtained_Response = split( / /, "$Detected_SafetyPath_Response" );
		S_teststep_expected("Expected Enable safety path response is '$tcpar_Resp_Enable_SaftyPath'", 'request_to_enable');			#evaluation 1
		S_teststep_detected("Detected Safety path Response is $Detected_SafetyPath_Response", 'request_to_enable');
		
		if (("0x".$Obtained_Response[0] eq $NegativeResponseIdentification)&& ("0x".$Obtained_Response[1] eq $EnableSafetyPathID)&& ("0x".$Obtained_Response[2] eq $NRC_ConditionNotCorrect))
		{
			S_set_verdict('VERDICT_PASS');
		}
		else
		{
			S_set_verdict('VERDICT_FAIL'); 
		}
		
		my @Obtained_Response = split( / /, "$Detected_FireDevice_Response" );
		S_teststep_expected("Expected: Negative Respone 22(NRC)", 'fire_squibs_pd');			#evaluation 3
		S_teststep_detected("Detected Response is $Detected_SafetyPath_Response", 'fire_squibs_pd');
		
		if (("0x".$Obtained_Response[0] eq $NegativeResponseIdentification ) && ("0x".$Obtained_Response[1] eq $FireDeviceID)&& ("0x".$Obtained_Response[2] eq $NRC_ConditionNotCorrect))
		{
			S_set_verdict('VERDICT_PASS');
		}
		else
		{
			S_set_verdict('VERDICT_FAIL'); 
		}
	}
	
	
	my @Obtained_Response = split( / /, "$Detected_ECUStatus_Response" ); #evaluation 2
	S_teststep_expected("Expected ECU status :Positive Response should receive\n", 'read_safety_path');			
	S_teststep_detected("Detected ECU status Response is $Detected_ECUStatus_Response \n", 'read_safety_path');
	
	if ("0x".$Obtained_Response[0] eq $PR_ECUStatus ) 
	{
		S_set_verdict('VERDICT_PASS');
	}
	else
	{
		S_set_verdict('VERDICT_FAIL'); 
	}	
	
	if(($tcpar_Status eq 'Enabled') && ($tcpar_Key eq 'Valid')&& ($tcpar_Signal eq 'Supported')&& ($tcpar_Line eq 'Connected'))
	{
		S_teststep_detected("Detected Fire Device Response bytes are $Detected_FireDevice_Response.", 'fire_squibs_pd');		
		S_teststep_expected("Expected Fire Device Response bytes are @tcpar_Resp_Fire_Squib_Bytes.", 'fire_squibs_pd');
		my @Obtained_Response = split( / /, "$Detected_FireDevice_Response" );
		if (("0x".$Obtained_Response[2] eq @tcpar_Resp_Fire_Squib_Bytes[0] ) && ("0x".$Obtained_Response[3] eq @tcpar_Resp_Fire_Squib_Bytes[1])&& ("0x".$Obtained_Response[4] eq @tcpar_Resp_Fire_Squib_Bytes[2])&& ("0x".$Obtained_Response[5] eq @tcpar_Resp_Fire_Squib_Bytes[3])&& ("0x".$Obtained_Response[6] eq @tcpar_Resp_Fire_Squib_Bytes[4])&& ("0x".$Obtained_Response[7] eq @tcpar_Resp_Fire_Squib_Bytes[5])&& ("0x".$Obtained_Response[8] eq @tcpar_Resp_Fire_Squib_Bytes[6])&& ("0x".$Obtained_Response[9] eq @tcpar_Resp_Fire_Squib_Bytes[7])&& ("0x".$Obtained_Response[10] eq @tcpar_Resp_Fire_Squib_Bytes[8]))
		{
			S_set_verdict('VERDICT_PASS');
		}
		else
		{
			S_set_verdict('VERDICT_FAIL'); 
		}

		my @Obtained_Response = split( / /, "$Detected_SafetyPath_Response" ); #evaluation 2
		S_teststep_expected("Expected ECU status :Positive Response should receive\n", 'read_safety_path');			
		S_teststep_detected("Detected ECU status Response is $Detected_SafetyPath_Response \n", 'read_safety_path');
		
		if ("0x".$Obtained_Response[0] eq $EnableSafetyPath_Response_Title) 
		{
			S_set_verdict('VERDICT_PASS');
		}
		else
		{
			S_set_verdict('VERDICT_FAIL'); 
		}
	
	}

	if(($tcpar_Status eq 'Enabled') && ($tcpar_Key eq 'Valid')&& ($tcpar_Signal eq 'Supported')&& ($tcpar_Line eq 'Faulty'))
	{
		S_teststep_detected("Detected Fire device Response bytes are $Detected_FireDevice_Response.", 'fire_squibs_pd');		
		S_teststep_expected("Expected Fire Device Response bytes are @tcpar_Resp_Fire_Squib_Bytes.", 'fire_squibs_pd');
		my @Obtained_Response = split( / /, "$Detected_FireDevice_Response" );
		if (("0x".$Obtained_Response[2] eq @tcpar_Resp_Fire_Squib_Bytes[0] ) && ("0x".$Obtained_Response[3] eq @tcpar_Resp_Fire_Squib_Bytes[1])&& ("0x".$Obtained_Response[4] eq @tcpar_Resp_Fire_Squib_Bytes[2])&& ("0x".$Obtained_Response[5] eq @tcpar_Resp_Fire_Squib_Bytes[3])&& ("0x".$Obtained_Response[6] eq @tcpar_Resp_Fire_Squib_Bytes[4])&& ("0x".$Obtained_Response[7] eq @tcpar_Resp_Fire_Squib_Bytes[5])&& ("0x".$Obtained_Response[8] eq @tcpar_Resp_Fire_Squib_Bytes[6])&& ("0x".$Obtained_Response[9] eq @tcpar_Resp_Fire_Squib_Bytes[7])&& ("0x".$Obtained_Response[10] eq @tcpar_Resp_Fire_Squib_Bytes[8]))
		{
			S_set_verdict('VERDICT_PASS');
		}
		else
		{
			S_set_verdict('VERDICT_FAIL'); 
		}

		my @Obtained_Response = split( / /, "$Detected_SafetyPath_Response" ); #evaluation 2
		S_teststep_expected("Expected ECU status :Positive Response should receive\n", 'read_safety_path');			
		S_teststep_detected("Detected ECU status Response is $Detected_SafetyPath_Response \n", 'read_safety_path');
		
		if ("0x".$Obtained_Response[0] eq $EnableSafetyPath_Response_Title) 
		{
			S_set_verdict('VERDICT_PASS');
		}
		else
		{
			S_set_verdict('VERDICT_FAIL'); 
		}
		
	}
	
	if(($tcpar_Status eq 'Enabled') && ($tcpar_Key eq 'Valid')&& ($tcpar_Signal eq 'NotSupported')&& ($tcpar_Line eq 'None'))
	{
		S_teststep_detected("Detected Fire Device Response bytes are $Detected_FireDevice_Response.", 'fire_squibs_pd');		
		S_teststep_expected("Expected Fire Device Response bytes are @tcpar_Resp_Fire_Squib_Bytes.", 'fire_squibs_pd');
		my @Obtained_Response = split( / /, "$Detected_FireDevice_Response" );
		if (("0x".$Obtained_Response[2] eq @tcpar_Resp_Fire_Squib_Bytes[0] ) && ("0x".$Obtained_Response[3] eq @tcpar_Resp_Fire_Squib_Bytes[1])&& ("0x".$Obtained_Response[4] eq @tcpar_Resp_Fire_Squib_Bytes[2])&& ("0x".$Obtained_Response[5] eq @tcpar_Resp_Fire_Squib_Bytes[3])&& ("0x".$Obtained_Response[6] eq @tcpar_Resp_Fire_Squib_Bytes[4])&& ("0x".$Obtained_Response[7] eq @tcpar_Resp_Fire_Squib_Bytes[5])&& ("0x".$Obtained_Response[8] eq @tcpar_Resp_Fire_Squib_Bytes[6])&& ("0x".$Obtained_Response[9] eq @tcpar_Resp_Fire_Squib_Bytes[7])&& ("0x".$Obtained_Response[10] eq @tcpar_Resp_Fire_Squib_Bytes[8]))
		{
			S_set_verdict('VERDICT_PASS');
		}
		else
		{
			S_set_verdict('VERDICT_FAIL'); 
		}

		my @Obtained_Response = split( / /, "$Detected_SafetyPath_Response" ); #evaluation 2
		S_teststep_expected("Expected ECU status :Positive Response should receive\n", 'read_safety_path');			
		S_teststep_detected("Detected ECU status Response is $Detected_SafetyPath_Response \n", 'read_safety_path');
		
		if ("0x".$Obtained_Response[0] eq $EnableSafetyPath_Response_Title) 
		{
			S_set_verdict('VERDICT_PASS');
		}
		else
		{
			S_set_verdict('VERDICT_FAIL'); 
		}
	}
	
	
	$verdict = PD_evaluate_faults($Faultmemorystate, [] );	 #evaluation 4
	S_teststep_expected(" Fault memory data after firing should be empty \n ", 'read_fault_memory');
	if($verdict eq 'VERDICT_PASS' )
	{
		S_teststep_detected( "Fault memory data after firing is:" . $Faultmemorystate . "\n",'read_fault_memory');
	}

	if($verdict eq 'VERDICT_FAIL' )
	{
		
		S_teststep_detected( "Fault Evaluation done at Stimulation and measurement(Refer the html report) \n",'read_fault_memory');
	}

	return 1;
}

sub TC_finalization {
	if($tcpar_Status eq 'Enabled')
	{
		GEN_setECUMode ("RemovePlantModes");
	}
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	return 1;
	
}


1;
