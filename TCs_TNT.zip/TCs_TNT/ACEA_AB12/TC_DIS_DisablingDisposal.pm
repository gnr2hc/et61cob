#### TEST CASE MODULE
package TC_DIS_DisablingDisposal;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DISP_Disposal
#TS version in DOORS: 3.104
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use INCLUDES_Project; 
use GENERIC_DCOM ;
use LIFT_labcar;
use LIFT_PD;
##################################

our $PURPOSE = "To verify disposal can be disabled using static behaviour bit";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DIS_DisablingDisposal

=head1 PURPOSE

To verify disposal can be disabled using static behaviour bit

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

1. Standard_Preparation

2. Send tester present continously


I<B<Stimulation and Measurement>>

1. Disable Disposal using static behaviour bit <Varaibale>

2. Reset ECU

3. Enter into <Session>

4. Enable Disposal using static behaviour bit <Varaibale>

5. Reset ECU

6. Enter into <Session>


I<B<Evaluation>>

3. No response obtained

6. Positive response obtained.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => Purpose of test case to be define
	SCALAR 'Variable' => Variable to be set
	SCALAR 'Session' => Session to be set


=head2 PARAMETER EXAMPLES

	purpose  = 'To verify disposal can be disabled using static behaviour bit'
	Variable ='rb_sycg_StaticBehaviorBits_dfst.rb_sycg_StaticBits_ab8(0)'
	Session ='Disposal Session'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Variable;
my $tcpar_Session;

################ global parameter declaration ###################
#add any global variables here
my $DisposalNoResponse = '';
my $TP_handle;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_Variable =  S_read_mandatory_testcase_parameter( 'Variable' );
	$tcpar_Session =  S_read_mandatory_testcase_parameter( 'Session' );

	return 1;
}

sub TC_initialization {

	S_w2rep("Standard_Preparation");
	GEN_StandardPrepNoFault();
	
	S_w2rep("Set Addressing Mode");
	GDCOM_set_addressing_mode("disposal");
	
	S_w2rep("Send tester present continously");	
	$TP_handle = ACEA_Send_TesterPresent_Cyclically();	

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Disable Disposal using static behaviour bit '$tcpar_Variable'", 'AUTO_NBR');
	PD_WriteMemoryByName("rb_sycg_StaticBehaviorBits_dfst.rb_sycg_StaticBits_ab8(0)",[0x00]);	

	S_teststep("Reset ECU", 'AUTO_NBR');
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep("Enter into '$tcpar_Session'", 'AUTO_NBR', 'enter_into_session_A');			#measurement 1	
	GDCOM_request("REQ_StartSession_DisposalSession",$DisposalNoResponse,'quiet');
	
	S_teststep("Enable Disposal using static behaviour bit '$tcpar_Variable'", 'AUTO_NBR');
	PD_WriteMemoryByName("rb_sycg_StaticBehaviorBits_dfst.rb_sycg_StaticBits_ab8(0)",[0x01]);
	
	S_teststep("Reset ECU", 'AUTO_NBR');
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');
	
	S_teststep("Enter into '$tcpar_Session'", 'AUTO_NBR', 'enter_into_session_B');			#measurement 2
	GDCOM_StartSession('DisposalSession');
	
	return 1;
}

sub TC_evaluation {

	S_teststep_expected("No response obtained", 'enter_into_session_A');			#evaluation 1
	S_teststep_detected("Evaluation done in Stimulation and Measurement Refer the traces or html report\n", 'enter_into_session_A');

	S_teststep_expected("Positive response obtained.", 'enter_into_session_B');			#evaluation 2
	S_teststep_detected("Evaluation done in Stimulation and Measurement Refer the traces or html report\n", 'enter_into_session_B');

	return 1;
}

sub TC_finalization {

	ACEA_Stop_TesterPresent($TP_handle);
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}


1;
