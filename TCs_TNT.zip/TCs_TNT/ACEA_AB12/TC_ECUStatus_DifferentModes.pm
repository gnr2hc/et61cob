#### TEST CASE MODULE
package TC_ECUStatus_DifferentModes;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DISP_Disposal
#TS version in DOORS: 3.104
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; 
use GENERIC_DCOM ;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_labcar;
##################################

our $PURPOSE = "Verification of Enabling saftey path when PSCS is in different modes(Init Modes,Idle mode etc)";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_ECUStatus_DifferentModes

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation


I<B<Stimulation and Measurement>>

1. Set <Electronic_Firing_Mode>  to <Value>

2. Reset ECU

3. Create <Condition>

4.  Enable saftey path by PD <Request>

5. Read ECU status by PD <Req_ReadECUStatus>


I<B<Evaluation>>

1. 

2.  ECU should be in Electronic Firing Mode

3. 

4. <Response>

 is obtained 

5. Expected <Resp_ReadECUStatus> with ECU status as <Status> at 5th byte of response.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'Electronic_Firing_Mode' => 
	SCALAR 'Value' => 
	SCALAR 'Condition' => 
	SCALAR 'Request' => 
	SCALAR 'Req_ReadECUStatus' => 
	SCALAR 'Resp_ReadECUStatus' => 


=head2 PARAMETER EXAMPLES

	purpose  = 'it is not possible to Enable saftey path when PSCS is in different modes.'
	
	Electronic_Firing_Mode = 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8' 
	Value = '40'
	Condition='<Test Heading>'
	Request = 'Enable_Safety_Path'
	Req_ReadECUStatus = 'REQ_ECU_Status'
	Resp_ReadECUStatus ='PR_ECU_Status'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Electronic_Firing_Mode;
my $tcpar_Value;
my $tcpar_Condition;
my $tcpar_Request;
my $tcpar_Req_ReadECUStatus;
my $tcpar_Resp_ReadECUStatus;
my $tcpar_Status;

################ global parameter declaration ###################

#add any global variables here
my $ECUStatus_BlockLength = 0x02;
my $ECUStatusID = 0x09;
my $ECUStatus_Checksum = 0x0B;

my $EnableSafetyPath_BlockLength = 0x04;
my $EnableSafetyPathID = 0x18;
my $EnableSafetyPath_High = 0xAB;
my $EnableSafetyPath_Low = 0x12;;
my $EnableSafetyPath_Checksum = 0xD9;
my $EnableSafetyPath_Response_BlockLength = 0x02;
my $EnableSafetyPath_Response_Title = 0x58;
my $Detected_SafetyPath_Response;
my $Detected_PD_Response;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_Electronic_Firing_Mode =  S_read_mandatory_testcase_parameter( 'Electronic_Firing_Mode' );
	$tcpar_Value =  S_read_mandatory_testcase_parameter( 'Value' );
	$tcpar_Condition =  S_read_mandatory_testcase_parameter( 'Condition' );
	$tcpar_Request =  S_read_mandatory_testcase_parameter( 'Request' );
	$tcpar_Req_ReadECUStatus =  S_read_mandatory_testcase_parameter( 'Req_ReadECUStatus' );
	$tcpar_Status =  S_read_mandatory_testcase_parameter( 'Status' );


	return 1;
}

sub TC_initialization {

	S_w2rep("Standard_Preparation");	
	GEN_StandardPrepNoFault();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Set '$tcpar_Electronic_Firing_Mode'  to '$tcpar_Value'", 'AUTO_NBR');
	GEN_setECUMode ("PlantMode7_ElectronicFiringMode");

	S_teststep("Reset ECU", 'AUTO_NBR', 'reset_ecu');			#measurement 1
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep("Create '$tcpar_Condition'", 'AUTO_NBR');
	if($tcpar_Condition eq "INIT")
	{
		GEN_Power_on_Reset('NO_WAIT');
		S_wait_ms(200);
	
	}
	elsif($tcpar_Condition eq "IDLE")
	{
		ACEA_SetECUMode ("Idle");
	
	}
	

	S_teststep("Enable saftey path by PD '$tcpar_Request'", 'AUTO_NBR', 'enable_saftey_path');			#measurement 2
	$Detected_SafetyPath_Response = PD_send_request_wait_response([$EnableSafetyPath_BlockLength,$EnableSafetyPathID,$EnableSafetyPath_High,$EnableSafetyPath_Low,$EnableSafetyPath_Checksum]);

	S_teststep("Read ECU status by PD '$tcpar_Req_ReadECUStatus'", 'AUTO_NBR', 'read_ecu_status');			#measurement 3
	$Detected_PD_Response = PD_send_request_wait_response([$ECUStatus_BlockLength,$ECUStatusID,$ECUStatus_Checksum]);

	return 1;
}

sub TC_evaluation {

	S_teststep_detected("Evaluation done in Stimulation and Measurement Refer the traces or html report\n ", 'reset_ecu'); #evaluation 1
	S_teststep_expected("Evaluation done in Stimulation and Measurement Refer the traces or html report\n ", 'reset_ecu');
	

	S_teststep_expected("Expected Response is Positive Response\n ",'enable_saftey_path');  #evaluation 2
	S_teststep_detected("Detected Response is $Detected_SafetyPath_Response \n",'enable_saftey_path');
	my @Obtained_Response = split( / /, "$Detected_SafetyPath_Response" );
	if (($Obtained_Response[0] eq $EnableSafetyPath_Response_BlockLength ) && ($Obtained_Response[1] eq $EnableSafetyPath_Response_Title))
	{
		S_set_verdict('VERDICT_PASS');
	}
	else
	{
		S_set_verdict('VERDICT_FAIL'); 
	}
	
	
	my @Obtained_Response = split( / /, "$Detected_PD_Response" );
	S_teststep_expected("Expected ECU status as '$tcpar_Status' at 5th byte of response.\n", 'read_ecu_status');			#evaluation 3
	S_teststep_detected("Detected ECU Status is $Obtained_Response[4]\n", 'read_ecu_status');
	
	if ($Obtained_Response[4] eq $tcpar_Status ) 
	{
		S_set_verdict('VERDICT_PASS');
	}
	else
	{
		S_set_verdict('VERDICT_FAIL'); 
	}

	return 1;
}

sub TC_finalization {

	if($tcpar_Condition eq "IDLE")
	{
		ACEA_ResetECUMode ("Idle");
	}	
	GEN_setECUMode ("RemovePlantModes");
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}


1;
