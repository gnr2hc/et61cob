#### TEST CASE MODULE
package TC_DIS_ECUresetHandling_AB12;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DISP_Disposal
#TS version in DOORS: 3.93
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_labcar;
use LIFT_can_access;
use LIFT_NET_access;
use INCLUDES_Project;
use GENERIC_DCOM;

##################################

our $PURPOSE = "To test reset handling by ACEA under various different conditions";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DIS_ECUresetHandling_AB12

=head1 PURPOSE

To test reset handling by ACEA under various different conditions

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>
Step1. Standard Preparation
Step2. No ACL Connected
Step3. SendTesterPresentCyclically

I<B<Stimulation and Measurement>>
Step1. Initiate Saftey system diagnostic session
execute Step 2 - 7 if ResetStrategy = 'Stategy2' and SPLActivation = 'ActivateSPL'
Step2. Read Decryption Key in RAM before executing SPL
Step3. Read Decrypted Commands in RAM before executing SPL
Step4. Obtain security access
Step5. Execute SPL 
Step6. Read Decryption Key in RAM after executing SPL
Step7. Read Decrypted Commands in RAM and saftey path status after executing SPL
execute step 8 if <Test Condition> is diag session change
Step8. Change Diag session to Default session
execute Step 09-11 if <testCondition> is StopDiagCommunication and <DiagcommunicationStopMethod> is StopDiagandTesterPresent
Step09. Stop DiagCommunication & sending TesterPresent
Step10. ReadVIN
Step11. Measure TimeDifference between Last Diag service and ECU reset
execute Step 12-13 if <testCondition> is StopDiagCommunication and <DiagcommunicationStopMethod> is StopTesterPresent
Step12. Stop sending tester present
Step13.	Measure TimeDifference between Last Tester present and ECU reset
Step14. Check active session and safteypath status.
execute step 15 -16 if<ResetStrategy> is Strategy2 and <SPLActivation> is Activate SPL
Step15. Read Decryption key in RAM
Step16. Read Decrypted commands in RAM

I<B<Evaluation>>

Step1: Evaluate response for Enter into safety system diagnostic session
execute Step 2 - 7 if ResetStrategy = 'Stategy2' and SPLActivation = 'ActivateSPL'
Step2: Evaluate Obtained decryption key in RAM before executing SPL
Step3: Evaluate obtained Decrypted Commands in RAM before executing SPL
Step4: evaluate Security access
Step5: Evaluate response for Activating SPL
Step6: Evaluate Obtained decryption key in RAM after executing SPL
Step7: Evaluate obtained Decrypted Commands in RAM after executing SPL and SPL status
Step8: Evaluate Active session
execute step 8 if <Test Condition> is diag session change
Step8: Evaluate response for Enter into Default session
execute Step 09-11 if <testCondition> is StopDiagCommunication and <DiagcommunicationStopMethod> is StopDiagandTesterPresent
Step09: No Evaluation
Step10: Evaluate VIN obtained
Step11:Evaluate session expiry timeout duration
execute Step 12-13 if <testCondition> is StopDiagCommunication and <DiagcommunicationStopMethod> is StopTesterPresent
Step12: No evaluation
Step13:Evaluate session expiry timeout duration
Step14:Evaluate Active session and saftey path status
execute step 15 -16 if<ResetStrategy> is Strategy2 and <SPLActivation> is Activate SPL
Step15: Evaluate Decryption key in RAM
Step16: Evaluate Decrypted commands in RAM.

I<B<Finalisation>>
Bring back the system to normal state



=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => Purpose of the test
	SCALAR 'ACL_Connectivity' => ACL connectivity based on OEM configuration
	SCALAR 'ECUResetBehavior' => RESET or NO_RESET
	SCALAR 'ResetStrategy' => configured reset strategy
	SCALAR 'TestCondition' => Test condition
	SCALAR 'DiagCommunicationStopMethod' => Diag Communication Stop Method
	SCALAR 'SPLActivation' => Is SPL Activation required
	SCALAR 'Exp_DecryptionKeyInRAM' => expected Decryption Key In RAM after security access obtained.
	SCALAR 'SessionExpiryTimeDuration' => Session Expiry Time Duration

	
=head2 PARAMETER EXAMPLES

	ResetStrategy = 'Strategy1'
	TestCondition = 'DiagSessionChange' 
	DiagCommunicationStopMethod = 'StopDiagandTesterPresent' 
	SPLActivation = 'ActivateSPL' 
	ACL_Connectivity = 'Yes'
	Exp_DecryptionKeyInRAM = '0xAB12'
	SessionExpiryTimeDuration = 5000 #ms
	purpose  = 'To verify ECU reset  behavior when diag session is changed - for strategy 1'
	ECUResetBehavior = 'RESET'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_ResetStrategy;
my $tcpar_ACL_Connectivity;
my $tcpar_TestCondition;
my $tcpar_DiagCommunicationStopMethod;
my $tcpar_SPLActivation;
my $tcpar_Exp_DecryptionKeyInRAM;
my $tcpar_SessionExpiryTimeDuration;
my $tcpar_purpose;
my $tcpar_ECUResetBehavior;
my $tcpar_Exp1_DecryptionKeyInRAM;
my $tcpar_Exp1_ReadDecryptedCommandsInRAM;

################ global parameter declaration ###################
#add any global variables here
my (
	$TP_handle,        $decryption_Key_BeforeSPL,     $decryption_Commands_BeforeSPL, $decryption_Key_AfterSPL,   $decryption_Commands_AfterSPL,   $ActiveDiagSession_untilReset, $TimeStamp_ResetTrigger, $TimeStamp_afterReset, $ExpiryTime,
	$MeasuredTimeDiff, $ActiveDiagSession_afterReset, $SPL_Routineresult_AfterReset,  $decryption_Key_AfterReset, $decryption_Commands_AfterReset, $Active_Session,               $SPL_results,            $routineStatusRecord
);
my $RoutineControlOption = '01';
my @decryption_Commands_BeforeSPL_Array;
my $verdict;
###############################################################

sub TC_set_parameters {

	$tcpar_ResetStrategy                   = S_read_mandatory_testcase_parameter('ResetStrategy');
	$tcpar_ACL_Connectivity                = S_read_mandatory_testcase_parameter('ACL_Connectivity');
	$tcpar_TestCondition                   = S_read_mandatory_testcase_parameter('TestCondition');
	$tcpar_DiagCommunicationStopMethod     = S_read_mandatory_testcase_parameter('DiagCommunicationStopMethod');
	$tcpar_SPLActivation                   = S_read_mandatory_testcase_parameter('SPLActivation');
	$tcpar_Exp_DecryptionKeyInRAM          = S_read_mandatory_testcase_parameter('Exp_DecryptionKeyInRAM');
	$tcpar_SessionExpiryTimeDuration       = S_read_mandatory_testcase_parameter('SessionExpiryTimeDuration');
	$tcpar_purpose                         = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_ECUResetBehavior                = S_read_mandatory_testcase_parameter('ECUResetBehavior');
	$tcpar_Exp1_DecryptionKeyInRAM         = S_read_mandatory_testcase_parameter('Exp1_DecryptionKeyInRAM');
	$tcpar_Exp1_ReadDecryptedCommandsInRAM = S_read_mandatory_testcase_parameter('Exp1_ReadDecryptedCommandsInRAM');

	$routineStatusRecord = S_get_label( 'RoutineStatusRecord', ['DISPOSAL'] )
	  if S_check_label( 'RoutineStatusRecord', ['DISPOSAL'] );

	return 1;
}

sub TC_initialization {
	S_teststep( "NET_simulation_start\n", 'NO_AUTO_NBR' );
	NET_simulation_start();    # starts RBS &  switch - off logging fast

	S_teststep( "NET_trace_start\n", 'NO_AUTO_NBR' );
	NET_trace_start();         # switch - on logging the trace

	S_teststep( "GEN_StandardPrepNoFault\n", 'NO_AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_w2rep("No ACLConnected");
	my $status = ACEA_SetACLConnection('Disconnect');

	S_teststep( "GDCOM_set_addressing_mode( 'disposal' )\n", 'NO_AUTO_NBR' );
	GDCOM_set_addressing_mode("disposal");

	S_teststep( "ACEA_Send_TesterPresent_Cyclically\n", 'NO_AUTO_NBR' );
	$TP_handle = ACEA_Send_TesterPresent_Cyclically();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Initiate Safety system diagnostic session\n", 'AUTO_NBR', 'STEP_1' );
	S_wait_ms(10000);
	GDCOM_StartSession('DisposalSession');
	if (   ( $tcpar_ResetStrategy eq 'Stategy2' )
		&& ( $tcpar_SPLActivation eq 'ActivateSPL' ) )
	{
		S_teststep( "Read Decryption Key in RAM before executing SPL\n", 'AUTO_NBR', 'STEP_2' );
		$decryption_Key_BeforeSPL = ACEA_ReadDecryptionKeyInRAM();

		S_teststep( "Read Decrypted Commands in RAM before executing SPL\n", 'AUTO_NBR', 'STEP_3' );
		$decryption_Commands_BeforeSPL       = ACEA_ReadDecryptedCommandsInRAM();
		@decryption_Commands_BeforeSPL_Array = @$decryption_Commands_BeforeSPL;

		S_teststep( "Obtain security access\n", 'AUTO_NBR', 'STEP_4' );
		ACEA_Get_SecurityAccess();

		S_teststep( "Execute SPL\n", 'AUTO_NBR', 'STEP_5' );
		ACEA_ExecuteDisposalProgramLoader( $RoutineControlOption, $routineStatusRecord );

		S_teststep( "Read Decryption Key in RAM after executing SPL\n", 'AUTO_NBR', 'STEP_6' );
		$decryption_Key_AfterSPL = ACEA_ReadDecryptionKeyInRAM();

		S_teststep( "Read Decrypted Commands in RAM and saftey path status after executing SPL\n", 'AUTO_NBR', 'STEP_7' );
		$decryption_Commands_AfterSPL = ACEA_ReadDecryptedCommandsInRAM($tcpar_ACL_Connectivity);
		$SPL_results = ACEA_RequestRoutineResults_SPL( $RoutineControlOption, $routineStatusRecord );
	}
	elsif (( $tcpar_ResetStrategy ne 'Stategy1' )
		&& ( $tcpar_ResetStrategy ne 'Stategy2' ) )
	{
		GEN_printComment("Invalid Reset Strategy $tcpar_ResetStrategy");
	}
	if ( $tcpar_TestCondition eq 'DiagSesssionChange' ) {

		S_teststep( "Change Diag session to Default session\n", 'AUTO_NBR', 'STEP_8' );
		GDCOM_StartSession('DefaultSession');
		PD_ECUlogin();
	}
	elsif (( $tcpar_TestCondition eq 'StopDiagCommunication' )
		&& ( $tcpar_DiagCommunicationStopMethod eq 'TimeSinceLastDiag' ) )
	{
		S_teststep( "Stop TesterPresent\n", 'AUTO_NBR', 'STEP_9' );
		GDCOM_stop_CyclicTesterPresent($TP_handle);

		S_teststep( "Read any Diagnostic service\n", 'AUTO_NBR', 'STEP_10' );
		ACEA_Read_HWDeploymentMethod();

		S_teststep( "Measure the time difference between ECU reset and last diag service\n ", 'AUTO_NBR', 'STEP_11' );
		S_w2rep( "Waiting 4.5 seconds to check whether ECU reset is happened", 'blue' );
		S_wait_ms(4500);
		S_w2rep( "Sending disposal Security seed request to check that ECU still in Disposal session or in Default Session", 'blue' );
		GDCOM_request_general( "REQ_SecurityAccess_CD_RequestSeed", "PR_SecurityAccess_CD_RequestSeed" );
		S_w2rep( "Waiting 5 seconds to check whether ECU reset is happened", 'blue' );
		S_wait_ms($tcpar_SessionExpiryTimeDuration);
		S_w2rep( "Sending disposal Security seed request to check that ECU still in Disposal session or in Default Session", 'blue' );
		if ( $tcpar_ECUResetBehavior eq 'RESET' ) {
			GDCOM_request_general( "REQ_SecurityAccess_CD_RequestSeed", "NR_busyRepeatRequest" );
			S_wait_ms(10000);    #To finish initialization of ECU
			PD_ECUlogin();
		}
		else {
			GDCOM_request_general( "REQ_SecurityAccess_CD_RequestSeed", "NR_serviceNotSupportedInActiveSession" );
		}
	}
	elsif (( $tcpar_TestCondition eq 'StopDiagCommunication' )
		&& ( $tcpar_DiagCommunicationStopMethod eq 'TimeSinceLastTP' ) )
	{

		S_teststep( "Stop sending tester present\n", 'AUTO_NBR', 'STEP_12' );
		GDCOM_stop_CyclicTesterPresent($TP_handle);

		S_teststep( "Measure the time difference between ECU reset and last tester present\n ", 'AUTO_NBR', 'STEP_13' );
		S_w2rep( "Waiting 4.5 seconds to check whether ECU reset is happened", 'blue' );
		S_wait_ms(4500);
		S_w2rep( "Sending disposal Security seed request to check that ECU still in Disposal session or in Default Session", 'blue' );
		GDCOM_request_general( "REQ_SecurityAccess_CD_RequestSeed", "PR_SecurityAccess_CD_RequestSeed" );
		S_w2rep( "Waiting 5 seconds to check whether ECU reset is happened", 'blue' );
		S_wait_ms($tcpar_SessionExpiryTimeDuration);
		S_w2rep( "Sending disposal Security seed request to check that ECU still in Disposal session or in Default Session", 'blue' );
		if ( $tcpar_ECUResetBehavior eq 'RESET' ) {
			GDCOM_request_general( 'REQ_SecurityAccess_CD_RequestSeed', 'NR_busyRepeatRequest' );
			S_wait_ms(10000);    #To finish initialization of ECU
			PD_ECUlogin();
		}
		else {
			GDCOM_request_general( 'REQ_SecurityAccess_CD_RequestSeed', 'NR_serviceNotSupportedInActiveSession' );
		}

	}
	else {
		S_set_error("Invalid Condition $tcpar_TestCondition");
	}

	S_teststep( "Check Saftey status \n", 'AUTO_NBR', 'STEP_14' );

	$SPL_Routineresult_AfterReset = ACEA_RequestRoutineResults_SPL( $RoutineControlOption, $routineStatusRecord, 'NR_serviceNotSupportedInActiveSession' );

	if (   ( $tcpar_ResetStrategy eq 'Stategy2' )
		&& ( $tcpar_SPLActivation eq 'ActivateSPL' ) )
	{

		S_teststep( "Read Decryption key in RAM\n", 'AUTO_NBR', 'STEP_15' );
		$decryption_Key_AfterReset = ACEA_ReadDecryptionKeyInRAM();

		S_teststep( "Read Decrypted commands in RAM\n", 'AUTO_NBR', 'STEP_16' );
		$decryption_Commands_AfterReset = ACEA_ReadDecryptedCommandsInRAM($tcpar_ACL_Connectivity);
	}

	S_teststep( "Stop and Store Network trace\n", 'NO_AUTO_NBR' );

	# NET_trace_stop();               #  switch - off logging (only) but not the measurement
	# CA_trace_stop();
	my $can_trace_file = NET_trace_store();    # storing the trace
	                                           # my $can_trace_file = CA_trace_store();# storing the trace
	S_w2rep(" NET trace stored : $can_trace_file\n");

	return 1;
}

sub TC_evaluation {

	S_teststep_expected( "Evaluate response for Enter into safety system diagnostic session:-Evaluation done in Stimulation and measurement(Refer the traces or html report)\n", 'STEP_1' );
	S_teststep_detected( "Evaluate response for Enter into safety system diagnostic session:-Evaluation done in Stimulation and measurement(Refer the traces or html report)\n", 'STEP_1' );

	if (   ( $tcpar_ResetStrategy eq 'Stategy2' )
		&& ( $tcpar_SPLActivation eq 'ActivateSPL' ) )
	{

		$verdict = EVAL_evaluate_value( "Decryption  key before SPL", $tcpar_Exp1_DecryptionKeyInRAM, '==', $decryption_Key_BeforeSPL );
		S_teststep_expected( " Expected Decryption  key before SPL is :$tcpar_Exp1_DecryptionKeyInRAM \n", 'STEP_2' );
		if ( $verdict eq 'VERDICT_PASS' ) {
			S_teststep_detected( "Decryption  key before SPL is:" . $decryption_Key_BeforeSPL . "\n", 'STEP_2' );
		}

		if ( $verdict eq 'VERDICT_FAIL' ) {
			S_teststep_detected( "MISMATCH: Decryption  key before SPL is:" . $decryption_Key_BeforeSPL . "\n", 'STEP_2' );
		}

		$verdict = EVAL_evaluate_value( "Decrypted Commands in RAM before SPL", $tcpar_Exp1_ReadDecryptedCommandsInRAM, '==', $decryption_Commands_BeforeSPL_Array[0] );
		S_teststep_expected( " Decrypted Commands in RAM before SPL is :$tcpar_Exp1_ReadDecryptedCommandsInRAM\n", 'STEP_3' );
		if ( $verdict eq 'VERDICT_PASS' ) {
			S_teststep_detected( "Decrypted Commands in RAM before SPL is:" . $decryption_Commands_BeforeSPL_Array[0] . "\n", 'STEP_3' );
		}

		if ( $verdict eq 'VERDICT_FAIL' ) {
			S_teststep_detected( "MISMATCH: Decrypted Commands in RAM before SPL is:" . $decryption_Commands_BeforeSPL_Array[0] . "\n", 'STEP_3' );
		}

		S_teststep_expected( "Evaluate Security access-Evaluation is done at Stimulation and measurement(Refer the traces or html report)\n", 'STEP_4' );
		S_teststep_detected( "Evaluate Security access-Evaluation is done at Stimulation and measurement(Refer the traces or html report)\n", 'STEP_4' );

		S_teststep_expected( "Evaluate response for Activating SPL:-Evaluation is done at stimulation and measurement(Refer the traces or html report)\n", 'STEP_5' );
		S_teststep_detected( "Evaluate response for Activating SPL:-Evaluation is done at stimulation and measurement(Refer the traces or html report)\n", 'STEP_5' );

		$verdict = EVAL_evaluate_string( "Decryption  key after SPL", $tcpar_Exp_DecryptionKeyInRAM, $decryption_Key_AfterSPL );
		S_teststep_expected( " Decryption  key after SPL is :$tcpar_Exp_DecryptionKeyInRAM\n ", 'STEP_6' );
		if ( $verdict eq 'VERDICT_PASS' ) {
			S_teststep_detected( "Decryption  key after SPL is:" . $decryption_Key_AfterSPL . "\n", 'STEP_6' );
		}

		if ( $verdict eq 'VERDICT_FAIL' ) {
			S_teststep_detected( "MISMATCH: Decryption  key after SPL is:" . $decryption_Key_AfterSPL . "\n", 'STEP_6' );
		}

		S_w2rep( "Note:Decrypted commands will be always zero in RAM as RAM data will be deleted immediately dueo saftey concerns.", 'blue' );
		ACEA_EvaluateDecryptedCommandsInRAM( $decryption_Commands_AfterSPL, 'ZERO' );
		S_teststep_expected( "Decrypted Commands in RAM after executing SPL-Evaluation is done at Stimulation and Measurement(Refer the traces or html report)\n", 'STEP_7' );
		S_teststep_detected( "Decrypted Commands in RAM after executing SPL-Evaluation is done at Stimulation and Measurement(Refer the traces or html report)\n", 'STEP_7' );

	}
	if ( $tcpar_TestCondition eq 'DiagSesssionChange' ) {
		S_teststep_expected( "Evaluate response for Enter into Default session:-Evaluation is done at Stimulation and Measurement(Refer the traces)\n", 'STEP_8' );
		S_teststep_detected( "Evaluate response for Enter into Default session:-Evaluation is done at Stimulation and Measurement(Refer the traces)\n", 'STEP_8' );

	}
	elsif (( $tcpar_TestCondition eq 'StopDiagCommunication' )
		&& ( $tcpar_DiagCommunicationStopMethod eq 'TimeSinceLastDiag' ) )
	{
		S_teststep_expected_NOHTML( "No evaluation\n", 'STEP_9' );
		S_teststep_detected_NOHTML( "No evaluation\n", 'STEP_9' );

		S_teststep_expected( "Evaluate VIN obtained:-Evaluation is done at Stimulation and Measurement(Refer the traces or html report)\n", 'STEP_10' );
		S_teststep_detected( "Evaluate VIN obtained:-Evaluation is done at Stimulation and Measurement(Refer the traces or html report)\n", 'STEP_10' );

		S_teststep_expected( "Evaluate session expiry timeout duration:-Evaluation is done at Stimulation and Measurement(Refer the traces or html report)\n", 'STEP_11' );
		S_teststep_detected( "Evaluate session expiry timeout duration:-Evaluation is done at Stimulation and Measurement(Refer the traces or html report)\n", 'STEP_11' );

	}
	elsif (( $tcpar_TestCondition eq 'StopDiagCommunication' )
		&& ( $tcpar_DiagCommunicationStopMethod eq 'TimeSinceLastTP' ) )
	{
		S_teststep_expected( "No evaluation\n", 'STEP_12' );
		S_teststep_detected( "No evaluation\n", 'STEP_12' );

		S_teststep_expected( "Evaluate session expiry timeout duration::-Evaluation is done at Stimulation and Measurement(Refer the traces or html report)\n", 'STEP_13' );
		S_teststep_detected( "Evaluate session expiry timeout duration::-Evaluation is done at Stimulation and Measurement(Refer the traces or html report)\n", 'STEP_13' );
	}

	S_teststep_expected( "Evaluate saftey path status::-Evaluation is done at Stimulation and Measurement(Refer the traces or html report)\n", 'STEP_14' );
	S_teststep_detected( "Evaluate saftey path status::-Evaluation is done at Stimulation and Measurement(Refer the traces or html report)\n", 'STEP_14' );

	if (   ( $tcpar_ResetStrategy eq 'Stategy2' )
		&& ( $tcpar_SPLActivation eq 'ActivateSPL' ) )
	{

		S_w2rep( "Step15: Evaluate Decryption key in RAM", 'blue' );
		$verdict = EVAL_evaluate_value( "Decryption Key in RAM after ECU reset", $decryption_Key_AfterReset, '==', $tcpar_Exp1_DecryptionKeyInRAM );
		S_teststep_expected( " Decryption key in RAM is :$tcpar_Exp1_DecryptionKeyInRAM\n ", 'STEP_15' );
		if ( $verdict eq 'VERDICT_PASS' ) {
			S_teststep_detected( "Decryption key in RAM is:" . $decryption_Key_AfterReset . "\n", 'STEP_15' );
		}

		if ( $verdict eq 'VERDICT_FAIL' ) {
			S_teststep_detected( "MISMATCH: Decryption key in RAM is:" . $decryption_Key_AfterReset . "\n", 'STEP_15' );
		}

		ACEA_EvaluateDecryptedCommandsInRAM( $decryption_Commands_AfterReset, 'ZERO' );
		S_teststep_expected( "Evaluate Decrypted commands in RAM::-Evaluation is done at Stimulation and Measurement(Refer the traces or html report)\n", 'STEP_16' );
		S_teststep_detected( "Evaluate Decrypted commands in RAM::-Evaluation is done at Stimulation and Measurement(Refer the traces or html report)\n", 'STEP_16' );

	}

	return 1;
}

sub TC_finalization {
	NET_trace_start();
	if ( $tcpar_TestCondition ne 'StopDiagCommunication' ) {
		ACEA_Stop_TesterPresent($TP_handle);
	}
	S_wait_ms(2000);

	# change addressing_mode back from initial GDCOM_set_addressing_mode("disposal")
	GDCOM_set_addressing_mode("physical");

	GEN_Power_on_Reset();
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}

1;
