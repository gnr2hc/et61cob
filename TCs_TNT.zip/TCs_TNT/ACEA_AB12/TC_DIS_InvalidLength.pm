#### TEST CASE MODULE
package TC_DIS_InvalidLength;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DISP_Disposal
#TS version in DOORS: 3.93
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
use GENERIC_DCOM;
use LIFT_labcar;
use LIFT_NET_access;
##################################

our $PURPOSE = "Checking NRC13 for Supported Diagnostic Services for ACEA";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DIS_InvalidLength

=head1 PURPOSE

Checking NRC's for Supported Diagnostic Services for ACEA

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation

I<B<Stimulation and Measurement>>

1. Set the <address_mode>

2. Send <Request> with invalid length

Note : Dependent services to be sent before <Request>


I<B<Evaluation>>

1. 

2. Expected <Response>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => Purpose of the Test case
	SCALAR 'address_mode' => Disposal Mode
	SCALAR 'Response' => NRC obtained as response
	SCALAR 'Key' => Security Key
	SCALAR 'RoutineControlOption' => Routine control Option to execute SPL
	SCALAR 'LoopId' => Loop ID of the squib
	SCALAR 'Service' => Service to be executed
	SCALAR 'Request' => Request to be sent
	SCALAR 'DismantlerInfo' => Dismantler info to be written


=head2 PARAMETER EXAMPLES

	purpose  = 'Checking NRC's for Supported Diagnostic Services for ACEA '
	Key = "FE AA'
	RoutineControlOption = '01'
	LoopId = '00'
	DismantlerInfo =  '00 00 00 00 00 00 00 00 00 00 00 00 07 D5 0C 1F'
	address_mode = 'Disposal'
	Response = 'NR_incorrectMessageLengthOrInvalidFormat'
	Service = 'RoutineControl'
	Request = 'SecurityAccess_CD_SendKey'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_address_mode;
my $tcpar_Response;
my $tcpar_Key;
my $tcpar_Request;
my $tcpar_Service;
my $tcpar_RoutineControlOption;
my $tcpar_LoopId;
my $tcpar_DismantlerInfo;
################ global parameter declaration ###################
my $Modified_Request_Long;
my $Modified_Request_Short;
my %Temp;
my ( $TP_handle, $routineStatusRecord );
my $NRCInfo;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose              = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_address_mode         = S_read_mandatory_testcase_parameter('address_mode');
	$tcpar_Response             = S_read_mandatory_testcase_parameter('Response');
	$tcpar_Key                  = S_read_optional_testcase_parameter('Key');
	$tcpar_RoutineControlOption = S_read_optional_testcase_parameter('RoutineControlOption');
	$tcpar_LoopId               = S_read_optional_testcase_parameter('LoopId');
	$tcpar_DismantlerInfo       = S_read_optional_testcase_parameter('DismantlerInfo');
	$tcpar_Request              = S_read_mandatory_testcase_parameter('Request');
	$tcpar_Service              = S_read_mandatory_testcase_parameter('Service');

	$routineStatusRecord = $LIFT_PROJECT::Defaults->{"DISPOSAL"}{'RoutineStatusRecord'};

	return 1;
}

sub TC_initialization {

	S_w2rep("Standard_Preparation");
	GEN_StandardPrepNoFault();

	S_w2rep("Send Tester Present Cyclically");
	$TP_handle = ACEA_Send_TesterPresent_Cyclically();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Set the '$tcpar_address_mode' addressing mode", 'AUTO_NBR', 'STEP_1' );
	GDCOM_set_addressing_mode($tcpar_address_mode);
	GDCOM_StartSession('DisposalSession');

	S_teststep( "Send '$tcpar_Request' with invalid length", 'AUTO_NBR', 'STEP_2' );
	if ( defined($tcpar_Key) ) {
		$Temp{'Key'} = $tcpar_Key;
		ACEA_RequestSeed();
	}
	elsif ( defined($tcpar_RoutineControlOption) ) {
		ACEA_Get_SecurityAccess();
		$Temp{'RoutineControlOption'} = $tcpar_RoutineControlOption;
	}
	elsif ( defined($tcpar_LoopId) ) {
		ACEA_Get_SecurityAccess();
		ACEA_ExecuteDisposalProgramLoader( '01', $routineStatusRecord );
		$Temp{'LoopId'} = $tcpar_LoopId;
	}
	elsif ( defined($tcpar_DismantlerInfo) ) {
		$Temp{'DismantlerInfo'} = $tcpar_DismantlerInfo;
	}
	$Modified_Request_Long = GDCOM_requestlength_manipulation( "REQ_$tcpar_Request", \%Temp, +1 );

	$Modified_Request_Short = GDCOM_requestlength_manipulation( "REQ_$tcpar_Request", \%Temp, -1 );
	$NRCInfo = GDCOM_getNRCfromMapping( $tcpar_Service, 'NR_incorrectMessageLengthOrInvalidFormat' );
	GDCOM_request( $Modified_Request_Long, $NRCInfo->{'Response'}, $NRCInfo->{'Mode'}, $NRCInfo->{'Desc'} );
	if ( defined($tcpar_Key) ) {
		ACEA_RequestSeed();
	}
	GDCOM_request( $Modified_Request_Short, $NRCInfo->{'Response'}, $NRCInfo->{'Mode'}, $NRCInfo->{'Desc'} );

	return 1;
}

sub TC_evaluation {

	S_teststep_expected( "No Evaluation\n", 'STEP_1' );
	S_teststep_detected( "No Evaluation\n", 'STEP_1' );

	S_teststep_expected( "Evaluation for Request and Response Refer the html report or traces \n", 'STEP_2' );
	S_teststep_detected( "Evaluation for Request and Response Refer the html report or traces \n", 'STEP_2' );

	return 1;
}

sub TC_finalization {
	NET_trace_start();
	ACEA_Stop_TesterPresent($TP_handle);
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}

1;
