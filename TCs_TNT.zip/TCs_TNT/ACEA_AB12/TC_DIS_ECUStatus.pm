#### TEST CASE MODULE
package TC_DIS_ECUStatus;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DISP_Disposal
#TS version in DOORS: 3.104
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; 
use GENERIC_DCOM ;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_labcar;

##################################

our $PURPOSE = "Verification of ECU status by PD without setting Electronic Firing bit";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_ECUStatus

=head1 PURPOSE

Verification of ECU status by PD without setting Electronic Firing bit

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation


I<B<Stimulation and Measurement>>

1. ACL is <Signal> and <Line>

2. Execute the following steps with the <Condition>

3. Send a request by PD to enable safety paths <Req_Enable_SaftyPath>

4. Read ECU status by PD <Req_ReadECUStatus>


I<B<Evaluation>>

1.

2.

3. Expected <Resp_Enable_SaftyPath>

4. Expected <Resp_ReadECUStatus> with ECU status as <Status> at 5th byte of response.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => Test case purpose to be define
	SCALAR 'Status' => Status to be set
	SCALAR 'Condition' => Condition to be set
	SCALAR 'Signal' => Signal to be set
	SCALAR 'Line' => Line to be set
	SCALAR 'Req_Enable_SaftyPath' => Request of enable safety path to be set
	SCALAR 'Req_ReadECUStatus' => Request of ECUstatus to be set
	SCALAR 'Resp_Enable_SaftyPath' => Response of Enable safety path to be set
	SCALAR 'Resp_ReadECUStatus' => Response of Read ECU status to be set
	SCALAR 'time' => Time to be set


=head2 PARAMETER EXAMPLES

	Condition =  'SystemInitialization'
	Signal =  'NotSupported'
	Line =  'None'
	Req_Enable_SaftyPath = 'REQ_Enable_Safety_Path'
	Req_ReadECUStatus = 'REQ_ECU_Status'
	Resp_Enable_SaftyPath = 'PR_Enable_Safety_Path'
	Resp_ReadECUStatus = 'PR_ECU_Status'
	time ='2s'
	purpose  = 'Check ECU status by PD without setting Electronic Firing bit'
	
	Status = '0x00'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Condition;
my $tcpar_Signal;
my $tcpar_Line;
my $tcpar_Req_Enable_SaftyPath;
my $tcpar_Req_ReadECUStatus;
my $tcpar_Resp_Enable_SaftyPath;
my $tcpar_Resp_ReadECUStatus;
my $tcpar_time;
my $tcpar_purpose;
my $tcpar_Status;

################ global parameter declaration ###################
#add any global variables here

my $EnableSafetyPathID = '0x18';
my $EnableSafetyPath_Response_BlockLength = '0x02';
my $EnableSafetyPath_Response_Title = '0x58';
my $Detected_SafetyPath_Response;
my $Detected_PD_Response;
my $NegativeResponse = '0x7F';
my $NR_ConditionNotCorrect = '0x22';
my $Modified_Request;
my @request_bytes;


###############################################################

sub TC_set_parameters {

	$tcpar_Condition =  S_read_mandatory_testcase_parameter( 'Condition' );
	$tcpar_Signal =  S_read_mandatory_testcase_parameter( 'Signal' );
	$tcpar_Line =  S_read_mandatory_testcase_parameter( 'Line' );
	$tcpar_Req_Enable_SaftyPath =  S_read_mandatory_testcase_parameter( 'Req_Enable_SaftyPath' );
	$tcpar_Req_ReadECUStatus =  S_read_mandatory_testcase_parameter( 'Req_ReadECUStatus' );
	$tcpar_Resp_Enable_SaftyPath =  S_read_mandatory_testcase_parameter( 'Resp_Enable_SaftyPath' );
	$tcpar_Resp_ReadECUStatus =  S_read_mandatory_testcase_parameter( 'Resp_ReadECUStatus' );
	$tcpar_time =  S_read_mandatory_testcase_parameter( 'time' );
	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_Status =  S_read_mandatory_testcase_parameter( 'Status' );

	return 1;
}

sub TC_initialization {

	S_w2rep("Standard_Preparation");	
	GEN_StandardPrepNoFault();	

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("ACL is '$tcpar_Signal' and '$tcpar_Line'", 'AUTO_NBR');

	S_teststep("Execute the following steps with the '$tcpar_Condition'", 'AUTO_NBR');
	if($tcpar_Condition eq "WithoutSettingEFbit")
	{
		S_teststep("Send a request by PD to enable safety paths '$tcpar_Req_Enable_SaftyPath'", 'AUTO_NBR', 'send_a_request');			#measurement 1
		$Modified_Request=GDCOM_getRequestLabelValue("$tcpar_Req_Enable_SaftyPath");	
	    @request_bytes = split(/ /, $Modified_Request);	
		$Detected_SafetyPath_Response = GEN_hexaref2byteString(PD_send_request_wait_response(\@request_bytes));
		
		
	}
	elsif($tcpar_Condition eq "SystemInitialization")
	{
		GEN_Power_on_Reset('NO_WAIT');
		S_wait_ms(200);
		S_teststep("Send a request by PD to enable safety paths '$tcpar_Req_Enable_SaftyPath'", 'AUTO_NBR', 'send_a_request');			#measurement 1
		$Modified_Request=GDCOM_getRequestLabelValue("$tcpar_Req_Enable_SaftyPath");	
	    @request_bytes = split(/ /, $Modified_Request);
		$Detected_SafetyPath_Response = GEN_hexaref2byteString(PD_send_request_wait_response(\@request_bytes));
	}
	elsif($tcpar_Condition eq "SafteyPathnotstarted")
	{
		GEN_setECUMode ("PlantMode7_ElectronicFiringMode");
		S_wait_ms('TIMER_ECU_READY');
		S_teststep("Send a request by PD to enable safety paths '$tcpar_Req_Enable_SaftyPath'", 'AUTO_NBR', 'send_a_request');			#measurement 1
		$Modified_Request=GDCOM_getRequestLabelValue("$tcpar_Req_Enable_SaftyPath");	
	    @request_bytes = split(/ /, $Modified_Request);
		$Detected_SafetyPath_Response = GEN_hexaref2byteString(PD_send_request_wait_response(\@request_bytes));
		
	}
	elsif($tcpar_Condition eq "SafteyPathStarted")
	{
		GEN_setECUMode ("PlantMode7_ElectronicFiringMode");
		S_teststep("Send a request by PD to enable safety paths '$tcpar_Req_Enable_SaftyPath'", 'AUTO_NBR', 'send_a_request');			#measurement 1
		$Modified_Request=GDCOM_getRequestLabelValue("$tcpar_Req_Enable_SaftyPath");	
	    @request_bytes = split(/ /, $Modified_Request);
		$Detected_SafetyPath_Response = GEN_hexaref2byteString(PD_send_request_wait_response(\@request_bytes));
		S_wait_ms(500);
	}
	elsif($tcpar_Condition eq "AfterSafteyPathEnabled")
	{
		GEN_setECUMode ("PlantMode7_ElectronicFiringMode");
		S_teststep("Send a request by PD to enable safety paths '$tcpar_Req_Enable_SaftyPath'", 'AUTO_NBR', 'send_a_request');			#measurement 1
		$Modified_Request=GDCOM_getRequestLabelValue("$tcpar_Req_Enable_SaftyPath");	
	    @request_bytes = split(/ /, $Modified_Request);
		$Detected_SafetyPath_Response = GEN_hexaref2byteString(PD_send_request_wait_response(\@request_bytes));
		S_wait_ms(2000);
	}	

	S_teststep("Read ECU status by PD '$tcpar_Req_ReadECUStatus'", 'AUTO_NBR', 'read_ecu_status');			#measurement 2
	$Modified_Request=GDCOM_getRequestLabelValue("$tcpar_Req_ReadECUStatus");	
	@request_bytes = split(/ /, $Modified_Request);
	$Detected_PD_Response = GEN_hexaref2byteString(PD_send_request_wait_response(\@request_bytes));

	return 1;
}

sub TC_evaluation {	
	
	S_teststep_expected("Expected Response is Positive Response\n ",'send_a_request');  #evaluation 1
	S_teststep_detected("Detected Response is $Detected_SafetyPath_Response \n",'send_a_request');	
	my @Obtained_Response = split( / /, "$Detected_SafetyPath_Response" );	
	
	if($tcpar_Condition eq "WithoutSettingEFbit")
	{
		if (("0x".$Obtained_Response[0] eq $NegativeResponse ) && ("0x".$Obtained_Response[1] eq $EnableSafetyPathID)&& ("0x".$Obtained_Response[2] eq $NR_ConditionNotCorrect))
		{
		S_set_verdict('VERDICT_PASS');
		}
		else
		{
		S_set_verdict('VERDICT_FAIL'); 
		}
	
	}
	
	else
	{
	
		if (("0x".$Obtained_Response[0] eq $EnableSafetyPath_Response_BlockLength ) && ("0x".$Obtained_Response[1] eq $EnableSafetyPath_Response_Title))
		{
			S_set_verdict('VERDICT_PASS');
		}
		else
		{
			S_set_verdict('VERDICT_FAIL'); 
		}
	}

	my @Obtained_Response = split( / /, "$Detected_PD_Response" );
	S_teststep_expected("Expected ECU status as '$tcpar_Status' at 5th byte of response.\n", 'read_ecu_status');			#evaluation 3
	S_teststep_detected("Detected ECU Status is $Obtained_Response[4]\n", 'read_ecu_status');
	
	if ("0x".$Obtained_Response[4] eq $tcpar_Status ) 
	{
		S_set_verdict('VERDICT_PASS');
	}
	else
	{
		S_set_verdict('VERDICT_FAIL'); 
	}

	return 1;
}

sub TC_finalization {

	if(($tcpar_Condition eq "SafteyPathnotstarted") || ($tcpar_Condition eq "SafteyPathStarted") ||($tcpar_Condition eq "AfterSafteyPathEnabled"))
	{
		GEN_setECUMode ("RemovePlantModes");
	}
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}


1;
