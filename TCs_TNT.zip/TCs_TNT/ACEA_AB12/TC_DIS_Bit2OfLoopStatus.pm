#### TEST CASE MODULE
package TC_DIS_Bit2OfLoopStatus;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DISP_Disposal
#TS version in DOORS: 3.41
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use INCLUDES_Project;
use GENERIC_DCOM;
use LIFT_evaluation;
use LIFT_can_access;
use LIFT_PD;

##################################

our $PURPOSE = "To check that Bit 2 of loop status is set in IDLE mode";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DIS_Bit2OfLoopStatus

=head1 PURPOSE

To check that Bit 2 of loop status is set in IDLE mode

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

1. Standard_Preparation
2. Send Tester Present continously

I<B<Stimulation and Measurement>>

1. Create Idle Mode

2. Read loop status of all deployable squibs rb_dmim_DeploymentLoopStatusTable_au8(0)




I<B<Evaluation>>

1.

2. Bit 2 of all the loop status should be set.




I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => Purpose of the test case
	SCALAR 'Test_Condition' => Test condition
	SCALAR 'REQ_ReadStatus' => Vaiable name to read deployment loop status


=head2 PARAMETER EXAMPLES

	purpose  = 'To check that Bit 2 of loop status is set in IDLE mode'
	Test_Condition =  'Idle Mode'
	REQ_ReadStatus = 'rb_dmim_DeploymentLoopStatusTable_au8(0)'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Test_Condition;
my $tcpar_REQ_ReadStatus;

################ global parameter declaration ###################
my $Squib_Loop_Status;
my @Squib_Loop_Array;
my $TP_handle;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose        = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_Test_Condition = S_read_mandatory_testcase_parameter('Test_Condition');
	$tcpar_REQ_ReadStatus = S_read_mandatory_testcase_parameter('REQ_ReadStatus');

	return 1;
}

sub TC_initialization {

	GEN_printTestStep("Start of Precondition");

	my $msg_aref = $LIFT_PROJECT::Defaults->{'CUSTOMER_DIAGNOSIS'}{'CAN_TesterPresent_REQ'};
	my $msg_ID   = $LIFT_PROJECT::Defaults->{"CUSTOMER_DIAGNOSIS"}{'REQuestID_disposal'};
	my $cycle    = 4500;
	GEN_printTestStep("Step1:Standard Preparation");
	GEN_StandardPrepNoFault();
	GDCOM_set_addressing_mode("disposal");
	GEN_printTestStep("Step 2: SendTesterPresentCyclically");
	$TP_handle = GDCOM_start_CyclicTesterPresent( $msg_aref, $msg_ID, $cycle );

	return 1;
}

sub TC_stimulation_and_measurement {

	GEN_printTestStep("Step 1. Create '$tcpar_Test_Condition'");
	S_user_action("Create Idle mode");

	#GEN_setECUMode('$tcpar_Test_Condition'); Will use when function is implemented in AB12 till Idle mode is created by S_useraction()
	GEN_printTestStep("Step 2. Read loop status of all deployable squibs '$tcpar_REQ_ReadStatus'");
	$Squib_Loop_Status = S_dec2bin( S_aref2dec( PD_ReadMemoryByName($tcpar_REQ_ReadStatus), U8 ) );
	$Squib_Loop_Status =~ s/^0+//;
	@Squib_Loop_Array = split( "", $Squib_Loop_Status );
	return 1;
}

sub TC_evaluation {

	GEN_printTestStep("Evaluation for Step 1.:-No Evaluation");
	GEN_printTestStep("Evaluation for Step 2. Bit 2 of all the loop status should be set.");
	EVAL_evaluate_value( "Bit2 is set", $Squib_Loop_Array[2], '==', 1 );
	return 1;
}

sub TC_finalization {

	GDCOM_stop_CyclicTesterPresent($TP_handle);    #Stop the TP sending cyclically
	S_wait_ms(2000);
	S_user_action("Remove Idle mode");
	GEN_setECUMode(RemoveIdleMode);
	GEN_Power_on_Reset();
	return 1;
}

1;
