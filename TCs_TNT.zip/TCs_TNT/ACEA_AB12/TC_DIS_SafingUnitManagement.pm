#### TEST CASE MODULE
package TC_DIS_SafingUnitManagement;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DISP_Disposal
#TS version in DOORS: 3.105
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
use LIFT_evaluation;
use LIFT_PD;
use GENERIC_DCOM;
use LIFT_labcar;

##################################

our $PURPOSE = "To verify the possible scenarios of firing when safing unit is locked or unlocked";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DIS_SafingUnitManagement

=head1 PURPOSE

To verify the possible scenarios of firing when safing unit is locked or unlocked

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

1. Standard_Preparation

2. Send tester present continously


I<B<Stimulation and Measurement>>

1.Enter Session
2.Enable Disposal Security
3.Create Condition
4.Send Request to Fire Squib
5.Execute SPL
6.Set DisposalMethod
7.Safing Unit CANStatus
8.Create Fault
9.Customer check applicable or not
10.Customer check executing or not
11.Execute Customer function 
12.Send Request to Fire Squib
13.Set NRCOption
14.Send Request to Fire Squib
15.Send Request to Fire Squib
16.Safing Unit ACLStatus
17.Create Fault
18.Wait for ACL for time $tcpar_time
19.Customer check applicable or not
20.Customer check executing or not
21.Execute Customer function
22.Send Request to Fire Squib
23.Set NRCOption
24.Send Request to Fire Squib based on NRC option
25.Send Request to Fire Squib based on NRC option
 
I<B<Evaluation>>

1. Disposal Session entered
2. Disposal Security Enabled
3. Created Condition
4. NRC Response obtained
5. SPL Executed
6. Set DisposalMethod
7. CANStatus is set
8. Fault Created
9. Custmer check verified
10. Customer check status verified
11. Customer function executed
12. Response obtained
13. NRCOption is set
14. NRC Response obtained
15. Response obtained with Status
16. ACLStatus is set
17. Fault Created
18. Waited 2 seconds to connect ACL
19. Custmer check verified
20. Customer check status verified
21. Customer function executed
22. Response obtained
23. NRCOption is set
24. NRC Response obtained
25. Response obtained with Status


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => Purpose of the test case
	SCALAR 'Session' => Disposal session to be entered
	SCALAR 'Condition' => Condition in which SPL to be executed or not
	SCALAR 'Response_NRC' => NRC Response
	SCALAR 'DisposalMethod' => Disposal method to be followed
	SCALAR 'CANStatus' => Status of CAN 
	SCALAR 'ACLSTatus' => Status of CAN+ACL system
	SCALAR 'Fault' => WD fault to be created
	SCALAR 'Response' => Response obtained
	SCALAR 'NRCOption' => Option where NRC is configured or not
	SCALAR 'Request' => Firing request to be sent 
	SCALAR 'time' => Time for which system should wait for ACL signal
	SCALAR 'Check' => Check used to verify whether customer specific precondition is required before firing
	SCALAR 'Status' => Status of customer specific pre condition

=head2 PARAMETER EXAMPLES

	purpose ='To verify the possible scenarios of firing when safing unit is locked or unlocked'
	
	Session ='DisposalSession'
	
	Condition ='Execute SPL'
	
	Response_NRC ='NR_requestSequenceError'
	
	DisposalMethod ='CAN'
	
	CANStatus ='Unlocked'
	
	ACLSTatus ='Unlocked'
	
	Fault ='rb_wdm_WDFaultMasterWD1_flt'
	
	Response ='PR_RoutineControl_StartRoutine_DeployLoopRoutineID'
	
	NRCOption ='NRC'
	
	ACLConnect ='ACL'
	
	Request='REQ_RoutineControl_StartRoutine_DeployLoopRoutineID'
	
	Status = 'Yes'
	
	Check = 'Pass'
	
	time = 2000#ms
=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Session;
my $tcpar_Condition;
my $tcpar_DisposalMethod;
my $tcpar_CANStatus;
my $tcpar_ACLStatus;
my $tcpar_Fault;
my $tcpar_NRCOption;
my $tcpar_ACLConnect;
my $tcpar_Request;
my $tcpar_Status;
my $tcpar_time;
my $tcpar_LoopId;
my $tcpar_Check;
my $tcpar_Cus_Status;

################ global parameter declaration ###################
my ( $TP_handle, $Response, $Response_LoopStatus, $i, $LoopStatus_Initial, $routineStatusRecord, $ECUType, $SWPath, $FlashToolNumber );
my %Temp;
my ( @Response_Array, @Response_LoopStatus_Array );
my $flag = 2;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose        = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_Session        = S_read_mandatory_testcase_parameter('Session');
	$tcpar_Condition      = S_read_mandatory_testcase_parameter('Condition');
	$tcpar_DisposalMethod = S_read_mandatory_testcase_parameter('DisposalMethod');
	$tcpar_CANStatus      = S_read_mandatory_testcase_parameter('CANStatus');
	$tcpar_ACLStatus      = S_read_mandatory_testcase_parameter('ACLStatus');
	$tcpar_Fault          = S_read_mandatory_testcase_parameter('Fault');
	$tcpar_NRCOption      = S_read_mandatory_testcase_parameter('NRCOption');
	$tcpar_ACLConnect     = S_read_mandatory_testcase_parameter('ACLConnect');
	$tcpar_Request        = S_read_mandatory_testcase_parameter('Request');
	$tcpar_Status         = S_read_optional_testcase_parameter('Status');
	$tcpar_time           = S_read_mandatory_testcase_parameter('time');
	$tcpar_LoopId         = S_read_mandatory_testcase_parameter('LoopId');
	$tcpar_Check          = S_read_mandatory_testcase_parameter('Check');
	$tcpar_Cus_Status     = S_read_mandatory_testcase_parameter('Cus_Status');

	$routineStatusRecord = $LIFT_PROJECT::Defaults->{"DISPOSAL"}{'RoutineStatusRecord'};
	$ECUType             = $LIFT_PROJECT::Defaults->{"DISPOSAL"}{'ECU_Type'};
	$SWPath              = $LIFT_PROJECT::Defaults->{"DISPOSAL"}{'SW_Path'};
	$FlashToolNumber     = $LIFT_PROJECT::Defaults->{"DISPOSAL"}{'ECU_Serial_Number'};

	return 1;
}

sub TC_initialization {

	S_w2rep("Standard_Preparation");
	GEN_StandardPrepNoFault();

	S_w2rep("Send tester present continously");
	$TP_handle = ACEA_Send_TesterPresent_Cyclically();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Enter $tcpar_Session ", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("disposal");
	S_wait_ms(20000);
	GDCOM_StartSession('DisposalSession');

	S_teststep( "Enable Disposal Security ", 'AUTO_NBR' );
	ACEA_Get_SecurityAccess();

	S_teststep( "Condition to be set is : $tcpar_Condition ", 'AUTO_NBR' );
	$Temp{'LoopId'}          = $tcpar_LoopId;
	$Temp{'LoopId_Response'} = $routineStatusRecord . ' ' . $tcpar_LoopId;
	$Response_LoopStatus     = ACEA_Read_DiploymentLoopTable();
	@Response_LoopStatus_Array = split( / /, $Response_LoopStatus );
	for ( $i = 6 ; $i < scalar(@Response_LoopStatus_Array) ; $i = $i + 2 ) {
		if ( $Response_LoopStatus_Array[$i] == $tcpar_LoopId ) {
			$LoopStatus_Initial = $Response_LoopStatus_Array[ $i + 1 ];
			last;
		}
	}
	if ( $tcpar_Condition eq 'NoSPL' ) {

		S_teststep( "Send $tcpar_Request to Fire Squib ", 'AUTO_NBR' );
		GDCOM_request_general( "REQ_RoutineControl_StartRoutine_DeployLoopRoutineID", "NR_requestSequenceError", \%Temp );
	}
	else {

		S_teststep( "Execute SPL ", 'AUTO_NBR' );
		ACEA_ExecuteDisposalProgramLoader( '01', $routineStatusRecord );
		S_teststep( "Set Disposal Method as  $tcpar_DisposalMethod ", 'AUTO_NBR' );
		if ( $tcpar_DisposalMethod eq 'CAN' ) {

			S_teststep( "Safing Unit $tcpar_CANStatus ", 'AUTO_NBR' );
			if ( $tcpar_CANStatus eq 'Locked' ) {
				S_teststep( "Create a fault $tcpar_Fault ", 'AUTO_NBR' );
				PD_WriteMemoryByName( "rb_wdm_Wd2ResponseRT_u32.1", [0x01] );
				S_wait_ms(2000);
				PD_ReadFaultMemory();
				S_teststep( " $tcpar_NRCOption ", 'AUTO_NBR' );
				if ( $tcpar_NRCOption eq 'NRC' ) {
					S_teststep( "Send $tcpar_Request to Fire Squib ", 'AUTO_NBR' );
					GDCOM_request_general( "REQ_RoutineControl_StartRoutine_DeployLoopRoutineID", "NR_conditionsNotCorrect", \%Temp );
				}
				else {
					S_teststep( "Send $tcpar_Request to Fire Squib ", 'AUTO_NBR' );
					$Response = GDCOM_request_general( "REQ_RoutineControl_StartRoutine_DeployLoopRoutineID", "PR_RoutineControl_StartRoutine_DeployLoopRoutineID", \%Temp );
					@Response_Array = split( / /, $Response );
					EVAL_evaluate_value( "Deployment Loop Status", $Response_Array[6], '==', "$LoopStatus_Initial" );
				}
			}
			elsif ( $tcpar_CANStatus eq 'Unlocked' ) {
				if ( $tcpar_Check eq 'NotApplicable' ) {
					S_w2rep( "No specific customer check proceeding to next step", 'blue' );
				}
				else {
					if ( $tcpar_Cus_Status eq 'Yes' ) {
						ACEA_FireCondition();
					}
					elsif ( $tcpar_Cus_Status eq 'No' ) {
						S_w2rep( "Skipping customer specific pre condition", 'blue' );
					}

				}
				S_teststep( "Send $tcpar_Request to Fire Squib ", 'AUTO_NBR' );
				$Response = GDCOM_request_general( "REQ_RoutineControl_StartRoutine_DeployLoopRoutineID", "PR_RoutineControl_StartRoutine_DeployLoopRoutineID", \%Temp );
				@Response_Array = split( / /, $Response );
				EVAL_evaluate_value( "Deployment Loop Status", $Response_Array[6], 'MASK', "$tcpar_Status" );
			}
		}
		elsif ( $tcpar_DisposalMethod eq 'CANACL' ) {
			S_teststep( "Safing Unit ACL status is $tcpar_ACLStatus ", 'AUTO_NBR' );
			if ( $tcpar_ACLStatus eq "LockedOther" ) {
				GEN_printTestStep( "Create $tcpar_Fault ", 'AUTO_NBR' );
				PD_WriteMemoryByName( "rb_wdm_Wd2ResponseRT_u32.1", [0x01] );
				S_wait_ms(2000);
				PD_ReadFaultMemory();
				$flag = 1;
			}
			elsif ( $tcpar_ACLStatus eq "Unlocked" ) {
				if ( $tcpar_Check eq 'NotApplicable' ) {
					S_w2rep( "No specific customer check proceeding to next step", 'blue' );
				}
				else {
					if ( $tcpar_Cus_Status eq 'Yes' ) {
						ACEA_FireCondition();
					}
					elsif ( $tcpar_Cus_Status eq 'No' ) {
						S_w2rep( "Skipping customer specific pre condition", 'blue' );
					}
				}

				$flag = 0;
			}
			elsif ( $tcpar_ACLStatus eq "LockedACL" ) {

				S_teststep( "Wait for ACL for time $tcpar_time ", 'AUTO_NBR' );
				S_wait_ms($tcpar_time);
				if ( $tcpar_ACLConnect eq "ACLNotConnected" ) {
					$flag = 1;
				}
			}
			if ( $flag == 1 ) {
				S_teststep( "NRC Condition is :$tcpar_NRCOption ", 'AUTO_NBR' );
				if ( $tcpar_NRCOption eq 'NRC' ) {
					S_teststep( "Send $tcpar_Request to Fire Squib ", 'AUTO_NBR' );
					GDCOM_request_general( "REQ_RoutineControl_StartRoutine_DeployLoopRoutineID", "NR_conditionsNotCorrect", \%Temp );
				}
				else {
					S_teststep( "Send $tcpar_Request to Fire Squib ", 'AUTO_NBR' );
					$Response = GDCOM_request_general( "REQ_RoutineControl_StartRoutine_DeployLoopRoutineID", "PR_RoutineControl_StartRoutine_DeployLoopRoutineID", \%Temp );
					@Response_Array = split( ' ', $Response );
					EVAL_evaluate_value( "Deployment Loop Status", $Response_Array[6], '==', "$LoopStatus_Initial" );
				}
			}
			elsif ( $flag == 0 ) {
				S_teststep( "Send $tcpar_Request to Fire Squib ", 'AUTO_NBR' );
				$Response = GDCOM_request_general( "REQ_RoutineControl_StartRoutine_DeployLoopRoutineID", "PR_RoutineControl_StartRoutine_DeployLoopRoutineID", \%Temp );
				@Response_Array = split( ' ', $Response );

				EVAL_evaluate_value( "Deployment Loop Status", S_hex2dec( $Response_Array[6] ), 'MASK', $tcpar_Status );
			}
		}

	}

	return 1;
}

sub TC_evaluation {

	S_w2rep(" Evaluation for all steps done at Stimulation and Measurement ");

	return 1;
}

sub TC_finalization {

	ACEA_Stop_TesterPresent($TP_handle);
	PD_ClearFaultMemory();
	GEN_Power_on_Reset();
	if ( ( $tcpar_ACLStatus eq "Unlocked" ) || ( $tcpar_ACLConnect eq "ConnectACL" ) ) {
		GEN_AutoECUFlash( $SWPath, $FlashToolNumber, $ECUType );
	}
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	return 1;
}

1;
