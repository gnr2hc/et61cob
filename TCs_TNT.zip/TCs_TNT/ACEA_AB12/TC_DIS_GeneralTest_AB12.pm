#### TEST CASE MODULE
package TC_DIS_GeneralTest_AB12;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DISP_Disposal
#TS version in DOORS: 3.93
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use INCLUDES_Project;

#include further modules here
use LIFT_PD;
use LIFT_evaluation;
use GENERIC_DCOM;
use LIFT_can_access;
use LIFT_labcar;

#use FuncLib_ACEA_TNT;
use LIFT_functional_layer;
##################################
our $PURPOSE = "To test ACEA deployement flow under various different conditions";
use constant DEFAULT_TRANSI_LOGTIME => 3;      #seconds
use constant THRESHOLD_SQUIB_FIRING => 1.2;    #threshold for squib firing (ampears)

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DIS_GeneralTest

=head1 PURPOSE

To test ACEA deployement flow under various different conditions

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

 	Step 1: Re-initialize NVM
	Step 2: Standard Preparation
	Step 3: SendTesterPresentCyclically
	Step 4: SetTestCondition


I<B<Stimulation and Measurement>>
	Step 1: Read HW deploypemt method
	Step 2: Read Number of ECU's in the Vehicle
	Step 3: Read address information of ECU's
	Step 4: Read VIN
	Step 5: Read default dismantler information
	Step 6: write dismantler information for the first time
	Step 7: write dismantler information for the second time
	Step 8: Read dismantler information after rewriting dismantler information
	Step 9: Read default deployment loop table
	Step 9: Read default loop status from NVM
	Step 10: Enter into safety system diagnostic session
	Step 11: Read Algo status after Entering into safety system diagnostic session
	Step 11: ReadWL status after Entering into safety system diagnostic session
	Step 11: Read SDL status after Entering into safety system diagnostic session
	Step 12: Read Default Disposal key stored at RAM
	Step 13: Obtain  security access
	Step 14: Read Disposal key stored at RAM after Activating DPL
	Step 15: Read disable line status
	Step 16: Execute disposal Program loader 
	Step 17: Execute disposal Program loader with RAM conversion
	Step 18: Read disable line status
	Step 19: Read Algo status after Activating DPL
	Step 19: Read WL status after Activating DPL
	Step 19: Read SDL status after Activating DPL
	Step 20: Read deployment loop table after Activating DPL
	Step 20: Read Deployment loop status from NVM after Activating DPL
	Step 21: ACL supported or Not
	Execute Step 22 and 23 if ACLSupported == 'Yes',
	Step 22: Fire a squib without ACL connected
	Step 23: Connecting the ACL PWM signal
	Step 24: Fire a squib
	Step 25: Read Fire Counter
	Step 26: Write dismantler information after each squib fired
	Step 27: Read dismantler information after each squib fired
	Step 28: Read deployment loop table after firing the squib
	Step 28: Read Deployment loop status from NVM after firing the squib
	Step 29: Read Request Routine Result after firiing the squib
	Step 30: Reset ECU
	Step 31: Read deployment loop table after Resetting ECU
	Step 31: Read Deployment loop status from NVM after Resetting ECU
Note : The entire test should be executed for all the system asic and possible asic combinations.
 
I<B<Evaluation>>
	Step 1: Evaluate HW deploypemt method
	Step 2: Evaluate Number of ECU's in the Vehicle
	Step 3: Evaluate address information of ECU's
	Step 4: Evaluate VIN
	Step 5: Evaluate dismantler information
	Step 6: Evaluate response for write dismantler information for the first time
	Step 7: Evaluate response for write dismantler information for the second time
	Step 8: Evaluate response for Read dismantler information after rewriting
	Step 9: Read default deployment loop table
	Step 9: Read default loop status from NVM
	Step 10: Evaluate response for Enter into safety system diagnostic session 
	Step 11: Evaluate Algo status read after Entering into safety system diagnostic session
	Step 11: Evaluate WL status read after Entering into safety system diagnostic session
	Step 11: Evaluate SDL status read after Entering into safety system diagnostic session
	Step 12: Evaluate Default Disposal key stored at RAM
	Step 13: Evaluate response for Obtain security access
	Step 14: Evaluate Disposal key stored at RAM read after Activating DPL
	Step 15: Expected disable line status = DISABLED
	Step 16: Evaluate response for Execute disposal Program loader
	Step 17: Evaluate response for Execute disposal Program loader with RAM conversion
	Step 18: Expected disable line status = ENABLED
	Step 19: Evaluate Algo status read after Activating DPL
	Step 19: Evaluate WL status read after Activating DPL
	Step 19: Evaluate SDL status read after Activating DPL
	Step 20: Evaluate deployment loop table after Activating DPL
	Step 20: Evaluate Deployment loop status from NVM read before Firing the squib
	Step 21: ACL supported or Not
	Evaluate Step 22 and 23 if ACLSupported == 'Yes',
	Step 22: Evaluate response for Fire a squib without ACL connected
	Step 23: No evaluation
	Step 24: Evaluate response for Fire a squib
	Step 25: Evaluate Fire counter value
	Step 26: Evaluate response for writing dismantler information after first squib fired
	Step 27: Evaluate response for Read dismantler information after first squib fired
	Step 28: Reading deployment loop table after firing the squib
	Step 28: Evaluate Deployment loop status from NVM read after firing the squib
	Step 29: Evaluate Request Routine Result read after firiing the squib
	Step 30: Reseting the ECU - No evaluation
	Step 31: Evaluate deployment loop table read after Restarting ECU.
	Step 31: Evaluate Deployment loop status from NVM read after Restarting ECU.

 


I<B<Finalisation>>

Bring back the system to normal state


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => purpose of the test
	SCALAR 'ACLSupported' => Is ACL supported or not
	SCALAR 'TestCondition' => Condition fo the test
	SCALAR 'ExpResp_DismantlerInfo_FirstWrite' => Expected Dismantler info after first write
	SCALAR 'ExpResp_DismantlerInfo_SecondWrite' => Expected Dismantler info after second write
	SCALAR 'ExpResp_DismantlerInfo_AfterWrite' => Expected Dismantler info after firing
	SCALAR 'Default_DeploymentloopStatusInNVM' => Deployment loop status in NVM
	SCALAR 'BeforeExecuteSPL_AlgoStatus' => Algo status before SPL execution
	SCALAR 'BeforeExecuteSPL_WLStatus' => Warning lamp status before SPL execution
	SCALAR 'BeforeExecuteSPL_SDLSwitchMonitoring' => SDLSwitchMonitoring status before SPL execution
	SCALAR 'Exp_DecryptionKeyInRAM' => Expected decryption key in RAM
	SCALAR 'AfterExecuteSPL_AlgoStatus' => Algo status after SPL execution
	SCALAR 'AfterExecuteSPL_WLStatus' => Warning lamp status after SPL execution
	SCALAR 'AfterExecuteSPL_SDLSwitchMonitoring' => SDLSwitchMonitoring status after SPL execution
	SCALAR 'BeforeFire_DeploymentloopStatusInNVM' => Deployment loop status in NVM before fire
	SCALAR 'Read_DismantlerInfo_AfterFire' => Reading dismantler info
	SCALAR 'AfterFire_DeployementLoopTable' => Deployment loop table after fire
	SCALAR 'AfterFire_DeploymentloopStatusInNVM' => Deployment loop status in NVM after fire
	SCALAR 'ResetAfterFire_DeployementLoopTable' => Deployment loop table after reset
	SCALAR 'Default_DismantlerInfo' => Default dismantler info
	SCALAR 'DismantlerInfo_FirstTime' => Dismantler info after first write
	SCALAR 'DismantlerInfo_SecondTime' => Dismantler info after second write
	SCALAR 'DismantlerInfo_ThirdTime' => Dismantler info after third write
	SCALAR 'Default_DeploymentloopStatus' => Deployment status  by default
	SCALAR 'AfterFire_DeploymentloopStatus' => Deployment status after firing a squib

=head2 PARAMETER EXAMPLES

	purpose  = 'To test ACEA deployement flow under various different conditions'
	ACLSupported = 'Yes' #'Yes' or 'No'
	TestCondition = 'No Fault'
	ExpResp_DismantlerInfo_FirstWrite = 'PR_WriteDatabyID_WriteDismantlerInfo'
	ExpResp_DismantlerInfo_SecondWrite = 'PR_WriteDatabyID_WriteDismantlerInfo'
	ExpResp_DismantlerInfo_AfterWrite = 'PR_ReadDatabyID_ReadDismantlerInfo'
	Default_DeploymentloopStatusInNVM = '0x0000000000000000'
	BeforeExecuteSPL_AlgoStatus = 'ENABLED'
	BeforeExecuteSPL_WLStatus = 'OFF'
	BeforeExecuteSPL_SDLSwitchMonitoring = 'MONITORED'
	BeforeExecuteSPL_CriticalDisposalcommandsInRAM = 'TBD'
	Exp_DecryptionKeyInRAM = '0xAB12'
	AfterExecuteSPL_AlgoStatus = 'DISABLED'
	AfterExecuteSPL_WLStatus = 'ON'
	AfterExecuteSPL_SDLSwitchMonitoring = 'NOTMONITORED' 
	BeforeFire_DeploymentloopStatusInNVM = '0x0000000000000000'
	Read_DismantlerInfo_AfterFire = '00 00 00 00 00 00 00 00 00 00 00 00 07 DE 0B 10'
	AfterFire_DeployementLoopTable = '20'
	AfterFire_DeploymentloopStatusInNVM = '0x0000000000000001'
	ResetAfterFire_DeployementLoopTable = '20'
	Default_DismantlerInfo = '00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00'
	DismantlerInfo_FirstTime = '00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F'
	DismantlerInfo_SecondTime = '0F 0F 0F 0F 0F 0F 0F 0F 0F 0F 0F 0F 0F 0F 0F 0F'
	DismantlerInfo_ThirdTime = '00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F'
	Default_DeploymentloopStatus = '00'
	AfterFire_DeploymentloopStatus = '20'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_ACLSupported;
my $tcpar_VINConfigured;
my $tcpar_TestCondition;
my $tcpar_DismantlerInfoRewritingStrategy;
my $tcpar_ExpResp_DismantlerInfo_FirstWrite;
my $tcpar_ExpResp_DismantlerInfo_SecondWrite;
my $tcpar_ExpResp_DismantlerInfo_AfterWrite;
my $tcpar_Default_DeploymentloopStatusInNVM;
my $tcpar_BeforeExecuteSPL_AlgoStatus;
my $tcpar_BeforeExecuteSPL_WLStatus;
my $tcpar_BeforeExecuteSPL_SDLSwitchMonitoring;
my $tcpar_Exp_DecryptionKeyInRAM;
my $tcpar_AfterExecuteSPL_AlgoStatus;
my $tcpar_AfterExecuteSPL_WLStatus;
my $tcpar_AfterExecuteSPL_SDLSwitchMonitoring;
my $tcpar_BeforeFire_DeploymentloopStatusInNVM;
my $tcpar_Read_DismantlerInfo_AfterFire;
my $tcpar_AfterFire_DeployementLoopTable;
my $tcpar_AfterFire_DeploymentloopStatusInNVM;
my $tcpar_ResetAfterFire_DeployementLoopTable;
my $tcpar_Default_DismantlerInfo;
my $tcpar_DismantlerInfo_FirstTime;
my $tcpar_DismantlerInfo_SecondTime;
my $tcpar_DismantlerInfo_ThirdTime;
my $tcpar_Default_DeploymentloopStatus;
my $tcpar_AfterFire_DeploymentloopStatus;
my $tcpar_SquibName;
my $tcpar_LoopId;
################ global parameter declaration ###################
my $ExecuteSPL_With_Conversion    = '01';
my $ExecuteSPL_Without_Conversion = '00';
my (
	$TP_handle,                           $routineStatusRecord,                  $DisLnStatus_afterDPLactivation,   $Resp_HWDeploymentMethod,               $Resp_NumberOfECUs,                $Resp_ECUAddressInfo,           $Resp_ReadVIN,
	$Resp_ReadDismantlerInfo_Default,     $Resp_ReadDismantlerInfo_AfterRewrite, $Resp_ReadDLT_BeforeSPLActivation, $DPLStatus_NVM_BeforeSPLActivation,     $Algo_Status_BeforeSPLActivation,  $WL_Status_BeforeSPLActivation, $DisposalKey_BeforeSPLActivation,
	$Algo_Status_AfterSPLActivation,      $WL_Status_AfterSPLActivation,         $DisposalKey_AfterSPLActivation,   $Resp_ReadDLT_AfterSPLActivation,       $DPLStatus_NVM_AfterSPLActivation, $Resp_FireSquib_WithACL,        $Resp_WriteDismantlerInfo_AfterFiring,
	$Resp_ReadDismantlerInfo_AfterFiring, $Resp_ReadDLT_AfterFiring,             $AfterFire_DPLStatus_NVM,          $Resp_RequestRoutineResult_AfterFiring, $Resp_ReadDLT_AfterReset,          $DPLStatus_NVM_AfterReset,      $DisLnStatus_beforeDPLactivation,
	$SDL_Status_BeforeSPLActivation,      $SDL_Status_AfterSPLActivation,        $verdict
);

# ------------- Parameters for squib physical fring checking
my $time_transi_record_real;
my $samplingFrequency;
my $memorySize;
my $time_transi_record_expected;
my $lct_Data_href;
my @squibs_Monitored;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose                              = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_ACLSupported                         = S_read_mandatory_testcase_parameter('ACLSupported');
	$tcpar_VINConfigured                        = S_read_mandatory_testcase_parameter('VINConfigured');
	$tcpar_TestCondition                        = S_read_mandatory_testcase_parameter('TestCondition');
	$tcpar_DismantlerInfoRewritingStrategy      = S_read_mandatory_testcase_parameter('DismantlerInfoRewritingStrategy');
	$tcpar_ExpResp_DismantlerInfo_FirstWrite    = S_read_mandatory_testcase_parameter('ExpResp_DismantlerInfo_FirstWrite');
	$tcpar_ExpResp_DismantlerInfo_SecondWrite   = S_read_mandatory_testcase_parameter('ExpResp_DismantlerInfo_SecondWrite');
	$tcpar_ExpResp_DismantlerInfo_AfterWrite    = S_read_mandatory_testcase_parameter('ExpResp_DismantlerInfo_AfterWrite');
	$tcpar_Default_DeploymentloopStatusInNVM    = S_read_mandatory_testcase_parameter('Default_DeploymentloopStatusInNVM');
	$tcpar_BeforeExecuteSPL_AlgoStatus          = S_read_mandatory_testcase_parameter('BeforeExecuteSPL_AlgoStatus');
	$tcpar_BeforeExecuteSPL_WLStatus            = S_read_mandatory_testcase_parameter('BeforeExecuteSPL_WLStatus');
	$tcpar_BeforeExecuteSPL_SDLSwitchMonitoring = S_read_mandatory_testcase_parameter('BeforeExecuteSPL_SDLSwitchMonitoring');
	$tcpar_Exp_DecryptionKeyInRAM               = S_read_mandatory_testcase_parameter('Exp_DecryptionKeyInRAM');
	$tcpar_AfterExecuteSPL_AlgoStatus           = S_read_mandatory_testcase_parameter('AfterExecuteSPL_AlgoStatus');
	$tcpar_AfterExecuteSPL_WLStatus             = S_read_mandatory_testcase_parameter('AfterExecuteSPL_WLStatus');
	$tcpar_AfterExecuteSPL_SDLSwitchMonitoring  = S_read_mandatory_testcase_parameter('AfterExecuteSPL_SDLSwitchMonitoring');
	$tcpar_BeforeFire_DeploymentloopStatusInNVM = S_read_mandatory_testcase_parameter('BeforeFire_DeploymentloopStatusInNVM');
	$tcpar_Read_DismantlerInfo_AfterFire        = S_read_mandatory_testcase_parameter('Read_DismantlerInfo_AfterFire');
	$tcpar_AfterFire_DeployementLoopTable       = S_read_mandatory_testcase_parameter('AfterFire_DeployementLoopTable');
	$tcpar_AfterFire_DeploymentloopStatusInNVM  = S_read_mandatory_testcase_parameter('AfterFire_DeploymentloopStatusInNVM');
	$tcpar_ResetAfterFire_DeployementLoopTable  = S_read_mandatory_testcase_parameter('ResetAfterFire_DeployementLoopTable');
	$tcpar_Default_DismantlerInfo               = S_read_mandatory_testcase_parameter('Default_DismantlerInfo');
	$tcpar_DismantlerInfo_FirstTime             = S_read_mandatory_testcase_parameter('DismantlerInfo_FirstTime');
	$tcpar_DismantlerInfo_SecondTime            = S_read_mandatory_testcase_parameter('DismantlerInfo_SecondTime');
	$tcpar_DismantlerInfo_ThirdTime             = S_read_mandatory_testcase_parameter('DismantlerInfo_ThirdTime');
	$tcpar_Default_DeploymentloopStatus         = S_read_mandatory_testcase_parameter('Default_DeploymentloopStatus');
	$tcpar_AfterFire_DeploymentloopStatus       = S_read_mandatory_testcase_parameter('AfterFire_DeploymentloopStatus');
	$tcpar_SquibName                            = S_read_mandatory_testcase_parameter('SquibName');
	$tcpar_LoopId                               = S_read_mandatory_testcase_parameter('LoopId');

	unless ( $tcpar_LoopId =~ s/0x//i ) {
		S_set_error("Unexpected setting for parameter 'Loop ID'; provide valid values ");
		return 0;
	}

	$routineStatusRecord = $LIFT_PROJECT::Defaults->{"DISPOSAL"}{'RoutineStatusRecord'};

	return 1;
}

sub TC_initialization {
	CA_trace_start();
	S_w2rep("Standard_Preparation");
	GEN_StandardPrepNoFault();

	S_w2rep("Set Addressing Mode");
	GDCOM_set_addressing_mode("disposal");

	S_w2rep("Set ACL connection");
	ACEA_SetACLConnection('Connect');

	S_w2rep("SendTesterPresentCyclically");
	$TP_handle = ACEA_Send_TesterPresent_Cyclically();

	S_w2rep("SetTestCondition");
	if ( $tcpar_TestCondition ne 'NoFlt' or $tcpar_TestCondition ne 'NotSupportedSquib' ) {
		ACEA_SetTestCondition( $tcpar_SquibName, $tcpar_TestCondition );
		PD_ECUlogin();
		S_wait_ms(2000);
		PD_ReadFaultMemory();
	}

	# ------------ used for check physical firing
	if ( $tcpar_TestCondition ne 'NotSupportedSquib' ) {
		S_w2rep("Prepare recorder devices (TRC or LCT)");
		_TransiOrLCT_Preparation();
	}

	return 1;
}

sub TC_stimulation_and_measurement {
	S_teststep( "Read HW deploypemt method\n", 'AUTO_NBR', 'STEP_1' );
	$Resp_HWDeploymentMethod = ACEA_Read_HWDeploymentMethod();

	S_teststep( "Step 2: Read Number of ECU's in the Vehicle'\n ", 'AUTO_NBR', 'STEP_2' );
	$Resp_NumberOfECUs = ACEA_Read_NumberOfPCUs();

	S_teststep( "Step 3: Read address information of ECU \n", 'AUTO_NBR', 'STEP_3' );
	$Resp_ECUAddressInfo = ACEA_Read_ECUAddressInfo();

	if ( $tcpar_VINConfigured eq 'Yes' ) {
		S_teststep( "Step 4: Read VIN\n", 'AUTO_NBR', 'STEP_4' );
		$Resp_ReadVIN = ACEA_Read_VIN();
	}

	S_teststep( "Step 5: Read default dismantler information \n", 'AUTO_NBR', 'STEP_5' );
	$Resp_ReadDismantlerInfo_Default = ACEA_ReadDismantlerInfo();

	S_teststep( "Step 6: write dismantler information for the first time \n", 'AUTO_NBR', 'STEP_6' );
	GDCOM_StartSession('DisposalSession');
	ACEA_WriteDismantlerInfo( $tcpar_DismantlerInfo_FirstTime, $tcpar_ExpResp_DismantlerInfo_FirstWrite, 'NO_EVAL_SWITCH' );

	S_teststep( "Step 7: write dismantler information for the second time\n", 'AUTO_NBR', 'STEP_7' );
	ACEA_WriteDismantlerInfo( $tcpar_DismantlerInfo_SecondTime, $tcpar_ExpResp_DismantlerInfo_SecondWrite, 'NO_EVAL_SWITCH' );

	S_teststep( "Step 8: Read dismantler information after rewriting dismantler information\n", 'AUTO_NBR', 'STEP_8' );
	$Resp_ReadDismantlerInfo_AfterRewrite = ACEA_ReadDismantlerInfo('EVAL_SWITCH');

	S_teststep( "Step 9: Read default deployment loop table\n", 'AUTO_NBR', 'STEP_9' );
	$Resp_ReadDLT_BeforeSPLActivation = ACEA_Read_DiploymentLoopTable();

	S_teststep( "Step 10: Read default loop status from NVM\n", 'AUTO_NBR', 'STEP_10' );
	$DPLStatus_NVM_BeforeSPLActivation = ACEA_ReadDPLStatusNVM();

	S_teststep( "Step 11: Enter into safety system diagnostic session\n", 'AUTO_NBR', 'STEP_11' );
	GDCOM_StartSession('DisposalSession');

	S_teststep( "Step 12: Read Algo status after Entering into safety system diagnostic session\n", 'AUTO_NBR', 'STEP_12' );
	$Algo_Status_BeforeSPLActivation = ACEA_ReadAlgoStatus();
	S_teststep( "Step 13: ReadWL status after Entering into safety system diagnostic session\n", 'AUTO_NBR', 'STEP_13' );
	$WL_Status_BeforeSPLActivation = ACEA_ReadWLStatus();

	S_teststep( "Step 14: Read Default Disposal key stored at RAM\n", 'AUTO_NBR', 'STEP_14' );
	$DisposalKey_BeforeSPLActivation = ACEA_ReadDecryptionKeyInRAM();

	S_teststep( "Step 15: Obtain  security access\n", 'AUTO_NBR', 'STEP_15' );
	ACEA_Get_SecurityAccess();

	S_teststep( "Step 16: Read Disposal key stored at RAM after Activating DPL\n", 'AUTO_NBR', 'STEP_16' );
	$DisposalKey_AfterSPLActivation = ACEA_ReadDecryptionKeyInRAM();

	S_teststep( "Step 17: Execute disposal Program loader \n", 'AUTO_NBR', 'STEP_17' );
	ACEA_ExecuteDisposalProgramLoader( $ExecuteSPL_Without_Conversion, $routineStatusRecord );
	S_wait_ms(3000);
	ACEA_RequestRoutineResults_SPL( $ExecuteSPL_Without_Conversion, $routineStatusRecord );

	S_teststep( "Step 18: Execute disposal Program loader with RAM conversion\n", 'AUTO_NBR', 'STEP_18' );
	ACEA_ExecuteDisposalProgramLoader( $ExecuteSPL_With_Conversion, $routineStatusRecord );
	S_wait_ms(3000);
	ACEA_RequestRoutineResults_SPL( $ExecuteSPL_With_Conversion, $routineStatusRecord );

	S_teststep( "Step 19: Read WL status after Activating DPL\n", 'AUTO_NBR', 'STEP_19' );
	$WL_Status_AfterSPLActivation = ACEA_ReadWLStatus();
	S_teststep( "Step 20: Read Algo status after Entering into safety system diagnostic session\n", 'AUTO_NBR', 'STEP_20' );
	$Algo_Status_AfterSPLActivation = ACEA_ReadAlgoStatus();

	S_teststep( "Step 21: Read deployment loop table after Activating DPL\n", 'AUTO_NBR', 'STEP_21' );
	$Resp_ReadDLT_AfterSPLActivation = ACEA_Read_DiploymentLoopTable();
	S_teststep( "Step 22: Read Deployment loop status from NVM after Activating DPL\n", 'AUTO_NBR', 'STEP_22' );
	$DPLStatus_NVM_AfterSPLActivation = ACEA_ReadDPLStatusNVM();
	S_wait_ms(1000);

	S_teststep( "Step 23: Fire a squib \n", 'AUTO_NBR', 'STEP_23' );
	if ( $tcpar_TestCondition ne 'NotSupportedSquib' ) {
		_TransiOrLCT_Start();    # Start LCT/TRC to log squib physical signals
		$Resp_FireSquib_WithACL = ACEA_FireSquib( $tcpar_LoopId, $tcpar_TestCondition, $routineStatusRecord );
		_TransiOrLCT_StopAndLogData();    # Save squib physical firing data
	}

	S_teststep( "Step 24: Read Fire Counter\n ", 'AUTO_NBR', 'STEP_24' );
	ACEA_FireCounter( $tcpar_TestCondition, $tcpar_SquibName );

	S_teststep( "Step 25: Write dismantler information after each squib fired\n", 'AUTO_NBR', 'STEP_25' );
	$Resp_WriteDismantlerInfo_AfterFiring = ACEA_WriteDismantlerInfo( $tcpar_DismantlerInfo_ThirdTime, $tcpar_ExpResp_DismantlerInfo_AfterWrite, 'NO_EVAL_SWITCH' );

	S_teststep( "Step 26: Read dismantler information after each squib fired\n", 'AUTO_NBR', 'STEP_26' );
	$Resp_ReadDismantlerInfo_AfterFiring = ACEA_ReadDismantlerInfo('NO_EVAL_SWITCH');

	S_teststep( "Step 27: Read deployment loop table after firing the squib\n", 'AUTO_NBR', 'STEP_27' );
	$Resp_ReadDLT_AfterFiring = ACEA_Read_DiploymentLoopTable();
	S_teststep( "Step 28: Read Deployment loop status from NVM after firing the squib\n", 'AUTO_NBR', 'STEP_28' );
	$AfterFire_DPLStatus_NVM = ACEA_ReadDPLStatusNVM();

	S_teststep( "Step 29: Read Request Routine Result after firiing the squib\n", 'AUTO_NBR', 'STEP_29' );
	$Resp_RequestRoutineResult_AfterFiring = ACEA_RequestRoutineResults( $tcpar_LoopId, $tcpar_TestCondition, $routineStatusRecord );

	S_teststep( "Step 30: Reset ECU\n", 'AUTO_NBR', 'STEP_30' );
	GEN_Power_on_Reset();
	PD_ECUlogin();

	S_teststep( "Step 31: Read deployment loop table after Resetting ECU\n", 'AUTO_NBR', 'STEP_31' );
	$Resp_ReadDLT_AfterReset = ACEA_Read_DiploymentLoopTable();
	S_teststep( "Step 32: Read Deployment loop status from NVM after Resetting ECU\n", 'AUTO_NBR', 'STEP_32' );
	$DPLStatus_NVM_AfterReset = ACEA_ReadDPLStatusNVM();
	return 1;
}

sub TC_evaluation {
	S_teststep_expected( "Evaluate HW deploypemt method-Evaluation done at stimulation and measurement(Refer the traces or html report)\n", 'STEP_1' );
	S_teststep_detected( "Evaluate HW deploypemt method-Evaluation done at stimulation and measurement(Refer the traces or html report)\n", 'STEP_1' );
	S_w2rep("Evaluation for Step 1: Evaluate HW deploypemt method-Evaluation done at stimulation and measurement ");

	S_teststep_expected( "Evaluate Number of ECU's in the Vehicle--Evaluation done at stimulation and measurement(Refer the traces or html report)\n", 'STEP_2' );
	S_teststep_detected( "Evaluate Number of ECU's in the Vehicle--Evaluation done at stimulation and measurement(Refer the traces or html report)\n", 'STEP_2' );
	S_w2rep("Evaluation for Step 2: Evaluate Number of ECU's in the Vehicle--Evaluation done at stimulation and measurement");

	S_w2rep("Evaluation for Step 3: Evaluate address information of ECU's--Evaluation done at stimulation and measurement");
	S_teststep_detected( "Evaluate address information of ECU's--Evaluation done at stimulation and measurement(Refer the traces or html report)\n", 'STEP_3' );
	S_teststep_expected( "Evaluate address information of ECU's--Evaluation done at stimulation and measurement(Refer the traces or html report)\n", 'STEP_3' );

	if ( $tcpar_VINConfigured eq 'Yes' ) {
		S_teststep_expected( "Evaluation of VIN done at stimulation and measurement(Refer the traces or html report)\n", 'STEP_4' );
		S_teststep_detected( "Evaluation of VIN done at stimulation and measurement(Refer the traces or html report)\n", 'STEP_4' );
		S_w2rep("Evaluation for Step 4: Evaluation of VIN done at stimulation and measurement");

	}

	S_w2rep("Evaluation for Step 5: Evaluate dismantler information");
	my $Resp_ReadDismantlerInfo = ACEA_ExtractRespDataToBeEvaluated( $Resp_ReadDismantlerInfo_Default, 9 );
	S_teststep_expected( " Expected address information of ECU's is :$tcpar_Default_DismantlerInfo \n", 'STEP_5' );
	$verdict = EVAL_evaluate_string( "Dismantler info Comparison", $tcpar_Default_DismantlerInfo, ACEA_ExtractRespDataToBeEvaluated( $Resp_ReadDismantlerInfo_Default, 9 ) );
	if ( $verdict eq 'VERDICT_PASS' ) {
		S_teststep_detected( "address information of ECU's is:" . $Resp_ReadDismantlerInfo . "\n", 'STEP_5' );
	}

	if ( $verdict eq 'VERDICT_FAIL' ) {
		S_teststep_detected( "MISMATCH: address information of ECU's is:" . $Resp_ReadDismantlerInfo . "\n", 'STEP_5' );
	}

	S_teststep_expected( "Evaluate response for write dismantler information for the first time-Evaluation done at stimulation and measurement(Refer the traces or html report)\n", 'STEP_6' );
	S_teststep_detected( "Evaluate response for write dismantler information for the first time-Evaluation done at stimulation and measurement(Refer the traces or html report)\n", 'STEP_6' );
	S_w2rep("Evaluation for Step 6: Evaluate response for write dismantler information for the first time-Evaluation done at stimulation and measurement");

	S_teststep_expected( "Evaluate response for write dismantler information for the second time-Evaluation done at stimulation and measurement(Refer the traces or html report)\n", 'STEP_7' );
	S_teststep_detected( "Evaluate response for write dismantler information for the second time-Evaluation done at stimulation and measurement(Refer the traces or html report)\n", 'STEP_7' );
	S_w2rep("Evaluation for Step 7: Evaluate response for write dismantler information for the second time-Evaluation done at stimulation and measurement");

	S_w2rep("Evaluation for Step 8: ");
	if ( $tcpar_DismantlerInfoRewritingStrategy eq 'DismantlerInfoNoRewriting' ) {
		my $Response_ReadDismantlerInfo_AfterRewrite = ACEA_ExtractRespDataToBeEvaluated( $Resp_ReadDismantlerInfo_AfterRewrite, 9 );
		S_teststep_expected( " Expected Dismantler information after rewriting is :$tcpar_DismantlerInfo_FirstTime \n", 'STEP_8' );
		$verdict = EVAL_evaluate_string( "Dismantler info Comparison", $tcpar_DismantlerInfo_FirstTime, ACEA_ExtractRespDataToBeEvaluated( $Resp_ReadDismantlerInfo_AfterRewrite, 9 ) );
		if ( $verdict eq 'VERDICT_PASS' ) {
			S_teststep_detected( "Dismantler information after rewriting is:" . $Response_ReadDismantlerInfo_AfterRewrite . "\n", 'STEP_8' );
		}

		if ( $verdict eq 'VERDICT_FAIL' ) {
			S_teststep_detected( "MISMATCH: Dismantler information after rewriting is:" . $Response_ReadDismantlerInfo_AfterRewrite . "\n", 'STEP_8' );
		}
	}
	else {
		my $Response_ReadDismantlerInfo_AfterRewrite = ACEA_ExtractRespDataToBeEvaluated( $Resp_ReadDismantlerInfo_AfterRewrite, 9 );
		S_teststep_expected( " Expected Dismantler information after rewriting is :$tcpar_DismantlerInfo_SecondTime \n", 'STEP_8' );
		$verdict = EVAL_evaluate_string( "Dismantler info Comparison", $tcpar_DismantlerInfo_SecondTime, ACEA_ExtractRespDataToBeEvaluated( $Resp_ReadDismantlerInfo_AfterRewrite, 9 ) );
		if ( $verdict eq 'VERDICT_PASS' ) {
			S_teststep_detected( "Dismantler information after rewriting is:" . $Response_ReadDismantlerInfo_AfterRewrite . "\n", 'STEP_8' );
		}

		if ( $verdict eq 'VERDICT_FAIL' ) {
			S_teststep_detected( "MISMATCH: Dismantler information after rewriting is:" . $Response_ReadDismantlerInfo_AfterRewrite . "\n", 'STEP_8' );
		}
	}

	S_w2rep("Evaluation for Step 9: Read default deployment loop table");
	$Resp_ReadDLT_BeforeSPLActivation = ACEA_ExtractRespDataToBeEvaluated( $Resp_ReadDLT_BeforeSPLActivation, 18 );
	S_teststep_detected( " Detected Loop status is :$Resp_ReadDLT_BeforeSPLActivation \n", 'STEP_9' );
	S_teststep_expected( " Expected Loop status is :$tcpar_Default_DeploymentloopStatus \n", 'STEP_9' );
	ACEA_EvaluateDLTForGivenLoopId( $Resp_ReadDLT_BeforeSPLActivation, $tcpar_Default_DeploymentloopStatus, $tcpar_LoopId, $tcpar_TestCondition );

	S_w2rep("Evaluation for Step 10: Evaluate response for Read default loop status from NVM");
	S_teststep_expected( " Expected loop status from NVM is :$tcpar_Default_DeploymentloopStatusInNVM \n ", 'STEP_10' );
	$verdict = EVAL_evaluate_value( "default loop status from NVM comparison", $DPLStatus_NVM_BeforeSPLActivation, '==', $tcpar_Default_DeploymentloopStatusInNVM );
	if ( $verdict eq 'VERDICT_PASS' ) {
		S_teststep_detected( "loop status from NVM comparison is:" . $DPLStatus_NVM_BeforeSPLActivation . "\n", 'STEP_10' );
	}

	if ( $verdict eq 'VERDICT_FAIL' ) {
		S_teststep_detected( "MISMATCH: loop status from NVM comparison is:" . $DPLStatus_NVM_BeforeSPLActivation . "\n", 'STEP_10' );
	}

	S_teststep_expected( "Evaluate Enter into safety system diagnostic session-Evaluation done at stimulation and measurement(Refer the traces or html report)\n", 'STEP_11' );
	S_teststep_detected( "Evaluate Enter into safety system diagnostic session-Evaluation done at stimulation and measurement(Refer the traces or html report)\n", 'STEP_11' );
	S_w2rep("Evaluation for Step 11: Enter into safety system diagnostic session");

	S_w2rep("Evaluation for Step 12: Evaluate Algo status read after Entering into safety system diagnostic session");
	S_teststep_detected( " Detected Algo status is :$Algo_Status_BeforeSPLActivation \n", 'STEP_12' );
	S_teststep_expected( " Expected Algo status is :$tcpar_BeforeExecuteSPL_AlgoStatus \n", 'STEP_12' );
	ACEA_EvaluateAlgoStatus( $Algo_Status_BeforeSPLActivation, $tcpar_BeforeExecuteSPL_AlgoStatus );

	S_w2rep("Evaluation for Step 13: Evaluate WL status read after Entering into safety system diagnostic session");
	S_teststep_detected( " Detected WL status is :$WL_Status_BeforeSPLActivation \n", 'STEP_13' );
	S_teststep_expected( " Expected WL status is :$tcpar_BeforeExecuteSPL_WLStatus \n", 'STEP_13' );
	ACEA_EvaluateWLStatus( $WL_Status_BeforeSPLActivation, $tcpar_BeforeExecuteSPL_WLStatus );

	S_w2rep("Evaluation for Step 14: Evaluate Default Disposal key stored at RAM - Not required");

	#	S_teststep_expected(" Expected Disposal key is :$tcpar_Exp_DecryptionKeyInRAM \n",'STEP_14');
	#	$verdict = EVAL_evaluate_value("Default Disposal key after security access", $DisposalKey_BeforeSPLActivation, '==',$tcpar_Exp_DecryptionKeyInRAM);
	#	if($verdict eq 'VERDICT_PASS' )
	#	{
	#		S_teststep_detected( "Disposal key is:" . $DisposalKey_BeforeSPLActivation . "\n",'STEP_14');
	#	}
	#
	#	if($verdict eq 'VERDICT_FAIL' )
	#	{
	#		S_teststep_detected( "MISMATCH: Disposal key is:" . $DisposalKey_BeforeSPLActivation . "\n" ,'STEP_14');
	#	}

	S_teststep_expected( "Evaluate response for Security Access done at stimulation and measurement(Refer the traces or html report)\n", 'STEP_15' );
	S_teststep_detected( "Evaluate response for Security Access done at stimulation and measurement(Refer the traces or html report)\n", 'STEP_15' );
	S_w2rep("Evaluation for Step 15: Evaluate response for Security Access done at stimulation and measurement");

	S_w2rep("Evaluation for Step 16: Evaluate Disposal key stored at RAM read after Activating DPL");
	S_teststep_expected( " Expected Disposal key is :$tcpar_Exp_DecryptionKeyInRAM \n ", 'STEP_16' );
	$verdict = EVAL_evaluate_value( " Disposal key in RAM after SPL", $DisposalKey_AfterSPLActivation, '==', hex($tcpar_Exp_DecryptionKeyInRAM) );
	if ( $verdict eq 'VERDICT_PASS' ) {
		S_teststep_detected( "Disposal key in RAM after SPL is:" . $DisposalKey_AfterSPLActivation . "\n", 'STEP_16' );
	}

	if ( $verdict eq 'VERDICT_FAIL' ) {
		S_teststep_detected( "MISMATCH: Disposal key in RAM after SPL is:" . $DisposalKey_AfterSPLActivation . "\n", 'STEP_16' );
	}

	S_teststep_expected( "Evaluate for Disposal Program loader without RAM conversion done at stimulation and measurement(Refer the traces or html report)\n", 'STEP_17' );
	S_teststep_detected( "Evaluate for Disposal Program loader without RAM conversion done at stimulation and measurement(Refer the traces or html report)\n", 'STEP_17' );
	S_w2rep("Evaluation for Step 17: Evaluate for Disposal Program loader without RAM conversion done at stimulation and measurement");

	S_teststep_expected( "Evaluate for Disposal Program loader with RAM conversion done at stimulation and measurement(Refer the traces or html report)\n", 'STEP_18' );
	S_teststep_detected( "Evaluate for Disposal Program loader with RAM conversion done at stimulation and measurement(Refer the traces or html report)\n", 'STEP_18' );
	S_w2rep("Evaluation for Step 18: Evaluate for Disposal Program loader with RAM conversion done at stimulation and measurement");

	S_w2rep("Evaluation for Step 19: Evaluate Algo status read after Activating DPL");
	S_teststep_detected( " Detected Algo status after DPL activation is :$Algo_Status_AfterSPLActivation \n", 'STEP_19' );
	S_teststep_expected( " Expected Algo status after DPL activation is :$tcpar_AfterExecuteSPL_AlgoStatus\n ", 'STEP_19' );
	ACEA_EvaluateAlgoStatus( $Algo_Status_AfterSPLActivation, $tcpar_AfterExecuteSPL_AlgoStatus );

	S_w2rep("Evaluation for Step 20: Evaluate WL status read after Activating DPL");
	S_teststep_detected( " Detected WL status after DPL activation is :$WL_Status_AfterSPLActivation \n", 'STEP_20' );
	S_teststep_expected( " Expected WL status after DPL activation is :$tcpar_AfterExecuteSPL_WLStatus \n", 'STEP_20' );
	ACEA_EvaluateWLStatus( $WL_Status_AfterSPLActivation, $tcpar_AfterExecuteSPL_WLStatus );

	S_w2rep("Evaluation for Step 21: Evaluate deployment loop table after Activating DPL");
	$Resp_ReadDLT_AfterSPLActivation = ACEA_ExtractRespDataToBeEvaluated( $Resp_ReadDLT_AfterSPLActivation, 18 );
	S_teststep_detected( " Detected deployment loop table after Activating DPL is :$Resp_ReadDLT_AfterSPLActivation \n", 'STEP_21' );
	S_teststep_expected( " Expected deployment loop table after Activating DPL is :$tcpar_Default_DeploymentloopStatus \n", 'STEP_21' );
	ACEA_EvaluateDLTForGivenLoopId( $Resp_ReadDLT_AfterSPLActivation, $tcpar_Default_DeploymentloopStatus, $tcpar_LoopId, $tcpar_TestCondition );

	S_w2rep("Evaluation for Step 22: Evaluate Deployment loop status from NVM read before Firing the squib");
	S_teststep_expected( " Evaluate Deployment loop status from NVM read before Firing the squib is :$tcpar_BeforeFire_DeploymentloopStatusInNVM \n", 'STEP_22' );
	$verdict = EVAL_evaluate_value( "Deployment loop status from NVM before SPL", $DPLStatus_NVM_AfterSPLActivation, '==', $tcpar_BeforeFire_DeploymentloopStatusInNVM );
	if ( $verdict eq 'VERDICT_PASS' ) {
		S_teststep_detected( "Deployment loop status from NVM read before Firing the squib is:" . $DPLStatus_NVM_AfterSPLActivation . "\n", 'STEP_22' );
	}

	if ( $verdict eq 'VERDICT_FAIL' ) {
		S_teststep_detected( "MISMATCH: Deployment loop status from NVM read before Firing the squib is:" . $DPLStatus_NVM_AfterSPLActivation . "\n", 'STEP_22' );
	}

	S_w2rep("Evaluation for Step 23: Evaluate response for Fire a squib");
	if ( $tcpar_TestCondition ne "NotSupportedSquib" ) {
		my $Resp_FireSquib_WithACL = ACEA_ExtractRespDataToBeEvaluated( $Resp_FireSquib_WithACL, 18 );
		S_teststep_expected( " Expected Squib Firing is :$tcpar_AfterFire_DeploymentloopStatus \n", 'STEP_23' );
		$verdict = EVAL_evaluate_string( "DLS after fire", $tcpar_AfterFire_DeploymentloopStatus, $Resp_FireSquib_WithACL );
		if ( $verdict eq 'VERDICT_PASS' ) {
			S_teststep_detected( "Squib Firing is:" . $Resp_FireSquib_WithACL . "\n", 'STEP_23' );
		}

		if ( $verdict eq 'VERDICT_FAIL' ) {
			S_teststep_detected( "MISMATCH: Squib Firing is:" . $Resp_FireSquib_WithACL . "\n", 'STEP_23' );
		}
		if ( $tcpar_TestCondition ne 'NotSupportedSquib' ) {
			_Evaluate_SquibPhysicalFiring();
		}
	}
	else {
		S_w2rep( "Evaluation done at stimulation and measurement", 'STEP_23' );
	}

	S_teststep_expected( "Evaluate response for FireCounter done at stimulation and measurement(Refer the traces or html report)\n", 'STEP_24' );
	S_teststep_detected( "Evaluate response for FireCounter done at stimulation and measurement(Refer the traces or html report)\n", 'STEP_24' );
	S_w2rep("Evaluation for Step 24: Evaluate response for FireCounter done at stimulation and measurement ");

	S_w2rep("Evaluation for Step 25: Evaluate Write Dismantler info after fire:-Evaluation done at Stimulation and measurement");
	S_teststep_expected( "Evaluate Write dismantler information after each squib fired:-Evaluation done at Stimulation and measurement(Refer the traces or html report)\n", 'STEP_25' );
	S_teststep_detected( "Evaluate Write dismantler information after each squib fired:-Evaluation done at Stimulation and measurement(Refer the traces or html report)\n", 'STEP_25' );

	S_w2rep("Evaluation for Step 26: Evaluate response for Read dismantler information after first squib fired");
	$Resp_ReadDismantlerInfo_AfterFiring = ACEA_ExtractRespDataToBeEvaluated( $Resp_ReadDismantlerInfo_AfterFiring, 9 );
	if ( $tcpar_DismantlerInfoRewritingStrategy eq 'DismantlerInfoNoRewriting' ) {
		S_teststep_expected( " Expected dismantler information after first squib fired is :$tcpar_DismantlerInfo_FirstTime \n", 'STEP_26' );
		$verdict = EVAL_evaluate_string( "Dismantler info after firing", $tcpar_DismantlerInfo_FirstTime, $Resp_ReadDismantlerInfo_AfterFiring );
		if ( $verdict eq 'VERDICT_PASS' ) {
			S_teststep_detected( "dismantler information after first squib fired is:" . $Resp_ReadDismantlerInfo_AfterFiring . "\n", 'STEP_26' );
		}

		if ( $verdict eq 'VERDICT_FAIL' ) {
			S_teststep_detected( "MISMATCH: dismantler information after first squib fired is:" . $Resp_ReadDismantlerInfo_AfterFiring . "\n", 'STEP_26' );
		}
	}
	else {
		if ( ( $tcpar_TestCondition eq "NotSupportedSquib" ) || ( $tcpar_TestCondition eq "NoCfgSqOpen" ) || ( $tcpar_TestCondition eq "OpenFlt" ) || ( $tcpar_TestCondition eq "CfgFlt" ) ) {
			S_teststep_expected( " Expected dismantler information after first squib fired is :$tcpar_DismantlerInfo_ThirdTime \n", 'STEP_26' );
			$verdict = EVAL_evaluate_string( "Dismantler info after firing", $tcpar_DismantlerInfo_ThirdTime, $Resp_ReadDismantlerInfo_AfterFiring );
			if ( $verdict eq 'VERDICT_PASS' ) {
				S_teststep_detected( "dismantler information after first squib fired is:" . $Resp_ReadDismantlerInfo_AfterFiring . "\n", 'STEP_26' );
			}

			if ( $verdict eq 'VERDICT_FAIL' ) {
				S_teststep_detected( "MISMATCH: dismantler information after first squib fired is:" . $Resp_ReadDismantlerInfo_AfterFiring . "\n", 'STEP_26' );
			}

		}
		else {
			S_teststep_expected( " Expected dismantler information after first squib fired is :$tcpar_Read_DismantlerInfo_AfterFire \n", 'STEP_26' );
			$verdict = EVAL_evaluate_string( "Dismantler info after firing", $tcpar_Read_DismantlerInfo_AfterFire, $Resp_ReadDismantlerInfo_AfterFiring );
			if ( $verdict eq 'VERDICT_PASS' ) {
				S_teststep_detected( "dismantler information after first squib fired is:" . $Resp_ReadDismantlerInfo_AfterFiring . "\n", 'STEP_26' );
			}

			if ( $verdict eq 'VERDICT_FAIL' ) {
				S_teststep_detected( "MISMATCH: dismantler information after first squib fired is:" . $Resp_ReadDismantlerInfo_AfterFiring . "\n", 'STEP_26' );
			}
		}
	}

	S_w2rep("Evaluation for Step 27: Reading deployment loop table after firing the squib");
	$Resp_ReadDLT_AfterFiring = ACEA_ExtractRespDataToBeEvaluated( $Resp_ReadDLT_AfterFiring, 18 );
	S_teststep_detected( " Detected deployment loop table after firing the squib is :$Resp_ReadDLT_AfterFiring \n", 'STEP_27' );
	S_teststep_expected( " Expected deployment loop table after firing the squib is :$tcpar_AfterFire_DeployementLoopTable\n ", 'STEP_27' );
	ACEA_EvaluateDLTForGivenLoopId( $Resp_ReadDLT_AfterFiring, $tcpar_AfterFire_DeployementLoopTable, $tcpar_LoopId, $tcpar_TestCondition );

	S_w2rep("Evaluation for Step 28: Evaluate Deployment loop status from NVM read after firing the squib");
	if ( ( $tcpar_TestCondition eq "NotSupportedSquib" ) || ( $tcpar_TestCondition eq "NoCfgSqOpen" ) || ( $tcpar_TestCondition eq "OpenFlt" ) || ( $tcpar_TestCondition eq "CfgFlt" ) ) {
		S_teststep_expected( " DLS after fire is :$DPLStatus_NVM_BeforeSPLActivation\n ", 'STEP_28' );
		$verdict = EVAL_evaluate_value( "DLS after fire", $AfterFire_DPLStatus_NVM, '==', $DPLStatus_NVM_BeforeSPLActivation );
		if ( $verdict eq 'VERDICT_PASS' ) {
			S_teststep_detected( "DLS after fire:" . $AfterFire_DPLStatus_NVM . "\n", 'STEP_28' );
		}

		if ( $verdict eq 'VERDICT_FAIL' ) {
			S_teststep_detected( "MISMATCH: DLS after fire:" . $AfterFire_DPLStatus_NVM . "\n", 'STEP_28' );
		}
	}
	else {
		S_teststep_expected( " DLS after fire is :$DPLStatus_NVM_BeforeSPLActivation\n ", 'STEP_28' );
		$verdict = EVAL_evaluate_value( "DLS after fire", $AfterFire_DPLStatus_NVM, '!=', $DPLStatus_NVM_BeforeSPLActivation );
		if ( $verdict eq 'VERDICT_PASS' ) {
			S_teststep_detected( "DLS after fire:" . $AfterFire_DPLStatus_NVM . "\n", 'STEP_28' );
		}

		if ( $verdict eq 'VERDICT_FAIL' ) {
			S_teststep_detected( "MISMATCH: DLS after fire:" . $AfterFire_DPLStatus_NVM . "\n", 'STEP_28' );
		}
	}

	S_w2rep("Evaluation for Step 29: Evaluate Request Routine Result read after firiing the squib");
	if ( $tcpar_TestCondition ne "NotSupportedSquib" ) {
		my $Resp_RequestRoutineResult_AfterFiring = ACEA_ExtractRespDataToBeEvaluated( $Resp_RequestRoutineResult_AfterFiring, 18 );
		S_teststep_expected( " Expected Routine result after fire is :$tcpar_AfterFire_DeploymentloopStatus \n", 'STEP_29' );
		$verdict = EVAL_evaluate_string( "Routine result after fire", $tcpar_AfterFire_DeploymentloopStatus, $Resp_RequestRoutineResult_AfterFiring );
		if ( $verdict eq 'VERDICT_PASS' ) {
			S_teststep_detected( "Detected Routine result after fire is:" . $Resp_RequestRoutineResult_AfterFiring . "\n", 'STEP_29' );
		}

		if ( $verdict eq 'VERDICT_FAIL' ) {
			S_teststep_detected( "MISMATCH: Detected Routine result after fire is:" . $Resp_RequestRoutineResult_AfterFiring . "\n", 'STEP_29' );
		}

	}
	else {
		S_w2rep("Evaluation done at stimulation and measurement");
	}

	S_w2rep("Evaluation for Step 30: Evaluate Reset ECU:-Evaluation done at Stimulation and measurement");
	S_teststep_expected( "Evaluate Reset ECU:-Evaluation done at Stimulation and measurement(Refer the traces or html report)\n", 'STEP_30' );
	S_teststep_detected( "Evaluate Reset ECU:-Evaluation done at Stimulation and measurement(Refer the traces or html report)\n", 'STEP_30' );

	S_w2rep("Evaluation for Step 31: Evaluate deployment loop table read after Restarting ECU.");
	$Resp_ReadDLT_AfterReset = ACEA_ExtractRespDataToBeEvaluated( $Resp_ReadDLT_AfterReset, 18 );
	S_teststep_detected( " Detected deployment loop table read after Restarting ECU is :$Resp_ReadDLT_AfterReset \n", 'STEP_31' );
	S_teststep_expected( " Expected deployment loop table read after Restarting ECU is :$tcpar_ResetAfterFire_DeployementLoopTable\n ", 'STEP_31' );
	ACEA_EvaluateDLTForGivenLoopId( $Resp_ReadDLT_AfterReset, $tcpar_ResetAfterFire_DeployementLoopTable, $tcpar_LoopId, $tcpar_TestCondition );

	S_w2rep("Evaluation for Step 32: Evaluate Deployment loop status from NVM read after Restarting ECU.");
	if ( ( $tcpar_TestCondition eq "NotSupportedSquib" ) || ( $tcpar_TestCondition eq "NoCfgSqOpen" ) || ( $tcpar_TestCondition eq "OpenFlt" ) || ( $tcpar_TestCondition eq "CfgFlt" ) ) {
		S_teststep_expected( " Expected DLS after reset is :$DPLStatus_NVM_BeforeSPLActivation\n ", 'STEP_32' );
		$verdict = EVAL_evaluate_value( "DLS after reset ", $DPLStatus_NVM_AfterReset, '==', $DPLStatus_NVM_BeforeSPLActivation );
		if ( $verdict eq 'VERDICT_PASS' ) {
			S_teststep_detected( "Detected DLS after reset is:" . $DPLStatus_NVM_AfterReset . "\n", 'STEP_32' );
		}

		if ( $verdict eq 'VERDICT_FAIL' ) {
			S_teststep_detected( "MISMATCH: DLS after reset is:" . $DPLStatus_NVM_AfterReset . "\n", 'STEP_32' );
		}
	}
	else {
		S_teststep_expected( " Expected DLS after reset is :$DPLStatus_NVM_BeforeSPLActivation\n ", 'STEP_32' );
		$verdict = EVAL_evaluate_value( "DLS after reset ", $DPLStatus_NVM_AfterReset, '!=', $DPLStatus_NVM_BeforeSPLActivation );
		if ( $verdict eq 'VERDICT_PASS' ) {
			S_teststep_detected( "Detected DLS after reset is:" . $DPLStatus_NVM_AfterReset . "\n", 'STEP_32' );
		}

		if ( $verdict eq 'VERDICT_FAIL' ) {
			S_teststep_detected( "MISMATCH: DLS after reset is:" . $DPLStatus_NVM_AfterReset . "\n", 'STEP_32' );
		}
	}

	return 1;
}

#----------- Evaluate squib physical firing
sub _Evaluate_SquibPhysicalFiring {
	my $fault_eval_table1 = new HTML::Table();
	$fault_eval_table1->setCaption("Squib Physical Firing Result");
	$fault_eval_table1->addRow( 'Squib Name', 'Firing is Expected?', 'Firing is Detected?', 'Verdict' );
	$fault_eval_table1->setRowBGColor( 1, "#E2E8EE" );
	$fault_eval_table1->setBorder( [1] );
	my @tableContents;
	my @squib_NotFired;
	my @squib_Fired;
	my $row_Num = 1;
	my $veridct;

	foreach my $squib (@squibs_Monitored) {
		next if $squib =~ /Gnd/i;    #skip GndOffset
		my ( $number_pulse, $pulses_href ) = EVAL_get_signal_pulses_NOHTML( $lct_Data_href, $squib, 0.5, 0, 'rising' );

		if ( $number_pulse >= 1 ) {
			if ( ( $squib =~ /$tcpar_SquibName/i ) and ( $tcpar_TestCondition =~ /NoFlt|S2GFlt|S2BFlt|ShortFlt|CCFlt|HighSideFlt|LowSideFlt|SQMRefTooHighFlt|SQMRefTooLowFlt/i ) ) {
				@tableContents = ( $squib, 'Yes', 'Yes', 'Pass' );
				$fault_eval_table1->addRow(@tableContents);
				$fault_eval_table1->setRowBGColor( ++$row_Num, "green" );
				push( @squib_Fired, $squib );
			}
			else {
				@tableContents = ( $squib, 'No', 'Yes', 'Fail' );
				$veridct = 'Fail';
				$fault_eval_table1->addRow(@tableContents);
				$fault_eval_table1->setRowBGColor( ++$row_Num, "red" );
				push( @squib_NotFired, $squib );
			}
		}
		elsif ( $number_pulse == 0 ) {
			if ( ( $squib =~ /$tcpar_SquibName/i ) and ( $tcpar_TestCondition =~ /NoFlt|S2GFlt|S2BFlt|ShortFlt|CCFlt|HighSideFlt|LowSideFlt|SQMRefTooHighFlt|SQMRefTooLowFlt/i ) ) {
				@tableContents = ( $squib, 'Yes', 'No', 'Fail' );
				$veridct = 'Fail';
				$fault_eval_table1->addRow(@tableContents);
				$fault_eval_table1->setRowBGColor( ++$row_Num, "red" );
				push( @squib_Fired, $squib );
			}
			else {
				@tableContents = ( $squib, 'No', 'No', 'Pass' );
				$fault_eval_table1->addRow(@tableContents);
				$fault_eval_table1->setRowBGColor( ++$row_Num, "green" );
				push( @squib_NotFired, $squib );
			}
		}
	}

	push( @TC_HTML_TEXT, $fault_eval_table1 );

	# For TR purpose
	if ( $tcpar_TestCondition =~ /NoFlt|S2GFlt|S2BFlt|ShortFlt|CCFlt|HighSideFlt|LowSideFlt|SQMRefTooHighFlt|SQMRefTooLowFlt/i ) {
		S_teststep_expected("Only squib '$tcpar_SquibName' should be deployed physically, other squibs should not be deployed.");
		S_teststep_detected("Squibs '@squib_Fired ' are deployed physically, and squibs '@squib_NotFired ' are not deployed physically");
	}
	else {
		S_teststep_expected("No Squibs should be firing");
		S_teststep_detected("Squibs '@squib_Fired ' are deployed physically");
	}
	S_set_verdict(VERDICT_FAIL) if ( $veridct eq 'Fail' );
	S_set_verdict(VERDICT_PASS) if ( $veridct ne 'Fail' );

	return 1;
}

sub TC_finalization {

	ACEA_ResetTestCondition( $tcpar_SquibName, $tcpar_TestCondition );
	ACEA_Stop_TesterPresent($TP_handle);
	S_wait_ms(2000);
	GEN_Power_on_Reset();
	GEN_AutoECUFlash();
	PD_ECUlogin();
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}

sub _TransiOrLCT_Preparation {
	my $flag_SquibValid;
	@squibs_Monitored = LC_Get_names( 'SQUIBS', 'connected' );
	S_w2rep("Monitored squibs are: '@squibs_Monitored '");
	foreach my $squib (@squibs_Monitored) {
		if ( $squib =~ /$tcpar_SquibName/i ) {
			$flag_SquibValid = 1;
			last;
		}
	}
	unless ( defined $flag_SquibValid ) {
		S_set_error("parameter 'SquibName'($tcpar_SquibName) should be one of the squib names in Mapping_Devices!!!");
		return 0;
	}

	#--- Set default record time
	$time_transi_record_real = DEFAULT_TRANSI_LOGTIME;

	#--- Extral handling for TRC
	unless ( FL_GetConfiguredDevice( 'labcar', 'measure_trace_digital' ) =~ /LCT/i ) {
		$time_transi_record_expected = 3000;                                                                             #ms
		$samplingFrequency           = 2 * 1000;                                                                         #2k HZ
		$memorySize                  = ( $samplingFrequency / 1000 ) * ( $time_transi_record_expected / 1000 ) * 1024;
		$time_transi_record_real     = int( $memorySize / $samplingFrequency ) + 2;                                      #2 more seconds for HW buffer
		foreach my $label (@squibs_Monitored) {
			$label .= '::current';
		}
		LC_ResetTRCscanner();
		LC_SetTRCscanner( \@squibs_Monitored, { 'SignalMode' => 'differential', 'VoltageRange' => 10, 'CouplingMode' => 'DC' } );
		LC_ConfigureTRCchannels( { 'SamplingFrequency' => $samplingFrequency, 'MemorySize' => $memorySize, 'TriggerDelay' => 0 } );
	}

	#--- Mandatory step: Config threshold for digital measurement
	LC_MeasureTraceDigitalConfigureThresholds( \@squibs_Monitored, THRESHOLD_SQUIB_FIRING );

	return 1;
}

sub _TransiOrLCT_Start {
	LC_MeasureTraceDigitalStart();
	S_wait_ms(1000);
	LC_MeasureTraceDigitalSendSWTrigger();

	return 1;
}

sub _TransiOrLCT_StopAndLogData {
	my $tc_name = $main::CURRENT_TC;
	$tc_name =~ s/\./-/g;
	my $file_name = $main::REPORT_PATH . "/" . $tc_name;

	#--- Get recorde data and store it as evidence
	S_wait_ms( $time_transi_record_real * 1000 );
	$lct_Data_href = LC_MeasureTraceDigitalGetValues( \@squibs_Monitored );
	my $dump_Name = ( split '-', $tc_name )[1];
	S_dump2pmFile(
		"VariableToDump" => $lct_Data_href,
		"VariableName"   => "TansiData",
		"PackageName"    => "TansiData\_$dump_Name",
		"StoragePath"    => "$main::REPORT_PATH/"
	);

	#--- store .unv format data
	my $unvFile = $file_name . "_original.txt.unv";
	LC_MeasureTraceDigitalPlotValues($unvFile);
	GEN_printLink($unvFile);

	LC_MeasureTraceDigitalStop();

	return 1;
}

1;
