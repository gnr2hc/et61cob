#### TEST CASE MODULE
package TC_DIS_InvalidKey;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DISP_Disposal
#TS version in DOORS: 3.93
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
use GENERIC_DCOM;
use LIFT_labcar;

##################################

our $PURPOSE = "Checking NRC35 for Supported Diagnostic Services for ACEA";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DIS_InvalidKey

=head1 PURPOSE

Checking NRC35 for Supported Diagnostic Services for ACEA

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation

 
I<B<Stimulation and Measurement>>

1. Set the <address_mode>

2. Send <Request>

Note : Dependent services to be sent before <Request>


I<B<Evaluation>>

1. 

2. Expected <Response>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => Purpose of the test case
	SCALAR 'address_mode' => Addressing mode to be set
	SCALAR 'Response' => NRC response to be obtained
	SCALAR 'Request' => Request to be sent
	SCALAR 'Service' => Service for which request to be sent

=head2 PARAMETER EXAMPLES

	purpose  = 'Checking NRC's for Supported Diagnostic Services for ACEA '
	address_mode = 'Disposal'
	Response = 'NR_invalidKey'
	Request = SecurityAccess_CD_SendKey
	Service = SecurityAccess

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_address_mode;
my $tcpar_Response;
my $tcpar_Request;
my $tcpar_Service;

################ global parameter declaration ###################
my ( $TP_handle, $Seed, $Key, $Complete_Request, $NRCInfo );
my @Seed_Array;
my %Temp;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose      = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_address_mode = S_read_mandatory_testcase_parameter('address_mode');
	$tcpar_Response     = S_read_mandatory_testcase_parameter('Response');
	$tcpar_Request      = S_read_mandatory_testcase_parameter('Request');
	$tcpar_Service      = S_read_mandatory_testcase_parameter('Service');

	return 1;
}

sub TC_initialization {

	S_w2rep("Standard_Preparation");
	GEN_StandardPrepNoFault();

	S_w2rep("Send Tester Present Cyclically");
	$TP_handle = ACEA_Send_TesterPresent_Cyclically();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Set the '$tcpar_address_mode'", 'AUTO_NBR', 'STEP_1' );
	GDCOM_set_addressing_mode($tcpar_address_mode);

	S_teststep( "Send '$tcpar_Request'", 'AUTO_NBR', 'STEP_2' );
	GDCOM_StartSession('DisposalSession');
	$Seed             = ACEA_RequestSeed();
	@Seed_Array       = split( ' ', $Seed );
	$Key              = $Seed_Array[2] . ' ' . $Seed_Array[3];
	$Temp{'Key'}      = $Key;
	$Complete_Request = GDCOM_getRequestLabelValue( "REQ_$tcpar_Request", \%Temp );
	$NRCInfo          = GDCOM_getNRCfromMapping( $tcpar_Service, $tcpar_Response );
	GDCOM_request( $Complete_Request, $NRCInfo->{'Response'}, $NRCInfo->{'Mode'}, $NRCInfo->{'Desc'} );
	return 1;
}

sub TC_evaluation {

	S_teststep_expected( "No Evaluation\n", 'STEP_1' );
	S_teststep_detected( "No Evaluation\n", 'STEP_1' );

	S_teststep_expected( "Evaluation for Request and Response Refer the html report or traces \n", 'STEP_2' );
	S_teststep_detected( "Evaluation for Request and Response Refer the html report or traces \n", 'STEP_2' );

	return 1;
}

sub TC_finalization {

	ACEA_Stop_TesterPresent($TP_handle);
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	return 1;
}

1;
