# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_PSI_DoorSlamBehaviour;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on various TS: e.g. AB12_TS_Feature_Peripheral_Sensor_Interface
#TS version in DOORS:                e.g. 5.10
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_FaultMemory;
use LIFT_TEMPERATURE;
use LIFT_PSI5_access;
use LIFT_evaluation;
use FuncLib_TNT_GEN;
##################################

our $PURPOSE = "test that a door slam signal does not lead to a fault";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PSI_ConstantLevel 

=head1 PURPOSE

 test that a door slam signal does not lead to a fault

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

	'TIMER_ECU_FAULT_QUALIFICATION'
	'TIMER_ECU_READY'
	'TIMER_ECU_OFF'
	'U_BATT_DEFAULT'
    Ubat
    Pin
    FLTmand
 
    [initialisation]
    get temperature
    UZ on with U_batt_default
    clear fault memory

    [stimulation & measurement]
    set Ubat
    send sensor data defect for 400ms
    send sensor data ok
    wait for fault qualification time
    read fault memory afterwards

    [evaluation]
    check if fault memory is empty

    [finalisation]
    switch ECU off


=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'ubat'        --> battery voltage value
    SCALAR 'pin'  		 --> peripheral sensor pin
    LIST   'FLTmand'     --> list of mandatory faults (logical names)
    LIST   'FLTopt'      --> list of optional faults (logical names)
    
=head2 PARAMETER EXAMPLES

    [TC_PSI_DoorSlamBehaviour.PASFD]
    purpose='Checking_DoorSlamBehaviour_PASFD' 
    Ubat=14.1 
    Pin = 'PASFD'
    FLTmand = @()
    
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my ( $fltmemBosch1, $fltmemPrimary1 );

my ( $tcpar_ubat, $tcpar_pin, $tcpar_psi_line, $tcpar_FLTmand, $tcpar_FLTopt, $tcpar_faultTime_ms );
my ($reboot_counter);
my @temperatures = ();

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_ubat         = S_read_mandatory_testcase_parameter('Ubat');
	$tcpar_pin          = S_read_mandatory_testcase_parameter('Pin');
	$tcpar_FLTmand      = S_read_mandatory_testcase_parameter('FLTmand');
	$tcpar_FLTopt       = S_read_optional_testcase_parameter('FLTopt');
	$tcpar_faultTime_ms = S_read_optional_testcase_parameter( 'FaultTime', 'byref', '2000' );

	$tcpar_psi_line = S_get_contents_of_hash( [ 'PSI5_SENSORS_PROJECT', $tcpar_pin, 'LINE' ] );

	S_get_contents_of_hash( [ 'VEHICLE', 'U_BATT_DEFAULT' ] );
	S_get_contents_of_hash( [ 'TIMER',   'TIMER_ECU_FAULT_QUALIFICATION' ] );
	S_get_contents_of_hash( [ 'TIMER',   'TIMER_ECU_READY' ] );
	S_get_contents_of_hash( [ 'TIMER',   'TIMER_ECU_OFF' ] );

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	push( @temperatures, TEMP_get_temperature() );
	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	S_teststep( 'Reset all reboot counter.', 'AUTO_NBR' );
	my $status = PSI5_reset_reboot_counter('ALL');
	PSI5_get_reboot_counter($tcpar_psi_line);

	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);
	S_wait_ms(1000);

	S_teststep( "Send sensor defect for $tcpar_pin for $tcpar_faultTime_ms ms", 'AUTO_NBR' );
	PSI5_set_Sensor_Defect($tcpar_pin);
	S_wait_ms($tcpar_faultTime_ms);

	S_teststep( "Remove fault for $tcpar_pin", 'AUTO_NBR' );
	PSI5_sensor_reinit($tcpar_pin);

	S_teststep( 'Read fault recorder', 'AUTO_NBR' );
	$fltmemBosch1   = LIFT_FaultMemory->read_fault_memory('Bosch');
	$fltmemPrimary1 = LIFT_FaultMemory->read_fault_memory('Primary');
	S_teststep( 'Evaluate fault recorder', 'AUTO_NBR', 'Fault' );

	S_teststep( "Read reboot counter of $tcpar_pin on line $tcpar_psi_line", 'AUTO_NBR' );
	$reboot_counter = PSI5_get_reboot_counter($tcpar_psi_line);
	S_teststep( 'Evaluate reboot counter', 'AUTO_NBR', 'Counter' );

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	my $expectedFaults1_href;

	S_teststep_expected( 'Expected faults:', 'Fault' );
	foreach my $fault (@$tcpar_FLTmand) {
		S_teststep_expected($fault);
	}

	$expectedFaults1_href = {
		'mandatory'   => $tcpar_FLTmand,
		'disjunction' => [],
		'optional'    => $tcpar_FLTopt,
	};

	$fltmemBosch1->evaluate_faults( $expectedFaults1_href, 'Fault' );
	$fltmemPrimary1->evaluate_faults( $expectedFaults1_href, 'Fault' );

	S_teststep_expected( "Reboot Counter >= 1", 'Counter' );
	S_teststep_detected( "Reboot Counter = '$reboot_counter'", 'Counter' );
	EVAL_evaluate_value( "Reboot Counter", $reboot_counter, '>=', 1 );

	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep_detected( "TEMP: " . join( ' -> ', @temperatures ) );
	S_teststep_detected("UBat: $tcpar_ubat V");

	return 1;
}

1;

__END__
