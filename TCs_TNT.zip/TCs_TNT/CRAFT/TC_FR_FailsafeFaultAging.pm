# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_FR_FailsafeFaultAging;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Fault_Recording
#TS version in DOORS: 1.5
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;

#use LIFT_PD;
use LIFT_ProdDiag;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use FuncLib_TNT_GEN;
use LIFT_FaultMemory;
use FuncLib_SYC_INTERFACE;
##################################

our $PURPOSE = " check that for an internal failsafe fault the aging mechanism is working ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_FR_FailsafeFaultAging 

=head1 PURPOSE

 check that for an internal failsafe fault the aging mechanism is working

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

    Ubat

    [initialisation]
    switch ECU on
    clear fault memory
    switch ECU off
    get temperature

    [stimulation & measurement]
	switch ECU on
	qualify failsafe fault
	dequalify failsafe fault
	repeat step 2 - 3 for (FailsafeLimit -1) times
	check fault memory
	reset ECU for FailsafeAging times
	check fault memory
	repeat step 2 - 3 once more
	check fault memory

    [evaluation]
	fault memory contains failsafe fault
	fault memory is empty
	fault memory contains failsafe fault and lifetime fault

    [finalisation]
    clear fault memory
    switch ECU off


=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'Ubat'        --> battery voltage value
    
=head2 PARAMETER EXAMPLES

    [TC_FR_FailsafeFaultAging.FailsafeFault_PermanentLampOn]
    purpose       = 'check that life time counter and life time fault are working correct for FailsafeFault_PermanentLampOn'
    Ubat          = 12.4
	FailsafeFault = 'rb_sft_ClockMonitoring_flt'
	FailsafeLimit = 5
	FailsafeAging = 127
	LifeTimeFault = 'rb_lfm_LifeTimeLamp_flt'
	
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my ( $fltmemPrimary1, $fltmemPrimary2, $fltmemPrimary3 );
my ( $fltmemBosch1,   $fltmemBosch2,   $fltmemBosch3 );

# my ( $disturbedFault,  $qualifiedFaults_href, $dequalifiedFaults_href );
my ( $tcpar_ubat, $tcpar_failsafeFault, $tcpar_failsafeLimit, $tcpar_lifeTimeFault, $tcpar_failsafeAging );
my $time4FaultManipulation_ms = 3000;
my @lifeTimeCounter           = ();
my $lifeTimeCounterValue;
my ( $i,          $value_aref, $type,            $dec_value );
my ( $value_aref, $type,       $POCounterBefore, $POCounterAfter );

# my ( $result, $BoschMemorySize, $minAutarkyTime_ms, $repetionTime_ms );
my @temperatures = ();

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_ubat          = GEN_Read_mandatory_testcase_parameter('Ubat');
	$tcpar_failsafeFault = GEN_Read_mandatory_testcase_parameter('FailsafeFault');
	$tcpar_failsafeLimit = GEN_Read_mandatory_testcase_parameter('FailsafeLimit');
	$tcpar_lifeTimeFault = GEN_Read_mandatory_testcase_parameter('LifeTimeFault');
	$tcpar_failsafeAging = GEN_Read_mandatory_testcase_parameter('FailsafeAging');

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');
	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	push( @temperatures, TEMP_get_temperature() );
	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	S_teststep( 'Switch ECU on', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);

	S_teststep( 'Wait for end of initialization', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Qualify and dequalify failsaft fault '$tcpar_failsafeFault' for '$tcpar_failsafeLimit-1' times", 'AUTO_NBR', 'lifeTimeCounter' );

	for ( $i = 1 ; $i < $tcpar_failsafeLimit ; $i++ ) {
		S_teststep_2nd_level( "Qualify and dequalify failsafe fault '$tcpar_failsafeFault'", 'AUTO_NBR' );
		PRD_Manipulate_Fault_Memory( { 'fault_name' => $tcpar_failsafeFault, 'action' => "qualify" } );
		S_wait_ms($time4FaultManipulation_ms);
		PRD_Manipulate_Fault_Memory( { 'fault_name' => $tcpar_failsafeFault, 'action' => "dequalify" } );
		S_wait_ms($time4FaultManipulation_ms);
	}
	my $reset_options_href = {
		'resetType'                => 'HARD',
		'wait_time_after_reset_ms' => 5000,
	};
	PRD_ECU_Reset($reset_options_href);

	S_teststep( "Read primary fault memory", 'AUTO_NBR', 'FaultMemory1Primary' );
	$fltmemPrimary1 = LIFT_FaultMemory->read_fault_memory('Primary');

	S_teststep( "Read Bosch fault memory", 'AUTO_NBR', 'FaultMemory1Bosch' );
	$fltmemBosch1 = LIFT_FaultMemory->read_fault_memory('Bosch');

	S_teststep( "Read power on counter", 'AUTO_NBR' );
	my $options_href->{'NbrOfBytes'} = 4;
	$value_aref      = PRD_Read_Memory( 'rb_tim_EcuOnTimeDataEe_dfst(0)', $options_href );
	$type            = 'U32';
	$POCounterBefore = S_aref2dec( $value_aref, $type );

	S_teststep( "Reset ECU for '$tcpar_failsafeAging' times", 'AUTO_NBR' );
	LC_ECU_Reset($tcpar_failsafeAging);

	#	for ( $i = 1 ; $i <= $tcpar_failsafeAging ; $i++ ) {
	#		PRD_ECU_Reset($reset_options_href);
	#	}

	S_teststep( "Read power on counter", 'AUTO_NBR', 'POC' );
	$value_aref     = PRD_Read_Memory( 'rb_tim_EcuOnTimeDataEe_dfst(0)', $options_href );
	$type           = 'U32';
	$POCounterAfter = S_aref2dec( $value_aref, $type );

	S_teststep( "Read primary fault memory", 'AUTO_NBR', 'FaultMemory2Primary' );
	$fltmemPrimary2 = LIFT_FaultMemory->read_fault_memory('Primary');

	S_teststep( "Read Bosch fault memory", 'AUTO_NBR', 'FaultMemory2Bosch' );
	$fltmemBosch2 = LIFT_FaultMemory->read_fault_memory('Bosch');

	S_teststep( "Qualify and dequalify failsaft fault '$tcpar_failsafeFault' one more time", 'AUTO_NBR' );
	S_teststep_2nd_level( "Qualify failsafe fault '$tcpar_failsafeFault'", 'AUTO_NBR' );
	PRD_Manipulate_Fault_Memory( { 'fault_name' => $tcpar_failsafeFault, 'action' => "qualify" } );
	S_wait_ms($time4FaultManipulation_ms);

	S_teststep_2nd_level( "Dequalify failsafe fault '$tcpar_failsafeFault'", 'AUTO_NBR' );
	PRD_Manipulate_Fault_Memory( { 'fault_name' => $tcpar_failsafeFault, 'action' => "dequalify" } );
	S_wait_ms($time4FaultManipulation_ms);

	S_teststep( "Reset ECU", 'AUTO_NBR' );
	LC_ECU_Reset(1);

	S_teststep( "Read primary fault memory", 'AUTO_NBR', 'FaultMemory3Primary' );
	$fltmemPrimary3 = LIFT_FaultMemory->read_fault_memory('Primary');

	S_teststep( "Read Bosch fault memory", 'AUTO_NBR', 'FaultMemory3Bosch' );
	$fltmemBosch3 = LIFT_FaultMemory->read_fault_memory('Bosch');

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	my $expectedFaults;

	$expectedFaults->{$tcpar_failsafeFault} =
	  { 'DecodedStatus' => { 'TestFailed' => 0 } };

	$fltmemPrimary1->evaluate_specific_faults( $expectedFaults, "FaultMemory1Primary" );

	$fltmemBosch1->evaluate_specific_faults( $expectedFaults, "FaultMemory1Bosch" );

	S_teststep_expected( "Power On Counter = $POCounterBefore + $tcpar_failsafeAging", 'POC' );
	S_teststep_detected( "Power On Counter = $POCounterAfter", 'POC' );
	EVAL_evaluate_value( "POC", $POCounterAfter, '==', $POCounterBefore + $tcpar_failsafeAging );

	$fltmemPrimary2->evaluate_faults( {}, "FaultMemory2Primary" );

	$fltmemBosch2->evaluate_specific_faults( $expectedFaults, "FaultMemory2Bosch" );

	$expectedFaults->{$tcpar_lifeTimeFault} =
	  { 'DecodedStatus' => { 'TestFailed' => 1 } };
	$fltmemPrimary3->evaluate_specific_faults( $expectedFaults, "FaultMemory3Primary" );

	$fltmemBosch3->evaluate_specific_faults( $expectedFaults, "FaultMemory3Bosch" );

	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	PRD_Clear_Fault_Memory();
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep_detected( "TEMP: " . join( ' -> ', @temperatures ) );
	S_teststep_detected("UBat: $tcpar_ubat V");

	return 1;
}

1;

