# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_CO_Connection;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TR_Feature_Crash_Output
#TS version in DOORS: 5.13
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use FuncLib_TNT_GEN;
use LIFT_FaultMemory;
use FuncLib_SYC_INTERFACE;
##################################

our $PURPOSE = "test that the configured low/high-side connection is used and otherwise a fault is stored in fault memory";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_CO_Connection

=head1 PURPOSE

test that the configured low/high-side connection is used and otherwise a fault is stored in fault memory

=head1 TESTCASE DESCRIPTION

This script is based on AB12_TR_Feature_Crash_Output

I<B<Initialisation>>

    switch ECU on
    clear fault recorder
    read fault recorder
    switch ECU off

I<B<Stimulation and Measurement>>

	user action - create requested connection
    switch ECU on
    read fault recorder
    switch ECU off
    user action - remove connection 

I<B<Evaluation>>

    evaluate fault recorder

I<B<Finalisation>>

    switch ECU on
    erase fault recorder
    switch ECU off


=head1 PARAMETER DESCRIPTION

    Ubat
    Pin
    Connection
	FLTmand

=head2 PARAMETER NAMES

    SCALAR 'Ubat'        				--> battery voltage value
    SCALAR 'Pin'         				--> ECU pin
    SCALAR 'Connection'					--> connection which is applied during test
    SCALAR 'FLTmand'					--> mandatory faults


=head2 PARAMETER EXAMPLES

		[TC_CO_Connection.CRO1_highSideConnection]
		purpose    = '$Checking_low_high_side_connection_CRO1' 
		Ubat       = 12.1
		Pin        = 'CRO1'
		Connection = 'highSideConnection'
		FLTmand    = @('rb_aod_AOutCrashOutput1Short2Gnd_flt')

=cut

#PARAMETERS
################ Parameters from .par file ###################
my ( $tcpar_ubat, $tcpar_pin, $tcpar_connection );
my ($tcpar_FLTmand);

################ global parameter declaration ###################
#add any global variables here
my @temperatures;

#my ( $data_aref1, $data_aref2 );
#my ( $data_href1, $data_href2 );
my ($fltmem);

#my $freq_mode_inactive;
#my $freq_mode_active = 20;

###############################################################

sub TC_set_parameters {

	$tcpar_ubat       = S_read_mandatory_testcase_parameter('Ubat');
	$tcpar_pin        = S_read_mandatory_testcase_parameter('Pin');
	$tcpar_connection = S_read_mandatory_testcase_parameter('Connection');
	$tcpar_FLTmand    = S_read_mandatory_testcase_parameter('FLTmand');
	return 1;
}

sub TC_initialization {

	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	PRD_Read_Fault_Memory('PRIMARY');
	PRD_Read_Fault_Memory('BOSCH');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	push( @temperatures, TEMP_get_temperature() );

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Create connection '$tcpar_connection' at pin '$tcpar_pin'", 'AUTO_NBR' );
	S_user_action( "Create connection '$tcpar_connection' at pin '$tcpar_pin'\nConfirm popup when connection is created", 'Ok' );

	S_teststep( "Switch ECU on with Ubat = $tcpar_ubat V", 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Read fault recorder", 'AUTO_NBR', 'FaultRecorder' );
	$fltmem = LIFT_FaultMemory->read_fault_memory('Bosch');

	S_teststep( "Switch ECU off", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Remove created connection '$tcpar_connection' at pin '$tcpar_pin'", 'AUTO_NBR' );
	S_user_action( "Remove created connection '$tcpar_connection' at pin '$tcpar_pin'\nConfirm popup when connection is removed", 'Ok' );

	return 1;
}

sub TC_evaluation {

	my $expectedFaults;

	foreach my $fault (@$tcpar_FLTmand) {
		$expectedFaults->{$fault} = { 'DecodedStatus' => { 'TestFailed' => 1 } };
	}
	$fltmem->evaluate_specific_faults( $expectedFaults, 'FaultRecorder' );

	return 1;
}

sub TC_finalization {

	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	LC_ECU_Off();

	S_teststep_detected("TEMP: $temperatures[0]");
	S_teststep_detected("UBat: $tcpar_ubat V");

	return 1;
}

1;
