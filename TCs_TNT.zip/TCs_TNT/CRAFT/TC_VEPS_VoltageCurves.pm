# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#    $Source: CRAFT/TC_VEPS_VoltageCurves.pm $
#    $Revision: 1.6 $
#    $Author: Withohn Sabine (CC-PS/EPS2) (WII2SI) $
#    $State: develop $
#    $Date: 2019/12/02 14:53:21ICT $
#******************************************************************************************************

#### TEST CASE MODULE
package TC_VEPS_VoltageCurves;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
###-------------------------------
our $VERSION = q$Revision: 1.6 $;
our $HEADER  = q$Header: CRAFT/TC_VEPS_VoltageCurves.pm 1.6 2019/12/02 14:53:21ICT Withohn Sabine (CC-PS/EPS2) (WII2SI) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Vehicle_ECU_Power_Supply
#TS version in DOORS: 5.11
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_TOE1;    # is this use needed???
use LIFT_ProdDiag;
use LIFT_FaultMemory;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_TNT_GEN;
##################################

our $PURPOSE = "run a given voltage curve file and check for given faults";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

RB_voltage_file $Revision: 1.6 $

=head1 PURPOSE

run a given voltage curve file and check for given faults

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

    curvefile
    FLTmand (optional)
    FLTopt  (optional)
    ReadLabels (optional)
    CheckLabels (optional)

    [initialisation]
    load given curve
    UZ on with U_batt_default
    clear fault memory
    read fault memory

    [stimulation & measurement]
    run given curve
    set U_batt_default
    read fault memory afterwards

    [evaluation]
    check if fault memory matches given faults
    send mail if not

    [finalisation]
    switch ECU off


=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'curvefile'  --> filename of curve to run (usually *.sat)
    LIST   'FLTmand'    --> list of mandatory faults (logical names)
    LIST   'FLTopt'     --> list of optional faults (logical names)
    LIST   'ReadLabels' --> list of labels which are documented
    HASH   'CheckLabels'--> hast of labels and values to be checked

=head2 PARAMETER EXAMPLES

    [RB_voltage_file.SDR10]
    purpose         = 'slow discharge ramp 10 hours'
    curvefile       = 'C.\curves\SDR_10h.sat'
    FLTmand         = @()
    FLTopt          = @('FltVbatLow')
    ReadLabels      = @()
    CheckLabels     =%()

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my ($duration);
my ( $tcpar_curvefile, $tcpar_FLTmand, $tcpar_FLTopt, @tcpar_ReadLabels,  %tcpar_CheckLabels );
my ( $fltmemBosch,     $fltmemPrimary, $fltmemPlant,  $fltmemDisturbance, $expectedFaults_href );
my @temperatures = ();

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

    $tcpar_curvefile = S_read_mandatory_testcase_parameter('curvefile');

    $tcpar_FLTmand     = S_read_optional_testcase_parameter('FLTmand');
    $tcpar_FLTopt      = S_read_optional_testcase_parameter('FLTopt');
    @tcpar_ReadLabels  = S_read_optional_testcase_parameter('ReadLabels');
    %tcpar_CheckLabels = S_read_optional_testcase_parameter('CheckLabels');

    return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

    push( @temperatures, TEMP_get_temperature() );

    #copy sat file to report folder
    copy( $tcpar_curvefile, "$main::REPORT_PATH" );

    # extract filename
    my $filename = basename($tcpar_curvefile);

    # the picture file is relative to report file
    my $picfile = $filename;
    $picfile =~ s/\.sat$//;    # delete file suffix

    # set filename in report folder for further actions
    $filename = "$main::REPORT_PATH/" . $filename;

    TOE1_createGraph( $filename, 'U_BATT_UNDERVOLTAGE', 'U_BATT_OVERVOLTAGE' );
    S_add_pic2html("$picfile.png");
    S_w2rep(" voltage curve $picfile\n");

    #$duration = LC_PowerConfigCurve($filename);
    $duration = TOE1_setCurveFile($filename);

    S_teststep( "Switch ECU on", 'AUTO_NBR' );

    #LC_ECU_On('U_BATT_DEFAULT');
    TOE1_PPSvoltage('U_BATT_DEFAULT');
    TOE1_PPSon();
    S_wait_ms('TIMER_ECU_READY');

    PRD_Clear_Fault_Memory();
    S_wait_ms('TIMER_ECU_READY');

    S_teststep( "read fault recorder", 'AUTO_NBR' );
    S_teststep_2nd_level( "read primary fault recorder", 'AUTO_NBR' );
    LIFT_FaultMemory->read_fault_memory('Primary');
    S_teststep_2nd_level( "read Bosch fault recorder", 'AUTO_NBR' );
    LIFT_FaultMemory->read_fault_memory('Bosch');
    S_teststep_2nd_level( "read plant fault recorder", 'AUTO_NBR' );
    LIFT_FaultMemory->read_fault_memory('Plant');
    S_teststep_2nd_level( "read disturbed fault recorder", 'AUTO_NBR' );
    LIFT_FaultMemory->read_fault_memory('Disturbance');

    S_teststep( "read given ECU labels", 'AUTO_NBR' );
    foreach my $label (@tcpar_ReadLabels) {
        my $value_aref = PRD_Read_Memory( $label, { memoryContentsAsInteger => 1 } );
        S_w2rep( "$label = $value_aref\n", 'blue' );
    }

    #LC_ECU_Off();
    TOE1_PPSoff();

    S_wait_ms('TIMER_ECU_OFF');
    push( @temperatures, TEMP_get_temperature() );
    return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

    S_teststep( "apply voltage profile", 'AUTO_NBR' );

    # LC_PowerStartCurve();
    TOE1_runCurve();

    S_wait_ms($duration);
    S_wait_ms(500);
    push( @temperatures, TEMP_get_temperature() );

    S_teststep( "switch ECU on", 'AUTO_NBR' );

    #LC_ECU_On('U_BATT_DEFAULT');
    TOE1_PPSvoltage('U_BATT_DEFAULT');
    TOE1_PPSon();

    S_wait_ms('TIMER_ECU_READY');

    #PD_ECUlogin();

    S_teststep( "read fault recorder", 'AUTO_NBR', 'read_fault' );
    S_teststep_2nd_level( "read primary fault recorder", 'AUTO_NBR', 'read_fault_primary' );
    $fltmemPrimary = LIFT_FaultMemory->read_fault_memory('Primary');
    S_teststep_2nd_level( "read Bosch fault recorder", 'AUTO_NBR', 'read_fault_bosch' );
    $fltmemBosch = LIFT_FaultMemory->read_fault_memory('Bosch');
    S_teststep_2nd_level( "read plant fault recorder", 'AUTO_NBR', 'read_fault_plant' );
    $fltmemPlant = LIFT_FaultMemory->read_fault_memory('Plant');
    S_teststep_2nd_level( "read disturbed fault recorder", 'AUTO_NBR', 'read_fault_disturb' );
    $fltmemDisturbance = LIFT_FaultMemory->read_fault_memory('Disturbance');

    S_teststep( "read given ECU labels", 'AUTO_NBR' );
    foreach my $label (@tcpar_ReadLabels) {
        my $value_aref = PRD_Read_Memory( $label, { memoryContentsAsInteger => 1 } );
        S_w2rep( "$label = $value_aref\n", 'blue' );
    }

    return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

    foreach my $label ( sort keys %tcpar_CheckLabels ) {
        S_teststep( "check label: $label", 'AUTO_NBR', $label );
        my $value_aref = PRD_Read_Memory( $label, { memoryContentsAsInteger => 1 } );
        S_w2log( 3, "$label = $value_aref\n", 'blue' );

        S_teststep_expected( "Expected value for label $label < $tcpar_CheckLabels{$label}", $label );
        S_teststep_detected( "Detected value for label $label: $value_aref", $label );

        EVAL_evaluate_value( "$label", $value_aref, '<', $tcpar_CheckLabels{$label} );
    }

    S_teststep_expected( 'Expected faults:', 'read_fault' );
    foreach my $fault (@$tcpar_FLTmand) {
        S_teststep_expected( $fault . " (mandatory)" );
    }
    foreach my $fault (@$tcpar_FLTopt) {
        S_teststep_expected( $fault . " (optional)" );
    }

    $expectedFaults_href = {
        'mandatory'   => $tcpar_FLTmand,
        'disjunction' => [],
        'optional'    => $tcpar_FLTopt,
    };
    $fltmemPrimary->evaluate_faults( $expectedFaults_href, 'read_fault_primary' );
    $fltmemBosch->evaluate_faults( $expectedFaults_href, 'read_fault_bosch' );
    $fltmemPlant->evaluate_faults( $expectedFaults_href, 'read_fault_plant' );

    # $fltmemDisturbance->evaluate_faults( $expectedFaults_href, 'read_fault_disturb' );

    return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

    S_teststep( "switch ECU off", 'AUTO_NBR' );

    #LC_ECU_Off();
    TOE1_PPSoff();

    S_wait_ms('TIMER_ECU_OFF');
    push( @temperatures, TEMP_get_temperature() );

    S_w2rep( "\nlogged temperatures in celsius: " . join( ' -> ', @temperatures ) . "\n", 'blue' );

    return 1;
}

1;

__END__
