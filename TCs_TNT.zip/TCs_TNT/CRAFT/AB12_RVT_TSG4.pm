# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#    $Source: CRAFT/AB12_RVT_TSG4.pm $
#    $Revision: 1.1 $
#    $Author: Withohn Sabine (CC-PS/EPS2) (WII2SI) $
#    $State: release $
#    $Date: 2017/07/04 18:49:26ICT $
#******************************************************************************************************

#### TEST CASE MODULE
package AB12_RVT_TSG4;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
###-------------------------------
our $VERSION = q$Revision: 1.1 $;
our $HEADER = q$Header: CRAFT/AB12_RVT_TSG4.pm 1.1 2017/07/04 18:49:26ICT Withohn Sabine (CC-PS/EPS2) (WII2SI) release  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Vehicle_ECU_Power_Supply
#TS version in DOORS: 5.11
#-------------------------------------------------------------------------

#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general;
use LIFT_TSG4;
use LIFT_PD;
use LIFT_TEMPERATURE;
use LIFT_TOE1; # for create graph
##################################

our $PURPOSE = "switch to different voltage levels (AB12 workaround)";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

AB12_RVT_TSG4 $Revision: 1.1 $


TO DO: rename parameters, use upper and lower band instead on/off

=head1 PURPOSE

switch to different voltage levels

=head1 TESTCASE DESCRIPTION

This test will create an on and off curve with random values between given min/max values. 
The test will store a curve file for later reproduction and put an image of the curve in the report.

To re-run single test just copy the parameters for RB_voltage_file from report to parameter file.
To re-run all failed tests use parameter file RB_RVT_TSG4_failed.par created in report folder.

[parameter used]

    Testcase Parameter:

    HImin
    HImax
    LOmin
    LOmax
    VminLO
    VmaxLO
    VminHI
    VmaxHI
    MAXtime
    FLTmand (optional)
    FLTopt  (optional)

    [initialisation]
    create random voltage curve between min and max values
    UZ on with U_batt_default
    clear fault memory
    switch ECU off
    wait TIMER_ECU_OFF

    [stimulation & measurement]
    run random voltage curve
    set U_batt_default
    read fault memory afterwards

    [evaluation]
    check if fault memory is empty
    send mail if not

    [finalisation]
    switch ECU off


=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'HImin'      --> minimum time for high level in milliseconds
    SCALAR 'HImax'      --> maximum time for high level in milliseconds
    SCALAR 'LOmin'     --> minimum time for low level in milliseconds
    SCALAR 'LOmax'     --> maximum time for low level in milliseconds
    SCALAR 'VminLO'     --> minimum voltage for low level in volts
    SCALAR 'VmaxLO'     --> maximum voltage for low level in volts
    SCALAR 'VminHI'     --> minimum voltage for high level in volts
    SCALAR 'VmaxHI'     --> maximum voltage for high level in volts
    SCALAR 'MAXtime'    --> maximum runtime of curve in seconds
    LIST   'FLTmand'    --> list of mandatory faults (logical names)
    LIST   'FLTopt'     --> list of optional faults (logical names)

=head2 PARAMETER EXAMPLES

    [AB12_RVT_TSG4.full_range]
    purpose     = 'random voltage test full range'
    HImin       = 1
    HImax       = 3000
    LOmin       = 1
    LOmax       = 2000
    VminLO      = 4.5
    VmaxLO      = 6
    VminHI      = 9.5
    VmaxHI      = 15
    MAXtime     = 60

 NOTE: values below 4.2 V will be set to 4.2 V (internal clipping due to OP-amp)
 
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my ($duration,$parstring);
my ( $fltmem1,     $filename, $fltmem2, $fltmem3, $fltmem4 );
my ($tcpar_HImin, $tcpar_HImax, $tcpar_LOmin, $tcpar_LOmax, $tcpar_VminLO, $tcpar_VmaxLO, $tcpar_VminHI, $tcpar_VmaxHI, $tcpar_MAXtime, @tcpar_FLTmand, @tcpar_FLTopt);
my @temperatures = ();

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

  $tcpar_HImin = S_read_testcase_parameter( 'HImin' );
    unless( defined $tcpar_HImin) {
        S_w2rep(" -->  Missing mandatory parameter HImin \n");
        return 0;
    }

  $tcpar_HImax = S_read_testcase_parameter( 'HImax' );
    unless( defined $tcpar_HImax) {
        S_w2rep(" -->  Missing mandatory parameter HImax \n");
        return 0;
    }

  $tcpar_LOmin = S_read_testcase_parameter( 'LOmin' );
    unless( defined $tcpar_LOmin) {
        S_w2rep(" -->  Missing mandatory parameter LOmin \n");
        return 0;
    }

  $tcpar_LOmax = S_read_testcase_parameter( 'LOmax' );
    unless( defined $tcpar_LOmax) {
        S_w2rep(" -->  Missing mandatory parameter LOmax \n");
        return 0;
    }

  $tcpar_VminLO = S_read_testcase_parameter( 'VminLO' );
    unless( defined $tcpar_VminLO) {
        S_w2rep(" -->  Missing mandatory parameter VminLO \n");
        return 0;
    }

  $tcpar_VmaxLO = S_read_testcase_parameter( 'VmaxLO' );
    unless( defined $tcpar_VmaxLO) {
        S_w2rep(" -->  Missing mandatory parameter VmaxLO \n");
        return 0;
    }

  $tcpar_VminHI = S_read_testcase_parameter( 'VminHI' );
    unless( defined $tcpar_VminHI) {
        S_w2rep(" -->  Missing mandatory parameter VminHI \n");
        return 0;
    }

  $tcpar_VmaxHI = S_read_testcase_parameter( 'VmaxHI' );
    unless( defined $tcpar_VmaxHI) {
        S_w2rep(" -->  Missing mandatory parameter VmaxHI \n");
        return 0;
    }
  $tcpar_MAXtime = S_read_testcase_parameter( 'MAXtime' );
    unless( defined $tcpar_MAXtime) {
        S_w2rep(" -->  Missing mandatory parameter MAXtime \n");
        return 0;
    }

  @tcpar_FLTmand = S_read_testcase_parameter( 'FLTmand' );
  @tcpar_FLTopt = S_read_testcase_parameter( 'FLTopt' );

    return 1;
}


#### INITIALIZE TC #####
sub TC_initialization {

my $name= "curve".time();

   $filename=$main::REPORT_PATH."/$name.sat";

    # add some copy paste parameter set for RB_TSG4_file e.g.:
    # [RB_TSG4_file.curve1214396433]
    # purpose            = 're-run RVT_TSG4 curve1214396433'
    # curvefile          = 'C:\curves\curve1214396433.sat'

	S_teststep( "generate voltage curve from parameter", 'AUTO_NBR' );
    $parstring ="[RB_TSG4_file.$name]\n";
    $parstring.="purpose     = 're-run RVT_TSG4 $name'\n";
    $parstring.="curvefile   = '$filename'\n";
	TEMP_get_temperature();

    my $volt_step = 100;
    my $time_step = 10;  
	TSG4_createRandomFile( $filename, $tcpar_HImax, $tcpar_HImin, $tcpar_LOmax, $tcpar_LOmin, $tcpar_VmaxHI*1000, $tcpar_VminHI*1000, $tcpar_VmaxLO*1000, $tcpar_VminLO*1000, $volt_step, $time_step, $tcpar_MAXtime );
#    $volt_step = 50,100 mV
#    $time_step = 10,20,50,80 ms

    S_w2rep("\ncopy paste parameter set for RB_TSG4_file.par:\n\n$parstring\n");

	S_teststep( "create graph of random voltage curve", 'AUTO_NBR' );
    TOE1_createGraph($filename,'U_BATT_UNDERVOLTAGE','U_BATT_OVERVOLTAGE');
    S_add_pic2html("$name.png");
    S_w2rep(" voltage curve $name\n");

	S_teststep( "load voltage curve to power supply of TSG4", 'AUTO_NBR' );
    $duration = TSG4_setCurveFile($filename);

	S_teststep( "switch ECU on", 'AUTO_NBR' );
    TSG4_SetVoltage('U_BATT_DEFAULT');
    TSG4_ConnectLine( 'ALL_SUPPLY' );
	S_wait_ms('TIMER_ECU_READY');
    PD_ECUlogin();
	S_teststep( "clear fault memory", 'AUTO_NBR' );
    PD_ClearFaultMemory();
    S_wait_ms('TIMER_ECU_READY');

	S_teststep( "switch ECU off", 'AUTO_NBR' );
    TSG4_DisconnectLine( 'ALL_SUPPLY' );
	S_wait_ms('TIMER_ECU_OFF');
	S_teststep( "switch ECU on", 'AUTO_NBR' );
    TSG4_ConnectLine( 'ALL_SUPPLY' );
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "read fault recorder", 'AUTO_NBR' );
	S_teststep_2nd_level( "read primary fault recorder", 'AUTO_NBR' );
	PD_GetExtendedFaultInformation(PRIMARY_FLT_MEM);
	S_teststep_2nd_level( "read Bosch fault recorder", 'AUTO_NBR' );
	PD_GetExtendedFaultInformation(BOSCH_FLT_MEM);
	S_teststep_2nd_level( "read plant fault recorder", 'AUTO_NBR' );
	PD_GetExtendedFaultInformation(PLANT_FLT_MEM);
	S_teststep_2nd_level( "read disturbed fault recorder", 'AUTO_NBR' );
	PD_GetExtendedFaultInformation(DISTURBANCE_FLT_MEM);

	S_teststep( "switch ECU off", 'AUTO_NBR' );
    TSG4_DisconnectLine( 'ALL_SUPPLY' );
    S_wait_ms( 'TIMER_ECU_OFF' );
	push( @temperatures, TEMP_get_temperature() );
    return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	S_teststep( "start voltage curve", 'AUTO_NBR' );
    TSG4_ConnectLine( 'ALL_SUPPLY' );
    TSG4_runCurve();
    S_wait_ms( $duration );
    S_wait_ms( 500 );
	S_teststep( "get ambient temperature", 'AUTO_NBR' );
	push( @temperatures, TEMP_get_temperature() );
	S_teststep( "switch ECU on", 'AUTO_NBR' );
    TSG4_SetVoltage('U_BATT_DEFAULT');
	TSG4_ConnectLine( 'ALL_SUPPLY' );

	S_teststep( "wait for ini end", 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');
	PD_ECUlogin();

	S_teststep( "read fault recorder", 'AUTO_NBR', 'read_fault' );
	S_teststep_2nd_level( "read primary fault recorder", 'AUTO_NBR', 'read_fault_primary' );
	$fltmem1 = PD_GetExtendedFaultInformation(PRIMARY_FLT_MEM);
	S_teststep_2nd_level( "read Bosch fault recorder", 'AUTO_NBR', 'read_fault_bosch' );
	$fltmem2 = PD_GetExtendedFaultInformation(BOSCH_FLT_MEM);
	S_teststep_2nd_level( "read plant fault recorder", 'AUTO_NBR', 'read_fault_plant' );
	$fltmem3 = PD_GetExtendedFaultInformation(PLANT_FLT_MEM);
	S_teststep_2nd_level( "read disturbed fault recorder", 'AUTO_NBR', 'read_fault_disturb' );
	$fltmem4 = PD_GetExtendedFaultInformation(DISTURBANCE_FLT_MEM);

  return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	S_teststep_expected( 'Expected faults:', 'read_fault' );
	foreach my $fault (@tcpar_FLTmand) {
		S_teststep_expected( $fault . " (mandatory)" );
	}
	foreach my $fault (@tcpar_FLTopt) {
		S_teststep_expected( $fault . " (optional)" );
	}

	S_teststep_detected( 'Detected faults (primary fault recorder):', 'read_fault_primary' );
	foreach my $fault ( @{ $fltmem1->{fault_text} } ) {
		S_teststep_detected($fault);
	}
	my $eval_primary = PD_evaluate_faults( $fltmem1, \@tcpar_FLTmand, \@tcpar_FLTopt );
	
	S_teststep_detected( 'Detected faults (Bosch fault recorder):', 'read_fault_bosch' );
	foreach my $fault ( @{ $fltmem2->{fault_text} } ) {
		S_teststep_detected($fault);
	}
	my $eval_bosch = PD_evaluate_faults( $fltmem2, \@tcpar_FLTmand, \@tcpar_FLTopt );
	
	S_teststep_detected( 'Detected faults (plant fault recorder):', 'read_fault_plant' );
	foreach my $fault ( @{ $fltmem3->{fault_text} } ) {
		S_teststep_detected($fault);
	}

	S_teststep_detected( 'Detected faults (disturbance fault recorder):', 'read_fault_disturb' );
	foreach my $fault ( @{ $fltmem4->{fault_text} } ) {
		S_teststep_detected($fault);
	}

	unless ($eval_primary eq VERDICT_PASS and $eval_bosch eq VERDICT_PASS )
	{
        # append parameter set to RB_RVT_ramps_failed.par
        my $failed_file = $main::REPORT_PATH."/RB_RVT_TSG4_failed.par";
        open ( my $failed_par, ">>","$failed_file" ) or warn "error opening file";
        print $failed_par "\n$parstring\n";
        close ($failed_par);

#       my $count = PD_count_fault( $fltmem1, 'rb_scm_SCONPlausibility_flt' );
#		S_user_action('check fault memory for rb_scm_SCONPlausibility_flt') if ($count>0);
   }

	# check idlemode
	my @idlestate;
	@idlestate = ();
	my $value_aref = PD_ReadMemoryByName('rb_bswm_IdleModeData_st.BlockIdleMode_u16');
	push( @idlestate, @$value_aref );
	$value_aref = PD_ReadMemoryByName('rb_bswm_IdleModeData_st.PermIdleMode_u16');
	push( @idlestate, @$value_aref );

    return 1;
}


#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	push( @temperatures, TEMP_get_temperature() );

	S_w2rep( "\nlogged temperatures in celsius: " . join( ' -> ', @temperatures ) . "\n", 'blue' );
    return 1;
}


1;

__END__
