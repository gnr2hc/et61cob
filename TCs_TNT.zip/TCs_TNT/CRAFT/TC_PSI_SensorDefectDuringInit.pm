# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_PSI_SensorDefectDuringInit;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on various TS: e.g. AB12_TS_Feature_Firing_Loops
#TS version in DOORS:                e.g. 6.3
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_PSI5_access;
use LIFT_PD;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use FuncLib_TNT_GEN;
##################################

our $PURPOSE = "test that a defect sensor is detected during initialization and stored in fault memory";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PSI_SensorDefectDuringInit 

=head1 PURPOSE

 test that a defect sensor is detected during initialization and stored in fault memory

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

    Ubat
    Pin
    FLTmand
    FLTopt  (optional)

    [initialisation]
    get temperature
    UZ on with U_batt_default
    clear fault memory

    [stimulation & measurement]
    apply sensor fault
    set Ubat
    wait for end of initialization
    read fault memory afterwards

    [evaluation]
    check if fault memory matches given faults
    send mail if not

    [finalisation]
    remove fault
    switch ECU off


=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'Ubat'        --> battery voltage value
    SCALAR 'Pin'         --> ECU pin
    LIST   'FLTmand'     --> list of mandatory faults (logical names)
    LIST   'FLTopt'      --> list of optional faults (logical names)
    
=head2 PARAMETER EXAMPLES

    [TC_PSI_SensorDefectDuringInit.UFSD]
    purpose='Checking_sensorDefectDuringInit_UFSD' 
    Ubat=15.8 
    Pin = 'UFSD'
    FLTmand = @('rb_psem_SensorDefect_flt')
    
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my ($fltmem1);

my ( $tcpar_ubat, $tcpar_pin, $text4teststep, @tcpar_FLTmand, @tcpar_FLTopt );
my @temperatures = ();

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_ubat = GEN_Read_mandatory_testcase_parameter('Ubat');
	$tcpar_pin  = GEN_Read_mandatory_testcase_parameter('Pin');

	@tcpar_FLTmand = GEN_Read_mandatory_testcase_parameter('FLTmand');
	@tcpar_FLTopt  = GEN_Read_optional_testcase_parameter('FLTopt');

	S_get_contents_of_hash( [ 'VEHICLE', 'U_BATT_DEFAULT' ] );
	S_get_contents_of_hash( [ 'TIMER',   'TIMER_ECU_READY' ] );
	S_get_contents_of_hash( [ 'TIMER',   'TIMER_ECU_OFF' ] );

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PD_ClearFaultMemory();
	S_wait_ms('TIMER_ECU_READY');
	PD_GetExtendedFaultInformation();

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	push( @temperatures, TEMP_get_temperature() );
	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	S_teststep( "Set sensor $tcpar_pin to defect", 'AUTO_NBR' );
	PSI5_set_Sensor_Defect($tcpar_pin);

	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);

	S_teststep( 'Wait for end of initialization', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( 'Read fault recorder', 'AUTO_NBR' );
	$fltmem1 = PD_GetExtendedFaultInformation();
	S_teststep( 'Evaluate fault recorder', 'AUTO_NBR', 'Fault' );

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	S_teststep_expected( 'Expected faults:', 'Fault' );
	foreach my $fault (@tcpar_FLTmand) {
		S_teststep_expected($fault);
	}

	S_teststep_detected( 'Detected faults:', 'Fault' );
	foreach my $fault ( @{ $fltmem1->{fault_text} } ) {
		S_teststep_detected($fault);
	}
	PD_evaluate_faults( $fltmem1, \@tcpar_FLTmand, \@tcpar_FLTopt );

	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	# remove fault
	PSI5_sensor_reinit($tcpar_pin);
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep_detected( "TEMP: " . join( ' -> ', @temperatures ) );
	S_teststep_detected("UBat: $tcpar_ubat V");

	return 1;
}

1;

__END__
