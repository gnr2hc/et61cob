# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_PSI_ConfigMismatch;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Peripheral_Sensor_Interface
#TS version in DOORS: 5.11
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;

#use LIFT_PD;
use LIFT_ProdDiag;
use LIFT_FaultMemory;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_TNT_GEN;
##################################

our $PURPOSE = "test that for a not configured but connected sensor a fault is stored";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

RB_voltage_file 

=head1 PURPOSE

 test that for a not configured but connected sensor a fault is stored

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

    Ubat
    Pin
    FLTmand
    FLTopt  (optional)

    [initialisation]
    get temperature
    switch ECU on with U_batt_default
    clear fault memory

    [stimulation & measurement]
    switch ECU on
    disconnect sensor
    read fault recorder
    connect sensor
    set sensor as not configured
    erase fault recorder
    reset ECU
    read fault recorder
    set sensor as not monitored
    erase fault recorder
    reset ECU
    read fault recorder
    switch ECU off

    [evaluation]
    check if fault memory matches given faults
    send mail if not

    [finalisation]
    switch ECU on
    set sensor as configured and monitored
    switch ECU off


=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'ubat'        --> battery voltage value
    SCALAR 'pin'         --> first ECU pin
    LIST   'FLTmand1'    --> list of mandatory faults (logical names)
    LIST   'FLTmand2'    --> list of mandatory faults (logical names)
    LIST   'FLTmand3'    --> list of mandatory faults (logical names)
    
=head2 PARAMETER EXAMPLES

    [TC_PSI_ConfigMismatch.UFSD]
    purpose='Checking_config_mismatch_UFSD' 
    Ubat=10.2 
    Pin = 'UFSD'
    FLTmand1 = @('rb_psem_OpenLineUFSD_flt')
    FLTmand2 = @('rb_psem_UnexpectedSensorUFSD_flt')
    FLTmand3 = @()
    
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my ( $fltmemBosch1, $fltmemPrimary1, $fltmemBosch2, $fltmemPrimary2, $fltmemBosch3, $fltmemPrimary3 );
my ( $expectedFaults1_href, $expectedFaults2_href, $expectedFaults3_href );
my ($devices_modes_href);

my ( $tcpar_ubat, $tcpar_pin, $tcpar_FLTmand1, $tcpar_FLTmand2, $tcpar_FLTmand3 );
my @temperatures = ();

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_ubat = S_read_mandatory_testcase_parameter('Ubat');
	$tcpar_pin  = S_read_mandatory_testcase_parameter('Pin');

	$tcpar_FLTmand1 = S_read_optional_testcase_parameter( 'FLTmand1', 'byref' );
	$tcpar_FLTmand2 = S_read_optional_testcase_parameter( 'FLTmand2', 'byref' );
	$tcpar_FLTmand3 = S_read_optional_testcase_parameter( 'FLTmand3', 'byref' );

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	push( @temperatures, TEMP_get_temperature() );
	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Disconnect sensor '$tcpar_pin'", 'AUTO_NBR' );
	LC_DisconnectLine($tcpar_pin);
	S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

	S_teststep( 'Read fault recorder', 'AUTO_NBR' );
	$fltmemBosch1   = LIFT_FaultMemory->read_fault_memory('Bosch');
	$fltmemPrimary1 = LIFT_FaultMemory->read_fault_memory('Primary');

	S_teststep( 'Evaluate fault recorder', 'AUTO_NBR', 'Fault1' );

	S_teststep( "Connect sensor '$tcpar_pin'", 'AUTO_NBR' );
	LC_ConnectLine($tcpar_pin);

	S_teststep( "Set sensor '$tcpar_pin' as not configured", 'AUTO_NBR' );
	$devices_modes_href = { $tcpar_pin => ['clear_Configure'], };
	PRD_Set_Device_Configuration($devices_modes_href);
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( 'Reset ECU', 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_READY');
	LC_ECU_On($tcpar_ubat);
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( 'Erase fault recorder', 'AUTO_NBR' );
	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( 'Reset ECU', 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_READY');
	LC_ECU_On($tcpar_ubat);
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( 'Read fault recorder', 'AUTO_NBR' );
	$fltmemBosch2   = LIFT_FaultMemory->read_fault_memory('Bosch');
	$fltmemPrimary2 = LIFT_FaultMemory->read_fault_memory('Primary');
	S_teststep( 'Evaluate fault recorder', 'AUTO_NBR', 'Fault2' );

	S_teststep( "Set sensor '$tcpar_pin' as not monitored", 'AUTO_NBR' );
	$devices_modes_href = { $tcpar_pin => ['clear_Monitor'], };
	PRD_Set_Device_Configuration($devices_modes_href);

	S_wait_ms('TIMER_ECU_READY');

	S_teststep( 'Reset ECU', 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_READY');
	LC_ECU_On($tcpar_ubat);
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( 'Erase fault recorder', 'AUTO_NBR' );
	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( 'Reset ECU', 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_READY');
	LC_ECU_On($tcpar_ubat);
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( 'Read fault recorder', 'AUTO_NBR' );
	$fltmemBosch3   = LIFT_FaultMemory->read_fault_memory('Bosch');
	$fltmemPrimary3 = LIFT_FaultMemory->read_fault_memory('Primary');

	S_teststep( 'Evaluate fault recorder', 'AUTO_NBR', 'Fault3' );

	S_teststep( 'Switch ECU off.', 'AUTO_NBR' );
	LC_ECU_Off();

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	S_teststep_expected( 'Expected faults:', 'Fault1' );
	foreach my $fault (@$tcpar_FLTmand1) {
		S_teststep_expected($fault);
	}

	$expectedFaults1_href = {
		'mandatory'   => $tcpar_FLTmand1,
		'disjunction' => [],
		'optional'    => [],
	};

	$fltmemBosch1->evaluate_faults($expectedFaults1_href);
	$fltmemPrimary1->evaluate_faults($expectedFaults1_href);

	S_teststep_expected( 'Expected faults:', 'Fault2' );
	foreach my $fault (@$tcpar_FLTmand2) {
		S_teststep_expected($fault);
	}

	$expectedFaults2_href = {
		'mandatory'   => $tcpar_FLTmand2,
		'disjunction' => [],
		'optional'    => [],
	};

	$fltmemBosch2->evaluate_faults($expectedFaults2_href);
	$fltmemPrimary2->evaluate_faults($expectedFaults2_href);

	S_teststep_expected( 'Expected faults:', 'Fault3' );
	foreach my $fault (@$tcpar_FLTmand3) {
		S_teststep_expected($fault);
	}

	$expectedFaults3_href = {
		'mandatory'   => $tcpar_FLTmand3,
		'disjunction' => [],
		'optional'    => [],
	};

	$fltmemBosch3->evaluate_faults($expectedFaults3_href);
	$fltmemPrimary3->evaluate_faults($expectedFaults3_href);

	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	S_teststep( 'Switch ECU on', 'AUTO_NBR' );
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Set sensor '$tcpar_pin' as configured and monitored", 'AUTO_NBR' );
	$devices_modes_href = { $tcpar_pin => [ 'set_Configure', 'set_Monitor' ], };
	PRD_Set_Device_Configuration($devices_modes_href);
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( 'Switch ECU off.', 'AUTO_NBR' );
	LC_ECU_Off();

	S_teststep_detected( "TEMP: " . join( ' -> ', @temperatures ) );
	S_teststep_detected("UBat: $tcpar_ubat V");
	return 1;
}

1;

__END__
