# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_PSI_SensorLineSwitchedOff;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on various TS: e.g. AB12_TS_Feature_Firing_Loops
#TS version in DOORS:                e.g. 6.3
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use LIFT_TEMPERATURE;
use LIFT_TSG4;
use LIFT_TRC;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use INCLUDES_Project;
##################################

our $PURPOSE = " check that the sensor lines are switched off in power down or in autarky if a fault is present";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

RB_voltage_file 

=head1 PURPOSE

 check that the sensor lines are switched off in power down or in autarky if a fault is present

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

    Ubat
    Pin
    measurementDuration
    firstMeasurement
    repetitionTime

    [initialisation]
    get temperature
    

    [stimulation & measurement]
    set scanner
    set transient recorder
    set Ubat
    switch ECU on
    wait for end of measurement
    

    [evaluation]
    evaluate measured signal for
    - first measurement
    - measurement duration
    - repetition time
    send mail if not

    [finalisation]
    switch ECU off


=head1 PARAMETER

=head2 PARAMETER NAMES
    SCALAR 	purpose
    SCALAR 	Ubat
    SCALAR 	Pin
    LIST 	FLTmand
=head2 PARAMETER EXAMPLES

	[TC_PSI_SensorLineSwitchedOff.UFSD]
	purpose='Checking_SwitchingOff_UFSD'
	Ubat=9.6
	Pin = 'UFSD+'
	FLTmand = @('rb_psem_Short2GndUFSD_flt')
	
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my ( $tcpar_Ubat, $tcpar_Pin, $tcpar_FLTmand, $tcpar_FLTopt, $fltmem1 );
my @temperatures = ();
my $unv_file_name;
my $pin;

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_Ubat = GEN_Read_mandatory_testcase_parameter('Ubat');
	$tcpar_Pin  = GEN_Read_mandatory_testcase_parameter('Pin');
	$pin        = $tcpar_Pin;
	chop($pin);

	$tcpar_FLTmand = GEN_Read_optional_testcase_parameter( 'FLTmand', 'byref' );
	$tcpar_FLTopt  = GEN_Read_optional_testcase_parameter( 'FLTopt',  'byref' );

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	# initialize TRC
	# TRC_InitHW();

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');
	PD_ECUlogin();
	PD_ClearFaultMemory();
	S_wait_ms('TIMER_ECU_READY');

	PD_GetExtendedFaultInformation();

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	push( @temperatures, TEMP_get_temperature() );
	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	# set TRC and scanner and measure
	TSG4_SetTRCscanner( ['UBAT1'], { 'SignalMode' => 'differential', 'VoltageRange' => 20 }, { 'TriggerVoltage' => 6, 'SlopeType' => 'negative' } );
	TSG4_SetTRCscanner( [$pin], { 'SignalMode' => 'differential', 'VoltageRange' => 20 } );

	#TSG4_SetTRCscanner( [$pin."::current"],{ 'SignalMode' => 'differential', 'VoltageRange' => 2 } );
	TSG4_ConfigureTRCchannels( { 'SamplingFrequency' => 500 * 1000, 'MemorySize' => 1024 * 1024, 'TriggerDelay' => -10 } );

	# set battery voltage
	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_Ubat);

	S_teststep( 'Wait for Init End.', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( 'Set transient recorder.', 'AUTO_NBR' );
	TRC_StartMeasurement();
	S_wait_ms(2000);

	S_teststep( 'Switch ECU off.', 'AUTO_NBR' );
	TSG4_DisconnectLine('ALL_SUPPLY+');

	S_teststep( 'Measure Signal.', 'AUTO_NBR' );
	S_wait_ms(15000);

	S_teststep( 'Stop transient recorder.', 'AUTO_NBR' );
	TRC_StopMeasurement();

	S_teststep( 'Plot values of recording for Offline evaluation.', 'AUTO_NBR', 'no_fault' );
	$unv_file_name = "TC_PSI_SensorLineSwitchedOff_" . $pin . ".txt.unv";
	TRC_plot_values( "$main::REPORT_PATH/" . $unv_file_name );
	S_w2rep( '<A HREF="./' . "$unv_file_name" . '" TYPE="text/unv">' . "Click to view TRC trace $unv_file_name" . '</A><br>' );

	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	TSG4_ConnectLine('ALL_SUPPLY+');

	S_teststep( 'Wait for Init End.', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Short '$tcpar_Pin' to 'B-'", 'AUTO_NBR' );
	TSG4_ShortLines( [ $tcpar_Pin, 'B-' ] );

	S_teststep( 'Wait untill fault is qualified.', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( 'Read fault recorder', 'AUTO_NBR' );
	PD_ECUlogin();
	$fltmem1 = PD_GetExtendedFaultInformation();
	S_teststep( 'Evaluate fault recorder', 'AUTO_NBR', 'FLT' );

	S_teststep( 'Set transient recorder.', 'AUTO_NBR' );
	TRC_StartMeasurement();
	S_wait_ms(2000);

	S_teststep( 'Switch ECU off.', 'AUTO_NBR' );
	TSG4_DisconnectLine('ALL_SUPPLY+');

	S_teststep( 'Measure Signal.', 'AUTO_NBR' );
	S_wait_ms(15000);
	S_teststep( 'Stop transient recorder.', 'AUTO_NBR' );
	TRC_StopMeasurement();
	S_teststep( 'Plot values of recording for Offline evaluation.', 'AUTO_NBR', 'fault' );

	$unv_file_name = "TC_PSI_SensorLineSwitchedOff_" . $pin . "_faulty.txt.unv";
	TRC_plot_values( "$main::REPORT_PATH/" . $unv_file_name );
	S_w2rep( '<A HREF="./' . "$unv_file_name" . '" TYPE="text/unv">' . "Click to view TRC trace $unv_file_name" . '</A><br>' );

	TSG4_ConnectLine('ALL_SUPPLY+');

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	#	evaluate measured signal
	S_teststep_expected( "'$pin' line is not switched off.", 'no_fault' );
	S_set_verdict('VERDICT_FAIL');
	S_teststep_detected( "FAIL --> manual Evaluation of transient recorder Trace needed", 'no_fault' );

	S_teststep_expected( "'$pin' line is switched off.", 'fault' );
	S_set_verdict('VERDICT_FAIL');
	S_teststep_detected( "FAIL --> manual Evaluation of transient recorder Trace needed", 'fault' );

	return 1;

}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	TSG4_ResetTRCscanner();

	#TRC_CloseHW();
	TSG4_UndoShortLines();

	S_teststep_detected("TEMP: $temperatures[0]");
	S_teststep_detected("UBat: $tcpar_Ubat V");

	return 1;
}

1;

__END__
