# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_PSI_P0Transmission;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on various TS: e.g. AB12_TS_Feature_Peripheral_Sensor_Interface
#TS version in DOORS:                e.g. 5.10
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_FaultMemory;
use LIFT_TEMPERATURE;
use LIFT_PSI5_access;
use LIFT_evaluation;
use FuncLib_TNT_GEN;
##################################

our $PURPOSE = "check that the correct P0 mode is configured";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PSI_P0Transmission 

=head1 PURPOSE

 check that the correct P0 mode is configured

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

	'TIMER_ECU_FAULT_QUALIFICATION'
	'TIMER_ECU_READY'
	'TIMER_ECU_OFF'
	'U_BATT_DEFAULT'
	'sensorType'
	'usedMode'
	'newMode'
    Ubat
    Pin
    FLTmand1
    FLTmand2
    FLTopt  (optional)

    [initialisation]
    get temperature
    UZ on with U_batt_default
    clear fault memory

    [stimulation & measurement]
    1. Set sensor to mode (wrong mode)
    2. Switch ECU on
    3. Wait for ini end
    4. Read fault recorder
    5. Evaluate fault recorder
    6. Erase fault recorder
    7. Switch ECU off
    8. Set sensor back to mode (used mode)
    9. Switch ECU on
    10. Wait for ini end
    11. Read fault recorder
    12. Evaluate fault recorder
    13. Switch ECU off 
   
    [evaluation]
    check if fault memory matches given faults

    [finalisation]
    switch ECU off


=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'ubat'        --> battery voltage value
    SCALAR 'pin'         --> tested pin
    LIST   'FLTmand1'     --> list of mandatory faults (logical names)
    LIST   'FLTmand2'     --> list of mandatory faults (logical names)
    LIST   'FLTopt'      --> list of optional faults (logical names)
    
=head2 PARAMETER EXAMPLES

    [TC_PSI_P0Transmission.PPSFD]
    purpose='Checking_P0_Transmission_PPSFD' 
    Ubat=9.5 
    Pin = 'PPSFD'
    FLTmand1 = @('rb_psem_InitPPSFD_flt')
    FLTmand2 = @()
    
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
my ( $fltmemBosch1, $fltmemPrimary1, $fltmemBosch2, $fltmemPrimary2 );
my ( $expectedFaults1_href, $expectedFaults2_href );

my ( $tcpar_ubat, $tcpar_pin, $tcpar_FLTmand1, $tcpar_FLTmand2, $tcpar_FLTopt );
my ( $type, $usedMode, $newMode );
my @temperatures = ();

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_ubat     = S_read_mandatory_testcase_parameter('Ubat');
	$tcpar_pin      = S_read_mandatory_testcase_parameter('Pin');
	$tcpar_FLTmand1 = S_read_mandatory_testcase_parameter('FLTmand1');
	$tcpar_FLTmand2 = S_read_mandatory_testcase_parameter('FLTmand2');
	$tcpar_FLTopt   = S_read_optional_testcase_parameter('FLTopt');

	S_get_contents_of_hash( [ 'VEHICLE', 'U_BATT_DEFAULT' ] );
	S_get_contents_of_hash( [ 'TIMER',   'TIMER_ECU_FAULT_QUALIFICATION' ] );
	S_get_contents_of_hash( [ 'TIMER',   'TIMER_ECU_READY' ] );
	S_get_contents_of_hash( [ 'TIMER',   'TIMER_ECU_OFF' ] );

	$type = S_get_contents_of_hash( [ 'PSI5_SENSORS_PROJECT', $tcpar_pin, 'TYPE' ] );
	if ( $type eq 'PTS1' || $type eq 'PPS3' ) {
		$usedMode = S_get_contents_of_hash( [ 'PSI5_SENSORS_PROJECT', $tcpar_pin, 'INIT2_DATA', 'TRANSMISSION_MODE' ] );
	}
	elsif ( $type eq 'PPS3e' ) {
		$usedMode = S_get_contents_of_hash( [ 'PSI5_SENSORS_PROJECT', $tcpar_pin, 'INIT2_DATA', 'PRESSURE_SENSOR_TYPE' ] );
	}
	else {
		S_w2rep( "Sensor type $type used for Manitoo-PAS is not supported in this test case.", 'cyan' );
	}

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	push( @temperatures, TEMP_get_temperature() );
	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	if    ( $type eq 'PPS3'  && $usedMode eq 'PPS3_ABS_PRESSURE_ON' )  { $newMode = 'PPS3_ABS_PRESSURE_OFF'; }
	elsif ( $type eq 'PPS3'  && $usedMode eq 'PPS3_ABS_PRESSURE_OFF' ) { $newMode = 'PPS3_ABS_PRESSURE_ON'; }
	elsif ( $type eq 'PTS1'  && $usedMode eq 'PTS1_ABS_PRESSURE_ON' )  { $newMode = 'PTS1_ABS_PRESSURE_OFF'; }
	elsif ( $type eq 'PTS1'  && $usedMode eq 'PTS1_ABS_PRESSURE_OFF' ) { $newMode = 'PTS1_ABS_PRESSURE_ON'; }
	elsif ( $type eq 'PPS3e' && $usedMode eq 'PN_SENSOR' )             { $newMode = 'P0_T_SENSOR'; }
	elsif ( $type eq 'PPS3e' && $usedMode eq 'P0_T_SENSOR' )           { $newMode = 'PN_SENSOR'; }

	S_teststep( "Set sensor $tcpar_pin to mode $newMode", 'AUTO_NBR' );
	PSI5_sensor_reinit($tcpar_pin);
	if ( $type eq 'PPS3' || $type eq 'PTS1' ) {
		PSI5_set_Init_Data( $tcpar_pin, 2, { 'TRANSMISSION_MODE' => $newMode, }, );
	}
	elsif ( $type eq 'PPS3e' ) {
		PSI5_set_Init_Data( $tcpar_pin, 2, { 'PRESSURE_SENSOR_TYPE' => $newMode, }, );
	}

	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);

	S_teststep( 'Wait for end of initialization', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( 'Read fault recorder', 'AUTO_NBR' );
	$fltmemBosch1   = LIFT_FaultMemory->read_fault_memory('Bosch');
	$fltmemPrimary1 = LIFT_FaultMemory->read_fault_memory('Primary');
	S_teststep( 'Evaluate fault recorder', 'AUTO_NBR', 'Fault1' );

	S_teststep( 'Erase fault recorder', 'AUTO_NBR' );
	PRD_Clear_Fault_Memory();

	S_teststep( 'Switch ECU off.', 'AUTO_NBR' );
	LC_ECU_Off();

	S_teststep( "Set sensor $tcpar_pin back to mode $usedMode", 'AUTO_NBR' );
	PSI5_sensor_reinit($tcpar_pin);

	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);

	S_teststep( 'Wait for end of initialization', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');
	S_teststep( 'Read fault recorder', 'AUTO_NBR' );
	$fltmemBosch2   = LIFT_FaultMemory->read_fault_memory('Bosch');
	$fltmemPrimary2 = LIFT_FaultMemory->read_fault_memory('Primary');
	S_teststep( 'Evaluate fault recorder', 'AUTO_NBR', 'Fault2' );

	S_teststep( 'Switch ECU off.', 'AUTO_NBR' );
	LC_ECU_Off();

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	S_teststep_expected( 'Expected faults:', 'Fault1' );
	foreach my $fault (@$tcpar_FLTmand1) {
		S_teststep_expected($fault);
	}

	$expectedFaults1_href = {
		'mandatory'   => $tcpar_FLTmand1,
		'disjunction' => [],
		'optional'    => $tcpar_FLTopt,
	};

	$fltmemBosch1->evaluate_faults( $expectedFaults1_href, 'Fault1' );
	$fltmemPrimary1->evaluate_faults( $expectedFaults1_href, 'Fault1' );

	S_teststep_expected( 'Expected faults:', 'Fault2' );
	foreach my $fault (@$tcpar_FLTmand2) {
		S_teststep_expected($fault);
	}

	$expectedFaults2_href = {
		'mandatory'   => $tcpar_FLTmand2,
		'disjunction' => [],
		'optional'    => $tcpar_FLTopt,
	};

	$fltmemBosch2->evaluate_faults( $expectedFaults2_href, 'Fault2' );
	$fltmemPrimary2->evaluate_faults( $expectedFaults2_href, 'Fault2' );

	return 1;
}

#### TC FINALIZATION #####
sub TC_finalization {

	# remove fault
	PSI5_sensor_reinit($tcpar_pin);
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep_detected( "TEMP: " . join( ' -> ', @temperatures ) );
	S_teststep_detected("UBat: $tcpar_ubat V");

	return 1;
}

1;

__END__
