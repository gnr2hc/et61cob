# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_FLT_Configuration;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on various TS: e.g. AB12_TS_Feature_Firing_Loops
#TS version in DOORS:                e.g. 6.3
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_FaultMemory;
use LIFT_TEMPERATURE;
use LIFT_evaluation;

use FuncLib_TNT_GEN;
##################################

our $PURPOSE = " test that a not configured but connected device is detected and a fault is stored ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_FLT_Configuration 

=head1 PURPOSE

 test that a not configured but connected device is detected and a fault is stored

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

	'TIMER_ECU_READY'
	'TIMER_ECU_OFF'
	'U_BATT_DEFAULT'
    Ubat
    Pin1
    FLTmand
    FLTopt  (optional)

    [initialisation]
    get temperature
    UZ on with U_batt_default
    clear fault memory

    [stimulation & measurement]
    set Ubat
    wait for end of initialization
    apply fault
    wait for fault qualification
    read fault memory afterwards

    [evaluation]
    check if fault memory matches given faults
    send mail if not

    [finalisation]
    remove fault
    switch ECU off


=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'ubat'        --> battery voltage value
    SCALAR 'Pin1'        --> first ECU pin
    LIST   'FLTmand'     --> list of mandatory faults (logical names)
    LIST   'FLTopt'      --> list of optional faults (logical names)
    
=head2 PARAMETER EXAMPLES

	[TC_FLT_Configuration.AB1FD]
	purpose  = 'Checking AB1FD'
	Ubat = 12
	Pin1 = 'AB1FD'
	FLTmand=@( 'rb_sqm_UnexpectedAB1FD_flt' )
	FLTopt=@( )
	    
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my ( $tcpar_ubat, $tcpar_pin, $tcpar_FLTmand, $tcpar_FLTopt, $fltmemBosch, $fltmemPrimary, $expectedFaults_href, $devices_modes_href );
my @temperatures = ();

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_ubat    = S_read_mandatory_testcase_parameter('Ubat');
	$tcpar_pin     = S_read_mandatory_testcase_parameter('Pin1');
	$tcpar_FLTmand = S_read_optional_testcase_parameter( 'FLTmand', 'byref' );
	$tcpar_FLTopt  = S_read_optional_testcase_parameter( 'FLTopt', 'byref' );

	S_get_contents_of_hash( [ 'VEHICLE', 'U_BATT_DEFAULT' ] );
	S_get_contents_of_hash( [ 'TIMER',   'TIMER_ECU_READY' ] );
	S_get_contents_of_hash( [ 'TIMER',   'TIMER_ECU_OFF' ] );

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	push( @temperatures, TEMP_get_temperature() );
	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);

	S_teststep( 'Wait for end of initialization', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "De-configure device '$tcpar_pin'.", 'AUTO_NBR' );

	$devices_modes_href = { $tcpar_pin => 'clear_Configure', };
	PRD_Set_Device_Configuration($devices_modes_href);
	S_wait_ms(2000);

	S_teststep( "Switch ECU off.", 'AUTO_NBR' );
	LC_ECU_Off();

	S_wait_ms('TIMER_ECU_OFF');

	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On();

	S_teststep( 'Wait for end of initialization', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( 'Read fault recorder', 'AUTO_NBR' );
	S_teststep( 'Evaluate fault recorder', 'AUTO_NBR', 'Fault' );
	$fltmemBosch   = LIFT_FaultMemory->read_fault_memory('Bosch');
	$fltmemPrimary = LIFT_FaultMemory->read_fault_memory('Primary');

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	S_teststep_expected( 'Expected faults:', 'Fault' );
	foreach my $fault (@$tcpar_FLTmand) {
		S_teststep_expected($fault);
	}

	$expectedFaults_href = {
		'mandatory'   => $tcpar_FLTmand,
		'disjunction' => [],
		'optional'    => $tcpar_FLTopt,
	};

	$fltmemBosch->evaluate_faults( $expectedFaults_href, 'Fault' );
	$fltmemPrimary->evaluate_faults( $expectedFaults_href, 'Fault' );

	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	$devices_modes_href = { $tcpar_pin => 'set_Configure', };
	PRD_Set_Device_Configuration($devices_modes_href);
	S_wait_ms(2000);

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep_detected( "TEMP: " . join( ' -> ', @temperatures ) );
	S_teststep_detected("UBat: $tcpar_ubat V");

	return 1;
}

1;

__END__
