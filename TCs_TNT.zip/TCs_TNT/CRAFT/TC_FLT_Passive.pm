# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_FLT_Passive;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on various TS: e.g. AB12_TS_Feature_Firing_Loops
#TS version in DOORS:                e.g. 6.3
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_FaultMemory;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use FuncLib_TNT_GEN;
##################################

our $PURPOSE = " test that a fault is detected in init mode and stored in fault memory";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_FLT_Passive 

=head1 PURPOSE

 test that a fault is detected in init phase mode and stored in fault memory

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

	'TIMER_ECU_READY'
	'TIMER_ECU_OFF'
	'U_BATT_DEFAULT'
    Ubat
    Pin1
    Pin2
    FLTmand
    FLTopt  (optional)

    [initialisation]
    get temperature
    UZ on with U_batt_default
    clear fault memory

    [stimulation & measurement]
    apply fault
    set Ubat
    wait for fault qualification
    read fault memory afterwards

    [evaluation]
    check if fault memory matches given faults
    send mail if not

    [finalisation]
    remove fault
    switch ECU off


=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'ubat'        --> battery voltage value
    SCALAR 'Pin1'        --> first ECU pin
    SCALAR 'Pin2'        --> second ECU pin or 'open'
	LIST   'Pins'		 --> list of pins for short, if only one pin is given disconnect is used
    LIST   'FLTmand'     --> list of mandatory faults (logical names)
    LIST   'FLTopt'      --> list of optional faults (logical names)
    
=head2 PARAMETER EXAMPLES

    [TC_FLT_Passive.BLFD_Gnd]
    purpose='Checking Short2Gnd(passive) BLFD' 
	Ubat=13.2
	Pin1='BLFD+'
	Pin2='B-'
	FLTmand='rb_swm_ShortLineBLFD_flt'
    
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my ( $fltmemBosch, $fltmemPrimary, $expectedFaults_href );

my ( $tcpar_ubat, $tcpar_pin1, $tcpar_pin2, $tcpar_pins, $text4teststep, @pins4fault, $tcpar_FLTmand, $tcpar_FLTopt );
my @temperatures = ();

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_ubat = S_read_mandatory_testcase_parameter('Ubat');
	$tcpar_pin1 = S_read_optional_testcase_parameter('Pin1');
	$tcpar_pin2 = S_read_optional_testcase_parameter('Pin2');
	$tcpar_pins = S_read_optional_testcase_parameter( 'Pins', 'byref' );

	if ( not defined $tcpar_pin1 and not defined $tcpar_pin2 and defined $tcpar_pins ) {
		@pins4fault = @$tcpar_pins;
	}
	elsif ( defined $tcpar_pin1 and defined $tcpar_pin2 and not defined $tcpar_pins ) {
		push @pins4fault, $tcpar_pin1;
		push @pins4fault, $tcpar_pin2 unless $tcpar_pin2 eq 'open';
	}
	elsif ( defined $tcpar_pin1 and not defined $tcpar_pin2 and not defined $tcpar_pins ) {
		push @pins4fault, $tcpar_pin1;
	}
	else {
		S_set_error("The used combination of parameters Pin1, Pin2 and Pins is not allowed. (Pin1) or (Pin1 and Pin2) or (Pins).");
	}

	$tcpar_FLTmand = S_read_optional_testcase_parameter( 'FLTmand', 'byref' );
	$tcpar_FLTopt  = S_read_optional_testcase_parameter( 'FLTopt',  'byref' );

	S_get_contents_of_hash( [ 'VEHICLE', 'U_BATT_DEFAULT' ] );
	S_get_contents_of_hash( [ 'TIMER',   'TIMER_ECU_READY' ] );
	S_get_contents_of_hash( [ 'TIMER',   'TIMER_ECU_OFF' ] );

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	push( @temperatures, TEMP_get_temperature() );
	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	if ( scalar @pins4fault == 1 ) {
		S_teststep( "Disconnect '$pins4fault[0]' line. ", 'AUTO_NBR' );
		LC_DisconnectLine( $pins4fault[0] );
	}
	else {
		$text4teststep = join ',', @pins4fault;
		S_teststep( "Short '$text4teststep' lines. ", 'AUTO_NBR' );
		LC_ShortLines( \@pins4fault );
	}

	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);

	S_teststep( 'Wait for end of initialization', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( 'Read fault recorder', 'AUTO_NBR' );
	$fltmemBosch   = LIFT_FaultMemory->read_fault_memory('Bosch');
	$fltmemPrimary = LIFT_FaultMemory->read_fault_memory('Primary');
	S_teststep( 'Evaluate fault recorder', 'AUTO_NBR', 'Fault' );

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	S_teststep_expected( 'Expected faults:', 'Fault' );
	foreach my $fault (@$tcpar_FLTmand) {
		S_teststep_expected($fault);
	}

	$expectedFaults_href = {
		'mandatory'   => $tcpar_FLTmand,
		'disjunction' => [],
		'optional'    => $tcpar_FLTopt,
	};

	$fltmemBosch->evaluate_faults( $expectedFaults_href, 'Fault' );
	$fltmemPrimary->evaluate_faults( $expectedFaults_href, 'Fault' );

	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	# remove fault
	# distinguish between faults with two pins used and open line fault
	if ( scalar @pins4fault == 1 ) {
		LC_ConnectLine( $pins4fault[0] );
	}
	else {
		LC_UndoShortLines();
	}
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep_detected( "TEMP: " . join( ' -> ', @temperatures ) );
	S_teststep_detected("UBat: $tcpar_ubat V");

	return 1;
}

1;

__END__
