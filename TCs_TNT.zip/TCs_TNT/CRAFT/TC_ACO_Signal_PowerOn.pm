# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_ACO_Signal_PowerOn;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Crash_Output
#TS version in DOORS: 5.7
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_TNT_GEN;
use FuncLib_SYC_INTERFACE;
##################################

our $PURPOSE = " test that the crash output signal behaviour during initialization and steady state for all analog channels is correct ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_ACO_Signal_PowerOn 

=head1 PURPOSE

 test that the crash output signal behaviour during initialization and steady state for all analog channels is correct

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:
    Ubat
    Pin
    
    [initialisation]
    get temperature
    

    [stimulation & measurement]
    set scanner and transient recorder
    start transient recorder measurement
    switch ECU on
    wait 15 sec
    measure signal
    stop transient recorder measurement
    plot values of recordind for offline evaluation
    switch ECU off

    [evaluation]
    manual evaluate necessary
    
    [finalisation]
    reset scanner


=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'ubat'          		 --> battery voltage value
    SCALAR 'pin'           		 --> ECU pin
    
=head2 PARAMETER EXAMPLES

    [TC_ACO_Signal_PowerOn.ACO]
    purpose='check crash output signal for ACO' 
    Ubat=15.3
	Pin='ACO'
    
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my ( $tcpar_Ubat, $tcpar_pin, );
my @temperatures = ();
my $unv_file_name;

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_Ubat = GEN_Read_mandatory_testcase_parameter('Ubat');
	$tcpar_pin  = GEN_Read_mandatory_testcase_parameter('Pin');

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	# switch ECU on
	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');
	PD_ECUlogin();
	PD_ClearFaultMemory();
	S_wait_ms('TIMER_ECU_READY');

	PD_GetExtendedFaultInformation();

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	push( @temperatures, TEMP_get_temperature() );
	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	# set TRC and scanner and measure
	S_teststep( "Set scanner and transient recorder.", 'AUTO_NBR' );
	LC_SetTRCscanner( ['UBAT1'], { 'SignalMode' => 'differential', 'VoltageRange' => 20 }, { 'TriggerVoltage' => 6, 'SlopeType' => 'positive' } );
	LC_SetTRCscanner( [$tcpar_pin], { 'SignalMode' => 'differential', 'VoltageRange' => 20 } );
	LC_ConfigureTRCchannels( { 'SamplingFrequency' => 20 * 1000, 'MemorySize' => 64 * 1024, 'TriggerDelay' => -5 } );

	# set battery voltage
	S_teststep( 'Start transient recorder measurement.', 'AUTO_NBR' );
	LC_MeasureTraceAnalogStart();
	S_wait_ms(2000);

	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_Ubat);
	S_teststep( 'Measure Signal.', 'AUTO_NBR' );
	S_wait_ms(15000);
	S_teststep( 'Stop transient recorder.', 'AUTO_NBR' );
	LC_MeasureTraceAnalogStop();

	S_teststep( 'Plot values of recording for Offline evaluation.', 'AUTO_NBR', 'analogcrashoutput_1' );
	$unv_file_name = S_get_TC_number() . '_TRC_Trace_ACO_SignalPowerOn_' . $tcpar_pin . '.txt.unv';

	LC_MeasureTraceAnalogPlotValues( "$main::REPORT_PATH/" . $unv_file_name, 30000 );
	S_w2rep( '<A HREF="./' . $unv_file_name . '" TYPE="text/unv">' . "Click to view TRC trace $unv_file_name" . '</A><br>' );

	S_teststep( 'Switch ECU off.', 'AUTO_NBR' );
	LC_ECU_Off();

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	#	evaluate measured signal
	S_teststep_expected( "'$tcpar_pin' behaviour is like specified behaviour and state is according to fault state.", 'analogcrashoutput_1' );
	S_set_verdict('VERDICT_FAIL');
	S_teststep_detected( "FAIL --> manual Evaluation of transient recorder Trace needed", 'analogcrashoutput_1' );

	return 1;
}
#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	LC_ResetTRCscanner();

	S_teststep_detected("TEMP: $temperatures[0]");
	S_teststep_detected("UBat: $tcpar_Ubat V");

	return 1;
}

1;

__END__
