# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_SI_TestPulse;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Switch_Inputs
#TS version in DOORS: 6.4
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_FaultMemory;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_TNT_GEN;
use FuncLib_SYC_INTERFACE;
use FuncLib_TNT_SYC_INTERFACE;
##################################

our $PURPOSE = " record the test pulses on each switch line and check that all parameters are correct ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SI_TestPulse 

=head1 PURPOSE

 record the test pulses on each switch line and check that all parameters are correct

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

    Ubat
    Pin
    measurementDuration
    firstMeasurement
    repetitionTime

    [initialisation]
    get temperature
    

    [stimulation & measurement]
    set scanner
    set transient recorder
    set Ubat
    switch ECU on
    wait for end of measurement
    

    [evaluation]
    evaluate measured signal for
    - first measurement
    - measurement duration
    - repetition time
    send mail if not

    [finalisation]
    switch ECU off


=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'ubat'          		 --> battery voltage value
    SCALAR 'pin'           		 --> ECU pin
    SCALAR 'measurementDuration' --> value how long the measurement takes
    SCALAR 'firstMeasurement'	 --> value when the first measurement is done
    SCALAR 'repetitionTime'	   	 --> value when the measurement is repeated
    
=head2 PARAMETER EXAMPLES

    [TC_SI_TestPulse.BLFD]
    purpose='check test pulses for BLFD' 
    Ubat=15.3
	Pin='BLFD'
    measurementDuration=1.5 # ms
	firstMeasurement=150 # ms
	repetitionTime=30 # ms
    
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my ( $tcpar_ubat, $tcpar_pin, $tcpar_duration, $tcpar_firstM, $tcpar_repetition, $unv_file_name, $unv_file_name_2, $tcpar_repetition_min, $tcpar_repetition_max, $result, $measurement_duration_ms, $memory_size );
my @temperatures = ();

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_ubat       = S_read_mandatory_testcase_parameter('Ubat');
	$tcpar_pin        = S_read_mandatory_testcase_parameter('Pin');
	$tcpar_duration   = S_read_mandatory_testcase_parameter('measurementDuration');
	$tcpar_firstM     = S_read_mandatory_testcase_parameter('firstMeasurement');
	$tcpar_repetition = S_read_mandatory_testcase_parameter('repetitionTime');

	if ( $tcpar_repetition eq 'SYC' ) {
		( $result, $tcpar_repetition ) = SYC_SWITCH_get_RepetitionTime();
		return 0 unless $result;
	}

	if ( $tcpar_firstM eq 'SYC' ) {
		( $result, $tcpar_firstM ) = SYC_SWITCH_get_InitTime_ms();
		return 0 unless $result;
	}

	$tcpar_repetition_min = $tcpar_repetition - 4;
	$tcpar_repetition_max = $tcpar_repetition + 4;

	#calculation for measure duration
	$measurement_duration_ms = $tcpar_repetition * 10;
	if ( $measurement_duration_ms > 419430 ) {
		$measurement_duration_ms = 840000;
		$memory_size             = 8192;
	}
	elsif ( $measurement_duration_ms > 209715 ) {
		$measurement_duration_ms = 440000;
		$memory_size             = 4096;
	}
	elsif ( $measurement_duration_ms > 104857 ) {
		$measurement_duration_ms = 220000;
		$memory_size             = 2048;
	}
	elsif ( $measurement_duration_ms > 52428 ) {
		$measurement_duration_ms = 120000;
		$memory_size             = 1024;
	}
	elsif ( $measurement_duration_ms > 26214 ) {
		$measurement_duration_ms = 60000;
		$memory_size             = 512;
	}
	elsif ( $measurement_duration_ms > 13107 ) {
		$measurement_duration_ms = 30000;
		$memory_size             = 256;
	}
	elsif ( $measurement_duration_ms > 6553 ) {
		$measurement_duration_ms = 15000;
		$memory_size             = 128;
	}
	elsif ( $measurement_duration_ms > 3276 ) {
		$measurement_duration_ms = 7500;
		$memory_size             = 64;
	}
	elsif ( $measurement_duration_ms > 1638 ) {
		$measurement_duration_ms = 4000;
		$memory_size             = 32;
	}
	elsif ( $measurement_duration_ms > 819 ) {
		$measurement_duration_ms = 2000;
		$memory_size             = 16;
	}
	elsif ( $measurement_duration_ms > 409 ) {
		$measurement_duration_ms = 1000;
		$memory_size             = 8;
	}
	else {
		$measurement_duration_ms = 500;
		$memory_size             = 4;
	}

	#replace , with dot to convert doors values to perl numbers
	$tcpar_duration =~ s/,/./g;
	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	push( @temperatures, TEMP_get_temperature() );

	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	S_teststep( "Set scanner and transient recorder.", 'AUTO_NBR' );
	LC_SetTRCscanner( ['UBAT1'], { 'SignalMode' => 'differential', 'VoltageRange' => 20 }, { 'TriggerVoltage' => 6, 'SlopeType' => 'positive' } );

	#	LC_SetTRCscanner( ['UBAT2'], { 'SignalMode' => 'differential', 'VoltageRange' => 20 }, { 'TriggerVoltage' => 6, 'SlopeType' => 'positive' } );
	LC_SetTRCscanner( ["$tcpar_pin"], { 'SignalMode' => 'differential', 'VoltageRange' => 5 } );

	#    LC_SetTRCscanner( ["$tcpar_pin", 'Sense1'], { 'SignalMode' => 'differential', 'VoltageRange' => 5 } );
	#    LC_SetTRCscanner( ['Sense1'], { 'SignalMode' => 'differential', 'VoltageRange' => 20 }, { 'TriggerVoltage' => 6, 'SlopeType' => 'positive' } );
	LC_ConfigureTRCchannels( { 'SamplingFrequency' => 10 * 1000, 'MemorySize' => 64 * 1024, 'TriggerDelay' => -5 } );

	S_teststep( "Start transient recorder measurement.", 'AUTO_NBR' );
	LC_MeasureTraceAnalogStart();

	S_teststep( "Wait 2000ms.", 'AUTO_NBR' );
	S_wait_ms(2000);

	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);

	S_teststep( "Wait 7s until transient recorder measurement is finished.", 'AUTO_NBR' );
	S_wait_ms(7000);

	$unv_file_name = $main::TC_REPORT_NAME . '_startup.txt.unv';
	LC_MeasureTraceAnalogStop();
	LC_MeasureTraceAnalogPlotValues( "$main::REPORT_PATH/" . $unv_file_name );
	S_w2rep( '<A HREF="./' . "$unv_file_name" . '" TYPE="text/unv">' . "Click to view TRC trace $unv_file_name" . '</A><br>' );

	S_teststep( "Evaluate timing of first test pulse.", 'AUTO_NBR', 'first_TP' );

	S_teststep( "Set scanner and transient recorder.", 'AUTO_NBR' );
	LC_ResetTRCscanner();
	LC_SetTRCscanner( ["$tcpar_pin"], { 'SignalMode' => 'differential', 'VoltageRange' => 5 } );
	LC_ConfigureTRCchannels( { 'SamplingFrequency' => 10 * 1000, 'MemorySize' => $memory_size * 1024, 'TriggerDelay' => 0 } );

	S_teststep( "Start transient recorder measurement.", 'AUTO_NBR' );
	LC_MeasureTraceAnalogStart();

	S_teststep( "Send SW trigger to transient recorder.", 'AUTO_NBR' );
	LC_MeasureTraceAnalogSendSWTrigger();

	S_teststep( "Wait '$measurement_duration_ms' ms until transient recorder measurement is finished.", 'AUTO_NBR' );
	S_wait_ms($measurement_duration_ms);

	$unv_file_name_2 = $main::TC_REPORT_NAME . '_normal.txt.unv';
	LC_MeasureTraceAnalogStop();
	LC_MeasureTraceAnalogPlotValues( "$main::REPORT_PATH/" . $unv_file_name_2 );
	S_w2rep( '<A HREF="./' . "$unv_file_name_2" . '" TYPE="text/unv">' . "Click to view TRC trace $unv_file_name_2" . '</A><br>' );
	S_teststep( "Evaluate measured signal for...", 'AUTO_NBR' );
	S_teststep_2nd_level( "maximum testpulse duration",                         'AUTO_NBR', 'TP_duration' );
	S_teststep_2nd_level( "repetition time of test pulses (min, max, average)", 'AUTO_NBR', 'TP_repetition' );

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	# evaluate measured signal
	my $data_HoH = EVAL_importUNV( "$main::REPORT_PATH/" . $unv_file_name );

	my ( $NumOfPulses, $pulses ) = EVAL_get_signal_pulses( $data_HoH, $tcpar_pin, 0.6, 0.05, 'rising', 7 );
	my $time1 = 0;

	# calculation and evaluation of first pulse
	$time1 = $pulses->{"pulse0"}{'start'} / 1000;    # fix for wrong time base
	S_teststep_expected( "t(first) <= '$tcpar_firstM' ms", 'first_TP' );
	S_teststep_detected( "t(first) = '$time1' ms", 'first_TP' );
	EVAL_evaluate_value( "$tcpar_pin first", $time1, '>',  0 );
	EVAL_evaluate_value( "$tcpar_pin first", $time1, '<=', $tcpar_firstM );

	# evaluate measured signal
	$data_HoH = EVAL_importUNV( "$main::REPORT_PATH/" . $unv_file_name_2 );

	( $NumOfPulses, $pulses ) = EVAL_get_signal_pulses( $data_HoH, $tcpar_pin, 0.4, 0.05, 'rising', 7 );
	$time1 = 0;
	my $time2 = 0;
	my $timestamp_time2;
	my $time_min_repetition = 10000000;
	my $timestamp_min_repetition;
	my $time_max_repetition = 0;
	my $timestamp_max_repetition;
	my $time_avg_repetition = 0;
	my $help;

	# calculation and evaluation of pulse duration
	foreach my $pulseNumber ( 0 .. ( $NumOfPulses - 1 ) ) {
		if ( $pulses->{"pulse$pulseNumber"}{'end'} - $pulses->{"pulse$pulseNumber"}{'start'} > $time2 ) {
			$time2           = $pulses->{"pulse$pulseNumber"}{'end'} - $pulses->{"pulse$pulseNumber"}{'start'};
			$timestamp_time2 = $pulses->{"pulse$pulseNumber"}{'start'};
		}
	}
	$time2           = sprintf( "%.2f", $time2 / 1000 );             # fix for wrong time base
	$timestamp_time2 = sprintf( "%.2f", $timestamp_time2 / 1000 );
	S_teststep_expected( "t(max duration) <= '$tcpar_duration' ms", 'TP_duration' );
	S_teststep_detected( "t(max duration) = '$time2' ms (@ $timestamp_time2 ms)", 'TP_duration' );
	EVAL_evaluate_value( "$tcpar_pin duration", $time2, '<=', $tcpar_duration );

	# calculation and evaluation of repetition time
	foreach my $pulseNumber ( 1 .. ( $NumOfPulses - 1 ) ) {
		$help = $pulseNumber - 1;
		if ( $pulses->{"pulse$pulseNumber"}{'start'} - $pulses->{"pulse$help"}{'start'} < $time_min_repetition ) {
			$time_min_repetition      = $pulses->{"pulse$pulseNumber"}{'start'} - $pulses->{"pulse$help"}{'start'};
			$timestamp_min_repetition = $pulses->{"pulse$help"}{'start'};
		}
		if ( $pulses->{"pulse$pulseNumber"}{'start'} - $pulses->{"pulse$help"}{'start'} > $time_max_repetition ) {
			$time_max_repetition      = $pulses->{"pulse$pulseNumber"}{'start'} - $pulses->{"pulse$help"}{'start'};
			$timestamp_max_repetition = $pulses->{"pulse$help"}{'start'};
		}
		$time_avg_repetition += $pulses->{"pulse$pulseNumber"}{'start'} - $pulses->{"pulse$help"}{'start'};
	}

	$time_min_repetition      = sprintf( "%.2f", $time_min_repetition / 1000 );        # fix for wrong time base
	$timestamp_min_repetition = sprintf( "%.2f", $timestamp_min_repetition / 1000 );
	S_teststep_expected( "'$tcpar_repetition_min ms' <= t(min repetition) <= '$tcpar_repetition_max ms'", 'TP_repetition' );
	S_teststep_detected( "t(min repetition) = '$time_min_repetition' ms (@ $timestamp_min_repetition ms)", 'TP_repetition' );
	EVAL_evaluate_value( "$tcpar_pin min repetition time", $time_min_repetition, '>', $tcpar_repetition_min );

	$time_max_repetition      = sprintf( "%.2f", $time_max_repetition / 1000 );        # fix for wrong time base
	$timestamp_max_repetition = sprintf( "%.2f", $timestamp_max_repetition / 1000 );
	S_teststep_expected( "'$tcpar_repetition_min ms' <= t(max repetition) <= '$tcpar_repetition_max ms'", 'TP_repetition' );
	S_teststep_detected( "t(max repetition) = '$time_max_repetition' ms (@ $timestamp_max_repetition ms)", 'TP_repetition' );
	EVAL_evaluate_value( "$tcpar_pin max repetition time", $time_max_repetition, '<', $tcpar_repetition_max );

	$time_avg_repetition = sprintf( "%.2f", $time_avg_repetition / ( $NumOfPulses - 1 ) );    # fix for wrong time base
	$time_avg_repetition = sprintf( "%.2f", $time_avg_repetition / 1000 );                    # fix for wrong time base
	S_teststep_expected( "'$tcpar_repetition_min ms' <= t(avg repetition) <= '$tcpar_repetition_max ms'", 'TP_repetition' );
	S_teststep_detected( "t(avg repetition) = '$time_avg_repetition' ms", 'TP_repetition' );
	EVAL_evaluate_interval( "$tcpar_pin average repetition time", $tcpar_repetition_min, $tcpar_repetition_max, $time_avg_repetition );
	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	push( @temperatures, TEMP_get_temperature() );

	LC_ResetTRCscanner();

	# switch ECU off
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep_detected("TEMP: $temperatures[0]");
	S_teststep_detected("UBat: $tcpar_ubat V");

	return 1;
}

1;

__END__
