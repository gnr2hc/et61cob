# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_VEPS_PowerSupply_Current;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Vehicle_ECU_Power_Supply
#TS version in DOORS: 5.11
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_FaultMemory;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_TNT_GEN;

use FuncLib_SYC_INTERFACE;
##################################

our $PURPOSE = " test that the ECU is working within the battery voltage range and that the current consumption is within the limits ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_VEPS_PowerSupply_Current

=head1 PURPOSE

test that the ECU is working within the battery voltage range and that the current consumption is within the limits

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. switch ECU on 

2. wait for ini end

3. read fault recorder

4. read ASIC temperature

5. read battery voltage 

6. measure current consumption

7. switch ECU off


I<B<Evaluation>>

1. -

2. - 

3. FLTmand, FLTopt 

4. ASIC temperature in given limits

5. battery voltage in given limits

6. ECU current in given limits

7. -


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose'      => short description of test case
	SCALAR 'Ubat'         => used battery voltage
	SCALAR 'I'            => limit of current 
	SCALAR 'CheckVoltage' => label for battery voltage
	SCALAR 'CheckTemp'    => label for ASIC temperature 
	LIST 'FLTmand'        => mandatory faults
	LIST 'FLTopt'         => optinal faults


=head2 PARAMETER EXAMPLES

	# description of test case
	purpose       = 'check power supply and current consumption at VbatLow' 
	
	# input parameter (used for stimulation and measurement)
	# Ubat is given in each test case
	Ubat          = 6.2
	
	# output parameter (used for evaluation)
	I            = 650
	FLTmand      = @('rb_pom_VbatLow_flt')
	FLTopt       = @()
	CheckTemp    = 'rb_pomv_PomAdcData_st.AdcValuesConverted_ast(0).Temperature_s32'
	CheckVoltage = 'rb_pomv_PomAdcData_st.AdcValuesConverted_ast(0).Vbat1_u16'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_I_mA;
my $tcpar_LabelCheckVoltage;
my $tcpar_LabelCheckTemp;
my $tcpar_Ubat_V;
my $tcpar_FLTmand;
my $tcpar_FLTopt;
my $correctionFactorTemp = 0.1;
my $correctionFactorUbat = 0.01;
my $toleranceUbat        = 10;     # %
my $toleranceCurrent     = 10;     # mA
my ( $ASICTemp, $Ubat, $measured_Ubat_V, $measured_I_mA, $correctionValue_V );
my ( $fltmemBosch, $fltmemPrimary, $expectedFaults_href );

# my ( $value_aref, $type );
################ global parameter declaration ###################
my $unv_file_name;
my @temperatures = ();
my @supplyLines = ( 'UBAT1_I', 'UBAT2_I', 'UBAT3_I', 'UBAT4_I' );

sub TC_set_parameters {

	$tcpar_Ubat_V = S_read_mandatory_testcase_parameter('Ubat');
	$tcpar_Ubat_V =~ s/,/./g;

	$tcpar_LabelCheckVoltage = S_read_mandatory_testcase_parameter('CheckVoltage');
	$tcpar_LabelCheckTemp    = S_read_mandatory_testcase_parameter('CheckTemp');
	$tcpar_I_mA              = S_read_mandatory_testcase_parameter('I');
	$tcpar_FLTmand           = S_read_mandatory_testcase_parameter( 'FLTmand', 'byref' );
	$tcpar_FLTopt            = S_read_mandatory_testcase_parameter( 'FLTopt', 'byref' );

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');
	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	push( @temperatures, TEMP_get_temperature() );

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Switch ECU on with measured and corrected battery voltage", 'AUTO_NBR' );
	LC_SetDVMscanner('Sense1');

	LC_ECU_On($tcpar_Ubat_V);
	S_wait_ms(4000);

	$measured_Ubat_V   = LC_MeasureOnceGetVoltage();
	$correctionValue_V = $tcpar_Ubat_V - $measured_Ubat_V;
	my $corrected_Ubat_V = $tcpar_Ubat_V + $correctionValue_V;
	S_w2rep( "corrected value = " . $corrected_Ubat_V . "; measured value = " . $measured_Ubat_V . "; correction value = " . $correctionValue_V . " \n" );

	LC_ECU_On($corrected_Ubat_V);
	S_wait_ms(4000);
	$measured_Ubat_V = LC_MeasureOnceGetVoltage();
	$measured_Ubat_V = sprintf( "%.2f", $measured_Ubat_V );
	S_teststep_2nd_level( "Battery voltage = '$measured_Ubat_V' V", 'AUTO_NBR' );
	LC_ResetDVMscanner();

	S_teststep( "Wait for end of initialization", 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Read fault recorder", 'AUTO_NBR' );
	$fltmemBosch   = LIFT_FaultMemory->read_fault_memory('Bosch');
	$fltmemPrimary = LIFT_FaultMemory->read_fault_memory('Primary');
	S_teststep_2nd_level( "Evaluate fault recorder", 'AUTO_NBR', 'evalFault' );

	S_teststep( "Read ASIC temperature", 'AUTO_NBR' );

	#	$value_aref = PD_ReadMemoryByName($tcpar_LabelCheckTemp);
	#	$type       = 'S32';
	#	$ASICTemp   = S_aref2dec( $value_aref, $type );
	$ASICTemp = PRD_Read_Memory( $tcpar_LabelCheckTemp, { memoryContentsAsInteger => 1 } );
	$ASICTemp = $ASICTemp * $correctionFactorTemp;
	$ASICTemp = sprintf( "%.2f", $ASICTemp );
	S_teststep_2nd_level( "ASIC temperature = " . $ASICTemp . " �C", 'AUTO_NBR' );
	S_teststep_2nd_level( "Evaluate ASIC temperature", 'AUTO_NBR', 'evalASICTemp' );

	S_teststep( "Read battery voltage", 'AUTO_NBR' );

	#	$value_aref = PD_ReadMemoryByName($tcpar_LabelCheckVoltage);
	#	$type       = 'U16';
	#	$Ubat       = S_aref2dec( $value_aref, $type );
	$Ubat = PRD_Read_Memory( $tcpar_LabelCheckVoltage, { memoryContentsAsInteger => 1 } );
	$Ubat = $Ubat * $correctionFactorUbat;
	$Ubat = sprintf( "%.2f", $Ubat );
	S_teststep_2nd_level( "Battery voltage = " . $Ubat . " V", 'AUTO_NBR' );
	S_teststep_2nd_level( "Evaluate battery voltage", 'AUTO_NBR', 'evalBattVolt' );

	S_teststep( "ECU current measurement", 'AUTO_NBR' );
	S_teststep_2nd_level( "Set scanner and transient recorder.", 'AUTO_NBR' );
	LC_SetTRCscanner( ['Sense1'], { 'SignalMode' => 'differential', 'VoltageRange' => 20 } );
	LC_SetTRCscanner( \@supplyLines, { 'SignalMode' => 'differential', 'VoltageRange' => 2 } );
	LC_ConfigureTRCchannels( { 'SamplingFrequency' => 500 * 1000, 'MemorySize' => 512 * 1024, 'TriggerDelay' => 0 } );

	S_teststep_2nd_level( "Start transient recorder measurement.", 'AUTO_NBR' );
	LC_MeasureTraceAnalogStart();

	S_teststep_2nd_level( "Send SW trigger to transient recorder", 'AUTO_NBR' );
	LC_MeasureTraceAnalogSendSWTrigger();

	S_teststep_2nd_level( "Wait 1.5s for measurement to be finished", 'AUTO_NBR' );
	S_wait_ms(1500);
	LC_MeasureTraceAnalogStop();

	S_teststep_2nd_level( "Evaluate current consumption", 'AUTO_NBR', 'evalCurrent' );
	$unv_file_name = $main::TC_REPORT_NAME . '.txt.unv';
	LC_MeasureTraceAnalogPlotValues( "$main::REPORT_PATH/" . $unv_file_name );
	S_w2rep( '<A HREF="./' . "$unv_file_name" . '" TYPE="text/unv">' . "Click to view TRC trace $unv_file_name" . '</A><br>' );

	S_teststep( "Switch ECU off", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_READY');

	return 1;
}

sub TC_evaluation {

	# evaluation of fault recorder
	S_teststep_expected( 'Expected faults:', 'evalFault' );
	foreach my $fault (@$tcpar_FLTmand) {
		S_teststep_expected($fault);
	}
	$expectedFaults_href = {
		'mandatory'   => $tcpar_FLTmand,
		'disjunction' => [],
		'optional'    => $tcpar_FLTopt,
	};

	$fltmemBosch->evaluate_faults( $expectedFaults_href, 'evalFault' );
	$fltmemPrimary->evaluate_faults( $expectedFaults_href, 'evalFault' );

	# evaluation of ASIC temperature
	S_teststep_expected( "ASIC temperature  < 135 �C", 'evalASICTemp' );
	S_teststep_detected( "ASIC temperature  == $ASICTemp �C", 'evalASICTemp' );
	EVAL_evaluate_value( "ASIC temperature", $ASICTemp, '<', 135 );

	# evaluation of battery voltage
	S_teststep_expected( "battery voltage (sense line) = $measured_Ubat_V V", 'evalBattVolt' );
	S_teststep_detected( "battery voltage (ECU value)  = $Ubat V", 'evalBattVolt' );
	EVAL_evaluate_value( "battery voltage", $measured_Ubat_V, '==', $Ubat, $toleranceUbat, 'relative' );

	# evaluation of current consumption
	my $data_HoH = EVAL_importUNV( "$main::REPORT_PATH/" . $unv_file_name );
	my ( $VALUES_AREF, $TIMES_AREF ) = EVAL_get_values_and_times_over_time( $data_HoH, "UBAT1_I" );

	foreach my $channel (@supplyLines) {
		my @values = EVAL_get_values_over_time( $data_HoH, $channel );
		my ( $squareamplitude, $avg_current_A );
		foreach my $datapoint (@values) { $squareamplitude += ( $datapoint * $datapoint ); }

		$squareamplitude /= scalar(@values);
		$avg_current_A = sqrt($squareamplitude);
		S_w2log( 3, "Average current of '$channel': $avg_current_A A." );
		$measured_I_mA += 1000 * $avg_current_A if $avg_current_A > 0.005;
	}

	$measured_I_mA = sprintf( "%.2f", $measured_I_mA );

	S_teststep_expected( "current = $tcpar_I_mA mA", 'evalCurrent' );
	S_teststep_detected( "current = $measured_I_mA mA", 'evalCurrent' );
	EVAL_evaluate_value( "current", $measured_I_mA, '==', $tcpar_I_mA, $toleranceCurrent, 'absolute' );
	return 1;
}

sub TC_finalization {

	LC_ResetTRCscanner();

	# switch ECU off
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep_detected("TEMP: $temperatures[0]");

	return 1;
}

1;
