# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_PAD_HWPath;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Peripheral_Sensor_Interface
#TS version in DOORS: 5.10
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_FaultMemory;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_SYC_INTERFACE;
use LIFT_QuaTe;
use LIFT_crash_simulation;
use LIFT_can_access;
use FuncLib_CREIS_Framework;
##################################

our $PURPOSE = " test that the configured devices are not deployed according to HW path of PAD therefore the HW path is set to DISABLE ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PAD_HWPath 

=head1 PURPOSE

 test that the configured devices are not deployed according to HW path of PAD therefore the HW path is set to DISABLE

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

    Ubat
    Pin
    State
    SDIS_S
    MDSMB
    CrashName
    CrashNumber

    
    [initialisation]
	switch ECU on
	erase fault recorder
	read fault recorder
	switch ECU off
	set pin to given state
	    
    [stimulation & measurement]
    set scanner
    set transient recorder
    set Ubat
    switch ECU on
	user action for setting of SDIS_S
    inject crash
    user action to remove setting of SDIS_S
    wait for end of measurement

    [evaluation]
    evaluate firing of squibs

    [finalisation]
    set pin to default state


=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'ubat'        --> battery voltage value
    SCALAR 'pin'         --> ECU pin
    SCALAR 'state'		 --> state for ECU pin
    SCALAR 'SDIS_S'		 --> value for SDIS_S line
    SCALAR 'MDSDB'       --> name of used MDS database file
    SCALAR 'CrashName'   --> name of injected crash (has to be a deployment crash with passenger airbag deloyment)
    SCALAR 'CrashNumber' --> number of injected crash
    
=head2 PARAMETER EXAMPLES

    [TC_PAD_HWPath.PADS1_PosB]
    purpose     = 'Checking_HW_path_PADS1' 
    Ubat        = 12.3 
    Pin         = 'PADS1'
    State       = 'PosB'
    SDIS_S		= 3.3
	MDSDB       = 'C:\TurboLIFT\AB12\CREIS\RT4_M3_13\SCI\SCI_M03_11_RT4_04B020_20190301.mdb'
	CrashName   = 'PT_Ramp_CA_AB1'
	CrashNumber = 24
    
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my ( $tcpar_ubat, $tcpar_pin, $tcpar_state, $tcpar_SDIS_S );
my ( $tcpar_MDSDB,    $tcpar_CrashName,       $tcpar_CrashNumber );
my ( $crashData_href, $fltmemBeforeInjection, $fltmemAfterInjection );

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_ubat   = S_read_mandatory_testcase_parameter('Ubat');
	$tcpar_pin    = S_read_mandatory_testcase_parameter('Pin');
	$tcpar_state  = S_read_mandatory_testcase_parameter('State');
	$tcpar_SDIS_S = S_read_mandatory_testcase_parameter('SDIS_S');

	$tcpar_MDSDB       = S_read_mandatory_testcase_parameter('MDSDB');
	$tcpar_CrashNumber = S_read_mandatory_testcase_parameter('CrashNumber');
	undef $tcpar_CrashName;
	$tcpar_CrashName = S_read_mandatory_testcase_parameter('CrashName') unless ( defined $tcpar_CrashNumber );

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	# 1. read next crash from MDS-Result-File (read environment states + velocities)
	if ( defined $tcpar_CrashNumber ) {
		$crashData_href = CSI_GetCrashDataFromMDS(
			{
				"CRASHINDEX"     => $tcpar_CrashNumber,
				"STATEVARIATION" => 1,
				"MDSTYPE"        => "MDSNG",
				"RESULTDB"       => $tcpar_MDSDB,
			}
		);

	}
	else {
		$crashData_href = CSI_GetCrashDataFromMDS(
			{
				"CRASHNAME"      => $tcpar_CrashName,
				"STATEVARIATION" => 1,
				"MDSTYPE"        => "MDSNG",
				"RESULTDB"       => $tcpar_MDSDB,
			}
		);

	}

	#LC_ResetTRCscanner();

	# prepare crash
	CSI_LoadAllData2Simulator($crashData_href);
	CA_simulation_start();

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_EDR();
	S_wait_ms('TIMER_ECU_READY');
	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	# 2. set environment states + velocities
	CSI_PrepareEnvironment( $crashData_href, 'before_crash', 'relaxed' );
	CREIS_PrepareMeasurementsAndReporting($crashData_href);

	PRD_Read_Fault_Memory('PRIMARY');
	PRD_Read_Fault_Memory('BOSCH');

	S_teststep( "Set '$tcpar_pin' to state '$tcpar_state'", 'AUTO_NBR' );
	if ( $tcpar_state eq 'open' ) {
		LC_DisconnectLine($tcpar_pin);
	}
	else {
		LC_SetLogicalState( $tcpar_pin, $tcpar_state );
	}

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}
### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	# start all measurement before ECU is switched on, so that network trace contains the full ECU cycle
	CREIS_StartAllMeasurements();

	S_teststep( "Switch ECU on with '$tcpar_ubat V' and wait until ECU is ready.", 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);
	S_wait_ms('TIMER_ECU_READY');

	$fltmemBeforeInjection = CREIS_StoreFaultMemory('BeforeCrash');

	S_teststep( "Set SDIS_S line to value '$tcpar_SDIS_S' V", 'AUTO_NBR' );
	S_user_action( "Set SDIS_S line to value '$tcpar_SDIS_S' V \n\n" . "Confirm popup when value is set", 'Ok' );

	S_teststep( "Start to inject the crash.", 'AUTO_NBR' );
	CSI_TriggerCrash();

	# wait for the crash duration
	CREIS_WaitUntillRecordingIsFinished();

	S_teststep( "Remove connection from SDIS_S line", 'AUTO_NBR' );
	S_user_action( "Remove connection from SDIS_S line. \n\n" . "Confirm popup when action is done", 'Ok' );

	CREIS_ReadFireCounter();
	$fltmemAfterInjection = CREIS_StoreFaultMemory('AfterCrash');

	S_teststep( "Reset environments which need reset.", 'AUTO_NBR' );
	CSI_PrepareEnvironment( $crashData_href, 'after_crash', 'relaxed' );

	S_teststep( "Call project specific post crash actions...", 'AUTO_NBR' );
	CSI_PostCrashActions($crashData_href);

	S_teststep( "Switch ECU off", 'AUTO_NBR' );
	LC_ECU_Off();

	CREIS_StopAllMeasurements();

	S_teststep( "Evaluate firing of squibs", 'AUTO_NBR', 'eval_firing' );

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	S_set_verdict(VERDICT_FAIL);

	S_teststep_expected( "check firing of squibs is according to setting of $tcpar_pin with state $tcpar_state", 'eval_firing' );
	S_teststep_detected( "<<add detected result here>>", 'eval_firing' );

	CREIS_EvaluateMeasurements($crashData_href);
	CREIS_EvaluateFaultMemory($crashData_href);
	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	S_teststep( "Set '$tcpar_pin' to default state", 'AUTO_NBR' );
	if ( $tcpar_state eq 'open' ) {
		LC_ConnectLine($tcpar_pin);
	}
	LC_SetLogicalState( $tcpar_pin, 'DEFAULT' );

	CREIS_FinishReporting($crashData_href);

	#LC_ResetTRCscanner();

	S_teststep_detected("UBat: $tcpar_ubat V");

	return 1;
}

1;
__END__
