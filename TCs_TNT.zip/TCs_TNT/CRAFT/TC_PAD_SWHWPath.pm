# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_PAD_SWHWPath;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Peripheral_Sensor_Interface
#TS version in DOORS: 5.10
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_FaultMemory;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_SYC_INTERFACE;
##################################

our $PURPOSE = " test that evaluation of SW and HW path results in the same result and that a fault is stored when there is a difference ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PAD_SWHWPath 

=head1 PURPOSE

 test that evaluation of SW and HW path results in the same result and that a fault is stored when there is a difference

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

    Ubat
    Pin
    State
    SDIS_S
    FLTmand

    
    [initialisation]
	switch ECU on
	erase fault recorder
	read fault recorder
	switch ECU off
	    
    [stimulation & measurement]
	set pin to given state
    switch ECU on
    read PAD state
    measure SDIS_S line
	user action for manipulation of SDIS_S line
    read fault recorder
    user action to remove manipulation of SDIS_S line

    [evaluation]
    evaluate PAD state
    evaluate SDIS_S measurement
    evaluate fault recorder

    [finalisation]


=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'ubat'        --> battery voltage value
    SCALAR 'pin'         --> ECU pin
    SCALAR 'state'		 --> state for ECU pin
    SCALAR 'SDIS_S'		 --> value for SDIS_S line
    SCALAR 'FLTmand'	 --> mandatory faults
    
=head2 PARAMETER EXAMPLES

    [TC_PAD_SWHWPath.PADS1_PosA]
    purpose     = 'Checking_SW_path_PADS1' 
    Ubat        = 12.3 
    Pin         = 'PADS1'
    State       = 'PosA'
    SDIS_S		= 3.3
    FLTmand		= @('rb_swm_SdlHwSwPlausibility_flt')
    
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my ( $tcpar_ubat, $tcpar_pin, $tcpar_state );
my ( $tcpar_FLTmand, $tcpar_SDIS_S );
my ( $PADState, $unv_file_name, $fltmem );

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_ubat    = S_read_mandatory_testcase_parameter('Ubat');
	$tcpar_pin     = S_read_mandatory_testcase_parameter('Pin');
	$tcpar_state   = S_read_mandatory_testcase_parameter('State');
	$tcpar_SDIS_S  = S_read_mandatory_testcase_parameter('SDIS_S');
	$tcpar_FLTmand = S_read_mandatory_testcase_parameter('FLTmand');

	return 1;

	# Label: rb_rma_PADSampleState_en
	# States
	# rb_rma_PABStates_ten;rb_rma_PABUndefined_e;  0;passenger airbag undefined (no valid measurement in ReleaseMatrix)
	# rb_rma_PABStates_ten;rb_rma_PABActivated_e;  1;passenger airbag activated
	# rb_rma_PABStates_ten;rb_rma_PABDeactivated_e;2;passenger airbag deactivated
}

#### INITIALIZE TC #####
sub TC_initialization {

	LC_ResetTRCscanner();

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_EDR();
	S_wait_ms('TIMER_ECU_READY');
	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	PRD_Read_Fault_Memory('PRIMARY');
	PRD_Read_Fault_Memory('BOSCH');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}
### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	S_teststep( "Set $tcpar_pin to state $tcpar_state", 'AUTO_NBR' );
	LC_SetLogicalState( $tcpar_pin, $tcpar_state );

	S_teststep( "Switch ECU on with '$tcpar_ubat V' and wait until ECU is ready.", 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);
	S_wait_ms('TIMER_ECU_READY');

	# S_teststep( "Read PAD state", 'AUTO_NBR', 'PADState' );
	# $PADState = PRD_Read_Memory( 'rb_rma_PADSampleState_en', { NbrOfBytes => 1, memoryContentsAsInteger => 1, } );

	S_teststep( "Measure SDIS_S line", 'AUTO_NBR' );
	S_teststep_2nd_level( "Set scanner and transient recorder.", 'AUTO_NBR' );
	LC_SetTRCscanner( ['SCON_DIS_S'], { 'SignalMode' => 'differential', 'VoltageRange' => 5 } );
	LC_ConfigureTRCchannels( { 'SamplingFrequency' => 20 * 1000, 'MemorySize' => 8 * 1024, 'TriggerDelay' => 0 } );

	S_teststep_2nd_level( "Start transient recorder measurement.", 'AUTO_NBR' );
	LC_MeasureTraceAnalogStart();
	S_wait_ms(100);
	LC_MeasureTraceAnalogSendSWTrigger();
	S_wait_ms(500);

	S_teststep_2nd_level( "Stop and store transient recorder measurement", 'AUTO_NBR' );
	$unv_file_name = $main::TC_REPORT_NAME . '.txt.unv';
	LC_MeasureTraceAnalogStop();
	LC_MeasureTraceAnalogPlotValues( "$main::REPORT_PATH/" . $unv_file_name );
	S_w2rep( '<A HREF="./' . "$unv_file_name" . '" TYPE="text/unv">' . "Click to view TRC trace $unv_file_name" . '</A><br>' );

	S_teststep( "Evaluate measured signal SDIS_S", 'AUTO_NBR', 'SDISSignal' );

	S_teststep( "Set SDIS_S line to value '$tcpar_SDIS_S' V", 'AUTONBR' );
	S_user_action( "Set SDIS_S line to value '$tcpar_SDIS_S' V \n\n" . "Confirm popup when value is set", 'Ok' );

	S_teststep( "Read fault recorder", 'AUTO_NBR', 'FaultRecorder' );
	$fltmem = LIFT_FaultMemory->read_fault_memory('Bosch');

	S_teststep( "Remove connection from SDIS_S line", 'AUTO_NBR' );
	S_user_action( "Remove connection from SDIS_S line. \n\n" . "Confirm popup when action is done", 'Ok' );

	S_teststep( "Erase fault recorder", 'AUTO_NBR' );
	PRD_Clear_Fault_Memory();

	S_teststep( "Switch ECU off", 'AUTO_NBR' );
	LC_ECU_Off();

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	my $data_HoH = EVAL_importUNV( "$main::REPORT_PATH/" . $unv_file_name );

	if ( $tcpar_state eq 'PosA' or $tcpar_state eq 'PositionA' ) {

		# S_teststep_expected( "PAD state: 2 - passenger airbag deactivated", 'PADState' );
		# S_teststep_detected( "PAD state: $PADState", 'PADState' );
		# EVAL_evaluate_value( 'PAD State:', $PADState, '==', 2 );

		S_teststep_expected( "SDIS_S line = 3.3 V", 'SDISSignal' );
		EVAL_evaluate_value_over_time( $data_HoH, 'SCON_DIS_S', '>', 3 );

	}
	elsif ( $tcpar_state eq 'PosB' or $tcpar_state eq 'PositionB' ) {

		# S_teststep_expected( "PAD state: 1 - passenger airbag activated", 'PADState' );
		# S_teststep_detected( "PAD state: $PADState", 'PADState' );
		# EVAL_evaluate_value( 'PAD State:', $PADState, '==', 1 );

		S_teststep_expected( "SDIS_S line = 0 V", 'SDISSignal' );
		EVAL_evaluate_value_over_time( $data_HoH, 'SCON_DIS_S', '<', 0.5 );
	}

	my $expectedFaults;
	$expectedFaults->{$tcpar_FLTmand} = { 'DecodedStatus' => { 'TestFailed' => 1 } };
	$fltmem->evaluate_specific_faults( $expectedFaults, 'FaultRecorder' );
	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	LC_ResetTRCscanner();

	LC_SetLogicalState( $tcpar_pin, 'DEFAULT' );

	S_teststep_detected("UBat: $tcpar_ubat V");

	return 1;
}

1;
__END__
