# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_PSI_FaultDequalification;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on various TS: e.g. AB12_TS_Feature_Firing_Loops
#TS version in DOORS:                e.g. 6.3
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_PSI5_access;
use LIFT_PD;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use LIFT_FaultMemory;
use FuncLib_TNT_GEN;
##################################

our $PURPOSE = "test that a fault for a defective peripheral sensor is dequalified if the peripheral sensor is changed";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PSI_FaultDequalification 

=head1 PURPOSE

 test that a fault for a defective peripheral sensor is dequalified if the peripheral sensor is changed

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

    Ubat
    Pin
    FLTmand
    FLTopt  (optional)

    [initialisation]
    get temperature
    UZ on with U_batt_default
    clear fault memory

    [stimulation & measurement]
    connect defective peripheral sensor
    switch ECU on
    wait for end of initialization
    read fault memory afterwards
    switch ECU off
    connect new sensor (with different serial number)
    switch ECU on
    wait for end of initialization
    read fault memory afterwards

    [evaluation]
    check if fault is qualified
    check if fault is dequalified
    send mail if not

    [finalisation]
    erase fault recorder
    switch ECU off


=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'Ubat'        --> battery voltage value
    SCALAR 'Pin'         --> ECU pin
    LIST   'FLTmand'     --> list of mandatory faults (logical names)
    LIST   'FLTopt'      --> list of optional faults (logical names)
    
=head2 PARAMETER EXAMPLES

    [TC_PSI_FaultDequalification.UFSD]
    purpose='Checking_fault_dequalification_for_UFSD' 
    Ubat=13.5 
    Pin = 'UFSD'
    FLTmand = @('rb_psem_SensorDefectUFSD_flt')

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my ( $fltmem1, $fltmem2 );

my ( $tcpar_ubat, $tcpar_pin, $text4teststep, @tcpar_FLTmand, @tcpar_FLTopt );
my @temperatures = ();

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_ubat = GEN_Read_mandatory_testcase_parameter('Ubat');
	$tcpar_pin  = GEN_Read_mandatory_testcase_parameter('Pin');

	@tcpar_FLTmand = GEN_Read_mandatory_testcase_parameter('FLTmand');
	@tcpar_FLTopt  = GEN_Read_optional_testcase_parameter('FLTopt');

	S_get_contents_of_hash( [ 'VEHICLE', 'U_BATT_DEFAULT' ] );
	S_get_contents_of_hash( [ 'TIMER',   'TIMER_ECU_FAULT_QUALIFICATION' ] );
	S_get_contents_of_hash( [ 'TIMER',   'TIMER_ECU_READY' ] );
	S_get_contents_of_hash( [ 'TIMER',   'TIMER_ECU_OFF' ] );

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PD_ClearFaultMemory();
	S_wait_ms('TIMER_ECU_READY');
	PD_GetExtendedFaultInformation();

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	push( @temperatures, TEMP_get_temperature() );
	return 1;
}

### STIMULATION AND MEASUREMENT ###
#    connect defective peripheral sensor
#    switch ECU on
#    wait for end of initialization
#    read fault memory afterwards
#    switch ECU off
#    connect new sensor (with different serial number)
#    switch ECU on
#    wait for end of initialization
#    read fault memory afterwards

sub TC_stimulation_and_measurement {

	S_teststep( "Set sensor $tcpar_pin to defect", 'AUTO_NBR' );
	PSI5_set_Sensor_Defect($tcpar_pin);

	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);

	S_teststep( 'Wait for end of initialization', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( 'Read fault recorder', 'AUTO_NBR' );
	$fltmem1 = LIFT_FaultMemory->read_fault_memory('Bosch');    #PD_GetExtendedFaultInformation();
	S_teststep( 'Evaluate fault recorder', 'AUTO_NBR', 'FaultQualified' );

	S_teststep( ' Switch ECU off.', 'AUTO_NBR' );
	LC_ECU_Off();

	S_teststep( 'Change serial number of external sensor and remove fault', 'AUTO_NBR' );
	PSI5_sensor_reinit($tcpar_pin);

	PSI5_set_Init_Data( $tcpar_pin, 2, { 'SERIES_NUMBER' => '0xAB9876543210', }, );

	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);

	S_teststep( 'Wait for end of initialization', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( 'Read fault recorder', 'AUTO_NBR' );
	$fltmem2 = LIFT_FaultMemory->read_fault_memory('Bosch');    #PD_GetExtendedFaultInformation();
	S_teststep( 'Evaluate fault recorder', 'AUTO_NBR', 'FaultDequalified' );

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

### evaluation of fault qualification
	my $qualified_faults_href = {
		@tcpar_FLTmand[0] => {

			'DecodedStatus' => {    # fault property
				'TestFailed' => 1,    # fault should be qualified
			},
		},
	};
	S_teststep_expected( 'Expected faults:', 'FaultQualified' );
	foreach my $fault (@tcpar_FLTmand) {
		S_teststep_expected($fault);
	}

	S_teststep_detected( 'Detected faults:', 'FaultQualified' );
	foreach my $fault ( @{ $fltmem1->{fault_text} } ) {
		S_teststep_detected($fault);
	}
	$fltmem1->evaluate_specific_faults( $qualified_faults_href, 'FaultQualified' );

### evaluation of fault dequalification
	my $dequalified_faults_href = {
		@tcpar_FLTmand[0] => {

			'DecodedStatus' => {    # fault property
				'TestFailed' => 0,    # fault should be qualified
			},
		},
	};
	S_teststep_expected( 'Expected faults:', 'FaultDequalified' );
	foreach my $fault (@tcpar_FLTmand) {
		S_teststep_expected($fault);
	}

	S_teststep_detected( 'Detected faults:', 'FaultDequalified' );
	foreach my $fault ( @{ $fltmem1->{fault_text} } ) {
		S_teststep_detected($fault);
	}
	$fltmem2->evaluate_specific_faults( $dequalified_faults_href, 'FaultDequalified' );

	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	# remove fault
	PSI5_sensor_reinit($tcpar_pin);
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep_detected( "TEMP: " . join( ' -> ', @temperatures ) );
	S_teststep_detected("UBat: $tcpar_ubat V");

	return 1;
}

1;

__END__
