# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_FL_MultipleElectricFiring;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Firing_Loops
#TS version in DOORS: 6.4
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_TNT_GEN;
use FuncLib_SYC_INTERFACE;
use LIFT_FaultMemory;
##################################

our $PURPOSE = " check that the ECU is able to deploy multiple times without damage ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_FL_MultipleElectricFiring

=head1 PURPOSE

check that the ECU is able to deploy multiple times without damage

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault
get temperature


I<B<Stimulation and Measurement>>

1. set scanner and transient recorder

2. switch ECU on

3. send disposal PWM signal on PIN <pin_acl> if ACL is used

4. electronic firing of ECU

4a. prepare electronic firing using RB PD
4b. read and evaluate fault recorder
4c. wait cool down time
4d. start transient recorder measurement
4e. trigger electronic firing using RB PD
4f. wait until transient recorder measurement is finished
4g. evaluate firing pulses of all squibs

5. read and evaluate fault recorder

6. clear fault recorder

7. switch ECU off


I<B<Evaluation>>

1. -

2. -

3. -

4. evaluation

4a. -
4b. check for expected faults
4c. -
4d. -
4e. -
4f. -
4g. all squibs are firing according to their configuration
    - check firing duration
    - check firing current
    - check number of firing pulses

5. check for expected faults

6. -

7. -


I<B<Finalisation>>

stop sending of disposal PWM signal if ACL is used
reset scanner

=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'UBat'          => battery voltage value 
	SCALAR 'Firing'        => number of deployments
	SCALAR 'CoolDownTime'  => wait time between two deployments
	SCALAR 'pin_acl'       => ACL Pin
	SCALAR 'source_acl'    => Source of ACL signal 
	LIST 'FLTmand'         => mandatory (expected) faults
	LIST 'FLTopt'          => optinal (accepted) faults 


=head2 PARAMETER EXAMPLES

	[TC_FL_MultipleElectricFiring.DeployMultipleLoops]
	purpose        = 'Check multiple firing - DeployMultipleLoops'
	Ubat           = 12.6
	Firing         = 6
	CoolDownTime   = 10 #s
	PinACL         = ACL
	SourceACL      = 'external'
	FLTmand        = @()
	FLTopt         = @()

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_UBat;
my $tcpar_Firing;
my $tcpar_CoolDownTime;
my $tcpar_FLTmand;
my $tcpar_FLTopt;
my $tcpar_pin_acl;
my $tcpar_source_acl;
################ global parameter declaration ###################
my @temperatures;
my @unv_file_name;
my @fltmem;
my $fltmem1;
my $time_s;
my ( $valid_flag, $return_value, $precondition_valid );
my $plantmode7_set  = 0b01000000;
my $plantmode_clear = 0b00000000;
my ( @squibList, @squibList4Scanner );
my $squibData_href;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose      = GEN_Read_mandatory_testcase_parameter('purpose');
	$tcpar_UBat         = GEN_Read_mandatory_testcase_parameter('UBat');
	$tcpar_Firing       = GEN_Read_mandatory_testcase_parameter('Firing');
	$tcpar_CoolDownTime = GEN_Read_mandatory_testcase_parameter('CoolDownTime');
	$tcpar_FLTmand      = GEN_Read_optional_testcase_parameter( 'FLTmand', 'byref' );
	$tcpar_FLTopt       = GEN_Read_optional_testcase_parameter( 'FLTopt', 'byref' );
	$tcpar_pin_acl      = GEN_Read_optional_testcase_parameter('PinACL');
	$tcpar_source_acl   = GEN_Read_optional_testcase_parameter('SourceACL');

	( $valid_flag, $return_value ) = S_read_public_variable("TEMPcontrolled");

	if ( $valid_flag == 1 and $return_value == 1 and TEMP_getTargetTemperature() > 75 ) {
		S_w2rep("Test should only run at HT - currenlty at HT");
		$precondition_valid = 1;
	}
	elsif ( $valid_flag == 1 ) {
		S_set_verdict("VERDICT_NONE");
		S_teststep_detected("Test should only run with IC for HT [IC_AB12_TEMP.HT]");
		S_teststep_detected("But Temp is not under control if IC [IC_AB12_TEMP.DEFAULT]") if $return_value == 0;

		$precondition_valid = 0;
	}
	elsif ( $valid_flag == 0 ) {
		S_set_verdict("VERDICT_NONE");
		S_teststep_detected("State of temperature is not known!");
		S_teststep_detected("IC with public variable 'TEMPcontrolled' to be used!");

		$precondition_valid = 0;
	}

	return 1;
}

sub TC_initialization {
	if ($precondition_valid) {

		# switch ECU oninitialize TRC
		LC_ECU_On('U_BATT_DEFAULT');
		S_wait_ms('TIMER_ECU_READY');

		#PD_ECUlogin();
		PD_ClearFaultMemory();
		S_wait_ms('TIMER_ECU_READY');

		PD_GetExtendedFaultInformation();
		my $device_data_href = PD_DumpDeviceConfiguration();

		# parse all squibs that are available in SW
		S_teststep( "Select a subset of squibs for evaluation (every 4th (0,4,8,12) squib of each ASIC).", 'AUTO_NBR' );
		foreach my $squib ( keys %{ $device_data_href->{'squib'}{'Prog'} } ) {
			next if $squib eq "bits" or $squib eq "variable";
			next unless ( $device_data_href->{'squib'}{'Prog'}{$squib} );

			my $deviceIndex            = PD_get_device_index($squib);
			my $loopConfigSetting_aref = PD_ReadMemoryByName("rb_sqm_SQMLoopConfigSettings_st.SQMLoopConfig_au16($deviceIndex)");

			my $flicASIC    = sprintf( "%d", $$loopConfigSetting_aref[0] >> 4 );
			my $asicChannel = sprintf( "%d", $$loopConfigSetting_aref[0] & 0xF );

			$squibData_href->{$squib}{Index}   = $deviceIndex;
			$squibData_href->{$squib}{ASIC}    = $flicASIC;
			$squibData_href->{$squib}{Channel} = $asicChannel;

			if ( $device_data_href->{'squib'}{'Prog'}{$squib} ) {
				if ( @$loopConfigSetting_aref == 0 ) {
					S_w2log( 3, "Reading SQMLoopConfigSettings not successfull for squib '$squib'. Reading the FireCounter will not be possible." );
					next;
				}

				if ( $asicChannel % 4 == 0 ) {
					push( @squibList4Scanner, $squib . "::current" );
					$squibData_href->{$squib}{AnalogMeasured} = 1;

					S_teststep( "Squib '$squib' will be evaluated as it is '$asicChannel' channel of '$flicASIC' ASIC.", 'NO_AUTO_NBR' );
				}

			}
		}
		LC_ECU_Off();
		S_wait_ms('TIMER_ECU_OFF');

	}

	push( @temperatures, TEMP_get_temperature() );

	return 1;
}

sub TC_stimulation_and_measurement {
	if ($precondition_valid) {
		S_teststep( "Set scanner and transient recorder.", 'AUTO_NBR' );
		LC_SetTRCscanner( \@squibList4Scanner, { 'SignalMode' => 'differential', 'VoltageRange' => 10 } );
		LC_ConfigureTRCchannels(
			{
				'SamplingFrequency' => 20 * 1000,
				'MemorySize'        => 8 * 1024,
				'TriggerDelay'      => 0
			}
		);

		S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
		LC_ECU_On($tcpar_UBat);
		S_wait_ms('TIMER_ECU_READY');

		S_teststep( 'Activate plant mode 7.', 'AUTO_NBR' );

		#PD_ECUlogin();
		PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [$plantmode7_set] );
		S_wait_ms(100);

		S_teststep( 'Switch ECU off.', 'AUTO_NBR' );
		LC_ECU_Off();
		S_wait_ms('TIMER_ECU_OFF');

		S_teststep( "Switch ECU on.", 'AUTO_NBR' );
		LC_ECU_On($tcpar_UBat);
		S_wait_ms('TIMER_ECU_READY');

		if ( defined $tcpar_pin_acl ) {
			S_teststep( "Send Disposal PWM on PIN '$tcpar_pin_acl'.", 'AUTO_NBR' );
			LC_ConnectLine($tcpar_pin_acl);
			LC_SendPWMDisposalStart($tcpar_pin_acl) unless $tcpar_source_acl eq 'external';
		}

		$time_s = S_get_TC_time();

		foreach my $nbrOfFiring ( 1 .. $tcpar_Firing ) {
			my $lastTime_s = $time_s;
			S_teststep( "Prepare electronic firing using RB PD.", 'AUTO_NBR' );
			PD_Prepare_electronic_firing();

			S_wait_ms(2000);

			$time_s = S_get_TC_time();

			S_w2rep("tcpar_CoolDownTime:$tcpar_CoolDownTime - (time_s:$time_s - lastTime_s:$lastTime_s)");
			my $waitTime_s = $tcpar_CoolDownTime - ( $time_s - $lastTime_s );
			$waitTime_s = sprintf( "%.3f", $waitTime_s );
			S_teststep( "Wait $waitTime_s s.", 'AUTO_NBR' ) if $waitTime_s > 0;
			S_wait_ms( $waitTime_s * 1000 ) if $waitTime_s > 0;

			$time_s = S_get_TC_time();

			S_teststep( "Start transient recorder measurement.", 'AUTO_NBR' );
			LC_MeasureTraceAnalogStart();
			LC_MeasureTraceAnalogSendSWTrigger();

			S_wait_ms(200);

			S_teststep( "Trigger electronic firing using RB PD.", 'AUTO_NBR' );
			PD_Trigger_electronic_firing();

			S_teststep( "Wait until transient recorder measurement is finished.", 'AUTO_NBR' );
			S_wait_ms(200);

			$unv_file_name[$nbrOfFiring] = S_get_TC_number() . 'firing_' . $nbrOfFiring . '.txt.unv';
			LC_MeasureTraceAnalogStop();
			LC_MeasureTraceAnalogPlotValues( "$main::REPORT_PATH/" . $unv_file_name[$nbrOfFiring] );
			S_w2rep( '<A HREF="./' . "$unv_file_name[$nbrOfFiring]" . '" TYPE="text/unv">' . "Click to view TRC trace $unv_file_name[$nbrOfFiring]" . '</A><br>' );

			foreach my $squib ( keys %$squibData_href ) {

				my $fireCounter_aref = PD_ReadMemoryByName("rb_sqmf_Firecounter_au16($squibData_href->{$squib}{ASIC})($squibData_href->{$squib}{Channel})");
				$squibData_href->{$squib}{$nbrOfFiring}{value_high_level_ms} = $$fireCounter_aref[0] * 0.025;
				$squibData_href->{$squib}{$nbrOfFiring}{value_low_level_ms}  = $$fireCounter_aref[1] * 0.025;

			}

			S_teststep( "Evaluate firing pulses of all squibs for firing '$nbrOfFiring'.", 'AUTO_NBR', 'squib_firing_' . $nbrOfFiring );
		}

		S_teststep( "Read and evaluate fault recorder.", 'AUTO_NBR', 'read_fault_recorder' );
		$fltmem1 = LIFT_FaultMemory->read_fault_memory('Bosch');

		S_teststep( "Clear Fault Memory", 'AUTO_NBR' );
		PD_ClearFaultMemory();
		S_wait_ms(500);
		PD_GetExtendedFaultInformation();
		S_teststep( "Switch ECU off.", 'AUTO_NBR' );
		LC_ECU_Off();

		S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
		LC_ECU_On($tcpar_UBat);
		S_wait_ms('TIMER_ECU_READY');

		S_teststep( 'Deactivate plant mode 7.', 'AUTO_NBR' );

		#PD_ECUlogin();
		PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [$plantmode_clear] );
		S_wait_ms(100);

		S_teststep( 'Switch ECU off.', 'AUTO_NBR' );
		LC_ECU_Off();
		S_wait_ms('TIMER_ECU_OFF');

	}
	return 1;
}

sub TC_evaluation {
	if ($precondition_valid) {
		foreach my $nbrOfFiring ( 1 .. $tcpar_Firing ) {
			S_teststep_expected( "All squibs are firing according to their configuration.", 'squib_firing_' . $nbrOfFiring );

			# evaluate measured signal
			my $data_HoH = EVAL_importUNV("$main::REPORT_PATH/$unv_file_name[$nbrOfFiring]");
			my ( @correctSquibs, @incorrectSquibs );

			foreach my $squib ( keys %$squibData_href ) {
				my $verdictNumOfPulses   = VERDICT_PASS;
				my $verdictPulseCurrent  = VERDICT_PASS;
				my $verdictPulseDuration = VERDICT_PASS;
				my ( $verdictFireCounterHighLevel, $verdictFireCounterLowLevel );
				S_w2rep("Evaluation of squib '$squib'");

				my ( $result, $tcpar_firingMode, $tcpar_min_duration_ms, $tcpar_min_current_A );

				( $result, $tcpar_firingMode ) = SYC_SQUIB_get_firing_mode($squib);
				return 0 unless $result;

				( $result, $tcpar_min_duration_ms ) = SYC_SQUIB_get_firing_pulse_min_duration($squib);
				return 0 unless $result;

				( $result, $tcpar_min_current_A ) = SYC_SQUIB_get_firing_pulse_min_current($squib);
				return 0 unless $result;

				if ( $tcpar_min_current_A >= 1.5 ) {
					S_w2rep("Expected: t(fire counter high level) >= '$tcpar_min_duration_ms' ms in firing mode '$tcpar_firingMode'");
					S_w2rep("Detected: t(fire counter high level) == '$squibData_href->{$squib}{$nbrOfFiring}{value_high_level_ms}' ms");
					$verdictFireCounterHighLevel = EVAL_evaluate_value( "t(fire counter high level)", $squibData_href->{$squib}{$nbrOfFiring}{value_high_level_ms}, '>=', $tcpar_min_duration_ms );
				}
				else {
					S_w2rep("Expected: t(fire counter high level) == '0' ms in firing mode '$tcpar_firingMode'");
					S_w2rep("Detected: t(fire counter high level) == '$squibData_href->{$squib}{$nbrOfFiring}{value_high_level_ms}' ms");
					$verdictFireCounterHighLevel = EVAL_evaluate_value( "t(fire counter high level)", $squibData_href->{$squib}{$nbrOfFiring}{value_high_level_ms}, '==', 0 );
				}

				S_w2rep("Expected: t(fire counter low level) >= '$tcpar_min_duration_ms' ms in firing mode '$tcpar_firingMode'");
				S_w2rep("Detected: t(fire counter low level) == '$squibData_href->{$squib}{$nbrOfFiring}{value_low_level_ms}' ms");
				$verdictFireCounterLowLevel = EVAL_evaluate_value( "t(fire counter low level)", $squibData_href->{$squib}{$nbrOfFiring}{value_low_level_ms}, '>=', $tcpar_min_duration_ms );

				if ( $squibData_href->{$squib}{AnalogMeasured} ) {
					my ( $NumOfPulses, $pulses ) = EVAL_get_signal_pulses( $data_HoH, $squib . '::CURRENT', 0.5, 0.01, 'rising' );
					my $squareamplitude;
					my @datapoints;
					my $current_A;
					my $pulse_duration_ms;

					S_w2rep("Expected: Nbr. of Firing pulses == 1");
					S_w2rep("Detected: Nbr. of Firing pulses == $NumOfPulses");
					$verdictNumOfPulses = EVAL_evaluate_value( "Nbr. of Firing pulses", $NumOfPulses, '==', 1 );

					next unless $NumOfPulses;

					@datapoints = @{ $pulses->{"pulse0"}{'values'} };
					foreach my $datapoint (@datapoints) {
						$squareamplitude += ( $datapoint * $datapoint );
					}
					$squareamplitude /= scalar(@datapoints);
					$current_A           = sqrt($squareamplitude);
					$current_A           = sprintf( "%.3f", $current_A );
					$verdictPulseCurrent = EVAL_evaluate_value( "I(pulse)", $current_A, '>=', $tcpar_min_current_A );
					S_w2rep("Expected: I(pulse) >= '$tcpar_min_current_A' A in firing mode '$tcpar_firingMode'");
					S_w2rep("Detected: I(pulse) == '$current_A' A");

					$pulse_duration_ms =
					  $pulses->{"pulse0"}{'end'} - $pulses->{"pulse0"}{'start'};
					$pulse_duration_ms = $pulse_duration_ms / 1000;               # fix for wrong time base
					$pulse_duration_ms = sprintf( "%.2f", $pulse_duration_ms );
					S_w2rep("Expected: t(pulse duration) >= '$tcpar_min_duration_ms' ms in firing mode '$tcpar_firingMode'");
					S_w2rep("Detected: t(pulse duration) == '$pulse_duration_ms' ms");
					$verdictPulseDuration = EVAL_evaluate_value( "t(pulse duration)", $pulse_duration_ms, '>=', $tcpar_min_duration_ms );

				}

				if (    $verdictNumOfPulses eq VERDICT_PASS
					and $verdictPulseCurrent eq VERDICT_PASS
					and $verdictPulseDuration eq VERDICT_PASS
					and $verdictFireCounterHighLevel eq VERDICT_PASS
					and $verdictFireCounterLowLevel eq VERDICT_PASS )
				{
					push @correctSquibs, $squib;
				}
				else {
					push @incorrectSquibs, $squib;
				}
			}

			my $textCorrect = "---";
			$textCorrect = join( ', ', @correctSquibs ) if @correctSquibs;

			if (@incorrectSquibs) {
				my $textIncorrect = join( ', ', @incorrectSquibs );
				S_teststep_detected( "Not all squibs are firing according to their configuration.", 'squib_firing_' . $nbrOfFiring );
				S_teststep_detected("Incorrect: $textIncorrect.");
				S_teststep_detected("Correct: $textCorrect.");
			}
			else {
				S_teststep_detected( "All squibs are firing according to their configuration.", 'squib_firing_' . $nbrOfFiring );
				S_teststep_detected("Correct: $textCorrect.");
			}
		}

		$fltmem1->evaluate_faults(
			{
				'mandatory' => $tcpar_FLTmand,
			},
			"read_fault_recorder"
		);
	}
	return 1;
}

sub TC_finalization {
	if ($precondition_valid) {
		if ( defined $tcpar_pin_acl ) {
			LC_DisconnectLine($tcpar_pin_acl);
			LC_SendPWMDisposalStop($tcpar_pin_acl) unless $tcpar_source_acl eq 'external';
		}
		LC_ResetTRCscanner();
	}

	S_teststep_detected("TEMP: $temperatures[0]");
	S_teststep_detected("UBat: $tcpar_UBat V");

	return 1;
}

1;
