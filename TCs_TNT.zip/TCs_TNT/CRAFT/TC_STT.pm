# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#    $Source: CRAFT/TC_STT.pm $
#    $Revision: 1.2 $
#    $Author: Withohn Sabine (CC-PS/EPS2) (WII2SI) $
#    $State: release $
#    $Date: 2016/12/16 23:13:40ICT $
#******************************************************************************************************

#### TEST CASE MODULE
package TC_STT;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.2 $;
our $HEADER  = q$Header: CRAFT/TC_STT.pm 1.2 2016/12/16 23:13:40ICT Withohn Sabine (CC-PS/EPS2) (WII2SI) release  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_STT
#TS version in DOORS: 1.1
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_TNT_GEN;
use FuncLib_SYC_INTERFACE;
##################################

our $PURPOSE = "STT: set temperature, read fault recorder, optional perform electronic firing and/or read labels";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_STT

=head1 PURPOSE

step temperature test: set temperature, read fault recorder, optional perform electronic firing and/or read labels
(if electronic firing is performed TRC is used for measuring the squib firing pulses)

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

1) Init TRC (if electronic firing requested)
 
2) Set temperature

3) Wait for 5 min


I<B<Stimulation and Measurement>>

1. Switch ECU on

2. Wait for duration ms

3. Optional part
3a. Set scanner and transient recorder
3b. Pepare electronic firing using RB PD
3c. Start transient recorder measurement
3d. Trigger electronic firing using RB PD
3e. Wait until transient recorder measurement is finished
3f. Evaluate squib firing for all squibs

4. Read labels

5. Read and evaluate fault recorder

6. Clear fault memory

7. Switch ECU off


I<B<Evaluation>>

1. -

2. - 

3f. All squibs are firing according to their configuration 

4. Document value(s)

5. Evaluate fault recorder

6. -

7. -


I<B<Finalisation>>

Document used battery voltage and temperature


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Ubat'			--> battery voltage value 
	SCALAR 'Duration_ms'	--> duration in ms for that the ECU is switched on before test 
	SCALAR 'T'				--> temperature in �C (positive value = 25, negative value = m30)
	SCALAR 'ElectricFiring'	--> 1 = electronic firing is done; 0 = no electronic firing
	SCALAR 'ECUReset'       --> 1 = ECU reset is done;         0 = no ECU reset
	SCALAR 'Reading'        --> 1 = read labels;               0 = no reading
	LIST 'Labels'           --> list of labels to be read
	LIST 'FLTmand'			--> expected mandatory faults
	LIST 'FLTopt'			--> accepted optional faults


=head2 PARAMETER EXAMPLES

	# description of test case
	purpose='step temperature test for Tdown_20' 
	
	# input parameter (used for stimulation and measurement)
	Ubat = 13.5 #V
	Duration_ms = 30000 #ms
	T = 20 #�C
	ElectricFiring = 0 # no electronic firing
	Reading = 0 # no reading
	Labels = @()
	ECUReset	= 0 # no reset
	
	# output parameter (used for evaluation)
	FLTmand = @() # no mandatory faults expected
	FLTopt = @()  # no optional faults expected
	

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_FLTmand;
my $tcpar_FLTopt;
my $tcpar_Labels;
my $tcpar_Ubat;
my $tcpar_Duration_ms;
my $tcpar_T;
my ($fltmem1);
my $PD_resp;
my @temperatures;
my ( $result, $unv_file_name );
my %LabelValue = ();
my ( $tcpar_ElectricFiring, $tcpar_Reading ) = 0;
my ($tcpar_Reset) = 1;
################ global parameter declaration ###################
#add any global variables here

###############################################################

sub TC_set_parameters {

    $tcpar_Ubat           = GEN_Read_mandatory_testcase_parameter('Ubat');
    $tcpar_Duration_ms    = GEN_Read_mandatory_testcase_parameter('Duration_ms');
    $tcpar_T              = GEN_Read_mandatory_testcase_parameter('T');
    $tcpar_ElectricFiring = GEN_Read_optional_testcase_parameter('ElectricFiring');
    $tcpar_Reading        = GEN_Read_optional_testcase_parameter('Reading');
    $tcpar_Reset          = GEN_Read_optional_testcase_parameter('ECUReset');
    $tcpar_Labels         = GEN_Read_optional_testcase_parameter( 'Labels', 'byref' );
    $tcpar_FLTmand        = GEN_Read_optional_testcase_parameter( 'FLTmand', 'byref' );
    $tcpar_FLTopt         = GEN_Read_optional_testcase_parameter( 'FLTopt', 'byref' );

    if ( $tcpar_T =~ /m(\d+)/ ) {
        $tcpar_T = -$1;
    }
    elsif ( $tcpar_T =~ /p(\d+)/ ) {
        $tcpar_T = $1;
    }

    return 1;
}

sub TC_initialization {

    if ($tcpar_Reset) {
        LC_ECU_Off();
    }

    # initialize TRC
    # TRC_InitHW() if ($tcpar_ElectricFiring);
    TEMP_setTargetTemperature($tcpar_T);

    S_w2rep( " * set temperature $tcpar_T �C * \n", 'green' );
    TEMP_waitForTemperature( 120, 2 );

    #    S_w2rep("Wait 5 min. \n");
    #    S_wait_ms( 5 * 60 * 1000 );

    S_w2rep("Wait 2 min. \n");
    S_wait_ms( 2 * 60 * 1000 );

    push( @temperatures, TEMP_get_temperature() );
    return 1;
}

sub TC_stimulation_and_measurement {

    S_teststep( "Switch ECU on.", 'AUTO_NBR' );
    LC_ECU_On($tcpar_Ubat);

    S_teststep( "Wait for '$tcpar_Duration_ms' ms.", 'AUTO_NBR' );
    S_wait_ms($tcpar_Duration_ms);

    PD_ECUlogin();

    if ($tcpar_ElectricFiring) {

        S_teststep( "Set scanner and transient recorder.", 'AUTO_NBR' );
        LC_SetTRCscanner( ['ALL_SQUIBS::current'], { 'SignalMode' => 'differential', 'VoltageRange' => 10 } );
        LC_ConfigureTRCchannels(
            {
                'SamplingFrequency' => 20 * 1000,
                'MemorySize'        => 8 * 1024,
                'TriggerDelay'      => 0
            }
        );

        S_teststep( "Prepare electronic firing using RB PD.", 'AUTO_NBR' );
        S_wait_ms(100);
        LC_ConnectLine('ACL');
        PD_Prepare_electronic_firing();

        S_wait_ms(2000);

        S_teststep( "Start transient recorder measurement.", 'AUTO_NBR' );
        LC_MeasureTraceAnalogStart();
        LC_MeasureTraceAnalogSendSWTrigger();

        S_teststep( "Trigger electronic firing using RB PD.", 'AUTO_NBR' );
        PD_Trigger_electronic_firing();

        S_teststep( "Wait until transient recorder measurement is finished.", 'AUTO_NBR' );
        S_wait_ms(500);

        $unv_file_name = S_get_TC_number() . '_STT_TRCtrace_elecfiring.txt.unv';
        LC_MeasureTraceAnalogPlotValues( "$main::REPORT_PATH/" . $unv_file_name );
        S_w2rep( '<A HREF="./' . "$unv_file_name" . '" TYPE="text/unv">' . "Click to view TRC trace $unv_file_name" . '</A><br>' );
        LC_ResetTRCscanner();
        S_teststep( "Evaluate squib firing for all squibs...", 'AUTO_NBR', 'squib_firing' );

    }

    if ($tcpar_Reading) {
        my ( $dec_value, $type );
        S_teststep( "Reading of given labels", 'AUTO_NBR', 'ReadLabels' );
        foreach my $label ( @{$tcpar_Labels} ) {
            S_teststep_2nd_level( "Read label '$label'", 'AUTO_NBR' );
            $PD_resp   = PD_ReadMemoryByName($label);
            $type      = PD_get_type_from_name($label);
            $dec_value = S_aref2dec( $PD_resp, $type );
            S_w2rep( "$label = $dec_value \n", 'blue' );
            $LabelValue{$label} = $dec_value;
        }
    }

    S_teststep( "Read and evaluate fault recorder.", 'AUTO_NBR', 'read_fault_recorder' );    #measurement 2
    $fltmem1 = PD_GetExtendedFaultInformation();

    S_teststep( "Clear fault memory", 'AUTO_NBR' );
    PD_ClearFaultMemory();
    S_wait_ms(500);
    PD_GetExtendedFaultInformation();

    if ($tcpar_Reset) {
        S_teststep( "Switch ECU off", 'AUTO_NBR' );
        LC_ECU_Off();
    }

    return 1;
}

sub TC_evaluation {

    if ($tcpar_ElectricFiring) {

        S_teststep_expected( "All squibs are firing according to their configuration.", 'squib_firing' );

        # evaluate measured signal
        my $data_HoH = EVAL_importUNV("$main::REPORT_PATH/$unv_file_name");
        my ( @correctSquibs, @incorrectSquibs );

        foreach my $squib ( TSG4_get_names("SQUIBS") ) {

            S_w2rep("Evaluation of squib '$squib'");

            my ( $result, $tcpar_firingMode, $tcpar_min_duration_ms, $tcpar_min_current_A );

            ( $result, $tcpar_firingMode ) = SYC_SQUIB_get_firing_mode($squib);
            return 0 unless $result;

            ( $result, $tcpar_min_duration_ms ) = SYC_SQUIB_get_firing_pulse_min_duration($squib);
            return 0 unless $result;

            ( $result, $tcpar_min_current_A ) = SYC_SQUIB_get_firing_pulse_min_current($squib);
            return 0 unless $result;

            my ( $NumOfPulses, $pulses ) = EVAL_get_signal_pulses( $data_HoH, $squib . '::CURRENT', 0.5, 0.01, 'rising' );
            my $squareamplitude;
            my @datapoints;
            my $current_A;
            my $pulse_duration_ms;
            my ( $verdictNumOfPulses, $verdictPulseCurrent, $verdictPulseDuration );

            S_w2rep("Expected: Nbr. of Firing pulses == 1");
            S_w2rep("Detected: Nbr. of Firing pulses == $NumOfPulses");
            $verdictNumOfPulses = EVAL_evaluate_value( "Nbr. of Firing pulses", $NumOfPulses, '==', 1 );

            next unless $NumOfPulses;

            @datapoints = @{ $pulses->{"pulse0"}{'values'} };
            foreach my $datapoint (@datapoints) {
                $squareamplitude += ( $datapoint * $datapoint );
            }
            $squareamplitude /= scalar(@datapoints);
            $current_A           = sqrt($squareamplitude);
            $current_A           = sprintf( "%.3f", $current_A );
            $verdictPulseCurrent = EVAL_evaluate_value( "I(pulse)", $current_A, '>=', $tcpar_min_current_A );
            S_w2rep("Expected: I(pulse) >= '$tcpar_min_current_A' A in firing mode '$tcpar_firingMode'");
            S_w2rep("Detected: I(pulse) == '$current_A' A");

            $pulse_duration_ms =
              $pulses->{"pulse0"}{'end'} - $pulses->{"pulse0"}{'start'};
            $pulse_duration_ms = $pulse_duration_ms / 1000;               # fix for wrong time base
            $pulse_duration_ms = sprintf( "%.2f", $pulse_duration_ms );
            S_w2rep("Expected: t(pulse duration) >= '$tcpar_min_duration_ms' ms in firing mode '$tcpar_firingMode'");
            S_w2rep("Detected: t(pulse duration) == '$pulse_duration_ms' ms");
            $verdictPulseDuration = EVAL_evaluate_value( "t(pulse duration)", $pulse_duration_ms, '>=', $tcpar_min_duration_ms );

            if ( $verdictNumOfPulses eq VERDICT_PASS and $verdictPulseCurrent eq VERDICT_PASS and $verdictPulseDuration eq VERDICT_PASS ) {
                push @correctSquibs, $squib;
            }
            else {
                push @incorrectSquibs, $squib;
            }
        }

        my $textCorrect = "---";
        $textCorrect = join( ', ', @correctSquibs ) if @correctSquibs;

        if (@incorrectSquibs) {
            my $textIncorrect = join( ', ', @incorrectSquibs );
            S_teststep_detected( "Not all squibs are firing according to their configuration.", 'squib_firing' );
            S_teststep_detected("Incorrect: $textIncorrect.");
            S_teststep_detected("Correct: $textCorrect.");
        }
        else {
            S_teststep_detected( "All squibs are firing according to their configuration.", 'squib_firing' );
            S_teststep_detected("Correct: $textCorrect.");
        }
    }

    if ($tcpar_Reading) {
        S_teststep_detected( 'Read labels:', 'ReadLabels' );
        foreach my $label ( keys %LabelValue ) {
            S_teststep_detected("Label '$label' = $LabelValue{$label} ");
        }
    }

    S_teststep_expected( 'Expected faults:', 'read_fault_recorder' );
    foreach my $fault ( @{$tcpar_FLTmand} ) {
        S_teststep_expected($fault);
    }

    S_teststep_detected( 'Detected faults:', 'read_fault_recorder' );
    foreach my $fault ( @{ $fltmem1->{fault_text} } ) {
        S_teststep_detected($fault);
    }
    PD_evaluate_faults( $fltmem1, $tcpar_FLTmand, $tcpar_FLTopt );

    return 1;
}

sub TC_finalization {

    # TRC_CloseHW() if ($tcpar_ElectricFiring);
    LC_ResetTRCscanner() if ($tcpar_ElectricFiring);
    LCT_DisconnectLine('ACL') if ($tcpar_ElectricFiring);
    S_teststep_detected("TEMP: $temperatures[0]");
    S_teststep_detected("UBat: $tcpar_Ubat V");

    return 1;
}

1;
