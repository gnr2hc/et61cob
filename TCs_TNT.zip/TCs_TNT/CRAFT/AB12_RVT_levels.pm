# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#    $Source: CRAFT/AB12_RVT_levels.pm $
#    $Revision: 1.8 $
#    $Author: Withohn Sabine (CC-PS/EPS2) (WII2SI) $
#    $State: develop $
#    $Date: 2020/05/15 17:53:02ICT $
#******************************************************************************************************

#### TEST CASE MODULE
package AB12_RVT_levels;

#### DONT MODIFY THIS SECTION ####
use strict;
###-------------------------------
our $VERSION = q$Revision: 1.8 $;
our $HEADER  = q$Header: CRAFT/AB12_RVT_levels.pm 1.8 2020/05/15 17:53:02ICT Withohn Sabine (CC-PS/EPS2) (WII2SI) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Vehicle_ECU_Power_Supply
#TS version in DOORS: 5.11
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_TOE1;
use LIFT_PD;
use LIFT_TEMPERATURE;
use FuncLib_TNT_GEN;
##################################

our $PURPOSE = "switch between different voltage levels";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

RB_RVT_levels $Revision: 1.8 $


TO DO: rename parameters, use upper and lower band instead on/off

=head1 PURPOSE

switch to different voltage levels

=head1 TESTCASE DESCRIPTION

This test will create an on and off curve with random values between given min/max values. 
The test will store a curve file for later reproduction and put an image of the curve in the report.

To re-run single test just copy the parameters for RB_voltage_file from report to parameter file.
To re-run all failed tests use parameter file RB_RVT_levels_failed.par created in report folder.

[parameter used]

    Testcase Parameter:

    ONmin
    ONmax
    OFFmin
    OFFmax
    Vmin
    Vmax
    MAXtime
    FLTmand (optional)
    FLTopt  (optional)

    [initialisation]
    create random voltage curve between min and max values
    UZ on with U_batt_default
    clear fault memory
    switch ECU off
    wait TIMER_ECU_OFF

    [stimulation & measurement]
    run random voltage curve
    set U_batt_default
    read fault memory afterwards

    [evaluation]
    check if fault memory is empty
    send mail if not

    [finalisation]
    switch ECU off


=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'ONmin'      --> minimum ontime in milliseconds
    SCALAR 'ONmax'      --> maximum ontime in milliseconds
    SCALAR 'OFFmin'     --> minimum offtime in milliseconds
    SCALAR 'OFFmax'     --> maximum offtime in milliseconds
    SCALAR 'Vmin'       --> minimum voltage in volts
    SCALAR 'Vmax'       --> maximum voltage in volts
    SCALAR 'MAXtime'    --> maximum runtime of curve in seconds
    LIST   'FLTmand'    --> list of mandatory faults (logical names)
    LIST   'FLTopt'     --> list of optional faults (logical names)

=head2 PARAMETER EXAMPLES
    [TC_RVT1.full_range]
    purpose     = 'randow voltage test full range'
    ONmin       = 1
    ONmax       = 3000
    OFFmin      = 1
    OFFmax      = 2000
    Vmin        = 9.5
    Vmax        = 15
    MAXtime     = 60


=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my ( $duration,    $Parstring );
my ( $fltmem1,     $filename, $fltmem2, $fltmem3, $fltmem4 );
my ( $tcpar_ONmin, $tcpar_ONmax, $tcpar_OFFmin, $tcpar_OFFmax, $tcpar_Vmin, $tcpar_Vmax, $tcpar_MAXtime, @tcpar_FLTmand, @tcpar_FLTopt );
my @temperatures = ();
my ( $faultType, @squibList, @devices );

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_ONmin   = GEN_Read_mandatory_testcase_parameter('ONmin');
	$tcpar_ONmax   = GEN_Read_mandatory_testcase_parameter('ONmax');
	$tcpar_OFFmin  = GEN_Read_mandatory_testcase_parameter('OFFmin');
	$tcpar_OFFmax  = GEN_Read_mandatory_testcase_parameter('OFFmax');
	$tcpar_Vmin    = GEN_Read_mandatory_testcase_parameter('Vmin');
	$tcpar_Vmax    = GEN_Read_mandatory_testcase_parameter('Vmax');
	$tcpar_MAXtime = GEN_Read_mandatory_testcase_parameter('MAXtime');

	@tcpar_FLTmand = GEN_Read_optional_testcase_parameter('FLTmand');
	@tcpar_FLTopt  = GEN_Read_optional_testcase_parameter('FLTopt');

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	my $name = "curve" . time();

	$filename = $main::REPORT_PATH . "/$name.sat";

	# add some copy paste parameter set for RB_voltage_file e.g.:
	# [TC_VEPS_VoltageCurves.curve1214396433]
	# purpose            = 're-run RVT_levels curve1214396433'
	# curvefile          = 'C:\curves\curve1214396433.sat'

	S_teststep( "generate voltage curve from parameter", 'AUTO_NBR' );
	$Parstring = "[TC_VEPS_VoltageCurves.$name]\n";
	$Parstring .= "purpose     = 're-run RVT_levels $name'\n";
	$Parstring .= "curvefile   = '$filename'\n";

	push( @temperatures, TEMP_get_temperature() );

	S_teststep( "create random voltag curve", 'AUTO_NBR' );
	TOE1_createRandomOnOffFile( $filename, $tcpar_ONmax, $tcpar_ONmin, $tcpar_OFFmax, $tcpar_OFFmin, $tcpar_Vmax * 1000, $tcpar_Vmin * 1000, $tcpar_MAXtime );

	S_w2rep("\ncopy paste parameter set for TC_VEPS_VoltageCurves.par:\n\n$Parstring\n");

	S_teststep( "create graph of random voltage curve", 'AUTO_NBR' );
	TOE1_createGraph( $filename, 'U_BATT_UNDERVOLTAGE', 'U_BATT_OVERVOLTAGE' );
	S_add_pic2html("$name.png");
	S_w2rep(" voltage curve $name\n");

	S_teststep( "load voltage curve to power supply", 'AUTO_NBR' );
	$duration = TOE1_setCurveFile($filename);

	S_teststep( "switch ECU On", 'AUTO_NBR' );
	TOE1_PPSvoltage('U_BATT_DEFAULT');
	TOE1_PPSon();
	S_wait_ms('TIMER_ECU_READY');

	PD_ECUlogin();

	S_teststep( "clear fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "switch ECU off", 'AUTO_NBR' );
	TOE1_PPSoff();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep( "switch ECU On", 'AUTO_NBR' );
	TOE1_PPSon();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "read fault recorder", 'AUTO_NBR' );
	S_teststep_2nd_level( "read primary fault recorder", 'AUTO_NBR' );
	PD_GetExtendedFaultInformation(PRIMARY_FLT_MEM);
	S_teststep_2nd_level( "read Bosch fault recorder", 'AUTO_NBR' );
	PD_GetExtendedFaultInformation(BOSCH_FLT_MEM);
	S_teststep_2nd_level( "read plant fault recorder", 'AUTO_NBR' );
	PD_GetExtendedFaultInformation(PLANT_FLT_MEM);
	S_teststep_2nd_level( "read disturbed fault recorder", 'AUTO_NBR' );
	PD_GetExtendedFaultInformation(DISTURBANCE_FLT_MEM);

	S_teststep( "switch ECU off", 'AUTO_NBR' );
	TOE1_PPSoff();
	S_wait_ms('TIMER_ECU_OFF');

	push( @temperatures, TEMP_get_temperature() );
	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	#    S_teststep( "generate squib faults", 'AUTO_NBR' );
	#
	#    S_teststep_2nd_level( "define fault type and select squibs", 'AUTO_NBR' );
	#    if ( rand(2) > 1 ) {
	#        $faultType = 'short2gnd';
	#        @devices   = LC_Get_names('SQUIBS');
	#        foreach my $squib (@devices) {
	#            if ( rand(8) < 1 ) {
	#                push( @squibList,     $squib . '+' );
	#                push( @tcpar_FLTmand, 'rb_sqm_TerminalShort2Gnd' . $squib . '_flt' );
	#            }
	#        }
	#        S_teststep_2nd_level( "create short2gnd fault for selected squibs", 'AUTO_NBR' );
	#        push( @squibList, 'B-' );
	#        LC_ShortLines( \@squibList );
	#    }
	#    else {
	#        $faultType = 'short2bat';
	#        @devices   = LC_Get_names('SQUIBS');
	#        foreach my $squib (@devices) {
	#            if ( rand(8) < 1 ) {
	#                push( @squibList,     $squib . '+' );
	#                push( @tcpar_FLTmand, 'rb_sqm_TerminalShort2Bat' . $squib . '_flt' );
	#            }
	#        }
	#        S_teststep_2nd_level( "create short2bat fault for selected squibs", 'AUTO_NBR' );
	#        push( @squibList, 'B+' );
	#        LC_ShortLines( \@squibList );
	#    }
	#    S_user_action("Start Voltage Curve");
	S_teststep( "start voltage curve", 'AUTO_NBR' );
	TOE1_runCurve();
	S_wait_ms($duration);
	S_wait_ms(500);

	S_teststep( "get ambient temperature", 'AUTO_NBR' );
	push( @temperatures, TEMP_get_temperature() );

	S_teststep( "switch ECU on", 'AUTO_NBR' );
	TOE1_PPSvoltage('U_BATT_DEFAULT');
	TOE1_PPSon();

	S_teststep( "wait for ini end", 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	PD_ECUlogin();

	S_teststep( "read fault recorder", 'AUTO_NBR', 'read_fault' );
	S_teststep_2nd_level( "read primary fault recorder", 'AUTO_NBR', 'read_fault_primary' );
	$fltmem1 = PD_GetExtendedFaultInformation(PRIMARY_FLT_MEM);
	S_teststep_2nd_level( "read Bosch fault recorder", 'AUTO_NBR', 'read_fault_bosch' );
	$fltmem2 = PD_GetExtendedFaultInformation(BOSCH_FLT_MEM);
	S_teststep_2nd_level( "read plant fault recorder", 'AUTO_NBR', 'read_fault_plant' );
	$fltmem3 = PD_GetExtendedFaultInformation(PLANT_FLT_MEM);
	S_teststep_2nd_level( "read disturbed fault recorder", 'AUTO_NBR', 'read_fault_disturb' );
	$fltmem4 = PD_GetExtendedFaultInformation(DISTURBANCE_FLT_MEM);

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	S_teststep_expected( 'Expected faults:', 'read_fault' );
	foreach my $fault (@tcpar_FLTmand) {
		S_teststep_expected( $fault . " (mandatory)" );
	}
	foreach my $fault (@tcpar_FLTopt) {
		S_teststep_expected( $fault . " (optional)" );
	}

	S_teststep_detected( 'Detected faults (primary fault recorder):', 'read_fault_primary' );
	foreach my $fault ( @{ $fltmem1->{fault_text} } ) {
		S_teststep_detected($fault);
	}
	my $eval_primary = PD_evaluate_faults( $fltmem1, \@tcpar_FLTmand, \@tcpar_FLTopt );

	S_teststep_detected( 'Detected faults (Bosch fault recorder):', 'read_fault_bosch' );
	foreach my $fault ( @{ $fltmem2->{fault_text} } ) {
		S_teststep_detected($fault);
	}
	my $eval_bosch = PD_evaluate_faults( $fltmem2, \@tcpar_FLTmand, \@tcpar_FLTopt );

	S_teststep_detected( 'Detected faults (plant fault recorder):', 'read_fault_plant' );
	foreach my $fault ( @{ $fltmem3->{fault_text} } ) {
		S_teststep_detected($fault);
	}

	S_teststep_detected( 'Detected faults (disturbance fault recorder):', 'read_fault_disturb' );
	foreach my $fault ( @{ $fltmem4->{fault_text} } ) {
		S_teststep_detected($fault);
	}

	unless ( $eval_primary eq VERDICT_PASS and $eval_bosch eq VERDICT_PASS ) {

		# append parameter set to RB_RVT_ramps_failed.par
		my $failed_file = $main::REPORT_PATH . "/AB12_RVT_levels_failed.par";
		open( FAILED_PAR, ">>$failed_file" );
		print( FAILED_PAR "\n$Parstring\n" );
		close(FAILED_PAR);

		#S_user_action("AB_Lampe checken");
	}

	# check idlemode
	my @idlestate;
	@idlestate = ();
	my $value_aref = PD_ReadMemoryByName('rb_bswm_IdleModeData_st.BlockIdleMode_u16');
	push( @idlestate, @$value_aref );
	$value_aref = PD_ReadMemoryByName('rb_bswm_IdleModeData_st.PermIdleMode_u16');
	push( @idlestate, @$value_aref );

	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	#    S_teststep( "remove all faults", 'AUTO_NBR' );
	#    LC_UndoShortLines();

	S_teststep( "switch ECU off", 'AUTO_NBR' );
	TOE1_PPSoff();
	S_wait_ms('TIMER_ECU_OFF');

	push( @temperatures, TEMP_get_temperature() );

	S_w2rep( "\nlogged temperatures in celsius: " . join( ' -> ', @temperatures ) . "\n", 'blue' );

	return 1;
}

1;

__END__
