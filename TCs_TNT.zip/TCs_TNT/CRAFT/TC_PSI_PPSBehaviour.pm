# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_PSI_PPSBehaviour;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on various TS: e.g. AB12_TS_Feature_Peripheral_Sensor_Interface
#TS version in DOORS:                e.g. 5.10
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;

#use LIFT_PD;
use LIFT_ProdDiag;
use LIFT_FaultMemory;
use LIFT_TEMPERATURE;
use LIFT_PSI5_access;
use LIFT_evaluation;
use FuncLib_TNT_GEN;
##################################

our $PURPOSE = "check that the PPS behaviour is correct when different pressure information is send";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PSI_PPSBehaviour 

=head1 PURPOSE

 check that the PPS behaviour is correct when different pressure information is send

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

	'TIMER_ECU_FAULT_QUALIFICATION'
	'TIMER_ECU_READY'
	'TIMER_ECU_OFF'
	'U_BATT_DEFAULT'
    Ubat
    Pin
    FLTmand
    FLTopt  (optional)

    [initialisation]
    get temperature
    UZ on with U_batt_default
    clear fault memory

    [stimulation & measurement]
    (1)  Set P0 too low for 'sensor'
    (2)  Switch ECU on
    (3)  Read fault memory
    (4)  Evaluate fault memory
    (5)  Switch ECU off
    (6)  Remove fault and erase fault memory
    
    (7)  Set P0 too high for 'sensor'
    (8)  Switch ECU on
    (9)  Read fault memory
    (10) Evaluate fault memory
    (11) Switch ECU off
    (12) Remove fault and erase fault memory
    
    (13) Set pressure difference > 430LSB for 'sensor'
    (14) Switch ECU on
    (15) Read fault memory
    (16) Evaluate fault memory
    (17) Switch ECU off
    (18) Remove fault and erase fault memory    

    [evaluation]
    (4)  evaluate fault memory - FLTmand1
    (10) evaluate fault memory - FLTmand1
    (16) evaluate fault memory - FLTmand2

    [finalisation]
    remove fault
    switch ECU off


=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'ubat'        --> battery voltage value
    SCALAR 'pin'         --> tested pin
    LIST   'FLTmand1'     --> list of mandatory faults (logical names)
    LIST   'FLTmand2'     --> list of mandatory faults (logical names)
    LIST   'FLTopt'      --> list of optional faults (logical names)
    
=head2 PARAMETER EXAMPLES

    [TC_PSI_PPSBehaviour.PPSFD]
    purpose='Checking_PPSBehaviour_PPSFD' 
    Ubat=14.1 
    Pin = 'PPSFD'
    FLTmand1 = @('rb_psem_SensorDefectPPSFD_flt')
    FLTmand2 = @('rb_psem_PPSAbsolutePressure_flt')
    
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my ( $fltmemBosch1, $fltmemPrimary1, $fltmemBosch2, $fltmemPrimary2, $fltmemBosch3, $fltmemPrimary3 );
my ( $expectedFaults1_href, $expectedFaults2_href, $expectedFaults3_href );

my ( $tcpar_ubat, $tcpar_pin, $tcpar_FLTmand1, $tcpar_FLTmand2, $tcpar_FLTopt );
my @temperatures = ();

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_ubat     = S_read_mandatory_testcase_parameter('Ubat');
	$tcpar_pin      = S_read_mandatory_testcase_parameter('Pin');
	$tcpar_FLTmand1 = S_read_mandatory_testcase_parameter( 'FLTmand1', 'byref' );
	$tcpar_FLTmand2 = S_read_mandatory_testcase_parameter( 'FLTmand2', 'byref' );
	$tcpar_FLTopt   = S_read_optional_testcase_parameter( 'FLTopt', 'byref' );

	S_get_contents_of_hash( [ 'VEHICLE', 'U_BATT_DEFAULT' ] );
	S_get_contents_of_hash( [ 'TIMER',   'TIMER_ECU_FAULT_QUALIFICATION' ] );
	S_get_contents_of_hash( [ 'TIMER',   'TIMER_ECU_READY' ] );
	S_get_contents_of_hash( [ 'TIMER',   'TIMER_ECU_OFF' ] );

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	push( @temperatures, TEMP_get_temperature() );
	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	S_teststep( "Set P0 too low for $tcpar_pin", 'AUTO_NBR' );
	PSI5_sensor_reinit($tcpar_pin);
	PSI5_set_Sensor_Defect( $tcpar_pin, '0x203' );

	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	S_teststep_2nd_level( 'Switch power supply on', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);
	S_teststep_2nd_level( 'Wait for end of initialization', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( 'Read fault recorder', 'AUTO_NBR' );
	$fltmemBosch1   = LIFT_FaultMemory->read_fault_memory('Bosch');
	$fltmemPrimary1 = LIFT_FaultMemory->read_fault_memory('Primary');
	S_teststep( 'Evaluate fault recorder', 'AUTO_NBR', 'Fault1' );

	S_teststep( 'Switch ECU off.', 'AUTO_NBR' );
	S_teststep_2nd_level( 'Switch power supply off', 'AUTO_NBR' );
	LC_ECU_Off();
	S_teststep_2nd_level( 'Wait for ECU off', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep( "Remove fault and erase fault memory", 'AUTO_NBR' );
	S_teststep_2nd_level( "Remove fault", 'AUTO_NBR' );
	PSI5_sensor_reinit($tcpar_pin);

	S_teststep_2nd_level( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);
	S_wait_ms('TIMER_ECU_READY');

	S_teststep_2nd_level( "Clear fault recorder", 'AUTO_NBR' );
	PRD_Clear_Fault_Memory();

	S_teststep_2nd_level( 'Switch ECU off.', 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep( "Set P0 too high for $tcpar_pin", 'AUTO_NBR' );
	PSI5_set_Sensor_Defect( $tcpar_pin, '0x202' );

	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	S_teststep_2nd_level( 'Switch power supply on', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);
	S_teststep_2nd_level( 'Wait for end of initialization', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( 'Read fault recorder', 'AUTO_NBR' );
	$fltmemBosch2   = LIFT_FaultMemory->read_fault_memory('Bosch');
	$fltmemPrimary2 = LIFT_FaultMemory->read_fault_memory('Primary');
	S_teststep( 'Evaluate fault recorder', 'AUTO_NBR', 'Fault2' );

	S_teststep( 'Switch ECU off.', 'AUTO_NBR' );
	S_teststep_2nd_level( 'Switch power supply off', 'AUTO_NBR' );
	LC_ECU_Off();
	S_teststep_2nd_level( 'Wait for ECU off', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep( "Remove fault and erase fault memory", 'AUTO_NBR' );
	S_teststep_2nd_level( "Remove fault", 'AUTO_NBR' );
	PSI5_sensor_reinit($tcpar_pin);

	S_teststep_2nd_level( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);
	S_wait_ms('TIMER_ECU_READY');

	S_teststep_2nd_level( "Clear fault recorder", 'AUTO_NBR' );
	PRD_Clear_Fault_Memory();

	S_teststep_2nd_level( 'Switch ECU off.', 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep( "Set pressure difference > 430LSB for $tcpar_pin", 'AUTO_NBR' );
	PSI5_set_Init_Data( $tcpar_pin, 3, { 'INIT3_MESSAGE' => 'SENSOR_OK', 'ABSOLUTE_PRESSURE_VALUE' => '500', }, );
	PSI5_set_CyclicMsgs( $tcpar_pin, { 'ABSOLUTE_PRESSURE_VALUE' => '500' } );

	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	S_teststep_2nd_level( 'Switch power supply on', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);
	S_teststep_2nd_level( 'Wait for end of initialization', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( 'Read fault recorder', 'AUTO_NBR' );
	$fltmemBosch3   = LIFT_FaultMemory->read_fault_memory('Bosch');
	$fltmemPrimary3 = LIFT_FaultMemory->read_fault_memory('Primary');
	S_teststep( 'Evaluate fault recorder', 'AUTO_NBR', 'Fault3' );

	S_teststep( 'Switch ECU off.', 'AUTO_NBR' );
	S_teststep_2nd_level( 'Switch power supply off', 'AUTO_NBR' );
	LC_ECU_Off();
	S_teststep_2nd_level( 'Wait for ECU off', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep( "Remove fault and erase fault memory", 'AUTO_NBR' );
	S_teststep_2nd_level( "Remove fault", 'AUTO_NBR' );
	PSI5_sensor_reinit($tcpar_pin);

	S_teststep_2nd_level( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);
	S_wait_ms('TIMER_ECU_READY');

	S_teststep_2nd_level( "Clear fault recorder", 'AUTO_NBR' );
	PRD_Clear_Fault_Memory();

	S_teststep_2nd_level( 'Switch ECU off.', 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	S_teststep_expected( 'Expected faults:', 'Fault1' );
	foreach my $fault (@$tcpar_FLTmand1) {
		S_teststep_expected($fault);
	}

	$expectedFaults1_href = {
		'mandatory'   => $tcpar_FLTmand1,
		'disjunction' => [],
		'optional'    => $tcpar_FLTopt,
	};

	$fltmemBosch1->evaluate_faults( $expectedFaults1_href, 'Fault1' );
	$fltmemPrimary1->evaluate_faults( $expectedFaults1_href, 'Fault1' );

	S_teststep_expected( 'Expected faults:', 'Fault2' );
	foreach my $fault (@$tcpar_FLTmand1) {
		S_teststep_expected($fault);
	}

	$expectedFaults2_href = {
		'mandatory'   => $tcpar_FLTmand1,
		'disjunction' => [],
		'optional'    => $tcpar_FLTopt,
	};

	$fltmemBosch2->evaluate_faults( $expectedFaults2_href, 'Fault2' );
	$fltmemPrimary2->evaluate_faults( $expectedFaults2_href, 'Fault2' );

	S_teststep_expected( 'Expected faults:', 'Fault3' );
	foreach my $fault (@$tcpar_FLTmand2) {
		S_teststep_expected($fault);
	}

	$expectedFaults3_href = {
		'mandatory'   => $tcpar_FLTmand2,
		'disjunction' => [],
		'optional'    => $tcpar_FLTopt,
	};

	$fltmemBosch3->evaluate_faults( $expectedFaults3_href, 'Fault3' );
	$fltmemPrimary3->evaluate_faults( $expectedFaults3_href, 'Fault3' );

	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	# remove fault
	PSI5_sensor_reinit($tcpar_pin);
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep_detected( "TEMP: " . join( ' -> ', @temperatures ) );
	S_teststep_detected("UBat: $tcpar_ubat V");

	return 1;
}

1;

__END__
