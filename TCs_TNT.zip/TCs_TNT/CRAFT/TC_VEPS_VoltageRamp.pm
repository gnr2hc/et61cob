# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_VEPS_VoltageRamp;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Vehicle_ECU_Power_Supply
#TS version in DOORS: 5.11
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_TOE1;    # is this use needed??
use LIFT_ProdDiag;
use LIFT_FaultMemory;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_TNT_GEN;
##################################

our $PURPOSE = "test that the ECU stores no internal fault for a battery voltage ramp";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

RB_voltage_file 

=head1 PURPOSE

test that the ECU stores no internal fault for a battery voltage ramp

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

    UbatStart
    UbatStop
    Speed
    FLTmand
    FLTopt

    [initialisation]
    get temperature
    switch ECU on
    clear fault memory
    reset ECU
    read fault recorder
    switch ECU off

    [stimulation & measurement]
    start battery voltage ramp
    switch ECU on
    read fault recorder

    [evaluation]
    check if fault memory matches given faults
    send mail if not

    [finalisation]
    switch ECU off


=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'UbatStart'  --> start voltage for ramp
    SCALAR 'UbatStop'   --> stop voltage for ramp
    SCALAR 'Speed'      --> speed of change for ramp
    LIST   'FLTmand'    --> list of mandatory faults (logical names)
    LIST   'FLTopt'     --> list of optional faults (logical names)

=head2 PARAMETER EXAMPLES

    [TC_VEPS_VoltageRamp.Ramp-0-33V]
    purpose='check battery voltage Ramp-0-33V'
    UbatStart=0 #V
	UbatStop=33 #V
	Speed=10 #mV/s
	FLTmand=@()
	FLTopt=@('rb_pom_VbatLow_flt','rb_pom_VbatHigh_flt')
    	
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my ( $duration,        $time,           $pic );
my ( $tcpar_ubatStart, $tcpar_ubatStop, $tcpar_speed, $tcpar_FLTmand, $tcpar_FLTopt );
my ( $fltmemBosch,     $fltmemPrimary,  $expectedFaults_href );

my @temperatures = ();

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_ubatStart = S_read_mandatory_testcase_parameter('UbatStart');
	$tcpar_ubatStop  = S_read_mandatory_testcase_parameter('UbatStop');
	$tcpar_speed     = S_read_mandatory_testcase_parameter('Speed');

	$tcpar_FLTmand = S_read_optional_testcase_parameter('FLTmand');
	$tcpar_FLTopt  = S_read_optional_testcase_parameter('FLTopt');

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	# switch ECU on and read fault recorder
	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	push( @temperatures, TEMP_get_temperature() );
	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	S_teststep( "Create file name for voltage ramp.", 'AUTO_NBR' );
	my $filename = "$main::REPORT_PATH/" . "ramp_" . $tcpar_ubatStart . "V_" . $tcpar_ubatStop . "V_" . time() . ".txt";

	# generate voltage ramp using TOE1 functions
	S_teststep( "Calculate runtime for voltage ramp in ms", 'AUTO_NBR' );
	$time = 1000 * ( abs( $tcpar_ubatStart - $tcpar_ubatStop ) ) / ( $tcpar_speed * 0.001 );

	S_teststep( "Generate voltage ramp.", 'AUTO_NBR' );
	$duration = TOE1_setCurveRamp( $tcpar_ubatStart, $tcpar_ubatStop, $time );

	S_teststep( "Create graph for generated voltage ramp.", 'AUTO_NBR' );
	$pic = TOE1_createRampGraph( $filename, [ [ $tcpar_ubatStart, $tcpar_ubatStop, $time ] ], 7, 18 );
	S_add_pic2html("$pic");

	S_teststep( "Run voltage ramp and wait for curve to be finished.", 'AUTO_NBR' );
	TOE1_runCurve();
	S_wait_ms($duration);
	S_wait_ms(500);

	push( @temperatures, TEMP_get_temperature() );
	S_teststep( "Switch ECU on.", 'AUTO_NBR' );
	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Read fault recorder.", 'AUTO_NBR' );
	$fltmemBosch   = LIFT_FaultMemory->read_fault_memory('Bosch');
	$fltmemPrimary = LIFT_FaultMemory->read_fault_memory('Primary');
	S_teststep( 'Evaluate fault recorder', 'AUTO_NBR', 'Fault' );
	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	S_teststep_expected( 'Expected faults:', 'Fault' );
	foreach my $fault (@$tcpar_FLTmand) {
		S_teststep_expected($fault);
	}

	$expectedFaults_href = {
		'mandatory'   => $tcpar_FLTmand,
		'disjunction' => [],
		'optional'    => $tcpar_FLTopt,
	};

	$fltmemBosch->evaluate_faults( $expectedFaults_href, 'Fault' );
	$fltmemPrimary->evaluate_faults( $expectedFaults_href, 'Fault' );

	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	push( @temperatures, TEMP_get_temperature() );

	S_teststep_detected( "TEMP: " . join( ' -> ', @temperatures ) );
	return 1;
}

1;

__END__
