# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_FL_TestPulse;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Firing_Loops
#TS version in DOORS: 6.4
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_TNT_GEN;
use FuncLib_SYC_INTERFACE;
##################################

our $PURPOSE = " record the test pulses on each squib line and check that all parameters are correct ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

RB_voltage_file 

=head1 PURPOSE

 record the test pulses on each squib line and check that all parameters are correct

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

    Ubat
    Pin
    testCurrent
    repetitionTime
    nofireCondition
    nofireMagnetic

    [initialisation]
    get temperature
    

    [stimulation & measurement]
    set scanner
    set transient recorder
    set Ubat
    switch ECU on
    wait for end of measurement
    

    [evaluation]
    evaluate measured signal for
    - test current
    - repetition time
    - no fire condition
    send mail if not

    [finalisation]
    switch ECU off


=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'ubat'          		 --> battery voltage value
    SCALAR 'pin'           		 --> ECU pin
    SCALAR 'testCurrent'		 --> current of test pulse
    SCALAR 'repetitionTime'	   	 --> value when the measurement is repeated
    SCALAR 'nofireCondition'	 --> check that current stays in no fire condition
    SCALAR 'nofireMagnetic'		 --> check that current stays in no fire condition
    
=head2 PARAMETER EXAMPLES

	[TC_FL_TestPulse.BT1FD]
	purpose='$check test pulses for BT1FD' 
	Ubat=10.6
	Pin = 'BT1FD'
	testCurrent=40 #mA
	repetitionTime=200 #ms
	nofireCondition=0.4 #A
	nofireMagnetic=120 #mA
    
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my ( $tcpar_ubat, $tcpar_pin, $tcpar_current, $tcpar_repetition, $unv_file_name, $tcpar_current_min, $tcpar_current_max, $tcpar_repetition_min, $tcpar_repetition_max, $tcpar_avg_repetition_min, $tcpar_avg_repetition_max );
my ($result);
my @temperatures = ();

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_ubat = GEN_Read_mandatory_testcase_parameter('Ubat');
	$tcpar_pin  = GEN_Read_mandatory_testcase_parameter('Pin');

	( $result, $tcpar_current ) = SYC_SQUIB_get_TestCurrent();
	return 0 unless $result;
	$tcpar_current_min = $tcpar_current - 10;
	$tcpar_current_max = $tcpar_current + 10;

	( $result, $tcpar_repetition ) = SYC_SQUIB_get_RepetitionTime();
	return 0 unless $result;

	$tcpar_avg_repetition_min = $tcpar_repetition - 5;
	$tcpar_avg_repetition_max = $tcpar_repetition + 5;

	$tcpar_repetition_min = $tcpar_repetition - 10;
	$tcpar_repetition_max = $tcpar_repetition + 10;

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	# switch ECU on
	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	#PD_ECUlogin();
	PD_ClearFaultMemory();
	S_wait_ms('TIMER_ECU_READY');

	PD_GetExtendedFaultInformation();

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	push( @temperatures, TEMP_get_temperature() );

	return 1;
}
### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	S_teststep( "Set scanner and transient recorder.", 'AUTO_NBR' );
	LC_SetTRCscanner( ['UBAT1'], { 'SignalMode' => 'differential', 'VoltageRange' => 20 } );
	LC_SetTRCscanner( [ "$tcpar_pin" . '::current' ], { 'SignalMode' => 'differential', 'VoltageRange' => 2 } );
	LC_ConfigureTRCchannels( { 'SamplingFrequency' => 20 * 1000, 'MemorySize' => 256 * 1024, 'TriggerDelay' => 0 } );

	S_teststep( "Start transient recorder measurement.", 'AUTO_NBR' );
	LC_MeasureTraceAnalogStart();

	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);

	S_teststep( "Wait 10s.", 'AUTO_NBR' );
	S_wait_ms(10000);

	S_teststep( "Send SW Trigger to transient recorder.", 'AUTO_NBR' );
	LC_MeasureTraceAnalogSendSWTrigger();

	S_teststep( "Wait until transient recorder measurement is finished.", 'AUTO_NBR' );
	S_wait_ms(15000);

	$unv_file_name = $main::TC_REPORT_NAME . '.txt.unv';
	LC_MeasureTraceAnalogStop();
	LC_MeasureTraceAnalogPlotValues( "$main::REPORT_PATH/" . $unv_file_name );
	S_w2rep( '<A HREF="./' . "$unv_file_name" . '" TYPE="text/unv">' . "Click to view TRC trace $unv_file_name" . '</A><br>' );

	S_teststep( "Evaluate measured signal for...", 'AUTO_NBR' );
	S_teststep_2nd_level( "average current of test pulses",                     'AUTO_NBR', 'TP_current' );
	S_teststep_2nd_level( "repetition time of test pulses (min, max, average)", 'AUTO_NBR', 'TP_repetition' );

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	# evaluate measured signal
	my $data_HoH = EVAL_importUNV( "$main::REPORT_PATH/" . $unv_file_name );

	my ( $NumOfPulses, $pulses ) = EVAL_get_signal_pulses( $data_HoH, $tcpar_pin . '::CURRENT', 0.02, 0, 'rising' );
	my $time_min_repetition = 10000000;
	my $timestamp_min_repetition;
	my $time_max_repetition = 0;
	my $timestamp_max_repetition;
	my $time_avg_repetition = 0;
	my $help;
	my $squareamplitude;
	my @datapoints;
	my $current_A;
	my $avg_current_A;
	my $avg_current_mA;

	# calculation and evaluation of repetition time

	foreach my $pulseNumber ( 0 .. ( $NumOfPulses - 1 ) ) {
		$help       = $pulseNumber - 1;
		@datapoints = @{ $pulses->{"pulse$pulseNumber"}{'values'} };

		foreach my $datapoint (@datapoints) { $squareamplitude += ( $datapoint * $datapoint ); }
		$squareamplitude /= scalar(@datapoints);
		$current_A = sqrt($squareamplitude);
		$avg_current_A += $current_A;

		next if $pulseNumber == 0;    # ignore first pulse for repetition calculation as there is no previous pulse

		if ( $pulses->{"pulse$pulseNumber"}{'start'} - $pulses->{"pulse$help"}{'start'} < $time_min_repetition ) {
			$time_min_repetition      = $pulses->{"pulse$pulseNumber"}{'start'} - $pulses->{"pulse$help"}{'start'};
			$timestamp_min_repetition = $pulses->{"pulse$help"}{'start'};
		}
		if ( $pulses->{"pulse$pulseNumber"}{'start'} - $pulses->{"pulse$help"}{'start'} > $time_max_repetition ) {
			$time_max_repetition      = $pulses->{"pulse$pulseNumber"}{'start'} - $pulses->{"pulse$help"}{'start'};
			$timestamp_max_repetition = $pulses->{"pulse$help"}{'start'};
		}
		$time_avg_repetition += $pulses->{"pulse$pulseNumber"}{'start'} - $pulses->{"pulse$help"}{'start'};
	}

	$avg_current_mA = 1000 * $avg_current_A / ($NumOfPulses);
	$avg_current_mA = sprintf( "%.2f", $avg_current_mA );
	S_teststep_expected( "'$tcpar_current_min mA' <= average current <= '$tcpar_current_max mA'", 'TP_current' );
	S_teststep_detected( "average current = '$avg_current_mA' mA ", 'TP_current' );
	EVAL_evaluate_interval( "$tcpar_pin average current", $tcpar_current_min, $tcpar_current_max, $avg_current_mA );

	$time_min_repetition      = $time_min_repetition / 1000;               # fix for wrong time base
	$timestamp_min_repetition = $timestamp_min_repetition / 1000;
	$time_min_repetition      = sprintf( "%.2f", $time_min_repetition );
	S_teststep_expected( "t(min repetition) >= '$tcpar_repetition_min ms'", 'TP_repetition' );
	S_teststep_detected( "t(min repetition) = '$time_min_repetition' ms (@ $timestamp_min_repetition ms)", 'TP_repetition' );
	EVAL_evaluate_value( "$tcpar_pin min repetition time", $time_min_repetition, '>', $tcpar_repetition_min );

	$time_max_repetition      = $time_max_repetition / 1000;               # fix for wrong time base
	$timestamp_max_repetition = $timestamp_max_repetition / 1000;
	$time_max_repetition      = sprintf( "%.2f", $time_max_repetition );
	S_teststep_expected( "t(max repetition) <= '$tcpar_repetition_max ms'", 'TP_repetition' );
	S_teststep_detected( "t(max repetition) = '$time_max_repetition' ms (@ $timestamp_max_repetition ms)", 'TP_repetition' );
	EVAL_evaluate_value( "$tcpar_pin max repetition time", $time_max_repetition, '<', $tcpar_repetition_max );

	$time_avg_repetition = $time_avg_repetition / ( $NumOfPulses - 1 );    # fix for wrong time base
	$time_avg_repetition = $time_avg_repetition / 1000;                    # fix for wrong time base
	$time_avg_repetition = sprintf( "%.2f", $time_avg_repetition );
	S_teststep_expected( "'$tcpar_avg_repetition_min ms' <= t(avg repetition) <= '$tcpar_avg_repetition_max ms'", 'TP_repetition' );
	S_teststep_detected( "t(avg repetition) = '$time_avg_repetition' ms", 'TP_repetition' );
	EVAL_evaluate_interval( "$tcpar_pin average repetition time", $tcpar_avg_repetition_min, $tcpar_avg_repetition_max, $time_avg_repetition );
	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	LC_ResetTRCscanner();

	# switch ECU off
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep_detected("TEMP: $temperatures[0]");
	S_teststep_detected("UBat: $tcpar_ubat V");

	return 1;
}

1;

__END__
