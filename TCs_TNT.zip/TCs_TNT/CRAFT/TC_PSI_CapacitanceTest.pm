# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_PSI_CapacitanceTest;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Peripheral_Sensor_Interface
#TS version in DOORS: 5.11
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_TNT_GEN;
##################################

our $PURPOSE = " PSI capacitance test with/without connected sensor ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PSI_CapacitanceTest 

=head1 PURPOSE

 PSI capacitance test with/without connected sensor

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

    Ubat
    Pin
    FLTmand

    [initialisation]
    disconnect all periphery
    activate plant modes
    
    [stimulation & measurement]
    set Ubat
    connect sensor if required
    switch ECU on and off (to stimulate fault)
    switch ECU on
    wait power on time
    read fault memory
    switch ECU off
    
    [evaluation]
    check fault memory
    
    [finalisation]
    connect all periphery
    deactivate plant modes

=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'ubat_v'     --> battery voltage value
    SCALAR 'pin'  		--> sensor which will be connected
    LIST   'FLTmand'	--> list of mandatory faults (logical names)
    
=head2 PARAMETER EXAMPLES

	[TC_PSI_CapacitanceTest.Master_1_UFSD]
	purpose='Checking_PSI_CapacitanceTest_Master_1_UFSD' 
	Ubat=10.2 
	Pin = 'UFSD'
	FLTmand = @('rb_psem_PsiCapacitance_flt')
    
=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_ubat_v;
my $tcpar_pin;
my $tcpar_pin2;
my @tcpar_FLTmand;

################ global parameter declaration ###################
my ($fltmem);
my $temperature;
my @names;
my $plantmode11_set  = 0b100;
my $plantmode2_3_set = 0b110;
my $plantmode_clear  = 0b000;
my $count            = 3;
###############################################################
sub TC_set_parameters {

	$tcpar_ubat_v  = GEN_Read_mandatory_testcase_parameter('Ubat');
	$tcpar_pin     = GEN_Read_mandatory_testcase_parameter('Pin');
	$tcpar_pin2    = GEN_Read_mandatory_testcase_parameter('Pin2');
	@tcpar_FLTmand = GEN_Read_mandatory_testcase_parameter('FLTmand');

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	# switch ECU on
	S_w2rep("Switch ECU on");
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	#PD_ECUlogin();
	S_wait_ms(300);

	# activate plant modes
	S_w2rep("Activate plant modes (11 and 2 and 3)");
	PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [$plantmode2_3_set] );
	PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(1)', [$plantmode11_set] );
	S_wait_ms(300);

	# switch ECU off
	S_w2rep("Switch ECU off");
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	# disconnect all periphery
	S_w2rep("Disconnect all periphery");
	@names = LC_Get_names('SQUIBS');
	push( @names, LC_Get_names('PAS_LINES') );
	push( @names, LC_Get_names('BELT_LOCKS') );
	push( @names, LC_Get_names('WARNING_LAMPS') );
	foreach my $line (@names) {
		LC_DisconnectLine($line);
	}

	# erase fault recorder
	S_w2rep("Erase fault recorder");
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	#PD_ECUlogin();
	PD_ClearFaultMemory();
	S_wait_ms('TIMER_ECU_READY');
	PD_GetExtendedFaultInformation();
	S_wait_ms('TIMER_ECU_READY');
	PD_ClearFaultMemory();
	LC_ECU_Off();

	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	# get temperature value
	$temperature = TEMP_get_temperature();
	S_teststep( "Get temperature $temperature �C ", 'AUTO_NBR' );

	# connect sensor if required
	S_teststep( 'connect required sensors', 'AUTO_NBR' );
	if ( $tcpar_pin eq 'noSensor' ) {
		S_teststep_2nd_level( 'no sensor connected', 'AUTO_NBR' );
	}
	elsif ( $tcpar_pin2 eq 'Capacitor' ) {
		S_teststep_2nd_level( "sensor $tcpar_pin connected", 'AUTO_NBR' );
		LC_ConnectLine($tcpar_pin);
		S_teststep_2nd_level( '10nF capacitor connected', 'AUTO_NBR' );
		S_user_action( "Connect 10nF capacitor parallel to sensor $tcpar_pin", 'Ok' );
	}
	else {
		S_teststep_2nd_level( " sensor $tcpar_pin connected ", 'AUTO_NBR' );
		LC_ConnectLine($tcpar_pin);
		S_teststep_2nd_level( " sensor $tcpar_pin2 connected ", 'AUTO_NBR' );
		LC_ConnectLine($tcpar_pin2);
	}

	# switch ECU on and off (to stimulate fault)
	S_teststep( "Switch ECU on and off for $count times to stimulate fault", 'AUTO_NBR' );
	for ( my $i = 0 ; $i < $count ; $i++ ) {
		LC_ECU_On($tcpar_ubat_v);
		S_wait_ms('TIMER_ECU_READY');
		LC_ECU_Off();
		S_wait_ms('TIMER_ECU_OFF');
	}

	# switch ECU on and wait power on time
	S_teststep( "Switch ECU on with battery voltage = $tcpar_ubat_v", 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat_v);
	S_wait_ms('TIMER_ECU_READY');

	# read fault memory
	S_teststep( 'Read fault memory', 'AUTO_NBR' );

	#PD_ECUlogin();
	S_wait_ms(2000);
	$fltmem = PD_GetExtendedFaultInformation();
	S_teststep( 'Evaluate fault recorder', 'AUTO_NBR', 'FLT' );

	# switch ECU off and wait power off time
	S_teststep( 'Switch ECU off', 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	if ( $tcpar_pin2 eq 'Capacitor' ) {
		S_teststep( '10nF capacitor disconnected', 'AUTO_NBR' );
		S_user_action( "Remove connected 10nF capacitor", 'Ok' );
	}

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	S_teststep_expected( 'Expected faults:', 'FLT' );
	foreach my $fault (@tcpar_FLTmand) {
		S_teststep_expected($fault);
	}

	S_teststep_detected( 'Detected faults:', 'FLT' );
	foreach my $fault ( @{ $fltmem->{fault_text} } ) {
		S_teststep_detected($fault);
	}
	PD_evaluate_faults( $fltmem, \@tcpar_FLTmand );

	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	# connect all periphery
	S_w2rep("Connect all periphery");
	foreach my $line (@names) {
		LC_ConnectLine($line);
	}

	# switch ECU on
	S_w2rep("Switch ECU on");
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	#PD_ECUlogin();
	S_wait_ms(300);

	# deactivate plant modes
	S_w2rep("Deactivate plant modes (11 and 2 and 3)");
	PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [$plantmode_clear] );
	PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(1)', [$plantmode_clear] );
	S_wait_ms(300);

	# switch ECU off
	S_w2rep("Switch ECU off");
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}

1;

__END__
