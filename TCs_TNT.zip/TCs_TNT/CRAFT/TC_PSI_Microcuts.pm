# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_PSI_Microcuts;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Peripheral_Sensor_Interface
#TS version in DOORS: 5.11
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_TNT_GEN;
##################################

our $PURPOSE = "test that a microcut (10�s) disturbs only one data frame and no defect is stored";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PSI_Microcuts 

=head1 PURPOSE

 test that a microcut (10�s) disturbs only one data frame and no defect is stored

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

    Ubat
    Pin
    FLTmand
    FLTopt  (optional)

    [initialisation]
    get temperature
    UZ on with U_batt_default
    clear fault memory

    [stimulation & measurement]
    set Ubat
    wait for end of initialization
    apply microcut
    wait
    read fault memory afterwards

    [evaluation]
    check if fault memory matches given faults
    send mail if not

    [finalisation]
    switch ECU off


=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'ubat'        --> battery voltage value
    SCALAR 'pin'         --> ECU pin
    LIST   'FLTmand'     --> list of mandatory faults (logical names)
    LIST   'FLTopt'      --> list of optional faults (logical names)
    
=head2 PARAMETER EXAMPLES

    [TC_PSI_Microcuts.UFSFD]
    purpose='Checking Microcuts UFSFD' 
	Ubat=13.2
	pin='UFSFD'
	FLTmand=''
    
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my ($fltmem1);

my ( $tcpar_ubat, $tcpar_pin, @tcpar_FLTmand, @tcpar_FLTopt );
my @temperatures = ();

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_ubat    = GEN_Read_mandatory_testcase_parameter('Ubat');
	$tcpar_pin     = GEN_Read_mandatory_testcase_parameter('Pin');
	@tcpar_FLTmand = GEN_Read_optional_testcase_parameter('FLTmand');
	@tcpar_FLTopt  = GEN_Read_optional_testcase_parameter('FLTopt');

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	#PD_ECUlogin();
	PD_ClearFaultMemory();
	S_wait_ms('TIMER_ECU_READY');

	PD_GetExtendedFaultInformation();

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	push( @temperatures, TEMP_get_temperature() );
	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);
	S_wait_ms('TIMER_ECU_READY');

	#PD_ECUlogin();
	PD_GetExtendedFaultInformation();

	S_teststep( "Apply microcut to '$tcpar_pin' for '10' microseconds", 'AUTO_NBR' );
	LC_LV124_microcut( $tcpar_pin, 10 );
	S_teststep( 'Wait for fault qualification time', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

	S_teststep( 'Read fault recorder', 'AUTO_NBR' );
	$fltmem1 = PD_GetExtendedFaultInformation();
	S_teststep( 'Evaluate fault recorder', 'AUTO_NBR', 'FLT' );

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	S_teststep_expected( 'Expected faults:', 'FLT' );
	foreach my $fault (@tcpar_FLTmand) {
		S_teststep_expected($fault);
	}

	S_teststep_detected( 'Detected faults:', 'FLT' );
	foreach my $fault ( @{ $fltmem1->{fault_text} } ) {
		S_teststep_detected($fault);
	}
	PD_evaluate_faults( $fltmem1, \@tcpar_FLTmand, \@tcpar_FLTopt );

	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep_detected( "TEMP: " . join( ' -> ', @temperatures ) );
	S_teststep_detected("UBat: $tcpar_ubat V");

	return 1;
}

1;

__END__
