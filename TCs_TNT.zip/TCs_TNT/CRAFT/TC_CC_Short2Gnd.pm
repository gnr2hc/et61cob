# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_CC_Short2Gnd;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Firing_Loops
#TS version in DOORS: 6.4
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_TNT_GEN;
##################################

our $PURPOSE = "test that a cross coupling fault is not detected when one squib has a short2gnd";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

RB_voltage_file 

=head1 PURPOSE

 test that a cross coupling fault is not detected when one squib has a short2gnd

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

    Ubat
    Pin1
    Pin2
	Pin3
    FLTmand
    FLTopt  (optional)

    [initialisation]
    get temperature
    UZ on with U_batt_default
    clear fault memory

    [stimulation & measurement]
    apply fault
    set Ubat
    wait for fault qualification
    read fault memory afterwards

    [evaluation]
    check if fault memory matches given faults
    send mail if not

    [finalisation]
    remove fault
    switch ECU off


=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'ubat'        --> battery voltage value
    SCALAR 'pin1'        --> first ECU pin
    SCALAR 'pin2'        --> second ECU pin
	SCALAR 'pin3'        --> B+ or B-
    LIST   'FLTmand'     --> list of mandatory faults (logical names)
    LIST   'FLTopt'      --> list of optional faults (logical names)
    
=head2 PARAMETER EXAMPLES

    [TC_CC_Short2Gnd.BLFD_BLFP]
    purpose='Checking Short2Gnd(passive) BLFD' 
	Ubat=13.2
	pin1='BLFD+'
	pin2='BLFP+'
	pin3='B-'
	FLTmand='rb_swm_ShortLineBLFD_flt'
    
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my ( $tcpar_ubat, $tcpar_pin1, $tcpar_pin2, $tcpar_pin3, @tcpar_FLTmand, @tcpar_FLTopt, $fltmem1, );
my @temperatures = ();

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_ubat    = GEN_Read_mandatory_testcase_parameter('Ubat');
	$tcpar_pin1    = GEN_Read_mandatory_testcase_parameter('Pin1');
	$tcpar_pin2    = GEN_Read_mandatory_testcase_parameter('Pin2');
	$tcpar_pin3    = GEN_Read_mandatory_testcase_parameter('Pin3');
	@tcpar_FLTmand = GEN_Read_optional_testcase_parameter('FLTmand');
	@tcpar_FLTopt  = GEN_Read_optional_testcase_parameter('FLTopt');

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PD_ECUlogin();
	PD_ClearFaultMemory();
	S_wait_ms('TIMER_ECU_READY');
	PD_GetExtendedFaultInformation();

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	push( @temperatures, TEMP_get_temperature() );
	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	S_teststep( "Short '$tcpar_pin1', '$tcpar_pin2' and '$tcpar_pin3' line. ", 'AUTO_NBR' );
	LC_ShortLines( [ $tcpar_pin1, $tcpar_pin2, $tcpar_pin3 ] );

	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);

	S_teststep( 'Wait for end of initialization', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( 'Read fault recorder', 'AUTO_NBR' );
	PD_ECUlogin();
	$fltmem1 = PD_GetExtendedFaultInformation();
	S_teststep( 'Evaluate fault recorder', 'AUTO_NBR', 'Fault' );

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	S_teststep_expected( 'Expected faults:', 'Fault' );
	foreach my $fault (@tcpar_FLTmand) {
		S_teststep_expected($fault);
	}

	S_teststep_detected( 'Detected faults:', 'Fault' );
	foreach my $fault ( @{ $fltmem1->{fault_text} } ) {
		S_teststep_detected($fault);
	}
	PD_evaluate_faults( $fltmem1, \@tcpar_FLTmand, \@tcpar_FLTopt );

	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	# remove fault
	LC_UndoShortLines();
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep_detected( "TEMP: " . join( ' -> ', @temperatures ) );
	S_teststep_detected("UBat: $tcpar_ubat V");

	return 1;
}

1;

__END__
