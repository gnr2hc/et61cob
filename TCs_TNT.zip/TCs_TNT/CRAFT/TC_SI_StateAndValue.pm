# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_SI_StateAndValue;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Switch_Inputs
#TS version in DOORS: 6.4
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_FaultMemory;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_TNT_GEN;
use FuncLib_SYC_INTERFACE;
##################################

our $PURPOSE = " test that a switch detects the correct state and measures the correct value ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SI_StateAndValue 

=head1 PURPOSE

 test that a switch detects the correct state and measures the correct value

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

    Ubat
    Pin
    Type
    Minimum
    Maximum
    CheckLSB
    CheckState
    FLTmand
    FLTopt  (optional)

    [initialisation]
    get temperature
    Ubat on
    clear fault memory
    read fault memory
    switch ECU off

    [stimulation & measurement]
    calculate switch value
    set switch value
    set Ubat
    wait for end of initialization
    read switch state and value
    read fault memory

    [evaluation]
    check switch state and value
    check if fault memory matches given faults
    send mail if not

    [finalisation]
    switch ECU off


=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'ubat'          --> battery voltage value
    SCALAR 'pin'           --> ECU pin
    SCALAR 'type'          --> switch type
    SCALAR 'minimum'	   --> value minimum
    SCALAR 'maximum'	   --> value maximum
    LIST   'checkLSB' 	   --> label and lsb value
    LIST   'checkState'    --> label and state value
    LIST   'FLTmand'       --> list of mandatory faults (logical names)
    LIST   'FLTopt'        --> list of optional faults (logical names)
    
=head2 PARAMETER EXAMPLES

    [TC_FLT_Active.BLFD_Gnd]
    purpose='Checking Short2Gnd(active) BLFD' 
	Ubat=13.2
	Pin1='BLFD+'
	Pin2='B-'
	FLTmand='rb_swm_ShortLineBLFD_flt'
    
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my ( $fltmemBosch1, $fltmemPrimary1, $fltmemBosch2, $fltmemPrimary2, $expectedFaults_href );

my ( $tcpar_ubat, $tcpar_pin,  $tcpar_type,     $tcpar_state,           $tcpar_FLTmand, $tcpar_FLTopt, $tcpar_checkLSB );
my ( $result,     $switch_nbr, $fault_reaction, $tcpar_asic_connection, $asic,          $meas,         $asic_connection_text );
my ( $threshold_min, $threshold_max, $threshold_unit, $det_threshold_min_href, $det_threshold_max_href );
my ($dec_value);
my @temperatures = ();

my $expected_SwitchInfo = {
	"Short2Gnd" => {
		"StatusFiltered_en" => 2,
	},
	"PositionA" => {
		"PositionFiltered_en" => 0,
		"StatusFiltered_en"   => 1,
	},
	"Undefined" => {
		"StatusFiltered_en" => 2,
	},
	"PositionB" => {
		"PositionFiltered_en" => 1,
		"StatusFiltered_en"   => 1,
	},
	"OpenLine" => {
		"StatusFiltered_en" => 2,
	},
};

sub TC_set_parameters {

	$tcpar_ubat    = S_read_mandatory_testcase_parameter('Ubat');
	$tcpar_pin     = S_read_mandatory_testcase_parameter('Pin');
	$tcpar_state   = S_read_mandatory_testcase_parameter('State');
	$tcpar_FLTmand = S_read_optional_testcase_parameter( 'FLTmand', 'byref' );
	$tcpar_FLTopt  = S_read_optional_testcase_parameter( 'FLTopt', 'byref' );

	if ( $tcpar_state =~ /(\w+)Value/ ) {
		$tcpar_state = $1;
	}

	( $result, $threshold_min, $threshold_max, $threshold_unit ) = SYC_SWITCH_get_state_thresholds( $tcpar_pin, $tcpar_state );
	return 0 unless $result;

	( $result, $tcpar_type ) = SYC_SWITCH_get_type($tcpar_pin);
	return 0 unless $result;

	( $result, $tcpar_asic_connection, $asic_connection_text, $asic, $meas ) = SYC_SWITCH_get_ASIC_connection_NOERROR($tcpar_pin);
	if ( $result == 1 ) {
		if ( defined( PRD_Get_Symbol_Mapping_NOERROR( { 'symbol_name' => 'rb_swma_AsicChannelData_ast(0)(0).Value10Bit_u16' } ) ) ) {
			my $nbr1 = $asic - 1;
			my $nbr2 = $meas - 1;
			$tcpar_checkLSB = "rb_swma_AsicChannelData_ast($nbr1)($nbr2).Value10Bit_u16";
		}
		else {
			$tcpar_checkLSB = "rb_swma_AsicChannelData_ast($tcpar_asic_connection).Value10Bit_u16";
		}

	}
	else {
		undef $tcpar_checkLSB;
		S_teststep_detected("Content of ConfigID 'AsicConnection' for switch '$tcpar_pin' is not in the expected format.");
	}

	$switch_nbr = PRD_Get_Device_Property( $tcpar_pin, { 'property_name' => 'index' } );

	if ( $tcpar_state eq 'OpenLine' or $tcpar_state eq 'Undefined' or $tcpar_state eq 'Short2Gnd' ) {

		( $result, $fault_reaction ) = SYC_SWITCH_get_FaultReaction($tcpar_pin);
		return 0 unless $result;

		( $result, $fault_reaction ) = SYC_SWITCH_get_DefaultCondition($tcpar_pin) if ( $fault_reaction =~ /default condition/ );
		( $result, $fault_reaction ) = SYC_SWITCH_get_InitialCondition($tcpar_pin) if ( $fault_reaction =~ /keep last condition/ );
		return 0 unless $result;

		$expected_SwitchInfo->{$tcpar_state}{PositionFiltered_en} = $expected_SwitchInfo->{$fault_reaction}{PositionFiltered_en};

	}

	$tcpar_FLTmand = [ "rb_swm_ShortLine" . $tcpar_pin . "_flt" ] if $tcpar_state eq 'Short2Gnd';
	$tcpar_FLTmand = [ "rb_swm_Undefined" . $tcpar_pin . "_flt" ] if $tcpar_state eq 'Undefined';
	$tcpar_FLTmand = [ "rb_swm_OpenLine" . $tcpar_pin . "_flt" ]  if $tcpar_state eq 'OpenLine';

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	push( @temperatures, TEMP_get_temperature() );
	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	if ( $threshold_unit =~ /R/i ) {

		$threshold_min = ( int( $threshold_min / 10 + 0.5 ) ) * 10;
		$threshold_min += 10 if $tcpar_state eq 'PositionA' or $tcpar_state eq 'PositionB';
		$threshold_min += 20 if $tcpar_state eq 'Undefined' or $tcpar_state eq 'OpenLine';

		$threshold_min = 20   if $threshold_min < 20;
		$threshold_min = 9990 if $threshold_min > 9990;

		S_teststep( "Set switch '$tcpar_pin' to '$threshold_min' Ohm.", 'AUTO_NBR' );
		LC_SetResistance( $tcpar_pin, $threshold_min );
	}
	elsif ( $threshold_unit =~ /I/i ) {

		#prepare for stepwide 0.1 mA , 0.1 .. 100.0
		$threshold_min = ( int( $threshold_min * 10 + 0.5 ) ) / 10;
		$threshold_min += 0.1 if $tcpar_state eq 'PositionA' or $tcpar_state eq 'PositionB';
		$threshold_min += 0.2 if $tcpar_state eq 'Undefined' or $tcpar_state eq 'Short2Gnd';

		$threshold_min = 0.1 if $threshold_min < 0.1;
		$threshold_min = 100 if $threshold_min > 100;

		S_teststep( "Set switch '$tcpar_pin' to '$threshold_min' mA.", 'AUTO_NBR' );
		LC_SetCurrent( $tcpar_pin, $threshold_min );
	}

	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( 'Read fault recorder', 'AUTO_NBR' );
	$fltmemBosch1   = LIFT_FaultMemory->read_fault_memory('Bosch');
	$fltmemPrimary1 = LIFT_FaultMemory->read_fault_memory('Primary');
	S_teststep( 'Evaluate fault recorder', 'AUTO_NBR', 'FLT_min' );

	S_teststep( 'Check switch state', 'AUTO_NBR' );
	foreach my $labelState ( sort keys %{ $expected_SwitchInfo->{$tcpar_state} } ) {
		S_teststep_2nd_level( "Check 'rb_swm_SwitchInfo_ast($switch_nbr).$labelState'.", "AUTO_NBR", $labelState . '_min' );
		$dec_value = PRD_Read_Memory( "rb_swm_SwitchInfo_ast($switch_nbr).$labelState", { memoryContentsAsInteger => 1 } );
		$det_threshold_min_href->{$labelState} = $dec_value;
	}

	if ( defined $tcpar_checkLSB ) {
		S_teststep( 'Read LSB value', 'AUTO_NBR' );
		S_teststep_2nd_level( "Read '$tcpar_checkLSB'.", "AUTO_NBR", $tcpar_checkLSB . '_min' );
		$dec_value = PRD_Read_Memory( $tcpar_checkLSB, { memoryContentsAsInteger => 1 } );
		$det_threshold_min_href->{$tcpar_checkLSB} = $dec_value;
	}

	# set default value
	LC_SetLogicalState( $tcpar_pin, 'DEFAULT' );
	S_wait_ms(5000);
	PRD_Clear_Fault_Memory();

	LC_ECU_Off();

	S_wait_ms('TIMER_ECU_OFF');

	if ( $threshold_unit =~ /R/i ) {

		$threshold_max = ( int( $threshold_max / 10 + 0.5 ) ) * 10;
		$threshold_max -= 10 if $tcpar_state eq 'PositionA' or $tcpar_state eq 'PositionB';
		$threshold_max -= 20 if $tcpar_state eq 'Undefined' or $tcpar_state eq 'Short2Gnd';

		$threshold_max = 20   if $threshold_max < 20;
		$threshold_max = 9990 if $threshold_max > 9990;

		S_teststep( "Set switch '$tcpar_pin' to '$threshold_max' Ohm.", 'AUTO_NBR' );
		LC_SetResistance( $tcpar_pin, $threshold_max );
	}
	elsif ( $threshold_unit =~ /I/i ) {

		#prepare for stepwide 0.1 mA , 0.1 .. 100.0
		$threshold_max = ( int( $threshold_max * 10 + 0.5 ) ) / 10;
		$threshold_max -= 0.1 if $tcpar_state eq 'PositionA' or $tcpar_state eq 'PositionB';
		$threshold_max -= 0.2 if $tcpar_state eq 'Undefined' or $tcpar_state eq 'OpenLine';

		$threshold_max = 0.1 if $threshold_max < 0.1;
		$threshold_max = 100 if $threshold_max > 100;

		S_teststep( "Set switch '$tcpar_pin' to '$threshold_max' mA.", 'AUTO_NBR' );
		LC_SetCurrent( $tcpar_pin, $threshold_max );
	}

	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( 'Read fault recorder', 'AUTO_NBR' );
	$fltmemBosch2   = LIFT_FaultMemory->read_fault_memory('Bosch');
	$fltmemPrimary2 = LIFT_FaultMemory->read_fault_memory('Primary');
	S_teststep( 'Evaluate fault recorder', 'AUTO_NBR', 'FLT_max' );

	S_teststep( 'Check switch state', 'AUTO_NBR' );
	foreach my $labelState ( sort keys %{ $expected_SwitchInfo->{$tcpar_state} } ) {
		S_teststep_2nd_level( "Check 'rb_swm_SwitchInfo_ast($switch_nbr).$labelState'.", "AUTO_NBR", $labelState . '_max' );
		$dec_value = PRD_Read_Memory( "rb_swm_SwitchInfo_ast($switch_nbr).$labelState", { memoryContentsAsInteger => 1 } );
		$det_threshold_max_href->{$labelState} = $dec_value;
	}

	if ( defined $tcpar_checkLSB ) {
		S_teststep( 'Read LSB value', 'AUTO_NBR' );
		S_teststep_2nd_level( "Read '$tcpar_checkLSB'.", "AUTO_NBR", $tcpar_checkLSB . '_max' );
		$dec_value = PRD_Read_Memory( $tcpar_checkLSB, { memoryContentsAsInteger => 1 } );
		$det_threshold_max_href->{$tcpar_checkLSB} = $dec_value;
	}

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	S_teststep_expected( 'Expected faults:', 'FLT_min' );
	foreach my $fault (@$tcpar_FLTmand) {
		S_teststep_expected($fault);
	}

	$expectedFaults_href = {
		'mandatory'   => $tcpar_FLTmand,
		'disjunction' => [],
		'optional'    => $tcpar_FLTopt,
	};

	$fltmemBosch1->evaluate_faults( $expectedFaults_href, 'FLT_min' );
	$fltmemPrimary1->evaluate_faults( $expectedFaults_href, 'FLT_min' );

	foreach my $labelState ( sort keys %{ $expected_SwitchInfo->{$tcpar_state} } ) {
		S_teststep_expected( "'$labelState' == '$expected_SwitchInfo->{$tcpar_state}{$labelState}'", $labelState . '_min' );
		S_teststep_detected( "'$labelState' == '$det_threshold_min_href->{$labelState}'", $labelState . '_min' );
		EVAL_evaluate_value( "$labelState", $det_threshold_min_href->{$labelState}, '==', $expected_SwitchInfo->{$tcpar_state}{$labelState} );
	}

	S_teststep_detected( "'LSB' == '$det_threshold_min_href->{$tcpar_checkLSB}'", $tcpar_checkLSB . '_min' ) if ( defined $tcpar_checkLSB );

	S_teststep_expected( 'Expected faults:', 'FLT_max' );
	foreach my $fault (@$tcpar_FLTmand) {
		S_teststep_expected($fault);
	}

	$expectedFaults_href = {
		'mandatory'   => $tcpar_FLTmand,
		'disjunction' => [],
		'optional'    => $tcpar_FLTopt,
	};

	$fltmemBosch1->evaluate_faults( $expectedFaults_href, 'FLT_max' );
	$fltmemPrimary1->evaluate_faults( $expectedFaults_href, 'FLT_max' );

	foreach my $labelState ( sort keys %{ $expected_SwitchInfo->{$tcpar_state} } ) {
		S_teststep_expected( "'$labelState' == '$expected_SwitchInfo->{$tcpar_state}{$labelState}'", $labelState . '_max' );
		S_teststep_detected( "'$labelState' == '$det_threshold_max_href->{$labelState}'", $labelState . '_max' );
		EVAL_evaluate_value( "$labelState", $det_threshold_max_href->{$labelState}, '==', $expected_SwitchInfo->{$tcpar_state}{$labelState} );
	}

	S_teststep_detected( "'LSB' == '$det_threshold_max_href->{$tcpar_checkLSB}'", $tcpar_checkLSB . '_max' ) if ( defined $tcpar_checkLSB );

	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	# set default value
	LC_SetLogicalState( $tcpar_pin, 'DEFAULT' );
	S_wait_ms(5000);

	# switch ECU off
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep_detected( "TEMP: " . join( ' -> ', @temperatures ) );
	S_teststep_detected("UBat: $tcpar_ubat V");

	return 1;
}

1;

__END__
