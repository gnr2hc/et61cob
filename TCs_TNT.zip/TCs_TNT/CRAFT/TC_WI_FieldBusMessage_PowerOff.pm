# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_WI_FieldBusMessage_PowerOff;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Warning_Indicators (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: 5.11 (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_FaultMemory;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use LIFT_NET_access;

##################################

our $PURPOSE = "check the behaviour of warning indicator is correct and that the warning indicator shows the correct state during power down/off";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_WI_FieldBusMessage_PowerOff

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Apply test case state

2. Set transient recorder

3. Switch ECU off

4. Measure signal

5. Evaluate signal


I<B<Evaluation>>

1. -

2. - 

3. -

4. -

5. warning indicator is either on or off during power down, and off at power off, warning indicator is not blinking


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'Ubat' => 
	SCALAR 'Pin' => 
	SCALAR 'Condition' => 
	SCALAR 'Type' => 
	HASH 'Signal_ON' => 
	LIST 'FLTmand' => 


=head2 PARAMETER EXAMPLES

	# description of test case
	purpose='check <Test Heading Head> (HW indicator) signal during power off with <Test Heading Tail>' 
	
	# input parameter (used for stimulation and measurement)
	Ubat=<Random 9 to 16 step 0.1>
	Pin='BAOna'
	Condition='LampOn'
	
	# output parameter (used for evaluation)
	Type='<Fetch {V_AB12Base_2015A} {(.* side driver)}>'
	Signal_ON=%("Dimming" => <Fetch {V_AB12Base_2015A} {(.*)% PWM}>,"Frequency" => <Fetch {V_AB12Base_2015A} {@ (.*) Hz}>)
	FLTmand=@()

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Ubat;
my $tcpar_Condition;
my $tcpar_can_signal;
my $tcpar_FLTmand;
my $tcpar_ExpectedValue_on_CAN;

################ global parameter declaration ###################
#add any global variables here
my ( $detectedValue_during_off, $detectedValue_during_init );
my ( $fltmemBosch, $fltmemPrimary, $expectedFaults_href );
my @temperatures = ();
###############################################################

sub TC_set_parameters {

	$tcpar_purpose              = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_Ubat                 = S_read_mandatory_testcase_parameter('Ubat');
	$tcpar_ExpectedValue_on_CAN = S_read_mandatory_testcase_parameter('Expected_value_on_CAN');
	$tcpar_Condition            = S_read_mandatory_testcase_parameter('Condition');
	$tcpar_can_signal           = S_read_mandatory_testcase_parameter('Can_Signal');
	$tcpar_FLTmand              = S_read_mandatory_testcase_parameter( 'FLTmand', 'byref' );

	return 1;
}

sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');
	NET_trace_start();
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	push( @temperatures, TEMP_get_temperature() );

	return 1;
}

sub TC_stimulation_and_measurement {

	if ( $tcpar_Condition eq "WalaOn" ) {
		S_teststep( 'Disconnect AB1FD line.', 'AUTO_NBR' );
		LC_DisconnectLine('AB1FD');

		S_teststep( 'Wait until fault is detected.', 'AUTO_NBR' );
		S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');
	}

	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_Ubat);

	S_teststep( 'Wait for Init End.', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Start CAN trace", 'AUTO_NBR' );
	NET_trace_start();

	S_teststep( 'Switch ECU off.', 'AUTO_NBR' );
	LC_DisconnectLine('ALL_SUPPLY+');

	#my $trStore_filepath = NET_trace_store ();

	S_teststep( "Check warning indicator message when ECU is off", 'AUTO_NBR', 'check_warning_indicator_ECUoff' );    #measurement 1

	S_teststep( "Switch ECU on", 'AUTO_NBR' );
	LC_ECU_On('U_BATT_DEFAULT');

	S_teststep( "Wait for IniEnd", 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Read fault recorder", 'AUTO_NBR', 'read_fault_recorder' );                                           #measurement 2
	                                                                                                                  # read fault memory
	$fltmemBosch   = LIFT_FaultMemory->read_fault_memory('Bosch');
	$fltmemPrimary = LIFT_FaultMemory->read_fault_memory('Primary');

	return 1;
}

sub TC_evaluation {

	S_teststep_expected( "warning indicator is either on or off during power down, and off at power off, warning indicator is not blinking", 'check_warning_indicator_ECUoff' );    #evaluation 1
	S_set_verdict('VERDICT_FAIL');
	S_teststep_detected( "FAIL---Manual validation is required", 'check_warning_indicator_ECUoff' );

	S_teststep_expected( 'Expected faults:', 'read_fault_recorder' );                                                                                                               #evaluation 2
	foreach my $fault (@$tcpar_FLTmand) {
		S_teststep_expected($fault);
	}

	$expectedFaults_href = {
		'mandatory'   => $tcpar_FLTmand,
		'disjunction' => [],
		'optional'    => $tcpar_FLTopt,
	};

	$fltmemBosch->evaluate_faults( $expectedFaults_href, 'read_fault_recorder' );
	$fltmemPrimary->evaluate_faults( $expectedFaults_href, 'read_fault_recorder' );

	return 1;
}

sub TC_finalization {
	LC_ConnectLine('AB1FD') if ( $tcpar_Condition eq "WalaOn" );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep_detected("TEMP: $temperatures[0]");
	S_teststep_detected("UBat: $tcpar_Ubat V");

	return 1;
}

1;
