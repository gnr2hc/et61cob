# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_PSI_programData;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Peripheral_Sensor_Interface
#TS version in DOORS: 5.11
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_FaultMemory;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_TNT_GEN;
##################################

our $PURPOSE = " check that changeable data can be programmed ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PSI_programData 

=head1 PURPOSE

 check that changeable data can be programmed 
 
=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

    Ubat
    Pin
    Label
    NewValue
	FLTmand
        
    [initialisation]
    get temperature

    [stimulation & measurement]
    set Ubat
	ECU on
    wait for end of initialization
    read label to get current value
    change label to new value
    reset ECU
    read fault recorder
    evaluate fault recorder
    change label back to current value
    reset ECU
    erase fault recorder
	ECU off
    
    [evaluation]
    check if label value is changed
    check if fault memory matches given faults

    [finalisation]
    get temperature
    print temperatures
    
=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'ubat'         --> battery voltage value
    SCALAR 'pin'		  --> PAS which is verifed
    SCALAR 'label'		  --> label containing start address
    SCALAR 'newValue'	  --> new value which is programmed
    LIST   'FLTmand'      --> list of mandatory faults (logical names)
    
=head2 PARAMETER EXAMPLES

    [TC_PSI_programData.UFSD]
    purpose	 ='Checking_programData_UFSD'
    Ubat	 = 10.8
    Pin		 = 'UFSD'
    Label	 = 'rb_psem_PsemNvmCfgData_dfst.SensorToLineMap_aen(0)' 
    NewValue = '0x04'
    FLTmand  = @('rb_psem_OpenLineUFSD_flt')
		
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
my ( $fltmemBosch, $fltmemPrimary );
my ($expectedFaults_href);
my ( $tcpar_ubat_V, $tcpar_pin, $tcpar_label, $tcpar_newValue, $tcpar_FLTmand );
my ( $currentValue, $changedValue, $changedValueBack );
my @temperatures = ();

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_ubat_V   = S_read_mandatory_testcase_parameter('Ubat');
	$tcpar_pin      = S_read_mandatory_testcase_parameter('Pin');
	$tcpar_label    = S_read_mandatory_testcase_parameter('Label');
	$tcpar_newValue = S_read_mandatory_testcase_parameter('NewValue');
	$tcpar_FLTmand  = S_read_optional_testcase_parameter('FLTmand');

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	push( @temperatures, TEMP_get_temperature() );
	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat_V);

	S_teststep( "Wait for end of initialization", 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Read label for current value", 'AUTO_NBR', 'read_current_value' );
	$currentValue = PRD_Read_Memory( $tcpar_label, { memoryContentsAsInteger => 1 } );
	S_wait_ms(500);

	S_w2rep("Current value: $currentValue");

	S_teststep( "Change value of label", 'AUTO_NBR', 'change_value' );
	PRD_Write_Memory( $tcpar_label, [$tcpar_newValue] );
	S_wait_ms(100);
	$changedValue = PRD_Read_Memory( $tcpar_label, { memoryContentsAsInteger => 1 } );
	S_w2rep("Changed value: $changedValue");

	S_teststep( "Reset ECU", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_READY');
	LC_ECU_On($tcpar_ubat_V);
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( 'Read fault recorder', 'AUTO_NBR' );
	$fltmemBosch   = LIFT_FaultMemory->read_fault_memory('Bosch');
	$fltmemPrimary = LIFT_FaultMemory->read_fault_memory('Primary');
	S_teststep( 'Evaluate fault recorder', 'AUTO_NBR', 'Fault' );

	S_teststep( "Change value of label (back to original value)", 'AUTO_NBR', 'change_value_back' );
	PRD_Write_Memory( $tcpar_label, [$currentValue] );

	S_wait_ms(100);
	$changedValueBack = PRD_Read_Memory( $tcpar_label, { memoryContentsAsInteger => 1 } );
	S_w2rep("Changed value back: $changedValueBack");

	S_teststep( "Reset ECU", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_READY');
	LC_ECU_On($tcpar_ubat_V);
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( 'Erase fault recorder', 'AUTO_NBR' );
	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	S_teststep_detected( "Programmed value = $currentValue", 'read_current_value' );

	S_teststep_expected( "New value     = $tcpar_newValue", 'change_value' );
	S_teststep_detected( "Changed value = $changedValue", 'change_value' );
	EVAL_evaluate_value( 'Changed value', $changedValue, '==', $tcpar_newValue );

	S_teststep_expected( 'Expected faults:', 'Fault' );
	foreach my $fault (@$tcpar_FLTmand) {
		S_teststep_expected($fault);
	}

	$expectedFaults_href = {
		'mandatory'   => $tcpar_FLTmand,
		'disjunction' => [],
		'optional'    => [],
	};

	$fltmemBosch->evaluate_faults( $expectedFaults_href, 'Fault' );
	$fltmemPrimary->evaluate_faults( $expectedFaults_href, 'Fault' );

	S_teststep_expected( "Original value = $currentValue", 'change_value_back' );
	S_teststep_detected( "Changed value  = $changedValueBack", 'change_value_back' );
	EVAL_evaluate_value( 'Changed value', $changedValueBack, '==', $currentValue );

	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep_detected( "TEMP: " . join( ' -> ', @temperatures ) );
	S_teststep_detected("UBat: $tcpar_ubat_V V");

	return 1;
}

1;

__END__
