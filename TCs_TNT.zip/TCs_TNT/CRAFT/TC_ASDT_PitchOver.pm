# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_ASDT_PitchOver;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Crash_Protection_ASDT
#TS version in DOORS: 5.8
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_FaultMemory;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_TNT_GEN;
use FuncLib_SYC_INTERFACE;

#include further modules here

##################################

our $PURPOSE = " verify the sensing directions of the algorithm relevant sensors at the interface between system software and algorithm software ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_ASDT_PitchOver

=head1 PURPOSE

verify the sensing directions of the algorithm relevant sensors at the interface between system software and algorithm software

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. mount ECU and peripheral sensors for pitch over to front

2. switch ECU on and wait for ini end

3. reset ECU

4. start fast diagnosis

5. perform pitch over to front with ECU

6. stop fast diagnosis

7. evaluate internal sensor signal

8. switch ECU off


I<B<Evaluation>>

1. -

2. - 

3. -

4. -

5. -

6. - 

7. captured sensor signal is according to test oracle 

8. -


I<B<Finalisation>>

Erase crash recorder and fault recorder


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'TestedAcc' => tested acceleration direction
	SCALAR 'SignalLabel' => signal label used for capturing 
	SCALAR 'DataType'    => data type of signal label 
	SCALAR 'Resolution'  => resolution of signal
	SCALAR 'DriverSide'  => LHD or RHD activated 
	SCALAR 'TestOracle'  => expected signal sign


=head2 PARAMETER EXAMPLES

    [TC_ASDT_RolloverRightSide.CsRollrate_LHD]   #ID: TS_CP_ASDT_831
        purpose='check pitch over sensing direction for CsPitchRate'
        TestedAcc = 'Wy'
        SignalLabel = 'rb_siam_CentralSensorData_st.CsPitchRateData_s16'
        DataType = 'S16'
        Resolution = 100
        TestOracle = 'pos'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_testedAcc;
my $tcpar_signalLabel;
my $tcpar_dataType;
my $tcpar_resolution;
my $tcpar_testOracle;
my $action;
my $fastDiag_file_name;
my $fastDiag_folder;
my $fastDiagdata_href;

#my $detectedSignalSign;
################ global parameter declaration ###################
my ( $fltmemBosch, $fltmemPrimary, $expectedFaults_href, $tcpar_FLTmand, $tcpar_FLTopt );

###############################################################

sub TC_set_parameters {

	$tcpar_testedAcc   = S_read_mandatory_testcase_parameter('TestedAcc');
	$tcpar_signalLabel = S_read_mandatory_testcase_parameter('SignalLabel');
	$tcpar_dataType    = S_read_mandatory_testcase_parameter('DataType');
	$tcpar_testOracle  = S_read_mandatory_testcase_parameter('TestOracle');

	$tcpar_resolution = S_read_optional_testcase_parameter('Resolution');
	$tcpar_FLTmand    = S_read_mandatory_testcase_parameter( 'FLTmand', 'byref' );
	$tcpar_FLTopt     = S_read_mandatory_testcase_parameter( 'FLTopt', 'byref' );

	return 1;
}

sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');
	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	PRD_Read_Fault_Memory('PRIMARY');
	PRD_Read_Fault_Memory('BOSCH');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}

sub TC_stimulation_and_measurement {

	my $graphTitle;

	S_teststep( "Mount ECU for pitch over to front.", 'AUTO_NBR' );
	$action = S_user_action("Mount ECU for pitch over to front.\n\nPlease confirm this popup when mounting is finished.");

	S_teststep( "Switch ECU on and wait for ini end.", 'NO_AUTO_NBR' );
	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Prepare acceleration of ECU in pitchover direction", 'AUTO_NBR' );
	$action = S_user_action("Prepare acceleration of ECU in pitchover direction.\n\nPlease confirm this popup when preparation is done.");

	S_teststep( "Start fast diagnosis for signal label '$tcpar_signalLabel'.", 'AUTO_NBR' );
	my $tcParaName = S_get_TC_parameter_name();
	$fastDiag_file_name = S_get_TC_number() . '_Pitchover_' . $tcParaName;
	$fastDiag_folder    = S_get_TC_number() . '_Pitchover_' . $tcParaName;
	my $fastDiagConfig_href = {
		labels             => [$tcpar_signalLabel],
		number_of_BUS_Ids  => 1,
		csv_data_file_path => "$main::REPORT_PATH/" . $fastDiag_folder,
	};
	$fastDiag_folder = PRD_Start_Fast_Diagnosis($fastDiagConfig_href);

	S_teststep( "Perform pitch over to front with ECU.", 'AUTO_NBR' );
	$action = S_user_action("Perform pitch over to front with ECU.\n\nPlease confirm this popup when rotation is performed.");

	S_teststep( "Stop fast diagnosis for signal label '$tcpar_signalLabel'.", 'AUTO_NBR' );
	PRD_Stop_Fast_Diagnosis();

	S_teststep( "Evaluate (internal/external) sensor signal.", 'AUTO_NBR', 'signal_measurement' );
	$fastDiagdata_href = PRD_Get_Fast_Diagnosis_Data( { 'data_path' => $fastDiag_folder } );
	$graphTitle = S_get_TC_number() . '_EcuInternalSensor_' . $tcParaName;
	EVAL_createGraphFromMeasurement( $fastDiagdata_href, $graphTitle, { 'y' => [$tcpar_signalLabel] }, 'no_interpolation', 2 );

	S_teststep( 'Read fault recorder', 'AUTO_NBR' );
	$fltmemBosch   = LIFT_FaultMemory->read_fault_memory('Bosch');
	$fltmemPrimary = LIFT_FaultMemory->read_fault_memory('Primary');
	S_teststep( 'Evaluate fault recorder', 'AUTO_NBR', 'Fault' );

	S_teststep( "Switch ECU off.", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_READY');

	return 1;
}

sub TC_evaluation {

	#	my ( $NumOfPulses, $pulses );
	#
	#	if ( $tcpar_testOracle eq 'pos' ) {
	#		( $NumOfPulses, $pulses ) = EVAL_get_signal_pulses( $fastDiagdata_HoH, $tcpar_signalLabel, 2500, 20, 'rising' );
	#		if ( $NumOfPulses >= 1 ) {
	#			$detectedSignalSign = 'pos';
	#		}
	#		else {
	#			$detectedSignalSign = 'none';
	#		}
	#	}
	#	elsif ( $tcpar_testOracle eq 'neg' ) {
	#		( $NumOfPulses, $pulses ) = EVAL_get_signal_pulses( $fastDiagdata_HoH, $tcpar_signalLabel, 2500, 20, 'falling' );
	#		if ( $NumOfPulses >= 1 ) {
	#			$detectedSignalSign = 'neg';
	#		}
	#		else {
	#			$detectedSignalSign = 'none';
	#		}
	#	}
	#	else {
	#		$NumOfPulses = -1;
	#		$pulses      = -1;
	#	}
	#
	#	S_teststep_expected( "Sensor signal sign == $tcpar_testOracle", 'signal_measurement' );
	#	S_teststep_expected( "Signal pulses >= 1",                      'signal_measurement' );
	#
	#	S_teststep_detected( "Sensor signal sign == $detectedSignalSign", 'signal_measurement' );
	#	EVAL_evaluate_string( "Sensor signal sign", $tcpar_testOracle, $detectedSignalSign );
	#	S_teststep_detected( "Signal pulses == $NumOfPulses", 'signal_measurement' );

	#	evaluate measured signal
	S_teststep_expected( "expected sensor signal sign == $tcpar_testOracle", 'signal_measurement' );
	S_set_verdict('VERDICT_FAIL');
	S_teststep_detected( "detected sensor signal sign == FAIL --> manual evaluation of fast diagnosis trace needed, copy FD plot in TR", 'signal_measurement' );

	S_teststep_expected( 'Mandatory faults:', 'Fault' );
	foreach my $fault (@$tcpar_FLTmand) {
		S_teststep_expected($fault);
	}
	S_teststep_expected( 'Optional faults:', 'Fault' );
	foreach my $fault (@$tcpar_FLTopt) {
		S_teststep_expected($fault);
	}

	$expectedFaults_href = {
		'mandatory'   => $tcpar_FLTmand,
		'disjunction' => [],
		'optional'    => $tcpar_FLTopt,
	};

	$fltmemBosch->evaluate_faults( $expectedFaults_href, 'Fault' );
	$fltmemPrimary->evaluate_faults( $expectedFaults_href, 'Fault' );

	return 1;
}

sub TC_finalization {

	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');
	PRD_Clear_EDR();
	S_wait_ms(500);
	PRD_Clear_Fault_Memory();
	S_wait_ms(500);
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_READY');

	return 1;
}

1;
