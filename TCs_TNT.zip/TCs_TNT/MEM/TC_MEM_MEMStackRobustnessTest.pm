#### TEST CASE MODULE
package TC_MEM_MEMStackRobustnessTest;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.5 $;
our $HEADER  = q$Header: MEM/TC_MEM_MEMStackRobustnessTest.pm 1.5 2019/03/01 17:34:01ICT Okrusch Thomas (CC-PS/EPS2) (OUT2SI) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: -
#TS version in DOORS: -
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use LIFT_CSM;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_labcar;
use LIFT_can_access;
use File::Spec;
##################################

our $PURPOSE = "Check Robustness of MEM Stack";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_MEM_MEMStackRobustnessTest

=head1 PURPOSE

Check Robustness of MEM Stack

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

-


I<B<Stimulation and Measurement>>

1. read POC counter

2. POW Off/On for tcpar_POC_TC cycles

3. read POC Counter

4. read NVM Re-Org Counter

5. read starting address of all NVM blocks + report + store ( idea : if TC_cnt modulo 100 == 0)

6. read fault memory (Primary + Bosch + Disturbance) ( idea : if TC_cnt modulo 100 == 0)

7. read content of all NVM blocks + store ( idea : if TC_cnt modulo 100 == 0)


I<B<Evaluation>>

1. -

2. -

3. POC is incremented by 1

4. NVM Re-Org Counter has incremented

5. -

6. Only allowed faults

7. Evaluate which blocks has been changed + report


I<B<Finalisation>>

-


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'PowOffTime_msec' => ECU Off duration
	SCALAR 'PowOffTime_msec' => ECU On duration
	SCALAR 'POC_TC' => Number of ECU Off/On repetitions


=head2 PARAMETER EXAMPLES

	purpose 		= 'Check Robustness of MEM Stack' 
	PowOffTime_msec 	= 5
	PowOffTime_msec 	= 8
	POC_TC 			= 10

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_PowOffTime_msec;
my $tcpar_PowOnTime_msec;
my $tcpar_POC_TC;

my $exopt_MEM_extended_measurement_cycle;
my $exopt_MEM_fault_memory_dump;

################ global parameter declaration ###################
#add any global variables here
my $POC_initial_dec;
my $reorg_cnt_initial_dec;
my $POC_after_reset_dec;
my $reorg_cnt_after_reset_dec;
my $start_addr_all_blocks;
my $flt_mem_Primary_after_reset;
my $flt_mem_Bosch_after_reset;
my $flt_mem_Disturbance_after_reset;
my $nvm_content_all_blocks;
my $nvmData_href;
my $cont_id_prefix;

###############################################################

sub TC_set_parameters {

    $tcpar_purpose         = S_read_optional_testcase_parameter( 'purpose',         'byvalue', 'MEM stack robustness test' );
    $tcpar_PowOffTime_msec = S_read_optional_testcase_parameter( 'PowOffTime_msec', 'byvalue', 8000 );
    $tcpar_PowOnTime_msec  = S_read_optional_testcase_parameter( 'PowOnTime_msec',  'byvalue', 10000 );
    $tcpar_POC_TC          = S_read_optional_testcase_parameter( 'POC_TC',          'byvalue', 20 );

    $exopt_MEM_extended_measurement_cycle = S_get_exec_option( "MEM_extended_measurement_cycle", 10 );   # later appr. 50
    $exopt_MEM_fault_memory_dump          = S_get_exec_option( "MEM_fault_memory_dump",          1 );    # 1 -> dump fault memory to container

    $cont_id_prefix = "MEM_TC_";

    return 1;
}

sub TC_initialization {

    #setup local and storage working area for CSM
    my $local_wk_ar = S_get_contents_of_hash( [ 'CSM', 'LocalWorkingArea_Path' ] );
    my $storage_ar  = S_get_contents_of_hash( [ 'CSM', 'StorageArea_Path' ] );

    my $current_test_folder_extn = File::Spec->abs2rel($main::REPORT_PATH);
    $current_test_folder_extn =~ m/.*\\(.*)$/i;    #extract report folder name

    CSM_init( { 'LocalWorkingArea_Path' => $local_wk_ar . "\\$1", 'StorageArea_Path' => $storage_ar . "\\$1" } ) || return;
	
	# S_user_action ("clear faults");

    return 1;
}

sub TC_stimulation_and_measurement {

    S_teststep( "Read POC counter", 'AUTO_NBR' );
    $POC_initial_dec       = GEN_readPowerONCounter();
    S_teststep_detected( "PowerOn counter BEFORE cycles: $POC_initial_dec" );

    S_teststep( "Read NVM reorg counter", 'AUTO_NBR' );
    $reorg_cnt_initial_dec = S_aref2hex( PD_ReadMemoryByName('Fee_LLSectorOrder_st(0).SecChngCnt_u32') );    # or MEM_Read_NVM_Reorg_Counter ();
    S_teststep_detected( "NVM reorg counter BEFORE cycles: $reorg_cnt_initial_dec" );

    S_teststep( "Perform ECU Off/On, $tcpar_POC_TC times", 'AUTO_NBR' );
    foreach ( 1 .. $tcpar_POC_TC ) {
        LC_ECU_Off();
		S_wait_ms (200);
		CA_trace_stop ();
        S_wait_ms( $tcpar_PowOffTime_msec, 'wait after power off' );
		CA_trace_start ();
        LC_ECU_On();
        S_wait_ms( $tcpar_PowOnTime_msec, 'wait after power on' );
    }

    S_teststep( "Read POC counter", 'AUTO_NBR', 'eval_POC' );
    $POC_after_reset_dec = GEN_readPowerONCounter();
    S_teststep_detected( "PowerOn counter AFTER cycles: $POC_after_reset_dec" );

    S_teststep( "Read NVM reorg counter", 'AUTO_NBR', 'eval_ROC' );
    $reorg_cnt_after_reset_dec = S_aref2hex( PD_ReadMemoryByName('Fee_LLSectorOrder_st(0).SecChngCnt_u32') );    # or MEM_Read_NVM_Reorg_Counter ();         ==> Thomas
    S_teststep_detected( "NVM reorg counter : $reorg_cnt_after_reset_dec" );

	my $ROC_diff = $reorg_cnt_after_reset_dec - $reorg_cnt_initial_dec;
    S_teststep_detected( "DIFFERENCE to initial NVM reorg counter : $ROC_diff = $reorg_cnt_after_reset_dec - $reorg_cnt_initial_dec " );
	
    #------------------------------------ Extended Measurements -------------------------------------------
    if ( S_get_TC_number() % $exopt_MEM_extended_measurement_cycle == 0 ) {                        #only for every $exopt_MEM_extended_measurement_cycle TC
		
		S_w2rep("Start of extended measurements");
		#count the number of extended measurements
		my ( $valid_flag, $total_msmt_cnt ) = S_read_public_variable("NUM_OF_EXT_MEASUREMENTS");
		$total_msmt_cnt = 0 unless ($valid_flag);
		S_set_public_variable( "NUM_OF_EXT_MEASUREMENTS", ++$total_msmt_cnt );

		
		S_w2rep("[Storage] Opening Container for measurements");
        my $mem_cont_id = $cont_id_prefix . S_get_TC_number();
        CSM_create_container($mem_cont_id);

		
        #----------------------- NvM block start address ---------------------
			S_teststep( "Read Start address of each NVM block", 'AUTO_NBR' );
			#
			# function initially local
			# loop over all blocks required
			#
			$start_addr_all_blocks = MEM_Read_NVM_Start_Address('all_blocks');    # ==> Thomas
			#
			#   interesting: how many times the starting  address of a single NVM block is changing
			#
		#--------------------- end NvM block start address -------------------

		
		
		#--------------------------- Fault memory ----------------------------
			S_teststep( "Read Fault Memory", 'AUTO_NBR' );
			#PFM
			S_teststep_2nd_level( "Read Primary Fault Memory", 'AUTO_NBR' );
			if ( $flt_mem_Primary_after_reset = PD_ReadFaultMemory(PRIMARY_FLT_MEM) and $exopt_MEM_fault_memory_dump == 1 ) {
				dump_2_container( $mem_cont_id, $flt_mem_Primary_after_reset, "PrimaryFaultMemory", "PD_ReadFaultMemory_Primary_Dump" );
			}

			#BFM
			S_teststep_2nd_level( "Read Bosch Fault Memory", 'AUTO_NBR' );
			if ( $flt_mem_Bosch_after_reset = PD_ReadFaultMemory(BOSCH_FLT_MEM) and $exopt_MEM_fault_memory_dump == 1 ) {
				dump_2_container( $mem_cont_id, $flt_mem_Bosch_after_reset, "BoschFaultMemory", "PD_ReadFaultMemory_Bosch_Dump" );
			}

			#DFM
			S_teststep_2nd_level( "Read Disturbance Fault Memory", 'AUTO_NBR' );
			if ( $flt_mem_Disturbance_after_reset = PD_ReadFaultMemory(DISTURBANCE_FLT_MEM) and $exopt_MEM_fault_memory_dump == 1 ) {
				dump_2_container( $mem_cont_id, $flt_mem_Disturbance_after_reset, "DisturbanceFaultMemory", "PD_ReadFaultMemory_Disturbance_Dump" );
			}
		#-------------------------- end Fault memory ---------------------------

		
		
		#-------------------------- NVM Block Content --------------------------
			S_teststep( "Read content of all NVM blocks", 'AUTO_NBR' );
			#   interesting: how many times the content of a single NVM block is changing
			#   Try to compare the content here ( if too long time then -> OFFLINE eval)

			#1. Get NVM dump from previous measurement (for comparision with current measurement)
			my $load_last_nvm_dump_status     = load_last_user_file('NVM_data_dump.pm');
			my $nvm_data_previous_measurement = $NVM_data_dump::NVM_data;


			#2. read content of each NVM block and compare with previous measurement
			my $read_nvmDump_href;
			my ( @changed_block_ids, @changed_block_names, @changed_block_counter );
			process_NVM();    #get $nvmData_href with details of all NVM blocks from .nvm file
			
			foreach my $block_id ( sort { $a <=> $b } keys %{$nvmData_href} ) { #loop over all blocks
				my $block_name = $nvmData_href->{$block_id}{"section name"};
				my $resp_aref  = PD_ReadNVMSection_NOERROR($block_name);
				my ( $valid_flag_change_cnt, $data_change_cnt ) = S_read_public_variable_NOHTML( "CONTENT_CHANGE_$block_id" . "_CNT" ); #read all block change counters
				$read_nvmDump_href->{ $block_id . "_$block_name" } = "Error in reading NVM block"; #default content
				
				if ( scalar @$resp_aref ) {    #valid data
					$read_nvmDump_href->{ $block_id . "_$block_name" } = "@$resp_aref";    #'blockid' => "databytes"

					#compare with previous measurement
					if ( $load_last_nvm_dump_status == 1 and $nvm_data_previous_measurement->{ $block_id . "_$block_name" } ne "@$resp_aref" ) {
						$valid_flag_change_cnt = S_set_public_variable ( "CONTENT_CHANGE_$block_id" . "_CNT", ++$data_change_cnt );    #increment counter if data has changed
						S_w2rep("Content of block $block_id ($block_name) has changed $data_change_cnt times \n");
					}
				}

				#to print summary table
				if ($valid_flag_change_cnt) {
					push( @changed_block_ids,     $block_id );
					push( @changed_block_names,   $block_name );
					push( @changed_block_counter, $data_change_cnt . "/$total_msmt_cnt" );
				}
			}

			
			#3. create summary table of changed NVM blocks
			if ( scalar @changed_block_ids ) {
				S_w2rep( "Summary of all changed NVM blocks (from start of test)\n", "blue" );
				my $tableObject = S_TableCreate( [ 'Block ID', 'Block Name', 'Num of Changes/Num of Measurements' ], [ \@changed_block_ids, \@changed_block_names, \@changed_block_counter ], 'column-wise' );
				S_TablePrint( CONSOLE | TEXT | HTML | 2, $tableObject, 'NVMBlockChanges' );
			}

			dump_2_container( $mem_cont_id, $read_nvmDump_href, "NVM_data", "NVM_data_dump" );
		#------------------------ end NVM Block Content -------------------------

		
		
        S_w2rep( " CSM Close container '$mem_cont_id'\n" );
        CSM_pack_container($mem_cont_id);

        S_w2rep( " CSM Archive container '$mem_cont_id'\n" );
        CSM_archive_container( $mem_cont_id, 'KeepLocalData' );
    }
	 #------------------------------------ end Extended Measurements -------------------------------------------

    return 1;
}

sub TC_evaluation {

    S_teststep_expected( "POC counter = $POC_initial_dec + $tcpar_POC_TC", 'eval_POC' );
    S_teststep_detected( "POC counter = $POC_after_reset_dec", 'eval_POC' );
    EVAL_evaluate_value( "POC", $POC_after_reset_dec, '==', $POC_initial_dec + $tcpar_POC_TC );

    #add further evaluation

    return 1;
}

sub TC_finalization {

    return 1;
}

sub MEM_Read_NVM_Start_Address {

}

sub process_NVM {

    my $NVMfile = $LIFT_config::SAD_file;
    my $response_aref;
    $NVMfile =~ s/\.sad$/.nvm/i;
    my $NVM_FileHandle;

    unless ( open( $NVM_FileHandle, "<$NVMfile" ) ) {
        S_set_error( " could not open $NVMfile for reading: $@", 1 );
        return 0;
    }
    my @NVM_SectionDetails;

    # my $NVMdataCounter = 0;
    S_w2log( 5, "process_NVM : Processing NVM file. .. \n" );
    while ( my $line = <$NVM_FileHandle> ) {    # Loop to process nvm-file line by line
        chomp $line;
        next if ( $line =~ /^NULL_PTR/ );

        @NVM_SectionDetails = split( /,/, $line );

        if ( defined $NVM_SectionDetails[2] && $NVM_SectionDetails[2] =~ /^\d+$/ )    # Checking if NVM block length is a valid numeric value
        {
            $$nvmData_href{ $NVM_SectionDetails[1] }{"section name"}        = $NVM_SectionDetails[0];    # NVM section name
                                                                                                         # $$nvmData_href{ $NVM_SectionDetails[1] }{ "section ID" } = $NVM_SectionDetails[1];          # NVM section ID
            $$nvmData_href{ $NVM_SectionDetails[1] }{"section BlockLength"} = $NVM_SectionDetails[2];    # NVM section BlockLength
                                                                                                         # $NVMdataCounter++;
        }
    }
    close($NVM_FileHandle);

    return $nvmData_href;
}

sub load_last_user_file {
    my $userfile = shift;

    my $previous_TC_container_id = S_get_TC_number() - $exopt_MEM_extended_measurement_cycle;
    if ( $previous_TC_container_id > 0 ) {

        $previous_TC_container_id = sprintf( "%04d", $previous_TC_container_id );

        my $Container_Header = CSM_get_container( $cont_id_prefix . $previous_TC_container_id );

        my $userfile_object = CSM_get_userfile(
            $cont_id_prefix . $previous_TC_container_id,
            $userfile,
            { extract => 1 },    # option extract : 0 - no ; 1 - yes
        );

        my $filename_long_last_user_file = $userfile_object->getFilename_long();
        S_w2log( 5, "UserFile extracted: $filename_long_last_user_file \n" );

        unless ( -e $filename_long_last_user_file ) {
            S_set_error("Data file '$filename_long_last_user_file' does not exist!");
        }

        S_w2log(5, "Requiring last user file $filename_long_last_user_file\n");
        eval { require $filename_long_last_user_file };
        if ($@) {
            S_set_error("Error occured while loading NVM Data Dump '$filename_long_last_user_file' : $@");
            return 0;
        }

        return 1;
    }

    S_w2log(4, "Last user file $userfile not found!\n");
    return 0;
}

sub dump_2_container {

    my $cont_id     = shift;
    my $VarToDump   = shift;
    my $VarName     = shift;
    my $PackageName = shift;

    S_dump2pmFile(
        "VariableToDump" => $VarToDump,
        "VariableName"   => $VarName,
        "PackageName"    => $PackageName,
        "StoragePath"    => $main::REPORT_PATH,
    );
    my $local_file = $main::REPORT_PATH . "/$PackageName" . ".pm";
    CSM_add_userfile( $cont_id, $local_file, $PackageName );
    CSM_add_keywords( $cont_id, [$PackageName] );
    S_w2log(5, " Delete file $local_file \n");
    unlink $local_file if -f $local_file;    # delete local file in Report folder !!

}

1;
