#### TEST CASE MODULE
package TC_VDS_FilterTestFFT;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.7 $;
our $HEADER  = q$Header: VDS/CREIS_Setup/TC_VDS_FilterTestFFT.pm 1.7 2019/04/29 11:00:54ICT Andrews Xavier Jesu (RBEI/EVS) (XAA1COB) develop  $;

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_evaluation;
use LIFT_PD;
use LIFT_labcar;
use LIFT_QuaTe;
use LIFT_can_access;
use LIFT_flexray_access;

use Math::FFT;
use Math::Trig;

##################################

our $PURPOSE = "Test of SMI7xy filter charecteristics";

# DOCUMENTATION

=head1 TESTCASE MODULE

TC_VDS_FilterTestFFT

=head1 PURPOSE

Test of SMI7xy filter charecteristics using a jump in sensor data and FFT analysis.

A simple jump in sensor data is stimulated by QuaTe:

 Amplitude  _____
           |     |
           |     |
 0    _____|     |_____
 
The data of the sensor seeing the jump are recorded.
The data is cut around the first edge and then the derivative is calculated. 
The derivative is ideally a Dirac pulse which contains all frequencies.
Therefore the FFT of the measured Dirac pulse gives the amplitude and phase (data age) over frequency.

=head1 TESTCASE DESCRIPTION

I<B<Preconditions>>

This test can only be performed with a crash injection setup and a CREIS modified ECU.

Configure sensor simulation device with all sensors that are defined for the project (use existing crash injection config).

I<B<Initialisation>>

Switch ECU on

I<B<Stimulation and Measurement>>

    create stimulation curve with amplitude depending on $tcpar_sensor_simulation_type
    start measurement of PD, CAN or flexray depending on $tcpar_measurement_type
    stimulate the created curve for the sensor defined in $tcpar_sensor_simulation_device and $tcpar_sensor_simulation_channel
    stop and store measurement
    get data from measurement
    prepare data for FFT
    perform FFT and calculate amplitude and data age vs frequency
    
If parameter 'offline_analysis' is set to 1 then no test bench devices (QuaTe, PD, CAN, FR) are accessed, 
but data are taken from PD fast diagnosis or CAN/FR traces which are located in 'offline_data_folder' from a previous test run.
This gives the possibility to do an offline re-evaluation of a test run.

I<B<Evaluation>>

    evaluate the following quantities from amplitude data against expected values in test case parameters:
    - passband_upper_frequency_Hz
    - filter_lower_frequency_Hz
    - filter_upper_frequency_Hz
    - stopband_lower_frequency_Hz
    - stopband_factor_db
    evaluate max_data_age_ms against expected value in test case parameter from data age data

I<B<Finalisation>>

nothing

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

	SCALAR 'purpose' = Purpose of the Testcase
	SCALAR 'sensor_simulation_device' = sensor simulation device name
	SCALAR 'sensor_simulation_channel' = sensor simulation channel name
	SCALAR 'sensor_simulation_type' = sensor simulation type: 'rate' or 'acceleration'
	SCALAR 'measurement_type' = type of measurement: 'PD' or 'CAN' or 'FR'
	SCALAR 'measurement_signal' = signal name for measurement
	SCALAR 'passband_upper_frequency_Hz' = upper limit of passband frequency in Hz
	SCALAR 'filter_lower_frequency_Hz' = lower limit of filter frequency in Hz
	SCALAR 'filter_upper_frequency_Hz' = upper limit of filter frequency in Hz
	SCALAR 'stopband_lower_frequency_Hz' = lower limit of stopband frequency in Hz
	SCALAR 'passband_tolerance_dB' = tolerance (ripple) of the passband in dB
	SCALAR 'stopband_factor_db' = amplitude reduction factor for the stopband in dB
	SCALAR 'max_data_age_ms' = maximum allowed data age in ms
	SCALAR 'offline_analysis' = (optional) flag to activate offline analysis
	SCALAR 'offline_data_folder' = (optional) folder in which data are stored for offline analysis; has to be defined if parameter 'offline_analysis' = 1

=head2 PARAMETER EXAMPLES

    [TC_VDS_FilterTestFFT.wx]
    purpose	= 'VDS filter test using FFT for wx'
    sensor_simulation_device = 'SMI715'
    sensor_simulation_channel = 'Ang_Rate_X'
    sensor_simulation_type = 'rate'
    measurement_type = 'PD'
    measurement_signal = 'rb_sfh_OutputBuffer_s16(3)'
    passband_upper_frequency_Hz = 5
    filter_lower_frequency_Hz = 14
    filter_upper_frequency_Hz = 16
    stopband_lower_frequency_Hz = 50
    passband_tolerance_dB = 0.1
    stopband_factor_db = -40
    max_data_age_ms = 38
    offline_analysis = 1
    offline_data_folder = 'C:\Users\phc2si\Documents\LIFT_info\VDS\20160913_084400_FastDiagData_Wx'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_sensor_simulation_device;
my $tcpar_sensor_simulation_channel;
my $tcpar_sensor_simulation_type;
my $tcpar_measurement_type;
my $tcpar_offline_analysis;
my $tcpar_offline_data_folder;
my $tcpar_measurement_signal;
my $tcpar_passband_upper_frequency_Hz;
my $tcpar_filter_lower_frequency_Hz;
my $tcpar_filter_upper_frequency_Hz;
my $tcpar_stopband_lower_frequency_Hz;
my $tcpar_passband_tolerance_dB;
my $tcpar_stopband_factor_db;
my $tcpar_max_data_age_ms;

################ global parameter declaration ###################
#add any global variables here

my $filterAmplitude_dB   = -3;
my $epsilon              = 1e-99;
my $targetRate_deg_s     = 300;
my $targetAngle_deg      = 90;
my $timeOnTargetValue_ms = 5000;
my $stepWidth_ms = 0.1;
my ( $tcNumber, $amplitude_db_aref, $groupDelay_ms_aref, $groupDelayUpperFrequency_Hz, $highestFrequency_Hz, $deltaF, $table );
my ($testAmplitude, $unit, $amp2LSB);

###############################################################

sub TC_set_parameters {
    $tcpar_purpose                     = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_sensor_simulation_device    = S_read_mandatory_testcase_parameter('sensor_simulation_device');
	$tcpar_sensor_simulation_channel   = S_read_mandatory_testcase_parameter('sensor_simulation_channel');
    $tcpar_sensor_simulation_type      = S_read_mandatory_testcase_parameter('sensor_simulation_type');
	$tcpar_measurement_type            = S_read_mandatory_testcase_parameter('measurement_type');
    $tcpar_offline_analysis            = S_read_mandatory_testcase_parameter('offline_analysis');
    $tcpar_offline_data_folder         = S_read_mandatory_testcase_parameter('offline_data_folder');
    $tcpar_measurement_signal          = S_read_mandatory_testcase_parameter('measurement_signal');
    $tcpar_passband_upper_frequency_Hz = S_read_mandatory_testcase_parameter('passband_upper_frequency_Hz');
    $tcpar_filter_lower_frequency_Hz   = S_read_mandatory_testcase_parameter('filter_lower_frequency_Hz');
    $tcpar_filter_upper_frequency_Hz   = S_read_mandatory_testcase_parameter('filter_upper_frequency_Hz');
    $tcpar_stopband_lower_frequency_Hz = S_read_mandatory_testcase_parameter('stopband_lower_frequency_Hz');
    $tcpar_passband_tolerance_dB       = S_read_mandatory_testcase_parameter('passband_tolerance_dB');
    $tcpar_stopband_factor_db          = S_read_mandatory_testcase_parameter('stopband_factor_db');
    $tcpar_max_data_age_ms             = S_read_mandatory_testcase_parameter('max_data_age_ms');

    if( $tcpar_measurement_type !~ /^(pd|can|fr)$/i ) {
        S_set_error("Parameter 'measurement_type' must be 'PD' or 'CAN' or 'FR'");
        return 0;
    }

    if( $tcpar_sensor_simulation_type =~ /^rate/i ) {
        $testAmplitude = 160;#145 for JLR due to 160 raadians for all axis #250
        $unit = 'deg/s';
        $amp2LSB = 100;
    }
    elsif( $tcpar_sensor_simulation_type =~ /^accel/i ) {
        $testAmplitude = 2.5;
        $unit = 'g';
        $amp2LSB = 5000;
    }
    else{
        S_set_error("Test case parameter 'sensor_simulation_type' must be either 'rate' or 'accel', but it is $tcpar_sensor_simulation_type");
        return 0;        
    }
    
    if ( $tcpar_offline_analysis and not -d $tcpar_offline_data_folder ) {
        S_set_error("Test case parameter 'offline_analysis' is selected (= $tcpar_offline_analysis), but selected data folder in parameter 'offline_data_folder' (= $tcpar_offline_data_folder) does not exist.");
        return 0;
    }

    return 1;
}

sub TC_initialization {

    # switch PD to AB12 mode, but do nothing else for offline analysis
    if ($tcpar_offline_analysis) {
        LIFT_PD::SetVariablesForUnitTest( 1, 12, 0 );
        return 1;
    }

    S_teststep( "Prepare test equipment", 'AUTO_NBR' );
	CA_simulation_start();
		S_wait_ms(1000);
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

    return 1;
}

sub TC_stimulation_and_measurement {

    $tcNumber = S_get_TC_number();

    my $dataFolder;
    if ($tcpar_offline_analysis) {
        $dataFolder = $tcpar_offline_data_folder;
    }
    else {
        $dataFolder = $main::REPORT_PATH;
    }

    my ($traceName, $deltaT_s) = GetTraceNameAndDeltaT( $dataFolder );

    DoStimulation($traceName) if not $tcpar_offline_analysis;

    S_teststep( "Get data from measurement: $traceName", 'AUTO_NBR' );
    my $measuredData_href;
    if( $tcpar_measurement_type =~ /^can$/i ) {
        $measuredData_href = CA_trace_get_dataref($traceName,[$tcpar_measurement_signal]);
    }
    elsif( $tcpar_measurement_type =~ /^fr$/i ) {
        $measuredData_href = FR_trace_get_dataref($traceName,[$tcpar_measurement_signal]);
    }
    elsif( $tcpar_measurement_type =~ /^pd$/i ) {
        $measuredData_href = PD_get_FDtrace($traceName);
        DataMs2s($measuredData_href);
    }

    my ( $ecu_output_values_aref, $times_aref ) = EVAL_get_values_and_times_over_time( $measuredData_href, $tcpar_measurement_signal );
    S_w2log( 4, "Plot raw data over time:\n" );
    CreateGraphFromHash( { 'data' => $ecu_output_values_aref, 'x' => $times_aref, 'x-label' => 'time in s' }, $tcNumber . '_jump data raw', 'amplitude', 4 );

    if( not defined $deltaT_s ) {
        $deltaT_s = DetermineDeltaT($times_aref);
    }

    my $outputData_aref = CutAtJumpValues( $ecu_output_values_aref, $times_aref, $deltaT_s );
    return 0 if @$outputData_aref == 0;

    S_teststep( "Do FFT and plot data", 'AUTO_NBR' );
    my $numberOfSamples = FindNextSmallerPowerOf2( scalar @$outputData_aref );
    my @outputData4FFT  = @$outputData_aref[ 0 .. $numberOfSamples - 1 ];

    #my $outputData4FFTFiltered_aref = FilterConstantValue( \@outputData4FFT );
    my $outputData4FFTFiltered_aref = \@outputData4FFT;

    ( $amplitude_db_aref, $groupDelay_ms_aref ) = DoFFT( $outputData4FFTFiltered_aref, $deltaT_s, $tcNumber );

    return 1;
}

sub TC_evaluation {

    S_teststep( "Evaluation of filter frequencies and group delay", 'AUTO_NBR' );

    my $item = 'passband upper frequency';
    my $measured_passband_upper_frequency_Hz = sprintf( "%.2f", FindValue( $amplitude_db_aref, -$tcpar_passband_tolerance_dB ) * $deltaF );
    S_teststep_2nd_level( "Measure $item : frequency where amplitude is still within 0 +- $tcpar_passband_tolerance_dB dB", 'AUTO_NBR', $item );
    S_teststep_expected( "$item >= $tcpar_passband_upper_frequency_Hz Hz", $item );
    S_teststep_detected( "$item = $measured_passband_upper_frequency_Hz Hz", $item );
    EVAL_evaluate_value( $item, $measured_passband_upper_frequency_Hz, '>=', $tcpar_passband_upper_frequency_Hz );

    $item = 'filter frequency';
    my $measured_filter_frequency_Hz = sprintf( "%.2f", FindValue( $amplitude_db_aref, $filterAmplitude_dB ) * $deltaF );
    S_teststep_2nd_level( "Measure $item : frequency where amplitude is $filterAmplitude_dB dB", 'AUTO_NBR', $item );
    S_teststep_expected( "$tcpar_filter_lower_frequency_Hz <= $item <= $tcpar_filter_upper_frequency_Hz Hz", $item );
    S_teststep_detected( "$item = $measured_filter_frequency_Hz Hz", $item );
    EVAL_evaluate_value( $item, $measured_filter_frequency_Hz, '>=', $tcpar_filter_lower_frequency_Hz );
    EVAL_evaluate_value( $item, $measured_filter_frequency_Hz, '<=', $tcpar_filter_upper_frequency_Hz );

    $item = 'stopband lower frequency';
    my $measured_stopband_lower_frequency_Hz = sprintf( "%.2f", FindValue( $amplitude_db_aref, $tcpar_stopband_factor_db ) * $deltaF );
    if( $measured_stopband_lower_frequency_Hz > 1 ) {
        S_teststep_2nd_level( "Measure $item : frequency where amplitude is <= $tcpar_stopband_factor_db dB", 'AUTO_NBR', $item );
        S_teststep_expected( "$item <= $tcpar_stopband_lower_frequency_Hz Hz", $item );
        S_teststep_detected( "$item = $measured_stopband_lower_frequency_Hz Hz", $item );
        EVAL_evaluate_value( $item, $measured_stopband_lower_frequency_Hz, '<=', $tcpar_stopband_lower_frequency_Hz );
    }
    else{
        S_set_warning("Could not evaluate $item. Make sure that $item is evaluated in another test case.");
    }

    $item = 'stopband maximum amplitude';
    if( $measured_stopband_lower_frequency_Hz > 1 and $highestFrequency_Hz > $tcpar_stopband_lower_frequency_Hz ) {
        my $stopbandIndex = $tcpar_stopband_lower_frequency_Hz / $deltaF;
        my @stopband_db = splice( @$amplitude_db_aref, $stopbandIndex );
        my $maxFreqIndex = 500 / $deltaF;
        splice( @stopband_db, $maxFreqIndex );
        my ( $minXS, $minSB_db, $maxXS, $maxSB_db ) = FindMinMax( \@stopband_db );
        $maxSB_db = sprintf( "%.2f", $maxSB_db );
        S_teststep_2nd_level( "Measure $item : maximum amplitude with frequency >= $tcpar_stopband_lower_frequency_Hz Hz and <= 500 Hz", 'AUTO_NBR', $item );
        S_teststep_expected( "$item <= $tcpar_stopband_factor_db dB", $item );
        S_teststep_detected( "$item = $maxSB_db dB", $item );
        EVAL_evaluate_value( $item, $maxSB_db, '<=', $tcpar_stopband_factor_db );
    }
    else{
        S_set_warning("Could not evaluate $item. Make sure that $item is evaluated in another test case.");
    }

    $item = 'maximum data age';
    my ( $minXD, $minDelay_ms, $maxXD, $maxDelay_ms ) = FindMinMax( \@$groupDelay_ms_aref );
    my $maxDelayFreq_Hz = sprintf( "%.2f", $maxXD * $deltaF );
    $maxDelay_ms = sprintf( "%.2f", $maxDelay_ms );
    S_teststep_2nd_level( "Found $item at $maxDelayFreq_Hz Hz for frequencies <= $groupDelayUpperFrequency_Hz Hz", 'AUTO_NBR', $item );
    S_teststep_expected( "$item <= $tcpar_max_data_age_ms ms", $item );
    S_teststep_detected( "$item = $maxDelay_ms ms", $item );
    EVAL_evaluate_value( $item, $maxDelay_ms, '<=', $tcpar_max_data_age_ms );

    return 1;
}

sub TC_finalization {
	if ( not $tcpar_offline_analysis )
    {
    CA_simulation_stop();
    }
    return 1;
}

#################
#
# Sub-functions
#
#################

#
# Get the name of the trace file and the data cycle time in sec depending on measurement type.
# Data cycle time for bus signals can be determined from the corresponding mapping.
# For fast diagnosis data the data cycle time will be determined later from the measurement data itself.
#
sub GetTraceNameAndDeltaT{
    my $dataFolder = shift;
    
    my ($traceName, $deltaT_s);

    if( $tcpar_measurement_type =~ /^can$/i ) {
        $traceName = $dataFolder . "/CAN_" . $tcpar_measurement_signal.".asc";

        my $can_mapping_href = S_get_contents_of_hash( ['Mapping_CAN'] );
        my $message = $can_mapping_href->{$tcpar_measurement_signal}{MESSAGE};
        S_w2log( 4, "Signal '$tcpar_measurement_signal' found in message '$message' according to CAN mapping\n" );
        my $cycleTime_ms = $can_mapping_href->{CAN_MESSAGES}{$message}{'CYCLE'};
        S_w2log( 4, "Message '$message' has a cycle time of $cycleTime_ms ms according to CAN mapping\n" );
        $deltaT_s = $cycleTime_ms / 1000;
        S_w2log( 1, "Determined deltaT = $deltaT_s s from CAN mapping\n" );
    }
    elsif( $tcpar_measurement_type =~ /^fr$/i ) {
        $traceName = $dataFolder . "/FR_" . $tcpar_measurement_signal.".asc";

        my $fr_mapping_href = S_get_contents_of_hash( ['Mapping_FLEXRAY'] );
        my $pdu = $fr_mapping_href->{$tcpar_measurement_signal}{FR_PDU_NAME};
        S_w2log( 4, "Signal '$tcpar_measurement_signal' found in PDU '$pdu' according to FLEXRAY mapping\n" );
        my $cycleTime_ms = $fr_mapping_href->{FR_PDU}{$pdu}{'CYCLE'};
        S_w2log( 4, "PDU '$pdu' has a cycle time of $cycleTime_ms ms according to FLEXRAY mapping\n" );
        $deltaT_s = $cycleTime_ms / 1000;
        S_w2log( 1, "Determined deltaT = $deltaT_s s from FLEXRAY mapping\n" );
    }
    elsif( $tcpar_measurement_type =~ /^pd$/i ){
        my $cleanSignalName = $tcpar_measurement_signal;
        $cleanSignalName =~ s/\./_/g;
        $traceName = $dataFolder . "/FD_" . $cleanSignalName;
        # $deltaT_s will be determined later from the data
    }

    return ($traceName, $deltaT_s);
}

#
# Creates an input curve, downloads it to QuaTe, starts the measurement, triggers the QuaTe and finally stops and stores the measurement
#
sub DoStimulation {
    my $traceName = shift;

    S_teststep("Create input curve for QuaTe with amplitude $testAmplitude $unit", 'AUTO_NBR');
    my ($inputCurve_aref, $curveDuration_ms) = CreateInputCurve($testAmplitude*$amp2LSB);
    
    S_teststep("Download the curve for the sensor '$tcpar_sensor_simulation_channel' in device '$tcpar_sensor_simulation_device'", 'AUTO_NBR');
    QuaTe_DownloadData($tcpar_sensor_simulation_device, $tcpar_sensor_simulation_channel, $inputCurve_aref, $stepWidth_ms*1000);

    S_teststep("Start $tcpar_measurement_type measurement of signal $tcpar_measurement_signal", 'AUTO_NBR');
    if( $tcpar_measurement_type =~ /^(can|fr)$/i ) {
        CA_trace_start ( );
    }
    elsif( $tcpar_measurement_type =~ /^pd$/i ) {
	CA_trace_start ( );#added for MRA2
        my $measurement_signal_type = PD_get_type_from_name($tcpar_measurement_signal);
        PD_StartFastDiagName( $traceName , [$tcpar_measurement_signal] , [$measurement_signal_type]);
    }
              
    S_wait_ms(200);
    S_teststep("Trigger sensor simulation", 'AUTO_NBR');
    QuaTe_SendControllerTrigger( 0 );
    S_wait_ms( $curveDuration_ms );

    S_teststep("Stop and store $tcpar_measurement_type measurement", 'AUTO_NBR');
    if( $tcpar_measurement_type =~ /^(can|fr)$/i ) {
        CA_trace_store ( $traceName );
		CA_trace_stop();
    }
    elsif( $tcpar_measurement_type =~ /^pd$/i ) {
        PD_StopFastDiag();
		CA_trace_stop();#added for MRA2
    }
}

#
# Create an input curve with given amplitude
#
sub CreateInputCurve{
    my $amplitude = shift;
    
    my $zeroTime_ms = 5000;
    my $valueTime_ms = 5000;
    my $zeroPoints = int( $zeroTime_ms / $stepWidth_ms + 0.5);
    my $valuePoints = int( $valueTime_ms / $stepWidth_ms + 0.5);
    
    my @curvePoints;
    push( @curvePoints, (0) x $zeroPoints );
    push( @curvePoints, ($amplitude) x $valuePoints );
    push( @curvePoints, (0) x $zeroPoints );
    my $curveDuration_ms = 2*$zeroTime_ms + $valueTime_ms;
    
    return (\@curvePoints, $curveDuration_ms);
}

#
# ($outputData_aref, $deltaT_s) = CutAtJumpValues($measuredData_href, $jumpValue);
#
# Cut the raw data ($measuredData_href) so that only the data from the first jump (from 0 to $jumpValue)
# until the second jump (from $jumpValue to 0) is present in the data.
# The first jump is included, the second jump is excluded.
#
# Return values:
# $outputData_aref: cut data as array ref
# $deltaT_s: time difference in s between every 2 data points
#
sub CutAtJumpValues {

    my $ecu_output_values_aref = shift;
    my $times_aref             = shift;
    my $deltaT_s               = shift;

    ($ecu_output_values_aref, $times_aref) = InterpolateDataGaps($ecu_output_values_aref, $times_aref, $deltaT_s);

    S_w2log( 4, "Plot interpolated raw data over time:\n" );
    CreateGraphFromHash( { 'data' => $ecu_output_values_aref, 'x' => $times_aref, 'x-label' => 'time in s' }, $tcNumber . '_jump data raw interpolated', 'amplitude', 4 );

    # calculate derivative of values to find the first jump time as maximum of the derivative
    my $values_derivative_aref = SimpleDerivative($ecu_output_values_aref);
    my ( $minX, $minDerivValue, $maxX, $maxDerivValue ) = FindMinMax($values_derivative_aref);

    if( $minX < $maxX ) {
        S_w2log( 1, "Negative jump detected. Changing the sign of measured data...\n" );
        $ecu_output_values_aref = DataSignChange($ecu_output_values_aref);
        $values_derivative_aref = SimpleDerivative($ecu_output_values_aref);
        ( $minX, $minDerivValue, $maxX, $maxDerivValue ) = FindMinMax($values_derivative_aref);
    }

    S_w2log( 4, "Plot derivative of raw data over time:\n" );
    CreateGraphFromHash( { 'data' => $values_derivative_aref, 'x' => $times_aref, 'x-label' => 'time in s' }, $tcNumber . '_raw_data_derivative', 'amplitude', 4 );

    # loop backwards in derivatives from $maxX to find the first 0 or negative value. This is the point where the jump starts precisely
    my $jumpStartIndex;
    foreach my $index ( reverse 0 .. $maxX ) {
        my $derivative = $$values_derivative_aref[$index];
        if ( $derivative <= 0 ) {
            $jumpStartIndex = $index + 1;
            last;
        }
    }
    my $jumpEndIndex = $minX - 100;
    S_w2log(5, "CutAtJumpValues: Jump start and end index: $jumpStartIndex and $jumpEndIndex.\n");
    my $jumpStartTime = $jumpStartIndex * $deltaT_s;
    my $jumpEndTime = $jumpEndIndex * $deltaT_s;
    S_w2log(4, "CutAtJumpValues: Jump start and end time $jumpStartTime s and $jumpEndTime s.\n");

    # consistency checks for start and end index
    my $jumpDuration_s = ( $jumpEndIndex - $jumpStartIndex ) * $deltaT_s;
    if ( $jumpDuration_s < 0.6 ) {
        S_set_error("The time between data jump start and data jump end must be at least 0.6 s, but it is $jumpDuration_s s. Data quality is not sufficient");
        return ( [], 0.001 );
    }

    # determine mean zero value from first data points, before the jump
    my $numberOfZeroValues = 2.5 / $deltaT_s;
    my $zeroValuesSum      = 0;
    grep { $zeroValuesSum += $_ } @$ecu_output_values_aref[ $jumpStartIndex - 10 - $numberOfZeroValues .. $jumpStartIndex - 11 ];
    my $meanZeroValue = $zeroValuesSum / $numberOfZeroValues;
    S_w2log(4, "CutAtJumpValues: Mean zero value = $meanZeroValue determined from $numberOfZeroValues data values before the jump.\n");

    if ( $numberOfZeroValues < 100 ) {
        S_set_warning("Only few data points before jump in data. Data quality may be not sufficient");
    }

    # get all data points from jump start to jump end
    my @outputData = @$ecu_output_values_aref[ $jumpStartIndex .. $jumpEndIndex ];

    # subtract the mean zero value from all data values to do offset compensation
    my @outputData_offset_comp = map { $_ - $meanZeroValue } @outputData;

    # pull first data point to 0
    shift(@outputData_offset_comp);
    unshift( @outputData_offset_comp, 0 );

    return \@outputData_offset_comp;
}

#
# ($amplitude_db_aref, $groupDelay_s_aref, $deltaF) = DoFFT($data_aref, $deltaT_s, $titlePrefix);
#
# Perform an FFT on $data_aref (number of data points must be a power of 2).
# The time difference in s between every 2 data points must be given in $deltaT_s.
# The following quantities are calculated from the FFT output:
# amplitude (absolute and in dB), phase (in deg), group delay (derivative of the phase, unfiltered and filtered)
# A plot of all derived quantities is done with a title prefix $titlePrefix.
#
# Return values:
# $amplitude_db_aref: amplitude values in dB
# $groupDelay_s_aref: group delay values in s
# $deltaF: frequency delta between every 2 points in Hz
#
sub DoFFT {
    my $data_aref   = shift;    # data array for FFT
    my $deltaT_s    = shift;    # delta T of every 2 data points in sec
    my $titlePrefix = shift;    # prefix for plot titles

    # get time axis data
    my @timeValues = map { $_ * $deltaT_s } 0 .. ( @$data_aref - 1 );

    # calculate the first derivative of the data to get rid of the constant offset; the jump is converted into a dirac pulse
    my $data_deriv_aref = SimpleDerivative($data_aref);

    # determine unit for frequency for x-axis plots
    my $dataSize = @{$data_aref};
    $deltaF = 1 / ( $deltaT_s * $dataSize );
    S_w2log(5, "DoFFT: Delta f in FFT output is $deltaF Hz.\n");

    # do the FFT on the data
    my $fft        = new Math::FFT($data_deriv_aref);
    my $coeff_aref = $fft->rdft();

    # split $coeff_aref into re (even index) and im (odd index) values; see the documentation of Math::FFT for details
    my ( @re, @im );
    my $index      = 0;
    my $firstValue = $$coeff_aref[0];
    foreach my $value (@$coeff_aref) {
        if ( $index % 2 ) {
            push( @im, $value / $firstValue );
        }
        else {
            push( @re, $value / $firstValue );
        }
        $index++;
    }

    # calculate all required quantities from re and im
    my ( @xValues, @amplitude, @phase, @amplitude_db, $maxAmplitude );
    my $lastPhase           = 0;
    my $phaseCorrection_deg = 0;
    foreach my $index ( 0 .. @re - 1 ) {

        # x-values for all plots over frequency
        my $xValue = $index * $deltaF;
        push( @xValues, $xValue );

        # amplitude (absolute value)
        my $amplitudeValue = sqrt( $re[$index] * $re[$index] + $im[$index] * $im[$index] );
        $maxAmplitude = $amplitudeValue if $index == 0;
        push( @amplitude, $amplitudeValue );

        # amplitude in dB
        my $amplitudeValue_db = log( $amplitudeValue / $maxAmplitude + $epsilon ) / log(10) * 20;
        push( @amplitude_db, $amplitudeValue_db );

        # phase (angle)
        my $phaseValue = atan2( $im[$index], $re[$index] );
        my $phaseValue_deg = -rad2deg($phaseValue);

        # correct phase values if there is a jump by 360deg to make the curve continuous
        $phaseValue_deg += $phaseCorrection_deg;
        if ( $phaseValue_deg - $lastPhase > 200 ) {
            $phaseValue_deg      -= 360;
            $phaseCorrection_deg -= 360;
        }
        elsif ( $phaseValue_deg - $lastPhase < -200 ) {
            $phaseValue_deg      += 360;
            $phaseCorrection_deg += 360;
        }
        push( @phase, $phaseValue_deg );
        $lastPhase = $phaseValue_deg;
    }

    # group delay from derivative of phase
    my $phase_deriv_aref = SimpleDerivative( \@phase );
    my @groupDelay = map { $_ / (-360) / $deltaF * 1000 } @$phase_deriv_aref;    # in ms

    $highestFrequency_Hz = $xValues[$#xValues];
    $groupDelayUpperFrequency_Hz = 3*$tcpar_filter_lower_frequency_Hz;
    if( $groupDelayUpperFrequency_Hz > $highestFrequency_Hz ) {
        S_w2log( 1, "Upper frequency for group delay reduced to $highestFrequency_Hz Hz because 3* filter frequency is too high.\n" );
        $groupDelayUpperFrequency_Hz = $highestFrequency_Hz;
    }

    # take group delay only until stopband lower frequency
    @groupDelay = @groupDelay[ 0 .. $groupDelayUpperFrequency_Hz / $deltaF ];
    my @reducedxValues = @xValues[ 0 .. $groupDelayUpperFrequency_Hz / $deltaF ];

    # get initial jump data for a plot to verify that the jump begins immediately at 0
    my $numberOfInitialValues = 10;
    my @initialDataValues     = @$data_aref[ 0 .. $numberOfInitialValues ];
    my @initialTimeValues     = @timeValues[ 0 .. $numberOfInitialValues ];

    # plot all curves
    S_w2log( 1, "Plot filtered jump data over time:\n" );
    CreateGraphFromHash( { 'data' => $data_aref, 'x' => \@timeValues, 'x-label' => 'time in s' }, $titlePrefix . '_jump_data', 'amplitude', 1 );
    S_w2log( 1, "Plot begin of filtered jump data over time:\n" );
    CreateGraphFromHash( { 'data' => \@initialDataValues, 'x' => \@initialTimeValues, 'x-label' => 'time in s' }, $titlePrefix . '_initial_jump_data', 'amplitude', 1 );
    S_w2log( 4, "Plot FFT input (derivative of jump data) over time:\n" );
    CreateGraphFromHash( { 'data_deriv' => $data_deriv_aref, 'x' => \@timeValues, 'x-label' => 'time in s' }, $titlePrefix . '_FFT_input_deriv', 'amplitude', 4 );
    S_w2log( 4, "Plot raw FFT results over frequency:\n" );
    CreateGraphFromHash( { 'rdft_re' => \@re, 'rdft_im' => \@im, 'x' => \@xValues, 'x-label' => 'frequency in Hz' }, $titlePrefix . '_raw_FFT_results', 'fft', 4 );
    S_w2log( 4, "Plot amplitude (absolute) over frequency:\n" );
    CreateGraphFromHash( { 'amplitude' => \@amplitude, 'x' => \@xValues, 'x-label' => 'frequency in Hz' }, $titlePrefix . '_amplitude_rel', 'amplitude', 4 );
    S_w2log( 1, "Plot amplitude in dB over frequency:\n" );
    CreateGraphFromHash( { 'amplitude_db' => \@amplitude_db, 'x' => \@xValues, 'x-label' => 'frequency in Hz' }, $titlePrefix . '_amplitude_db', 'amplitude in dB', 1 );
    S_w2log( 4, "Plot phase in deg over frequency:\n" );
    CreateGraphFromHash( { 'phase' => \@phase, 'x' => \@xValues, 'x-label' => 'frequency in Hz' }, $titlePrefix . '_phase', 'phase in deg', 4 );
    S_w2log( 4, "Plot phase difference over frequency:\n" );
    CreateGraphFromHash( { 'phase_deriv' => $phase_deriv_aref, 'x' => \@xValues, 'x-label' => 'frequency in Hz' }, $titlePrefix . '_phase_deriv', 'phase diff in deg', 4 );
    S_w2log( 1, "Plot group delay in ms over frequency:\n" );
    CreateGraphFromHash( { 'group_delay' => \@groupDelay, 'x' => \@reducedxValues, 'x-label' => 'frequency in Hz' }, $titlePrefix . '_group_delay', 'group delay in ms', 1 );

    return ( \@amplitude_db, \@groupDelay );
}

sub CreateGraphFromHash {
    my $graphData_href = shift;
    my $graphTitle     = shift;
    my $ylabel         = shift;
    my $loglevel       = shift;

    S_create_graph( $graphData_href, "$main::REPORT_PATH/$graphTitle.txt", $graphTitle, 'white', 'no_interpolation', $ylabel );
    S_add_pic2html( "$graphTitle.png", "", "$graphTitle.txt.unv", 'TYPE="text/unv"', $loglevel );
    return 1;
}

#
# $data_deriv_aref = SimpleDerivative($data_aref);
#
# Calculate a simple derivative for equidistant data points $data_aref.
#
# Return values:
# @data_deriv: derivative of $data_aref
#
sub SimpleDerivative {
    my $data_aref = shift;

    my ( @derivatives, $previous, $current, $next, $slope );

    # loop over all data points
    foreach my $index ( 0 .. @$data_aref - 1 ) {
        $current = $$data_aref[$index];

        # for first point take only current and next value
        if ( $index == 0 ) {
            $next  = $$data_aref[ $index + 1 ];
            $slope = $next - $current;
        }

        # for last point take only current and previous value
        elsif ( $index == @$data_aref - 1 ) {
            $previous = $$data_aref[ $index - 1 ];
            $slope    = $current - $previous;
        }

        # for all other points take previous and next value
        else {
            $previous = $$data_aref[ $index - 1 ];
            $next     = $$data_aref[ $index + 1 ];
            $slope    = ( $next - $previous ) / 2;
        }
        push( @derivatives, $slope );
    }

    return \@derivatives;
}

#
# $foundX = FindValue($data_aref, $findValue [, $startIndex ] );
#
# Find the x-value (index) for a given y-value $findValue in data array $data_aref.
# Linear interpolation is done between the data points in order to get the x-value as precise as possible.
#
# Return values:
# $foundX: x-value (unit-less)
#
sub FindValue {
    my $data_aref  = shift;
    my $findValue  = shift;
    my $startIndex = shift;

    $startIndex = 0 if not defined $startIndex;

    my $foundX;
    my $lastDifference = 0;
    foreach my $index ( $startIndex .. @$data_aref - 1 ) {
        my $currentValue = $$data_aref[$index];
        my $difference   = $currentValue - $findValue;
        if ( $difference * $lastDifference < 0 ) {    # check if sign is different
            my $lastValue = $$data_aref[ $index - 1 ];
            my $deltaY    = $currentValue - $lastValue;
            my $xPart     = $findValue - $lastValue;
            $foundX = $index - 1 + $xPart / $deltaY;
            last;
        }
        $lastDifference = $difference;
    }
    
    if( not defined $foundX ) {
        S_w2log(1, "Could not find value $findValue from start index $startIndex in given data.");
        return;
    }

    S_w2log(5, "FindValue: Value $findValue found at x = $foundX (interpolated) in given data.\n");

    return $foundX;
}

#
# ($minX, $minValue, $maxX, $maxValue) = FindMinMax($data_aref);
#
# Find minimum and maximum values in a data array $data_aref and their corresponding x-value (index).
#
# Return values:
# $minX: x-value (index) of the minimum value
# $minValue: minimum value
# $maxX: x-value (index) of the maximum value
# $maxValue: maximum value
#
sub FindMinMax {
    my $data_aref = shift;

    my $minValue = 1e99;
    my $maxValue = -1e99;

    my ( $minX, $maxX );
    foreach my $index ( 0 .. @$data_aref - 1 ) {
        my $currentValue = $$data_aref[$index];
        if ( $currentValue < $minValue ) {
            $minValue = $currentValue;
            $minX     = $index;
        }
        if ( $currentValue > $maxValue ) {
            $maxValue = $currentValue;
            $maxX     = $index;
        }
    }
    S_w2log(5, "FindMinMax: minimum value = $minValue at x = $minX   ,   maximum value = $maxValue at x = $maxX\n");

    return ( $minX, $minValue, $maxX, $maxValue );
}

#
# $powerOf2 = FindNextSmallerPowerOf2($number);
#
# Find the next smaller power of 2 for a given $number.
#
# Return values:
# $powerOf2: next smaller power of 2 for $number
#
sub FindNextSmallerPowerOf2 {
    my $number = shift;

    my $exponent = int(log($number)/log(2));
    my $powerOf2 = 1 << $exponent;

    S_w2log(5, "FindNextSmallerPowerOf2: Next smaller power of 2 for $number is $powerOf2\n");

    return $powerOf2;
}

#
# $outputData_aref = RollingAverage($data_aref, $period);
#
# Calculate a rolling average for every point of $data_aref out of every $period values.
#
# Return values:
# $outputData_aref: array with rolling average values
#
sub RollingAverage {
    my $data_aref = shift;
    my $period    = shift;

    my ( @subArray, @outputArray );
    foreach my $value (@$data_aref) {
        push( @subArray, $value );
        if ( @subArray > $period + $epsilon ) {
            shift @subArray;
        }
        my $sum;
        grep { $sum += $_ } @subArray;
        my $average = $sum / @subArray;
        push( @outputArray, $average );
    }
    return \@outputArray;
}

#
# $outputData_aref = FilterConstantValue($data_aref);
#
# From $data_aref determine the constant value from the right, find a complete oscillation and take original data until 2 oscillations.
# From that point onwards do a linear interpolation until the constant value and let the rest of the data at constant value.
#
# Return values:
# $outputData_aref: array with filtered values
#
sub FilterConstantValue {
    my $data_aref = shift;

    my $dataLength = @$data_aref;

    my $pointsForConstantValue  = int( $dataLength / 2 + $epsilon );
    my $pointsForLinearAdaption = int( $dataLength / 4 + $epsilon );

    # find constant value from right
    my @constantPart = splice( @$data_aref, -$pointsForConstantValue );
    my $constSum;
    grep { $constSum += $_ } @constantPart;
    my $constantValue = $constSum / @constantPart;
    S_w2log(5, "FilterConstantValue: Constant value in jump is $constantValue.\n");

    # find complete period from left (first 3 occurances of constant value)
    my $constValueIndex1 = FindValue( $data_aref, $constantValue, 0 );
    my $constValueIndex2 = FindValue( $data_aref, $constantValue, $constValueIndex1 + 1 );
    my $constValueIndex3 = FindValue( $data_aref, $constantValue, $constValueIndex2 + 1 );

    # determine double period and take original data until double period
    my $origDataIndex     = int( 2 * $constValueIndex3 - $constValueIndex1 + $epsilon );
    my $lastOrigDataValue = $$data_aref[ $origDataIndex - 1 ];
    my @outputArray       = splice( @$data_aref, 0, $origDataIndex );
    S_w2log(4, "FilterConstantValue: Taking original data until index $origDataIndex.\n");

    # do linear adaption from double period to constant value for 1000 points
    foreach my $index ( 1 .. $pointsForLinearAdaption ) {
        my $adaptionValue = $lastOrigDataValue + $index / $pointsForLinearAdaption * ( $constantValue - $lastOrigDataValue );
        push( @outputArray, $adaptionValue );
    }
    S_w2log(4, "FilterConstantValue: Next $pointsForLinearAdaption data points will adapt linearly to value $constantValue.\n");

    # add constant value for the rest of the array
    my $missingPoints = $dataLength - @outputArray;
    @constantPart = ($constantValue) x $missingPoints;
    push( @outputArray, @constantPart );
    S_w2log(4, "FilterConstantValue: The rest of the data points will be constant at value $constantValue.\n");

    return \@outputArray;
}

#
# Finds gaps in the data and adds missing data points using linear interpolation
#
sub InterpolateDataGaps{
    my $values_aref = shift;
    my $times_aref  = shift;
    my $deltaTNominal = shift;

    # find gaps in data and interpolate if gaps are found
    my $lastValue = $$values_aref[0];
    my $lastTime = $$times_aref[0];
    my @newValues = ($lastValue);
    my @newTimes = ($lastTime);   
    my $interpolateCounter = 0;
    foreach my $index ( 1 .. $#$values_aref ) {
        my $value = $$values_aref[$index];
        my $time = $$times_aref[$index];
        my $deltaT = $time - $lastTime;
        my $gapSize = int( $deltaT/$deltaTNominal + 0.5 ) - 1;
        if( $gapSize > 0 ) {
            my $deltaV = ($value - $lastValue)/($gapSize + 1);
            foreach my $gapCounter ( 1 .. $gapSize ) {
                push(@newValues, $lastValue+$gapCounter*$deltaV);
                push(@newTimes, $lastTime+$gapCounter*$deltaTNominal);
            }
            $interpolateCounter += $gapSize;
        }
        push(@newValues, $value);
        push(@newTimes, $time);
        $lastValue = $value;
        $lastTime = $time;
    }
    
    if( $interpolateCounter > 0 ) {
        my $datapointsOld = @$times_aref;
        my $datapointsNew = @newTimes;
        S_set_warning("Detected $interpolateCounter gaps in the data. Those gaps are interpolated, so the number of data points increases from $datapointsOld to $datapointsNew");
    }
    
    return (\@newValues, \@newTimes);
}

#
# Changes the time base of a given $data_href structure from ms to s   
#
sub DataMs2s{
    my $data_href = shift;
    
    my @times = sort {$a <=> $b} keys %{ $data_href };
    foreach my $time ( @times ) {
        my $newTime = $time/1000;
        foreach my $signal ( keys %{ $data_href->{$time} } ) {
            my $value = $data_href->{$time}{$signal};
            $data_href->{$newTime}{$signal} = $value;
        }
        delete $data_href->{$time};
    }
}

#
# Changes the sign of the values of a $values_aref array
#
sub DataSignChange{
    my $values_aref = shift;

    my @newValues;

    foreach my $index ( 0 .. $#$values_aref ) {
        my $value = $$values_aref[$index];
        $value = -$value;
        push(@newValues, $value);
    }
    
    return \@newValues;
}

#
# Calculates the time difference between every 2 data points and fills them into a histogram.
# Then finds the maximum value of the histogram. The corresponding time difference value is the nominal time difference of the measurement.
# By this procedure the nominal time difference of the measurement can be found even if there are data gaps.
#
sub DetermineDeltaT{
    my $times_aref = shift;
    
    my $histogramChannelWidth_s = 0.0001;
    my $histogramMax_s = 0.2;
    my $numberOfChannels = $histogramMax_s/$histogramChannelWidth_s;
    
    my @deltaTHistogram = (0) x $numberOfChannels;

    my $lastTime_s = 0;
    foreach my $time_s ( @$times_aref ) {
        my $deltaT_s = $time_s - $lastTime_s;
        my $histogramIndex = int( $deltaT_s/$histogramChannelWidth_s + 0.5 );
        $histogramIndex = 0 if $histogramIndex < 0;
        $histogramIndex = $numberOfChannels-1 if $histogramIndex > $numberOfChannels-1;
        $deltaTHistogram[$histogramIndex]++;
        $lastTime_s = $time_s;
    }

    my @times_s;
    my $maxHistogramIndex;
    my $maxHistogramValue = -1;
    foreach my $index ( 0 .. $numberOfChannels-1 ) {
        $times_s[$index] = $index * $histogramChannelWidth_s;
        my $histogramValue = $deltaTHistogram[$index];
        if( $histogramValue > $maxHistogramValue ) {
            $maxHistogramValue = $histogramValue;
            $maxHistogramIndex = $index;
        }
    }

    my %graphData;
    my $yLabel = 'deltaT_number';
    $graphData{'x'}       = \@times_s;
    $graphData{'x-label'} = 'deltaT in s';
    $graphData{$yLabel} = \@deltaTHistogram;

    S_w2log( 4, "Plot deltaT histogram:\n" );

    CreateGraphFromHash( { 'data' => \@deltaTHistogram, 'x' => \@times_s, 'x-label' => 'deltaT in s' }, $tcNumber . '_deltaT_histogram', 'number', 4 );

    my $deltaT_s = $maxHistogramIndex * $histogramChannelWidth_s;
    S_w2log( 1, "Determined deltaT = $deltaT_s s from measurement\n" );

    return $deltaT_s;
}

1;
