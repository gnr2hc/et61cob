#### TEST CASE MODULE
package TC_VDS_SlowOffsetCorrection;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER = q$Header: VDS/CREIS_Setup/TC_VDS_SlowOffsetCorrection.pm 1.1 2017/09/07 20:04:40ICT Prosch Christian (CC-PS/EPS2) (PHC2SI) develop  $;

#### INCLUDE ENGINE MODULES ####

use INCLUDES_Project; #necessary
use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use LIFT_QuaTe;

##################################

our $PURPOSE = "Test of VDS Slow Offset Correction Functionality";

# DOCUMENTATION 

=head1 TESTCASE MODULE

TC_VDS_SlowOffsetCorrection

=head1 PURPOSE

	Test of SMI7xy Slow Offset Correction

=head1 TESTCASE DESCRIPTION


IBPreconditions

    Configure sensor simulation device with all sensors that are defined for the project (use existing crash injection config)

IBInitialisation


IBStimulation and Measurement

    create list of frequency values to be tested (@testFrequencies)
    loop over all frequencies of @testFrequencies
        start measurement of PD, CAN or flexray depending on %tcpar_measurement
        create a sine curve with the given frequency and an amplitude depending on $tcpar_sensor_simulation{'type'}
        stimulate the created curve for the sensor defined in %tcpar_sensor_simulation
        stop and store measurement
        determine frequency and amplitude of the measured curve (tbd how exactly)
        check if measured frequency = stimulated frequency (which tolerance?)
        add frequency (x-value) and amplitude (y-value) to frequency diagram
    end loop

IBEvaluation

    plot frequency diagram

IBFinalisation


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' = Purpose of the Testcase
	SCALAR 'sensor_simulation_device' = sensor simulation device name
	SCALAR 'sensor_simulation_channel' = sensor simulation channel name
	SCALAR 'sensor_simulation_type' = sensor simulation type: 'rate' or 'acceleration'
	SCALAR 'signal_amplitude' = signal value in g or �/s
	SCALAR 'duration_s' = signal duration in sec
	LIST 'FLTmand' = mandatory faults
	LIST 'FLTopt' = optional faults

=head2 PARAMETER EXAMPLES

    [TC_FLT_OffsetCancellation.wz_CAN]
    purpose	= 'Check Slow Offset Correction for wz'
    sensor_simulation_device = 'SMI700'
    sensor_simulation_channel = 'Ang_Rate_-Z'
    sensor_simulation_type = 'rate'
    signal_amplitude = 90
    duration_s = 2250
    Labels = @('rb_csem_SensorDataRT_st.ChannelValue_as16(4)','rb_siam_CentralSensorData_st.CsLowGXData_s16','rb_simc_CtrlChOffsetValue_as16(4)','rb_cs7m_ChlState_aen(0)')
    FLTmand = @()
    FLTopt = @()

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_sensor_simulation_device;
my $tcpar_sensor_simulation_channel;
my $tcpar_sensor_simulation_type;
my $tcpar_signal_amplitude;
my $tcpar_duration_s;
my $tcpar_Labels;

################ global parameter declaration ###################
#add any global variables here

my ($testAmplitude, $unit, $amp2LSB);
my (@tcpar_FLTmand, @tcpar_FLTopt);
my $fltmem1;

my $stepWidth_ms = 10;
my ($fd_file_name, $fd_plotfile);

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_sensor_simulation_device =  GEN_Read_mandatory_testcase_parameter( 'sensor_simulation_device' );
	$tcpar_sensor_simulation_channel =  GEN_Read_mandatory_testcase_parameter( 'sensor_simulation_channel' );
	$tcpar_sensor_simulation_type =  GEN_Read_mandatory_testcase_parameter( 'sensor_simulation_type' );
	$tcpar_Labels         = GEN_Read_optional_testcase_parameter( 'Labels', 'byref' );
	$tcpar_signal_amplitude = GEN_Read_mandatory_testcase_parameter ( 'signal_amplitude' );
	$tcpar_duration_s = GEN_Read_mandatory_testcase_parameter( 'duration_s' );

    if( $tcpar_sensor_simulation_type =~ /^rate/i ) {
        $testAmplitude = 90;
        $unit = 'deg/s';
        $amp2LSB = 100;
    }
    elsif( $tcpar_sensor_simulation_type =~ /^accel/i ) {
        $testAmplitude = 1;
        $unit = 'G';
        $amp2LSB = 5000; # for low g signals
        
    }
    else{
        S_set_error("\$tcpar_sensor_simulation_type must be either 'rate' or 'accel', but it is $tcpar_sensor_simulation_type");
        return 0;        
    }
    @tcpar_FLTmand = GEN_Read_optional_testcase_parameter('FLTmand');
    @tcpar_FLTopt  = GEN_Read_optional_testcase_parameter('FLTopt');
    
	return 1;
}

sub TC_initialization {

    LC_ECU_On('U_BATT_DEFAULT');
    S_wait_ms('TIMER_ECU_READY');

    PD_ECUlogin();
    PD_ClearFaultMemory();
    S_wait_ms('TIMER_ECU_READY');
    PD_GetExtendedFaultInformation(BOSCH_FLT_MEM);

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

	return 1;
}

sub TC_stimulation_and_measurement {
    
	S_teststep( 'Switch ECU on', 'AUTO_NBR');
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');
	PD_ECUlogin();
	
	my $tcNumber = S_get_TC_number ( ); 

    S_teststep("Signal amplitude $tcpar_signal_amplitude $unit for $tcpar_duration_s s", 'AUTO_NBR');

    S_teststep_2nd_level("create signal", 'AUTO_NBR');
    my $rect_aref = CreateRectangleZeroCurve($tcpar_signal_amplitude*$amp2LSB, $tcpar_duration_s, $stepWidth_ms);
    my $duration_ms = $tcpar_duration_s*1000+2000;
        
    S_teststep_2nd_level("download the curve for the sensor '$tcpar_sensor_simulation_channel' in device '$tcpar_sensor_simulation_device'", 'AUTO_NBR');
    QuaTe_DownloadData($tcpar_sensor_simulation_device, $tcpar_sensor_simulation_channel, $rect_aref, $stepWidth_ms*1000);
             
    S_wait_ms(200);
    #S_user_action("Start fast diagnosis");	
				
    S_teststep_2nd_level( "Read labels with fast diagnosis to capture values", 'AUTO_NBR' );
    $fd_file_name = "$main::REPORT_PATH/" . S_get_TC_number() . '_SOC_PD_FD';
    $fd_plotfile  = "$main::REPORT_PATH/" . S_get_TC_number() . '_SOC_PD_FD_Plot.txt.unv';
    PD_StartFastDiagName( $fd_file_name, $tcpar_Labels, ['S16','S16','S16','U8'], undef, 1 );
		
    S_teststep_2nd_level("Trigger sensor simulation", 'AUTO_NBR');
    QuaTe_SendControllerTrigger( 0 );
    S_wait_ms($duration_ms);

	#S_user_action("Stop fast diagnosis");
	PD_StopFastDiag();
    #my $data_HoH = PD_get_FDtrace($fd_file_name);
    #PD_plot_FDtrace( $data_HoH, $fd_plotfile );
	
    S_teststep( 'Read fault recorder', 'AUTO_NBR' );
    PD_ECUlogin();
    $fltmem1 = PD_GetExtendedFaultInformation(BOSCH_FLT_MEM);
    S_teststep( 'Evaluate fault recorder', 'AUTO_NBR', 'Fault' );
	
	return 1;
}

sub TC_evaluation {

    S_teststep_expected( 'Expected faults:', 'Fault' );
    foreach my $fault (@tcpar_FLTmand) {
        S_teststep_expected($fault);
    }

    S_teststep_detected( 'Detected faults:', 'Fault' );
    foreach my $fault ( @{ $fltmem1->{fault_text} } ) {
        S_teststep_detected($fault);
    }
    PD_evaluate_faults( $fltmem1, \@tcpar_FLTmand, \@tcpar_FLTopt );
   
	return 1;
}

sub TC_finalization {

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

	return 1;
}



#sub CreateRectangleCurve{
#    my $amplitude = shift;
#    my $duration_s = shift;
#    my $stepWidth_ms = shift; #50ms
#        
#	my @curvePoints;
#
#    my $mumberOfPoints = int( 1 * 1000 / $stepWidth_ms);
#    my @zeros = (0) x $mumberOfPoints;
#
#	push( @curvePoints, @zeros);
#
#	$mumberOfPoints = int( $duration_s * 1000 / $stepWidth_ms);
#	my @offsets = ($amplitude) x $mumberOfPoints;
#
#	push( @curvePoints, @offsets);
#
#	push( @curvePoints, @zeros);
#   
#   return \@curvePoints;
#}

sub CreateRectangleZeroCurve {
	my $amplitude                = shift;
	my $duration_s               = shift;
	my $stepWidth_ms             = shift;    
	my $durationPartAmplitude_ms = 3950;
	my $durationPartZero_ms      = 50;
	my $numberOfPeriods = $duration_s * 1000 / ( $durationPartAmplitude_ms + $durationPartZero_ms );
	
	my @curvePoints;
	#my $numberOfPoints1 = int( 1 * 1000 / $stepWidth_ms );
	#my @zeros          = (0) x $numberOfPoints1;
	my @zeros;

	#push( @curvePoints, @zeros );

	my $numberOfPoints2 = int( $durationPartAmplitude_ms / $stepWidth_ms );
	my @offsets = ($amplitude) x $numberOfPoints2;

	my $numberOfPoints3 = int( $durationPartZero_ms / $stepWidth_ms );
	@zeros          = (0) x $numberOfPoints3;

	foreach my $index ( 1 .. $numberOfPeriods ) {
	

		push( @curvePoints, @offsets );
		push( @curvePoints, @zeros );
		$index++;
	}
	my $numberOfPoints4 = int( ($duration_s * 1000 % ( $durationPartAmplitude_ms + $durationPartZero_ms)) / $stepWidth_ms );
	my @offsets = ($amplitude) x $numberOfPoints4;
	push( @curvePoints, @offsets );
	
    return \@curvePoints;

}

sub DisturbCurve{
    my $curve_aref = shift;
    my $amplitudeFactor = shift;
    my $noiseFactor = shift;
    
    my @valuesDisturbed;
    foreach my $value ( @{$curve_aref} ){
        my $newValue = $amplitudeFactor * $value + (rand(2) - 1)*$noiseFactor;
        push(@valuesDisturbed, $newValue);
    }

    return \@valuesDisturbed;
}

1;
