#### TEST CASE MODULE
package TC_VDS_MeasurementRange;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.6 $;
our $HEADER  = q$Header: VDS/CREIS_Setup/TC_VDS_MeasurementRange.pm 1.6 2019/04/29 11:02:18ICT Andrews Xavier Jesu (RBEI/EVS) (XAA1COB) develop  $;

#### INCLUDE ENGINE MODULES ####

use INCLUDES_Project; #necessary
use LIFT_general;
use LIFT_evaluation;
use LIFT_PD;
use LIFT_labcar;
use LIFT_QuaTe;
use LIFT_can_access;
use LIFT_flexray_access;

##################################

our $PURPOSE = "Test of VDS bus signals measurement range";

# DOCUMENTATION

=head1 TESTCASE MODULE

TC_VDS_MeasurementRange

=head1 PURPOSE

Test of VDS bus signals measurement range

=head1 TESTCASE DESCRIPTION

The test stimulates values close to the measurement range threshold (measurement_signal_range_threshold) on one of the VDS sensor channels.
The stimulated values are from stimulation_min_value until stimulation_max_value in steps of 0.01G for accelerations or 1deg/s for rates
for a duration of 980ms. In between always the values are set to 0 for 20ms to avoid triggering of SW monitorings for the VDS signals.
For stimulated values > measurement_signal_range_threshold the measured value must be = measurement_signal_range_threshold.
For stimulated values > measurement_quality_OK_threshold the measurement_quality_signal must be set to != measurement_quality_in_range_value.

I<B<Preconditions>>

This test can only be performed with a Quate and an ECU prepared for crash injection.

I<B<Initialisation>>

    - Switch on ECU.
    - Read fault memory

I<B<Stimulation and Measurement>>

    - Create stimulation curve (see description above) for sensor simulation
    - Load stimulation curve to sensor simulation
    - Start bus trace
    - Trigger stimulation curve
    - Stop and store bus trace

I<B<Evaluation>>

    - Load bus trace and extract data for measurement_signal and measurement_quality_signal
    - For every stimulation step get the mean measured value from the last 500ms (avoid filter oscillations)
    - If stimulation value < measurement_signal_range_threshold then measured value must be = stimulated value
    - If stimulation value >= measurement_signal_range_threshold then measured value must be = measurement_signal_range_threshold
    - If stimulation value < measurement_quality_OK_threshold then measurement_quality_signal must be = measurement_quality_in_range_value
    - If stimulation value >= measurement_quality_OK_threshold then measurement_quality_signal must be != measurement_quality_in_range_value

I<B<Finalisation>>

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

	SCALAR 'purpose' = Purpose of the Testcase
	SCALAR 'sensor_simulation_device' = sensor simulation device name
	SCALAR 'sensor_simulation_channel' = sensor simulation channel name
	SCALAR 'sensor_simulation_type' = sensor simulation type: 'rate' or 'acceleration'
	SCALAR 'stimulation_min_value' = minimum stimulation value
    SCALAR 'stimulation_max_value' = maximum stimulation value
	SCALAR 'measurement_type' = type of measurement: 'CAN' or 'FR'
	SCALAR 'measurement_signal' = signal name for measurement
	SCALAR 'measurement_to_phys_factor' = factor to convert measured values to physical values
	SCALAR 'measurement_phys_offset_g' = (optional) offset in G to be added to measured physical values to compensate any earth gravity correction
	                                   either in internal sensor values or in bus values. Only for accelerations. Will be ignored for rates.
	SCALAR 'measurement_signal_range_threshold' = range threshold for measurement signal
	SCALAR 'measurement_signal_error_value' = (optional) error value for measurement signal if stimulation value >= measurement_quality_OK_threshold
	SCALAR 'measurement_quality_signal' = signal name for measurement quality
	SCALAR 'measurement_quality_in_range_value' = value of measurement quality signal that indicates: signal within range
	SCALAR 'measurement_quality_OK_threshold' = (optional) if given then this threshold will be used for the quality signal,
	                                            if not given then measurement_signal_range_threshold will be used for the quality signal.
	SCALAR 'offline_analysis' = (optional) flag to activate offline analysis
	SCALAR 'offline_data_file' = (optional) folder in which data are stored for offline analysis; has to be defined if parameter 'offline_analysis' = 1

=head2 PARAMETER EXAMPLES

    [TC_VDS_MeasurementRange.trial]
    purpose = 'trial'
    sensor_simulation_device = 'SMI705'
    sensor_simulation_channel = 'Acc_LG_Y'
    sensor_simulation_type = 'acceleration'
    stimulation_min_value = 4.5
    stimulation_max_value = 5.5
    measurement_type = 'CAN'
    measurement_signal = 'bla'
    measurement_to_phys_factor = 1
    measurement_phys_offset_g = -1
    measurement_signal_range_threshold = 5
    measurement_quality_signal = 'blo'
    measurement_quality_in_range_value = 1
    measurement_quality_OK_threshold = 5.1
    offline_analysis = 0
    offline_data_file = 'C:\temp'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_sensor_simulation_device;
my $tcpar_sensor_simulation_channel;
my $tcpar_sensor_simulation_type;
my $tcpar_measurement_type;
my $tcpar_measurement_signal;
my $tcpar_measurement_to_phys_factor;
my $tcpar_measurement_phys_offset_g;
my $tcpar_measurement_signal_range_threshold;
my $tcpar_measurement_signal_error_value;
my $tcpar_measurement_quality_signal;
my $tcpar_measurement_quality_in_range_value;
my $tcpar_offline_analysis;
my $tcpar_offline_data_file;
my $tcpar_stimulation_min_value;
my $tcpar_stimulation_max_value;
my $tcpar_measurement_quality_OK_threshold;

################ global parameter declaration ###################
#add any global variables here
my ( $tcNumber, $valueDelta, $valueStep, $valueUnit, $value2LSB, $valueCorrection, $traceFile, $stimulation_href, $stimulationCurvePhys_aref, $stimulationSteps_aref );
my $stimulationTime_ms = 980;
my $zeroTime_ms        = 20;
my $timeStep_ms        = 10;

my (@tcpar_FLTmand, @tcpar_FLTopt);
my $fltmem1;

###############################################################

sub TC_set_parameters {

    $tcpar_purpose                            = S_read_mandatory_testcase_parameter('purpose');
    $tcpar_sensor_simulation_device           = S_read_mandatory_testcase_parameter('sensor_simulation_device');
    $tcpar_sensor_simulation_channel          = S_read_mandatory_testcase_parameter('sensor_simulation_channel');
    $tcpar_sensor_simulation_type             = S_read_mandatory_testcase_parameter('sensor_simulation_type');
    $tcpar_measurement_type                   = S_read_mandatory_testcase_parameter('measurement_type');
    $tcpar_measurement_signal                 = S_read_mandatory_testcase_parameter('measurement_signal');
    $tcpar_measurement_to_phys_factor         = S_read_mandatory_testcase_parameter('measurement_to_phys_factor');
    $tcpar_measurement_phys_offset_g          = S_read_optional_testcase_parameter('measurement_phys_offset_g');
    $tcpar_measurement_signal_range_threshold = S_read_mandatory_testcase_parameter('measurement_signal_range_threshold');
    $tcpar_measurement_signal_error_value     = S_read_optional_testcase_parameter('measurement_signal_error_value');
    $tcpar_measurement_quality_signal         = S_read_mandatory_testcase_parameter('measurement_quality_signal');
    $tcpar_measurement_quality_in_range_value = S_read_mandatory_testcase_parameter('measurement_quality_in_range_value');
    $tcpar_offline_analysis                   = S_read_optional_testcase_parameter('offline_analysis');
    $tcpar_offline_data_file                  = S_read_optional_testcase_parameter('offline_data_file');
    $tcpar_stimulation_min_value              = S_read_mandatory_testcase_parameter('stimulation_min_value');
    $tcpar_stimulation_max_value              = S_read_mandatory_testcase_parameter('stimulation_max_value');
    $tcpar_measurement_quality_OK_threshold   = S_read_optional_testcase_parameter('measurement_quality_OK_threshold');

    if ( $tcpar_stimulation_min_value >= $tcpar_stimulation_max_value ) {
        S_set_error("Test case parameter 'stimulation_min_value' >= 'stimulation_max_value'.");
        return 0;
    }

    if ( $tcpar_measurement_signal_range_threshold < $tcpar_stimulation_min_value or $tcpar_measurement_signal_range_threshold > $tcpar_stimulation_max_value ) {
        S_set_error("Test case parameter 'measurement_signal_range_threshold' (=$tcpar_measurement_signal_range_threshold) must be between 'stimulation_min_value' (=$tcpar_stimulation_min_value) and 'stimulation_max_value' (=$tcpar_stimulation_max_value).");
        return 0;
    }

    if ( defined $tcpar_measurement_quality_OK_threshold and ( $tcpar_measurement_quality_OK_threshold < $tcpar_stimulation_min_value or $tcpar_measurement_quality_OK_threshold > $tcpar_stimulation_max_value ) ) {
        S_set_error("Test case parameter 'measurement_quality_OK_threshold' (=$tcpar_measurement_quality_OK_threshold) must be between 'stimulation_min_value' (=$tcpar_stimulation_min_value) and 'stimulation_max_value' (=$tcpar_stimulation_max_value).");
        return 0;
    }

    $tcpar_measurement_quality_OK_threshold = $tcpar_measurement_signal_range_threshold if not defined $tcpar_measurement_quality_OK_threshold;

    if ( $tcpar_sensor_simulation_type =~ /^rate/i ) {
        $valueDelta      = ( $tcpar_stimulation_max_value - $tcpar_stimulation_min_value ) / 2;
        $valueStep       = 1;
        $valueUnit       = 'deg/s';
        $value2LSB       = 100;
        $valueCorrection = 0;
        if ( defined $tcpar_measurement_phys_offset_g ) {
            S_set_warning("Given parameter 'measurement_phys_offset_g' will be ignored for rates. It is only applicable for accelerations.");
        }
    }
    elsif ( $tcpar_sensor_simulation_type =~ /^accel/i ) {
        $valueDelta      = ( $tcpar_stimulation_max_value - $tcpar_stimulation_min_value ) / 2;
        $valueStep       = 0.01;
        $valueUnit       = 'g';
        $value2LSB       = 5000;
        $valueCorrection = 0;
        if ( defined $tcpar_measurement_phys_offset_g ) {
            $valueCorrection = $tcpar_measurement_phys_offset_g;
        }
    }
    else {
        S_set_error("\$tcpar_sensor_simulation_type must be either 'rate' or 'accel', but it is $tcpar_sensor_simulation_type");
        return 0;
    }

    if ( $tcpar_measurement_type !~ /^(can|fr)$/i ) {
        S_set_error("\$tcpar_measurement_type must be either 'CAN' or 'FR', but it is $tcpar_sensor_simulation_type");
        return 0;
    }

    if ( $tcpar_offline_analysis and not -e $tcpar_offline_data_file ) {
        S_set_error("Test case parameter 'offline_analysis' is selected (= $tcpar_offline_analysis), but selected data folder in parameter 'offline_data_folder' (= $tcpar_offline_data_file) does not exist.");
        return 0;
    }
	@tcpar_FLTmand = GEN_Read_optional_testcase_parameter('FLTmand');
    @tcpar_FLTopt  = GEN_Read_optional_testcase_parameter('FLTopt');
	
    return 1;
}

sub TC_initialization {

    if ( not $tcpar_offline_analysis ) {
        S_teststep( "Prepare test equipment", 'AUTO_NBR' );
		CA_simulation_start();
		S_wait_ms(1000);
        LC_ECU_On();
        S_wait_ms('TIMER_ECU_READY');
        S_teststep( "Read fault memory before stimulation", 'AUTO_NBR' );
        PD_ReadFaultMemory();
		# CA_simulation_start();
		# S_wait_ms(1000);
		CA_trace_stop();
		CA_trace_store('C:\temp\dummy.asc'); # to make sure that a new trace will be started in TC_stimulation_and_measurement
    }

    return 1;
}

sub TC_stimulation_and_measurement {

    $tcNumber = S_get_TC_number();

    S_teststep( "Create stimulation curve for threshold value $tcpar_measurement_signal_range_threshold for sensor simulation. Stimulation range is [$tcpar_stimulation_min_value .. $tcpar_stimulation_max_value] ", 'AUTO_NBR' );
    ( $stimulationCurvePhys_aref, $stimulationSteps_aref ) = CreateStimulationCurve();
    my $duration_ms = @$stimulationCurvePhys_aref * $timeStep_ms;
    my @times = map { $_ * $timeStep_ms / 1000 } ( 1 .. @$stimulationCurvePhys_aref );
    CreateGraphFromHash( { 'data' => $stimulationCurvePhys_aref, 'x' => \@times, 'x-label' => 'time in s' }, $tcNumber . '_stimulation', 'amplitude', 1 );

    if ($tcpar_offline_analysis) {
        $traceFile = $tcpar_offline_data_file;
    }
    else {
        $traceFile = $main::REPORT_PATH . "/" . $tcNumber . "_CAN_trace.asc";
        S_teststep( "Load stimulation curve to sensor simulation", 'AUTO_NBR' );
        my @stimulationCurveDev = map { $_ * $value2LSB } @$stimulationCurvePhys_aref;
        QuaTe_DownloadData( $tcpar_sensor_simulation_device, $tcpar_sensor_simulation_channel, \@stimulationCurveDev, $timeStep_ms * 1000 );
        S_teststep( "Start bus trace", 'AUTO_NBR' );
        CA_trace_start();
        S_teststep( "Trigger stimulation curve", 'AUTO_NBR' );
        S_wait_ms(200);
        QuaTe_SendControllerTrigger(0);
        S_wait_ms($duration_ms);
        S_teststep( "Stop and store bus trace", 'AUTO_NBR' );
        CA_trace_store($traceFile);
        CA_trace_stop();
		CA_trace_start();
        S_teststep( "Read fault memory after stimulation", 'AUTO_NBR' );
        PD_ReadFaultMemory();
		$fltmem1 = PD_GetExtendedFaultInformation(BOSCH_FLT_MEM);
		S_teststep( 'Evaluate fault recorder', 'AUTO_NBR', 'Fault' );
		CA_trace_stop();
    }

    return 1;
}

sub TC_evaluation {
	if ( not $tcpar_offline_analysis )
	{

	S_teststep_expected( 'Expected faults:', 'Fault' );
    foreach my $fault (@tcpar_FLTmand) {
        S_teststep_expected($fault);
    }

    S_teststep_detected( 'Detected faults:', 'Fault' );
    foreach my $fault ( @{ $fltmem1->{fault_text} } ) {
        S_teststep_detected($fault);
    }
    PD_evaluate_faults( $fltmem1, \@tcpar_FLTmand, \@tcpar_FLTopt );
	}

    S_teststep( "Load bus trace and extract data for measurement_signal and measurement_quality_signal", 'AUTO_NBR' );
    my $measuredData_href;
    if ( $tcpar_measurement_type =~ /^can$/i ) {
        $measuredData_href = CA_trace_get_dataref( $traceFile, [ $tcpar_measurement_signal, $tcpar_measurement_quality_signal ] );
    }
    else {
        $measuredData_href = FR_trace_get_dataref( $traceFile, [ $tcpar_measurement_signal, $tcpar_measurement_quality_signal ] );
    }
    EVAL_createGraphFromMeasurement( $measuredData_href, $tcNumber . "_measured_bus_data", { 'y' => [ $tcpar_measurement_signal, $tcpar_measurement_quality_signal ] }, 'no_interpolation', 1 );
    EVAL_dataCalculationOverTime( $measuredData_href, 'physical_sensor_value', "#0 * $tcpar_measurement_to_phys_factor", [$tcpar_measurement_signal] );
    EVAL_createGraphFromMeasurement( $measuredData_href, $tcNumber . "_measured_physical_data", { 'y' => [ 'physical_sensor_value', $tcpar_measurement_quality_signal ] }, 'no_interpolation', 1 );

    S_teststep( "Determine mean measured values for every stimulation step", 'AUTO_NBR' );
    my ( $meanMeasuredValues_aref, $associatedQualityValues_aref ) = DetermineMeanMeasuredValues( $measuredData_href, 'physical_sensor_value', $tcpar_measurement_quality_signal, $stimulationSteps_aref );

    AdjustStimulationAndMeasuredValues( $stimulationSteps_aref, $meanMeasuredValues_aref, $associatedQualityValues_aref ) or return 0;

    CreateGraphFromHash( { 'measured_values' => $meanMeasuredValues_aref, 'stimulated_values' => $stimulationSteps_aref, 'quality_values' => $associatedQualityValues_aref }, $tcNumber . '_mean_measured_values', 'amplitude', 1 );

    S_teststep( "Evaluate mean measured values for every stimulation step", 'AUTO_NBR' );
    foreach my $valueIndex ( 0 .. @$meanMeasuredValues_aref - 1 ) {
        my $measuredValue   = $$meanMeasuredValues_aref[$valueIndex];
        my $stimulatedValue = $$stimulationSteps_aref[$valueIndex];
        my $expectedValue   = $stimulatedValue;
        my $tolerance       = $valueStep / 2;
        my $qualityValue    = $$associatedQualityValues_aref[$valueIndex];
        my $qualityOperator = '==';
        if ( abs($stimulatedValue) > abs($tcpar_measurement_signal_range_threshold) ) {
                $expectedValue = $tcpar_measurement_signal_range_threshold;
        }

        if ( abs($stimulatedValue) > abs($tcpar_measurement_quality_OK_threshold) ) {
            $qualityOperator = '!=';
            if ( defined $tcpar_measurement_signal_error_value ) {
                $expectedValue = $tcpar_measurement_signal_error_value;
            }
        }

        EVAL_evaluate_value( "measured_values at stimulated value $stimulatedValue", $measuredValue, '==', $expectedValue, $tolerance, 'absolute' );
        EVAL_evaluate_value( "quality_values at stimulated value $stimulatedValue", $qualityValue, $qualityOperator, $tcpar_measurement_quality_in_range_value );
    }

    return 1;
}

sub TC_finalization {
	if ( not $tcpar_offline_analysis )
	{
	S_teststep( "clear fault memory", 'AUTO_NBR' );
	PD_ManipulateFaultMemory(3, 'dequalify');
	S_wait_ms('TIMER_ECU_READY');
	PD_ClearFaultMemory();
	S_wait_ms('TIMER_ECU_READY');
	PD_ECUreset();
    S_wait_ms('TIMER_ECU_READY');
	CA_simulation_stop();
	}
    return 1;
}

#
# ($stimulationCurvePhys_aref, $stimulationSteps_aref) = CreateStimulationCurve();
#
# Create the stimulation curve for the sensor simulation device.
# The stimulated values are from $tcpar_measurement_signal_range_threshold - $valueDelta until $tcpar_measurement_signal_range_threshold + $valueDelta in steps of $valueStep
# for a duration of $stimulationTime_ms. In between always the values are set to 0 for $zeroTime_ms to avoid triggering of SW monitorings for the VDS signals.
#
# Return values:
# $stimulationCurvePhys_aref: stimulation curve in physical units
# $stimulationSteps_aref: list of the different stimulation steps
#
sub CreateStimulationCurve {
    my $numberOfValues = int( $stimulationTime_ms / $timeStep_ms + 0.5 );
    my $numberOfZeros  = int( $zeroTime_ms / $timeStep_ms + 0.5 );

    # set a sign factor to be able to handle also negative threshold values
    my $signFactor   = 1;
    my $lowestValue  = $tcpar_stimulation_min_value;
    my $highestValue = $tcpar_stimulation_max_value;
    if ( $tcpar_measurement_signal_range_threshold < 0 ) {
        $signFactor   = -1;
        $lowestValue  = -$tcpar_stimulation_max_value;
        $highestValue = -$tcpar_stimulation_min_value;
    }

    my ( @curvePoints, @stimulation_values );
    push( @curvePoints, 0 );
    for ( my $value = $lowestValue ; $value <= $highestValue ; $value += $valueStep ) {
        my @values = ( $value * $signFactor ) x $numberOfValues;
        push( @curvePoints, @values );
        my @zeros = (0) x $numberOfZeros;
        push( @curvePoints,        @zeros );
        push( @stimulation_values, $value * $signFactor );
    }

    return ( \@curvePoints, \@stimulation_values );

}

#
# CreateGraphFromHash($graphData_href, $graphTitle, $ylabel, $loglevel);
#
# Combines the commands S_create_graph and S_add_pic2html to create a graph in the test report and the corresponding plot files in the report folder.
#
# Return values:
# always 1
#
sub CreateGraphFromHash {
    my $graphData_href = shift;
    my $graphTitle     = shift;
    my $ylabel         = shift;
    my $loglevel       = shift;

    my $offline = $main::opt_offline;
    $main::opt_offline = 0;

    S_create_graph( $graphData_href, "$main::REPORT_PATH/$graphTitle.txt", $graphTitle, 'white', 'no_interpolation', $ylabel );
    S_add_pic2html( "$graphTitle.png", "", "$graphTitle.txt.unv", 'TYPE="text/unv"', $loglevel );

    $main::opt_offline = $offline;
    return 1;
}

#
# ($meanMeasuredValues_aref, $associatedQualityValues_aref) = DetermineMeanMeasuredValues($data_href, $valueSignal, $qualitySignal);
#
# Determines in $data_href the mean measured values for signal $valueSignal and the corresponding quality value (for signal $qualitySignal) for each stimulation step.
# In the measurement data the first edge is found (if ( abs( $currentValue - $initialValue ) > $firstEdgeThreshold )), 
# which is the start of stimulation of the first value
# From this point the measured values for all stimulated values are calculated as mean value over a period of $meanValuesDuration_s.
# Also the associated quality value is taken (only at one point in time).
#
# Return values:
# $meanMeasuredValues_aref: list with mean measured values for every stimulation step
# $associatedQualityValues_aref: list with associated quality values for every stimulation step
#
sub DetermineMeanMeasuredValues {
    my $data_href     = shift;
    my $valueSignal   = shift;
    my $qualitySignal = shift;
    my $stimulationSteps_aref = shift;

    my ( @meanMeasuredValues, @associatedQualityValues );

    my ( $signalValues_aref, $times_aref ) = EVAL_get_values_and_times_over_time( $data_href, $valueSignal );

    my @qualityValues = EVAL_get_values_over_time( $data_href, $qualitySignal );

    my $deltaTime_s = DetermineDeltaTime( $times_aref );

    my ($currentValue, $initialValue, $firstEdgeIndex);
    my $initialStimulationValue = $$stimulationSteps_aref[0];
    my $firstEdgeThresholdPercentage = 0.5;
    my $firstEdgeThreshold = abs($initialStimulationValue) * $firstEdgeThresholdPercentage;
    foreach my $valueIndex ( 0 .. @$signalValues_aref - 1 ) {

        $currentValue = $$signalValues_aref[$valueIndex];

        # determine the initial value
        if( not defined $initialValue ){
        	$initialValue = $currentValue;
        }
        
        # find first edge in the data
        if ( abs( $currentValue - $initialValue ) > $firstEdgeThreshold ) {
            $firstEdgeIndex = $valueIndex;
            S_w2log( 4, "DetermineMeanMeasuredValues: First edge detected at index $firstEdgeIndex and value $currentValue\n" );
            last;
        }
    }

    if ( $valueCorrection != 0 ) {
        S_teststep_2nd_level( "Applying value correction: measured values are corrected with " . $valueCorrection . "g", 'AUTO_NBR' );
    }

    my $meanValuesDuration_s   = 0.5;
    my $distanceFromEdge_s = 0.3;
    my $lengthOfOneStimulation = ($stimulationTime_ms + $zeroTime_ms)/ $deltaTime_s /1000;
    my $numberOfValuesForMean = int( $meanValuesDuration_s / $deltaTime_s + 0.5 );
    my $highestDataIndex = @$signalValues_aref-1;
    foreach my $stimulationIndex ( 0 .. @$stimulationSteps_aref-1 ) {
        my $startIndex = int( $firstEdgeIndex + $stimulationIndex * $lengthOfOneStimulation + $distanceFromEdge_s / $deltaTime_s + 0.5 );
        my $endIndex = $startIndex + $numberOfValuesForMean;

        if( $endIndex > $highestDataIndex ) {
            S_set_warning("No more data points available to calculate mean measured values. Evaluation might not be reliable.");
            last;
        }

        my $valueSum = 0;
        foreach my $meanValueIndex ( $startIndex .. $endIndex ) {
            $valueSum += $$signalValues_aref[$meanValueIndex];
        }
        my $meanValue = $valueSum / ( $numberOfValuesForMean + 1 );
        push( @meanMeasuredValues, $meanValue + $valueCorrection );
        S_w2log( 4, "DetermineMeanMeasuredValues: Mean value $meanValue determined from index $startIndex until index $endIndex.\n" );
        my $qualityValue = $qualityValues[$endIndex];
        push( @associatedQualityValues, $qualityValue );
        S_w2log( 4, "DetermineMeanMeasuredValues: Associated quality value is $qualityValue.\n" );
    }

    return ( \@meanMeasuredValues, \@associatedQualityValues );
}

#
# $deltaT_s = DetermineDeltaTime($times_aref, $numberOfValues);
#
# Determine from a time array $times_aref out of the first $numberOfValues values the time difference between 2 points in s.
#
# Return values:
# $deltaT_s: time difference between 2 points in s
#
sub DetermineDeltaTime {
    my $times_aref     = shift;

    # determine delta T from the first time values
    my $lastTime;
    my $deltaTimeSum       = 0;
    my $deltaTimeSquareSum = 0;
    my $deltaTCounter      = 0;
    foreach my $time ( @$times_aref ) {
        if ( defined $lastTime ) {
            my $deltaT = $time - $lastTime;
            $deltaTimeSum += $deltaT;
            $deltaTimeSquareSum += $deltaT * $deltaT;
            $deltaTCounter++;
        }
        $lastTime = $time;
    }

    # check if delta T calculation is good or if the standard deviation is too high
    my $deltaT_s = $deltaTimeSum / $deltaTCounter;
    my $standDev_ms = sqrt( ( $deltaTimeSquareSum - $deltaTimeSum * $deltaTimeSum / $deltaTCounter ) / ( $deltaTCounter - 1 ) );
    if ( $standDev_ms > 0.1 ) {
        S_set_warning("Standard deviation of the time differences is $standDev_ms ms. There seem to be time gaps in the data points. Data quality might not be sufficient");
        return (0.01);
    }
    S_w2log( 4, "DetermineDeltaTime: Delta T in data is $deltaT_s s.\n" );

    return $deltaT_s;
}

#
# $success = AdjustStimulationAndMeasuredValues( $stimulationSteps_aref, $meanMeasuredValues_aref, $associatedQualityValues_aref );
#
# Checks if number of elements of $stimulationSteps_aref matches $meanMeasuredValues_aref and $associatedQualityValues_aref
# and adjusts if possible.
#
# Return values:
# $success: 1 if so, 0 otherwise
#
sub AdjustStimulationAndMeasuredValues {
    my $stimulationSteps_aref        = shift;
    my $meanMeasuredValues_aref      = shift;
    my $associatedQualityValues_aref = shift;

    my $maxAcceptedMissingMeasurements = 50;

    my $valueNumberDifference = @$stimulationSteps_aref - @$meanMeasuredValues_aref;
    if ( $valueNumberDifference > 0 and $valueNumberDifference <= $maxAcceptedMissingMeasurements ) {
        S_set_warning("It was not possible to determine mean measured values for $valueNumberDifference stimulation steps. Removing $valueNumberDifference stimulation steps...");
        splice( @$stimulationSteps_aref, -$valueNumberDifference, $valueNumberDifference );
    }
    elsif ( $valueNumberDifference > $maxAcceptedMissingMeasurements ) {
        S_set_error("It was not possible to determine mean measured values for $valueNumberDifference stimulation steps. Data quality is not sufficient.");
        return 0;
    }
    elsif ( $valueNumberDifference < 0 ) {
        $valueNumberDifference = -$valueNumberDifference;
        S_set_warning("There are $valueNumberDifference more mean measured values than stimulation steps. Removing $valueNumberDifference mean measured values...");
        splice( @$meanMeasuredValues_aref,      -$valueNumberDifference, $valueNumberDifference );
        splice( @$associatedQualityValues_aref, -$valueNumberDifference, $valueNumberDifference );
    }
    else {
        # $valueNumberDifference == 0, all OK, nothing to do
    }

    # check if stimulated and measured data have a different sign
    my $firstStimulationValue = $$stimulationSteps_aref[0];
    my $firstMeasuredValue    = $$meanMeasuredValues_aref[0];
    if ( $firstStimulationValue * $firstMeasuredValue < 0 ) {

        # stimulated and measured data have a different sign -> change sign of stimulated values
        S_teststep_2nd_level( "Measured and stimulated values have different sign: Inverting stimulated values.", 'AUTO_NBR' );
        $tcpar_measurement_signal_range_threshold *= -1;
        foreach my $index ( 0 .. $#$stimulationSteps_aref ) {
            $$stimulationSteps_aref[$index] *= -1;
        }
    }

    return 1;
}

1;
