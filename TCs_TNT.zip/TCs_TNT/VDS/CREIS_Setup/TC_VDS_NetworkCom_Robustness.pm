#### TEST CASE MODULE
package TC_VDS_NetworkCom_Robustness;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER  = q$Header: VDS/CREIS_Setup/TC_VDS_NetworkCom_Robustness.pm 1.1 2017/09/07 20:04:40ICT Prosch Christian (CC-PS/EPS2) (PHC2SI) develop  $;

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_evaluation;
use LIFT_can_access;
use LIFT_flexray_access;

##################################

our $PURPOSE = "Test of Network COM Application - Robustness";

# DOCUMENTATION

=head1 TESTCASE MODULE

TC_VDS_FilterTest

=head1 PURPOSE

From HLD: 
The test case shall show that the average time between two bus messages is according to the specification (typ. 100 Hz --> cycle time 10 ms). 
Also the test case shall show that under any no-crash condition there is no loss of bus messages due to �C load. 

=head1 TESTCASE DESCRIPTION

This is a pure offline evaluation test case. 
Another (crash injection) test case must be executed before this test to record a network trace under rough road conditions.

I<B<Preconditions>>

A network trace under rough road conditions for the system under test must be available.
There must not be any measurement gaps or ECU resets in the trace.

I<B<Initialisation>>

    - nothing

I<B<Stimulation and Measurement>>

    - nothing

I<B<Evaluation>>

    - Load bus trace from trace_file_path and extract VDS_CAN_messages and VDS_FR_PDUs
    - Loop over each of VDS_CAN_messages and VDS_FR_PDUs
        - Calculate minimum and maximum cycle time of the message/PDU in the whole trace
        - Evaluate minimum and maximum cycle time against cycle_time_expected_ms and cycle_time_tolerance_ms 

I<B<Finalisation>>

    - nothing

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

    SCALAR 'purpose' = Purpose of the Testcase
    SCALAR 'trace_file_path' = path to network trace file
    LIST   'VDS_CAN_messages' = (optional) list of VDS messages on CAN to be evaluated.
    LIST   'VDS_FR_PDUs' = (optional) list of VDS PDUs on FR to be evaluated.
    SCALAR 'cycle_time_expected_ms' = expected cycle time value of all VDS messages/PDUs in ms
    SCALAR 'cycle_time_tolerance_ms' = tolerance for cycle time value of all VDS messages/PDUs in ms

    Note: At least one of the test case parameters 'VDS_CAN_messages' and 'VDS_FR_PDUs' must be defined.

=head2 PARAMETER EXAMPLES

    purpose = 'example'
    trace_file_path = 'C:\VDS_NetworkCom_Robustness\FR_example.asc'
    VDS_FR_PDUs = @('SRSBackBoneSignalIPdu04')
    cycle_time_expected_ms = 10
    cycle_time_tolerance_ms = 1

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_trace_file_path;
my $tcpar_VDS_CAN_messages_aref;
my $tcpar_VDS_FR_PDUs_aref;
my $tcpar_cycle_time_expected_ms;
my $tcpar_cycle_time_tolerance_ms;

################ global parameter declaration ###################
#add any global variables here


###############################################################

sub TC_set_parameters {

    $tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
    $tcpar_trace_file_path =  S_read_mandatory_testcase_parameter( 'trace_file_path' );
    $tcpar_VDS_CAN_messages_aref =  S_read_optional_testcase_parameter( 'VDS_CAN_messages' );
    $tcpar_VDS_FR_PDUs_aref =  S_read_optional_testcase_parameter( 'VDS_FR_PDUs' );
    $tcpar_cycle_time_expected_ms =  S_read_mandatory_testcase_parameter( 'cycle_time_expected_ms' );
    $tcpar_cycle_time_tolerance_ms =  S_read_mandatory_testcase_parameter( 'cycle_time_tolerance_ms' );

    if( not defined $tcpar_VDS_CAN_messages_aref and not defined $tcpar_VDS_FR_PDUs_aref ) {
        S_set_error("At least one of the test case parameters 'VDS_CAN_messages' and 'VDS_FR_PDUs' must be defined");
        return 0;
    }

    return 1;
}

sub TC_initialization {

    return 1;
}

sub TC_stimulation_and_measurement {

    return 1;
}

sub TC_evaluation {

    if ( defined $tcpar_VDS_CAN_messages_aref ) {
        S_teststep( "Extract VDS_CAN_messages from bus trace in trace_file_path $tcpar_trace_file_path", 'AUTO_NBR' );
        my $measureData_href = CA_trace_get_dataref( $tcpar_trace_file_path, $tcpar_VDS_CAN_messages_aref );
        Evaluate_one_bus_type($measureData_href, $tcpar_VDS_CAN_messages_aref, 'CAN');
    }

    if ( defined $tcpar_VDS_FR_PDUs_aref ) {
        S_teststep( "Extract VDS_FR_PDUs from bus trace in trace_file_path $tcpar_trace_file_path", 'AUTO_NBR' );
        my $measureData_href = FR_trace_get_dataref( $tcpar_trace_file_path, $tcpar_VDS_FR_PDUs_aref );
        Evaluate_one_bus_type($measureData_href, $tcpar_VDS_FR_PDUs_aref, 'FR');
    }
  
    return 1;
}

sub TC_finalization {

    return 1;
}

sub Evaluate_one_bus_type{
    my $measureData_href = shift;
    my $evaluationItems_aref = shift;
    my $itemType = shift;

    S_teststep( "Loop over each of the $itemType messages/PDUs", 'AUTO_NBR' );
    foreach my $item ( @$evaluationItems_aref ) {
        S_teststep_2nd_level( "Create cycle time histogram for $item for the whole trace", 'AUTO_NBR' );
        my ($values_aref, $times_s_aref) = EVAL_get_values_and_times_over_time ( $measureData_href , $item );
        my $traceDuration_s = $$times_s_aref[-1] - $$times_s_aref[0];
        S_w2rep("Trace duration for $item is $traceDuration_s s.");
        my ($lastTime, @timeDiffs_ms);
        foreach my $time ( @$times_s_aref ) {
            push( @timeDiffs_ms, ($time - $lastTime)*1000 ) if defined $lastTime;
            $lastTime = $time;
        }
        my $tcNumber = S_get_TC_number();
        S_create_histogram( \@timeDiffs_ms, $tcNumber."_cycle_time_histogram_$item", {'title' => "Cycle time histogram for $item", 'xAxisLabel' => 'cycle time in ms', 'numberOfChannels' => 60, 'loglevel' => 1, 'ylogarithmic' => 'yes'} );

        S_teststep_2nd_level( "Calculate minimum and maximum cycle time for $item in the whole trace", 'AUTO_NBR' );
        my ($cycletime_min_ms,$cycletime_max_ms)=(1e99,-1e99);
        map {$cycletime_max_ms=$_ if ($_>$cycletime_max_ms); $cycletime_min_ms=$_ if($_<$cycletime_min_ms);} @timeDiffs_ms;
        S_teststep_2nd_level( "Evaluate minimum cycle time in ms for $item", 'AUTO_NBR' );
        EVAL_evaluate_value ( "Min cycle time in ms for $item", $cycletime_min_ms, '>', $tcpar_cycle_time_expected_ms - $tcpar_cycle_time_tolerance_ms );
        S_teststep_2nd_level( "Evaluate maximum cycle time in ms for $item", 'AUTO_NBR' );
        EVAL_evaluate_value ( "Max cycle time in ms for $item", $cycletime_max_ms, '<', $tcpar_cycle_time_expected_ms + $tcpar_cycle_time_tolerance_ms );
    }
}

1;
