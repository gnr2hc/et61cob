#### TEST CASE MODULE
package TC_VDS_FilterTest;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.3 $;
our $HEADER = q$Header: VDS/CREIS_Setup/TC_VDS_FilterTest.pm 1.3 2018/05/07 23:28:41ICT Prosch Christian (CC-PS/EPS2) (PHC2SI) develop  $;

#### INCLUDE ENGINE MODULES ####

use FuncLib_TNT_GEN;  
use LIFT_general;
use LIFT_PD;
use LIFT_QuaTe;
use LIFT_can_access;
use LIFT_flexray_access;
use LIFT_evaluation;
use LIFT_TSG4;
use Readonly;

##################################

our $PURPOSE = "Test of SMI7xy filter charecteristics";

# DOCUMENTATION 

=head1 TESTCASE MODULE

TC_VDS_FilterTest

=head1 PURPOSE

	Test of SMI7xy filter charecteristics

=head1 TESTCASE DESCRIPTION


IBPreconditions

This test can be performed only if a TSG4 is used. Connect the Quate trigger line to TSG4.

Configure sensor simulation device with all sensors that are defined for the project (use existing crash injection config).

Quate trigger must be configured to 'NEG_SLOPE' (default) because the test case sets TSG4 in such a way 
that it is converting the trigger pulse into a CAN message with associated timestamp = falling edge of the trigger pulse.
    
In the project specific CAN mapping one additional message 'EventTrigger' must be added. This is the message with the timestamp information
of the QuaTe trigger:
       'EventTrigger'  =>
                      {
                        'ID'            => 0x7,
                        'CAN_BUS_NBR'   => 2,
                        'DLC'           => 8,
						'SENDER'		=> 'TSG4',
                      },


IBInitialisation

    switch TSG4 event trigger timing to falling edge because the Quate trigger signal is by default a negative pulse

IBStimulation and Measurement

    create list of frequency values to be tested (@testFrequencies)
    loop over all frequencies of @testFrequencies
        start measurement of PD, CAN or flexray depending on $tcpar_measurement_type
        create a sine curve with the given frequency and an amplitude depending on $tcpar_sensor_simulation_type
        stimulate the created curve for the sensor defined in $tcpar_sensor_simulation_device and $tcpar_sensor_simulation_channel
        stop and store measurement
        determine the data age from trigger time and the calculated zero positions of the measured data (only for CAN measurement)
        plot measured curve
        determine the amplitude of the measured curve by measuring the min and max values
    end loop
    plot amplitude (in dB) vs frequency
    plot data age (in ms) vs frequency

    If parameter 'offline_analysis' is set to 1 then no test bench devices (QuaTe, PD, CANoe) are accessed, 
    but data are taken from CAN traces or PD fast diagnosis traces which are located in 'offline_data_folder' from a previous test run.
    This gives the possibility to do an offline re-evaluation of a test run.
    

IBEvaluation

    evaluate the following quantities from amplitude data against expected values in test case parameters:
    - passband_upper_frequency_Hz
    - filter_lower_frequency_Hz
    - filter_upper_frequency_Hz
    - stopband_lower_frequency_Hz
    - stopband_factor_db
    evaluate max_data_age_ms against expected value in test case parameter from data age data

IBFinalisation

    nothing

=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' = Purpose of the Testcase
	SCALAR 'sensor_simulation_device' = sensor simulation device name
	SCALAR 'sensor_simulation_channel' = sensor simulation channel name
	SCALAR 'sensor_simulation_type' = sensor simulation type: 'rate' or 'acceleration'
	SCALAR 'measurement_type' = type of measurement: 'PD' or 'CAN' or 'FR'
	SCALAR 'measurement_signal' = signal name for measurement
	SCALAR 'measurement_to_phys_factor' = factor to convert measured values to physical values
	SCALAR 'passband_upper_frequency_Hz' = upper limit of passband frequency in Hz
	SCALAR 'filter_lower_frequency_Hz' = lower limit of filter frequency in Hz
	SCALAR 'filter_upper_frequency_Hz' = upper limit of filter frequency in Hz
	SCALAR 'stopband_lower_frequency_Hz' = lower limit of stopband frequency in Hz
	SCALAR 'passband_tolerance_dB' = tolerance (ripple) of the passband in dB
	SCALAR 'stopband_factor_db' = amplitude reduction factor for the stopbad in dB
	SCALAR 'max_data_age_ms' = maximum allowed data age in ms
	SCALAR 'quick_check' = flag for doing only a quick check with only one frequency and no/minimal evaluation
	SCALAR 'offline_analysis' = (optional) flag to activate offline analysis
	SCALAR 'offline_data_folder' = (optional) folder in which data are stored for offline analysis; has to be defined if parameter 'offline_analysis' = 1

=head2 PARAMETER EXAMPLES

    [TC_VDS_FilterTest.Ford_wz_CAN]
    purpose	= 'VDS filter test for Ford wz on CAN'
    sensor_simulation_device = 'SMI705'
    sensor_simulation_channel = 'Ang_Rate_-Z'
    sensor_simulation_type = 'rate'
    measurement_type = 'CAN'
    measurement_signal = 'VehYaw_W_Actl'
    measurement_to_phys_factor = 57.29578
    passband_upper_frequency_Hz = 5
    filter_lower_frequency_Hz = 11
    filter_upper_frequency_Hz = 15
    stopband_lower_frequency_Hz = 50
    passband_tolerance_dB = 0.2
    stopband_factor_db = -40
    max_data_age_ms = 35
    quick_check = 0
    offline_analysis = 1
    offline_data_folder = 'C:\TurboLIFT\VDS_FilterTest_01'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_sensor_simulation_device;
my $tcpar_sensor_simulation_channel;
my $tcpar_sensor_simulation_type;
my $tcpar_measurement_type;
my $tcpar_measurement_signal;
my $tcpar_measurement_to_phys_factor;
my $tcpar_passband_upper_frequency_Hz;
my $tcpar_filter_lower_frequency_Hz;
my $tcpar_filter_upper_frequency_Hz;
my $tcpar_stopband_lower_frequency_Hz;
my $tcpar_passband_tolerance_dB;
my $tcpar_stopband_factor_db;
my $tcpar_max_data_age_ms;
my $tcpar_quick_check;
my $tcpar_offline_analysis;
my $tcpar_offline_data_folder;

################ global parameter declaration ###################
#add any global variables here

Readonly my $PI => 4 * atan2(1, 1);

my (@testFrequencies, $testAmplitude, $unit, $amp2LSB, $bus2phys, $traceName, $dB, @measuredAmplitudes_dB, @dataAges_rough_ms, @dataAges_zeros_ms);

my $stepWidth_ms = 0.1;
my $numberOfPeriods;
my $sensorMaxDelay_ms = 10.2;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_sensor_simulation_device =  GEN_Read_mandatory_testcase_parameter( 'sensor_simulation_device' );
	$tcpar_sensor_simulation_channel =  GEN_Read_mandatory_testcase_parameter( 'sensor_simulation_channel' );
	$tcpar_sensor_simulation_type =  GEN_Read_mandatory_testcase_parameter( 'sensor_simulation_type' );
	$tcpar_measurement_type =  GEN_Read_mandatory_testcase_parameter( 'measurement_type' );
	$tcpar_measurement_signal =  GEN_Read_mandatory_testcase_parameter( 'measurement_signal' );
	$tcpar_measurement_to_phys_factor =  GEN_Read_mandatory_testcase_parameter( 'measurement_to_phys_factor' );
	$tcpar_passband_upper_frequency_Hz =  GEN_Read_mandatory_testcase_parameter( 'passband_upper_frequency_Hz' );
	$tcpar_filter_lower_frequency_Hz =  GEN_Read_mandatory_testcase_parameter( 'filter_lower_frequency_Hz' );
	$tcpar_filter_upper_frequency_Hz =  GEN_Read_mandatory_testcase_parameter( 'filter_upper_frequency_Hz' );
	$tcpar_stopband_lower_frequency_Hz =  GEN_Read_mandatory_testcase_parameter( 'stopband_lower_frequency_Hz' );
	$tcpar_passband_tolerance_dB =  GEN_Read_mandatory_testcase_parameter( 'passband_tolerance_dB' );
	$tcpar_stopband_factor_db =  GEN_Read_mandatory_testcase_parameter( 'stopband_factor_db' );
	$tcpar_max_data_age_ms =  GEN_Read_mandatory_testcase_parameter( 'max_data_age_ms' );
	$tcpar_quick_check =  GEN_Read_mandatory_testcase_parameter( 'quick_check' );
	$tcpar_offline_analysis =  GEN_Read_optional_testcase_parameter( 'offline_analysis' );
	$tcpar_offline_data_folder =  GEN_Read_optional_testcase_parameter( 'offline_data_folder' );

    if( $tcpar_measurement_type !~ /^(pd|can|fr)$/i ) {
        S_set_error("Parameter 'measurement_type' must be 'PD' or 'CAN' or 'FR'");
        return 0;
    }

    if( $tcpar_sensor_simulation_type =~ /^rate/i ) {
        $testAmplitude = 90;
        $unit = 'deg/s';
        $amp2LSB = 100;
    }
    elsif( $tcpar_sensor_simulation_type =~ /^accel/i ) {
        $testAmplitude = 1;
        $unit = 'G';
        $amp2LSB = 5000;
    }
    else{
        S_set_error("\$tcpar_sensor_simulation_type must be either 'rate' or 'accel', but it is $tcpar_sensor_simulation_type");
        return 0;        
    }
    
    if( $tcpar_offline_analysis and not -d $tcpar_offline_data_folder ) {
        S_set_error("Parameter 'offline_analysis' is selected (= $tcpar_offline_analysis), but selected data folder in parameter 'offline_data_folder' (= $tcpar_offline_data_folder) does not exist.");
        return 0;        
    }

	return 1;
}

sub TC_initialization {
    
    # switch PD to AB12 mode, but do nothing else for offline analysis
    if( $tcpar_offline_analysis ){
        LIFT_PD::SetVariablesForUnitTest(1, 12, 0);
        return 1;
    }

    # switch TSG4 event trigger timing to falling edge because the Quate trigger signal is by default a negative pulse
    my $status = TSG4_lowlevel_command( "rc_configure_event_trigger(1,'FALLING')" );

    # if above command does not work TSG4 might not be connected properly -> exit test
    return 0 if $status < 0;

	return 1;
}

sub TC_stimulation_and_measurement {
    
    # determine sampling frequency of current measurement
    my $samplingFrequency_Hz;
    if( $tcpar_measurement_type =~ /^can$/i ) {
        $samplingFrequency_Hz = 100; # now hard coded, to be determined from CAN mapping: 1000 / cycle time [ms]
    }
    elsif( $tcpar_measurement_type =~ /^fr$/i ) {
        $samplingFrequency_Hz = 100; # now hard coded, to be determined from FR mapping: 1000 / cycle time [ms]
    }
    elsif( $tcpar_measurement_type =~ /^pd$/i ){
        $samplingFrequency_Hz = 1000; # fast diagnosis with 1 signal and 1 CAN ID has a sampling frequency of 1000 Hz
    }
    
	my $tcNumber = S_get_TC_number ( ); 
    S_teststep("create list of frequency values to be tested", 'AUTO_NBR');
    @testFrequencies = (1 .. $tcpar_stopband_lower_frequency_Hz); # lower frequencies until stopband lower frequency in steps of 1 Hz
    @testFrequencies = map { $_ + 0.5 } @testFrequencies; # shift frequencies by 0.5Hz to avoid systematic effects with frquencies which are multiples of 10
    my @highFrequencies = map { $tcpar_stopband_lower_frequency_Hz + 10 * $_ + 1 } 1 .. $tcpar_stopband_lower_frequency_Hz/10; # higher frequencies until 2*stopband lower frequency +1 in steps of 10Hz
    push(@testFrequencies, @highFrequencies ); # add high frequencies to test frequencies
    @testFrequencies = grep { $_ <= $samplingFrequency_Hz/2 } @testFrequencies; # limit the test frequencies to half of the sampling frequency (depends on $tcpar_measurement_type)
    @testFrequencies = (1, $tcpar_passband_upper_frequency_Hz, $tcpar_filter_lower_frequency_Hz, $tcpar_filter_upper_frequency_Hz, $tcpar_stopband_lower_frequency_Hz, 2*$tcpar_stopband_lower_frequency_Hz) if $tcpar_quick_check;

    my $cleanSignalName = $tcpar_measurement_signal;
    $cleanSignalName =~ s/\./_/g;

    S_teststep("loop over all test frequencies:  @testFrequencies", 'AUTO_NBR');
    foreach my $testFrequency_Hz ( @testFrequencies ){
        S_teststep("Frequency $testFrequency_Hz Hz", 'AUTO_NBR');
        $numberOfPeriods = 2*$testFrequency_Hz;

        my $dataFolder;
        if( $tcpar_offline_analysis ){
            $dataFolder = $tcpar_offline_data_folder;
        }
        else{
            $dataFolder = $main::REPORT_PATH;
        }

        my $useZeros = 0;
        if( $tcpar_measurement_type =~ /^can$/i ) {
            $traceName = $dataFolder."/CAN_".$tcpar_measurement_signal."_".$testFrequency_Hz.".asc";
            $useZeros = 1 if $testFrequency_Hz <= $samplingFrequency_Hz/3;
        }
        elsif( $tcpar_measurement_type =~ /^fr$/i ) {
            $traceName = $dataFolder."/FR_".$tcpar_measurement_signal."_".$testFrequency_Hz.".asc";
            $useZeros = 1 if $testFrequency_Hz <= $samplingFrequency_Hz/3;
        }
        elsif( $tcpar_measurement_type =~ /^pd$/i ){
            $traceName = $dataFolder."/FD_".$cleanSignalName."_".$testFrequency_Hz.".txt";
        }

        if( not $tcpar_offline_analysis ){
            S_teststep_2nd_level("create input sine curve with frequency $testFrequency_Hz Hz and amplitude $testAmplitude $unit", 'AUTO_NBR');
            my $sine_aref = CreateSineCurve($testAmplitude*$amp2LSB, 0, $testFrequency_Hz, $stepWidth_ms, $numberOfPeriods);
            my $duration_ms = $numberOfPeriods/$testFrequency_Hz*1000;
            
            S_teststep_2nd_level("download the curve for the sensor '$tcpar_sensor_simulation_channel' in device '$tcpar_sensor_simulation_device'", 'AUTO_NBR');
            QuaTe_DownloadData($tcpar_sensor_simulation_device, $tcpar_sensor_simulation_channel, $sine_aref, $stepWidth_ms*1000);
    
            S_teststep_2nd_level("start $tcpar_measurement_type measurement of signal $tcpar_measurement_signal", 'AUTO_NBR');
            if( $tcpar_measurement_type =~ /^(can|fr)$/i ) {
                CA_trace_start ( );
            }
            elsif( $tcpar_measurement_type =~ /^pd$/i ) {
                PD_StartFastDiagName( $traceName , [$tcpar_measurement_signal] , ['S16']);
            }
                      
            S_wait_ms(200);
            S_teststep_2nd_level("Trigger sensor simulation", 'AUTO_NBR');
            QuaTe_SendControllerTrigger( 0 );
            S_wait_ms($duration_ms);
    
            S_teststep_2nd_level("stop and store $tcpar_measurement_type measurement", 'AUTO_NBR');
            if( $tcpar_measurement_type =~ /^(can|fr)$/i ) {
                CA_trace_store ( $traceName );
    			CA_trace_stop();
    			
            }
            elsif( $tcpar_measurement_type =~ /^pd$/i ) {
                PD_StopFastDiag();
            }
        }
        
        S_teststep_2nd_level("get data from $tcpar_measurement_type measurement", 'AUTO_NBR');
        my $measuredData_href;
        if( $tcpar_measurement_type =~ /^can$/i ) {
            $measuredData_href = CA_trace_get_dataref($traceName,[$tcpar_measurement_signal, 'EventTrigger']);
        }
        elsif( $tcpar_measurement_type =~ /^fr$/i ) {
            $measuredData_href = FR_trace_get_dataref($traceName,[$tcpar_measurement_signal]);
            my $measuredCANData_href = CA_trace_get_dataref($traceName,[ 'EventTrigger']);
            @{$measuredData_href}{keys %{ $measuredCANData_href } } = values %{ $measuredCANData_href };
        }
        elsif( $tcpar_measurement_type =~ /^pd$/i ) {
            $measuredData_href = PD_get_FDtrace( $traceName);
            DataMs2s($measuredData_href);
        }

        if( $tcpar_measurement_type =~ /^(can|fr)$/i ) {
			# determine data age
			my ($age_rough_ms, $age_zeros_ms) = DetermineDataAge($measuredData_href, $tcpar_measurement_signal, $testFrequency_Hz, $useZeros, 2);
			S_teststep_2nd_level("Measurement: Frequency $testFrequency_Hz Hz    Data age: (detailed) $age_zeros_ms ms (rough) $age_rough_ms ms", 'AUTO_NBR');
			push(@dataAges_rough_ms, $age_rough_ms);
			push(@dataAges_zeros_ms, $age_zeros_ms);
        }
        
        S_teststep_2nd_level("determine amplitude of the measured curve", 'AUTO_NBR');
        EVAL_createGraphFromMeasurement( $measuredData_href, $tcNumber."_data_".$cleanSignalName."_".$testFrequency_Hz, {'y'=>[$tcpar_measurement_signal]}, 'no_interpolation', 1 );
        my $measuredAmplitude = DetermineMinMaxAmplitude($measuredData_href, $tcpar_measurement_signal, $testFrequency_Hz, $testAmplitude, $tcpar_measurement_to_phys_factor, $numberOfPeriods/3, 1.8*$numberOfPeriods/3);
        $dB = Factor2dB($measuredAmplitude/$testAmplitude);
        S_teststep_2nd_level("Measurement: Frequency $testFrequency_Hz Hz    Amplitude $dB dB", 'AUTO_NBR');

        # add amplitude to measured amplitudes list
        push(@measuredAmplitudes_dB, $dB);        
    }

    S_teststep("Plot Amplitude vs Frequency", 'AUTO_NBR');
    my  $dB_href={
       'x' => \@testFrequencies,
       'x-label' => 'Frequency in Hz',
       'Amplitude_in_dB'=> \@measuredAmplitudes_dB,
    };
    S_create_graph($dB_href, $main::REPORT_PATH."/".$tcNumber."Amplitude_".$cleanSignalName, 'Amplitude in dB over Frequency in Hz', 'white', 'interpolate');
    S_add_pic2html ( "./".$tcNumber."Amplitude_".$cleanSignalName.".png" , 'width=600', "./".$tcNumber."Amplitude_".$cleanSignalName.".txt.unv",'TYPE="text/unv"', 1 );

    if( $tcpar_measurement_type =~ /^(can|fr)$/i ) {
        S_teststep("Plot detailed Data age vs Frequency", 'AUTO_NBR');
        my  $age_href={
           'x' => \@testFrequencies,
           'x-label' => 'Frequency in Hz',
           'Data_age_in_ms'=> \@dataAges_zeros_ms,
        };
        S_create_graph($age_href, $main::REPORT_PATH."/".$tcNumber."ZerosDataAge_".$cleanSignalName, 'Data age in ms over Frequency in Hz', 'white', 'interpolate');
        S_add_pic2html ( "./".$tcNumber."ZerosDataAge_".$cleanSignalName.".png" , 'width=600', "./".$tcNumber."ZerosDataAge_".$cleanSignalName.".txt.unv",'TYPE="text/unv"', 1 );

        S_teststep("Plot rough Data age vs Frequency", 'AUTO_NBR');
        my  $age_href={
           'x' => \@testFrequencies,
           'x-label' => 'Frequency in Hz',
           'Data_age_in_ms'=> \@dataAges_rough_ms,
        };
        S_create_graph($age_href, $main::REPORT_PATH."/".$tcNumber."RoughDataAge_".$cleanSignalName, 'Data age in ms over Frequency in Hz', 'white', 'interpolate');
        S_add_pic2html ( "./".$tcNumber."RoughDataAge_".$cleanSignalName.".png" , 'width=600', "./".$tcNumber."RoughDataAge_".$cleanSignalName.".txt.unv",'TYPE="text/unv"', 1 );
    }

	return 1;
}

sub TC_evaluation {
    my $filterAmplitude_dB = -3;

    my $measured_passband_upper_frequency_Hz;
    my $measured_filter_frequency_Hz;
    my $measured_stopband_lower_frequency_Hz;
    my $lastFrequency = 0;
    my $lastAmplitude = 0;
	my $maxAmplitudeStopBand = -1e99;
    foreach my $index ( 0 .. @measuredAmplitudes_dB-1 ) {
        my $frequency = $testFrequencies[$index];
        my $amplitude = $measuredAmplitudes_dB[$index];

        # look for first point outside of pass band
        if( not defined $measured_passband_upper_frequency_Hz ) {
            $measured_passband_upper_frequency_Hz = $lastFrequency if abs($amplitude) > $tcpar_passband_tolerance_dB;
        }

        # determine frequency where amplitude = $filterAmplitude_dB (filter frequency)
        if( not defined $measured_filter_frequency_Hz ) {
            if( $amplitude <= $filterAmplitude_dB ){
    			my $deltaF = $frequency - $lastFrequency;
    			my $deltaA = $amplitude - $lastAmplitude;
				my $amplitudePart = $filterAmplitude_dB - $lastAmplitude;
				$measured_filter_frequency_Hz = $lastFrequency + $amplitudePart*$deltaF/$deltaA;
            }
            
        }
        
        # look for first point in stop band
        if( not defined $measured_stopband_lower_frequency_Hz ) {
            $measured_stopband_lower_frequency_Hz = $frequency if $amplitude <= $tcpar_stopband_factor_db;
        }

        # check max amplitude in stop band
        if( $frequency >= $tcpar_stopband_lower_frequency_Hz ){
        	$maxAmplitudeStopBand = $amplitude if $amplitude > $maxAmplitudeStopBand;
        }

        $lastFrequency = $frequency;
        $lastAmplitude = $amplitude;
    }

    my $item = 'passband upper frequency';
    if( defined $measured_passband_upper_frequency_Hz ) {
        S_teststep("Measure $item : frequency where amplitude is still within 0 +- $tcpar_passband_tolerance_dB dB", 'AUTO_NBR', $item);
        S_teststep_expected("$item >= $tcpar_passband_upper_frequency_Hz Hz", $item);
        S_teststep_detected("$item = $measured_passband_upper_frequency_Hz Hz", $item);
        EVAL_evaluate_value ( $item , $measured_passband_upper_frequency_Hz, '>=' , $tcpar_passband_upper_frequency_Hz );
    }
    else{
        S_set_warning("Could not evaluate $item. Make sure that $item is evaluated in another test case.");
    }

    $item = 'filter frequency'; 
    if( defined $measured_filter_frequency_Hz ) {
        S_teststep("Measure $item : frequency where amplitude is $filterAmplitude_dB dB", 'AUTO_NBR', $item);
        S_teststep_expected("$tcpar_filter_lower_frequency_Hz <= $item <= $tcpar_filter_upper_frequency_Hz Hz", $item);
        S_teststep_detected("$item = $measured_filter_frequency_Hz Hz", $item);
        EVAL_evaluate_value ( $item , $measured_filter_frequency_Hz, '>=' , $tcpar_filter_lower_frequency_Hz );
        EVAL_evaluate_value ( $item , $measured_filter_frequency_Hz, '<=' , $tcpar_filter_upper_frequency_Hz );
    }
    else{
        S_set_warning("Could not evaluate $item. Make sure that $item is evaluated in another test case.");
    }

    $item = 'stopband lower frequency';
    if( defined $measured_stopband_lower_frequency_Hz ) {
        S_teststep("Measure $item : frequency where amplitude is <= $tcpar_stopband_factor_db dB", 'AUTO_NBR', $item);
        S_teststep_expected("$item <= $tcpar_stopband_lower_frequency_Hz Hz", $item);
        S_teststep_detected("$item = $measured_stopband_lower_frequency_Hz Hz", $item);
        EVAL_evaluate_value ( $item , $measured_stopband_lower_frequency_Hz, '<=' , $tcpar_stopband_lower_frequency_Hz );
    }
    else{
        S_set_warning("Could not evaluate $item. Make sure that $item is evaluated in another test case.");
    }

    $item = 'stopband maximum amplitude';
    if( defined $measured_stopband_lower_frequency_Hz ) {
        S_teststep("Measure $item : maximum amplitude with frequency >= $tcpar_stopband_lower_frequency_Hz Hz", 'AUTO_NBR', $item);
        S_teststep_expected("$item <= $tcpar_stopband_factor_db dB", $item);
        S_teststep_detected("$item = $maxAmplitudeStopBand dB", $item);
        EVAL_evaluate_value ( $item , $maxAmplitudeStopBand, '<=' , $tcpar_stopband_factor_db );
    }
    else{
        S_set_warning("Could not evaluate $item. Make sure that $item is evaluated in another test case.");
    }

    if( $tcpar_measurement_type =~ /^(can|fr)$/i ) {
		# check data ages
		my $maxAge_rough = (sort { $b <=> $a } @dataAges_rough_ms)[0];
		my $maxAge_zeros = (sort { $b <=> $a } @dataAges_zeros_ms)[0];
		my $maxAge = $maxAge_zeros;
		$maxAge = $maxAge_rough if $maxAge_rough > $maxAge_zeros;
		S_w2rep("Maximum measured data age (from SPI to CAN) is $maxAge ms. For evaluation the maximum sensor delay of $sensorMaxDelay_ms ms is added.");
        $maxAge += $sensorMaxDelay_ms;
	    my $item = 'maximum data age';
	    S_teststep("Measure $item", 'AUTO_NBR', $item);
	    S_teststep_expected("$item <= $tcpar_max_data_age_ms ms", $item);
	    S_teststep_detected("$item = $maxAge ms", $item);
	    EVAL_evaluate_value ( $item , $maxAge, '<=' , $tcpar_max_data_age_ms );
    }
    
	return 1;
}

sub TC_finalization {

	return 1;
}

#
# Convert from dB to amplitude factor
#
sub DB2factor{
    my $dB = shift;
    
    my $amplitudeFactor = 10 ** ($dB/20);
    
    return $amplitudeFactor;
}

#
# Convert from amplitude factor to dB
#
sub Factor2dB{
    my $amplitudeFactor = shift;
    
    if( $amplitudeFactor < 0 ){
        S_set_error("\$amplitudeFactor (= $amplitudeFactor) must be > 0");
        return;
    }
    elsif( $amplitudeFactor == 0 ){
    	my $zerodB = -60;
        S_set_warning("Output amplitude = 0; setting dB = $zerodB");
        return $zerodB;
    }
    
    my $dB =  log($amplitudeFactor)/log(10)*20;
    
    return $dB;
}

#
# Create a sine curve with given amplitude, offset, frequency, step width and number of periods
#
sub CreateSineCurve{
    my $amplitude = shift;
    my $offset = shift;
    my $frequency_Hz = shift;
    my $stepWidth_ms = shift;
    my $numberOfPeriods = shift;
    
    my $mumberOfPoints = int( $numberOfPeriods / $frequency_Hz / $stepWidth_ms *1000 +1.5);
    
    my @curvePoints;
    foreach my $index ( 0 .. $mumberOfPoints-1 ){
        my $x = $index * $stepWidth_ms / 1000 *2 * $PI;
        my $y = $amplitude * sin($frequency_Hz * ($x + $offset) );
        push(@curvePoints, $y);
    }
    
    return \@curvePoints;
}

#
# Gets a curve (array of values) and multiplies every value with a given amplitude factor and adds a random value (up to +-noise factor) 
#
sub DisturbCurve{
    my $curve_aref = shift;
    my $amplitudeFactor = shift;
    my $noiseFactor = shift;
    
    my @valuesDisturbed;
    foreach my $value ( @{$curve_aref} ){
        my $newValue = $amplitudeFactor * $value + (rand(2) - 1)*$noiseFactor;
        push(@valuesDisturbed, $newValue);
    }

    return \@valuesDisturbed;
}

#
# Determine the amplitude from the measured sensor values of a given sine input curve
#
sub DetermineMinMaxAmplitude{
    my $data_href = shift; # time base of CAN data is in seconds, time base of PD is in ms
    my $signalName = shift;
    my $frequency_Hz = shift;
    my $inputAmplitude = shift;
    my $measurement2physFactor = shift;
    my $skipPeriods = shift;
    my $evaluatePeriods = shift;

    my $expectedAmplitude = $inputAmplitude/$measurement2physFactor;

	my ($jumpTime, $initialValue);
	my $ignoreCounter = 0;
	my $ignoreValues = 2; 
    foreach my $time ( sort {$a <=> $b} keys %{ $data_href } ) {
        my $value = $data_href->{$time}{$signalName};
        next if not defined $value;
        
        # ignore the first n values, because unexpected jumps can happen
        $ignoreCounter++;
        next if $ignoreCounter <= $ignoreValues;

        # determine the initial value
        if( not defined $initialValue ){
        	$initialValue = $value;
        }
        
		# determine the initial data jump time
		if( not defined $jumpTime ){
			next if $value == $initialValue;
			$jumpTime = $time;
			last;
		}

    }

    my $startTime = $jumpTime + $skipPeriods / $frequency_Hz;
    
    # calculate duration
    my $duration_s = $evaluatePeriods / $frequency_Hz;

    # find min and max values
    my $minValue = 1E99;
    my $maxValue = -1E99;
    foreach my $time ( sort {$a <=> $b} keys %{ $data_href } ) {
        next if $time < $startTime;

        my $value = $data_href->{$time}{$signalName};

        next if not defined $value;

        $minValue = $value if $value < $minValue;
        $maxValue = $value if $value > $maxValue;

        last if ($time - $startTime) > $duration_s;
    }

    my $measuredAmplitude = ($maxValue - $minValue)/2;

    my $endTime = $startTime + $duration_s;
    S_w2log(2, "Measured amplitude (raw) = $measuredAmplitude from time = $startTime s to time = $endTime s, min = $minValue, max = $maxValue");
    my $measuredAmplitudePhys = $measuredAmplitude*$measurement2physFactor;
    S_w2log(1, "Measured amplitude (physical) = $measuredAmplitudePhys");

    return $measuredAmplitudePhys;
}

#
# Changes the time base of a given $data_href structure from ms to s   
#
sub DataMs2s{
    my $data_href = shift;
    
    my @times = sort {$a <=> $b} keys %{ $data_href };
    foreach my $time ( @times ) {
        my $newTime = $time/1000;
        foreach my $signal ( keys %{ $data_href->{$time} } ) {
            my $value = $data_href->{$time}{$signal};
            $data_href->{$newTime}{$signal} = $value;
        }
        delete $data_href->{$time};
    }
}

#
# Determine the data age from the measured sensor values of a given sine input curve
#
# The functions calculates the zero points in the measured data and calculates the data age from the time of one of the zero points ($zeroIndex).
# If data quality is not sufficient then the data age is simply calculated from the time when the first data jump happens.
#
sub DetermineDataAge{
    my $data_href = shift;
    my $signalName = shift;
    my $frequency_Hz = shift;
    my $useZeros = shift;
    my $zeroIndex = shift;


	# get quate trigger time
	my (undef,$triggerTimes_aref)= EVAL_get_values_and_times_over_time($data_href,'EventTrigger');
	my $triggerTime = $triggerTimes_aref->[0];
	if( not defined $triggerTime ) {
	    S_set_error("Could not find EventTrigger from TSG4 in bus trace for data age calculation. Please check the following:\n- The message 'EventTrigger' must be defined in the CAN mapping with the correct bus number.\n- The TSG4 CAN bus must be visible in the Canoe logging block. Check physical connection as well as Canoe configuration and filters before the logging block.\n- The QuaTe trigger line must be connected to TSG4.", 21);
        return (0, 0);
	}
	else{
        S_w2log(2, "Found QuaTe trigger time in bus trace = $triggerTime s");	    
	}
	
	my (@zeroTimes, $jumpTime, $lastValue, $lastTime, $initialValue);
	my $ignoreCounter = 0;
	my $ignoreValues = 2; 
    foreach my $time ( sort {$a <=> $b} keys %{ $data_href } ) {
        my $value = $data_href->{$time}{$signalName};
        next if not defined $value;
        
        # ignore the first n values, because unexpected jumps can happen
        $ignoreCounter++;
        next if $ignoreCounter <= $ignoreValues;

        # determine the initial value
        if( not defined $initialValue ){
        	$initialValue = $value;
        }
        
		# determine the initial data jump time
		if( not defined $jumpTime ){
			next if $value == $initialValue;
			$jumpTime = $time;
			$lastValue = $value;
			$lastTime = $time;
		}

		# check if there is a sign change
		if( $value >= 0 and $lastValue < 0 or $value < 0 and $lastValue >= 0 ){
			# do linear interpolation to calculate the time when the value is zero
			my $deltaTime = $time - $lastTime;
			my $timeToZero;
			if($value != 0){
				my $valuePart = abs($lastValue/$value);
				$timeToZero = $valuePart*$deltaTime/(1+$valuePart);				
			}
			else{
				$timeToZero = $deltaTime;
			}
			push(@zeroTimes, $lastTime+$timeToZero);
			last if @zeroTimes > $zeroIndex+1;
		}

		$lastValue = $value;
		$lastTime = $time;
    }

	S_w2log(2, "Found jump time at $jumpTime s");
	S_w2log(2, "Found zeroes at following times: @zeroTimes");

    my ($age_zeros_ms, $age_rough_ms);
	if ( $useZeros ){
    	# data quality is good, calculate data age using zero points. This leads to high quality data age values. 

        # get duration of 1.5 periods ($zeroIndex = 2 i.e. 3 zeros from trigger time = 3/2 periods)
    	my $calculatedPeriodTime = ($zeroIndex+1)/2/$frequency_Hz;
		my $selectedZeroTime = $zeroTimes[$zeroIndex];
    	$age_zeros_ms = ($selectedZeroTime - $triggerTime - $calculatedPeriodTime)*1000;
    	if( $age_zeros_ms < 0 ){
    		# if data age is negative then we have the first zero very soon after the trigger time, therefore we have to go one zero further
    	    $selectedZeroTime = $zeroTimes[$zeroIndex+1];
        	$age_zeros_ms = ($selectedZeroTime - $triggerTime - $calculatedPeriodTime)*1000;
    	}
	    S_w2log(2, "Using zero time $selectedZeroTime for data age calculation (1.5 periods from trigger time)\n");
    	
	    S_w2log(1, "Using zero positions for data age calculation: data age = $age_zeros_ms\n");

        if( $age_zeros_ms < 0 ) {
            $age_zeros_ms = 0;
    	    S_w2log(1, "Implausible data age value. Setting it to zero.\n");
        }
	}
	else{
	    $age_zeros_ms = 0;
	}

    # for lower quality data we use simply the first jump time for data age calculation
    $age_rough_ms = ($jumpTime - $triggerTime)*1000;
    S_w2log(1, "Rough data age calculation from jump time: data age = $age_rough_ms\n");

	return ($age_rough_ms, $age_zeros_ms);	    
	
}

1;
