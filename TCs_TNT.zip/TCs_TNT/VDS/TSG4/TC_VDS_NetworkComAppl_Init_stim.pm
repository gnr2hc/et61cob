#### TEST CASE MODULE
package TC_VDS_NetworkComAppl_Init_stim;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.2 $;
our $HEADER  = q$Header: VDS/TSG4/TC_VDS_NetworkComAppl_Init_stim.pm 1.2 2019/04/01 18:48:59ICT Andrews Xavier Jesu (RBEI/EVS) (XAA1COB) develop  $;

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_can_access;
use LIFT_labcar;
use LIFT_CSM;
use LIFT_PD;
use LIFT_TEMPERATURE;
use LIFT_TSG4;
use LIFT_equipment;
use FuncLib_VDS;

##################################

our $PURPOSE = "Test of Network COM Application - Initialization - stimulation part";

# DOCUMENTATION

=head1 TESTCASE MODULE

TC_VDS_NetworkComAppl_Init_stim

=head1 PURPOSE

From HLD: 
The test case shall show the timing between power-up of the ECU and the first bus massages being sent (with channel state �init�), 
and the timing to the subsequent change from �init� to �normal�. 

=head1 TESTCASE DESCRIPTION

This a pure stimulation test case to record test data. 
The corresponding evaluation test case (TC_VDS_NetworkComAppl_Init_eval.pm) must be executed after this test 
to evaluate the recorded data.

I<B<Preconditions>>

This test case needs a TSG4 to be able to get the power-on time via a CAN message in sync with the ECU bus communication.
In the Canoe configuration the TSG4 CAN must be recorded as CAN bus number 2 together with the ECU busses. 

I<B<Initialisation>>

    - nothing

I<B<Stimulation and Measurement>>

    - Switch ECU off.
    - Manual step: Set ECU position such that 'direction' points downwards (1 g).
    - Set temperature to 'temperature'.
    - Start network trace.
    - Switch ECU on.
    - Wait 3 seconds.
    - Stop network trace.
    - Read fault memory.
    - Switch ECU off.

I<B<Evaluation>>

    - nothing

I<B<Finalisation>>

    - nothing

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

    SCALAR 'purpose' = Purpose of the Testcase
    SCALAR 'project_ID' = Unique project ID for data container (same as in evaluation test case).
    SCALAR 'down_direction' = Axis of the ECU that points downwards. Must be 'x', 'y' or 'z'.
    SCALAR 'TSG4_CAN_bus_number' = (optional) Bus number of TSG4 CAN. Default = 2.
    LIST   'temperatures' = (optional) list of temperatures (in deg) for which this test will be repeated.
                            If not given then no temperature control will be done and the test is executed only once. 

=head2 PARAMETER EXAMPLES

    [TC_VDS_NetworkComAppl_Init_eval.example]
    purpose = 'example'
    project_ID = 'ProjectXY_Var1_SampleA'
    down_direction = 'x'
    temperatures = @(23, -40, 85)
    TSG4_CAN_bus_number = 3

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_project_ID;
my $tcpar_down_direction;
my $tcpar_temperatures_aref;
my $tcpar_TSG4_CAN_bus_number;

################ global parameter declaration ###################
#add any global variables here
my @temperatures;

###############################################################

sub TC_set_parameters {
    
    $tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
    $tcpar_project_ID =  S_read_mandatory_testcase_parameter( 'project_ID' );
    $tcpar_down_direction =  S_read_mandatory_testcase_parameter( 'down_direction' );
    $tcpar_temperatures_aref =  S_read_optional_testcase_parameter( 'temperatures' );
    $tcpar_TSG4_CAN_bus_number =  S_read_optional_testcase_parameter( 'TSG4_CAN_bus_number' );

    # check validity of $tcpar_down_direction
    if ( $tcpar_down_direction !~ /^[xyz]$/i ) {
        S_set_error("Given parameter 'down_direction' = '$tcpar_down_direction' is none of the following allowed: 'x', 'y', 'z'");
        return 0;
    }

    if( defined $tcpar_temperatures_aref and ref($tcpar_temperatures_aref) eq 'ARRAY' ) {
        @temperatures = @$tcpar_temperatures_aref;
    }
    elsif( not defined $tcpar_temperatures_aref ){
        @temperatures = (23);
    }
    else{
        S_set_error("Given parameter 'temperatures' = '$tcpar_temperatures_aref' must be either a list or not defined");
        return 0;
    }

    $tcpar_TSG4_CAN_bus_number = 2 if not defined $tcpar_TSG4_CAN_bus_number;

    return 1;
}

sub TC_initialization {

    CSM_init() || return;
	CA_simulation_start ( );
    CA_trace_stop();
    CA_trace_store('C:\temp\dummy.asc'); # to make sure that a new trace will be started in TC_stimulation_and_measurement

    # check if TSG4 is set as device for power_Ubat
    my $powerDevice = EQUIP_get_devices ( 'Labcar' , 'power_static_Ubat');
    if( $powerDevice ne 'TSG4' ) {
        S_set_error("'TSG4' must be set as device for 'Labcar'->'power_Ubat' in LIFT_testbenches.pm, but '$powerDevice' is set.");
        return 0;
    }
    
    return 1;
}

sub TC_stimulation_and_measurement {

    my @traceFiles;

    S_teststep( "Switch ECU off.", 'AUTO_NBR' );
    LC_ECU_Off();

    S_teststep( "Manual step: Set ECU position such that $tcpar_down_direction direction points downwards (1 g).", 'AUTO_NBR' );
    S_user_action("Set ECU position such that $tcpar_down_direction direction points downwards (1 g)");

    foreach my $temperature ( @temperatures ) {

        if( defined $tcpar_temperatures_aref ) {
            S_teststep( "Set temperature to $temperature deg.", 'AUTO_NBR' );
            TEMP_setTargetTemperature($temperature);
            TEMP_waitForTemperature(120);
        }
    
        S_teststep( "Start network trace.", 'AUTO_NBR' );
        CA_trace_start();
        S_wait_ms(500);
    
        S_teststep( "Switch ECU on.", 'AUTO_NBR' );
        LC_ECU_On();
    
        S_teststep( "Wait 3 seconds.", 'AUTO_NBR' );
        S_wait_ms(3000);
    
        S_teststep( "Stop network trace.", 'AUTO_NBR' );
        CA_trace_stop();
        my $canTraceName = 'C:\temp\\' . $tcpar_down_direction . '_' . $temperature . '.asc';
        CA_trace_store($canTraceName);
		CA_trace_start();# added on 8012018
		 S_wait_ms(500);# added on 8012018
        push(@traceFiles, $canTraceName);
        
        S_teststep( "Read fault memory.", 'AUTO_NBR' );
        PD_ReadFaultMemory();
    
        S_teststep( "Switch ECU off.", 'AUTO_NBR' );
        LC_ECU_Off();
        S_wait_ms('TIMER_ECU_OFF');

    }

    S_teststep( "Add trace files to data container.", 'AUTO_NBR' );
    # get TSG4 CAN ID for first power supply line
    my @pslNames = TSG4_get_names( 'POWER_SUPPLY_LINES' );
    my $tsg4CanId = TSG4_get_CANid( $pslNames[0] );
    VDS_StoreDataContainer( \@traceFiles, [ $tcpar_project_ID, 'NetworkComAppl_Init', $tcpar_down_direction ], {'TSG4_CAN_ID' => $tsg4CanId, 'TSG4_CAN_bus' => $tcpar_TSG4_CAN_bus_number} );

    return 1;
}

sub TC_evaluation {

    return 1;
}

sub TC_finalization {

    return 1;
}


1;
