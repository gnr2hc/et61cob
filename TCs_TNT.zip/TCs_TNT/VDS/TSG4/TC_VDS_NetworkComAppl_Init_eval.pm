#### TEST CASE MODULE
package TC_VDS_NetworkComAppl_Init_eval;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.2 $;
our $HEADER  = q$Header: VDS/TSG4/TC_VDS_NetworkComAppl_Init_eval.pm 1.2 2017/10/24 16:40:27ICT Prosch Christian (CC-PS/EPS2) (PHC2SI) develop  $;

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_evaluation;
use LIFT_can_access;
use LIFT_flexray_access;
use LIFT_CSM;
use FuncLib_VDS;

##################################

our $PURPOSE = "Test of Network COM Application - Initialization - evaluation part";

# DOCUMENTATION

=head1 TESTCASE MODULE

TC_VDS_NetworkComAppl_Init_eval

=head1 PURPOSE

From HLD:
The test case shall show the timing between power-up of the ECU and the first bus massages being sent (with channel state �init�), 
and the timing to the subsequent change from �init� to �normal�. 

=head1 TESTCASE DESCRIPTION

This an offline evaluation test case. 
The corresponding stimulation test case (TC_VDS_NetworkComAppl_Init_stim.pm) must be executed before this test 
to record network traces in a CSM container.

I<B<Preconditions>>

A CSM container with network traces with recorded power up behaviour for the system under test must be available.

I<B<Initialisation>>

    - nothing

I<B<Stimulation and Measurement>>

    - nothing, see TC_VDS_NetworkComAppl_Init_stim

I<B<Evaluation>>

    - Load data container with project ID 'project_ID'

    - Loop over all trace files in data container (ECU mounting and temperature can vary)
        - Get Power-On time = first occurance of TSG4 Power-On CAN message in trace

        - Loop over all signals given in 'VDS_CAN_signals', 'VDS_FR_signals'
            - Evaluate that time from Power-On to signal available (= initial value) 
              is 'time_signal_available_expected_s' with tolerance 'time_signal_available_tolerance_s'
            - Evaluate that time from signal available to signal valid (not initial value) 
              is 'time_signal_valid_expected_s' with tolerance 'time_signal_valid_tolerance_s'
            - Evaluate that the signal cycle time is 'cycle_time_expected_ms' with tolerance 'cycle_time_tolerance_ms'
              
        - Loop over all signals given in 'VDS_CAN_quality_signals', 'VDS_FR_quality_signals'
            - Evaluate that time from Power-On to signal available (= 'quality_initial_value') 
              is 'time_signal_available_expected_s' with tolerance 'time_signal_available_tolerance_s'
            - Evaluate that time from signal available to signal valid (= 'quality_valid_value') 
              is 'time_signal_valid_expected_s' with tolerance 'time_signal_valid_tolerance_s'
            - Evaluate that the signal cycle time is 'cycle_time_expected_ms' with tolerance 'cycle_time_tolerance_ms'

I<B<Finalisation>>

    - nothing

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

    SCALAR 'purpose' = Purpose of the Testcase
    SCALAR 'project_ID' = Unique project ID (same as in stimulation test case).
    SCALAR 'down_direction' = Axis of the ECU that points downwards. Must be 'x', 'y' or 'z'.
                              Same as in stimulation test case.
    LIST   'VDS_CAN_signals' = (optional) list of VDS signals on CAN to be evaluated.
    LIST   'VDS_CAN_quality_signals' = (optional) list of VDS quality signals on CAN to be evaluated.
    LIST   'VDS_FR_signals' = (optional) list of VDS signals on FR to be evaluated.
    LIST   'VDS_FR_quality_signals' = (optional) list of VDS quality signals on FR to be evaluated.
    SCALAR 'quality_initial_value' = value of quality signal that indicates: initial value
    SCALAR 'quality_valid_value' = value of quality signal that indicates: signal valid
    SCALAR 'time_signal_available_max_expected_s' = expected maximum time between power on and signal available in s
    SCALAR 'time_signal_valid_max_expected_s' = expected maximum time between spower on and signal valid in s
    SCALAR 'cycle_time_expected_ms' = expected cycle time value of all VDS messages/PDUs in ms
    SCALAR 'cycle_time_tolerance_ms' = tolerance for cycle time value of all VDS messages/PDUs in ms

    Note: 
    At least one of the test case parameters 'VDS_CAN_signals' and 'VDS_FR_signals' must be defined.
    If the test case parameter 'VDS_CAN_signals' is defined then also 'VDS_CAN_quality_signals' must be defined
    If the test case parameter 'VDS_FR_signals' is defined then also 'VDS_FR_quality_signals' must be defined

=head2 PARAMETER EXAMPLES

    [TC_VDS_NetworkComAppl_Init_eval.example]
    purpose = 'example'
    project_ID = 'ProjectXY_Var1_SampleA'
    down_direction = 'x'
    VDS_FR_signals = @('ALgt1', 'ALat1', 'AVert2', 'RollRate1', 'YawRate1')
    VDS_FR_quality_signals = @('ALgt1Qf1', 'ALat1Qf1', 'AVert2Qf1', 'RollRate1Qf1', 'YawRate1Qf1')
    quality_initial_value = 1
    quality_valid_value = 3
    time_signal_available_max_expected_s = 0.25
    time_signal_valid_max_expected_s = 0.55
    cycle_time_expected_ms = 10
    cycle_time_tolerance_ms = 1

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_project_ID;
my $tcpar_down_direction;
my $tcpar_VDS_CAN_signals_aref;
my $tcpar_VDS_CAN_quality_signals_aref;
my $tcpar_VDS_FR_signals_aref;
my $tcpar_VDS_FR_quality_signals_aref;
my $tcpar_quality_initial_value;
my $tcpar_quality_valid_value;
my $tcpar_time_signal_available_max_expected_s;
my $tcpar_time_signal_valid_max_expected_s;
my $tcpar_cycle_time_expected_ms;
my $tcpar_cycle_time_tolerance_ms;

################ global parameter declaration ###################
#add any global variables here
my ( $powerOnTimeStamp_s, $tcNumber );

###############################################################

sub TC_set_parameters {

    $tcpar_purpose                              = S_read_mandatory_testcase_parameter('purpose');
    $tcpar_project_ID                           = S_read_mandatory_testcase_parameter('project_ID');
    $tcpar_down_direction                       = S_read_mandatory_testcase_parameter('down_direction');
    $tcpar_VDS_CAN_signals_aref                 = S_read_optional_testcase_parameter('VDS_CAN_signals');
    $tcpar_VDS_CAN_quality_signals_aref         = S_read_optional_testcase_parameter('VDS_CAN_quality_signals');
    $tcpar_VDS_FR_signals_aref                  = S_read_optional_testcase_parameter('VDS_FR_signals');
    $tcpar_VDS_FR_quality_signals_aref          = S_read_optional_testcase_parameter('VDS_FR_quality_signals');
    $tcpar_quality_initial_value                = S_read_mandatory_testcase_parameter('quality_initial_value');
    $tcpar_quality_valid_value                  = S_read_mandatory_testcase_parameter('quality_valid_value');
    $tcpar_time_signal_available_max_expected_s = S_read_mandatory_testcase_parameter('time_signal_available_max_expected_s');
    $tcpar_time_signal_valid_max_expected_s     = S_read_mandatory_testcase_parameter('time_signal_valid_max_expected_s');
    $tcpar_cycle_time_expected_ms               = S_read_mandatory_testcase_parameter('cycle_time_expected_ms');
    $tcpar_cycle_time_tolerance_ms              = S_read_mandatory_testcase_parameter('cycle_time_tolerance_ms');

    # check validity of $tcpar_down_direction
    if ( $tcpar_down_direction !~ /^[xyz]$/i ) {
        S_set_error("Given parameter 'down_direction' = '$tcpar_down_direction' is none of the following allowed: 'x', 'y', 'z'");
        return 0;
    }

    if ( not defined $tcpar_VDS_CAN_signals_aref and not defined $tcpar_VDS_FR_signals_aref ) {
        S_set_error("At least one of the test case parameters 'VDS_CAN_signals' and 'VDS_FR_signals' must be defined");
        return 0;
    }

    if ( defined $tcpar_VDS_CAN_signals_aref and not defined $tcpar_VDS_CAN_quality_signals_aref ) {
        S_set_error("If the test case parameter 'VDS_CAN_signals' is defined then also 'VDS_CAN_quality_signals' must be defined");
        return 0;
    }

    if ( defined $tcpar_VDS_FR_signals_aref and not defined $tcpar_VDS_FR_quality_signals_aref ) {
        S_set_error("If the test case parameter 'VDS_FR_signals' is defined then also 'VDS_FR_quality_signals' must be defined");
        return 0;
    }

    return 1;
}

sub TC_initialization {

    $tcNumber = S_get_TC_number();
    CSM_init() || return;
    return 1;
}

sub TC_stimulation_and_measurement {

    return 1;
}

sub TC_evaluation {

    my $testData_href = VDS_GetDataContainer( [ $tcpar_project_ID, 'NetworkComAppl_Init', $tcpar_down_direction ] );
    my $subtest_href  = $testData_href->{'subtests'};
    my @subtests      = sort keys %{$subtest_href};
    S_teststep( "Found " . scalar(@subtests) . " bus traces in data container with project ID '$tcpar_project_ID' and keyword 'NetworkComAppl_Init'.", 'AUTO_NBR' );
    if ( not @subtests ) {
        S_set_error("No bus trace found in data container with project ID '$tcpar_project_ID' and keyword 'NetworkComAppl_Init'.");
        return 0;
    }

    my $tsg4CanId  = $testData_href->{'metaData'}{'TSG4_CAN_ID'};
    my $tsg4CanBus = $testData_href->{'metaData'}{'TSG4_CAN_bus'};
    if ( not defined $tsg4CanId or not defined $tsg4CanBus ) {
        S_set_error("'TSG4_CAN_ID' or 'TSG4_CAN_bus' not found in meta data of data container.");
        return 0;
    }

    foreach my $subtest (@subtests) {
        my $direction   = $subtest_href->{$subtest}{'direction'};
        my $temperature = $subtest_href->{$subtest}{'temperature'};
        my $traceFile   = $subtest_href->{$subtest}{'traceFile'};
        S_teststep( "Reading bus trace '$traceFile' for direction '$direction' and temperature $temperature.", 'AUTO_NBR' );

        S_teststep( "Extract CAN signals from bus trace", 'AUTO_NBR' );
        my @canSignals = ( [ $tsg4CanId, $tsg4CanBus ] );
        push( @canSignals, @$tcpar_VDS_CAN_signals_aref )         if defined $tcpar_VDS_CAN_signals_aref;
        push( @canSignals, @$tcpar_VDS_CAN_quality_signals_aref ) if defined $tcpar_VDS_CAN_quality_signals_aref;

        my $canMeasureData_href = CA_trace_get_dataref( $traceFile, \@canSignals );
        if ( not defined $canMeasureData_href ) {
            shift @canSignals;
            S_set_error("Could not find any of the signals '@canSignals [ID $tsg4CanId (dec) on bus $tsg4CanBus]' in the trace");
            next;
        }

        S_teststep( "Get Power-On time (first occurance of TSG4 CAN message $tsg4CanId on bus $tsg4CanBus) from trace", 'AUTO_NBR' );
        my ( $dummy, $tsg4Times_aref ) = EVAL_get_values_and_times_over_time( $canMeasureData_href, $tsg4CanId );
        if ( not defined $tsg4Times_aref or @$tsg4Times_aref == 0 ) {
            S_set_error("Could not find Power-On time: No occurance of message $tsg4CanId on bus $tsg4CanBus found in trace");
            next;
        }
        $powerOnTimeStamp_s = $$tsg4Times_aref[0];
        S_teststep( "Found Power-On time at $powerOnTimeStamp_s s.", 'AUTO_NBR' );
        shift @canSignals;

        if ( defined $tcpar_VDS_CAN_signals_aref or defined $tcpar_VDS_CAN_quality_signals_aref ) {
            Evaluate_init_timing( $canMeasureData_href, $tcpar_VDS_CAN_signals_aref, $tcpar_VDS_CAN_quality_signals_aref, 'CAN', $direction, $temperature );
        }

        if ( defined $tcpar_VDS_FR_signals_aref or defined $tcpar_VDS_FR_quality_signals_aref ) {
            S_teststep( "Extract Flexray signals from bus trace", 'AUTO_NBR' );
            my @frSignals;
            push( @frSignals, @$tcpar_VDS_FR_signals_aref )         if defined $tcpar_VDS_FR_signals_aref;
            push( @frSignals, @$tcpar_VDS_FR_quality_signals_aref ) if defined $tcpar_VDS_FR_quality_signals_aref;
            my $frmeasureData_href = FR_trace_get_dataref( $traceFile, \@frSignals );
            Evaluate_init_timing( $frmeasureData_href, $tcpar_VDS_FR_signals_aref, $tcpar_VDS_FR_quality_signals_aref, 'FR', $direction, $temperature );
        }

    }

    VDS_CloseDataContainer( $testData_href->{'container_id'} );

    return 1;
}

sub TC_finalization {

    return 1;
}

sub Evaluate_init_timing {
    my $measureData_href    = shift;
    my $dataSignals_aref    = shift;
    my $qualitySignals_aref = shift;
    my $itemType            = shift;
    my $direction           = shift;
    my $temperature         = shift;

    S_teststep( "Loop over each of the $itemType data signals", 'AUTO_NBR' );
    EVAL_createGraphFromMeasurement( $measureData_href, "$tcNumber direction $direction temperature $temperature $itemType data signals", { 'y' => $dataSignals_aref }, 'no_interpolation', 1 );
    foreach my $dataSignal (@$dataSignals_aref) {
        S_teststep_2nd_level( "Evaluate data signal $dataSignal", 'AUTO_NBR' );
        my $signalAvailableTimeStamp_s = EVAL_get_time_when( $measureData_href, $dataSignal, '>', -1E9, $powerOnTimeStamp_s );
        my ($initialValue) = EVAL_get_value_around_time( $measureData_href, $signalAvailableTimeStamp_s, $dataSignal );
        my $signalAvailableTime_s = $signalAvailableTimeStamp_s - $powerOnTimeStamp_s;
        EVAL_evaluate_value( "Time (in s) from power on to $dataSignal available (= $initialValue)", $signalAvailableTime_s, '<', $tcpar_time_signal_available_max_expected_s );

        my $signalValidTimeStamp_s = EVAL_get_time_when( $measureData_href, $dataSignal, '!=', $initialValue, $signalAvailableTimeStamp_s );
        my $signalValidTime_s = $signalValidTimeStamp_s - $powerOnTimeStamp_s;
        EVAL_evaluate_value( "Time (in s) from power on to $dataSignal valid (not $initialValue)", $signalValidTime_s, '<', $tcpar_time_signal_valid_max_expected_s );

        my $cycleTimeStart_s = $signalAvailableTimeStamp_s + $tcpar_cycle_time_expected_ms / 1000;
        EvaluateCycleTime( $measureData_href, $dataSignal, $cycleTimeStart_s );
    }

    S_teststep( "Loop over each of the $itemType quality signals", 'AUTO_NBR' );
    EVAL_createGraphFromMeasurement( $measureData_href, "$tcNumber direction $direction temperature $temperature $itemType quality signals", { 'y' => $qualitySignals_aref }, 'no_interpolation', 1 );
    foreach my $qualitySignal (@$qualitySignals_aref) {
        S_teststep_2nd_level( "Evaluate quality signal $qualitySignal", 'AUTO_NBR' );
        my $signalAvailableTimeStamp_s = EVAL_get_time_when( $measureData_href, $qualitySignal, '==', $tcpar_quality_initial_value, $powerOnTimeStamp_s );
        my $signalAvailableTime_s = $signalAvailableTimeStamp_s - $powerOnTimeStamp_s;
        EVAL_evaluate_value( "Time (in s) from power on to $qualitySignal available (= $tcpar_quality_initial_value)", $signalAvailableTime_s, '<', $tcpar_time_signal_available_max_expected_s );

        my $signalValidTimeStamp_s = EVAL_get_time_when( $measureData_href, $qualitySignal, '==', $tcpar_quality_valid_value, $signalAvailableTimeStamp_s );
        my $signalValidTime_s = $signalValidTimeStamp_s - $powerOnTimeStamp_s;
        EVAL_evaluate_value( "Time (in s) from power on to $qualitySignal valid (= $tcpar_quality_valid_value)", $signalValidTime_s, '<', $tcpar_time_signal_valid_max_expected_s );

        my $cycleTimeStart_s = $signalAvailableTimeStamp_s + $tcpar_cycle_time_expected_ms / 1000;
        EvaluateCycleTime( $measureData_href, $qualitySignal, $cycleTimeStart_s );
    }
    return 1;
}

sub EvaluateCycleTime {
    my $measureData_href = shift;
    my $signal           = shift;
    my $cycleTimeStart_s = shift;

    my ( $cycletime_min_s, $cycletime_max_s, $cycletime_avg_s ) = EVAL_get_signal_cycletime( $measureData_href, $signal, $cycleTimeStart_s );
    S_teststep_2nd_level( "Evaluate minimum cycle time for $signal", 'AUTO_NBR' );
    EVAL_evaluate_value( "Min cycle time for $signal", $cycletime_min_s * 1000, '==', $tcpar_cycle_time_expected_ms, $tcpar_cycle_time_tolerance_ms, 'absolute' );
    S_teststep_2nd_level( "Evaluate maximum cycle time for $signal", 'AUTO_NBR' );
    EVAL_evaluate_value( "Max cycle time for $signal", $cycletime_max_s * 1000, '==', $tcpar_cycle_time_expected_ms, $tcpar_cycle_time_tolerance_ms, 'absolute' );
    return 1;
}

1;
