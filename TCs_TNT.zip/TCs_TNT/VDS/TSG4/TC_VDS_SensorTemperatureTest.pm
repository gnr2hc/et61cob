# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#    $Source: VDS/TSG4/TC_VDS_SensorTemperatureTest.pm $
#    $Revision: 1.1 $ (kommt von MKS)
#    $Author: Knoedler Christian (CC-PS/EPS2) (knc2abt) $
#    $State: develop $
#    $Date: 2019/10/21 14:31:28ICT $
#******************************************************************************************************

#### TEST CASE MODULE
package TC_VDS_SensorTemperatureTest;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
###-------------------------------
my $VERSION = q$Revision: 1.1 $;                                                                                            # stimmt net!
my $HEADER  = q$Header: VDS/TSG4/TC_VDS_SensorTemperatureTest.pm 1.1 2019/10/21 14:31:28ICT Knoedler Christian (CC-PS/EPS2) (knc2abt) develop  $;

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use FuncLib_TNT_GEN;
use LIFT_ProdDiag;
use Excel::Writer::XLSX;
use LIFT_flexray_access;                                                                                                    # excel M�glichkeit
##################################

our $PURPOSE = "SensorTemperatureTest";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE
    
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my (
    $Date_Oven_start,           $Time_Oven_start,                     $Time_Oven_ready,                            $filename_csv,    $format,            $format2,                  $format3,
    $format4,                   $workbook,                            $worksheet,                                  $worksheet2,      $worksheet3,        $worksheet4,               $FieldBus_TemperaturSignal,
    $Unit,                      $Time_Oven_delta,                     $Time_ECU_delta,                             $Time_SMIx_delta, $Response_BUS_Time, $Oven_delta_Time,
    $SMIx_templable_raw_value,  $SMI_Temp_steady_state,               $SMIx_temp_Celsius1,                         $SMIx_temp_Celsius2,
    $SMIx_temp_Celsius,         $SMIx_temp_Celsius_new,               $Oven_Temp,                                  $TIMER_RESPONSE,  $TIMER_RESPONSE2,   $Response_Time_internSMIx, $Temp_Oven_start,
    $Temp_Oven_diff,            $Temp_SMIx_start,                     $Temp_SMIx_ready,                            $Temp_BUS_start,  $Temp_BUS_ready,    $Oven_delta_Time,          $Temp_SMIx_diff,
    $tcpar_temperatures_G_aref, $tcpar_FieldBus_Response_Delta_Value, $tcpar_Internal_Lable_SMIx_TemperaturSignal, $tcpar_FieldBus_TemperaturSignal,

);

#Testcase-Globalen-Variablen

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

    # . par file variables

    $tcpar_temperatures_G_aref = S_read_mandatory_testcase_parameter("temperatures_G");    # ref for reference // a for list/array -> aref

    $tcpar_Internal_Lable_SMIx_TemperaturSignal = S_read_mandatory_testcase_parameter("Internal_Lable_SMIx_TemperaturSignal");

    $tcpar_FieldBus_TemperaturSignal = S_read_mandatory_testcase_parameter("FieldBus_TemperaturSignal");

    $tcpar_FieldBus_Response_Delta_Value = S_read_mandatory_testcase_parameter("FieldBus_Response_Delta_Value");

    return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

    #############################################
    ##############      EXCEL       #############
    #############################################

    # Create a new Excel workbook
    my $filename_excel = $main::REPORT_PATH . '\\' . S_get_TC_number() . "_TemperaturTest_" . S_get_date_extension() . ".xlsx";

    # Variable = path to reports ; name of Testcase ; filename *fix* ; date and time ; in excel
    $workbook = Excel::Writer::XLSX->new($filename_excel);

    # Add a worksheet
    $worksheet  = $workbook->add_worksheet("VALUES");
    $worksheet2 = $workbook->add_worksheet("Noise_VALUES");
    $worksheet3 = $workbook->add_worksheet("data");
    $worksheet4 = $workbook->add_worksheet("data2");

    #  Add and define a format // all coloure
    $format = $workbook->add_format();
    $format->set_bold();
    $format->set_color('black');
    $format->set_align('center');

    $format2 = $workbook->add_format();
    $format2->set_bold();
    $format2->set_color('blue');
    $format2->set_align('center');

    $format3 = $workbook->add_format();
    $format3->set_bold();
    $format3->set_color('red');
    $format3->set_align('center');

    $format4 = $workbook->add_format();
    $format4->set_bold();
    $format4->set_color('orange');
    $format4->set_align('center');

    # Excel-position-purpose

    #VALUES
    $worksheet->set_column( 0, 6, 18 );    # Size format excel # split wide
    $worksheet->set_column( 7, 8, 26 );    # Size format excel # split wide
    $worksheet->set_column( 9, 9, 20 );    # Size format excel # split wide

    #Noise_VALUES
    $worksheet2->set_column( 0, 6, 18 );    # Size format excel # split wide
    $worksheet2->set_column( 7, 8, 26 );    # Size format excel # split wide
    $worksheet2->set_column( 9, 9, 20 );    # Size format excel # split wide

    #data
    $worksheet3->set_column( 0, 6,  18 );    # Size format excel # split wide
    $worksheet3->set_column( 7, 8,  26 );    # Size format excel # split wide
    $worksheet3->set_column( 9, 12, 20 );    # Size format excel # split wide

    $worksheet4->set_column( 0, 10, 20 );    # Size format excel # split wide

    $worksheet->write( 0, 0,  'Date_Oven_start',           $format );    #A
    $worksheet->write( 0, 1,  'Time_Oven_start',           $format );    #B
    $worksheet->write( 0, 2,  'Time_Oven_ready',           $format );    #C
    $worksheet->write( 0, 3,  'Time_settled',              $format );    #D
    $worksheet->write( 0, 4,  'OvenTemp_Target',           $format );    #E
    $worksheet->write( 0, 5,  'OvenTemp_actually',         $format );    #F
    $worksheet->write( 0, 6,  'SMIx_1 Temp',               $format );    #G
    $worksheet->write( 0, 7,  'FieldBus_TemperaturSignal', $format );    #H
    $worksheet->write( 0, 8,  'Response_Time_intern_SMIx', $format );    #I
    $worksheet->write( 0, 9,  'Response_Time_BUS',         $format );    #J
    $worksheet->write( 0, 11, 'ECU-SwVersion',             $format );    #L

    $worksheet2->write( 0, 0,  'Date_Oven_start',           $format );   #A
    $worksheet2->write( 0, 1,  'Time_Oven_start',           $format );   #B
    $worksheet2->write( 0, 2,  'Time_Oven_ready',           $format );   #C
    $worksheet2->write( 0, 3,  'Time_settled',              $format );   #D
    $worksheet2->write( 0, 4,  'OvenTemp_Target',           $format );   #E
    $worksheet2->write( 0, 5,  'OvenTemp_actually',         $format );   #F
    $worksheet2->write( 0, 6,  'SMIx_1 Temp',               $format );   #G
    $worksheet2->write( 0, 7,  'FieldBus_TemperaturSignal', $format );   #H
    $worksheet2->write( 0, 8,  'Response_Time_intern_SMIx', $format );   #I
    $worksheet2->write( 0, 9,  'Response_Time_BUS',         $format );   #J
    $worksheet2->write( 0, 11, 'ECU-SwVersion',             $format );   #L

    $worksheet3->write( 0, 0,  'Date_Oven_start',                 $format );    #A
    $worksheet3->write( 0, 1,  'Time_Oven_start',                 $format );    #B
    $worksheet3->write( 0, 2,  'Time_Oven_ready',                 $format );    #C
    $worksheet3->write( 0, 3,  'Time_settled',                    $format );    #D
    $worksheet3->write( 0, 4,  'OvenTemp_Target',                 $format );    #E
    $worksheet3->write( 0, 5,  'OvenTemp_actually',               $format );    #F
    $worksheet3->write( 0, 6,  'SMIx_1 Temp',                     $format );    #G
    $worksheet3->write( 0, 7,  'FieldBus_TemperatureSignal',      $format );    #H
    $worksheet3->write( 0, 8,  'Response_Time_intern_SMIx',       $format );    #I
    $worksheet3->write( 0, 9,  'Response_Time_BUS',               $format );    #J
    $worksheet3->write( 0, 10, 'avg_Temp_Diff. for steady state', $format );    #K
    $worksheet3->write( 0, 11, 'Surveys',                         $format );    #L
    $worksheet3->write( 0, 12, 'Values to steady state',          $format );    #M
    $worksheet3->write( 0, 13, 'Times of values',                 $format );    #N

    $worksheet4->write( 0, 0,  'Temp_Oven_start',      $format );               #A #$Temp_Oven_start
    $worksheet4->write( 0, 1,  'Temp_Oven_diff',       $format );               #B #$Temp_Oven_diff
    $worksheet4->write( 0, 2,  'Oven_delta_Time',      $format );               #C #$Oven_delta_Time
    $worksheet4->write( 0, 3,  'Temp_SMIx_start',      $format );               #C #$Temp_SMIx_start
    $worksheet4->write( 0, 4,  'Time_Oven/SMIx_Value', $format );               #D #Time_Oven/SMIx_Value
    $worksheet4->write( 0, 5,  'Temp_Oven_Value',      $format );               #D #Temp_Oven_Value
    $worksheet4->write( 0, 6,  'Temp_SMIx_Value',      $format );               #D #Temp_SMIx_Value
    $worksheet4->write( 0, 7,  'Temp_SMIx_ready',      $format );               #D #$Temp_SMIx_ready
    $worksheet4->write( 0, 8,  'Temp_SMIx_diff',       $format );               #E #$Temp_SMIx_diff
    $worksheet4->write( 0, 9,  'Temp_BUS_start',       $format );               #E #$Temp_BUS_start
    $worksheet4->write( 0, 10, 'Temp_BUS_ready',       $format );               #E #$Temp_BUS_ready

    #############################################
    ##############      .CSV       ##############
    #############################################

    $filename_csv = $main::REPORT_PATH . '\\' . S_get_TC_number() . "_TempLog.csv";

    open( EVAL, ">$filename_csv" ) || S_set_error("Couldn't open '$filename_csv' file!!!");

    print EVAL "Date_Oven_start;";
    print EVAL "Time_Oven_start;";
    print EVAL "Time_Oven_ready;";
    print EVAL "Time_settled;";
    print EVAL "OvenTemp_Target;";
    print EVAL "OvenTemp_actually;";
    print EVAL "SMIx_1 Temp;";
    print EVAL "SMIx_2 Temp;";
    print EVAL "FieldBus_TemperatureSignal;";

    close EVAL;

    #############################################

    LC_ECU_On('U_BATT_DEFAULT');    #ECU_ON
    PRD_Read_Fault_Memory('BOSCH');

    S_wait_ms('600000');            #Waiting Time to get SMIx work temeprature (start phase)

    return 1;

}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

    my $row  = 1;                   #variable for worksheet (Excel-Report)
    my $row2 = 1;                   #variable for worksheet2 (Excel-Report)
    my $row3 = 1;                   #variable for worksheet3 (Excel-Report)
    my $row4 = 1;                   #variable for worksheet3 (Excel-Report)

    my $project_info_href = S_get_project_info();
    my $SW_version        = $project_info_href->{ECU_SW_VERSION};

    $worksheet->write( $row, 11, $SW_version, $format2 );    #read&write ECU-SW to report

    foreach my $temperature (@$tcpar_temperatures_G_aref) {

        S_w2rep( "\n\n ####################### $temperature �C Oven Temp ###################### \n ############################################################## \n", 'green' );

        S_w2rep( "\n\n #################### Oven-Target-Temp is approached #################### \n", 'red' );

        $Oven_Temp = TEMP_get_temperature();
        S_w2rep( "Oven Temp is : $Oven_Temp �C  \n", 'blue' );

        $Temp_Oven_start = $Oven_Temp;                       #test #Temp_Oven_start

        TEMP_setTargetTemperature($temperature, 7);

        S_set_timer_zero("TIMER_RESPONSE");

        ( $Date_Oven_start, $Time_Oven_start ) = S_formated_timestamp();

        ####################################
        ########### Response time ##########
        ####################################

        # 1. Temperaturschrank bekommt Temperatur�nderungsanfrage
        # 2. Wenn eine Temperatur�nderung im Temperaturschrank >0.5 Kelvin gemessen wird, wird der Timer gestartet
        # 3. Wenn sich der SMIx Temperaturwert um >1 Kelvin �ndert wird die Zeit f�r Response Wert f�r den SMIx intern genommen
        # 4. Wenn sich das Temperatursignal auf dem BUS um >2 Kelvin �ndert wird die Zeit f�r den Response BUS Wert genommen

        #english below:
        # 1. Temperature cabinet gets temperature change request
        # 2. If a temperature change in the temperature cabinet> 0.5 Kelvin is measured, the timer is started
        # 3. When the SMIx temperature value changes by> 1 Kelvin, the time for response value for the SMIx is taken internally
        # 4. When the temperature signal on the bus changes by> 2 Kelvin, the time for the Response BUS value is taken

        ###### Oven-Temp-Delta-Detection ######

        foreach my $loop_Oven_time ( 0 .. 1000 ) {

            S_w2rep( "Response-Time detection \n", 'blue' );

            my $Oven_Temp_Loop = TEMP_get_temperature;

            if ( abs( $Oven_Temp_Loop - $Oven_Temp ) >= 0.5 ) {

                $Temp_Oven_diff = ( abs( $Oven_Temp_Loop - $Oven_Temp ) );    #Temp_Oven_diff #Temp_Oven_ready

                $Oven_delta_Time = S_read_timer_ms("TIMER_RESPONSE");

                $Oven_delta_Time = $Oven_delta_Time;                          #Oven_delta_Time #Oven_delta_Time

                S_w2rep( "         Oven-delta-Time is:	$Oven_delta_Time ms  \n", 'blue' );
                last;
            }
            S_wait_ms('1000');
        }

        ################ End #################

        # Detection SMI Temp
        $SMIx_templable_raw_value = PRD_Read_Memory( $tcpar_Internal_Lable_SMIx_TemperaturSignal, { memoryContentsAsInteger => 1 } );
        $SMIx_temp_Celsius1 = $SMIx_templable_raw_value / 200 + 50;    #calculation IST Temp at SMI

        S_w2rep( "SMIx_Temp is: $SMIx_temp_Celsius1 \n", 'blue' );

        $Temp_SMIx_start = $SMIx_temp_Celsius1;    # test #Temp_SMIx_start

        ( $FieldBus_TemperaturSignal, $Unit ) = FR_read_flxr_signal( $tcpar_FieldBus_TemperaturSignal, 'phys' );    #get Signal

        $Temp_BUS_start = $FieldBus_TemperaturSignal;                                                               # test #Temp_BUS_start

        S_set_timer_zero("TIMER_RESPONSE2");

        ###### Response-Time for intern SMIx Detection ######
        #####################################################

        foreach my $loop_Response_Time_internSMIx ( 0 .. 1000 ) {

            S_w2rep( "Response-Time for SMIX_intern detection \n", 'blue' );

            ### intern Temp-Signal
            $SMIx_templable_raw_value = PRD_Read_Memory( $tcpar_Internal_Lable_SMIx_TemperaturSignal, { memoryContentsAsInteger => 1 } );
            my $SMIx_Temp_loop = $SMIx_templable_raw_value / 200 + 50;    #calculation IST Temp at SMI
            S_w2rep( "SMIx Temp is: $SMIx_Temp_loop �C  \n", 'blue' );

            if ( abs( $SMIx_Temp_loop - $SMIx_temp_Celsius1 ) >= 0.3 ) {

                $Temp_SMIx_diff = ( abs( $SMIx_Temp_loop - $SMIx_temp_Celsius1 ) );    #Oven_delta_Time #Temp_SMIx_diff

                $Temp_SMIx_ready = $SMIx_Temp_loop;                                    #test #Temp_SMIx_ready

                $Response_Time_internSMIx = S_read_timer_ms("TIMER_RESPONSE2");

                my $Time_Messwert_loop = S_formated_timestamp();
                $worksheet4->write( $row4, 4, $Time_Messwert_loop, $format );          #test #Time_Oven/SMIx_Value
                my $Oven_Temp_loop = TEMP_get_temperature();
                $worksheet4->write( $row4, 5, $Oven_Temp_loop, $format );              #test #Temp_Oven_Value
                $worksheet4->write( $row4, 6, $SMIx_Temp_loop, $format );              #test #Temp_SMIx_Value
                $row4++;

                last;
            }

            my $Time_Messwert_loop = S_formated_timestamp();
            $worksheet4->write( $row4, 4, $Time_Messwert_loop, $format );              #test #Time_Oven/SMIx_Value
            my $Oven_Temp_loop = TEMP_get_temperature();
            $worksheet4->write( $row4, 5, $Oven_Temp_loop, $format );                  #test #Temp_Oven_Value
            $worksheet4->write( $row4, 6, $SMIx_Temp_loop, $format );                  #test #Temp_SMIx_Value
            $row4++;

            S_wait_ms('1000');

        }

        ################ End #################

        ###### Response-Time for BUS Detection ######
        #############################################

        foreach my $loop_Response_BUS_time ( 0 .. 1000 ) {

            ### Bus-Temp-Signal
            my ( $FieldBus_Temp_loop, $Unit ) = FR_read_flxr_signal( $tcpar_FieldBus_TemperaturSignal, 'phys' );    #get Signal

            S_w2rep( "        SMIx-BUS-Start-Wert: 	$FieldBus_TemperaturSignal �C  \n", 'blue' );                  # Temp-Start-Wert
            S_w2rep( "SMIx-BUS-Response-Temp-Wert:	$FieldBus_Temp_loop �C  \n\n",       'blue' );                  # Temp-Response-Loop-Wert

            if ( abs( $FieldBus_Temp_loop - $FieldBus_TemperaturSignal ) >= $tcpar_FieldBus_Response_Delta_Value ) {

                $Response_BUS_Time = S_read_timer_ms("TIMER_RESPONSE2");

                #my $Response_with_Oven_Time = S_read_timer_ms("TIMER_RESPONSE2");

                #$Response_BUS_Time = $Response_with_Oven_Time - $Oven_delta_Time;                                   # ResponseTime Berechnung

                ### Report-Darstellung - Tempwerte
                my $Result_Response_Temp_Loop = abs( $FieldBus_Temp_loop - $FieldBus_TemperaturSignal );
                S_w2rep( "SMIx-BUS-Temp-Werte: $FieldBus_TemperaturSignal �C   -   $FieldBus_Temp_loop �C   =   $Result_Response_Temp_Loop �C   >=   2 �C  \n\n", 'blue' );    # Calculation 2rep

                ### Report-Darstellung - Zeitwerte
                S_w2rep( "SMIx-BUS-Zeit-Werte: $Response_BUS_Time ms  \n\n", 'blue' );

                #S_w2rep( "SMIx-BUS-Zeit-Werte: $Response_with_Oven_Time ms   -   $Oven_delta_Time ms   =   $Response_BUS_Time ms  \n\n", 'blue' );                                 # Calculation 2rep

                $Temp_BUS_ready = $FieldBus_Temp_loop;                                                                                                                             #test #Temp_BUS_ready

                S_w2rep( "Temp_BUS_start ist: $Temp_BUS_start �C  \n", 'blue' );

                $SMIx_templable_raw_value = PRD_Read_Memory( $tcpar_Internal_Lable_SMIx_TemperaturSignal, { memoryContentsAsInteger => 1 } );
                my $SMIx_Temp_loop = $SMIx_templable_raw_value / 200 + 50;                                                                                                         #calculation IST Temp at SMI
                S_w2rep( "SMIx Temp is: $SMIx_Temp_loop �C  \n", 'blue' );

                $Temp_SMIx_start = $SMIx_Temp_loop;

                #S_user_action("Innerhalb der IF-Schleife");
                S_wait_ms('3000');
                last;                                                                                                                                                              # mit dem last kommt man wieder aus der foreach(1..1000) Schleife raus!
            }
            S_wait_ms('1000');
        }

        ################ End #################

        ###########################################
        ########### Response time ENDE ############
        ###########################################

        TEMP_waitForTemperature( 60, 1 );    # (waiting period, tolerance)
        S_wait_ms('TIMER_ECU_READY');

        $Time_Oven_ready = S_formated_timestamp();

        S_wait_ms('300000');                 # chamber reached target temperature; after time settle process will be start

        #read SMI Temp
        $SMIx_templable_raw_value = PRD_Read_Memory( $tcpar_Internal_Lable_SMIx_TemperaturSignal, { memoryContentsAsInteger => 1 } );
        $SMIx_temp_Celsius1 = $SMIx_templable_raw_value / 200 + 50;    #calculation IST Temp at SMI

        S_teststep( " SMIx temp is $SMIx_temp_Celsius1", 'AUTO_NBR' );

        ###########################################
        ########### SENSOR steady state ###########
        ###########################################

        # 1. Temperaturschrank hat vorgegebene Temperatur erreicht
        # 2. SMIX_intern Temperaturwert wird erfasst und in eine Liste abgelegt
        # 3. Der Durchschnitt der letzten 20 Werte wid mit dem Durchschnitt der vorherigen 20 Werten verglichen;
        # Wenn dieser Vergleich <0.025 betr�gt gilt der SMIx als eingeschwungen und weitere �nderungen sind maginal und k�nnen ignoriert werden.

        #english below:
        # 1. Temperature cabinet has reached specified temperature
        # 2. SMIX_intern temperature value is captured and put into a list
        # 3. The average of the last 20 values wid compared with the average of the previous 20 values;
        # If this comparison is <0.025 the SMIx is considered steady and further changes are magical and can be ignored.

        my $counter_settled_values = 1;

        S_w2rep( "\n\n ######################## SENSOR steady state is determined ######################## \n\n", 'green' );

        my @liste_temp_SMIx;

        foreach my $messDurchlaeufe ( 0 .. 2000 ) {

            ## SMIx Temp
            $SMIx_templable_raw_value = PRD_Read_Memory( $tcpar_Internal_Lable_SMIx_TemperaturSignal, { memoryContentsAsInteger => 1 } );
            $SMIx_temp_Celsius = $SMIx_templable_raw_value / 200 + 50;    #calculation IST Temp at SMI

            ## Bus-Frame is read out and stored in variable
            ( $FieldBus_TemperaturSignal, $Unit ) = FR_read_flxr_signal( $tcpar_FieldBus_TemperaturSignal, 'phys' );

            unshift( @liste_temp_SMIx, $SMIx_temp_Celsius );    #unshift ; to set next value at the beginning of the list

            # temperature values of SMI should be stored to log the settling
            S_w2rep( "\n Determined value Nr: $counter_settled_values \n", 'blue' );
            $worksheet3->write( $row3, 11, $counter_settled_values, $format );
            $counter_settled_values++;

            $worksheet3->write( $row3, 12, $SMIx_temp_Celsius, $format );

            my $Time_Messwert = S_formated_timestamp();
            $worksheet3->write( $row3, 13, $Time_Messwert, $format );

            $Oven_Temp = TEMP_get_temperature();

            if ( @liste_temp_SMIx > 40 ) {
                my $sum = 0;
                for my $i ( 20 .. 40 ) {
                    $sum = $liste_temp_SMIx[$i] + $sum;
                }

                my $average_old = $sum / 21;

                $sum = 0;
                for my $i ( 0 .. 19 ) {
                    $sum = $liste_temp_SMIx[$i] + $sum;
                }

                my $average_new = $sum / 20;

                ##### $avg_Temp_Diff #####
                my $avg_Temp_Diff = sprintf( "%.2f", abs( $average_old - $average_new ) );    #abs -> for absolute number (to remove sign); sprintf ("%.3f",xxxx) -> round to three decimal places
                S_w2rep( "\n avg_Temp_Diff = $avg_Temp_Diff �C \n\n", 'blue' );

                ##### $Temp_Diff #####
                my $Temp_Diff = sprintf( "%.2f", abs( $liste_temp_SMIx[20] - $liste_temp_SMIx[0] ) );    #abs -> for absolute number (to remove sign); sprintf ("%.3f",xxxx) -> round to three decimal places
                S_w2rep( " Temp_Diff = $Temp_Diff �C \n\n", 'blue' );

                $worksheet3->write( $row3, 10, $avg_Temp_Diff, $format );                                #Temp_Differnece write to report
                $row3++;

                #abort condition
                $SMI_Temp_steady_state = 0.025;                                                          #Value for steady_state
                last if $avg_Temp_Diff <= $SMI_Temp_steady_state;

                #last if $Temp_Diff <= $tcpar_SMI_Temp_steady_state;
            }

            S_w2rep( " SMIx_1    Lable Temp: $SMIx_temp_Celsius �C \n", 'blue' );

            S_w2rep( " SMIx_1 FieldBus Temp: $FieldBus_TemperaturSignal �C \n", 'blue' );

            S_w2rep("\n ############################################ \n");
        }

        my $Time_Sensor_settled = S_formated_timestamp();

        ####### ECU-SENSOR settled ######

        #################################################
        ########### SENSOR steady state ENDE ############
        #################################################

        S_wait_ms('10000');    # Time after ECU is settled

        ###################################
        ####### Noise Measurement #########
        ###################################

        # 1. Bei jeder Temperatur werden nach dem einschwingen 100 Werte erfasst.
        # 2. Mit diesen 100 Werten wird mittels des Excel-Auswerte-Blatt das Rauschen errechnet.

        #englisch below:
        # 1. At each temperature, 100 values are detected after settling.
        # 2. With these 100 values, the noise is calculated by means of the Excel evaluation sheet.

        S_w2rep("Values for Noise measurement are collected \n\n");

        foreach my $Noise_messDurchlaeufe ( 1 .. 100 ) {    #100 Iteration for normal run

            #foreach - loop for capture the values for Noise determination

            ## steady value is passed to excel result
            $SMIx_templable_raw_value = PRD_Read_Memory( $tcpar_Internal_Lable_SMIx_TemperaturSignal, { memoryContentsAsInteger => 1 } );
            $SMIx_temp_Celsius1 = $SMIx_templable_raw_value / 200 + 50;    #Berechnung der IST Temp im SMI

            S_add2eval_collection( 'SensorTemp SMIx 0', $SMIx_temp_Celsius1 );

            ## Bus-Frame read and passed to excel
            ( $FieldBus_TemperaturSignal, $Unit ) = FR_read_flxr_signal( $tcpar_FieldBus_TemperaturSignal, 'phys' );    #get Signal

            S_w2rep( "read out SMIx_temp_Celsius = $SMIx_temp_Celsius1 �C  \n\n", 'blue' );

            $Oven_Temp = TEMP_get_temperature();
            S_add2eval_collection( 'OvenTemp', $Oven_Temp );
            S_w2rep( "Oven Temp is : $Oven_Temp �C  \n\n", 'blue' );

            ####################################
            # Write a formatted and unformatted string, row and column notation.

            $worksheet2->write( $row2, 0, $Date_Oven_start,           $format );     #A
            $worksheet2->write( $row2, 1, $Time_Oven_start,           $format );     #B
            $worksheet2->write( $row2, 2, $Time_Oven_ready,           $format );     #C
            $worksheet2->write( $row2, 3, $Time_Sensor_settled,       $format3 );    #D
            $worksheet2->write( $row2, 4, $temperature,               $format2 );    #E
            $worksheet2->write( $row2, 5, $Oven_Temp,                 $format4 );    #F
            $worksheet2->write( $row2, 6, $SMIx_temp_Celsius1,        $format3 );    #G
            $worksheet2->write( $row2, 7, $FieldBus_TemperaturSignal, $format3 );    #H
            $worksheet2->write( $row2, 8, $Response_Time_internSMIx,  $format3 );    #I
            $worksheet2->write( $row2, 9, $Response_BUS_Time,         $format3 );    #J
            $row2++;

            S_wait_ms('1000');                                                       # Each sec one value

        }

        ########################################
        ####### Noise Measurement ENDE #########
        ########################################

        S_w2rep("->completed \n\n");

        #############################################
        ##############      EXCEL       #############
        #############################################

        # Excel-Position-Determination

        $worksheet->write( $row, 0, $Date_Oven_start,           $format );     #A
        $worksheet->write( $row, 1, $Time_Oven_start,           $format );     #B
        $worksheet->write( $row, 2, $Time_Oven_ready,           $format );     #C
        $worksheet->write( $row, 3, $Time_Sensor_settled,       $format3 );    #D
        $worksheet->write( $row, 4, $temperature,               $format2 );    #E
        $worksheet->write( $row, 5, $Oven_Temp,                 $format4 );    #F
        $worksheet->write( $row, 6, $SMIx_temp_Celsius1,        $format3 );    #G
        $worksheet->write( $row, 7, $FieldBus_TemperaturSignal, $format3 );    #H
        $worksheet->write( $row, 8, $Response_Time_internSMIx,  $format3 );    #I
        $worksheet->write( $row, 9, $Response_BUS_Time,         $format3 );    #J
        $row++;

        S_w2rep("Values for XLS: \n\n");
        $worksheet3->write( $row3, 0, $Date_Oven_start, $format );             #A
        S_w2rep( "Date: $Date_Oven_start \n", 'blue' );
        $worksheet3->write( $row3, 1, $Time_Oven_start, $format );             #B
        S_w2rep( "Time Oven started: $Time_Oven_start \n", 'blue' );
        $worksheet3->write( $row3, 2, $Time_Oven_ready, $format );             #C
        S_w2rep( "Time Oven ready: $Time_Oven_ready \n", 'blue' );
        $worksheet3->write( $row3, 3, $Time_Sensor_settled, $format3 );        #D
        S_w2rep( "Time Temperature is settled: $Time_Sensor_settled \n", 'blue' );
        $worksheet3->write( $row3, 4, $temperature, $format2 );                #E
        S_w2rep( "OvenTemp_Target $temperature �C \n", 'blue' );
        $worksheet3->write( $row3, 5, $Oven_Temp, $format4 );                  #F
        S_w2rep( "OvenTemp_actually $Oven_Temp �C \n", 'blue' );
        $worksheet3->write( $row3, 6, $SMIx_temp_Celsius1, $format3 );         #G
        S_w2rep( "SMIx_1: $SMIx_temp_Celsius1 �C \n", 'blue' );
        $worksheet3->write( $row3, 7, $FieldBus_TemperaturSignal, $format3 );    #H
        S_w2rep( "Temperature-Signal at Bus: $FieldBus_TemperaturSignal �C \n", 'blue' );
        $worksheet3->write( $row3, 8, $Response_Time_internSMIx, $format3 );     #I
        S_w2rep( "ResponseTime of SMIx: $Response_Time_internSMIx \n", 'blue' );
        $worksheet3->write( $row3, 9, $Response_BUS_Time, $format3 );            #J
        S_w2rep( "ResponseTime at Bus: $Response_BUS_Time \n\n\n", 'blue' );
        $row3++;

        $worksheet4->write( $row4, 0,  $Temp_Oven_start, $format );              #A
        $worksheet4->write( $row4, 1,  $Temp_Oven_diff,  $format );              #B
        $worksheet4->write( $row4, 2,  $Oven_delta_Time, $format );              #F
        $worksheet4->write( $row4, 3,  $Temp_SMIx_start, $format );              #C
        $worksheet4->write( $row4, 7,  $Temp_SMIx_ready, $format );              #D
        $worksheet4->write( $row4, 8,  $Temp_SMIx_diff,  $format );              #E
        $worksheet4->write( $row4, 9,  $Temp_BUS_start,  $format );              #E
        $worksheet4->write( $row4, 10, $Temp_BUS_ready,  $format );              #F
        $row4++;

        #############################################
        ##############      .CSV       ##############
        #############################################

        open( EVAL, ">>$filename_csv" ) || S_set_error("Couldn't open '$filename_csv' file!!!");

        print EVAL "$Date_Oven_start;$Time_Oven_start;$Time_Oven_ready;$Time_Sensor_settled;$temperature;$Oven_Temp;$SMIx_temp_Celsius1;$FieldBus_TemperaturSignal;$Response_Time_internSMIx;$Response_BUS_Time;\n";

        close EVAL;

    }

    return 1;

}

###################################################################################################################

#### EVALUATE TC #####
sub TC_evaluation {

    return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

    PRD_Read_Fault_Memory('BOSCH');

    $workbook->close();

    return 1;
}

1;

__END__
