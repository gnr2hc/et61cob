#### TEST CASE MODULE
package TC_SMI_TGT_RIDT_stim;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.2 $;
our $HEADER  = q$Header: VDS/ACUROT/TC_SMI_TGT_RIDT_stim.pm 1.2 2019/08/08 21:46:15ICT Prosch Christian (CC-PS/EPS2) (PHC2SI) develop  $;

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_TEMPERATURE;
use LIFT_ProdDiag;
use LIFT_can_access;
use LIFT_labcar;
use LIFT_CSM;
use FuncLib_VDS;

##################################

our $PURPOSE = "Stimulation of the TGT and RIDT test for VDS functionality";

# DOCUMENTATION

=head1 TESTCASE MODULE

TC_SMI_TGT_RIDT_stim

=head1 PURPOSE

	Stimulation of the TGT and RIDT test for SMI verification

=head1 TESTCASE DESCRIPTION

Does the stimulation part of the TGT (Temperature Gradient Test) and RIDT (Run In Drift Test) for VDS functionality.
For the TGT the temperature of the ACUROT is changed from room temperature (23�C) to low temperature (-40�C) and then to high temperature (85�C).
As long as the temperature is changing the SMIxy verification service is sent on PD every 60s and the ECU responses are recorded in a CAN trace.
Before each temperature (room, low and high) the RIDT is performed: After a waiting time 
($tcpar_wait_time_before_RIDT_s, e.g. 1 hour so that the desired temperature is also inside the ECU)
the PD sensor verification service ('0D' for SMI7, '0E' for SMI8 sensors) is sent on PD every 60s and the ECU responses are recorded in the same field bus trace as for the TGT.

NOTE: With standard settings this test will run for approx. 11-12 hours !!! 

I<B<Preconditions>>

The following functions must be configured in LIFT_testbenches:

    'Functions' => {
        'Labcar' => {
            'power_Ubat' => <device>, # e.g. TSG4, TOE1, NIDAQ
        },

        'CAN_Access' => {
            'basic' =>  'CANoe',
        },

        'PD' => 'PD',

        'Temperature' => {
            'get'     =>   'VOETSCH',
            'set'     =>   'VOETSCH',
        },

        'Motion' => {
           'Position' => ACUROT, 
           'Rotate'   => ACUROT,
        },
    },

The init campaign shall initialize the functions via EQUIP_init_testbench. 

LIFT_CSM (Container Storage Management) must be configured with 2 paths in your ProjectConst.pm:

    'CSM' => {
         'LocalWorkingArea_Path'    => 'C:\TurboLIFT\CSM_Local_Working_Area', # this is the path where the CAN traces will be stored
         'StorageArea_Path'         => 'C:\temp',                             # currently not used
    },


The ECU shall be placed in the ACUROT with az = 1.

The Canoe project must be prepared for LIFT control like described here:
L<https://connect.bosch.com/wikis/home?lang=de-de#!/wiki/Wad0c302c3442_4748_8eef_7d10157fb564/page/Control%20CANoe%20Trace%20logging>

In short: add 2 files from TurboLIFT template project in your Canoe project configuration:

    System variables: Template\config\Tools\CANoe\LIFT_CAN_access\configuration\ComCtrlSysVars.xml
    CAPL node:        Template\config\Tools\CANoe\LIFT_CAN_access\nodes_template\LIFT_can_control.can

I<B<Initialisation>>

	Call TEMP_ and PD_ functions to make sure that those devices work properly before starting the actual test

I<B<Stimulation and Measurement>>

	go to room temperature
	wait until the RIDT can start
	start the CAN trace
	do the RIDT at room temperature
	go to low temperature
	do the TGT until low temperature reached
	wait until the RIDT can start
	do the RIDT at low temperature
	go to high temperature
	do the TGT until high temperature reached
	wait until the RIDT can start
	do the RIDT at high temperature
	stop and store the CAN trace
	make a copy of the trace in the same folder

I<B<Evaluation>>

	none, this will be done in a separate test case: TC_SMI_TGT_RIDT_eval

I<B<Finalisation>>

	go to room temperature

=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' = Purpose of the Testcase
    SCALAR 'project_ID' = Unique project ID which will be used in evaluation test case to identify the data container.
	SCALAR 'number_of_samples' = Number of samples for PD SMI verification service 
	SCALAR 'wait_time_before_RIDT_s' = Waiting time before the RIDT can start (in s)
	SCALAR 'duration_RIDT_s' = Duration of the RIDT (in s)

=head2 PARAMETER EXAMPLES

	[TC_SMI_TGT_RIDT_stim.example]
	purpose	= 'SMI700/SMI710'
    project_ID = 'ProjectXY_Var1_SampleA'
    sensor_type = 'SMI7'
	number_of_samples = 1000
	wait_time_before_RIDT_s = 3600
	duration_RIDT_s = 3600

=cut

#PARAMETERS
################ Parameters from .par file ###################
my ( $tcpar_purpose, $tcpar_project_ID, $tcpar_sensor_type, $tcpar_number_of_samples, $tcpar_wait_time_before_RIDT_s, $tcpar_duration_RIDT_s );

################ global parameter declaration ###################
#add any global variables here

my $room_temperature     = 23;
my $low_temperature      = -41;
my $high_temperature     = 86;
my $measure_time_delta_s = 60;
my $bus_recording_time_s = 5;
my $timeoutDuration_s    = 7200;
my $tgtPostRunDuration_s = 1200;

my $measureTimesRIDT_href = {
    'segment1' => {
        'interval_s'     => 15,    # must be > $bus_recording_time_s
        'until_time_min' => 3,
    },
    'segment2' => {
        'interval_s'     => 60,    # must be > $bus_recording_time_s
        'until_time_min' => 60,
    },
};

my ( $sensorConfig_href, $faultsBefore_href, $faultsAfter_href );

###############################################################

sub TC_set_parameters {

    $tcpar_purpose                 = S_read_mandatory_testcase_parameter('purpose');
    $tcpar_project_ID              = S_read_mandatory_testcase_parameter('project_ID');
    $tcpar_sensor_type             = S_read_mandatory_testcase_parameter('sensor_type');
    $tcpar_number_of_samples       = S_read_mandatory_testcase_parameter('number_of_samples');
    $tcpar_wait_time_before_RIDT_s = S_read_mandatory_testcase_parameter('wait_time_before_RIDT_s');
    $tcpar_duration_RIDT_s         = S_read_mandatory_testcase_parameter('duration_RIDT_s');

    if ( uc($tcpar_sensor_type) eq 'SMI7' ) {

        # SMI7
        $sensorConfig_href = {
            'sensor_type'    => 'SMI7',
            'Sensor1_Rate'   => 'LF_processed',
            'Sensor1_ACC1'   => 'LF_processed',
            'Sensor1_ACC2'   => 'LF_processed',
            'Sensor2_Rate'   => 'LF_processed',
            'Sensor2_ACC1'   => 'LF_processed',
            'Sensor2_ACC2'   => 'LF_processed',
            'Sensor3_Rate'   => 'LF_processed',
            'Sensor3_ACC1'   => 'LF_processed',
            'Sensor3_ACC2'   => 'LF_processed',
            'Sensor4_Rate'   => 'LF_processed',
            'Sensor4_ACC1'   => 'LF_processed',
            'Sensor4_ACC2'   => 'LF_processed',
            'amount_samples' => $tcpar_number_of_samples,
        };
    }
    else {
        # SMI8
        $sensorConfig_href = {
            'sensor_type'    => 'SMI8',
            'ALL'            => 'processed',
            'amount_samples' => $tcpar_number_of_samples,
        };
    }

    return 1;
}

sub TC_initialization {

    S_teststep( "prepare test equipment", 'AUTO_NBR' );
    CSM_init() || return;
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

    TEMP_get_temperature();

    S_teststep( "read fault memory", 'AUTO_NBR' );
    $faultsBefore_href = PRD_Read_Fault_Memory('BOSCH');

    PRD_Sensor_Verification($sensorConfig_href);

    return 1;
}

sub TC_stimulation_and_measurement {

    my $timeoutCounter;

    S_teststep( "go to room temperature", 'AUTO_NBR' );
    TEMP_setTargetTemperature($room_temperature);
    TEMP_waitForTemperature(120);

    S_teststep( "Prepare bus trace", 'AUTO_NBR' );
    CA_simulation_start();

    S_teststep( "do the RIDT at room temperature", 'AUTO_NBR' );
    Do_RIDT($room_temperature);

    S_teststep( "go to low temperature", 'AUTO_NBR' );
    TEMP_setTargetTemperature($low_temperature);
    TEMP_waitForTemperature(120);

    S_teststep( "do the RIDT at low temperature", 'AUTO_NBR' );
    Do_RIDT($low_temperature);

    S_teststep( "go to high temperature", 'AUTO_NBR' );
    TEMP_setTargetTemperature($high_temperature);

    S_teststep( "do the TGT until high temperature reached", 'AUTO_NBR' );
    Do_TGT($high_temperature);

    S_teststep( "do the RIDT at high temperature", 'AUTO_NBR' );
    Do_RIDT($high_temperature);

    S_teststep( "go to low temperature", 'AUTO_NBR' );
    TEMP_setTargetTemperature($low_temperature);

    S_teststep( "do the TGT until low temperature reached", 'AUTO_NBR' );
    Do_TGT($low_temperature);

    S_teststep( "go to room temperature", 'AUTO_NBR' );
    TEMP_setTargetTemperature($room_temperature);
    TEMP_waitForTemperature(120);

    # second RIDT at room temperature for checking the repeatability of the measurement
    S_teststep( "do the RIDT at room temperature", 'AUTO_NBR' );
    Do_RIDT($room_temperature);

    S_teststep( "read fault memory", 'AUTO_NBR' );
    $faultsAfter_href = PRD_Read_Fault_Memory('BOSCH');

    S_teststep( "stop and store the CAN trace", 'AUTO_NBR' );
    my $canTraceName = 'C:\temp\TGT_RIDT.asc';
    CA_trace_store($canTraceName);
    S_teststep( "CAN trace stored as $canTraceName", 'AUTO_NBR' );

    CA_simulation_stop();

    S_teststep( "store trace file in CSM container for later evaluation", 'AUTO_NBR' );
    VDS_StoreDataContainer( [$canTraceName], [ $tcpar_project_ID, 'TGT_RIDT' ], {} );

    return 1;
}

sub TC_evaluation {

    return 1;
}

sub TC_finalization {

    LC_ECU_Off();
    TEMP_setTargetTemperature($room_temperature);
    TEMP_waitForTemperature(120);

    return 1;
}

sub Do_RIDT {
    my $temperature = shift;

    S_w2log( 1, "wait until the RIDT can start", 'AUTO_NBR' );
    LC_ECU_Off();
    S_wait_ms( $tcpar_wait_time_before_RIDT_s * 1000 );
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

    # loop over all measurement segments defined in $measureTimesRIDT_href
    my $start_time_min = 0;
    foreach my $segment ( sort keys %{$measureTimesRIDT_href} ) {
        my $interval_s     = $measureTimesRIDT_href->{$segment}{'interval_s'};
        my $until_time_min = $measureTimesRIDT_href->{$segment}{'until_time_min'};

        # calculate the number of measurements that must be taken in the current segment
        my $numberOfMeasurements = ( $until_time_min - $start_time_min ) * 60 / $interval_s;

        # loop over all measurements in the current segment
        foreach my $counter_RIDT ( 1 .. $numberOfMeasurements ) {
            CA_trace_start();
            S_w2log( 1, "Send SMI verification request for RIDT at $temperature �C # $counter_RIDT for $segment\n" );
            PRD_Sensor_Verification($sensorConfig_href);
            S_wait_ms( $bus_recording_time_s * 1000 );
            CA_trace_stop();
            S_wait_ms( ( $interval_s - $bus_recording_time_s ) * 1000 );
        }

        # set start time for next segment
        $start_time_min = $until_time_min;
    }

    return 1;
}

sub Do_TGT {
    my $targetTemperature = shift;

    my $temperatureReached = 0;
    my $postRunCounter     = 0;
    my $tgtFinished        = 0;
    my $timeoutCounter     = 1;
    while ( not $tgtFinished ) {
        my $currentTemperature = TEMP_get_temperature();

        # if target temperature is reached we set the $temperatureReached flag and start incrementing the post-run counter
        if ( abs( $currentTemperature - $targetTemperature ) <= 1 or $temperatureReached ) {
            $temperatureReached = 1;
            $postRunCounter++;
        }
        CA_trace_start();
        S_w2log( 1, "Send SMI verification request for TGT towards $targetTemperature � # $timeoutCounter (current chamber temperature = $currentTemperature)\n" );
        PRD_Sensor_Verification($sensorConfig_href);
        S_wait_ms( $bus_recording_time_s * 1000 );
        CA_trace_stop();

        # wait for $measure_time_delta_s between two measurments
        S_wait_ms( ( $measure_time_delta_s - $bus_recording_time_s ) * 1000 );

        # set $tgtFinished flag if $postRunCounter has reached the equivalent of the defined time ($tgtPostRunDuration_s)
        if ( $postRunCounter > $tgtPostRunDuration_s / $measure_time_delta_s ) {
            $tgtFinished = 1;
        }
        $timeoutCounter++;
        last if ( $timeoutCounter > $timeoutDuration_s / $measure_time_delta_s );
    }
    return 1;

}

1;
