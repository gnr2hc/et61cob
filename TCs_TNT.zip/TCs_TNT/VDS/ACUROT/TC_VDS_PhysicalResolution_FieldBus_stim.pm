#### TEST CASE MODULE
package TC_VDS_PhysicalResolution_FieldBus_stim;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.2 $;
our $HEADER  = q$Header: VDS/ACUROT/TC_VDS_PhysicalResolution_FieldBus_stim.pm 1.2 2019/04/01 16:57:30ICT Andrews Xavier Jesu (RBEI/EVS) (XAA1COB) develop  $;

#### INCLUDE ENGINE MODULES ####

#use INCLUDES_Project;    #necessary
use LIFT_general;
use LIFT_can_access;
use LIFT_flexray_access;
use LIFT_motion;
use LIFT_labcar;
use LIFT_CSM;
use LIFT_PD;
use LIFT_TEMPERATURE;
use LIFT_TSG4;
use LIFT_equipment;
use FuncLib_VDS;
use Math::Trig;

##################################

our $PURPOSE = "Test of PhyisicalResolution - stimulation part";

# DOCUMENTATION

=head1 TESTCASE MODULE

TC_VDS_PhysicalResolution_FieldBus_stim

=head1 PURPOSE

From HLD: 

The test case shall set different Rotation rates / accelerations (with determined step) during an specific time, and measure the samples on the BUS (during this time). 
Then calculate the Resolution using the following formula:
            
            RES(n) = y(n) - y(n-1)  for n = 1 ... 20

 y(n) is the average of the measured samples the Rate/acceleration set.
 y(n-1) is the average of the measured samples the previous Rate/acceleration set.
 
 All the calculated RES should be inside the Range according to Customer Requirements.
 
=head1 TESTCASE DESCRIPTION

This a pure stimulation test case to record test data. 
The corresponding evaluation test case (TC_VDS_PhysicalResolution_FieldBus_stim.pm) must be executed after this test 
to evaluate the recorded data.

NOTE: With standard settings this test will run for approx. 7 hours for acceleration and 10 min for Rotation !!!

I<B<Preconditions>>


The following functions must be configured in LIFT_testbenches:

    'Functions' => {
        'Labcar' => {
            'power_Ubat' => <device>, # e.g. TSG4, TOE1, NIDAQ
        },

        'CAN_Access' => {
            'basic' =>  'CANoe',
        },

        'PD' => 'PD',

        'Temperature' => {
            'get'     =>   'VOETSCH',
            'set'     =>   'VOETSCH',
        },

        'Motion' => {
           'Position' => ACUROT, 
           'Rotate'   => ACUROT,
        },
    },


The init campaign shall initialize the functions via EQUIP_init_testbench. 

LIFT_CSM (Container Storage Management) must be configured with 2 paths in your ProjectConst.pm:

    'CSM' => {
         'LocalWorkingArea_Path'    => 'C:\TurboLIFT\CSM_Local_Working_Area', # this is the path where the CAN traces will be stored
         'StorageArea_Path'         => 'C:\temp',                             # currently not used
    },

The ECU shall be placed in the ACUROT on the appropriate table with with appropriate mounting depending on $acurot_table and $tcpar_moving_direction.


I<B<Initialisation>>

    - Connect ECU in '$tcpar_AcuRot_Table'
    - Set temperature to 'temperature'.
    - Switch ECU ON.
    - Wait 60 min

I<B<Stimulation and Measurement>>

    - Set 'MovingDirection' to 'StartValue'
    - Start network trace.
    - Start PD Service storing.
    - Wait 'measurement_duration_s'
    - Stop network trace.
    - Stop PD Service Storing.
    - Save Data to Data Container.
    - Set 'MovingDirection' to 0.
    - Wait 10 Sec
    - Repeat the Steps with 'StartValue' = 'StartValue'+'Step' 

I<B<Evaluation>>

    - nothing

I<B<Finalisation>>

    - nothing

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

    SCALAR 'purpose' = Verify that the Physical Resolution of the sensor Fulfills the customer requirements
    SCALAR 'project_ID' = Unique project ID for data container (same as in evaluation test case).
    SCALAR 'AcuRot_Table' = Table where the ECU should be connected in the Acu Rot. Should be 'upper' or 'lower'
    SCALAR 'temperature' = Temperature to be set for the Test
    SCALAR 'MovingDirection' = type of measurement for the test. Can be rotation rate ('wx', 'wy', 'wz') and/or acceleration ('ax', 'ay', 'az')
    SCALAR 'StartValue' = first value to be set (Acceleration or Rate) in order to start measurements. Should be in �/seg for Rate and in � for Acceleration
    SCALAR 'Step' = step size for incrementing the stimulation value. Should be in �/seg for Rate and in g for Acceleration
    SCALAR 'measurement_duration_s' = Time for CAN measurement
    LIST   'PDVariable' = PD Variables to be monitored with FastDiag
    LIST   'PDVariable_Type' = Type of PDVariable.
    SCALAR 'AmountOfSteps' = (Optional) Amount of Steps to be simulated. default value: 20
    SCALAR 'OnlyOneTrace' = (Optional) if only one big trace containing all the simulated steps in the measurement is desired, this parameter should be set to "yes". Default value is "no", it means, a trace will be stored for each step separately
   
=head2 PARAMETER EXAMPLES

    [TC_VDS_PhysicalResolution_FieldBus_stim.example]
    purpose = 'example'
    project_ID = 'ProjectXY_Var1_SampleA'
    AcuRot_Table = 'upper'
    temperature = 23
    MovingDirection = 'wx'
    StartValue = '10'
    Step = '0.05'
    measurement_duration_s = 20
    PDVariable = @('','')
    PDVariable_Type = @('U8','U16')
    AmountOfSteps = 20
    OnlyOneTrace = 'no'
    
=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_project_ID;
my $tcpar_AcuRot_Table;
my $tcpar_temperature;
my $tcpar_MovingDirection;
my $tcpar_StartValue;
my $tcpar_Step;
my $tcpar_measurement_duration_s;
my $tcpar_CanIDsNnbr;
my $tcpar_AmountOfSteps;
my $tcpar_OnlyOneTrace;
my @tcpar_PDVariable;
my @tcpar_PDVariable_Type;

################ global parameter declaration ###################
#add any global variables here
my ($measurement_Duration_ms, $table, $traceFiles_href);
my @traceFiles;

###############################################################

sub TC_set_parameters {
    
    $tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
    $tcpar_project_ID =  S_read_mandatory_testcase_parameter( 'project_ID' );
    $tcpar_AcuRot_Table =  S_read_mandatory_testcase_parameter( 'AcuRot_Table' );
    $tcpar_temperature =  S_read_optional_testcase_parameter( 'temperature' );
    $tcpar_MovingDirection =  S_read_mandatory_testcase_parameter( 'MovingDirection' );
    $tcpar_StartValue = S_read_mandatory_testcase_parameter( 'StartValue' );
    $tcpar_Step =  S_read_mandatory_testcase_parameter( 'Step' );
    $tcpar_measurement_duration_s =  S_read_mandatory_testcase_parameter( 'measurement_duration_s' );
    $tcpar_CanIDsNnbr = S_read_mandatory_testcase_parameter( 'CanIDsNnbr' );
    @tcpar_PDVariable = S_read_optional_testcase_parameter( 'PDVariable' );
    @tcpar_PDVariable_Type = S_read_optional_testcase_parameter( 'PDVariable_Type' );
    $tcpar_AmountOfSteps = S_read_optional_testcase_parameter( 'AmountOfSteps' );
    $tcpar_OnlyOneTrace = S_read_optional_testcase_parameter( 'OnlyOneTrace' );
    
    $measurement_Duration_ms = $tcpar_measurement_duration_s*1000;
     
     # check validity of $tcpar_down_direction
    if ( $tcpar_MovingDirection !~ /^[aw][xyz]$/i ) {
        S_set_error("Given parameter 'MovingDirection' = '$tcpar_MovingDirection' is none of the following allowed:  'wx', 'wy', 'wz', 'ax', 'ay', 'az'");
        return 0;
    }

     # check validity of $tcpar_acurot_table
    if ( $tcpar_AcuRot_Table =~ /upper/i ) {
        $table = 'H'; # horizontal axis = upper table
    }
    elsif ( $tcpar_AcuRot_Table =~ /lower/i ) {
        $table = 'V'; # vertical axis = lower table
    }
    else {
        S_set_error("Test case parameter 'acurot_table' must be either 'upper' or 'lower'");
    }
    
    if(not defined $tcpar_temperature ){
        $tcpar_temperature = 23;
    }
    
    if(not defined $tcpar_AmountOfSteps ){
        $tcpar_AmountOfSteps = 20;
    }
    
    if(not defined $tcpar_OnlyOneTrace ){
        $tcpar_OnlyOneTrace = 'no';
    }
    if(($tcpar_OnlyOneTrace ne 'yes') and ($tcpar_OnlyOneTrace ne 'no')){
        
        S_set_error("Test case parameter 'OnlyOneTrace' must be either 'yes' or 'no'");
    }
   
    #for Acceleration sensors, convert the Step value (given in g) to deg.
     
   return 1;
}

sub TC_initialization {

    CSM_init() || return;

    $traceFiles_href = {};

	CA_simulation_start();
	S_wait_ms(1000);
    #CA_trace_stop();
    #CA_trace_store('C:\temp\dummy.asc'); # to make sure that a new trace will be started in TC_stimulation_and_measurement
   
    S_teststep( "Set temperature to $tcpar_temperature deg.", 'AUTO_NBR' );
    TEMP_setTargetTemperature($tcpar_temperature);
    TEMP_waitForTemperature(120);
    
    
    S_teststep( "Switch ECU On.", 'AUTO_NBR' );
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');
    
	PD_ECUlogin();
	
    S_teststep( "Wait to make the ECU the right temperature", 'AUTO_NBR' );
    #S_wait_ms(3600000);
    S_wait_ms(10000);
    
    return 1;
}

sub TC_stimulation_and_measurement {

     
    S_teststep( "Set Moving direction $tcpar_MovingDirection to Initial Value", 'AUTO_NBR' ); 
    
    my ($ActualValue, $ActualValue_g);
    
    $ActualValue = $tcpar_StartValue; 
    
    my $FD_trace = $main::REPORT_PATH ."/FD_Trace".$tcpar_MovingDirection.".txt";
                
    if (($tcpar_OnlyOneTrace eq 'yes') and (defined @tcpar_PDVariable) and (defined @tcpar_PDVariable_Type) ){
        
        PD_StartFastDiagName( $FD_trace, @tcpar_PDVariable, @tcpar_PDVariable_Type, [ 0, 0 ], $tcpar_CanIDsNnbr);
		
    }
    else{
        S_w2rep("FD Trace will not be stored because PDVariable and PDVariable_type not given in Parameters") if ($tcpar_OnlyOneTrace eq 'no');
        S_w2rep("FD Trace is being stored since the begining of the Test in an unique Trace. ") if ($tcpar_OnlyOneTrace eq 'yes');

    }
	CA_trace_stop();
    CA_trace_store('C:\temp\dummy.asc'); # to make sure that a new trace will be started in TC_stimulation_and_measurement
	my $i = 0;
    for (0...$tcpar_AmountOfSteps){
           my $canTraceName;
           my $position_deg;
           $i++;
           my $FD_trace = $main::REPORT_PATH ."/FD_Trace".$tcpar_MovingDirection."_".$ActualValue.".txt";
                
           if ($tcpar_MovingDirection =~ /^w/){
          
               S_teststep( "Set Moving direction $tcpar_MovingDirection to $ActualValue �/s", 'AUTO_NBR' );     
               MOT_Rotate( $table, $ActualValue );
           }
           else{
                
                S_teststep( "Set Moving direction $tcpar_MovingDirection to $ActualValue �", 'AUTO_NBR' );     
                MOT_Position( $table, $ActualValue );
                S_wait_ms(500);
                $position_deg = MOT_GetPosition( $table );
                S_teststep( "Actual Position from System:  $position_deg �", 'AUTO_NBR' );
                S_wait_ms(5000);               
           }

            S_teststep( "Start Bus Measurement", 'AUTO_NBR' );       
            #Start measurements
            
            CA_trace_start();
            
            if (($tcpar_OnlyOneTrace eq 'no') and (defined @tcpar_PDVariable) and (defined @tcpar_PDVariable_Type) ){
                PD_StartFastDiagName( $FD_trace, @tcpar_PDVariable, @tcpar_PDVariable_Type, [ 0, 0 ], $tcpar_CanIDsNnbr);
            }
            else{
                S_w2rep("FD Trace will not be stored because PDVariable and PDVariable_type not given in Parameters");
            }
            S_teststep( "Wait $measurement_Duration_ms msec", 'AUTO_NBR' );                
            S_wait_ms($measurement_Duration_ms);  #recording TIme
            
            S_teststep( "Stop Bus Measurement and store the Trace", 'AUTO_NBR' );       
            #Stop measurements
            if ($tcpar_OnlyOneTrace eq 'no'){    
                CA_trace_stop();
                
                #Store Can Trace
                $canTraceName = 'C:\temp\PhysicalResolution_' . $tcpar_MovingDirection . '_' . $i . '.asc';
                           
                CA_trace_store($canTraceName);
                       
                if((defined @tcpar_PDVariable ) and (defined @tcpar_PDVariable_Type )){
                PD_StopFastDiag();
                }
                else{
                    S_w2rep("FD Trace not stored because PDVariable and PDVariable_type not given in Parameters, or only one Big Trace stored");
                    
                }
                # push trace file name into $traceFiles_href for CSM storage later
                $traceFiles_href ->{$tcpar_MovingDirection}{$ActualValue} = $canTraceName;
                push( @traceFiles, $traceFiles_href ->{$tcpar_MovingDirection}{$ActualValue} );                    
            }
            
            
            S_teststep( "Set Axis $tcpar_MovingDirection back to 0", 'AUTO_NBR' ); 
            
            # stop and zero position to avoid Algo Watchdog problem
            MOT_Stop($table) if ($tcpar_MovingDirection =~ /^w/);             # stop the rotation
            MOT_Position( $table, 0 ); # go to 0 position
      
            
            S_teststep( "Wait 10s", 'AUTO_NBR' );    
            S_wait_ms(10000);         

            S_teststep( "Increment Moving Direction in $tcpar_Step units", 'AUTO_NBR' );                      
            
            if ($tcpar_MovingDirection =~ /^a/){
                
                if($tcpar_MovingDirection eq 'az'){
                    $ActualValue_g = cos (deg2rad($ActualValue)); #convert Actual Value in deg to g
                    S_w2log(3,"Actual Value in �: = $ActualValue �, converted to $ActualValue_g g ","Blue");
                    my $nextActualValue = $ActualValue_g + $tcpar_Step; #add the step in g
                    $ActualValue = rad2deg( acos($nextActualValue)); #convert total angle (actual +step) from g to deg)                                  
                    S_w2log(3,"Next Value to be simulated in g: = $nextActualValue g, converted to $ActualValue � ","Blue");                                                               
                   
                }
                else{
                    $ActualValue_g = sin (deg2rad($ActualValue)); #convert Actual Value in deg to g
                    S_w2log(3,"Actual Value in �: = $ActualValue �, converted to $ActualValue_g g ","Blue");
                    my $nextActualValue = $ActualValue_g + $tcpar_Step; #add the step in g
                    $ActualValue = rad2deg( asin($nextActualValue)); #convert total angle (actual +step) from g to deg)                                  
                    S_w2log(3,"Next Value to be simulated in g: = $nextActualValue g, converted to $ActualValue � ","Blue");                                             
                    
                }
        
            }
            else{
                                   
                $ActualValue= $ActualValue + $tcpar_Step; #increment step for next measurement                 
            }            
    } 
    
    if ($tcpar_OnlyOneTrace eq 'yes'){    #stop and store the only big trace
                CA_trace_stop(); 
                if((defined @tcpar_PDVariable ) and (defined @tcpar_PDVariable_Type )){
                
                PD_StopFastDiag();
                }
                else{
                    S_w2rep("FD Trace not stored because PDVariable and PDVariable_type not given in Parameters, or only one Big Trace stored");
                    
                }      
                #Store Can Trace
                my $canTraceName = 'C:\temp\PhysicalResolution_' . $tcpar_MovingDirection . '.asc';
                           
                CA_trace_store($canTraceName);
                $traceFiles_href ->{$tcpar_MovingDirection}{'OnlyTrace'} = $canTraceName;    
                push( @traceFiles,$traceFiles_href ->{$tcpar_MovingDirection}{'OnlyTrace'});                          
    }
	
	CA_simulation_stop();
    
    S_teststep( "Add trace files to data container.", 'AUTO_NBR' );
    
    VDS_StoreDataContainer( \@traceFiles, [ $tcpar_project_ID, 'PhysicalResolution', $tcpar_MovingDirection], {} );

    return 1;
}

sub TC_evaluation {
    
    S_w2rep( "No Evaluation Needed, will be performed in Evaluation TC"); 
    
    return 1;
}

sub TC_finalization {
   
    LC_ECU_Off();
    TEMP_setTargetTemperature(23) ;
    TEMP_waitForTemperature(120);
    
    return 1;
}


1;
