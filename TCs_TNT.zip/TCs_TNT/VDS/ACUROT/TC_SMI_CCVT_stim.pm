#### TEST CASE MODULE
package TC_SMI_CCVT_stim;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER  = q$Header: VDS/ACUROT/TC_SMI_CCVT_stim.pm 1.1 2019/08/08 21:05:40ICT Prosch Christian (CC-PS/EPS2) (PHC2SI) develop  $;

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_TEMPERATURE;
use LIFT_ProdDiag;
use LIFT_motion;
use LIFT_can_access;
use LIFT_labcar;
use FuncLib_VDS;
use LIFT_CSM;
use Math::Trig;

##################################

our $PURPOSE = "Stimulation of the CCVT test for VDS functionality";

# DOCUMENTATION

=head1 TESTCASE MODULE

TC_SMI_CCVT_stim

=head1 PURPOSE

    Stimulation of the CCVT test for SMI verification

=head1 TESTCASE DESCRIPTION

Does the stimulation part of the CCVT (Characteristic Curve Value Test) of the SMI verification test.
For the CCVT the temperature of the ACUROT is changed from room temperature (23�C) to low temperature (-40�C) and then to high temperature (85�C).
For each temperature (room, low and high) a set of characteristic rotation rates and/or accelerations (depending on $tcpar_moving_directions) 
are set on the ACUROT and for each value the PD sensor verification service ('0D' for SMI7, '0E' for SMI8 sensors) is sent on PD and the ECU responses are recorded in a CAN trace.
For setting accelerations statically the earth's gravity is used.

NOTE: With standard settings this test will run with one mounting for approx. 9 hours !!!

The test case is optimized for run time and allows to test more than one sensor channel per temperature with one ECU mounting.
Typically the following mountings and sensor channels should be configured in test case parameters:

    1) Mount ECU at lower rotation table, rotation around az
    acurot_table = 'lower'
    moving_directions = @( 'wz' )
    
    2) Mount ECU at upper rotation table, rotation around x-axis
    acurot_table = 'upper'
    moving_directions = @( 'wx', 'ay' )

    3) Mount ECU at upper rotation table, rotation around y-axis
    acurot_table = 'upper'
    moving_directions = @( 'wy', 'ax', 'az' )
    az_angle_offset = 90

    4) Mount ECU at upper rotation table, rotation around z-axis (to measure cross axis sensitivity of az)
    acurot_table = 'upper'
    moving_directions = @( 'ax' )

I<B<Preconditions>>

The following functions must be configured in LIFT_testbenches:

    'Functions' => {
        'Labcar' => {
            'power_Ubat' => <device>, # e.g. TSG4, TOE1, NIDAQ
        },

        'CAN_Access' => {
            'basic' =>  'CANoe',
        },

        'PD' => 'PD',

        'Temperature' => {
            'get'     =>   'VOETSCH',
            'set'     =>   'VOETSCH',
        },

        'Motion' => {
           'Position' => ACUROT, 
           'Rotate'   => ACUROT,
        },
    },


The init campaign shall initialize the functions via EQUIP_init_testbench. 

LIFT_CSM (Container Storage Management) must be configured with 2 paths in your ProjectConst.pm:

    'CSM' => {
         'LocalWorkingArea_Path'    => 'C:\TurboLIFT\CSM_Local_Working_Area', # this is the path where the CAN traces will be stored
         'StorageArea_Path'         => 'C:\temp',                             # currently not used
    },

The ECU shall be placed in the ACUROT on the appropriate table with with appropriate mounting depending on $tcpar_moving_direction.

The Canoe project must be prepared for LIFT control like described here:
L<https://connect.bosch.com/wikis/home?lang=de-de#!/wiki/Wad0c302c3442_4748_8eef_7d10157fb564/page/Control%20CANoe%20Trace%20logging>

In short: add 2 files from TurboLIFT template project in your Canoe project configuration:

    System variables: Template\config\Tools\CANoe\LIFT_CAN_access\configuration\ComCtrlSysVars.xml
    CAPL node:        Template\config\Tools\CANoe\LIFT_CAN_access\nodes_template\LIFT_can_control.can

I<B<Initialisation>>

    Call TEMP_ and PD_ functions to make sure that those devices work properly before starting the actual test

I<B<Stimulation and Measurement>>

    get input values for rates or accelerations
    go to room temperature
    wait until the CCVT can start
    start the CAN trace
    do the CCVT at room temperature
    go to low temperature
    wait until the CCVT can start
    do the CCVT at low temperature
    go to high temperature
    wait until the CCVT can start
    do the CCVT at high temperature
    stop and store the CAN trace
    make a copy of the trace in the same folder


I<B<Evaluation>>

    none, this will be done in a separate test case: TC_SMI_CCVT_eval

I<B<Finalisation>>

    go to room temperature

=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

    SCALAR 'purpose' = Purpose of the Testcase
    SCALAR 'project_ID' = Unique project ID which will be used in evaluation test case to identify the data container.
    SCALAR 'CAN_trace_prefix' = Prefix for the CAN trace files that shall be stored. Rest of the file name and extension (.asc) will be added by the test case.
    SCALAR 'number_of_samples' = Number of samples for PD SMI verification service 
    SCALAR 'wait_time_before_CCVT_s' = Waiting time before the CCVT can start (in s)
    SCALAR 'acurot_table' = 'upper' or 'lower' table of the ACUROT
    LIST   'moving_directions' = Moving directions with associated maximum stimulation values, either rotation rate ('wx', 'wy', 'wz') and/or acceleration ('ax', 'ay', 'az')
    SCALAR '**_max_stimulation_value' = (optional) maximum value for stimulation of **; ** must be one of the values of 'moving_directions'; 
                                        default = 300 (deg/s) for rates and 1 (g) for accelerations
    SCALAR '**_angle_offset' = (optional) angle offset for acceleration ** in deg; ** must be one of the values of 'moving_directions' and is only used for accelerations;
                               this adds an offset to the stimulated angle to make it possible to use the same mounting for e.g. ax and az when rotation axis is y
    SCALAR 'wait_after_PD_ms' = (optional) wait time after PD request to collect CAN data (default = 5000)
    SCALAR 'use_temperature' = (optional) if set to 1 then the test uses 3 temperatures (default), 
                                          if set to 0 then the test runs only for room temperature and does not control any temperature chamber.

=head2 PARAMETER EXAMPLES

    [TC_SMI_CCVT_stim.wz]
    purpose	= 'SMI700/SMI710 wz'
    project_ID = 'ProjectXY_Var1_SampleA'
    CAN_trace_prefix = 'CCVT_roty'
    number_of_samples = 1000
    wait_time_before_CCVT_s = 3600
    moving_directions = @( 'ax', 'az', 'wy' )
    wy_max_stimulation_value = 140
    az_angle_offset = 90
    acurot_table = 'upper'
    wait_after_PD_ms = 10000
    use_temperature = 1

=cut

#PARAMETERS
################ Parameters from .par file ###################
my ( $tcpar_purpose, $tcpar_project_ID, $tcpar_sensor_type, $tcpar_CAN_trace_prefix, $tcpar_number_of_samples, $tcpar_wait_time_before_CCVT_s, @tcpar_moving_directions, $tcpar_acurot_table, $tcpar_wait_after_PD_ms, $tcpar_use_temperature );

################ global parameter declaration ###################
#add any global variables here

my @temperatures = ( 23, -41, 86 );

my ( $sensorConfig_href, $faultsBefore_href, $faultsAfter_href, $table, $directions_href, $traceFiles_href );

###############################################################

sub TC_set_parameters {

    $tcpar_purpose                 = S_read_mandatory_testcase_parameter('purpose');
    $tcpar_project_ID              = S_read_mandatory_testcase_parameter('project_ID');
    $tcpar_sensor_type             = S_read_mandatory_testcase_parameter('sensor_type');
    $tcpar_CAN_trace_prefix        = S_read_mandatory_testcase_parameter('CAN_trace_prefix');
    $tcpar_number_of_samples       = S_read_mandatory_testcase_parameter('number_of_samples');
    $tcpar_wait_time_before_CCVT_s = S_read_mandatory_testcase_parameter('wait_time_before_CCVT_s');
    @tcpar_moving_directions       = S_read_mandatory_testcase_parameter( 'moving_directions', 'byvalue' );
    $tcpar_acurot_table            = S_read_mandatory_testcase_parameter('acurot_table');
    $tcpar_wait_after_PD_ms        = S_read_optional_testcase_parameter('wait_after_PD_ms');
    $tcpar_use_temperature         = S_read_optional_testcase_parameter('use_temperature');

    $tcpar_wait_after_PD_ms = 5000 if not defined $tcpar_wait_after_PD_ms;
    $tcpar_use_temperature  = 1    if not defined $tcpar_use_temperature;

    @temperatures = (23) if not $tcpar_use_temperature;

    if ( uc($tcpar_sensor_type) eq 'SMI7' ) {

        # SMI7
        $sensorConfig_href = {
            'sensor_type'    => 'SMI7',
            'Sensor1_Rate'   => 'LF_processed',
            'Sensor1_ACC1'   => 'LF_processed',
            'Sensor1_ACC2'   => 'LF_processed',
            'Sensor2_Rate'   => 'LF_processed',
            'Sensor2_ACC1'   => 'LF_processed',
            'Sensor2_ACC2'   => 'LF_processed',
            'Sensor3_Rate'   => 'LF_processed',
            'Sensor3_ACC1'   => 'LF_processed',
            'Sensor3_ACC2'   => 'LF_processed',
            'Sensor4_Rate'   => 'LF_processed',
            'Sensor4_ACC1'   => 'LF_processed',
            'Sensor4_ACC2'   => 'LF_processed',
            'amount_samples' => $tcpar_number_of_samples,
        };
    }
    else {
              # SMI8
        $sensorConfig_href = {
            'sensor_type'    => 'SMI8',
            'ALL'            => 'processed',
            'amount_samples' => $tcpar_number_of_samples,
        };
    }

    # check validity of $tcpar_CAN_trace_prefix
    if ( $tcpar_CAN_trace_prefix =~ /^(.+)\.(\w+)$/ ) {
        S_set_error("Given parameter 'CAN_trace_prefix' = '$tcpar_CAN_trace_prefix' must not have a file extension.");
    }

    # check validity of $tcpar_acurot_table
    if ( $tcpar_acurot_table =~ /upper/i ) {
        $table = 'H';    # horizontal axis = upper table
    }
    elsif ( $tcpar_acurot_table =~ /lower/i ) {
        $table = 'V';    # vertical axis = lower table
    }
    else {
        S_set_error("Test case parameter 'acurot_table' must be either 'upper' or 'lower'");
    }

    # check validity of keys in $tcpar_moving_directions_href
    foreach my $direction (@tcpar_moving_directions) {
        if ( $direction !~ /^[aw][xyz]$/ ) {
            S_set_error("The value '$direction' of test case parameter 'moving_directions' is none of the following allowed keys: 'wx', 'wy', 'wz', 'ax', 'ay', 'az'");
        }
        $directions_href->{$direction}{'max_stimulation_value'} = S_read_testcase_parameter( $direction . '_max_stimulation_value' );
        $directions_href->{$direction}{'angle_offset'}          = S_read_testcase_parameter( $direction . '_angle_offset' );
    }

    return 1;
}

sub TC_initialization {

    S_teststep( "prepare test equipment", 'AUTO_NBR' );
    CSM_init() || return;
    $traceFiles_href = {};
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

    TEMP_get_temperature() if $tcpar_use_temperature;

    S_teststep( "read fault memory", 'AUTO_NBR' );
    $faultsBefore_href = PRD_Read_Fault_Memory('BOSCH');

    PRD_Sensor_Verification($sensorConfig_href);

    return 1;
}

sub TC_stimulation_and_measurement {

    foreach my $temperature (@temperatures) {
        S_teststep( "Go to temperature $temperature �C", 'AUTO_NBR' );
        TEMP_setTargetTemperature($temperature) if $tcpar_use_temperature;
        TEMP_waitForTemperature(120) if $tcpar_use_temperature;

        S_teststep( "Wait until the CCVT can start", 'AUTO_NBR' );
        S_wait_ms( $tcpar_wait_time_before_CCVT_s * 1000 );

        foreach my $direction (@tcpar_moving_directions) {
            my $maxStimulationValue = $directions_href->{$direction}{'max_stimulation_value'};
            my $angleOffset         = $directions_href->{$direction}{'angle_offset'};

            my $values_href = VDS_GetCCVTInputs( {}, $direction, $maxStimulationValue );

            Do_CCVT( $values_href->{'input'}{'up'}, $values_href->{'input'}{'down'}, $direction, $temperature, $angleOffset );
        }
    }

    S_teststep( "store all trace files in proper CSM containers for later evaluation", 'AUTO_NBR' );
    foreach my $direction (@tcpar_moving_directions) {
        my @traceFiles;
        foreach my $temperature (@temperatures) {
            push( @traceFiles, $traceFiles_href->{$direction}{$temperature} );
        }
        VDS_StoreDataContainer( \@traceFiles, [ $tcpar_project_ID, 'CCVT', $tcpar_CAN_trace_prefix, $direction ], {} );
        S_wait_ms(1000);    # to make sure a new container is created with a new name
    }

    return 1;
}

sub TC_evaluation {

    return 1;
}

sub TC_finalization {

    LC_ECU_Off();
    TEMP_setTargetTemperature(23) if $tcpar_use_temperature;
    TEMP_waitForTemperature(120)  if $tcpar_use_temperature;

    return 1;
}

sub Do_CCVT {
    my $inputValuesUp_aref   = shift;
    my $inputValuesDown_aref = shift;
    my $direction            = shift;
    my $temperature          = shift;
    my $angleOffset          = shift;

    $angleOffset = 0 if not defined $angleOffset;

    my $isRate;
    if ( $direction =~ /^w/ ) {
        $isRate = 1;
    }
    elsif ( $direction =~ /^a/ ) {
        $isRate = 0;
    }

    S_teststep( "Prepare bus trace for $direction for temperature $temperature �C", 'AUTO_NBR' );
    CA_simulation_start();

    my @inputValues = ( @{$inputValuesDown_aref}, @{$inputValuesUp_aref}, @{$inputValuesDown_aref} );    # down-ramp, then up-ramp, then down-ramp again for repeatability
    S_teststep( "Do the CCVT for $direction for temperature $temperature �C with input values @inputValues", 'AUTO_NBR' );
    foreach my $index ( 0 .. @inputValues - 1 ) {
        my $inputValue = $inputValues[$index];
        if ($isRate) {

            # rotate with given input rate in �/s
            MOT_Rotate( $table, $inputValue );
            S_wait_ms(200);                                                                              # to avoid Wx ESO problem change the waiting time to 1000
            S_w2log( 1, "Send SMI7xy verification request for CCVT of $direction at $temperature �C with rate $inputValue �/s\n" );

            CA_trace_start();
            PRD_Sensor_Verification($sensorConfig_href);
            S_wait_ms($tcpar_wait_after_PD_ms);                                                          # wait long enough to allow for CAN data collection
            CA_trace_stop();

            # stop and zero position to avoid Algo Watchdog problem
            MOT_Stop($table);
            MOT_Position( $table, 0 );
            S_wait_ms(10000);
        }
        else {
            # use earth gravity to create static acceleration values up to 1g
            # input value is given in g, convert to �
            my $angle_deg;
            if ( $index < @{$inputValuesDown_aref} or $index >= @{$inputValuesDown_aref} + @{$inputValuesUp_aref} ) {

                # we are in the down-ramp, so we calculate the angle with the easy asin formula
                $angle_deg = rad2deg( asin($inputValue) ) + $angleOffset;
            }
            else {
                # we are in the up-ramp and we want to continue the rotation of the down ramp,
                # so we calculate the angle with the more complicated acos formula
                $angle_deg = rad2deg( acos($inputValue) - 1.5 * pi ) + $angleOffset;
            }
            MOT_Position( $table, $angle_deg );
            S_wait_ms(5000);
            S_w2log( 1, "Send SMI7xy verification request for CCVT of $direction at $temperature �C with acceleration $inputValue g\n" );

            CA_trace_start();
            PRD_Sensor_Verification($sensorConfig_href);
            S_wait_ms($tcpar_wait_after_PD_ms);    # wait long enough to allow for CAN data collection: default = 5000
            CA_trace_stop();

        }
    }

    S_teststep( "read fault memory", 'AUTO_NBR' );
    $faultsAfter_href = PRD_Read_Fault_Memory('BOSCH');

    S_teststep( "Stop and store the CAN trace for $direction for temperature $temperature �C", 'AUTO_NBR' );
    my $canTraceName = 'C:\temp\\' . $tcpar_CAN_trace_prefix . '_' . $direction . '_' . $temperature . '.asc';
    CA_trace_store($canTraceName);
    S_teststep( "CAN trace stored as $canTraceName", 'AUTO_NBR' );

    # push trace file name into $traceFiles_href for CSM storage later
    $traceFiles_href->{$direction}{$temperature} = $canTraceName;

    CA_simulation_stop();
    CA_simulation_start();    # To avoid PD error

    if ($isRate) {

        # stop the rotation
        MOT_Stop($table);
        MOT_Position( $table, 0 );
    }
    else {
        # go to home position
        MOT_Position( $table, 0 );
    }

    return 1;
}

1;
