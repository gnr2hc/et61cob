#### TEST CASE MODULE
package TC_SMI_CCVT_eval;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER  = q$Header: VDS/ACUROT/TC_SMI_CCVT_eval.pm 1.1 2019/08/08 21:05:39ICT Prosch Christian (CC-PS/EPS2) (PHC2SI) develop  $;

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_evaluation;
use FuncLib_VDS;
use LIFT_CSM;

##################################

our $PURPOSE = "Evaluation of the CCVT test for SMI verification";

# DOCUMENTATION

=head1 TESTCASE MODULE

TC_SMI_CCVT_eval

=head1 PURPOSE

    Evaluation of the CCVT test for SMI verification

=head1 TESTCASE DESCRIPTION

Does the evaluation part of the CCVT (Characteristic Curve Value Test) of the SMI verification test.
Reads the traces that were recorded by TC_SMI_CCVT_stim with the project ID given by parameter 'project_ID',
the prefix given by parameter 'CAN_trace_prefix' and the moving direction given by parameter 'moving_direction' 
and extracts SMI data from them for each temperature.
Calculates, evaluates and plots the data for each temperature.
The following data are usually calculated, evaluated and plotted:

=over 1

=item * sensor physical values against stimulation input values

=item * line fit to the sensor physical values against stimulation input values

=item * sensor nonlinearity (= deviation of sensor values from line fit)

=item * sensor hysteresis (= deviation of sensor values for the same stimulation input value)

=back

I<B<Preconditions>>

Because this is a pure evaluation test the init campaign should not access any tool.
The CAN traces that were recorded by TC_SMI_CCVT_stim or a comparable test must be available.

I<B<Initialisation>>

    Initialize CSM

I<B<Stimulation and Measurement>>

    none, this must be done in a separate test case: e.g. TC_SMI_CCVT_stim

I<B<Evaluation>>

    Read traces from data container with project ID $tcpar_project_ID and prefix $tcpar_CAN_trace_prefix (one trace file for each temperature).
    Extract SMI data for every temperature.
    Calculate, evaluate and plot $tcpar_moving_direction CCVT for each temperature

I<B<Finalisation>>

    none

=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

    SCALAR 'purpose' = Purpose of the Testcase.
    SCALAR 'project_ID' = Unique project ID (same as in stimulation test case).
    SCALAR 'CAN_trace_prefix' = Prefix for the CAN trace files that are to be read. Rest of the file name and extension (.asc) will be added by the test case.
    SCALAR 'moving_direction' = Moving direction, either rotation rate ('wx', 'wy', 'wz') or acceleration ('ax', 'ay', 'az')
    SCALAR 'max_stimulation_value' = (optional) maximum value for stimulation; default = 300 (deg/s) for rates and 1 (g) for accelerations
    SCALAR 'max_evaluation_value' = (optional) maximum value for evaluation; can be less than 'max_stimulation_value'; default = 300 (deg/s) for rates and 1 (g) for accelerations
    SCALAR 'slope_tolerance' = tolerance for slope linearity evaluation for signals in moving direction; expected slope value = 1 
    SCALAR 'cross_axis_sensitivity' = tolerance for slope nonlinearity evaluation for signals NOT in moving direction; expected slope value = 0
    HASH   'nonlinearity_limits' = series of x and y values for nonlinearity evaluation limits: 
                                   e.g. %( 0 => 0.3, 30 => 1.5, 150 => 2.5 ) means limit is 
                                            0.3 for input values 0 < x <= 30, 
                                            1.5 for input values 30 < x <= 150
                                            2.5 for input values >150
                                            and symmetrical for negative input values
    HASH   'hysteresis_limits' = series of x and y values for hysteresis evaluation limits, see example for 'nonlinearity_limits'
    HASH   'repeatability_limits' = series of x and y values for repeatability evaluation limits, see example for 'nonlinearity_limits'
    SCALAR 'number_of_PD_samples' = Number of samples that was used for PD SMI verification service
    SCALAR 'sensor1_type' = sensor type as per SYC
    SCALAR 'sensor1_orientation' = sensor orientation as per SYC
    SCALAR 'sensor2_type' = sensor type as per SYC
    SCALAR 'sensor2_orientation' = sensor orientation as per SYC
    SCALAR 'sensor3_type' = sensor type as per SYC
    SCALAR 'sensor3_orientation' = sensor orientation as per SYC
    SCALAR 'sensor4_type' = sensor type as per SYC
    SCALAR 'sensor4_orientation' = sensor orientation as per SYC
    LIST   'ignore_signals' = (optional) list of signals that shall be ignored in evaluation (because they are not used in the project)
    HASH   'can_signals' = (optional) mapping of can signal names; 
                        keys: rotation rates ('wxcan', 'wycan', 'wzcan') and/or accelerations ('axcan', 'aycan', 'azcan')
                        values: project specific can signal names (according to dbc file) for corresponding rotation rates and accelerations
    HASH   'can_factors' = (optional) conversion factors for can signals to convert from physical units as defined in the dbc file
                           to deg/s for rates and G for accelerations;
                        keys: rotation rates ('wxcan', 'wycan', 'wzcan') and/or accelerations ('axcan', 'aycan', 'azcan')
                        values: project specific conversion factors for corresponding rotation rates and accelerations
    HASH   'can_quality_signals' = (optional) mapping of can quality signal names; 
                        keys: rotation rates ('wxcan', 'wycan', 'wzcan') and/or accelerations ('axcan', 'aycan', 'azcan')
                        values: project specific can quality signal names (according to dbc file) for corresponding rotation rates and accelerations
    HASH   'can_quality_OK_values' = (optional) values of the 'can_quality_signals' that indicate "OK"
                        keys: rotation rates ('wxcan', 'wycan', 'wzcan') and/or accelerations ('axcan', 'aycan', 'azcan')
                        values: project specific values of 'can_quality_signals' that indicate "OK"
    SCALAR 'number_of_can_samples' = (optional) Number of samples to be used for evaluation of can signals (default: 100)
    HASH   'FR_signals' = (optional) same as 'can_signals', only for flexray
    HASH   'FR_factors' = (optional) same as 'can_factors', only for flexray
    HASH   'FR_quality_signals' = (optional) same as 'can_quality_signals', only for flexray
    HASH   'FR_quality_OK_values' = (optional) same as 'can_quality_OK_values', only for flexray
	SCALAR 'number_of_FR_samples' = (optional) same as 'number_of_can_samples', only for flexray
	SCALAR 'Bus_for_PD' = (optional) bus number for PD services (default: 1). For CAN only the bus number must be given (e.g. 1), for flexray 'Fr' must be given.
 

=head2 PARAMETER EXAMPLES

    [TC_SMI_CCVT_eval.wx]
    purpose = 'SMI700/SMI710 wx'
    project_ID = 'ProjectXY_Var1_SampleA'
    CAN_trace_prefix = 'CCVT_rotx'
    moving_direction = 'wx'
    max_stimulation_value = 150
    max_evaluation_value = 100
    slope_tolerance = 0.03
    cross_axis_sensitivity = 0.0174
    nonlinearity_limits = %( 0 => 0.3, 30 => 1.5, 150 => 2.5 )
    hysteresis_limits = %( 0 => 0.3, 30 => 1.5, 150 => 2.5 )
    repeatability_limits = %( 0 => 0.3, 30 => 1.5, 150 => 2.5 )
    number_of_PD_samples = 1000
    sensor1_type = 'SMI700'
    sensor1_orientation = 'Sensor in 180� on back-layer'
    sensor2_type = 'N/A'
    sensor2_orientation = 'N/A'
    sensor3_type = 'SMI710'
    sensor3_orientation = 'Sensor in 90� on back-layer'
    sensor4_type = 'N/A'
    sensor4_orientation = 'N/A'
    can_signals = %( 'wzcan' => 'PSIP1', 'wxcan' => 'PHIP' )
    can_factors = %( 'wzcan' => -57.296, 'wxcan' => 57.296 )
    can_quality_signals =   %( 'wzcan' => 'PSIP1QS', 'wxcan' => 'PHIPQS' )
    can_quality_OK_values = %( 'wzcan' => 1,         'wxcan' => 1 )
    number_of_can_samples = 100
    Bus_for_PD = 1

    [TC_SMI_CCVT_eval.ay]
    purpose = 'SMI700/SMI710 ay'
    project_ID = 'ProjectXY_Var1_SampleA'
    CAN_trace_prefix = 'CCVT_rotx'
    moving_direction = 'ay'
    slope_tolerance = 0.03
    cross_axis_sensitivity = 0.023
    nonlinearity_limits = %( 0 => 0.015 )
    hysteresis_limits = %( 0 => 0.005 )
    repeatability_limits = %( 0 => 0.005 )
    number_of_PD_samples = 1000
    sensor1_type = 'SMI700'
    sensor1_orientation = 'Sensor in 180� on back-layer'
    sensor2_type = 'N/A'
    sensor2_orientation = 'N/A'
    sensor3_type = 'SMI710'
    sensor3_orientation = 'Sensor in 90� on back-layer'
    sensor4_type = 'N/A'
    sensor4_orientation = 'N/A'
    ignore_signals = @('ayred')
    can_signals = %( 'axcan' => 'VehLong2_A_Actl',  'aycan' => 'VehLat2_A_Actl' )
    can_factors = %( 'axcan' => 0.102,              'aycan' => -0.102 )
    can_quality_signals =   %( 'axcan' => 'VehLong2_Q', 'aycan' => 'VehLat2_Q' )
    can_quality_OK_values = %( 'axcan' => 3,            'aycan' => 3 )
    number_of_can_samples = 100
    Bus_for_PD = 1

=cut

#PARAMETERS
################ Parameters from .par file ###################
my ( $tcpar_purpose, $tcpar_CAN_trace_prefix, $tcpar_number_of_PD_samples );
my ( $tcpar_sensor1_type, $tcpar_sensor1_orientation, $tcpar_sensor2_type, $tcpar_sensor2_orientation, $tcpar_sensor3_type, $tcpar_sensor3_orientation, $tcpar_sensor4_type, $tcpar_sensor4_orientation );
my (
    $tcpar_moving_direction,    $tcpar_canSignals_href, $tcpar_max_stimulation_value, $tcpar_slope_tolerance, $tcpar_cross_axis_sensitivity, $tcpar_nonlinearity_limits_href, $tcpar_hysteresis_limits_href, $tcpar_repeatability_limits_href, $tcpar_number_of_can_samples,
    $tcpar_ignore_signals_aref, $tcpar_canFactors_href, $tcpar_max_evaluation_value,  $tcpar_project_ID,      $tcpar_Bus_for_PD,             $tcpar_FRSignals_href,           $tcpar_FRFactors_href,         $tcpar_number_of_FR_samples,
);
my ( $tcpar_can_quality_signals_href, $tcpar_can_quality_OK_values_href, $tcpar_FR_quality_signals_href, $tcpar_FR_quality_OK_values_href );

################ global parameter declaration ###################
#add any global variables here

my ( %sensorInfo, %canSignals, %FRSignals, $sensorType );

###############################################################

sub TC_set_parameters {

    ReadAllParameters();

    CheckParameters();

    $sensorInfo{1}{'type'}        = $tcpar_sensor1_type;
    $sensorInfo{1}{'orientation'} = $tcpar_sensor1_orientation;
    $sensorInfo{2}{'type'}        = $tcpar_sensor2_type;
    $sensorInfo{2}{'orientation'} = $tcpar_sensor2_orientation;
    $sensorInfo{3}{'type'}        = $tcpar_sensor3_type;
    $sensorInfo{3}{'orientation'} = $tcpar_sensor3_orientation;
    $sensorInfo{4}{'type'}        = $tcpar_sensor4_type;
    $sensorInfo{4}{'orientation'} = $tcpar_sensor4_orientation;

    if ( $tcpar_sensor1_type =~ /^SMI8/i ) {
        $sensorType = "SMI8";
    }
    else {
        $sensorType = "SMI7";
    }

    return 1;
}

sub ReadAllParameters {
    $tcpar_purpose                   = S_read_mandatory_testcase_parameter('purpose');
    $tcpar_project_ID                = S_read_mandatory_testcase_parameter('project_ID');
    $tcpar_CAN_trace_prefix          = S_read_mandatory_testcase_parameter('CAN_trace_prefix');
    $tcpar_moving_direction          = S_read_mandatory_testcase_parameter('moving_direction');
    $tcpar_max_stimulation_value     = S_read_optional_testcase_parameter('max_stimulation_value');
    $tcpar_max_evaluation_value      = S_read_optional_testcase_parameter('max_evaluation_value');
    $tcpar_slope_tolerance           = S_read_mandatory_testcase_parameter('slope_tolerance');
    $tcpar_cross_axis_sensitivity    = S_read_mandatory_testcase_parameter('cross_axis_sensitivity');
    $tcpar_nonlinearity_limits_href  = S_read_mandatory_testcase_parameter( 'nonlinearity_limits', 'byref' );
    $tcpar_hysteresis_limits_href    = S_read_mandatory_testcase_parameter( 'hysteresis_limits', 'byref' );
    $tcpar_repeatability_limits_href = S_read_mandatory_testcase_parameter( 'repeatability_limits', 'byref' );

    $tcpar_number_of_PD_samples = S_read_mandatory_testcase_parameter('number_of_PD_samples');
    $tcpar_sensor1_type         = S_read_mandatory_testcase_parameter('sensor1_type');

    if ( $tcpar_sensor1_type !~ /^SMI8/i ) {
        $tcpar_sensor1_orientation = S_read_mandatory_testcase_parameter('sensor1_orientation');
        $tcpar_sensor2_type        = S_read_mandatory_testcase_parameter('sensor2_type');
        $tcpar_sensor2_orientation = S_read_mandatory_testcase_parameter('sensor2_orientation');
        $tcpar_sensor3_type        = S_read_mandatory_testcase_parameter('sensor3_type');
        $tcpar_sensor3_orientation = S_read_mandatory_testcase_parameter('sensor3_orientation');
        $tcpar_sensor4_type        = S_read_mandatory_testcase_parameter('sensor4_type');
        $tcpar_sensor4_orientation = S_read_mandatory_testcase_parameter('sensor4_orientation');
    }

    $tcpar_ignore_signals_aref = S_read_optional_testcase_parameter( 'ignore_signals', 'byref' );

    $tcpar_canSignals_href            = S_read_optional_testcase_parameter( 'can_signals',           'byref' );
    $tcpar_canFactors_href            = S_read_optional_testcase_parameter( 'can_factors',           'byref' );
    $tcpar_can_quality_signals_href   = S_read_optional_testcase_parameter( 'can_quality_signals',   'byref' );
    $tcpar_can_quality_OK_values_href = S_read_optional_testcase_parameter( 'can_quality_OK_values', 'byref' );
    $tcpar_number_of_can_samples      = S_read_optional_testcase_parameter('number_of_can_samples');

    $tcpar_FRSignals_href            = S_read_optional_testcase_parameter( 'FR_signals',           'byref' );
    $tcpar_FRFactors_href            = S_read_optional_testcase_parameter( 'FR_factors',           'byref' );
    $tcpar_FR_quality_signals_href   = S_read_optional_testcase_parameter( 'FR_quality_signals',   'byref' );
    $tcpar_FR_quality_OK_values_href = S_read_optional_testcase_parameter( 'FR_quality_OK_values', 'byref' );
    $tcpar_number_of_FR_samples      = S_read_optional_testcase_parameter('number_of_FR_samples');

    $tcpar_Bus_for_PD = S_read_optional_testcase_parameter('Bus_for_PD');
}

sub CheckParameters {

    # check validity of $tcpar_CAN_trace_prefix
    if ( $tcpar_CAN_trace_prefix =~ /^(.+)\.(\w+)$/ ) {
        S_set_error("Given parameter 'CAN_trace_prefix' = '$tcpar_CAN_trace_prefix' must not have a file extension.");
    }

    # check validity of keys in $tcpar_moving_direction
    if ( $tcpar_moving_direction !~ /^[aw][xyz]$/ ) {
        S_set_error("Given parameter 'moving_direction' = '$tcpar_moving_direction' is none of the following allowed: 'wx', 'wy', 'wz', 'ax', 'ay', 'az'");
    }

    # add CAN signal conversion factors to $tcpar_canSignals_href
    if ( defined $tcpar_canSignals_href ) {
        foreach my $signal ( keys %{$tcpar_canSignals_href} ) {
            $canSignals{$signal}{'name'} = $tcpar_canSignals_href->{$signal};
        }
    }
    if ( defined $tcpar_canFactors_href ) {
        foreach my $signal ( keys %{$tcpar_canFactors_href} ) {
            $canSignals{$signal}{'factor'} = $tcpar_canFactors_href->{$signal};
        }
    }

    if ( defined $tcpar_FRSignals_href ) {
        foreach my $signal ( keys %{$tcpar_FRSignals_href} ) {
            $FRSignals{$signal}{'name'} = $tcpar_FRSignals_href->{$signal};
        }
    }
    if ( defined $tcpar_FRFactors_href ) {
        foreach my $signal ( keys %{$tcpar_FRFactors_href} ) {
            $FRSignals{$signal}{'factor'} = $tcpar_FRFactors_href->{$signal};
        }
    }

    if ( defined $tcpar_canSignals_href and not defined $tcpar_can_quality_signals_href ) {
        S_set_error("Test case parameter 'can_quality_signals' must be defined if 'can_signals' is defined");
        return 0;
    }

    if ( defined $tcpar_can_quality_signals_href and not defined $tcpar_can_quality_OK_values_href ) {
        S_set_error("Test case parameter 'can_quality_OK_values' must be defined if 'can_quality_signals' is defined");
        return 0;
    }

    my $qualityHashesMatch = 1;
    if ( defined $tcpar_can_quality_signals_href and defined $tcpar_can_quality_OK_values_href ) {
        my @quality_signals_keys       = sort keys %$tcpar_can_quality_signals_href;
        my @can_quality_OK_values_keys = sort keys %$tcpar_can_quality_OK_values_href;
        $qualityHashesMatch = ( @quality_signals_keys ~~ @can_quality_OK_values_keys );
    }
    if ( not $qualityHashesMatch ) {
        S_set_error("Test case parameters 'can_quality_signals' and 'can_quality_OK_values' must have the same keys");
        return 0;
    }

    if ( defined $tcpar_can_quality_signals_href ) {
        foreach my $signal ( keys %{$tcpar_can_quality_signals_href} ) {
            $canSignals{$signal}{'quality_signal'} = $tcpar_can_quality_signals_href->{$signal};
        }
    }

    if ( defined $tcpar_FRSignals_href ) {
        foreach my $signal ( keys %{$tcpar_FRSignals_href} ) {
            $FRSignals{$signal}{'name'} = $tcpar_FRSignals_href->{$signal};
        }
    }
    if ( defined $tcpar_FRFactors_href ) {
        foreach my $signal ( keys %{$tcpar_FRFactors_href} ) {
            $FRSignals{$signal}{'factor'} = $tcpar_FRFactors_href->{$signal};
        }
    }

    if ( defined $tcpar_FRSignals_href and not defined $tcpar_FR_quality_signals_href ) {
        S_set_error("Test case parameter 'FR_quality_signals' must be defined if 'FR_signals' is defined");
        return 0;
    }

    if ( defined $tcpar_FR_quality_signals_href and not defined $tcpar_FR_quality_OK_values_href ) {
        S_set_error("Test case parameter 'FR_quality_OK_values' must be defined if 'FR_quality_signals' is defined");
        return 0;
    }

    $qualityHashesMatch = 1;
    if ( defined $tcpar_FR_quality_signals_href and defined $tcpar_FR_quality_OK_values_href ) {
        my @quality_signals_keys      = sort keys %$tcpar_FR_quality_signals_href;
        my @FR_quality_OK_values_keys = sort keys %$tcpar_FR_quality_OK_values_href;
        $qualityHashesMatch = ( @quality_signals_keys ~~ @FR_quality_OK_values_keys );
    }
    if ( not $qualityHashesMatch ) {
        S_set_error("Test case parameters 'FR_quality_signals' and 'FR_quality_OK_values' must have the same keys");
        return 0;
    }

    if ( defined $tcpar_FR_quality_signals_href ) {
        foreach my $signal ( keys %{$tcpar_FR_quality_signals_href} ) {
            $FRSignals{$signal}{'quality_signal'} = $tcpar_FR_quality_signals_href->{$signal};
        }
    }

    if ( defined $tcpar_ignore_signals_aref and ref($tcpar_ignore_signals_aref) ne 'ARRAY' ) {
        S_set_error("Test case parameter 'ignore_signals' must be given as list: @( ... )");
        return 0;
    }
    foreach my $signal (@$tcpar_ignore_signals_aref) {
        if ( $signal !~ /^[aw][xyz]/ ) {
            S_set_error("Value '$signal' of test case parameter 'ignore_signals' does not begin with 'wx' or 'wy' or 'wz' or 'ax' or 'ay' or 'az'");
            return 0;
        }
    }
}

sub TC_initialization {

    CSM_init() || return;
    return 1;
}

sub TC_stimulation_and_measurement {

    return 1;
}

sub TC_evaluation {

    my $calculatedSignals_href;

    my $tcNumber = S_get_TC_number();

    my $testData_href = VDS_GetDataContainer( [ $tcpar_project_ID, 'CCVT', $tcpar_CAN_trace_prefix, $tcpar_moving_direction ] );
    my $subtest_href  = $testData_href->{'subtests'};
    my @subtests      = sort keys %{$subtest_href};
    S_teststep( "Found " . scalar(@subtests) . " traces in data container with project ID '$tcpar_project_ID' and prefix '$tcpar_CAN_trace_prefix'.", 'AUTO_NBR' );
    if ( not @subtests ) {
        S_set_error("No trace found in data container with project ID '$tcpar_project_ID' and prefix '$tcpar_CAN_trace_prefix'.");
        return 0;
    }

    foreach my $subtest (@subtests) {
        my $temperature = $subtest_href->{$subtest}{'temperature'};
        my $traceFile   = $subtest_href->{$subtest}{'traceFile'};

        S_w2log( 1, '', undef, "CCVT_$temperature" );
        S_teststep( "Read trace '$traceFile' for '$tcpar_moving_direction' and temperature $temperature.", 'AUTO_NBR' );
        my $smiresponses_href = VDS_GetSMIResponsesFromTrace( $traceFile, $sensorType , {busForPD => $tcpar_Bus_for_PD} );

        S_teststep( "Extract SMI data.", 'AUTO_NBR' );
        my $smiData_href = {};
        foreach my $time ( sort { $a <=> $b } keys %{$smiresponses_href} ) {
            $smiData_href->{$time} = VDS_ExtractSMIDataFromPD( $smiresponses_href->{$time}, $sensorType );
            $smiData_href->{$time}{'time'} = $time;
        }

        S_teststep( "Extract CAN data.", 'AUTO_NBR' );
        VDS_GetSMICANDataFromTrace( $traceFile, \%canSignals, $smiData_href, $tcpar_number_of_can_samples ) if %canSignals;

        S_teststep( "Extract FR data.", 'AUTO_NBR' );
        VDS_GetSMIFRDataFromTrace( $traceFile, \%FRSignals, $smiData_href, $tcpar_number_of_FR_samples ) if %FRSignals;

        S_teststep( "Calculate, evaluate and plot $tcpar_moving_direction CCVT for temperature $temperature", 'AUTO_NBR' );
        $calculatedSignals_href = VDS_CalculateSMIData( $smiData_href, $tcpar_number_of_PD_samples, \%sensorInfo, "CCVT $tcpar_moving_direction", undef, $tcpar_number_of_can_samples, $tcpar_max_stimulation_value, $tcpar_max_evaluation_value );

        EVAL_dump2UNV( $smiData_href, $main::REPORT_PATH . '/' . $tcNumber . '_' . $temperature . '_' . $tcpar_moving_direction . '_dump.txt.unv' );
        return if not defined $calculatedSignals_href;

        my ( $type, $unit ) = VDS_GetTypeUnitFromName($tcpar_moving_direction);
        my $input = $tcpar_moving_direction . '_input_in_' . $unit;

        my @signals;
        if ( $tcpar_moving_direction =~ /^w[xyz]/ ) {
            @signals = @{ $calculatedSignals_href->{'rate'} };
        }
        elsif ( $tcpar_moving_direction =~ /^a[xyz]/ ) {
            push( @signals, @{ $calculatedSignals_href->{'accel_xy'} } );
            push( @signals, @{ $calculatedSignals_href->{'accel_z'} } ) if defined @{ $calculatedSignals_href->{'accel_z'} };
        }
        else {
            S_set_error("Testcase parameter 'moving_direction' does not start with 'w' (rate) or 'a' (acceleration) followed by 'x', 'y' or 'z' (direction)");
        }

        # loop for signals in moving direction
        my $signalsInMovingDirectionFound;
        foreach my $signal (@signals) {
            next if grep { $signal =~ /^($_|$_\_\w+)$/ } @{$tcpar_ignore_signals_aref};
            next if $signal !~ /$tcpar_moving_direction/;
            my $slope     = $calculatedSignals_href->{ $signal . '_slope' };
            my $intercept = $calculatedSignals_href->{ $signal . '_intercept' };
            my $postfix   = $signal . '_' . $temperature;

            S_teststep_2nd_level( "Evaluate the sensitivity error (1 - slope of line fit, expected = 0) for stimulated signal $signal for temperature $temperature", 'AUTO_NBR' );
            EVAL_evaluate_value( 'Sensitivity_Error_CCVT_' . $signal . '_slope_' . $temperature, sprintf( "%.4f", 1 - abs($slope) ), '==', 0, sprintf( "%.4f", $tcpar_slope_tolerance ), 'absolute' );
            S_w2rep( "Signal 'Linearity_CCVT_" . $signal . "_intercept' (information only): " . sprintf( "%.4f", $intercept ) );
            EVAL_dataCalculationOverTime( $smiData_href, $signal . '_line_fit', "#0 * $slope + $intercept", [$input] );
            EVAL_evaluateAndPlotDataWithLimits( $smiData_href, $tcNumber . '_Linearity_CCVT_' . $postfix, { 'x' => $input, 'y' => [ $signal . '_measure_down', $signal . '_measure_up', $signal . '_measure_down_repeat', $signal . '_line_fit' ] }, undef, "$type in $unit" );

            S_teststep_2nd_level( "Evaluate deviation from line fit for stimulated signal $signal for temperature $temperature", 'AUTO_NBR' );
            my $nonlinearityLimitName = 'NonLinearity_CCVT_' . $signal . '_limit';
            my $nonlinearityLimitString = VDS_GetMultipleLimitString( $tcpar_nonlinearity_limits_href, $nonlinearityLimitName );
            EVAL_dataCalculationOverTime( $smiData_href, $nonlinearityLimitName, $nonlinearityLimitString, [ $signal . '_input_in_' . $unit ] );
            EVAL_evaluateAndPlotDataWithLimits( $smiData_href, $tcNumber . '_NonLinearity_CCVT_' . $postfix, { 'x' => $input, 'y' => [ 'NonLinearity_CCVT_' . $signal . '_down', 'NonLinearity_CCVT_' . $signal . '_up' ] }, "abs < $nonlinearityLimitName", "$type nonlinearity in $unit" );

            S_teststep_2nd_level( "Evaluate hysteresis (difference of up-ramp and down-ramp) for stimulated signal $signal for temperature $temperature", 'AUTO_NBR' );
            my $hysteresisLimitName = 'Hysteresis_CCVT_' . $signal . '_limit';
            my $hysteresisLimitString = VDS_GetMultipleLimitString( $tcpar_hysteresis_limits_href, $hysteresisLimitName );
            EVAL_dataCalculationOverTime( $smiData_href, $hysteresisLimitName, $hysteresisLimitString, [ $signal . '_input_in_' . $unit ] );
            EVAL_evaluateAndPlotDataWithLimits( $smiData_href, $tcNumber . '_Hysteresis_CCVT_' . $postfix, { 'x' => $input, 'y' => [ 'Hysteresis_CCVT_' . $signal ] }, "abs < $hysteresisLimitName", "$type hysteresis in $unit" );

            S_teststep_2nd_level( "Evaluate repeatability (difference of down-ramp and repeated down-ramp) for stimulated signal $signal for temperature $temperature", 'AUTO_NBR' );
            my $repeatabilityLimitName = 'Repeatability_CCVT_' . $signal . '_limit';
            my $repeatabilityLimitString = VDS_GetMultipleLimitString( $tcpar_repeatability_limits_href, $repeatabilityLimitName );
            EVAL_dataCalculationOverTime( $smiData_href, $repeatabilityLimitName, $repeatabilityLimitString, [ $signal . '_input_in_' . $unit ] );
            EVAL_evaluateAndPlotDataWithLimits( $smiData_href, $tcNumber . '_Repeatability_CCVT_' . $postfix, { 'x' => $input, 'y' => [ 'Repeatability_CCVT_' . $signal ] }, "abs < $repeatabilityLimitName", "$type repeatability in $unit" );

            $signalsInMovingDirectionFound = 1;
        }

        # loop for signals NOT in moving direction
        foreach my $signal (@signals) {
            next if grep { $signal =~ /^($_|$_\_\w+)$/ } @{$tcpar_ignore_signals_aref};
            next if $signal =~ /$tcpar_moving_direction/;
            my ( $type, $unit ) = VDS_GetTypeUnitFromName($signal);
            my $slope     = $calculatedSignals_href->{ $signal . '_slope' };
            my $intercept = $calculatedSignals_href->{ $signal . '_intercept' };
            my $postfix   = $tcNumber . '_' . $temperature . '_' . $signal;

            if ( not $signalsInMovingDirectionFound ) {

                # if no signals in moving direction exist then we have to create the input signal in moving direction ($input) artificially here because it is used below
                my $signalInput = $signal . '_input_in_' . $unit;
                EVAL_dataCalculationOverTime( $smiData_href, $input, "#0", [$signalInput] );
            }

            S_teststep_2nd_level( "Evaluate slope of line fit (expected = 0) for NOT stimulated signal $signal (= cross axis sensitivity) for temperature $temperature", 'AUTO_NBR' );
            EVAL_evaluate_value( 'Cross_Axis_Sensitivity_CCVT_' . $signal . '_' . $temperature, sprintf( "%.4f", $slope ), '==', 0, sprintf( "%.4f", $tcpar_cross_axis_sensitivity ), 'absolute' );
            S_w2rep( "Signal 'Cross_Axis_Sensitivity_CCVT_" . $signal . "_intercept' (information only): " . sprintf( "%.4f", $intercept ) );
            EVAL_dataCalculationOverTime( $smiData_href, $signal . '_line_fit', "#0 * $slope + $intercept", [$input] );
            EVAL_evaluateAndPlotDataWithLimits( $smiData_href, $tcNumber . '_Cross_Axis_Sensitivity_CCVT_' . $postfix, { 'x' => $input, 'y' => [ $signal . '_measure_down', $signal . '_measure_up', $signal . '_line_fit' ] }, undef,, "$type in $unit" );
        }

        if ( defined $tcpar_can_quality_signals_href or defined $tcpar_FR_quality_signals_href ) {
            S_teststep_2nd_level( "Evaluate quality signals", 'AUTO_NBR' );
            EvaluateQualitySignals( $calculatedSignals_href, $smiData_href );
            EVAL_evaluateAndPlotDataWithLimits( $smiData_href, $tcNumber . '_Quality_signals_CCVT_' . $temperature, $calculatedSignals_href->{'quality'}, undef, "" );
        }
    }

    VDS_WriteEvalData2xml( "$tcpar_CAN_trace_prefix $tcpar_moving_direction", $testData_href->{'metaData'} );

    VDS_CloseDataContainer( $testData_href->{'container_id'} );

    return 1;
}

sub TC_finalization {

    return 1;
}

#
# Evaluate the quality signals on the bus against expected values given as TC parameters
#
sub EvaluateQualitySignals {
    my $calculatedSignals_href = shift;
    my $smiData_href           = shift;

    foreach my $qualitySignal ( @{ $calculatedSignals_href->{'quality'} } ) {
        if ( $qualitySignal =~ /^Quality_(\w+?)_/ ) {
            my $signal = $1;
            my $expectedValue = $tcpar_can_quality_OK_values_href->{$signal} // $tcpar_FR_quality_OK_values_href->{$signal};    # use can values if defined, otherwise FR values
            EVAL_evaluate_value_over_time( $smiData_href, $qualitySignal, '==', $expectedValue );
        }
    }
    return 1;
}

1;
