#### TEST CASE MODULE
package TC_RateErrorOffsetAfterCompensation;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.4 $;
our $HEADER = q$Header: VDS/ACUROT/TC_RateErrorOffsetAfterCompensation.pm 1.4 2019/04/29 11:10:51ICT Andrews Xavier Jesu (RBEI/EVS) (XAA1COB) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
# Include further modules here

use LIFT_MLC;
use LIFT_evaluation;
use LIFT_PD;
use LIFT_CD;
use LIFT_vector_cantool;
use tsg4;
use TSG4CAN;
use PD;
use LIFT_labcar;
# use GENERIC_DCOM;
use LIFT_can_access;
use LIFT_TEMPERATURE;
use LIFT_ACUROT;
use Devel::Size qw(total_size);
use File::Basename;
use Data::Dumper;
use LIFT_flexray_access;

##################################

our $PURPOSE = "Check if the offset error after compensation is less than a treshold within a temperature range.";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_ISC_ErrorOffsetTestAfterCompensation

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>


I<B<Finalisation>>



=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES



=head2 PARAMETER EXAMPLES

	
=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Protocol;
my $tcpar_OffsetSignalName;
my $tcpar_OffsetQualifierSignalName;
my $tcpar_SensorRateSignalName;
my $tcpar_UBat1;
my $tcpar_StandstillInformationSignalName;
my $tcpar_StandstillValue;
my $tcpar_NotStandstillValue;
my $tcpar_VelocitySignalName;
my $tcpar_MaxTemperature;
my $tcpar_MinTemperature;
my $tcpar_RTCSignalName;
my $tcpar_HighVelocityValue;
my $tcpar_LowVelocityValue;
my $tcpar_LowLearningQualityValue;
my $tcpar_HighestLearningQualityValue;
my $tcpar_TestWithCompensatedRate; #$tcpar_TestWithCompensatedYaw
my $tcpar_SensorTemperatureSignalName;
my $tcpar_CycleOfMessage; #$tcpar_CycleOfYawMessage
my $tcpar_LongitudeAccSignalName; 
my $tcpar_LateralAccSignalName; 
my $tcpar_VerticalAccSignalName; 
#my $tcpar_RollRateSignalName; 
#my $tcpar_YawRateSignalName; 
#my $tcpar_PitchRateSignalName; 
my $tcpar_OptionalRateSignalName;
my $tcpar_AmbientSignalName; 
my $tcpar_AmbientSignalValue; 
my $tcpar_YocTimeStampLabel; 
my $tcpar_QualifierLabel; 
my $tcpar_OffsetLabel; 
my $tcpar_InternalTempSensor1Label; 
my $tcpar_InternalTempSensor2Label; 
my $tcpar_InternalTempSensor3Label; 
my $tcpar_CompensateDifferenceValue; 
my $tcpar_OffsetPrecisionValue; 
my $tcpar_RotationTableAxis; 
my $tcpar_RotationRateValue; 
my $tcpar_RotationTimeValue; 
my $tcpar_RTCSignalValue;
my $tcpar_VechicleDrivingDirSignalName;
my $tcpar_DrivingDirectionStatus;
my $tcpar_VehicleSpeedQualitySignalName;
my $tcpar_VehicleSpeedQualityValue;
my (@tcpar_FLTmand, @tcpar_FLTopt);

 


################ Global parameter declaration ###################
# Global variables

my $TracePath;
my $TracePath2;
my $all_signals_Pase2;
my $all_signals;
my $Tracename;
my $Time_before_Learn;
my $Time_After_Learn;
my @YOCNVMValues;
my @YOCQualNVMValues;
my @YOCNVMValuesBeforeLearning;
my @YOCQualNVMValuesBeforeLearning;

my @TemperatureSensor2ValueArray;
my @TemperatureSensor3ValueArray;

my @TemperatureSensor1ValueArray;
my @KammaTemperatureArray;

my @Time0;
my @Time1;
my @TimeBeforeLearningPath1;
my @TimeBeforeLearningPath2;
my @TimeLearningPathFinish1;
my @TimeLearningPathFinish2;

my @TimeOftheTestPhase2_1;
my @TimeOftheTestPhase2_2;
my @Time0_WithoutLearning;

my @YOCNVMValuesInROMAfterReset;
my @YOCQualNVMValuesInROMAfterReset;
my $fltmem1;
my $fltmem2;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_TestWithCompensatedRate =  GEN_Read_mandatory_testcase_parameter( 'TestWithCompensatedRate' );
	$tcpar_Protocol =  GEN_Read_mandatory_testcase_parameter( 'Protocol' );
	$tcpar_CycleOfMessage =  GEN_Read_mandatory_testcase_parameter( 'CycleOfMessage' );
	$tcpar_OffsetSignalName =  GEN_Read_mandatory_testcase_parameter( 'OffsetSignalName' );
	$tcpar_OffsetQualifierSignalName =  GEN_Read_mandatory_testcase_parameter( 'OffsetQualifierSignalName' );
	$tcpar_SensorRateSignalName =  GEN_Read_mandatory_testcase_parameter( 'SensorRateSignalName' );
	$tcpar_UBat1 =  GEN_Read_mandatory_testcase_parameter( 'UBat1' );
	$tcpar_StandstillInformationSignalName =  GEN_Read_mandatory_testcase_parameter( 'StandstillInformationSignalName' );
	$tcpar_NotStandstillValue =  GEN_Read_mandatory_testcase_parameter( 'NotStandstillValue' );
	$tcpar_StandstillValue =  GEN_Read_mandatory_testcase_parameter( 'StandstillValue' );
	$tcpar_VelocitySignalName = GEN_Read_mandatory_testcase_parameter( 'VelocitySignalName' );
	$tcpar_HighVelocityValue = GEN_Read_mandatory_testcase_parameter( 'HighVelocityValue' );
	$tcpar_LowVelocityValue = GEN_Read_mandatory_testcase_parameter( 'LowVelocityValue' );
	$tcpar_MaxTemperature = GEN_Read_mandatory_testcase_parameter( 'MaxTemperature' );
	$tcpar_MinTemperature = GEN_Read_mandatory_testcase_parameter( 'MinTemperature' );
	$tcpar_RTCSignalName = GEN_Read_mandatory_testcase_parameter( 'RTCSignalName' );
	$tcpar_LowLearningQualityValue = GEN_Read_mandatory_testcase_parameter( 'LowLearningQualityValue' );
	$tcpar_HighestLearningQualityValue = GEN_Read_mandatory_testcase_parameter( 'HighestLearningQualityValue' );
	$tcpar_SensorTemperatureSignalName = GEN_Read_mandatory_testcase_parameter( 'SensorTemperatureSignalName' );
	$tcpar_LongitudeAccSignalName = GEN_Read_mandatory_testcase_parameter( 'LongitudeAccSignalName' );
	$tcpar_LateralAccSignalName = GEN_Read_mandatory_testcase_parameter( 'LateralAccSignalName' );
	$tcpar_VerticalAccSignalName = GEN_Read_mandatory_testcase_parameter( 'VerticalAccSignalName' );
	#$tcpar_RollRateSignalName = GEN_Read_mandatory_testcase_parameter( 'RollRateSignalName' );
	#$tcpar_YawRateSignalName = GEN_Read_mandatory_testcase_parameter( 'YawRateSignalName' );
	#$tcpar_PitchRateSignalName = GEN_Read_mandatory_testcase_parameter( 'PitchRateSignalName' );
	$tcpar_OptionalRateSignalName = GEN_Read_mandatory_testcase_parameter( 'OptionalRateSignalName' );
	$tcpar_AmbientSignalName = GEN_Read_mandatory_testcase_parameter( 'AmbientSignalName' );
	$tcpar_AmbientSignalValue = GEN_Read_mandatory_testcase_parameter( 'AmbientSignalValue' );
	$tcpar_YocTimeStampLabel = GEN_Read_mandatory_testcase_parameter( 'YocTimeStampLabel' );
	$tcpar_QualifierLabel = GEN_Read_mandatory_testcase_parameter( 'QualifierLabel' );
	$tcpar_OffsetLabel = GEN_Read_mandatory_testcase_parameter( 'OffsetLabel' );
	$tcpar_InternalTempSensor1Label = GEN_Read_mandatory_testcase_parameter( 'InternalTempSensor1Label' );
	$tcpar_InternalTempSensor2Label = GEN_Read_optional_testcase_parameter( 'InternalTempSensor2Label' );
	$tcpar_InternalTempSensor3Label = GEN_Read_optional_testcase_parameter( 'InternalTempSensor3Label' );
	$tcpar_CompensateDifferenceValue = GEN_Read_mandatory_testcase_parameter( 'CompensateDifferenceValue' );
	$tcpar_OffsetPrecisionValue = GEN_Read_mandatory_testcase_parameter( 'OffsetPrecisionValue' );
	$tcpar_RotationTableAxis = GEN_Read_mandatory_testcase_parameter( 'RotationTableAxis' );
	$tcpar_RotationRateValue = GEN_Read_mandatory_testcase_parameter( 'RotationRateValue' );
	$tcpar_RotationTimeValue = GEN_Read_mandatory_testcase_parameter( 'RotationTimeValue' );
	$tcpar_RTCSignalValue = GEN_Read_mandatory_testcase_parameter( 'RTCSignalValue' );
	$tcpar_VechicleDrivingDirSignalName = GEN_Read_mandatory_testcase_parameter( 'VechicleDrivingDirSignalName' );
	$tcpar_DrivingDirectionStatus = GEN_Read_mandatory_testcase_parameter( 'DrivingDirectionStatus' );
	$tcpar_VehicleSpeedQualitySignalName = GEN_Read_mandatory_testcase_parameter( 'VehicleSpeedQualitySignalName' );
	$tcpar_VehicleSpeedQualityValue = GEN_Read_mandatory_testcase_parameter( 'VehicleSpeedQualityValue' );
	@tcpar_FLTmand = GEN_Read_optional_testcase_parameter('FLTmand');
    @tcpar_FLTopt  = GEN_Read_optional_testcase_parameter('FLTopt');


	return 1;
}

sub TC_initialization {

	S_w2log ( CONSOLE , "**************************************************************\n* Start of TC_RateErrorOffsetAfterCompensation Test *\n**************************************************************\n" , 'yellow' );

	# Restart ECU
	S_w2log ( 1 , "\n Restart the ECU \n" );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	CA_simulation_start();
	S_wait_ms(2000);
    LC_ECU_On();
    S_w2log ( 1 , "\n Set voltage to  $tcpar_UBat1\n" );
	LC_SetVoltage( $tcpar_UBat1 ); #Set a random voltage within the specified range
	S_wait_ms('TIMER_ECU_READY');
	#S_teststep( "Read fault memory before stimulation", 'AUTO_NBR' );
    #PD_ReadFaultMemory();
	
	# Clear fault memory 
	S_w2log ( 1 , "\n Clear fault memory \n" );
	PD_ClearFaultMemory(); 
	S_wait_ms(1000);
	# Read fault memory 
	S_teststep( "Read fault memory before stimulation", 'AUTO_NBR' );
    PD_ReadFaultMemory();
	$fltmem1 = PD_GetExtendedFaultInformation(BOSCH_FLT_MEM);
	S_teststep( 'Evaluate fault recorder', 'AUTO_NBR', 'Fault' );
	
	# Eval fault memory
	S_teststep_expected( 'Expected faults:', 'Fault' );
    foreach my $fault (@tcpar_FLTmand) {
        S_teststep_expected($fault);
    }

    S_teststep_detected( 'Detected faults:', 'Fault' );
    foreach my $fault ( @{ $fltmem1->{fault_text} } ) {
        S_teststep_detected($fault);
    }
    PD_evaluate_faults( $fltmem1, \@tcpar_FLTmand, \@tcpar_FLTopt );
	return 1;
}

sub TC_stimulation_and_measurement {
		
	S_w2log ( CONSOLE , "\n* Stimulation and measurement *\n" , 'yellow' );
	$Tracename = S_get_TC_number()."_ErrorOffsetTest_CAN_Trace";
	
	######################
	# 1) Start the Trace #
	######################
    S_teststep("Start NET trace", 'AUTO_NBR');
	#CA_simulation_start();
	S_wait_ms(1000);
	CA_trace_stop();
	# CA_trace_store("$main::REPORT_PATH/".S_get_TC_number()."_NET_Traces/_Trash.asc"); # Store the trace before stimulation
	CA_trace_store("$main::REPORT_PATH/_Trash.asc"); # Store the trace before stimulation
	CA_trace_start(); # Start the Canoe trace
	S_wait_ms(3000);

    S_teststep("Initialize standstill information -> no learning before test start", 'AUTO_NBR');
	# Initialise the standstill information in order to avoid any learning before the begining of the test
	FR_write_flxr_signal ( $tcpar_StandstillInformationSignalName , $tcpar_NotStandstillValue ) if( lc($tcpar_Protocol) =~ m/flxr/i ); # Set the standstill signal to the proper value
	CA_write_can_signal ( $tcpar_StandstillInformationSignalName , $tcpar_NotStandstillValue ) if( lc($tcpar_Protocol) =~ m/can/i ); # Set the standstill signal to the proper value
	FR_write_flxr_signal ( $tcpar_AmbientSignalName , $tcpar_AmbientSignalValue ) if( lc($tcpar_Protocol) =~ m/flxr/i ); # Set the Ambient signal to the proper value
	CA_write_can_signal ( $tcpar_AmbientSignalName , $tcpar_AmbientSignalValue ) if( lc($tcpar_Protocol) =~ m/can/i ); # Set the Ambient signal to the proper value
	FR_write_flxr_signal ( $tcpar_VechicleDrivingDirSignalName , $tcpar_DrivingDirectionStatus ) if( lc($tcpar_Protocol) =~ m/flxr/i ); # Set the VechicleDrivingDir signal to the proper value
	CA_write_can_signal ( $tcpar_VechicleDrivingDirSignalName , $tcpar_DrivingDirectionStatus ) if( lc($tcpar_Protocol) =~ m/can/i ); # Set the VechicleDrivingDir signal to the proper value
	FR_write_flxr_signal ( $tcpar_VehicleSpeedQualitySignalName , $tcpar_VehicleSpeedQualityValue ) if( lc($tcpar_Protocol) =~ m/flxr/i ); # Set the VehicleSpeedQualitySignal signal to the proper value
	CA_write_can_signal ( $tcpar_VehicleSpeedQualitySignalName , $tcpar_VehicleSpeedQualityValue ) if( lc($tcpar_Protocol) =~ m/can/i ); # Set the VehicleSpeedQualitySignal signal to the proper value
	
	#####################################
	# 2) Initialize the LUT values to 0 #
	#####################################
	S_teststep("Initialize the Look up Table (LUT) in RAM with value '0'", 'AUTO_NBR', 'lookup_before_learning');
	# Initialise the Timestamp to 0 to be sure that the DTC signal and the registered DTC match
	my $TMPadresse = PD_GetAddressByName( $tcpar_YocTimeStampLabel );
	PD_WriteMemoryByAddress( $TMPadresse,[0,0,0,0]);
	S_wait_ms(2000);
	
	foreach my $lutValueIndex (0..29)
	{
        $TMPadresse = PD_GetAddressByName( $tcpar_OffsetLabel."($lutValueIndex)" );
        PD_WriteMemoryByAddress( $TMPadresse,[0,0]);
        S_wait_ms(2000);	    
	}

    foreach my $qualValueIndex (0..29)
    {
		$TMPadresse = PD_GetAddressByName( $tcpar_QualifierLabel."($qualValueIndex)" );
		PD_WriteMemoryByAddress( $TMPadresse,[0]);
		S_wait_ms(2000);
	}
	
	###################################################################
	# 3) Set kamma temperature to the specified starting temperature  #
	###################################################################
	S_teststep("Switch the temperture to $tcpar_MinTemperature deg.", 'AUTO_NBR');
	TEMP_setTargetTemperature( $tcpar_MinTemperature );
	TEMP_waitForTemperature(120, 1); # checks every 60sec 120 times whether temp is reached (tolerance 1deg)
	S_wait_ms(5*60000); #Wait to stabilize the temperature
	TEMP_get_temperature();
	
	##########################################
	# 4) Read the LUT in Ram befor the Test  #
	##########################################

    foreach my $lutValueIndex (0..29)
	{
			my $YOCMemory = PD_ReadMemoryByName(  $tcpar_OffsetLabel."($lutValueIndex)"  );
			my $hex_YOCMemory = S_aref2hex ( $YOCMemory );
			S_wait_ms(2000);
			push @YOCNVMValuesBeforeLearning, $hex_YOCMemory ;
	}
	S_w2rep("NVM YOC offset values @YOCNVMValuesBeforeLearning \n");

    foreach my $qualValueIndex (0..29)
    {
			my $YOCMemory = PD_ReadMemoryByName(  $tcpar_QualifierLabel."($qualValueIndex)"  );
			my $hex_YOCMemory = S_aref2hex ( $YOCMemory );
			S_wait_ms(2000);
			push @YOCQualNVMValuesBeforeLearning, $hex_YOCMemory ;
	}
	S_w2rep("NVM YOC qualifier values @YOCQualNVMValuesBeforeLearning \n");
	
	#################################
	# 5) Beginning of the Test Loop #
	#################################
	for(my $currentTemp = $tcpar_MinTemperature; $currentTemp <= $tcpar_MaxTemperature; $currentTemp = $currentTemp + 5){ # The loop cover the minimal to the maximal temperature range according to the parameter with a step of 5 degree
		S_w2log ( 1 ,"*******************************\n*** Test for temperature $currentTemp ***\n*******************************\n",'green');
		
		# a) Set the wished temperature
        S_teststep("Set temperature $currentTemp deg and wait for temperature to be set.", 'AUTO_NBR', "eval_temp_$currentTemp");
		TEMP_setTargetTemperature( $currentTemp ); 
		TEMP_waitForTemperature(10,1); # Read temp every 60 sec 10 times
		#S_wait_ms(10*60000); # Wait 10 minutes
		S_wait_ms(20*60000); # Wait 20 minutes for better result from temp sensor
		
		# b) read the internal temperature of the yaw rate sensor component
		my $tempValueYawSensor = PD_ReadMemoryByName( $tcpar_InternalTempSensor1Label );# internal sensor temperature of Yaw rate
		my $TemperatureSensor1DecValue = S_aref2dec ( $tempValueYawSensor,S16 );
		
		#my $TemperatureSensor1Value = (((($TemperatureSensor1DecValue * 328)+7864320)>>16)-70);		#formula given by raja architech as per MRA2 both formulas are display same value.
		my $TemperatureSensor1Value  = (($TemperatureSensor1DecValue / 200)+50);#formula to conver decimal to celsius given by stefan (decimal value/200)+50
		S_wait_ms(2000);
		my $tempValueRollSensor = PD_ReadMemoryByName( $tcpar_InternalTempSensor2Label );# internal sensor temperature of Roll rate
		 my $TemperatureSensor2DecValue = S_aref2dec ( $tempValueRollSensor,S16 );
		 
		#my $TemperatureSensor2Value = (((($TemperatureSensor2DecValue * 328)+7864320)>>16)-70);#formula given by raja architech as per MRA2 both formulas are display same value.
		my $TemperatureSensor2Value= (($TemperatureSensor2DecValue / 200)+50); #formula to conver decimal to celsius given by stefan (decimal value/200)+50
		S_wait_ms(2000);
		# my $tempValuePitchSensor = PD_ReadMemoryByName( $tcpar_InternalTempSensor3Label);# internal sensor temperature of Pitch rate
		 # my $TemperatureSensor3DecValue = S_aref2dec( $tempValuePitchSensor,S16 );
		
		# # my $TemperatureSensor3Value = (((($TemperatureSensor3DecValue * 328)+7864320)>>16)-70);#formula given by raja architech as per MRA2 both formulas are display same value.
		# my $TemperatureSensor3Value = (($TemperatureSensor3DecValue / 200)+50);#formula to conver decimal to celsius given by stefan (decimal value/200)+50
		S_wait_ms(2000);
		push @TemperatureSensor1ValueArray, $TemperatureSensor1Value;
		push @TemperatureSensor2ValueArray, $TemperatureSensor2Value;
		# push @TemperatureSensor3ValueArray, $TemperatureSensor3Value;
		
        S_w2log ( 1 ,"\n*** Measured Temperature with the internal ECU temperature sensors ***");
        S_w2log ( 1 ,"\n Measured temperature yawrate sensor value: $TemperatureSensor1Value (°C) \n");
        S_w2log ( 1 ,"\n Measured Temperature rollrate sensor value: $TemperatureSensor2Value (°C) \n");
		# S_w2log ( 1 ,"\n Measured Temperature Pitchrate sensor value: $TemperatureSensor3Value (°C) \n");
		S_w2log ( 1 ,"\n*** Measured Temperature with the Kammer temperature sensor ***\n");
        push @KammaTemperatureArray, TEMP_get_temperature();
		
		# c) restart the trace 
        S_teststep("Start NET trace for temperature $currentTemp deg", 'AUTO_NBR');
		CA_trace_stop(); 
        CA_trace_store("$main::REPORT_PATH/_Trash.asc"); # Store the trace before stimulation
		CA_trace_start(); # Start the Canoe trace
		#push @Time0, S_get_TC_time (); # Store the time when the trace start
		S_wait_ms(4000); # Wait 4s
		
		FR_write_flxr_signal ( $tcpar_AmbientSignalName , $tcpar_AmbientSignalValue ) if( lc($tcpar_Protocol) =~ m/flxr/i ); # Set the Ambient signal to the proper value
		CA_write_can_signal ( $tcpar_AmbientSignalName , $tcpar_AmbientSignalValue ) if( lc($tcpar_Protocol) =~ m/can/i ); # Set the Ambient signal to the proper value
		FR_write_flxr_signal ( $tcpar_VechicleDrivingDirSignalName , $tcpar_DrivingDirectionStatus ) if( lc($tcpar_Protocol) =~ m/flxr/i ); # Set the VechicleDrivingDir signal to the proper value
		CA_write_can_signal ( $tcpar_VechicleDrivingDirSignalName , $tcpar_DrivingDirectionStatus ) if( lc($tcpar_Protocol) =~ m/can/i ); # Set the VechicleDrivingDir signal to the proper value
		FR_write_flxr_signal ( $tcpar_VehicleSpeedQualitySignalName , $tcpar_VehicleSpeedQualityValue ) if( lc($tcpar_Protocol) =~ m/flxr/i ); # Set the VehicleSpeedQualitySignal signal to the proper value
		CA_write_can_signal ( $tcpar_VehicleSpeedQualitySignalName , $tcpar_VehicleSpeedQualityValue ) if( lc($tcpar_Protocol) =~ m/can/i ); # Set the VehicleSpeedQualitySignal signal to the proper value
				
		# d) Simulate a movement of the vehicle to complete the driving cycle
        S_teststep("Simulate movement", 'AUTO_NBR');
        S_teststep_2nd_level("Set '$tcpar_StandstillInformationSignalName' to '$tcpar_NotStandstillValue'", 'AUTO_NBR');
		FR_write_flxr_signal ( $tcpar_StandstillInformationSignalName , $tcpar_NotStandstillValue ) if( $tcpar_Protocol =~ m/flxr/i); # Set the standstill signal to the proper value
        CA_write_can_signal ( $tcpar_StandstillInformationSignalName , $tcpar_NotStandstillValue ) if( $tcpar_Protocol =~ m/can/i); # Set the standstill signal to the proper value

        S_teststep_2nd_level("Set '$tcpar_RTCSignalName' to '$tcpar_RTCSignalValue' ", 'AUTO_NBR');
		FR_write_flxr_signal ( $tcpar_RTCSignalName , $tcpar_RTCSignalValue ) if( $tcpar_Protocol =~ m/flxr/i); # Be sure that the Day couter is valid
		CA_write_can_signal ( $tcpar_RTCSignalName , $tcpar_RTCSignalValue ) if( $tcpar_Protocol =~ m/can/i); # Be sure that the Day couter is valid
		S_wait_ms(5000); # Wait 5s

		# Change the velocity over 10kph
        S_teststep_2nd_level("Set '$tcpar_VelocitySignalName' to '$tcpar_HighVelocityValue'", 'AUTO_NBR');
		FR_write_flxr_signal ( $tcpar_VelocitySignalName , $tcpar_HighVelocityValue ) if( $tcpar_Protocol =~ m/flxr/i); # Change the velocity value to 10kph
		CA_write_can_signal ( $tcpar_VelocitySignalName , $tcpar_HighVelocityValue ) if( $tcpar_Protocol =~ m/can/i); # Change the velocity value to 10kph

		# Move the sensor with Acurot
        S_teststep("ECU will move in the Rate direction with Acurot.", 'AUTO_NBR');
		AR_rotate($tcpar_RotationTableAxis, $tcpar_RotationRateValue);
		S_wait_ms($tcpar_RotationTimeValue); # Wait 10s
		
				
        S_teststep("Stop movement", 'AUTO_NBR');
		AR_stop($tcpar_RotationTableAxis);
		S_wait_ms(5000); # Wait 5s

		# Stop the movement simulation
        S_teststep_2nd_level("Set $tcpar_VelocitySignalName to $tcpar_LowVelocityValue", 'AUTO_NBR','Qual_before_learning_'. $currentTemp);
		FR_write_flxr_signal ( $tcpar_VelocitySignalName , $tcpar_LowVelocityValue ) if( $tcpar_Protocol =~ m/flxr/i); # Change the velocity value to 0kph
		CA_write_can_signal ( $tcpar_VelocitySignalName , $tcpar_LowVelocityValue ) if( $tcpar_Protocol =~ m/can/i); # Change the velocity value to 0kph
		# get time references
		# push @TimeBeforeLearningPath1, S_get_TC_time ();
		S_wait_ms(2000); 
		# push @TimeBeforeLearningPath2, S_get_TC_time ();
		S_wait_ms(1000); 
		
		# e) Create a standstill situation
        S_teststep("Create a standstill situation for 15 sec : $tcpar_StandstillInformationSignalName = $tcpar_StandstillValue.", 'AUTO_NBR');
		FR_write_flxr_signal ( $tcpar_StandstillInformationSignalName ,  $tcpar_StandstillValue ) if( $tcpar_Protocol =~ m/flxr/i); # Set the standstill signal to the proper value
		CA_write_can_signal ( $tcpar_StandstillInformationSignalName ,  $tcpar_StandstillValue ) if( $tcpar_Protocol =~ m/can/i); # Set the standstill signal to the proper value
		S_wait_ms(15000); # Wait 15s

        S_teststep("Reset standstill situation ($tcpar_StandstillInformationSignalName = $tcpar_NotStandstillValue )", 'AUTO_NBR','Qual_After_learning_'. $currentTemp);
		FR_write_flxr_signal ( $tcpar_StandstillInformationSignalName , $tcpar_NotStandstillValue ) if( $tcpar_Protocol =~ m/flxr/i); # Set the standstill signal to the proper value
		CA_write_can_signal ( $tcpar_StandstillInformationSignalName , $tcpar_NotStandstillValue ) if( $tcpar_Protocol =~ m/can/i); # Set the standstill signal to the proper value
		S_wait_ms(100);
		#S_wait_ms(320);
		
				
		# push @TimeLearningPathFinish1, S_get_TC_time ();
		S_wait_ms(2000); # Todo Check this time with Matthias
		# push @TimeLearningPathFinish2, S_get_TC_time ();
		S_wait_ms(1000);
		
		# f) stop the Canoe trace
		S_teststep("Stop and store NET trace", 'AUTO_NBR');
		CA_trace_stop(); # Stop the Canoe trace 
		$TracePath = GEN_printLink(FR_trace_store("$main::REPORT_PATH/".S_get_TC_number()."_" .$currentTemp."_deg".'.asc' )) if( $tcpar_Protocol =~ m/flxr/i);
		$all_signals = FR_trace_get_dataref($TracePath,[ $tcpar_OffsetSignalName, $tcpar_OffsetQualifierSignalName, $tcpar_SensorRateSignalName , $tcpar_VelocitySignalName, $tcpar_StandstillInformationSignalName, $tcpar_AmbientSignalName, $tcpar_LongitudeAccSignalName, $tcpar_LateralAccSignalName, $tcpar_VerticalAccSignalName, $tcpar_OptionalRateSignalName, $tcpar_SensorTemperatureSignalName ]) if( $tcpar_Protocol =~ m/flxr/i); 
		$TracePath = GEN_printLink(CA_trace_store("$main::REPORT_PATH/".S_get_TC_number()."_" .$currentTemp."_deg".'.asc' )) if( $tcpar_Protocol =~ m/can/i);
		$all_signals = CA_trace_get_dataref($TracePath,[ $tcpar_OffsetSignalName, $tcpar_OffsetQualifierSignalName, $tcpar_SensorRateSignalName , $tcpar_VelocitySignalName, $tcpar_StandstillInformationSignalName, $tcpar_AmbientSignalName, $tcpar_LongitudeAccSignalName, $tcpar_LateralAccSignalName, $tcpar_VerticalAccSignalName, $tcpar_OptionalRateSignalName, $tcpar_SensorTemperatureSignalName ]) if( $tcpar_Protocol =~ m/can/i); 
		# FR_trace_start(); # Start the Canoe trace

        S_teststep("Restart NET trace", 'AUTO_NBR');
		CA_trace_start(); # Start the Canoe trace
		
		FR_write_flxr_signal ( $tcpar_AmbientSignalName , $tcpar_AmbientSignalValue ) if( lc($tcpar_Protocol) =~ m/flxr/i ); # Set the Ambient signal to the proper value
		CA_write_can_signal ( $tcpar_AmbientSignalName , $tcpar_AmbientSignalValue ) if( lc($tcpar_Protocol) =~ m/can/i ); # Set the Ambient signal to the proper value
		FR_write_flxr_signal ( $tcpar_VechicleDrivingDirSignalName , $tcpar_DrivingDirectionStatus ) if( lc($tcpar_Protocol) =~ m/flxr/i ); # Set the VechicleDrivingDir signal to the proper value
		CA_write_can_signal ( $tcpar_VechicleDrivingDirSignalName , $tcpar_DrivingDirectionStatus ) if( lc($tcpar_Protocol) =~ m/can/i ); # Set the VechicleDrivingDir signal to the proper value
		FR_write_flxr_signal ( $tcpar_VehicleSpeedQualitySignalName , $tcpar_VehicleSpeedQualityValue ) if( lc($tcpar_Protocol) =~ m/flxr/i ); # Set the VehicleSpeedQualitySignal signal to the proper value
		CA_write_can_signal ( $tcpar_VehicleSpeedQualitySignalName , $tcpar_VehicleSpeedQualityValue ) if( lc($tcpar_Protocol) =~ m/can/i ); # Set the VehicleSpeedQualitySignal signal to the proper value
		
		# g) stop the standstill situation
        S_teststep("Set not standstill situation ($tcpar_StandstillInformationSignalName = $tcpar_NotStandstillValue )", 'AUTO_NBR');
		FR_write_flxr_signal ( $tcpar_StandstillInformationSignalName , $tcpar_NotStandstillValue ) if( $tcpar_Protocol =~ m/flxr/i); # Set the standstill signal to the proper value
		CA_write_can_signal ( $tcpar_StandstillInformationSignalName , $tcpar_NotStandstillValue ) if( $tcpar_Protocol =~ m/can/i); # Set the standstill signal to the proper value
		
		# h) read the LUT in RAM and display it
		S_teststep ( "\n Read LUT status in RAM at end of $currentTemp \n", 'AUTO_NBR');
        foreach my $lutValueIndex (0..29)
        {
			my $YOCMemory = PD_ReadMemoryByName(  $tcpar_OffsetLabel."($lutValueIndex)"  );
			my $hex_YOCMemory = S_aref2hex ( $YOCMemory );
			S_wait_ms(2000);
			push @YOCNVMValues, $hex_YOCMemory ;
		}
		S_w2rep("NVM YOC offset values @YOCNVMValues \n");
        foreach my $qualValueIndex (0..29)
		{
			my $YOCMemory = PD_ReadMemoryByName(  $tcpar_QualifierLabel."($qualValueIndex)"  );
			my $hex_YOCMemory = S_aref2hex ( $YOCMemory );
			S_wait_ms(2000);
			push @YOCQualNVMValues, $hex_YOCMemory ;
		}
		# re-initialize the table
		S_w2rep("NVM YOC Qualifier values @YOCQualNVMValues \n");
		@YOCQualNVMValues = @_;
		@YOCNVMValues = @_;
	} # End of the big testing loop
	
	#################################################################################################
	# 6) Stop all the trace and for security reason reset the temperature of the Kamma to 24 degree #
	#################################################################################################
	CA_trace_stop(); # Stop the Canoe trace 
	TEMP_setTargetTemperature( 24 ); 
	TEMP_get_temperature();

	##########################
	# 7) Read the LUT values #need to change the array name like afterallcycle 
	##########################
	S_teststep("Read the offset look up table in EEPROM memory.", 'AUTO_NBR', 'read_the_offset');			#measurement 4
	S_w2log ( 1 ,"\n *** NVM LUT status Before hardreset *** \n");
	#my @NVMLUTBlockBefore;
	#my @NVMLUTBlockAfter;
	S_wait_ms(3000);
	S_w2log ( 1 ,"\n *** LUT status after learning in RAM *** \n");
	for(my $i=0; $i<30;$i++)
		{
			my $YOCMemory = PD_ReadMemoryByName(  $tcpar_OffsetLabel."($i)"  );
			my $hex_YOCMemory = S_aref2hex ( $YOCMemory );
			S_wait_ms(2000);
			push @YOCNVMValues, $hex_YOCMemory ;
		}
	S_w2rep("NVM YOC Offset values @YOCNVMValues \n");
	for(my $i=0; $i<30;$i++)
		{
			my $YOCMemory = PD_ReadMemoryByName(  $tcpar_QualifierLabel."($i)"  );
			my $hex_YOCMemory = S_aref2hex ( $YOCMemory );
			S_wait_ms(2000);
			push @YOCQualNVMValues, $hex_YOCMemory ;
		}
	S_w2rep("NVM YOC Qualifier values @YOCQualNVMValues \n");
	
	#####################
	# 7) Restart te ECU #
	#####################
	S_wait_ms(20000);#Analysis
	S_teststep("Perform a Hardreset", 'AUTO_NBR');
	LC_ECU_Off();
	#S_wait_ms(20000);
	S_wait_ms(60000);#analysis
    LC_ECU_On();
	S_wait_ms(60000);
	#S_wait_ms(20000);#analysis
	
	#####################
	# 8) Read the LUT values after ECU HardReset #
	#####################
	
	S_teststep("Read the offset look up table in EEPROM memory.", 'AUTO_NBR', 'read_After_Reset');
	S_w2log ( 1 ,"\n *** NVM LUT status After hardreset *** \n");
	S_wait_ms(3000);  # Added
	S_w2log ( 1 ,"\n *** LUT status After hardreset in ROM *** \n");
	for(my $i=0; $i<30; $i++)
		{
			my $YOCMemory = PD_ReadMemoryByName(  $tcpar_OffsetLabel."($i)"  );
			my $hex_YOCMemory = S_aref2hex ( $YOCMemory );
			S_wait_ms(2000);
			push @YOCNVMValuesInROMAfterReset, $hex_YOCMemory ;
		}
	S_w2rep("NVM YOC values @YOCNVMValuesInROMAfterReset \n");
	for(my $i=0; $i<30;$i++)
		{
			my $YOCMemory = PD_ReadMemoryByName(  $tcpar_QualifierLabel."($i)"  );
			my $hex_YOCMemory = S_aref2hex ( $YOCMemory );
			S_wait_ms(2000);
			push @YOCQualNVMValuesInROMAfterReset, $hex_YOCMemory ;
		}
	S_w2rep("NVM YOC values @YOCQualNVMValuesInROMAfterReset \n");
	
	
	##############################################
	# Test the compensation without new learning #
	##############################################
	for(my $currentTemp = $tcpar_MaxTemperature; $currentTemp >= $tcpar_MinTemperature; $currentTemp = $currentTemp - 5){ # The loop cover the minimal to the maximal temperature range according to the parameter with a step of 5 degree
		S_w2log ( 1 ,"**************************************\n*** Test without learning for temperature $currentTemp ***\n**************************************\n",'green');
		
		# a) Set the wished temperature
        S_teststep("Set temperature $currentTemp deg and wait for temperature to be set.", 'AUTO_NBR', "eval_Witout_Learning_temp_$currentTemp");
		TEMP_setTargetTemperature( $currentTemp ); 
		TEMP_waitForTemperature(10,1); # Read temp every 60 sec 10 times
		#S_wait_ms(10*60000); # Wait 10 minutes
		S_wait_ms(20*60000); # Wait 20 minutes
			
		# b) restart the trace 
        S_teststep("Start NET trace for temperature $currentTemp deg", 'AUTO_NBR');
		CA_trace_stop(); 
        CA_trace_store("$main::REPORT_PATH/_Trash.asc"); # Store the trace before stimulation
		CA_trace_start(); # Start the Canoe trace
		FR_write_flxr_signal ( $tcpar_StandstillInformationSignalName , $tcpar_NotStandstillValue ) if( lc($tcpar_Protocol) =~ m/flxr/i ); # Set the standstill signal to the proper value
		CA_write_can_signal ( $tcpar_StandstillInformationSignalName , $tcpar_NotStandstillValue ) if( lc($tcpar_Protocol) =~ m/can/i ); # Set the standstill signal to the proper value
		push @Time0_WithoutLearning, S_get_TC_time (); # Store the time when the trace start
		S_wait_ms(4000); # Wait 4s
       
		push @TimeOftheTestPhase2_1, S_get_TC_time ();
		S_wait_ms(2000);
		push @TimeOftheTestPhase2_2, S_get_TC_time ();
		S_wait_ms(2000);
		
		S_teststep("Stop and store the trace", 'AUTO_NBR');
		CA_trace_stop(); 
		$TracePath2 = GEN_printLink(FR_trace_store("$main::REPORT_PATH/".S_get_TC_number()."_" .$currentTemp."_deg_Phase2".'.asc' )) if( $tcpar_Protocol =~ m/flxr/i);
		$all_signals_Pase2 = FR_trace_get_dataref($TracePath2,[ $tcpar_OffsetSignalName, $tcpar_OffsetQualifierSignalName, $tcpar_SensorRateSignalName , $tcpar_VelocitySignalName, $tcpar_StandstillInformationSignalName, $tcpar_AmbientSignalName, $tcpar_LongitudeAccSignalName, $tcpar_LateralAccSignalName, $tcpar_VerticalAccSignalName, $tcpar_OptionalRateSignalName, $tcpar_SensorTemperatureSignalName  ]) if( $tcpar_Protocol =~ m/flxr/i); 
		$TracePath2 = GEN_printLink(CA_trace_store("$main::REPORT_PATH/".S_get_TC_number()."_" .$currentTemp."_deg_Phase2".'.asc' )) if( $tcpar_Protocol =~ m/can/i);
		$all_signals_Pase2 = CA_trace_get_dataref($TracePath2,[ $tcpar_OffsetSignalName, $tcpar_OffsetQualifierSignalName, $tcpar_SensorRateSignalName , $tcpar_VelocitySignalName, $tcpar_StandstillInformationSignalName, $tcpar_AmbientSignalName, $tcpar_LongitudeAccSignalName, $tcpar_LateralAccSignalName, $tcpar_VerticalAccSignalName, $tcpar_OptionalRateSignalName,$tcpar_SensorTemperatureSignalName  ]) if( $tcpar_Protocol =~ m/can/i); 

		S_teststep("Restart the trace", 'AUTO_NBR');
		CA_trace_start(); # Start the Canoe trace
	}
	
		
	#CA_simulation_stop();
	return 1;
}

sub TC_evaluation {

	S_w2log ( CONSOLE , "\n* Evaluation *\n" , 'yellow' );
	my $NotCompensatedSensorValue; # Or not compensated sensor value
	my $CompensatedSensorValue; # Or not compensated sensor value
	my $SensorValue;
	my $SumOfNotCompYawRateValue = 0;
	my $Zahler = 0;
	my $TIMESTAMP;
	my $CompensatedYawRateAverageRound;
	my $CompensatedYawRateAverage;
	my $OffsetValue;
	my $e = 0;
	for(my $Temperature = $tcpar_MinTemperature; $Temperature <= $tcpar_MaxTemperature; $Temperature = $Temperature + 5){
		# $i . $Tracename
		# $Tracename.$i.'.asc'
		S_w2log ( 1 , "\n************************\n* Test for temperature $Temperature. *\n************************\n", 'green' );
		$all_signals = FR_trace_get_dataref("$main::REPORT_PATH/".S_get_TC_number()."_" .$Temperature."_deg".'.asc',[$tcpar_RTCSignalName ,$tcpar_OffsetSignalName, $tcpar_OffsetQualifierSignalName, $tcpar_SensorRateSignalName , $tcpar_VelocitySignalName, $tcpar_StandstillInformationSignalName, $tcpar_SensorTemperatureSignalName, $tcpar_AmbientSignalName, $tcpar_LongitudeAccSignalName, $tcpar_LateralAccSignalName, $tcpar_VerticalAccSignalName, $tcpar_OptionalRateSignalName ])if( $tcpar_Protocol =~ m/flxr/i); #, 'PSIP1_Sens_Temp1' , 'DayCnt', 'A1' , 'A2', 'Az'
		$all_signals = CA_trace_get_dataref("$main::REPORT_PATH/".S_get_TC_number()."_" .$Temperature."_deg".'.asc',[$tcpar_RTCSignalName ,$tcpar_OffsetSignalName, $tcpar_OffsetQualifierSignalName, $tcpar_SensorRateSignalName , $tcpar_VelocitySignalName, $tcpar_StandstillInformationSignalName, $tcpar_SensorTemperatureSignalName, $tcpar_AmbientSignalName, $tcpar_LongitudeAccSignalName, $tcpar_LateralAccSignalName, $tcpar_VerticalAccSignalName, $tcpar_OptionalRateSignalName ])if( $tcpar_Protocol =~ m/can/i); #, 'PSIP1_Sens_Temp1' , 'DayCnt', 'A1' , 'A2', 'Az'

		
		
		# check if initialization was successful
		my $OffsetLUTDifferentFrom0 = 0;
		my $QualifierLUTDifferentFrom0 = 0;
		for(my $a=0; $a < 30; $a++ ){
				if ($YOCNVMValuesBeforeLearning[$a] != 0){
						$OffsetLUTDifferentFrom0 ++;
				}
				if ($YOCQualNVMValuesBeforeLearning[$a] != 0){
						$QualifierLUTDifferentFrom0 ++;
				}
			}
		# Check if LUT of learning values has been successfully stored in the NVM
		S_teststep_expected_NOHTML("--- LUT STATUS BEFORE STIMULATION ---");
		S_teststep_detected_NOHTML("--- LUT STATUS BEFORE STIMULATION ---");
		S_teststep_expected("Qualifier LUT values are 0", 'lookup_before_learning' );
		if ($QualifierLUTDifferentFrom0 != 0){
			#S_w2log ( 1 , "Qualifier LUT is different from 0 $QualifierLUTDifferentFrom0 time." );
            S_teststep_detected ("Qualifier LUT is different from 0 $QualifierLUTDifferentFrom0 time.", 'lookup_before_learning' );
			S_set_verdict ( 'VERDICT_FAIL' );
			return 1;
		}
		S_teststep_detected ("Each qualifier LUT values are well initialised to 0.", 'lookup_before_learning' );
		# Check if LUT of learning value has been successfully stored in the NVM
		S_teststep_expected("Offset LUT values are 0", 'lookup_before_learning');
		if ($OffsetLUTDifferentFrom0 != 0){
			#S_w2log ( 1 , "Offset LUT is different from 0 $OffsetLUTDifferentFrom0 time." );
            S_teststep_detected ("Offset LUT is different from 0 $OffsetLUTDifferentFrom0 time.", 'lookup_before_learning');
			S_set_verdict ( 'VERDICT_FAIL' );
            return 1;
   		}
   		S_teststep_detected ("Each offset LUT values are well initialised to 0.", 'lookup_before_learning' );

		S_teststep_expected_NOHTML("--- OFFSET QUALIFIER SIGNAL BEFORE LEARNING ---");
		S_teststep_detected_NOHTML("--- OFFSET QUALIFIER SIGNAL BEFORE LEARNING ---");
		S_teststep_expected("$tcpar_OffsetQualifierSignalName must be lower than $tcpar_HighestLearningQualityValue before learning path.", 'Qual_before_learning_'. $Temperature );
		my $verdict = 'VERDICT_PASS';
		# Check if before learning the qualifier is equal to low learning quality
		my $thisVerdict;
		my @mismatchTimestamps = ();
		
		$Time_before_Learn = EVAL_get_time_when( $all_signals , $tcpar_SensorRateSignalName , ">" , 9 );
		
		push @Time0 ,$Time_before_Learn;
		
		my $Time_Learn_start = EVAL_get_time_when( $all_signals , $tcpar_StandstillInformationSignalName , "==" , 2 );
		$Time_After_Learn = EVAL_get_time_when( $all_signals , $tcpar_StandstillInformationSignalName , "==" , 1, $Time_Learn_start );
		$Time_After_Learn = $Time_After_Learn + 0.02; #to avoid fail added 20ms,it is due to transistion time from qulaifier value low to high.
		push @Time1 ,$Time_After_Learn;
		
		for(my $Time = $Time0[$e]; $Time < ($Time0[$e]+2); $Time = $Time + $tcpar_CycleOfMessage ){ # $tcpar_CycleOfMessage = 0.01
			
			$thisVerdict = EVAL_evaluate_value_around_time_NOHTML ( $all_signals , $Time , $tcpar_OffsetQualifierSignalName, '<' , $tcpar_HighestLearningQualityValue );
			$verdict = 'VERDICT_FAIL' if ($thisVerdict eq 'VERDICT_FAIL');
			if($thisVerdict eq 'VERDICT_FAIL'){			
				
				S_teststep_mismatch("Time $Time , expected < $tcpar_HighestLearningQualityValue, detected value $tcpar_HighestLearningQualityValue");
				push(@mismatchTimestamps, $Time);
			}
			# EVAL_evaluate_value_around_time ( $all_signals , $Time , $tcpar_OffsetQualifierSignalName, '<=' , 7 );
		}
		S_teststep_detected ("Offset signal is under $tcpar_HighestLearningQualityValue (high learning quality) for all time stamps", 'Qual_before_learning_'. $Temperature ) if($verdict eq 'VERDICT_PASS');
		S_teststep_detected ("Offset signal is not under $tcpar_HighestLearningQualityValue (high learning quality) for time stamps: @mismatchTimestamps", 'Qual_before_learning_'. $Temperature ) if($verdict eq 'VERDICT_FAIL');
		S_set_verdict($verdict);
		
		S_teststep_expected_NOHTML("--- OFFSET QUALIFIER SIGNAL AFTER LEARNING ---");
		S_teststep_detected_NOHTML("--- OFFSET QUALIFIER SIGNAL AFTER LEARNING ---");
		# Check After learning the qualifier is greater then low learning quality
		S_teststep_expected("Check if after learning the qualifier is different from 'low learning quality' does not report an error.", 'Qual_After_learning_'. $Temperature );
		for(my $Time = $Time1[$e]; $Time < ($Time1[$e]+2); $Time = $Time + $tcpar_CycleOfMessage ){
			# ToDo: Print out failed cases
			EVAL_evaluate_value_around_time_NOHTML ( $all_signals , $Time , $tcpar_OffsetQualifierSignalName, '>' , $tcpar_LowLearningQualityValue );
			
		}
			
		# Caluculation of the not compensated yaw average
		$Zahler = 0;
		$SumOfNotCompYawRateValue = 0;
		for(my $Time = $Time1[$e]; $Time < ($Time1[$e]+2); $Time = $Time + $tcpar_CycleOfMessage ){
			($SensorValue, $TIMESTAMP) = EVAL_get_value_around_time_NOHTML( $all_signals , $Time ,  $tcpar_SensorRateSignalName );# Average of sensor value without compensation
			$SumOfNotCompYawRateValue = $SumOfNotCompYawRateValue + $SensorValue;
			$Zahler++;
		}
		my $YawRateAverage = $SumOfNotCompYawRateValue/$Zahler;
		my $YawRateAverageRound = sprintf("%.4f", $YawRateAverage);
		S_w2log ( 1 , "\n******************************************\n* Yaw Rate Average = $YawRateAverage \n* Counter = $Zahler \n");
		$Zahler = 0;
		
		# Calculation of Compensated yaw average value
		my $SumOfCompensatedYawRateValue = 0;
		my $CompensatedYawRateAverageRound;
		my $CompensatedYawRateAverage;
		if($tcpar_TestWithCompensatedRate =~ m/Yes/i){
			for(my $Time = $Time1[$e]; $Time < ($Time1[$e]+2); $Time = $Time + $tcpar_CycleOfMessage ){
					($CompensatedSensorValue, $TIMESTAMP) = EVAL_get_value_around_time_NOHTML( $all_signals , $Time ,  $tcpar_OffsetSignalName ); # Average of sensor value with compensation
					$SumOfCompensatedYawRateValue = $SumOfCompensatedYawRateValue + $CompensatedSensorValue;
					$Zahler++;
			}
			$CompensatedYawRateAverage = $SumOfCompensatedYawRateValue/$Zahler;
			$CompensatedYawRateAverageRound = sprintf("%.4f", $CompensatedYawRateAverage);
			S_w2log ( 1 , "\n******************************************\n* Compensated Yaw Rate Average = $CompensatedYawRateAverage \n* Counter = $Zahler \n"); 
		}
		
		# Offset calculation
		if ($tcpar_TestWithCompensatedRate =~ m/Yes/i){
			($NotCompensatedSensorValue, $TIMESTAMP) = EVAL_get_value_around_time( $all_signals , ($Time1[$e]+2) ,  $tcpar_SensorRateSignalName ); # Sensor value without compensation
			($CompensatedSensorValue, $TIMESTAMP) = EVAL_get_value_around_time( $all_signals , ($Time1[$e]+2)  ,  $tcpar_OffsetSignalName ); # Sensor value with compensation
			$OffsetValue = $CompensatedSensorValue - $NotCompensatedSensorValue; #this step not required due to we are using compensated signal
		}else{
			($OffsetValue, $TIMESTAMP) = EVAL_get_value_around_time( $all_signals , ($Time1[$e]+2) , $tcpar_OffsetSignalName );
		}
		
		# Display values on the report
		#S_w2log ( 1 , "\n******************************************\n* Yaw Rate Average = $YawRateAverage \n* Counter = $Zahler \n* CAN offset value = $OffsetValue\n");
		S_w2log ( 1 , "\n******************************************\n* FR/ CAN offset value = $OffsetValue\n"); 		
		S_w2log ( 1 ,"* Measured temperature yawrate sensor value:" . $TemperatureSensor1ValueArray[$e] . "\n* Measured Temperature rollrate sensor value:" . $TemperatureSensor2ValueArray[$e] . "\n* Measured Temperature Pitchrate sensor value:" . $TemperatureSensor3ValueArray[$e]);
		S_w2log ( 1 ,"* Measured temperature in the kamma:" . $KammaTemperatureArray[$e] . "\n******************************************\n" );
		S_w2log ( 1 , "LUT Offset values @YOCNVMValues \n LUT Qualifier value @YOCQualNVMValues\n");

		# S_teststep_expected_NOHTML("--- OFFSET SIGNAL AFTER LEARNING ---");
		# S_teststep_detected_NOHTML("--- OFFSET SIGNAL AFTER LEARNING ---");
		# Evaluate the efficiency of the compensation 
		if($tcpar_TestWithCompensatedRate =~ m/Yes/i){
			EVAL_evaluate_value("Check if $tcpar_OffsetSignalName is lower than 0.2 deg/s", abs($CompensatedYawRateAverageRound) ,'<=', ($tcpar_CompensateDifferenceValue)); # When the vehicle is immobilized, the compensated value must be under 0.2 deg/s
			S_teststep_expected("Absolute value of compensated YawRate must be lower or equal than the uncompensated one", 'Qual_After_learning_'. $Temperature);
			if (abs($YawRateAverageRound) >= ($tcpar_OffsetPrecisionValue)){
				EVAL_evaluate_value("Check if |$tcpar_OffsetSignalName| is lower than |$tcpar_SensorRateSignalName| value ",abs($CompensatedYawRateAverageRound) ,'<=', abs($YawRateAverageRound)); # compensated yaw must be lower than the uncompensated one
			}else{
				EVAL_evaluate_value("Check if |$tcpar_OffsetSignalName| is lower than |0.05| deg/s value ",abs($CompensatedYawRateAverageRound) ,'<', ($tcpar_OffsetPrecisionValue));
			}
		}else{
			S_teststep_expected("Absolute value of |YawRate value - offset compensation| must be lower or equal than the absolute value of YawRate", 'Qual_After_learning_'. $Temperature);
			EVAL_evaluate_value("Check if $tcpar_SensorRateSignalName - $tcpar_OffsetSignalName is lower than 0.2 deg/s", abs($YawRateAverageRound-$OffsetValue) ,'<=', ($tcpar_CompensateDifferenceValue)); # When the vehicle is immobilized, the compensated value must be under 0.2 deg/s
			if (abs($YawRateAverageRound) >= ($tcpar_OffsetPrecisionValue)){
				EVAL_evaluate_value("Check if |$tcpar_SensorRateSignalName - $tcpar_OffsetSignalName| is lower than |$tcpar_SensorRateSignalName| value ",abs($YawRateAverageRound - $OffsetValue) ,'<=', abs($YawRateAverageRound)); # compensated yaw must be lower than the uncompensated one
			}else{
				EVAL_evaluate_value("Check if |$tcpar_SensorRateSignalName - $tcpar_OffsetSignalName| is lower than |$tcpar_SensorRateSignalName| value ",abs($YawRateAverageRound - $OffsetValue) ,'<', ($tcpar_OffsetPrecisionValue));
			}
		}
		
		########### Plot of the signal value ############
		EVAL_evaluateAndPlotDataWithLimits($all_signals, 'TC_YOC_ErrorOffsetTestAfterCompensation Offset qualifier'.S_get_TC_number(). $tcpar_OffsetQualifierSignalName. $tcpar_MaxTemperature. $tcpar_MinTemperature.$Temperature,[ $tcpar_OffsetQualifierSignalName ]);
		EVAL_evaluateAndPlotDataWithLimits($all_signals, 'TC_YOC_ErrorOffsetTestAfterCompensation Offset signal'.S_get_TC_number() . $tcpar_MaxTemperature. $tcpar_MinTemperature.$Temperature,[ $tcpar_OffsetSignalName ]);
		EVAL_evaluateAndPlotDataWithLimits($all_signals, 'TC_YOC_ErrorOffsetTestAfterCompensation sensor signal' .S_get_TC_number() . $tcpar_MaxTemperature . $tcpar_MinTemperature.$Temperature,[$tcpar_SensorRateSignalName ]);
		EVAL_evaluateAndPlotDataWithLimits($all_signals, 'TC_YOC_ErrorOffsetTestAfterCompensation vehicle speed signal' .S_get_TC_number(). $tcpar_MaxTemperature . $tcpar_MinTemperature.$Temperature,[ $tcpar_VelocitySignalName ]);
		EVAL_evaluateAndPlotDataWithLimits($all_signals, 'TC_YOC_ErrorOffsetTestAfterCompensation standstill signal' .S_get_TC_number(). $tcpar_MaxTemperature . $tcpar_MinTemperature.$Temperature,[ $tcpar_StandstillInformationSignalName ]);
		EVAL_evaluateAndPlotDataWithLimits($all_signals, 'TC_YOC_ErrorOffsetTestAfterCompensation day counter' .S_get_TC_number(). $tcpar_MaxTemperature . $tcpar_MinTemperature.$Temperature,[ $tcpar_RTCSignalName ]);
		EVAL_evaluateAndPlotDataWithLimits($all_signals, 'TC_YOC_ErrorOffsetTestAfterCompensation temperature signal' .S_get_TC_number(). $tcpar_MaxTemperature . $tcpar_MinTemperature . $tcpar_SensorTemperatureSignalName .$Temperature,[ $tcpar_SensorTemperatureSignalName ]);
		EVAL_evaluateAndPlotDataWithLimits($all_signals, 'TC_YOC_ErrorOffsetTestAfterCompensation Longitude signal' .S_get_TC_number(). $tcpar_MaxTemperature . $tcpar_MinTemperature.$Temperature,[ $tcpar_LongitudeAccSignalName]);
		EVAL_evaluateAndPlotDataWithLimits($all_signals, 'TC_YOC_ErrorOffsetTestAfterCompensation Lateral signal' .S_get_TC_number(). $tcpar_MaxTemperature . $tcpar_MinTemperature.$Temperature,[ $tcpar_LateralAccSignalName ]);
		EVAL_evaluateAndPlotDataWithLimits($all_signals, 'TC_YOC_ErrorOffsetTestAfterCompensation Vertical signal' .S_get_TC_number(). $tcpar_MaxTemperature . $tcpar_MinTemperature.$Temperature,[ $tcpar_VerticalAccSignalName ]);
		EVAL_evaluateAndPlotDataWithLimits($all_signals, 'TC_YOC_ErrorOffsetTestAfterCompensation Roll or Pitch or Yaw Rate signal' .S_get_TC_number(). $tcpar_MaxTemperature . $tcpar_MinTemperature.$Temperature,[ $tcpar_OptionalRateSignalName ]);
		#EVAL_evaluateAndPlotDataWithLimits($all_signals, 'TC_YOC_ErrorOffsetTestAfterCompensation RollRate signal' .S_get_TC_number(). $tcpar_MaxTemperature . $tcpar_MinTemperature.$Temperature,[ $tcpar_RollRateSignalName ]);
		#EVAL_evaluateAndPlotDataWithLimits($all_signals, 'TC_YOC_ErrorOffsetTestAfterCompensation YawRate signal' .S_get_TC_number(). $tcpar_MaxTemperature . $tcpar_MinTemperature.$Temperature,[ $tcpar_YawRateSignalName ]);
		#EVAL_evaluateAndPlotDataWithLimits($all_signals, 'TC_YOC_ErrorOffsetTestAfterCompensation PitchRate signal' .S_get_TC_number(). $tcpar_MaxTemperature . $tcpar_MinTemperature.$Temperature,[ $tcpar_PitchRateSignalName ]);
		EVAL_evaluateAndPlotDataWithLimits($all_signals, 'TC_YOC_ErrorOffsetTestAfterCompensation Ambient signal' .S_get_TC_number(). $tcpar_MaxTemperature . $tcpar_MinTemperature.$Temperature,[ $tcpar_AmbientSignalName ]);
		$e++;
	}
	
	#####################
	# Compare NVM values before and after Hardreset  # 
	#####################
    my $OffsetLUTDifferentAfterHardReset = 0;
		my $QualifierLUTDifferentAfterHardReset = 0;
		for(my $a=0; $a < 30; $a++ ){
		S_w2rep("After reset offset values $YOCNVMValuesInROMAfterReset[$a] \n");############ analysis
		S_w2rep("Before reset offset values $YOCNVMValues[$a] \n");############ analysis
				if ($YOCNVMValuesInROMAfterReset[$a] != $YOCNVMValues[$a]){
						$OffsetLUTDifferentAfterHardReset ++;
				}
				S_w2rep("in loop After reset qualifier values $YOCQualNVMValuesInROMAfterReset[$a] \n");############ analysis
				S_w2rep(" in loopBefore reset qualifier values $YOCQualNVMValues[$a] \n");############ analysis
				if ($YOCQualNVMValuesInROMAfterReset[$a] != $YOCQualNVMValues[$a]){
						S_w2rep("out loop After reset qualifier values $YOCQualNVMValuesInROMAfterReset[$a] \n");############ analysis
						S_w2rep("out loop Before reset qualifier values $YOCQualNVMValues[$a] \n");############ analysis
						$QualifierLUTDifferentAfterHardReset ++;
						
				}
			}
	
		S_teststep_expected("Before and After HardResetQualifier LUT values should same", 'read_After_Reset' );	
		if ($QualifierLUTDifferentAfterHardReset != 0){
			S_w2log ( 1 , "Qualifier LUT is different After HardReset $QualifierLUTDifferentAfterHardReset time." );
            S_teststep_detected ("Qualifier LUT is different After HardReset $QualifierLUTDifferentAfterHardReset time.", 'read_After_Reset' );
			S_set_verdict ( 'VERDICT_FAIL' );
			return 1;
		}
		else{
		S_teststep_detected ("Before and After HardReset Each qualifier LUT values are same", 'read_After_Reset');
		S_set_verdict ( 'VERDICT_PASS' );
		}
		# Check if LUT of learning value has been successfully stored in the NVM
		S_teststep_expected("Before and After HardReset Offset LUT values should same", 'read_After_Reset');
		if ($OffsetLUTDifferentAfterHardReset != 0){
			S_w2log ( 1 , "Offset LUT is different After HardReset $OffsetLUTDifferentAfterHardReset time." );
            S_teststep_detected ("Offset LUT is different After HardReset $OffsetLUTDifferentAfterHardReset time.", 'read_After_Reset');
			S_set_verdict ( 'VERDICT_FAIL' );
            return 1;
   		}
		else{
		
   		S_teststep_detected ("Before and After HardReset Each Offset LUT values are same",'read_After_Reset' );
		S_set_verdict ( 'VERDICT_PASS' );
		}
	
	##########
	S_teststep_expected("At the end of the test and after a reset, some element of the LUT (EEPROM) must be different from 0.", 'read_the_offset');			#evaluation 4
	my $TableLenght = (scalar @YOCNVMValues);
	my $CounterWhenNVMTableIsDifferentFrom0 = 0;
	for(my $i=0; $i < $TableLenght; $i++){
		if ( S_0x2dec($YOCNVMValues[$i]) != 0){
			$CounterWhenNVMTableIsDifferentFrom0++;
		}
	}
	EVAL_evaluate_value('The Offset compensation LUT is different from Zero more than 1 time ', $CounterWhenNVMTableIsDifferentFrom0, '>', 1);
	S_w2log ( 1 , "\n YOC Offset values are: @YOCNVMValues \n YOC Qualifier values are: @YOCQualNVMValues \n" );
	
	#
	######## Start of the Evaluation Pase 2 ############
	#
	S_w2log ( CONSOLE , "\n* Evaluation Phase2 *\n" , 'yellow' );
	$e = 0;
	for(my $Temperature = $tcpar_MaxTemperature; $Temperature >= $tcpar_MinTemperature; $Temperature = $Temperature - 5){
		S_w2log ( 1 , "\n*********************************************\n* Test for temperature $Temperature deg in phase 2 (without learning) *\n*********************************************\n", 'green' );
		$all_signals_Pase2 = FR_trace_get_dataref("$main::REPORT_PATH/".S_get_TC_number()."_" .$Temperature."_deg_Phase2".'.asc',[$tcpar_RTCSignalName ,$tcpar_OffsetSignalName, $tcpar_OffsetQualifierSignalName, $tcpar_SensorRateSignalName , $tcpar_VelocitySignalName, $tcpar_StandstillInformationSignalName, $tcpar_SensorTemperatureSignalName, $tcpar_AmbientSignalName, $tcpar_LongitudeAccSignalName, $tcpar_LateralAccSignalName, $tcpar_VerticalAccSignalName, $tcpar_OptionalRateSignalName ])if( $tcpar_Protocol =~ m/flxr/i); #, 'PSIP1_Sens_Temp1' , 'DayCnt', 'A1' , 'A2', 'Az'
		$all_signals_Pase2 = CA_trace_get_dataref("$main::REPORT_PATH/".S_get_TC_number()."_" .$Temperature."_deg_Phase2".'.asc',[$tcpar_RTCSignalName ,$tcpar_OffsetSignalName, $tcpar_OffsetQualifierSignalName, $tcpar_SensorRateSignalName , $tcpar_VelocitySignalName, $tcpar_StandstillInformationSignalName, $tcpar_SensorTemperatureSignalName, $tcpar_AmbientSignalName, $tcpar_LongitudeAccSignalName, $tcpar_LateralAccSignalName, $tcpar_VerticalAccSignalName, $tcpar_OptionalRateSignalName ])if( $tcpar_Protocol =~ m/can/i); #, 'PSIP1_Sens_Temp1' , 'DayCnt', 'A1' , 'A2', 'Az'

		# Caluculation of the not compensated yaw average
		$Zahler = 0;
		$SumOfNotCompYawRateValue = 0;
		for(my $Time = $TimeOftheTestPhase2_1[$e] - $Time0_WithoutLearning[$e]; $Time < $TimeOftheTestPhase2_2[$e] - $Time0_WithoutLearning[$e]; $Time = $Time + $tcpar_CycleOfMessage ){
			($SensorValue, $TIMESTAMP) = EVAL_get_value_around_time_NOHTML( $all_signals_Pase2 , $Time ,  $tcpar_SensorRateSignalName );# Average of sensor value without compensation
			$SumOfNotCompYawRateValue = $SumOfNotCompYawRateValue + $SensorValue;
			$Zahler++;
		}
		
		my $YawRateAverage = $SumOfNotCompYawRateValue/$Zahler;
		my $YawRateAverageRound = sprintf("%.4f", $YawRateAverage);

		# Calculation of Compensated yaw average value
		$Zahler = 0;
		my $SumOfCompensatedYawRateValue = 0;
		if($tcpar_TestWithCompensatedRate =~ m/Yes/i){
			for(my $Time = $TimeOftheTestPhase2_1[$e] - $Time0_WithoutLearning[$e]; $Time < $TimeOftheTestPhase2_2[$e] - $Time0_WithoutLearning[$e]; $Time = $Time + $tcpar_CycleOfMessage ){
					($CompensatedSensorValue, $TIMESTAMP) = EVAL_get_value_around_time_NOHTML( $all_signals_Pase2 , $Time ,  $tcpar_OffsetSignalName ); # Average of sensor value with compensation
					$SumOfCompensatedYawRateValue = $SumOfCompensatedYawRateValue + $CompensatedSensorValue;
					$Zahler++;
			}
			$CompensatedYawRateAverage = $SumOfCompensatedYawRateValue / $Zahler;
			$CompensatedYawRateAverageRound = sprintf("%.4f", $CompensatedYawRateAverage);
		}
		
		# Offset calculation
		if ($tcpar_TestWithCompensatedRate =~ m/Yes/i){
			($NotCompensatedSensorValue, $TIMESTAMP) = EVAL_get_value_around_time( $all_signals_Pase2 , $TimeOftheTestPhase2_2[$e] - $Time0_WithoutLearning[$e] ,  $tcpar_SensorRateSignalName ); # Sensor value without compensation
			($CompensatedSensorValue, $TIMESTAMP) = EVAL_get_value_around_time( $all_signals_Pase2 , $TimeOftheTestPhase2_2[$e] - $Time0_WithoutLearning[$e] ,  $tcpar_OffsetSignalName ); # Sensor value with compensation
			$OffsetValue = $CompensatedSensorValue - $NotCompensatedSensorValue;
		}else{
			($OffsetValue, $TIMESTAMP) = EVAL_get_value_around_time( $all_signals_Pase2 , $TimeOftheTestPhase2_2[$e] - $Time0_WithoutLearning[$e], $tcpar_OffsetSignalName );
		}
		
		S_teststep_expected_NOHTML("--- OFFSET SIGNAL AFTER LEARNING AND RESET---");
		S_teststep_detected_NOHTML("--- OFFSET SIGNAL AFTER LEARNING AND RESET---");
		# Evaluate the efficiency of the compensation 
		if($tcpar_TestWithCompensatedRate =~ m/Yes/i){
			EVAL_evaluate_value("Check if $tcpar_OffsetSignalName is lower than 0.2 deg/s", abs($CompensatedYawRateAverageRound) ,'<=', ($tcpar_CompensateDifferenceValue)); # When the vehicle is immobilized, the compensated value must be under 0.2 deg/s
			S_teststep_expected("Absolute value of compensated YawRate must be lower or equal than the uncompensated one", 'Qual_After_learning_'. $Temperature);
			if (abs($YawRateAverageRound) >= ($tcpar_OffsetPrecisionValue)){
				EVAL_evaluate_value("Check if |$tcpar_OffsetSignalName| is lower than |$tcpar_SensorRateSignalName| value ",abs($CompensatedYawRateAverageRound) ,'<=', abs($YawRateAverageRound)); # compensated yaw must be lower than the uncompensated one
			}else{
				EVAL_evaluate_value("Check if |$tcpar_OffsetSignalName| is lower than |0.05| deg/s value ",abs($CompensatedYawRateAverageRound) ,'<', ($tcpar_OffsetPrecisionValue));
			}
		}else{
			S_teststep_expected("Absolute value of |YawRate value - offset compensation| must be lower or equal than the absolute value of YawRate", 'Qual_After_learning_'. $Temperature);
			EVAL_evaluate_value("Check if $tcpar_SensorRateSignalName - $tcpar_OffsetSignalName is lower than 0.2 deg/s", abs($YawRateAverageRound-$OffsetValue) ,'<=', ($tcpar_CompensateDifferenceValue)); # When the vehicle is immobilized, the compensated value must be under 0.2 deg/s
			if (abs($YawRateAverageRound) >= ($tcpar_OffsetPrecisionValue)){
				EVAL_evaluate_value("Check if |$tcpar_SensorRateSignalName - $tcpar_OffsetSignalName| is lower than |$tcpar_SensorRateSignalName| value ",abs($YawRateAverageRound - $OffsetValue) ,'<=', abs($YawRateAverageRound)); # compensated yaw must be lower than the uncompensated one
			}else{
				EVAL_evaluate_value("Check if |$tcpar_SensorRateSignalName - $tcpar_OffsetSignalName| is lower than |$tcpar_SensorRateSignalName| value ",abs($YawRateAverageRound - $OffsetValue) ,'<', ($tcpar_OffsetPrecisionValue));
			}
		}
		
		########### Plot of the signal value ############
		EVAL_evaluateAndPlotDataWithLimits($all_signals_Pase2, 'TC_YOC_ErrorOffsetTestAfterCompensation Offset qualifier Phase 2'. S_get_TC_number() . $tcpar_OffsetQualifierSignalName. $tcpar_MaxTemperature. $tcpar_MinTemperature.$Temperature,[ $tcpar_OffsetQualifierSignalName ]);
		EVAL_evaluateAndPlotDataWithLimits($all_signals_Pase2, 'TC_YOC_ErrorOffsetTestAfterCompensation Offset signal Phase 2'. S_get_TC_number() . $tcpar_MaxTemperature. $tcpar_MinTemperature.$Temperature,[ $tcpar_OffsetSignalName ]);
		EVAL_evaluateAndPlotDataWithLimits($all_signals_Pase2, 'TC_YOC_ErrorOffsetTestAfterCompensation sensor signal Phase 2' . S_get_TC_number() . $tcpar_MaxTemperature . $tcpar_MinTemperature.$Temperature,[$tcpar_SensorRateSignalName ]);
		EVAL_evaluateAndPlotDataWithLimits($all_signals_Pase2, 'TC_YOC_ErrorOffsetTestAfterCompensation vehicle speed signal Phase 2' . S_get_TC_number() . $tcpar_MaxTemperature . $tcpar_MinTemperature.$Temperature,[ $tcpar_VelocitySignalName ]);
		EVAL_evaluateAndPlotDataWithLimits($all_signals_Pase2, 'TC_YOC_ErrorOffsetTestAfterCompensation standstill signal Phase 2' . S_get_TC_number() . $tcpar_MaxTemperature . $tcpar_MinTemperature.$Temperature,[ $tcpar_StandstillInformationSignalName ]);
		EVAL_evaluateAndPlotDataWithLimits($all_signals_Pase2, 'TC_YOC_ErrorOffsetTestAfterCompensation day counter Phase 2' . S_get_TC_number() . $tcpar_MaxTemperature . $tcpar_MinTemperature.$Temperature,[ $tcpar_RTCSignalName ]);
		EVAL_evaluateAndPlotDataWithLimits($all_signals_Pase2, 'TC_YOC_ErrorOffsetTestAfterCompensation temperature signal Phase 2' . S_get_TC_number() . $tcpar_MaxTemperature . $tcpar_MinTemperature . $tcpar_SensorTemperatureSignalName .$Temperature,[ $tcpar_SensorTemperatureSignalName ]);
		EVAL_evaluateAndPlotDataWithLimits($all_signals_Pase2, 'TC_YOC_ErrorOffsetTestAfterCompensation Longitude signal Phase 2' . S_get_TC_number() . $tcpar_MaxTemperature . $tcpar_MinTemperature.$Temperature,[ $tcpar_LongitudeAccSignalName ]);
		EVAL_evaluateAndPlotDataWithLimits($all_signals_Pase2, 'TC_YOC_ErrorOffsetTestAfterCompensation Lateral signal Phase 2' . S_get_TC_number() . $tcpar_MaxTemperature . $tcpar_MinTemperature.$Temperature,[ $tcpar_LateralAccSignalName ]);
		EVAL_evaluateAndPlotDataWithLimits($all_signals_Pase2, 'TC_YOC_ErrorOffsetTestAfterCompensation Vertical signal Phase 2' . S_get_TC_number() . $tcpar_MaxTemperature . $tcpar_MinTemperature.$Temperature,[ $tcpar_VerticalAccSignalName ]);
		EVAL_evaluateAndPlotDataWithLimits($all_signals_Pase2, 'TC_YOC_ErrorOffsetTestAfterCompensation Roll or Pitch or Yaw Rate signal Phase 2' . S_get_TC_number() . $tcpar_MaxTemperature . $tcpar_MinTemperature.$Temperature,[ $tcpar_OptionalRateSignalName ]);
		#EVAL_evaluateAndPlotDataWithLimits($all_signals_Pase2, 'TC_YOC_ErrorOffsetTestAfterCompensation YawRate signal Phase 2' . S_get_TC_number() . $tcpar_MaxTemperature . $tcpar_MinTemperature.$Temperature,[ $tcpar_YawRateSignalName ]);
		#EVAL_evaluateAndPlotDataWithLimits($all_signals_Pase2, 'TC_YOC_ErrorOffsetTestAfterCompensation PitchRate signal Phase 2' . S_get_TC_number() . $tcpar_MaxTemperature . $tcpar_MinTemperature.$Temperature,[ $tcpar_PitchRateSignalName ]);
		EVAL_evaluateAndPlotDataWithLimits($all_signals_Pase2, 'TC_YOC_ErrorOffsetTestAfterCompensation Ambient signal Phase 2' . S_get_TC_number() . $tcpar_MaxTemperature . $tcpar_MinTemperature.$Temperature,[ $tcpar_AmbientSignalName ]);
		$e++;
	}

	
	
	S_w2log ( 1 , "\n YOC values are: @YOCNVMValuesInROMAfterReset \n YOC Qualifier values are: @YOCQualNVMValuesInROMAfterReset \n" );
	
	# Read fault memory 
	S_teststep( "Read fault memory After stimulation", 'AUTO_NBR' );
    PD_ReadFaultMemory();
	$fltmem2 = PD_GetExtendedFaultInformation(BOSCH_FLT_MEM);
	S_teststep( 'Evaluate fault recorder', 'AUTO_NBR', 'FaultAfterStim' );
	
	
	# Eval fault memory
	S_teststep_expected( 'Expected faults:', 'FaultAfterStim' );
    foreach my $fault2 (@tcpar_FLTmand) {
        S_teststep_expected($fault2);
    }

    S_teststep_detected( 'Detected faults:', 'FaultAfterStim' );
    foreach my $fault2 ( @{ $fltmem2->{fault_text} } ) {
        S_teststep_detected($fault2);
    }
    PD_evaluate_faults( $fltmem2, \@tcpar_FLTmand, \@tcpar_FLTopt );

	return 1;
}

sub TC_finalization {
	S_teststep( "Dequalify fault memory", 'AUTO_NBR' );
	PD_ManipulateFaultMemory(3, 'dequalify');
	S_wait_ms('TIMER_ECU_READY');
	S_w2log ( CONSOLE , "\n* Finalisation *\n" , 'yellow' );
	PD_ClearFaultMemory();
	S_wait_ms(1000); # Wait until the fault memory is clear
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	CA_simulation_stop();
	return 1;
}


1;
