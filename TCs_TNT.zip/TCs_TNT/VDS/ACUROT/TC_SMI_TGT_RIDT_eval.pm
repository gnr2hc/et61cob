#### TEST CASE MODULE
package TC_SMI_TGT_RIDT_eval;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER  = q$Header: VDS/ACUROT/TC_SMI_TGT_RIDT_eval.pm 1.1 2019/08/08 21:05:40ICT Prosch Christian (CC-PS/EPS2) (PHC2SI) develop  $;

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_evaluation;
use FuncLib_VDS;
use LIFT_CSM;

##################################

our $PURPOSE = "Evaluation of the TGT and RIDT test for VDS functionality";

# DOCUMENTATION

=head1 TESTCASE MODULE

TC_SMI_TGT_RIDT_eval

=head1 PURPOSE

Evaluation of the TGT and RIDT test for SMI verification

=head1 TESTCASE DESCRIPTION

Does the evaluation part of the TGT (Temperature Gradient Test) and RIDT (Run In Drift Test) of the SMI verification test.
Reads the trace that was recorded by TC_SMI_TGT_RIDT_stim and extracts SMI data from it.
Extracts the RIDT parts from the main data set.
Calculates, evaluates and plots the data for TGT.
Calculates, evaluates and plots the data for RIDT for each temperature.
The following data are usually calculated, evaluated and plotted:

=over 1

=item * sensor physical absolute values 

=item * sensor noise RMS values (= standard deviation)

=item * sensor noise peak to peak values (= max - min values)

=item * sensor offset drift gradient values (= current value - previous value)

=item * sensor offset relative to T0 values (= current value - first value)

=back

I<B<Preconditions>>

Because this is a pure evaluation test the init campaign should not access any tool.
A trace that was recorded by TC_SMI_TGT_RIDT_stim or a comparable test must be available.

I<B<Initialisation>>

	none

I<B<Stimulation and Measurement>>

	none, this must be done in a separate test case: e.g. TC_SMI_TGT_RIDT_stim

I<B<Evaluation>>

	Read traces from data container with project ID $tcpar_project_ID.
	Extract SMI data.
	Extract RIDT data.
	Calculate, evaluate and plot TGT
	Calculate, evaluate and plot RIDT for each temperature

I<B<Finalisation>>

	none

=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' = Purpose of the Testcase
    SCALAR 'project_ID' = Unique project ID (same as in stimulation test case).
	SCALAR 'number_of_samples' = Number of samples that was used for PD SMI verification service
	SCALAR 'sensor1_type' = sensor type as per SYC
	SCALAR 'sensor1_orientation' = sensor orientation as per SYC
	SCALAR 'sensor2_type' = sensor type as per SYC
	SCALAR 'sensor2_orientation' = sensor orientation as per SYC
	SCALAR 'sensor3_type' = sensor type as per SYC
	SCALAR 'sensor3_orientation' = sensor orientation as per SYC
	SCALAR 'sensor4_type' = sensor type as per SYC
	SCALAR 'duration_RIDT_s' = Duration of the RIDT (in s)
	SCALAR 'rate_value_absolute_limit' = limit for the absolute rate value in deg/s
	SCALAR 'rate_Noise_RMS_limit' = limit for the rate RMS noise
	SCALAR 'rate_Noise_pk2pk_limit' = limit for the rate pk2pk noise (peak to peak noise: max - min value)
	SCALAR 'rate_Offset_Drift_Gradient_limit' = limit for the rate offset drift gradient (current value - previous value)
	SCALAR 'rate_Offset_rel_T0_limit' = limit for the rate offset to T0 (current value - first value)
	SCALAR 'accel_xy_value_absolute_limit' = limit for the xy acceleration absolute value in g
	SCALAR 'accel_z_value_absolute' = expected value for the z acceleration in g (+1 or -1)
	SCALAR 'accel_z_value_absolute_limit' = limit for the z acceleration absolute value in g
	SCALAR 'accel_Noise_RMS_limit' = limit for the acceleration RMS noise
	SCALAR 'accel_Noise_pk2pk_limit' = limit for the acceleration pk2pk noise (peak to peak noise: max - min value)
	SCALAR 'accel_Offset_Drift_Gradient_limit' = limit for the acceleration offset drift gradient (current value - previous value)
	SCALAR 'accel_Offset_rel_T0_limit' = limit for the acceleration offset (current value - first value)
    HASH   'rate_Offset_rel_T0_limits_RIDT' = series of x and y values for RIDT rate offset evaluation limits: 
                                       e.g. %( 0 => 0.5, 4 => 0.2 ) means limit is 
                                            0.5 for input values 0 <= x < 4, 
                                            0.2 for input values x >= 4
    HASH   'rate_Offset_Drift_Gradient_limits_RIDT' = series of x and y values for RIDT rate offset drift gradient evaluation limits (same structure as rate_Offset_rel_T0_limits_RIDT)
	SCALAR 'accel_Offset_rel_T0_limit_RIDT' = limit for the RIDT acceleration offset
	SCALAR 'accel_xy_Offset_Drift_Gradient_limit_RIDT' = limit for the RIDT xy acceleration offset drift gradient in g
    HASH   'accel_z_Offset_Drift_Gradient_limits_RIDT' = series of x and y values for RIDT z acceleration offset drift gradient evaluation limits (same structure as rate_Offset_rel_T0_limits_RIDT)
    HASH   'can_signals' = (optional) mapping of can signal names; 
                        keys: rotation rates ('wxcan', 'wycan', 'wzcan') and/or accelerations ('axcan', 'aycan', 'azcan')
                        values: project specific can signal names (according to dbc file) for corresponding rotation rates and accelerations
    HASH   'can_factors' = (optional) conversion factors for can signals to convert from physical units as defined in the dbc file
                           to deg/s for rates and G for accelerations;
                        keys: rotation rates ('wxcan', 'wycan', 'wzcan') and/or accelerations ('axcan', 'aycan', 'azcan')
                        values: project specific conversion factors for corresponding rotation rates and accelerations
    HASH   'can_quality_signals' = (optional) mapping of can quality signal names; 
                        keys: rotation rates ('wxcan', 'wycan', 'wzcan') and/or accelerations ('axcan', 'aycan', 'azcan')
                        values: project specific can quality signal names (according to dbc file) for corresponding rotation rates and accelerations
    HASH   'can_quality_OK_values' = (optional) values of the 'can_quality_signals' that indicate "OK"
                        keys: rotation rates ('wxcan', 'wycan', 'wzcan') and/or accelerations ('axcan', 'aycan', 'azcan')
                        values: project specific values of 'can_quality_signals' that indicate "OK"
	SCALAR 'number_of_can_samples' = (optional) Number of samples to be used for evaluation of can signals (default: 100)
    HASH   'FR_signals' = (optional) same as 'can_signals', only for flexray
    HASH   'FR_factors' = (optional) same as 'can_factors', only for flexray
    HASH   'FR_quality_signals' = (optional) same as 'can_quality_signals', only for flexray
    HASH   'FR_quality_OK_values' = (optional) same as 'can_quality_OK_values', only for flexray
	SCALAR 'number_of_FR_samples' = (optional) same as 'number_of_can_samples', only for flexray
	SCALAR 'Bus_for_PD' = (optional) bus number for PD services (default: 1). For CAN only the bus number must be given (e.g. 1), for flexray 'Fr' must be given.
    LIST   'ignore_signals' = (optional) list of signals that shall be ignored in evaluation (because they are not used in the project)


=head2 PARAMETER EXAMPLES

	[TC_SMI_TGT_RIDT_eval.trial]
	purpose	= 'SMI700/SMI710'
    project_ID = 'ProjectXY_Var1_SampleA'
	number_of_samples = 1000
	sensor1_type = 'SMI700'
	sensor1_orientation = 'Sensor in 180� on back-layer'
	sensor2_type = 'N/A'
	sensor2_orientation = 'N/A'
	sensor3_type = 'SMI710'
	sensor3_orientation = 'Sensor in 90� on back-layer'
	sensor4_type = 'N/A'
	sensor4_orientation = 'N/A'
	duration_RIDT_s = 3600
	rate_value_absolute_limit = 2
	rate_Noise_RMS_limit = 0.5
	rate_Noise_pk2pk_limit = 3.5
	rate_Offset_Drift_Gradient_limit = 0.1
	rate_Offset_rel_T0_limit = 2
	accel_xy_value_absolute_limit = 0.04
	accel_z_value_absolute = -1
	accel_z_value_absolute_limit = 0.04
	accel_Noise_RMS_limit = 0.01
	accel_Noise_pk2pk_limit = 0.06
	accel_Offset_Drift_Gradient_limit = 0.006
	accel_Offset_rel_T0_limit = 0.04
	rate_Offset_rel_T0_limits_RIDT = %( 0 => 0.5, 4 => 0.2 )
	rate_Offset_Drift_Gradient_limits_RIDT = %( 0 => 0.2, 4 => 0.1 )
	accel_Offset_rel_T0_limit_RIDT = 0.01
	accel_xy_Offset_Drift_Gradient_limit_RIDT = 0.005
	accel_z_Offset_Drift_Gradient_limits_RIDT = %( 0 => 0.012, 2 => 0.005 )
    can_signals = %( 'wzcan' => 'PSIP1', 'wxcan' => 'PHIP' )
    can_factors = %( 'wzcan' => -57.296, 'wxcan' => 57.296 )
    can_quality_signals =   %( 'wzcan' => 'PSIP1QS', 'wxcan' => 'PHIPQS' )
    can_quality_OK_values = %( 'wzcan' => 1,         'wxcan' => 1 )
    number_of_can_samples = 100
    Bus_for_PD = 1
    ignore_signals = @('ayred')

=cut

#PARAMETERS
################ Parameters from .par file ###################
my ( $tcpar_purpose,                   $tcpar_project_ID,           $tcpar_number_of_samples );
my ( $tcpar_sensor1_type,              $tcpar_sensor1_orientation,  $tcpar_sensor2_type, $tcpar_sensor2_orientation, $tcpar_sensor3_type, $tcpar_sensor3_orientation, $tcpar_sensor4_type, $tcpar_sensor4_orientation );
my ( $tcpar_rate_value_absolute_limit, $tcpar_rate_Noise_RMS_limit, $tcpar_rate_Offset_Drift_Gradient_limit, $tcpar_accel_xy_value_absolute_limit, $tcpar_accel_z_value_absolute, $tcpar_accel_z_value_absolute_limit, $tcpar_accel_Noise_RMS_limit, $tcpar_accel_Offset_Drift_Gradient_limit );
my ( $tcpar_rate_Offset_rel_T0_limits_RIDT_href, $tcpar_rate_Offset_Drift_Gradient_limits_RIDT_href, $tcpar_accel_Offset_rel_T0_limit_RIDT, $tcpar_accel_xy_Offset_Drift_Gradient_limit_RIDT, $tcpar_accel_z_Offset_Drift_Gradient_limits_RIDT_href );
my ( $tcpar_rate_Noise_pk2pk_limit,              $tcpar_rate_Offset_rel_T0_limit,                    $tcpar_accel_Noise_pk2pk_limit,        $tcpar_accel_Offset_rel_T0_limit );
my ( $tcpar_canSignals_href,                     $tcpar_canFactors_href,                             $tcpar_number_of_can_samples,          $tcpar_duration_RIDT_s );
my ( $tcpar_FRSignals_href,                      $tcpar_FRFactors_href,                              $tcpar_number_of_FR_samples,           $tcpar_Bus_for_PD,                                $tcpar_ignore_signals_aref );
my ( $tcpar_can_quality_signals_href,            $tcpar_can_quality_OK_values_href,                  $tcpar_FR_quality_signals_href,        $tcpar_FR_quality_OK_values_href );
################ global parameter declaration ###################
#add any global variables here

my ( %sensorInfo, %canSignals, %FRSignals, $sensorType );
my @FRsignalsA;

###############################################################

sub TC_set_parameters {

    ReadAllParameters();

    CheckParameters();

    $sensorInfo{1}{'type'}        = $tcpar_sensor1_type;
    $sensorInfo{1}{'orientation'} = $tcpar_sensor1_orientation;
    $sensorInfo{2}{'type'}        = $tcpar_sensor2_type;
    $sensorInfo{2}{'orientation'} = $tcpar_sensor2_orientation;
    $sensorInfo{3}{'type'}        = $tcpar_sensor3_type;
    $sensorInfo{3}{'orientation'} = $tcpar_sensor3_orientation;
    $sensorInfo{4}{'type'}        = $tcpar_sensor4_type;
    $sensorInfo{4}{'orientation'} = $tcpar_sensor4_orientation;

    if ( $tcpar_sensor1_type =~ /^SMI8/i ) {
        $sensorType = "SMI8";
    }
    else {
        $sensorType = "SMI7";
    }

    return 1;
}

sub ReadAllParameters {

    $tcpar_purpose           = S_read_mandatory_testcase_parameter('purpose');
    $tcpar_project_ID        = S_read_mandatory_testcase_parameter('project_ID');
    $tcpar_number_of_samples = S_read_mandatory_testcase_parameter('number_of_samples');
    $tcpar_sensor1_type      = S_read_mandatory_testcase_parameter('sensor1_type');

    if ( $tcpar_sensor1_type !~ /^SMI8/i ) {
        $tcpar_sensor1_orientation = S_read_mandatory_testcase_parameter('sensor1_orientation');
        $tcpar_sensor2_type        = S_read_mandatory_testcase_parameter('sensor2_type');
        $tcpar_sensor2_orientation = S_read_mandatory_testcase_parameter('sensor2_orientation');
        $tcpar_sensor3_type        = S_read_mandatory_testcase_parameter('sensor3_type');
        $tcpar_sensor3_orientation = S_read_mandatory_testcase_parameter('sensor3_orientation');
        $tcpar_sensor4_type        = S_read_mandatory_testcase_parameter('sensor4_type');
        $tcpar_sensor4_orientation = S_read_mandatory_testcase_parameter('sensor4_orientation');
    }

    $tcpar_duration_RIDT_s = S_read_mandatory_testcase_parameter('duration_RIDT_s');

    $tcpar_rate_value_absolute_limit                      = S_read_mandatory_testcase_parameter('rate_value_absolute_limit');
    $tcpar_rate_Noise_RMS_limit                           = S_read_mandatory_testcase_parameter('rate_Noise_RMS_limit');
    $tcpar_rate_Noise_pk2pk_limit                         = S_read_mandatory_testcase_parameter('rate_Noise_pk2pk_limit');
    $tcpar_rate_Offset_Drift_Gradient_limit               = S_read_mandatory_testcase_parameter('rate_Offset_Drift_Gradient_limit');
    $tcpar_rate_Offset_rel_T0_limit                       = S_read_mandatory_testcase_parameter('rate_Offset_rel_T0_limit');
    $tcpar_accel_xy_value_absolute_limit                  = S_read_mandatory_testcase_parameter('accel_xy_value_absolute_limit');
    $tcpar_accel_z_value_absolute                         = S_read_mandatory_testcase_parameter('accel_z_value_absolute');
    $tcpar_accel_z_value_absolute_limit                   = S_read_mandatory_testcase_parameter('accel_z_value_absolute_limit');
    $tcpar_accel_Noise_RMS_limit                          = S_read_mandatory_testcase_parameter('accel_Noise_RMS_limit');
    $tcpar_accel_Noise_pk2pk_limit                        = S_read_mandatory_testcase_parameter('accel_Noise_pk2pk_limit');
    $tcpar_accel_Offset_Drift_Gradient_limit              = S_read_mandatory_testcase_parameter('accel_Offset_Drift_Gradient_limit');
    $tcpar_accel_Offset_rel_T0_limit                      = S_read_mandatory_testcase_parameter('accel_Offset_rel_T0_limit');
    $tcpar_rate_Offset_rel_T0_limits_RIDT_href            = S_read_mandatory_testcase_parameter( 'rate_Offset_rel_T0_limits_RIDT', 'byref' );
    $tcpar_rate_Offset_Drift_Gradient_limits_RIDT_href    = S_read_mandatory_testcase_parameter( 'rate_Offset_Drift_Gradient_limits_RIDT', 'byref' );
    $tcpar_accel_Offset_rel_T0_limit_RIDT                 = S_read_mandatory_testcase_parameter('accel_Offset_rel_T0_limit_RIDT');
    $tcpar_accel_xy_Offset_Drift_Gradient_limit_RIDT      = S_read_mandatory_testcase_parameter('accel_xy_Offset_Drift_Gradient_limit_RIDT');
    $tcpar_accel_z_Offset_Drift_Gradient_limits_RIDT_href = S_read_mandatory_testcase_parameter( 'accel_z_Offset_Drift_Gradient_limits_RIDT', 'byref' );

    $tcpar_canSignals_href            = S_read_optional_testcase_parameter( 'can_signals',           'byref' );
    $tcpar_canFactors_href            = S_read_optional_testcase_parameter( 'can_factors',           'byref' );
    $tcpar_can_quality_signals_href   = S_read_optional_testcase_parameter( 'can_quality_signals',   'byref' );
    $tcpar_can_quality_OK_values_href = S_read_optional_testcase_parameter( 'can_quality_OK_values', 'byref' );
    $tcpar_number_of_can_samples      = S_read_optional_testcase_parameter('number_of_can_samples');

    $tcpar_FRSignals_href            = S_read_optional_testcase_parameter( 'FR_signals',           'byref' );
    $tcpar_FRFactors_href            = S_read_optional_testcase_parameter( 'FR_factors',           'byref' );
    $tcpar_FR_quality_signals_href   = S_read_optional_testcase_parameter( 'FR_quality_signals',   'byref' );
    $tcpar_FR_quality_OK_values_href = S_read_optional_testcase_parameter( 'FR_quality_OK_values', 'byref' );
    $tcpar_number_of_FR_samples      = S_read_optional_testcase_parameter('number_of_FR_samples');

    $tcpar_Bus_for_PD = S_read_optional_testcase_parameter('Bus_for_PD');

    $tcpar_ignore_signals_aref = S_read_optional_testcase_parameter( 'ignore_signals', 'byref' );

    return 1;
}

sub CheckParameters {

    # add CAN signal conversion factors to $tcpar_canSignals_href
    if ( defined $tcpar_canSignals_href ) {
        foreach my $signal ( keys %{$tcpar_canSignals_href} ) {
            $canSignals{$signal}{'name'} = $tcpar_canSignals_href->{$signal};
        }
    }
    if ( defined $tcpar_canFactors_href ) {
        foreach my $signal ( keys %{$tcpar_canFactors_href} ) {
            $canSignals{$signal}{'factor'} = $tcpar_canFactors_href->{$signal};
        }
    }

    if ( defined $tcpar_canSignals_href and not defined $tcpar_can_quality_signals_href ) {
        S_set_error("Test case parameter 'can_quality_signals' must be defined if 'can_signals' is defined");
        return 0;
    }

    if ( defined $tcpar_can_quality_signals_href and not defined $tcpar_can_quality_OK_values_href ) {
        S_set_error("Test case parameter 'can_quality_OK_values' must be defined if 'can_quality_signals' is defined");
        return 0;
    }

    my $qualityHashesMatch = 1;
    if ( defined $tcpar_can_quality_signals_href and defined $tcpar_can_quality_OK_values_href ) {
        my @quality_signals_keys       = sort keys %$tcpar_can_quality_signals_href;
        my @can_quality_OK_values_keys = sort keys %$tcpar_can_quality_OK_values_href;
        $qualityHashesMatch = ( @quality_signals_keys ~~ @can_quality_OK_values_keys );
    }
    if ( not $qualityHashesMatch ) {
        S_set_error("Test case parameters 'can_quality_signals' and 'can_quality_OK_values' must have the same keys");
        return 0;
    }

    if ( defined $tcpar_can_quality_signals_href ) {
        foreach my $signal ( keys %{$tcpar_can_quality_signals_href} ) {
            $canSignals{$signal}{'quality_signal'} = $tcpar_can_quality_signals_href->{$signal};
        }
    }

    if ( defined $tcpar_FRSignals_href ) {
        foreach my $signal ( keys %{$tcpar_FRSignals_href} ) {
            $FRSignals{$signal}{'name'} = $tcpar_FRSignals_href->{$signal};
        }
    }
    if ( defined $tcpar_FRFactors_href ) {
        foreach my $signal ( keys %{$tcpar_FRFactors_href} ) {
            $FRSignals{$signal}{'factor'} = $tcpar_FRFactors_href->{$signal};
        }
    }

    if ( defined $tcpar_FRSignals_href and not defined $tcpar_FR_quality_signals_href ) {
        S_set_error("Test case parameter 'FR_quality_signals' must be defined if 'FR_signals' is defined");
        return 0;
    }

    if ( defined $tcpar_FR_quality_signals_href and not defined $tcpar_FR_quality_OK_values_href ) {
        S_set_error("Test case parameter 'FR_quality_OK_values' must be defined if 'FR_quality_signals' is defined");
        return 0;
    }

    $qualityHashesMatch = 1;
    if ( defined $tcpar_FR_quality_signals_href and defined $tcpar_FR_quality_OK_values_href ) {
        my @quality_signals_keys      = sort keys %$tcpar_FR_quality_signals_href;
        my @FR_quality_OK_values_keys = sort keys %$tcpar_FR_quality_OK_values_href;
        $qualityHashesMatch = ( @quality_signals_keys ~~ @FR_quality_OK_values_keys );
    }
    if ( not $qualityHashesMatch ) {
        S_set_error("Test case parameters 'FR_quality_signals' and 'FR_quality_OK_values' must have the same keys");
        return 0;
    }

    if ( defined $tcpar_FR_quality_signals_href ) {
        foreach my $signal ( keys %{$tcpar_FR_quality_signals_href} ) {
            $FRSignals{$signal}{'quality_signal'} = $tcpar_FR_quality_signals_href->{$signal};
        }
    }

    if ( defined $tcpar_ignore_signals_aref and ref($tcpar_ignore_signals_aref) ne 'ARRAY' ) {
        S_set_error("Test case parameter 'ignore_signals' must be given as list: @( ... )");
        return 0;
    }
    foreach my $signal (@$tcpar_ignore_signals_aref) {
        if ( $signal !~ /^[aw][xyz]/ ) {
            S_set_error("Value '$signal' of test case parameter 'ignore_signals' does not begin with 'wx' or 'wy' or 'wz' or 'ax' or 'ay' or 'az'");
            return 0;
        }
    }

    return 1;
}

sub TC_initialization {

    CSM_init() || return;
    return 1;
}

sub TC_stimulation_and_measurement {

    return 1;
}

sub TC_evaluation {

    my $calculatedSignals_href;

    my $tcNumber = S_get_TC_number();
    my $prefix   = $tcNumber . '_';

    my $testData_href = VDS_GetDataContainer( [ $tcpar_project_ID, 'TGT_RIDT' ] );
    my $subtest_href  = $testData_href->{'subtests'};
    my @subtests      = sort keys %{$subtest_href};
    S_teststep( "Found " . scalar(@subtests) . " traces in data container with project ID '$tcpar_project_ID' and test type 'TGT_RIDT'.", 'AUTO_NBR' );
    if ( not @subtests ) {
        S_set_error("No trace found in data container with project ID '$tcpar_project_ID' and test type 'TGT_RIDT'.");
        return 0;
    }

    my $traceFile = $subtest_href->{0}{'traceFile'};
    S_teststep( "Read CAN trace $traceFile.", 'AUTO_NBR' );
    my $smiresponses_href = VDS_GetSMIResponsesFromTrace( $traceFile, $sensorType, { busForPD => $tcpar_Bus_for_PD } );

    S_teststep( "Extract SMI data.", 'AUTO_NBR' );
    my $smiData_href = {};
    foreach my $time ( sort { $a <=> $b } keys %{$smiresponses_href} ) {
        $smiData_href->{$time} = VDS_ExtractSMIDataFromPD( $smiresponses_href->{$time}, $sensorType );
    }

    S_teststep( "Extract CAN data.", 'AUTO_NBR' );
    VDS_GetSMICANDataFromTrace( $traceFile, \%canSignals, $smiData_href, $tcpar_number_of_can_samples ) if %canSignals;

    S_teststep( "Extract FR data.", 'AUTO_NBR' );
    VDS_GetSMIFRDataFromTrace( $traceFile, \%FRSignals, $smiData_href, $tcpar_number_of_FR_samples ) if %FRSignals;

    EVAL_dump2UNV($smiData_href);

    S_teststep( "Extract RIDT data.", 'AUTO_NBR' );
    my $RIDT_href = VDS_ExtractSMISubtests( $smiData_href, 250, $tcpar_duration_RIDT_s );

    S_w2log( 1, '', undef, 'TGT' );
    S_teststep( "*** Calculate, evaluate and plot TGT ***", 'AUTO_NBR' );
    $calculatedSignals_href = VDS_CalculateSMIData( $smiData_href, $tcpar_number_of_samples, \%sensorInfo, 'TGT', undef, $tcpar_number_of_can_samples );
    RemoveIgnoreSignals( $calculatedSignals_href, $tcpar_ignore_signals_aref ) if defined $tcpar_ignore_signals_aref;

    # do here all evaluations and plots for TGT
    Evaluate_TGT( $smiData_href, $prefix, $calculatedSignals_href );

    EVAL_dump2UNV($smiData_href);

    # determine value of $offsetSeparationIndex
    my ($offsetSeparationIndex);
    my @offsetLimitIndices = sort { $a <=> $b } keys %{$tcpar_rate_Offset_rel_T0_limits_RIDT_href};
    my $zeroIndex = $offsetLimitIndices[0];
    if ( @offsetLimitIndices == 1 ) {
        $offsetSeparationIndex = undef;
    }
    elsif ( @offsetLimitIndices == 2 ) {
        $offsetSeparationIndex = $offsetLimitIndices[1];
    }
    else {
        S_set_error("Test case parameter 'rate_Offset_rel_T0_limits_RIDT' must have 1 or 2 keys.");
        return 0;
    }

    # loop over the RIDT subtests
    foreach my $subtest ( sort keys %{$RIDT_href} ) {
        my $temperature = $RIDT_href->{$subtest}{'temperature'};
        $prefix = $tcNumber . '_' . $temperature . '_';

        S_w2log( 1, '', undef, "RIDT_$temperature" );
        S_teststep( "*** Calculate, evaluate and plot $temperature RIDT ***", 'AUTO_NBR' );
        $calculatedSignals_href = VDS_CalculateSMIData( $RIDT_href->{$subtest}{'data'}, $tcpar_number_of_samples, \%sensorInfo, 'RIDT', $offsetSeparationIndex );
        RemoveIgnoreSignals( $calculatedSignals_href, $tcpar_ignore_signals_aref ) if defined $tcpar_ignore_signals_aref;

        # do here all evaluations and plots for RIDT $subtest
        Evaluate_RIDT( $RIDT_href->{$subtest}, $temperature, $prefix, $calculatedSignals_href, $offsetSeparationIndex, $zeroIndex );

        S_wait_ms(1000);    # wait so that a new unv file (with new date/time stamp) is surely created
        EVAL_dump2UNV( $RIDT_href->{$subtest}{'data'} );
    }

    my $repeatSubtest = 3;

    return 1 if not defined $RIDT_href->{$repeatSubtest}{'data'};

    # evaluate repeatability if data for 23�C repeat subtest exist
    S_w2log( 1, '', undef, "RIDT_repeatability" );
    S_teststep( "*** Calculate, evaluate and plot data for repeatability ***", 'AUTO_NBR' );

    # calculate repeatability values
    my ( $rateRepeat_aref, $accelRepeat_aref ) = CalculateReapeatability( $RIDT_href, $repeatSubtest, $calculatedSignals_href );

    # plot and evaluate repeatabilities
    $prefix = $tcNumber . '_';
    S_teststep_2nd_level( "Evaluate RIDT 23�_rate_repeatability", 'AUTO_NBR' );
    EVAL_evaluateAndPlotDataWithLimits( $RIDT_href->{0}{'data'}, $prefix . '23�_Repeatability_rate', $rateRepeat_aref, "abs < $tcpar_rate_Offset_Drift_Gradient_limit", "rotation rate repeatability in �/s" );
    S_teststep_2nd_level( "Evaluate RIDT 23�_accel_repeatability", 'AUTO_NBR' );
    EVAL_evaluateAndPlotDataWithLimits( $RIDT_href->{0}{'data'}, $prefix . '23�_Repeatability_accel', $accelRepeat_aref, "abs < $tcpar_accel_Offset_Drift_Gradient_limit", "acceleration repeatability in G" );

    VDS_WriteEvalData2xml( "TGT/RIDT", $testData_href->{'metaData'} );

    VDS_CloseDataContainer( $testData_href->{'container_id'} );

    return 1;
}

sub TC_finalization {

    return 1;
}

#
# Print and evaluate minimum and maximum values for offset values
#
sub PrintAndEvaluateOffsetMinMaxValues {
    my $calculatedSignals_href = shift;
    my $signalGroup            = shift;
    my $offsetSeparationIndex  = shift;
    my $limit_t0               = shift;
    my $limit_t1               = shift;

    # loop over all signals in $signalGroup (rate_Offset_rel_T0 or acceleration_Offset_rel_T0)
    foreach my $offsetSignal ( @{ $calculatedSignals_href->{$signalGroup} } ) {

        # if $offsetSeparationIndex is defined then offsets are calculated in 2 time ranges: 0 <= t < $offsetSeparationIndex and $offsetSeparationIndex <= t <= end
        if ( defined $offsetSeparationIndex ) {
            PrintAndEvaluateOneRange( $calculatedSignals_href, $offsetSignal, 't0', $offsetSeparationIndex, $limit_t0 );
            PrintAndEvaluateOneRange( $calculatedSignals_href, $offsetSignal, 't1', $offsetSeparationIndex, $limit_t1 );
        }

        # if $offsetSeparationIndex is not defined then offsets are calculated in only 1 time range: 0 <= t <= end (first time range)
        else {
            PrintAndEvaluateOneRange( $calculatedSignals_href, $offsetSignal, 't0', $offsetSeparationIndex, $limit_t0 );
        }
    }
}

#
# Print and evaluate minimum and maximum values for one range.
# Evaluation is only done if $limit is defined
#
sub PrintAndEvaluateOneRange {
    my $calculatedSignals_href = shift;
    my $offsetSignal           = shift;
    my $range                  = shift;
    my $offsetSeparationIndex  = shift;
    my $limit                  = shift;

    # get min/max values of time range
    my $minValue = $calculatedSignals_href->{ $offsetSignal . '_' . $range . '_min' };
    my $maxValue = $calculatedSignals_href->{ $offsetSignal . '_' . $range . '_max' };

    my $rangeText;
    if ( defined $offsetSeparationIndex and $range eq 't0' ) {
        $rangeText = "for t < $offsetSeparationIndex min";
    }
    elsif ( defined $offsetSeparationIndex and $range eq 't1' ) {
        $rangeText = "for t >= $offsetSeparationIndex min";
    }
    else {
        $rangeText = "";
    }
    S_w2rep( "Offsetstability_max_min_TGT of $offsetSignal $rangeText are: minimum = " . sprintf( "%.5f", $minValue ) . " ,  maximum = " . sprintf( "%.5f", $maxValue ) . " ,  maximum-minimum = " . sprintf( "%.5f", $maxValue - $minValue ) );

    # evaluate min/max values of time range against limit $limit (if defined)
    EVAL_evaluate_value( "Offsetstability_max_min_" . $offsetSignal . " offset $rangeText", sprintf( "%.5f", $maxValue - $minValue ), '<', $limit ) if defined $limit;
}

#
# Remove the signals that are defined as to be ignored
#
sub RemoveIgnoreSignals {
    my $calculatedSignals_href = shift;
    my $ignore_signals_aref    = shift;

    foreach my $ignoreSignal (@$ignore_signals_aref) {
        foreach my $signalGroup ( keys %{$calculatedSignals_href} ) {
            next if ref( $calculatedSignals_href->{$signalGroup} ) ne 'ARRAY';
            my @signals = @{ $calculatedSignals_href->{$signalGroup} };
            my $regex   = $ignoreSignal . '(_\w+$)?$';                    # match all strings with $ignoreSignal at the end or $ignoreSignal followed by '_...' at the end
            @signals = grep { $_ !~ /$regex/ } @signals;                  # remove all signals from @signals which match to $regex
            @{ $calculatedSignals_href->{$signalGroup} } = @signals;
        }
    }
    return 1;
}

#
# Evaluate the quality signals on the bus against expected values given as TC parameters
#
sub EvaluateQualitySignals {
    my $calculatedSignals_href = shift;
    my $smiData_href           = shift;

    foreach my $qualitySignal ( @{ $calculatedSignals_href->{'quality'} } ) {
        if ( $qualitySignal =~ /^Quality_(\w+?)_/ ) {
            my $signal = $1;
            my $expectedValue = $tcpar_can_quality_OK_values_href->{$signal} // $tcpar_FR_quality_OK_values_href->{$signal};    # use can values if defined, otherwise FR values
            EVAL_evaluate_value_over_time( $smiData_href, $qualitySignal, '==', $expectedValue );
        }
    }
    return 1;
}

#
# Do all evaluation and plotting for the TGT part
#
sub Evaluate_TGT {
    my $smiData_href           = shift;
    my $prefix                 = shift;
    my $calculatedSignals_href = shift;

    S_teststep_2nd_level( "Plot Temperatures_TGT", 'AUTO_NBR' );
    EVAL_evaluateAndPlotDataWithLimits( $smiData_href, $prefix . 'Temperatures_TGT', $calculatedSignals_href->{'temperatures'}, undef, "temperature in �C" );

    S_teststep_2nd_level( "Evaluate Offset_absolute_TGT_rate", 'AUTO_NBR' );
    EVAL_evaluateAndPlotDataWithLimits( $smiData_href, $prefix . 'Offset_absolute_TGT_rate', $calculatedSignals_href->{'rate'}, "abs < $tcpar_rate_value_absolute_limit", "rotation rate in �/s" );

    S_teststep_2nd_level( "Evaluate Noise_RMS_TGT_rate", 'AUTO_NBR' );
    EVAL_evaluateAndPlotDataWithLimits( $smiData_href, $prefix . 'Noise_RMS_TGT_rate', $calculatedSignals_href->{'rate_Noise_RMS'}, "value < $tcpar_rate_Noise_RMS_limit", "rotation rate noise in �/s" );

    S_teststep_2nd_level( "Evaluate Noise_pk2pk_TGT_rate", 'AUTO_NBR' );
    EVAL_evaluateAndPlotDataWithLimits( $smiData_href, $prefix . 'Noise_pk2pk_TGT_rate', $calculatedSignals_href->{'rate_Noise_pk2pk'}, "value < $tcpar_rate_Noise_pk2pk_limit", "rotation rate p2p noise in �/s" );

    S_teststep_2nd_level( "Evaluate Offset_Drift_Gradient_TGT_rate", 'AUTO_NBR' );
    EVAL_evaluateAndPlotDataWithLimits( $smiData_href, $prefix . 'Offset_Drift_Gradient_TGT_rate', $calculatedSignals_href->{'rate_Offset_Drift_Gradient'}, "abs < $tcpar_rate_Offset_Drift_Gradient_limit", "rotation rate offset drift gradient in �/s" );

    S_teststep_2nd_level( "Plot Offset_rel_T0_TGT_rate", 'AUTO_NBR' );
    EVAL_evaluateAndPlotDataWithLimits( $smiData_href, $prefix . 'Offset_rel_T0_TGT_rate', $calculatedSignals_href->{'rate_Offset_rel_T0'}, "abs < $tcpar_rate_Offset_rel_T0_limit", "rotation rate offset in �/s" );
    PrintAndEvaluateOffsetMinMaxValues( $calculatedSignals_href, 'rate_Offset_rel_T0', undef, $tcpar_rate_Offset_rel_T0_limit );

    S_teststep_2nd_level( "Evaluate Offset_absolute_TGT_accel_xy", 'AUTO_NBR' );
    EVAL_evaluateAndPlotDataWithLimits( $smiData_href, $prefix . 'Offset_absolute_TGT_accel_xy', $calculatedSignals_href->{'accel_xy'}, "abs < $tcpar_accel_xy_value_absolute_limit", "acceleration in G" );

    if ( defined $calculatedSignals_href->{'accel_z'} ) {
        S_teststep_2nd_level( "Evaluate Offset_absolute_TGT_accel_z", 'AUTO_NBR' );
        EVAL_evaluateAndPlotDataWithLimits( $smiData_href, $prefix . 'Offset_absolute_TGT_accel_z', $calculatedSignals_href->{'accel_z'}, "value = $tcpar_accel_z_value_absolute+-$tcpar_accel_z_value_absolute_limit", "acceleration in G" );
    }

    S_teststep_2nd_level( "Evaluate Noise_RMS_TGT_accel", 'AUTO_NBR' );
    EVAL_evaluateAndPlotDataWithLimits( $smiData_href, $prefix . 'Noise_RMS_TGT_accel', $calculatedSignals_href->{'accel_Noise_RMS'}, "value < $tcpar_accel_Noise_RMS_limit", "acceleration noise in G" );

    S_teststep_2nd_level( "Evaluate Noise_pk2pk_TGT_accel", 'AUTO_NBR' );
    EVAL_evaluateAndPlotDataWithLimits( $smiData_href, $prefix . 'Noise_pk2pk_TGT_accel', $calculatedSignals_href->{'accel_Noise_pk2pk'}, "value < $tcpar_accel_Noise_pk2pk_limit", "acceleration p2p noise in G" );

    S_teststep_2nd_level( "Evaluate Offset_Drift_Gradient_TGT_accel", 'AUTO_NBR' );
    EVAL_evaluateAndPlotDataWithLimits( $smiData_href, $prefix . 'Offset_Drift_Gradient_TGT_accel', $calculatedSignals_href->{'accel_Offset_Drift_Gradient'}, "abs < $tcpar_accel_Offset_Drift_Gradient_limit", "acceleration offset drift gradient in G" );

    S_teststep_2nd_level( "Plot Offset_rel_T0_TGT_accel", 'AUTO_NBR' );
    EVAL_evaluateAndPlotDataWithLimits( $smiData_href, $prefix . 'Offset_rel_T0_TGT_accel', $calculatedSignals_href->{'accel_Offset_rel_T0'}, "abs < $tcpar_accel_Offset_rel_T0_limit", "acceleration offset in G" );
    PrintAndEvaluateOffsetMinMaxValues( $calculatedSignals_href, 'accel_Offset_rel_T0', undef, $tcpar_accel_Offset_rel_T0_limit );

    if ( defined $tcpar_can_quality_signals_href or defined $tcpar_FR_quality_signals_href ) {
        S_teststep_2nd_level( "Evaluate quality signals", 'AUTO_NBR' );
        EvaluateQualitySignals( $calculatedSignals_href, $smiData_href );
        EVAL_evaluateAndPlotDataWithLimits( $smiData_href, $prefix . 'Quality_signals', $calculatedSignals_href->{'quality'}, undef, "" );
    }

    return 1;
}

#
# Do all evaluation and plotting for one RIDT part
#
sub Evaluate_RIDT {
    my $RIDTsubtest_href       = shift;
    my $temperature            = shift;
    my $prefix                 = shift;
    my $calculatedSignals_href = shift;
    my $offsetSeparationIndex  = shift;
    my $zeroIndex              = shift;

    S_teststep_2nd_level( "Evaluate $temperature Offset_rel_T0_RIDT_rate", 'AUTO_NBR' );
    my $rateOffsetLimitName = $temperature . '_rate_Offset_rel_T0_limit_RIDT';
    my $rateOffsetLimitString = VDS_GetMultipleLimitString( $tcpar_rate_Offset_rel_T0_limits_RIDT_href, $rateOffsetLimitName );
    EVAL_dataCalculationOverTime( $RIDTsubtest_href->{'data'}, $rateOffsetLimitName, $rateOffsetLimitString, ['timeIndex'] );
    EVAL_evaluateAndPlotDataWithLimits( $RIDTsubtest_href->{'data'}, $prefix . 'Offset_rel_T0_RIDT_rate', $calculatedSignals_href->{'rate_Offset_rel_T0'}, "abs < $rateOffsetLimitName", "rotation rate offset in �/s" );

    S_teststep_2nd_level( "Evaluate $temperature Offsetstability_max_min_RIDT_rate", 'AUTO_NBR' );
    PrintAndEvaluateOffsetMinMaxValues( $calculatedSignals_href, 'rate_Offset_rel_T0', $offsetSeparationIndex, $tcpar_rate_Offset_rel_T0_limits_RIDT_href->{$zeroIndex}, $tcpar_rate_Offset_rel_T0_limits_RIDT_href->{$offsetSeparationIndex} );

    if ( defined $offsetSeparationIndex ) {
        S_teststep_2nd_level( "Evaluate $temperature Offset_rel_T0_overall_RIDT_rate", 'AUTO_NBR' );
        my $rateOffsetOverallLimit = $tcpar_rate_Offset_rel_T0_limits_RIDT_href->{$zeroIndex};
        EVAL_evaluateAndPlotDataWithLimits( $RIDTsubtest_href->{'data'}, $prefix . 'Offset_rel_T0_overall_RIDT_rate', $calculatedSignals_href->{'rate_Offset_rel_T0_overall'}, "abs < $rateOffsetOverallLimit", "rotation rate offset in �/s" );

        S_teststep_2nd_level( "Evaluate $temperature Offsetstability_max_min_overall_RIDT_rate", 'AUTO_NBR' );
        PrintAndEvaluateOffsetMinMaxValues( $calculatedSignals_href, 'rate_Offset_rel_T0_overall', undef, $rateOffsetOverallLimit );
    }

    S_teststep_2nd_level( "Evaluate $temperature Offset_Drift_Gradient_RIDT_rate", 'AUTO_NBR' );
    my $rateDriftGradientLimitName = $temperature . '_rate_Offset_Drift_Gradient_limit_RIDT';
    my $rateDriftGradientLimitString = VDS_GetMultipleLimitString( $tcpar_rate_Offset_Drift_Gradient_limits_RIDT_href, $rateDriftGradientLimitName );
    EVAL_dataCalculationOverTime( $RIDTsubtest_href->{'data'}, $rateDriftGradientLimitName, $rateDriftGradientLimitString, ['timeIndex'] );
    EVAL_evaluateAndPlotDataWithLimits( $RIDTsubtest_href->{'data'}, $prefix . 'Offset_Drift_Gradient_RIDT_rate', $calculatedSignals_href->{'rate_Offset_Drift_Gradient'}, "abs < $rateDriftGradientLimitName", "rotation rate offset drift gradient in �/s" );

    S_teststep_2nd_level( "Evaluate $temperature Noise_RMS_RIDT_rate", 'AUTO_NBR' );
    EVAL_evaluateAndPlotDataWithLimits( $RIDTsubtest_href->{'data'}, $prefix . 'Noise_RMS_RIDT_rate', $calculatedSignals_href->{'rate_Noise_RMS'}, "value < $tcpar_rate_Noise_RMS_limit", "rotation rate noise in �/s" );

    S_teststep_2nd_level( "Evaluate $temperature Noise_pk2pk_RIDT_rate", 'AUTO_NBR' );
    EVAL_evaluateAndPlotDataWithLimits( $RIDTsubtest_href->{'data'}, $prefix . 'Noise_pk2pk_RIDT_rate', $calculatedSignals_href->{'rate_Noise_pk2pk'}, "value < $tcpar_rate_Noise_pk2pk_limit", "rotation rate p2p noise in �/s" );

    S_teststep_2nd_level( "Evaluate $temperature Offset_rel_T0_RIDT_accel", 'AUTO_NBR' );
    EVAL_evaluateAndPlotDataWithLimits( $RIDTsubtest_href->{'data'}, $prefix . 'Offset_rel_T0_RIDT_accel', $calculatedSignals_href->{'accel_Offset_rel_T0'}, "abs < $tcpar_accel_Offset_rel_T0_limit_RIDT", "acceleration offset in G" );

    S_teststep_2nd_level( "Evaluate $temperature Offsetstability_max_min_RIDT_accel", 'AUTO_NBR' );
    PrintAndEvaluateOffsetMinMaxValues( $calculatedSignals_href, 'accel_Offset_rel_T0', $offsetSeparationIndex, $tcpar_accel_Offset_rel_T0_limit_RIDT, $tcpar_accel_Offset_rel_T0_limit_RIDT );

    if ( defined $offsetSeparationIndex ) {
        S_teststep_2nd_level( "Evaluate $temperature Offset_rel_T0_overall_RIDT_accel", 'AUTO_NBR' );
        EVAL_evaluateAndPlotDataWithLimits( $RIDTsubtest_href->{'data'}, $prefix . 'Offset_rel_T0_overall_RIDT_accel', $calculatedSignals_href->{'accel_Offset_rel_T0_overall'}, "abs < $tcpar_accel_Offset_rel_T0_limit_RIDT", "acceleration offset in �/s" );

        S_teststep_2nd_level( "Evaluate $temperature Offsetstability_max_min_overall_RIDT_accel", 'AUTO_NBR' );
        PrintAndEvaluateOffsetMinMaxValues( $calculatedSignals_href, 'accel_Offset_rel_T0_overall', undef, $tcpar_accel_Offset_rel_T0_limit_RIDT );
    }

    S_teststep_2nd_level( "Evaluate $temperature Offset_Drift_Gradient_RIDT_accel_xy", 'AUTO_NBR' );
    EVAL_evaluateAndPlotDataWithLimits( $RIDTsubtest_href->{'data'}, $prefix . 'Offset_Drift_Gradient_RIDT_accel_xy', $calculatedSignals_href->{'accel_xy_Offset_Drift_Gradient'}, "abs < $tcpar_accel_xy_Offset_Drift_Gradient_limit_RIDT", "acceleration offset drift gradient in G" );

    if ( defined $calculatedSignals_href->{'accel_z_Offset_Drift_Gradient'} ) {
        S_teststep_2nd_level( "Evaluate $temperature Offset_Drift_Gradient_RIDT_accel_z", 'AUTO_NBR' );
        my $accelDeltaLimitName = $temperature . '_accel_z_Offset_Drift_Gradient_limit_RIDT';
        my $accelDeltaLimitString = VDS_GetMultipleLimitString( $tcpar_accel_z_Offset_Drift_Gradient_limits_RIDT_href, $accelDeltaLimitName );
        EVAL_dataCalculationOverTime( $RIDTsubtest_href->{'data'}, $accelDeltaLimitName, $accelDeltaLimitString, ['timeIndex'] );
        EVAL_evaluateAndPlotDataWithLimits( $RIDTsubtest_href->{'data'}, $prefix . 'Offset_Drift_Gradient_RIDT_accel_z', $calculatedSignals_href->{'accel_z_Offset_Drift_Gradient'}, "abs < $accelDeltaLimitName", "acceleration offset drift gradient in G" );
    }

    S_teststep_2nd_level( "Evaluate $temperature Noise_RMS_RIDT_accel", 'AUTO_NBR' );
    EVAL_evaluateAndPlotDataWithLimits( $RIDTsubtest_href->{'data'}, $prefix . 'Noise_RMS_RIDT_accel', $calculatedSignals_href->{'accel_Noise_RMS'}, "value < $tcpar_accel_Noise_RMS_limit", "acceleration noise in G" );

    S_teststep_2nd_level( "Evaluate $temperature Noise_pk2pk_RIDT_accel", 'AUTO_NBR' );
    EVAL_evaluateAndPlotDataWithLimits( $RIDTsubtest_href->{'data'}, $prefix . 'Noise_pk2pk_RIDT_accel', $calculatedSignals_href->{'accel_Noise_pk2pk'}, "value < $tcpar_accel_Noise_pk2pk_limit", "acceleration p2p noise in G" );

    if ( defined $tcpar_can_quality_signals_href or defined $tcpar_FR_quality_signals_href ) {
        S_teststep_2nd_level( "Evaluate $temperature quality signals", 'AUTO_NBR' );
        EvaluateQualitySignals( $calculatedSignals_href, $RIDTsubtest_href->{'data'} );
        EVAL_evaluateAndPlotDataWithLimits( $RIDTsubtest_href->{'data'}, $prefix . 'Quality_signals', $calculatedSignals_href->{'quality'}, undef, "" );
    }

    return 1;
}

#
# Calculate repeatability values (difference between first and second room temperature values)
#
sub CalculateReapeatability {
    my $RIDT_href              = shift;
    my $repeatSubtest          = shift;
    my $calculatedSignals_href = shift;

    my @times23       = sort { $a <=> $b } keys %{ $RIDT_href->{0}{'data'} };
    my @times23repeat = sort { $a <=> $b } keys %{ $RIDT_href->{$repeatSubtest}{'data'} };
    foreach my $timeIndex ( 0 .. @times23 - 1 ) {
        my $time23       = $times23[$timeIndex];
        my $time23repeat = $times23repeat[$timeIndex];

        # calculate repeatability for rates
        foreach my $signal ( @{ $calculatedSignals_href->{'rate'} } ) {
            my $value23       = $RIDT_href->{0}{'data'}{$time23}{$signal};
            my $value23repeat = $RIDT_href->{$repeatSubtest}{'data'}{$time23repeat}{$signal};
            my $repeatability = $value23 - $value23repeat;
            $RIDT_href->{0}{'data'}{$time23}{ 'Repeatability_RIDT_' . $signal } = $repeatability;
        }

        # calculate repeatability for accelerations
        foreach my $signal ( @{ $calculatedSignals_href->{'accel_xy'} }, @{ $calculatedSignals_href->{'accel_z'} } ) {
            my $value23       = $RIDT_href->{0}{'data'}{$time23}{$signal};
            my $value23repeat = $RIDT_href->{$repeatSubtest}{'data'}{$time23repeat}{$signal};
            my $repeatability = $value23 - $value23repeat;
            $RIDT_href->{0}{'data'}{$time23}{ 'Repeatability_RIDT_' . $signal } = $repeatability;
        }
    }

    # create lists of repeatability signals
    my ( @rateRepeat, @accelRepeat );
    foreach my $signal ( @{ $calculatedSignals_href->{'rate'} } ) {
        push( @rateRepeat, 'Repeatability_RIDT_' . $signal );
    }
    foreach my $signal ( @{ $calculatedSignals_href->{'accel_xy'} }, @{ $calculatedSignals_href->{'accel_z'} } ) {
        push( @accelRepeat, 'Repeatability_RIDT_' . $signal );
    }

    return ( \@rateRepeat, \@accelRepeat );
}

1;
