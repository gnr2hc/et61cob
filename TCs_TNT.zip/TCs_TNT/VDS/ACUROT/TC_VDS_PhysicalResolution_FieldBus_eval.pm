#### TEST CASE MODULE
package TC_VDS_PhysicalResolution_FieldBus_eval;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
use Statistics::Basic qw(:all);

###-------------------------------###
our $VERSION = q$Revision: 1.2 $;
our $HEADER  = q$Header: VDS/ACUROT/TC_VDS_PhysicalResolution_FieldBus_eval.pm 1.2 2019/04/01 18:15:19ICT Andrews Xavier Jesu (RBEI/EVS) (XAA1COB) develop  $;

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_evaluation;
use LIFT_can_access;
use LIFT_flexray_access;
use LIFT_CSM;
use FuncLib_VDS;
use Data::Dumper;

##################################

our $PURPOSE = "Test of PhyisicalResolution - evaluation part";

# DOCUMENTATION

=head1 TESTCASE MODULE

TC_VDS_PhysicalResolution_FieldBus_eval

=head1 PURPOSE

From HLD:

The test case shall set different Rotation rates / accelerations (with determined step) during an specific time, and measure the samples on the BUS (during this time). 
Then calculate the Resolution using the following formula:
            
            RES(n) = y(n) - y(n-1)  for n = 1 ... 20

 y(n) is the average of the measured samples the Rate/acceleration set.
 y(n-1) is the average of the measured samples the previous Rate/acceleration set.
 
 All the calculated RES should be inside the Range according to Customer Requirements.
 
=head1 TESTCASE DESCRIPTION

This an offline evaluation test case. 
The corresponding stimulation test case (TC_VDS_PhysicalResolution_FieldBus_stim.pm) must be executed before this test 
to record network traces in a CSM container.

I<B<Preconditions>>

A CSM container with network traces with recorded power up behaviour for the system under test must be available.


I<B<Initialisation>>

    - nothing

I<B<Stimulation and Measurement>>

    - nothing, see TC_VDS_PhysicalResolution_FieldBus_stim

I<B<Evaluation>>

    - Load data container with project ID 'project_ID'
    - Read Can Traces for all the measurements performed for 'MovingDirection' (one trace file for simulated Value, 20 in total)
    - for each trace, Get all the Data Samples of signal 'VDS_CAN_signal' or 'VDS_FR_signal' between 'TIME_LOG_START' and 'TIME_LOG_END'
    - Convert the Samples with 'Factor'
    - Calculate the Average of the Samples for each one of the measured traces (20). 
    - Calculate the physical Resolution with the formula: RES(n) = y(n) - y(n-1)  for n = 1 ... 20
    - Compare all the Points of the Phyisical Resolution with 'Cust_RES' +/- 'Tolerance'
    - Plot all the points of the phyisical Resolution and the limit values.


I<B<Finalisation>>

    - nothing

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

    SCALAR 'purpose' = Purpose of the Testcase
    SCALAR 'project_ID' = Unique project ID (same as in stimulation test case).
    SCALAR 'MovingDirection' = Axis of the ECU that points downwards. Must be 'x', 'y' or 'z'.
                              Same as in stimulation test case.
    SCALAR 'VDS_CAN_signal' = (optional) VDS signal on CAN to be evaluated for Sensor 'MovingDirection'.
    SCALAR 'VDS_FR_signal' = (optional) VDS signal on FR to be evaluated for Sensor 'MovingDirection'..
    SCALAR 'Factor' = (optional)conversion factor for can signals to convert from physical units as defined in the dbc file to deg/s for rates and G for accelerations
    SCALAR 'Cust_RES' = Physical Resolution required by the Customer
    SCALAR 'Tolerance' = Accepted Tolerance.
    SCALAR 'TIME_LOG_START' = Time of the first Data Sample to be taken in account for Evaluation
    SCALAR 'TIME_LOG_END' = Time of the last Data Sample to be taken in account for Evaluation
 
    Note: 
    At least one of the test case parameters 'VDS_CAN_signal' and 'VDS_FR_signal' must be defined.

=head2 PARAMETER EXAMPLES

    [TC_VDS_PhysicalResolution_FieldBus_eval.example]
    purpose = 'example'
    project_ID = 'ProjectXY_Var1_SampleA'
    MovingDirection = 'ax'
    VDS_CAN_signal = 'ALgt1'
    Factor = 1
    Cust_RES = 0.0235
    Tolerance = 0.0044


=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_project_ID;
my $tcpar_MovingDirection;
my $tcpar_VDS_CAN_signal;
my $tcpar_VDS_FR_signal;
my $tcpar_Factor;
my $tcpar_Cust_RES;
my $tcpar_Tolerance;
my $tcpar_TIME_LOG_START;
my $tcpar_TIME_LOG_END;
my $tcpar_AmountOfTraces;

################ global parameter declaration ###################
#add any global variables here
my ($powerOnTimeStamp_s, $BusSignal, $tcNumber,$graphTitle,$HighLimit,$LowLimit);
my @RES_aref;

###############################################################

sub TC_set_parameters {
    
    $tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
    $tcpar_project_ID =  S_read_mandatory_testcase_parameter( 'project_ID' );
    $tcpar_MovingDirection =  S_read_mandatory_testcase_parameter( 'MovingDirection' );
    $tcpar_VDS_CAN_signal =  S_read_optional_testcase_parameter( 'VDS_CAN_signal' );
    $tcpar_VDS_FR_signal =  S_read_optional_testcase_parameter( 'VDS_FR_signal' );
    $tcpar_Factor =  S_read_optional_testcase_parameter( 'Factor' );
    $tcpar_Cust_RES =  S_read_mandatory_testcase_parameter( 'Cust_RES' );
    $tcpar_Tolerance =  S_read_mandatory_testcase_parameter( 'Tolerance' );
    $tcpar_TIME_LOG_START =  S_read_mandatory_testcase_parameter( 'TIME_LOG_START' );
    $tcpar_TIME_LOG_END =  S_read_mandatory_testcase_parameter( 'TIME_LOG_END' );
    $tcpar_AmountOfTraces =  S_read_mandatory_testcase_parameter( 'AmountOfTraces' );

    
    # check validity of $tcpar_down_direction
    if ( $tcpar_MovingDirection !~ /^[aw][xyz]$/i ) {
        S_set_error("Given parameter 'MovingDirection' = '$tcpar_MovingDirection' is none of the following allowed:  'wx', 'wy', 'wz', 'ax', 'ay', 'az'");
        return 0;
    }

    if( not defined $tcpar_VDS_CAN_signal and not defined $tcpar_VDS_FR_signal ) {
        S_set_error("At least one of the test case parameters 'VDS_CAN_signal' and 'VDS_FR_signal' must be defined");
        return 0;
    }

    $HighLimit = $tcpar_Cust_RES+$tcpar_Tolerance;
    $LowLimit = $tcpar_Cust_RES-$tcpar_Tolerance;
    
    return 1;
}

sub TC_initialization {

    $tcNumber = S_get_TC_number();
    CSM_init() || return;
    
    return 1;
}

sub TC_stimulation_and_measurement {

    return 1;
}

sub TC_evaluation {

    my $testData_href = VDS_GetDataContainer( [ $tcpar_project_ID, 'PhysicalResolution', $tcpar_MovingDirection] );
    my $subtest_href  = $testData_href->{'subtests'};
    my @subtests      = sort keys %{$subtest_href};
    
    S_teststep( "Found " . scalar(@subtests) . " bus traces in data container with project ID '$tcpar_project_ID' and keyword PhysicalResolution_$tcpar_MovingDirection.", 'AUTO_NBR' );
    if ( not @subtests ) {
        S_set_error("No bus trace found in data container with project ID '$tcpar_project_ID' and keyword PhysicalResolution_$tcpar_MovingDirection.");
        return 0;
    }
    
    if ( scalar(@subtests) != $tcpar_AmountOfTraces ) {
        S_set_error("Amount of traces found in data container with project ID '$tcpar_project_ID' and keyword 'PhysicalResolution' _ $tcpar_MovingDirection does not match with expected simulation values according to HLD: 20 in ");
        return 0;
    }
    $tcpar_AmountOfTraces = $tcpar_AmountOfTraces-1;
    my $count =0;
    my @Average_aref;
    
    for my $i (0...$tcpar_AmountOfTraces) {
        my $BUSMeasureData_href;
        $count++;
        
        S_teststep( "Reading bus trace $count for direction $tcpar_MovingDirection", 'AUTO_NBR' );
        my $traceFile   = $subtest_href->{$i}{'traceFile'};
        
        
        S_teststep( "Extract CAN/FR signals from bus trace", 'AUTO_NBR' );
        
        if (defined $tcpar_VDS_CAN_signal)
        {
            $BusSignal = $tcpar_VDS_CAN_signal;
            $BUSMeasureData_href = CA_trace_get_dataref( $traceFile, [$BusSignal]);
            S_dump2pmFile (    "VariableToDump" => $BUSMeasureData_href,
                         "PackageName" => "Trace".$count);
            
        }
        else{
            $BusSignal = $tcpar_VDS_FR_signal;
            $BUSMeasureData_href=FR_trace_get_dataref( $traceFile, [$BusSignal] );        
        }
       
       
        if( not defined $BUSMeasureData_href ) {
            S_set_error("Could not find any of the signal $BusSignal in the trace");
            next;
        }
       
        S_teststep( "Get All the Data Samples for the Signal $BusSignal in Trace $count ", 'AUTO_NBR' );
        
        my @BUSDataSamples = EVAL_get_values_over_time ( $BUSMeasureData_href , $BusSignal, $tcpar_TIME_LOG_START , $tcpar_TIME_LOG_END );

        S_teststep( "Calculate the Average of the Samples for each one of the measured traces. Trace $count", 'AUTO_NBR' );
        
        my $Average = mean(@BUSDataSamples);
        $Average = -$Average if ($Average < 0);
        
        S_w2rep( "Average: $Average");
        push (@Average_aref, $Average);  

        my $stddev   = stddev(@BUSDataSamples);
        
        S_w2rep("Standard Deviation = $stddev in trace $count");         
    }
    
    S_teststep( "Calculate RES and compare it with Expected RES", 'AUTO_NBR' );
    
    my $Calculated_RES= 0;
    
    for my $i (1..$tcpar_AmountOfTraces){
        
        S_w2log(4, "Calculate RES for Point n=$i with: RES(n) = y(n) - y(n-1)");
        S_w2log(4, "y(n) = $Average_aref[$i]"); 
        S_w2log(4,"y(n-1) = $Average_aref[$i-1]");
        
        #$Calculated_RES = $Average_aref[$i]-$Average_aref[$i-1];
		$Calculated_RES = ($Average_aref[$i]-$Average_aref[$i-1]) * $tcpar_Factor;
        $Calculated_RES = abs $Calculated_RES;
        S_w2rep( "Compare Calculated RES: $Calculated_RES with $tcpar_Cust_RES (Cust_Res) +/- $tcpar_Tolerance (Tolerance)");
        EVAL_evaluate_value ( "Calculated RES for point $i", $Calculated_RES, '==', $tcpar_Cust_RES , $tcpar_Tolerance , 'absolute' );       # check with 0.5 absolute tolerance   
        push (@RES_aref, $Calculated_RES);
    }
    
    S_teststep( "Plot RES for sensor $tcpar_MovingDirection", 'AUTO_NBR' );

    
    my @HighLimit_aref = ($HighLimit) x $tcpar_AmountOfTraces;
    my @LowerLimit_aref = ($LowLimit) x $tcpar_AmountOfTraces;
    
    my $ResolutionData_href =
    {
       'RES' => \@RES_aref,
       'RES_max'  => \@HighLimit_aref,
       'RES_min'  => \@LowerLimit_aref,
    };
    
    my $report_path = $main::REPORT_PATH."/";  
    my  $graphTitle = "PhyisicalResolution_".$tcpar_MovingDirection;
    

    S_create_graph(
                    $ResolutionData_href,
                    $report_path.$graphTitle.'.txt',
                    $graphTitle,
                    'white',
                    );
 
    S_add_pic2html( "$graphTitle.png", "", "$graphTitle.txt.unv", 'TYPE="text/unv"');
 
 
     VDS_CloseDataContainer( $testData_href->{'container_id'} );

    return 1;
}

sub TC_finalization {

    return 1;
}


1;
