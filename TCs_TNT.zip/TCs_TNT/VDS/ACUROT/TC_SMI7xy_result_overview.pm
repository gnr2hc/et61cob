#### TEST CASE MODULE
package TC_SMI7xy_result_overview;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER  = q$Header: VDS/ACUROT/TC_SMI7xy_result_overview.pm 1.1 2017/09/07 20:04:36ICT Prosch Christian (CC-PS/EPS2) (PHC2SI) develop  $;

#### INCLUDE ENGINE MODULES ####

use INCLUDES_Project;    #necessary
use LIFT_general;
use FuncLib_VDS;

##################################

our $PURPOSE = "Result overview for SMI7xy verification";

# DOCUMENTATION

=head1 TESTCASE MODULE

TC_SMI7xy_result_overview

=head1 PURPOSE

    Result overview for SMI7xy verification

=head1 TESTCASE DESCRIPTION

Creates an Excel (and xml) summary file for all SMI7xy verification evaluation tests that have been run before in the same test list.

I<B<Preconditions>>

TC_SMI7xy_CCVT_eval and/or TC_SMI7xy_TGT_RIDT_eval test cases must be in the test list before this one. 

I<B<Initialisation>>

none

I<B<Stimulation and Measurement>>

none

I<B<Evaluation>>

Create the Excel (and xml) summary file from the aggregated results in the file _main__result_eval.csv

I<B<Finalisation>>

none

=head1 PARAMETER DESCRIPTION

no parameters used

=cut

#PARAMETERS
################ Parameters from .par file ###################

################ global parameter declaration ###################
#add any global variables here

###############################################################

sub TC_set_parameters {
    return 1;
}

sub TC_initialization {

    S_set_verdict(VERDICT_PASS);
    return 1;
}

sub TC_stimulation_and_measurement {
    return 1;
}

sub TC_evaluation {

    S_teststep( "Create Excel (and xml) summary file", 'AUTO_NBR' );
    VDS_WriteXml2Excel();
    return 1;
}

sub TC_finalization {

    return 1;
}

1;
