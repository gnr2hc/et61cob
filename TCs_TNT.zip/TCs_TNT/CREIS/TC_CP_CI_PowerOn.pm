# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_CP_CI_PowerOn;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
###-------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;    # this is always required
use LIFT_evaluation;
use LIFT_ProdDiag;
use LIFT_QuaTe;
use LIFT_crash_simulation;
use LIFT_can_access;
use FuncLib_CREIS_Framework;
use FuncLib_TNT_SYC_INTERFACE;
use LIFT_labcar;
##################################

our $PURPOSE = "verify that crash behaviour in different conditions is correct";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_CP_CI_PowerOn  

=head1 PURPOSE

=head1 TESTCASE DESCRIPTION

=head1 PARAMETER

=head2 PARAMETER NAMES

=head2 PARAMETER EXAMPLES


=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
my ( $tcpar_CrashName, $tcpar_State, $tcpar_CrashNumber, $tcpar_CreisInputFile, $tcpar_Ubat, $tcpar_PowerOnTime_ms, $ignoreMissingEnvironments );
my ( $crashData_href, $fltmemAfterInjection, $fltmemBeforeInjection );

#### TC PARAMETERS #####
sub TC_set_parameters {

	my ( $result, $ecuInitTime_s );

	$tcpar_CreisInputFile = S_read_mandatory_testcase_parameter('CreisInputFile');

	$tcpar_CrashNumber = S_read_optional_testcase_parameter('CrashNumber');

	undef $tcpar_CrashName;
	$tcpar_CrashName = S_read_mandatory_testcase_parameter('CrashName') unless ( defined $tcpar_CrashNumber );

	$tcpar_State = S_read_optional_testcase_parameter( 'State', 'byref', 1 );

	$tcpar_Ubat = S_read_optional_testcase_parameter( 'Ubat', 'byref', 'U_BATT_DEFAULT' );

	$tcpar_PowerOnTime_ms = S_read_optional_testcase_parameter( 'PowerOnTime_ms', 'byref', 'TIMER_ECU_READY' );

	if ( $tcpar_PowerOnTime_ms eq 'SYC' ) {
		( $result, $ecuInitTime_s ) = SYC_ECU_get_InitTime_s();
		$tcpar_PowerOnTime_ms = $ecuInitTime_s * 1000;
		return 0 unless $result;
	}

	if ( $tcpar_Ubat !~ /([0-9]+)/ ) {
		$tcpar_Ubat = S_get_contents_of_hash( [ 'VEHICLE', $tcpar_Ubat ] );
	}

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	LC_ECU_Off();
	S_set_timer_zero("ECU_OFF");

	# 1. read next crash from MDS-Result-File (read environment states + velocities)
	if ( defined $tcpar_CrashNumber ) {
		$crashData_href = CSI_GetCrashDataFromMDS(
			{
				"CRASHINDEX"     => $tcpar_CrashNumber,
				"STATEVARIATION" => $tcpar_State,
				"MDSTYPE"        => "MDSNG",
				"RESULTDB"       => $tcpar_CreisInputFile,
			}
		);
	}
	else {
		$crashData_href = CSI_GetCrashDataFromMDS(
			{
				'CRASHNAME'      => $tcpar_CrashName,
				"STATEVARIATION" => $tcpar_State,
				"MDSTYPE"        => "MDSNG",
				"RESULTDB"       => $tcpar_CreisInputFile,
			}
		);
	}

	# make sure that ECU is off
	S_wait_until_timer_ms( S_get_contents_of_hash( [ 'TIMER', 'TIMER_ECU_OFF' ] ), "ECU_OFF" );

	# prepare crash
	CSI_LoadAllData2Simulator($crashData_href);
	CA_simulation_start();

	# power ON the ECU
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	# 2. set environment states + velocities
	$ignoreMissingEnvironments = S_get_exec_option('CREIS_IgnoreMissingEnvironments') if S_check_exec_option('CREIS_IgnoreMissingEnvironments');

	CSI_PrepareEnvironment( $crashData_href, 'before_crash', 'relaxed' );
	CREIS_PrepareMeasurementsAndReporting($crashData_href);

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_Fault_Memory();

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	# start all measurement before ECU is switched on, so that network trace contains the full ECU cycle
	CREIS_StartAllMeasurements();

	S_teststep( "Switch ECU on with '$tcpar_Ubat V'.", 'AUTO_NBR' );
	LC_ECU_On($tcpar_Ubat);
	S_wait_ms('TIMER_ECU_READY');

	$fltmemBeforeInjection = CREIS_StoreFaultMemory('BeforeCrash');

	S_teststep( "Switch ECU off", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	S_teststep( "Switch ECU on", 'AUTO_NBR' );
	LC_ECU_On($tcpar_Ubat);
	S_set_timer_zero("ECU_On");

	# wait for ECU ready
	if ( $tcpar_PowerOnTime_ms eq 'TIMER_ECU_READY' ) {
		S_teststep( "Wait for end of initialisation phase", 'AUTO_NBR' );
		CP_CI_WaitEcuReady();
	}
	else {
		S_teststep( "Wait '$tcpar_PowerOnTime_ms' ms.", 'AUTO_NBR' );
		S_wait_until_timer_ms( $tcpar_PowerOnTime_ms, "ECU_On" );
	}

	S_teststep( "Start to inject the crash.", 'AUTO_NBR' );
	CSI_TriggerCrash();

	# wait for the crash duration
	CREIS_WaitUntillRecordingIsFinished();

	CREIS_ReadFireCounter();
	$fltmemAfterInjection = CREIS_StoreFaultMemory('AfterCrash');

	S_teststep( "Reset environments which need reset.", 'AUTO_NBR' );
	CSI_PrepareEnvironment( $crashData_href, 'after_crash', 'relaxed' );

	S_teststep( "Call project specific post crash actions...", 'AUTO_NBR' );
	CSI_PostCrashActions($crashData_href);

	S_teststep( "Switch ECU off", 'AUTO_NBR' );
	LC_ECU_Off();
	S_set_timer_zero("ECU_OFF");

	CREIS_StopAllMeasurements();

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	S_teststep( "Check deployment behaviour of all SimDevices (Squibs, CrashOutputs...)", 'AUTO_NBR', 'deployment' );
	CREIS_EvaluateMeasurements($crashData_href);
	S_teststep_expected( "All SimDevices are deployed as given in mdb result file.", 'deployment' );
	S_teststep_detected( "All SimDevices are deployed as given in mdb result file.",     'deployment' ) if $VERDICT eq "VERDICT_PASS";
	S_teststep_detected( "NOT all SimDevices are deployed as given in mdb result file.", 'deployment' ) if $VERDICT eq "VERDICT_FAIL";

	CREIS_EvaluateFaultMemory($crashData_href);

	return 1;
}

#### TC FINALIZATION #####
sub TC_finalization {

	S_wait_until_timer_ms( S_get_contents_of_hash( [ 'TIMER', 'TIMER_ECU_OFF' ] ), "ECU_OFF" );

	LC_ECU_On();

	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_EDR( { timeout_ms => 15000 } );

	S_wait_ms(2000);

	PRD_Clear_Fault_Memory();

	CREIS_FinishReporting($crashData_href);

	return 1;
}

sub CP_CI_WaitEcuReady {

	return if ($main::opt_offline);

	my ( $dec_value, $start, $timeout );
	$start     = S_get_TC_time_NOHTML();
	$dec_value = 0;
	$timeout   = 2 * ( S_get_contents_of_hash_NOHTML( [ 'TIMER', 'TIMER_ECU_READY' ] ) / 1000 );

	# try to get timeout time from Project Defaults
	my $timerPdReady_ms = S_get_contents_of_hash_NOERROR( [ 'TIMER', 'TIMER_PD_READY' ] );

	unless ( defined $timerPdReady_ms ) {
		$timerPdReady_ms = 1500;
	}

	S_wait_ms($timerPdReady_ms);

	# add comparison with ECU_OFF timer here...
	while ( $dec_value < 1 and S_get_TC_time_NOHTML() - $start < $timeout ) {
		$dec_value = PRD_Read_Memory( 'rb_itm_EndOfItmTimestamp_u32', { memoryContentsAsInteger => 1 } );
		next unless $dec_value;
		S_w2log( 5, "CP_CI_WaitItmFinished: rb_itm_EndOfItmTimestamp_u32 = '$dec_value'." );
	}

	my $total_time = S_get_TC_time_NOHTML() - $start;
	$total_time = sprintf( "%.2f", $total_time );
	S_w2log( 3, "CP_CI_WaitItmFinished: returned after $total_time s of max 2x TIMER_ECU_READY $timeout s." );

	return 1;
}

1;

__END__

