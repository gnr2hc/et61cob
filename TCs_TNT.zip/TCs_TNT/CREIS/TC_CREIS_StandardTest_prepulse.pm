# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#    $Source: CREIS/TC_CREIS_StandardTest_prepulse.pm $
#    $Revision: 1.0 $
#    $Author: Pavithra Krishnasamy (RBEI/ESA-PW4) (PKV1COB) $
#    $State: develop $
#    $Date: 2020/04/29 14:54:14ICT $
#******************************************************************************************************

#### TEST CASE MODULE
package TC_CREIS_StandardTest_Prepulse;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
###-------------------------------
our $VERSION = q$Revision: 1.0 $;
our $HEADER  = q$Header: CREIS/TC_CREIS_StandardTest_prepulse.pm 1.0 2020/04/29 14:54:14ICT Pavithra Krishnasamy (RBEI/ESA-PW4) (PKV1COB) develop  $;
##################################

#### INCLUDE ENGINE MODULES ####
use LIFT_general;    # this is always required
use LIFT_evaluation;
use LIFT_ProdDiag;
use LIFT_PD;
use LIFT_QuaTe;
use LIFT_crash_simulation;
use LIFT_can_access;
use FuncLib_CREIS_Framework;
use LIFT_labcar;
use LIFT_flexray_access;
use LIFT_CANoe_device;
use FuncLib_TNT_GEN;
use LIFT_LIN_Access;
use LIFT_FaultMemory;
use LIFT_NET_access;
use INCLUDES_Project;  
use GENERIC_DCOM;
use Data::Dumper;
use LIFT_CD;
use FuncLib_SYC_INTERFACE;
use LIFT_QuaTe;
use warnings;
use Params::Util ();
use Moose::Role;
use LIFT_LCT;
use File::Basename;
use tsg4;
use tsg4_lct64;
use GD::Graph::lines;
use Exporter;
use File::Copy;
use LIFT_numerics;
use LIFT_simulation;
##################################

our $PURPOSE = "Standard Crash Injection test ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

#-> update documentation that somebody else can use the test without asking you
#-> delete parameter section if no paramteres are used
#-> note that POD documentation needs entirely empty lines before and after keywords (e.g. =head1, =cut ...)

=head1 TESTCASE MODULE

TC_CREIS_StandardTest  $Revision: 1.0 $

=head1 PURPOSE

=head1 TESTCASE DESCRIPTION

=head1 PARAMETER

=head2 PARAMETER NAMES

=head2 PARAMETER EXAMPLES


=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#-> define variables here which sall be used across subroutines
#-> test case parameters shall start with tcpar_
my ( $tcpar_CrashName, $tcpar_State, $tcpar_CrashNumber, $tcpar_CreisInputFile, $tcpar_Ubat, $tcpar_ignoreAllErrors, $tcpar_FLT_mand, $tcpar_FLT_opt,$tcpar_Signal_update );
my ( $crashData_href, $fltmemAfterInjection, $errorHandlingPrepEnv, $failedHandlingEnvCheck, $errorHandlingEnvCheck);
my ($Env_Global_System_time, $Delaytime, $Delay) = 0;
my $GTS_Tracedata_href = {};
my $SVTriggerHard_Tracedata_href = {};
my ($GTS_values_trace, $GTS_time_stamps_trace) = 0; 
my (@GTS_Values_Array, @Time_Stamp_Values_Array, @Valid_GTS_values, @SVTrigger_SIIAP, @SVTrigger_SIIAP_Time_Stamp_Value);
my $GTS_Arraysize;
my ($Index, $Index1, $Index2, $Index3);
my ($GTS_index_When_FR_Messages_Updated, $Nearest_Global_System_Algo_time, $Valid_GTS_index, $Valid_GTS_Time_stamp, $Valid_GTS_time) = 0;
my ($SVTriggerHardValue, $SVTriggerHard_timeStamp, $SVTriggerHardTimestamp,$SVTriggerHard_SIIAP_Firing); 
my ($ActualFiretime, $ExpectedFiretime) = 0;
my $GlobalTimeofImpact = 1800;
my $Squib_Name_passenger = "SIIAP";
my $Squib_Name_Driver = "SIIAD";
my (@Simdevice, @Actual_Firing_time,@Expected_Firing_time);
my $Env_Crash_Flag_Value = 0;
my $trace_file_path = $main::REPORT_PATH . "/" . '0001_MRA2_PretriggerSide_Signal3_1_1\0001_MRA2_PretriggerSide_Signal3;' . "1_1_NET_trace.asc";
# my $tcpar_simDevice = ; 
my $SVTriggerSIIAD_Tracedata_href = {};
my ($SVTriggerSIIADValue, $SVTriggerSIIAD_timeStamp);
my (@SVTrigger_SIIAD, @SVTrigger_SIIAD_Time_Stamp_Value);
my ($SVTriggerSIIADTimestamp, $SVTrigger_SIIAD_Firing); 
my ($ActualFiretime_SIIAD, $ExpectedFiretime_SIIAD); 
my (@Simdevice_SIIAD,@Actual_Firing_time_SIIAD, @Expected_Firing_time_SIIAD); 
my $GlobalTimeofImpact_1 = 800;
my ($Env_trigger_Crash, $Env_trigger_Crash1);


sub TC_set_parameters {

    $tcpar_CreisInputFile = S_read_mandatory_testcase_parameter('CreisInputFile');

    $tcpar_CrashNumber = S_read_optional_testcase_parameter('CrashNumber');

    undef $tcpar_CrashName;
    $tcpar_CrashName = S_read_mandatory_testcase_parameter('CrashName') unless ( defined $tcpar_CrashNumber );

    $tcpar_State = S_read_optional_testcase_parameter( 'State', 'byref', 1 );

    $tcpar_Ubat = S_read_optional_testcase_parameter( 'Ubat', 'byref', 'U_BATT_DEFAULT' );
	
	$tcpar_Signal_update = S_read_mandatory_testcase_parameter('Signal_update');
	
	# $tcpar_simDevice = S_read_mandatory_testcase_parameter('sim_Device');
	
	my $ignoreFailedEnvironmentChecks  = S_check_exec_option('CREIS_IgnoreFailedEnvironmentChecks')  ? S_get_exec_option('CREIS_IgnoreFailedEnvironmentChecks')  : 0;
    my $ignoreMissingEnvironmentChecks = S_check_exec_option('CREIS_IgnoreMissingEnvironmentChecks') ? S_get_exec_option('CREIS_IgnoreMissingEnvironmentChecks') : 1;
    $failedHandlingEnvCheck = $ignoreFailedEnvironmentChecks  ? 'relaxed' : 'strict';
    $errorHandlingEnvCheck  = $ignoreMissingEnvironmentChecks ? 'relaxed' : 'strict';

    my $ignoreMissingEnvironments = S_get_exec_option('CREIS_IgnoreMissingEnvironments') if S_check_exec_option('CREIS_IgnoreMissingEnvironments');
    $errorHandlingPrepEnv = $ignoreMissingEnvironments ? 'relaxed' : 'strict';

    return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

    # 1. read next crash from MDS-Result-File (read environment states + velocities)
    $crashData_href = CSI_GetCrashDataFromMDS(
        {
            "CRASHINDEX"     => $tcpar_CrashNumber,
            'CRASHNAME'      => $tcpar_CrashName,
            "STATEVARIATION" => $tcpar_State,
            "MDSTYPE"        => "MDSNG",
            "RESULTDB"       => $tcpar_CreisInputFile,
        }
    );

	S_dump2pmFile (    "StoragePath" => CREIS_GetResultsFolder( ),
                         "VariableToDump" => $crashData_href,
                         "VariableName" => "CrashData",
                        "PackageName" => S_get_TC_number() . "_crashDataDump.pm"
				);

    # prepare crash
    CSI_LoadAllData2Simulator($crashData_href);
    CA_simulation_start();

    # power ON the ECU
    LC_ECU_On();
    CREIS_WaitEcuReady();
	
    # S_user_action("Power On");
	
	
	FR_write_flxr_signal( $tcpar_Signal_update, 1);
	S_wait_ms(2000);

    PRD_Clear_EDR({timeout_ms => 'TIMER_CLEAR_CRASH_RECORDER'});

    S_wait_ms(2000);

    # 2. set environment states + velocities
    CSI_PrepareEnvironment( $crashData_href, 'before_crash', $errorHandlingPrepEnv );

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

    LC_ECU_On();
    CREIS_WaitEcuReady();
	
	FR_write_flxr_signal( $tcpar_Signal_update, 1);
	S_wait_ms(2000);

    CSI_VerifyEnvironment( $crashData_href, 'before_crash', $failedHandlingEnvCheck, $errorHandlingEnvCheck );
    CREIS_PrepareMeasurementsAndReporting($crashData_href);

    PRD_Clear_Fault_Memory();

    S_wait_ms(2000);

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

    return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

    # start all measurement before ECU is switched on, so that network trace contains the full ECU cycle
    CREIS_StartAllMeasurements();

	#start QuaTe monitor (SPI/PSI)
	# QuaTe_SetSPIMonitorMode('SPImonitor', ENABLE, 0, 0, ['SMI860','SMA760','SMA720','SMG810']);

    # power ON the ECU
    S_teststep( "Switch ECU on", 'AUTO_NBR' );
    LC_ECU_On($tcpar_Ubat);
    CREIS_LogTestCaseEvent("ECU_On");

    # wait for ECU ready
    S_teststep( "Wait until ECU is ready.", 'AUTO_NBR' );
    CREIS_WaitEcuReady();
	
	FR_write_flxr_signal( $tcpar_Signal_update, 1);
	S_wait_ms(2000);
		
    CSI_PrepareEnvironment( $crashData_href, 'before_crash_same_cycle', $errorHandlingPrepEnv );
    CREIS_StoreFaultMemory('BeforeCrash');
    CREIS_DumpNVMData('BeforeCrash');
    CREIS_ReadPdLabels('BeforeCrash');
    CREIS_ReadSquibResistance( );
    CSI_VerifyEnvironment( $crashData_href, 'before_crash_same_cycle', $failedHandlingEnvCheck, $errorHandlingEnvCheck );
    CREIS_RuntimeBeforeCrash();
	# CREIS_StartFastDiagTrace();

	
	# S_user_action("Before crash");
	
	CA_set_EnvVar_value ( 'ENV_Crash_Flag', 1);
	
    CREIS_StartFastDiagTrace();
	
	while( $Env_Crash_Flag_Value == 0)
	
	{
		
	 $Env_Crash_Flag_Value = CA_get_EnvVar_value ( 'ENV_Crash_Flag' );
	
	}
	
	S_w2rep( " Value of ENV_Crash_Flag is = $Env_Crash_Flag_Value'\n" ); 
	
    $Env_Global_System_time = CA_get_EnvVar_value ( 'ENV_Global_System_Time' );
	
	
	while( $Env_Global_System_time == 0)
	{	
	 
	 $Env_Global_System_time = CA_get_EnvVar_value ( 'ENV_Global_System_Time' );
	 
	} 
	
	S_w2rep( " Value of ENV_Global_System_Time is = $Env_Global_System_time'\n" ); 
	

    # Inject the crash
    S_teststep( "Start to inject the crash.", 'AUTO_NBR' );
    CREIS_LogTestCaseEvent("Inject_Crash");
	
	$Env_trigger_Crash = CA_get_EnvVar_value ( 'ENV_Triggercrash' );
	
	while( $Env_trigger_Crash == 0)
	{	
	 
	 $Env_trigger_Crash = CA_get_EnvVar_value ( 'ENV_Triggercrash' );
	 
	} 
	
    CSI_TriggerCrash();
	
    # S_wait_ms(5000);
	
	
    # $Env_trigger_Crash1 = CA_get_EnvVar_value ( 'ENV_Triggercrash_1' );
	
	# while( $Env_trigger_Crash1 == 0)
	# {	
	 
	 # $Env_trigger_Crash = CA_get_EnvVar_value ( 'ENV_Triggercrash_1' );
	 
	# } 
	
	# CSI_TriggerCrash();
	
	
	# S_wait_ms(500);
	
	# wait for the crash duration
    CREIS_WaitUntillRecordingIsFinished();

    # S_teststep( "Start to inject the crash.", 'AUTO_NBR' );
    # CREIS_LogTestCaseEvent("Inject_Crash");
	
	# CSI_TriggerCrash();
	
	# S_user_action("After crash");
	# CA_trace_stop();
    CREIS_StopFastDiagTrace();
    CREIS_RuntimeAfterCrash();
    CREIS_ReadFireCounter();
    CREIS_ReadPdLabels('AfterCrash');

	#stop QuaTe monitor (SPI/PSI), save dump
	# QuaTe_SetSPIMonitorMode('SPImonitor', DISABLE, 0, 1, ['SMI860','SMA760','SMA720','SMG810']); 
	# my $filename = CREIS_GetResultsFolder( ).S_get_TC_number() . "_SPI_Trace.csv";
	# QuaTe_SaveSPIMonitorData_NOERROR('SPImonitor', $filename);

    $fltmemAfterInjection = CREIS_StoreFaultMemory('AfterCrash');
    CREIS_ReadPD_EDR();
    S_wait_ms(2000);
    CREIS_DumpNVMData('AfterCrash');
	
    S_teststep( "Reset environments which need reset.", 'AUTO_NBR' );
    CSI_PrepareEnvironment( $crashData_href, 'after_crash', 'relaxed' );

    S_teststep( "Call project specific post crash actions...", 'AUTO_NBR' );
    CSI_PostCrashActions($crashData_href);

    # S_teststep( "Switch ECU off", 'AUTO_NBR' );
    # LC_ECU_Off();
    # S_set_timer_zero("ECU_OFF");
	
	CA_set_EnvVar_value ( 'ENV_Crash_Flag', 0);

    CREIS_StopAllMeasurements();

    return 1;
}

#### EVALUATE TC #####
sub TC_evaluation 
{

	# if(($Env_Crash_Flag_Value == 1) or ($Env_Crash_Flag_Value == 3) or ($Env_Crash_Flag_Value == 4) or ($Env_Crash_Flag_Value == 5))	
    # {
	   	# $GTS_Tracedata_href = CANoe_trace_get_sysvar_dataref ( $trace_file_path, 'GTS::Global_System_Time', $GTS_Tracedata_href );
	 
		# ($GTS_values_trace, $GTS_time_stamps_trace) = EVAL_get_values_and_times_over_time($GTS_Tracedata_href, 'GTS::Global_System_Time' );
	
		# # Get the Global system time values and the time stamps from the Canoe trace 	
		# foreach $Index ( 0 .. @$GTS_values_trace - 1 ) 
		# {
			# push(@GTS_Values_Array, $$GTS_values_trace[$Index]);
	   
			# push(@Time_Stamp_Values_Array, $$GTS_time_stamps_trace[$Index]);
	    
			# S_w2rep( " The Global System Time and the time stamp values get from the trace = $Time_Stamp_Values_Array[$Index] ; $GTS_Values_Array[$Index]" ); 
	    # }
		
		# #To find the GTS value and the array index of the GTS value when the Flexray Messages are updated i.e GTS time < 20000 & GTS time > 10000
		# foreach $Index1 ( 0 .. @GTS_Values_Array - 1 ) 
		# {
			# if(S_hex2dec($GTS_Values_Array[$Index1]) == $Env_Global_System_time)
			# {
				# $GTS_index_When_FR_Messages_Updated = $Index1 ;
				
				# $Valid_GTS_time  = $GTS_Values_Array[$Index1];
				
				# $Valid_GTS_Time_stamp = $Time_Stamp_Values_Array[$Index1];
			
				# S_w2rep( " The GTS index when the FR messages value updated = $GTS_index_When_FR_Messages_Updated" ); 
			
				# S_w2rep( " The GTS value when the FR messages value updated = $Valid_GTS_time" ); 
				
				# S_w2rep( " The GTS time stamp value when the FR messages value updated = $Valid_GTS_Time_stamp" ); 
				
			# }
		# }
		
			# #Find the time stamp for SVTriggeredHard which is the indication of SIIAP firing 
			# $SVTriggerHard_Tracedata_href = CANoe_trace_get_sysvar_dataref ( $trace_file_path, 'Stimulus::SVTriggerHard', $SVTriggerHard_Tracedata_href );  
	   
			# ($SVTriggerHardValue, $SVTriggerHard_timeStamp ) = EVAL_get_values_and_times_over_time( $SVTriggerHard_Tracedata_href, 'Stimulus::SVTriggerHard');  
	
		  
			# foreach $Index ( 0 .. @$SVTriggerHardValue - 1 ) 
			# {
				# push(@SVTrigger_SIIAP, $$SVTriggerHardValue[$Index]);
	   
				# push(@SVTrigger_SIIAP_Time_Stamp_Value, $$SVTriggerHard_timeStamp[$Index]);
	   
				# $SVTriggerHardTimestamp = $SVTrigger_SIIAP_Time_Stamp_Value[$Index];
	   
				# my $SVTriggerHard_SIIAP_Firing = $SVTrigger_SIIAP[$Index];
	    
				# S_w2rep( " SVTrigger Hard for Right Passenger SIIAP value and timestamp get from the trace = @SVTrigger_SIIAP ; @SVTrigger_SIIAP_Time_Stamp_Value  " );
	   
				# S_w2rep( " SVTrigger Hard for Right Passenger SIIAP timestamp value = $SVTriggerHardTimestamp" );
	   
				# S_w2rep( " SVTrigger Hard for Right Passenger SIIAP value from Trace which indicated the firing of SIIAP = $SVTriggerHard_SIIAP_Firing" );
	   
		
			# }
		
			# #Find the actual firing timing from the nearest GTS time stamp of GTS value after FR message update and the SVTriggerHard time stamp value which is the indication of SIIAP firing  
			# $ActualFiretime	=  (S_hex2dec($Valid_GTS_time) * 0.1) + (($SVTriggerHardTimestamp - $Valid_GTS_Time_stamp) * 1000) ; 
		
			# # Calculate the expected fire time using the formula for same cycle	
			# $ExpectedFiretime = $GlobalTimeofImpact;
		
			# S_w2rep( "Actual Fire Time for SIIAP in ms = $ActualFiretime" );
  
			# S_w2rep( "Expected Fire Time for SIIAP in ms = $ExpectedFiretime" );   
	
		   # $SVTriggerSIIAD_Tracedata_href = CANoe_trace_get_sysvar_dataref ( $trace_file_path, 'Stimulus::SVTriggerSIIAD', $SVTriggerSIIAD_Tracedata_href );  
	   
			# ($SVTriggerSIIADValue, $SVTriggerSIIAD_timeStamp ) = EVAL_get_values_and_times_over_time( $SVTriggerSIIAD_Tracedata_href, 'Stimulus::SVTriggerSIIAD');  
		
			# foreach $Index ( 0 .. @$SVTriggerSIIADValue - 1 ) 
			# {
				# push(@SVTrigger_SIIAD, $$SVTriggerSIIADValue[$Index]);
	   
				# push(@SVTrigger_SIIAD_Time_Stamp_Value, $$SVTriggerSIIAD_timeStamp[$Index]);
	   
				# $SVTriggerSIIADTimestamp = $SVTrigger_SIIAD_Time_Stamp_Value[$Index];
	   
				# $SVTrigger_SIIAD_Firing = $SVTrigger_SIIAD[$Index];
	    
				# S_w2rep( " Left Driver SIIAD value and timestamp get from the trace = @SVTrigger_SIIAD ; @SVTrigger_SIIAD_Time_Stamp_Value  " );
	   
				# S_w2rep( " Left Driver SIIAD timestamp value = $SVTriggerSIIADTimestamp" );
	   
				# S_w2rep( " Left Driver SIIAD value from Trace which indicated the firing of SIIAD = $SVTrigger_SIIAD_Firing" );
			# }	
		
			# #Find the actual firing timing from the nearest GTS time stamp of GTS value after FR message update and the SVTriggerHard time stamp value which is the indication of SIIAD firing  
			# $ActualFiretime_SIIAD	=  (S_hex2dec($Valid_GTS_time) * 0.1) + (($SVTriggerSIIADTimestamp - $Valid_GTS_Time_stamp) * 1000) ; 
			
			# # Calculate the expected fire time using the formula for same cycle	
			# $ExpectedFiretime_SIIAD = $GlobalTimeofImpact;
			
			# S_w2rep( "Actual Fire Time for SIIAD in ms = $ActualFiretime_SIIAD" );
  
			# S_w2rep( "Expected Fire Time for SIIAD in ms = $ExpectedFiretime_SIIAD" );   
	     
		    # my $verdict = EVAL_evaluate_value("Fire Timings" , $ExpectedFiretime, '==', $ActualFiretime, 1.0 , 'absolute');
		 
			# my $verdict = EVAL_evaluate_value("Fire Timings" , $ExpectedFiretime_SIIAD, '==', $ActualFiretime_SIIAD, 1.0 , 'absolute');
			
			# #Create result table 
			# push(@Simdevice, $Squib_Name_passenger);
			# push(@Actual_Firing_time, $ActualFiretime);
			# push(@Expected_Firing_time, $ExpectedFiretime); 
			
			# my $tableObject = S_TableCreate( [ 'SimDevice', 'Actual_Firing_time', 'Expected_Firing_time' ], [ \@Simdevice, \@Actual_Firing_time, \@Expected_Firing_time ], 'column-wise' );
			# S_TablePrint( CONSOLE | TEXT | HTML | 2, $tableObject, 'Result Table' );
			
			# push(@Simdevice_SIIAD, $Squib_Name_Driver);
			# push(@Actual_Firing_time_SIIAD, $ActualFiretime_SIIAD);
			# push(@Expected_Firing_time_SIIAD, $ExpectedFiretime_SIIAD); 
			
			# my $tableObject_1 = S_TableCreate( [ 'SimDevice', 'Actual_Firing_time', 'Expected_Firing_time' ], [ \@Simdevice_SIIAD, \@Actual_Firing_time_SIIAD, \@Expected_Firing_time_SIIAD ], 'column-wise' );
			# S_TablePrint( CONSOLE | TEXT | HTML | 2, $tableObject_1, 'Result Table' );
       	
	# }
	
	# elsif($Env_Crash_Flag_Value == 2)
	# {
			# $GTS_Tracedata_href = CANoe_trace_get_sysvar_dataref ( $trace_file_path, 'GTS::Global_System_Time', $GTS_Tracedata_href );
	 
			# ($GTS_values_trace, $GTS_time_stamps_trace) = EVAL_get_values_and_times_over_time($GTS_Tracedata_href, 'GTS::Global_System_Time' );
	
	
			# # Get the Global system time values and the time stamps from the Canoe trace 	
			# foreach $Index ( 0 .. @$GTS_values_trace - 1 ) 
			# {
				# push(@GTS_Values_Array, $$GTS_values_trace[$Index]);
	   
				# push(@Time_Stamp_Values_Array, $$GTS_time_stamps_trace[$Index]);
	    
				# S_w2rep( " The Global System Time and the time stamp values get from the trace = $Time_Stamp_Values_Array[$Index] ; $GTS_Values_Array[$Index]" ); 
			# }
	
			# # Find the size of an GTS array
			# $GTS_Arraysize = @GTS_Values_Array;
			# S_w2rep( " Size of an GTS Array = $GTS_Arraysize" ); 
	
	
			# #To find the GTS value and the array index of the GTS value when the Flexray Messages are updated i.e GTS time > 40000
			# foreach $Index1 ( 0 .. @GTS_Values_Array - 1 ) 
			# {
				# if(S_hex2dec($GTS_Values_Array[$Index1]) == $Env_Global_System_time)
				# {
					# $GTS_index_When_FR_Messages_Updated = $Index1 ;
			
					# S_w2rep( " The Global system time index when the FR messages value updated = $GTS_index_When_FR_Messages_Updated" ); 
			
					# S_w2rep( " The Global system time value when the FR messages value updated = $GTS_Values_Array[$Index1]" ); 
	
				# }
			# }
	
			# # Get the GTS values using the found GTS index(approximately 6 values after the FR message update)
			# foreach $Index ($GTS_index_When_FR_Messages_Updated .. ((int(@GTS_Values_Array/10)) + $GTS_index_When_FR_Messages_Updated -1)) 
			# {
	
				# push(@Valid_GTS_values, $GTS_Values_Array[$Index]);
	         
			# }
	
			# S_w2rep( " The Global System Algo Time values from the trace after the FR message update is @Valid_GTS_values \n" ); 
		
	
			# # To find the nearest GTS value greater than 60000 after the FR message update i.e before injecting crash	
			# foreach $Index2 (0 .. @Valid_GTS_values -1 ) 
			# {
	
				# if(S_hex2dec($Valid_GTS_values[$Index2]) > 60000)
				# {
					# $Nearest_Global_System_Algo_time = $Valid_GTS_values[$Index2];
		   
					# S_w2rep( " The Nearest Global system time value greater than 60000 = $Nearest_Global_System_Algo_time "); 
				# }
	   
			# }
	
		# # Get the GTS time value and the time stamp value used for calculation 
		# foreach $Index3 ( 0 .. @GTS_Values_Array - 1 ) 
		# {
			# if(S_hex2dec($GTS_Values_Array[$Index3]) == S_hex2dec($Nearest_Global_System_Algo_time))
			# {
				# $Valid_GTS_index = $Index3 ;
			
				# $Valid_GTS_Time_stamp = $Time_Stamp_Values_Array[$Index3];
			
				# $Valid_GTS_time = $GTS_Values_Array[$Index3];
			
				# S_w2rep( " The valid Global system time index = $Valid_GTS_index" ); 
			
				# S_w2rep( " The valid Global system time value = $Valid_GTS_time" ); 
			
				# S_w2rep( " The valid GTS time stamp value in secs = $Valid_GTS_Time_stamp" );
			# }
		  
		# }
	
			# #Find the time stamp for SVTriggeredHard which is the indication of SIIAP firing 
			# $SVTriggerHard_Tracedata_href = CANoe_trace_get_sysvar_dataref ( $trace_file_path, 'Stimulus::SVTriggerHard', $SVTriggerHard_Tracedata_href );  
	   
			# ($SVTriggerHardValue, $SVTriggerHard_timeStamp ) = EVAL_get_values_and_times_over_time( $SVTriggerHard_Tracedata_href, 'Stimulus::SVTriggerHard');  
		
  
			# foreach $Index ( 0 .. @$SVTriggerHardValue - 1 ) 
			# {
				# push(@SVTrigger_SIIAP, $$SVTriggerHardValue[$Index]);
	   
				# push(@SVTrigger_SIIAP_Time_Stamp_Value, $$SVTriggerHard_timeStamp[$Index]);
	   
				# $SVTriggerHardTimestamp = $SVTrigger_SIIAP_Time_Stamp_Value[$Index];
	   
				# my $SVTriggerHard_SIIAP_Firing = $SVTrigger_SIIAP[$Index];
	    
				# S_w2rep( " SVTrigger Hard for Right Passenger SIIAP value and timestamp get from the trace = @SVTrigger_SIIAP ; @SVTrigger_SIIAP_Time_Stamp_Value  " );
	   
				# S_w2rep( " SVTrigger Hard for Right Passenger SIIAP timestamp value = $SVTriggerHardTimestamp" );
	   
				# S_w2rep( " SVTrigger Hard for Right Passenger SIIAP value from Trace which indicated the firing of SIIAP = $SVTriggerHard_SIIAP_Firing" );
	   
			# }
			
			# #Find the actual firing timing from the nearest GTS time stamp of GTS value after FR message update and the SVTriggerHard time stamp value which is the indication of SIIAP firing  
			# $ActualFiretime	= ($SVTriggerHardTimestamp - $Valid_GTS_Time_stamp) * 1000 ; 
	
			# S_w2rep( "Actual Fire Time for SIIAP in ms = $ActualFiretime" );
			
			# # Calculate the expected fire time using the formula for the next cycle	
			# $ExpectedFiretime =  ((65535 - (S_hex2dec($Valid_GTS_time))) * 0.1 ) + $GlobalTimeofImpact;
		
			# S_w2rep( "Actual Fire Time for SIIAP in ms = $ActualFiretime" );
  
			# S_w2rep( "Expected Fire Time for SIIAP in ms = $ExpectedFiretime" ); 
			
			# $SVTriggerSIIAD_Tracedata_href = CANoe_trace_get_sysvar_dataref ( $trace_file_path, 'Stimulus::SVTriggerSIIAD', $SVTriggerSIIAD_Tracedata_href );  
	   
			# ($SVTriggerSIIADValue, $SVTriggerSIIAD_timeStamp ) = EVAL_get_values_and_times_over_time( $SVTriggerSIIAD_Tracedata_href, 'Stimulus::SVTriggerSIIAD');  
		
			# foreach $Index ( 0 .. @$SVTriggerSIIADValue - 1 ) 
			# {
				# push(@SVTrigger_SIIAD, $$SVTriggerSIIADValue[$Index]);
	   
				# push(@SVTrigger_SIIAD_Time_Stamp_Value, $$SVTriggerSIIAD_timeStamp[$Index]);
	   
				# $SVTriggerSIIADTimestamp = $SVTrigger_SIIAD_Time_Stamp_Value[$Index];
	   
				# $SVTrigger_SIIAD_Firing = $SVTrigger_SIIAD[$Index];
	    
				# S_w2rep( " Left Driver SIIAD value and timestamp get from the trace = @SVTrigger_SIIAD ; @SVTrigger_SIIAD_Time_Stamp_Value  " );
	   
				# S_w2rep( " Left Driver SIIAD timestamp value = $SVTriggerSIIADTimestamp" );
	   
				# S_w2rep( " Left Driver SIIAD value from Trace which indicated the firing of SIIAD = $SVTrigger_SIIAD_Firing" );
	   
			# }
	

			# #Find the actual firing timing from the nearest GTS time stamp of GTS value after FR message update and the SVTriggerSIIAD time stamp value which is the indication of SIIAD firing  
			# $ActualFiretime_SIIAD = ($SVTriggerSIIADTimestamp - $Valid_GTS_Time_stamp) * 1000 ; 
			
			# # Calculate the expected fire time using the formula for the next cycle	
			# $ExpectedFiretime_SIIAD =  ((65535 - (S_hex2dec($Valid_GTS_time))) * 0.1 ) + $GlobalTimeofImpact;
	
			# S_w2rep( "Actual Fire Time for SIIAD in ms = $ActualFiretime_SIIAD" );
			
			# S_w2rep( "Expected Fire Time for SIIAD in ms = $ExpectedFiretime_SIIAD" ); 
			
			# my $verdict = EVAL_evaluate_value("Fire Timings" , $ExpectedFiretime_SIIAD, '==', $ActualFiretime_SIIAD, 1.0 , 'absolute');
			
			# my $verdict = EVAL_evaluate_value("Fire Timings" , $ExpectedFiretime, '==', $ActualFiretime, 1.0 , 'absolute');
			
			# #Create result table 
			# push(@Simdevice, $Squib_Name_passenger);
			# push(@Actual_Firing_time, $ActualFiretime);
			# push(@Expected_Firing_time, $ExpectedFiretime); 
			
			# my $tableObject = S_TableCreate( [ 'SimDevice', 'Actual_Firing_time', 'Expected_Firing_time' ], [ \@Simdevice, \@Actual_Firing_time, \@Expected_Firing_time ], 'column-wise' );
			# S_TablePrint( CONSOLE | TEXT | HTML | 2, $tableObject, 'Result Table' );
			
			# push(@Simdevice_SIIAD, $Squib_Name_Driver);
			# push(@Actual_Firing_time_SIIAD, $ActualFiretime_SIIAD);
			# push(@Expected_Firing_time_SIIAD, $ExpectedFiretime_SIIAD); 
			
			# my $tableObject_1 = S_TableCreate( [ 'SimDevice', 'Actual_Firing_time', 'Expected_Firing_time' ], [ \@Simdevice_SIIAD, \@Actual_Firing_time_SIIAD, \@Expected_Firing_time_SIIAD ], 'column-wise' );
			# S_TablePrint( CONSOLE | TEXT | HTML | 2, $tableObject_1, 'Result Table' );
	
	    
  	
	# }
	
	# elsif(($Env_Crash_Flag_Value == 6) or ($Env_Crash_Flag_Value == 7))
	# { 
			# $GTS_Tracedata_href = CANoe_trace_get_sysvar_dataref ( $trace_file_path, 'GTS::Global_System_Time', $GTS_Tracedata_href );
	 
			# ($GTS_values_trace, $GTS_time_stamps_trace) = EVAL_get_values_and_times_over_time($GTS_Tracedata_href, 'GTS::Global_System_Time' );
	
	
			# # Get the Global system time values and the time stamps from the Canoe trace 	
			# foreach $Index ( 0 .. @$GTS_values_trace - 1 ) 
			# {
				# push(@GTS_Values_Array, $$GTS_values_trace[$Index]);
	   
				# push(@Time_Stamp_Values_Array, $$GTS_time_stamps_trace[$Index]);
	    
				# S_w2rep( " The Global System Time and the time stamp values get from the trace = $Time_Stamp_Values_Array[$Index] ; $GTS_Values_Array[$Index]" ); 
			# }
	
			# # Find the size of an GTS array
			# $GTS_Arraysize = @GTS_Values_Array;
			# S_w2rep( " Size of an GTS Array = $GTS_Arraysize" ); 
	
	
			# #To find the GTS value and the array index of the GTS value when the Flexray Messages are updated i.e GTS time > 40000
			# foreach $Index1 ( 0 .. @GTS_Values_Array - 1 ) 
			# {
				# if(S_hex2dec($GTS_Values_Array[$Index1]) == $Env_Global_System_time)
				# {
					# $GTS_index_When_FR_Messages_Updated = $Index1 ;
			
					# S_w2rep( " The Global system time index when the FR messages value updated = $GTS_index_When_FR_Messages_Updated" ); 
			
					# S_w2rep( " The Global system time value when the FR messages value updated = $GTS_Values_Array[$Index1]" ); 
	
				# }
			# }
	
			# # Get the GTS values using the found GTS index(approximately 6 values after the FR message update)
			# foreach $Index ($GTS_index_When_FR_Messages_Updated .. ((int(@GTS_Values_Array/7)) + $GTS_index_When_FR_Messages_Updated -1)) 
			# {
	
				# push(@Valid_GTS_values, $GTS_Values_Array[$Index]);
	         
			# }
	
			# S_w2rep( " The Global System Algo Time values from the trace after the FR message update is @Valid_GTS_values \n" ); 
		
	
			# # To find the nearest GTS value greater than 60000 after the FR message update i.e before injecting crash	
			# foreach $Index2 (0 .. @Valid_GTS_values -1 ) 
			# {
	
				# if(S_hex2dec($Valid_GTS_values[$Index2]) > 60000)
				# {
					# $Nearest_Global_System_Algo_time = $Valid_GTS_values[$Index2];
		   
					# S_w2rep( " The Nearest Global system time value greater than 60000 = $Nearest_Global_System_Algo_time "); 
				# }
	   
			# }
	
		# # Get the GTS time value and the time stamp value used for calculation 
		# foreach $Index3 ( 0 .. @GTS_Values_Array - 1 ) 
		# {
			# if(S_hex2dec($GTS_Values_Array[$Index3]) == S_hex2dec($Nearest_Global_System_Algo_time))
			# {
				# $Valid_GTS_index = $Index3 ;
			
				# $Valid_GTS_Time_stamp = $Time_Stamp_Values_Array[$Index3];
			
				# $Valid_GTS_time = $GTS_Values_Array[$Index3];
			
				# S_w2rep( " The valid Global system time index = $Valid_GTS_index" ); 
			
				# S_w2rep( " The valid Global system time value = $Valid_GTS_time" ); 
			
				# S_w2rep( " The valid GTS time stamp value in secs = $Valid_GTS_Time_stamp" );
			# }
		  
		# }
		
			# #Find the time stamp for SVTriggeredHard which is the indication of SIIAP firing 
			# $SVTriggerHard_Tracedata_href = CANoe_trace_get_sysvar_dataref ( $trace_file_path, 'Stimulus::SVTriggerHard', $SVTriggerHard_Tracedata_href );  
	   
			# ($SVTriggerHardValue, $SVTriggerHard_timeStamp ) = EVAL_get_values_and_times_over_time( $SVTriggerHard_Tracedata_href, 'Stimulus::SVTriggerHard');  
		
  
			# foreach $Index ( 0 .. @$SVTriggerHardValue - 1 ) 
			# {
				# push(@SVTrigger_SIIAP, $$SVTriggerHardValue[$Index]);
	   
				# push(@SVTrigger_SIIAP_Time_Stamp_Value, $$SVTriggerHard_timeStamp[$Index]);
	   
				# $SVTriggerHardTimestamp = $SVTrigger_SIIAP_Time_Stamp_Value[$Index];
	   
				# my $SVTriggerHard_SIIAP_Firing = $SVTrigger_SIIAP[$Index];
	    
				# S_w2rep( " SVTrigger Hard for Right Passenger SIIAP value and timestamp get from the trace = @SVTrigger_SIIAP ; @SVTrigger_SIIAP_Time_Stamp_Value  " );
	   
				# S_w2rep( " SVTrigger Hard for Right Passenger SIIAP timestamp value = $SVTriggerHardTimestamp" );
	   
				# S_w2rep( " SVTrigger Hard for Right Passenger SIIAP value from Trace which indicated the firing of SIIAP = $SVTriggerHard_SIIAP_Firing" );
	   
			# }
			
			# #Find the actual firing timing from the nearest GTS time stamp of GTS value after FR message update and the SVTriggerHard time stamp value which is the indication of SIIAP firing  
			# $ActualFiretime	= ($SVTriggerHardTimestamp - $Valid_GTS_Time_stamp) * 1000 ; 
			
			# if($Env_Crash_Flag_Value == 6)
			# {
				# # Calculate the expected fire time using the formula for the next cycle	
				# $ExpectedFiretime =  ((65535 - (S_hex2dec($Valid_GTS_time))) * 0.1 ) + $GlobalTimeofImpact_1;
			# }
			# elsif($Env_Crash_Flag_Value == 7)
			# {
				# # Calculate the expected fire time using the formula for the next cycle	
				# $ExpectedFiretime =  ((65535 - (S_hex2dec($Valid_GTS_time))) * 0.1 );
			# }
			
	    	# S_w2rep( "Actual Fire Time for SIIAP in ms = $ActualFiretime" );
  
			# S_w2rep( "Expected Fire Time for SIIAP in ms = $ExpectedFiretime" ); 
			
			# $SVTriggerSIIAD_Tracedata_href = CANoe_trace_get_sysvar_dataref ( $trace_file_path, 'Stimulus::SVTriggerSIIAD', $SVTriggerSIIAD_Tracedata_href );  
	   
			# ($SVTriggerSIIADValue, $SVTriggerSIIAD_timeStamp ) = EVAL_get_values_and_times_over_time( $SVTriggerSIIAD_Tracedata_href, 'Stimulus::SVTriggerSIIAD');  
		
			# foreach $Index ( 0 .. @$SVTriggerSIIADValue - 1 ) 
			# {
				# push(@SVTrigger_SIIAD, $$SVTriggerSIIADValue[$Index]);
	   
				# push(@SVTrigger_SIIAD_Time_Stamp_Value, $$SVTriggerSIIAD_timeStamp[$Index]);
	   
				# $SVTriggerSIIADTimestamp = $SVTrigger_SIIAD_Time_Stamp_Value[$Index];
	   
				# $SVTrigger_SIIAD_Firing = $SVTrigger_SIIAD[$Index];
	    
				# S_w2rep( " Left Driver SIIAD value and timestamp get from the trace = @SVTrigger_SIIAD ; @SVTrigger_SIIAD_Time_Stamp_Value  " );
	   
				# S_w2rep( " Left Driver SIIAD timestamp value = $SVTriggerSIIADTimestamp" );
	   
				# S_w2rep( " Left Driver SIIAD value from Trace which indicated the firing of SIIAD = $SVTrigger_SIIAD_Firing" );
	   
			# }
			
			# #Find the actual firing timing from the nearest GTS time stamp of GTS value after FR message update and the SVTriggerSIIAD time stamp value which is the indication of SIIAD firing  
			# $ActualFiretime_SIIAD = ($SVTriggerSIIADTimestamp - $Valid_GTS_Time_stamp) * 1000 ; 
			
			# if($Env_Crash_Flag_Value == 6)
			# {
				# # Calculate the expected fire time using the formula for the next cycle	
				# $ExpectedFiretime_SIIAD =  ((65535 - (S_hex2dec($Valid_GTS_time))) * 0.1 ) + $GlobalTimeofImpact_1;			
			# }
			
			# elsif($Env_Crash_Flag_Value == 7)
			# {
				# # Calculate the expected fire time using the formula for the next cycle	
				# $ExpectedFiretime_SIIAD =  ((65535 - (S_hex2dec($Valid_GTS_time))) * 0.1 );			
			# }
	
			# S_w2rep( "Actual Fire Time for SIIAD in ms = $ActualFiretime_SIIAD" );
			
			# S_w2rep( "Expected Fire Time for SIIAD in ms = $ExpectedFiretime_SIIAD" ); 
			
			# my $verdict = EVAL_evaluate_value("Fire Timings" , $ExpectedFiretime_SIIAD, '==', $ActualFiretime_SIIAD, 1.0 , 'absolute');
			
			# my $verdict = EVAL_evaluate_value("Fire Timings" , $ExpectedFiretime, '==', $ActualFiretime, 1.0 , 'absolute');
			
			# my $Global_TOI_FR_Message = CA_get_EnvVar_value ( 'ENV_Global_time_of_impact');
			
			# S_w2rep( "Global TOI FR Message PI_Sd_GlobalTOI_Rt_ST3 and PI_Sd_GlobalTOI_Lt_ST3 is $Global_TOI_FR_Message" );
			
			# #Create result table 
			# push(@Simdevice, $Squib_Name_passenger);
			# push(@Actual_Firing_time, $ActualFiretime);
			# push(@Expected_Firing_time, $ExpectedFiretime); 
			
			# my $tableObject = S_TableCreate( [ 'SimDevice', 'Actual_Firing_time', 'Expected_Firing_time' ], [ \@Simdevice, \@Actual_Firing_time, \@Expected_Firing_time ], 'column-wise' );
			# S_TablePrint( CONSOLE | TEXT | HTML | 2, $tableObject, 'Result Table' );
			
			# push(@Simdevice_SIIAD, $Squib_Name_Driver);
			# push(@Actual_Firing_time_SIIAD, $ActualFiretime_SIIAD);
			# push(@Expected_Firing_time_SIIAD, $ExpectedFiretime_SIIAD); 
			
			# my $tableObject_1 = S_TableCreate( [ 'SimDevice', 'Actual_Firing_time', 'Expected_Firing_time' ], [ \@Simdevice_SIIAD, \@Actual_Firing_time_SIIAD, \@Expected_Firing_time_SIIAD ], 'column-wise' );
			# S_TablePrint( CONSOLE | TEXT | HTML | 2, $tableObject_1, 'Result Table' );
	
	
	
	# }
		CREIS_EvaluateMeasurements($crashData_href);
		CREIS_EvaluateExtendedRuntime();
		CREIS_EvaluateFaultMemory($crashData_href);
		CREIS_StoreFastDiagTrace();

		return 1;
}

#### TC FINALIZATION #####
sub TC_finalization {

    CREIS_FinishReporting($crashData_href);

    # S_wait_until_timer_ms( S_get_contents_of_hash( [ 'TIMER', 'TIMER_ECU_OFF' ] ), "ECU_OFF" );

	# S_teststep( "Switch ECU On", 'AUTO_NBR' );
    # LC_ECU_On();
    # S_set_timer_zero("ECU_On");
	FR_write_flxr_signal( $tcpar_Signal_update, 1);
	S_wait_ms(2000);

	# my $Prepulsecounter = PD_ReadMemoryByName('rb_sqm_CustPrePulseCounter_dfst.PrePulseCounter_u8');
	my $address1= PD_GetAddressByName('rb_sqm_CustPrePulseCounter_dfst.PrePulseCounter_u8');
	my $Prepulsecounter_Value = PD_ReadMemoryByAddress( $address1, 1 );
		
	# PD_WriteMemoryByAddress( $address1, [0] );
	
    return 1;
}

1;

__END__

