#### TEST CASE MODULE
package TC_LST_Device;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.10 $;
our $HEADER  = q$Header: LST/TC_LST_Device.pm 1.10 2015/01/09 18:47:25ICT ver6cob develop  $;

#### INCLUDE MODULES ####
use LIFT_general;
use LIFT_PD;
use LIFT_flexray_access;
use INCLUDES_Project;    #necessary
use LIFT_evaluation;
use LIFT_CD;
##################################

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_LST_Device

=head1 PURPOSE

Increase the load for squibs and switches in steps and check for expected faults

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Increase the <Device> current or resistance based on the device type from Min threshold to Max threshold in steps of <StepSize>.
2. Wait for fault qualification if any faults are expected/accepted. Even there is no fault expected/accepted wait for maximum qualification time (say 5 sec).
3. Read fault memory in each <Step>.
4. Optionally, only for switches: Read diagnosis label and bus signals (Flexray) that are associated with the device 

I<B<Evaluation>>

1. - 
2. -
3. If there is any expected/accepted fault for given threshold, then check for expected fault as mandatory fault and accepted fault as optional fault. And ensure that no other faults are present.
4. Optionally, only for switches: Check if the diagnosis label and bus signals match the expected values as defined in $Defaults->{"Mapping_DEVICE"}{'LST_SwitchTypeExpectedValues'} for each Step 

I<B<Finalisation>>

Reset the device under test state to default.


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

'Device' is device name. Ex: AB1FD, BLFD.
'StepSize' specifies the step size (in mA or ohm) for the increment of current or resistance
'Min_expFlt' is Expected faults from threshold Min to TolerranceLow.
'Min_accFlt' is Accepted faults from threshold 'Min' to 'TolerranceLow'.
'ToleranceLow_expFlt' is Expected faults from threshold 'TolerranceLow' to 'Low'.
'ToleranceLow_accFlt' is Accepted faults from threshold 'TolerranceLow' to 'Low'.
'Low_expFlt' is Expected faults from threshold 'Low' to 'ToleranceLowUndefined'.
'Low_accFlt' is Accepted faults from threshold 'Low' to 'ToleranceLowUndefined'.
'ToleranceLowUndefined_expFlt' is Expected faults from threshold 'ToleranceLowUndefined' to 'LowUndefined'.
'ToleranceLowUndefined_accFlt' is Accepted faults from threshold 'ToleranceLowUndefined' to 'LowUndefined'.
'ToleranceUndefinedHigh_expFlt' is Expected faults from threshold 'ToleranceUndefinedHigh' to 'UndefinedHigh'.
'ToleranceUndefinedHigh_accFlt' is Accepted fault	

=head2 PARAMETER EXAMPLES

[TC_LST_Device.SWITCH_DSPOS]   #ID: TS_SI_1496
StepSize = '0.5'
# From here on: applicable Lift Default Parameters
purpose	= 'To test the LST for SWs'
Device = 'DSPOS'
Min_expFlt = @('ShortResistance')
Min_accFlt = @('')
ToleranceLow_expFlt = @('')
ToleranceLow_accFlt = @('ShortResistance')
Low_expFlt = @('')
Low_accFlt = @('')
ToleranceLowUndefined_expFlt = @('')
ToleranceLowUndefined_accFlt = @('Undefined')
LowUndefined_expFlt = @('Undefined')
LowUndefined_accFlt = @('')
ToleranceUndefinedHigh_expFlt = @('')
ToleranceUndefinedHigh_accFlt = @('Undefined')
UndefinedHigh_expFlt = @('')
UndefinedHigh_accFlt = @('')
ToleranceHigh_expFlt = @('')
ToleranceHigh_accFlt = @('Openline','Undefined')
High_expFlt = @('Openline')
High_accFlt = @('')
Max_expFlt = @('Openline')
Max_accFlt = @('')

=cut

#add any global variables here
my ( $defaultpar_purpose, $defaultpar_Device, $defaultpar_StepSize );
my ( $thresholdValue, $nextThresholdValue, $deviceType, $switchType, $deviceSetValue, $deviceSetUnit );
my ( $SearchHashRef, @tempRes, $fltMemStruct, @fltMemStruct2 );
my ( $numberOfThresholds, @switchHallBands, @switchResistiveBands, @squibBands, @finalFltMem, @finalRes, @finalDiagLabels, @finalBusSignals );
my ( @table, $tableString, $qualiTimeFinal, $newStep, $switchDiagnosable );

#our is used To access the variable by name
our ( @defaultpar_Min_expFlt, @defaultpar_Min_accFlt, @defaultpar_ToleranceLow_expFlt, @defaultpar_ToleranceLow_accFlt, @defaultpar_Low_expFlt, @defaultpar_Low_accFlt, @defaultpar_ToleranceHigh_expFlt, @defaultpar_ToleranceHigh_accFlt, @defaultpar_High_expFlt, @defaultpar_High_accFlt, @defaultpar_ToleranceLowUndefined_expFlt, @defaultpar_ToleranceLowUndefined_accFlt, @defaultpar_LowUndefined_expFlt, @defaultpar_LowUndefined_accFlt, @defaultpar_ToleranceUndefinedHigh_expFlt, @defaultpar_ToleranceUndefinedHigh_accFlt, @defaultpar_UndefinedHigh_expFlt, @defaultpar_UndefinedHigh_accFlt );
our ( @defaultpar_Min_belted, @defaultpar_Max_belted, @defaultpar_Min_notbelted, @defaultpar_Max_notbelted, @defaultpar_Min_notmeasure, @defaultpar_Max_notmeasure, @defaultpar_Signal );
my ( $v_AB_Gurtschloss_Reihe2_MI, $v_AB_Gurtschloss_Reihe2_FA, $v_AB_Gurtschloss_Reihe2_BF, @v_AB_MI, @v_AB_FA, @v_AB_BF );
my ( $config_DiagLabel, $config_BusSignal );

###############################################################

sub TC_set_parameters {

	$defaultpar_purpose  = GEN_Read_mandatory_testcase_parameter('purpose');
	$defaultpar_Device   = GEN_Read_mandatory_testcase_parameter('Device');
	$defaultpar_StepSize = GEN_Read_optional_testcase_parameter('StepSize');

	$deviceType = DEVICE_fetchDeviceType($defaultpar_Device);    #Fetch device type Squib/Switch

	if ( $deviceType eq 'Switch' )                               #parameters for all switches
	{
		$switchType = DEVICE_fetchSwitchType($defaultpar_Device);
		our $PURPOSE = "Load step test for SWITCH($defaultpar_Device)";
		my $diagnosable = $LIFT_PROJECT::Defaults->{'Mapping_DEVICE'}{$defaultpar_Device}{'diagnosable'};    # read diagnosable status of switch
		if ( $diagnosable eq 'NO' ) {                                                                        #parameters for non diagnosable switches
			$switchDiagnosable         = 1;                                                                  # Set global variable to 1, which is reqauired to seperate test steps for non diagnosable switches
			@defaultpar_Min_belted     = GEN_Read_mandatory_testcase_parameter('Min_belted');
			@defaultpar_Max_belted     = GEN_Read_mandatory_testcase_parameter('Max_belted');
			@defaultpar_Min_notbelted  = GEN_Read_mandatory_testcase_parameter('Min_notbelted');
			@defaultpar_Max_notbelted  = GEN_Read_mandatory_testcase_parameter('Max_notbelted');
			@defaultpar_Min_notmeasure = GEN_Read_optional_testcase_parameter('Min_notmeasure');
			@defaultpar_Max_notmeasure = GEN_Read_optional_testcase_parameter('Max_notmeasure');
			@defaultpar_Signal         = GEN_Read_mandatory_testcase_parameter('Signal');
		}
		else {                                                                                               #parameters for diagnosable switches
			$switchDiagnosable              = 0;
			@defaultpar_Min_expFlt          = GEN_Read_mandatory_testcase_parameter('Min_expFlt');
			@defaultpar_Min_accFlt          = GEN_Read_mandatory_testcase_parameter('Min_accFlt');
			@defaultpar_ToleranceLow_expFlt = GEN_Read_mandatory_testcase_parameter('ToleranceLow_expFlt');
			@defaultpar_ToleranceLow_accFlt = GEN_Read_mandatory_testcase_parameter('ToleranceLow_accFlt');
			@defaultpar_Low_expFlt          = GEN_Read_mandatory_testcase_parameter('Low_expFlt');
			@defaultpar_Low_accFlt          = GEN_Read_mandatory_testcase_parameter('Low_accFlt');

			@defaultpar_ToleranceLowUndefined_expFlt  = GEN_Read_mandatory_testcase_parameter('ToleranceLowUndefined_expFlt');
			@defaultpar_ToleranceLowUndefined_accFlt  = GEN_Read_mandatory_testcase_parameter('ToleranceLowUndefined_accFlt');
			@defaultpar_LowUndefined_expFlt           = GEN_Read_mandatory_testcase_parameter('LowUndefined_expFlt');
			@defaultpar_LowUndefined_accFlt           = GEN_Read_mandatory_testcase_parameter('LowUndefined_accFlt');
			@defaultpar_ToleranceUndefinedHigh_expFlt = GEN_Read_mandatory_testcase_parameter('ToleranceUndefinedHigh_expFlt');
			@defaultpar_ToleranceUndefinedHigh_accFlt = GEN_Read_mandatory_testcase_parameter('ToleranceUndefinedHigh_accFlt');
			@defaultpar_UndefinedHigh_expFlt          = GEN_Read_mandatory_testcase_parameter('UndefinedHigh_expFlt');
			@defaultpar_UndefinedHigh_accFlt          = GEN_Read_mandatory_testcase_parameter('UndefinedHigh_accFlt');

			@defaultpar_ToleranceHigh_expFlt = GEN_Read_mandatory_testcase_parameter('ToleranceHigh_expFlt');
			@defaultpar_ToleranceHigh_accFlt = GEN_Read_mandatory_testcase_parameter('ToleranceHigh_accFlt');
			@defaultpar_High_expFlt          = GEN_Read_mandatory_testcase_parameter('High_expFlt');
			@defaultpar_High_accFlt          = GEN_Read_mandatory_testcase_parameter('High_accFlt');
		}
	}
	elsif ( $deviceType eq 'Squib' )    #parameters for all squibs
	{
		our $PURPOSE = "Load step test for SQUIB($defaultpar_Device)";
		@defaultpar_Min_expFlt           = GEN_Read_mandatory_testcase_parameter('Min_expFlt');
		@defaultpar_Min_accFlt           = GEN_Read_mandatory_testcase_parameter('Min_accFlt');
		@defaultpar_ToleranceLow_expFlt  = GEN_Read_mandatory_testcase_parameter('ToleranceLow_expFlt');
		@defaultpar_ToleranceLow_accFlt  = GEN_Read_mandatory_testcase_parameter('ToleranceLow_accFlt');
		@defaultpar_Low_expFlt           = GEN_Read_mandatory_testcase_parameter('Low_expFlt');
		@defaultpar_Low_accFlt           = GEN_Read_mandatory_testcase_parameter('Low_accFlt');
		@defaultpar_ToleranceHigh_expFlt = GEN_Read_mandatory_testcase_parameter('ToleranceHigh_expFlt');
		@defaultpar_ToleranceHigh_accFlt = GEN_Read_mandatory_testcase_parameter('ToleranceHigh_accFlt');
		@defaultpar_High_expFlt          = GEN_Read_mandatory_testcase_parameter('High_expFlt');
		@defaultpar_High_accFlt          = GEN_Read_mandatory_testcase_parameter('High_accFlt');
	}

	return 1;
}

sub TC_initialization {

	S_w2rep( "StandardPrepNoFault", 'blue' );

	# get optional DiagLabel and BusSignal from device mapping
	$config_DiagLabel = $LIFT_PROJECT::Defaults->{'Mapping_DEVICE'}{$defaultpar_Device}{'DiagLabel'};
	$config_BusSignal = $LIFT_PROJECT::Defaults->{'Mapping_DEVICE'}{$defaultpar_Device}{'BusSignal'};

	return 1;
}

sub TC_stimulation_and_measurement {

	#my $counter = 0; # for debugging purposes only
	#Threshold names for SQ's and SW's.
	@switchHallBands      = ( 'Min', 'ToleranceLow', 'Low', 'ToleranceLowUndefined', 'LowUndefined', 'ToleranceUndefinedHigh', 'UndefinedHigh', 'ToleranceHigh', 'High', 'Max' );
	@switchResistiveBands = ( 'Min', 'ToleranceLow', 'Low', 'ToleranceLowUndefined', 'LowUndefined', 'ToleranceUndefinedHigh', 'UndefinedHigh', 'ToleranceHigh', 'High', 'Max' );
	@squibBands           = ( 'Min', 'ToleranceLow', 'Low', 'ToleranceHigh',         'High',         'Max' );

	if ( $switchDiagnosable == 1 ) {    #Threshold names for non diagnosable SW's.
		@switchHallBands      = ( 'Min_belted', 'Max_belted', 'Min_notbelted', 'Max_notbelted', 'Min_notmeasure', 'Max_notmeasure' );
		@switchResistiveBands = ( 'Min_belted', 'Max_belted', 'Min_notbelted', 'Max_notbelted', 'Min_notmeasure', 'Max_notmeasure' );
	}

	#--- BEGIN ---code to find out the number of thresholds supported for given device
	my $LIFT_DeviceMapping = $LIFT_PROJECT::Defaults->{'Mapping_DEVICE'};
	foreach my $key ( keys %{ $LIFT_DeviceMapping->{'Thresholds'} } ) {
		if ( $key eq $defaultpar_Device ) {
			$numberOfThresholds = keys( %{ $LIFT_DeviceMapping->{'Thresholds'}{$defaultpar_Device} } );
			last;
		}
		else { $numberOfThresholds = 0; }    #If no device thresholds are present
	}

	if ( $numberOfThresholds == 0 ) {        #If no device thresholds are present use default thresholds (Squib/Switch_hall/Switch_resistive)
		if ( $deviceType eq 'Squib' ) {
			S_w2rep( "Simulate: Threshold hash is not defined for the device($defaultpar_Device) in Mapping_device.pm file, default Squib thresholds will be used for this device($defaultpar_Device) ", 'blue' );
			$numberOfThresholds = keys( %{ $LIFT_DeviceMapping->{'Thresholds'}{'Squib'} } );    # To know total number of threshold defined in device mapping file for Squib
		}
		if ( ( $deviceType eq 'Switch' ) and ( $switchType eq 'hall' ) ) {
			S_w2rep( "Simulate: Threshold hash is not defined for the device($defaultpar_Device) in Mapping_device.pm file, default Switch_hall thresholds will be used for this device($defaultpar_Device) ", 'blue' );
			$numberOfThresholds = keys( %{ $LIFT_DeviceMapping->{'Thresholds'}{'Switch_hall'} } );    # To know total number of threshold defined in device mapping file for Switch_hall
		}
		if ( ( $deviceType eq 'Switch' ) and ( $switchType eq 'resistive' ) ) {
			S_w2rep( "Simulate: Threshold hash is not defined for the device($defaultpar_Device) in Mapping_device.pm file, default Switch_resistive thresholds will be used for this device($defaultpar_Device) ", 'blue' );
			$numberOfThresholds = keys( %{ $LIFT_DeviceMapping->{'Thresholds'}{'Switch_resistive'} } );    # To know total number of threshold defined in device mapping file for Switch_resistive
		}
	}

	#--- END ---code to find out the number of thresholds supported for given device

	#--- BEGIN ---FOR loop to repeat the step for all thresholds
	for ( my $index = 0 ; $index < $numberOfThresholds - 1 ; $index++ ) {    #Perform for all thresholds
		my @fltMemStruct1;                                                   #Temp variable to push the faultmem structure
		my ( @diagLabelStruct, @busSignalStruct );
		my ( $faultExpName,    $faultAccName );
		no strict "refs";                                                    # To access the variable by name

		if ( $deviceType eq 'Squib' )                                        # If device type is SQ then. All this info is required for beautification of report.
		{
			$deviceSetValue     = 'resistance';
			$deviceSetUnit      = 'ohms';
			$thresholdValue     = DEVICE_fetchDeviceThreshold( $defaultpar_Device, $squibBands[$index] );          # Get band threshold value
			$nextThresholdValue = DEVICE_fetchDeviceThreshold( $defaultpar_Device, $squibBands[ $index + 1 ] );    # Get next band threshold value

			return 0 unless ( defined $thresholdValue and defined $nextThresholdValue );

			if ( defined $defaultpar_StepSize ) {
				$newStep = $defaultpar_StepSize;
			}
			else {
				GEN_printComment("dividing the range into 4 equal parts");
				$newStep = ( $nextThresholdValue - $thresholdValue ) / 4;                                          #divide the range to 4 equal parts
			}

			$faultExpName = "defaultpar_" . $squibBands[$index] . "_expFlt";                                       #Constructing the variable to get the expected faults
			$faultAccName = "defaultpar_" . $squibBands[$index] . "_accFlt";                                       #Constructing the variable to get the accepted faults
			S_w2rep( "Simulate: Set the device($defaultpar_Device) $deviceSetValue from band($squibBands[$index]) value($thresholdValue) to band($squibBands[$index+1]) value($nextThresholdValue) in steps of ($newStep) and check for fault memory", 'blue' );
		}
		elsif ( $deviceType eq 'Switch' )                                                                          # If device type is SW then. All this info is required for beautification of report.
		{
			if ( ($switchType) eq 'hall' )                                                                         #if switch type is hall
			{
				$deviceSetValue = 'current';
				$deviceSetUnit  = 'mA';

				#				if($switchDiagnosable == 1){
				#					$faultExpName = "defaultpar_" . $switchHallBands[$index];#Constructing the variable to get the expected faults
				#					$faultAccName = "defaultpar_" . $switchHallBands[$index];#Constructing the variable to get the accepted faults
				#				}
				$faultExpName       = "defaultpar_" . $switchHallBands[$index] . "_expFlt";                                 #Constructing the variable to get the expected faults
				$faultAccName       = "defaultpar_" . $switchHallBands[$index] . "_accFlt";                                 #Constructing the variable to get the accepted faults
				$thresholdValue     = DEVICE_fetchDeviceThreshold( $defaultpar_Device, $switchHallBands[$index] );          # Get band threshold value
				$nextThresholdValue = DEVICE_fetchDeviceThreshold( $defaultpar_Device, $switchHallBands[ $index + 1 ] );    # Get next band threshold value

				return 0 unless ( defined $thresholdValue and defined $nextThresholdValue );

				if ( defined $defaultpar_StepSize ) {
					$newStep = $defaultpar_StepSize;
				}
				else {
					GEN_printComment("dividing the range into 4 equal parts");
					$newStep = ( $nextThresholdValue - $thresholdValue ) / 4;                                               #divide the range to 4 equal parts
				}

				S_w2rep( "Simulate: Set the device($defaultpar_Device) $deviceSetValue from band($switchHallBands[$index]) value($thresholdValue) to band($switchHallBands[$index+1]) value($nextThresholdValue) in steps of ($newStep) and check for fault memory", 'blue' );
			}
			if ( ($switchType) eq 'resistive' )                                                                             #if switch type is resistive
			{
				$deviceSetValue = 'resistance';
				$deviceSetUnit  = 'ohms';

				#				if($switchDiagnosable == 1){
				#					$faultExpName = "defaultpar_" . $switchHallBands[$index];#Constructing the variable to get the expected faults
				#					$faultAccName = "defaultpar_" . $switchHallBands[$index];#Constructing the variable to get the accepted faults
				#				}
				$faultExpName       = "defaultpar_" . $switchResistiveBands[$index] . "_expFlt";                                 #Constructing the variable to get the expected faults
				$faultAccName       = "defaultpar_" . $switchResistiveBands[$index] . "_accFlt";                                 #Constructing the variable to get the accepted faults
				$thresholdValue     = DEVICE_fetchDeviceThreshold( $defaultpar_Device, $switchResistiveBands[$index] );          # Get band threshold value
				$nextThresholdValue = DEVICE_fetchDeviceThreshold( $defaultpar_Device, $switchResistiveBands[ $index + 1 ] );    # Get next band threshold value

				return 0 unless ( defined $thresholdValue and defined $nextThresholdValue );

				if ( defined $defaultpar_StepSize ) {
					$newStep = $defaultpar_StepSize;
				}
				else {
					GEN_printComment("dividing the range into 4 equal parts");
					$newStep = ( $nextThresholdValue - $thresholdValue ) / 4;                                                    #divide the range to 4 equal parts
				}

				S_w2rep( "Simulate: Set the device($defaultpar_Device) $deviceSetValue from band($switchResistiveBands[$index]) value($thresholdValue) to band($switchResistiveBands[$index+1]) value($nextThresholdValue) in steps of ($newStep) and check for fault memory", 'blue' );
			}
			if ( ($switchType) eq 'mech' )                                                                                       #if switch type is mechanical
			{
				S_w2rep( "Load step test is not applicable for mechanical switch ($defaultpar_Device)", 'blue' );
				return 1;
			}
		}
		#--- BEGIN ---WHILE loop to repeat the step for all thresholds in steps of $newStep
		while ( $nextThresholdValue >= $thresholdValue ) {

			if ( $deviceSetValue eq 'resistance' ) {    #if switch type is resistive
				if ( $thresholdValue eq $nextThresholdValue ) {
					if ( ( $nextThresholdValue - $thresholdValue ) < 10 ) {
						my $thresholdValue_new = $thresholdValue - 0.1;
						DEVICE_setDeviceResistance( $defaultpar_Device, $thresholdValue_new );
						push( @tempRes, $thresholdValue_new );    # Push threshold value to one more array for evaluation purpose
						S_w2rep( "Simulate: fault memory when $defaultpar_Device $deviceSetValue is set to $thresholdValue_new $deviceSetUnit", 'blue' );
					}
					else {
						my $thresholdValue_new = $thresholdValue - 1;
						DEVICE_setDeviceResistance( $defaultpar_Device, $thresholdValue_new );
						push( @tempRes, $thresholdValue - 1 );    # Push threshold value to one more array for evaluation purpose
						S_w2rep( "Simulate: fault memory when $defaultpar_Device $deviceSetValue is set to $thresholdValue_new $deviceSetUnit", 'blue' );
					}
				}
				else {
					DEVICE_setDeviceResistance( $defaultpar_Device, $thresholdValue );
					push( @tempRes, $thresholdValue );            # Push threshold value to one more array for evaluation purpose
					S_w2rep( "Simulate: fault memory when $defaultpar_Device $deviceSetValue is set to $thresholdValue $deviceSetUnit", 'blue' );
				}
			}
			elsif ( $deviceSetValue eq 'current' ) {              #if switch type is hall
				if ( $thresholdValue eq $nextThresholdValue ) {
					if ( ( $nextThresholdValue - $thresholdValue ) < 10 ) {
						my $thresholdValue_new = $thresholdValue - 0.1;
						DEVICE_setDeviceCurrent( $defaultpar_Device, $thresholdValue_new );
						push( @tempRes, $thresholdValue_new );    # Push threshold value to one more array for evaluation purpose
						S_w2rep( "Simulate: fault memory when $defaultpar_Device $deviceSetValue is set to $thresholdValue_new $deviceSetUnit", 'blue' );
					}
					else {
						my $thresholdValue_new = $thresholdValue - 1;
						DEVICE_setDeviceCurrent( $defaultpar_Device, $thresholdValue_new );
						push( @tempRes, $thresholdValue_new );    # Push threshold value to one more array for evaluation purpose
						S_w2rep( "Simulate: fault memory when $defaultpar_Device $deviceSetValue is set to $thresholdValue_new $deviceSetUnit", 'blue' );
					}
				}
				else {
					DEVICE_setDeviceCurrent( $defaultpar_Device, $thresholdValue );
					push( @tempRes, $thresholdValue );            # Push threshold value to one more array for evaluation purpose
					S_w2rep( "Simulate: fault memory when $defaultpar_Device $deviceSetValue is set to $thresholdValue $deviceSetUnit", 'blue' );
				}
			}

			my ( %SearchHash, $faultsExp, $faultsAcc, @faultsExpar, @faultsAccar );
			my $qualitimenew = 3000;                              #Deafult wait time for fault qualification if any

			$SearchHash{'Device'} = $defaultpar_Device;
			if ( $switchDiagnosable == 1 ) {                      #IF switch is non diagnosable
				S_w2rep( "Wait for 1000 msec before checking the flexray signal", 'Orange' );
				S_wait_ms(1000);                                  #Wait for signal to update
				my $signal = FR_read_flxr_signal( $defaultpar_Signal[0], 'hex' );
				push( @v_AB_FA, $signal );
				$thresholdValue = $thresholdValue + $newStep;     #increase the threshold value in steps
				$thresholdValue = eval sprintf("%.3f", $thresholdValue);  #only to limit to 3 decimal places
			}
			else                                                  #IF switch is diagnosable
			{
				foreach my $condition ( @{$faultExpName} ) {
					if ( $condition ne '' ) {
						$SearchHash{'Condition'} = $condition;
						$faultsExp = FM_fetchFaultName( \%SearchHash );
						if ( defined $faultsExp ) { S_w2rep( "Adding fault(@$faultsExp) to mandatory faults list ", 'Orange' ); }
						else                      { S_set_error( "Fault name is not present in fault mapping file with condition($condition), device name($defaultpar_Device) ", 114 ); }
					}
					my $qualitime;
					foreach my $condition1 (@$faultsExp) {
						if ( $condition1 ne '' ) {
							my $faultproperty = FM_fetchFaultInfo($condition1);
							$qualitime = $faultproperty->{'Qualificationtime'};
						}
						if ( $qualitimenew < $qualitime ) { $qualitimenew = $qualitime; }
					}
				}
				$SearchHash{'Device'} = $defaultpar_Device;
				foreach my $condition ( @{$faultAccName} ) {
					if ( $condition ne '' ) {
						$SearchHash{'Condition'} = $condition;
						$faultsAcc = FM_fetchFaultName( \%SearchHash );
						if ( defined $faultsAcc ) { S_w2rep( "Adding fault(@$faultsAcc) to mandatory faults list ", 'Orange' ); }
						else                      { S_set_error( "Fault name is not present in fault mapping file with condition($condition), device name($defaultpar_Device) ", 114 ); }
					}
					my $qualitime;
					foreach my $condition1 (@$faultsAcc) {
						if ( $condition1 ne '' ) {
							my $faultproperty = FM_fetchFaultInfo($condition1);
							$qualitime = $faultproperty->{'Qualificationtime'};
						}
						if ( $qualitimenew < $qualitime ) { $qualitimenew = $qualitime; }
					}
				}
				$qualitimenew = $qualitimenew + ( $qualitimenew * 0.2 );    #Wait for fault quali time + tolerrance
				GEN_printComment("Wait $qualitimenew msec for device($defaultpar_Device) fault qualification time");
				S_wait_ms($qualitimenew);                                   #Wait for fault quali time
				$qualiTimeFinal = $qualitimenew;

				$fltMemStruct = FM_PD_readFaultMemory();                    # Read fault memory through PD
				push( @fltMemStruct1, $fltMemStruct );                      # Push fault mem struvt to one more array for evaluation purpose

				$thresholdValue = $thresholdValue + $newStep;               #increase the threshold value in steps
				$thresholdValue = eval sprintf("%.3f", $thresholdValue);  	#only to limit to 3 decimal places
			}

			# if DiagLabel is defined for the current device then read the value of the DiagLabel with PD and store it
			if ( defined $config_DiagLabel ) {
				my $DiagLabel_aref = PD_ReadMemoryByName($config_DiagLabel);

				#$DiagLabel_aref = [$counter]; # for debugging purposes only
				#$counter++; # for debugging purposes only
				push( @diagLabelStruct, ${$DiagLabel_aref}[0] );
			}

			# if BusSignal is defined for the current device then read the value of the BusSignal from Flexray and store it
			if ( defined $config_BusSignal ) {
				my $busValue = FR_read_flxr_signal( $config_BusSignal, 'hex' );
				push( @busSignalStruct, $busValue );
			}

			PD_ClearFaultMemory();

			#last;
		}

		#--- END ---WHILE loop to repeat the step for all thresholds in steps of $newStep

		$finalFltMem[$index] = \@fltMemStruct1;
		my @finalRes1 = @tempRes;
		$finalRes[$index]        = \@finalRes1;
		$finalDiagLabels[$index] = \@diagLabelStruct;
		$finalBusSignals[$index] = \@busSignalStruct;
		$#tempRes                = -1;                  #remove the elements in array and then proceed

		#last;
	}

	#--- END ---FOR loop to repeat the step for all thresholds
	return 1;
}

sub TC_evaluation {

	my ( $faultExpName, $faultAccName, $htmlString, $verdictColor, $range );
	my $j = 0;                                          # Variable for table index

	if ( $switchDiagnosable == 1 ) {                    #create table only for diagnosable switches
		$htmlString = '<div class="w2rep"><TABLE class="tablesorter" border="1"> <TR> <TH>Index</TH> <TH>Value</TH> <TH>Sig expt value</TH> <TH>Sig obt value</TH> <TH>Status</TH>';    #table class and heading (1st row)
	}
	else {
		$htmlString = '<div class="w2rep"><TABLE class="tablesorter" border="1"> <TR> <TH>Index</TH> <TH>Value</TH> <TH>Exp Flts</TH> <TH>Acc Flts</TH> <TH>Obt Flts</TH> <TH>Status</TH>';    #table class and heading (1st row)
	}

	# extend result table header if DiagLabel exists
	if ( defined $config_DiagLabel ) {
		$htmlString .= '<TH>Exp value</TH> <TH>Obt value - Diag Label </br>' . $config_DiagLabel . '</TH> <TH>Status</TH>';
	}

	# extend result table header if BusSignal exists
	if ( defined $config_BusSignal ) {
		$htmlString .= '<TH>Exp value</TH> <TH>Obt value - Bus Signal </br>' . $config_BusSignal . '</TH> <TH>Status</TH>';
	}

	# end of result table header
	$htmlString .= '</TR>';

	push( @table, $htmlString );

	#--- BEGIN ---FOR loop to repeat the step for all thresholds
	for ( my $index = 0 ; $index < $numberOfThresholds - 1 ; $index++ )    #Perform for all thresholds
	{
		no strict "refs";                                                  # To access the variable by name

		if ( $deviceType eq 'Squib' )                                      # IF DEVICE TYPE IS SQUIB
		{
			$deviceSetValue     = 'resistance';
			$deviceSetUnit      = 'ohms';
			$thresholdValue     = DEVICE_fetchDeviceThreshold( $defaultpar_Device, $squibBands[$index] );          # Get band threshold value
			$nextThresholdValue = DEVICE_fetchDeviceThreshold( $defaultpar_Device, $squibBands[ $index + 1 ] );    # Get next band threshold value
			$faultExpName       = "defaultpar_" . $squibBands[$index] . "_expFlt";                                 #Constructing the variable to get the expected faults
			$faultAccName       = "defaultpar_" . $squibBands[$index] . "_accFlt";                                 #Constructing the variable to get the accepted faults
			S_w2rep( "Evaluate: Fault memory when device $deviceSetValue is set from band($squibBands[$index]) value($thresholdValue) to band($squibBands[$index+1]) value($nextThresholdValue) in steps of ($newStep) and check for fault memory", 'blue' );
		}
		if ( $deviceType eq 'Switch' )                                                                             # IF DEVICE TYPE IS SWITCH
		{
			if ( $switchType eq 'hall' ) {
				$deviceSetValue     = 'current';
				$deviceSetUnit      = 'mA';
				$thresholdValue     = DEVICE_fetchDeviceThreshold( $defaultpar_Device, $switchHallBands[$index] );          # Get band threshold value
				$nextThresholdValue = DEVICE_fetchDeviceThreshold( $defaultpar_Device, $switchHallBands[ $index + 1 ] );    # Get next band threshold value
				if ( $switchDiagnosable == 1 ) {
					$faultExpName = "defaultpar_" . $switchHallBands[$index];                                               #Constructing the variable to get the expected faults
					$faultAccName = "defaultpar_" . $switchHallBands[$index];                                               #Constructing the variable to get the accepted faults
				}
				else {
					$faultExpName = "defaultpar_" . $switchHallBands[$index] . "_expFlt";                                   #Constructing the variable to get the expected faults
					$faultAccName = "defaultpar_" . $switchHallBands[$index] . "_accFlt";                                   #Constructing the variable to get the accepted faults
				}
				S_w2rep( "Evaluate: Fault memory when device $deviceSetValue is set from band($switchHallBands[$index]) value($thresholdValue) to band($switchHallBands[$index+1]) value($nextThresholdValue) in steps of ($newStep) and check for fault memory", 'blue' );
			}
			if ( $switchType eq 'resistive' ) {
				$deviceSetValue     = 'resistance';
				$deviceSetUnit      = 'ohms';
				$thresholdValue     = DEVICE_fetchDeviceThreshold( $defaultpar_Device, $switchResistiveBands[$index] );          # Get band threshold value
				$nextThresholdValue = DEVICE_fetchDeviceThreshold( $defaultpar_Device, $switchResistiveBands[ $index + 1 ] );    # Get next band threshold value
				if ( $switchDiagnosable == 1 ) {
					$faultExpName = "defaultpar_" . $switchHallBands[$index];                                                    #Constructing the variable to get the expected faults
					$faultAccName = "defaultpar_" . $switchHallBands[$index];                                                    #Constructing the variable to get the accepted faults
				}
				else {
					$faultExpName = "defaultpar_" . $switchResistiveBands[$index] . "_expFlt";
					$faultAccName = "defaultpar_" . $switchResistiveBands[$index] . "_accFlt";
				}
				S_w2rep( "Evaluate: Fault memory when device $deviceSetValue is set from band($switchResistiveBands[$index]) value($thresholdValue) to band($switchResistiveBands[$index+1]) value($nextThresholdValue) in steps of ($newStep) and check for fault memory", 'blue' );
			}
			if ( $switchType eq 'mech' ) {
				S_w2rep( "Load step test is not applicable for mechanical SWITCHE($defaultpar_Device)", 'blue' );
				return 1;
			}

			# get the name of the current ohm or ampere range from $faultExpName
			if ( $faultExpName =~ /defaultpar_(\w+)/ ) {
				$range = $1;
				$range =~ s/_expFlt//;
			}
			else {
				$range = undef;
			}
		}

		my $arrayRes = $finalRes[$index];
		my $i;

		#--- BEGIN ---FOR loop to repeat the evaluation step for all fault structures
		for ( $i = 0 ; $i < @$arrayRes ; $i++ ) {
			my $verdictVariable;
			S_w2rep( "Evaluate: fault memory when $defaultpar_Device $deviceSetValue is set to @{$finalRes[$index]}[$i]", 'blue' );    #] ..... @$array[$i]
			push( @TC_HTML_TEXT, "<a id='step$index$i' name='step$index$i'></a>" );                                                    # pushing the anchor to report
			my ( %SearchHash, $faultsExp, $faultsAcc, @faultsExpar, @faultsAccar );

			if ( $switchDiagnosable == 1 ) {                                                                                           #IF switch is non diagnosable
				my $expSigValue;

				foreach my $condition ( @{$faultExpName} ) {
					if ( $condition ne '' ) {
						$expSigValue = $condition;
						my $VERDICT = EVAL_evaluate_value( "Signal ($defaultpar_Signal[0]) value ", $v_AB_FA[$j], '==', $expSigValue );

						#my $VERDICT = S_get_current_verdict ( );
						$verdictColor = 'red';
						if ( $VERDICT eq 'VERDICT_PASS' ) {
							$verdictColor = 'green';
						}
						$htmlString = "<TR> <TD>$j</TD> <TD>@{$finalRes[$index]}[$i] $deviceSetUnit</TD> <TD>$expSigValue</TD> <TD>$v_AB_FA[$j]</TD><TD><a href='#step$index$i' style =\" color:$verdictColor\">$VERDICT</a></TD>";    #table content rows

					}
					else {
						$htmlString = "<TR> <TD>$j</TD> <TD>@{$finalRes[$index]}[$i] $deviceSetUnit</TD> <TD>$expSigValue</TD> <TD> <span style ='color:gray'>Not evaluated - Gray values</TD><TD bgcolor =\"green\"><a href='#step$index$i' style =\" color:gray\">NONE</a></TD>";    #table content rows
					}

				}

				#EVAL_evaluate_value ( "Signal ($defaultpar_Signal[0]) value " , $v_AB_FA[$j], '==', $expSigValue );
				#push( @tableNonDiag, "<TR> <TD>$j</TD> <TD>@{$finalRes[$index]}[$i] $deviceSetUnit</TD> <TD>$expSigValue</TD> <TD>$v_AB_FA[$j]</TD><TD><a href='#step$index$i'>$VERDICT</a></TD><TR>" );#table content rows
				$thresholdValue = $thresholdValue + $newStep;    #increase the threshold value in steps
			}
			else {                                               #IF switch is diagnosable
				$SearchHash{'Device'} = $defaultpar_Device;

				#--- BEGIN ---FOR loop to fetch expecetd faults
				foreach my $condition ( @{$faultExpName} ) {
					if ( $condition ne '' ) {
						$SearchHash{'Condition'} = $condition;
						$faultsExp = FM_fetchFaultName( \%SearchHash );
						if ( defined $faultsExp ) {
							S_w2rep( "Adding fault(@$faultsExp) to mandatory faults list ", 'Orange' );
							push( @faultsExpar, @$faultsExp );
						}
						else { S_set_error( "Fault name is not present in fault mapping file with condition($condition), device name($defaultpar_Device) ", 114 ); }
					}
				}

				#--- END ---FOR loop to fetch expecetd faults

				#--- BEGIN ---FOR loop to fetch accepted faults
				foreach my $condition ( @{$faultAccName} ) {
					if ( $condition ne '' ) {
						$SearchHash{'Condition'} = $condition;
						$faultsAcc = FM_fetchFaultName( \%SearchHash );
						if ( defined $faultsAcc ) {
							S_w2rep( "Adding fault(@$faultsAcc) to mandatory faults list ", 'Orange' );
							push( @faultsAccar, @$faultsAcc );
						}
						else { S_set_error( "Fault name is not present in fault mapping file with condition($condition), device name($defaultpar_Device) ", 114 ); }
					}
				}

				#--- END ---FOR loop to fetch accepted faults

				my $VERDICT = CD_evaluate_faults( ${ $finalFltMem[$index] }[$i], \@faultsExpar, \@faultsAccar );

				#my $VERDICT = S_get_current_verdict ( );
				my $fltstuct       = ${ $finalFltMem[$index] }[$i];
				my $allFaults_aref = $fltstuct->{'fault_text'};
				my $option_flts    = $LIFT_PROJECT::Defaults->{TEMP_OPTIONAL_FAULTS};
				my ( $skip, @finalfaultlist );

				#--- BEGIN ---FOR loop to remove optional faults from total faults
				foreach my $first (@$allFaults_aref) {
					$skip = 0;
					foreach my $second (@$option_flts) {
						if ( $first eq $second ) {
							$skip = 1;
							last;
						}
					}
					if ( $skip == 0 ) { push( @finalfaultlist, $first ); }
				}

				#--- END ---FOR loop to remove optional faults from total faults

				# evaluate variable values
				$verdictColor = 'red';
				if ( $VERDICT eq 'VERDICT_PASS' ) {
					$verdictColor = 'green';
				}
				$htmlString = "<TR> <TD>$j</TD> <TD>@{$finalRes[$index]}[$i] $deviceSetUnit</TD> <TD>@faultsExpar</TD> <TD>@faultsAccar</TD> <TD>@finalfaultlist</TD> <TD><a href='#step$index$i' style =\" color:$verdictColor\">$VERDICT</a></TD>";

			}    #end ELSE

			my $switchTypeExpectedValues = $LIFT_PROJECT::Defaults->{'Mapping_DEVICE'}{'LST_SwitchTypeExpectedValues'};

			# evaluate DiagLabel
			if ( defined $config_DiagLabel ) {

				# check if expected values exist for the current ohm or ampere range
				if ( defined $range and ( defined $switchTypeExpectedValues->{$defaultpar_Device}{'DiagLabelValue'}{$range} or defined $switchTypeExpectedValues->{$switchType}{'DiagLabelValue'}{$range} ) ) {
					my $detectedValue = ${ $finalDiagLabels[$index] }[$i];
					my $expectedValue;

					# expected value is taken from device mapping, either from key with the device name (if it exists) or from key with the switch type
					if ( defined $switchTypeExpectedValues->{$defaultpar_Device}{'DiagLabelValue'}{$range} ) {
						$expectedValue = $switchTypeExpectedValues->{$defaultpar_Device}{'DiagLabelValue'}{$range};
					}
					else {
						$expectedValue = $switchTypeExpectedValues->{$switchType}{'DiagLabelValue'}{$range};
					}

					# compare detected and expected value
					$verdictVariable = EVAL_evaluate_value( "Diag label ($config_DiagLabel) value ", $expectedValue, '==', $detectedValue );

					# add entry to result table for current ohm or ampere range
					$verdictColor = 'red';
					if ( $verdictVariable eq 'VERDICT_PASS' ) {
						$verdictColor = 'green';
					}
					$htmlString .= "<TD>$expectedValue</TD> <TD>$detectedValue</TD> <TD><a href='#step$index$i' style =\" color:$verdictColor\">$verdictVariable</a></TD>";

				}

				# if no expected value exists then 'Not evaluated' is written to the result table
				else {
					$htmlString .= "<TD> </TD> <TD>Not evaluated - Gray values</TD> <TD><a href='#step$index$i' style =\" color:gray\">NONE</a></TD>";
				}
			}

			# evaluate BusSignal
			if ( defined $config_BusSignal ) {

				# check if expected values exist for the current ohm or ampere range
				if ( defined $range and ( defined $switchTypeExpectedValues->{$defaultpar_Device}{'BusSignalValue'}{$range} or defined $switchTypeExpectedValues->{$switchType}{'BusSignalValue'}{$range} ) ) {
					my $detectedValue = ${ $finalBusSignals[$index] }[$i];
					my $expectedValue;

					# expected value is taken from device mapping, either from key with the device name (if it exists) or from key with the switch type
					if ( defined $switchTypeExpectedValues->{$defaultpar_Device}{'BusSignalValue'}{$range} ) {
						$expectedValue = $switchTypeExpectedValues->{$defaultpar_Device}{'BusSignalValue'}{$range};
					}
					else {
						$expectedValue = $switchTypeExpectedValues->{$switchType}{'BusSignalValue'}{$range};
					}

					# compare detected and expected value
					$verdictVariable = EVAL_evaluate_value( "Bus signal ($config_BusSignal) value ", $expectedValue, '==', $detectedValue );

					# add entry to result table for current ohm or ampere range
					$verdictColor = 'red';
					if ( $verdictVariable eq 'VERDICT_PASS' ) {
						$verdictColor = 'green';
					}
					$htmlString .= "<TD>$expectedValue</TD> <TD>$detectedValue</TD> <TD><a href='#step$index$i' style =\" color:$verdictColor\">$verdictVariable</a></TD>";

				}

				# if no expected value exists then 'Not evaluated' is written to the result table
				else {
					$htmlString .= "<TD> </TD> <TD>Not evaluated - Gray values</TD> <TD><a href='#step$index$i' style =\" color:gray\">NONE</a></TD>";
				}
			}

			$htmlString .= "</TR>";

			push( @table, $htmlString );    #table content rows
			$j++;                           #Increase the table index

		}

		#--- END ---FOR loop to repeat the evaluation step for all fault structures
	}

	#--- END ---FOR loop to repeat the step for all thresholds

	push( @table, "</TABLE></div>\n" );     #close table
	$tableString = join( '', @table );      #make it a string
	unshift( @TC_HTML_TEXT, "<p><b> <center> Summary of test evaluation </center> </b></p> <br/> $tableString" );    #print to report

	return 1;
}

sub TC_finalization {

	# Set the device to default state

	if ( $deviceType eq 'Squib' ) {
		DEVICE_setDeviceResistance( $defaultpar_Device, 2.2 );
	}
	if ( $deviceType eq 'Switch' ) {
		DEVICE_setDeviceState( $defaultpar_Device, 'DEFAULT' );
	}

	GEN_printComment("Wait $qualiTimeFinal msec to set the device back to normal state");
	S_wait_ms(1000);    #Wait for fault quali time

	PD_ClearFaultMemory();

	return 1;
}

1;
