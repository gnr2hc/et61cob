Folder contains the sVTT curve collection (curve database usable by all projects):

0. No random (stochastic) parametrised curves to be placed here, only base-shape curves!
1. Place new curve here (consider naming convention to make clear what it is inside!!!)
2. Update DOORS: "Generic test spec"
	Examples of DOORS automation to sVTT started already
	   - core-asset VTT in Dz, but not based on sVTT module
	   - MQB project sVTT in Dz started to generate par-files from DOORS (Reza, Archana)
	Final/longterm solution to be developed further, based on given needs/user feedback

Notes:
- All curves used in any test are archived in testreport

