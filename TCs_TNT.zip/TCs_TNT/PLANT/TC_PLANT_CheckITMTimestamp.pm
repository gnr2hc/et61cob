# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_PLANT_CheckITMTimestamp;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Plant
#TS version in DOORS: 1.13
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_TEMPERATURE;
use LIFT_evaluation;

#use LIFT_functional_layer;
use FuncLib_TNT_GEN;
use LIFT_FaultMemory;
use FuncLib_SYC_INTERFACE;
##################################

our $PURPOSE = " check ITM timestamp with ECU ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PLANT_CheckITMTimestamp 

=head1 PURPOSE

 check ITM timestamp with ECU

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

    Ubat
    Label
    ECUInitTime_s

    [initialisation]
    get temperature
    switch ECU on with U_BATT_DEFAULT
    clear fault memory

    [stimulation & measurement]
    1. switch ECU on
    2. activate plant mode 5
    3. reset ECU
    4. wait 10sec (for end of initialization)
    5. read ITM timestamp
    6. compare ITM timestamp against value for initalization
    7. deactivate plant mode 5
    8. switch ECU off

    [evaluation]
    1. -
    2. -
    3. -
    4. -
    5. -
    6. ITM timestamp < EcuInitTime_s
    7. -
    8. -

    [finalisation]
    switch ECU on
    clear fault memory
    switch ECU off


=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'Ubat'           --> battery voltage value
    SCALAR 'Label'          --> label for ITM timestamp
    SCALAR 'EcuInitTime_s'  --> value for initialization time
    
=head2 PARAMETER EXAMPLES

    [TC_PLANT_CheckITMTimestamp.ECU]
	purpose       = 'check ITM timestamp with ECU'
	Ubat          = 13.5
	Label         = 'rb_itm_EndOfItmTimestamp_u32'
	EcuInitTime_s = 'SYC'
	
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#PARAMETERS
################ Parameters from .par file ######################
my ( $tcpar_Ubat_V, $label, $ecuInitTime_s );
################ Parameters from syc ############################

################ global parameter declaration ###################
my $plantmode5_set  = 0b00010000;
my $plantmode_clear = 0b00000000;

my ($itmTimestamp);

my @temperatures = ();

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_Ubat_V  = S_read_mandatory_testcase_parameter('Ubat');
	$label         = S_read_mandatory_testcase_parameter('Label');
	$ecuInitTime_s = S_read_mandatory_testcase_parameter('EcuInitTime_s');

	if ( $ecuInitTime_s eq 'SYC' ) {
		( my $result, $ecuInitTime_s ) = SYC_ECU_get_InitTime_s();
		return 0 unless $result;
	}

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');
	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	# 1. switch ECU on
	S_teststep( "Switch ECU on with Ubat = $tcpar_Ubat_V V", 'AUTO_NBR' );
	LC_ECU_On($tcpar_Ubat_V);
	S_wait_ms('TIMER_ECU_READY');

	# 2. activate plant mode 5
	S_teststep( "Activate plantmode", 'AUTO_NBR' );
	PRD_Write_Memory( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [$plantmode5_set] );

	# 3. reset ECU
	S_teststep( "Reset ECU", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	LC_ECU_On($tcpar_Ubat_V);

	# 4. wait 10sec (for end of initialization)
	S_teststep( "Wait 10sec (for end of initialization)", 'AUTO_NBR' );
	S_wait_ms(10000);

	# 5. read ITM timestamp
	S_teststep( "Read ITM timestamp", 'AUTO_NBR' );

	$itmTimestamp = PRD_Read_Memory( $label, { memoryContentsAsInteger => 1 } );

	# 6. compare ITM timestamp against value for initalization
	S_teststep( "Compare ITM timestamp against value for initialization", 'AUTO_NBR', 'ItmTimestamp' );

	# 7. deactivate plant mode 5
	S_teststep( "Deactivate plantmode", 'AUTO_NBR' );
	PRD_Write_Memory( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [$plantmode_clear] );

	# 8. switch ECU off
	S_teststep( "Switch ECU off", 'AUTO_NBR' );
	LC_ECU_Off();

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	S_teststep_expected( "EcuInitTime == $ecuInitTime_s sec",                    'ItmTimestamp' );
	S_teststep_expected( "value for comparision == " . $ecuInitTime_s * 1000000, 'ItmTimestamp' );
	S_teststep_detected( "ITM Timestamp is $itmTimestamp", 'ItmTimestamp' );
	EVAL_evaluate_value( "ITM Timestamp", $itmTimestamp, '<', $ecuInitTime_s * 1000000 );
	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');
	PRD_Clear_Fault_Memory();
	LC_ECU_Off();

	S_teststep_detected("TEMP: $temperatures[0]");
	S_teststep_detected("UBat: $tcpar_Ubat_V V");

	return 1;
}

1;
