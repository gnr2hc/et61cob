# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_PLANT_plantmode_8;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Plant
#TS version in DOORS:
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use LIFT_QuaTe;
use FuncLib_TNT_GEN;

##################################

our $PURPOSE = "check plant mode 8: PSI test mode";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PLANT_plantmode_8

=head1 PURPOSE

check plant mode 8 SuppressPesFaults behaviour

=head1 TESTCASE DESCRIPTION

This script is based on 

I<B<Initialisation>>

PROD_Standard_Preparation


Set <TestCondition>


I<B<Stimulation and Measurement>>



I<B<Evaluation>>






I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES



=head2 PARAMETER EXAMPLES


=cut

#PARAMETERS
################ Parameters from .par file ###################
my ( $tcpar_FLTmandPMInactive, $tcpar_FLToptPMInactive, $tcpar_FLTmandPMActive, $tcpar_FLToptPMActive );
my ($tcpar_Ubat_V);
################ global parameter declaration ###################
#add any global variables here
my @temperatures;
my $plantmode8_set  = 0b10000000;
my $plantmode_clear = 0b00000000;
my ( $data_aref1,  $data_aref2 );
my ( $data_href1,  $data_href2 );
my ( $fltmem1,     $fltmem2 );
my ( $fault1count, $fault2count );

###############################################################

sub TC_set_parameters {

	$tcpar_Ubat_V            = S_read_mandatory_testcase_parameter('Ubat');
	$tcpar_FLTmandPMInactive = S_read_optional_testcase_parameter('FLTmandPMInactive');
	$tcpar_FLToptPMInactive  = S_read_optional_testcase_parameter('FLToptPMInactive');
	$tcpar_FLTmandPMActive   = S_read_optional_testcase_parameter('FLTmandPMActive');
	$tcpar_FLToptPMActive    = S_read_optional_testcase_parameter('FLToptPMActive');

	S_set_error( "'QUATE_plant' configuration not found in Project Defaults", 114 ) unless ( defined $main::ProjectDefaults->{'QUATE_plant'} );
	S_set_error( "'U_BATT_DEFAULT' not found in Project Defaults 'VEHICLE'",  114 ) unless ( defined $main::ProjectDefaults->{'VEHICLE'}{'U_BATT_DEFAULT'} );
	S_set_error( "'TIMER_ECU_OFF' not found in Project Defaults 'TIMER'",     114 ) unless ( defined $main::ProjectDefaults->{'TIMER'}{'TIMER_ECU_OFF'} );
	S_set_error( "'TIMER_ECU_READY' not found in Project Defaults 'TIMER'",   114 ) unless ( defined $main::ProjectDefaults->{'TIMER'}{'TIMER_ECU_READY'} );

	return 1;
}

sub TC_initialization {

	S_teststep( "Standard Prep No fault", 'AUTO_NBR' );
	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	#    PD_ECUlogin();
	PD_ClearFaultMemory();
	S_wait_ms('TIMER_ECU_READY');

	PD_GetExtendedFaultInformation();

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	push( @temperatures, TEMP_get_temperature() );

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Switch ECU on with Ubat = $tcpar_Ubat_V V", 'AUTO_NBR' );
	LC_ECU_On($tcpar_Ubat_V);
	S_wait_ms('TIMER_ECU_READY');

	#    PD_ECUlogin();

	S_teststep( "Check if plantmode is not yet activated", 'AUTO_NBR', 'mode_inactive' );
	$data_aref1 = PD_ReadMemoryByName('rb_sycg_ActivePlantModes_au8(0)');
	$data_href1 = PD_ReadLampStates();

	S_teststep( "Switch ECU off", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep( "Load QuaTe configuration for plant mode", 'AUTO_NBR' );
	QuaTe_configure( $main::ProjectDefaults->{'QUATE_plant'} );
	S_wait_ms(2000);

	S_teststep( "Switch ECU on", 'AUTO_NBR' );
	LC_ECU_On($tcpar_Ubat_V);
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Check if faults are qualified", 'AUTO_NBR', 'checkFaultPMInactive' );
	$fltmem1     = PD_GetExtendedFaultInformation();
	$fault1count = scalar( @{ $fltmem1->{"fltnum"} } );

	S_teststep( "Set plantmode", 'AUTO_NBR' );

	#   PD_ECUlogin();
	PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [$plantmode8_set] );

	S_teststep( "Do SW reset", 'AUTO_NBR' );
	PD_ECUreset();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Clear fault recorder", 'AUTO_NBR' );
	PD_ClearFaultMemory();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Check if plantmode is activated", 'AUTO_NBR', 'mode_active' );

	#    PD_ECUlogin();
	$data_aref2 = PD_ReadMemoryByName('rb_sycg_ActivePlantModes_au8(0)');
	$data_href2 = PD_ReadLampStates();

	S_teststep( "Check if no faults are qualified", 'AUTO_NBR', 'checkFaultPMActive' );
	$fltmem2     = PD_GetExtendedFaultInformation();
	$fault2count = scalar( @{ $fltmem2->{"fltnum"} } );

	return 1;
}

sub TC_evaluation {

	my ( $lampStatus1, $lampStatus2 );

	S_teststep_expected( "Plant mode 8 == 0", 'mode_inactive' );
	S_teststep_detected( "Plant mode 8 is $$data_aref1[0]", 'mode_inactive' );
	EVAL_evaluate_value( "Plant mode 8 inactive", $$data_aref1[0], '==', 0 );

	S_teststep_expected( "WL == Off" . "\n", 'mode_inactive' );
	S_teststep_detected( "WL is $data_href1->{'System Warning Lamp'}" . "\n", 'mode_inactive' );
	if    ( $data_href1->{'System Warning Lamp'} =~ /.*off/i ) { $lampStatus1 = 'Off'; }
	elsif ( $data_href1->{'System Warning Lamp'} =~ /.*on/i )  { $lampStatus1 = 'On'; }
	else                                                       { $lampStatus1 = 'Error'; }
	EVAL_evaluate_string( "WL inactive", 'Off', $lampStatus1 );

	S_teststep_expected( "faults > 0", 'checkFaultPMInactive' );
	S_teststep_detected( "found $fault1count faults", 'checkFaultPMInactive' );
	EVAL_evaluate_value( "qualified faults", $fault1count, '>', 0 );

	S_teststep_expected( 'Expected faults:', 'checkFaultPMInactive' );
	foreach my $fault (@$tcpar_FLTmandPMInactive) {
		S_teststep_expected($fault);
	}
	S_teststep_expected("\n");
	S_teststep_detected( 'Detected faults:', 'checkFaultPMInactive' );
	foreach my $fault ( @{ $fltmem1->{fault_text} } ) {
		S_teststep_detected($fault);
	}
	S_teststep_detected("\n");
	PD_evaluate_faults( $fltmem1, $tcpar_FLTmandPMInactive, $tcpar_FLToptPMInactive );

	S_teststep_expected( "Plant mode 8 == $plantmode8_set", 'mode_active' );
	S_teststep_detected( "Plant mode 8 is $$data_aref2[0]", 'mode_active' );
	EVAL_evaluate_value( "Plant mode 8 active", $$data_aref2[0], '==', $plantmode8_set );

	S_teststep_expected( "WL == On" . "\n", 'mode_active' );
	S_teststep_detected( "WL is $data_href2->{'System Warning Lamp'}" . "\n", 'mode_active' );
	if    ( $data_href2->{'System Warning Lamp'} =~ /.*off/i ) { $lampStatus2 = 'Off'; }
	elsif ( $data_href2->{'System Warning Lamp'} =~ /.*on/i )  { $lampStatus2 = 'On'; }
	else                                                       { $lampStatus2 = 'Error'; }
	EVAL_evaluate_string( "WL active", 'On', $lampStatus2 );

	S_teststep_expected( "faults = 0", 'checkFaultPMActive' );
	S_teststep_detected( "found $fault2count faults", 'checkFaultPMActive' );
	EVAL_evaluate_value( "qualified faults", $fault2count, '==', 0 );

	S_teststep_expected( 'Expected faults:', 'checkFaultPMActive' );
	foreach my $fault (@$tcpar_FLTmandPMActive) {
		S_teststep_expected($fault);
	}
	S_teststep_expected("\n");
	S_teststep_detected( 'Detected faults:', 'checkFaultPMActive' );
	foreach my $fault ( @{ $fltmem2->{fault_text} } ) {
		S_teststep_detected($fault);
	}
	S_teststep_detected("\n");
	PD_evaluate_faults( $fltmem2, $tcpar_FLTmandPMActive, $tcpar_FLToptPMActive );
	return 1;
}

sub TC_finalization {

	S_teststep( "Set battery voltage to default value", 'AUTO_NBR' );
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Deactivate plantmode", 'AUTO_NBR' );

	#    PD_ECUlogin();
	PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [$plantmode_clear] );
	PD_ECUreset();
	S_wait_ms('TIMER_ECU_READY');

	my $data_aref = PD_ReadMemoryByName('rb_sycg_ActivePlantModes_au8(0)');
	EVAL_evaluate_value( "Plant mode inactive", $$data_aref[0], '==', $plantmode_clear );
	LC_ECU_Off();

	S_teststep( "Load default QuaTe configuration", 'AUTO_NBR' );
	QuaTe_configure();    # load default config
	S_wait_ms(2000);

	S_teststep_detected("TEMP: $temperatures[0]");
	S_teststep_detected("UBat: $tcpar_Ubat_V V");

	return 1;
}

1;
