# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_PLANT_WalaOn;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Plant
#TS version in DOORS: 1.x
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use FuncLib_TNT_GEN;
use LIFT_can_access;

##################################

our $PURPOSE = "test that the warning lamp is switched on if one or more plant modes are activated";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PLANT_WalaOn

=head1 PURPOSE

check that warning lamp is switched on for activated PlantMode_1

=head1 TESTCASE DESCRIPTION

This script is based on 

I<B<Initialisation>>

PROD_Standard_Preparation


Set <TestCondition>


I<B<Stimulation and Measurement>>



I<B<Evaluation>>






I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES



=head2 PARAMETER EXAMPLES


=cut

#PARAMETERS
################ Parameters from .par file ###################
my ( $tcpar_Ubat_V, $tcpar_WalaType, $tcpar_WalaName, $tcpar_WalaOnValue, $tcpar_WalaOffValue );
my ( @tcpar_PlantMode, @tcpar_FLTmand, @tcpar_FLTopt );
my ( $fltmem1, $fltmem4 );

################ global parameter declaration ###################
#add any global variables here
my @temperatures;
my $plantmode_set0  = 0b00000000;
my $plantmode_set1  = 0b00000000;
my $plantmode_set2  = 0b00000000;
my $plantmode_clear = 0b00000000;
my ( $data_aref1, $data_aref2, $data_aref3, $data_aref4, $data_aref5, $data_aref6 );
my ( $data_href1, $data_href4 );
my ( $WalaOn, $WalaOff, $unit );
my ( $data_HoH1, $data_HoH4 );
my $TRC_Trace_storename;

###############################################################

sub TC_set_parameters {

	$tcpar_Ubat_V       = S_read_mandatory_testcase_parameter('Ubat');
	$tcpar_WalaType     = S_read_mandatory_testcase_parameter('WalaType');
	$tcpar_WalaName     = S_read_mandatory_testcase_parameter('Name');
	$tcpar_WalaOnValue  = S_read_mandatory_testcase_parameter('WalaOnValue');
	$tcpar_WalaOffValue = S_read_mandatory_testcase_parameter('WalaOffValue');

	# @tcpar_PlantMode    = S_read_mandatory_testcase_parameter('PlantMode');
	@tcpar_PlantMode = GEN_Read_mandatory_testcase_parameter('PlantMode');

	# @tcpar_FLTmand      = S_read_mandatory_testcase_parameter('FLTmand');
	# @tcpar_FLTopt       = S_read_mandatory_testcase_parameter('FLTopt');
	@tcpar_FLTmand = GEN_Read_mandatory_testcase_parameter('FLTmand');
	@tcpar_FLTopt  = GEN_Read_mandatory_testcase_parameter('FLTopt');

	return 1;
}

sub TC_initialization {

	S_teststep( "Standard Prep No fault", 'AUTO_NBR' );
	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	#	PD_ECUlogin();
	PD_ClearFaultMemory();
	S_wait_ms('TIMER_ECU_READY');

	PD_GetExtendedFaultInformation();

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	push( @temperatures, TEMP_get_temperature() );

	if ( $tcpar_WalaType eq 'HW' ) {
		S_teststep( "Prepare TRC measurement for HW warning lamp", 'AUTO_NBR' );

		# set TRC and scanner and measure
		LC_SetTRCscanner( ['UBAT1'],         { 'SignalMode' => 'differential', 'VoltageRange' => 20 } );
		LC_SetTRCscanner( [$tcpar_WalaName], { 'SignalMode' => 'differential', 'VoltageRange' => 20 } );
		LC_ConfigureTRCchannels(
			{
				'SamplingFrequency' => 125 * 1000,
				'MemorySize'        => 512 * 1024,
				'TriggerDelay'      => -1
			}
		);
	}

	return 1;
}

sub TC_stimulation_and_measurement {
	S_teststep( "Switch ECU on with Ubat = $tcpar_Ubat_V V", 'AUTO_NBR' );
	LC_ECU_On($tcpar_Ubat_V);
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Check that no plantmode is activated and warning lamp is off", 'AUTO_NBR', 'mode_inactive' );

	S_teststep_2nd_level( "Read all 3 active plant mode labels", 'AUTO_NBR' );
	$data_aref1 = PD_ReadMemoryByName('rb_sycg_ActivePlantModes_au8(0)');
	$data_aref2 = PD_ReadMemoryByName('rb_sycg_ActivePlantModes_au8(1)');
	$data_aref3 = PD_ReadMemoryByName('rb_sycg_ActivePlantModes_au8(2)');

	S_teststep_2nd_level( "Read warning lamp status", 'AUTO_NBR' );
	$data_href1 = PD_ReadLampStates();

	if ( $tcpar_WalaType eq 'HW' ) {
		S_teststep_2nd_level( "Measure HW warning lamp", 'AUTO_NBR' );
		S_teststep_2nd_level( 'Set transient recorder.', 'AUTO_NBR' );
		LC_MeasureTraceAnalogStart();
		S_wait_ms(2000);

		S_teststep_2nd_level( 'Send SW trigger for transient recorder.', 'AUTO_NBR' );
		LC_MeasureTraceAnalogSendSWTrigger();
		S_teststep_2nd_level( 'Measure Signal.', 'AUTO_NBR' );
		S_wait_ms(7000);
		S_teststep_2nd_level( 'Stop transient recorder.', 'AUTO_NBR' );
		LC_MeasureTraceAnalogStop();

		S_teststep_2nd_level( 'Plot values of recording for Offline evaluation.', 'AUTO_NBR', 'lamp_1' );
		$TRC_Trace_storename = S_get_TC_number() . '_TRC_Trace_WL_PMNotActive_' . time() . '.txt.unv';

		LC_MeasureTraceAnalogPlotValues( "$main::REPORT_PATH/" . $TRC_Trace_storename, 20000 );
		S_w2rep( '<A HREF="./' . $TRC_Trace_storename . '" TYPE="text/unv">' . "Click to view TRC trace $TRC_Trace_storename" . '</A><br>' );

		# evaluate measured signal
		$data_HoH1 = EVAL_importUNV( "$main::REPORT_PATH/" . $TRC_Trace_storename );

	}
	elsif ( $tcpar_WalaType eq 'CAN' ) {
		S_teststep_2nd_level( "Capture CAN message", 'AUTO_NBR' );
		( $WalaOff, $unit ) = CA_read_can_signal( $tcpar_WalaName, 'phys' );

	}
	elsif ( $tcpar_WalaType eq 'FR' ) {
		S_teststep_2nd_level( "Capture FR message", 'AUTO_NBR' );
		( $WalaOff, $unit ) = FR_read_flxr_signal( $tcpar_WalaName, 'phys' );
	}
	else {
		S_teststep_2nd_level( "Selected warning lamp type is not supported", 'AUTO_NBR' );
	}

	$fltmem1 = PD_GetExtendedFaultInformation();

	S_teststep( "Activate plantmode(s)", 'AUTO_NBR' );

	#	PD_ECUlogin();

	foreach my $mode (@tcpar_PlantMode) {
		if ( $mode < 9 ) {
			S_teststep_2nd_level( "Plantmode '$mode' is activated", 'AUTO_NBR' );
			$plantmode_set0 = $plantmode_set0 + 2**( $mode - 1 );
		}
		elsif ( $mode < 17 ) {
			S_teststep_2nd_level( "Plantmode '$mode' is activated", 'AUTO_NBR' );
			$plantmode_set1 = $plantmode_set1 + 2**( $mode - 9 );
		}
		elsif ( $mode < 20 ) {
			S_teststep_2nd_level( "Plantmode '$mode' is activated", 'AUTO_NBR' );
			$plantmode_set2 = $plantmode_set2 + 2**( $mode - 17 );
		}
		else {
			S_teststep_2nd_level( "Plantmode '$mode' is not supported", 'AUTO_NBR' );
		}
	}
	PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [$plantmode_set0] );
	PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(1)', [$plantmode_set1] );
	PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(2)', [$plantmode_set2] );

	S_teststep( "Do SW reset", 'AUTO_NBR' );
	PD_ECUreset();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Check that plantmode is activated and warning lamp is on", 'AUTO_NBR', 'mode_active' );
	PD_ECUlogin();

	S_teststep_2nd_level( "Read all 3 active plant mode labels", 'AUTO_NBR' );
	$data_aref4 = PD_ReadMemoryByName('rb_sycg_ActivePlantModes_au8(0)');
	$data_aref5 = PD_ReadMemoryByName('rb_sycg_ActivePlantModes_au8(1)');
	$data_aref6 = PD_ReadMemoryByName('rb_sycg_ActivePlantModes_au8(2)');

	S_teststep_2nd_level( "Read warning lamp status", 'AUTO_NBR' );
	$data_href4 = PD_ReadLampStates();

	if ( $tcpar_WalaType eq 'HW' ) {
		S_teststep_2nd_level( "Measure HW warning lamp", 'AUTO_NBR' );
		S_teststep_2nd_level( 'Set transient recorder.', 'AUTO_NBR' );
		LC_MeasureTraceAnalogStart();
		S_wait_ms(2000);

		S_teststep_2nd_level( 'Send SW trigger for transient recorder.', 'AUTO_NBR' );
		LC_MeasureTraceAnalogSendSWTrigger();
		S_teststep_2nd_level( 'Measure Signal.', 'AUTO_NBR' );
		S_wait_ms(7000);
		S_teststep_2nd_level( 'Stop transient recorder.', 'AUTO_NBR' );
		LC_MeasureTraceAnalogStop();

		S_teststep_2nd_level( 'Plot values of recording for Offline evaluation.', 'AUTO_NBR', 'lamp_2' );
		$TRC_Trace_storename = S_get_TC_number() . '_TRC_Trace_WL_PMActive_' . time() . '.txt.unv';

		LC_MeasureTraceAnalogPlotValues( "$main::REPORT_PATH/" . $TRC_Trace_storename, 20000 );
		S_w2rep( '<A HREF="./' . $TRC_Trace_storename . '" TYPE="text/unv">' . "Click to view TRC trace $TRC_Trace_storename" . '</A><br>' );

		# evaluate measured signal
		$data_HoH4 = EVAL_importUNV( "$main::REPORT_PATH/" . $TRC_Trace_storename );

	}
	elsif ( $tcpar_WalaType eq 'CAN' ) {
		S_teststep_2nd_level( "Capture CAN message", 'AUTO_NBR' );
		( $WalaOn, $unit ) = CA_read_can_signal( $tcpar_WalaName, 'phys' );
	}
	elsif ( $tcpar_WalaType eq 'FR' ) {
		S_teststep_2nd_level( "Capture FR message", 'AUTO_NBR' );
		( $WalaOn, $unit ) = FR_read_flxr_signal( $tcpar_WalaName, 'phys' );
	}
	else {
		S_teststep_2nd_level( "Selected warning lamp type is not supported", 'AUTO_NBR' );
	}

	$fltmem4 = PD_GetExtendedFaultInformation();

	return 1;
}

sub TC_evaluation {

	my ( $lampStatus1, $lampStatus4 );

### Plant Mode not activ ###
	S_teststep_expected( "Plant mode label(x) == 0", 'mode_inactive' );

	S_teststep_detected( "Plant mode label(0) is $$data_aref1[0]", 'mode_inactive' );
	EVAL_evaluate_value( "Plant mode inactive", $$data_aref1[0], '==', 0 );

	S_teststep_detected( "Plant mode label(1) is $$data_aref2[0]", 'mode_inactive' );
	EVAL_evaluate_value( "Plant mode inactive", $$data_aref2[0], '==', 0 );

	S_teststep_detected( "Plant mode label(2) is $$data_aref3[0]", 'mode_inactive' );
	EVAL_evaluate_value( "Plant mode inactive", $$data_aref3[0], '==', 0 );

	S_teststep_expected( "WL (Label) == Off", 'mode_inactive' );
	S_teststep_detected( "WL (Label) is $data_href1->{'System Warning Lamp'}", 'mode_inactive' );
	if    ( $data_href1->{'System Warning Lamp'} =~ /.*off/i ) { $lampStatus1 = 'Off'; }
	elsif ( $data_href1->{'System Warning Lamp'} =~ /.*on/i )  { $lampStatus1 = 'On'; }
	else                                                       { $lampStatus1 = 'Error'; }
	EVAL_evaluate_string( "WL (Label) inactive", 'Off', $lampStatus1 );

	S_teststep_expected( "WL (measurement) is off", 'mode_inactive' );

	if ( $tcpar_WalaType eq 'HW' ) {

		#		S_set_verdict('VERDICT_FAIL');
		#		S_teststep_detected( "WL (measurement): FAIL --> manual evaluation of transient recorder trace needed", 'mode_inactive' );
		S_teststep_expected( "WL (measurement) < $tcpar_WalaOffValue V", 'mode_inactive' );
		EVAL_evaluate_value_over_time( $data_HoH1, $tcpar_WalaName, '<', $tcpar_WalaOffValue );
	}
	elsif ( $tcpar_WalaType eq 'CAN' or $tcpar_WalaType eq 'FR' ) {
		S_teststep_expected( "WL (measurement) == $tcpar_WalaOffValue", 'mode_inactive' );
		S_teststep_detected( "WL (measurement) is $WalaOff", 'mode_inactive' );
		EVAL_evaluate_value( "WL (measurement)", $tcpar_WalaOffValue, '==', $WalaOff );
	}

	S_teststep_expected( 'Expected faults:', 'mode_inactive' );
	foreach my $fault (@tcpar_FLTmand) {
		S_teststep_expected($fault);
	}

	S_teststep_detected( 'Detected faults:', 'mode_inactive' );
	foreach my $fault ( @{ $fltmem1->{fault_text} } ) {
		S_teststep_detected($fault);
	}
	PD_evaluate_faults( $fltmem1, \@tcpar_FLTmand, \@tcpar_FLTopt );

### Plant Mode activ ###
### adapt expected plant mode value if plant mode 13 is activared
	foreach my $mode (@tcpar_PlantMode) {
		if ( $mode == 13 ) {
			$mode           = 2;
			$plantmode_set0 = $plantmode_set0 + 2**( $mode - 1 );
			$mode           = 11;
			$plantmode_set1 = $plantmode_set1 + 2**( $mode - 9 );
		}
	}

	S_teststep_expected( "Plant mode label(0) == $plantmode_set0", 'mode_active' );
	S_teststep_detected( "Plant mode label(0) is $$data_aref4[0]", 'mode_active' );
	EVAL_evaluate_value( "Plant mode active", $$data_aref4[0], '==', $plantmode_set0 );

	S_teststep_expected( "Plant mode label(1) == $plantmode_set1", 'mode_active' );
	S_teststep_detected( "Plant mode label(1) is $$data_aref5[0]", 'mode_active' );
	EVAL_evaluate_value( "Plant mode active", $$data_aref5[0], '==', $plantmode_set1 );

	S_teststep_expected( "Plant mode label(2) == $plantmode_set2", 'mode_active' );
	S_teststep_detected( "Plant mode label(2) is $$data_aref6[0]", 'mode_active' );
	EVAL_evaluate_value( "Plant mode active", $$data_aref6[0], '==', $plantmode_set2 );

	S_teststep_expected( "WL (Label) == On", 'mode_active' );
	S_teststep_detected( "WL (Label) is $data_href4->{'System Warning Lamp'}", 'mode_active' );
	if    ( $data_href4->{'System Warning Lamp'} =~ /.*off/i ) { $lampStatus4 = 'Off'; }
	elsif ( $data_href4->{'System Warning Lamp'} =~ /.*on/i )  { $lampStatus4 = 'On'; }
	else                                                       { $lampStatus4 = 'Error'; }
	EVAL_evaluate_string( "WL (Label) active", 'On', $lampStatus4 );
	S_teststep_expected( "WL (measurement) is on", 'mode_active' );
	if ( $tcpar_WalaType eq 'HW' ) {

		#		S_set_verdict('VERDICT_FAIL');
		#		S_teststep_detected( "WL (measurement): FAIL --> manual evaluation of transient recorder trace needed", 'mode_active' );
		S_teststep_expected( "WL (measurement) > $tcpar_WalaOnValue V", 'mode_active' );
		EVAL_evaluate_value_over_time( $data_HoH4, $tcpar_WalaName, '>', $tcpar_WalaOnValue );
	}
	elsif ( $tcpar_WalaType eq 'CAN' or $tcpar_WalaType eq 'FR' ) {
		S_teststep_expected( "WL (measurement) == $tcpar_WalaOnValue", 'mode_active' );
		S_teststep_detected( "WL (measurement) is $WalaOn", 'mode_inactive' );
		EVAL_evaluate_value( "WL (measurement)", $tcpar_WalaOnValue, '==', $WalaOn );
	}

	#	S_teststep_expected( 'Expected faults:', 'mode_active' );
	#	foreach my $fault (@tcpar_FLTmand) {
	#		S_teststep_expected($fault);
	#	}
	#
	#	S_teststep_detected( 'Detected faults:', 'mode_active' );
	#	foreach my $fault ( @{ $fltmem4->{fault_text} } ) {
	#		S_teststep_detected($fault);
	#	}
	#	PD_evaluate_faults( $fltmem4, \@tcpar_FLTmand, \@tcpar_FLTopt );

	return 1;
}

sub TC_finalization {

	S_teststep( "Set battery voltage to default value", 'AUTO_NBR' );
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Deactivate plantmode", 'AUTO_NBR' );
	PD_ECUlogin();
	PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [$plantmode_clear] );
	PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(1)', [$plantmode_clear] );
	PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(2)', [$plantmode_clear] );
	PD_ECUreset();
	S_wait_ms('TIMER_ECU_READY');

	my $data_aref = PD_ReadMemoryByName('rb_sycg_ActivePlantModes_au8(0)');
	EVAL_evaluate_value( "Plant mode inactive", $$data_aref[0], '==', $plantmode_clear );
	$data_aref = PD_ReadMemoryByName('rb_sycg_ActivePlantModes_au8(1)');
	EVAL_evaluate_value( "Plant mode inactive", $$data_aref[0], '==', $plantmode_clear );
	$data_aref = PD_ReadMemoryByName('rb_sycg_ActivePlantModes_au8(2)');
	EVAL_evaluate_value( "Plant mode inactive", $$data_aref[0], '==', $plantmode_clear );

	PD_ClearFaultMemory();
	LC_ECU_Off();
	if ( $tcpar_WalaType eq 'HW' ) {
		LC_ResetTRCscanner();
	}

	S_teststep_detected("TEMP: $temperatures[0]");
	S_teststep_detected("UBat: $tcpar_Ubat_V V");

	return 1;
}

1;
