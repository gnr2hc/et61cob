# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_PLANT_PDCondition;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Plant
#TS version in DOORS: 1.x
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_can_access;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use FuncLib_TNT_GEN;

##################################

our $PURPOSE = "check that the specified production diagnosis services are working as expected in special conditions (vehicle speed and warning lamp behaviour)";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PLANT_PDCondition

=head1 PURPOSE

check that the specified production diagnosis services are working as expected in special conditions (vehicle speed and warning lamp behaviour)

=head1 TESTCASE DESCRIPTION

I<B<Initialisation>>

PROD_Standard_Preparation


Set <TestCondition>


I<B<Stimulation and Measurement>>



I<B<Evaluation>>






I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES



=head2 PARAMETER EXAMPLES


=cut

#PARAMETERS
################ Parameters from .par file ###################
my ( $tcpar_Ubat_V, $tcpar_diagRequest, $tcpar_CanSignal );

################ global parameter declaration ###################
#add any global variables here
my ( $sensorData1_href, $sensorData2_href, $sensorData3_href, $sensorData4_href );
my ( $requestStatus1,   $requestStatus2,   $requestStatus3,   $requestStatus4 );
my ( $data_href0,       $data_href4,       $data_href5,       $data_href6 );

my @temperatures;
my $plantmode1_set  = 0b00000001;
my $plantmode_clear = 0b00000000;
my $waitTime_ms     = 5000;
###############################################################

sub TC_set_parameters {

	$tcpar_Ubat_V      = S_read_mandatory_testcase_parameter('Ubat');
	$tcpar_diagRequest = S_read_mandatory_testcase_parameter('DiagnosisRequest');
	$tcpar_CanSignal   = S_read_mandatory_testcase_parameter('CANSignal');

	return 1;
}

sub TC_initialization {
	S_teststep( "Standard Prep No fault", 'AUTO_NBR' );
	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');
	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	push( @temperatures, TEMP_get_temperature() );

	return 1;
}

sub TC_stimulation_and_measurement {
	my ( $SMI7sensorConfig_href, $SMI8sensorConfig_href, $address );

	$SMI7sensorConfig_href = {
		'sensor_type'    => 'SMI7',
		'Sensor1_Rate'   => 'LF_raw',
		'Sensor1_ACC1'   => 'LF_raw',
		'Sensor1_ACC2'   => 'LF_raw',
		'Sensor2_Rate'   => 'LF_raw',
		'Sensor2_ACC1'   => 'LF_raw',
		'Sensor2_ACC2'   => 'LF_raw',
		'Sensor3_Rate'   => 'LF_raw',
		'Sensor3_ACC1'   => 'LF_raw',
		'Sensor3_ACC2'   => 'LF_raw',
		'Sensor4_Rate'   => 'LF_raw',
		'Sensor4_ACC1'   => 'LF_raw',
		'Sensor4_ACC2'   => 'LF_raw',
		'amount_samples' => 100,
	};
	$SMI8sensorConfig_href = {
		'sensor_type'          => 'SMI8',
		'AccZ_redundant_low_g' => 'processed',
		'AccX_mid_g'           => 'processed',
		'AccY_high_g'          => 'processed',
		'Rate_wX'              => 'processed',
		'amount_samples'       => 100,
	};

	S_teststep( "Switch ECU on with Ubat = $tcpar_Ubat_V V", 'AUTO_NBR' );
	LC_ECU_On($tcpar_Ubat_V);
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Check if warning lamp is off", 'AUTO_NBR', 'WalaOff_1' );
	$data_href0 = PRD_Get_ECU_Properties( { 'Property_names' => ['Lamp_status'] } );

	S_teststep( "Set Power On Counter = 2", 'AUTO_NBR' );
	PRD_Write_Memory( 'rb_tim_EcuOnTimeDataEe_st.POnCounter_u32', [ 0, 0, 0, 2 ] );

	S_teststep( "Set vehicle speed to 2kmh", 'AUTO_NBR' );
	CA_write_can_signal( $tcpar_CanSignal, 2 );

	S_teststep( "Do SW reset", 'AUTO_NBR' );
	PRD_ECU_Reset();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Send diagnosis request '$tcpar_diagRequest'", 'AUTO_NBR', 'DiagRequest1' );
	if ( $tcpar_diagRequest eq 'SMI7Verification' ) {
		$sensorData1_href = PRD_Sensor_Verification_NOERROR($SMI7sensorConfig_href);
		$requestStatus1   = $sensorData1_href->{response_href}->{'Status'};
		if    ( $requestStatus1 eq "" ) { $requestStatus1 = -1; }
		elsif ( $requestStatus1 == 0 )  { $requestStatus1 = 1; }
		else                            { $requestStatus1 = -1; }
	}
	elsif ( $tcpar_diagRequest eq 'SMI8Verification' ) {
		$sensorData1_href = PRD_Sensor_Verification_NOERROR($SMI8sensorConfig_href);
		$requestStatus1   = $sensorData1_href->{response_href}->{'Status'};
		if    ( $requestStatus1 eq "" ) { $requestStatus1 = -1; }
		elsif ( $requestStatus1 == 0 )  { $requestStatus1 = 1; }
		else                            { $requestStatus1 = -1; }
	}
	elsif ( $tcpar_diagRequest eq 'SWReset' ) {
		$requestStatus1 = PRD_ECU_Reset_NOERROR();    #succes = 1 ansonsten undef
		if ( $requestStatus1 != 1 ) { $requestStatus1 = -1; }
	}
	elsif ( $tcpar_diagRequest eq 'WriteByAddress' ) {
		my $mapping_info = PRD_Get_Symbol_Mapping( { 'symbol_name' => 'rb_tim_EcuOnTimeDataEe_st.POnCounter_u32' } );
		$address = $mapping_info->{'address'};
		$requestStatus1 = PRD_Write_Memory_NOERROR( 'rb_tim_EcuOnTimeDataEe_st.POnCounter_u32', [ 0, 0, 0, 2 ] );
		if ( $requestStatus1 != 1 ) { $requestStatus1 = -1; }
	}
	else {
		S_set_verdict('VERDICT_NONE');
		S_w2rep( "given diagnosis request '$tcpar_diagRequest' is not supported by test case \n", 'blue' );
	}
	S_wait_ms($waitTime_ms);

	S_teststep( "Set vehicle speed to 10kmh", 'AUTO_NBR' );
	CA_write_can_signal( $tcpar_CanSignal, 10 );
	S_wait_ms(3000);

	S_teststep( "Send diagnosis request '$tcpar_diagRequest'", 'AUTO_NBR', 'DiagRequest2' );
	if ( $tcpar_diagRequest eq 'SMI7Verification' ) {
		$sensorData2_href = PRD_Sensor_Verification_NOERROR($SMI7sensorConfig_href);
		$requestStatus2   = $sensorData2_href->{response_href}->{'Status'};
		if    ( $requestStatus2 eq "" ) { $requestStatus2 = -1; }
		elsif ( $requestStatus2 == 0 )  { $requestStatus2 = 1; }
		else                            { $requestStatus2 = -1; }
	}
	elsif ( $tcpar_diagRequest eq 'SMI8Verification' ) {
		$sensorData2_href = PRD_Sensor_Verification_NOERROR($SMI8sensorConfig_href);
		$requestStatus2   = $sensorData2_href->{response_href}->{'Status'};
		if    ( $requestStatus2 eq "" ) { $requestStatus2 = -1; }
		elsif ( $requestStatus2 == 0 )  { $requestStatus2 = 1; }
		else                            { $requestStatus2 = -1; }
	}
	elsif ( $tcpar_diagRequest eq 'SWReset' ) {
		$requestStatus2 = PRD_ECU_Reset_NOERROR();    #succes = 1 ansonsten undef
		if ( $requestStatus2 != 1 ) { $requestStatus2 = -1; }
	}
	elsif ( $tcpar_diagRequest eq 'WriteByAddress' ) {
		my $mapping_info = PRD_Get_Symbol_Mapping( { 'symbol_name' => 'rb_tim_EcuOnTimeDataEe_st.POnCounter_u32' } );
		$address = $mapping_info->{'address'};
		$requestStatus2 = PRD_Write_Memory_NOERROR( 'rb_tim_EcuOnTimeDataEe_st.POnCounter_u32', [ 0, 0, 0, 2 ] );
		if ( $requestStatus2 != 1 ) { $requestStatus2 = -1; }
	}
	else {
		S_set_verdict('VERDICT_NONE');
		S_w2rep( "given diagnosis request '$tcpar_diagRequest' is not supported by test case \n", 'blue' );
	}
	S_wait_ms($waitTime_ms);

	S_teststep( "Send no vehicle speed message, stop bus simulation", 'AUTO_NBR' );
	CA_simulation_stop();

	S_teststep( "Send diagnosis request '$tcpar_diagRequest'", 'AUTO_NBR', 'DiagRequest3' );
	if ( $tcpar_diagRequest eq 'SMI7Verification' ) {
		$sensorData3_href = PRD_Sensor_Verification_NOERROR($SMI7sensorConfig_href);
		$requestStatus3   = $sensorData3_href->{response_href}->{'Status'};
		if    ( $requestStatus3 eq "" ) { $requestStatus3 = -1; }
		elsif ( $requestStatus3 == 0 )  { $requestStatus3 = 1; }
		else                            { $requestStatus3 = -1; }
	}
	elsif ( $tcpar_diagRequest eq 'SMI8Verification' ) {
		$sensorData3_href = PRD_Sensor_Verification_NOERROR($SMI8sensorConfig_href);
		$requestStatus3   = $sensorData3_href->{response_href}->{'Status'};
		if    ( $requestStatus3 eq "" ) { $requestStatus3 = -1; }
		elsif ( $requestStatus3 == 0 )  { $requestStatus3 = 1; }
		else                            { $requestStatus3 = -1; }
	}
	elsif ( $tcpar_diagRequest eq 'SWReset' ) {
		$requestStatus3 = PRD_ECU_Reset_NOERROR();    #succes = 1 ansonsten undef
		if ( $requestStatus3 != 1 ) { $requestStatus3 = -1; }
	}
	elsif ( $tcpar_diagRequest eq 'WriteByAddress' ) {
		my $mapping_info = PRD_Get_Symbol_Mapping( { 'symbol_name' => 'rb_tim_EcuOnTimeDataEe_st.POnCounter_u32' } );
		$address = $mapping_info->{'address'};
		$requestStatus3 = PRD_Write_Memory_NOERROR( 'rb_tim_EcuOnTimeDataEe_st.POnCounter_u32', [ 0, 0, 0, 2 ] );
		if ( $requestStatus3 != 1 ) { $requestStatus3 = -1; }
	}
	else {
		S_set_verdict('VERDICT_NONE');
		S_w2rep( "given diagnosis request '$tcpar_diagRequest' is not supported by test case \n", 'blue' );
	}
	S_wait_ms($waitTime_ms);

	S_teststep( "Set Power On Counter = 5", 'AUTO_NBR' );
	PRD_Write_Memory( 'rb_tim_EcuOnTimeDataEe_st.POnCounter_u32', [ 0, 0, 0, 5 ] );

	S_teststep( "Restart simulation", 'AUTO_NBR' );
	CA_simulation_start();
	CA_write_can_signal( $tcpar_CanSignal, 2 );

	PRD_Clear_Fault_Memory();
	S_wait_ms(100);

	S_teststep( "Reset ECU", 'AUTO_NBR' );
	LC_ECU_Reset();

	S_teststep( "Check if warning lamp is off", 'AUTO_NBR', 'WalaOff_2' );
	$data_href4 = PRD_Get_ECU_Properties( { 'Property_names' => ['Lamp_status'] } );

	S_teststep( "Send diagnosis request '$tcpar_diagRequest'", 'AUTO_NBR', 'DiagRequest4' );
	if ( $tcpar_diagRequest eq 'SMI7Verification' ) {
		$sensorData4_href = PRD_Sensor_Verification_NOERROR($SMI7sensorConfig_href);
		$requestStatus4   = $sensorData4_href->{response_href}->{'Status'};
		if    ( $requestStatus4 eq "" ) { $requestStatus4 = -1; }
		elsif ( $requestStatus4 == 0 )  { $requestStatus4 = 1; }
		else                            { $requestStatus4 = -1; }
	}
	elsif ( $tcpar_diagRequest eq 'SMI8Verification' ) {
		$sensorData4_href = PRD_Sensor_Verification_NOERROR($SMI8sensorConfig_href);
		$requestStatus4   = $sensorData4_href->{response_href}->{'Status'};
		if    ( $requestStatus4 eq "" ) { $requestStatus4 = -1; }
		elsif ( $requestStatus4 == 0 )  { $requestStatus4 = 1; }
		else                            { $requestStatus4 = -1; }
	}
	elsif ( $tcpar_diagRequest eq 'SWReset' ) {
		$requestStatus4 = PRD_ECU_Reset_NOERROR();    #succes = 1 ansonsten undef
		if ( $requestStatus4 != 1 ) { $requestStatus4 = -1; }
	}
	elsif ( $tcpar_diagRequest eq 'WriteByAddress' ) {
		my $mapping_info = PRD_Get_Symbol_Mapping( { 'symbol_name' => 'rb_tim_EcuOnTimeDataEe_st.POnCounter_u32' } );
		$address = $mapping_info->{'address'};
		$requestStatus4 = PRD_Write_Memory_NOERROR( 'rb_tim_EcuOnTimeDataEe_st.POnCounter_u32', [ 0, 0, 0, 7 ] );
		if ( $requestStatus4 != 1 ) { $requestStatus4 = -1; }
	}
	else {
		S_set_verdict('VERDICT_NONE');
		S_w2rep( "given diagnosis request '$tcpar_diagRequest' is not supported by test case \n", 'blue' );
	}
	S_wait_ms($waitTime_ms);

	S_teststep( "Check if warning lamp is on", 'AUTO_NBR', 'WalaOn_4' );
	$data_href5 = PRD_Get_ECU_Properties( { 'Property_names' => ['Lamp_status'] } );

	S_teststep( "Reset ECU", 'AUTO_NBR' );
	LC_ECU_Reset();

	S_teststep( "Check if warning lamp is off", 'AUTO_NBR', 'WalaOff_3' );
	$data_href6 = PRD_Get_ECU_Properties( { 'Property_names' => ['Lamp_status'] } );

	return 1;
}

sub TC_evaluation {

	my ( $lampStatus1, $lampStatus2, $lampStatus3, $lampStatus4 );

	if ( $tcpar_diagRequest eq 'SWReset' ) {
		S_teststep_expected( "WL == Off" . "\n", 'WalaOff_1' );
		S_teststep_detected( "WL is $data_href0->{'Lamp_status'}->{'SystemWarningLamp'}" . "\n", 'WalaOff_1' );
		if    ( $data_href0->{'Lamp_status'}->{'SystemWarningLamp'} =~ /.*off/i ) { $lampStatus1 = 'Off'; }
		elsif ( $data_href0->{'Lamp_status'}->{'SystemWarningLamp'} =~ /.*on/i )  { $lampStatus1 = 'On'; }
		else                                                                      { $lampStatus1 = 'Error'; }
		EVAL_evaluate_string( "WL inactive", 'Off', $lampStatus1 );

		S_teststep_expected( "Diagnosis request is successful (1)", 'DiagRequest1' );
		S_teststep_detected( "Diagnosis request is $requestStatus1", 'DiagRequest1' );
		EVAL_evaluate_value( "Diagnosis request status", 1, '==', $requestStatus1 );

		S_teststep_expected( "Diagnosis request is successful (1)", 'DiagRequest2' );
		S_teststep_detected( "Diagnosis request is $requestStatus2", 'DiagRequest2' );
		EVAL_evaluate_value( "Diagnosis request status", 1, '==', $requestStatus2 );

		S_teststep_expected( "Diagnosis request is successful (1)", 'DiagRequest3' );
		S_teststep_detected( "Diagnosis request is $requestStatus3", 'DiagRequest3' );
		EVAL_evaluate_value( "Diagnosis request status", 1, '==', $requestStatus3 );

		S_teststep_expected( "WL == Off" . "\n", 'WalaOff_2' );
		S_teststep_detected( "WL is $data_href4->{'Lamp_status'}->{'SystemWarningLamp'}" . "\n", 'WalaOff_2' );
		if    ( $data_href4->{'Lamp_status'}->{'SystemWarningLamp'} =~ /.*off/i ) { $lampStatus2 = 'Off'; }
		elsif ( $data_href4->{'Lamp_status'}->{'SystemWarningLamp'} =~ /.*on/i )  { $lampStatus2 = 'On'; }
		else                                                                      { $lampStatus2 = 'Error'; }
		EVAL_evaluate_string( "WL inactive", 'Off', $lampStatus2 );

		S_teststep_expected( "Diagnosis request is successful (1)", 'DiagRequest4' );
		S_teststep_detected( "Diagnosis request is $requestStatus4", 'DiagRequest4' );
		EVAL_evaluate_value( "Diagnosis request status", 1, '==', $requestStatus4 );

		S_teststep_expected( "WL == Off" . "\n", 'WalaOn_4' );
		S_teststep_detected( "WL is $data_href5->{'Lamp_status'}->{'SystemWarningLamp'}" . "\n", 'WalaOn_4' );
		if    ( $data_href5->{'Lamp_status'}->{'SystemWarningLamp'} =~ /.*off/i ) { $lampStatus4 = 'Off'; }
		elsif ( $data_href5->{'Lamp_status'}->{'SystemWarningLamp'} =~ /.*on/i )  { $lampStatus4 = 'On'; }
		else                                                                      { $lampStatus4 = 'Error'; }
		EVAL_evaluate_string( "WL inactive", 'Off', $lampStatus4 );

		S_teststep_expected( "WL == Off" . "\n", 'WalaOff_3' );
		S_teststep_detected( "WL is $data_href6->{'Lamp_status'}->{'SystemWarningLamp'}" . "\n", 'WalaOff_3' );
		if    ( $data_href6->{'Lamp_status'}->{'SystemWarningLamp'} =~ /.*off/i ) { $lampStatus3 = 'Off'; }
		elsif ( $data_href6->{'Lamp_status'}->{'SystemWarningLamp'} =~ /.*on/i )  { $lampStatus3 = 'On'; }
		else                                                                      { $lampStatus3 = 'Error'; }
		EVAL_evaluate_string( "WL inactive", 'Off', $lampStatus3 );
	}
	else {
		S_teststep_expected( "WL == Off" . "\n", 'WalaOff_1' );
		S_teststep_detected( "WL is $data_href0->{'Lamp_status'}->{'SystemWarningLamp'}" . "\n", 'WalaOff_1' );
		if    ( $data_href0->{'Lamp_status'}->{'SystemWarningLamp'} =~ /.*off/i ) { $lampStatus1 = 'Off'; }
		elsif ( $data_href0->{'Lamp_status'}->{'SystemWarningLamp'} =~ /.*on/i )  { $lampStatus1 = 'On'; }
		else                                                                      { $lampStatus1 = 'Error'; }
		EVAL_evaluate_string( "WL inactive", 'Off', $lampStatus1 );

		S_teststep_expected( "Diagnosis request is successful (1)", 'DiagRequest1' );
		S_teststep_detected( "Diagnosis request is $requestStatus1", 'DiagRequest1' );
		EVAL_evaluate_value( "Diagnosis request status", 1, '==', $requestStatus1 );

		S_teststep_expected( "Diagnosis request is unsuccessful (-1)", 'DiagRequest2' );
		S_teststep_detected( "Diagnosis request is $requestStatus2", 'DiagRequest2' );
		EVAL_evaluate_value( "Diagnosis request status", -1, '==', $requestStatus2 );

		S_teststep_expected( "Diagnosis request is successful (1)", 'DiagRequest3' );
		S_teststep_detected( "Diagnosis request is $requestStatus3", 'DiagRequest3' );
		EVAL_evaluate_value( "Diagnosis request status", 1, '==', $requestStatus3 );

		S_teststep_expected( "WL == Off" . "\n", 'WalaOff_2' );
		S_teststep_detected( "WL is $data_href4->{'Lamp_status'}->{'SystemWarningLamp'}" . "\n", 'WalaOff_2' );
		if    ( $data_href4->{'Lamp_status'}->{'SystemWarningLamp'} =~ /.*off/i ) { $lampStatus2 = 'Off'; }
		elsif ( $data_href4->{'Lamp_status'}->{'SystemWarningLamp'} =~ /.*on/i )  { $lampStatus2 = 'On'; }
		else                                                                      { $lampStatus2 = 'Error'; }
		EVAL_evaluate_string( "WL inactive", 'Off', $lampStatus2 );

		S_teststep_expected( "Diagnosis request is successful (1)", 'DiagRequest4' );
		S_teststep_detected( "Diagnosis request is $requestStatus4", 'DiagRequest4' );
		EVAL_evaluate_value( "Diagnosis request status", 1, '==', $requestStatus4 );

		S_teststep_expected( "WL == On" . "\n", 'WalaOn_4' );
		S_teststep_detected( "WL is $data_href5->{'Lamp_status'}->{'SystemWarningLamp'}" . "\n", 'WalaOn_4' );
		if    ( $data_href5->{'Lamp_status'}->{'SystemWarningLamp'} =~ /.*off/i ) { $lampStatus3 = 'Off'; }
		elsif ( $data_href5->{'Lamp_status'}->{'SystemWarningLamp'} =~ /.*on/i )  { $lampStatus3 = 'On'; }
		else                                                                      { $lampStatus3 = 'Error'; }
		EVAL_evaluate_string( "WL inactive", 'On', $lampStatus3 );

		S_teststep_expected( "WL == Off" . "\n", 'WalaOff_3' );
		S_teststep_detected( "WL is $data_href6->{'Lamp_status'}->{'SystemWarningLamp'}" . "\n", 'WalaOff_3' );
		if    ( $data_href6->{'Lamp_status'}->{'SystemWarningLamp'} =~ /.*off/i ) { $lampStatus4 = 'Off'; }
		elsif ( $data_href6->{'Lamp_status'}->{'SystemWarningLamp'} =~ /.*on/i )  { $lampStatus4 = 'On'; }
		else                                                                      { $lampStatus4 = 'Error'; }
		EVAL_evaluate_string( "WL inactive", 'Off', $lampStatus4 );
	}

	return 1;
}

sub TC_finalization {

	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	LC_ECU_Off();

	S_teststep_detected("TEMP: $temperatures[0]");
	S_teststep_detected("UBat: $tcpar_Ubat_V V");

	return 1;
}

1;
