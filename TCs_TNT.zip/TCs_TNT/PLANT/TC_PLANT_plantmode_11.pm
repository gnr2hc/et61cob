# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_PLANT_plantmode_11;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Plant
#TS version in DOORS: 1.x
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_TNT_GEN;

#use FuncLib_SYC_INTERFACE;
##################################

our $PURPOSE = "check plant mode 11: EMC capacitance test";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PLANT_plantmode_11

=head1 PURPOSE

check plant mode 11: EMC capacitance test 

=head1 TESTCASE DESCRIPTION

This script is based on 

I<B<Initialisation>>

PROD_Standard_Preparation


Set <TestCondition>


I<B<Stimulation and Measurement>>



I<B<Evaluation>>






I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES



=head2 PARAMETER EXAMPLES


=cut

#PARAMETERS
################ Parameters from .par file ###################
my ( $tcpar_FLTmandPMInactive, $tcpar_FLToptPMInactive, $tcpar_FLTmandPMActive, $tcpar_FLToptPMActive );
my ($tcpar_Ubat_V);

################ global parameter declaration ###################
#add any global variables here
my @temperatures;
my $plantmode11_set = 0b00000100;
my $plantmode_clear = 0b00000000;
my ( $data_aref1, $data_aref2 );
my ( $data_href1, $data_href2 );
my ( $fltmem1,    $fltmem2 );

###############################################################

sub TC_set_parameters {

	$tcpar_Ubat_V            = S_read_mandatory_testcase_parameter('Ubat');
	$tcpar_FLTmandPMInactive = S_read_mandatory_testcase_parameter('FLTmandPMInactive');
	$tcpar_FLToptPMInactive  = S_read_optional_testcase_parameter('FLToptPMInactive');
	$tcpar_FLTmandPMActive   = S_read_mandatory_testcase_parameter('FLTmandPMActive');
	$tcpar_FLToptPMActive    = S_read_optional_testcase_parameter('FLToptPMActive');

	return 1;
}

sub TC_initialization {

	S_teststep( "Standard Prep No fault", 'AUTO_NBR' );
	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	#	PD_ECUlogin();
	PD_ClearFaultMemory();
	S_wait_ms('TIMER_ECU_READY');

	PD_GetExtendedFaultInformation();

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	push( @temperatures, TEMP_get_temperature() );

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Switch ECU on with Ubat = $tcpar_Ubat_V V", 'AUTO_NBR' );
	LC_ECU_On($tcpar_Ubat_V);
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Check if plantmode is not yet activated", 'AUTO_NBR', 'mode_inactive' );
	$data_aref1 = PD_ReadMemoryByName('rb_sycg_ActivePlantModes_au8(1)');
	$data_href1 = PD_ReadLampStates();

	S_teststep( "Check if no faults qualified", 'AUTO_NBR', 'checkFaultPMInactive' );
	$fltmem1 = PD_GetExtendedFaultInformation();

	S_teststep( "Set plantmode", 'AUTO_NBR' );

	#	PD_ECUlogin();
	PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(1)', [$plantmode11_set] );

	S_teststep( "Do SW reset", 'AUTO_NBR' );
	PD_ECUreset();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Check if plantmode is activated", 'AUTO_NBR', 'mode_active' );

	#	PD_ECUlogin();
	$data_aref2 = PD_ReadMemoryByName('rb_sycg_ActivePlantModes_au8(1)');
	$data_href2 = PD_ReadLampStates();

	S_teststep( "Check if faults qualify due to activated plant mode and connected periphery", 'AUTO_NBR', 'checkFaultPMActive' );
	$fltmem2 = PD_GetExtendedFaultInformation();

	return 1;
}

sub TC_evaluation {

	my ( $lampStatus1, $lampStatus2 );

	S_teststep_expected( "Plant mode 11 == 0", 'mode_inactive' );
	S_teststep_detected( "Plant mode 11 is $$data_aref1[0]", 'mode_inactive' );
	EVAL_evaluate_value( "Plant mode 11 inactive", $$data_aref1[0], '==', 0 );

	S_teststep_expected( "WL == Off" . "\n", 'mode_inactive' );
	S_teststep_detected( "WL is $data_href1->{'System Warning Lamp'}" . "\n", 'mode_inactive' );
	if    ( $data_href1->{'System Warning Lamp'} =~ /.*off/i ) { $lampStatus1 = 'Off'; }
	elsif ( $data_href1->{'System Warning Lamp'} =~ /.*on/i )  { $lampStatus1 = 'On'; }
	else                                                       { $lampStatus1 = 'Error'; }
	EVAL_evaluate_string( "WL inactive", 'Off', $lampStatus1 );

	S_teststep_expected( 'Expected faults:', 'checkFaultPMInactive' );
	foreach my $fault (@$tcpar_FLTmandPMInactive) {
		S_teststep_expected($fault);
	}
	S_teststep_expected("\n");
	S_teststep_detected( 'Detected faults:', 'checkFaultPMInactive' );
	foreach my $fault ( @{ $fltmem1->{fault_text} } ) {
		S_teststep_detected($fault);
	}
	S_teststep_detected("\n");
	PD_evaluate_faults( $fltmem1, $tcpar_FLTmandPMInactive, $tcpar_FLToptPMInactive );

	S_teststep_expected( "Plant mode 11 == $plantmode11_set", 'mode_active' );
	S_teststep_detected( "Plant mode 11 is $$data_aref2[0]", 'mode_active' );
	EVAL_evaluate_value( "Plant mode 11 active", $$data_aref2[0], '==', $plantmode11_set );

	S_teststep_expected( "WL == On" . "\n", 'mode_active' );
	S_teststep_detected( "WL is $data_href2->{'System Warning Lamp'}" . "\n", 'mode_active' );
	if    ( $data_href2->{'System Warning Lamp'} =~ /.*off/i ) { $lampStatus2 = 'Off'; }
	elsif ( $data_href2->{'System Warning Lamp'} =~ /.*on/i )  { $lampStatus2 = 'On'; }
	else                                                       { $lampStatus2 = 'Error'; }
	EVAL_evaluate_string( "WL active", 'On', $lampStatus2 );

	S_teststep_expected( 'Expected faults:', 'checkFaultPMActive' );
	foreach my $fault (@$tcpar_FLTmandPMActive) {
		S_teststep_expected($fault);
	}
	S_teststep_expected("\n");
	S_teststep_detected( 'Detected faults:', 'checkFaultPMActive' );
	foreach my $fault ( @{ $fltmem2->{fault_text} } ) {
		S_teststep_detected($fault);
	}
	S_teststep_detected("\n");
	PD_evaluate_faults( $fltmem2, $tcpar_FLTmandPMActive, $tcpar_FLToptPMActive );

	return 1;
}

sub TC_finalization {

	S_teststep( "Set battery voltage to default value", 'AUTO_NBR' );
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Deactivate plantmode", 'AUTO_NBR' );

	#	PD_ECUlogin();
	PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(1)', [$plantmode_clear] );
	PD_ECUreset();
	S_wait_ms('TIMER_ECU_READY');

	my $data_aref = PD_ReadMemoryByName('rb_sycg_ActivePlantModes_au8(1)');
	EVAL_evaluate_value( "Plant mode inactive", $$data_aref[0], '==', $plantmode_clear );
	LC_ECU_Off();

	S_teststep_detected("TEMP: $temperatures[0]");
	S_teststep_detected("UBat: $tcpar_Ubat_V V");

	return 1;
}

1;
