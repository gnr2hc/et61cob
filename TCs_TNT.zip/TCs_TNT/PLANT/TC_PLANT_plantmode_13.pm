# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_PLANT_plantmode_13;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Plant
#TS version in DOORS:
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use LIFT_TEMPERATURE;
use LIFT_can_access;
use LIFT_evaluation;
use LIFT_QuaTe;
use FuncLib_TNT_GEN;

##################################

our $PURPOSE = "check plant mode 13: automatic detection 'ECU is in panel' behaviour";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PLANT_plantmode_13

=head1 PURPOSE

check plant mode 13: automatic detection 'ECU is in panel' behaviour 

=head1 TESTCASE DESCRIPTION

This script is based on 

I<B<Initialisation>>

PROD_Standard_Preparation


Set <TestCondition>


I<B<Stimulation and Measurement>>

    AIN1_5_9  will be set to 100 Ohm
    AIN2_6_10 will be set to Hall low (3 mA)
    AIN3_7_11 will be set to 400 Ohm
    AIN4_8_12 will be set to Hall high (14mA)

I<B<Evaluation>>






I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES



=head2 PARAMETER EXAMPLES

	[TC_PLANT_plantmode_13.RefType3]
	purpose     = 'AutomaticPlantModeDetection RefType3'
	AIN1_5_9    = @( 'BLRP',  'SPSFD', 'BLRD' )
	AIN2_6_10   = @( 'PADS1', 'OPSFP', 'BLFP' )
	AIN3_7_11   = @( 'BLRC',  'BLFD' )
	AIN4_8_12   = @( 'PADS2', 'BLR2D' )
	
	[TC_PLANT_plantmode_13.DevBoard]
	purpose     = 'AutomaticPlantModeDetection DevBoard'
	AIN1_5_9    = @( 'BLRP', 'BLFP', 'SPSFD' )
	AIN2_6_10   = @( 'PADS1', 'OPSFP', 'BLFD' )
	AIN3_7_11   = @( 'BLRC', 'BLR2D' )
	AIN4_8_12   = @( 'PADS2', 'BLRD' )

=cut

#PARAMETERS
################ Parameters from .par file ###################
my ( $tcpar_FLTmandPMInactive, $tcpar_FLToptPMInactive, $tcpar_FLTmandPMActive, $tcpar_FLToptPMActive );
my ( $tcpar_Ubat_V,            $tcpar_SingleECU,        $tcpar_ECUinPanel );
my ( $tcpar_AIN1_5_9,          $tcpar_AIN2_6_10,        $tcpar_AIN3_7_11,       $tcpar_AIN4_8_12 );

################ global parameter declaration ###################
my @deviceNames;
my @temperatures;
my $plantmode3_set   = 0b00000100;
my $plantmode13_set  = 0b00010000;
my $plantmode_clear  = 0b00000000;
my @itm_TestStarted  = ( 0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF );
my @itm_TestFinished = ( 0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF );
my @itm_TestFailed   = ( 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 );
my @itm_TestSkipped  = ( 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 );
my ($data_aref1);
my ($data_href1);
my ( $data_aref_panel1,      $data_aref_panel2,       $data_href_panel );
my ( $data_aref_ecu1,        $data_aref_ecu2,         $data_href_ecu );
my ( $fltmem1,               $fltmem2,                $fltmem3 );
my ( $data_aref_itm_started, $data_aref_itm_finished, $data_aref_itm_failed, $data_aref_itm_skipped );

###############################################################

sub TC_set_parameters {

	$tcpar_AIN1_5_9  = S_read_mandatory_testcase_parameter('AIN1_5_9');
	$tcpar_AIN2_6_10 = S_read_mandatory_testcase_parameter('AIN2_6_10');
	$tcpar_AIN3_7_11 = S_read_mandatory_testcase_parameter('AIN3_7_11');
	$tcpar_AIN4_8_12 = S_read_mandatory_testcase_parameter('AIN4_8_12');

	$tcpar_SingleECU  = S_read_mandatory_testcase_parameter('SingleECU');
	$tcpar_ECUinPanel = S_read_mandatory_testcase_parameter('ECUinPanel');

	$tcpar_Ubat_V            = S_read_mandatory_testcase_parameter('Ubat');
	$tcpar_FLTmandPMInactive = S_read_optional_testcase_parameter('FLTmandPMInactive');
	$tcpar_FLToptPMInactive  = S_read_optional_testcase_parameter('FLToptPMInactive');
	$tcpar_FLTmandPMActive   = S_read_optional_testcase_parameter('FLTmandPMActive');
	$tcpar_FLToptPMActive    = S_read_optional_testcase_parameter('FLToptPMActive');

	S_set_error( "'QUATE_plant' configuration not found in Project Defaults", 114 ) unless ( defined $main::ProjectDefaults->{'QUATE_plant'} );
	S_set_error( "'U_BATT_DEFAULT' not found in Project Defaults 'VEHICLE'",  114 ) unless ( defined $main::ProjectDefaults->{'VEHICLE'}{'U_BATT_DEFAULT'} );
	S_set_error( "'TIMER_ECU_OFF' not found in Project Defaults 'TIMER'",     114 ) unless ( defined $main::ProjectDefaults->{'TIMER'}{'TIMER_ECU_OFF'} );
	S_set_error( "'TIMER_ECU_READY' not found in Project Defaults 'TIMER'",   114 ) unless ( defined $main::ProjectDefaults->{'TIMER'}{'TIMER_ECU_READY'} );

	return 1;
}

sub TC_initialization {

	S_teststep( "Standard Prep No fault", 'AUTO_NBR' );
	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	#	PD_ECUlogin();
	PD_ClearFaultMemory();
	S_wait_ms('TIMER_ECU_READY');

	PD_GetExtendedFaultInformation();

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	push( @temperatures, TEMP_get_temperature() );

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Switch ECU on with Ubat = $tcpar_Ubat_V V", 'AUTO_NBR' );
	LC_ECU_On($tcpar_Ubat_V);
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Check if plantmode is not yet activated", 'AUTO_NBR', 'mode_inactive' );
	$data_aref1 = PD_ReadMemoryByName('rb_sycg_ActivePlantModes_au8(1)');
	$data_href1 = PD_ReadLampStates();

	S_teststep( "Check if no faults qualified", 'AUTO_NBR', 'checkNoFaultPMInactive' );
	$fltmem1 = PD_GetExtendedFaultInformation();

	S_teststep( "Set plantmode", 'AUTO_NBR' );

	PD_ECUlogin();
	PD_ClearFaultMemory();
	S_wait_ms(1000);
	PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [$plantmode3_set] );
	PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(1)', [$plantmode13_set] );

	S_teststep( "ECU in panel", 'AUTO_NBR' );

	S_teststep_2nd_level( "Do HW reset", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep_2nd_level( "Load PAS config for plantmode 8", 'AUTO_NBR', );
	QuaTe_configure( $main::ProjectDefaults->{'QUATE_plant'} );
	S_wait_ms(2000);

	S_teststep_2nd_level( "Set AINs for plantmode 9", 'AUTO_NBR', );
	foreach my $ain (@$tcpar_AIN1_5_9) {
		LC_SetResistance( $ain, 100 );
	}
	foreach my $ain (@$tcpar_AIN2_6_10) {
		LC_SetCurrent( $ain, 3 );
	}
	foreach my $ain (@$tcpar_AIN3_7_11) {
		LC_SetResistance( $ain, 400 );
	}
	foreach my $ain (@$tcpar_AIN4_8_12) {
		LC_SetCurrent( $ain, 14 );
	}

	S_teststep_2nd_level( "Disconnect external devices for panel mode", 'AUTO_NBR', );
	@deviceNames = LC_Get_names('SQUIBS');
	push( @deviceNames, LC_Get_names('BELT_LOCKS') );
	push( @deviceNames, LC_Get_names('PAS_LINES') );
	push( @deviceNames, LC_Get_names('WARNING_LAMPS') );
	foreach my $device (@deviceNames) {
		LC_DisconnectLine($device);
	}
	S_wait_ms(500);

	S_teststep_2nd_level( "Stop CAN bus simulation", 'AUTO_NBR' );
	CA_simulation_stop();

	S_teststep_2nd_level( "Switch ECU on", 'AUTO_NBR' );
	LC_ECU_On($tcpar_Ubat_V);
	S_wait_ms('TIMER_ECU_READY');

	S_teststep_2nd_level( "Check if panel mode is activated", 'AUTO_NBR', 'mode_panel' );

	PD_ECUlogin();
	$data_aref_panel1 = PD_ReadMemoryByName('rb_sycg_ActivePlantModes_au8(0)');
	$data_aref_panel2 = PD_ReadMemoryByName('rb_sycg_ActivePlantModes_au8(1)');
	$data_href_panel  = PD_ReadLampStates();

	S_teststep_2nd_level( "Read fault recorder in panel mode active", 'AUTO_NBR', 'fault_mode_panel' );
	$fltmem2 = PD_GetExtendedFaultInformation();

	PD_ClearFaultMemory();
	S_wait_ms(1000);

	S_teststep( "single ECU", 'AUTO_NBR' );

	S_teststep_2nd_level( "do HW reset", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep_2nd_level( "Connect external devices for ECU mode", 'AUTO_NBR', );
	foreach my $device (@deviceNames) {
		LC_ConnectLine($device);
	}
	S_wait_ms(500);

	S_teststep_2nd_level( "Start CAN bus simulation", 'AUTO_NBR' );
	CA_simulation_start();

	S_teststep_2nd_level( "Switch ECU on", 'AUTO_NBR' );
	LC_ECU_On($tcpar_Ubat_V);

	S_teststep_2nd_level( "check if single mode is activated", 'AUTO_NBR', 'mode_single' );
	S_wait_ms(300);

	PD_ECUlogin();
	S_wait_ms('TIMER_ECU_READY');

	$data_aref_ecu1 = PD_ReadMemoryByName('rb_sycg_ActivePlantModes_au8(0)');
	$data_aref_ecu2 = PD_ReadMemoryByName('rb_sycg_ActivePlantModes_au8(1)');
	$data_href_ecu  = PD_ReadLampStates();

	$data_aref_itm_started  = PD_ReadMemoryByName('rb_itm_TestStarted_u64');
	$data_aref_itm_finished = PD_ReadMemoryByName('rb_itm_TestFinished_u64');
	$data_aref_itm_failed   = PD_ReadMemoryByName('rb_itm_TestFailed_u64');
	$data_aref_itm_skipped  = PD_ReadMemoryByName('rb_itm_TestSkipped_u64');

	S_teststep_2nd_level( "Read fault recorder in panel mode active", 'AUTO_NBR', 'fault_mode_single' );
	$fltmem3 = PD_GetExtendedFaultInformation();

	return 1;
}

sub TC_evaluation {

	my ( $lampStatus1, $lampStatus2, $lampStatus3 );

	### Plant mode not active ###
	S_teststep_expected( "Plant mode 13 == 0", 'mode_inactive' );
	S_teststep_detected( "Plant mode 13 is $$data_aref1[0]", 'mode_inactive' );
	EVAL_evaluate_value( "Plant mode 13 inactive", $$data_aref1[0], '==', 0 );

	S_teststep_expected( "WL == Off" . "\n", 'mode_inactive' );
	S_teststep_detected( "WL is $data_href1->{'System Warning Lamp'}" . "\n", 'mode_inactive' );
	if    ( $data_href1->{'System Warning Lamp'} =~ /.*off/i ) { $lampStatus1 = 'Off'; }
	elsif ( $data_href1->{'System Warning Lamp'} =~ /.*on/i )  { $lampStatus1 = 'On'; }
	else                                                       { $lampStatus1 = 'Error'; }
	EVAL_evaluate_string( "WL inactive", 'Off', $lampStatus1 );

	S_teststep_expected( 'Expected faults:', 'checkNoFaultPMInactive' );
	foreach my $fault (@$tcpar_FLTmandPMInactive) {
		S_teststep_expected($fault);
	}
	S_teststep_expected("\n");
	S_teststep_detected( 'Detected faults:', 'checkNoFaultPMInactive' );
	foreach my $fault ( @{ $fltmem1->{fault_text} } ) {
		S_teststep_detected($fault);
	}
	S_teststep_detected("\n");
	PD_evaluate_faults( $fltmem1, $tcpar_FLTmandPMInactive, $tcpar_FLToptPMInactive );

	### Plant mode active - ECU in panel ###
	S_teststep_expected( "plantmode[0] == 00xxx11x", 'mode_panel' );
	S_teststep_detected( "plantmode[0] is " . sprintf( "%08b", $$data_aref_panel1[0] ), 'mode_panel' );
	EVAL_evaluate_value( "plantmode[0] active", $$data_aref_panel1[0], 'MASK', '0b00xxx11x' );

	S_teststep_expected( "plantmode[1] == x0xxx1x0", 'mode_panel' );
	S_teststep_detected( "plantmode[1] is " . sprintf( "%08b", $$data_aref_panel2[0] ), 'mode_panel' );
	EVAL_evaluate_value( "plantmode[1] active", $$data_aref_panel2[0], 'MASK', '0bx0xxx1x0' );

	S_teststep_expected( "WL == On" . "\n", 'mode_panel' );
	S_teststep_detected( "WL is $data_href_panel->{'System Warning Lamp'}" . "\n", 'mode_panel' );
	if    ( $data_href_panel->{'System Warning Lamp'} =~ /.*off/i ) { $lampStatus2 = 'Off'; }
	elsif ( $data_href_panel->{'System Warning Lamp'} =~ /.*on/i )  { $lampStatus2 = 'On'; }
	else                                                            { $lampStatus2 = 'Error'; }
	EVAL_evaluate_string( "WL active", 'On', $lampStatus2 );

	S_teststep_expected( 'Expected faults:', 'fault_mode_panel' );
	foreach my $fault (@$tcpar_FLTmandPMInactive) {
		S_teststep_expected($fault);
	}
	S_teststep_expected("\n");
	S_teststep_detected( 'Detected faults:', 'fault_mode_panel' );
	foreach my $fault ( @{ $fltmem2->{fault_text} } ) {
		S_teststep_detected($fault);
	}
	S_teststep_detected("\n");
	PD_evaluate_faults( $fltmem2, $tcpar_FLTmandPMActive, $tcpar_FLToptPMActive );

	### Plant mode active - single ECU ###
	S_teststep_expected( "plantmode[0] == 11xxx00x", 'mode_single' );
	S_teststep_detected( "plantmode[0] is " . sprintf( "%08b", $$data_aref_ecu1[0] ), 'mode_single' );
	EVAL_evaluate_value( "plantmode[0] active", $$data_aref_ecu1[0], 'MASK', '0b11xxx00x' );

	S_teststep_expected( "plantmode[1] == x1xxx0x1", 'mode_single' );
	S_teststep_detected( "plantmode[1] is " . sprintf( "%08b", $$data_aref_ecu2[0] ), 'mode_single' );
	EVAL_evaluate_value( "plantmode[1] active", $$data_aref_ecu2[0], 'MASK', '0bx1xxx0x1' );

	S_teststep_expected( "WL == On" . "\n", 'mode_single' );
	S_teststep_detected( "WL is $data_href_ecu->{'System Warning Lamp'}" . "\n", 'mode_single' );
	if    ( $data_href_ecu->{'System Warning Lamp'} =~ /.*off/i ) { $lampStatus3 = 'Off'; }
	elsif ( $data_href_ecu->{'System Warning Lamp'} =~ /.*on/i )  { $lampStatus3 = 'On'; }
	else                                                          { $lampStatus3 = 'Error'; }
	EVAL_evaluate_string( "WL active", 'On', $lampStatus3 );

	for ( my $i = 1 ; $i < 8 ; $i++ ) {
		S_teststep_expected( "ITM Test Started Byte $i == $itm_TestStarted[$i]", 'mode_single' );
		S_teststep_detected( "ITM Test Started Byte $i == $$data_aref_itm_started[$i]", 'mode_single' );
		EVAL_evaluate_value( "ITM Test Started Byte $i", $$data_aref_itm_started[$i], '==', $itm_TestStarted[$i] );
	}
	S_teststep_expected("\n");
	S_teststep_detected("\n");
	for ( my $i = 1 ; $i < 8 ; $i++ ) {
		S_teststep_expected( "ITM Test Finished Byte $i == $itm_TestFinished[$i]", 'mode_single' );
		S_teststep_detected( "ITM Test Finished Byte $i == $$data_aref_itm_finished[$i]", 'mode_single' );
		EVAL_evaluate_value( "ITM Test Finished Byte $i", $$data_aref_itm_finished[$i], '==', @itm_TestFinished[$i] );
	}
	S_teststep_expected("\n");
	S_teststep_detected("\n");
	for ( my $i = 0 ; $i < 8 ; $i++ ) {
		S_teststep_expected( "ITM Test Failed Byte $i == $itm_TestFailed[$i]", 'mode_single' );
		S_teststep_detected( "ITM Test Failed Byte $i == $$data_aref_itm_failed[$i]", 'mode_single' );
		EVAL_evaluate_value( "ITM Test Failed Byte $i", $$data_aref_itm_failed[$i], '==', $itm_TestFailed[$i] );
	}
	S_teststep_expected("\n");
	S_teststep_detected("\n");
	for ( my $i = 0 ; $i < 8 ; $i++ ) {
		S_teststep_expected( "ITM Test Skipped Byte $i == $itm_TestSkipped[$i]", 'mode_single' );
		S_teststep_detected( "ITM Test Skipped Byte $i == $$data_aref_itm_skipped[$i]", 'mode_single' );
		EVAL_evaluate_value( "ITM Test Skipped Byte $i", $$data_aref_itm_skipped[$i], '==', @itm_TestSkipped[$i] );
	}
	S_teststep_expected("\n");
	S_teststep_detected("\n");

	S_teststep_expected( 'Expected faults:', 'fault_mode_single' );
	foreach my $fault (@$tcpar_FLTmandPMInactive) {
		S_teststep_expected($fault);
	}
	S_teststep_expected("\n");
	S_teststep_detected( 'Detected faults:', 'fault_mode_single' );
	foreach my $fault ( @{ $fltmem3->{fault_text} } ) {
		S_teststep_detected($fault);
	}
	S_teststep_detected("\n");
	PD_evaluate_faults( $fltmem3, $tcpar_FLTmandPMActive, $tcpar_FLToptPMActive );

	return 1;
}

sub TC_finalization {

	my $data_aref;

	S_teststep( "Set battery voltage to default value", 'AUTO_NBR' );
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Deactivate plantmode", 'AUTO_NBR' );

	#	PD_ECUlogin();
	PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [$plantmode_clear] );
	PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(1)', [$plantmode_clear] );
	S_wait_ms(2000);
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep( "Load default QuaTe config", 'AUTO_NBR' );
	QuaTe_configure();    # load default config
	S_wait_ms(2000);

	S_teststep( "Set default values for switches", 'AUTO_NBR' );
	my @blNames = LC_Get_names('BELT_LOCKS');
	foreach my $device (@blNames) {
		LC_SetLogicalState( $device, 'DEFAULT' );
	}

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	$data_aref = PD_ReadMemoryByName('rb_sycg_ActivePlantModes_au8(0)');
	EVAL_evaluate_value( "plantmode inactive", $$data_aref[0], '==', 0 );
	$data_aref = PD_ReadMemoryByName('rb_sycg_ActivePlantModes_au8(1)');
	EVAL_evaluate_value( "plantmode inactive", $$data_aref[0], '==', 0 );

	LC_ECU_Off();

	S_teststep_detected("TEMP: $temperatures[0]");
	S_teststep_detected("UBat: $tcpar_Ubat_V V");

	return 1;
}

1;
