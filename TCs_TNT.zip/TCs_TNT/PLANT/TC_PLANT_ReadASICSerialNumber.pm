# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_PLANT_ReadASICSerialNumber;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Plant
#TS version in DOORS: 1.10
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_TEMPERATURE;
use LIFT_evaluation;

#use LIFT_functional_layer;
use FuncLib_TNT_GEN;
use LIFT_FaultMemory;
use FuncLib_SYC_INTERFACE;
##################################

our $PURPOSE = " check that it is possible to read all system ASIC serial numbers if any plant mode is active ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PLANT_ReadASICSerialNumber 

=head1 PURPOSE

 check that it is possible to read all system ASIC serial numbers if any plant mode is active

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

    Ubat
    Pin
    FLTmand
    Temperature

    [initialisation]
    get temperature
    switch ECU on with U_BATT_DEFAULT
    clear fault memory

    [stimulation & measurement]
	1. switch ECU on - no plant mode active
	2. send production diagnosis service
	3. check response
	4. activate one plant mode
	5. reset ECU
	6. send production diagnosis service
	7. check response
	8. docment all read ASIC serial numbers
	9. deactivate plant mode

    [evaluation]
	1. -
	2. -
	3. Response = NRC 
	4. -
	5. -
	6. - 
	7. Response contains ASIC serial numbers
	8. ASIC serial number are stored in test report
	9. -

    [finalisation]
    switch ECU on
    clear fault memory
    switch ECU off


=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'Ubat'        --> battery voltage value
    
=head2 PARAMETER EXAMPLES

    [TC_PLANT_ReadASICSerialNumber.Read]
	purpose = 'check reading of ASIC serial number'
	Ubat=13.5
	
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#PARAMETERS
################ Parameters from .par file ######################
my ($tcpar_Ubat_V);
################ Parameters from syc ############################
my ( $sycpar_MasterAsic, $sycpar_Slave1Asic, $sycpar_Slave2Asic );
my ( $result, $master_asic_type_aref, $slave1_asic_type_aref, $slave2_asic_type_aref );
################ global parameter declaration ###################
my $plantmode5_set  = 0b00010000;
my $plantmode_clear = 0b00000000;

my ( $data_aref1,     $data_aref2 );
my ( $data_href1,     $data_href2 );
my ( $response_href1, $response_href2 );

my @temperatures = ();

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_Ubat_V = GEN_Read_mandatory_testcase_parameter('Ubat');

	( $result, $master_asic_type_aref ) = SYC_SYSTEMASIC_get_MasterAsicType();
	$sycpar_MasterAsic = $master_asic_type_aref;
	S_w2rep( " Master Asic: '$sycpar_MasterAsic'\n", 'green' );

	( $result, $slave1_asic_type_aref ) = SYC_SYSTEMASIC_get_Slave1AsicType();
	$sycpar_Slave1Asic = $slave1_asic_type_aref;
	S_w2rep( " Slave1 Asic: '$sycpar_Slave1Asic'\n", 'green' );

	( $result, $slave2_asic_type_aref ) = SYC_SYSTEMASIC_get_Slave2AsicType();
	$sycpar_Slave2Asic = $slave2_asic_type_aref;
	S_w2rep( " Slave2 Asic: '$sycpar_Slave2Asic'\n", 'green' );

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');
	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	# 1. switch ECU on - no plant mode active
	S_teststep( "Switch ECU on with Ubat = $tcpar_Ubat_V V", 'AUTO_NBR' );
	LC_ECU_On($tcpar_Ubat_V);
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Check if plantmode is not yet activated", 'AUTO_NBR', 'mode_inactive' );
	$data_aref1 = PRD_Read_Memory('rb_sycg_ActivePlantModes_au8(0)');
	$data_href1 = PRD_Get_ECU_Properties( { 'Property_names' => ['Lamp_status'] } );

	# 2. send production diagnosis service
	S_teststep( "send production diagnosis service", 'AUTO_NBR', 'requestPMInactive' );
	$response_href1 = PRD_Send_Request_Wait_Response_NOERROR( [ 0x02, 0x17, 0x19 ] );

	# 3. check response
	S_teststep( "Check response to diagnosis service", 'AUTO_NBR', 'responsePMInactive' );

	# 4. activate one plant mode
	S_teststep( "Set plantmode", 'AUTO_NBR' );
	PRD_Write_Memory( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [$plantmode5_set] );

	# 5. reset ECU
	S_teststep( "Do SW reset", 'AUTO_NBR' );
	PRD_ECU_Reset();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Check if plantmode is activated", 'AUTO_NBR', 'mode_active' );
	$data_aref2 = PRD_Read_Memory('rb_sycg_ActivePlantModes_au8(0)');
	$data_href2 = PRD_Get_ECU_Properties( { 'Property_names' => ['Lamp_status'] } );

	# 6. send production diagnosis service
	S_teststep( "send production diagnosis service", 'AUTO_NBR', 'requestPMActive' );
	$response_href2 = PRD_Send_Request_Wait_Response( [ 0x02, 0x17, 0x19 ] );

	# 7. check response
	S_teststep( "Check response to diagnosis service", 'AUTO_NBR', 'responsePMActive' );

	return 1;

	#Byte	Description of Block Content	Content
	#1	 Block Length	14H
	#2	 Block Title : 'Read system ASICs Serial Number'	57H
	#3	 ASIC 1 - MSB
	#4	 ASIC 1
	#5	 ASIC 1
	#6 	 ASIC 1
	#7	 ASIC 1
	#8	 ASIC 1 - LSB
	#9	 ASIC 2 - MSB
	#10	 ASIC 2
	#11	 ASIC 2
	#12	 ASIC 2
	#13	 ASIC 2
	#14	 ASIC 2 - LSB
	#15	 ASIC 3 - MSB
	#16	 ASIC 3
	#17	 ASIC 3
	#18	 ASIC 3
	#19	 ASIC 3
	#20	 ASIC 3 - LSB
	#21	 Checksum

	#	    $response_href = {
	#        'Status' => 0,
	#        'ErrorDescription' => 'OK',
	#        'PdLength' => 7,
	#        'Id' => 73,   # positive reponse to 0x09 = 0x49
	#        'PdPayload' => [73, 0, 0, 0, 3, 0],
	#        'Checksum' => 83,
	#        'CompletePdMsg' => [7, 73, 0, 0, 0, 3, 0, 83],
	#    }

}

#### EVALUATE TC #####
sub TC_evaluation {

	my ( $i, $masterAsicNumber, $slave1AsicNumber, $slave2AsicNumber );
	my ( $status1, $status2, $content1 );
	my ( $lampStatus1, $lampStatus2 );

	S_teststep_expected( "Plant mode 5 == 0", 'mode_inactive' );
	S_teststep_detected( "Plant mode 5 is $$data_aref1[0]", 'mode_inactive' );
	EVAL_evaluate_value( "Plant mode 5 inactive", $$data_aref1[0], '==', 0 );

	S_teststep_expected( "WL == Off", 'mode_inactive' );
	S_teststep_detected( "WL is $data_href1->{'Lamp_status'}->{'SystemWarningLamp'}", 'mode_inactive' );
	if    ( $data_href1->{'Lamp_status'}->{'SystemWarningLamp'} =~ /.*off/i ) { $lampStatus1 = 'Off'; }
	elsif ( $data_href1->{'Lamp_status'}->{'SystemWarningLamp'} =~ /.*on/i )  { $lampStatus1 = 'On'; }
	else                                                                      { $lampStatus1 = 'Error'; }
	EVAL_evaluate_string( "WL inactive", 'Off', $lampStatus1 );

	S_teststep_expected( 'diagnosis service status: no response', 'requestPMInactive' );
	$status1 = $response_href1->{'Status'};
	S_teststep_detected( "diagnosis service status: $status1", 'responsePMInactive' );
	EVAL_evaluate_value( "diagnosis service status", $status1, '>=', 0 );

	S_teststep_expected( 'diagnosis service: NRC 0x22', 'responsePMInactive' );
	$content1 = '0x' . sprintf( "%X", $response_href1->{'CompletePdMsg'}->[3] );
	S_teststep_detected( "diagnosis service: $content1", 'responsePMInactive' );
	EVAL_evaluate_string( 'diagnosis service', '0x22', $content1 );

	S_teststep_expected( "Plant mode 5 == $plantmode5_set", 'mode_active' );
	S_teststep_detected( "Plant mode 5 is $$data_aref2[0]", 'mode_active' );
	EVAL_evaluate_value( "Plant mode 5 active", $$data_aref2[0], '==', $plantmode5_set );

	S_teststep_expected( "WL == On" . "\n", 'mode_active' );
	S_teststep_detected( "WL is $data_href2->{'Lamp_status'}->{'SystemWarningLamp'}" . "\n", 'mode_active' );
	if    ( $data_href2->{'Lamp_status'}->{'SystemWarningLamp'} =~ /.*off/i ) { $lampStatus2 = 'Off'; }
	elsif ( $data_href2->{'Lamp_status'}->{'SystemWarningLamp'} =~ /.*on/i )  { $lampStatus2 = 'On'; }
	else                                                                      { $lampStatus2 = 'Error'; }
	EVAL_evaluate_string( "WL active", 'On', $lampStatus2 );

	S_teststep_expected( 'diagnosis service status: response available', 'requestPMActive' );
	$status2 = $response_href2->{'Status'};
	S_teststep_detected( "diagnosis service status: $status2", 'responsePMActive' );
	EVAL_evaluate_value( "diagnosis service status", $status2, '>=', 0 );

	# 8. docment all read ASIC serial numbers
	# Master ASIC
	$masterAsicNumber = '0x';
	for ( $i = 2 ; $i < 8 ; $i++ ) {
		$masterAsicNumber .= sprintf( "%X", $response_href2->{'CompletePdMsg'}->[$i] );
	}
	S_teststep_expected( "Master Asic '$sycpar_MasterAsic' has serial number (!= 0x000000000000)", 'responsePMActive' );
	S_teststep_detected( "Master Asic Serial Number: $masterAsicNumber", 'responsePMActive' );
	EVAL_evaluate_string( 'diagnosis service', '0x000000000000', $masterAsicNumber, '!=' );

	# Slave1 ASIC
	$slave1AsicNumber = '0x';
	for ( $i = 8 ; $i < 14 ; $i++ ) {
		$slave1AsicNumber .= sprintf( "%X", $response_href2->{'CompletePdMsg'}->[$i] );
	}
	if ( $sycpar_Slave1Asic eq 'N/A' ) {
		S_teststep_expected( "Slave1 Asic '$sycpar_Slave1Asic' has no serial number (= 0x000000000000)", 'responsePMActive' );
		S_teststep_detected( "Slave1 Asic Serial Number: $slave1AsicNumber", 'responsePMActive' );
		EVAL_evaluate_string( 'diagnosis service', '0x000000000000', $slave1AsicNumber );
	}
	else {
		S_teststep_expected( "Slave1 Asic '$sycpar_Slave1Asic' has serial number (!= 0x000000000000)", 'responsePMActive' );
		S_teststep_detected( "Slave1 Asic Serial Number: $slave1AsicNumber", 'responsePMActive' );
		EVAL_evaluate_string( 'diagnosis service', '0x000000000000', $slave1AsicNumber, '!=' );
	}

	# Slave2 ASIC
	$slave2AsicNumber = '0x';
	for ( $i = 14 ; $i < 20 ; $i++ ) {
		$slave2AsicNumber .= sprintf( "%X", $response_href2->{'CompletePdMsg'}->[$i] );
	}
	if ( $sycpar_Slave2Asic eq 'N/A' ) {
		S_teststep_expected( "Slave2 Asic '$sycpar_Slave2Asic' has no serial number (= 0x000000000000)", 'responsePMActive' );
		S_teststep_detected( "Slave2 Asic Serial Number: $slave2AsicNumber", 'responsePMActive' );
		EVAL_evaluate_string( 'diagnosis service', '0x000000000000', $slave2AsicNumber );
	}
	else {
		S_teststep_expected( "Slave2 Asic '$sycpar_Slave2Asic' has serial number (!= 0x000000000000)", 'responsePMActive' );
		S_teststep_detected( "Slave2 Asic Serial Number: $slave2AsicNumber", 'responsePMActive' );
		EVAL_evaluate_string( 'diagnosis service', '0x000000000000', $slave2AsicNumber, '!=' );
	}

	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	my $data_aref;

	# 9. deactivate plant mode
	S_teststep( "Set battery voltage to default value", 'AUTO_NBR' );
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Deactivate plantmode", 'AUTO_NBR' );
	PRD_Write_Memory( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [$plantmode_clear] );
	PRD_ECU_Reset();
	S_wait_ms('TIMER_ECU_READY');

	$data_aref = PRD_Read_Memory('rb_sycg_ActivePlantModes_au8(0)');
	EVAL_evaluate_value( "Plant mode inactive", $$data_aref[0], '==', $plantmode_clear );
	PRD_Clear_Fault_Memory();
	LC_ECU_Off();

	S_teststep_detected("TEMP: $temperatures[0]");
	S_teststep_detected("UBat: $tcpar_Ubat_V V");

	return 1;
}

1;
