#### TEST CASE MODULE
package Feature_SCR_SampleTest;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.2 $;
our $HEADER = q$Header: OST/Feature_SCR_SampleTest.pm 1.2 2018/01/19 00:14:24ICT Okrusch Thomas (CC-PS/EPS2) (OUT2SI) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use INCLUDES_Project;
use LIFT_evaluation;
use LIFT_DCOM;
use LIFT_TSG4;
use LIFT_LCT;
use LIFT_TRC; #necessary
#include further modules here

##################################

our $PURPOSE = "Feature_SCR_SampleTest";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

Feature_SCR_SampleTest

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Switch ECU on with nominal setting


I<B<Stimulation and Measurement>>

1.switch on ECU for 30sec with Ubat = 13.5V at T = room temp.

2.Read fault memory (normal fault free)

3.Measure the current consumption - (BBHW - QSGD0315)

4.Read squib values - (BBHW - QSGD0315)

5.Read AIN values - (BBHW - QSGD0315)

6.Measure AOUT level - deviation between of the values max �3%

7.Check level of communication (CAN, LIN, K-Line, FR) - (OST - QSGD0314)

8.Measure external sensors signals - (OST - QSGD0314)


I<B<Evaluation>>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES


	SCALAR 'purpose' => 
	SCALAR 'Label' => 
    SCALAR 'Device' => 
	SCALAR 'Type' => 
	SCALAR 'Value' => 
	SCALAR 'UpperLimit' => 
	SCALAR 'LowerLimit' => 


=head2 PARAMETER EXAMPLES

	purpose='SampleTest' 
	Label ='SampleTest_DoorsID : <ID>' 
    Device = AB1FD
	Type=0
	Value =13.6
	UpperLimit =0 
	LowerLimit =0

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Label;
my $tcpar_Device;
my $tcpar_Type;
my $tcpar_Value;
my $tcpar_UpperLimit;
my $tcpar_LowerLimit;
my $data_HoH;
my $WaitTime = 6000;
my $DeviceWaitTime = 2000;
################ global parameter declaration ###################
#add any global variables here


###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_Label =  GEN_Read_optional_testcase_parameter( 'Label' );
    $tcpar_Device =  GEN_Read_mandatory_testcase_parameter( 'Device' );
	$tcpar_Type =  GEN_Read_optional_testcase_parameter( 'Type' );
	$tcpar_Value =  GEN_Read_optional_testcase_parameter( 'Value' );
	$tcpar_UpperLimit =  GEN_Read_optional_testcase_parameter( 'UpperLimit' );
	$tcpar_LowerLimit =  GEN_Read_optional_testcase_parameter( 'LowerLimit' );

	return 1;
}

sub TC_initialization {

	GEN_printTestStep("Switch ECU on with nominal setting");

	return 1;
}

sub TC_stimulation_and_measurement {

    my @SQ_val;
    
    if($tcpar_Type == 0){
	GEN_printTestStep("Step 1.switch on ECU for 30sec with Ubat = 13.5V at T = room temp.");
	LC_SetVoltage('U_BATT_DEFAULT');	
	S_wait_ms( $WaitTime,"Wait after voltage is set" ); 

	GEN_printTestStep("Step 2.Read fault memory (normal fault free)");
    FM_PD_readFaultMemory (); 
	GEN_printTestStep("Step 3.Measure the current consumption - (BBHW - QSGD0315)");
    }
    elsif ($tcpar_Type == 1){
	GEN_printTestStep("Step 4.Read squib values - (BBHW - QSGD0315)");
    #my $value_aref = PD_ReadMemoryByName('rb_sqmm_ResistanceValue_au16(0)');

    push (@SQ_val, @{PD_ReadMemoryByName ($tcpar_Label)}); 
    if($main::opt_offline){
            @SQ_val = (0,0);
    }
    #temp fix
    my $temp = $SQ_val[1];
    $SQ_val[1] = $SQ_val[0];
    $SQ_val[0] = $temp;
    my $detected_value = S_aref2dec ( \@SQ_val, U16 );
    
    EVAL_evaluate_interval ( "Evaluate squib resistance" ,$tcpar_LowerLimit , $tcpar_UpperLimit , $detected_value  );
    }
    elsif ($tcpar_Type == 2){    
        GEN_printTestStep("Step 5.Read AIN values - (BBHW - QSGD0315)");
        DEVICE_setDeviceCurrent ($tcpar_Device,$tcpar_Value);
        S_wait_ms( $DeviceWaitTime,"Wait after SwitchValue is set" ); 
        push (@SQ_val, @{PD_ReadMemoryByName ($tcpar_Label)}); 
        if($main::opt_offline){
            @SQ_val = (0,0);
        }
        #temp fix
        my $temp = $SQ_val[1];
        $SQ_val[1] = $SQ_val[0];
        $SQ_val[0] = $temp;
        my $detected_value = S_aref2dec ( \@SQ_val, U16 );
        
        EVAL_evaluate_interval ( "Evaluate Switch resistance" ,$tcpar_LowerLimit , $tcpar_UpperLimit , $detected_value  );
    }
    elsif ($tcpar_Type == 4){
        GEN_printTestStep("Step 6.Measure AOUT level - deviation between of the values max �3%");
        TRC_StartMeasurement();
        TRC_SendSWTrigger();
        $data_HoH = TRC_get_values(['ENS1'], 2000);
        TRC_plot_values($main::REPORT_PATH."/ENS.txt.unv", 2000);
        GEN_printTestStep ("Link to captured TRC trace");
        GEN_printLink($main::REPORT_PATH."/ENS.txt.unv");   
    }
    elsif ($tcpar_Type == 5){
	GEN_printTestStep("Step 7.Check level of communication (CAN, LIN, K-Line, FR) - (OST - QSGD0314)");
    TRC_StartMeasurement();
    TRC_SendSWTrigger();
    $data_HoH = TRC_get_values(['CANH','CANL'], 2000);    
    TRC_plot_values($main::REPORT_PATH."/CAN.txt.unv", 2000);
    GEN_printTestStep ("Link to captured TRC trace");
    GEN_printLink($main::REPORT_PATH."/CAN.txt.unv");
    
    }
    elsif ($tcpar_Type == 3){    
	GEN_printTestStep("Step 8.Measure external sensors signals - (OST - QSGD0314)");
    push (@SQ_val, @{PD_ReadMemoryByName ($tcpar_Label)}); 
        if($main::opt_offline){
            @SQ_val = (0,0);
        }
        #temp fix
    my $temp = $SQ_val[1];
    $SQ_val[1] = $SQ_val[0];
    $SQ_val[0] = $temp;
    my $detected_value = S_aref2dec ( \@SQ_val, U16 );
    EVAL_evaluate_interval ( "Evaluate sensor labels" ,$tcpar_LowerLimit , $tcpar_UpperLimit , $detected_value  );
    }
    else{
   # TSG4_CloseHW();
    }
   # TSG4_CloseHW();
	return 1;
}


sub TC_evaluation {
    S_set_verdict(VERDICT_PASS);
	return 1;
}

sub TC_finalization {

	return 1;
}


1;
