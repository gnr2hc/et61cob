#### TEST CASE MODULE
package TC_EDR_CrashRecord_Layout;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;

#include further modules here
use LIFT_evaluation;
use LIFT_labcar;
use LIFT_crash_simulation;
use LIFT_can_access;
use LIFT_ProdDiag;
use LIFT_FaultMemory;
use GENERIC_DCOM;
use LIFT_MDSRESULT;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;

##################################

our $PURPOSE = "<summarize what this test is good for>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_CrashRecord_Layout

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFaultNoCT


I<B<Stimulation and Measurement>>

1. Power up ECU

2. Inject each crash in list <CrashCodeList> 

3. Wait for <wait_ms>

4. Power down ECU

5. Power up ECU

6. Read all crash telegrams stored in NVM with diagnosis <DiagType>


I<B<Evaluation>>

1. - 

2. - 

3. - 

4. - 

5. - 

6. a) <EvalType> = CTsize

Number of bytes reported except supplier data must match EDR_CT_SIZE from SYC

b) <EvalType> = CTsizeInternal

Number of bytes in supplier EDID must match EDR_CT_INTERNAL_SIZE from SYC

c) <EvalType> = 'ParseRecordSuccessful'

Parsing of record according to EDR mapping which is derived from EDID List SRS must be successful.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'EDR_CT_SIZE' => 
	SCALAR 'purpose' => 
	SCALAR 'ResultDB' => 
	LIST 'CrashCodeList' => 
	SCALAR 'DiagType' => 
	HASH 'COMSignalsAfterCrash' => 
	SCALAR 'EvalType' => 


=head2 PARAMETER EXAMPLES

	purpose = 'Inject <Test Heading Tail> crash and evaluate record with respect to <Test Heading Head>' # description of test case
	
	# ---------- Stimulation ------------ 
	ResultDB = 'EDR'
	CrashCodeList = @('Single_EDR_Front_Inflatable', 'Single_EDR_SideRight_Inflatable')
	# give here as many crashes as NVM buffers are available
	DiagType = 'ProdDiag'
	COMSignalsAfterCrash = %()
	
	# ---------- Evaluation ------------ 
	EvalType = 'CTsize'
	#EDR_CT_SIZE = <Fetch {'V_RefType2_B_Sample'} {([5-8][0-9][0-9])}> 
	EDR_CT_SIZE = 500 #no value provided in SYC

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_ResultDB;
my $tcpar_CrashCodeList;
my $tcpar_DiagType;
my $tcpar_COMSignalsAfterCrash;
my $tcpar_EvalType;
my $tcpar_EDID_InternalData;
my $tcpar_read_NHTSAEDR;
my $tcpar_read_CHINAEDR;

################ global parameter declaration ###################
#add any global variables here
my ( $record_handler, $edrNumberOfEventsToBeStored, $crashLabel, $ChinaEDR_diagType );

###############################################################

sub TC_set_parameters {

	$tcpar_purpose              = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_ResultDB             = S_read_mandatory_testcase_parameter('ResultDB');
	$tcpar_CrashCodeList        = S_read_mandatory_testcase_parameter( 'CrashCodeList', 'byref' );
	$tcpar_DiagType             = S_read_mandatory_testcase_parameter('DiagType');
	$tcpar_COMSignalsAfterCrash = S_read_optional_testcase_parameter( 'COMSignalsAfterCrash', 'byref' );
	$tcpar_EvalType             = S_read_mandatory_testcase_parameter('EvalType');
	$tcpar_EDID_InternalData    = S_read_optional_testcase_parameter( 'EDID_InternalData', 'byref' );
	$tcpar_EDID_InternalData    = ['999'] unless ( defined $tcpar_EDID_InternalData );
	if ( ref($tcpar_EDID_InternalData) ne 'ARRAY' ) {
		my $aref;
		push( @{$aref}, $tcpar_EDID_InternalData );
		$tcpar_EDID_InternalData = $aref;
	}
	$tcpar_read_NHTSAEDR = S_read_optional_testcase_parameter('read_NHTSAEDR');
	$tcpar_read_CHINAEDR = S_read_optional_testcase_parameter('read_CHINAEDR');

	if ( not defined $tcpar_read_CHINAEDR ) {
		$tcpar_read_NHTSAEDR = 'yes';
		$tcpar_read_CHINAEDR = 'no';
	}
	else {
		$tcpar_read_NHTSAEDR = 'no';
		$ChinaEDR_diagType   = 'CHINA_Payload';

	}
	return 1;
}

sub TC_initialization {

	S_teststep( "Test setup preparation", 'AUTO_NBR' );

	#--------------------------------------------------------------
	# INITIALIZE RECORD AND CRASH HANDLER
	#
	S_w2rep("Initialize Record Handler");
	$record_handler = EDR_init_RecordHandler() || return;

	S_teststep( "Power up ECU", 'AUTO_NBR' );
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');
	S_w2log( 1, "Initialize CD and start CAN trace" );
	GDCOM_init();    # To fetch info for CD from mapping_diag
	CA_trace_start();

	S_teststep( "Clear crash recorder", 'AUTO_NBR' );
	PRD_Clear_EDR( { timeout_ms => 'TIMER_CLEAR_CRASH_RECORDER' } );

	S_wait_ms(2000);
	S_teststep( "Clear fault memory", 'AUTO_NBR' );
	PRD_Clear_Fault_Memory();
	S_wait_ms(2000);

	S_teststep( "Read fault memory before stimulation", 'AUTO_NBR' );
	my $faultsBeforeStimulation_obj = LIFT_FaultMemory->read_fault_memory('Primary');

	#Check fault empty before stimulation
	my $faultsVerdict = $faultsBeforeStimulation_obj->evaluate_faults( {} );
	return 0 unless ( $faultsVerdict eq 'VERDICT_PASS' );

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Inject each crash in list 'CrashCodeList' ", 'AUTO_NBR' );
	foreach my $crashCode ( @{$tcpar_CrashCodeList} ) {
		S_w2rep("Prepare and inject $crashCode");
		$crashLabel .= "_" if ( defined $crashLabel );
		$crashLabel .= $crashCode;
		my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
		my $resultDB_Path = $resultDBDetails->{'PATH'};
		S_w2rep("Get crash settings for crash $crashCode");
		my $crashDetails_href = { "RESULTDB" => $tcpar_ResultDB, 'CRASHNAME' => $crashCode };
		my $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);

		unless ( defined $crashSettings ) {
			S_set_error("Crash $crashCode not available in result DB $tcpar_ResultDB. Test case aborted.");
			return;
		}

		S_w2log( 1, "Crashcode: $crashCode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)" );

		S_teststep( "Set environment for crash", 'AUTO_NBR' );
		CSI_PrepareEnvironment( $crashSettings, 'init_complete' );
		S_wait_ms(2000);

		LC_ECU_Off();
		S_wait_ms('TIMER_ECU_OFF');

		# Prepare crash
		CSI_LoadCrashSensorData2Simulator($crashSettings);

		# Power ON the ECU
		LC_ECU_On();
		S_wait_ms('TIMER_ECU_READY');

		CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle', 'normal' );
		S_wait_ms(1000);

		CSI_TriggerCrash();

		S_teststep( "Wait for 15 seconds", 'AUTO_NBR' );
		S_wait_ms(15000);
	}

	if ( defined $tcpar_COMSignalsAfterCrash ) {
		foreach my $signal ( keys %{$tcpar_COMSignalsAfterCrash} ) {
			S_w2rep("Signal=$signal");
			my $dataOnCOM = $tcpar_COMSignalsAfterCrash->{$signal};
			S_w2rep("DataOnCOM=$dataOnCOM");
			COM_setSignalState( $signal, $dataOnCOM );
		}
	}

	S_teststep( "Read all crash telegrams stored in NVM with diagnosis '$tcpar_DiagType'", 'AUTO_NBR', 'read_all_crash' );    #measurement 1
	$edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();
	my $dataStoragePath = "$main::REPORT_PATH/" . S_get_TC_number() . "_" . $crashLabel;
	PRD_ECU_Login() if ( $tcpar_DiagType eq 'ProdDiag' );

	if ( lc($tcpar_read_NHTSAEDR) eq 'yes' ) {
		EDR_ReadAndStoreAllRecords(
			"DiagType"     => $tcpar_DiagType,
			"CrashLabel"   => $crashLabel,
			"NbrOfRecords" => $edrNumberOfEventsToBeStored,
			"StoragePath"  => $dataStoragePath,
			"read_EDRType" => 'NHTSA'
		);
	}
	if ( lc($tcpar_read_CHINAEDR) eq 'yes' ) {
		$edrNumberOfEventsToBeStored = 3;
		EDR_ReadAndStoreAllRecords(
			"DiagType"     => $ChinaEDR_diagType,
			"CrashLabel"   => $crashLabel,
			"NbrOfRecords" => $edrNumberOfEventsToBeStored,
			"StoragePath"  => $dataStoragePath,
			"read_EDRType" => 'CHINA'
		);
	}
	return 1;
}

sub TC_evaluation {

	my $scipGeneratedMapping = EDR_Mapping_GeneratedWithSCIP();
	if ( not defined $scipGeneratedMapping ) {
		S_set_error(" scipGeneratedMapping is not defined, check function 'EDR_Mapping_GeneratedWithSCIP' for more details.");
	}
	foreach my $recordNbr ( 1 .. $edrNumberOfEventsToBeStored ) {
		my $recordAvailable = $record_handler->IsRecordAvailable( "CrashLabel" => $crashLabel, "RecordNumber" => $recordNbr );
		next unless ($recordAvailable);
		S_w2rep( "--------------------------------",     'teal' );
		S_w2rep( "Validate layout of record $recordNbr", 'teal' );
		S_w2rep( "--------------------------------",     'teal' );

		if ( $tcpar_EvalType eq 'CTsize' ) {
			S_teststep( "Evaluate number of bytes reported in one crash telegram except supplier data", 'AUTO_NBR', "Eval_CT_Size_Record$recordNbr" );
			my $edidInfo;
			$edidInfo = EDR_ReadEDR_Record_structure_info_from_mapping()      if ( $tcpar_read_NHTSAEDR eq 'yes' );
			$edidInfo = EDR_ReadCHINAEDR_Record_structure_info_from_mapping() if ( $tcpar_read_CHINAEDR eq 'yes' );

			my $expectedCrashTelegramSize = 0;
			foreach my $edidDefined ( keys %{ $edidInfo->{'EDIDS'} } ) {
				next if ( $edidDefined eq '999' );
				if ( $scipGeneratedMapping eq 'no' ) {
					my $stateEDID = $edidInfo->{'EDIDS'}->{$edidDefined}->{'StateEDID'};
					if ( $stateEDID eq 'Implemented' ) {
						my $bytesPerDataSample = $edidInfo->{'EDIDS'}->{$edidDefined}->{'BytesPerDataSample'};
						my $dataSamples        = $edidInfo->{'EDIDS'}->{$edidDefined}->{'DataSamples'};
						my $datalength         = $dataSamples * $bytesPerDataSample;
						$expectedCrashTelegramSize = $expectedCrashTelegramSize + $datalength;
					}
					else {
						next;
					}
				}
				if ( $scipGeneratedMapping eq 'yes' ) {
					my $bytesPerDataSample = $edidInfo->{'EDIDS'}->{$edidDefined}->{'BytesPerDataSample'};
					my $dataSamples        = $edidInfo->{'EDIDS'}->{$edidDefined}->{'DataSamples'};
					my $datalength         = $dataSamples * $bytesPerDataSample;
					$expectedCrashTelegramSize = $expectedCrashTelegramSize + $datalength;
				}
			}

			my $edidsInRecord_aref = $record_handler->GetListOfEDIDsInRecord(
				"CrashLabel"    => $crashLabel,
				"RecordNumber"  => $recordNbr,
				"MainEdidsOnly" => 1
			);
			my $detectedNumberOfBytes;
			foreach my $edidInRecord ( @{$edidsInRecord_aref} ) {
				if ( grep /^$edidInRecord$/, @{$tcpar_EDID_InternalData} ) {
					S_w2log( 1, "EDID $edidInRecord will be skipped because it contains internal data" );
					next;
				}
				my $rawInternalData = $record_handler->GetRawEDID( "CrashLabel" => $crashLabel, "RecordNumber" => $recordNbr, "EDIDnr" => $edidInRecord );
				my $numberOfBytes = 1;
				$numberOfBytes = @{$rawInternalData} if ( ref($rawInternalData) eq 'ARRAY' );
				$detectedNumberOfBytes = $detectedNumberOfBytes + $numberOfBytes;
			}
			EVAL_evaluate_value( "CTsize_Record$recordNbr", $detectedNumberOfBytes, '==', $expectedCrashTelegramSize );
			S_teststep_expected( "Calculated from Mapping EDR: $expectedCrashTelegramSize", "Eval_CT_Size_Record$recordNbr" );
			S_teststep_detected( "EDR: $detectedNumberOfBytes", "Eval_CT_Size_Record$recordNbr" );
		}
		elsif ( $tcpar_EvalType eq 'CTsizeInternal' ) {
			S_teststep( "Evaluate number of bytes reported supplier EDID", 'AUTO_NBR', "Eval_CT_Size_Internal_Record$recordNbr" );
			my $edidInfo                          = EDR_ReadEDR_Record_structure_info_from_mapping();
			my $bytesPerDataSample                = $edidInfo->{'EDIDS'}->{'999'}->{'BytesPerDataSample'};
			my $dataSamples                       = $edidInfo->{'EDIDS'}->{'999'}->{'DataSamples'};
			my $expectedCrashTelegramSizeInternal = $dataSamples * $bytesPerDataSample;

			my $detectedNumberOfBytes;
			foreach my $internalDataEDID ( @{$tcpar_EDID_InternalData} ) {
				my $rawInternalData = $record_handler->GetRawEDID( "CrashLabel" => $crashLabel, "RecordNumber" => $recordNbr, "EDIDnr" => $internalDataEDID );
				my $numberOfBytes = 1;
				$numberOfBytes = @{$rawInternalData} if ( ref($rawInternalData) eq 'ARRAY' );
				$detectedNumberOfBytes = $detectedNumberOfBytes + $numberOfBytes;
			}
			EVAL_evaluate_value( "CTsizeInternal_Record$recordNbr", $detectedNumberOfBytes, '==', $expectedCrashTelegramSizeInternal );
			S_teststep_expected( "Calculated from Mapping EDR: $expectedCrashTelegramSizeInternal", "Eval_CT_Size_Internal_Record$recordNbr" );
			S_teststep_detected( "EDR: $detectedNumberOfBytes", "Eval_CT_Size_Internal_Record$recordNbr" );
		}
		elsif ( $tcpar_EvalType eq 'ParseRecordSuccessful' ) {
			S_teststep( "Evaluate data length of each EDID", 'AUTO_NBR', "ParseRecordSuccessful_Record$recordNbr" );
			my $detectedParseStatus;
			my $verdict = S_get_current_verdict();

			if ( $verdict eq 'VERDICT_INCONC' ) {
				$detectedParseStatus = 'ParseRecordNotSuccessful';
				S_w2rep("Parsing not successful, test case verdict is 'VERDICT_INCONC' --> Error during parsing");
				S_set_verdict('VERDICT_FAIL');
			}
			else {
				$detectedParseStatus = 'ParseRecordSuccessful';
				S_w2rep("Parsing successful, test case verdict is 'VERDICT_NONE' or 'VERDICT_PASS'");
				S_set_verdict('VERDICT_PASS');
			}

			S_teststep_expected( "Parsing record successful", "ParseRecordSuccessful_Record$recordNbr" );
			S_teststep_detected( "Status of parsing record: $detectedParseStatus", "ParseRecordSuccessful_Record$recordNbr" );

			if ( $scipGeneratedMapping eq 'yes' ) {

				S_teststep( "Check that all EDIDs available in SCIP are reported", 'AUTO_NBR', "All_EDIDs_Reported_Record$recordNbr" );

				my $edidsNotReported;
				my $stateVerdict       = 'VERDICT_NONE';
				my $reportedVerdict    = 'VERDICT_NONE';
				my $edidInfo           = EDR_ReadEDR_Record_structure_info_from_mapping();
				my $edidsInRecord_aref = $record_handler->GetListOfEDIDsInRecord(
					"CrashLabel"    => $crashLabel,
					"RecordNumber"  => 1,
					"MainEdidsOnly" => 1
				);
				foreach my $edidDefined ( keys %{ $edidInfo->{'EDIDS'} } ) {
					my $allAttributeInfo = $edidInfo->{'EDIDS'}->{$edidDefined};
					next unless ( defined $allAttributeInfo );

					#grep

					if ( grep( $edidDefined, @{$edidsInRecord_aref} ) ) {
						$reportedVerdict = 'VERDICT_PASS' unless ( $stateVerdict eq 'VERDICT_FAIL' );
					}
					else {
						$reportedVerdict = 'VERDICT_FAIL';
						$edidsNotReported .= " $edidDefined";
					}
				}
				S_set_verdict($reportedVerdict);
				S_teststep_expected( "All EDIDs available in SCIP are reported", "All_EDIDs_Reported_Record$recordNbr" );
				S_teststep_detected( "EDIDs which are available in SCIP but not reported in EDR: $edidsNotReported", "All_EDIDs_Reported_Record$recordNbr" ) if ($edidsNotReported);
				S_teststep_detected( "All EDIDs  available in SCIP are reported",                                    "All_EDIDs_Reported_Record$recordNbr" ) if ( not $edidsNotReported );
			}
			elsif ( $scipGeneratedMapping eq 'no' ) {
				S_teststep( "Check that only EDIDs in state 'Implemented' are reported", 'AUTO_NBR', "EDID_States_Record$recordNbr" );
				my $edidsInRecord_aref = $record_handler->GetListOfEDIDsInRecord(
					"CrashLabel"    => $crashLabel,
					"RecordNumber"  => 1,
					"MainEdidsOnly" => 1
				);
				my $edidInfo = EDR_ReadEDR_Record_structure_info_from_mapping();

				my $string_EDIDs_Failed;
				my $stateVerdict = 'VERDICT_NONE';
				foreach my $edidInRecord ( @{$edidsInRecord_aref} ) {
					my $stateEDID = $edidInfo->{'EDIDS'}->{$edidInRecord}->{'StateEDID'};
					if ( $stateEDID eq 'Implemented' ) {
						$stateVerdict = 'VERDICT_PASS' unless ( $stateVerdict eq 'VERDICT_FAIL' );
					}
					else {
						$stateVerdict = 'VERDICT_FAIL';
						$string_EDIDs_Failed .= " $edidInRecord";
					}
				}
				S_set_verdict($stateVerdict);
				S_teststep_expected( "All reported EDIDs are in 'Implemented' state", "EDID_States_Record$recordNbr" );
				S_teststep_detected( "EDIDs which are not in implemented state but reported in EDR: $string_EDIDs_Failed", "EDID_States_Record$recordNbr" ) if ($string_EDIDs_Failed);
				S_teststep_detected( "All reported EDIDs are in 'Implemented' state",                                      "EDID_States_Record$recordNbr" ) if ( not $string_EDIDs_Failed );

				S_teststep( "Check that all EDIDs in state 'Implemented' are reported", 'AUTO_NBR', "All_EDIDs_Reported_Record$recordNbr" );

				my $edidsNotReported;
				my $reportedVerdict = 'VERDICT_NONE';
				foreach my $edidDefined ( keys %{ $edidInfo->{'EDIDS'} } ) {
					my $stateEDID = $edidInfo->{'EDIDS'}->{$edidDefined}->{'StateEDID'};
					next unless ( $stateEDID eq 'Implemented' );

					#grep

					if ( grep( $edidDefined, @{$edidsInRecord_aref} ) ) {
						$reportedVerdict = 'VERDICT_PASS' unless ( $stateVerdict eq 'VERDICT_FAIL' );
					}
					else {
						$reportedVerdict = 'VERDICT_FAIL';
						$edidsNotReported .= " $edidDefined";
					}
				}
				S_set_verdict($reportedVerdict);
				S_teststep_expected( "All EDIDs in 'Implemented' state are reported", "All_EDIDs_Reported_Record$recordNbr" );
				S_teststep_detected( "EDIDs which are in implemented state but not reported in EDR: $edidsNotReported", "All_EDIDs_Reported_Record$recordNbr" ) if ($edidsNotReported);
				S_teststep_detected( "All EDIDs in 'Implemented' state are reported",                                   "All_EDIDs_Reported_Record$recordNbr" ) if ( not $edidsNotReported );
			}
			else {
				S_set_error("'EDR mapping generation type is not known! Must be 'SCIP generated' or 'Non SCIP generated' , but is given as '$scipGeneratedMapping'");
				return;
			}
		}
		else {
			S_set_error("EvalType not known! Must be 'CTsize', 'CTsizeInternal' or 'ParseRecordSuccessful'");
			return;
		}
	}

	return 1;
}

sub TC_finalization {

	# Read fault memory after crash
	LIFT_FaultMemory->read_fault_memory('Primary');
	S_wait_ms(2000);

	# Erase EDR
	PRD_Clear_EDR( { timeout_ms => 'TIMER_CLEAR_CRASH_RECORDER' } );
	S_wait_ms(2000);

	# Erase Fault memory
	PRD_Clear_Fault_Memory();
	S_wait_ms(2000);

	# Reset ECU
	PRD_ECU_Reset();
	S_wait_ms('TIMER_ECU_READY');

	# Read fault memory after clearing and erasing EDR
	LIFT_FaultMemory->read_fault_memory('Primary');
	S_wait_ms(2000);
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_w2rep("Clean up record handler");
	$record_handler->DeleteAllRecords();

	return 1;
}

1;
