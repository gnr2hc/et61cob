#### TEST CASE MODULE
package TC_EDR_Storage_EventPriority;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use INCLUDES_Project;
#include further modules here
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_can_access;
use LIFT_MDSRESULT;
use GENERIC_DCOM;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;
use Data::Dumper;

##################################

our $PURPOSE = "<summarize what this test is good for>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_Storage_EventPriority

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Inject so many <DeploymentCrashCode> crashes that two empty records are left.

2. Read all records of injected crashes.

3. Power down ECU

4. Set MDS environments for crash <Crashcode1>

#---- Crash 1 ----

5. Set <Switch1> to state <Switch1_State1> and <Switch2> to <Switch2_State1>

6. Power up ECU

7. Start recording of fire times.

8. Inject <Crashcode1> 

9. Wait <WaitTime_ms>

10. Stop recording of fire times.

11. Power down ECU

#---- Crash 2 ----

12. Set <Switch1> to state <Switch1_State2> and <Switch2> to <Switch2_State1>

13. Power up ECU

14. Start recording of fire times.

15. Inject <Crashcode2> 

16. Wait <WaitTime_ms>

17. Stop recording of fire times.

18. Power down ECU

#---- Crash 3 ----

19. Set <Switch1> to state <Switch1_State2> and <Switch2> to <Switch2_State2>

20. Power up ECU

21. Start recording of fire times.

22. Inject <Crashcode3> 

23. Power Off at T0 if <Autarky> is 'true'

24. Wait <WaitTime_ms>

25. Stop recording of fire times.

26. Power down ECU

27. Read and store all EDR records


I<B<Evaluation>>

1. -

2. -

3. -

4. -

5. Switch states <Crashcode1> reported in expected record number 

6. -

7. -

8. -

9. -

10. Fire times <Crashcode1> reported in expected record number

11. -

12. -

13. Switch states <Crashcode2> reported in expected record number

14. -

15. -

16. -

17. -

18. Fire times <Crashcode2> reported in expected record number

19. -

20. -

21. Switch states <Crashcode3> reported in expected record number

22. -

23. -

24. -

25. -

26. Fire times <Crashcode2> reported in expected record number

27. -

28. -


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Crashcode1' => 
	SCALAR 'Crash1_TimeZero_ms' => 
	SCALAR 'Crashcode2' => 
	SCALAR 'Crash2_TimeZero_ms' => 
	SCALAR 'Crashcode3' => 
	SCALAR 'Crash3_TimeZero_ms' => 
	SCALAR 'HighPriority_Crash1' => 
	SCALAR 'HighPriority_Crash2' => 
	SCALAR 'purpose' => 
	SCALAR 'ResultDB' => 
	SCALAR 'DeploymentCrashCode' => 
	SCALAR 'Switch1' => 
	SCALAR 'EDID_Switch1' => 
	SCALAR 'Switch1_State1' => 
	SCALAR 'Switch1_State2' => 
	SCALAR 'Switch2' => 
	SCALAR 'EDID_Switch2' => 
	SCALAR 'Switch2_State1' => 
	SCALAR 'Switch2_State2' => 
	SCALAR 'WaitTime_ms' => 
	SCALAR 'Autarky' => 


=head2 PARAMETER EXAMPLES

	 purpose		 = 'Check whether injecting a <Test Heading Tail> airbag deployment crash overwrites a <Test Heading 2> or <Test Heading 4>  crash.'
	# ---------- Stimulation ------------ 
	ResultDB = 'EDR' # defined in CREIS project constants - will be set to 'DEFAULT' if not given
	DeploymentCrashCode = 'Single_EDR_Front_Inflatable'
	Switch1 = 'BLFD'
	EDID_Switch1 = '71'
	Switch1_State1 = 'PosA'
	Switch1_State2 = 'PosB'
	Switch2 = 'BLFP'
	EDID_Switch2 = '77'
	Switch2_State1 = 'PosA'
	Switch2_State2 = 'PosB'
	WaitTime_ms = 15000
	# ---------- Evaluation ------------ 
	# Front NAD (CT5) and Side AD (CT6) stored
	Crashcode1 = 'Single_EDR_Front_NonInflatable'
	Crash1_TimeZero_ms = '22.26' #given in crash list
	
	Crashcode2= 'Single_EDR_SideLeft_Inflatable'
	Crash2_TimeZero_ms = '14.26' #given in crash list
	
	Crashcode3 = 'Single_EDR_Front_above_8kph_NoDeployment'
	Crash3_TimeZero_ms = '76.26' #given in crash list
	
	HighPriority_Crash1 = 'Single_EDR_Front_NonInflatable'
	HighPriority_Crash2 = 'Single_EDR_SideLeft_Inflatable'
	
	Autarky = 'false'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_ResultDB;
my $tcpar_DeploymentCrashCode;
my $tcpar_Switch1;
my $tcpar_EDID_Switch1;
my $tcpar_Switch1_State1;
my $tcpar_Switch1_State2;
my $tcpar_Switch2;
my $tcpar_EDID_Switch2;
my $tcpar_Switch2_State1;
my $tcpar_Switch2_State2;
my $tcpar_WaitTime_ms;
my $tcpar_Crashcode1;
my $tcpar_Crash1_TimeZero_ms;
my $tcpar_Crashcode2;
my $tcpar_Crash2_TimeZero_ms;
my $tcpar_Crashcode3;
my $tcpar_Crash3_TimeZero_ms;
my $tcpar_HighPriority_Crash1;
my $tcpar_HighPriority_Crash1_RecordNbr;
my $tcpar_HighPriority_Crash2;
my $tcpar_HighPriority_Crash2_RecordNbr;
my $tcpar_DiagType;
my $tcpar_FireTimeTolerance_ms;
my $tcpar_FireTime_EDIDs;
my $tcpar_Autarky;
my $tcpar_AutarkyCrashNumber;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_SupplierEDID;
my $tcpar_read_NHTSAEDR;
my $tcpar_read_CHINAEDR;

################ global parameter declaration ###################
#add any global variables here
my (
	$crash_handler,
	$record_handler,
	$resultDB_Path,
	$crashInjectionInfo_href,
	$edrNumberOfEventsToBeStored,
	$mappingEDR,
	$ChinaEDR_diagType,
);

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_ResultDB =  S_read_optional_testcase_parameter( 'ResultDB' );
	$tcpar_ResultDB = 'DEFAULT' unless(defined $tcpar_ResultDB);
	$tcpar_DeploymentCrashCode =  S_read_mandatory_testcase_parameter( 'DeploymentCrashCode' );

	$tcpar_Switch1 =  S_read_mandatory_testcase_parameter( 'Switch1' );
	$tcpar_Switch1_State1 =  S_read_mandatory_testcase_parameter( 'Switch1_State1' );
	$tcpar_Switch1_State2 =  S_read_mandatory_testcase_parameter( 'Switch1_State2' );
	$tcpar_Switch2 =  S_read_mandatory_testcase_parameter( 'Switch2' );
	$tcpar_Switch2_State1 =  S_read_mandatory_testcase_parameter( 'Switch2_State1' );
	$tcpar_Switch2_State2 =  S_read_mandatory_testcase_parameter( 'Switch2_State2' );
	$tcpar_WaitTime_ms =  S_read_mandatory_testcase_parameter( 'WaitTime_ms' );
	$tcpar_Crashcode1 =  S_read_mandatory_testcase_parameter( 'Crashcode1' );
	$tcpar_Crash1_TimeZero_ms =  S_read_mandatory_testcase_parameter( 'Crash1_TimeZero_ms' );
	$tcpar_Crashcode2 =  S_read_mandatory_testcase_parameter( 'Crashcode2' );
	$tcpar_Crash2_TimeZero_ms =  S_read_mandatory_testcase_parameter( 'Crash2_TimeZero_ms' );
	$tcpar_Crashcode3 =  S_read_mandatory_testcase_parameter( 'Crashcode3' );
	$tcpar_Crash3_TimeZero_ms =  S_read_mandatory_testcase_parameter( 'Crash3_TimeZero_ms' );
	$tcpar_DiagType =  S_read_optional_testcase_parameter( 'DiagType' );
	$tcpar_DiagType = 'ProdDiag' unless(defined $tcpar_DiagType);

	$tcpar_HighPriority_Crash1 =  S_read_mandatory_testcase_parameter( 'HighPriority_Crash1' );
	$tcpar_HighPriority_Crash2 =  S_read_mandatory_testcase_parameter( 'HighPriority_Crash2' );
    $tcpar_HighPriority_Crash1_RecordNbr =  S_read_optional_testcase_parameter( 'HighPriority_Crash1_RecordNbr' );
    $tcpar_HighPriority_Crash2_RecordNbr =  S_read_optional_testcase_parameter( 'HighPriority_Crash2_RecordNbr' );
	$tcpar_EDID_Switch1 =  S_read_mandatory_testcase_parameter( 'EDID_Switch1' );
	$tcpar_EDID_Switch2 =  S_read_mandatory_testcase_parameter( 'EDID_Switch2' );
	$tcpar_FireTimeTolerance_ms =  S_read_optional_testcase_parameter( 'FireTimeTolerance_ms' );
	$tcpar_FireTimeTolerance_ms = 3 unless(defined $tcpar_FireTimeTolerance_ms);
	$tcpar_FireTime_EDIDs =  S_read_mandatory_testcase_parameter( 'FireTime_EDIDs', 'byref' );
	
	$tcpar_SupplierEDID = S_read_optional_testcase_parameter('SupplierEDID');

	$tcpar_Autarky =  S_read_optional_testcase_parameter( 'Autarky' );
	$tcpar_AutarkyCrashNumber = S_read_optional_testcase_parameter( 'AutarkyCrashNumber' );
	if(defined $tcpar_Autarky and not defined $tcpar_AutarkyCrashNumber)
	{
		$tcpar_AutarkyCrashNumber = 3; #default
	}
	$tcpar_COMsignalsAfterCrash =  S_read_optional_testcase_parameter( 'COMsignalsAfterCrash','byref');

    $mappingEDR = S_get_contents_of_hash(['Mapping_EDR']);
	$tcpar_read_NHTSAEDR=S_read_optional_testcase_parameter('read_NHTSAEDR');
	$tcpar_read_CHINAEDR=S_read_optional_testcase_parameter('read_CHINAEDR');
	if(not defined $tcpar_read_CHINAEDR) {
		$tcpar_read_NHTSAEDR = 'yes';
		$tcpar_read_CHINAEDR = 'no';
	}
	else {
		$tcpar_read_NHTSAEDR = 'no';
		my $storageOrder = EDR_getStorageOrder();
		return unless(defined $storageOrder);

		if($storageOrder eq 'PhysicalOrder'){
			$ChinaEDR_diagType= 'ProdDiag';  #In platform NHTSA and China EDR is read via proddiag
		}
		else {
			$ChinaEDR_diagType= 'CHINA_Payload';
		}
	}

	return 1;
}

sub TC_initialization {

	S_teststep("Test setup preparation", 'AUTO_NBR');

	#--------------------------------------------------------------
    # INITIALIZE RECORD AND CRASH HANDLER
    #    
	S_w2rep("Initialize Record and Crash Handler");
	$record_handler = EDR_init_RecordHandler() || return;
	$crash_handler  = EDR_init_CrashHandler() || return;

	#--------------------------------------------------------------
    # PREPARE CRASH AND INITIALIZE EQUIPMENT
    #
	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	$resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log(1, "ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");

	S_w2log(1, "Power on ECU");
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');
    
    S_w2log(1, "Initialize CD and start CAN trace");
    GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start ( );
	
	S_w2log(1, "Clear crash recorder");
    PD_ClearCrashRecorder();
    S_wait_ms(2000);

	S_w2log(1, "Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	S_w2log(1, "Reset ECU");
    PD_ECUreset();
    S_wait_ms('TIMER_ECU_READY');

	S_w2log(1, "Read and evaluate fault memory before stimulation");
    my $faultsBeforeStimulation = PD_ReadFaultMemory();
    my $faultsVerdict = PD_evaluate_faults( $faultsBeforeStimulation, []);
 	return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

	return 1;
}

sub TC_stimulation_and_measurement {

	my $extendedMeasurements = lc($mappingEDR -> {'Extended_Measurement'});
	my $dataStoragePath;

	#--------------------------------------------------------------
    # Deployment crash injection until all but 2 records are filled
    #
	S_teststep("Inject so many '$tcpar_DeploymentCrashCode' crashes that two empty records are left.", 'AUTO_NBR');
	$edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();
	my $numberOfDeploymentCrashes = $edrNumberOfEventsToBeStored - 2;
	
	if($numberOfDeploymentCrashes > 0){
        S_w2log(1, "Get crash settings for crash $tcpar_DeploymentCrashCode");
        my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_DeploymentCrashCode};
        my $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
        unless(defined $crashSettings) {
            S_set_error("Crash $tcpar_DeploymentCrashCode not available in result DB $tcpar_ResultDB. Test case aborted.");
            return;
        }
    
        S_w2log(1, "Set environments for deployment crash as per result DB");
        CSI_PrepareEnvironment($crashSettings, 'init_complete');
    
        for(my $crashNumber = 1; $crashNumber <= $numberOfDeploymentCrashes; $crashNumber++)
        {
            S_w2rep("Inject deployment crash $tcpar_DeploymentCrashCode $crashNumber");
    
            LC_ECU_Off();
            S_wait_ms('TIMER_ECU_OFF');
    
            S_w2log(1, "Prepare crash");
            CSI_LoadCrashSensorData2Simulator($crashSettings);
    
            S_w2log(1, "Power on ECU");
            LC_ECU_On();
            S_wait_ms('TIMER_ECU_READY');
            
            CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    		S_wait_ms(1000);
    
            S_w2log(1, "Inject Crashcode: $tcpar_DeploymentCrashCode ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");
            CSI_TriggerCrash();
            S_wait_ms($tcpar_WaitTime_ms);
        }
    
        S_teststep("Read all records of injected crashes.", 'AUTO_NBR');
        S_teststep_2nd_level("Power off and wait 10 seconds", 'AUTO_NBR');
        LC_ECU_Off();
        S_wait_ms('TIMER_ECU_OFF');
    
        $dataStoragePath = "$main::REPORT_PATH/"."TC_".S_get_TC_number()."_Complete_EDR_AfterPreparation";
    
        S_teststep_2nd_level("Power back on, and wait 10 seconds", 'AUTO_NBR');
        LC_ECU_On();
        S_wait_ms('TIMER_ECU_READY');
        PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');
        S_wait_ms(2000);
 
		if ( lc( $tcpar_read_NHTSAEDR) eq 'yes' ) {
			EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
										"CrashLabel" => "Complete_EDR_AfterPreparation",
										"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
										"StoragePath" => $dataStoragePath,
										"OnlyDump" => "true",
										"read_EDRType"=>'NHTSA')
		}
		if (lc($tcpar_read_CHINAEDR) eq 'yes'){
			$edrNumberOfEventsToBeStored=3;
			EDR_ReadAndStoreAllRecords ("DiagType" =>  $ChinaEDR_diagType,
										"CrashLabel" =>"Complete_EDR_AfterPreparation",
										"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
										"StoragePath" => $dataStoragePath,
										"OnlyDump" => "true",
										"read_EDRType"=>'CHINA');
	
		}								
	}


	S_teststep("Power down ECU", 'AUTO_NBR');
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	#--------------------------------------------------------------
    # Crash injection of three crashes with different severity 
    #    - only those two with highest priority will be stored!
    #
	$crashInjectionInfo_href = {
		'1' => {'Crashcode' => $tcpar_Crashcode1,
				'Switch1_State' => $tcpar_Switch1_State1,
				'Switch2_State' => $tcpar_Switch2_State1,
				'CrashTimeZero_ms'=> $tcpar_Crash1_TimeZero_ms},
		'2' => {'Crashcode' => $tcpar_Crashcode2,
				'Switch1_State' => $tcpar_Switch1_State2,
				'Switch2_State' => $tcpar_Switch2_State1,
				'CrashTimeZero_ms'=> $tcpar_Crash2_TimeZero_ms},
		'3' => {'Crashcode' => $tcpar_Crashcode3,
				'Switch1_State' => $tcpar_Switch1_State2,
				'Switch2_State' => $tcpar_Switch2_State2,
				'CrashTimeZero_ms'=> $tcpar_Crash3_TimeZero_ms},
	};

	$dataStoragePath = "$main::REPORT_PATH/"."TC_".S_get_TC_number()."_Complete_EDR_AfterOverwriting";
	unless(-e $dataStoragePath) {
		mkdir($dataStoragePath) || return;
	}

	foreach my $crashNumber (sort {$a <=> $b} keys %{$crashInjectionInfo_href})
	{
		S_w2rep("");
		S_w2rep("---- Crash $crashNumber ----", 'magenta');
		my $thisCrashcode = $crashInjectionInfo_href -> {$crashNumber} -> {'Crashcode'};

		S_w2log(1, "Get crash settings for crash $thisCrashcode");
	    my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $thisCrashcode};
		my $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
        unless(defined $crashSettings) {
            S_set_error("Crash $thisCrashcode not available in result DB $tcpar_ResultDB. Test case aborted.");
            return;
        }

        S_teststep("Prepare crash '$thisCrashcode'", 'AUTO_NBR');
        CSI_LoadCrashSensorData2Simulator($crashSettings);

		S_teststep("Power up ECU", 'AUTO_NBR');
		LC_ECU_On();
		S_wait_ms('TIMER_ECU_READY');

        S_w2log(1, "Set environments for deployment crash as per result DB");
        CSI_PrepareEnvironment($crashSettings, 'init_complete');
        
        CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    	S_wait_ms(1000);

        S_teststep("--- SWITCH STATES CRASH $crashNumber ---", 'NO_AUTO_NBR');
		my $switch1_State = $crashInjectionInfo_href -> {$crashNumber} -> {'Switch1_State'};
		my $switch2_State = $crashInjectionInfo_href -> {$crashNumber} -> {'Switch2_State'};
		S_teststep("Set '$tcpar_Switch1' to state '$switch1_State'", 'AUTO_NBR', "set_switch1_crash_$crashNumber"); #measurement 1
		my ( $result, $state_value, $state_unit );
		# Switch 1
        ( $result, $state_value, $state_unit ) = SYC_SWITCH_get_state( $tcpar_Switch1, $switch1_State );
        LC_SetResistance( $tcpar_Switch1, $state_value )
            if ( $state_unit eq 'R' );
        LC_SetCurrent( $tcpar_Switch1, $state_value )
            if ( $state_unit eq 'I' );

		# Switch 2
        S_teststep("Set '$tcpar_Switch2' to '$switch2_State'", 'AUTO_NBR', "set_switch2_crash_$crashNumber"); #measurement 1
        ( $result, $state_value, $state_unit ) = SYC_SWITCH_get_state( $tcpar_Switch2, $switch2_State );
        LC_SetResistance( $tcpar_Switch2, $state_value )
            if ( $state_unit eq 'R' );
        LC_SetCurrent( $tcpar_Switch2, $state_value )
            if ( $state_unit eq 'I' );
		
		S_w2log(1, "Wait 3 sec until switch state is set.");
		S_wait_ms(3000);
		
		S_teststep("Start recording of fire times.", 'AUTO_NBR');
	    LC_MeasureTraceDigitalStart();

		S_teststep("Inject '$thisCrashcode' ", 'AUTO_NBR');
		CSI_TriggerCrash();
		if($crashNumber == $tcpar_AutarkyCrashNumber and $tcpar_Autarky eq 'true') {
			S_teststep("Cut power at T0 of crash $crashNumber", 'AUTO_NBR');
			my $autarkyCrashTimeZero = $crashInjectionInfo_href -> {$tcpar_AutarkyCrashNumber} -> {CrashTimeZero_ms};
			my @allIncidentsTimeZero = split('_', $autarkyCrashTimeZero);
			my $firstTimeZero_ms = $allIncidentsTimeZero[0];
			S_wait_ms($firstTimeZero_ms);
			LC_ECU_Off();
		}

		S_teststep("Wait '$tcpar_WaitTime_ms'", 'AUTO_NBR');
		S_wait_ms($tcpar_WaitTime_ms);

		S_teststep("Stop recording of fire times.", 'AUTO_NBR'); #measurement 2
	    LC_MeasureTraceDigitalStop();
		$crashInjectionInfo_href -> {$crashNumber} -> {'FireTimes'} = LC_MeasureTraceDigitalGetValues();
		EVAL_dump2UNV( $crashInjectionInfo_href -> {$crashNumber} -> {'FireTimes'}, "$dataStoragePath/LCT_Measurement_".S_get_TC_number()."_$thisCrashcode.txt.unv" );
		my $squibLabels_aref;
		foreach my $lctTimeStamp (keys %{$crashInjectionInfo_href -> {$crashNumber} -> {'FireTimes'}})
		{
			foreach my $squib (keys %{$crashInjectionInfo_href -> {$crashNumber} -> {'FireTimes'} -> {$lctTimeStamp}})
			{
				push(@{$squibLabels_aref}, $squib);
			}
			last;
		}

		if(defined $squibLabels_aref) {
			S_w2rep("Add fire times for crash $thisCrashcode");
			EDR_addFireTimesToCrashHandler ("LCT_Measurement" => $crashInjectionInfo_href -> {$crashNumber} -> {'FireTimes'},
											"SquibLabels" => $squibLabels_aref,
											"CrashLabel"  => $thisCrashcode,
											"StoragePath" => $dataStoragePath);
		}
		else {
			S_w2rep("No squibs deployed during crash.");
		}

		if($extendedMeasurements eq 'enabled' and $crashNumber != 3){		
			S_w2rep("Additional measurement: Read all records after crash $crashNumber");
			PD_ECUlogin();
			S_wait_ms(2000);
		
			if ( lc( $tcpar_read_NHTSAEDR) eq 'yes' ) {
				EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
											"CrashLabel" => "Complete_EDR_After_Crash_$crashNumber",
											"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
											"StoragePath" => "$main::REPORT_PATH/"."TC_".S_get_TC_number()."_Complete_EDR_After_Crash_$crashNumber",
											"read_EDRType"=>'NHTSA')
			}
			if (lc($tcpar_read_CHINAEDR) eq 'yes'){
				$edrNumberOfEventsToBeStored=3;
				EDR_ReadAndStoreAllRecords ("DiagType" =>  $ChinaEDR_diagType,
											"CrashLabel" =>"Complete_EDR_After_Crash_$crashNumber",
											"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
											"StoragePath" => "$main::REPORT_PATH/"."TC_".S_get_TC_number()."_Complete_EDR_After_Crash_$crashNumber",
											"read_EDRType"=>'CHINA');
			}						
		}	

		if($crashNumber != 3 or $tcpar_Autarky eq 'false') {
			S_teststep("Power down ECU", 'AUTO_NBR');
			LC_ECU_Off();
			S_wait_ms('TIMER_ECU_OFF');
		}
	}

	#--------------------------------------------------------------
    # Read final crash recorder
    #
	S_teststep("Power up ECU and read all records after injection of all crashes.", 'AUTO_NBR');
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');
	if (defined $tcpar_COMsignalsAfterCrash){
		foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
		{				
			my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
			S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
			COM_setSignalState($signal,$dataOnCOM);	
		}
	}

    PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');	
	S_wait_ms(2000);

	if ( lc( $tcpar_read_NHTSAEDR) eq 'yes' ) {
				EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
											"CrashLabel" => "Complete_EDR_AfterOverwriting",
											"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
											"StoragePath" =>$dataStoragePath,
											'Supplier_EDID' => $tcpar_SupplierEDID,
											"read_EDRType"=>'NHTSA')
	}
	if (lc($tcpar_read_CHINAEDR) eq 'yes'){
		$edrNumberOfEventsToBeStored=3;
		EDR_ReadAndStoreAllRecords ("DiagType" =>  $ChinaEDR_diagType,
									"CrashLabel" =>"Complete_EDR_AfterOverwriting",
									"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
									"StoragePath" => $dataStoragePath,
									"read_EDRType"=>'CHINA');
	
	}

		
	return 1;
}

sub TC_evaluation {
	#--------------------------------------------------------------
    # Get record number in diag service for high prio 1 and 2 crash
    #
	my $storageOrder = EDR_getStorageOrder();
	return unless($storageOrder);

    if($storageOrder eq 'PhysicalOrder' and not defined $tcpar_HighPriority_Crash1_RecordNbr){
        S_set_error("For physical reporting order, record number for high prio crash 1 and 2 must be given as parameter!.\n".
                    "Please define: HighPriority_Crash1_RecordNbr and HighPriority_Crash2_RecordNbr");
        return;
    }

	my $recordNumberHighPrio1;
	if($tcpar_HighPriority_Crash1_RecordNbr){
	    $recordNumberHighPrio1 = $tcpar_HighPriority_Crash1_RecordNbr;
	}
	else {
        $recordNumberHighPrio1 = 2 if ($storageOrder eq 'MostRecentFirst');
        $recordNumberHighPrio1 = $edrNumberOfEventsToBeStored - 1 if ($storageOrder eq 'MostRecentLast');	    
	}

    if($storageOrder eq 'PhysicalOrder' and not defined $tcpar_HighPriority_Crash2_RecordNbr){
        S_set_error("For physical reporting order, record number for high prio crash 1 and 2 must be given as parameter!.\n".
                    "Please define: HighPriority_Crash1_RecordNbr and HighPriority_Crash2_RecordNbr");
        return;
    }

	my $recordNumberHighPrio2;
    if($tcpar_HighPriority_Crash2_RecordNbr){
        $recordNumberHighPrio2 = $tcpar_HighPriority_Crash2_RecordNbr;
    }
    else {
    	$recordNumberHighPrio2 = 1 if ($storageOrder eq 'MostRecentFirst');
    	$recordNumberHighPrio2 = $edrNumberOfEventsToBeStored if ($storageOrder eq 'MostRecentLast');
    }

	S_w2rep("High Prio crash 1 ($tcpar_HighPriority_Crash1) is expected in record $recordNumberHighPrio1");
	S_w2rep("High Prio crash 2 ($tcpar_HighPriority_Crash2) is expected in record $recordNumberHighPrio2");

	my $crashNumberMapping_href = {
		$tcpar_Crashcode1 => 1,
		$tcpar_Crashcode2 => 2,
		$tcpar_Crashcode3 => 3,
	};

	#--------------------------------------------------------------
    # Check whether the right 2 crashes out of three have been stored
    #
	foreach my $recordNbr (1..$edrNumberOfEventsToBeStored)
	{
		my ($thisCrashCode, $crashExpectedInRecordNbr, $multiEventIncidentNumber, $incident);
		my @highPriorityCrash1 = split(/__/, $tcpar_HighPriority_Crash1);
		my @highPriorityCrash2 = split(/__/, $tcpar_HighPriority_Crash2);

		if($recordNbr == $recordNumberHighPrio1){
			$thisCrashCode = $highPriorityCrash1[0];
			$crashExpectedInRecordNbr = $recordNumberHighPrio1;
			$incident = 'n/a';
			if(defined $highPriorityCrash1[1]) {
				my @multiEventIncidentNumber_array = split(/Incident/, $highPriorityCrash1[1]);
				$multiEventIncidentNumber = $multiEventIncidentNumber_array[1];
				$incident = $multiEventIncidentNumber;
				S_w2log(1, "Incident $multiEventIncidentNumber of multi event $thisCrashCode is expected to be stored")
			}	
		}
		elsif($recordNbr == $recordNumberHighPrio2){
			$thisCrashCode = $highPriorityCrash2[0];
			$crashExpectedInRecordNbr = $recordNumberHighPrio2;
			$incident = 'n/a';
			if(defined $highPriorityCrash2[1]) {
				my @multiEventIncidentNumber_array = split(/Incident/, $highPriorityCrash2[1]);
				$multiEventIncidentNumber = $multiEventIncidentNumber_array[1];
				$incident = $multiEventIncidentNumber;
				S_w2log(1, "Incident $multiEventIncidentNumber of multi event $thisCrashCode is expected to be stored")
			}	
		}
		else {
			S_w2rep("Record $recordNbr does not store high priority crash. No further evaluation done for this record.");
			next;
		}
		
		my $crashNumber = $crashNumberMapping_href -> {$thisCrashCode};

        S_teststep("----------------------------", 'NO_AUTO_NBR');
        S_teststep("CRASH $thisCrashCode, RECORD $crashExpectedInRecordNbr, (INCIDENT $incident)", 'NO_AUTO_NBR');

        S_teststep_expected_NOHTML("----------------------------",);
        S_teststep_expected_NOHTML("CRASH $thisCrashCode, RECORD $crashExpectedInRecordNbr, (INCIDENT $incident)",);

        S_teststep_detected_NOHTML("----------------------------",);
        S_teststep_detected_NOHTML("CRASH $thisCrashCode, RECORD $crashExpectedInRecordNbr, (INCIDENT $incident)",);

	    # Switch states
	    #
	    S_teststep_expected_NOHTML("--- SWITCH STATES CRASH $thisCrashCode (INCIDENT $incident) ---");
        S_teststep_detected_NOHTML("--- SWITCH STATES CRASH $thisCrashCode (INCIDENT $incident) ---");
        my $switchStateMapping = S_get_contents_of_hash_NOERROR(['Mapping_EDR', 'SwitchStates']);
        my $edrSwitchStates_href;
        if(defined $switchStateMapping){
	       foreach my $specifiedSwitchState (sort keys %{$switchStateMapping}){
	        	foreach my $edrSwitchState (@{$switchStateMapping -> {$specifiedSwitchState}}){
	        		$edrSwitchStates_href -> {$edrSwitchState} = $specifiedSwitchState;
	        	}
	        }        	
        }
 
		my $expectedSwitch1_State = $crashInjectionInfo_href -> {$crashNumber} -> {'Switch1_State'};
        S_teststep_expected("$tcpar_Switch1 -> $expectedSwitch1_State", "set_switch1_crash_$crashNumber"); #evaluation 1
	    my $switch1_EDIDdata = $record_handler -> GetDecodedEDID("CrashLabel" => "Complete_EDR_AfterOverwriting",
	    														 "RecordNumber" => $crashExpectedInRecordNbr,
	    														 "EDIDnr" => $tcpar_EDID_Switch1);
		if($main::opt_offline) {
			$switch1_EDIDdata = {"DataValue" => $expectedSwitch1_State, "DataUnit" => 'n/a'};
		}

		if(not defined $switch1_EDIDdata) {
			S_set_error("No data could be obtained for EDID $tcpar_EDID_Switch1 in record $crashExpectedInRecordNbr");
			return;
		}
		my $detectedSwitch1_State = $switch1_EDIDdata -> {"DataValue"};
		my $detectedSwitch1_State_Mapped;
		if(defined $edrSwitchStates_href){
			$detectedSwitch1_State_Mapped = $edrSwitchStates_href -> {$detectedSwitch1_State}				
		}
		$detectedSwitch1_State_Mapped = $detectedSwitch1_State unless(defined $detectedSwitch1_State_Mapped);

        S_teststep_detected("$tcpar_Switch1 -> $detectedSwitch1_State ($detectedSwitch1_State_Mapped)", "set_switch1_crash_$crashNumber");
        my $verdictSwitch1 = EVAL_evaluate_string ( "Switch_$tcpar_Switch1\_Record_$crashExpectedInRecordNbr",
        												$expectedSwitch1_State ,
        												$detectedSwitch1_State_Mapped  );
        S_teststep_mismatch("$tcpar_Switch1: $expectedSwitch1_State expected, $detectedSwitch1_State detected", "set_switch1_crash_$crashNumber") if($verdictSwitch1 eq 'VERDICT_FAIL');

		my $expectedSwitch2_State = $crashInjectionInfo_href -> {$crashNumber} -> {'Switch2_State'};
        S_teststep_expected("$tcpar_Switch2 -> $expectedSwitch2_State", "set_switch2_crash_$crashNumber");
	    my $switch2_EDIDdata = $record_handler -> GetDecodedEDID("CrashLabel" => "Complete_EDR_AfterOverwriting",
	    														 "RecordNumber" => $crashExpectedInRecordNbr,
	    														 "EDIDnr" => $tcpar_EDID_Switch2);
		if($main::opt_offline) {
			$switch2_EDIDdata = {"DataValue" => $expectedSwitch2_State, "DataUnit" => 'n/a'};
		}

		if(not defined $switch2_EDIDdata) {
			S_set_error("No data could be obtained for EDID $tcpar_EDID_Switch2 in record $crashExpectedInRecordNbr");
			return;
		}
		my $detectedSwitch2_State = $switch2_EDIDdata -> {"DataValue"};
		my $detectedSwitch2_State_Mapped;
		if(defined $edrSwitchStates_href){
			$detectedSwitch2_State_Mapped = $edrSwitchStates_href -> {$detectedSwitch2_State}				
		}
		$detectedSwitch2_State_Mapped = $detectedSwitch2_State unless(defined $detectedSwitch2_State_Mapped);
        S_teststep_detected("$tcpar_Switch2 -> $detectedSwitch2_State ($detectedSwitch2_State_Mapped)", "set_switch2_crash_$crashNumber");
        my $verdictSwitch2 = EVAL_evaluate_string ( "Switch_$tcpar_Switch2\_Record_$crashExpectedInRecordNbr",
        											$expectedSwitch2_State ,
        											$detectedSwitch2_State_Mapped  );
        S_teststep_mismatch("$tcpar_Switch2: $expectedSwitch2_State expected, $detectedSwitch2_State detected", "set_switch2_crash_$crashNumber") if($verdictSwitch2 eq 'VERDICT_FAIL');


	    # Fire times
	    #
		S_teststep("--- FIRE TIMES CRASH $thisCrashCode (INCIDENT $incident) ---", 'NO_AUTO_NBR');
        S_teststep("Evaluate fire times for crash $thisCrashCode (INCIDENT $incident)", 'NO_AUTO_NBR', "firetime_recording__record_$crashExpectedInRecordNbr");
        S_teststep_expected_NOHTML("--- FIRE TIMES CRASH $thisCrashCode (INCIDENT $incident) ---");
        S_teststep_detected_NOHTML("--- FIRE TIMES CRASH $thisCrashCode (INCIDENT $incident) ---");
		my ($squibVerdict, $allSquibs_href) = EDR_Eval_SquibFireTimes("CrashLabel" => "Complete_EDR_AfterOverwriting",
												   "CrashLabel_FireTimes" => $thisCrashCode,
		                                           "EDID_SquibLabels" => $tcpar_FireTime_EDIDs,
		                                           "CrashTimeZero_ms" => $crashInjectionInfo_href -> {$crashNumber} -> {'CrashTimeZero_ms'},
		                                           "FireTimeTolerance_ms" => 3,
												   "RecordNumber" => $crashExpectedInRecordNbr,
												   "MultiEventIncidentNumber" => $multiEventIncidentNumber);

		S_teststep_mismatch("Deployment times in EDR are not as measured", "firetime_recording__record_$crashExpectedInRecordNbr")
			if $squibVerdict eq 'VERDICT_FAIL';
	}

	return 1;
}

sub TC_finalization {

	# Erase EDR
    PD_ClearCrashRecorder();
    S_wait_ms(2000);
	
	# Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(10000);

	# Reset ECU    
    PD_ECUreset();
    S_wait_ms('TIMER_ECU_READY');

	# Read fault memory after clearing and erasing EDR
    PD_ReadFaultMemory();   
    
    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');
    
    S_w2rep("Clean up record and crash handler");
    $record_handler -> DeleteAllRecords();
    $crash_handler -> DeleteAllSources();

	return 1;
}


1;
