#### TEST CASE MODULE
package TC_EDR_DiagnosticInterfaceUnlock;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
#include further modules here
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use GENERIC_DCOM;
use LIFT_can_access;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;

use Data::Dumper;

##################################

our $PURPOSE = "<This test script checks for EDR unlock feature>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_DiagnosticInterfaceUnlock

=head1 PURPOSE

<This test script checks for EDR unlock feature>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Inject <crashcode>.

2. Power down ECU

3. Wait <wait_ms>

4. Power up ECU

5. Wait <wait_ms>

6. Read EDR record 

7. Read variable 'rb_dcc_HeaderPublic_st.RecordLockStatus_aen[0]'

8. Call <diag_service> if <EDR_UNLOCK_RECORD> is true

9. Read EDR record 

10.Read variable 'rb_dcc_HeaderPublic_st.RecordLockStatus_aen[0]'


I<B<Evaluation>>

1. -

2. -

3. -

4. -

5. 

6. EDR data is reported

7.'rb_dcc_HeaderPublic_st.RecordLockStatus_aen[0]' =<Expected_LockStatus1>

8

9. Check if <diag_service> was performed correctly (that record has been unlocked) depending on <EDR_UNLOCK_RECORD>

10.'rb_dcc_HeaderPublic_st.RecordLockStatus_aen[0]' =<Expected_LockStatus2>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'EDR_UNLOCK_RECORD' => 
	SCALAR 'Expected_LockStatus1' => 
	SCALAR 'Expected_LockStatus2' => 
	SCALAR 'purpose' => 
	SCALAR 'crashcode' => 
	SCALAR 'DiagType' => 
	SCALAR 'wait_ms' => 
	SCALAR 'ResultDB' => 
	SCALAR 'diag_service' => 
	SCALAR 'NbrOfRecordsExpected' => 


=head2 PARAMETER EXAMPLES

	purpose		 = 'check whether the diagnostic service  'EDRUnlock' unlocks EDR'
	# ---------- Stimulation ------------ 
	crashcode = 'Single_EDR_Front_Inflatable'
	DiagType = 'ProdDiag'
	wait_ms = 5000 #ms
	ResultDB='EDR'
	diag_service = 'EDRUnlock'
	# ---------- Evaluation ------------ 
	NbrOfRecordsExpected='1'
	
	EDR_UNLOCK_RECORD = 'true'
	Expected_LockStatus1='03'
	
	Expected_LockStatus2='02'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Crashcode1;
my $tcpar_Crashcode2;
my $tcpar_DiagType;
my $tcpar_wait_ms;
my $tcpar_ResultDB;
my $tcpar_diag_service;
my $tcpar_NbrOfRecordsExpected;
my $tcpar_EDR_UNLOCK_RECORD;
my $tcpar_Expected_LockStatus1;
my $tcpar_Expected_LockStatus2;
my $LockStatus1;
my $LockStatus2;
my $LockStatus3;
my $tcpar_Variable;
my $tcpar_COMsignalsAfterCrash;

################ global parameter declaration ###################
#add any global variables here
my ($crashSettings, $edrNumberOfEventsToBeStored);

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_Crashcode1 =  S_read_mandatory_testcase_parameter( 'crashcode1' );
	$tcpar_Crashcode2 =  S_read_mandatory_testcase_parameter( 'crashcode2' );
	$tcpar_DiagType =  S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_wait_ms =  S_read_mandatory_testcase_parameter( 'wait_ms' );
	$tcpar_ResultDB =  S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_ResultDB =  S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_diag_service =  S_read_mandatory_testcase_parameter( 'diag_service' );
	$tcpar_Variable =  S_read_mandatory_testcase_parameter( 'variable' );
	$tcpar_Expected_LockStatus1 =  S_read_mandatory_testcase_parameter( 'Expected_LockStatus1' );
	$tcpar_Expected_LockStatus2 =  S_read_mandatory_testcase_parameter( 'Expected_LockStatus2' );
	$tcpar_COMsignalsAfterCrash =  S_read_optional_testcase_parameter( 'COMsignalsAfterCrash','byref');

    $tcpar_EDR_UNLOCK_RECORD = SYC_EDR_get_UnlockRecord();
	unless(defined $tcpar_EDR_UNLOCK_RECORD){
		S_set_error("Not available in SYC - add or overwrite with Custlibrary Function");
        return;
    }
	 
    if ($tcpar_EDR_UNLOCK_RECORD eq "false"){
		S_set_error( "This testcase is not applicable for the project", 20 );
    	return undef;
    }
 
	return 1;
}

sub TC_initialization {

	S_teststep("Test setup preparation", 'AUTO_NBR');

	#--------------------------------------------------------------
    # PREPARE CRASH AND INITIALIZE EQUIPMENT
    #
	S_w2rep("Get crash settings for crash $tcpar_Crashcode1");
    my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode1};
    $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
    unless(defined $crashSettings) {
        S_set_error("Crash $tcpar_Crashcode1 not available in result DB $tcpar_ResultDB. Test case aborted.");
        return;
    }

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log(1, "Crashcode: $tcpar_Crashcode1, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");

	S_w2log(1, "Power on ECU");
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

    S_w2log(1, "Initialize CD and start CAN trace");
    GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start ( );

	S_w2log(1, "Set environments for crash as per result DB");
    CSI_PrepareEnvironment($crashSettings, 'init_complete');

	S_w2log(1, "Clear crash recorder");
    PD_ClearCrashRecorder();
    S_wait_ms(2000);

	S_w2log(1, "Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	S_w2log(1, "Read and evaluate fault memory before stimulation");
    my $faultsBeforeStimulation = PD_ReadFaultMemory();

    #Fault memory must be empty
    my $faultsVerdict = PD_evaluate_faults( $faultsBeforeStimulation, []);
    return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

	return 1;
}

sub TC_stimulation_and_measurement {

	#--------------------------------------------------------------
    # CRASH INJECTION
    #
	
	$edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();
	unless(defined $edrNumberOfEventsToBeStored){
		S_set_error("Not available in SYC - add or overwrite with Custlibrary Function");
        return;
    }

	S_teststep("Inject $edrNumberOfEventsToBeStored '$tcpar_Crashcode1' crash events", 'AUTO_NBR');

	foreach my $crash (1..$edrNumberOfEventsToBeStored)
	{
		# Prepare crash
        S_teststep_2nd_level("Prepare crash $crash", 'AUTO_NBR');
        LC_ECU_Off();
        S_wait_ms('TIMER_ECU_OFF');
    
        # Prepare crash
        CSI_LoadCrashSensorData2Simulator($crashSettings);
    
        # Power ON the ECU
        LC_ECU_On();
        S_wait_ms('TIMER_ECU_READY');
        
        CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    	S_wait_ms(1000);
        
        #--------------------------------------------------------------
		# CRASH INJECTION
		#
		S_teststep_2nd_level("Inject '$tcpar_Crashcode1' $crash", 'AUTO_NBR');
		CSI_TriggerCrash();
		S_wait_ms(10000);
    }

    if (defined $tcpar_COMsignalsAfterCrash){
        foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
        {               
            my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
            S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
            COM_setSignalState($signal,$dataOnCOM); 
        }
    }
    
	S_teststep("Reset ECU", 'AUTO_NBR');
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

	S_teststep("Read lock status via PD before unlocking", 'AUTO_NBR', 'read_variable_rb_before_unlock');			#measurement 2	
    $LockStatus1 = S_aref2dec(PD_ReadMemoryByName($tcpar_Variable), U8);

	S_teststep("Call '$tcpar_diag_service' to unlock locked EDR", 'AUTO_NBR');
	EDR_CD_UnlockEDR();   #This is dummy function since this feature is not present in coreassets
	S_wait_ms(2000);
								
	S_teststep("Read lock status via PD after '$tcpar_diag_service' is requested ", 'AUTO_NBR', 'read_variable_rb_after_unlock');			#measurement 4	
    $LockStatus2 = S_aref2dec(PD_ReadMemoryByName($tcpar_Variable), U8);
	
	S_teststep("Inject '$tcpar_Crashcode2' ", 'AUTO_NBR');
	#--------------------------------------------------------------
    # PREPARE CRASH AND INITIALIZE EQUIPMENT
    #
	S_w2rep("Get crash settings for crash $tcpar_Crashcode2");
    my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode2};
    $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
    unless(defined $crashSettings) {
        S_set_error("Crash $tcpar_Crashcode2 not available in result DB $tcpar_ResultDB. Test case aborted.");
        return;
    }

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log(1, "Crashcode: $tcpar_Crashcode2, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");

    S_wait_ms('TIMER_ECU_READY');

	S_w2log(1, "Set environments for crash as per result DB");
    CSI_PrepareEnvironment($crashSettings, 'init_complete');

    # Prepare crash
    S_teststep_2nd_level("Prepare crash $tcpar_Crashcode2", 'AUTO_NBR');
    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

    # Prepare crash
    CSI_LoadCrashSensorData2Simulator($crashSettings);

    # Power ON the ECU
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');
        
	#--------------------------------------------------------------
    # CRASH INJECTION
	CSI_TriggerCrash();
    S_wait_ms(10000);
	
    S_teststep("Read lock status via PD after injecting crash code 2 ", 'AUTO_NBR', 'read_variable_rb_after_injecting_crash');           #measurement 4  
	$LockStatus3 = S_aref2dec(PD_ReadMemoryByName($tcpar_Variable), U8);

	return 1;
}

sub TC_evaluation {

	my $LockStatusVerdict_BeforeUnlock = 'VERDICT_PASS';
	my $LockStatusVerdict_AfterUnlock = 'VERDICT_PASS';
	my $LockStatusVerdict_AfterCrash = 'VERDICT_PASS';
	
	S_teststep_expected("Read lock status via PD before unlocking, LOCK STATUS ='$tcpar_Expected_LockStatus1'", 'read_variable_rb_before_unlock');			#evaluation 2
	S_teststep_detected("LOCK STATUS =$LockStatus1", 'read_variable_rb_before_unlock');
	my $verdict = EVAL_evaluate_string ("Lock status before unlocking\_Evaluation", $tcpar_Expected_LockStatus1, $LockStatus1);
    $LockStatusVerdict_BeforeUnlock = 'VERDICT_FAIL' if $verdict eq 'VERDICT_FAIL';
	
	S_teststep_expected("Read lock status via PD after unlocking,LOCK STATUS ='$tcpar_Expected_LockStatus2'", 'read_variable_rb_after_unlock');			#evaluation 4
	S_teststep_detected("LOCK STATUS =$LockStatus2", 'read_variable_rb_after_unlock');
	my $verdict = EVAL_evaluate_string ("Lock status after unlocking\_Evaluation",$tcpar_Expected_LockStatus2, $LockStatus2);
    $LockStatusVerdict_AfterUnlock = 'VERDICT_FAIL' if $verdict eq 'VERDICT_FAIL';
	
	S_teststep_expected("Read lock status via PD after injecting another crash,LOCK STATUS ='$tcpar_Expected_LockStatus1'", 'read_variable_rb_after_injecting_crash');			#evaluation 6
	S_teststep_detected("LOCK STATUS =$LockStatus3", 'read_variable_rb_after_injecting_crash');
	my $verdict = EVAL_evaluate_string ("Lock status after injecting another crash\_Evaluation",$tcpar_Expected_LockStatus1, $LockStatus3);
    $LockStatusVerdict_AfterCrash = 'VERDICT_FAIL' if $verdict eq 'VERDICT_FAIL';
	
	return 1;
}

sub TC_finalization {

	# Erase EDR
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(2000);

	# Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	# Read fault memory after clearing and erasing EDR
    PD_ReadFaultMemory();   

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');
	return 1;
}


1;
