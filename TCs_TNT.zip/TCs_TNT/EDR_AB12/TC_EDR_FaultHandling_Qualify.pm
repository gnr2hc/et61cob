#### TEST CASE MODULE
package TC_EDR_FaultHandling_Qualify;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
#include further modules here
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use GENERIC_DCOM;
use LIFT_can_access;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;
use LIFT_FaultMemory;
use Data::Dumper;


##################################

our $PURPOSE = "This test script tests fault qualification when EDR is full";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_FaultHandling_Qualify

=head1 PURPOSE

<This test script tests fault qualification when EDR is full>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Inject (NumberOfEventsToBeStored - ThresholdValueForInternalError) <Crashcode> crash events.

2. Read fault memory.


I<B<Evaluation>>

1. -

2. Check for fault <faultExpected>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Crashcode' => 
	SCALAR 'faultExpected' => 
	SCALAR 'purpose' => 
	SCALAR 'crashtype' => 
	SCALAR 'DiagType' => 
	SCALAR 'ResultDB' => 
	SCALAR 'WaitTime_ms' => 
	SCALAR 'NumerOfEventsToBeStored' => 
	SCALAR 'ThresholdValueForInternalError' => 


=head2 PARAMETER EXAMPLES

	purpose		 = 'Check that fault <Test Heading Head> is qualified after injecting sufficient number of crashes.'
	# ---------- Stimulation ------------ 
	DiagType = 'ProdDiag'
	ResultDB = 'EDR' # defined in CREIS project constants - will be set to 'DEFAULT' if not given
	WaitTime_ms = 15000
	#NumerOfEventsToBeStored = <Fetch {V_RefType2_B_Sample} {([1-6])}> 
	NumerOfEventsToBeStored = 2
	#ThresholdValueForInternalError= <Fetch {V_RefType2_B_Sample} {([1-2])}> 
	ThresholdValueForInternalError= 1
	# ---------- Evaluation ------------ 
	Crashcode='Single_EDR_Front_Inflatable'
	
	faultExpected = %('rb_edr_DataAreaFull_flt'=>'0xAF')

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_crashtype;
my $tcpar_DiagType;
my $tcpar_ResultDB;
my $tcpar_WaitTime_ms;
my $tcpar_NumerOfEventsToBeStored;
my $tcpar_ThresholdValueForInternalError;
my $tcpar_Crashcode;
my $tcpar_faultExpected;
my $tcpar_faultstatus;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_OptionalFaults_aref;

################ global parameter declaration ###################
#add any global variables here
my ($crashSettings, $edrNumberOfEventsToBeStored,$edrThresholdValueForInternalError,$faultsBeforeLastCrashInjection,$faultsAfterLastCrashInjection);

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_DiagType =  S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_ResultDB =  S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_WaitTime_ms =  S_read_mandatory_testcase_parameter( 'WaitTime_ms' );
	$tcpar_Crashcode =  S_read_mandatory_testcase_parameter( 'Crashcode' );
	$tcpar_faultExpected =  S_read_mandatory_testcase_parameter( 'faultExpected', 'byref' );
	$tcpar_faultstatus =  S_read_optional_testcase_parameter( 'FltStatus');
	$tcpar_COMsignalsAfterCrash =  S_read_optional_testcase_parameter( 'COMsignalsAfterCrash','byref');
    $tcpar_OptionalFaults_aref = S_read_optional_testcase_parameter( 'OptionalFaults_List','byref');
    unless(defined $tcpar_OptionalFaults_aref){
        $tcpar_OptionalFaults_aref = [];
    }

	return 1;
}

sub TC_initialization {

	S_teststep("Test setup preparation", 'AUTO_NBR');

	#--------------------------------------------------------------
    # PREPARE CRASH AND INITIALIZE EQUIPMENT
    #
	S_w2rep("Get crash settings for crash $tcpar_Crashcode");
    my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode};
    $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
    unless(defined $crashSettings) {
        S_set_error("Crash $tcpar_Crashcode not available in result DB $tcpar_ResultDB. Test case aborted.");
        return;
    }
	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log(1, "Crashcode: $tcpar_Crashcode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");

	S_w2log(1, "Power on ECU");
    LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

    S_w2log(1, "Initialize CD and start CAN trace");
    GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start ( );
    
    # Set environment settings for crash
    S_w2log(1, "Set environments for crash as per result DB");
    CSI_PrepareEnvironment($crashSettings, 'init_complete');
    S_wait_ms(2000);

	S_w2log(1, "Clear crash recorder");
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(2000);

	S_w2log(1, "Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	S_w2log(1, "Read and evaluate fault memory before stimulation");
    # read fault memory
    my $faultsBeforeStimulation = LIFT_FaultMemory -> read_fault_memory('Bosch');

    #Fault memory must be empty
    my $faultsVerdict = $faultsBeforeStimulation -> evaluate_faults({});
    S_w2rep("Faults verdict: $faultsVerdict");
    return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

	return 1;
}

sub TC_stimulation_and_measurement {
	
	$edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();
	unless(defined $edrNumberOfEventsToBeStored){
        S_set_error("Not available in SYC - add or overwrite with Custlibrary Function");
        return;
    }
	
	$edrThresholdValueForInternalError = SYC_EDR_get_ThresholdValueForInternalError();
	unless(defined $edrThresholdValueForInternalError){
        S_set_error("Not available in SYC - add or overwrite with Custlibrary Function");
        return;
    }
	S_teststep("Inject ($edrNumberOfEventsToBeStored-$edrThresholdValueForInternalError) '$tcpar_Crashcode' crash events", 'AUTO_NBR');

	my $CrashCount =1;
	while ($CrashCount <= ($edrNumberOfEventsToBeStored-$edrThresholdValueForInternalError)){
		# Prepare crash
        CSI_LoadCrashSensorData2Simulator($crashSettings);
		S_wait_ms(1000); 
		
		CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    	S_wait_ms(1000);
		#--------------------------------------------------------------
		# CRASH INJECTION
		#
		S_teststep("Inject '$tcpar_Crashcode' $CrashCount time.", 'AUTO_NBR');
		S_w2rep("count=$CrashCount");
			if  ($CrashCount == ($edrNumberOfEventsToBeStored-$edrThresholdValueForInternalError)){
				S_teststep("Read fault memory before last crash injection", 'AUTO_NBR', 'read_fault_memory_before_last_crash_injection');
				$faultsBeforeLastCrashInjection = LIFT_FaultMemory -> read_fault_memory('Primary');
			}
		CSI_TriggerCrash();
		S_wait_ms(10000);
		$CrashCount++;
    }

	if (defined $tcpar_COMsignalsAfterCrash){
		foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
		{				
			my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
			S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
			COM_setSignalState($signal,$dataOnCOM);	
		}
	}	

	# This step is done in order to clear LCT of stored values
	S_teststep("Read fault memory", 'AUTO_NBR', 'read_fault_memory_after_last_crash_injection');			#measurement 1
    $faultsAfterLastCrashInjection = LIFT_FaultMemory -> read_fault_memory('Primary');

    my $dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_FaultHandling_".$tcpar_Crashcode;
	my $edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();
	PD_ECUlogin();
	EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
								"CrashLabel" => $tcpar_Crashcode,
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								);

 
	return 1;
}

sub TC_evaluation { 
 	
	my $faultname;
	
	# 'TEMP_OPTIONAL_FAULTS' can have all other faults except "data area fault". This is declared in project constant.pm
	my $expected_faults_before_crash_href = {'mandatory' => [ ],'optional' => $tcpar_OptionalFaults_aref,};
	$faultsBeforeLastCrashInjection -> evaluate_faults( $expected_faults_before_crash_href,
														'read_fault_memory_before_last_crash_injection');
	
	if (%$tcpar_faultExpected){
		#GeneralStatus
		my $expected_faults_after_crash_href = {
     		'optional' => $tcpar_OptionalFaults_aref,
		};
		
		foreach my $faultName (keys %{$tcpar_faultExpected}){
			$expected_faults_after_crash_href -> {'mandatory'} -> {$faultName} = {
				'RawStatus' => hex($tcpar_faultExpected->{$faultName}),
			};
		}
		$faultsAfterLastCrashInjection -> evaluate_faults( $expected_faults_after_crash_href,
														'read_fault_memory_after_last_crash_injection');
	}
	else{
		$faultsBeforeLastCrashInjection -> evaluate_faults( $expected_faults_before_crash_href,
														'read_fault_memory_after_last_crash_injection');
	}
    
	return 1;
}

sub TC_finalization {

	# Erase EDR
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(2000);

	# Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(10000);

	# Read fault memory after clearing and erasing EDR
    PD_ReadFaultMemory();   

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');
	return 1;
}


1;
