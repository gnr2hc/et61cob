#### TEST CASE MODULE
package TC_EDR_Power_Dependency;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
#include further modules here
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use GENERIC_DCOM;
use LIFT_can_access;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;
use Data::Dumper;

##################################

our $PURPOSE = "<This testscript checks behaviour of extended events in high and low voltage>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_Power_Dependency

=head1 PURPOSE

<This testscript checks behaviour of extended events in high and low voltage>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1.Set power supply to <powerSupply >

2. Inject multi-crash <Crashcode>consisting of closely followed <crash1>, <crash2> and <crash3> (all in one crash file to achieve timing)

3. Wait <wait_ms>

4. Read crash recorder.


I<B<Evaluation>>

1. -

2. -

3. -

4. Second crash telegram must contain deployment times of second and third crash if <EDR_ENABLE_EXT_EV>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Crashcode' => 
	SCALAR 'CrashT0_ms' => 
	HASH 'SquibNames' => 
	SCALAR 'purpose' => 
	SCALAR 'powerSupply' => 
	SCALAR 'ResultDB' => 
	SCALAR 'EDR_ENABLE_EXT_EV' => 
	SCALAR 'wait_ms' => 
	SCALAR 'DiagType' => 
	HASH 'EDIDs_CT1' => 
	HASH 'EDIDs_CT2' => 
	HASH 'EDIDs_CT3' => 
	HASH 'CompareValues' => 
	HASH 'FireTime_EDIDs' => 


=head2 PARAMETER EXAMPLES

	purpose		 = 'check whether EDR functionality is independent from changes in power supply'
	
	# ---------- Stimulation ------------ 
	
	powerSupply = <Test Heading Tail>
	
	ResultDB = 'EDR' # defined in CREIS project constants - will be set to 'DEFAULT' if not given
	
	#data from SYC
	#EDR_ENABLE_EXT_EV = '<Fetch {V_RefType2_B_Sample}{(true|false)}>'
	EDR_ENABLE_EXT_EV = 'true' #km/h
	
	# general
	wait_ms = 5000 #ms
	DiagType = 'ProdDiag'
	NumberOfIncidents='3'
	
	# ---------- Evaluation ------------ 
	
	CompareValues = %('61' => 'FireTimeGreaterThanZero', '51' => 'FireTimeGreaterThanZero', '1000' => 'completed successfully', '998' => 'completed successfully')
	
	FireTime_EDIDs = %('51' => 'AB1FD' , '52' => 'AB2FD', '53' => 'AB3FD', '56' => 'AB1FP', '57' =>'AB2FP', '58' => 'AB3FP', '63' => 'BT1FD', '108' => 'BT1FC', '67' => 'BT1FP', '109' => 'BT2FD', '110' => 'BT2FP', '111' => 'BT2FC', '147' => 'BT1RC', '61' => 'SA1FD', '65' => 'SA1FP', '101' => 'KA1FD', '102' => 'KA1FP', '115' => 'ALLFD', '116' => 'ALLFP')
	Crashcode='Multi_EDR_Extended_Front_ND_Side_AD_Front_AD'
	CrashT0_ms = '43.76_139.76'
	

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_powerSupply;
my $tcpar_ResultDB;
my $tcpar_wait_ms;
my $tcpar_DiagType;
my $tcpar_CompareValues;
my $tcpar_Crashcode;
my $tcpar_CrashT0_ms;
my $tcpar_FireTime_EDIDs;
my $tcpar_NumberOfIncidents;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_FireTime_Tolerance;
my $tcpar_RecordIncidentMapping_href;
my $tcpar_MeHandlingType = 'tbd';
my $tcpar_PowerGlitchDuration_ms;
my $tcpar_read_NHTSAEDR;
my $tcpar_read_CHINAEDR;

################ global parameter declaration ###################
#add any global variables here
my($edrNumberOfParallelEventsToBeStored);
my ($record_handler, $crash_handler, $crashSettings, $edrNumberOfEventsToBeStored,$ChinaEDR_diagType);

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_powerSupply =  S_read_mandatory_testcase_parameter( 'powerSupply' );
	if($tcpar_powerSupply eq 'PowerGlitch'){
        $tcpar_PowerGlitchDuration_ms =  S_read_mandatory_testcase_parameter( 'PowerGlitchDuration_ms' );	    
	}
	$tcpar_ResultDB =  S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_NumberOfIncidents =  S_read_mandatory_testcase_parameter( 'NumberOfIncidents' );
	$tcpar_wait_ms =  S_read_mandatory_testcase_parameter( 'wait_ms' );
	$tcpar_DiagType =  S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_FireTime_Tolerance =  S_read_mandatory_testcase_parameter( 'FireTime_Tolerance' );
	$tcpar_Crashcode =  S_read_mandatory_testcase_parameter( 'Crashcode' );
	$tcpar_CrashT0_ms =  S_read_mandatory_testcase_parameter( 'CrashT0_ms' );
	$tcpar_CompareValues =  S_read_mandatory_testcase_parameter( 'CompareValues', 'byref' );
	$tcpar_FireTime_EDIDs =  S_read_optional_testcase_parameter( 'FireTime_EDIDs' , 'byref');
	if(not defined $tcpar_FireTime_EDIDs){
		S_w2log(1, "Get fire time labels from EDR mapping");
		my $fireTimeLabelMapping = S_get_contents_of_hash(['Mapping_EDR', 'SquibLabelMapping']);
		%{$tcpar_FireTime_EDIDs} = reverse %{$fireTimeLabelMapping};
	}
	$tcpar_COMsignalsAfterCrash =  S_read_optional_testcase_parameter( 'COMsignalsAfterCrash','byref');
	

	$edrNumberOfParallelEventsToBeStored = SYC_EDR_get_NumberOfParallelEvents();
	unless(defined $edrNumberOfParallelEventsToBeStored){
		S_set_error("Not available in SYC - add or overwrite with Custlibrary Function");
        return;
    }
	
	# Check multi-event behavior
	if($tcpar_NumberOfIncidents > $edrNumberOfParallelEventsToBeStored){
		my ($result_ME, $meHandlingType) = SYC_EDR_get_MultiEventHandling();
		unless($result_ME) {
			S_set_error("Getting EDR Multi Event Handling Type from SYC was not successful. Evaluation will be aborted.", 110);
			return;
		}
		$tcpar_MeHandlingType = $meHandlingType;
		if($meHandlingType eq 'EDR_MEHandlingType_Drop'){
			$tcpar_RecordIncidentMapping_href = S_read_mandatory_testcase_parameter( 'RecordIncidentMapping', 'byref' );
			#'Record_1' => 'Incident_2'
		}
	}
	$tcpar_read_NHTSAEDR=S_read_optional_testcase_parameter('read_NHTSAEDR');
	$tcpar_read_CHINAEDR=S_read_optional_testcase_parameter('read_CHINAEDR');
	
	if(not defined $tcpar_read_CHINAEDR) {
		$tcpar_read_NHTSAEDR = 'yes';
		$tcpar_read_CHINAEDR = 'no';
	}
	else {
		$tcpar_read_NHTSAEDR = 'no';
		my $storageOrder = EDR_getStorageOrder();
		return unless(defined $storageOrder);

		if($storageOrder eq 'PhysicalOrder'){
			$ChinaEDR_diagType= 'ProdDiag';  #In platform NHTSA and China EDR is read via proddiag
		}
		else {
			$ChinaEDR_diagType= 'CHINA_Payload';
		}
	}
	
	return 1;
}

sub TC_initialization {

	S_teststep("Test setup preparation", 'AUTO_NBR');

	#--------------------------------------------------------------
    # INITIALIZE RECORD AND CRASH HANDLER
    #    
	S_w2rep("Initialize Record and Crash Handler");
	$record_handler = EDR_init_RecordHandler() || return;
	$crash_handler  = EDR_init_CrashHandler() || return;

	#--------------------------------------------------------------
    # PREPARE CRASH AND INITIALIZE EQUIPMENT
    #
	S_w2rep("Get crash settings for crash $tcpar_Crashcode");
    my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode};
    $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
    unless(defined $crashSettings) {
        S_set_error("Crash $tcpar_Crashcode not available in result DB $tcpar_ResultDB. Test case aborted.");
        return;
    }

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log(1, "Crashcode: $tcpar_Crashcode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");

	S_w2log(1, "Power on ECU");
    LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');
   
    S_w2log(1, "Initialize CD and start CAN trace");
    GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start ( );

	S_w2log(1, "Set environments for crash as per result DB");
    CSI_PrepareEnvironment($crashSettings, 'init_complete');
    S_wait_ms(2000);

	S_w2log(1, "Clear crash recorder");
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(5000);

	S_w2log(1, "Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	S_w2log(1, "Read and evaluate fault memory before stimulation");
    my $faultsBeforeStimulation = PD_ReadFaultMemory();
    #Fault memory must be empty
    my $faultsVerdict = PD_evaluate_faults( $faultsBeforeStimulation, []);
    return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

	return 1;
}

sub TC_stimulation_and_measurement {

    # Prepare crash
    S_teststep("Prepare crash", 'AUTO_NBR');
    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

    # Prepare crash
    CSI_LoadCrashSensorData2Simulator($crashSettings);

    # Power ON the ECU
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');
    
    CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    S_wait_ms(1000);

	S_teststep("Set power supply to '$tcpar_powerSupply '", 'AUTO_NBR');
	my $tolerance = 0.5; #0.5Volt
	my $waitTimeUntilPowerGlitch_ms;
	if($tcpar_powerSupply eq 'HighVoltage'){
		(my $result, $tcpar_powerSupply) = SYC_POWERSUPPLY_get_HighVoltageDetectionLimit();
	}
	elsif($tcpar_powerSupply eq 'LowVoltage'){
		(my $result, $tcpar_powerSupply) = SYC_POWERSUPPLY_get_LowVoltageDetectionLimit();
		$tcpar_powerSupply = $tcpar_powerSupply + $tolerance;
	}
	elsif($tcpar_powerSupply eq 'PowerGlitch'){
	    my @crashT0_array = split(/_/, $tcpar_CrashT0_ms);
	    # power glitch between first and second event
	    my $firstIncidentStartTime = $crashT0_array[0];
	    my $secondIncidentStartTime = $crashT0_array[1];
	    $waitTimeUntilPowerGlitch_ms = ($firstIncidentStartTime + $secondIncidentStartTime) / 2;
	}
	else {
		S_set_error("Voltage defined is not �HighVoltage� or �LowVoltage�,Specify the correct label for voltage");
        return;
	}
	unless(defined $tcpar_powerSupply){
		S_set_error("Voltage range is not defined in SYC, hence testcase will not be executed");
        return;
    }
	
	if($tcpar_powerSupply ne 'PowerGlitch'){
        S_teststep_2nd_level("Voltage from SYC: '$tcpar_powerSupply' V (with 0.5V tolerance on low voltage end)", 'AUTO_NBR');
        LC_SetVoltage( $tcpar_powerSupply );
        S_wait_ms('TIMER_ECU_READY');	    
	}
	
	S_teststep("Start recording of fire times.", 'AUTO_NBR');
    LC_MeasureTraceDigitalStart();
	#--------------------------------------------------------------
	# CRASH INJECTION
	#
	S_teststep("Inject multi-crash '$tcpar_Crashcode'", 'AUTO_NBR');
	CSI_TriggerCrash();
	if($tcpar_powerSupply eq "PowerGlitch"){
	    S_teststep("Cut power $waitTimeUntilPowerGlitch_ms ms after Quate trigger and reconnect after $tcpar_PowerGlitchDuration_ms ms",
	               'AUTO_NBR');
	    my $powerGlitchDuration_us = $tcpar_PowerGlitchDuration_ms * 1000; 
	    S_wait_ms($waitTimeUntilPowerGlitch_ms);
        LC_LV124_E10('0.1R', $powerGlitchDuration_us); # cut power for 10ms -> 10000�s
	}

	S_teststep("Wait '$tcpar_wait_ms'", 'AUTO_NBR');
	S_wait_ms($tcpar_wait_ms);

    if (defined $tcpar_COMsignalsAfterCrash){
        foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
        {               
            my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
            S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
            COM_setSignalState($signal,$dataOnCOM); 
        }
        S_wait_ms(5000);
    }

    S_teststep("Reset ECU with normal voltage", 'AUTO_NBR');
	LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');
	LC_ECU_On();
	LC_SetVoltage(13.5 );
	S_wait_ms('TIMER_ECU_READY');
 
 	S_teststep("Stop recording of fire times", 'AUTO_NBR');
    LC_MeasureTraceDigitalStop();

	S_teststep("Read crash recorder.", 'AUTO_NBR', 'read_crash_recorder');			#measurement 1
	my $dataStoragePath = "$main::REPORT_PATH/"."TC_".S_get_TC_number()."_".$tcpar_Crashcode;

	$edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();

	unless(defined $edrNumberOfEventsToBeStored){
        S_set_error("Number of EDR records (NVM buffers) not available in SYC - add or overwrite with Custlibrary Function");
        return;
    }
		
	PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');
  				
	if ( lc( $tcpar_read_NHTSAEDR) eq 'yes' ) {
		EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
								"CrashLabel" =>$tcpar_Crashcode,
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								"read_EDRType"=>'NHTSA')
	}
	if (lc($tcpar_read_CHINAEDR) eq 'yes'){
		$edrNumberOfEventsToBeStored=3;
		EDR_ReadAndStoreAllRecords ("DiagType" =>  $ChinaEDR_diagType,
								"CrashLabel" =>  $tcpar_Crashcode,
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								"read_EDRType"=>'CHINA');
	}
		
	if(defined $tcpar_FireTime_EDIDs){
		S_teststep("Compare Deployment_EDIDs to LCT measurement.", 'AUTO_NBR', 'compare_deployment_edids'); #measurement 2
	    my $lct_Data = LC_MeasureTraceDigitalGetValues();

		# Get list of all measured squib labels
	    my $squibLabels_aref;

	    foreach my $time ( sort { $a <=> $b } keys %$lct_Data )
	    {
	    	foreach my $squibLabel (keys %{$lct_Data->{$time}})
	    	{
	    		push(@{$squibLabels_aref}, $squibLabel);
	    	}
	        last;
	    }

		EVAL_dump2UNV( $lct_Data, "$dataStoragePath/LCT_Measurement.txt.unv" );

		EDR_addFireTimesToCrashHandler("LCT_Measurement" => $lct_Data,
										"SquibLabels" => $squibLabels_aref,
										"CrashLabel"  => $tcpar_Crashcode,
										"StoragePath" => $dataStoragePath) if(defined $squibLabels_aref);		
	}
	return 1;
}

sub TC_evaluation {

	#--------------------------------------------------------------
    # NUMBER OF EXPECTED RECORDS
    #
    S_teststep("--------------------------------------------------------", 'NO_AUTO_NBR');
    S_teststep("NUMBER OF EXPECTED RECORDS", 'NO_AUTO_NBR');
    S_teststep_expected_NOHTML("--------------------------------------------------------");
    S_teststep_expected_NOHTML("NUMBER OF EXPECTED RECORDS");
    S_teststep_detected_NOHTML("--------------------------------------------------------");
    S_teststep_detected_NOHTML("NUMBER OF EXPECTED RECORDS");

	my $detectedNbrOfStoredRecords = 0;
	foreach my $recordNumber (1..$edrNumberOfEventsToBeStored){
		my $recordAvailable = $record_handler -> IsRecordAvailable("CrashLabel" => $tcpar_Crashcode, "RecordNumber"=> $recordNumber);
		$detectedNbrOfStoredRecords++ if ($recordAvailable);		
	}
	
	my $numberOfExpectedRecords;
	if($tcpar_NumberOfIncidents > $edrNumberOfParallelEventsToBeStored){
		$numberOfExpectedRecords = $edrNumberOfParallelEventsToBeStored;
	}
	else{
		$numberOfExpectedRecords = $tcpar_NumberOfIncidents;
	}

	S_teststep_expected("Expect $numberOfExpectedRecords records to be stored", 'read_crash_recorder'); #evaluation 1
	my $verdict= EVAL_evaluate_value("NumberOfRecords", $detectedNbrOfStoredRecords,'==', $numberOfExpectedRecords);
	S_teststep_detected("Number of stored records is $detectedNbrOfStoredRecords", 'read_crash_recorder');
	if ($verdict ne "VERDICT_PASS" and not $main::opt_offline){
		S_w2rep("Number of detected records is incorrect, no further EDID validation is done");
		return 1;
	}
	#--------------------------------------------------------------
    # FIRE TIMES
    #
    S_teststep("--------------------------------------------------------", 'NO_AUTO_NBR');
    S_teststep("DEPLOYMENT TIMES", 'NO_AUTO_NBR');
    S_teststep_expected_NOHTML("--------------------------------------------------------");
    S_teststep_expected_NOHTML("DEPLOYMENT TIMES");
    S_teststep_detected_NOHTML("--------------------------------------------------------");
    S_teststep_detected_NOHTML("DEPLOYMENT TIMES");

    if($tcpar_MeHandlingType eq 'EDR_MEHandlingType_Drop' and $tcpar_NumberOfIncidents > $edrNumberOfParallelEventsToBeStored){
		foreach my $recordNbr (1..$edrNumberOfParallelEventsToBeStored)
		{
	        S_teststep("Record $recordNbr", 'NO_AUTO_NBR');     
	        S_teststep_expected_NOHTML("Record $recordNbr");     
	        S_teststep_detected_NOHTML("Record $recordNbr");     
			S_teststep("Read all deployment times stored in record $recordNbr", 'AUTO_NBR', "read_firetime_edids_$recordNbr");			#measurement 1
			my $fireTimesFromIncidentNbr = $tcpar_RecordIncidentMapping_href -> {"Record_$recordNbr"};
			my @incidentNumbersSplit = split(/_/, $fireTimesFromIncidentNbr);
			S_w2rep("Fire times from incident $fireTimesFromIncidentNbr are stored in record $recordNbr");
	        $fireTimesFromIncidentNbr = $incidentNumbersSplit[1];

	        S_w2rep("Crash time zero: $tcpar_CrashT0_ms");
	        my ($squibVerdict, $allResults_href) = EDR_Eval_SquibFireTimes("CrashLabel" => $tcpar_Crashcode,
	                                                   "EDID_SquibLabels" => $tcpar_FireTime_EDIDs,
	                                                   "CrashTimeZero_ms" => $tcpar_CrashT0_ms, # For multi events: T01_T02, e.g. 12_500 
	                                                   "FireTimeTolerance_ms" => $tcpar_FireTime_Tolerance,
	                                                   "RecordNumber" => $recordNbr,
	                                                   "CrashLabel_FireTimes" => $tcpar_Crashcode,
	                                                   "MultiEventIncidentNumber" => $fireTimesFromIncidentNbr);
			
			S_teststep_mismatch("Deployment times in EDR Record $recordNbr are not as measured", "read_firetime_edids_$recordNbr") if $squibVerdict eq 'VERDICT_FAIL';
		}

    }
    else{
		my @crashTimesZero_array = split(/_/, $tcpar_CrashT0_ms);
		
		# create time zero of event
		my $crashT0_ms;
		foreach my $crashNumber (1..$numberOfExpectedRecords)
		{
		    my $t0Index = $crashNumber - 1;
			if ($crashNumber == 1){
				$crashT0_ms = $crashTimesZero_array[$t0Index];				
			}
			else{
				$crashT0_ms = $crashT0_ms."_".$crashTimesZero_array[$t0Index];		
			}
		}

		my ($squibVerdict, $allResults_href) = EDR_Eval_SquibFireTimes("CrashLabel" => $tcpar_Crashcode,
		                                           "EDID_SquibLabels" => $tcpar_FireTime_EDIDs,
		                                           "CrashTimeZero_ms" => $crashT0_ms,
		                                           "FireTimeTolerance_ms" => $tcpar_FireTime_Tolerance,
												   );
													   
	
		S_teststep_expected("Fire times stored in crash recorder should match with recorded fire times in LCT", 'compare_deployment_edids'); #evaluation 2
		S_teststep_detected("Fire times stored in crash recorder matches with recorded fire times in LCT", 'compare_deployment_edids') if $squibVerdict eq 'VERDICT_PASS';
		S_teststep_mismatch("Fire times stored in crash recorder does NOT match with recorded fire times in LCT", 'compare_deployment_edids') if $squibVerdict eq 'VERDICT_FAIL';
    	
    }
		
	# For multi event handling
	if($tcpar_NumberOfIncidents > $edrNumberOfParallelEventsToBeStored){		

        S_teststep("Check that for more incidents than RAM bufferst, correct values are stored for last incident", 'AUTO_NBR', 'compare_deployment_time'); #measurement 3

		my $rawValuesVerdict = 'VERDICT_PASS';

		my $storageOrder = EDR_getStorageOrder();		
		unless(defined $storageOrder) {
			S_set_error("Define 'StorageOrder' in EDR mapping! Must be 'MostRecentFirst' or 'MostRecentLast' or 'PhysicalOrder'");
			return;
		}
		
		if($storageOrder eq 'PhysicalOrder'){
		    S_set_warning("Storage order 'PhysicalOrder' will be treated as 'MostRecentFirst' raw value validation.");
            $storageOrder = 'MostRecentFirst';
		}

        my $recordNumber;
		$recordNumber = $edrNumberOfParallelEventsToBeStored if($storageOrder eq 'MostRecentLast');
		$recordNumber = 1 if($storageOrder eq 'MostRecentFirst');

		foreach my $rawEDID (keys %{$tcpar_CompareValues})
		{		
			my $expectedValue = $tcpar_CompareValues -> {$rawEDID};
			my $dataElement = $record_handler -> GetDataElementEDID( "EDIDnr" => $rawEDID,
																	 "RecordNumber" => $recordNumber,
																	 "CrashLabel" => $tcpar_Crashcode);

           S_teststep_2nd_level("EDID $rawEDID ($dataElement) record $recordNumber", 'AUTO_NBR', "EDID_$rawEDID"); #measurement 3
           S_teststep_expected_NOHTML("EDID $rawEDID ($dataElement) record $recordNumber"); #measurement 3
           S_teststep_detected_NOHTML("EDID $rawEDID ($dataElement) record $recordNumber"); #measurement 3

				
			my $edidData = $record_handler -> GetDecodedEDID("CrashLabel" => $tcpar_Crashcode, "RecordNumber" => $recordNumber,"EDIDnr" => $rawEDID );
			my $Detectedvalue = $edidData -> {"DataValue"};
		 
			unless(defined $Detectedvalue) {
				S_set_error("No data could be obtained for EDID $rawEDID in record $recordNumber.");
				next;
			}

           S_teststep_expected("$expectedValue", "EDID_$rawEDID"); #measurement 3
           S_teststep_detected("$Detectedvalue", "EDID_$rawEDID"); #measurement 3
		
            my $verdict;
			if ($expectedValue eq "FireTimeGreaterThanZero" or $expectedValue eq "GreaterThanZero"){
			    $expectedValue = 0;
				if($Detectedvalue =~ /[a-zA-Z]/) {
                    $verdict = EVAL_evaluate_string ( "EDID_$rawEDID($dataElement)\_Evaluation", $expectedValue, $Detectedvalue );
				}
				else{
					$verdict = EVAL_evaluate_value ( "EDID_$rawEDID($dataElement)\_Evaluation", $Detectedvalue,'>', $expectedValue );
				}
			}		
			else{
				$verdict = EVAL_evaluate_string ( "EDID_$rawEDID($dataElement)\_Evaluation", $expectedValue, $Detectedvalue );
			}
			$rawValuesVerdict = 'VERDICT_FAIL' if $verdict eq 'VERDICT_FAIL';
		}	
	}

	return 1;
}

sub TC_finalization {

	# Erase EDR
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(2000);

	# Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	# Read fault memory after clearing and erasing EDR
    PD_ReadFaultMemory(); 

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

	S_w2rep("Clean up record and crash handler");
    $record_handler -> DeleteAllRecords();
    $crash_handler -> DeleteAllSources();

	return 1;
}


1;
