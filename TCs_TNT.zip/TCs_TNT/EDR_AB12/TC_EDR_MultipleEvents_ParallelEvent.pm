#### TEST CASE MODULE
package TC_EDR_MultipleEvents_ParallelEvent;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
#include further modules here
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use GENERIC_DCOM;
use LIFT_can_access;
use FuncLib_EDR_Framework;
use FuncLib_TNT_SYC_INTERFACE;
use Data::Dumper;

##################################

our $PURPOSE = "<This test scripts checks the correct timing for parallel events>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_MultipleEvents_ParallelEvent

=head1 PURPOSE

<This test scripts checks the correct timing for parallel events>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Inject <Crashcode>

2. Wait <wait_ms>

3. Read Crash Recorder


I<B<Evaluation>>

1. -

2. -

3. There is only one CT expected; check correct timing focussing especially on correct reference to t0 depending on first incident and active algos.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Crashcode' => 
	HASH 'CompareValues_CT' => 
	SCALAR 'purpose' => 
	SCALAR 'crashtype' => 
	SCALAR 'Incident1' => 
	SCALAR 'Incident2' => 
	SCALAR 'dV_trigger_startAlgo' => 
	SCALAR 'DiagType' => 
	SCALAR 'ResultDB' => 
	SCALAR 'EDR_TRIGGER_THRESHOLD' => 
	SCALAR 'EDR_TRIGGER_THRESHOLD_TIME' => 
	SCALAR 'wait_ms' => 
	SCALAR 'expected_nr_of_records' => 
	LIST 'expected_active_algos' => 
	SCALAR 'expected_first_active_algo' => 
	SCALAR 'expected_second_active_algo' => 
	SCALAR 'AlgoStartTime_Tolerance' => 
	HASH 'COMsignalsAfterCrash' => 


=head2 PARAMETER EXAMPLES

	purpose		 = 'check crash record for correct timing, with special interest in t0 that depends on which crash was first'
	# ---------- Stimulation ------------ 
	crashtype = '<Test Heading Head>_<Test Heading 2>_<Test Heading Tail>'
	Incident1 = 'front'
	Incident2 = 'side'
	dV_trigger_startAlgo = 4
	DiagType = 'ProdDiag'
	ResultDB = 'EDR'

	# general
	wait_ms = 15000 #ms
	# ---------- Evaluation ------------ 
	expected_nr_of_records  = 1
	expected_active_algos = @('front', 'side')
	expected_first_active_algo = 'front'
	expected_second_active_algo = 'side'
	AlgoStartTime_Tolerance= '3'  #ms
	COMsignalsAfterCrash = %()
	Crashcode='Parallel_EDR_Front_ND_Side_Active_beforeFrontSoE'
	
	CompareValues_CT = %('4'=>'0','5'=>'10','48' =>  'DataNotAvailable', '45' => '1')  # Most recent first record

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_DiagType;
my $tcpar_ResultDB;
my $tcpar_wait_ms;
my $tcpar_expected_nr_of_records;
my $tcpar_AlgoStartTime_Tolerance;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_Crashcode;
my $tcpar_CompareValues_CT;
my $tcpar_Default_EDIDs;
my $tcpar_read_NHTSAEDR;
my $tcpar_read_CHINAEDR;
################ global parameter declaration ###################
#add any global variables here
my ($record_handler, $crashSettings, $edrNumberOfEventsToBeStored,$ChinaEDR_diagType);

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_DiagType =  S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_ResultDB =  S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_wait_ms =  S_read_mandatory_testcase_parameter( 'wait_ms' );
	$tcpar_expected_nr_of_records =  S_read_mandatory_testcase_parameter( 'expected_nr_of_records' );
	$tcpar_AlgoStartTime_Tolerance =  S_read_mandatory_testcase_parameter( 'AlgoStartTime_Tolerance' );
	$tcpar_COMsignalsAfterCrash =  S_read_optional_testcase_parameter( 'COMsignalsAfterCrash','byref');
	$tcpar_Crashcode =  S_read_mandatory_testcase_parameter( 'Crashcode' );
	$tcpar_CompareValues_CT =  S_read_optional_testcase_parameter( 'CompareValues_CT','byref' );
	$tcpar_Default_EDIDs = S_read_optional_testcase_parameter( 'Default_EDIDs', 'byref' );
	
	$tcpar_read_NHTSAEDR=S_read_optional_testcase_parameter('read_NHTSAEDR');
	$tcpar_read_CHINAEDR=S_read_optional_testcase_parameter('read_CHINAEDR');
	
	if(not defined $tcpar_read_CHINAEDR) {
		$tcpar_read_NHTSAEDR = 'yes';
		$tcpar_read_CHINAEDR = 'no';
	}
	else {
		$tcpar_read_NHTSAEDR = 'no';
		my $storageOrder = EDR_getStorageOrder();
		return unless(defined $storageOrder);

		if($storageOrder eq 'PhysicalOrder'){
			$ChinaEDR_diagType= 'ProdDiag';  #In platform NHTSA and China EDR is read via proddiag
		}
		else {
			$ChinaEDR_diagType= 'CHINA_Payload';
		}
	}


	return 1;
}

sub TC_initialization {

	S_teststep("Test setup preparation", 'AUTO_NBR');

	#--------------------------------------------------------------
    # INITIALIZE RECORD AND CRASH HANDLER
    #    
	S_w2rep("Initialize Record Handler");
	$record_handler = EDR_init_RecordHandler() || return;
	
	#--------------------------------------------------------------
    # PREPARE CRASH AND INITIALIZE EQUIPMENT
    #
	S_w2rep("Get crash settings for crash $tcpar_Crashcode");
    my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode};
    $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
    unless(defined $crashSettings) {
        S_set_error("Crash $tcpar_Crashcode not available in result DB $tcpar_ResultDB. Test case aborted.");
        return;
    }
	
	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log(1, "Crashcode: $tcpar_Crashcode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");

	S_w2log(1, "Power on ECU");
    LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

    S_w2log(1, "Initialize CD and start CAN trace");
    GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start ( );
    
	S_w2log(1, "Clear crash recorder");
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(2000);

	S_w2log(1, "Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);
	
	S_w2log(1, "Set environments for crash as per result DB");
    CSI_PrepareEnvironment($crashSettings, 'init_complete');
    S_wait_ms(2000);
	
	S_w2log(1, "Read and evaluate fault memory before stimulation");
    my $faultsBeforeStimulation = PD_ReadFaultMemory();

    #Fault memory must be empty
    my $faultsVerdict = PD_evaluate_faults( $faultsBeforeStimulation, []);
    return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

	return 1;
}

sub TC_stimulation_and_measurement {

	#--------------------------------------------------------------
    # CRASH PREPARATION
    #
	S_teststep("Prepare crash", 'AUTO_NBR');
    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

    # Prepare crash
    CSI_LoadCrashSensorData2Simulator($crashSettings);

    # Power ON the ECU
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

    CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    S_wait_ms(1000);
	#--------------------------------------------------------------
    # CRASH INJECTION
    #

	S_teststep("Inject '$tcpar_Crashcode'.", 'AUTO_NBR');
	CSI_TriggerCrash();
	S_teststep("Wait '$tcpar_wait_ms'", 'AUTO_NBR');
	S_wait_ms($tcpar_wait_ms);
	
	if (defined $tcpar_COMsignalsAfterCrash){
		foreach my $Signal (keys %{$tcpar_COMsignalsAfterCrash})
		{	
			S_w2rep("Signal=$Signal");		
			my $DataOnCOM = $tcpar_COMsignalsAfterCrash -> {$Signal};
			S_w2rep("DataOnCOM=$DataOnCOM");
			COM_setSignalState($Signal,$DataOnCOM);	
		}

	}
	
	#--------------------------------------------------------------
    # MEASUREMENTS
    #
	S_teststep("Read crash record", 'AUTO_NBR', 'read_crash_record');			#measurement 1
    my $dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_".$tcpar_Crashcode;

	$edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();
	unless(defined $edrNumberOfEventsToBeStored){
		S_set_error("'NumberOfEventsToBeStored' is not available in SYC - add or overwrite 'SYC_EDR_get_NumberOfEventsToBeStored' with Custlibrary Function");
        return;
    }

	PD_ECUlogin() if ($tcpar_DiagType eq 'ProdDiag');

	if ( lc( $tcpar_read_NHTSAEDR) eq 'yes' ) {
		EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
								"CrashLabel" => $tcpar_Crashcode,
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								"read_EDRType"=>'NHTSA')
	}
	if (lc($tcpar_read_CHINAEDR) eq 'yes'){
		$edrNumberOfEventsToBeStored=3;
		EDR_ReadAndStoreAllRecords ("DiagType" =>  $ChinaEDR_diagType,
								"CrashLabel" =>   $tcpar_Crashcode,
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								"read_EDRType"=>'CHINA');
	}	
	
	return 1;
}

sub TC_evaluation {

	#--------------------------------------------------------------
    # NUMBER OF EXPECTED RECORDS
    #
	S_w2rep("");
	S_w2rep("--------------------------------------------------------", 'purple');
	S_w2rep("NUMBER OF EXPECTED RECORDS", 'purple');
	my $detectedNbrOfStoredRecords = 0;
	for(my $recordNumber = 1; $recordNumber <= $edrNumberOfEventsToBeStored; $recordNumber++)
	{
		my $recordAvailable = $record_handler -> IsRecordAvailable("CrashLabel" => $tcpar_Crashcode, "RecordNumber"=> $recordNumber);
		$detectedNbrOfStoredRecords++ if ($recordAvailable);
	}
	S_teststep_expected("Number of records expected is '$tcpar_expected_nr_of_records'", 'read_crash_record');	#evaluation 1
	my $verdict=EVAL_evaluate_value("NumberOfRecords", $detectedNbrOfStoredRecords, '==',$tcpar_expected_nr_of_records);
	S_teststep_detected("Number of stored records is $detectedNbrOfStoredRecords", 'read_crash_record');
	if ($verdict eq "VERDICT_FAIL" and not $main::opt_offline){
		S_w2rep(" Expected number of records do not match with detected records, hence no evaluation will be done further");
		return 1;
	}
	
	if (defined $tcpar_CompareValues_CT)
	{
		S_teststep("check the timing of start and reset of first active algos, followed by subsequent algos and time difeerence between them, along with multievent number",'AUTO_NBR','read_algo_StartResetTime');	 #measurement 2
		S_w2rep("",'teal');
		S_w2rep("*****************************************", 'teal');	
		S_w2rep("Algo Start and Reset time of expected algo", 'teal');
		foreach my $edid (keys %{$tcpar_CompareValues_CT})
		{ 
            my $expectedValue = $tcpar_CompareValues_CT -> {$edid};

		    EDR_Eval_evaluate_EDID_Decoded ("EDIDnr" => $edid,
                                "RecordNumber" => 1,
                                "CrashLabel" => $tcpar_Crashcode,
                                "ExpectedValueDecoded" => $expectedValue,
                                "EvalOperator" => '==',  # in case expected value is a string, this will be overwritten
                                "EvalTolerance_abs" => $tcpar_AlgoStartTime_Tolerance);
		}

		S_w2rep("",'teal');
		S_w2rep("*****************************************", 'teal');	
		S_w2rep("Default Algo Start and Reset time for non active algo ", 'teal');
		foreach my $edid (keys %{$tcpar_Default_EDIDs})
		{
				
			my $expectedValue = $tcpar_Default_EDIDs -> {$edid};
            EDR_Eval_evaluate_EDID_Decoded ("EDIDnr" => $edid,
                                "RecordNumber" => 1,
                                "CrashLabel" => $tcpar_Crashcode,
                                "ExpectedValueDecoded" => $expectedValue,
                                "EvalOperator" => 'eq');
		}
	}

	return 1;
}

sub TC_finalization {
	S_w2rep("Delete all object instances...");
	$record_handler -> DeleteAllRecords();

	# Erase EDR
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(2000);

	# Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	# Read fault memory after clearing and erasing EDR
    PD_ReadFaultMemory();   

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

	return 1;
}


1;
