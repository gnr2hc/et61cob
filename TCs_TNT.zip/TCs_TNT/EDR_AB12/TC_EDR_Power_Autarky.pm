#### TEST CASE MODULE
package TC_EDR_Power_Autarky;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
#include further modules here
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_PD;
use GENERIC_DCOM;
use LIFT_can_access;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use LIFT_FaultMemory;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;

use Data::Dumper;

use constant SECOND_TO_MILLISEC => 1000;
use constant MAX_TIME_BETWEEN_MULTI_EVENTS => 5000;
use constant MIN_TOTAL_ITERATIONS => 10;
use constant TOLERANCE_TIME_BETWEEN_EVENTS_ONE_CRASHCODE_MS => 3;
# additional tolerance as loading Quate with two different crash codes leads to higher insecurities about the actual T0 of the events
use constant TOLERANCE_TIME_BETWEEN_EVENTS_TWO_CRASHCODES_MS => 10;
##################################

our $PURPOSE = "<This test script tests EDR behaviour during autarky>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_Power_Autarky

=head1 PURPOSE

<This test script tests EDR behaviour during autarky>>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Inject <Crashcode> and cut power at <CrashTimeZero_ms> 

2. Wait for <WaitTime_ms>

3. Power up ECU

4. Read crash record

5.Read <EDIDSs>


I<B<Evaluation>>

1. -

2. -

3. -

4. Check that mandatory EDR data is recorded for both (or all three when special parallel regular) incidents.

5.<EDIDs> should have data<CompareValues>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'CrashTimeZeroIncident1_ms' => 
	SCALAR 'CrashTimeZeroIncident2_ms' => 
	SCALAR 'purpose' => 
	SCALAR 'Crashcode1' => 
	SCALAR 'Crashcode2' => 
	SCALAR 'ResultDB' => 
	SCALAR 'wait_ms' => 
	HASH 'ExpectedValueRaw_EDIDs' => 
	HASH 'FireTime_EDIDs' => 
	HASH 'NonDefault_EDIDs' => 
	SCALAR 'AWL_Status_Incident2' => 
	SCALAR 'NbrOfRecordsExpected' => 
	SCALAR 'DiagType' => 


=head2 PARAMETER EXAMPLES

	purpose    = 'check storage of mandatory EDR data when autarky occured'
	
	# ---------- Stimulation ------------ 
	Crashcode1= 'Single_EDR_Front_Inflatable'   
	Crashcode2= 'Single_EDR_Rollover_Inflatable'
	ResultDB = 'EDR' # defined in CREIS project constants - will be set to 'DEFAULT' if not given
	COMsignalsAfterCrash = %() # optional parameter which provides COM signals needed to be sent after crash.

	wait_ms    = 5000 #ms

	# ---------- Evaluation ------------ 
	NbrOfRecordsExpected = 1
	DiagType = 'ProdDiag'

	ExpectedValueRaw_EDIDs =%('1000' => '5A',  '45'=> 'MultiEventNumber', '48' => 'TimeFromInitialToCurrent', '75' => 'AWL_Status', '1001' => 'IgnitionCycleEvent', '1002' => 'IgnitionCycleDownload', '71' => '01')
	AWL_Status_Incident2 = '01'
	FireTime_EDIDs = %('51' => 'AB1FD', '56' => 'AB1FP')
	NonDefault_EDIDs = %( '31' => 'FF', '33' => 'FF', '35' => 'FF',  '75' => 'FF', '91' => 'FF', '92' => 'FF','95' => 'FF' )

	CrashTimeZeroIncident2_ms = '543.26' #given in crash list
	CrashTimeZeroIncident1_ms = '11.76' #given in crash list

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Crashcode1;
my $tcpar_Crashcode2;
my $tcpar_CrashCodeNumber_MultiEvent;
my $tcpar_ResultDB;
my $tcpar_CrashTimeZeroIncident1_ms;
my $tcpar_CrashTimeZeroIncident2_ms;
my $tcpar_CrashTimeZeroIncident3_ms;
my $tcpar_ExpectedValueRaw_EDIDs;
my $tcpar_FireTime_EDIDs;
my $tcpar_NonDefault_EDIDs;
my $tcpar_NbrOfRecordsExpected;
my $tcpar_MandatoryDataStoredForIncident;
my $tcpar_DiagType;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_AWL_Status_Incident1;
my $tcpar_AWL_Status_Incident2;
my $tcpar_PD_Variable_PowerOnCounter;
my $tcpar_FireTimeTolerance_ms;
my $tcpar_DeviceOpenLineBeforeCrash;
my $tcpar_PD_Variable_WarningLamp;
my $tcpar_AutarkyOccuredAtTime_ms;
my $tcpar_read_NHTSAEDR;
my $tcpar_read_CHINAEDR;
################ global parameter declaration ###################
#add any global variables here
my ($record_handler,
    $crash_handler,
    $crashSettings,
    $edrNumberOfEventsToBeStored,
    $expectedRawValues_href,
    $timeBetweenEvents_ms,
    $incidentRecordMapping,
    $storageOrder,
    $wlMeasurementFastDiagFile,
    $specialEventTimerExists,
	$currentTestCaseIteration,
    $toleranceTimeBetweenEvents_ms,
	$ChinaEDR_diagType);

###############################################################

sub TC_set_parameters {

	$tcpar_purpose = S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_Crashcode1 = S_read_mandatory_testcase_parameter( 'Crashcode1' );
	$tcpar_Crashcode2 = S_read_optional_testcase_parameter( 'Crashcode2' );
	$tcpar_CrashCodeNumber_MultiEvent = S_read_optional_testcase_parameter( 'CrashCodeNumber_MultiEvent' );
	if(defined $tcpar_CrashCodeNumber_MultiEvent and $tcpar_CrashCodeNumber_MultiEvent > 2){
	    S_set_error("Parameter 'CrashCodeNumber_MultiEvent' can only be 1 or 2 as only two crash codes are supported!");
	    return;
	}
	$tcpar_ResultDB =  S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_NbrOfRecordsExpected =  S_read_mandatory_testcase_parameter( 'NbrOfRecordsExpected' );
    $tcpar_MandatoryDataStoredForIncident = S_read_mandatory_testcase_parameter( 'MandatoryDataStored_Incident' );
    $tcpar_MandatoryDataStoredForIncident = 1 if($tcpar_MandatoryDataStoredForIncident eq 'First');
    $tcpar_MandatoryDataStoredForIncident = 2 if($tcpar_MandatoryDataStoredForIncident eq 'Second');
    $tcpar_MandatoryDataStoredForIncident = 3 if($tcpar_MandatoryDataStoredForIncident eq 'Third');
	$tcpar_DiagType =  S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_AutarkyOccuredAtTime_ms =  S_read_mandatory_testcase_parameter( 'AutarkyOccuredAtTime_ms' );
	$tcpar_read_NHTSAEDR=S_read_optional_testcase_parameter('read_NHTSAEDR');
	$tcpar_read_CHINAEDR=S_read_optional_testcase_parameter('read_CHINAEDR');
	$tcpar_CrashTimeZeroIncident1_ms =  S_read_mandatory_testcase_parameter( 'CrashTimeZeroIncident1_ms' );
    $tcpar_CrashTimeZeroIncident2_ms =  S_read_mandatory_testcase_parameter( 'CrashTimeZeroIncident2_ms' );
    if($tcpar_CrashTimeZeroIncident2_ms eq 'SingleEvent'){
        $tcpar_CrashTimeZeroIncident2_ms = $tcpar_CrashTimeZeroIncident1_ms;
    }
	$tcpar_CrashTimeZeroIncident3_ms =  S_read_optional_testcase_parameter( 'CrashTimeZeroIncident3_ms' );
	$tcpar_ExpectedValueRaw_EDIDs =  S_read_mandatory_testcase_parameter( 'ExpectedValueRaw_EDIDs', 'byref' );
	$tcpar_FireTime_EDIDs =  S_read_mandatory_testcase_parameter( 'FireTime_EDIDs', 'byref' );
	$tcpar_NonDefault_EDIDs = S_read_mandatory_testcase_parameter( 'NonDefault_EDIDs', 'byref' );
    $tcpar_AWL_Status_Incident1 = S_read_optional_testcase_parameter( 'AWL_Status_Incident1' );
    $tcpar_AWL_Status_Incident1 = '00' if(not defined $tcpar_AWL_Status_Incident1);
	$tcpar_AWL_Status_Incident2 = S_read_mandatory_testcase_parameter( 'AWL_Status_Incident2' );
	$tcpar_PD_Variable_PowerOnCounter = S_read_mandatory_testcase_parameter( 'PD_Variable_PowerOnCounter' , 'byref');
	$tcpar_PD_Variable_WarningLamp = S_read_optional_testcase_parameter( 'PD_Variable_WarningLamp');
	if(not defined $tcpar_PD_Variable_WarningLamp){
	    S_set_warning("Warning lamp variable will be set to default value: rb_wimi_SysWIStatus_aen(0)");
	    $tcpar_PD_Variable_WarningLamp = 'rb_wimi_SysWIStatus_aen(0)';
	}

	$tcpar_COMsignalsAfterCrash =  S_read_optional_testcase_parameter( 'COMsignalsAfterCrash','byref');
	$tcpar_FireTimeTolerance_ms = S_read_optional_testcase_parameter( 'FireTimeTolerance_ms');
	if(not defined $tcpar_FireTimeTolerance_ms){
	    S_set_warning("Setting fire time tolerance to default value 3 ms!");
	    $tcpar_FireTimeTolerance_ms = 3;
	}
	
	$tcpar_DeviceOpenLineBeforeCrash = S_read_optional_testcase_parameter('DeviceOpenLineBeforeCrash');

	# Assign expected values according to StorageOrder
    $storageOrder = EDR_getStorageOrder();
	return unless(defined $storageOrder);
    if($storageOrder eq 'PhysicalOrder'){
       $storageOrder =  'MostRecentLast'; #same behavior as there is no overwriting
    }
    
    if(defined $tcpar_Crashcode2){ # greater tolerance for two crash codes
        $toleranceTimeBetweenEvents_ms = TOLERANCE_TIME_BETWEEN_EVENTS_TWO_CRASHCODES_MS;
    }
    else{
        $toleranceTimeBetweenEvents_ms = TOLERANCE_TIME_BETWEEN_EVENTS_ONE_CRASHCODE_MS;        
    }

	if ($tcpar_NbrOfRecordsExpected == 1){
		$expectedRawValues_href -> {'MultiEventNumber'} = {"Record_1" => '01'};
		$expectedRawValues_href -> {'TimeFromInitialToCurrent'} = {"Record_1" => 'FFFF'};
        $expectedRawValues_href -> {'TimeFromPreviousToCurrent'} = {"Record_1" => 'FFFF'};
		$expectedRawValues_href -> {'AWL_Status'} = {"Record_1" => $tcpar_AWL_Status_Incident1};
	}
	else{
		if($storageOrder eq 'MostRecentLast') {
			$expectedRawValues_href -> {'MultiEventNumber'} = {"Record_1" => '01', "Record_2" => '02'};
			$expectedRawValues_href -> {'TimeFromInitialToCurrent'} = {"Record_1" => 'FFFF', "Record_2" => 'tbd'};
            $expectedRawValues_href -> {'TimeFromPreviousToCurrent'} = {"Record_1" => 'FFFF', "Record_2" => 'tbd'};
			$expectedRawValues_href -> {'AWL_Status'} = {"Record_1" => $tcpar_AWL_Status_Incident1,
			                                             "Record_2" => $tcpar_AWL_Status_Incident2};
			$expectedRawValues_href -> {'MultiEventNumber'} -> {"Record_3"} = '03' if($tcpar_CrashTimeZeroIncident3_ms);
			$expectedRawValues_href -> {'TimeFromInitialToCurrent'} -> {"Record_3"} = 'tbd' if($tcpar_CrashTimeZeroIncident3_ms);
            $expectedRawValues_href -> {'TimeFromPreviousToCurrent'} -> {"Record_3"} = 'tbd' if($tcpar_CrashTimeZeroIncident3_ms);
			$expectedRawValues_href -> {'AWL_Status'} -> {"Record_3"} = $tcpar_AWL_Status_Incident2 if($tcpar_CrashTimeZeroIncident3_ms);
			
		}
		elsif($storageOrder eq 'MostRecentFirst' and not defined $tcpar_CrashTimeZeroIncident3_ms) {
			$expectedRawValues_href -> {'MultiEventNumber'} = {"Record_1" => '02', "Record_2" => '01'};
			$expectedRawValues_href -> {'TimeFromInitialToCurrent'} = {"Record_1" => 'tbd', "Record_2" => 'FFFF'};
            $expectedRawValues_href -> {'TimeFromPreviousToCurrent'} = {"Record_1" => 'tbd', "Record_2" => 'FFFF'};
			$expectedRawValues_href -> {'AWL_Status'} = {"Record_1" => $tcpar_AWL_Status_Incident2,
			                                             "Record_2" => $tcpar_AWL_Status_Incident1};
		}
		elsif($storageOrder eq 'MostRecentFirst' and defined $tcpar_CrashTimeZeroIncident3_ms) {
			$expectedRawValues_href -> {'MultiEventNumber'} = {"Record_1" => '03', "Record_2" => '02', "Record_3" => '01'};
			$expectedRawValues_href -> {'TimeFromInitialToCurrent'} = {"Record_1" => 'tbd', "Record_2" => 'tbd',"Record_3" => 'FFFF'};
            $expectedRawValues_href -> {'TimeFromPreviousToCurrent'} = {"Record_1" => 'tbd', "Record_2" => 'tbd',"Record_3" => 'FFFF'};
			$expectedRawValues_href -> {'AWL_Status'} = {"Record_1" => $tcpar_AWL_Status_Incident2,
			                                             "Record_2" => $tcpar_AWL_Status_Incident2,
			                                             "Record_3" => $tcpar_AWL_Status_Incident1};		
		}
		else {
			S_set_error("Set 'StorageOrder' in EDR mapping to 'MostRecentLast' or 'MostRecentFirst'", 110);
		}
	}
	
	if(defined $tcpar_read_CHINAEDR and $tcpar_read_CHINAEDR eq 'yes'){
		$tcpar_read_NHTSAEDR = 'no';
		$toleranceTimeBetweenEvents_ms=100;  #EDID 4013  has resolution of 100ms
		my $storageOrder = EDR_getStorageOrder();
		return unless(defined $storageOrder);

		if($storageOrder eq 'PhysicalOrder'){
			$ChinaEDR_diagType= 'ProdDiag';  #In platform NHTSA and China EDR is read via proddiag
		}
		else {
			$ChinaEDR_diagType= 'CHINA_Payload';
		}
	}
	else{
		$tcpar_read_NHTSAEDR = 'yes';
	}
	return 1;
}

sub TC_initialization {

    my $success;
    ($success, $currentTestCaseIteration) = S_read_public_variable("TC_Iteration_Autarky_$tcpar_Crashcode1\_$tcpar_Crashcode2\_$tcpar_DeviceOpenLineBeforeCrash\_$tcpar_AutarkyOccuredAtTime_ms");
    if($success){
        $currentTestCaseIteration ++;
    }
    else{
        $currentTestCaseIteration = 1;
    }

    S_set_public_variable("TC_Iteration_Autarky_$tcpar_Crashcode1\_$tcpar_Crashcode2\_$tcpar_DeviceOpenLineBeforeCrash\_$tcpar_AutarkyOccuredAtTime_ms", $currentTestCaseIteration);
    S_teststep("--- START TEST ITERATION $currentTestCaseIteration ---", 'NO_AUTO_NBR');
    S_teststep_expected_NOHTML("--- START TEST ITERATION $currentTestCaseIteration ---");
    S_teststep_detected_NOHTML("--- START TEST ITERATION $currentTestCaseIteration ---");

	#--------------------------------------------------------------
    # INITIALIZE RECORD AND CRASH HANDLER
    #    
	S_w2rep("Initialize Record and Crash Handler");
	$record_handler = EDR_init_RecordHandler() || return;
	$crash_handler  = EDR_init_CrashHandler() || return;


	S_w2log(1, "Power on ECU");
    LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

    S_w2log(1, "Initialize CD and start CAN trace");
    GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start ( );

	S_w2log(1, "Clear crash recorder");
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(2000);

	S_w2log(1, "Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);

    # read fault memory
    my $faultsBeforeStimulation = LIFT_FaultMemory -> read_fault_memory('Bosch');

    #Fault memory must be empty
    my $faultsVerdict = $faultsBeforeStimulation -> evaluate_faults({});
    S_w2rep("Faults verdict: $faultsVerdict");
    return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

	return 1;
}

sub TC_stimulation_and_measurement {

    # Edr records
    $edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();
    unless(defined $edrNumberOfEventsToBeStored){
        S_set_error("Number of records to be stored in EDR not available in SYC - add or overwrite with Custlibrary Function");
        return;
    }

	#--------------------------------------------------------------
    # CRASH PREPARATION
    #
	S_teststep("Prepare crash", 'AUTO_NBR');

    #--------------------------------------------------------------
    # PREPARE CRASH AND INITIALIZE EQUIPMENT
    #
	S_w2rep("Get crash settings for crash $tcpar_Crashcode1");
    my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode1};
    $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
    unless(defined $crashSettings) {
        S_set_error("Crash $tcpar_Crashcode1 not available in result DB $tcpar_ResultDB. Test case aborted.");
        return;
    }

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log(1, "Crashcode: $tcpar_Crashcode1, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");
    S_w2log(1, "Set environments for crash as per result DB");
    CSI_PrepareEnvironment($crashSettings, 'init_complete');

	#--------------------------------------------------------------
    # CRASH PREPARATION
    #

    # Prepare crash
    S_teststep("Prepare crash", 'AUTO_NBR');
    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

    # Prepare crash
    CSI_LoadCrashSensorData2Simulator($crashSettings);

    # Power ON the ECU
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

    if($tcpar_DeviceOpenLineBeforeCrash){
        S_teststep("Create open line fault for device $tcpar_DeviceOpenLineBeforeCrash before crash and wait 5sec for fault qualification",
                        'AUTO_NBR');
        LC_DisconnectLine($tcpar_DeviceOpenLineBeforeCrash);
        S_wait_ms(5000);
    }

	#--------------------------------------------------------------
    # CRASH INJECTION
    #
 	# Read power on cycle for evaluation
    my $powerOnCounterCrash = PD_ReadMemoryByName($tcpar_PD_Variable_PowerOnCounter -> {"VariableName"});
    $powerOnCounterCrash = S_aref2dec ( $powerOnCounterCrash, $tcpar_PD_Variable_PowerOnCounter -> {"VariableType"} );
    $expectedRawValues_href -> {'IgnitionCycleEvent'} = {"Record_1" => {"Decoded" => $powerOnCounterCrash, "Tolerance_abs" => 0},
                                                            "Record_2" => {"Decoded" => $powerOnCounterCrash, "Tolerance_abs" => 0}};
    $expectedRawValues_href -> {'IgnitionCycleEvent'} = {"Record_1" => {"Decoded" => $powerOnCounterCrash, "Tolerance_abs" => 0},
                                                            "Record_2" => {"Decoded" => $powerOnCounterCrash, "Tolerance_abs" => 0},
                                                            "Record_3" => {"Decoded" => $powerOnCounterCrash, "Tolerance_abs" => 0}}
                                                               if(defined $tcpar_CrashTimeZeroIncident3_ms) ;


    my $dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number();
    mkdir($dataStoragePath) unless(-e $dataStoragePath);

    my $pd_Labels_aref = ['rb_evm_EventTimer_au16(0)',
                          'Fee_Rb_WorkingState_en',
                          'NvM_Prv_stRequests_rAMwAM_au16(0)',
                          'Dem_NvMImmediateStorageRequested',
                          'NvM_Prv_ImmRequestQueue_ast(0).idBlock_u16',
                          'NvM_Prv_ImmRequestQueue_ast(1).idBlock_u16',
                          'NvM_Prv_ImmRequestQueue_ast(2).idBlock_u16',
                          'rb_dcsm_HeaderUpdateStatus_en',
                          'rb_dcsm_EvStoreState_aen(1)',
                          'rb_evm_EventInfo_ast(0).EventMaxSevType_en',
                          'rb_dcc_HeaderPublic_st.MandatoryDataRecCompltStatus_aen(1)',
                          'rb_dcsm_AutarkyHeaderStatus_en',
                          'rb_dcsm_DataSectionStoreIndex_aen(0)',
                          'rb_dcsm_DataSectionStoreIndex_aen(1)'
                          ];
    my $pd_Types_aref = ['U16',
                            'U8',
                            'U16',
                            'U8',
                            'U16',
                            'U16',
                            'U16',
                            'U8',
                            'U8',
                            'U8',
                            'U8',
                            'U8',
                            'U8',
                            'U8'];
    
    # special event timer variable if existing (only exists if special event is configured)
    my $specialEventTimer_aref = PD_ReadMemoryByName_NOERROR('rb_evm_EventTimer_au16(1)');
	if(defined $specialEventTimer_aref and @{$specialEventTimer_aref} > 0){
        $specialEventTimerExists = 1;
        push(@{$pd_Labels_aref}, 'rb_evm_EventTimer_au16(1)');
        push(@{$pd_Types_aref}, 'U16');
    }
    else{
        $specialEventTimerExists = 0;
    }

    # Variables for mandatory storage completion
    my $mandatoryStorageRecords = $edrNumberOfEventsToBeStored;
     # 3 is the maximum number of events currently supported
     # Number of variables to measure must be limited due to Fast Diagnosis resources
    $mandatoryStorageRecords = 3 if($mandatoryStorageRecords > 3);
    foreach my $nvmBuffer(1..$mandatoryStorageRecords){
        my $pdIndex = $nvmBuffer - 1;
        push(@{$pd_Labels_aref}, "rb_dcc_HeaderPublic_st.MandatoryDataRecCompltStatus_aen($pdIndex)");
        push(@{$pd_Types_aref}, 'U8');        
    }

    # Warning lamp variable
    my $wLValueBeforeCrash = PD_ReadMemoryByName($tcpar_PD_Variable_WarningLamp);
    if(defined $wLValueBeforeCrash and @{$wLValueBeforeCrash} == 0){
        S_set_error("Given warning lamp variable '$tcpar_PD_Variable_WarningLamp' is not present in SAD file!");
        $tcpar_PD_Variable_WarningLamp = undef;
    }
    else{
        push(@{$pd_Labels_aref}, $tcpar_PD_Variable_WarningLamp);
        push(@{$pd_Types_aref}, 'U8');        
    }
    
    S_teststep("Start fast diagnosis measurement", 'AUTO_NBR');
    $wlMeasurementFastDiagFile = $dataStoragePath."/FstDg.txt";
    
    my $nbrOfCanIds = S_get_contents_of_hash_NOERROR(['Mapping_EDR', 'NbrOfCanIds']);
    $nbrOfCanIds = 4 unless(defined $nbrOfCanIds);

	S_w2log(1, "Calling fast diag with $nbrOfCanIds CAN IDs");
    my $fastDiag = PD_StartFastDiagName( $wlMeasurementFastDiagFile ,
                                         $pd_Labels_aref,
                                         $pd_Types_aref , undef, $nbrOfCanIds);
    unless($fastDiag){
        S_set_error("Fast diagnosis measurement could not be started! Evaluation will not be complete!");
    }
    
    CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    S_wait_ms(1000);
    
    S_teststep("Start recording of fire times.", 'AUTO_NBR');
    LC_MeasureTraceDigitalStart();

    S_teststep("Inject '$tcpar_Crashcode1' ", 'AUTO_NBR');
	CSI_TriggerCrash();
	S_set_timer_zero('Crash_Timer');

	my $time_SecondInjection_ms;
	if (defined $tcpar_Crashcode2){
		#--------------------------------------------------------------
		# PREPARE CRASH AND INITIALIZE EQUIPMENT
		#
		S_wait_ms(1000);
		S_w2rep("Get crash settings for crash $tcpar_Crashcode2");
		my $crashDetails2_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode2};
        $crashSettings = CSI_GetCrashDataFromMDS($crashDetails2_href);
        unless(defined $crashSettings) {
            S_set_error("Crash $tcpar_Crashcode2 not available in result DB $tcpar_ResultDB. Test case aborted.");
            return;
        }

		my $resultDBDetails2 = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
		my $resultDB_Path2 = $resultDBDetails2->{'PATH'};
		S_w2log(1, "Crashcode: $tcpar_Crashcode2, ResultDB: $tcpar_ResultDB (path: $resultDB_Path2)");
		# Prepare crash
        CSI_LoadCrashSensorData2Simulator($crashSettings);
        
        CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    	S_wait_ms(1000);

		S_teststep("Inject '$tcpar_Crashcode2' ", 'AUTO_NBR');
		CSI_TriggerCrash_NOERROR(); #Environments can't be set again, as this should be a multi-event
		$time_SecondInjection_ms = S_read_timer_ms('Crash_Timer');
	}

    my $timeUntilT0;
    if(defined $tcpar_CrashCodeNumber_MultiEvent and $tcpar_CrashCodeNumber_MultiEvent == 1){
        $timeUntilT0 = $tcpar_CrashTimeZeroIncident3_ms;
    }
    else{
        $timeUntilT0 = $tcpar_CrashTimeZeroIncident2_ms;
    }
	S_teststep("Wait for T0 of power cut incident ('$timeUntilT0' ms)", 'AUTO_NBR');
	S_wait_ms($timeUntilT0);
    S_teststep("Cut power after '$tcpar_AutarkyOccuredAtTime_ms' ms", 'AUTO_NBR');
	S_wait_ms($tcpar_AutarkyOccuredAtTime_ms);
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	
	if($fastDiag){
		S_w2rep("Stop fast diag measurement");
	    PD_StopFastDiag();
	}

	S_teststep("Stop recording of fire times", 'AUTO_NBR');
    LC_MeasureTraceDigitalStop();

	S_teststep("Power up ECU", 'AUTO_NBR');
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	if (defined $tcpar_COMsignalsAfterCrash){
		foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
		{
			my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
			S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
			COM_setSignalState($signal,$dataOnCOM);
		}
	}

	#--------------------------------------------------------------
    # MEASUREMENTS
    #
    if (defined $time_SecondInjection_ms) {
		S_w2rep("Two crash codes were injected - therefore T0 time of second and/or third crash code"
		          ." must be adapted to include the time between first and second injection ($time_SecondInjection_ms ms).");		
		# add measured time between first and second injection to T0 of second incident
		if(not defined $tcpar_CrashCodeNumber_MultiEvent){
            $tcpar_CrashTimeZeroIncident2_ms = $tcpar_CrashTimeZeroIncident2_ms + $time_SecondInjection_ms;
            S_w2rep("Adapted T0 of second incident in ms: $tcpar_CrashTimeZeroIncident2_ms");		
		}
		elsif($tcpar_CrashCodeNumber_MultiEvent == 1) {
            S_w2rep("Multi event in crash code $tcpar_CrashCodeNumber_MultiEvent");

            $tcpar_CrashTimeZeroIncident3_ms = $tcpar_CrashTimeZeroIncident3_ms + $time_SecondInjection_ms;
            S_w2rep("T0 of second incident in ms: $tcpar_CrashTimeZeroIncident2_ms");
            S_w2rep("T0 of third incident in ms: $tcpar_CrashTimeZeroIncident3_ms");
		}
		elsif($tcpar_CrashCodeNumber_MultiEvent == 2){
            $tcpar_CrashTimeZeroIncident2_ms = $tcpar_CrashTimeZeroIncident2_ms + $time_SecondInjection_ms ;
            $tcpar_CrashTimeZeroIncident3_ms = $tcpar_CrashTimeZeroIncident3_ms + $time_SecondInjection_ms;		    
            S_w2rep("T0 of second incident in ms: $tcpar_CrashTimeZeroIncident2_ms");
            S_w2rep("T0 of third incident in ms: $tcpar_CrashTimeZeroIncident3_ms");
		}
	}

	$timeBetweenEvents_ms = $tcpar_CrashTimeZeroIncident2_ms - $tcpar_CrashTimeZeroIncident1_ms;		
	my $timeBetweenEvents_2_3_ms = $tcpar_CrashTimeZeroIncident3_ms - $tcpar_CrashTimeZeroIncident2_ms if(defined $tcpar_CrashTimeZeroIncident3_ms);
	S_w2rep("Time between events 1 and 2 is: $timeBetweenEvents_ms ms");
	S_w2rep("Time between events 2 and 3 is: $timeBetweenEvents_2_3_ms ms") if(defined $tcpar_CrashTimeZeroIncident3_ms);

	my $maxTimeBetweenMultiEvents = MAX_TIME_BETWEEN_MULTI_EVENTS;
	if(defined $tcpar_CrashCodeNumber_MultiEvent and $tcpar_CrashCodeNumber_MultiEvent == 1 and $storageOrder eq 'MostRecentFirst'){ # Storage order most recent first
		if($timeBetweenEvents_2_3_ms >= MAX_TIME_BETWEEN_MULTI_EVENTS){
			S_w2rep("Multi event between incident 1 and 2 (special event), ".
			         "No multi-event between incident 2 and 3 since time between events greater than $maxTimeBetweenMultiEvents ms");
			$expectedRawValues_href -> {'MultiEventNumber'} = {"Record_1" => '01', "Record_2" => '02', "Record_3" => '01'};
			$expectedRawValues_href -> {'TimeFromInitialToCurrent'} = {"Record_1" => 'FFFF',
			                                                           "Record_2" => {"Decoded" => $timeBetweenEvents_ms,
			                                                                          "Tolerance_abs" => $toleranceTimeBetweenEvents_ms},
			                                                           "Record_3" => 'FFFF'};

            $expectedRawValues_href -> {'TimeFromPreviousToCurrent'} = {"Record_1" => 'FFFF',
                                                                        "Record_2" => {"Decoded" => $timeBetweenEvents_ms,
                                                                                       "Tolerance_abs" => $toleranceTimeBetweenEvents_ms},
                                                                        "Record_3" => 'FFFF'};
		}
		else {
			S_w2rep("All three incidents are multi-events");
			$expectedRawValues_href -> {'MultiEventNumber'} = {"Record_1" => '03', "Record_2" => '02', "Record_3" => '01'};
			my $timeFromInitialToCurrentIncident3 = $tcpar_CrashTimeZeroIncident3_ms - $tcpar_CrashTimeZeroIncident1_ms;
			$expectedRawValues_href -> {'TimeFromInitialToCurrent'} = {"Record_1" => {
			                                                                 "Decoded" => $timeFromInitialToCurrentIncident3,
			                                                                 "Tolerance_abs" => $toleranceTimeBetweenEvents_ms},
			                                                            "Record_2" => {
			                                                                "Decoded" => $timeBetweenEvents_ms,
			                                                                "Tolerance_abs" => $toleranceTimeBetweenEvents_ms},
			                                                            "Record_3" => 'FFFF'};

            $expectedRawValues_href -> {'TimeFromPreviousToCurrent'} = {"Record_1" => {
                                                                            "Decoded" => $timeBetweenEvents_2_3_ms,
                                                                            "Tolerance_abs" => $toleranceTimeBetweenEvents_ms},
                                                                        "Record_2" => {
                                                                            "Decoded" => $timeBetweenEvents_ms,
                                                                            "Tolerance_abs" => $toleranceTimeBetweenEvents_ms},
                                                                        "Record_3" => 'FFFF'};
		}
	}
	elsif(defined $tcpar_CrashCodeNumber_MultiEvent and $tcpar_CrashCodeNumber_MultiEvent == 2 and $storageOrder eq 'MostRecentFirst'){ # Storage order most recent first
		if($timeBetweenEvents_ms >= MAX_TIME_BETWEEN_MULTI_EVENTS){
			S_w2rep("No multi-event between incident 1 and 2 since time between events greater than $maxTimeBetweenMultiEvents ms, ".
			             "multi-event between incident 2 and 3 (special event)");
			$expectedRawValues_href -> {'MultiEventNumber'} = {"Record_1" => '02', "Record_2" => '01', "Record_3" => '01'};
			$expectedRawValues_href -> {'TimeFromInitialToCurrent'} = {"Record_1" => {
			                                                                 "Decoded" => $timeBetweenEvents_2_3_ms,
			                                                                 "Tolerance_abs" => $toleranceTimeBetweenEvents_ms},
			                                                           "Record_2" => 'FFFF',
			                                                           "Record_3" => 'FFFF'};

            $expectedRawValues_href -> {'TimeFromPreviousToCurrent'} = {"Record_1" => {
                                                                            "Decoded" => $timeBetweenEvents_2_3_ms,
                                                                            "Tolerance_abs" => $toleranceTimeBetweenEvents_ms},
                                                                        "Record_2" => 'FFFF',
                                                                        "Record_3" => 'FFFF'};
		}
		else {
			S_w2rep("All three incidents are multi-events");
			$expectedRawValues_href -> {'MultiEventNumber'} = {"Record_1" => '03', "Record_2" => '02', "Record_3" => '01'};
			my $timeFromInitialToCurrentIncident3 = $tcpar_CrashTimeZeroIncident3_ms - $tcpar_CrashTimeZeroIncident1_ms;
			$expectedRawValues_href -> {'TimeFromInitialToCurrent'} = {"Record_1" => {
			                                                                 "Decoded" => $timeFromInitialToCurrentIncident3,
			                                                                 "Tolerance_abs" => $toleranceTimeBetweenEvents_ms},
			                                                            "Record_2" => {"Decoded" => $timeBetweenEvents_ms,
			                                                                 "Tolerance_abs" => $toleranceTimeBetweenEvents_ms},
			                                                            "Record_3" => 'FFFF'};

            $expectedRawValues_href -> {'TimeFromPreviousToCurrent'} = {"Record_1" => {
                                                                            "Decoded" => $timeBetweenEvents_2_3_ms,
                                                                            "Tolerance_abs" => $toleranceTimeBetweenEvents_ms},
                                                                        "Record_2" => {
                                                                            "Decoded" => $timeBetweenEvents_ms,
                                                                            "Tolerance_abs" => $toleranceTimeBetweenEvents_ms},
                                                                        "Record_3" => 'FFFF'};
		}
	}
	elsif(defined $tcpar_CrashCodeNumber_MultiEvent and $tcpar_CrashCodeNumber_MultiEvent == 1 and $storageOrder eq 'MostRecentLast'){ # Storage order most recent last
        if($timeBetweenEvents_2_3_ms >= MAX_TIME_BETWEEN_MULTI_EVENTS){
            S_w2rep("Multi event between incident 1 and 2 (special event),".
                        " No multi-event between incident 2 and 3 since time between events greater than $maxTimeBetweenMultiEvents ms");
            $expectedRawValues_href -> {'MultiEventNumber'} = {"Record_1" => '01', "Record_2" => '02', "Record_3" => '01'};
            $expectedRawValues_href -> {'TimeFromInitialToCurrent'} = { "Record_1" => 'FFFF',
                                                                        "Record_2" => {
                                                                            "Decoded" => $timeBetweenEvents_ms, 
                                                                            "Tolerance_abs" => $toleranceTimeBetweenEvents_ms},
                                                                        "Record_3" => 'FFFF'};

            $expectedRawValues_href -> {'TimeFromPreviousToCurrent'} = {"Record_1" => 'FFFF',
                                                                        "Record_2" => {
                                                                            "Decoded" => $timeBetweenEvents_ms,
                                                                            "Tolerance_abs" => $toleranceTimeBetweenEvents_ms},
                                                                        "Record_3" => 'FFFF'};
        }
        else {
            S_w2rep("All three incidents are multi-events");
            $expectedRawValues_href -> {'MultiEventNumber'} = {"Record_1" => '01', "Record_2" => '02', "Record_3" => '03'};
            my $timeFromInitialToCurrentIncident3 = $tcpar_CrashTimeZeroIncident3_ms - $tcpar_CrashTimeZeroIncident1_ms;
            $expectedRawValues_href -> {'TimeFromInitialToCurrent'} = { "Record_1" => 'FFFF', 
                                                                        "Record_2" => {
                                                                            "Decoded" => $timeBetweenEvents_ms,
                                                                            "Tolerance_abs" => $toleranceTimeBetweenEvents_ms},
                                                                        "Record_3" => {
                                                                            "Decoded" => $timeFromInitialToCurrentIncident3,
                                                                            "Tolerance_abs" => $toleranceTimeBetweenEvents_ms}};

            $expectedRawValues_href -> {'TimeFromPreviousToCurrent'} = {"Record_1" => 'FFFF',
                                                                        "Record_2" => {
                                                                            "Decoded" => $timeBetweenEvents_ms,
                                                                            "Tolerance_abs" => $toleranceTimeBetweenEvents_ms},
                                                                        "Record_3" => {
                                                                            "Decoded" => $timeBetweenEvents_2_3_ms,
                                                                            "Tolerance_abs" => $toleranceTimeBetweenEvents_ms}};
        }
	}
	elsif(defined $tcpar_CrashCodeNumber_MultiEvent and $tcpar_CrashCodeNumber_MultiEvent == 2 and $storageOrder eq 'MostRecentLast'){ # Storage order most recent last
        if($timeBetweenEvents_ms >= MAX_TIME_BETWEEN_MULTI_EVENTS){
            S_w2rep("No multi-event between incident 1 and 2 since time between events".
                        " greater than $maxTimeBetweenMultiEvents ms, multi-event between incident 2 and 3 (special event)");
            $expectedRawValues_href -> {'MultiEventNumber'} = {"Record_1" => '01', "Record_2" => '01', "Record_3" => '02'};
            $expectedRawValues_href -> {'TimeFromInitialToCurrent'} = { "Record_1" => 'FFFF',
                                                                        "Record_2" => 'FFFF',
                                                                        "Record_3" => {
                                                                            "Decoded" => $timeBetweenEvents_2_3_ms,
                                                                            "Tolerance_abs" => $toleranceTimeBetweenEvents_ms}};

            $expectedRawValues_href -> {'TimeFromPreviousToCurrent'} = {"Record_1" => 'FFFF',
                                                                        "Record_2" => 'FFFF',
                                                                        "Record_3" => {
                                                                            "Decoded" => $timeBetweenEvents_2_3_ms,
                                                                            "Tolerance_abs" => $toleranceTimeBetweenEvents_ms}};
        }
        else {
            S_w2rep("All three incidents are multi-events");
            $expectedRawValues_href -> {'MultiEventNumber'} = {"Record_1" => '01', "Record_2" => '02', "Record_3" => '03'};
            my $timeFromInitialToCurrentIncident3 = $tcpar_CrashTimeZeroIncident3_ms - $tcpar_CrashTimeZeroIncident1_ms;
            $expectedRawValues_href -> {'TimeFromInitialToCurrent'} = { "Record_1" => 'FFFF',
                                                                        "Record_2" => {
                                                                            "Decoded" => $timeBetweenEvents_ms,
                                                                            "Tolerance_abs" => $toleranceTimeBetweenEvents_ms},
                                                                        "Record_3" => {
                                                                            "Decoded" => $timeFromInitialToCurrentIncident3,
                                                                            "Tolerance_abs" => $toleranceTimeBetweenEvents_ms}};

            $expectedRawValues_href -> {'TimeFromPreviousToCurrent'} = {"Record_1" => 'FFFF',
                                                                        "Record_2" => {
                                                                            "Decoded" => $timeBetweenEvents_ms,
                                                                            "Tolerance_abs" => $toleranceTimeBetweenEvents_ms},
                                                                        "Record_3" => {
                                                                            "Decoded" => $timeBetweenEvents_2_3_ms,
                                                                            "Tolerance_abs" => $toleranceTimeBetweenEvents_ms}};
        }
	}
	else { # no special event
		if($timeBetweenEvents_ms >= MAX_TIME_BETWEEN_MULTI_EVENTS) {
			S_w2rep("No multi-event since time between events greater than $maxTimeBetweenMultiEvents ms");
			$expectedRawValues_href -> {'MultiEventNumber'} = {"Record_1" => '01', "Record_2" => '01'};
			$expectedRawValues_href -> {'TimeFromInitialToCurrent'} = {"Record_1" => 'FFFF', "Record_2" => 'FFFF'};
            $expectedRawValues_href -> {'TimeFromPreviousToCurrent'} = {"Record_1" => 'FFFF', "Record_2" => 'FFFF'};
		}
		elsif($timeBetweenEvents_ms < MAX_TIME_BETWEEN_MULTI_EVENTS and $timeBetweenEvents_ms !=0 and $storageOrder eq 'MostRecentLast') {
			$expectedRawValues_href -> {'MultiEventNumber'} = {"Record_1" => '01', "Record_2" => '02'};
			$expectedRawValues_href -> {'TimeFromInitialToCurrent'} = {"Record_1" => 'FFFF',
			                                                             "Record_2" => {
			                                                                 "Decoded" => $timeBetweenEvents_ms,
			                                                                 "Tolerance_abs" => $toleranceTimeBetweenEvents_ms}};

            $expectedRawValues_href -> {'TimeFromPreviousToCurrent'} = {"Record_1" => 'FFFF',
                                                                        "Record_2" => {
                                                                            "Decoded" => $timeBetweenEvents_ms,
                                                                            "Tolerance_abs" => $toleranceTimeBetweenEvents_ms}};
		}
		elsif($timeBetweenEvents_ms < MAX_TIME_BETWEEN_MULTI_EVENTS and  $timeBetweenEvents_ms !=0 and $storageOrder eq 'MostRecentFirst') {
			$expectedRawValues_href -> {'MultiEventNumber'} = {"Record_1" => '02', "Record_2" => '01'};
			$expectedRawValues_href -> {'TimeFromInitialToCurrent'} = {"Record_1" => {
			                                                                 "Decoded" => $timeBetweenEvents_ms,
			                                                                 "Tolerance_abs" => $toleranceTimeBetweenEvents_ms},
		                                                                 "Record_2" => 'FFFF'};

            $expectedRawValues_href -> {'TimeFromPreviousToCurrent'} = {"Record_1" => {
                                                                            "Decoded" => $timeBetweenEvents_ms,
                                                                            "Tolerance_abs" => $toleranceTimeBetweenEvents_ms},
                                                                        "Record_2" => 'FFFF'};
		}
	}

	S_teststep("Read crash record", 'AUTO_NBR', "read_crash_record_Iteration".$currentTestCaseIteration); #measurement 1

	my $powerOnCounterDownload = PD_ReadMemoryByName($tcpar_PD_Variable_PowerOnCounter -> {"VariableName"});
    $powerOnCounterDownload = S_aref2dec ( $powerOnCounterDownload, $tcpar_PD_Variable_PowerOnCounter -> {"VariableType"});
	$expectedRawValues_href -> {'IgnitionCycleDownload'} = {"Record_1" => {"Decoded" => $powerOnCounterDownload},
	                                                        "Record_2" => {"Decoded" => $powerOnCounterDownload}};
	$expectedRawValues_href -> {'IgnitionCycleDownload'} = {"Record_1" => {"Decoded" => $powerOnCounterDownload},
	                                                        "Record_2" => {"Decoded" => $powerOnCounterDownload},
	                                                        "Record_3" => {"Decoded" => $powerOnCounterDownload}}
	                                                           if(defined $tcpar_CrashTimeZeroIncident3_ms) ;

	S_w2rep("Read and store all available records ($edrNumberOfEventsToBeStored records)");
    PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');

    if ( lc( $tcpar_read_NHTSAEDR) eq 'yes' ) {
		EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
								"CrashLabel" => $tcpar_Crashcode1."_".$tcpar_Crashcode2,
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								"read_EDRType"=>'NHTSA')
	}
	if (lc($tcpar_read_CHINAEDR) eq 'yes'){
		$edrNumberOfEventsToBeStored=3;
		EDR_ReadAndStoreAllRecords ("DiagType" =>  $ChinaEDR_diagType,
								"CrashLabel" =>   $tcpar_Crashcode1."_".$tcpar_Crashcode2,
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								"read_EDRType"=>'CHINA');
	}	

   if(S_get_exec_option_NOERROR ( 'EDR_ExtendedMeasurementsEnabled' )){
        S_teststep("Store NVM data", 'AUTO_NBR');
        PD_ECUlogin();
        S_wait_ms(2000);
        PD_DumpNVMData_NOERROR_NOHTML($dataStoragePath . "/".S_get_TC_number(). "_ReadAllNVMSections_Dump.txt");
    }

	# Fire time measurement
	my $lctData = LC_MeasureTraceDigitalGetValues();
	EVAL_dump2UNV( $lctData, "$dataStoragePath/LCT_Measurement.txt.unv" );
	my $squibLabels_aref;
	foreach my $lctEDID (keys %{$tcpar_FireTime_EDIDs})
	{
		push(@{$squibLabels_aref}, $tcpar_FireTime_EDIDs -> {$lctEDID});
	}
	EDR_addFireTimesToCrashHandler ("LCT_Measurement" => $lctData,
									"SquibLabels" => $squibLabels_aref,
									"CrashLabel"  => $tcpar_Crashcode1."_".$tcpar_Crashcode2,
									"StoragePath" => $dataStoragePath);

	return 1;
}

sub TC_evaluation {

    # Get measurements required for evaluation
    my $fast_diag_data_HoH = PD_get_FDtrace($wlMeasurementFastDiagFile);

    ### Decision on repeating test case
    my $repeatTestCase;
    if($currentTestCaseIteration < MIN_TOTAL_ITERATIONS){
        S_w2rep("Test case will be repeated as minimum number of iterations is not reached yet");
        $repeatTestCase = 1;
    }
    else{
        S_w2rep("Test case will not be repeated as minimum number of iterations and minimum number of iterations with reorg has been reached.");
        $repeatTestCase = 0;
    }
    $repeatTestCase = 0 if $main::opt_offline;
    
    if($repeatTestCase){
        S_repeat_testcase ( 1 ); # create separate HTML when repeating test case
    }


	#--------------------------------------------------------------
    # NUMBER OF EXPECTED RECORDS
    #
	S_teststep("--------------------------------------------------------", 'NO_AUTO_NBR');
	S_teststep("NUMBER OF EXPECTED RECORDS", 'NO_AUTO_NBR');
    S_teststep_expected_NOHTML("--------------------------------------------------------");
    S_teststep_expected_NOHTML("NUMBER OF EXPECTED RECORDS");
    S_teststep_detected_NOHTML("--------------------------------------------------------");
    S_teststep_detected_NOHTML("NUMBER OF EXPECTED RECORDS");

	my $detectedNbrOfStoredRecords = 0;
	foreach my $recordNumber (1..$edrNumberOfEventsToBeStored)
	{
		my $recordAvailable = $record_handler -> IsRecordAvailable("CrashLabel" => $tcpar_Crashcode1."_".$tcpar_Crashcode2,
		                                                           "RecordNumber"=> $recordNumber);
		$detectedNbrOfStoredRecords++ if ($recordAvailable);
	}
	S_teststep_expected("Expect minimum $tcpar_NbrOfRecordsExpected records to be stored", "read_crash_record_Iteration".$currentTestCaseIteration); #evaluation 1
	my $verdict= EVAL_evaluate_value("NumberOfRecords", $detectedNbrOfStoredRecords,'>=', $tcpar_NbrOfRecordsExpected);
	S_teststep_detected("Number of stored records is $detectedNbrOfStoredRecords", "read_crash_record_Iteration".$currentTestCaseIteration);
	if ($verdict ne "VERDICT_PASS" and not $main::opt_offline){
		S_w2rep(" Number of detected records is incorrect, hence no further EDID validation is done");
		return 1;
	}
	
	if($detectedNbrOfStoredRecords == 0) {
		S_w2rep("No further evaluation done since no record was stored.");
		return 1;
	}
	
    # Map record number to incident number to validate only expected mandatory
    my $recordNbrMandatoryComplete;
    my $recordMandatoryCompleteT0;
    if($detectedNbrOfStoredRecords == 1){
        $recordNbrMandatoryComplete = 1;
        $recordMandatoryCompleteT0 = $tcpar_CrashTimeZeroIncident1_ms if($tcpar_MandatoryDataStoredForIncident == 1);
        $recordMandatoryCompleteT0 = $tcpar_CrashTimeZeroIncident2_ms if($tcpar_MandatoryDataStoredForIncident == 2);
        $recordMandatoryCompleteT0 = $tcpar_CrashTimeZeroIncident3_ms if($tcpar_MandatoryDataStoredForIncident == 3);
    }
    else{
        $recordNbrMandatoryComplete = $detectedNbrOfStoredRecords - $tcpar_MandatoryDataStoredForIncident + 1
                    if($storageOrder eq 'MostRecentFirst');
        $recordNbrMandatoryComplete = $tcpar_MandatoryDataStoredForIncident
                    if($storageOrder eq 'MostRecentLast');
    }
    S_teststep("Validate mandatory data complete for incident $tcpar_MandatoryDataStoredForIncident ".
                    "stored in record $recordNbrMandatoryComplete", 'AUTO_NBR');

	#--------------------------------------------------------------
    # FIRE TIMES
    #
    S_teststep("--------------------------------------------------------", 'NO_AUTO_NBR');
    S_teststep("DEPLOYMENT TIMES", 'NO_AUTO_NBR');
    S_teststep_expected_NOHTML("--------------------------------------------------------");
    S_teststep_expected_NOHTML("DEPLOYMENT TIMES");
    S_teststep_detected_NOHTML("--------------------------------------------------------");
    S_teststep_detected_NOHTML("DEPLOYMENT TIMES");

	my $crashTimeZero_Total;
	if($detectedNbrOfStoredRecords == 1) {
		$crashTimeZero_Total = $recordMandatoryCompleteT0;
	}
	elsif($tcpar_CrashTimeZeroIncident1_ms == $tcpar_CrashTimeZeroIncident2_ms){
		$crashTimeZero_Total = $tcpar_CrashTimeZeroIncident1_ms;
	}
	elsif($detectedNbrOfStoredRecords == 2) {
		$crashTimeZero_Total = $tcpar_CrashTimeZeroIncident1_ms."_".$tcpar_CrashTimeZeroIncident2_ms;
	}
	else{
		$crashTimeZero_Total = $tcpar_CrashTimeZeroIncident1_ms."_".$tcpar_CrashTimeZeroIncident2_ms."_".$tcpar_CrashTimeZeroIncident3_ms;
	}
	S_w2rep("Crash time zero: $crashTimeZero_Total (ms)");
	my $squibVerdict = EDR_Eval_SquibFireTimes("CrashLabel" => $tcpar_Crashcode1."_".$tcpar_Crashcode2,
											   "EDID_SquibLabels" => $tcpar_FireTime_EDIDs,
											   "CrashTimeZero_ms" => $crashTimeZero_Total,
											   "FireTimeTolerance_ms" => $tcpar_FireTimeTolerance_ms,
											   "RecordNumber" => $recordNbrMandatoryComplete,
											   "MultiEventIncidentNumber" => $tcpar_MandatoryDataStoredForIncident,
											   "Autarky" => 'true');

	#--------------------------------------------------------------
    # RAW VALUES
    #
	my $rawValuesVerdict = 'VERDICT_PASS';

    S_teststep("--------------------------------------------------------", 'NO_AUTO_NBR');
    S_teststep("RAW VALUES", 'NO_AUTO_NBR');
    S_teststep_expected_NOHTML("--------------------------------------------------------");
    S_teststep_expected_NOHTML("RAW VALUES");
    S_teststep_detected_NOHTML("--------------------------------------------------------");
    S_teststep_detected_NOHTML("RAW VALUES");
    

    # Get expected value for warning lamp in incident 2 from fd measurement 
    my ($value, $time) = EVAL_get_value_around_time ( $fast_diag_data_HoH , $tcpar_CrashTimeZeroIncident2_ms , $tcpar_PD_Variable_WarningLamp);
    $tcpar_AWL_Status_Incident2 = sprintf("%02x", $value);
    if($storageOrder eq 'MostRecentLast') {
        $expectedRawValues_href -> {'AWL_Status'} = {"Record_1" => $tcpar_AWL_Status_Incident1,
                                                     "Record_2" => $tcpar_AWL_Status_Incident2};
		$expectedRawValues_href -> {'AWL_Status'} -> {"Record_3"} = $tcpar_AWL_Status_Incident2 if($tcpar_CrashTimeZeroIncident3_ms);
    }
    elsif($storageOrder eq 'MostRecentFirst') {
        $expectedRawValues_href -> {'AWL_Status'} = {"Record_1" => $tcpar_AWL_Status_Incident2,
                                                     "Record_2" => $tcpar_AWL_Status_Incident1};
		$expectedRawValues_href -> {'AWL_Status'} = {"Record_1" => $tcpar_AWL_Status_Incident2,
		                                             "Record_2" => $tcpar_AWL_Status_Incident2,
		                                             "Record_3" => $tcpar_AWL_Status_Incident1} if($tcpar_CrashTimeZeroIncident3_ms);
    }
    S_teststep_2nd_level("Use actual warning lamp status at start of second incident: $tcpar_AWL_Status_Incident2", 'AUTO_NBR');   

	foreach my $rawEDID (keys %{$tcpar_ExpectedValueRaw_EDIDs})
	{

		my $expectedRawValue_key = $tcpar_ExpectedValueRaw_EDIDs -> {$rawEDID};
		
		my $dataElement = $record_handler -> GetDataElementEDID( "EDIDnr" => $rawEDID,
																 "RecordNumber" => $recordNbrMandatoryComplete,
														     	 "CrashLabel" => $tcpar_Crashcode1."_".$tcpar_Crashcode2);

		my $expectedRawValue = $expectedRawValues_href -> {$expectedRawValue_key} -> {"Record_$recordNbrMandatoryComplete"};
		if ($expectedRawValue_key eq 'TimeFromPreviousToCurrent' and $expectedRawValue eq 'FFFF' and $tcpar_read_CHINAEDR eq 'yes'){
			$expectedRawValue='FF';	
		}

		if(not defined $expectedRawValue) {
			$expectedRawValue = $expectedRawValue_key;
		}

	    S_teststep_2nd_level("Validate EDID $rawEDID ($dataElement) in record $recordNbrMandatoryComplete",
	                           'AUTO_NBR',
	                           "EDID_$rawEDID\_Record_$recordNbrMandatoryComplete\_Iteration".$currentTestCaseIteration); #measurement 2
        S_teststep_expected_NOHTML("EDID $rawEDID, record $recordNbrMandatoryComplete");
        S_teststep_detected_NOHTML("EDID $rawEDID, record $recordNbrMandatoryComplete");

		my ($detectedEDIDvalue, $evalType, $tolerance_abs);
		if(ref $expectedRawValue eq 'HASH') {
            $tolerance_abs = $expectedRawValue -> {"Tolerance_abs"};
            $tolerance_abs = 0 if (not defined $tolerance_abs);
			$expectedRawValue = $expectedRawValue -> {"Decoded"};
			$detectedEDIDvalue = $record_handler -> GetDecodedEDID( "EDIDnr" => $rawEDID,
												   "RecordNumber" => $recordNbrMandatoryComplete,
												   "CrashLabel" => $tcpar_Crashcode1."_".$tcpar_Crashcode2,
													);
			$detectedEDIDvalue = $detectedEDIDvalue -> {"DataValue"};
			$evalType = 'Value';
			$evalType = 'String' if($detectedEDIDvalue =~ /[a-zA-Z]/);
		}
		else {
			$detectedEDIDvalue = $record_handler -> GetRawEDID( "EDIDnr" => $rawEDID,
												   "RecordNumber" => $recordNbrMandatoryComplete,
												   "CrashLabel" => $tcpar_Crashcode1."_".$tcpar_Crashcode2,
												   "FormatOption" => "HEX");			
			$evalType = 'String';
		}

		unless(defined $detectedEDIDvalue) {
			S_set_error("No data could be obtained for EDID $rawEDID in record $recordNbrMandatoryComplete.");
			next;
		}

		if(ref $detectedEDIDvalue eq 'ARRAY') {
			my $detectedEDIDvalueString;
			foreach my $hexElement (@{$detectedEDIDvalue})
			{
				$detectedEDIDvalueString .= $hexElement;
			}
			$detectedEDIDvalue = $detectedEDIDvalueString;
		}

		my $verdict;
        $verdict = EVAL_evaluate_string ( "EDID_$rawEDID\_Evaluation", $expectedRawValue, $detectedEDIDvalue ) if ($evalType eq 'String');
        $verdict = EVAL_evaluate_value ( "EDID_$rawEDID\_Evaluation",
                                         $detectedEDIDvalue,
                                         '==',
                                         $expectedRawValue,
                                         $tolerance_abs,
                                         'absolute' ) if ($evalType eq 'Value');
		S_teststep_expected("EDID $rawEDID record $recordNbrMandatoryComplete expected: 0x$expectedRawValue",
		                      "EDID_$rawEDID\_Record_$recordNbrMandatoryComplete\_Iteration".$currentTestCaseIteration);
		S_teststep_detected("EDID $rawEDID record $recordNbrMandatoryComplete detected: 0x$detectedEDIDvalue",
		                      "EDID_$rawEDID\_Record_$recordNbrMandatoryComplete\_Iteration".$currentTestCaseIteration);
	}

	#--------------------------------------------------------------
    # NON DEFAULT VALUES
    #
    S_teststep("--------------------------------------------------------", 'NO_AUTO_NBR');
    S_teststep("NON DEFAULT VALUE", 'NO_AUTO_NBR');
    S_teststep_expected_NOHTML("--------------------------------------------------------");
    S_teststep_expected_NOHTML("NON DEFAULT VALUE");
    S_teststep_detected_NOHTML("--------------------------------------------------------");
    S_teststep_detected_NOHTML("NON DEFAULT VALUE");

	foreach my $nonDefaultEDID (keys %{$tcpar_NonDefault_EDIDs})
	{
		my $defaultValue = $tcpar_NonDefault_EDIDs -> {$nonDefaultEDID};
		my $dataElement = $record_handler -> GetDataElementEDID( "EDIDnr" => $nonDefaultEDID,
		                                                         "RecordNumber" => $recordNbrMandatoryComplete,
														         "CrashLabel" => $tcpar_Crashcode1."_".$tcpar_Crashcode2);

	    S_teststep_2nd_level("Check that EDID $nonDefaultEDID ($dataElement) has non default value in record $recordNbrMandatoryComplete",
	                           'AUTO_NBR',
	                           "EDID_$nonDefaultEDID\_Record_$recordNbrMandatoryComplete\_Iteration".$currentTestCaseIteration); #measurement 2
        S_teststep_expected_NOHTML("EDID $nonDefaultEDID, record $recordNbrMandatoryComplete");
        S_teststep_detected_NOHTML("EDID $nonDefaultEDID, record $recordNbrMandatoryComplete");
		my $detectedEDIDvalue = $record_handler -> GetRawEdidDataSamples( "EDIDnr" => $nonDefaultEDID,
                                               "RecordNumber" => $recordNbrMandatoryComplete,
                                               "CrashLabel" => $tcpar_Crashcode1."_".$tcpar_Crashcode2,
                                               "FormatOption" => "HEX");

		unless(defined $detectedEDIDvalue) {
			S_set_error("No data could be obtained for EDID $nonDefaultEDID.");
			next;
		}

		if(ref $detectedEDIDvalue eq 'ARRAY') {
		    my $dataSample = 1;

			my $recStartTime_ms = $record_handler -> GetRecStartTimeMillisecEDID("EDIDnr" => $nonDefaultEDID,
                                               "RecordNumber" => $recordNbrMandatoryComplete,
                                               "CrashLabel" => $tcpar_Crashcode1."_".$tcpar_Crashcode2);
            $recStartTime_ms = 0 if($recStartTime_ms eq 'T0');                                  
			my $sampleRate_Hz = $record_handler -> Get_EDID_SampleRateHz("EDIDnr" => $nonDefaultEDID,
                                               "RecordNumber" => $recordNbrMandatoryComplete,
                                               "CrashLabel" => $tcpar_Crashcode1."_".$tcpar_Crashcode2);                                
            my $mandatoryDataDuration_sec = (300 - $recStartTime_ms) * 0.001;
            my $mandatoryDataSamples = $mandatoryDataDuration_sec * $sampleRate_Hz + 1;
            my $maxDataSampleNbr;

            if(@{$detectedEDIDvalue} > $mandatoryDataSamples){
                $maxDataSampleNbr = $mandatoryDataSamples;
				S_w2rep("Evaluate only $maxDataSampleNbr data samples which are mandatory");
            }
            else{
            	$maxDataSampleNbr = @{$detectedEDIDvalue};
				S_w2rep("Evaluate all $maxDataSampleNbr data samples");
            }


			foreach my $edidValue (@{$detectedEDIDvalue})
			{

                
                S_teststep_2nd_level("EDID $nonDefaultEDID, data sample $dataSample",
                                        'AUTO_NBR',
                                        "EDID_$nonDefaultEDID\_Record_$recordNbrMandatoryComplete\_sample_$dataSample\_Iteration".$currentTestCaseIteration);
		        EVAL_evaluate_string ( "EDID_$nonDefaultEDID\_Evaluation_$dataSample", $defaultValue, $edidValue, '!=');
                S_teststep_expected(" != $defaultValue",
                                        "EDID_$nonDefaultEDID\_Record_$recordNbrMandatoryComplete\_sample_$dataSample\_Iteration".$currentTestCaseIteration);
                S_teststep_detected("$edidValue",
                                        "EDID_$nonDefaultEDID\_Record_$recordNbrMandatoryComplete\_sample_$dataSample\_Iteration".$currentTestCaseIteration);
                last if($dataSample == $maxDataSampleNbr);
                $dataSample++;
			}
		}
		else {
            S_teststep_expected(" != $defaultValue",
                                    "EDID_$nonDefaultEDID\_Record_$recordNbrMandatoryComplete\_Iteration".$currentTestCaseIteration);
            S_teststep_detected("$detectedEDIDvalue",
                                    "EDID_$nonDefaultEDID\_Record_$recordNbrMandatoryComplete\_Iteration".$currentTestCaseIteration);
	        EVAL_evaluate_string ( "EDID_$nonDefaultEDID\_Evaluation", $defaultValue, $detectedEDIDvalue, '!=');
		}

	#next EDID
	}	
	
    #--------------------------------------------------------------
    # MINIMUM AUTARKY TIME
    #
    S_teststep("--------------------------------------------------------", 'NO_AUTO_NBR');
    S_teststep("MINIMUM AUTARKY TIME", 'NO_AUTO_NBR');
    S_teststep_expected_NOHTML("--------------------------------------------------------");
    S_teststep_expected_NOHTML("MINIMUM AUTARKY TIME");
    S_teststep_detected_NOHTML("--------------------------------------------------------");
    S_teststep_detected_NOHTML("MINIMUM AUTARKY TIME");

    S_teststep_2nd_level("Mandatory data for incident $tcpar_MandatoryDataStoredForIncident must be stored within minimum autarky time",
                            'AUTO_NBR', "Min_Autarky_Time_Iteration".$currentTestCaseIteration); #measurement 2


    # Get expected value from SYC
    my ($status, $expectedMinAutarkyTime_ms) = SYC_POWERSUPPLY_get_MinAutarkyTime();
    unless($status){
        S_teststep_expected("EDR mandatory data complete within minimum autarky time defined in SYC",
                                "Min_Autarky_Time_Iteration".$currentTestCaseIteration);
        S_teststep_detected("Minimum autarky time could not be obtained from SYC",
                                "Min_Autarky_Time_Iteration".$currentTestCaseIteration);
        S_set_verdict('VERDICT_FAIL');
        return 1;
    }

    S_teststep_expected("EDR mandatory data complete within minimum autarky time of $expectedMinAutarkyTime_ms ms",
                            "Min_Autarky_Time_Iteration".$currentTestCaseIteration);
    S_add2eval_collection( "EXP_StorageTime", $expectedMinAutarkyTime_ms );

    my $publicHeaderIndex = $tcpar_MandatoryDataStoredForIncident - 1; # public header in physical order, but starting count from 0
    my $timeCompletelyStored = EVAL_get_time_when( $fast_diag_data_HoH ,
                                    "rb_dcc_HeaderPublic_st.MandatoryDataRecCompltStatus_aen($publicHeaderIndex)" ,
                                    "==" ,
                                    0x5A );
    if($timeCompletelyStored == -1){
        S_teststep_detected("PD variable rb_dcc_HeaderPublic_st.MandatoryDataRecCompltStatus_aen($publicHeaderIndex) ".
                                "does not indicate record completeness at all", "Min_Autarky_Time_Iteration".$currentTestCaseIteration);
        S_set_verdict("VERDICT_FAIL");
        S_w2rep("No further evaluations done as autarky start time can't be calculated!");
        return 1;
    }

    S_w2rep("Incident $tcpar_MandatoryDataStoredForIncident mandatory data is complete at $timeCompletelyStored (Fast Diag Time Base)");

    my $incidentStartTime;
    my $regularEventStartTime = EVAL_get_time_when( $fast_diag_data_HoH ,
                                    'rb_evm_EventTimer_au16(0)' ,
                                    ">=" ,
                                    1 ,
                                    0,
                                    $timeCompletelyStored);

    my $firstEventStartTime;
    if($specialEventTimerExists){
        my $specialEventStartTime = EVAL_get_time_when( $fast_diag_data_HoH ,
                                    'rb_evm_EventTimer_au16(1)' ,
                                    ">=" ,
                                    1,
                                    0,
                                    $timeCompletelyStored);

        if($regularEventStartTime == -1){
            $firstEventStartTime = $specialEventStartTime;
        }
        elsif($specialEventStartTime == -1){
            $firstEventStartTime = $regularEventStartTime;
        }
        elsif($specialEventStartTime >= $regularEventStartTime){
            $firstEventStartTime = $regularEventStartTime;
        }
         else{
            $firstEventStartTime = $specialEventStartTime;
        }
    }
    else{
        $firstEventStartTime = $regularEventStartTime;
    }
    
    if($firstEventStartTime == -1){
        S_teststep_detected("Event timer for regular and special event have both not started - no event seems to have occured.", 
                            "Min_Autarky_Time_Iteration".$currentTestCaseIteration);
        S_set_verdict("VERDICT_FAIL");
        return 1;        
    }
    
    S_w2rep("First incident starts at: $firstEventStartTime ms  (Fast Diag Time Base)");
    
    my $storedIncidentStartTime;
    $storedIncidentStartTime = $firstEventStartTime if($tcpar_MandatoryDataStoredForIncident == 1);
    $storedIncidentStartTime = $firstEventStartTime + ($tcpar_CrashTimeZeroIncident2_ms - $tcpar_CrashTimeZeroIncident1_ms)
                if($tcpar_MandatoryDataStoredForIncident == 2);
    $storedIncidentStartTime = $firstEventStartTime + ($tcpar_CrashTimeZeroIncident3_ms - $tcpar_CrashTimeZeroIncident2_ms)
                if($tcpar_MandatoryDataStoredForIncident == 3);

    S_w2rep("Stored incident number $tcpar_MandatoryDataStoredForIncident starts at: $storedIncidentStartTime ms  (Fast Diag Time Base)");
    
    # Power is cut at start of second crashcode
    my $autarkyStartTime_ms;
    if(defined $tcpar_CrashCodeNumber_MultiEvent and $tcpar_CrashCodeNumber_MultiEvent == 1){
        $autarkyStartTime_ms = $firstEventStartTime
                               + ($tcpar_CrashTimeZeroIncident3_ms - $tcpar_CrashTimeZeroIncident1_ms)
                               + $tcpar_AutarkyOccuredAtTime_ms;
    }
    else{
        $autarkyStartTime_ms = $firstEventStartTime
                               + ($tcpar_CrashTimeZeroIncident2_ms - $tcpar_CrashTimeZeroIncident1_ms)
                               + $tcpar_AutarkyOccuredAtTime_ms;
    }

    S_w2rep("Autarky starts at: $autarkyStartTime_ms ms  (Fast Diag Time Base)");


    my $requiredStorageTimeMandatoryData_ms;
    if($autarkyStartTime_ms >= $timeCompletelyStored){
        $requiredStorageTimeMandatoryData_ms = $timeCompletelyStored - $storedIncidentStartTime;
        S_w2rep("Required time for storage is $requiredStorageTimeMandatoryData_ms according to Fast Diag measurement".
                " (mandatory data flag updated in RAM).\n".
                "Add 30ms which is the worst case time required to store the header data from RAM to NVM.");

        $requiredStorageTimeMandatoryData_ms = $requiredStorageTimeMandatoryData_ms + 30;

        S_teststep_detected("Complete storage of mandatory data of incident $tcpar_MandatoryDataStoredForIncident before autarky starts".
                            " (time required: $requiredStorageTimeMandatoryData_ms ms)",
                    		"Min_Autarky_Time_Iteration".$currentTestCaseIteration);
        S_add2eval_collection( "DET_StorageTime", $requiredStorageTimeMandatoryData_ms );
        S_set_verdict("VERDICT_PASS");           
    }
    else{
        $requiredStorageTimeMandatoryData_ms = $timeCompletelyStored - $storedIncidentStartTime 
                if($storedIncidentStartTime >= $autarkyStartTime_ms);

        $requiredStorageTimeMandatoryData_ms = $timeCompletelyStored - $autarkyStartTime_ms 
                if($storedIncidentStartTime < $autarkyStartTime_ms);
 
        S_w2rep("Required time for storage is $requiredStorageTimeMandatoryData_ms according to Fast Diag measurement".
                " (mandatory data flag updated in RAM).\n".
                "Add 30ms which is the worst case time required to store the header data from RAM to NVM.");
        my $requiredStorageTimeMandatoryDataComplete_ms = $requiredStorageTimeMandatoryData_ms + 30;
        S_teststep_detected("Complete storage of mandatory data of incident $tcpar_MandatoryDataStoredForIncident ".
                            "after $requiredStorageTimeMandatoryDataComplete_ms ms (actual $requiredStorageTimeMandatoryData_ms ms + 30 ms)",
                        "Min_Autarky_Time_Iteration".$currentTestCaseIteration);

        S_add2eval_collection( "DET_StorageTime", $requiredStorageTimeMandatoryDataComplete_ms );

        EVAL_evaluate_value ( "AutarkyStorageTime", $requiredStorageTimeMandatoryDataComplete_ms, '<', $expectedMinAutarkyTime_ms);
    }

    #--------------------------------------------------------------
    # NVM VARIABLES
    #
    S_teststep("--------------------------------------------------------", 'NO_AUTO_NBR');
    S_teststep("NVM VARIABLES", 'NO_AUTO_NBR');
    S_teststep_expected_NOHTML("--------------------------------------------------------");
    S_teststep_expected_NOHTML("NVM VARIABLES");
    S_teststep_detected_NOHTML("--------------------------------------------------------");
    S_teststep_detected_NOHTML("NVM VARIABLES");

        # --- 1 --- No soft Reorg
        # Fee_rb_workingtsate_en is always 0 or 1, 6 is accepted (hard reorg)
    S_teststep_2nd_level("NVM should not start any soft reorganisation",
                            'AUTO_NBR', "Nvm_Reorg_".$currentTestCaseIteration); #measurement 2

    S_teststep_expected("Fee_Rb_WorkingState_en != 5 (soft reorg)", "Nvm_Reorg_".$currentTestCaseIteration);

    EVAL_evaluate_values_existence ($fast_diag_data_HoH,
                                     "Fee_Rb_WorkingState_en" ,
                                     {'NEVER' => [5]}, # 5: Softreorg, 6: Hardreorg
                                     $autarkyStartTime_ms);
                                            
    my $detectedValuesString;
    $time = EVAL_get_time_when ( $fast_diag_data_HoH , "Fee_Rb_WorkingState_en" , "==" , 0, $autarkyStartTime_ms);
    $detectedValuesString = "0 (no activity), " if($time != -1);
    $time = EVAL_get_time_when ( $fast_diag_data_HoH , "Fee_Rb_WorkingState_en" , "==" , 1, $autarkyStartTime_ms);
    $detectedValuesString .= "1 (writing), " if($time != -1);
    $time = EVAL_get_time_when ( $fast_diag_data_HoH , "Fee_Rb_WorkingState_en" , "==" , 5, $autarkyStartTime_ms);
    $detectedValuesString .= "5 (soft-reorg), " if($time != -1);
    $time = EVAL_get_time_when ( $fast_diag_data_HoH , "Fee_Rb_WorkingState_en" , "==" , 6, $autarkyStartTime_ms);
    $detectedValuesString .= "6 (hard-reorg), " if($time != -1);
    S_teststep_detected("$detectedValuesString", "Nvm_Reorg_".$currentTestCaseIteration);
     
        # --- 2 --- No pending requests
        # NvM_Prv_stRequests_rAMwAM_au16(0) is 0
    S_teststep_2nd_level("NVM should not have any pending requests",
                            'AUTO_NBR', "Nvm_Pending_Req_".$currentTestCaseIteration); #measurement 2

    S_teststep_expected("NvM_Prv_stRequests_rAMwAM_au16(0) != 1 (pending)", "Nvm_Pending_Req_".$currentTestCaseIteration);

    EVAL_evaluate_values_existence ( $fast_diag_data_HoH,
                                      "NvM_Prv_stRequests_rAMwAM_au16(0)" ,
                                      {'NEVER' => [1]} # 1: pending
                                      , $autarkyStartTime_ms);
                                            
    my $detectedValuesPendingReqString;
    my $timePendingReq = EVAL_get_time_when ( $fast_diag_data_HoH , "NvM_Prv_stRequests_rAMwAM_au16(0)" , "==" , 0, $autarkyStartTime_ms);
    $detectedValuesPendingReqString = "0 (no activity), " if($timePendingReq != -1);
    $timePendingReq = EVAL_get_time_when ( $fast_diag_data_HoH , "NvM_Prv_stRequests_rAMwAM_au16(0)" , "==" , 1, $autarkyStartTime_ms);
    $detectedValuesPendingReqString .= "1 (writing), " if($timePendingReq != -1);
    S_teststep_detected("$detectedValuesPendingReqString", "Nvm_Pending_Req_".$currentTestCaseIteration);

        # --- 3 --- DEM should not trigger storage
        # Dem_NvMImmediateStorageRequested is 0
    S_teststep_2nd_level("DEM should not trigger storage",
                            'AUTO_NBR', "Dem_Storage".$currentTestCaseIteration); #measurement 2

    S_teststep_expected("Dem_NvMImmediateStorageRequested != 1 (Storage requested)", "Dem_Storage".$currentTestCaseIteration);

    EVAL_evaluate_values_existence ( $fast_diag_data_HoH,
                                      "Dem_NvMImmediateStorageRequested" ,
                                      {'NEVER' => [1]} # 1: Storage is requested
                                      , $autarkyStartTime_ms);
                                            
    my $detectedValuesDemReqString;
    my $timeDemReq = EVAL_get_time_when ( $fast_diag_data_HoH , "Dem_NvMImmediateStorageRequested" , "==" , 0, $autarkyStartTime_ms);
    $detectedValuesDemReqString = "0 (Storage not requested), " if($timeDemReq != -1);
    $timeDemReq = EVAL_get_time_when ( $fast_diag_data_HoH , "Dem_NvMImmediateStorageRequested" , "==" , 1, $autarkyStartTime_ms);
    $detectedValuesDemReqString .= "1 (Storage is requested), " if($timeDemReq != -1);
    S_teststep_detected("$detectedValuesDemReqString", "Dem_Storage".$currentTestCaseIteration);

	return 1;
}

sub TC_finalization {

    if($tcpar_DeviceOpenLineBeforeCrash){
        S_w2rep("Remove open line fault for device $tcpar_DeviceOpenLineBeforeCrash before crash and wait 5sec for fault dequalification");
        LC_ConnectLine($tcpar_DeviceOpenLineBeforeCrash);
        S_wait_ms(5000);
    }

	# Erase EDR
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(2000);

	# Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	# Read fault memory after clearing and erasing EDR
    LIFT_FaultMemory -> read_fault_memory('Bosch');

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

	S_w2rep("Clean up record and crash handler");
    $record_handler -> DeleteAllRecords();
    $crash_handler -> DeleteAllSources();


	return 1;
}


1;
