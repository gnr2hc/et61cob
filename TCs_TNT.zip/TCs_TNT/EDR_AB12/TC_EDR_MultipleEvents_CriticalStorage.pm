#### TEST CASE MODULE
package TC_EDR_MultipleEvents_CriticalStorage;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
#include further modules here
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use GENERIC_DCOM;
use LIFT_can_access;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;
use Data::Dumper;

##################################

our $PURPOSE = "<summarize what this test is good for>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_Basic_General

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFaultNoCT


I<B<Stimulation and Measurement>>

1. Set environments for crash.

2. Power up ECU

3. Start recording of fire times.

4. Inject <Crashtype> and cut power at T0 if <CrashCondition> is Autarky.

5. Wait for <WaitTime_ms>

6. Stop recording of fire times

7. Power down ECU

8. Power up ECU

9. Read EDR

10. Compare all given EDIDs to <ExpectedValueRaw>


I<B<Evaluation>>

1. - 

2. - 

3. - 

4. -

5. - 

6. - 

7. - 

8. - 

9. -

10. Value of EDIDs is as expected.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'Crashcode' => 
	SCALAR 'Autarky' => 
	SCALAR 'ResultDB' => 
	HASH   'EDIDs_Incident1' => 
	HASH   'EDIDs_Incident2' => 
	SCALAR 'DiagType' => 
	HASH   'COMSignalsAfterCrash' => Key: Signal name, Value: value to set after crash


=head2 PARAMETER EXAMPLES

	purpose		 = 'check crash record for correct and complete storage of multi-event <Test Heading Head>_<Test Heading 2> with <Test Heading Tail>'
	
	# ---------- Stimulation ------------ 
	ResultDB = 'EDR'
	DiagType = 'ProdDiag'
	Crashcode = 'Multi_EDR_SideAD_FrontND'
	Autarky = 'true'
	COMSignalsAfterCrash = %()
	
	# ---------- Evaluation ------------ 
	# ID => 'ExpectedRawValue'
	EDIDs_Incident1 = %('1000' => '5A', '4' => 'FF', '5' => '0')
	EDIDs_Incident2 = %('1000' => '5A', '4' => '0', '5' => 'FF')

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Crashcode;
my $tcpar_ResultDB;
my $tcpar_DiagType;
my $tcpar_Autarky;
my $tcpar_EDIDs_Incident1;
my $tcpar_EDIDs_Incident2;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_CrashTimeZero_ms;
my $tcpar_MadatoryDataStored_Incident;
my $tcpar_read_NHTSAEDR;
my $tcpar_read_CHINAEDR;
################ global parameter declaration ###################
#add any global variables here
my ($record_handler, $crashSettings, $edrNumberOfEventsToBeStored,$ChinaEDR_diagType);

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_Crashcode =  S_read_mandatory_testcase_parameter( 'Crashcode' );
	$tcpar_EDIDs_Incident1 =  S_read_mandatory_testcase_parameter( 'EDIDs_Incident1', 'byref' );
	$tcpar_EDIDs_Incident2 =  S_read_mandatory_testcase_parameter( 'EDIDs_Incident2', 'byref' );
	$tcpar_CrashTimeZero_ms =  S_read_mandatory_testcase_parameter( 'CrashTimeZero_ms');
	$tcpar_DiagType = S_read_mandatory_testcase_parameter( 'DiagType');
	$tcpar_MadatoryDataStored_Incident = S_read_optional_testcase_parameter( 'MadatoryDataStored_Incident');
	$tcpar_ResultDB =  S_read_optional_testcase_parameter( 'ResultDB' );
	$tcpar_ResultDB = 'DEFAULT' unless(defined $tcpar_ResultDB);
	$tcpar_Autarky =  S_read_optional_testcase_parameter( 'Autarky' );
	$tcpar_Autarky = 'false' unless(defined $tcpar_Autarky);
	$tcpar_COMsignalsAfterCrash =  S_read_optional_testcase_parameter( 'COMsignalsAfterCrash','byref');
	$tcpar_read_NHTSAEDR=S_read_optional_testcase_parameter('read_NHTSAEDR');
	$tcpar_read_CHINAEDR=S_read_optional_testcase_parameter('read_CHINAEDR');
	
	if(not defined $tcpar_read_CHINAEDR) {
		$tcpar_read_NHTSAEDR = 'yes';
		$tcpar_read_CHINAEDR = 'no';
	}
	else {
		$tcpar_read_NHTSAEDR = 'no';
		my $storageOrder = EDR_getStorageOrder();
		return unless(defined $storageOrder);

		if($storageOrder eq 'PhysicalOrder'){
			$ChinaEDR_diagType= 'ProdDiag';  #In platform NHTSA and China EDR is read via proddiag
		}
		else {
			$ChinaEDR_diagType= 'CHINA_Payload';
		}
	}

	return 1;
}

sub TC_initialization {

	S_teststep("Test setup preparation", 'AUTO_NBR');

	#--------------------------------------------------------------
    # INITIALIZE RECORD HANDLER
    #    
	S_w2rep("Initialize Record Handler");
	$record_handler = EDR_init_RecordHandler() || return;

	#--------------------------------------------------------------
    # PREPARE CRASH AND INITIALIZE EQUIPMENT
    #
	S_w2rep("Get crash settings for crash $tcpar_Crashcode");
    my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode};
    $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
    unless(defined $crashSettings) {
        S_set_error("Crash $tcpar_Crashcode not available in result DB $tcpar_ResultDB. Test case aborted.");
        return;
    }

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log(1, "Crashcode: $tcpar_Crashcode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");

	S_w2log(1, "Power on ECU");
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');
    
    S_w2log(1, "Initialize CD and start CAN trace");
    GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start ( );
 
	S_w2log(1, "Set environments for crash as per result DB");
    CSI_PrepareEnvironment($crashSettings, 'init_complete');
	S_wait_ms(2000);

	S_w2log(1, "Clear crash recorder");
    PD_ClearCrashRecorder();
    S_wait_ms(2000);

	S_w2log(1, "Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	S_w2log(1, "Reset ECU");
    PD_ECUreset();
    S_wait_ms('TIMER_ECU_READY');

	S_w2log(1, "Read and evaluate fault memory before stimulation");
    my $faultsBeforeStimulation = PD_ReadFaultMemory();
    my $faultsVerdict = PD_evaluate_faults( $faultsBeforeStimulation, []);
  	return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

	return 1;
}

sub TC_stimulation_and_measurement {

	#--------------------------------------------------------------
    # CRASH PREPARATION
    #
	S_teststep("Prepare crash", 'AUTO_NBR');
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	# Prepare crash
    CSI_LoadCrashSensorData2Simulator($crashSettings);

	# Power ON the ECU
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');
	
	CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    S_wait_ms(1000);

	#--------------------------------------------------------------
    # CRASH INJECTION
    #
	S_teststep("Start recording of fire times.", 'AUTO_NBR');
    LC_MeasureTraceDigitalStart();
    
    # Calculate time zero of second incident for power cutting
    my @crashTimeZero_array = split(/_/, $tcpar_CrashTimeZero_ms);
    my $timeZeroSecondIncident = $crashTimeZero_array[1];

	S_teststep("Inject '$tcpar_Crashcode'", 'AUTO_NBR');
	CSI_TriggerCrash();
	if ($tcpar_Autarky eq 'true') {
		S_teststep("Cut power at T0 of second incident ($timeZeroSecondIncident ms)", 'AUTO_NBR');
		S_wait_ms($timeZeroSecondIncident);
		LC_ECU_Off();
	}

	S_teststep("Wait for '15000' ms", 'AUTO_NBR');
    S_wait_ms(15000);

	S_teststep("Stop recording of fire times", 'AUTO_NBR');
    LC_MeasureTraceDigitalStop();

    if (defined $tcpar_COMsignalsAfterCrash){
        foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
        {               
            my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
            S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
            COM_setSignalState($signal,$dataOnCOM); 
        }
    }

	S_teststep("Power down ECU", 'AUTO_NBR');
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep("Power up ECU", 'AUTO_NBR');
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	S_wait_ms(2000);

	#--------------------------------------------------------------
    # MEASUREMENTS
    #
	S_teststep("Read EDR", 'AUTO_NBR', 'read_edr'); #measurement 1
    my $dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_".$tcpar_Crashcode;

	$edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();

	PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');

   	if ( lc( $tcpar_read_NHTSAEDR) eq 'yes' ) {
		EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
								"CrashLabel" => $tcpar_Crashcode,
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								"read_EDRType"=>'NHTSA')
	}
	if (lc($tcpar_read_CHINAEDR) eq 'yes'){
		$edrNumberOfEventsToBeStored=3;
		EDR_ReadAndStoreAllRecords ("DiagType" =>  $ChinaEDR_diagType,
								"CrashLabel" =>   $tcpar_Crashcode,
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								"read_EDRType"=>'CHINA');
	}	
    my $lct_Data = LC_MeasureTraceDigitalGetValues();
	EVAL_dump2UNV( $lct_Data, "$dataStoragePath/LCT_Measurement_$tcpar_Crashcode.txt.unv" );

	return 1;
}

sub TC_evaluation {

	my $storageOrder = EDR_getStorageOrder();
    return unless(defined $storageOrder);

    if($storageOrder eq 'PhysicalOrder'){
       $storageOrder =  'MostRecentLast'; #same behavior as there is no overwriting
    }
	
	my $detectedNbrOfStoredRecords;
	if ($tcpar_Autarky eq 'true'){
        S_teststep("--- Number of records in autarky ---", 'NO_AUTO_NBR');
        S_teststep_expected_NOHTML("--- Number of records in autarky ---");
        S_teststep_detected_NOHTML("--- Number of records in autarky ---");
        S_teststep("Check number of stored records in autarky", 'AUTO_NBR', 'Nbr_of_records_autarky');
        S_teststep_expected("1 or 2 records stored", 'Nbr_of_records_autarky');
		$detectedNbrOfStoredRecords = 0;
		for(my $recordNumber = 1; $recordNumber <= $edrNumberOfEventsToBeStored; $recordNumber++)
		{
			my $recordAvailable = $record_handler -> IsRecordAvailable("CrashLabel" => $tcpar_Crashcode, "RecordNumber"=> $recordNumber);
			$detectedNbrOfStoredRecords++ if ($recordAvailable);
		}
        S_teststep_detected("$detectedNbrOfStoredRecords records stored", 'Nbr_of_records_autarky');
        if($detectedNbrOfStoredRecords == 0){
            S_set_verdict('VERDICT_FAIL');
            return 1;
        }
        else {
            S_set_verdict('VERDICT_PASS');
        }
	}
	
	foreach my $incident (1..2)
	{
		my $recordNbr;
		$recordNbr = 3 - $incident if ($storageOrder eq 'MostRecentFirst');
		$recordNbr = $incident if($storageOrder eq 'MostRecentLast');
		
		my $edidsToEvaluate_href;
		# Match incidents for autarky		
		if ( defined $detectedNbrOfStoredRecords){

            if($incident == 1 and $tcpar_MadatoryDataStored_Incident eq 'First'){
                $edidsToEvaluate_href = $tcpar_EDIDs_Incident1;
            }
            elsif($incident == 2 and $tcpar_MadatoryDataStored_Incident eq 'Second'){
                $edidsToEvaluate_href = $tcpar_EDIDs_Incident2;
            }
            else {
                S_w2rep("Data storage not expected for this incident in autarky. Skip validation");
                next;
            }           
			$recordNbr = 1 if($detectedNbrOfStoredRecords ==1);		
		}
		else {
			$edidsToEvaluate_href = $tcpar_EDIDs_Incident1 if($incident == 1);
			$edidsToEvaluate_href = $tcpar_EDIDs_Incident2 if($incident == 2);	
		}

        S_teststep("--- Incident $incident (stored in record $recordNbr) ---", 'NO_AUTO_NBR');
        S_teststep_expected_NOHTML("--- Incident $incident (stored in record $recordNbr) ---");
        S_teststep_detected_NOHTML("--- Incident $incident (stored in record $recordNbr) ---");

		foreach my $rawEDID (keys %{$edidsToEvaluate_href})
		{
			my $expectedRawValue = $edidsToEvaluate_href -> {$rawEDID};
			my $dataElement = $record_handler -> GetDataElementEDID( "EDIDnr" => $rawEDID, "RecordNumber" => $recordNbr,
															      "CrashLabel" => $tcpar_Crashcode);

			S_teststep("Validate EDID $rawEDID ($dataElement) for incident $incident in record $recordNbr", 'AUTO_NBR', "EDID_$rawEDID\_incident_$incident");

			S_w2log(1, "Get EDID data for $tcpar_Crashcode, Record $recordNbr");
			my $detectedEDIDvalue = $record_handler -> GetRawEDID( "EDIDnr" => $rawEDID,
                                                   "RecordNumber" => $recordNbr,
                                                   "CrashLabel" => $tcpar_Crashcode,
                                                   "FormatOption" => "HEX");

			if(ref $detectedEDIDvalue eq 'ARRAY') {
				my $detectedEDIDvalue_string;
				foreach my $edidValue (@{$detectedEDIDvalue})
				{
					$detectedEDIDvalue_string .= $edidValue;
				}
				$detectedEDIDvalue = $detectedEDIDvalue_string
			}

			unless(defined $detectedEDIDvalue) {
				S_set_error("No data could be obtained for EDID $rawEDID in record $recordNbr.");
				next;
			}

	        EVAL_evaluate_string ( "EDID_$rawEDID\_Evaluation", $expectedRawValue, $detectedEDIDvalue );
			S_teststep_expected("EDID $rawEDID: $expectedRawValue", "EDID_$rawEDID\_incident_$incident"); #evaluation 4
			S_teststep_detected("EDID $rawEDID: $detectedEDIDvalue", "EDID_$rawEDID\_incident_$incident");
		}	
		if ($detectedNbrOfStoredRecords == 1){	
			S_w2rep("Only one record is obtained during autarky, hence evaluation is completed");
			return 1;
		}		
	}

	return 1;
}

sub TC_finalization {

	# Erase EDR
    PD_ClearCrashRecorder();
    S_wait_ms(2000);

	# Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	# Reset ECU    
    PD_ECUreset();
    S_wait_ms('TIMER_ECU_READY');

	# Read fault memory after clearing and erasing EDR
    PD_ReadFaultMemory();   

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');
    
	S_w2rep("Clean up record handler");
    $record_handler -> DeleteAllRecords();

	return 1;
}


1;
