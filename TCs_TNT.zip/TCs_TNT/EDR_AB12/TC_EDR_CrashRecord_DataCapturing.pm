#### TEST CASE MODULE
package TC_EDR_CrashRecord_DataCapturing;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
use constant MILLISEC_TO_SECOND => 0.001;
use FuncLib_EDR_Framework;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;

#include further modules here
use LIFT_crash_simulation;
use LIFT_ProdDiag;
use LIFT_FaultMemory;
use GENERIC_DCOM;
use LIFT_labcar;
use LIFT_can_access;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use FuncLib_SYC_INTERFACE;
use FuncLib_EDR_Framework;

##################################

our $PURPOSE = "<To check that static and dynamic data are recorded for the correct time (static: until EoE; dynamic: until capture interval exceeded)>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_CrashRecord_DataCapturing

=head1 PURPOSE

<To check that static and dynamic data are recorded for the correct time (static: until EoE; dynamic: until capture interval exceeded)>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFaultNoCT


I<B<Stimulation and Measurement>>

1. Power up ECU

2. Inject <crashtype>

3. Wait for <wait_ms>

4. Power down ECU

5. Power up ECU

6. Read EDR


I<B<Evaluation>>

1. - 

2. - 

3. - 

4. - 

5. - 

6. Read all crash telegrams stored in NVM and check for the right length of <EDIDs> compared to <capture_interval> (storing of static or dynamic data)


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

	SCALAR 'Crashcode' => 
	SCALAR 'CrashTimeZero_ms' => 
	SCALAR 'capture_interval' => 
	SCALAR 'DataType' => 
	SCALAR 'SensorLabel' => 
	SCALAR 'EvalType' => 
	SCALAR 'EvalUnit' => 
	SCALAR 'EvalTolerance_abs' => 
	SCALAR 'EDIDs' => 
	SCALAR 'purpose' => 
	SCALAR 'DiagType' => 
	SCALAR 'ResultDB' => 
	HASH 'COMsignalsAfterCrash' => 


=head2 PARAMETER EXAMPLES

	purpose = 'Inject <Test Heading 2>_<Test Heading Tail> crash and evaluate record with respect to capturing of  <Test Heading Head> data elements' # description of test case
	
	# ---------- Stimulation ------------ 
	DiagType = 'ProdDiag'
	ResultDB = 'EDR'
	COMsignalsAfterCrash = %()
	Crashcode = 'Single_EDR_Front_AD_shorter250ms'
	CrashTimeZero_ms = '131.76'
	capture_interval = 250 #ms
	DataType = 'Dynamic'
	SensorLabel = 'ECU: Acc_HG: M45: SMA660_sync_axay_96g_426Hz' # High G X
	EvalType = 'DeltaV'
	EvalUnit = 'km/h'
	EvalTolerance_abs = '10' # kmph
	EDIDs = '31'		# Dynamic EDID, individual capture length 250ms

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_capture_interval;
my $tcpar_EDID;
my $tcpar_Crashcode;
my $tcpar_DiagType;
my $tcpar_ResultDB;
my $tcpar_DataType;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_Crash_Duration;
my $tcpar_CrashTimeZero_ms;
my $tcpar_SourceLabel;
my $tcpar_EvalType;
my $tcpar_EvalUnit;
my $tcpar_EvalTolerance_abs;
my $tcpar_Voltage_At_StartOfCrash;
my $tcpar_Voltage_Change_DuringCrash;
my $tcpar_Voltage_Tolerance_abs;
my $tcpar_read_NHTSAEDR;
my $tcpar_read_CHINAEDR;
my $Tend_Tolerance_abs;

################ global parameter declaration ###################
#add any global variables here
my ( $record_handler, $crash_handler, $crashSettings, $ChinaEDR_diagType );

###############################################################

sub TC_set_parameters {

	$tcpar_purpose                    = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_capture_interval           = S_read_optional_testcase_parameter('capture_interval');
	$tcpar_EDID                       = S_read_mandatory_testcase_parameter('EDIDs');
	$tcpar_COMsignalsAfterCrash       = S_read_optional_testcase_parameter( 'COMsignalsAfterCrash', 'byref' );
	$tcpar_Crashcode                  = S_read_mandatory_testcase_parameter('Crashcode');
	$tcpar_DiagType                   = S_read_mandatory_testcase_parameter('DiagType');
	$tcpar_ResultDB                   = S_read_mandatory_testcase_parameter('ResultDB');
	$tcpar_DataType                   = S_read_mandatory_testcase_parameter('DataType');
	$tcpar_Voltage_At_StartOfCrash    = S_read_optional_testcase_parameter('Voltage_At_StartOfCrash');
	$tcpar_Voltage_Change_DuringCrash = S_read_optional_testcase_parameter('Voltage_Change_DuringCrash');
	$tcpar_Crash_Duration             = S_read_optional_testcase_parameter('Crash_Duration');
	$tcpar_SourceLabel                = S_read_optional_testcase_parameter('SensorLabel');
	$tcpar_EvalType                   = S_read_optional_testcase_parameter('EvalType');
	$tcpar_EvalUnit                   = S_read_optional_testcase_parameter('EvalUnit');
	$tcpar_EvalTolerance_abs          = S_read_optional_testcase_parameter('EvalTolerance_abs');
	$tcpar_Voltage_Tolerance_abs      = S_read_optional_testcase_parameter('Voltage_Tolerance_abs');
	$tcpar_CrashTimeZero_ms           = S_read_optional_testcase_parameter('CrashTimeZero_ms');
	$Tend_Tolerance_abs               = S_read_optional_testcase_parameter('Tend_Tolerance_abs');

	if ( $tcpar_DataType ne 'Static' and $tcpar_DataType ne 'Dynamic' and $tcpar_DataType ne 'Static_ChinaEDR' ) {
		S_set_error( " Datatype specified ('$tcpar_DataType') is incorrect. Must be 'Dynamic' or 'Static' or 'Static_ChinaEDR'. Testcase is aborted", 110 );
		return 0;
	}
	$tcpar_read_NHTSAEDR = S_read_optional_testcase_parameter('read_NHTSAEDR');
	$tcpar_read_CHINAEDR = S_read_optional_testcase_parameter('read_CHINAEDR');

	if ( not defined $tcpar_read_CHINAEDR ) {
		$tcpar_read_NHTSAEDR = 'yes';
		$tcpar_read_CHINAEDR = 'no';
	}
	else {
		$tcpar_read_NHTSAEDR = 'no';
		my $storageOrder = EDR_getStorageOrder();
		return unless ( defined $storageOrder );

		if ( $storageOrder eq 'PhysicalOrder' ) {
			$ChinaEDR_diagType = 'ProdDiag';    #In platform NHTSA and China EDR is read via proddiag
		}
		else {
			$ChinaEDR_diagType = 'CHINA_Payload';
		}
	}

	return 1;
}

sub TC_initialization {

	S_w2rep("Initialize Record and Crash Handler");
	$record_handler = EDR_init_RecordHandler();
	$crash_handler  = EDR_init_CrashHandler();

	S_w2log( 1, "Initialize CD and start CAN trace" );
	GDCOM_init();    # To fetch info for CD from mapping_diag
	CA_trace_start();

	S_w2log( 1, "Power on ECU" );
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_EDR_NOERROR( { timeout_ms => 'TIMER_CLEAR_CRASH_RECORDER' } ) ();
	S_wait_ms(6000);

	S_w2log( 1, "Clear fault memory" );
	PRD_Clear_Fault_Memory();
	S_wait_ms(2000);

	#--------------------------------------------------------------
	# PREPARE CRASH AND INITIALIZE EQUIPMENT
	#
	S_w2rep("Get crash settings for crash $tcpar_Crashcode");
	my $crashDetails_href = { "RESULTDB" => $tcpar_ResultDB, 'CRASHNAME' => $tcpar_Crashcode };
	$crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
	unless ( defined $crashSettings ) {
		S_set_error("Crash $tcpar_Crashcode not available in result DB $tcpar_ResultDB. Test case aborted.");
		return;
	}

	EDR_addSensorDataToCrashHandler( "Crash_href" => $crashDetails_href, "CrashLabel" => $tcpar_Crashcode . "_" . $tcpar_DataType );

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log( 1, "Crashcode: $tcpar_Crashcode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)" );

	S_w2log( 1, "Set environments for crash as per result DB" );
	CSI_PrepareEnvironment( $crashSettings, 'init_complete' );
	S_wait_ms(2000);

	# read fault memory
	my $faultsBeforeStimulation_obj = LIFT_FaultMemory->read_fault_memory('Primary');

	#Fault memory must be empty
	my $faultsVerdict = $faultsBeforeStimulation_obj->evaluate_faults( {} );
	return 0 unless ( $faultsVerdict eq 'VERDICT_PASS' );

	return 1;
}

sub TC_stimulation_and_measurement {

	#--------------------------------------------------------------
	# CRASH PREPARATION
	#

	# Prepare crash
	S_teststep( "Prepare crash", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	# Prepare crash
	CSI_LoadCrashSensorData2Simulator($crashSettings);

	# Power ON the ECU
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle', 'normal' );
	S_wait_ms(1000);

	S_teststep( "Inject '$tcpar_Crashcode'", 'AUTO_NBR' );
	CSI_TriggerCrash();

	if ( $tcpar_DataType eq 'Static' ) {
		LC_SetVoltage( $tcpar_Voltage_At_StartOfCrash, 'Ubat' );
		my $wait_timebeforeEndOfCrash = $tcpar_Crash_Duration - 30;    #30ms
		S_teststep( "Wait for '$wait_timebeforeEndOfCrash'", 'AUTO_NBR' );
		S_wait_ms($wait_timebeforeEndOfCrash);
		S_teststep( "Set ECU voltage to $tcpar_Voltage_Change_DuringCrash (crash still ongoing)", 'AUTO_NBR' );
		LC_SetVoltage( $tcpar_Voltage_Change_DuringCrash, 'Ubat' );
	}

	S_teststep( "Wait 10 sec until all data is stored", 'AUTO_NBR' );
	S_wait_ms(10000);

	# EDR records supported for the project
	S_teststep( "Read EDR Record 1", 'AUTO_NBR', "read_edr_$tcpar_DataType" );    #measurement 1

	my $dataStoragePath = "$main::REPORT_PATH/" . S_get_TC_number() . "_" . $tcpar_Crashcode;
	PRD_ECU_Login() if ( $tcpar_DiagType eq 'ProdDiag' );

	if ( lc($tcpar_read_NHTSAEDR) eq 'yes' ) {
		EDR_ReadAndStoreAllRecords(
			"DiagType"     => $tcpar_DiagType,
			"CrashLabel"   => $tcpar_Crashcode . "_" . $tcpar_DataType,
			"NbrOfRecords" => 1,
			"StoragePath"  => $dataStoragePath,
			"read_EDRType" => 'NHTSA'
		);
	}
	if ( lc($tcpar_read_CHINAEDR) eq 'yes' ) {
		EDR_ReadAndStoreAllRecords(
			"DiagType"     => $ChinaEDR_diagType,
			"CrashLabel"   => $tcpar_Crashcode . "_" . $tcpar_DataType,
			"NbrOfRecords" => 1,
			"StoragePath"  => $dataStoragePath,
			"read_EDRType" => 'CHINA'
		);
	}

	return 1;
}

sub TC_evaluation {

	if ( $tcpar_DataType eq 'Dynamic' ) {

		$tcpar_SourceLabel = EDR_getEdidSensorLabel($tcpar_EDID) if ( not defined $tcpar_SourceLabel );
		my $sourceData = $crash_handler->GetSourceDataSamples(
			"SourceLabel"      => $tcpar_SourceLabel,
			"CoordinateSystem" => "NHTSA",
			"CrashLabel"       => $tcpar_Crashcode . "_" . $tcpar_DataType
		);    # contains sample rate, time unit, data samples

		unless ( defined $sourceData ) {
			S_w2rep( "No Sensor data obtained from crash handler.", 'red' );
			S_set_verdict('VERDICT_NONE');
			return 1;
		}
		my $dataElement = $record_handler->GetDataElementEDID(
			"EDIDnr"       => $tcpar_EDID,
			"RecordNumber" => 1,
			"CrashLabel"   => $tcpar_Crashcode . "_" . $tcpar_DataType
		);

		#-----------------------------------------------------------------------
		# Get EDID data
		#-----------------------------------------------------------------------
		S_teststep( "Validate EDID $tcpar_EDID ($dataElement) in record 1", 'AUTO_NBR', "read_edr_$tcpar_EDID" );

		my $edidData = $record_handler->GetDecodedEDID( "CrashLabel" => $tcpar_Crashcode . "_" . $tcpar_DataType, "RecordNumber" => 1, "EDIDnr" => $tcpar_EDID );

		unless ( defined $edidData ) {
			S_set_error( "No EDID data obtained from record.", 'red' ) unless ($main::opt_offline);
			S_set_verdict('VERDICT_NONE');
			return 1;
		}

		#-----------------------------------------------------------------------
		# Get start and end time for evaluation
		#-----------------------------------------------------------------------
		S_w2rep("Get recording start and end time");

		# Recording Start Time
		my $recStartTime_ms = $record_handler->GetRecStartTimeMillisecEDID( "CrashLabel" => $tcpar_Crashcode . "_" . $tcpar_DataType, "RecordNumber" => 1, "EDIDnr" => $tcpar_EDID );
		S_w2rep("Recording start time for EDID: $recStartTime_ms ms");

		# Recording End Time
		my $recEndTime_ms = $record_handler->GetRecEndTimeMillisecEDID( "CrashLabel" => $tcpar_Crashcode . "_" . $tcpar_DataType, "RecordNumber" => 1, "EDIDnr" => $tcpar_EDID );
		S_w2rep("Recording end time for EDID: $recEndTime_ms ms");

		my $graphLabel = "Delta V Eval (EDID $tcpar_EDID, crash $tcpar_Crashcode, record 1)";
		S_w2rep("Start ringbuffer evaluation with sensor $tcpar_SourceLabel and EDID $tcpar_EDID");
		my $thisCrashVerdict = EDR_Eval_Ringbuffer_MethodDeltaV(
			"EDID_ID"            => $tcpar_EDID,
			"EDID_DataSamples"   => $edidData->{"DataSamples"},
			"EDID_DataUnit"      => $edidData->{"ValueUnit"},
			"EDID_SampleRateHz"  => $edidData->{"SampleRateHz"},
			"Sensor_DataSamples" => $sourceData->{"DataSamples"},
			"Sensor_DataUnit"    => $sourceData->{"DataUnit"},
			"Absolute_Tolerance" => $tcpar_EvalTolerance_abs,
			"CompareDataUnit"    => $tcpar_EvalUnit,
			"Rec_Start_Time_ms"  => $recStartTime_ms,
			"Rec_End_Time_ms"    => $recEndTime_ms,
			"Crash_TimeZero_s"   => $tcpar_CrashTimeZero_ms * MILLISEC_TO_SECOND,
			"GraphLabel"         => $graphLabel,
		);
		S_teststep_expected( "Dynamic Data values (EDID $tcpar_EDID) within absolute tolerance $tcpar_EvalTolerance_abs $tcpar_EvalUnit of sensor data for $tcpar_Crashcode", "read_edr_$tcpar_EDID" );    #evaluation 1
		S_teststep_detected( "Dynamic Data values (EDID $tcpar_EDID) within absolute tolerance $tcpar_EvalTolerance_abs $tcpar_EvalUnit of sensor data for $tcpar_Crashcode",         "read_edr_$tcpar_EDID" ) if ( $thisCrashVerdict eq 'VERDICT_PASS' );
		S_teststep_detected( "Dynamic Data values (EDID $tcpar_EDID) are not within absolute tolerance $tcpar_EvalTolerance_abs $tcpar_EvalUnit of sensor data for $tcpar_Crashcode", "read_edr_$tcpar_EDID" ) if ( $thisCrashVerdict eq 'VERDICT_FAIL' );
	}
	elsif ( $tcpar_DataType eq 'Static_ChinaEDR' ) {

		my $dataElement = $record_handler->GetDataElementEDID(
			"EDIDnr"       => $tcpar_EDID,
			"RecordNumber" => 1,
			"CrashLabel"   => $tcpar_Crashcode . "_" . $tcpar_DataType
		);

		S_teststep( "Validate EDID $tcpar_EDID ($dataElement) in record 1", 'AUTO_NBR', "read_edr_$tcpar_EDID" );
		my $edidData      = $record_handler->GetDecodedEDID( "CrashLabel" => $tcpar_Crashcode . "_" . $tcpar_DataType, "RecordNumber" => 1, "EDIDnr" => $tcpar_EDID );
		my $Detectedvalue = $edidData->{"DataValue"};
		my $unit          = $edidData->{"ValueUnit"};
		unless ( defined $Detectedvalue ) {
			S_w2rep("No data could be obtained for EDID.") unless ($main::opt_offline);
			S_set_verdict('VERDICT_NONE');
			return 1;
		}

		my $verdict = EVAL_evaluate_value( "EDID_$tcpar_EDID\_Evaluation", $Detectedvalue, '==', $tcpar_Crash_Duration, $Tend_Tolerance_abs, 'absolute' );
		S_teststep_expected( "$tcpar_Crash_Duration ms", "read_edr_$tcpar_EDID" );    #evaluation 1
		S_teststep_detected( "$Detectedvalue $unit", "read_edr_$tcpar_EDID" );
	}
	elsif ( $tcpar_DataType eq 'Static' ) {

		my $dataElement = $record_handler->GetDataElementEDID(
			"EDIDnr"       => $tcpar_EDID,
			"RecordNumber" => 1,
			"CrashLabel"   => $tcpar_Crashcode . "_" . $tcpar_DataType
		);

		S_teststep( "Validate EDID $tcpar_EDID ($dataElement) in record 1", 'AUTO_NBR', "read_edr_$tcpar_EDID" );
		my $edidData      = $record_handler->GetDecodedEDID( "CrashLabel" => $tcpar_Crashcode . "_" . $tcpar_DataType, "RecordNumber" => 1, "EDIDnr" => $tcpar_EDID );
		my $Detectedvalue = $edidData->{"DataValue"};
		my $unit          = $edidData->{"ValueUnit"};
		unless ( defined $Detectedvalue ) {
			S_w2rep("No data could be obtained for EDID.") unless ($main::opt_offline);
			S_set_verdict('VERDICT_NONE');
			return 1;
		}

		my $verdict = EVAL_evaluate_value( "EDID_$tcpar_EDID\_Evaluation", $Detectedvalue, '==', $tcpar_Voltage_Change_DuringCrash, $tcpar_Voltage_Tolerance_abs, 'absolute' );
		S_teststep_expected( "$tcpar_Voltage_Change_DuringCrash V", "read_edr_$tcpar_EDID" );    #evaluation 1
		S_teststep_detected( "$Detectedvalue $unit", "read_edr_$tcpar_EDID" );
	}

	return 1;
}

sub TC_finalization {

	#Delete Record Handler
	$record_handler->DeleteRecord(
		"CrashLabel"   => $tcpar_Crashcode . "_" . $tcpar_DataType,
		"RecordNumber" => 1
	);

	if ( defined $tcpar_SourceLabel ) {
		$crash_handler->DeleteSource(
			"SourceLabel" => $tcpar_SourceLabel,
			"CrashLabel"  => $tcpar_Crashcode . "_" . $tcpar_DataType
		);

	}

	#Clearing crash recorder
	PRD_Clear_EDR( { timeout_ms => 'TIMER_CLEAR_CRASH_RECORDER' } );
	S_wait_ms(2000);

	#Erase Fault memory
	PRD_Clear_Fault_Memory();
	S_wait_ms(2000);

	#Read fault memory after clearing and erasing EDR
	LIFT_FaultMemory->read_fault_memory('Primary');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	return 1;
}

1;
