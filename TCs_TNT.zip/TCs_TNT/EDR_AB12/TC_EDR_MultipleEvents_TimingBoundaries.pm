#### TEST CASE MODULE
package TC_EDR_MultipleEvents_TimingBoundaries;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use INCLUDES_Project;
#include further modules here
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use GENERIC_DCOM;
use LIFT_can_access;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;

use Data::Dumper;

##################################

our $PURPOSE = "<This test scripts tests storage behaviour of single, parallel and multiple events>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_MultipleEvents_TimingBoundaries

=head1 PURPOSE

<This test scripts tests behaviour of single, parallel and multiple events>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFaultNoCT


I<B<Stimulation and Measurement>>

1. Power up ECU

2. Start measurement of fire times

3. Inject combined crash <crashtype>

4. Wait for <wait_ms> for complete storage of CT

5. Stop measurement of fire times

6. Power down ECU

7. Power up ECU

8. Read EDR


I<B<Evaluation>>

1. - 

2. - 

3. - 

4. -

5. - 

6. -

7. -

8. Expect <expected_number_of_CT> and check MultiEventNumber as well as algo set and reset times. 


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'expected_number_of_CT' => 
	SCALAR 'CrashCode' => 
	HASH 'CompareValues_CT1' => 
	HASH 'CompareValues_CT2' => 
	SCALAR 'purpose' => 
	SCALAR 'crashtype' => 
	SCALAR 'ResultDB' => 
	SCALAR 'timing_type' => 
	SCALAR 'DiagType' => 
	HASH 'EDIDs_CT1' => 
	HASH 'EDIDs_CT2' => 


=head2 PARAMETER EXAMPLES

	purpose = 'Inject combined crash of two regular crashes  '<Test Heading Head>' and '<Test Heading Tail>' and check that correct number of CT are saved as well as and multi-event number aspects' # description of test case
	# ---------- Stimulation ------------ 
	crashtype = '<Test Heading Head>_<Test Heading 2>_<Test Heading Tail>'
	ResultDB = 'EDR'
	timing_type = 'parallel'
	DiagType = 'ProdDiag'
	# ---------- Evaluation ------------ 
	EDIDs_CT1 = %('48' => 'Time from initial event to current event',  '45' => 'Multi-event, number of events') # older record
	EDIDs_CT2 = %('48' => 'Time from initial event to current event',  '45' => 'Multi-event, number of events')
	expected_number_of_CT = 1
	
	CrashCode = 'Parallel_EDR_Rear_NonInflate_SideLeft_Inflate'
	# ID => 'Description'
	
	CompareValues_CT1 = %('48' => 'FFFF', '45' => '1') 
	CompareValues_CT2 = %()

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_crashtype;
my $tcpar_ResultDB;
my $tcpar_timing_type;
my $tcpar_DiagType;
my $tcpar_EDIDs_CT1;
my $tcpar_EDIDs_CT2;
my $tcpar_expected_number_of_CT;
my $tcpar_CrashCode;
my $tcpar_CompareValues_CT1;
my $tcpar_CompareValues_CT2;
my $tcpar_CompareValues_CT3;
my $tcpar_wait_ms;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_read_NHTSAEDR;
my $tcpar_read_CHINAEDR;

################ global parameter declaration ###################
#add any global variables here
my ($record_handler, $crashSettings, $edrNumberOfEventsToBeStored,$edrNumberOfParallelEventsToBeStored,$ChinaEDR_diagType );

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_ResultDB =  S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_timing_type =  S_read_mandatory_testcase_parameter( 'timing_type' );
	$tcpar_DiagType =  S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_wait_ms =  S_read_mandatory_testcase_parameter( 'wait_ms' );
	$tcpar_expected_number_of_CT =  S_read_mandatory_testcase_parameter( 'expected_number_of_CT' );
	$tcpar_CrashCode =  S_read_mandatory_testcase_parameter( 'CrashCode' );
	$tcpar_CompareValues_CT1 =  S_read_mandatory_testcase_parameter( 'CompareValues_CT1' ,'byref');
	$tcpar_CompareValues_CT2 =  S_read_optional_testcase_parameter( 'CompareValues_CT2','byref' );
	$tcpar_CompareValues_CT3 =  S_read_optional_testcase_parameter( 'CompareValues_CT3','byref' );
	$tcpar_COMsignalsAfterCrash =  S_read_optional_testcase_parameter( 'COMsignalsAfterCrash','byref');
	$tcpar_read_NHTSAEDR=S_read_optional_testcase_parameter('read_NHTSAEDR');
	$tcpar_read_CHINAEDR=S_read_optional_testcase_parameter('read_CHINAEDR');
	
	$edrNumberOfParallelEventsToBeStored = SYC_EDR_get_NumberOfParallelEvents();
	unless(defined $edrNumberOfParallelEventsToBeStored){
		S_set_error("Not available in SYC - add or overwrite with Custlibrary Function");
        return;
    }
	if( ($tcpar_timing_type eq  'multi_three') and ($edrNumberOfParallelEventsToBeStored == '2')){
		S_w2rep("This testcase is not applicable for your project since number of buffers available is $edrNumberOfParallelEventsToBeStored ");
		return;
	}
	if(not defined $tcpar_read_CHINAEDR) {
		$tcpar_read_NHTSAEDR = 'yes';
		$tcpar_read_CHINAEDR = 'no';
	}
	else {
		$tcpar_read_NHTSAEDR = 'no';
		my $storageOrder = EDR_getStorageOrder();
		return unless(defined $storageOrder);

		if($storageOrder eq 'PhysicalOrder'){
			$ChinaEDR_diagType= 'ProdDiag';  #In platform NHTSA and China EDR is read via proddiag
		}
		else {
			$ChinaEDR_diagType= 'CHINA_Payload';
		}
	}
	return 1;
}

sub TC_initialization {

	S_teststep("Test setup preparation", 'AUTO_NBR');

	#--------------------------------------------------------------
    # INITIALIZE RECORD AND CRASH HANDLER
    #    
	S_w2rep("Initialize Record Handler");
	$record_handler = EDR_init_RecordHandler() || return;	

	#--------------------------------------------------------------
    # PREPARE CRASH AND INITIALIZE EQUIPMENT
    #
	S_w2rep("Get crash settings for crash $tcpar_CrashCode");
    my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_CrashCode};
    $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
    unless(defined $crashSettings) {
        S_set_error("Crash $tcpar_CrashCode not available in result DB $tcpar_ResultDB. Test case aborted.");
        return;
    }

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log(1, "Crashcode: $tcpar_CrashCode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");

	S_w2log(1, "Power on ECU");
    LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');
    
    S_w2log(1, "Initialize CD and start CAN trace");
    GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start ( );

	S_w2log(1, "Set environments for crash as per result DB");
    CSI_PrepareEnvironment($crashSettings, 'init_complete');
    S_wait_ms(2000);

	S_w2log(1, "Clear crash recorder");
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(2000);

	S_w2log(1, "Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	S_w2log(1, "Read and evaluate fault memory before stimulation");
    my $faultsBeforeStimulation = PD_ReadFaultMemory();

    #Fault memory must be empty
    my $faultsVerdict = PD_evaluate_faults( $faultsBeforeStimulation, []);
    return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

	return 1;
}

sub TC_stimulation_and_measurement {

	#--------------------------------------------------------------
    # CRASH PREPARATION
    #
	S_teststep("Prepare crash", 'AUTO_NBR');
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

    # Prepare crash
    CSI_LoadCrashSensorData2Simulator($crashSettings);
	
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    S_wait_ms(1000);

	#--------------------------------------------------------------
    # CRASH INJECTION
    #

	S_teststep("Inject '$tcpar_CrashCode'.", 'AUTO_NBR');
	CSI_TriggerCrash();
    S_teststep("Wait '$tcpar_wait_ms'", 'AUTO_NBR');
    S_wait_ms($tcpar_wait_ms);

	if (defined $tcpar_COMsignalsAfterCrash){
		foreach my $Signal (keys %{$tcpar_COMsignalsAfterCrash})
		{	
			S_w2rep("Signal=$Signal");		
			my $DataOnCOM = $tcpar_COMsignalsAfterCrash -> {$Signal};
			S_w2rep("DataOnCOM=$DataOnCOM");
			COM_setSignalState($Signal,$DataOnCOM);	
		}
	}
 
	#--------------------------------------------------------------
    # MEASUREMENTS
    #
    S_teststep("\n", 'NO_AUTO_NBR');
    S_teststep("--- NUMBER OF EXPECTED RECORDS ---", 'NO_AUTO_NBR');
	S_teststep("Read crash record", 'AUTO_NBR', 'read_crash_record');			#measurement 1
    my $dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_".$tcpar_CrashCode;

	$edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();
	unless(defined $edrNumberOfEventsToBeStored){
		S_set_error("Number of EDR records not available in SYC - add to SYC or overwrite with Custlibrary Function");
        return;
    }

	PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');
	
	if ( lc( $tcpar_read_NHTSAEDR) eq 'yes' ) {
		EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
								"CrashLabel" => $tcpar_CrashCode,
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								"read_EDRType"=>'NHTSA')
	}
	if (lc($tcpar_read_CHINAEDR) eq 'yes'){
		$edrNumberOfEventsToBeStored=3;
		EDR_ReadAndStoreAllRecords ("DiagType" =>  $ChinaEDR_diagType,
								"CrashLabel" => $tcpar_CrashCode,
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								"read_EDRType"=>'CHINA');
	
	}
		
	return 1;
}

sub TC_evaluation {


	#--------------------------------------------------------------
    # NUMBER OF EXPECTED RECORDS
    #
    S_teststep_expected_NOHTML("--- NUMBER OF EXPECTED RECORDS ---"); #evaluation 1
    S_teststep_detected_NOHTML("--- NUMBER OF EXPECTED RECORDS ---"); #evaluation 1
	S_teststep_expected("Expect $tcpar_expected_number_of_CT records to be stored", 'read_crash_record'); #evaluation 1
	my $verdict_NbrOfRecords = 'VERDICT_PASS';
	my $detectedNbrOfStoredRecords = 0;
	my @recordsStored;
	foreach my $recordNumber(1..$edrNumberOfEventsToBeStored)
	{
	 	my $recordAvailable = $record_handler -> IsRecordAvailable("CrashLabel" => $tcpar_CrashCode, "RecordNumber"=> $recordNumber);
	 	if($recordAvailable){
            $detectedNbrOfStoredRecords ++ ;
	 	    push(@recordsStored, $recordNumber);
	 	}
	}

	S_teststep_detected("$detectedNbrOfStoredRecords records stored", 'read_crash_record');
	if ($detectedNbrOfStoredRecords == $tcpar_expected_number_of_CT){
	    S_set_verdict("VERDICT_PASS");
	}
	else{
        S_set_verdict("VERDICT_PASS");
        S_teststep_mismatch("$tcpar_expected_number_of_CT records expected, $detectedNbrOfStoredRecords detected", 'read_crash_record');	    
	}
	
	foreach my $recordNumber(@recordsStored)
	{
		S_teststep("--- RECORD $recordNumber Validation ---",'NO_AUTO_NBR');
        S_teststep_expected_NOHTML("--- RECORD $recordNumber Validation ---");
        S_teststep_detected_NOHTML("--- RECORD $recordNumber Validation ---");
		
		my $tcpar_CompareValues_CT;
		$tcpar_CompareValues_CT = $tcpar_CompareValues_CT1 if ($recordNumber == 1);
		$tcpar_CompareValues_CT = $tcpar_CompareValues_CT2 if ($recordNumber == 2);
		$tcpar_CompareValues_CT = $tcpar_CompareValues_CT3 if ($recordNumber == 3);
		
		foreach my $rawEDID (keys %{$tcpar_CompareValues_CT})
		{
				

			my $dataElement = $record_handler -> GetDataElementEDID( "EDIDnr" => $rawEDID,
																	 "RecordNumber" => $recordNumber,
																	 "CrashLabel" => $tcpar_CrashCode);

			S_teststep("Check EDID $rawEDID ($dataElement) in record $recordNumber", 'AUTO_NBR', "Record_$recordNumber\_EDID_$rawEDID"); #measurement 2

			my $expectedValue = $tcpar_CompareValues_CT -> {$rawEDID};

				
			my $edidData = $record_handler -> GetDecodedEDID("CrashLabel" => $tcpar_CrashCode, "RecordNumber" => $recordNumber,"EDIDnr" => $rawEDID );
			my $detectedValue = $edidData -> {"DataValue"};
			my $unit = $edidData -> {"ValueUnit"};		 
		 
			unless(defined $detectedValue) {
				S_set_error("No data could be obtained for EDID $rawEDID in record $recordNumber.");
				next;
			}
					
			if ($expectedValue eq "GreaterThanZero"){
				EVAL_evaluate_value ( "EDID_$rawEDID\_Evaluation", $detectedValue,'>', 0 )if (lc($tcpar_read_NHTSAEDR) eq 'yes');	
				EVAL_evaluate_value ( "EDID_$rawEDID\_Evaluation", $detectedValue,'>=', 0 )if (lc($tcpar_read_CHINAEDR) eq 'yes');	
			}
			else{
				EVAL_evaluate_string ( "EDID_$rawEDID\_Evaluation", $expectedValue, $detectedValue );
			}
			S_teststep_expected("EDID $rawEDID : $expectedValue", "Record_$recordNumber\_EDID_$rawEDID"); #evaluation 2
			S_teststep_detected("EDID $rawEDID : $detectedValue", "Record_$recordNumber\_EDID_$rawEDID");
		}	
	}

	return 1;
}

sub TC_finalization {

	S_w2rep("Delete all object instances created...");
	$record_handler -> DeleteAllRecords();

	# Erase EDR
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(2000);

	# Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	# Read fault memory after clearing and erasing EDR
    PD_ReadFaultMemory();   

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');
	return 1;
}


1;
