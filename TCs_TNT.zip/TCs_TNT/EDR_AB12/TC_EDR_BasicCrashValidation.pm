#### TEST CASE MODULE
package TC_EDR_BasicCrashValidation;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
#include further modules here
use LIFT_labcar;
use LIFT_PD;
use LIFT_MDSRESULT;
use LIFT_evaluation;
use GENERIC_DCOM;
use LIFT_can_access;
use LIFT_crash_simulation;
use LIFT_FaultMemory;
use FuncLib_SYC_INTERFACE;
use FuncLib_EDR_Framework;
use Data::Dumper;

use constant MILLISEC_TO_SECOND => 0.001;
use constant MAX_AUTARKY_STORAGE_TIME_MS => 300;

##################################

our $PURPOSE = "<summarize what this test is good for>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_BasicCrashValidation

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Inject crash

2. Wait for crash storage to complete

3. Read <FireTime_EDIDs>

4. Read EDR

5. Read Flag for event extension


I<B<Evaluation>>

1. -

2. -

3. Evaluate Fire Times in all stored records

4. Evaluate delta-V ringbuffers in all stored records

5. Evaluate given decoded values for comparison in all stored records

6. Check that flag is set as expected


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'CrashCode' => Name of crash as giben in .mdb
	SCALAR 'CrashTimeZero_ms' => EDR crash time zero
	SCALAR 'NbrOfExpectedRecords' => Number of records which are expected to be stored
	SCALAR 'purpose' => description of the test case purpose
	SCALAR 'ResultDB' => Name of the result DB to be used for crash injection (name specified in CREIS mapping)
	SCALAR 'Autarky' => 'true' if power should be cut at crash injection
	SCALAR 'DiagType' => Gives the diagnosis type for readout
	HASH 'DeltaV_EDIDs' => EDIDs for which delta-V ringbuffer shall be evaluated
	HASH 'Angle_EDIDs' => EDIDs for which angle ringbuffer shall be evaluated
	HASH 'CompareValues_Incident1' => EDIDs with expected decoded values in first incident
	HASH 'CompareValues_Incident2' =>  EDIDs with expected decoded values in second incident
	HASH 'CompareValues_Incidentxxx' =>  EDIDs with expected decoded values in xxx incident (max 6 incidents supported)
	HASH 'CompareValue_Tolerances' => Tolerances for compare values given above, if supported
	HASH 'EventExtensionFlag' => Expected event extension flag value for each incident

=head2 PARAMETER EXAMPLES

	purpose = 'inject PedPro crash and validate all given data elements are stored in the normal EDR'
	
	# ---------- Stimulation ------------ 
	ResultDB = 'EDR'
	Autarky = 'false'
	DiagType = 'ProdDiag'
	
	# ---------- Evaluation ------------ 
	DeltaV_EDIDs = %('DeltaV_Longitudinal' => '31', 'DeltaV_Lateral' => '32')
	Angle_EDIDs = %('Rollangle' => '27')
	CompareValues_Incident1 = %('998' => 'completed', '1000' => 'completed', '1' => 'Pedestrian', '48' => 4)
	CompareValues_Incident2 = %()
	CompareValue_Tolerances = %('48' => 2)
	
	EventExtensionFlag = %('Incident_1' => 0)
	CrashCode = 'Single_EDR_PedPro_NoDeployment;5'
	CrashTimeZero_ms = '46.26'
	NbrOfExpectedRecords ='1'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_ResultDB;
my $tcpar_Autarky;
my $tcpar_DeltaV_EDIDs;
my $tcpar_FireTime_EDIDs;
my $tcpar_EventExtensionFlag;
my $tcpar_CrashCode;
my $tcpar_CrashTimeZero_ms;
my $tcpar_JitterTime_ms;
my $tcpar_FireTimeToleranceAbsolute;
my $tcpar_FireTimeValidation;
my $tcpar_DiagType;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_Rollangle_EDIDs;
my $tcpar_DefaultValueAutarky;

my $tcpar_CompareValues_Incident1;
my $tcpar_CompareValues_Incident2;
my $tcpar_CompareValues_Incident3;
my $tcpar_CompareValues_Incident4;
my $tcpar_CompareValues_Incident5;
my $tcpar_CompareValues_Incident6;
my $tcpar_CompareValue_Tolerances;
my $tcpar_read_NHTSAEDR;
my $tcpar_read_CHINAEDR;
my $tcpar_NbrOfRecordsExpected;

################ global parameter declaration ###################
#add any global variables here
my ($record_handler, $crash_handler, $resultDB_Path, $crashSettings, $edrNumberOfEventsToBeStored, $eventExtension_href,$ChinaEDR_diagType);
my @expectedValuesPerIncident = ();
###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_ResultDB =  S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_Autarky =  S_read_mandatory_testcase_parameter( 'Autarky' );
	if($tcpar_Autarky eq 'true'){
        $tcpar_DefaultValueAutarky =  S_read_optional_testcase_parameter( 'DefaultValueAutarky' );
        $tcpar_DefaultValueAutarky = 'DataNotAvailable' if(not defined $tcpar_DefaultValueAutarky);
	}
	$tcpar_DeltaV_EDIDs =  S_read_mandatory_testcase_parameter( 'DeltaV_EDIDs' , 'byref');
    $tcpar_Rollangle_EDIDs =  S_read_optional_testcase_parameter( 'Angle_EDIDs' , 'byref');
    if(not defined $tcpar_Rollangle_EDIDs){
        S_set_warning("No rollangle EDIDs will be validated!");
    }
	$tcpar_FireTime_EDIDs = S_read_optional_testcase_parameter( 'FireTime_EDIDs');
	
	if(not defined $tcpar_FireTime_EDIDs){ 
		my $fireTimeLabelMapping = S_get_contents_of_hash(['Mapping_EDR', 'SquibLabelMapping']);
    	%{$tcpar_FireTime_EDIDs} = reverse %{$fireTimeLabelMapping};
	}
	$tcpar_FireTimeToleranceAbsolute = S_read_optional_testcase_parameter( 'FireTimeToleranceAbsolute' );
	unless(defined $tcpar_FireTimeToleranceAbsolute) {
        S_set_warning("Setting fire time tolerance to default value 3ms");
		$tcpar_FireTimeToleranceAbsolute = 3;
	}
	#FireTimeValidation
	$tcpar_FireTimeValidation = S_read_optional_testcase_parameter( 'FireTimeValidation');
	if(not defined $tcpar_FireTimeValidation){
		$tcpar_FireTimeValidation = 'true';
	}
	elsif($tcpar_FireTimeValidation ne 'false'){
		$tcpar_FireTimeValidation = 'true';
	}

	$tcpar_CompareValues_Incident1 = S_read_mandatory_testcase_parameter( 'CompareValues_Incident1' );
	$tcpar_CompareValues_Incident2 = S_read_optional_testcase_parameter( 'CompareValues_Incident2' );
	$tcpar_CompareValues_Incident3 = S_read_optional_testcase_parameter( 'CompareValues_Incident3' );
	$tcpar_CompareValues_Incident4 = S_read_optional_testcase_parameter( 'CompareValues_Incident4' );
	$tcpar_CompareValues_Incident5 = S_read_optional_testcase_parameter( 'CompareValues_Incident5' );
	$tcpar_CompareValues_Incident6 = S_read_optional_testcase_parameter( 'CompareValues_Incident6' );
	$tcpar_CompareValue_Tolerances = S_read_optional_testcase_parameter( 'CompareValue_Tolerances' );
	if(not defined $tcpar_CompareValue_Tolerances){
		$tcpar_CompareValue_Tolerances = {};
	}

    push(@expectedValuesPerIncident, $tcpar_CompareValues_Incident1);
    push(@expectedValuesPerIncident, $tcpar_CompareValues_Incident2)
    		if(defined $tcpar_CompareValues_Incident2 and keys %{$tcpar_CompareValues_Incident2});
    push(@expectedValuesPerIncident, $tcpar_CompareValues_Incident3)
    		if(defined $tcpar_CompareValues_Incident3 and keys %{$tcpar_CompareValues_Incident3});
    push(@expectedValuesPerIncident, $tcpar_CompareValues_Incident4)
    		if(defined $tcpar_CompareValues_Incident4 and keys %{$tcpar_CompareValues_Incident4});
    push(@expectedValuesPerIncident, $tcpar_CompareValues_Incident5)
    		if(defined $tcpar_CompareValues_Incident5 and keys %{$tcpar_CompareValues_Incident5});
    push(@expectedValuesPerIncident, $tcpar_CompareValues_Incident6)
    		if(defined $tcpar_CompareValues_Incident6 and keys %{$tcpar_CompareValues_Incident6});

	$tcpar_NbrOfRecordsExpected = S_read_mandatory_testcase_parameter( 'NbrOfExpectedRecords' );

	$tcpar_EventExtensionFlag =  S_read_mandatory_testcase_parameter( 'EventExtensionFlag' , 'byref');
	$tcpar_CrashCode =  S_read_mandatory_testcase_parameter( 'CrashCode' );
	$tcpar_CrashTimeZero_ms =  S_read_mandatory_testcase_parameter( 'CrashTimeZero_ms' );

	$tcpar_DiagType = S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_COMsignalsAfterCrash =  S_read_optional_testcase_parameter( 'COMsignalsAfterCrash','byref');
	$tcpar_read_NHTSAEDR=S_read_optional_testcase_parameter('read_NHTSAEDR');
	$tcpar_read_CHINAEDR=S_read_optional_testcase_parameter('read_CHINAEDR');
	
	$tcpar_JitterTime_ms = S_read_optional_testcase_parameter('JitterTime_ms');
    if(not defined $tcpar_JitterTime_ms and S_get_exec_option_NOERROR('JitterTime_SensorRingbuffer_ms')){
        $tcpar_JitterTime_ms = S_get_exec_option('JitterTime_SensorRingbuffer_ms');
    }
	
	
	if(not defined $tcpar_read_CHINAEDR) {
		$tcpar_read_NHTSAEDR = 'yes';
		$tcpar_read_CHINAEDR = 'no';
	}
	else {
		$tcpar_read_NHTSAEDR = 'no';
		my $storageOrder = EDR_getStorageOrder();
		return unless(defined $storageOrder);

		if($storageOrder eq 'PhysicalOrder'){
			$ChinaEDR_diagType= 'ProdDiag';  #In platform NHTSA and China EDR is read via proddiag
		}
		else {
			$ChinaEDR_diagType= 'CHINA_Payload';
		}
	}

	return 1;
}

sub TC_initialization {

	S_teststep("Test setup preparation", 'AUTO_NBR');

	#--------------------------------------------------------------
    # INITIALIZE RECORD AND CRASH HANDLER
    #    
	S_w2rep("Initialize Record and Crash Handler");
	$record_handler = EDR_init_RecordHandler() || return;
	$crash_handler  = EDR_init_CrashHandler() || return;

	#--------------------------------------------------------------
    # PREPARE CRASH AND INITIALIZE EQUIPMENT
    #
	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	$resultDB_Path = $resultDBDetails->{'PATH'};

    my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_CrashCode};
    $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
    unless(defined $crashSettings) {
        S_set_error("Crash $tcpar_CrashCode not available in result DB $tcpar_ResultDB. Test case aborted.");
        return;
    }

	S_w2log(1, "Crashcode: $tcpar_CrashCode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");


	S_w2log(1, "Power on ECU");
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

    S_w2log(1, "Initialize CD and start CAN trace");
    GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start ( );

    # Set environment settings for crash
    CSI_PrepareEnvironment($crashSettings, 'init_complete');
	S_wait_ms(2000);

	S_w2log(1, "Clear crash recorder");
	# EDR_SendPostCrashCANSignals ();	 # Ford specific
    PD_ClearCrashRecorder();
    S_wait_ms(2000);

	S_w2log(1, "Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	S_w2log(1, "Reset ECU");
    PD_ECUreset();
    S_wait_ms('TIMER_ECU_READY');

	S_w2log(1, "Read fault memory before stimulation");
    my $faultsBeforeStimulation = PD_ReadFaultMemory();

    #Fault memory must be empty
    my $faultsBeforeStimulation_obj = LIFT_FaultMemory -> read_fault_memory('Bosch');
    my $faultsVerdict = $faultsBeforeStimulation_obj -> evaluate_faults({});
    return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

	return 1;
}

sub TC_stimulation_and_measurement {

	#--------------------------------------------------------------
    # CRASH PREPARATION
    #
	S_teststep("Prepare crash", 'AUTO_NBR');
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	# Get T0 of last incident
	my @crashTimeZeroAllIncidents = split(/_/, $tcpar_CrashTimeZero_ms);
	my $numberOfIncidents = @crashTimeZeroAllIncidents;
	my $lastIncidentTimeZero = $crashTimeZeroAllIncidents[$numberOfIncidents - 1];

    # Prepare crash
    CSI_LoadCrashSensorData2Simulator($crashSettings);

	# Power ON the ECU
	S_teststep("Power on ECU and wait until ECU is initialized", 'AUTO_NBR');
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');
	
	CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    S_wait_ms(1000);

	S_teststep("Start recording of fire times", 'AUTO_NBR');
	LC_MeasureTraceDigitalStart();

	#--------------------------------------------------------------
    # CRASH INJECTION
    #
	S_teststep("Inject multi-crash (crash code: '$tcpar_CrashCode')", 'AUTO_NBR');
	CSI_TriggerCrash();
	if($tcpar_Autarky eq 'true') {
		S_teststep ("Wait $lastIncidentTimeZero ms then cut power (at T0 of last incident)", 'AUTO_NBR');
		S_wait_ms($lastIncidentTimeZero);
		LC_ECU_Off();
	}

	S_teststep("Wait 15 seconds", 'AUTO_NBR');
    S_wait_ms(15000);

	S_teststep("Stop recording of fire times", 'AUTO_NBR');
    LC_MeasureTraceDigitalStop();

	if($tcpar_Autarky eq 'true') {
		S_teststep ("Power ECU back on", 'AUTO_NBR');
		LC_ECU_On();
	    S_wait_ms('TIMER_ECU_READY');
	}

	if (defined $tcpar_COMsignalsAfterCrash){
		foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
		{
			S_w2rep("Signal = $signal");
			my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
			S_w2rep("DataOnCOM = $dataOnCOM");
			COM_setSignalState($signal,$dataOnCOM);
		}
	}

 	#--------------------------------------------------------------
    # DATA STORAGE
    #
	S_teststep("Store all data: EDR records, fire times, sensor data", 'AUTO_NBR');
    my $dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_".$tcpar_CrashCode;

	# EDR records
	$edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();
	PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');

	if ( lc( $tcpar_read_NHTSAEDR) eq 'yes' ) {
		EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
								"CrashLabel" => $tcpar_CrashCode,
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								"read_EDRType"=>'NHTSA')
	}
	if (lc($tcpar_read_CHINAEDR) eq 'yes'){
		$edrNumberOfEventsToBeStored=3;
		EDR_ReadAndStoreAllRecords ("DiagType" =>  $ChinaEDR_diagType,
								"CrashLabel" => $tcpar_CrashCode,
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								"read_EDRType"=>'CHINA');
	}	
	
    if(S_get_exec_option_NOERROR ( 'EDR_ExtendedMeasurementsEnabled' )){
        S_teststep("Store NVM data", 'AUTO_NBR');
        PD_ECUlogin();
        S_wait_ms(2000);
        PD_DumpNVMData_NOERROR_NOHTML($main::REPORT_PATH . "/".S_get_TC_number(). "_ReadAllNVMSections_Dump.txt");
    }

 	# Fire Times
    my ($lct_Data, $squibLabels_aref);
	$lct_Data = LC_MeasureTraceDigitalGetValues();
	foreach my $lctTimeStamp (keys %{$lct_Data})
	{
		foreach my $squib (keys %{$lct_Data -> {$lctTimeStamp}}){push(@{$squibLabels_aref}, $squib);}
		last;
	}

	if(defined $squibLabels_aref) {
		EVAL_dump2UNV( $lct_Data, "$dataStoragePath/LCT_Measurement.txt.unv" );
		EDR_addFireTimesToCrashHandler (  "LCT_Measurement" => $lct_Data,
		                                  "SquibLabels" => $squibLabels_aref,
		                                  "CrashLabel"  => $tcpar_CrashCode,
		                                  "StoragePath" => $dataStoragePath);
	}

	# Sensor Data
    EDR_addSensorDataToCrashHandler ("Crash_href" => {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_CrashCode},
                                     "CrashLabel"  => $tcpar_CrashCode,
                                     "DataStoragePath" => $dataStoragePath,
                                    );


	# Extended Event Flag
	my $storageOrder = EDR_getStorageOrder ();
    return unless(defined $storageOrder);

    if($storageOrder eq 'PhysicalOrder'){
       $storageOrder =  'MostRecentLast'; #same behavior as there is no overwriting
    }
	foreach my $recordIndex (0..$edrNumberOfEventsToBeStored - 1)
	{
		my $incident = $recordIndex + 1;
		S_teststep("Read Flag for event extension incident $incident", 'AUTO_NBR',
					"read_event_extension_flag_incident_$incident"); #measurement 4
		my $pdResponse = PD_ReadMemoryByName("rb_dcc_HeaderPublic_st.IsEventExtended_abo(" . $recordIndex . ")");
		$eventExtension_href -> {$recordIndex} = S_aref2dec ( $pdResponse, 'S32' );
	}

	return 1;
}

sub TC_evaluation {
	my $numberOfStoredRecords = $record_handler -> GetNumberOfStoredRecords("CrashLabel" => $tcpar_CrashCode);

	if($tcpar_Autarky eq 'true'){
	    S_teststep("At least one record must be stored in autarky", 'AUTO_NBR', "Number_of_records_autarky");
	    S_teststep_expected(">= 1 records stored", "Number_of_records_autarky");
        S_teststep_detected("$numberOfStoredRecords records stored", "Number_of_records_autarky");
        if($numberOfStoredRecords >= 1){
            S_set_verdict('VERDICT_PASS');
        }
        else{
            S_set_verdict('VERDICT_FAIL');
            return 1; #abort evaluation
        }
	}
	else{
		S_teststep("Check number of stored records", 'AUTO_NBR', 'number_of_records');
	    S_teststep_expected($tcpar_NbrOfRecordsExpected, "number_of_records");
        S_teststep_detected($numberOfStoredRecords, "number_of_records");
        EVAL_evaluate_value('nbr_of_records', $numberOfStoredRecords, '==', $tcpar_NbrOfRecordsExpected);
	}

	my $numberOfExpectedIncidents = @expectedValuesPerIncident;
	S_w2rep("Validation data given for $numberOfExpectedIncidents incidents");
	if($numberOfExpectedIncidents != $numberOfStoredRecords and not $main::opt_offline){
		S_set_error("Not enough data given to validate all stored incidents! ($numberOfStoredRecords)");
		return;
	}

	#--------------------------------------------------------------
    # FIRE TIMES
    #
    
    if($tcpar_FireTimeValidation eq 'true'){
		S_teststep("\n", 'NO_AUTO_NBR');
		S_teststep("--- DEPLOYMENT TIMES ---", 'NO_AUTO_NBR');
	    S_teststep_expected_NOHTML("--- DEPLOYMENT TIMES ---");
	    S_teststep_detected_NOHTML("--- DEPLOYMENT TIMES ---");
	
		S_teststep("Evaluate fire times in all available records with total crash time zero $tcpar_CrashTimeZero_ms",
					'AUTO_NBR',
					"read_firetime_edids");
	    my ($squibVerdict, $allResults_href) = EDR_Eval_SquibFireTimes("CrashLabel" => $tcpar_CrashCode,
	                                                   "EDID_SquibLabels" => $tcpar_FireTime_EDIDs,
	                                                   "CrashTimeZero_ms" => $tcpar_CrashTimeZero_ms, # For multi events: T01_T02, e.g. 12_500 
	                                                   "FireTimeTolerance_ms" => $tcpar_FireTimeToleranceAbsolute,
	                                                   "CrashLabel_FireTimes" => $tcpar_CrashCode);
	
		S_teststep_mismatch("Deployment times in EDR Records are not as measured", "read_firetime_edids")
								if $squibVerdict eq 'VERDICT_FAIL';	
    }

	#--------------------------------------------------------------
    # Delta-V ringbuffers
    #
	my $crashTimeZero_ms;
	if($tcpar_JitterTime_ms){
        $crashTimeZero_ms = $tcpar_CrashTimeZero_ms + $tcpar_JitterTime_ms;
        S_teststep("Add given jitter time $tcpar_JitterTime_ms ms to crash time zero  -> new T0: $crashTimeZero_ms ms", 'AUTO_NBR');
    }
    else{
       	$crashTimeZero_ms=$tcpar_CrashTimeZero_ms;
    }
    S_teststep("--- DELTA-V RGB ---", 'NO_AUTO_NBR');
    S_teststep_expected_NOHTML("--- DELTA-V RGB ---");
    S_teststep_detected_NOHTML("--- DELTA-V RGB ---");

	foreach my $evalType (keys %{$tcpar_DeltaV_EDIDs})
	{
		my $edid=$tcpar_DeltaV_EDIDs->{$evalType};
	    _Validate_Sensor_Ringbuffer($edid, 'DeltaV', $crashTimeZero_ms);
		# next EDID
	}

	#--------------------------------------------------------------
    # Roll angle ringbuffers
    #

    if(defined $tcpar_Rollangle_EDIDs){
        S_teststep("--- ROLLANGLE RGB ---", 'NO_AUTO_NBR');
        S_teststep_expected_NOHTML("--- ROLLANGLE ---");
        S_teststep_detected_NOHTML("--- ROLLANGLE ---");
        foreach my $evalType (keys %{$tcpar_Rollangle_EDIDs})
        {
			my $edid=$tcpar_Rollangle_EDIDs->{$evalType};
            _Validate_Sensor_Ringbuffer($edid, $evalType, $crashTimeZero_ms);
            # next EDID
        }
    }

	#--------------------------------------------------------------
    # Compare values
    #
    S_teststep("--- DECODED COMPARE VALUES ---", 'NO_AUTO_NBR');
    S_teststep_expected_NOHTML("--- DECODED COMPARE VALUES ---");
    S_teststep_detected_NOHTML("--- DECODED COMPARE VALUES ---");

    # Map compare values to record number
    my $expectedVales_href = {};
    my $storageOrder = EDR_getStorageOrder();

    foreach my $incidentNbr (1..$numberOfExpectedIncidents){
    	my $expectedDataThisIncident = $expectedValuesPerIncident[$incidentNbr - 1];
    	my $recordNbr;
		if($storageOrder eq 'MostRecentFirst'){
			$recordNbr = $numberOfExpectedIncidents - $incidentNbr + 1;
		}
		else{
			$recordNbr = $incidentNbr;
		}
	    $expectedVales_href -> {"Record_$recordNbr"} = $expectedDataThisIncident;
    }

	foreach my $recordNbr (1..$numberOfExpectedIncidents)
	{
        S_teststep("Record $recordNbr", 'NO_AUTO_NBR');
        S_teststep_expected_NOHTML("Record $recordNbr");
        S_teststep_detected_NOHTML("Record $recordNbr");

        my $expectedValues_thisRecord_href = $expectedVales_href -> {"Record_$recordNbr"};
        foreach my $edid(sort {$a <=> $b} keys %{$expectedValues_thisRecord_href})
        {
        	my $compareOp;
        	if($expectedValues_thisRecord_href -> {$edid} =~ /^[A-Z]|[a-z]/){
        		$compareOp = 'eq';
    		}
    		else{
    			$compareOp = '==';
    		}

        	EDR_Eval_evaluate_EDID_Decoded ("EDIDnr" => $edid,
		                           			"RecordNumber" => $recordNbr,
		                                	"CrashLabel" => $tcpar_CrashCode,
		                                	"ExpectedValueDecoded" => $expectedValues_thisRecord_href -> {$edid},
		                                	"EvalOperator" => $compareOp,
		                                	"EvalTolerance_abs" => $tcpar_CompareValue_Tolerances -> {$edid});
        }
	}

	#--------------------------------------------------------------
    # Event extension flag
    #
    S_teststep("--- EVENT EXTENSION FLAG ---", 'NO_AUTO_NBR');
    S_teststep_expected_NOHTML("--- EVENT EXTENSION FLAG ---");
    S_teststep_detected_NOHTML("--- EVENT EXTENSION FLAG ---");
	foreach my $incident (1..$numberOfStoredRecords)
	{
        S_teststep("Incident $incident", 'NO_AUTO_NBR');
        S_teststep_expected_NOHTML("Incident $incident");
        S_teststep_detected_NOHTML("Incident $incident");

		my $detectedValue = $eventExtension_href -> {$incident - 1};
		my $expectedValue = $tcpar_EventExtensionFlag -> {"Incident_$incident"};
		S_w2rep("Expected value: $expectedValue");
		$expectedValue = 0 if (not $expectedValue);
		EVAL_evaluate_value ( "Event_Extension_Flag_Incident\_$incident" , $detectedValue, '==', $expectedValue);
		S_teststep_expected("Event extension flag incident $incident = $expectedValue", "read_event_extension_flag_incident_$incident");
		S_teststep_detected("Event extension flag incident $incident = $detectedValue", "read_event_extension_flag_incident_$incident");
	}

	return 1;
}

sub TC_finalization {

	# Erase EDR
    PD_ClearCrashRecorder();
    S_wait_ms(5000);

	# Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(5000);

	# Reset ECU    
    PD_ECUreset();
    S_wait_ms('TIMER_ECU_READY');

	# Read fault memory after clearing and erasing EDR
    LIFT_FaultMemory -> read_fault_memory('Bosch');

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

    S_w2rep("Clean up record and crash handler");
    $record_handler -> DeleteAllRecords();
    $crash_handler -> DeleteAllSources();

	return 1;
}

sub _Validate_Sensor_Ringbuffer {

    my $edid = shift;
    my $type = shift;
    my $crashTimeZero_ms = shift;

    if($type ne 'DeltaV' and $type ne 'Angle'and $type ne 'Rate'){
        S_set_error("Sensor RGB type $type can't be evaluated");
        return;
    }


    #-----------------------------------------------------------------------
    # Get source data
    #-----------------------------------------------------------------------
    my $sensorLabel = EDR_getEdidSensorLabel_NOERROR($edid);

    S_w2rep("Get source data (label: $sensorLabel)");

    my $sourceData = $crash_handler -> GetSourceDataSamples( "SourceLabel" => $sensorLabel, "CoordinateSystem" => "NHTSA", "CrashLabel" => $tcpar_CrashCode); # contains samplerate, time unit, data samples

    if(not defined $sourceData and not $main::opt_offline){
        S_set_error("No Sensor data obtained from crash handler for sensor '$sensorLabel'. Check sensor label.", 110);
        return;
    }

    my $sourceSampleRateHz = $crash_handler -> GetSourceSampleRateHz("SourceLabel" => $sensorLabel, "CrashLabel"=>$tcpar_CrashCode );

    S_w2rep("Get recording start and end time");
    my $recStartTime_ms = $record_handler -> GetRecStartTimeMillisecEDID("CrashLabel" => $tcpar_CrashCode, "RecordNumber" => 1,"EDIDnr" => $edid);
    my $recEndTime_ms = $record_handler -> GetRecEndTimeMillisecEDID("CrashLabel" => $tcpar_CrashCode, "RecordNumber" => 1,"EDIDnr" => $edid);
    S_w2rep("Recording start time: $recStartTime_ms , Recording end time: $recEndTime_ms ms");
    if($tcpar_Autarky eq 'true' and $recEndTime_ms > MAX_AUTARKY_STORAGE_TIME_MS){
        $recEndTime_ms = MAX_AUTARKY_STORAGE_TIME_MS;
    }

    my ($numberOfRecords, $crashTimeZero_href) = EDR_getCrashTimeZeroPerRecord($crashTimeZero_ms);

    foreach my $recordNbr (1..$numberOfRecords)
    {
        S_teststep("Record $recordNbr", 'NO_AUTO_NBR');
        S_teststep_expected_NOHTML("Record $recordNbr");
        S_teststep_detected_NOHTML("Record $recordNbr");

        my $crashTimeZero = $crashTimeZero_href -> {"Record_$recordNbr"};
        S_w2rep("Crash Time Zero: $crashTimeZero ms");
		$crashTimeZero = EDR_synchronize_T0_for_EDID ($edid, $crashTimeZero, $tcpar_CrashCode, $recordNbr);
        S_w2rep("Crash Time Zero after synchronization: $crashTimeZero ms");

        S_w2rep("Get EDID data (EDID $edid)");
        S_teststep("Read EDID '$edid' ($type) for record $recordNbr", 'AUTO_NBR', "EDID_$edid\_$type\_Record$recordNbr");           #measurement 3
        my $edidData = $record_handler -> GetDecodedEDID("CrashLabel" => $tcpar_CrashCode, "RecordNumber" =>  $recordNbr,"EDIDnr" => $edid);

        unless(defined $edidData){
            S_set_error("No EDID data obtained from record handler for EDID $edid. Check EDID ID.", 110);
            return;
        }

        my $edid_DataSamples_NonDefault;
        my $edid_DataSamples_Default;
        my $recEndTime_sec = $recEndTime_ms * MILLISEC_TO_SECOND;
        foreach my $timeStamp (sort {$a<=>$b} keys %{$edidData -> {"DataSamples"}}){
            $edid_DataSamples_NonDefault -> {$timeStamp} = $edidData -> {"DataSamples"}-> {$timeStamp} if($timeStamp <= $recEndTime_sec);
            $edid_DataSamples_Default -> {$timeStamp} = $edidData -> {"DataSamples"}-> {$timeStamp} if($timeStamp > $recEndTime_sec);
        }

        # Evaluate RGB

        # Delta-V
        if($type eq 'DeltaV'){
            my $graphLabel = "Delta V Eval (EDID $edid), crash $tcpar_CrashCode, record $recordNbr)";
            S_w2rep("Start ringbuffer evaluation with sensor $sensorLabel and EDID $edid");
            my $thisCrashDeltaV_Verdict;
            $thisCrashDeltaV_Verdict = EDR_Eval_Ringbuffer_MethodDeltaV (
                                                "EDID_ID"            => $edid,
                                                "EDID_DataSamples"   => $edid_DataSamples_NonDefault,
                                                "EDID_DataUnit"      => $edidData -> {"ValueUnit"},
                                                "EDID_SampleRateHz"  => $edidData -> {"SampleRateHz"},
                                                "Sensor_DataSamples" => $sourceData -> {"DataSamples"},
                                                "Sensor_DataUnit"    => $sourceData -> {"DataUnit"},
                                                "Absolute_Tolerance" => 10,
                                                "CompareDataUnit"    => 'kmph',
                                                "Rec_Start_Time_ms"  => $recStartTime_ms,
                                                "Rec_End_Time_ms"    => $recEndTime_ms,
                                                "Crash_TimeZero_s"   => $crashTimeZero * MILLISEC_TO_SECOND,
                                                "GraphLabel"    => $graphLabel,
                                              ) unless ($main::opt_offline);
            $thisCrashDeltaV_Verdict = 'VERDICT_PASS' if($main::opt_offline);
            S_teststep_mismatch("EDID '$edid' data != sensor data", "EDID_$edid\_$type\_Record$recordNbr") if ($thisCrashDeltaV_Verdict eq 'VERDICT_FAIL');
        }
        #Rollangle
        elsif($type eq 'Rate' or $type eq 'Angle'){
            my $graphLabel = "Rollangle Eval (EDID $edid, crash $tcpar_CrashCode, record $recordNbr)";
            S_w2rep("Start ringbuffer evaluation with sensor $sensorLabel and EDID $edid");
			my $unit= 'deg' if  $type eq 'Angle';
			$unit= 'deg/s' if  $type eq 'Rate';
            my $thisEDIDverdict = EDR_Eval_Ringbuffer_Angle (
                                            "EDID_ID"            => $edid,
                                            "EDID_Type"          => $type,
                                            "EDID_DataSamples"   => $edid_DataSamples_NonDefault,
                                            "EDID_SampleRateHz"  => $edidData -> {"SampleRateHz"},
                                            "EDID_Unit" => $unit,
                                            "Rollrate_Sensor_DataSamples" => $sourceData-> {"DataSamples"},
                                            "Rec_Start_Time_ms"  => $recStartTime_ms,
                                            "Rec_End_Time_ms"    => $recEndTime_ms,
                                            "Absolute_Tolerance" => 10,
                                            "Crash_TimeZero_s"   => $crashTimeZero * MILLISEC_TO_SECOND,
                                            "GraphLabel"    => $graphLabel,);
        }
        # next record

        next unless(defined $edid_DataSamples_Default);

        S_teststep("Default values EDID '$edid' ($type) for record $recordNbr from 300ms onwards due to autarky",
                        'AUTO_NBR');

        foreach my $defaultValueTimeStamp (sort {$a <=> $b} keys %{$edid_DataSamples_Default}){
            S_teststep_2nd_level("Time stamp: $defaultValueTimeStamp (sec)",
                            'AUTO_NBR', "EDID_$edid\_$type\_Record$recordNbr\_autarky_$defaultValueTimeStamp");
            S_teststep_expected("$tcpar_DefaultValueAutarky", "EDID_$edid\_$type\_Record$recordNbr\_autarky_$defaultValueTimeStamp");
            S_teststep_detected("$edid_DataSamples_Default->{$defaultValueTimeStamp}", "EDID_$edid\_$type\_Record$recordNbr\_autarky_$defaultValueTimeStamp");
            EVAL_evaluate_string ( "DefaultValue_$defaultValueTimeStamp\_sec_Record$recordNbr" ,
                                    $tcpar_DefaultValueAutarky,
                                    $edid_DataSamples_Default -> {$defaultValueTimeStamp});
        }
    }

    return 1;
}


1;
