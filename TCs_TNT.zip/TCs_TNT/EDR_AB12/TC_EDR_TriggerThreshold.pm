#### TEST CASE MODULE
package TC_EDR_TriggerThreshold;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
#include further modules here
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_PD;
use LIFT_can_access;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use GENERIC_DCOM;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;
use Data::Dumper;

##################################

our $PURPOSE = "<summarize what this test is good for>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_TriggerThreshold

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFaultNoCT


I<B<Stimulation and Measurement>>

1. Set environments for crash.

2. Power up ECU

3. Inject <Crashcode> and cut power at T0 if <CrashCondition> is Autarky.

4. Wait for <WaitTime_ms>

5. Read EDR records

6. Get EDID <EventType_EDID> from each record


I<B<Evaluation>>

1. - 

2. - 

3. -

4. -

5. Check that <NbrOfRecordsExpected> records are stored.

6. Compare to <ExpectedRawValue_EventType>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	HASH 'ExpectedRawValue_EventType' => 
	SCALAR 'Crashcode' => 
	SCALAR 'purpose' => 
	SCALAR 'ResultDB' => 
	SCALAR 'NbrOfRecordsExpected' => 
	SCALAR 'DiagType' => 
	SCALAR 'EventType_EDID' => 


=head2 PARAMETER EXAMPLES

	purpose = 'Inject a single or multiple crash with different storage thresholds. Check that crash record is only stored if trigger threshold exceeded or deployment.'
	
	# ---------- Stimulation ------------ 
	ResultDB = 'EDR' # defined in CREIS project constants - will be set to 'DEFAULT' if not given
	
	# ---------- Evaluation ------------ 
	NbrOfRecordsExpected = 1
	DiagType = 'ProdDiag'
	EventType_EDID = 1
	ExpectedRawValue_EventType = %('Record1' => '2') #Rear
	Crashcode = 'Single_EDR_Rear_above_8kph_NoDeployment'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_ResultDB;
my $tcpar_NbrOfRecordsExpected;
my $tcpar_DiagType;
my $tcpar_EventType_EDID;
my $tcpar_ExpectedRawValue_EventType;
my $tcpar_Crashcode;
my $tcpar_WaitTime_ms;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_read_NHTSAEDR;
my $tcpar_read_CHINAEDR;
################ global parameter declaration ###################
#add any global variables here
my ($record_handler, $edrNumberOfEventsToBeStored, $crashSettings,$ChinaEDR_diagType);

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_ResultDB =  S_read_optional_testcase_parameter( 'ResultDB' );
	$tcpar_ResultDB = 'DEFAULT' unless(defined $tcpar_ResultDB);
	$tcpar_NbrOfRecordsExpected =  S_read_mandatory_testcase_parameter( 'NbrOfRecordsExpected' );
	$tcpar_DiagType =  S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_EventType_EDID =  S_read_optional_testcase_parameter( 'EventType_EDID' );
	$tcpar_ExpectedRawValue_EventType =  S_read_optional_testcase_parameter( 'ExpectedRawValue_EventType', 'byref' );
	$tcpar_Crashcode =  S_read_mandatory_testcase_parameter( 'Crashcode' );
	$tcpar_WaitTime_ms =  S_read_mandatory_testcase_parameter( 'WaitTime_ms' );
	$tcpar_COMsignalsAfterCrash =  S_read_optional_testcase_parameter( 'COMsignalsAfterCrash','byref');
	
	$tcpar_read_NHTSAEDR=S_read_optional_testcase_parameter('read_NHTSAEDR');
	$tcpar_read_CHINAEDR=S_read_optional_testcase_parameter('read_CHINAEDR');
	
	if(not defined $tcpar_read_CHINAEDR) {
		$tcpar_read_NHTSAEDR = 'yes';
		$tcpar_read_CHINAEDR = 'no';
	}
	else {
		$tcpar_read_NHTSAEDR = 'no';
		my $storageOrder = EDR_getStorageOrder();
		return unless(defined $storageOrder);

		if($storageOrder eq 'PhysicalOrder'){
			$ChinaEDR_diagType= 'ProdDiag';  #In platform NHTSA and China EDR is read via proddiag
		}
		else {
			$ChinaEDR_diagType= 'CHINA_Payload';
		}
	}

	return 1;
}

sub TC_initialization {

	S_teststep("Test setup preparation", 'AUTO_NBR');

	#--------------------------------------------------------------
    # INITIALIZE RECORD HANDLER
    #    
	S_w2rep("Initialize Record Handler");
	$record_handler = EDR_init_RecordHandler() || return;

	#--------------------------------------------------------------
    # PREPARE CRASH AND INITIALIZE EQUIPMENT
    #
	S_w2rep("Get crash settings for crash $tcpar_Crashcode");
    my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode};
    $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
    unless(defined $crashSettings) {
        S_set_error("Crash $tcpar_Crashcode not available in result DB $tcpar_ResultDB. Test case aborted.");
        return;
    }

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log(1, "Crashcode: $tcpar_Crashcode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");

	S_w2log(1, "Power on ECU");
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');
    
    S_w2log(1, "Initialize CD and start CAN trace");
    GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start ( );

	S_w2log(1, "Set environments for crash as per result DB");
    CSI_PrepareEnvironment($crashSettings, 'init_complete');
    S_wait_ms(2000);

	S_w2log(1, "Clear crash recorder");
    PD_ClearCrashRecorder();
    S_wait_ms(2000);

	S_w2log(1, "Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	S_w2log(1, "Reset ECU");
    PD_ECUreset();
    S_wait_ms('TIMER_ECU_READY');

	S_w2log(1, "Read and evaluate fault memory before stimulation");
    my $faultsBeforeStimulation = PD_ReadFaultMemory();
    my $faultsVerdict = PD_evaluate_faults( $faultsBeforeStimulation, []);
	return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

	return 1;
}

sub TC_stimulation_and_measurement {

	#--------------------------------------------------------------
    # CRASH PREPARATION
    #
	S_teststep("Prepare crash", 'AUTO_NBR');
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	# Prepare crash
    CSI_LoadCrashSensorData2Simulator($crashSettings);

	# Power ON the ECU
	S_teststep("Power up ECU", 'AUTO_NBR');
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');
	
	CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    S_wait_ms(1000);

	#--------------------------------------------------------------
    # CRASH INJECTION
    #
	S_teststep("Inject '$tcpar_Crashcode'", 'AUTO_NBR');
    CSI_TriggerCrash();

	S_teststep("Wait for '$tcpar_WaitTime_ms'", 'AUTO_NBR');
    S_wait_ms($tcpar_WaitTime_ms);
	if (defined $tcpar_COMsignalsAfterCrash){
		foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
		{				
			my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
			S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
			COM_setSignalState($signal,$dataOnCOM);	
		}
	}
	S_wait_ms(2000);

	S_teststep("Read EDR records", 'AUTO_NBR', 'read_edr_records');	#measurement 1
    my $dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_".$tcpar_Crashcode;

	$edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();

	PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');

	if ( lc( $tcpar_read_NHTSAEDR) eq 'yes' ) {
		EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
								"CrashLabel" => $tcpar_Crashcode,
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								"read_EDRType"=>'NHTSA')
	}
	if (lc($tcpar_read_CHINAEDR) eq 'yes'){
		$edrNumberOfEventsToBeStored=3;
		EDR_ReadAndStoreAllRecords ("DiagType" =>  $ChinaEDR_diagType,
								"CrashLabel" =>   $tcpar_Crashcode,
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								"read_EDRType"=>'CHINA');
	}	
	return 1;
}

sub TC_evaluation {
	#--------------------------------------------------------------
    # NUMBER OF EXPECTED RECORDS
    #
	S_w2rep("");
	S_w2rep("--------------------------------------------------------", 'purple');
	S_w2rep("NUMBER OF EXPECTED RECORDS", 'purple');
    S_teststep_expected("$tcpar_NbrOfRecordsExpected records stored", 'read_edr_records'); #evaluation 1
	my $detectedNbrOfStoredRecords = 0;
	for(my $recordNumber = 1; $recordNumber <= $edrNumberOfEventsToBeStored; $recordNumber++)
	{
	 	my $recordAvailable = $record_handler -> IsRecordAvailable("CrashLabel" => $tcpar_Crashcode, "RecordNumber"=> $recordNumber);
	 	if($recordNumber <= $tcpar_NbrOfRecordsExpected) {
	 		if ($recordAvailable) {
	 			$detectedNbrOfStoredRecords++;
	 			S_set_verdict('VERDICT_PASS');
	 		}
	 		else {
	 			S_set_verdict('VERDICT_FAIL');
	 		}
	 	}
	 	elsif($recordNumber > $tcpar_NbrOfRecordsExpected) {
	 		if ($recordAvailable) {
	 			$detectedNbrOfStoredRecords++;
	 			S_set_verdict('VERDICT_FAIL');
	 		}
	 		else {
	 			S_set_verdict('VERDICT_PASS');
	 		}
	 	}
	}
    S_teststep_detected("$detectedNbrOfStoredRecords records stored", 'read_edr_records');
	
	if($detectedNbrOfStoredRecords == 0) {
		S_w2rep("No EDR record detected. Event Type will not be validated.");
		return 1;
	}

	#--------------------------------------------------------------
    # EVENT TYPE
    #
	S_w2rep("");
	S_w2rep("--------------------------------------------------------", 'purple');
	S_w2rep("EVENT TYPE", 'purple');

	if (defined $tcpar_EventType_EDID){
		for (my $recordNumber = 1; $recordNumber <= $detectedNbrOfStoredRecords; $recordNumber++)
		{
			S_teststep("Get EDID '$tcpar_EventType_EDID' (Event Type) from record $recordNumber", 'AUTO_NBR', "get_edid_eventtype_record$recordNumber"); #measurement 2

			my $expectedRawValue = $tcpar_ExpectedRawValue_EventType -> {"Record$recordNumber"};
			unless(defined $expectedRawValue) {
				S_set_warning("No expected raw value for event type in record $recordNumber given. Will be skipped.");
				next;
			}

			S_teststep_expected("$expectedRawValue", "get_edid_eventtype_record$recordNumber"); #evaluation 2

			S_w2log(1, "Get EDID data for $tcpar_Crashcode, Record $recordNumber");
			my $detectedEDIDvalue = $record_handler -> GetRawEDID( "EDIDnr" => $tcpar_EventType_EDID,
																   "RecordNumber" => $recordNumber,
																   "CrashLabel" => $tcpar_Crashcode,
																   "FormatOption" => "DEC");

			unless(defined $detectedEDIDvalue) {
				S_set_error("No data could be obtained for EDID $tcpar_EventType_EDID.");
				next;
			}

			S_teststep_detected("$detectedEDIDvalue", "get_edid_eventtype_record$recordNumber");

			my $verdict = EVAL_evaluate_value( "EDID_$tcpar_EventType_EDID\_Evaluation", $detectedEDIDvalue, '==', $expectedRawValue);
		}
	}

	return 1;
}

sub TC_finalization {

	# Erase EDR
    PD_ClearCrashRecorder();
    S_wait_ms(2000);
	
	# Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	# Reset ECU    
    PD_ECUreset();
    S_wait_ms('TIMER_ECU_READY');

	# Read fault memory after clearing and erasing EDR
    PD_ReadFaultMemory();   
    
    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF'); 

	S_w2rep("Clean up record handler");
    $record_handler -> DeleteAllRecords();

	return 1;
}


1;
