#### TEST CASE MODULE
package TC_EDR_Storage_LockStatus;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
#include further modules here
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use GENERIC_DCOM;
use LIFT_can_access;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;
use Data::Dumper;

##################################

our $PURPOSE = "<This test script checks for EDR locking status>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_Storage_LockStatus

=head1 PURPOSE

<This test script checks for EDR locking status>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Read <LockStatusVariable> for all records with PD, measurement A

2. Inject <CrashCode1> for number of events which can be stored.

3. Read <LockStatusVariable> for all records with PD, measurement B

4. Reset ECU

5. Unlock all records if <UnlockAllRecords> is 'true'

6. Read <LockStatusVariable> for all records with PD, measurement C

7. Reset ECU

8. Erase EDR if <EraseAllRecords> is 'true'

9. Read <LockStatusVariable> for all records with PD, measurement D

10. Inject <CrashCode2> for number of events which can be stored.

11. Read <LockStatusVariable> for all records with PD, measurement E


I<B<Evaluation>>

1. -<ExpectedLockStatus > for measurement A 

2. -

3. -<ExpectedLockStatus > for measurement B 

4. - 

5. -

6.<ExpectedLockStatus > for measurement C 

7.

8.

9.<ExpectedLockStatus > for measurement D

10.

11.<ExpectedLockStatus > for measurement E  


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'CrashCode2' => 
	SCALAR 'purpose' => 
	SCALAR 'ResultDB' => 
	SCALAR 'CrashCode1' => 
	SCALAR 'UnlockAllRecords' => 
	SCALAR 'EraseAllRecords' => 
	HASH 'LockStatusVariable' => 
	HASH 'ExpectedLockStatus' => 


=head2 PARAMETER EXAMPLES

	purpose		 = 'Verify lock status'
	
	# ---------- Stimulation ------------
	ResultDB = 'EDR'
	CrashCode1 = 'Single_EDR_Front_Inflatable'
	UnlockAllRecords = 'false'
	EraseAllRecords = 'true'
	LockStatusVariable = %('1' => 'rb_dcc_HeaderPublic_st.RecordLockStatus_aen(0)', '2' => 'rb_dcc_HeaderPublic_st.RecordLockStatus_aen(1)')
	
	# ---------- Evaluation ------------ 
	ExpectedLockStatus = %('Measurement_A' => 0, 'Measurement_B' => 3, 'Measurement_C' => 3, 'Measurement_D' => 0, 'Measurement_E' => 0)
	CrashCode2 = ''

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_ResultDB;
my $tcpar_CrashCode1;
my $tcpar_UnlockAllRecords;
my $tcpar_EraseAllRecords;
my $tcpar_LockStatusVariable;
my $tcpar_ExpectedLockStatus;
my $tcpar_CrashCode2;
my $tcpar_COMsignalsAfterCrash;

################ global parameter declaration ###################
#add any global variables here
my (@LockStatus_A,@LockStatus_B,@LockStatus_C,@LockStatus_D,@LockStatus_E);
my ($crashSettings, $edrNumberOfEventsToBeStored,$EDR_UNLOCK_RECORD);

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_ResultDB =  S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_CrashCode1 =  S_read_mandatory_testcase_parameter( 'CrashCode1' );
	$tcpar_UnlockAllRecords =  S_read_mandatory_testcase_parameter( 'UnlockAllRecords' );
	$tcpar_EraseAllRecords =  S_read_mandatory_testcase_parameter( 'EraseAllRecords' );
	$tcpar_LockStatusVariable =  S_read_mandatory_testcase_parameter( 'LockStatusVariable' );
	$tcpar_ExpectedLockStatus =  S_read_mandatory_testcase_parameter( 'ExpectedLockStatus','byref' );
	$tcpar_CrashCode2 =  S_read_optional_testcase_parameter( 'CrashCode2' );
	$tcpar_COMsignalsAfterCrash =  S_read_optional_testcase_parameter( 'COMsignalsAfterCrash','byref');

	return 1;
}

sub TC_initialization {

	S_teststep("Test setup preparation", 'AUTO_NBR');

	#--------------------------------------------------------------
    # PREPARE CRASH AND INITIALIZE EQUIPMENT
    #
	S_w2rep("Get crash settings for crash $tcpar_CrashCode1");
    my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_CrashCode1};
    $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
    unless(defined $crashSettings) {
        S_set_error("Crash $tcpar_CrashCode1 not available in result DB $tcpar_ResultDB. Test case aborted.");
        return;
    }
	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log(1, "Crashcode: $tcpar_CrashCode1, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");

	S_w2log(1, "Power on ECU");
    LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');
    
    S_w2log(1, "Initialize CD and start CAN trace");
    GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start ( );

	S_w2log(1, "Set environments for crash as per result DB");
    CSI_PrepareEnvironment($crashSettings, 'init_complete');

	S_w2log(1, "Clear crash recorder");
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(2000);

	S_w2log(1, "Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	S_w2log(1, "Read and evaluate fault memory before stimulation");
    my $faultsBeforeStimulation = PD_ReadFaultMemory();

    #Fault memory must be empty
    my $faultsVerdict = PD_evaluate_faults( $faultsBeforeStimulation, []);
    return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

	return 1;
}

sub TC_stimulation_and_measurement {

	$edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();
	unless(defined $edrNumberOfEventsToBeStored){
		S_set_error("Not available in SYC - add or overwrite with Custlibrary Function");
        return;
    }
	
	S_teststep("Read '$tcpar_LockStatusVariable' for all records with PD, measurement A", 'AUTO_NBR', 'read_lockstatusvariable_for_A');									#measurement 1
	
	for(my $index =($edrNumberOfEventsToBeStored-1);$index >= 0; $index--)
	{
		my $value_aref=PD_ReadMemoryByName("$tcpar_LockStatusVariable($index)");
		my $LockStatus =S_aref2dec ( $value_aref , U8 );
		push (@LockStatus_A,$LockStatus);											# Lock status before injecting crash
	}

	S_teststep("Inject '$tcpar_CrashCode1' for number of events which can be stored.", 'AUTO_NBR');  
	my $CrashCount=1;	
	while ($CrashCount <= $edrNumberOfEventsToBeStored)
	{
        # Prepare crash
        CSI_LoadCrashSensorData2Simulator($crashSettings);
        S_wait_ms(1000);

		CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    	S_wait_ms(1000);
		#--------------------------------------------------------------
		# CRASH INJECTION
		#
		S_teststep("Inject '$tcpar_CrashCode1' $CrashCount time.", 'AUTO_NBR');
	
		CSI_TriggerCrash();
		S_wait_ms(10000);
		$CrashCount++;
	}

	if (defined $tcpar_COMsignalsAfterCrash){
		S_w2rep("Send COM signals after crash");
		foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
		{				
			my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
			S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
			COM_setSignalState($signal,$dataOnCOM);	
		}
	}
	
	S_teststep("Read '$tcpar_LockStatusVariable' for all records with PD, measurement B", 'AUTO_NBR', 'read_lockstatusvariable_for_B');										#measurement 2
	for(my $index =($edrNumberOfEventsToBeStored-1);$index >= 0; $index--)
	{
		my $value_aref=PD_ReadMemoryByName("$tcpar_LockStatusVariable($index)");
		my $LockStatus =S_aref2dec ( $value_aref , U8 );
		push (@LockStatus_B,$LockStatus);										# Lock status after injecting crash
	}

	S_teststep("Reset ECU", 'AUTO_NBR');
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	if ($tcpar_UnlockAllRecords eq 'true'){
        S_teststep("Unlock all records", 'AUTO_NBR');
		$EDR_UNLOCK_RECORD = SYC_EDR_get_UnlockRecord();
		unless(defined $EDR_UNLOCK_RECORD){
			S_set_error("Not available in SYC - add or overwrite with Custlibrary Function");
			return;
		}
		if ($EDR_UNLOCK_RECORD eq "false"){
			S_set_error( "This testcase is not applicable for the project", 20 );
			return ;
		}
		else{
			EDR_CD_UnlockEDR();   #This is dummy function since this feature is not present in coreassets
			S_wait_ms(2000);
		}
	}

	S_teststep("Read '$tcpar_LockStatusVariable' for all records with PD, measurement C", 'AUTO_NBR', 'read_lockstatusvariable_for_C');													#measurement 3
	for(my $index =($edrNumberOfEventsToBeStored-1);$index >= 0; $index--)
	{
		my $value_aref=PD_ReadMemoryByName("$tcpar_LockStatusVariable($index)");
		my $LockStatus =S_aref2dec ( $value_aref , U8 );
		push (@LockStatus_C,$LockStatus);							# Lock status after unlocking EDR if applicable
	}

	S_teststep("Reset ECU", 'AUTO_NBR');
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');
	PD_ECUlogin();

	S_wait_ms('TIMER_ECU_READY');

	if ($tcpar_EraseAllRecords eq 'true'){
        S_teststep("Erase EDR if '$tcpar_EraseAllRecords'", 'AUTO_NBR');
	
		PD_ClearCrashRecorder_NOERROR();
		S_wait_ms(5000);
		LC_ECU_Off();
		S_wait_ms('TIMER_ECU_OFF');
		LC_ECU_On();
		S_wait_ms('TIMER_ECU_READY');
		PD_ECUlogin();

		S_wait_ms('TIMER_ECU_READY');
			
	}
	
	S_teststep("Read '$tcpar_LockStatusVariable' for all records with PD, measurement D", 'AUTO_NBR', 'read_lockstatusvariable_for_D');														#measurement 4
	for(my $index =($edrNumberOfEventsToBeStored-1);$index >= 0; $index--)
	{
		my $value_aref=PD_ReadMemoryByName("$tcpar_LockStatusVariable($index)");
		my $LockStatus =S_aref2dec ( $value_aref , U8 );
		push (@LockStatus_D,$LockStatus);						# Lock status after erasing EDR if applicable
	}

	if (defined $tcpar_CrashCode2){
		S_teststep("Inject '$tcpar_CrashCode2' for number of events which can be stored.", 'AUTO_NBR');
		#--------------------------------------------------------------
		# PREPARE CRASH AND INITIALIZE EQUIPMENT
		#
		S_w2rep("Get crash settings for crash $tcpar_CrashCode2");
		my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_CrashCode2};
        $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
        unless(defined $crashSettings) {
            S_set_error("Crash $tcpar_CrashCode2 not available in result DB $tcpar_ResultDB. Test case aborted.");
            return;
        }
		my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
		my $resultDB_Path = $resultDBDetails->{'PATH'};
		S_w2log(1, "Crashcode: $tcpar_CrashCode2, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");
		S_w2log(1, "Set environments for crash $tcpar_CrashCode2 as per result DB");
	    CSI_PrepareEnvironment($crashSettings, 'init_complete');

		my $CrashCount=1;
		while ($CrashCount <= $edrNumberOfEventsToBeStored){
			# Prepare crash
            CSI_LoadCrashSensorData2Simulator($crashSettings);
			S_wait_ms(1000); 
			#--------------------------------------------------------------
			# CRASH INJECTION
			#
			S_teststep("Inject '$tcpar_CrashCode2' $CrashCount time.", 'AUTO_NBR');
		
			CSI_TriggerCrash();
			S_wait_ms(8000);
			$CrashCount++;
		}

		if (defined $tcpar_COMsignalsAfterCrash){
			S_w2rep("Send COM signals after crash");
			foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
			{				
				my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
				S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
				COM_setSignalState($signal,$dataOnCOM);	
			}
		}	
	}
	
	S_teststep("Read '$tcpar_LockStatusVariable' for all records with PD, measurement E", 'AUTO_NBR', 'read_lockstatusvariable_for_E');														#measurement 5
	for(my $index =($edrNumberOfEventsToBeStored-1);$index >= 0; $index--)
	{
		my $value_aref=PD_ReadMemoryByName("$tcpar_LockStatusVariable($index)");
		my $LockStatus =S_aref2dec ( $value_aref , U8 );
		push (@LockStatus_E,$LockStatus);								# Lock status after injecting another crash if applicable
	}
	
	return 1;
}

sub TC_evaluation {
	
    # Measurement A: Before crash injection             
    S_teststep("--- Lock status before crash injection (EDR empty) ---", 'AUTO_NBR');                            
    S_teststep_expected_NOHTML("--- Lock status before crash injection (EDR empty) ---");                        
    S_teststep_detected_NOHTML("--- Lock status before crash injection (EDR empty) ---");              
    my $expectedValue = $tcpar_ExpectedLockStatus -> {'Measurement_A'}; 
    foreach my $recordNumber (1..$edrNumberOfEventsToBeStored)
	{			
		my $detectedValue= $LockStatus_A[$recordNumber-1];
		S_teststep_2nd_level("Lock status record $recordNumber", 'AUTO_NBR', "MeasurementA_record_$recordNumber");				
		EVAL_evaluate_value ( "LockStatus_MeasurementA_Record_$recordNumber", $detectedValue,'==', $expectedValue );
        S_teststep_expected("$expectedValue"."\n", "MeasurementA_record_$recordNumber");
        S_teststep_detected("$detectedValue"."\n", "MeasurementA_record_$recordNumber");
	}
								
    # Measurement B: After crash injection           
    S_teststep("--- Lock status after crash injection (EDR full) ---", 'AUTO_NBR');                       
    S_teststep_expected_NOHTML("--- Lock status after crash injection (EDR full) ---");                           
    S_teststep_detected_NOHTML("--- Lock status after crash injection (EDR full) ---");              
    $expectedValue = $tcpar_ExpectedLockStatus -> {'Measurement_B'};    
    foreach my $recordNumber (1..$edrNumberOfEventsToBeStored)
	{			
		my $detectedValue= $LockStatus_B[$recordNumber-1];
        S_teststep_2nd_level("Lock status record $recordNumber", 'AUTO_NBR', "MeasurementB_record_$recordNumber");              
		EVAL_evaluate_value ( "LockStatus_MeasurementB_Record_$recordNumber", $detectedValue,'==', $expectedValue );
        S_teststep_expected("$expectedValue", "MeasurementB_record_$recordNumber");
        S_teststep_detected("$detectedValue", "MeasurementB_record_$recordNumber");
	}
    
    # Measurement C: after unlocking EDR if applicable            
    S_teststep("--- Lock status unlocking EDR (if applicable) ---", 'AUTO_NBR');                           
    S_teststep_expected_NOHTML("--- Lock status unlocking EDR (if applicable) ---");                    
    S_teststep_detected_NOHTML("--- Lock status unlocking EDR (if applicable) ---");              
    $expectedValue = $tcpar_ExpectedLockStatus -> {'Measurement_C'};    
    foreach my $recordNumber (1..$edrNumberOfEventsToBeStored)
	{			
		my $detectedValue= $LockStatus_C[$recordNumber-1];
        S_teststep_2nd_level("Lock status record $recordNumber", 'AUTO_NBR', "MeasurementC_record_$recordNumber");              
		EVAL_evaluate_value ( "LockStatus_MeasurementC_Record_$recordNumber", $detectedValue,'==', $expectedValue );
        S_teststep_expected("$expectedValue", "MeasurementC_record_$recordNumber");
        S_teststep_detected("$detectedValue", "MeasurementC_record_$recordNumber");
	}

	
    # Measurement D: after erasing EDR if applicable             
    S_teststep("--- Lock status after erasing EDR (EDR empty) ---", 'AUTO_NBR');                         
    S_teststep_expected_NOHTML("--- Lock status after erasing EDR (EDR empty) ---");              
    S_teststep_detected_NOHTML("--- Lock status after erasing EDR (EDR empty) ---");              
    $expectedValue = $tcpar_ExpectedLockStatus -> {'Measurement_D'};    
    foreach my $recordNumber (1..$edrNumberOfEventsToBeStored)
	{			
		my $detectedValue= $LockStatus_D[$recordNumber-1];
        S_teststep_2nd_level("Lock status record $recordNumber", 'AUTO_NBR', "MeasurementD_record_$recordNumber");              
		EVAL_evaluate_value ( "LockStatus_MeasurementD_Record_$recordNumber", $detectedValue,'==', $expectedValue );
        S_teststep_expected("$expectedValue", "MeasurementD_record_$recordNumber");
        S_teststep_detected("$detectedValue", "MeasurementD_record_$recordNumber");
	}
	
    # Measurement E: after injecting second crash            
    S_teststep("--- Lock status after injecting crashes again (EDR full) ---", 'AUTO_NBR');                           
    S_teststep_expected_NOHTML("--- Lock status after injecting crashes again (EDR full) ---");                          
    S_teststep_detected_NOHTML("--- Lock status after injecting crashes again (EDR full) ---");              
    $expectedValue = $tcpar_ExpectedLockStatus -> {'Measurement_E'};    
    foreach my $recordNumber (1..$edrNumberOfEventsToBeStored)
	{
		my $detectedValue= $LockStatus_E[$recordNumber-1];
        S_teststep_2nd_level("Lock status record $recordNumber", 'AUTO_NBR', "MeasurementE_record_$recordNumber");              
		EVAL_evaluate_value ( "LockStatus_MeasurementE_Record_$recordNumber", $detectedValue,'==', $expectedValue );
        S_teststep_expected("$expectedValue", "MeasurementE_record_$recordNumber");
        S_teststep_detected("$detectedValue", "MeasurementE_record_$recordNumber");
	}

	return 1;
}

sub TC_finalization {

	# Erase EDR
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(2000);

	# Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	# Read fault memory after clearing and erasing EDR
    PD_ReadFaultMemory();   

	LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');
	return 1;
}


1;
