#### TEST CASE MODULE
package TC_EDR_FireTimes;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
#include further modules here
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_can_access;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use GENERIC_DCOM;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;
use Data::Dumper;

##################################

our $PURPOSE = "<summarize what this test is good for>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_FireTimes

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFaultNoCT


I<B<Stimulation and Measurement>>

1. Set environments for crash.

2. Power up ECU

3. Start recording of fire times.

4. Inject <Crashcode>

5. Wait for <WaitTime_ms>

6. Stop recording of fire times

7. Power down ECU

8. Power up ECU

9. Read EDR

10. Compare Deployment_EDIDs to LCT measurement.


I<B<Evaluation>>

1. - 

2. - 

3. - 

4. -

5. - 

6. - 

7. - 

8. - 

9. -

10. Deployment times stored in EDR are as measured.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Crashcode' => 
	SCALAR 'purpose' => 
	SCALAR 'ResultDB' => 
	SCALAR 'CrashT0_ms' => 
	SCALAR 'DiagType' => 
	SCALAR 'EvalTolerance_abs' => 
	HASH 'FireTime_EDIDs' => 
	SCALAR 'Autarky_T0' => Autarky at T0 of first incident if set to 'yes' or 'true'


=head2 PARAMETER EXAMPLES

	purpose = 'Inject <Test Heading> crash and evaluate record with respect to fire times' # description of test case
	
	# ---------- Stimulation ------------ 
	ResultDB = 'EDR' # defined in CREIS project constants - will be set to 'DEFAULT' if not given
	CrashT0_ms = '11.76'
	
	DiagType = 'ProdDiag'
	
	# ---------- Evaluation ------------ 
	EvalTolerance_abs = 3 #ms
	FireTime_EDIDs = %('AB1FD' => '51', 'AB2FD' => '52',  'AB3FD' => '53', 'AB1FP' => '56','AB2FP' => '57', 'AB3FP' => '58', 'BT1FD' => '63', 'BT1FC' => '108', 'BT1FP' => '67', 'BT2FD' => '109', 'BT2FP' => '110', 'BT2FC' => '111', 'BT3FD' => '1012', 'BT3FP' => '1013', 'BT1RD' => '145', 'BT1RC' => '147', 'BT1RP' => '146', 'SA1FD' => '61', 'SA1FP' => '65', 'SA1RD' => '1019', 'SA1RP' => '1020', 'KA1FD' => '101', 'KA1FP' => '102', 'IC1FD' => '62', 'IC1FP' => '66', 'ALLFD' => '115', 'ALLFP' => '116')
	Crashcode = 'Single_EDR_Front_Inflatable'
	
	Autarky_T0 = 'yes' #optional, default is 'no'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_ResultDB;
my $tcpar_CrashT0_ms;
my $tcpar_DiagType;
my $tcpar_EvalTolerance_abs;
my $tcpar_FireTime_EDIDs;
my $tcpar_Crashcode;
my $tcpar_WaitTime_ms;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_FireTimeTolerance_ms;
my $tcpar_Autarky_T0;
my $tcpar_read_NHTSAEDR;
my $tcpar_read_CHINAEDR;

################ global parameter declaration ###################
#add any global variables here
my ($record_handler, $crash_handler, $crashSettings, $squibLabels_aref,$ChinaEDR_diagType);

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_ResultDB =  S_read_optional_testcase_parameter( 'ResultDB' );
	$tcpar_ResultDB = 'DEFAULT' unless(defined $tcpar_ResultDB);
	$tcpar_WaitTime_ms =  S_read_mandatory_testcase_parameter( 'WaitTime_ms' );
	$tcpar_CrashT0_ms =  S_read_mandatory_testcase_parameter( 'CrashT0_ms' );
	$tcpar_DiagType =  S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_read_NHTSAEDR=S_read_optional_testcase_parameter('read_NHTSAEDR');
	$tcpar_read_CHINAEDR=S_read_optional_testcase_parameter('read_CHINAEDR');
	$tcpar_EvalTolerance_abs =  S_read_mandatory_testcase_parameter( 'EvalTolerance_abs' );
	$tcpar_FireTime_EDIDs =  S_read_mandatory_testcase_parameter( 'FireTime_EDIDs', 'byref' );
	$tcpar_Crashcode =  S_read_mandatory_testcase_parameter( 'Crashcode' );
	$tcpar_COMsignalsAfterCrash =  S_read_optional_testcase_parameter( 'COMsignalsAfterCrash','byref');
    $tcpar_FireTimeTolerance_ms = S_read_optional_testcase_parameter( 'FireTimeTolerance_ms' );
    if(not defined $tcpar_FireTimeTolerance_ms){
        S_w2rep("Set fire time tolerance to default value: 3ms");
        $tcpar_FireTimeTolerance_ms = 3;
    }
    $tcpar_Autarky_T0 = S_read_optional_testcase_parameter( 'Autarky_T0' );
    if(not defined $tcpar_Autarky_T0){
        $tcpar_Autarky_T0 = 'no';
    }
    $tcpar_Autarky_T0 = 'yes' if(lc($tcpar_Autarky_T0) eq 'true');
    if(lc($tcpar_Autarky_T0) ne 'yes' and lc($tcpar_Autarky_T0) ne 'no'){
        S_set_error("Parameter 'Autarky_T0' must be either 'yes' or 'no'", 110);
    }
	if(not defined $tcpar_read_CHINAEDR) {
		$tcpar_read_NHTSAEDR = 'yes';
		$tcpar_read_CHINAEDR = 'no';
	}
	else {
		$tcpar_read_NHTSAEDR = 'no';
		my $storageOrder = EDR_getStorageOrder();
		return unless(defined $storageOrder);

		if($storageOrder eq 'PhysicalOrder'){
			$ChinaEDR_diagType= 'ProdDiag';  #In platform NHTSA and China EDR is read via proddiag
		}
		else {
			$ChinaEDR_diagType= 'CHINA_Payload';
		}
	}
	

	return 1;
}

sub TC_initialization {

	S_teststep("Test setup preparation", 'AUTO_NBR');

	#--------------------------------------------------------------
    # INITIALIZE RECORD AND CRASH HANDLER
    #    
	S_w2rep("Initialize Record and Crash Handler");
	$record_handler = EDR_init_RecordHandler() || return;
	$crash_handler  = EDR_init_CrashHandler() || return;

	#--------------------------------------------------------------
    # PREPARE CRASH AND INITIALIZE EQUIPMENT
    #
	S_w2rep("Get crash settings for crash $tcpar_Crashcode");
    my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode};
    $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
    unless(defined $crashSettings) {
        S_set_error("Crash $tcpar_Crashcode not available in result DB $tcpar_ResultDB. Test case aborted.");
        return;
    }

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log(1, "Crashcode: $tcpar_Crashcode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");

	S_w2log(1, "Power on ECU");
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

    S_w2log(1, "Initialize CD and start CAN trace");
    GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start ( );

	S_w2log(1, "Set environments for crash as per result DB");
    CSI_PrepareEnvironment($crashSettings, 'init_complete');
    S_wait_ms(2000);

	S_w2log(1, "Clear crash recorder");
    PD_ClearCrashRecorder();
    S_wait_ms(2000);

	S_w2log(1, "Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	S_w2log(1, "Reset ECU");
    PD_ECUreset();
    S_wait_ms('TIMER_ECU_READY');

	S_w2log(1, "Read and evaluate fault memory before stimulation");
    my $faultsBeforeStimulation = PD_ReadFaultMemory();
    my $faultsVerdict = PD_evaluate_faults( $faultsBeforeStimulation, []);
  	return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

	return 1;
}

sub TC_stimulation_and_measurement {

	#--------------------------------------------------------------
    # CRASH PREPARATION
    #
	S_teststep("Prepare crash", 'AUTO_NBR');
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	# Prepare crash
    CSI_LoadCrashSensorData2Simulator($crashSettings);

	# Power ON the ECU
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    S_wait_ms(1000);
	#--------------------------------------------------------------
    # CRASH INJECTION
    #
	S_teststep("Start recording of fire times.", 'AUTO_NBR');
    LC_MeasureTraceDigitalStart();

	S_teststep("Inject '$tcpar_Crashcode'", 'AUTO_NBR');
	CSI_TriggerCrash();
	if(lc($tcpar_Autarky_T0) eq 'yes'){
	    my @crashTimeZero = split(/_/, $tcpar_CrashT0_ms);
	    my $t0FirstIncident = $crashTimeZero[0];
	    S_teststep("Wait for T0 of first incident ($t0FirstIncident ms) and then cut power");
	    S_wait_ms($t0FirstIncident);
	    LC_ECU_Off();
	}

	S_teststep("Wait for '$tcpar_WaitTime_ms'", 'AUTO_NBR');
    S_wait_ms($tcpar_WaitTime_ms);

	S_teststep("Stop recording of fire times", 'AUTO_NBR');
    LC_MeasureTraceDigitalStop();

	if (defined $tcpar_COMsignalsAfterCrash){
		foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
		{				
			my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
			S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
			COM_setSignalState($signal,$dataOnCOM);	
		}
	}
	S_wait_ms(2000);

    if(lc($tcpar_Autarky_T0) eq 'yes'){
        S_teststep("Turn ECU back on after crash");
        LC_ECU_On();
        S_wait_ms('TIMER_ECU_READY');
    }


	#--------------------------------------------------------------
    # MEASUREMENTS
    #
	S_teststep("Read EDR", 'AUTO_NBR');
    my $dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_".$tcpar_Crashcode;

	my $edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();

	PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');

	if ( lc( $tcpar_read_NHTSAEDR) eq 'yes' ) {
		EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
								"CrashLabel" => $tcpar_Crashcode,
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								"read_EDRType"=>'NHTSA')
	}
	if (lc($tcpar_read_CHINAEDR) eq 'yes'){
		$edrNumberOfEventsToBeStored=3;
		EDR_ReadAndStoreAllRecords ("DiagType" =>  $ChinaEDR_diagType,
								"CrashLabel" => $tcpar_Crashcode,
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								"read_EDRType"=>'CHINA');
	}
		
	S_teststep("Store measured deployment times", 'AUTO_NBR', 'compare_deployment_edids');			#measurement 1
    my $lct_Data = LC_MeasureTraceDigitalGetValues();

	# Get list of all measured squib labels
	foreach my $lctTimeStamp (keys %{$lct_Data})
	{
		foreach my $squib (keys %{$lct_Data -> {$lctTimeStamp}})
		{
			push(@{$squibLabels_aref}, $squib);		
		}
		last;
	}
	if(defined $squibLabels_aref) {
		EVAL_dump2UNV( $lct_Data, "$dataStoragePath/LCT_Measurement.txt.unv" );
	
		EDR_addFireTimesToCrashHandler ("LCT_Measurement" => $lct_Data,
										"SquibLabels" => $squibLabels_aref,
										"CrashLabel"  => $tcpar_Crashcode,
										"StoragePath" => $dataStoragePath)		
	}
	else {
		S_w2rep("No deployment times measured");
	}


	return 1;
}

sub TC_evaluation {

	#--------------------------------------------------------------
    # FIRE TIMES
    #
    S_teststep("Validate deployment times stored in EDR", 'AUTO_NBR');

    my $considerAutarky = 'true' if($tcpar_Autarky_T0 eq 'yes');
	my $squibVerdict = EDR_Eval_SquibFireTimes("CrashLabel" => $tcpar_Crashcode,
	                                           "EDID_SquibLabels" => $tcpar_FireTime_EDIDs,
	                                           "CrashTimeZero_ms" => $tcpar_CrashT0_ms,
	                                           "FireTimeTolerance_ms" => $tcpar_FireTimeTolerance_ms,
                                               "Autarky" => $considerAutarky);

	return 1;
}

sub TC_finalization {

	# Erase EDR
    PD_ClearCrashRecorder();
    S_wait_ms(2000);
	
	# Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(10000);

	# Reset ECU    
    PD_ECUreset();
    S_wait_ms('TIMER_ECU_READY');

	# Read fault memory after clearing and erasing EDR
    PD_ReadFaultMemory(); 
	S_wait_ms(2000);	
    
    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');
    
    S_w2rep("Clean up record and crash handler");
    $record_handler -> DeleteAllRecords();
    $crash_handler -> DeleteAllSources();


	return 1;
}


1;
