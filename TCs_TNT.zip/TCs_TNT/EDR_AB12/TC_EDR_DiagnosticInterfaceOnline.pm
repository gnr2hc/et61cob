#### TEST CASE MODULE
package TC_EDR_DiagnosticInterfaceOnline;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
#include further modules here
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use GENERIC_DCOM;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;
use LIFT_can_access;
use Data::Dumper;


##################################

our $PURPOSE = "This test script evaluates diagnostics in motion";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_DiagnosticInterfaceOnline

=head1 PURPOSE

<This test script evaluates diagnostics in motion>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Inject <crashcode>.

2. Power down ECU

3. Wait <wait_ms>

4. Power up ECU

5. Set vehicle speed in <COM_Message> to 50km/h if <vehicle_in_motion> is true, else 0km/h

6. Wait <wait_ms>

7. Call <diag_service> if <service_configured> is true

8. Stop car if <vehicle_in_motion> is true

9. Read EDR record 


I<B<Evaluation>>

1. -

2. -

3. -

4. -

5. -

6. -

7. -

8. -

9. Check if <diag_service> was performed correctly depending on <service_configured>

The EDR data should be stored in<expected_nr_of_records>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'expected_nr_of_records' => 
	SCALAR 'purpose' => 
	SCALAR 'crashcode' => 
	SCALAR 'vehicle_in_motion' => 
	SCALAR 'COM_Message' => 
	SCALAR 'diag_service' => 
	SCALAR 'service_configured' => 
	SCALAR 'wait_ms' => 


=head2 PARAMETER EXAMPLES

	purpose		 = 'check whether the diagnostic service  'ReadEDR' works correctly'
	
	# ---------- Stimulation ------------ 
	crashcode = 'Single_EDR_Front_Inflatable'
	EDR_ALLOW_ONLINE_DIAG = 'True'
	
	diag_service = 'ReadEDR'
	
	wait_ms = 5000 #ms
	
	# ---------- Evaluation ------------ 
	expected_nr_of_records = 0

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Crashcode;
my $tcpar_vehicle_in_motion;
my $tcpar_COM_Message;
my $tcpar_diag_service;
my $tcpar_wait_ms;
my $tcpar_NbrOfRecordsExpected;
my $tcpar_ResultDB;
my $tcpar_DiagType;
my $tcpar_Response;
my $EDR_ALLOW_ONLINE_DIAG;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_Protocol;
my $tcpar_read_NHTSAEDR;
my $tcpar_read_CHINAEDR;
################ global parameter declaration ###################
#add any global variables here
my ($crashSettings,$readEDR_response_aref,$edrNumberOfEventsToBeStored);
my @Obtained_response;
my $verdict ;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_Crashcode =  S_read_mandatory_testcase_parameter( 'crashcode' );
	$tcpar_COM_Message =  S_read_mandatory_testcase_parameter( 'COM_Message' );
	$tcpar_diag_service =  S_read_mandatory_testcase_parameter( 'diag_service' );
	$tcpar_wait_ms =  S_read_mandatory_testcase_parameter( 'wait_ms' );
	$tcpar_NbrOfRecordsExpected =  S_read_mandatory_testcase_parameter( 'expected_nr_of_records' );
	$tcpar_ResultDB =  S_read_optional_testcase_parameter( 'ResultDB' );
	$tcpar_DiagType =  S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_Response =  S_read_mandatory_testcase_parameter( 'Response' );
	$tcpar_COMsignalsAfterCrash =  S_read_optional_testcase_parameter( 'COMsignalsAfterCrash','byref');
	$tcpar_Protocol = S_read_optional_testcase_parameter('Protocol');
	unless(lc($tcpar_Protocol) =~ m/can/i or lc($tcpar_Protocol) =~ m/flexray/i) {
		S_w2rep("Set communication protocol to default CAN");
		$tcpar_Protocol = 'CAN';
	}
	$tcpar_read_NHTSAEDR=S_read_optional_testcase_parameter('read_NHTSAEDR');
	$tcpar_read_CHINAEDR=S_read_optional_testcase_parameter('read_CHINAEDR');
	if(not defined $tcpar_read_CHINAEDR) {
		$tcpar_read_NHTSAEDR = 'yes';
		$tcpar_read_CHINAEDR = 'no';
	}
	else {
		$tcpar_read_NHTSAEDR = 'no';
		$tcpar_DiagType= 'CHINA_Payload';	
	}
	
	return 1;
}

sub TC_initialization {
	
	$EDR_ALLOW_ONLINE_DIAG = SYC_EDR_get_DiagInMotion( );
	unless(defined $EDR_ALLOW_ONLINE_DIAG){
		S_set_error("Configuration of online diagnosis not available in SYC - add or overwrite with Custlibrary Function");
        return;
    }
	if ($EDR_ALLOW_ONLINE_DIAG eq "false"){
		S_w2rep("$tcpar_Response is expected");
	}

	S_teststep("Test setup preparation", 'AUTO_NBR');

	#--------------------------------------------------------------
    # PREPARE CRASH AND INITIALIZE EQUIPMENT
    #
	S_w2rep("Get crash settings for crash $tcpar_Crashcode");
    my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode};
    $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
    unless(defined $crashSettings) {
        S_set_error("Crash $tcpar_Crashcode not available in result DB $tcpar_ResultDB. Test case aborted.");
        return;
    }

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log(1, "Crashcode: $tcpar_Crashcode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");

	S_w2log(1, "Power on ECU");
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

    S_w2log(1, "Initialize CD and start CAN trace");
    GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start ( );

	S_w2log(1, "Set environments for crash as per result DB");
    CSI_PrepareEnvironment($crashSettings, 'init_complete');

	S_w2log(1, "Clear crash recorder");
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(2000);

	S_w2log(1, "Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	S_w2log(1, "Read and evaluate fault memory before stimulation");
    my $faultsBeforeStimulation = PD_ReadFaultMemory();

    #Fault memory must be empty
    my $faultsVerdict = PD_evaluate_faults( $faultsBeforeStimulation, []);
    return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

	return 1;
}

sub TC_stimulation_and_measurement {

    #--------------------------------------------------------------
    # CRASH PREPARATION
    #

    # Prepare crash
    S_teststep("Prepare crash", 'AUTO_NBR');
    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

    # Prepare crash
    CSI_LoadCrashSensorData2Simulator($crashSettings);

    # Power ON the ECU
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');
	
	CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    S_wait_ms(1000);

	#--------------------------------------------------------------
    # CRASH INJECTION
    #
	S_teststep("Inject '$tcpar_Crashcode'.", 'AUTO_NBR');
	CSI_TriggerCrash();
    S_wait_ms(10000);
	if (defined $tcpar_COMsignalsAfterCrash){
		foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
		{				
			my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
			S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
			COM_setSignalState($signal,$dataOnCOM,$tcpar_Protocol);	
		}
	}

	S_teststep("Set vehicle speed in '$tcpar_COM_Message' to 50km/h ", 'AUTO_NBR');
	COM_setSignalState($tcpar_COM_Message,'5000', $tcpar_Protocol);
		
	S_teststep("Wait '$tcpar_wait_ms'", 'AUTO_NBR');
	S_wait_ms($tcpar_wait_ms);

	S_teststep("Call '$tcpar_diag_service'", 'AUTO_NBR');  #measurement 1
    my $Label = 1;# This label is given for evaluation of diagnostic response
	if ($tcpar_diag_service eq 'ReadRecord'){
		if ( lc( $tcpar_read_NHTSAEDR) eq 'yes' ) {
			if ($tcpar_DiagType eq 'ProdDiag'){
				S_teststep("Read EDR via PD", 'AUTO_NBR', "$tcpar_diag_service");	
				PD_ECUlogin();
				S_wait_ms(2000);
				$readEDR_response_aref=PD_ReadCrashRecorder_NOERROR(0);
			}
			else{
				S_teststep("Read EDR record via CD ", 'AUTO_NBR', "$tcpar_diag_service");	
				$readEDR_response_aref=EDR_CD_ReadEDR('1',undef,$tcpar_Response,$Label);	
			}
		}
		if (lc($tcpar_read_CHINAEDR) eq 'yes'){
			S_teststep("Read China EDR record via CD ", 'AUTO_NBR', "$tcpar_diag_service");
			$readEDR_response_aref=EDR_CD_ReadCHINAEDR('1',undef,$tcpar_Response,$Label);
		}
	}
	elsif($tcpar_diag_service eq 'EraseRecord'){
		if ($tcpar_DiagType eq 'ProdDiag'){
			S_teststep("Erase EDR via PD", 'AUTO_NBR', "$tcpar_diag_service");
			my $clearFlag;
			($clearFlag, $readEDR_response_aref) = PD_ClearCrashRecorder_NOERROR()
		}
		else{
			S_teststep("Erase EDR record via CD", 'AUTO_NBR', "$tcpar_diag_service");	
			$readEDR_response_aref = EDR_CD_EraseEDR($tcpar_Response);
		}
	}
	else{
		S_set_error("$tcpar_diag_service is not available or unknown");
	}
	$readEDR_response_aref = [1] if($main::opt_offline);

	foreach my $byteInEDRresponse (@{$readEDR_response_aref})
    {
        push (@Obtained_response,$byteInEDRresponse);
    }
						
    S_teststep("Stop car", 'AUTO_NBR');								
	COM_setSignalState($tcpar_COM_Message,'0', $tcpar_Protocol);							
	S_wait_ms(1000);

	return 1;
}

sub TC_evaluation {

	my $verdict_platform= "VERDICT_FAIL";
	my $length= scalar(@$readEDR_response_aref);
	S_w2rep("EDR response length = $length bytes");

	if ($length > 3){
		if ($tcpar_DiagType eq 'ProdDiag' ){
			S_w2rep("Detected response is a positive response. For platform online diagnostics is not applicable");
			S_set_verdict("VERDICT_PASS");
			$verdict_platform = "VERDICT_PASS";
		
		}
		elsif ($EDR_ALLOW_ONLINE_DIAG eq "false"){
			S_w2rep("$tcpar_Response is expected,Detected response is a positive response");
			S_set_verdict("VERDICT_PASS");
			$verdict = "VERDICT_PASS";
		}
		else {
			S_w2rep("Detected response is greater than 3 bytes of expected NRC, a positive response may be obtained");
			S_set_verdict("VERDICT_FAIL");
			$verdict = "VERDICT_FAIL";
		}
			
	}
	else{
		S_w2rep("Detected response is 3 bytes of expected NRC");
		S_set_verdict("VERDICT_PASS");
		$verdict = "VERDICT_PASS";

	}
	
	if ($tcpar_DiagType eq 'ProdDiag')
	{
		S_teststep_expected	("Expected positive response ","$tcpar_diag_service");
		S_teststep_detected("Detected response is a positive response for platform project", "$tcpar_diag_service") if $verdict_platform eq 'VERDICT_PASS';
		S_teststep_detected("Detected response is a NRC", "$tcpar_diag_service") if $verdict_platform eq 'VERDICT_FAIL';
	}
	elsif ($EDR_ALLOW_ONLINE_DIAG eq "false")
	{
		S_teststep_expected	("Expected positive response ","$tcpar_diag_service");
		S_teststep_detected("Detected response is a positive response", "$tcpar_diag_service") if $verdict_platform eq 'VERDICT_PASS';
		S_teststep_detected("Detected response is a NRC", "$tcpar_diag_service") if $verdict_platform eq 'VERDICT_FAIL';
	}
	else{

		S_teststep_expected	("Expected NRC when online diagnostics is not allowed ","$tcpar_diag_service");
		S_teststep_detected("Detected response is @Obtained_response (NRC) in decimal format", "$tcpar_diag_service") if $verdict eq 'VERDICT_PASS'; 
		S_teststep_detected("Detected response is more than 3 bytes of expected NRC,@Obtained_response in decimal format", "$tcpar_diag_service") if $verdict eq 'VERDICT_FAIL'; 
	}


	return 1;
}

sub TC_finalization {

	# Erase EDR
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(2000);

	# Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	# Read fault memory after clearing and erasing EDR
    PD_ReadFaultMemory();   

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');
	return 1;
}


1;
