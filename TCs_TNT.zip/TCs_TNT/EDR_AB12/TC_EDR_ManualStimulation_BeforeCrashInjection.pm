#### TEST CASE MODULE
package TC_EDR_ManualStimulation_BeforeCrashInjection;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS_EDID_GenericEDIDList> 
#TS version in DOORS: <1.10> 
#-------------------------------------------------------------------------


#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general;
use LIFT_evaluation;
use LIFT_PD;
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_MDSRESULT;
use GENERIC_DCOM;
use LIFT_can_access;
use LIFT_flexray_access;
use INCLUDES_Project;
use File::Basename;
use Data::Dumper;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;
use constant MILLISEC_TO_SECOND => 0.001;
use constant SECOND_TO_MILLISEC => 1000;
##################################

# Todo: Update documenation
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_ManualStimulation_BeforeCrashInjection  

requires test setup with
	- Quate
	- MDS data base
	- LCT 64
	- CANoe
	- TSG4

default state is faultfree ECU powered ON

=head1 PURPOSE

inject a crash and store all data in record and crash handler for use in later test cases

=head1 TESTCASE DESCRIPTION 

    [initialisation]
    initialize record handler
    initialize crash handler
    clear crash recorder and fault memory

    [stimulation & measurement]
	1. start LCT measurement and CAN trace
	2. Perform any manual stimulation if required
    3. inject crash
    4. stop LCT measurement
    5. read all crash records and add to record handler
	6. Store CAN trace
    7. get all sensor data and add to crash handler
	8. get switch states and add to crash handler
    9. add all fire times to crash handler
	(Steps 6. to 8.: Which data is stored in crash handler depends on storage options parameter)
	
	All data in record and crash handler will be available to the rest of the test cases in the testlist!
	
    [evaluation]
    1. no evaluation required if no EDID is given
	2. If EDID number is given, print the detected EDID data in raw and decoded form.

    [finalisation]
    1. clear fault memory
    2. clear crash recorder
    3. reset ECU

=head2 PARAMETER NAMES

	SCALAR 'Val_SpecialBehaviourBits' => 
	SCALAR 'ExpVal_SpecialBehaviourBits' => 
	SCALAR 'Crashcode' => 
	SCALAR 'purpose' => 
	LIST 'EDIDs' => 
	SCALAR 'DiagType' => 
	SCALAR 'ResultDB' => 
	SCALAR 'EDIDNr_Supplier' => 
	HASH 'COMsignalsAfterCrash' => 
	SCALAR 'Var_SpecialBehaviourBits' => 
	SCALAR 'WaitTime_ms' => 


=head2 PARAMETER EXAMPLES

	purpose	 = 'to validate the data element 'Special behavior table' recorded in EDR'
	
	EDIDs= @('5007')
	DiagType = 'ProdDiag'
	ResultDB = 'EDR'
	EDIDNr_Supplier = '999'
	COMsignalsAfterCrash = %()
	Var_SpecialBehaviourBits= 'rb_sycg_StaticBehaviorBits_dfst.rb_sycg_StaticBits_ab8(0)'
	WaitTime_ms=6000 #ms
	Val_SpecialBehaviourBits='None'
	#normal case after flashing.
	ExpVal_SpecialBehaviourBits ='0x20'
	Crashcode='Multi_EDR_Side_ND_Front_AD;5'

=cut


#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Crashtype;
my $tcpar_DiagType;
my $tcpar_Protocol;
my $tcpar_CrashTimeZero_ms;
my $tcpar_ResultDB;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_FireCurrentThreshold;
my $tcpar_purpose;
my $tcpar_EDIDNr_Supplier;
my $tcpar_FD_Variables_aref;
my $tcpar_FD_VariablesTypes_aref;
my $tcpar_EDIDs;

################ global parameter declaration ###################
#add any global variables here
my (
		$record_handler,
		$crash_handler,
		$crashSettings,
		$crashDetails_href,
		$crashInfo_href,
		$numberOfRecords
	);

our $PURPOSE;
our $TC_name = "TC_EDR_ManualStimulation_BeforeCrashInjection";

#-------------------------------------------------------------------------------
sub TC_set_parameters {
#-------------------------------------------------------------------------------
	S_w2rep("Read testcase parameters");
	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
    $tcpar_Crashtype = S_read_mandatory_testcase_parameter('Crashcode');
    $tcpar_DiagType = S_read_mandatory_testcase_parameter('DiagType');
    $tcpar_ResultDB = S_read_optional_testcase_parameter('ResultDB');
    $tcpar_ResultDB = 'DEFAULT' unless (defined $tcpar_ResultDB);

	$tcpar_COMsignalsAfterCrash =  S_read_optional_testcase_parameter( 'COMsignalsAfterCrash','byref');
	$tcpar_FireCurrentThreshold =  S_read_optional_testcase_parameter( 'FireCurrentThreshold');
	$tcpar_EDIDNr_Supplier =  S_read_optional_testcase_parameter( 'EDIDNr_Supplier');
    $tcpar_FD_Variables_aref = S_read_optional_testcase_parameter( 'FD_Variables', 'byref');
    $tcpar_EDIDs = S_read_optional_testcase_parameter('EDIDs','byref');
    if($tcpar_FD_Variables_aref){
        $tcpar_FD_VariablesTypes_aref = S_read_mandatory_testcase_parameter( 'FD_Variables_Types', 'byref');
    }

	return 1;
}

#-------------------------------------------------------------------------------
sub TC_initialization {
#-------------------------------------------------------------------------------

	#--------------------------------------------------------------
    # INITIALIZE RECORD AND CRASH HANDLER
    #    
	S_w2rep("Initialize Record and Crash Handler");
	$record_handler = EDR_init_RecordHandler() || return;
	$crash_handler  = EDR_init_CrashHandler() || return;

	#--------------------------------------------------------------
    # GET CRASH DETAILS
    #    
	# Crash name or index and result DB from EDR mapping
    $crashDetails_href = {'RESULTDB' => $tcpar_ResultDB, 'CRASHNAME' => $tcpar_Crashtype};
	# Crash settings
	$crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
	unless(defined $crashSettings) {
		S_set_error("Crash code $tcpar_Crashtype not defined in given result DB. Test case will be aborted.");
		return 0;
	}
	# Make crash label unique if threshold was set
	if (defined $tcpar_FireCurrentThreshold) {
		my $measureThreshold = $tcpar_FireCurrentThreshold;
		S_w2rep("Current threshold: $measureThreshold ");
		$measureThreshold =~ s/\./_/g;
		$tcpar_Crashtype .= "_".$measureThreshold."A";
	}
	#--------------------------------------------------------------
    # ADD EDR CRASH TIME ZERO AS CRASH SOURCE
    #
    $crashInfo_href -> {"CrashCode_MDS"} = $tcpar_Crashtype;

	# Name of Result DB
	my $resultDB = $crashDetails_href -> {"RESULTDB"};
	unless(defined $resultDB) {
		$resultDB = "DEFAULT";
	}

	# Result DB path
	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$resultDB" ] );
	$crashInfo_href -> {"MDB_Path"} = $resultDBDetails->{'PATH'};

	# Crash time Zero and EDR crash label -> crash name in EDR mapping
	$crashInfo_href -> {"CrashTimeZero_ms"} = $tcpar_CrashTimeZero_ms;
	$crashInfo_href -> {"CrashLabel"} = $tcpar_Crashtype;

	#--------------------------------------------------------------
    # Initialize equipment
    #

	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');
    CA_trace_start();
    GDCOM_init () ; # To fetch info for CD from mapping_diag

	# Set environment settings for crash
	CSI_PrepareEnvironment($crashSettings, 'init_complete');
	S_wait_ms('TIMER_ECU_READY');
    PD_ClearCrashRecorder();
    S_wait_ms(2000);
    # erase FltMem
    PD_ClearFaultMemory();
    S_wait_ms(2000);
	# read fault memory
    my $faultsBeforeStimulation = PD_ReadFaultMemory();
	#Fault memory must be empty
    my $faultsVerdict = PD_evaluate_faults( $faultsBeforeStimulation, []);
 	return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

    return 1;
}

#-------------------------------------------------------------------------------
sub TC_stimulation_and_measurement {
#-------------------------------------------------------------------------------
	#--------------------------------------------------------------
    # CRASH PREPARATION
    #
    S_teststep("Prepare crash (download crash data)", 'AUTO_NBR');
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	# Prepare crash
	CSI_LoadCrashSensorData2Simulator( $crashSettings )unless $main::opt_offline;

	# Power ON the ECU
	LC_ECU_On();
 	S_wait_ms('TIMER_ECU_READY');
 	
 	CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    S_wait_ms(1000);
    
 	# User Action for manual stimulation
    S_teststep("<<MANUAL STIMULATION STEP>>", 'AUTO_NBR');
 	S_user_action("Crash '$tcpar_Crashtype' about to be injected.\n Perform manual stimulation.\n");
	#--------------------------------------------------------------
    # START MEASUREMENTS
    #
    S_teststep("Configure and start LCT Measurement", 'AUTO_NBR');

    # configure digital fire time measurement
    if($tcpar_FireCurrentThreshold){
        S_teststep_2nd_level("Set measurement threshold to $tcpar_FireCurrentThreshold A for all squibs", 'AUTO_NBR');
        LC_MeasureTraceDigitalConfigureThresholds( ['ALL'], $tcpar_FireCurrentThreshold );
    }
    else {
        S_teststep_2nd_level("Set measurement threshold to 0.5 A for all squibs", 'AUTO_NBR');
        LC_MeasureTraceDigitalConfigureThresholds( ['ALL'], 0.5 );
    }
    S_teststep_2nd_level("Start fire time measurement", 'AUTO_NBR');
    LC_MeasureTraceDigitalStart();
    my $fastDiag;
    if($tcpar_FD_Variables_aref){
        S_teststep_2nd_level("Start fast diag measurement", 'AUTO_NBR');
        $fastDiag = PD_StartFastDiagName( "$main::REPORT_PATH/".S_get_TC_number()."__FastDiagMeasurement" , $tcpar_FD_Variables_aref , $tcpar_FD_VariablesTypes_aref , undef, 4);
    }
	#--------------------------------------------------------------
    # CRASH INJECTION
    #
	S_teststep("Inject crash $tcpar_Crashtype", 'AUTO_NBR');
	CSI_TriggerCrash();
    S_wait_ms(10000);
    if($tcpar_FD_Variables_aref and $fastDiag){
      S_teststep_2nd_level("Stop fast diag measurement", 'AUTO_NBR');
      PD_StopFastDiag();
    }
    S_wait_ms(10000);
	#--------------------------------------------------------------
    # STOP MEASUREMENTS
    #
	S_teststep("Stop LCT Measurement", 'AUTO_NBR');
    LC_MeasureTraceDigitalStop();

	if (defined $tcpar_COMsignalsAfterCrash){
		foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
		{
			my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
			S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
			COM_setSignalState($signal,$dataOnCOM);
		}
	}
	S_wait_ms(2000);
    # Rollover has long storing times
    S_wait_ms(20000) if ($tcpar_Crashtype =~ /Rollover/);
	#--------------------------------------------------------------
    # READ AND STORE CRASH RECORDS
    #
    my $dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_".$tcpar_Crashtype;

    # ************** 1 - CRASH RECORDS **************   
	S_teststep("Get all stored records via CustDiag and store in record handler", 'AUTO_NBR', 'read_EDR_records');
	$numberOfRecords = SYC_EDR_get_NumberOfEventsToBeStored();
	unless(defined $numberOfRecords){
        S_set_error("Not available in SYC - add or overwrite with Custlibrary Function");
        return;
    }
	PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');
	EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
								"CrashLabel" => $tcpar_Crashtype,
								"NbrOfRecords" =>  $numberOfRecords,
								"StoragePath" => $dataStoragePath,
								"CrashInfo" => $crashInfo_href,);
	my $recordAvailable = $record_handler -> IsRecordAvailable("CrashLabel" => $tcpar_Crashtype, "RecordNumber"=> 1);
	if($recordAvailable){
		$record_handler -> ExportCrashRecordsToExcel("CrashLabel" => $tcpar_Crashtype,
													"Filepath" => $dataStoragePath."\\".$tcpar_Crashtype.".xlsx");
	}

	foreach my $recordNbr (1..$numberOfRecords)
	{
		$record_handler -> PrintDecodedEDIDs( "RecordNumber" => $recordNbr,
                                          "CrashLabel" => $tcpar_Crashtype,);
		#--------------------------------------------------------------
		# PRINT SUPPLIER EDIDS
		#    
		# ----------------------------------------------------------- 
		$recordAvailable = $record_handler -> IsRecordAvailable("CrashLabel" => $tcpar_Crashtype,"RecordNumber"=> $recordNbr);
		if ($recordAvailable and defined $tcpar_EDIDNr_Supplier)
		{
			my $recordData_aref = $record_handler -> GetRawEDID("EDIDnr" => $tcpar_EDIDNr_Supplier,
																"RecordNumber" => $recordNbr,
																"CrashLabel" => $tcpar_Crashtype,);
			my $recordStructure_href = EDR_ReadEDR_Record_structure_info_from_mapping_NOERROR('Supplier',0,'Mapping_EDR','SUPPLIER_EDIDS');
			if (defined $recordStructure_href ){
			$record_handler -> AddCrashRecord(
												"RecordNumber" => $recordNbr,
												"CrashLabel"   => $tcpar_Crashtype.'_Supplier',
												"RecordStructureInfo" => $recordStructure_href,
												"RawDataGeneric" => $recordData_aref,
												);
			$record_handler -> PrintRawEDIDs( "RecordNumber" => $recordNbr,
												"CrashLabel" => $tcpar_Crashtype.'_Supplier',
												"FormatOption" => 'HEX');
			$record_handler -> PrintDecodedEDIDs( "RecordNumber" => $recordNbr,
                                          "CrashLabel" => $tcpar_Crashtype.'_Supplier');
			}
			else
			{
				S_w2rep("No Supplier EDID data found for in the record number $recordNbr .");
				next;
			}
		}
		else
		{
			S_w2rep("Requested EDR record is empty.NO supplier edids will be printed.");
			next;
		}
	}
	PD_ECUlogin();
	S_wait_ms(2000);
	PD_DumpNVMData_NOERROR_NOHTML($main::REPORT_PATH . "/".S_get_TC_number(). "_ReadAllNVMSections_Dump.txt");


	#--------------------------------------------------------------
    # STORE MEASUREMENTS
    #
	S_w2rep("Store $tcpar_Protocol Trace");
	my $fileName = "$dataStoragePath/LIFT_network_trace_$tcpar_Crashtype.asc";
	my $tracePath;
	$tracePath = CA_trace_store($fileName) if (lc($tcpar_Protocol) =~ m/can/i);
	$tracePath = FR_trace_store($fileName) if (lc($tcpar_Protocol) =~ m/flexray/i);
	S_w2rep("Trace File: $tracePath");

	# Restart Rest bus simulation - is stopped when storing!
	S_wait_ms(2000);
	CA_trace_start() if (lc($tcpar_Protocol) =~ m/can/i);
	FR_trace_start() if (lc($tcpar_Protocol) =~ m/flexray/i);

    # ************** 1 - FIRE TIMES **************       
	S_teststep("Get and store measured fire times", 'AUTO_NBR');

	S_w2rep("Get measured squib fire values by calling LC_MeasureTraceDigitalGetValues()");
    LC_MeasureTraceDigitalGetValues();

    return 1;
}

#-------------------------------------------------------------------------------
sub TC_evaluation {
#-------------------------------------------------------------------------------
	S_set_verdict('VERDICT_FAIL');
	if(defined $tcpar_EDIDs)
	{
		foreach my $EDID (@$tcpar_EDIDs)
		{
			my $dataElement = $record_handler -> GetDataElementEDID(  "EDIDnr" => $EDID,
																  "RecordNumber" => 1,
																  "CrashLabel" => $tcpar_Crashtype);
			if (not defined $dataElement){
				$dataElement = $record_handler -> GetDataElementEDID(  "EDIDnr" => $EDID,
																  "RecordNumber" => 1,
																  "CrashLabel" => $tcpar_Crashtype."_Supplier");
			}
			foreach my $recordNbr (1..$numberOfRecords)
			{
				my $edidData_hashref = $record_handler -> GetDecodedEDID( "EDIDnr" => $EDID,
																	   "RecordNumber"=> $recordNbr,
																	   "CrashLabel" => $tcpar_Crashtype);
				my $rawData = $record_handler -> GetRawEDID( "EDIDnr" => $EDID,
															"RecordNumber" => $recordNbr,
															"CrashLabel" => $tcpar_Crashtype,
															"FormatOption" => 'HEX');
				if(not defined $edidData_hashref)
				{
					$edidData_hashref = $record_handler -> GetDecodedEDID("EDIDnr"=> $EDID,
																		"RecordNumber"=> $recordNbr,
																		"CrashLabel" => $tcpar_Crashtype."_Supplier");
					$rawData = $record_handler -> GetRawEDID( "EDIDnr" => $EDID,
															 "RecordNumber"=> $recordNbr,
															 "CrashLabel" => $tcpar_Crashtype."_Supplier",
															 "FormatOption"=> 'HEX');
				}
				my $rawEDID_String;
				if(ref $rawData eq 'ARRAY'){
					foreach my $data (@{$rawData}){
					$rawEDID_String=$rawEDID_String." ". $data;
					}
				}
				else {
					$rawEDID_String=$rawData;
				}
				S_teststep_expected("FILL MANUALLY for EDID $EDID, record nbr. $recordNbr", 'read_EDR_records');
				if(defined $edidData_hashref ->{'DataSamples'}){ # dynamic data
					my $DecodedEDID_String;
					my $edidData =$edidData_hashref -> {"DataSamples"};
					my ($EDID_timestamps, $EDID_data) = Transform_hash_to_array($edidData);
					foreach my $data (@{$EDID_data})
					{
						$DecodedEDID_String=$DecodedEDID_String." ". $data;
					}
					S_teststep_detected(" EDID $EDID, record nbr. $recordNbr (decoded): $DecodedEDID_String",'read_EDR_records');
					S_teststep_detected(" EDID $EDID, record nbr. $recordNbr (raw): $rawEDID_String",'read_EDR_records');
				}
				elsif (defined $edidData_hashref ->{'DataValue'}){ # static data
					my $dataValue = $edidData_hashref ->{'DataValue'};
					my $dataUnit = $edidData_hashref ->{'ValueUnit'};
					S_teststep_detected("EDID $EDID, record nbr. $recordNbr (decoded): $dataValue ($dataUnit)",'read_EDR_records');
					S_teststep_detected("EDID $EDID, record nbr. $recordNbr (raw): $rawEDID_String (hex)",'read_EDR_records');
				}
				else {
					S_teststep_detected("EDID $EDID not in record $recordNbr", 'read_EDR_records');
					next;
				}
			}
		}
	}
	else
	{
		S_teststep_detected("FILL MANUALLY", 'read_EDR_records');
	}
    return 1;
}

#-------------------------------------------------------------------------------
sub TC_finalization {
#-------------------------------------------------------------------------------

	S_user_action("Reset stimulation if required!!");

    # Reset current threshold to default value 0.5
    if($tcpar_FireCurrentThreshold){
        LC_MeasureTraceDigitalConfigureThresholds( ['ALL'], 0.5 );
    }

    S_w2log(1, "Delete all stored record objects as per execution option 'EDR_CrashInjection_DeleteRecordObjects'");
    $numberOfRecords = SYC_EDR_get_NumberOfEventsToBeStored();
    if(not defined $numberOfRecords){
        S_set_warning("Not available in SYC - add or overwrite with Custlibrary Function");
    }
    else{
        foreach my $recordNbr (1..$numberOfRecords)
        {
            $record_handler -> DeleteRecord("CrashLabel" => $tcpar_Crashtype, "RecordNumber" => $recordNbr);
            $record_handler -> DeleteRecord("CrashLabel" => $tcpar_Crashtype."_Supplier", "RecordNumber" => $recordNbr);
        }         
    }
	# Read fault memory after crash
    PD_ReadFaultMemory();
    S_wait_ms(2000);

	# Erase EDR
    PD_ClearCrashRecorder();
    S_wait_ms(2000);
	# Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(2000);
	# Reset ECU    
    PD_ECUreset();
    S_wait_ms('TIMER_ECU_READY');
	# Read fault memory after clearing and erasing EDR
    PD_ReadFaultMemory();
    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

	return 1;
}


1;