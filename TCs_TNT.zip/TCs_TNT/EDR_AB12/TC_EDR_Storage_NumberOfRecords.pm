#### TEST CASE MODULE
package TC_EDR_Storage_NumberOfRecords;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
#include further modules here
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_can_access;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use GENERIC_DCOM;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;
use Data::Dumper;

##################################

our $PURPOSE = "<This testscript checks that the correct number of records supported for project is stored>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_Storage_NumberOfRecords

=head1 PURPOSE

<This testscript checks that the correct number of records is stored>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Read <variable> to get current power on cycle

2. Follow steps 3 - 5 for <NumberOfEventsToBeStored>

3. Inject <crashtype>

4. Wait <wait_ms>

5. Reset ECU

6. Read all records


I<B<Evaluation>>

1. -

2. -

3. -

4. -

5. -

6. EDID ID <EDID> IgnitionCycle of record is as expected.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'variable' => 
	SCALAR 'crashtype' => 
	SCALAR 'NumberOfEventsToBeStored' => 
	SCALAR 'StorageOrder' => 
	SCALAR 'wait_ms' => 
	SCALAR 'EDID' => 
	SCALAR 'ExpectedNumberOfCT' => 


=head2 PARAMETER EXAMPLES

	purpose		 = 'check NumberOfEventsToBeStored'
	
	# ---------- Stimulation ------------ 
	variable = 'rb_tim_EcuOnTimeDataEe_st.POnCounter_u32'
	crashtype = 'Front_ND'
	
	#data from SYC
	#NumberOfEventsToBeStored = '<Fetch {V_RefType2_B_Sample}{([0-9])}>'
	NumberOfEventsToBeStored  = 2 
	StorageOrder = 'MostRecentFirst' # alternative: 'MostRecentLast'
	
	# general
	wait_ms = 10000 #ms
	
	# ---------- Evaluation ------------ 
	# ExpectedNumberOfCT = '<Fetch {V_RefType2_B_Sample}{([0-9])}>'
	EDID = 1001
	ExpectedNumberOfCT = 2		# same as NumberOfEventsToBeStored
	# Expected_IgnitionCycle_OldestCrash = "InitialPowerOn"
	# Expected_IgnitionCycle_MostRecentCrash = "InitialPowerOn + NumberOfEventsToBeStored"

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Crashcode;
my $tcpar_StorageOrder;
my $tcpar_EDID;
my $tcpar_DiagType;
my $tcpar_ResultDB;
my $tcpar_IgnitionCycle_LowByte;
my $tcpar_IgnitionCycle_HighByte;
my $tcpar_IgnitionCycle;
my $tcpar_COMsignalsAfterCrash;
my $faultsBeforeStimulation;
my $tcpar_read_NHTSAEDR;
my $tcpar_read_CHINAEDR;


################ global parameter declaration ###################
#add any global variables here
my ($record_handler, $crashSettings, $edrNumberOfEventsToBeStored,$ChinaEDR_diagType);
my @ignitionCycle;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_IgnitionCycle_LowByte =  S_read_optional_testcase_parameter( 'Variable_IgnitionCycle_LowByte' );
	if($tcpar_IgnitionCycle_LowByte){
		$tcpar_IgnitionCycle_HighByte =  S_read_mandatory_testcase_parameter( 'Variable_IgnitionCycle_HighByte' );
	}
	else {
		$tcpar_IgnitionCycle =  S_read_mandatory_testcase_parameter( 'Variable_IgnitionCycle' );	
	}
	$tcpar_Crashcode =  S_read_mandatory_testcase_parameter( 'crashtype' );
	$tcpar_ResultDB =  S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_DiagType =  S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_EDID =  S_read_mandatory_testcase_parameter( 'EDID' );
	$tcpar_COMsignalsAfterCrash =  S_read_optional_testcase_parameter( 'COMsignalsAfterCrash','byref');
	$tcpar_read_NHTSAEDR=S_read_optional_testcase_parameter('read_NHTSAEDR');
	$tcpar_read_CHINAEDR=S_read_optional_testcase_parameter('read_CHINAEDR');
	$edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();
	unless(defined $edrNumberOfEventsToBeStored){
		S_set_error("Not available in SYC - add or overwrite with Custlibrary Function");
        return;
    }
	if(not defined $tcpar_read_CHINAEDR) {
		$tcpar_read_NHTSAEDR = 'yes';
		$tcpar_read_CHINAEDR = 'no';
	}
	else {
		$tcpar_read_NHTSAEDR = 'no';
		my $storageOrder = EDR_getStorageOrder();
		return unless(defined $storageOrder);

		if($storageOrder eq 'PhysicalOrder'){
			$ChinaEDR_diagType= 'ProdDiag';  #In platform NHTSA and China EDR is read via proddiag
		}
		else {
			$ChinaEDR_diagType= 'CHINA_Payload';
		}
	}
	return 1;
}

sub TC_initialization {

	S_teststep("Test setup preparation", 'AUTO_NBR');

	#--------------------------------------------------------------
    # INITIALIZE RECORD AND CRASH HANDLER
    #    
	S_teststep_2nd_level("Initialize Record Handler", 'AUTO_NBR');
	$record_handler = EDR_init_RecordHandler() || return;

	#--------------------------------------------------------------
    # PREPARE CRASH AND INITIALIZE EQUIPMENT
    #
	S_teststep_2nd_level("Get crash settings for crash $tcpar_Crashcode", 'AUTO_NBR');
    my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode};
    # Crash settings
    $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
    unless(defined $crashSettings) {
        S_set_error("Crash $tcpar_Crashcode not available in result DB $tcpar_ResultDB. Test case aborted.");
        return;
    }

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2rep("Crashcode: $tcpar_Crashcode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");

	S_teststep_2nd_level("Power on ECU", 'AUTO_NBR');
    LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

    S_w2log(1, "Initialize CD and start CAN trace");
    GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start ( );

	S_teststep_2nd_level("Set environments for crash as per result DB", 'AUTO_NBR');
    CSI_PrepareEnvironment($crashSettings, 'init_complete');
    S_wait_ms(2000);

	S_teststep_2nd_level("Clear crash recorder", 'AUTO_NBR');
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(2000);

	S_teststep_2nd_level("Clear fault memory", 'AUTO_NBR');
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	S_teststep_2nd_level("Read fault memory before stimulation", 'AUTO_NBR', 'fault_memory_before_stimulation');
    $faultsBeforeStimulation = PD_ReadFaultMemory();
    my $faultsVerdict = PD_evaluate_faults( $faultsBeforeStimulation, []);
    return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Inject $tcpar_Crashcode $edrNumberOfEventsToBeStored times", 'AUTO_NBR');

	foreach my $crashCount (1..$edrNumberOfEventsToBeStored)
	{		

        S_teststep_2nd_level("Reset ECU and prepare crash while ECU is off", 'AUTO_NBR');
        LC_ECU_Off();
        S_wait_ms('TIMER_ECU_OFF');

        CSI_LoadCrashSensorData2Simulator($crashSettings);

        LC_ECU_On();
        S_wait_ms('TIMER_ECU_READY');

		#--------------------------------------------------------------
		# READ IGNITION CYCLE
		#
		my $ignitionCycle;
		if(defined $tcpar_IgnitionCycle){
			S_teststep_2nd_level("Read '$tcpar_IgnitionCycle' to get current power on cycle", 'AUTO_NBR', "IgnitionCycle_Crash_$crashCount");
			$ignitionCycle = S_aref2dec(PD_ReadMemoryByName($tcpar_IgnitionCycle), U32);
			return unless($ignitionCycle);		
		}
		else {
			S_teststep_2nd_level("Read '$tcpar_IgnitionCycle_LowByte','$tcpar_IgnitionCycle_HighByte' to get current power on cycle", 'AUTO_NBR', "IgnitionCycle_Crash_$crashCount");
			my	$ignitionCycleBeforeCrash1 = S_aref2hex(PD_ReadMemoryByName($tcpar_IgnitionCycle_LowByte));
			return unless($ignitionCycleBeforeCrash1);
			my  $ignitionCycleBeforeCrash2 = S_aref2hex(PD_ReadMemoryByName($tcpar_IgnitionCycle_HighByte));
			return unless($ignitionCycleBeforeCrash2);

			$ignitionCycle =$ignitionCycleBeforeCrash2.$ignitionCycleBeforeCrash1;
			$ignitionCycle=~ m/0x(.*)0x(.*)/;			#concatenated and removed 0x
			$ignitionCycle = '0x'.$1.$2;			
			$ignitionCycle = S_0x2dec ( $ignitionCycle );  
		}
		S_w2rep("Ignition cycle for crash count $crashCount =  $ignitionCycle ");		
		push (@ignitionCycle, $ignitionCycle);
		
		CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    	S_wait_ms(1000);
		
		#--------------------------------------------------------------
		# CRASH INJECTION
		#		
		S_teststep_2nd_level("Trigger crash", 'AUTO_NBR');
        CSI_TriggerCrash();
		S_wait_ms(10000);	
    }

	if (defined $tcpar_COMsignalsAfterCrash){
		foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
		{				
			my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
			S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
			COM_setSignalState($signal,$dataOnCOM);	
		}

	}

	S_teststep("Read all $edrNumberOfEventsToBeStored EDR records", 'AUTO_NBR', 'read_all_records');
	my $dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_".$tcpar_Crashcode;

	PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');

	if ( lc( $tcpar_read_NHTSAEDR) eq 'yes' ) {
		EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
								"CrashLabel" => $tcpar_Crashcode,
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								"read_EDRType"=>'NHTSA')
	}
	if (lc($tcpar_read_CHINAEDR) eq 'yes'){
		$edrNumberOfEventsToBeStored=3;
		EDR_ReadAndStoreAllRecords ("DiagType" =>  $ChinaEDR_diagType,
								"CrashLabel" => $tcpar_Crashcode,
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								"read_EDRType"=>'CHINA');
	
	}	
	return 1;
}

sub TC_evaluation {

	#--------------------------------------------------------------
    # FAULTS BEFORE STIMULATION
    #
	S_teststep_expected("Empty fault memory: []", 'fault_memory_before_stimulation');
	PD_evaluate_faults( $faultsBeforeStimulation, []);
	my @detectedFaults = @{$faultsBeforeStimulation -> {"fault_text"}};
	unless(@detectedFaults){
		push(@detectedFaults, "[]");
	}
	S_teststep_detected(@detectedFaults, 'fault_memory_before_stimulation');
	
	#--------------------------------------------------------------
    # NUMBER OF EXPECTED RECORDS
    #
	S_w2rep("");
	S_w2rep("--------------------------------------------------------", 'purple');
	S_w2rep("NUMBER OF EXPECTED RECORDS", 'purple');
	S_teststep_expected("Expect $edrNumberOfEventsToBeStored records to be stored", 'read_all_records'); #evaluation 1

	my $detectedNbrOfStoredRecords = 0;
	for(my $recordNumber = 1; $recordNumber <= $edrNumberOfEventsToBeStored; $recordNumber++)
	{
		my $recordAvailable = $record_handler -> IsRecordAvailable("CrashLabel" => $tcpar_Crashcode, "RecordNumber"=> $recordNumber);
		$detectedNbrOfStoredRecords++ if ($recordAvailable);
	}
	my $verdict= EVAL_evaluate_value("NumberOfRecords", $detectedNbrOfStoredRecords,'==', $edrNumberOfEventsToBeStored);
	S_teststep_detected("Number of stored records is $detectedNbrOfStoredRecords", 'read_all_records');
	unless ($verdict eq "VERDICT_PASS"){
		S_w2rep("Number of detected records is incorrect, no further EDID validation is done");
		return 1;
	}
	
	#--------------------------------------------------------------
    # IGNITION CYCLE VALUE
    #
	my $storageOrder = EDR_getStorageOrder(); # to differ between 'MostRecentFirst' and 'MostRecentLast'
    return unless(defined $storageOrder);

    if($storageOrder eq 'PhysicalOrder'){
       $storageOrder =  'MostRecentLast'; #same behavior as there is no overwriting
    }

	my $dataElement = $record_handler -> GetDataElementEDID( "EDIDnr" => $tcpar_EDID,
														     "RecordNumber" => 1,
														     "CrashLabel" => $tcpar_Crashcode);

	foreach my $recordNumber (1..$edrNumberOfEventsToBeStored)
	{
		S_teststep("Read EDID $tcpar_EDID ($dataElement) in record $recordNumber",
					'AUTO_NBR',
					"Read_EDID_record_$recordNumber");						
	
		my $expectedIgnitionCycle;
		$expectedIgnitionCycle = $ignitionCycle[$edrNumberOfEventsToBeStored - $recordNumber] if ( $storageOrder  eq 'MostRecentFirst');
		$expectedIgnitionCycle = $ignitionCycle[$recordNumber -1] if ( $storageOrder  eq 'MostRecentLast');

		S_teststep_expected("$expectedIgnitionCycle ", "Read_EDID_record_$recordNumber");
		
		my $edidData = $record_handler -> GetDecodedEDID("CrashLabel" => $tcpar_Crashcode,
														 "RecordNumber" => $recordNumber,
														 "EDIDnr" => $tcpar_EDID );
		my $detectedIgnitionCycle = $edidData -> {"DataValue"};
		my $unit = $edidData -> {"ValueUnit"};
		 
		unless(defined $detectedIgnitionCycle) {
			S_set_error("No data could be obtained for EDID $tcpar_EDID in record $recordNumber.");
			next;
		}
					
		EVAL_evaluate_value ( "EDID_$tcpar_EDID\_Evaluation", $detectedIgnitionCycle,'==', $expectedIgnitionCycle );
	
		S_teststep_detected("$detectedIgnitionCycle", "Read_EDID_record_$recordNumber");
		
	}

	return 1;
}

sub TC_finalization {

	S_w2rep("Clear EDR");
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(5000);

	S_w2rep("Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);    #PD is unstable, added additional delay.

	# Read fault memory after clearing and erasing EDR
	S_w2rep("Read fault memory");
    PD_ReadFaultMemory();   

	S_w2rep("Switch off ECU");
    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

	S_w2rep("Delete records from record handler");
    foreach my $recordNbr (1..$edrNumberOfEventsToBeStored)
    {
    	$record_handler -> DeleteRecord("CrashLabel" => $tcpar_Crashcode, "RecordNumber" => $recordNbr);
    }

	return 1;
}


1;
