#### TEST CASE MODULE
package TC_EDR_DiagnosticInterfaceEraseEDR;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
#include further modules here
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use GENERIC_DCOM;
use LIFT_can_access;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;
use Data::Dumper;

##################################

our $PURPOSE = "<This testscript tests erasure of EDR via CD";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_DiagnosticInterfaceEraseEDR

=head1 PURPOSE

<This testscript tests erasure of EDR via CD>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Inject <crashcode>.

2. Power down ECU

3. Wait <wait_ms>

4. Power up ECU

5. Wait <wait_ms>

6. Read EDR record 

7. Call <diag_service> to erase EDR 

8. Read EDR record 


I<B<Evaluation>>

1. -

2. -

3. -

4. -

5. 

6. EDR data is reported <NbrOfRecordsExpected_BeforeErase>

7

8 EDR data is reported <NbrOfRecordsExpected_AfterErase>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'crashcode' => 
	SCALAR 'DiagType' => 
	SCALAR 'wait_ms' => 
	SCALAR 'ResultDB' => 
	SCALAR 'diag_service' => 
	SCALAR 'NbrOfRecordsExpected_BeforeErase' => 
	SCALAR 'NbrOfRecordsExpected_AfterErase' => 


=head2 PARAMETER EXAMPLES

	purpose		 = 'check whether the diagnostic service  '<Test Heading Head>' erases EDR'
	
	# ---------- Stimulation ------------ 
	crashcode = 'Single_EDR_Front_Inflatable'
	DiagType = 'ProdDiag'
	
	wait_ms = 5000 #ms
	ResultDB='EDR'
	
	diag_service = '<Test Heading Head>'
	
	# ---------- Evaluation ------------ 
	NbrOfRecordsExpected_BeforeErase='1'
	NbrOfRecordsExpected_AfterErase='0'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Crashcode;
my $tcpar_DiagType;
my $tcpar_wait_ms;
my $tcpar_ResultDB;
my $tcpar_diag_service;
my $tcpar_NbrOfRecordsExpected_BeforeErase;
my $tcpar_NbrOfRecordsExpected_AfterErase;
my $faultsBeforeStimulation,;
my $tcpar_COMsignalsAfterCrash ;

################ global parameter declaration ###################
#add any global variables here
my ($record_handler, $crashSettings, $edrNumberOfEventsToBeStored);

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_Crashcode =  S_read_mandatory_testcase_parameter( 'crashcode' );
	$tcpar_DiagType =  S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_wait_ms =  S_read_mandatory_testcase_parameter( 'wait_ms' );
	$tcpar_ResultDB =  S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_diag_service =  S_read_mandatory_testcase_parameter( 'diag_service' );
	$tcpar_NbrOfRecordsExpected_BeforeErase =  S_read_mandatory_testcase_parameter( 'NbrOfRecordsExpected_BeforeErase' );
	$tcpar_NbrOfRecordsExpected_AfterErase =  S_read_mandatory_testcase_parameter( 'NbrOfRecordsExpected_AfterErase' );
	$tcpar_COMsignalsAfterCrash =  S_read_optional_testcase_parameter( 'COMsignalsAfterCrash','byref');

	return 1;
}

sub TC_initialization {

	S_teststep("Test setup preparation", 'AUTO_NBR');

	#--------------------------------------------------------------
    # INITIALIZE RECORD HANDLER
    #    
	S_w2rep("Initialize Record Handler");
	$record_handler = EDR_init_RecordHandler() || return;

	#--------------------------------------------------------------
    # PREPARE CRASH AND INITIALIZE EQUIPMENT
    #
	S_w2rep("Get crash settings for crash $tcpar_Crashcode");
    my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode};
    $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
    unless(defined $crashSettings) {
        S_set_error("Crash $tcpar_Crashcode not available in result DB $tcpar_ResultDB. Test case aborted.");
        return;
    }

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log(1, "Crashcode: $tcpar_Crashcode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");

	S_w2log(1, "Power on ECU");
    LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

    S_w2log(1, "Initialize CD and start CAN trace");
    GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start ( );

	S_w2log(1, "Set environments for crash as per result DB");
    CSI_PrepareEnvironment($crashSettings, 'init_complete');

	S_w2log(1, "Clear crash recorder");
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(2000);

	S_w2log(1, "Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	S_w2log(1, "Read and evaluate fault memory before stimulation");
    $faultsBeforeStimulation = PD_ReadFaultMemory();

    #Fault memory must be empty
    my $faultsVerdict = PD_evaluate_faults( $faultsBeforeStimulation, []);
    return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

	return 1;
}

sub TC_stimulation_and_measurement {

	
	#--------------------------------------------------------------
    # CRASH PREPARATION
    #
	
    # Prepare crash
    S_teststep("Prepare crash", 'AUTO_NBR');
    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

    # Prepare crash
    CSI_LoadCrashSensorData2Simulator($crashSettings);

    # Power ON the ECU
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');
    
    CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    S_wait_ms(1000);

	#--------------------------------------------------------------
	# CRASH INJECTION
	#
	S_teststep("Inject '$tcpar_Crashcode' ", 'AUTO_NBR');	
	CSI_TriggerCrash();
	S_teststep("Wait '$tcpar_wait_ms'", 'AUTO_NBR');
	S_wait_ms($tcpar_wait_ms);

    if (defined $tcpar_COMsignalsAfterCrash){
        S_teststep("Send post crash COM signals", 'AUTO_NBR');
        foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
        {               
            my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
            S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
            COM_setSignalState($signal,$dataOnCOM); 
        }

    }

	S_teststep("Read EDR record after crash injection", 'AUTO_NBR', 'read_edr_record_A');			#measurement 1
	my $dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_$tcpar_Crashcode\_BeforeErase";

	$edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();
	unless(defined $edrNumberOfEventsToBeStored){
        S_set_error("Not available in SYC - add or overwrite with Custlibrary Function");
        return;
    }

    PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');
	EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
							 	"CrashLabel" => "$tcpar_Crashcode\_BeforeErase",
							 	"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
							 	"StoragePath" => $dataStoragePath,
							 	);
														

	S_wait_ms(5000);
	
	S_teststep("Call '$tcpar_diag_service' customer diagnostic service to erase EDR ", 'AUTO_NBR');

	if($tcpar_DiagType eq 'ProdDiag') {
		PD_ClearCrashRecorder();
	}
	else {
		EDR_CD_EraseEDR();		
	}
	
	S_wait_ms(7000);

	S_teststep("Reset ECU", 'AUTO_NBR');
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	LC_ECU_On();

	S_wait_ms('TIMER_ECU_READY');	
	
	S_teststep("Read EDR record after erasing", 'AUTO_NBR', 'read_edr_record_B');			#measurement 2
	$dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_$tcpar_Crashcode\_AfterErase";
    PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');
	EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
							 	"CrashLabel" => "$tcpar_Crashcode\_AfterErase",
							 	"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
							 	"StoragePath" => $dataStoragePath,
							 	);
								
							
	return 1;
}

sub TC_evaluation {
	
	#--------------------------------------------------------------
    # NUMBER OF EXPECTED RECORDS BEFORE ERASE
    #
	my $detectedNbrOfStoredRecords_BeforeErase = 0;
	my $detectedNbrOfStoredRecords_AfterErase = 0;
	for(my $recordNumber = 1; $recordNumber <= $edrNumberOfEventsToBeStored; $recordNumber++)
	{
		my $recordAvailableBefore = $record_handler -> IsRecordAvailable("CrashLabel" => "$tcpar_Crashcode\_BeforeErase", "RecordNumber"=> $recordNumber);
		$detectedNbrOfStoredRecords_BeforeErase++ if ($recordAvailableBefore);

		my $recordAvailableAfter = $record_handler -> IsRecordAvailable("CrashLabel" => "$tcpar_Crashcode\_AfterErase", "RecordNumber"=> $recordNumber);
		$detectedNbrOfStoredRecords_AfterErase++ if ($recordAvailableAfter);
	}

	S_teststep_expected("Expect $tcpar_NbrOfRecordsExpected_BeforeErase records to be stored before EDR erasure", 'read_edr_record_A'); #evaluation 1
	EVAL_evaluate_value("NumberOfRecords_BeforeErase", $detectedNbrOfStoredRecords_BeforeErase,'==', $tcpar_NbrOfRecordsExpected_BeforeErase);
	S_teststep_detected("Number of stored records is $detectedNbrOfStoredRecords_BeforeErase before EDR erasure", 'read_edr_record_A');
	
	S_teststep_expected("Expect $tcpar_NbrOfRecordsExpected_AfterErase records to be stored after EDR erasure", 'read_edr_record_B'); #evaluation 2
	EVAL_evaluate_value("NumberOfRecords_AfterErase", $detectedNbrOfStoredRecords_AfterErase,'==', $tcpar_NbrOfRecordsExpected_AfterErase);
	S_teststep_detected("Number of stored records is $detectedNbrOfStoredRecords_AfterErase after EDR erasure" , 'read_edr_record_B');
	

	return 1;
}

sub TC_finalization {

	# Erase EDR
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(2000);

	# Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(10000);  #PD is unstable, hence added additional delay.
	
	S_w2rep("Clean up record handler");
    $record_handler -> DeleteAllRecords();

	# Read fault memory after clearing and erasing EDR
    PD_ReadFaultMemory();   

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

	return 1;
}


1;
