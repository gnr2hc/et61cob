#### TEST CASE MODULE
package TC_EDR_ReportFaultsBeforeCrash;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
#include further modules here
use INCLUDES_Project;
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_can_access;
use LIFT_MDSRESULT;
use LIFT_FaultMemory;
use GENERIC_DCOM;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;
use Data::Dumper;

##################################

our $PURPOSE = "<To Check that faults that occur before the crash are reported in the crash record.>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_ReportFaultsBeforeCrash

=head1 PURPOSE

<Check that faults that occur before the crash are reported in the crash record.>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFaultNoCT


I<B<Stimulation and Measurement>>

1. Power up ECU

2. Stimulate fault <fault>

3. Wait <wait_ms>

4. Read fault memory

5. Inject <crashtype>

6. Power down ECU

7. Power up ECU

8. Read EDR


I<B<Evaluation>>

1. - 

2. - 

3. -

4. Stimulated fault <fault> shall appear

5. -

6. -

7. - 

8. Check EDID <EDID> for matching faults.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => purpose of test case

    SCALAR 'Crashcode' => crash to be injected (crash code must be present in given result DB)
    SCALAR 'ResultDB' => label for result DB defined in CREIS project const
    SCALAR 'DiagType' => diag type which will be used for reading and parsing EDR data
    SCALAR 'wait_ms_fault' => wait time for fault qualification / dequalification
    SCALAR 'wait_ms_crash' => wait time for storage of crash after triggering crash
    HASH 'EDID' => ID of the data element that reports fault memory

    SCALAR 'DeviceType' => any device type that can be handled by FuncLib_TNT_FM for fault creation OR 'NoFault' OR 'MaximumFaults'
	SCALAR 'Device' => device to manipulate
	SCALAR 'Condition' => fault condition in which device should be set, e.g. open line
    SCALAR 'FaultState' => if not given: Qualified, otherwise 'Dequalified' or 'DequalifiedAndReset'
    SCALAR 'expected_number_of_CT' => number of expected records, dependant on crash type - default is 1
    HASH 'COMsignalsAfterCrash' => Set of CAN signals which have to be set after crash, e.g. speed to 0
    SCALAR 'FaultID_Type' => can be 'BoschFaultNumber' or 'DTC' - default is 'DTC'
    SCALAR 'NbrOfBytes_FaultID' => number of bytes of fault ID (default 3 for FaultID_Type DTC and 2 for BoschFaultNumber)
    SCALAR 'NbrOfBytes_FaultStatus' => number of bytes of fault status (default 1)
	SCALAR 'AdditionalFaults'=>Any optional faults that get qualified during creation of 'fault under test'


=head2 PARAMETER EXAMPLES

	purpose = 'Check that faults ('<Test Heading Head>') that occur before the crash (<Test Heading Tail>) are reported in the crash record.' 
	
	   # Mandatory Parameters
	Crashcode = 'Single_Front_Inflatable;5'
    ResultDB = 'EDR'
	DiagType = 'ProdDiag' # 'AKLV', 'Nissan',...
	wait_ms_fault = 5000
	wait_ms_crash = 10000
    EDID = 987

        # Optional parameters
	DeviceType = 'Switch'
	Device = 'BLFD'
	Condition = 'OpenLine'
	FaultState = 'Dequalified'
	expected_number_of_CT = 2
	COMsignalsAfterCrash = %('VehicleSpeed_Dashboard' => 0)
	FaultID_Type = 'BoschFaultNumber'
	NbrOfBytes_FaultID = 2
	NbrOfBytes_FaultStatus = 1
	AdditionalFaults=@('rb_psem_Short2GndPASMD_flt','rb_psem_Short2GndPPSFD_flt')


=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_DeviceType;
my $tcpar_Device;
my $tcpar_Condition;
my $tcpar_wait_ms_Crash;
my $tcpar_EDID;
my $tcpar_OptionalFault;
my $tcpar_wait_ms_Fault;
my $tcpar_Crashcode;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_DiagType;
my $tcpar_ResultDB;
my $tcpar_FaultState;
my $tcpar_expected_number_of_CT;
my $tcpar_FaultID_type;
my $tcpar_NbrOfBytesInFaultID;
my $tcpar_NbrOfBytesFaultStatus;
my $tcpar_AdditionalFaults_aref;

################ global parameter declaration ###################
#add any global variables here
my ($fltname,$FaultInfo,$tcpar_faultstatus,$device_list);
my $faultsAfterStimulation;
my $faultsAfterStimulation_Bosch;
my $faultsAfterStimulation_Incident2;
my $max_Faults_created;
my (@SquibFaultNames,@SwitchFaultNames,@FaultsCreated);
my ($record_handler, $crashSettings, $edrNumberOfEventsToBeStored,$faultsAfterLastCrashInjection);

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_Crashcode =  S_read_mandatory_testcase_parameter( 'Crashcode' );
	$tcpar_DiagType =  S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_ResultDB =  S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_DeviceType =  S_read_optional_testcase_parameter( 'DeviceType' );
	$tcpar_wait_ms_Fault =  S_read_mandatory_testcase_parameter( 'wait_ms_fault' );
	$tcpar_wait_ms_Crash =  S_read_mandatory_testcase_parameter( 'wait_ms_crash' );
	$tcpar_Device =  S_read_optional_testcase_parameter( 'Device' );
	$tcpar_Condition =  S_read_optional_testcase_parameter( 'Condition' );
	$tcpar_EDID =  S_read_mandatory_testcase_parameter( 'EDID' );
	$tcpar_AdditionalFaults_aref =  S_read_optional_testcase_parameter( 'AdditionalFaults','byref' );
	$tcpar_FaultState =  S_read_optional_testcase_parameter( 'FaultState' );
	$tcpar_FaultState = 'Qualified' unless(defined $tcpar_FaultState);
    if($tcpar_FaultState ne 'Qualified' and $tcpar_FaultState ne 'Dequalified' and $tcpar_FaultState ne 'DequalifiedAndReset'){
        S_set_error("Parameter 'FaultState' must be either 'Qualified' or 'Dequalified' or 'DequalifiedAndReset' (given: '$tcpar_FaultState')");
        return;
    }
	$tcpar_expected_number_of_CT =  S_read_optional_testcase_parameter( 'expected_number_of_CT' );
	unless(defined $tcpar_expected_number_of_CT){
	    S_w2rep("Expect 1 record for single or parallel event scenario");
	    $tcpar_expected_number_of_CT = 1;
	}
	$tcpar_COMsignalsAfterCrash =  S_read_optional_testcase_parameter( 'COMsignalsAfterCrash','byref');
	$tcpar_FaultID_type =  S_read_optional_testcase_parameter( 'FaultID_Type');
	$tcpar_FaultID_type = 'DTC' unless(defined $tcpar_FaultID_type);
	if($tcpar_FaultID_type ne 'DTC' and $tcpar_FaultID_type ne 'BoschFaultNumber'){
		S_set_error("Parameter 'FaultID_Type' must be either 'DTC' or 'BoschFaultNumber' (given: '$tcpar_FaultID_type')");
		return;
	}

	$tcpar_NbrOfBytesInFaultID =  S_read_optional_testcase_parameter( 'NbrOfBytes_FaultID');
	$tcpar_NbrOfBytesInFaultID = 3 if(not defined $tcpar_NbrOfBytesInFaultID and $tcpar_FaultID_type eq 'DTC');
	$tcpar_NbrOfBytesInFaultID = 2 if(not defined $tcpar_NbrOfBytesInFaultID and $tcpar_FaultID_type eq 'BoschFaultNumber');

	$tcpar_NbrOfBytesFaultStatus =  S_read_optional_testcase_parameter( 'NbrOfBytes_FaultStatus');
	$tcpar_NbrOfBytesFaultStatus = 1 unless(defined $tcpar_NbrOfBytesFaultStatus);
	
	S_w2log(1, "Fault layout in EDR: 
							Fault ID type - '$tcpar_FaultID_type'
							Number of bytes fault ID - '$tcpar_NbrOfBytesInFaultID'
							Number of bytes fault status - '$tcpar_NbrOfBytesFaultStatus'");

	return 1;
}

sub TC_initialization {

	S_teststep("Test setup preparation", 'AUTO_NBR');

	#--------------------------------------------------------------
    # INITIALIZE RECORD AND CRASH HANDLER
    #    
	S_w2rep("Initialize Record Handler");
	$record_handler = EDR_init_RecordHandler() || return;

	#--------------------------------------------------------------
    # PREPARE CRASH AND INITIALIZE EQUIPMENT
    #
	S_w2rep("Get crash settings for crash $tcpar_Crashcode");
    my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode};
    $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
    unless(defined $crashSettings) {
        S_set_error("Crash $tcpar_Crashcode not available in result DB $tcpar_ResultDB. Test case aborted.");
        return;
    }

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log(1, "Crashcode: $tcpar_Crashcode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");

	S_w2log(1, "Power on ECU");
    LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

    S_w2log(1, "Initialize CD and start CAN trace");
    GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start ( );
    
    # Set environment settings for crash
    CSI_PrepareEnvironment($crashSettings, 'init_complete');
    S_wait_ms(2000);

	S_w2log(1, "Clear crash recorder");
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(2000);

	S_w2log(1, "Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);

    # read fault memory
    my $faultsBeforeStimulation = LIFT_FaultMemory -> read_fault_memory('Bosch');

    #Fault memory must be empty
    my $faultsVerdict = $faultsBeforeStimulation -> evaluate_faults({});
    S_w2rep("Faults verdict: $faultsVerdict");
    return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

	return 1;
}

sub TC_stimulation_and_measurement {

    #--------------------------------------------------------------
    # CRASH PREPARATION
    #

    # Prepare crash
    S_teststep("Prepare crash", 'AUTO_NBR');
    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

    # Prepare crash
    CSI_LoadCrashSensorData2Simulator($crashSettings);

    # Power ON the ECU
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

    CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    S_wait_ms(1000);

    #--------------------------------------------------------------
    # FAULT STIMULATION
    #
	my $Device_count=0;
	my @Devices_Shorted;
	
	if (defined $tcpar_Condition){  # Specific fault condition is defined and will be set
	   
		my $MySearch->{'DeviceType'} = $tcpar_DeviceType;
		$MySearch->{'Device'} = $tcpar_Device;
		$MySearch->{'Condition'} = $tcpar_Condition;
		my $fltnames = FM_fetchFaultName($MySearch);
		$fltname = @$fltnames[0];

		S_teststep("Stimulate fault '$tcpar_Condition' for $tcpar_DeviceType '$tcpar_Device' ", 'AUTO_NBR');
		FM_createFault($fltname);
		push(@FaultsCreated, $fltname);
		S_wait_ms($tcpar_wait_ms_Fault);
		S_w2rep( "Number of faults created : 1",'RED');
 
        # Set fault state to dequalified or dequalified and reset unless fault state given is 'Qualified'
        if ($tcpar_FaultState eq "Dequalified"){
            S_teststep_2nd_level("Reset '$tcpar_Condition' for $tcpar_DeviceType '$tcpar_Device'", 'AUTO_NBR');
            FM_removeFault($fltname);
            S_wait_ms($tcpar_wait_ms_Fault);
        }
        if ($tcpar_FaultState eq "DequalifiedAndReset"){
            S_teststep_2nd_level("Reset '$tcpar_Condition' for $tcpar_DeviceType '$tcpar_Device'", 'AUTO_NBR');
            FM_removeFault($fltname);
            S_wait_ms($tcpar_wait_ms_Fault);
            S_teststep_2nd_level("Reset ECU", 'AUTO_NBR');
            LC_ECU_Off();
            S_wait_ms('TIMER_ECU_OFF');
            LC_ECU_On();
            S_wait_ms('TIMER_ECU_READY');
        }
    }

	elsif($tcpar_DeviceType eq 'MaximumFaults'){ # No fault condition defined, set max number of faults
        $max_Faults_created  = SYC_FLT_get_DemMaxNumberEventEntryPrimary( );
        S_w2rep("Maximum number of faults: $max_Faults_created");
	
		my $SquibDetails_href = S_get_contents_of_hash(['TSG4', 'SQUIBS']);	
		my @SquibKeys = grep(/_Name$/, keys %{$SquibDetails_href});
		my	$Squib_count= scalar(@SquibKeys);
		
		my $beltLockDetails_href = S_get_contents_of_hash(['TSG4', 'BELT_LOCKS']);	
		my @beltLockKeys = grep(/_Name$/, keys %{$beltLockDetails_href});
		my	$Switch_count= scalar(@beltLockKeys);
		
		my $Total_device_count=$Squib_count+$Switch_count;  # should be greater than max no of faults to be created.
		
		if ($Total_device_count >= $max_Faults_created)
		{
			S_teststep("Stimulate maximum number of faults ($max_Faults_created faults)", 'AUTO_NBR');
            
            # Part 1: Set all squibs to faulty
			foreach my $Squib (@SquibKeys)
			{
                # get squib name
				$Squib =~ m/SQ(.*)_Name/;	# get number of Squib, will be stored in $1
				my $SquibNumber = $1;
				my $SquibName = $SquibDetails_href -> {"SQ$SquibNumber\_Name"};

                S_w2log(1, "Set squib '$SquibName' to Openline");
				my $MySearch->{'DeviceType'} = 'Squib';
				$MySearch->{'Device'} = $SquibName;
				$MySearch->{'Condition'} = 'Openline';
				my $fltnames = FM_fetchFaultName_NOERROR($MySearch);
				next unless($fltnames);
				$fltname = @$fltnames[0];
				FM_createFault($fltname);
				push(@FaultsCreated, $fltname);
				$Device_count++; # count up number of faulty devices
				
				if ($Device_count == $max_Faults_created){
					S_w2rep("Maximum number of faults is created");
					last;
				}
				
			}
			
            # Part 2: If maximum number of faults is greater than number of squibs, continue by setting switches faulty
			if ($Device_count < $max_Faults_created){
		
				foreach my $beltLock (@beltLockKeys)
				{
					
					# get switch name
					$beltLock =~ m/BL(.*)_Name/;	# get number of beltlock, will be stored in $1
					my $beltLockNumber = $1;
					my $beltLockName = $beltLockDetails_href -> {"BL$beltLockNumber\_Name"};

					my $MySearch->{'DeviceType'} = 'Switch';
					$MySearch->{'Device'} = $beltLockName;
					my $switchtype = DEVICE_fetchSwitchType_NOERROR ($beltLockName);
					next unless($switchtype);
					if ($switchtype eq 'mech'){
                        S_w2log(1, "Skip mechanical switch $beltLockName for fault creation");
					    next;
					}
					else{
						$MySearch->{'Condition'} = 'Openline';
						my $fltnames = FM_fetchFaultName_NOERROR($MySearch);
						next unless($fltnames);
                        S_w2log(1, "Set switch '$beltLockName' to Openline");
						$fltname = @$fltnames[0];
						FM_createFault($fltname);
					}

                    $Device_count++; # count up number of faulty devices
                    S_w2log(2, "$Device_count of $max_Faults_created faults created");
                    push(@FaultsCreated, $fltname);

					if ($Device_count == $max_Faults_created){
						S_w2rep("Maximum number of faults is created");
						last;
					}				
				}
			}

			S_wait_ms($tcpar_wait_ms_Fault);
			
			S_w2rep( "Number of faults created: $Device_count",'RED');
		}
		
	    else{
			S_set_error(" Total number of squib and switch faults i.e $Total_device_count is less than maximum number of faults to be created.\n".
			 "Hence test script needs to be modified to create max faults as per your project.\n".
			 "(Hint: You may add COM faults, warning lamp faults)", 20);
			return undef;
		}

    }
    elsif($tcpar_DeviceType eq 'NoFault'){ # No fault condition defined, set max number of faults
            S_teststep("Keep system fault free", 'AUTO_NBR');
    }
    else {
        S_set_error("No fault condition given and device type is not 'NoFault' or 'MaximumFaults'");
    }

	S_wait_ms($tcpar_wait_ms_Fault);
	S_teststep("Read primary and Bosch fault memory", 'AUTO_NBR', 'read_fault_memory');			#measurement 1
	$faultsAfterStimulation = LIFT_FaultMemory -> read_fault_memory('Primary'); #Primary
	$faultsAfterStimulation_Bosch = LIFT_FaultMemory -> read_fault_memory('Bosch'); #BOSCH_FLT_MEM

	#--------------------------------------------------------------
    # CRASH INJECTION
    #
	S_teststep("Inject '$tcpar_Crashcode'", 'AUTO_NBR');
	CSI_TriggerCrash();
	if ($tcpar_expected_number_of_CT > 1){  #only defined for multi events
        S_teststep("Wait for 1000 ms and read fault memory before second crash", 'AUTO_NBR');
		S_wait_ms(1000);
        $faultsAfterStimulation_Incident2 = LIFT_FaultMemory -> read_fault_memory('Primary'); #BOSCH_FLT_MEM
	}

	S_teststep("Wait '$tcpar_wait_ms_Crash'", 'AUTO_NBR');
	S_wait_ms($tcpar_wait_ms_Crash);

	if (defined $tcpar_COMsignalsAfterCrash){
		foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
		{				
			my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
			S_w2rep("Signal =$signal, Data to be sent=$dataOnCOM");
			COM_setSignalState($signal, $dataOnCOM);	
		}
	}

	S_wait_ms(2000);

	S_teststep("Read EDR", 'AUTO_NBR', 'read_edr'); # measurement 2
	my $dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_".$tcpar_Crashcode;

	$edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();

	unless(defined $edrNumberOfEventsToBeStored){
        S_set_error("Not available in SYC - add or overwrite with Custlibrary Function");
        return;
    }

	PD_ECUlogin() if ($tcpar_DiagType eq 'ProdDiag');
	EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
							 	"CrashLabel" => $tcpar_Crashcode,
							 	"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
							 	"StoragePath" => $dataStoragePath,
							 	);

	return 1;
}

sub TC_evaluation {

    # Part 1: Validate that all stimulated faults are stored with correct status in fault memory
	
	# Collect expected fault status for each fault that is expected to be stored
    my $faultStatusExpected_href = {};
    S_w2rep("Evaluate that all faults are stored in state: $tcpar_FaultState");
	foreach my $faultname (@FaultsCreated)
	{
		if ( $tcpar_FaultState eq 'Dequalified'){
			$faultStatusExpected_href -> {'mandatory'} -> {$faultname} = {
			    'DecodedStatus' => {'TestFailed' => 0, 'TestFailedThisOperationCycle' => 1},
			};
		}
        elsif ($tcpar_FaultState eq 'DequalifiedAndReset'){
            $faultStatusExpected_href -> {'mandatory'} -> {$faultname} = {
                'DecodedStatus' => {'TestFailed' => 0, 'TestFailedThisOperationCycle' => 0},
            };
        }
		else{
            $faultStatusExpected_href -> {'mandatory'} -> {$faultname} = {
                'DecodedStatus' => {'TestFailed' => 1, 'TestFailedThisOperationCycle' => 1}
            };
		}
	}
	
	$faultStatusExpected_href -> {'optional'} = $tcpar_AdditionalFaults_aref if (defined $tcpar_AdditionalFaults_aref) ;
	
	# evaluate faults eval keyword "read_fault_memory_$faultname"
    $faultsAfterStimulation -> evaluate_faults( $faultStatusExpected_href, "read_fault_memory" );


    # Part 2: Validate fault status in EDR															 

    # get expected faults per record
    my $expectedFaultsPerRecord_href;
    if($tcpar_expected_number_of_CT == 1){
        $expectedFaultsPerRecord_href -> {"Record_1"} = $faultsAfterStimulation;
    }
    else {
        my $storageOrder = EDR_getStorageOrder();
        return unless($storageOrder);
        if($storageOrder eq 'PhysicalOrder'){
           $storageOrder =  'MostRecentLast'; #same behavior as there is no overwriting
        }

        $expectedFaultsPerRecord_href -> {"Record_1"} = $faultsAfterStimulation if($storageOrder eq 'MostRecentLast');
        $expectedFaultsPerRecord_href -> {"Record_2"} = $faultsAfterStimulation_Incident2 if($storageOrder eq 'MostRecentLast');
        $expectedFaultsPerRecord_href -> {"Record_1"} = $faultsAfterStimulation_Incident2 if($storageOrder eq 'MostRecentFirst');
        $expectedFaultsPerRecord_href -> {"Record_2"} = $faultsAfterStimulation if($storageOrder eq 'MostRecentFirst');
    }
	
	# Get EDID data element for printing purpose	
    my $dataElement = $record_handler -> GetDataElementEDID( "EDIDnr" => $tcpar_EDID,
                                                         "RecordNumber" => 1,
                                                         "CrashLabel" => $tcpar_Crashcode);														 
    ## ENABLE for various records
    foreach my $recordNbr (1..$tcpar_expected_number_of_CT)
    {
        S_teststep("---- EDID $tcpar_EDID - RECORD $recordNbr ----", 'NO_AUTO_NBR');
        S_teststep_expected_NOHTML("---- EDID $tcpar_EDID - RECORD $recordNbr ----");
        S_teststep_detected_NOHTML("---- EDID $tcpar_EDID - RECORD $recordNbr ----");


        # Get expected faults for record
        my $thisRecordFaultsAfterStimulation_Bosch = $expectedFaultsPerRecord_href -> {"Record_$recordNbr"};
        # Get expected faults from fault memory hash
        my @expected_DTC_array;
        my $expectedFaultsInEDR;
        my $storedFaults_aref = $thisRecordFaultsAfterStimulation_Bosch
                                    -> get_faults_with_properties({'DecodedStatus' => {'ConfirmedDTC' => 1}});

        foreach my $storedFaultEntry (@{$storedFaults_aref})
        {
            my $faultName = $storedFaultEntry -> {'FaultName'};
            $expectedFaultsInEDR -> {$faultName} -> {'DTC'} = $storedFaultEntry -> {'DTC'};
            $expectedFaultsInEDR -> {$faultName} -> {'Bosch_Fault_Number'} = $storedFaultEntry -> {'BoschFaultNbr'};
            $expectedFaultsInEDR -> {$faultName} -> {'FaultState'} = $storedFaultEntry -> {'RawStatus'};
            push (@expected_DTC_array, $expectedFaultsInEDR -> {$faultName} -> {'DTC'}) if($tcpar_FaultID_type eq 'DTC');
            push (@expected_DTC_array, $expectedFaultsInEDR -> {$faultName} -> {'Bosch_Fault_Number'}) if($tcpar_FaultID_type eq 'BoschFaultNumber');
        }

        S_teststep("Get data for EDID $tcpar_EDID ($dataElement) in record $recordNbr", 'AUTO_NBR', "Record_$recordNbr\_stored");

        my $isAvailable = $record_handler -> IsRecordAvailable("CrashLabel" => $tcpar_Crashcode,
                                                       "RecordNumber" => $recordNbr);
        unless($isAvailable){
            S_set_verdict('VERDICT_FAIL');
            S_teststep_expected("Record $recordNbr is stored", "Record_$recordNbr\_stored");
            S_teststep_detected("Record $recordNbr is empty", "Record_$recordNbr\_stored");
            next;
        }

        my $edidFormat_href = { 'BytesPerFaultId' => $tcpar_NbrOfBytesInFaultID,
                                'BytesPerFaultStatus' => $tcpar_NbrOfBytesFaultStatus,};

        my $detectedFaultsInEDR_href = EDR_ExtractStoredFaultsFromRecord($recordNbr,
                                                                         $tcpar_Crashcode,
                                                                         $tcpar_EDID,
                                                                         $edidFormat_href);

        # Check whether expected faults are reported in EDR
        foreach my $fault (keys %{$expectedFaultsInEDR})
        {
            S_teststep_2nd_level("Validate whether fault '$fault' is present in EDR", 'AUTO_NBR', "Fault_$fault\_record_$recordNbr");
            my ($faultID, $faultID_hex);
            if ($tcpar_FaultID_type eq 'BoschFaultNumber')  {
                $faultID = $expectedFaultsInEDR -> {$fault} -> {'Bosch_Fault_Number'};
                $faultID_hex = lc(S_dec2hex($faultID));
            }
            elsif($tcpar_FaultID_type eq 'DTC') {
                $faultID = $expectedFaultsInEDR -> {$fault} -> {'DTC'};
                $faultID_hex = lc(S_dec2hex($faultID));
            }
            else {
                S_set_error("Unkown fault ID type. Must be either 'DTC' or 'Bosch Fault Number'");
            }
    
            my $expectedFaultState = lc(S_dec2hex($expectedFaultsInEDR -> {$fault} -> {'FaultState'}));
    
            S_teststep_expected("Fault ID: $faultID_hex, Fault status: $expectedFaultState", "Fault_$fault\_record_$recordNbr");
           
           if($detectedFaultsInEDR_href -> {$faultID})
           {
              S_w2rep("Fault $faultID ($fault) is present in EDR. Validate whether state is reported correctly.");
              my $detectedState = lc(S_dec2hex($detectedFaultsInEDR_href -> {$faultID}));
              EVAL_evaluate_value ( "State_Fault_$faultID", $detectedState, '==', $expectedFaultState);                   
              S_teststep_detected("Fault ID: $faultID_hex, Fault status: $detectedState", "Fault_$fault\_record_$recordNbr");
           }
           else {
              S_set_verdict('VERDICT_FAIL');
              S_teststep_detected("Fault ID: $faultID_hex not present in EDR", "Fault_$fault\_record_$recordNbr");
           }
        }

        S_teststep_2nd_level("Check that no faults are reported in EDR which are not there in fault memory", 'AUTO_NBR', "additional_faults_in_edr_record_$recordNbr");
        S_teststep_expected("Only faults present in fault memory are detected in EDR", "additional_faults_in_edr_record_$recordNbr");
        # Crosscheck that no additional faults are reported in EDR which are not there in the fault recorder
        my $additionalFaultsReported;
        foreach my $detectedFaultId (sort {$a <=> $b} keys %{$detectedFaultsInEDR_href})
        {
            unless (grep $_ == $detectedFaultId, @expected_DTC_array){
                S_w2rep( "'$tcpar_FaultID_type' $detectedFaultId reported in EDR, but NOT present in fault recorder",'RED');
                S_set_verdict ('VERDICT_FAIL');
                if(not defined $additionalFaultsReported){
                    $additionalFaultsReported = 'Additional fault numbers: ';
                }
                $additionalFaultsReported .= " ".lc(S_dec2hex($detectedFaultId));
            }
        }
        if(not defined $additionalFaultsReported){
            $additionalFaultsReported = 'No additional faults';
        }
        S_teststep_detected("$additionalFaultsReported",  "additional_faults_in_edr_record_$recordNbr");

        # next record   
    }
	
	return 1;
}

sub TC_finalization {

	S_w2rep("Reset fault conditions");
	if (defined $tcpar_Condition){
		my $MySearch->{'DeviceType'} = $tcpar_DeviceType;
		$MySearch->{'Device'} = $tcpar_Device;
		$MySearch->{'Condition'} = $tcpar_Condition;
		my $fltnames = FM_fetchFaultName($MySearch);
		$fltname = @$fltnames[0];
		FM_removeFault($fltname);
		S_wait_ms($tcpar_wait_ms_Fault);
	}
    elsif($tcpar_DeviceType eq 'MaximumFaults'){ # No fault condition defined, set max number of faults
		my $SquibDetails_href = S_get_contents_of_hash(['TSG4', 'SQUIBS']);	
		my @SquibKeys = grep(/_Name$/, keys %{$SquibDetails_href});
		
		my $beltLockDetails_href = S_get_contents_of_hash(['TSG4', 'BELT_LOCKS']);	
		my @beltLockKeys = grep(/_Name$/, keys %{$beltLockDetails_href});
	
		foreach my $Squib (@SquibKeys)
		{
			$Squib =~ m/SQ(.*)_Name/;	# get number of Squib, will be stored in $1
			my $SquibNumber = $1;
			my $SquibName = $SquibDetails_href -> {"SQ$SquibNumber\_Name"};
			my $MySearch->{'DeviceType'} = 'Squib';
			$MySearch->{'Device'} = $SquibName;
			$MySearch->{'Condition'} = 'Openline';
			my $fltnames = FM_fetchFaultName_NOERROR($MySearch);
			next unless($fltnames);
			$fltname = @$fltnames[0];
			FM_removeFault($fltname);
		}	

		foreach my $beltLock (@beltLockKeys)
		{
			$beltLock =~ m/BL(.*)_Name/;	# get number of beltlock, will be stored in $1
			my $beltLockNumber = $1;
			my $beltLockName = $beltLockDetails_href -> {"BL$beltLockNumber\_Name"};
			my $MySearch->{'DeviceType'} = 'Switch';
			$MySearch->{'Device'} = $beltLockName;
			my $switchtype = DEVICE_fetchSwitchType_NOERROR ($beltLockName);
			next unless($switchtype);
			S_w2rep("switchtype= $switchtype");
			
			if ($switchtype eq 'mech'){
				$MySearch->{'Condition'} = 'Short2Bat';
				my $fltnames = FM_fetchFaultName($MySearch);
				$fltname = @$fltnames[0];
				LC_UndoShortLines();
				FM_removeFault($fltname);
			}
			else{
				$MySearch->{'Condition'} = 'Openline';
				my $fltnames = FM_fetchFaultName_NOERROR($MySearch);
				next unless($fltnames);
				$fltname = @$fltnames[0];
				FM_removeFault($fltname);
			}
		}

		S_wait_ms($tcpar_wait_ms_Fault);

    } 

	$record_handler -> DeleteAllRecords();

	# Erase EDR
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(2000);
			
	# Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(2000);
	
	# Read fault memory after clearing and erasing EDR
    PD_ReadFaultMemory();   

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');
	return 1;
}


1;
