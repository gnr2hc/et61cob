#### TEST CASE MODULE
package TC_EDR_CrashDataRetrieval;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general;
use LIFT_evaluation;
use File::Basename;
use Data::Dumper;
use LIFT_can_access;
use FuncLib_SYC_INTERFACE;
use FuncLib_EDR_Framework;

use constant MILLISEC_TO_SECOND => 0.001;
use constant SECOND_TO_MILLISEC => 1000;
##################################
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_CrashDataRetrieval  $Revision: 1.20 $

requires test setup with
	- Quate
	- MDS data base
	- LCT 64
	- CANoe
	- TSG4

default state is faultfree ECU powered ON

=head1 PURPOSE

inject crashes and store all data in record and crash handler for use in later test cases

=head1 TESTCASE DESCRIPTION 

    [initialisation]
    initialize record handler
    initialize crash handler
    clear crash recorder and fault memory

    [stimulation & measurement]
	1. start LCT measurement
    2. inject crash
    3. stop LCT measurement
    4. read all crash records and add to record handler
    5. get all sensor data and add to crash handler
    6. add all fire times to crash handler

    [evaluation]
    1. no evaluation required

    [finalisation]
    1. clear fault memory
    2. clear crash recorder
    3. reset ECU

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

    purpose --> Purpose of the test case
    crashtype --> Type/name of crash. Name must be defined in Mapping_EDR.pm!
  	DiagType --> AKLV, Ford, ProdDiag, or Geely
  	DataStartFromByteIndex --> Index of byte in record response aref where EDR data starts
	StorageOptions --> Import COM signals, sensor data, fire times, switches depending on this parameter
	StoragePath --> In this path, the test case will look for a folder with the same name as the crashtype
	                In that folder, the stored crash data is expected

=head2 PARAMETER EXAMPLES

    [TC_EDR_CrashDataRetrieval.xxx]
	# From here on: applicable Lift Default Parameters
	purpose = 'retrieve crash data'
	crashtype = 'Rollover'
	DiagType = 'AKLV'
	DataStartFromByteIndex = '4' #optional
	StorageOptions = %('COM_Signals' => 'no', 'SensorData' => 'yes', 'FireTimes' => 'yes', 'SwitchStates' => 'yes')
	StoragePath = 'C:\TurboLIFT\AB12\CrashData\'

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Crashtype;
my $tcpar_StoragePath;
my $tcpar_DiagType;
my $tcpar_DataStartByteIndex;
my $tcpar_StorageOptions_href;
my $tcpar_SDID;
my $tcpar_FireCurrentThreshold;
my $tcpar_retrieve_NHTSAEDR;
my $tcpar_retrieve_CHINAEDR;
my $tcpar_read_NHTSAEDR;

################ global parameter declaration ###################
#add any global variables here
my (
		$record_handler,
		$crash_handler,
		$comSignalLabelMapping_href,
	);
	
# Choose here which tables to print in the report
my $printDecodedTable = 1;
my $printRawDecimalTable = 0;
my $printRawHexTable = 1;
my $crashLabel;
our $PURPOSE;
our $TC_name = "TC_EDR_CrashInjection";

#-------------------------------------------------------------------------------
sub TC_set_parameters {
#-------------------------------------------------------------------------------
	S_w2rep("Read testcase parameters");
    $tcpar_Crashtype = S_read_mandatory_testcase_parameter('crashtype');
    $tcpar_DiagType = S_read_optional_testcase_parameter('DiagType');
    $tcpar_DataStartByteIndex = S_read_optional_testcase_parameter('DataStartByteIndex');
    $tcpar_FireCurrentThreshold = S_read_optional_testcase_parameter('FireCurrentThreshold');
	$tcpar_retrieve_CHINAEDR=S_read_optional_testcase_parameter('retrieve_CHINAEDR');
	if(not defined $tcpar_retrieve_CHINAEDR) {
		$tcpar_retrieve_NHTSAEDR = 'yes';
		$tcpar_retrieve_CHINAEDR = 'no';
		if (not defined $tcpar_DiagType ){
			S_set_error("Diagtype $tcpar_DiagType is not defined  for retreiving NHTSA EDR. Test case aborted.");
			return;
		}
	}
	else {
		$tcpar_retrieve_NHTSAEDR = 'no';
		$tcpar_DiagType='CHINA_Payload';
	}

    # Make crash label unique if threshold was set
    if (defined $tcpar_FireCurrentThreshold) {
        my $measureThreshold = $tcpar_FireCurrentThreshold;
        S_w2rep("Fire current threshold: $measureThreshold ");
        $measureThreshold =~ s/\./_/g;
        $tcpar_Crashtype .= "_".$measureThreshold."A";  
    }
    $tcpar_StorageOptions_href = S_read_mandatory_testcase_parameter('StorageOptions', 'byref');
	$tcpar_StoragePath = S_read_mandatory_testcase_parameter('StoragePath');
    $tcpar_SDID = S_read_optional_testcase_parameter('SupplierData_EDID');
    if(not defined $tcpar_SDID){
    	$tcpar_SDID = 999;
    }

	return 1;
}

#-------------------------------------------------------------------------------
sub TC_initialization {
#-------------------------------------------------------------------------------
	#--------------------------------------------------------------
    # INITIALIZE RECORD AND CRASH HANDLER
    #    
	S_w2rep("Initialize Record and Crash Handler");
	$record_handler = EDR_init_RecordHandler() || return;
	$crash_handler  = EDR_init_CrashHandler() || return;

    return 1;
}

#-------------------------------------------------------------------------------
sub TC_stimulation_and_measurement {
#-------------------------------------------------------------------------------

    my $mappingEDR = S_get_contents_of_hash(['Mapping_EDR']);

	#--------------------------------------------------------------
    # GET CRASH RECORDS
	#    
	S_teststep("Get all stored records via CustDiag and store in record handler", 'AUTO_NBR');
	my $recordStructure_href;
	my $recordData_aref;
	my $recordDataOEM_aref;
	
	# require file with stored EDR records
	my $crashDataFile = $tcpar_StoragePath.$tcpar_Crashtype.'\EDR_Records.pm'if ($tcpar_retrieve_NHTSAEDR eq 'yes' or $tcpar_DiagType eq 'ProdDiag');
	$crashDataFile = $tcpar_StoragePath.$tcpar_Crashtype.'\EDR_Records_CHINA.pm'if ($tcpar_retrieve_CHINAEDR eq 'yes' and $tcpar_DiagType ne 'ProdDiag');
    unless( -e $crashDataFile ) {
    	S_set_error("Crash data file '$crashDataFile' does not exist!");
    	return;
    }

    S_w2rep("requiring crash data $crashDataFile \n");
    require $crashDataFile;
	my $allRecordsDump_href = $EDR_Records::Records if ($tcpar_retrieve_NHTSAEDR eq 'yes');
	$allRecordsDump_href = $EDR_Records_CHINA::Records if ($tcpar_retrieve_CHINAEDR eq 'yes');

	# Get number of records in EDR	
	my $numberOfRecords = SYC_EDR_get_NumberOfEventsToBeStored();
	S_w2rep("Number of EDR records (from SYC): $numberOfRecords");
	
	foreach my $recordNbr (1..$numberOfRecords)
	{
		S_w2rep("--------------------");
		S_w2rep("Record $recordNbr ");
		S_w2rep("--------------------");

		S_teststep_2nd_level("Get record data for record $recordNbr from stored file", 'AUTO_NBR');

		if($tcpar_DiagType eq 'AKLV') {			
			$recordData_aref = $allRecordsDump_href -> {$recordNbr} -> {'Data'} -> {'Generic'};
			$recordDataOEM_aref = $allRecordsDump_href -> {$recordNbr} -> {'Data'} -> {'OEM'};
			$recordStructure_href = EDR_ReadEDR_Record_structure_info_from_mapping('AKLV');
		}
		elsif($tcpar_DiagType eq 'Ford') {
			$recordData_aref = $allRecordsDump_href -> {$recordNbr} -> {'Data'};
			$recordStructure_href = $allRecordsDump_href -> {'StructureInfo'};
		}
		elsif($tcpar_DiagType eq 'CHINA_Payload') {
				$recordData_aref = $allRecordsDump_href -> {$recordNbr} -> {'Data'};
				$recordStructure_href =EDR_ReadCHINAEDR_Record_structure_info_from_mapping();
			}
		else {
			S_w2log(4, "For all diag types other than Ford and AKLV, AKLV style (EDID followed by data) is expected\n.".
			           "Data start byte index is configurable");
			$recordData_aref = $allRecordsDump_href -> {$recordNbr} -> {'Data'};
			$recordData_aref = $allRecordsDump_href -> {$recordNbr} -> {'Data'} -> {'Generic'} if(not defined $recordData_aref);
			$tcpar_DataStartByteIndex = 4 if(not defined $tcpar_DataStartByteIndex); # 4 is value for Prod Diag
			$recordStructure_href = EDR_ReadEDR_Record_structure_info_from_mapping('ProdDiag', $tcpar_DataStartByteIndex); #Data start from byte index 4
		}

		unless(defined $recordData_aref) {
			S_w2rep("No valid response was recieved for request of record $recordNbr. Try next slot.");
			next;
		}		

		S_teststep_2nd_level("Add obtained crash record $recordNbr to record handler", 'AUTO_NBR');
		my $recordCreated = $record_handler -> AddCrashRecord(
											"RecordNumber" => $recordNbr,
											"CrashLabel"   => $tcpar_Crashtype,
											"RecordStructureInfo" => $recordStructure_href,
											"RawDataGeneric" => $recordData_aref,
											"RawDataOEM"     => $recordDataOEM_aref,
											);
		
		next unless($recordCreated);
 
        S_teststep_2nd_level("Print crash record $recordNbr", 'AUTO_NBR');
        $record_handler -> PrintRawEDIDs( "RecordNumber" => $recordNbr,
                                            "CrashLabel" => $tcpar_Crashtype,
                                         ) if($printRawDecimalTable);

        $record_handler -> PrintRawEDIDs( "RecordNumber" => $recordNbr,
                                            "CrashLabel" => $tcpar_Crashtype,
                                            "FormatOption" => 'HEX',
                                         ) if($printRawHexTable);

        $record_handler -> PrintDecodedEDIDs( "RecordNumber" => $recordNbr,
                                            "CrashLabel" => $tcpar_Crashtype,
                                            ) if($printDecodedTable);

        my $supplierRecordData_aref = $record_handler -> GetRawEDID( "EDIDnr" => $tcpar_SDID,
                                                                "RecordNumber" => $recordNbr,
                                                                "CrashLabel" => $tcpar_Crashtype,)if ($tcpar_retrieve_NHTSAEDR eq 'yes');
        
        next unless($supplierRecordData_aref);
                                                                
        my $recordStructureSupplier_href = EDR_ReadEDR_Record_structure_info_from_mapping_NOERROR('Supplier',0,'Mapping_EDR','SUPPLIER_EDIDS');
        next unless($recordStructureSupplier_href);

        S_teststep_2nd_level("Add obtained supplier data for crash record $recordNbr to record handler", 'AUTO_NBR');
        $record_handler -> AddCrashRecord(  "RecordNumber" => $recordNbr,
                                                "CrashLabel"   => $tcpar_Crashtype.'_Supplier',
                                                "RecordStructureInfo" => $recordStructureSupplier_href,
                                                "RawDataGeneric" => $supplierRecordData_aref,);

        S_teststep_2nd_level("Print supplier data crash record $recordNbr", 'AUTO_NBR');
        $record_handler -> PrintRawEDIDs( "RecordNumber" => $recordNbr,
                                            "CrashLabel" => $tcpar_Crashtype.'_Supplier',
                                            "FormatOption" => 'HEX',
                                         )if($printRawHexTable);

        $record_handler -> PrintDecodedEDIDs( "RecordNumber" => $recordNbr,
                                                "CrashLabel" => $tcpar_Crashtype.'_Supplier',
                                             )if($printDecodedTable);


    }

	#--------------------------------------------------------------
    # GET CRASH DATA FROM MDS
	#    
    # ************** 1 - GENERAL CRASH INFO **************
   if(defined ($allRecordsDump_href -> {"CrashInfo"}) and ($allRecordsDump_href -> {"CrashInfo"} ne '')){
        if(defined $allRecordsDump_href -> {"CrashInfo"} -> {"CrashTimeZero_ms"}) {
            $crash_handler -> AddCrashSource( "CrashLabel" => $tcpar_Crashtype,
                                              "SourceLabel" => 'CrashTimeZero', 
                                              "OriginalSourceData" => $allRecordsDump_href -> {"CrashInfo"} -> {"CrashTimeZero_ms"},
                                              "SourceUnit" => 'ms',);           
            $crash_handler -> AddCrashSource( "CrashLabel" => $tcpar_Crashtype."_Supplier",
                                              "SourceLabel" => 'CrashTimeZero', 
                                              "OriginalSourceData" => $allRecordsDump_href -> {"CrashInfo"} -> {"CrashTimeZero_ms"},
                                              "SourceUnit" => 'ms',)if ($tcpar_retrieve_NHTSAEDR eq 'yes');           
        }
        if(defined $allRecordsDump_href -> {"CrashInfo"} -> {"FirstDeployment_ms"}) {
            $crash_handler -> AddCrashSource( "CrashLabel" => $tcpar_Crashtype,
                                              "SourceLabel" => 'FirstDeployment', 
                                              "OriginalSourceData" => $allRecordsDump_href -> {"CrashInfo"} -> {"FirstDeployment_ms"},
                                              "SourceUnit" => 'ms',);           
            $crash_handler -> AddCrashSource( "CrashLabel" => $tcpar_Crashtype."_Supplier",
                                              "SourceLabel" => 'FirstDeployment', 
                                              "OriginalSourceData" => $allRecordsDump_href -> {"CrashInfo"} -> {"FirstDeployment_ms"},
                                              "SourceUnit" => 'ms',)if ($tcpar_retrieve_NHTSAEDR eq 'yes');           
        }
        if(defined $allRecordsDump_href -> {"CrashInfo"} -> {"CrashCode_MDS"}) {
            $crash_handler -> AddCrashSource( "CrashLabel" => $tcpar_Crashtype,
                                              "SourceLabel" => 'CrashCode_MDS', 
                                              "OriginalSourceData" => $allRecordsDump_href -> {"CrashInfo"} -> {"CrashCode_MDS"},);         
            $crash_handler -> AddCrashSource( "CrashLabel" => $tcpar_Crashtype."_Supplier",
                                              "SourceLabel" => 'CrashCode_MDS', 
                                              "OriginalSourceData" => $allRecordsDump_href -> {"CrashInfo"} -> {"CrashCode_MDS"},)if ($tcpar_retrieve_NHTSAEDR eq 'yes');         
        }
        if(defined $allRecordsDump_href -> {"CrashInfo"} -> {"MDB_Path"}) {
            $crash_handler -> AddCrashSource( "CrashLabel" => $tcpar_Crashtype,
                                              "SourceLabel" => 'MDB_Path', 
                                              "OriginalSourceData" => $allRecordsDump_href -> {"CrashInfo"} -> {"MDB_Path"},)if ($tcpar_retrieve_NHTSAEDR eq 'yes');          
            $crash_handler -> AddCrashSource( "CrashLabel" => $tcpar_Crashtype."_Supplier",
                                              "SourceLabel" => 'MDB_Path', 
                                              "OriginalSourceData" => $allRecordsDump_href -> {"CrashInfo"} -> {"MDB_Path"},)if ($tcpar_retrieve_NHTSAEDR eq 'yes');          
        }     
    }   
	
    # ************** 2 - SENSOR DATA **************       
	if($tcpar_StorageOptions_href->{'SensorData'} eq 'yes')
	{
		S_teststep("Get stored physical sensor values and add to crash handler", 'AUTO_NBR');


		EDR_addSensorDataToCrashHandler ( "RetrieveStoredData" => 'true',
		                                   "CrashLabel"  => $tcpar_Crashtype,
		                                     "DataStoragePath" => $tcpar_StoragePath, # optional
		                                    ); 
	}

    # ************** 3 - SWITCH STATES **************       
	if($tcpar_StorageOptions_href->{'SwitchStates'} eq 'yes')
	{
		S_teststep("Get stored switch states", 'AUTO_NBR');
	
		$crashDataFile = "$tcpar_StoragePath$tcpar_Crashtype/Switch_States.pm";
	    unless( -e $crashDataFile ) {
	    	S_set_error("Crash data file '$crashDataFile' does not exist!");
	    	return;
	    }
	    
	    S_w2rep("requiring crash data $crashDataFile \n");
	    require $crashDataFile;
	    	
		my $crashSwitchStates = $Switch_States::SwitchStatesDuringCrash;
	
		# Go through all stored switches
	    foreach my $switch ( keys %{$crashSwitchStates} )
	    {
			# Add switch to crash handler
			next if($crashSwitchStates -> {$switch} eq 'not_connected');
			my $switchState = $crashSwitchStates -> {$switch} -> {"State"};
			my $switchStateManipulated = $crashSwitchStates -> {$switch} -> {"ManipulatedValue"};
			$switchState = $switchStateManipulated if (defined $switchStateManipulated);
			$crash_handler -> AddCrashSource(  "CrashLabel" => $tcpar_Crashtype,
											   "SourceType" => 'Switch', 
	                                           "SourceLabel" => $switch,
	                                           "OriginalSourceData" => $switchState );    		
	    }
	}

    # ************** 4 - PD Variables **************       
	S_teststep("Get stored PD variables", 'AUTO_NBR');

	$crashDataFile = "$tcpar_StoragePath$tcpar_Crashtype/EDR_PD_VariableData.pm";

    if( -e $crashDataFile ) {
    	S_w2rep("PD variables read during crash will be added to crash handler.");
	    S_w2rep("requiring crash data $crashDataFile \n");
	    require $crashDataFile;
	    	
		my $crashPDvariables = $EDR_PD_VariableData::PD_Variables;
	
		# Go through all stored switches
	    foreach my $pdLabel ( keys %{$crashPDvariables} )
	    {
			# Add switch to crash handler
			my $PDvalue = $crashPDvariables -> {$pdLabel} -> {'Value'};
			my $PDvariable = $crashPDvariables -> {$pdLabel} -> {'VariableName'};
			S_w2rep("Variable $PDvariable ($pdLabel)  with value $PDvalue");
			$crash_handler -> AddCrashSource(  "CrashLabel" => $tcpar_Crashtype,
	                                           "SourceUnit"  => $crashPDvariables -> {$pdLabel} -> {'Unit'},
	                                           "SourceLabel" => $pdLabel,
	                                           "OriginalSourceName" => $PDvariable,
	                                           "OriginalSourceData" => $PDvalue );    		
	    }
    }
    else {
    	S_w2rep("No PD variables stored during crash.");
    }


	#--------------------------------------------------------------
    # GET CRASH DATA FROM MEASUREMENTS
	#    

    # ************** 1 - COM SIGNALS **************       
	if($tcpar_StorageOptions_href->{'COM_Signals'} eq 'yes')
	{
		S_teststep("Get stored COM trace dataref", 'AUTO_NBR');

        # Get list of EDR relevant COM signals from EDR mapping
        my $edr_COM_signals_aref = $mappingEDR -> {'EDR_COM_SIGNAL_LABELS'};
        $crashDataFile = "$tcpar_StoragePath$tcpar_Crashtype/LIFT_network_trace.asc";
            unless( -e $crashDataFile ) {
            S_set_error("Crash data file '$crashDataFile' does not exist!");
            return;
        }

		EDR_addCOMsignalsToCrashHandler ("COM_SignalLabels" => $edr_COM_signals_aref,
		                                 "CrashLabel"  => $tcpar_Crashtype,
		                                 "COM_TraceFileName" => $crashDataFile,);		
	}

    # ************** 2 - FIRE TIMES **************       
	if($tcpar_StorageOptions_href->{'FireTimes'} eq 'yes')
	{
		S_teststep("Get stored fire times", 'AUTO_NBR');
	
		$crashDataFile = "$tcpar_StoragePath$tcpar_Crashtype/LCT_Measurement.txt.unv";
	    unless( -e $crashDataFile ) {
	    	S_set_warning("No fire times measured");
	    	return 1;
	    }
		S_teststep_2nd_level("Get measured squib fire values from stored file ($crashDataFile)", 'AUTO_NBR');
	    my $LCT_data = EVAL_importUNV($crashDataFile);
		my $squibLabels_aref = undef; 
	
		# List of all measured squib labels
	    foreach my $time ( sort { $a <=> $b } keys %$LCT_data )
	    {
	    	foreach my $squibLabel (keys %{$LCT_data->{$time}})
	    	{
	    		push(@{$squibLabels_aref}, $squibLabel);
	    	}
	        last;
	    }
		
		if(defined $squibLabels_aref) {
			S_teststep_2nd_level("Add all fire times measured to crash handler for $tcpar_Crashtype", 'AUTO_NBR');
			EDR_addFireTimesToCrashHandler ("LCT_Measurement" => $LCT_data,
											"SquibLabels" => $squibLabels_aref,
											"CrashLabel"  => $tcpar_Crashtype,
											"FireCurrentDuration" => 'true');
            EDR_addFireTimesToCrashHandler_NOHTML ("LCT_Measurement" => $LCT_data,
                                            "SquibLabels" => $squibLabels_aref,
                                            "CrashLabel"  => $tcpar_Crashtype."_Supplier",
                                            "FireCurrentDuration" => 'true')if ($tcpar_retrieve_NHTSAEDR eq 'yes');
		}
		else {
			S_w2rep("No deployment times available for crash $tcpar_Crashtype.", 'AUTO_NBR');		
		}
	}
	
    return 1;
}

#-------------------------------------------------------------------------------
sub TC_evaluation {
#-------------------------------------------------------------------------------
	S_w2rep("No evaluation in this test case", 'AUTO_NBR');	
	
    return 1;
}

#-------------------------------------------------------------------------------
sub TC_finalization {
#-------------------------------------------------------------------------------    	

    undef $tcpar_Crashtype;
	undef $tcpar_DiagType;
    undef $tcpar_StorageOptions_href;
	undef $tcpar_StoragePath;

	return 1;
}



1;