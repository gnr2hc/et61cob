#### TEST CASE MODULE
package TC_EDR_SpecialEventHandling;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
#include further modules here
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use GENERIC_DCOM;
use LIFT_can_access;
use LIFT_FaultMemory;
use FuncLib_EDR_Framework;
use FuncLib_TNT_SYC_INTERFACE;
use Data::Dumper;

##################################

our $PURPOSE = "<This test script checks behaviour of EDR when ROSE is special event in combination with multi event.>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_MultipleEvents_RoSe_parallel_Standard

=head1 PURPOSE

<This test script checks behaviour of EDR when ROSE is special event in combination with multi event.>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Inject <crashtype> 

2. Start measurement of fire times

3. Wait for <wait_ms>

4. Stop measurement of fire times

5. Read crash record


I<B<Evaluation>>

1. -

2. -

3. -

4. -

5. Check timing aspects in CT are correct depending on SoE for standard event <SoE> and EoE for standard event <EoE>. E.g. check time for deployment of pretensioner. Should not be zero in both CT because both refer to same T0.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'crashtype' => 
	SCALAR 'SoE' => 
	SCALAR 'EoE' => 
	SCALAR 'purpose' => 
	SCALAR 'EDR_SPECIAL_EVENT' => 
	SCALAR 'EDR_Type' => 
	SCALAR 'Event_Extended' => 
	SCALAR 'wait_ms' => 
	SCALAR 'Crash_Time_Zero_Record1' => 
	SCALAR 'Crash_Time_Zero_Record2' => 
	HASH 'FireTime_EDIDs' => 
	SCALAR 'NumberOfRecordsExpected' => 
	HASH 'CompareValues_CT1' => 
	HASH 'CompareValues_CT2' => 


=head2 PARAMETER EXAMPLES

	purpose		 = 'check crash record for correct timing, with special interest in t0 that depends on which crash was first'
	
	# ---------- Stimulation ------------ 
	
	wait_ms = 5000 #ms
	
	# ---------- Evaluation ------------ 
	# compare to measured fire times
	
	
	Crash_Time_Zero_Record1 = 'xx' # Fetched from crash file
	Crash_Time_Zero_Record2 = 'xx'# Fetched from crash file
	
	FireTime_EDIDs = %('51' => 'AB1FD' , '52' => 'AB2FD', '53' => 'AB3FD', '56' => 'AB1FP', '57' =>'AB2FP', '58' => 'AB3FP', '63' => 'BT1FD', '108' => 'BT1FC', '67' => 'BT1FP', '109' => 'BT2FD', '110' => 'BT2FP', '111' => 'BT2FC', '147' => 'BT1RC', '61' => 'SA1FD', '65' => 'SA1FP', '101' => 'KA1FD', '102' => 'KA1FP', '115' => 'ALLFD', '116' => 'ALLFP')
	
	NumberOfRecordsExpected ='2'
	
	#--> Evaluate deployment of pretensioner is reported with reference to algo activation of the respective record --> should not be the same value in both records!
	
	CompareValues_CT1 = %('48' => 'FFFF', '45' => '1') # most recent first.
	CompareValues_CT2 = %('48' => 'TimeGreaterThanZero', '45' => '2')
	crashtype = 'Side100msAfterRoSe'
	SoE = 'not_used'
	EoE = 'not_used'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_DiagType;
my $tcpar_Event_Extended;
my $tcpar_wait_ms;
my $tcpar_CrashT0_ms;
my $tcpar_CrashT0_special_ms;
my $tcpar_FireTime_EDIDs;
my $tcpar_FireTime_EDIDs_SpecialEvent;
my $tcpar_EvalTolerance_abs;
my $tcpar_NumberOfRecordsExpected;
my $tcpar_CompareValues_CT1;
my $tcpar_CompareValues_CT2;
my $tcpar_CompareValues_CT3;
my $tcpar_CompareValues_CT4;
my $tcpar_CompareValues_CT5;
my $tcpar_CompareValues_CT6;
my $tcpar_Crashcode ;
my $tcpar_Record_Compared_Extended;
my $tcpar_Record_Compared_SpecialEvent_aref;
my $tcpar_CompareValues_Extended ;
my $tcpar_CompareValue_SpecialEvent;
my $tcpar_ResultDB;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_AlgoEDIDSupported;
my $tcpar_read_NHTSAEDR;
my $tcpar_read_CHINAEDR;
################ global parameter declaration ###################
my($tcpar_CompareValues_CT);
my ($record_handler, $crash_handler, $crashSettings, $edrNumberOfEventsToBeStored, $noRegularEvent,$ChinaEDR_diagType);

###############################################################

sub TC_set_parameters {


	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_ResultDB =  S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_DiagType =  S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_Event_Extended =  S_read_optional_testcase_parameter( 'Event_Extended' );
	$tcpar_wait_ms =  S_read_mandatory_testcase_parameter( 'wait_ms' );
	$tcpar_CrashT0_ms =  S_read_optional_testcase_parameter( 'Crash_Time_Zero' );
	$tcpar_CrashT0_special_ms =  S_read_mandatory_testcase_parameter( 'Crash_Time_Zero_Special' );
	$tcpar_FireTime_EDIDs =  S_read_mandatory_testcase_parameter('FireTime_EDIDs' , 'byref' );
    $tcpar_FireTime_EDIDs_SpecialEvent =  S_read_mandatory_testcase_parameter('FireTime_EDIDs_SpecialEvent' , 'byref' );
	$tcpar_NumberOfRecordsExpected =  S_read_mandatory_testcase_parameter( 'NumberOfRecordsExpected' );
	$tcpar_Record_Compared_SpecialEvent_aref =  S_read_mandatory_testcase_parameter( 'Record_Compared_SpecialEvent' , 'byref');
	$tcpar_Record_Compared_Extended =  S_read_optional_testcase_parameter( 'Record_Compared_Extended' );
	$tcpar_CompareValues_Extended  =  S_read_optional_testcase_parameter( 'CompareValues_Extended','byref');
	$tcpar_CompareValue_SpecialEvent =  S_read_optional_testcase_parameter( 'CompareValue_SpecialEvent', 'byref' );
	$tcpar_CompareValues_CT1 =  S_read_mandatory_testcase_parameter( 'CompareValues_CT1','byref' );
	$tcpar_CompareValues_CT2 =  S_read_optional_testcase_parameter( 'CompareValues_CT2','byref' );
	$tcpar_CompareValues_CT3 =  S_read_optional_testcase_parameter( 'CompareValues_CT3','byref' );
	$tcpar_CompareValues_CT4 =  S_read_optional_testcase_parameter( 'CompareValues_CT4','byref' );
	$tcpar_CompareValues_CT5 =  S_read_optional_testcase_parameter( 'CompareValues_CT5','byref' );
	$tcpar_CompareValues_CT6 =  S_read_optional_testcase_parameter( 'CompareValues_CT6','byref' );
	$tcpar_Crashcode =  S_read_mandatory_testcase_parameter( 'Crashcode' );
	$tcpar_EvalTolerance_abs =  S_read_mandatory_testcase_parameter( 'EvalTolerance_abs' );
	$tcpar_COMsignalsAfterCrash =  S_read_optional_testcase_parameter( 'COMsignalsAfterCrash','byref');
	$tcpar_AlgoEDIDSupported = S_read_optional_testcase_parameter('AlgoEDIDSupported');
	
	# my $specialEvent  = SYC_EDR_get_SpecialEvent();
	my $specialEvent  = 'true';
	if (not defined $specialEvent){
		S_set_error("Not available in SYC - add or overwrite with Custlibrary Function");
		return;
	}
	elsif ($specialEvent eq 'false'){
		S_set_warning(" Special event is not enabled for your project, make sure this is reflected in the given TC parameters");
	}
	$tcpar_read_NHTSAEDR=S_read_optional_testcase_parameter('read_NHTSAEDR');
	$tcpar_read_CHINAEDR=S_read_optional_testcase_parameter('read_CHINAEDR');
	
	if(not defined $tcpar_read_CHINAEDR) {
		$tcpar_read_NHTSAEDR = 'yes';
		$tcpar_read_CHINAEDR = 'no';
	}
	else {
		$tcpar_read_NHTSAEDR = 'no';
		my $storageOrder = EDR_getStorageOrder();
		return unless(defined $storageOrder);

		if($storageOrder eq 'PhysicalOrder'){
			$ChinaEDR_diagType= 'ProdDiag';  #In platform NHTSA and China EDR is read via proddiag
		}
		else {
			$ChinaEDR_diagType= 'CHINA_Payload';
		}
	}

	return 1;
}

sub TC_initialization {

	S_teststep("Test setup preparation", 'AUTO_NBR');

	#--------------------------------------------------------------
    # INITIALIZE RECORD AND CRASH HANDLER
    #    
	S_w2rep("Initialize Record and Crash Handler");
	$record_handler = EDR_init_RecordHandler() || return;
	$crash_handler  = EDR_init_CrashHandler() || return;

	#--------------------------------------------------------------
    # PREPARE CRASH AND INITIALIZE EQUIPMENT
    #
	S_w2rep("Get crash settings for crash $tcpar_Crashcode");
    my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode};
	$crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log(1, "Crashcode: $tcpar_Crashcode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");

	S_w2log(1, "Power on ECU");
    LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

    S_w2log(1, "Initialize CD and start CAN trace");
    GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start ( );

	S_w2log(1, "Set environments for crash as per result DB");
    CSI_PrepareEnvironment($crashSettings, 'init_complete');
	S_wait_ms(2000);

	S_w2log(1, "Clear crash recorder");
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(2000);

	S_w2log(1, "Clear fault memory");
	PD_ClearFaultMemory();
    S_wait_ms(2000);

	S_w2log(1, "Read and evaluate fault memory before stimulation");
	my $faultsBeforeStimulation_obj = LIFT_FaultMemory -> read_fault_memory('Bosch');
    my $faultsVerdict = $faultsBeforeStimulation_obj -> evaluate_faults({});
    return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

	return 1;
}

sub TC_stimulation_and_measurement {

    #--------------------------------------------------------------
    # CRASH PREPARATION
    #
    S_teststep("Prepare crash", 'AUTO_NBR');
    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

    # Prepare crash
    CSI_LoadCrashSensorData2Simulator($crashSettings);

    # Power ON the ECU
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

    # Start fire time measurement
	S_teststep("Start recording of fire times.", 'AUTO_NBR');
    LC_MeasureTraceDigitalStart();
    
    CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    S_wait_ms(1000);

	#--------------------------------------------------------------
	# CRASH INJECTION
	#
	S_teststep("Inject '$tcpar_Crashcode'", 'AUTO_NBR');
	CSI_TriggerCrash();

	S_teststep("Wait '$tcpar_wait_ms'", 'AUTO_NBR');
	S_wait_ms($tcpar_wait_ms);

	S_teststep("Stop recording of fire times", 'AUTO_NBR');
    LC_MeasureTraceDigitalStop();

    # Send post crash COM signals
    if (defined $tcpar_COMsignalsAfterCrash){
        S_w2log(1, "Send COM signals after crash");
        foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
        {
            my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
            S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
            COM_setSignalState($signal,$dataOnCOM);
        }
    }

    S_teststep("Reset ECU", 'AUTO_NBR');
	LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep("Read crash record", 'AUTO_NBR', 'read_crash_record'); #measurement 1
	my $dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_".$tcpar_Crashcode;
	$edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();
	unless(defined $edrNumberOfEventsToBeStored){
        S_set_error("Not available in SYC - add or overwrite with Custlibrary Function");
        return;
    }

	PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');

	if ( lc($tcpar_read_NHTSAEDR) eq 'yes' ) {
		EDR_ReadAndStoreAllRecords(
			"DiagType"     => $tcpar_DiagType,
			"CrashLabel"   => $tcpar_Crashcode,
			"NbrOfRecords" => $edrNumberOfEventsToBeStored,
			"StoragePath"  => $dataStoragePath,
			"read_EDRType" => 'NHTSA'
		);
	}
	if ( lc($tcpar_read_CHINAEDR) eq 'yes' ) {
		$edrNumberOfEventsToBeStored = 3;
		EDR_ReadAndStoreAllRecords(
			"DiagType"     => $ChinaEDR_diagType,
			"CrashLabel"   => $tcpar_Crashcode,
			"NbrOfRecords" => $edrNumberOfEventsToBeStored,
			"StoragePath"  => $dataStoragePath,
			"read_EDRType" => 'CHINA'
		);

	}
	
	my $lct_Data = LC_MeasureTraceDigitalGetValues();
    EVAL_dump2UNV( $lct_Data, "$dataStoragePath/LCT_Measurement.txt.unv" );

	if(defined $tcpar_FireTime_EDIDs){
		S_teststep("Extract Deployment_EDIDs to MDS simulation", 'AUTO_NBR', 'compare_deployment_edids'); #measurement 2  
		 EDR_addFireTimesToCrashHandler("CrashSettings_MDS" => $crashSettings,
										 "CrashLabel"  => $tcpar_Crashcode);
	}
	S_teststep("Check that multi event number is incremented correctly and time from previous event to current event is greater than zero ", 'AUTO_NBR', 'compare_multievent'); #measurement 3
	S_teststep("Check that Rose crash telegram records belt pretensioner firing time with correct 'crashTime_to' ", 'AUTO_NBR', 'compare_Rose_deployment_time'); #measurement 4
	S_teststep("Check that crash telegram $tcpar_Record_Compared_Extended stores deployment times of current and subsequent crashes ", 'AUTO_NBR', 'compare_extendedevent_deployment_time') if (defined $tcpar_Event_Extended); #measurement 5

	return 1;
}

sub TC_evaluation {

	#--------------------------------------------------------------
    # NUMBER OF EXPECTED RECORDS
    #
	S_w2rep("");
	S_w2rep("--------------------------------------------------------", 'purple');
	S_w2rep("NUMBER OF EXPECTED RECORDS", 'purple');
	my $detectedNbrOfStoredRecords = 0;
	foreach my $recordNumber (1..$edrNumberOfEventsToBeStored)
	{
		my $recordAvailable = $record_handler -> IsRecordAvailable("CrashLabel" => $tcpar_Crashcode, "RecordNumber"=> $recordNumber);
		$detectedNbrOfStoredRecords++ if ($recordAvailable);
	}
	S_teststep_expected("$tcpar_NumberOfRecordsExpected records stored", 'read_crash_record'); #evaluation 1
	my $verdict=EVAL_evaluate_value("NumberOfRecords", $detectedNbrOfStoredRecords, '==',$tcpar_NumberOfRecordsExpected);
	S_teststep_detected("$detectedNbrOfStoredRecords records stored", 'read_crash_record');


	#--------------------------------------------------------------
    # FIRE TIMES
    #

	S_w2rep("");
	S_w2rep("--------------------------------------------------------", 'purple');
	S_w2rep("DEPLOYMENT TIMES SPECIAL EVENT", 'purple');

	my $specialEventIncidentNumber = 1;
	my $numberOfSpecialEvents = @{$tcpar_Record_Compared_SpecialEvent_aref};
    foreach my $recordNumber (@{$tcpar_Record_Compared_SpecialEvent_aref})
    {
        S_teststep("Validate Fire times in record $recordNumber (special event)", 'AUTO_NBR');

		my ( $specialSquibVerdict, $specialSquibVerdict ) = EDR_Eval_SquibFireTimes(
			"CrashLabel"               => $tcpar_Crashcode,
			"EDID_SquibLabels"         => $tcpar_FireTime_EDIDs_SpecialEvent,
			"CrashTimeZero_ms"         => $tcpar_CrashT0_special_ms,
			"RecordNumber"             => $recordNumber,
			"MultiEventIncidentNumber" => $specialEventIncidentNumber,
			"FireTimeTolerance_ms"     => $tcpar_EvalTolerance_abs,
		);
		$specialEventIncidentNumber++;
    }

	S_w2rep("");
	S_w2rep("--------------------------------------------------------", 'purple');
	S_w2rep("DEPLOYMENT TIMES REGULAR EVENT", 'purple');

	my $numberOfRegularIncidents = $tcpar_NumberOfRecordsExpected - 1; # One is special event
    if($numberOfRegularIncidents){
		my @crashTimesZero_array = split(/_/, $tcpar_CrashT0_ms);
	
	    # Remove incidents which are not stored in EDR for fire time validation
		if(scalar (@crashTimesZero_array) > ($tcpar_NumberOfRecordsExpected - 1)){ # special event not included
	        my $CrashT0_ms;
	   	    foreach my $incidentToStore (1..$tcpar_NumberOfRecordsExpected)
		    {
		        if(not defined $CrashT0_ms){
		            $CrashT0_ms = $crashTimesZero_array[$incidentToStore - 1];
		            next;
		        }
		        $CrashT0_ms = $CrashT0_ms."_".$crashTimesZero_array[$incidentToStore - 1];
		    }
		    $tcpar_CrashT0_ms = $CrashT0_ms;
		}    	

		my $regularIncidentNumber = 1;
		my $specialEvent_href;
		foreach my $specialEventRecord (@{$tcpar_Record_Compared_SpecialEvent_aref}){
			$specialEvent_href -> {"Record_$specialEventRecord"} = 1;
		}

		if ( lc($tcpar_read_CHINAEDR) eq 'yes' ) {
			my $recordNumber;
			for ($recordNumber = $tcpar_NumberOfRecordsExpected; $recordNumber >= 1; $recordNumber = $recordNumber-1 ) {
				next if ( defined $specialEvent_href->{"Record_$recordNumber"} );

				S_teststep( "Validate Fire times in record $recordNumber (regular event)", 'AUTO_NBR' );

				my ( $squibVerdict, $allResults_href ) = EDR_Eval_SquibFireTimes(
					"CrashLabel"               => $tcpar_Crashcode,
					"EDID_SquibLabels"         => $tcpar_FireTime_EDIDs,
					"CrashTimeZero_ms"         => $tcpar_CrashT0_ms,
					"RecordNumber"             => $recordNumber,
					"MultiEventIncidentNumber" => $regularIncidentNumber,
					"FireTimeTolerance_ms"     => $tcpar_EvalTolerance_abs,
				);
				$regularIncidentNumber++;
			}

		}
		else {
			foreach my $recordNumber ( 1 .. $tcpar_NumberOfRecordsExpected ) {
				next if ( defined $specialEvent_href->{"Record_$recordNumber"} );

				S_teststep( "Validate Fire times in record $recordNumber (regular event)", 'AUTO_NBR' );

				my ( $squibVerdict, $allResults_href ) = EDR_Eval_SquibFireTimes(
					"CrashLabel"               => $tcpar_Crashcode,
					"EDID_SquibLabels"         => $tcpar_FireTime_EDIDs,
					"CrashTimeZero_ms"         => $tcpar_CrashT0_ms,
					"RecordNumber"             => $recordNumber,
					"MultiEventIncidentNumber" => $regularIncidentNumber,
					"FireTimeTolerance_ms"     => $tcpar_EvalTolerance_abs,
				);
				$regularIncidentNumber++;
			}
		}
	}
	else {
		S_w2rep("No regular event in this crash scenario.");
	}

	#--------------------------------------------------------------
    # Compare EDID for multi event and Time from previous to current event
    #
    S_w2rep("");
    S_w2rep("--------------------------------------------------------", 'purple');
    S_w2rep("MULTI-EVENT NUMBER AND TIME", 'purple');
    foreach my $recordNumber (1..$tcpar_NumberOfRecordsExpected)
	{
		S_w2rep("Record $recordNumber EDID validation",'BLUE');
		$tcpar_CompareValues_CT = $tcpar_CompareValues_CT1 if ($recordNumber == 1);
		$tcpar_CompareValues_CT = $tcpar_CompareValues_CT2 if ($recordNumber == 2);
		$tcpar_CompareValues_CT = $tcpar_CompareValues_CT3 if ($recordNumber == 3);
		$tcpar_CompareValues_CT = $tcpar_CompareValues_CT4 if ($recordNumber == 4);
		$tcpar_CompareValues_CT = $tcpar_CompareValues_CT5 if ($recordNumber == 5);
		$tcpar_CompareValues_CT = $tcpar_CompareValues_CT6 if ($recordNumber == 6);
		
		if(not defined $tcpar_CompareValues_CT){
			S_set_error("No expected values provided for record $recordNumber!");
			next;
		}

		foreach my $rawEDID ( keys %{$tcpar_CompareValues_CT} ) {
			my $dataElement = $record_handler->GetDataElementEDID(
				"EDIDnr"       => $rawEDID,
				"RecordNumber" => $recordNumber,
				"CrashLabel"   => $tcpar_Crashcode
			);
			S_teststep( "Validate EDID $rawEDID ($dataElement) in record $recordNumber", 'AUTO_NBR', "EDID_$rawEDID\_record_$recordNumber" );

			my $edidData      = $record_handler->GetDecodedEDID( "CrashLabel" => $tcpar_Crashcode, "RecordNumber" => $recordNumber, "EDIDnr" => $rawEDID );
			my $detectedValue = $edidData->{"DataValue"};
			my $unit          = $edidData->{"ValueUnit"};

			unless ( defined $detectedValue ) {
				S_set_error("No data could be obtained for EDID $rawEDID in record $recordNumber.");
				next;
			}
		
            my $expectedValue = $tcpar_CompareValues_CT -> {$rawEDID};
            if($detectedValue =~ /[a-zA-Z]/) {
                EVAL_evaluate_string ( "EDID_$rawEDID\_Evaluation", $expectedValue, $detectedValue );
                S_teststep_expected("$expectedValue", "EDID_$rawEDID\_record_$recordNumber"); #evaluation 2
                S_teststep_detected("$detectedValue ($unit)", "EDID_$rawEDID\_record_$recordNumber"); #evaluation 2
            }
			elsif ($expectedValue eq "TimeGreaterThanZero"){
			    $expectedValue = 0;
				EVAL_evaluate_value ( "EDID_$rawEDID\_Evaluation", $detectedValue,'>', $expectedValue ) if ( lc( $tcpar_read_NHTSAEDR) eq 'yes');
				EVAL_evaluate_value ( "EDID_$rawEDID\_Evaluation", $detectedValue,'>=', $expectedValue ) if ( lc( $tcpar_read_CHINAEDR) eq 'yes');
                S_teststep_expected("Time > 0", "EDID_$rawEDID\_record_$recordNumber"); #evaluation 2
                S_teststep_detected("$detectedValue ($unit)", "EDID_$rawEDID\_record_$recordNumber"); #evaluation 2
			}
			else{
				EVAL_evaluate_string ( "EDID_$rawEDID\_Evaluation", $expectedValue, $detectedValue );
                S_teststep_expected("$expectedValue", "EDID_$rawEDID\_record_$recordNumber"); #evaluation 2
                S_teststep_detected("$detectedValue ($unit)", "EDID_$rawEDID\_record_$recordNumber"); #evaluation 2
			}
		}
	}

	if ($tcpar_AlgoEDIDSupported eq 'yes')
	{
		#--------------------------------------------------------------
		# Compare time from zero to deployment for special event in particular record
		#
		S_w2rep("");
		S_w2rep( "--------------------------------------------------------", 'purple' );
		S_w2rep( "ALGO ACTIVATION SPECIAL EVENT",                            'purple' );
		foreach my $recordNbr ( @{$tcpar_Record_Compared_SpecialEvent_aref} ) {
			foreach my $rawEDID ( keys %{$tcpar_CompareValue_SpecialEvent} ) {
				my $dataElement = $record_handler->GetDataElementEDID(
					"EDIDnr"       => $rawEDID,
					"RecordNumber" => $recordNbr,
					"CrashLabel"   => $tcpar_Crashcode
				);

				S_teststep( "Validate EDID $rawEDID ($dataElement) in record $recordNbr", 'AUTO_NBR', "EDID_$rawEDID\_record_$recordNbr" );

				my $edidData = $record_handler->GetDecodedEDID( "CrashLabel" => $tcpar_Crashcode, "RecordNumber" => $recordNbr, "EDIDnr" => $rawEDID );
				my $detectedValue = $edidData->{"DataValue"};
				unless ( defined $detectedValue ) {
					S_set_error("No data could be obtained for EDID $rawEDID in record $recordNbr.");
					next;
				}
				
	            my $expectedValue = $tcpar_CompareValue_SpecialEvent -> {$rawEDID};
	            my $compareOperator;
	
				if($detectedValue =~ /[a-zA-Z]/) {
	                EVAL_evaluate_string ( "EDID_$rawEDID\_Evaluation", $expectedValue, $detectedValue );
	                $compareOperator = '='; #only for teststep handling
				}
				else{
	                if ($expectedValue eq "TimeGreaterThanZero"){
	                    $expectedValue = 0;
	                    $compareOperator = '>' if ( lc( $tcpar_read_NHTSAEDR) eq 'yes' );
						$compareOperator = '>=' if ( lc( $tcpar_read_CHINAEDR) eq 'yes' );
	                }
	                else {
	                    $compareOperator = '==';
	                }
	                EVAL_evaluate_value ( "EDID_$rawEDID\_Evaluation", $detectedValue,$compareOperator, $expectedValue );
				}
				S_teststep_expected("$compareOperator $expectedValue", "EDID_$rawEDID\_record_$recordNbr");
	            S_teststep_detected("$detectedValue", "EDID_$rawEDID\_record_$recordNbr");
			}
	    }
	}
	#--------------------------------------------------------------
	# Compare fire times in extended event data record.
	#
	if ( defined $tcpar_Event_Extended ) {
		S_w2rep("");
		S_w2rep( "--------------------------------------------------------", 'purple' );
		S_w2rep( "EXTENDED EVENT RECORD",                                    'purple' );
		foreach my $rawEDID ( keys %{$tcpar_CompareValues_Extended} ) {
			my $dataElement = $record_handler->GetDataElementEDID(
				"EDIDnr"       => $rawEDID,
				"RecordNumber" => $tcpar_Record_Compared_Extended,
				"CrashLabel"   => $tcpar_Crashcode
			);

			S_teststep( "EDID $rawEDID ($dataElement) in record $tcpar_Record_Compared_Extended (Extended record)", 'AUTO_NBR', "EDID_$rawEDID\_Extended" );

			my $edidData = $record_handler->GetDecodedEDID(
				"CrashLabel"   => $tcpar_Crashcode,
				"RecordNumber" => $tcpar_Record_Compared_Extended,
				"EDIDnr"       => $rawEDID
			);
			my $detectedValue = $edidData->{"DataValue"};

			unless ( defined $detectedValue ) {
				S_set_error("No data could be obtained for EDID $rawEDID in record $tcpar_Record_Compared_Extended.");
				next;
			}
					
            my $expectedValue = $tcpar_CompareValues_Extended -> {$rawEDID};
            my $compareOperator;
            if($detectedValue =~ /[a-zA-Z]/) {
                EVAL_evaluate_string ( "EDID_$rawEDID\_Evaluation", $expectedValue, $detectedValue );
                $compareOperator = '='; #only for teststep handling
            }
            else{
                if ($expectedValue eq "FireTimeGreaterThanZero"){
                    $expectedValue = 0;
                    $compareOperator = '>' if ( lc( $tcpar_read_NHTSAEDR) eq 'yes' );
					$compareOperator = '>=' if ( lc( $tcpar_read_CHINAEDR) eq 'yes' );
                    EVAL_evaluate_value ( "EDID_$rawEDID\_Evaluation", $detectedValue,$compareOperator, $expectedValue );
                }
                elsif($expectedValue =~ /[a-zA-Z]/) {
                    EVAL_evaluate_string ( "EDID_$rawEDID\_Evaluation", $expectedValue, $detectedValue );
                }
                else{
                    $compareOperator = '==';
                    EVAL_evaluate_value ( "EDID_$rawEDID\_Evaluation", $detectedValue,$compareOperator, $expectedValue );
                }
            }
            S_teststep_expected("$compareOperator $expectedValue", "EDID_$rawEDID\_Extended");
            S_teststep_detected("$detectedValue", "EDID_$rawEDID\_Extended");          
		}
	}

	return 1;
}

sub TC_finalization {

	S_w2rep("Start test case finalization...");
	
	S_w2rep("Clean up record and crash handler");
    $record_handler -> DeleteAllRecords();
    $crash_handler -> DeleteAllSources();
	
	# Erase EDR
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(2000);

	# Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	# Read fault memory after clearing and erasing EDR
    LIFT_FaultMemory -> read_fault_memory('Bosch');

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');
	return 1;
}


1;
