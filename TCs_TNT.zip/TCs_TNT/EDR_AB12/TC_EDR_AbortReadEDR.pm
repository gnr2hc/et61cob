#### TEST CASE MODULE
package TC_EDR_AbortReadEDR;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use INCLUDES_Project;

#include further modules here
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_FaultMemory;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use GENERIC_DCOM;
use LIFT_can_access;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;

use Data::Dumper;

##################################

our $PURPOSE = "<This test script tests for abort of EDR data reporting when crash is injected at same time";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_AbortReadEDR

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Inject crash <crashcode>.

2. Wait <wait_ms>

3. Send diag service Read EDR

4. Inject crash <crashcode>.


I<B<Evaluation>>

1. -

2. -

3. Diag response must be invalid or incomplete due to crash injection in step

<Response> is obtained 4.

4. -


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'crashcode' => 
	SCALAR 'DiagType' => 
	SCALAR 'NbrOfRecordsExpected' => 
	SCALAR 'wait_ms' => 
	SCALAR 'Response' => 


=head2 PARAMETER EXAMPLES

# ---------- Stimulation ------------ 
crashcode = 'Single_EDR_Front_Inflatable'
DiagType = 'ProdDiag'
NbrOfRecordsExpected='1'
wait_ms = 10000 #ms
ResultDB='EDR'

# ---------- Evaluation ------------ 
Response = 'Truncated_Response'  #Conditions not correct

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Crashcode;
my $tcpar_NbrOfRecordsExpected;
my $tcpar_wait_ms;
my $tcpar_ResultDB;

################ global parameter declaration ###################
#add any global variables here
my ( $crashSettings, $response_aref, $Detected_ResponseLength_Normal, $Detected_ResponseLength_Abort );

###############################################################

sub TC_set_parameters {

	$tcpar_purpose              = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_Crashcode            = S_read_mandatory_testcase_parameter('crashcode');
	$tcpar_NbrOfRecordsExpected = S_read_mandatory_testcase_parameter('NbrOfRecordsExpected');
	$tcpar_wait_ms              = S_read_mandatory_testcase_parameter('wait_ms');
	$tcpar_ResultDB             = S_read_optional_testcase_parameter('ResultDB');

	return 1;
}

sub TC_initialization {

	S_teststep( "Test setup preparation", 'AUTO_NBR' );

	#--------------------------------------------------------------
	# PREPARE CRASH AND INITIALIZE EQUIPMENT
	#
	S_w2rep("Get crash settings for crash $tcpar_Crashcode");
	my $crashDetails_href = { "RESULTDB" => $tcpar_ResultDB, 'CRASHNAME' => $tcpar_Crashcode };
	$crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
	unless ( defined $crashSettings ) {
		S_set_error("Crash $tcpar_Crashcode not available in result DB $tcpar_ResultDB. Test case aborted.");
		return;
	}

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log( 1, "Crashcode: $tcpar_Crashcode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)" );

	S_w2log( 1, "Power on ECU" );
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	S_w2log( 1, "Initialize CD and start CAN trace" );
	GDCOM_init();    # To fetch info for CD from mapping_diag
	CA_trace_start();

	S_w2log( 1, "Set environments for crash as per result DB" );
	CSI_PrepareEnvironment( $crashSettings, 'init_complete' );
	S_wait_ms(2000);

	S_w2log( 1, "Clear crash recorder" );
	PRD_Clear_EDR_NOERROR( { timeout_ms => 'TIMER_CLEAR_CRASH_RECORDER' } );
	S_wait_ms(2000);

	S_w2log( 1, "Clear fault memory" );
	PRD_Clear_Fault_Memory();
	S_wait_ms(2000);

	S_w2log( 1, "Read and evaluate fault memory before stimulation" );
	my $faultsBeforeStimulation_obj = LIFT_FaultMemory->read_fault_memory('Primary');

	#Fault memory must be empty
	my $faultsVerdict = $faultsBeforeStimulation_obj->evaluate_faults( {} );
	return 0 unless ( $faultsVerdict eq 'VERDICT_PASS' );

	return 1;
}

sub TC_stimulation_and_measurement {

	#--------------------------------------------------------------
	# CRASH PREPARATION
	#

	# Prepare crash
	S_teststep( "Prepare crash", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	# Prepare crash
	CSI_LoadCrashSensorData2Simulator($crashSettings);

	# Power ON the ECU
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');
	PRD_ECU_Login();

	CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle', 'normal' );
	S_wait_ms(1000);

	#--------------------------------------------------------------
	# CRASH INJECTION 1
	#

	S_teststep( "Inject first '$tcpar_Crashcode'.", 'AUTO_NBR' );
	CSI_TriggerCrash();

	S_teststep( "Wait '$tcpar_wait_ms'", 'AUTO_NBR' );
	S_wait_ms($tcpar_wait_ms);

	S_teststep( "Read EDR via PD in normal condition", 'AUTO_NBR', 'PD_read_crashrecorder_normal' );    #measurement 1
	my $response_href = PRD_Read_EDR( 0, { date_time_in_file_name => 0 } );
	if ( not defined $response_href ) {
		$response_href = PRD_Get_Last_Response();
	}
	my $response_aref = $response_href->{CompletePdMsg};
	$response_aref = [1] if ($main::opt_offline);
	$Detected_ResponseLength_Normal = @{$response_aref};
	S_w2rep("Detected Response length in normal condition = $Detected_ResponseLength_Normal");

	#--------------------------------------------------------------
	# CRASH INJECTION 2
	#

	# Prepare crash
	S_teststep( "Prepare crash second time", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	# Prepare crash
	CSI_LoadCrashSensorData2Simulator($crashSettings);

	CA_trace_start();

	# Power ON the ECU
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');
	PRD_ECU_Login();

	S_teststep( "Inject second  crash '$tcpar_Crashcode'.", 'AUTO_NBR' );
	CSI_TriggerCrash();

	S_teststep( "Read EDR via PD in abort condition", 'AUTO_NBR', 'PD_read_crashrecorder_abort' );    #measurement 2
	my $response_href = PRD_Read_EDR_NOERROR( 0, { date_time_in_file_name => 0 } );
	if ( not defined $response_href ) {
		$response_href = PRD_Get_Last_Response();
	}

	my $response_aref = $response_href->{CompletePdMsg};
	$response_aref = [1] if ($main::opt_offline);
	$Detected_ResponseLength_Abort = @{$response_aref};

	S_w2rep("Detected Response length in abort condition = $Detected_ResponseLength_Abort");

	S_wait_ms(15000);

	my $dataStoragePath = "$main::REPORT_PATH/" . S_get_TC_number() . "_AbortReadEdr_" . $tcpar_Crashcode;
	mkdir($dataStoragePath);
	CA_trace_store( "$main::REPORT_PATH/" . S_get_TC_number() . "_AbortReadEdr_" . $tcpar_Crashcode . "/Canoe_Trace_DuringCrash.asc" );

	return 1;
}

sub TC_evaluation {

	S_teststep_expected( "Diag response must be incomplete due to crash injection, i.e. < $Detected_ResponseLength_Normal bytes", 'PD_read_crashrecorder_abort' );    #evaluation 2
	S_teststep_detected( "$Detected_ResponseLength_Abort bytes", 'PD_read_crashrecorder_abort' );

	if ( $Detected_ResponseLength_Abort < $Detected_ResponseLength_Normal ) {
		S_w2rep("Detected Response length in abort condition is less than Detected Response length in normal condition");
		S_set_verdict('VERDICT_PASS');
	}
	else {
		S_w2rep("Detected Response length in abort condition is same as Detected Response length in normal condition");
		S_set_verdict('VERDICT_FAIL');
	}

	return 1;
}

sub TC_finalization {

	# Erase EDR
	PRD_Clear_EDR_NOERROR( { timeout_ms => 'TIMER_CLEAR_CRASH_RECORDER' } );
	S_wait_ms(2000);

	# Erase Fault memory
	PRD_Clear_Fault_Memory();
	S_wait_ms(10000);

	# Read fault memory after clearing and erasing EDR
	LIFT_FaultMemory->read_fault_memory('Primary');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	return 1;
}

1;
