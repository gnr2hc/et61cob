#### TEST CASE MODULE
package TC_EDR_Basic;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
#include further modules here
use LIFT_crash_simulation;
use LIFT_can_access;
use LIFT_labcar;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use GENERIC_DCOM;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;
use Data::Dumper;

##################################

our $PURPOSE = "<summarize what this test is good for>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_Basic_General

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFaultNoCT


I<B<Stimulation and Measurement>>

1. Set environments for crash.

2. Power up ECU

3. Start recording of fire times.

4. Inject <Crashtype> and cut power at T0 if <CrashCondition> is Autarky.

5. Wait for <WaitTime_ms>

6. Stop recording of fire times

7. Power down ECU

8. Power up ECU

9. Read EDR

10. Compare Deployment_EDIDs to LCT measurement.

11. Compare Switch_EDIDs to stored switch states.

12. Compare all other EDIDs to <ExpectedValueRaw>


I<B<Evaluation>>

1. - 

2. - 

3. - 

4. -

5. - 

6. - 

7. - 

8. - 

9. Check that number of stored records is as expected.

10. Deployment times stored in EDR are as measured.

11. Switch states stored in EDR are as set during crash.

12. Value of <EDIDs> is as expected.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'Crashcode' => 
	SCALAR 'CrashTimeZero_ms' => 
	SCALAR 'ResultDB' => 
	SCALAR 'WaitTime_ms' => 
	SCALAR 'NbrOfRecordsExpected' => 
	SCALAR 'DiagType' => 


=head2 PARAMETER EXAMPLES

	purpose = 'Inject <Test Heading Tail> crash and evaluate record with respect to <Test Heading Head>' # description of test case
	
	# ---------- Stimulation ------------ 
	Crashcode = 'Single_EDR_Front_Inflatable' # valid crash code from .mdb
	CrashTimeZero_ms = '11.76' #given in crash list
	ResultDB = 'EDR' # defined in CREIS project constants - will be set to 'DEFAULT' if not given
	
	WaitTime_ms = 15000
	
	# ---------- Evaluation ------------ 
	NbrOfRecordsExpected = 1
	DiagType = 'ProdDiag'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Crashcode;
my $tcpar_CrashTimeZero_ms;
my $tcpar_ResultDB;
my $tcpar_WaitTime_ms;
my $tcpar_NbrOfRecordsExpected;
my $tcpar_DiagType;
my $tcpar_CrashCondition;
my $tcpar_ExpectedValueRaw;
my $tcpar_ExpectedValueRaw_EDIDs;
my $tcpar_LCT_EDIDs;
my $tcpar_Switch_EDIDs;
my $tcpar_NonDefault_EDIDs;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_FireTimeTolerance_ms;
my $tcpar_read_NHTSAEDR;
my $tcpar_read_CHINAEDR;

################ global parameter declaration ###################
#add any global variables here
my ($ChinaEDR_diagType,$record_handler, $crash_handler, $crashSettings, $edrNumberOfEventsToBeStored);

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_Crashcode =  S_read_mandatory_testcase_parameter( 'Crashcode' );
	$tcpar_CrashTimeZero_ms =  S_read_mandatory_testcase_parameter( 'CrashTimeZero_ms' );
	$tcpar_WaitTime_ms =  S_read_mandatory_testcase_parameter( 'WaitTime_ms' );
	$tcpar_NbrOfRecordsExpected =  S_read_mandatory_testcase_parameter( 'NbrOfRecordsExpected' );
	$tcpar_DiagType =  S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_read_NHTSAEDR=S_read_optional_testcase_parameter('read_NHTSAEDR');
	$tcpar_read_CHINAEDR=S_read_optional_testcase_parameter('read_CHINAEDR');
	$tcpar_ResultDB =  S_read_optional_testcase_parameter( 'ResultDB' );
	$tcpar_ResultDB = 'DEFAULT' unless(defined $tcpar_ResultDB);
	$tcpar_CrashCondition =  S_read_optional_testcase_parameter( 'CrashCondition' );
	$tcpar_ExpectedValueRaw =  S_read_optional_testcase_parameter( 'ExpectedValueRaw' );
	$tcpar_ExpectedValueRaw_EDIDs =  S_read_optional_testcase_parameter( 'ExpectedValueRaw_EDIDs', 'byref' );
	$tcpar_LCT_EDIDs =  S_read_optional_testcase_parameter( 'LCT_EDIDs', 'byref' );
    $tcpar_FireTimeTolerance_ms = S_read_optional_testcase_parameter( 'FireTimeTolerance_ms' );
    if(not defined $tcpar_FireTimeTolerance_ms){
        S_w2rep("Set fire time tolerance to default value: 3ms");
        $tcpar_FireTimeTolerance_ms = 3;
    }
	$tcpar_Switch_EDIDs =  S_read_optional_testcase_parameter( 'Switch_EDIDs', 'byref' );

	$tcpar_NonDefault_EDIDs = S_read_optional_testcase_parameter( 'NonDefault_EDIDs', 'byref' );
	$tcpar_COMsignalsAfterCrash =  S_read_optional_testcase_parameter( 'COMsignalsAfterCrash','byref');
	
	if(not defined $tcpar_read_CHINAEDR) {
		$tcpar_read_NHTSAEDR = 'yes';
		$tcpar_read_CHINAEDR = 'no';
	}
	else {
		$tcpar_read_NHTSAEDR = 'no';
		my $storageOrder = EDR_getStorageOrder();
		return unless(defined $storageOrder);

		if($storageOrder eq 'PhysicalOrder'){
			$ChinaEDR_diagType= 'ProdDiag';  #In platform NHTSA and China EDR is read via proddiag
		}
		else {
			$ChinaEDR_diagType= 'CHINA_Payload';
		}
	}
	
	return 1;
}

sub TC_initialization {

	S_teststep("Test setup preparation", 'AUTO_NBR');

	#--------------------------------------------------------------
    # INITIALIZE RECORD AND CRASH HANDLER
    #    
	S_w2rep("Initialize Record and Crash Handler");
	$record_handler = EDR_init_RecordHandler() || return;
	$crash_handler  = EDR_init_CrashHandler() || return;

	#--------------------------------------------------------------
    # PREPARE CRASH AND INITIALIZE EQUIPMENT
    #
	S_w2rep("Get crash settings for crash $tcpar_Crashcode");
    my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode};
	$crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
	unless(defined $crashSettings) {
		S_set_error("Crash $tcpar_Crashcode not available in result DB $tcpar_ResultDB. Test case aborted.");
		return;
	}

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log(1, "Crashcode: $tcpar_Crashcode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");

	S_w2log(1, "Power on ECU");
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

    S_w2log(1, "Initialize CD and start CAN trace");
    GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start ( );
 
	S_w2log(1, "Set environments for crash as per result DB");
	CSI_PrepareEnvironment($crashSettings, 'init_complete');
	S_wait_ms(2000);

	S_w2log(1, "Clear crash recorder");
    PD_ClearCrashRecorder();
    S_wait_ms(2000);

	S_w2log(1, "Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	S_w2log(1, "Reset ECU");
    PD_ECUreset();
    S_wait_ms('TIMER_ECU_READY');

	S_w2log(1, "Read and evaluate fault memory before stimulation");
    my $faultsBeforeStimulation = PD_ReadFaultMemory();
    my $faultsVerdict = PD_evaluate_faults( $faultsBeforeStimulation, []);
  	return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

	return 1;
}

sub TC_stimulation_and_measurement {

	#--------------------------------------------------------------
    # CRASH PREPARATION
    #
	S_teststep("Prepare crash", 'AUTO_NBR');
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	# Prepare crash
	CSI_LoadCrashSensorData2Simulator($crashSettings);

	# Power ON the ECU
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    S_wait_ms(1000);
	#--------------------------------------------------------------
    # CRASH INJECTION
    #
	S_teststep("Start recording of fire times.", 'AUTO_NBR');
    LC_MeasureTraceDigitalStart();

	S_teststep("Inject '$tcpar_Crashcode'", 'AUTO_NBR');
	CSI_TriggerCrash();
	if ($tcpar_CrashCondition eq 'Autarky') {
        S_teststep("Wait until T0 and turn off ECU (Autarky condition)", 'AUTO_NBR');
		S_wait_ms($tcpar_CrashTimeZero_ms);
		LC_ECU_Off();
	}

	S_teststep("Wait for '$tcpar_WaitTime_ms' ms", 'AUTO_NBR');
    S_wait_ms($tcpar_WaitTime_ms);

	S_teststep("Stop recording of fire times", 'AUTO_NBR');
    LC_MeasureTraceDigitalStop();

	S_teststep("Power down ECU", 'AUTO_NBR');
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep("Power up ECU", 'AUTO_NBR');
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');
	if (defined $tcpar_COMsignalsAfterCrash){
		foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
		{				
			my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
			S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
			COM_setSignalState($signal,$dataOnCOM);	
		}
	}
	S_wait_ms(2000);

	#--------------------------------------------------------------
    # MEASUREMENTS
    #
	S_teststep("Read all stored EDR records", 'AUTO_NBR', 'read_edr'); #measurement 1
    my $dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_".$tcpar_Crashcode;

	$edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();

	PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');

	if ( lc( $tcpar_read_NHTSAEDR) eq 'yes' ) {
		EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
								"CrashLabel" => $tcpar_Crashcode,
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								"read_EDRType"=>'NHTSA')
	}
	if (lc($tcpar_read_CHINAEDR) eq 'yes'){
		$edrNumberOfEventsToBeStored=3;
		EDR_ReadAndStoreAllRecords ("DiagType" =>  $ChinaEDR_diagType,
								"CrashLabel" => $tcpar_Crashcode,
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								"read_EDRType"=>'CHINA');
	
	}	

    my $lct_Data = LC_MeasureTraceDigitalGetValues();
	EVAL_dump2UNV( $lct_Data, "$dataStoragePath/LCT_Measurement_$tcpar_Crashcode.txt.unv" );

	if(defined $tcpar_LCT_EDIDs) {

		# Get list of all measured squib labels
	    my $squibLabels_aref;
		foreach my $lctEDID (keys %{$tcpar_LCT_EDIDs})
		{
			push(@{$squibLabels_aref}, $tcpar_LCT_EDIDs -> {$lctEDID});
		}

		EDR_addFireTimesToCrashHandler ("LCT_Measurement" => $lct_Data,
										"SquibLabels" => $squibLabels_aref,
										"CrashLabel"  => $tcpar_Crashcode,
										"StoragePath" => $dataStoragePath);
	}

	if(defined $tcpar_Switch_EDIDs) {
		my $crashDetails_href = MDSRESULT_GetCrashDetails( {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode} , NO_FILTERING);

		foreach my $switchEDID (keys %{$tcpar_Switch_EDIDs})
		{
			my $switchLabel = $tcpar_Switch_EDIDs -> {$switchEDID};
			my $switchStateMDS;
		    $switchStateMDS = MDSRESULT_GetStateOfEnvVariable($crashDetails_href, "Switch_$switchLabel\_State") unless $main::opt_offline;
		    if ($main::opt_offline) {
		    	$switchStateMDS = 1;
		    }

			my $switchStatePhysical;
			if($switchStateMDS == 0) {
				S_w2log(4, "Switch $switchLabel in PositionA (state 0)", 'AUTO_NBR');
				$switchStatePhysical = 'PositionA';
			}
			elsif ($switchStateMDS == 1) {
				$switchStatePhysical = 'PositionB';
				S_w2log(4, "Switch $switchLabel in PositionB (state 1)");
			}
			elsif ($switchStateMDS == 2) {
				$switchStatePhysical = 'Undefined';
				S_w2log(4, "Switch $switchLabel is Undefined (state 2)");
			}
			elsif ($switchStateMDS == 3) {
				$switchStatePhysical = 'Openline';
				S_w2log(4, "Switch $switchLabel is not connected (state 3)");
			}
			else {
				S_w2rep("Switch state for $switchLabel will be set to 'n/a'.State $switchStateMDS is not known.", 'AUTO_NBR');
				$switchStatePhysical = 'n/a';
			}

			# Add switch to crash handler
			S_w2rep("Adding switch $switchLabel with state $switchStatePhysical to crash handler");
			$crash_handler -> AddCrashSource(  "CrashLabel" => $tcpar_Crashcode,
											   "SourceType" => 'Switch',
	                                           "SourceLabel" => $switchLabel,
	                                           "OriginalSourceData" => $switchStatePhysical );
		}
	}

	return 1;
}

sub TC_evaluation {

	#--------------------------------------------------------------
    # NUMBER OF EXPECTED RECORDS
    #
	S_w2rep("");
	S_w2rep("NUMBER OF EXPECTED RECORDS", 'blue');
	S_teststep_expected("$tcpar_NbrOfRecordsExpected records stored", 'read_edr'); #evaluation 1
	my $verdict_NbrOfRecords = 'VERDICT_PASS';
	my $detectedNbrOfStoredRecords = 0;
	for(my $recordNumber = 1; $recordNumber <= $edrNumberOfEventsToBeStored; $recordNumber++)
	{
	 	my $recordAvailable = $record_handler -> IsRecordAvailable("CrashLabel" => $tcpar_Crashcode, "RecordNumber"=> $recordNumber);
	 	if($recordNumber <= $tcpar_NbrOfRecordsExpected) {
	 		if ($recordAvailable) {
	 			$detectedNbrOfStoredRecords++;
	 			S_set_verdict('VERDICT_PASS');
	 		}
	 		else {
	 			S_set_verdict('VERDICT_FAIL');
	 			$verdict_NbrOfRecords = 'VERDICT_FAIL';
	 		}
	 	}
	 	elsif($recordNumber > $tcpar_NbrOfRecordsExpected) {
	 		if ($recordAvailable) {
	 			$detectedNbrOfStoredRecords++;
	 			S_set_verdict('VERDICT_FAIL');
	 			$verdict_NbrOfRecords = 'VERDICT_FAIL';
	 		}
	 		else {
	 			S_set_verdict('VERDICT_PASS');
	 		}
	 	}
	}
	S_teststep_detected("$detectedNbrOfStoredRecords records stored", 'read_edr');

	#--------------------------------------------------------------
    # FIRE TIMES
    #
	if(defined $tcpar_LCT_EDIDs) {
		S_w2rep("");
        S_teststep("Compare Deployment_EDIDs to measurement.", 'AUTO_NBR', 'compare_deployment_edids'); #measurement 2
		my $squibVerdict = EDR_Eval_SquibFireTimes("CrashLabel" => $tcpar_Crashcode,
		                                           "EDID_SquibLabels" => $tcpar_LCT_EDIDs,
		                                           "CrashTimeZero_ms" => $tcpar_CrashTimeZero_ms,
		                                           "FireTimeTolerance_ms" => $tcpar_FireTimeTolerance_ms);
	}

	#--------------------------------------------------------------
    # SWITCH STATES
    #
	if(defined $tcpar_Switch_EDIDs) {
		my $switchVerdict = 'VERDICT_PASS';

        my $switchStateMapping = S_get_contents_of_hash_NOERROR(['Mapping_EDR', 'SwitchStates']);
        my $edrSwitchStates_href;
        if(defined $switchStateMapping){
	       foreach my $specifiedSwitchState (sort keys %{$switchStateMapping}){
	        	foreach my $edrSwitchState (@{$switchStateMapping -> {$specifiedSwitchState}}){
	        		$edrSwitchStates_href -> {$edrSwitchState} = $specifiedSwitchState;
	        	}
	        }        	
        }


		S_w2rep("");
        S_teststep("Validate switch states in EDR", 'AUTO_NBR', 'compare_switch_edids'); #measurement 3
		foreach my $switchEDID (keys %{$tcpar_Switch_EDIDs})
		{
			my $switchLabel = $tcpar_Switch_EDIDs -> {$switchEDID};

			S_w2log(1, "Get expected switch state for '$switchLabel' in crash $tcpar_Crashcode");
			my $sourceData = $crash_handler -> GetSourceDataSamples ( "SourceLabel" => $switchLabel,
																	  "CrashLabel"  => $tcpar_Crashcode );

			unless(defined $sourceData) {
				S_w2rep("No switch state data found for crash $tcpar_Crashcode. EDID will not be evaluated. Go to next crash");
				next;
			}

			my $expectedSwitchState = $sourceData -> {'DataValues'};
			for(my $recordNumber = 1; $recordNumber <= $tcpar_NbrOfRecordsExpected; $recordNumber ++)
			{
                S_teststep_2nd_level("Record $recordNumber: $switchLabel state", 'AUTO_NBR', "Record_$recordNumber\_switch_$switchLabel");

				S_w2log(1, "Get EDID data for switch '$switchLabel' from crash $tcpar_Crashcode, Record $recordNumber");
		        my $edidData = $record_handler -> GetDecodedEDID("CrashLabel" => $tcpar_Crashcode,
		                                                         "RecordNumber" => $recordNumber,
		                                                         "EDIDnr" => $switchEDID );

				unless(defined $edidData) {
					S_w2rep("No EDID data found for crash $tcpar_Crashcode. EDID will not be evaluated.");
					$switchVerdict = 'VERDICT_FAIL';
					next;
				}

				my $detectedSwitchState = $edidData -> {'DataValue'};
				if(defined $edrSwitchStates_href -> {$detectedSwitchState}){
					$detectedSwitchState = $edrSwitchStates_href -> {$detectedSwitchState};
				}

                S_teststep_expected("$expectedSwitchState", "Record_$recordNumber\_switch_$switchLabel");
                S_teststep_detected("$detectedSwitchState", "Record_$recordNumber\_switch_$switchLabel");
		        my $verdict = EVAL_evaluate_string ( $switchLabel, $expectedSwitchState, $detectedSwitchState );
			}

		}
	}

	#--------------------------------------------------------------
    # RAW VALUES
    #
	if(defined $tcpar_ExpectedValueRaw_EDIDs) {
		S_w2rep("");
        S_teststep("Validate EDID raw values", 'AUTO_NBR', 'compare_all_other'); #measurement 4

		foreach my $rawEDID (keys %{$tcpar_ExpectedValueRaw_EDIDs})
		{
			my $expectedRawValue = $tcpar_ExpectedValueRaw_EDIDs -> {$rawEDID};
			my $dataElement = $record_handler -> GetDataElementEDID( "EDIDnr" => $rawEDID, "RecordNumber" => 1,
															      "CrashLabel" => $tcpar_Crashcode);

			for(my $recordNumber = 1; $recordNumber <= $tcpar_NbrOfRecordsExpected; $recordNumber ++)
			{

               S_teststep_2nd_level("Record $recordNumber: EDID $rawEDID ($dataElement)",'AUTO_NBR', "Record_$recordNumber\_EDID_$rawEDID");

				S_w2log(1, "Get EDID data for $tcpar_Crashcode, Record $recordNumber");
				my $detectedEDIDvalue = $record_handler -> GetRawEDID( "EDIDnr" => $rawEDID,
	                                                   "RecordNumber" => $recordNumber,
	                                                   "CrashLabel" => $tcpar_Crashcode,
	                                                   "FormatOption" => "HEX");

				$detectedEDIDvalue = 'FF' if($main::opt_offline);

				unless(defined $detectedEDIDvalue) {
					S_set_error("No data could be obtained for EDID $rawEDID.");
					next;
				}

                S_teststep_expected("$expectedRawValue", "Record_$recordNumber\_EDID_$rawEDID");
                S_teststep_detected("$detectedEDIDvalue", "Record_$recordNumber\_EDID_$rawEDID");
		        my $verdict = EVAL_evaluate_string ( "EDID_$rawEDID\_Evaluation", $expectedRawValue, $detectedEDIDvalue );
			}
		}
	}

	#--------------------------------------------------------------
    # NON DEFAULT VALUES
    #
	if(defined $tcpar_NonDefault_EDIDs) {
		S_w2rep("");
        S_teststep("Validate non-default value in EDIDs", 'AUTO_NBR', 'compare_all_nonDefault'); #measurement 5

		foreach my $nonDefaultEDID (keys %{$tcpar_NonDefault_EDIDs})
		{
			my $defaultValue = $tcpar_NonDefault_EDIDs -> {$nonDefaultEDID};
			my $dataElement = $record_handler -> GetDataElementEDID( "EDIDnr" => $nonDefaultEDID, "RecordNumber" => 1,
															      "CrashLabel" => $tcpar_Crashcode);

			for(my $recordNumber = 1; $recordNumber <= $tcpar_NbrOfRecordsExpected; $recordNumber ++)
			{

                S_teststep_2nd_level("Record $recordNumber: EDID $nonDefaultEDID ($dataElement) non default value",'AUTO_NBR',  "Record_$recordNumber\_EDID_$nonDefaultEDID");

				S_w2log(1, "Get EDID data for $tcpar_Crashcode, Record $recordNumber");
				my $detectedEDIDvalue = $record_handler -> GetRawEDID( "EDIDnr" => $nonDefaultEDID,
	                                                   "RecordNumber" => $recordNumber,
	                                                   "CrashLabel" => $tcpar_Crashcode,
	                                                   "FormatOption" => "HEX");

				$detectedEDIDvalue = 'FF' if($main::opt_offline);

				unless(defined $detectedEDIDvalue) {
					S_set_error("No data could be obtained for EDID $nonDefaultEDID.");
					next;
				}

				S_w2log(1, "Compare expected and detected values", 'AUTO_NBR');
				my $detectedValueString;
				if(ref $detectedEDIDvalue eq 'ARRAY') {
					foreach my $edidValue (@{$detectedEDIDvalue})
					{
				        my $verdict = EVAL_evaluate_string ( "EDID_$nonDefaultEDID\_Evaluation", $defaultValue, $edidValue, '!=');
						$detectedValueString .= "$edidValue ";
					}
				}
				else {
			        my $verdict = EVAL_evaluate_string ( "EDID_$nonDefaultEDID\_Evaluation", $defaultValue, $detectedEDIDvalue, '!=');
			        $detectedValueString = $detectedEDIDvalue;
				}
                S_teststep_expected("all data samples other than default: $defaultValue", "Record_$recordNumber\_EDID_$nonDefaultEDID");
                S_teststep_detected("$detectedValueString", "Record_$recordNumber\_EDID_$nonDefaultEDID");

			#next Record
			}
		#next EDID
		}
	}

	return 1;
}

sub TC_finalization {

	# Erase EDR
    PD_ClearCrashRecorder();
    S_wait_ms(2000);

	# Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(10000);

	# Read fault memory after clearing and erasing EDR
    PD_ReadFaultMemory(); 
	S_wait_ms(2000);

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');
    
	S_w2rep("Clean up record and crash handler");
    $record_handler -> DeleteAllRecords();
    $crash_handler -> DeleteAllSources();

	return 1;
}


1;
