#### TEST CASE MODULE
package TC_EDR_EnvironmentalData;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
#include further modules here
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_can_access;
use LIFT_MDSRESULT;
use GENERIC_DCOM;
use FuncLib_EDR_Framework;
use FuncLib_TNT_SYC_INTERFACE;
use Data::Dumper;

##################################

our $PURPOSE = "<Check that environmental data is stored matching to the fired BT or squibs>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_EnvironmentalData

=head1 PURPOSE

<Check that environmental data is stored matching to the fired BT or squibs>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFaultNoCT


I<B<Stimulation and Measurement>>

1. Power up ECU

2. Change buckle state driver <change_buckleState>and inject <crashtype>

3. Wait for <wait_ms>

4. Read EDR


I<B<Evaluation>>

1. - 

2. - 

3. - 

4. Check that environmental data matches firing <EDIDs>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'crashtype' => 
	SCALAR 'change_buckleState' => 
	SCALAR 'wait_ms' => 
	HASH 'EDIDs' => 
	HASH 'SquibLabels' => 
	SCALAR 'EvalType' => 
	SCALAR 'EvalTolerance_abs' => 


=head2 PARAMETER EXAMPLES

	purpose = 'Inject a crash and change environment <Test Heading Head> SoE' 
	
	# ---------- Stimulation ------------ 
	crashtype= '<Test Heading Tail>'
	change_buckleState = '<Test Heading Head>_<Test Heading 2>'
	
	# General
	wait_ms = 2000 #ms
	
	# ---------- Evaluation ------------ 
	EDIDs = %('63' => 'Pretensioner (1) time to deploy driver', '109' => 'Pretensioner (2) time to deploy driver', '112' => 'Pretensioner (3) time to deploy driver')
	
	SquibLabels = %('63' => 'BT1FD', '109' => 'BT2FD', '112' => 'BT3FD')
	
	EvalType = 'FireTime'
	EvalTolerance_abs = 10

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_crashtype;
my $tcpar_change_buckleState;
my $tcpar_wait_ms;
my $tcpar_Expected_Data;
my $tcpar_SquibLabels;
my $tcpar_EvalTolerance_abs;
my $tcpar_Switch;
my $tcpar_SwitchState;
my $tcpar_CrashT0_ms;
my $tcpar_DiagType;
my $tcpar_ResultDB;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_read_NHTSAEDR;
my $tcpar_read_CHINAEDR;

################ global parameter declaration ###################
#add any global variables here
my ($record_handler, $crash_handler, $crashSettings, $edrNumberOfEventsToBeStored,$ChinaEDR_diagType);
my $state_value;
my $state_unit;
my $result;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_crashtype =  S_read_mandatory_testcase_parameter( 'crashtype' );
	$tcpar_Switch =  S_read_mandatory_testcase_parameter( 'Switch' );
	$tcpar_SwitchState =  S_read_mandatory_testcase_parameter( 'SwitchState' );
	$tcpar_CrashT0_ms =  S_read_mandatory_testcase_parameter( 'CrashT0_ms' );
	$tcpar_DiagType =  S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_ResultDB =  S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_change_buckleState =  S_read_mandatory_testcase_parameter( 'change_buckleState' );
	$tcpar_COMsignalsAfterCrash =  S_read_optional_testcase_parameter( 'COMsignalsAfterCrash','byref' );
	$tcpar_wait_ms =  S_read_mandatory_testcase_parameter( 'wait_ms' );
	$tcpar_Expected_Data =  S_read_optional_testcase_parameter( 'Expected_Data','byref' );
	$tcpar_SquibLabels =  S_read_mandatory_testcase_parameter( 'SquibLabels' ,'byref');
	$tcpar_EvalTolerance_abs =  S_read_mandatory_testcase_parameter( 'EvalTolerance_abs' );
	$tcpar_read_NHTSAEDR=S_read_optional_testcase_parameter('read_NHTSAEDR');
	$tcpar_read_CHINAEDR=S_read_optional_testcase_parameter('read_CHINAEDR');
	
	if(not defined $tcpar_read_CHINAEDR) {
		$tcpar_read_NHTSAEDR = 'yes';
		$tcpar_read_CHINAEDR = 'no';
	}
	else {
		$tcpar_read_NHTSAEDR = 'no';
		my $storageOrder = EDR_getStorageOrder();
		return unless(defined $storageOrder);

		if($storageOrder eq 'PhysicalOrder'){
			$ChinaEDR_diagType= 'ProdDiag';  #In platform NHTSA and China EDR is read via proddiag
		}
		else {
			$ChinaEDR_diagType= 'CHINA_Payload';
		}
	}
	return 1;
}

sub TC_initialization {

	S_teststep("Test setup preparation", 'AUTO_NBR');

	#--------------------------------------------------------------
    # INITIALIZE RECORD AND CRASH HANDLER
    #    
	S_w2rep("Initialize Record Handler");
	$record_handler = EDR_init_RecordHandler() || return;
    $crash_handler = EDR_init_CrashHandler() || return;
	#--------------------------------------------------------------
    # PREPARE CRASH AND INITIALIZE EQUIPMENT
    #
	S_w2rep("Get crash settings for crash $tcpar_crashtype");
    my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_crashtype};
    $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
    unless(defined $crashSettings) {
        S_set_error("Crash $tcpar_crashtype not available in result DB $tcpar_ResultDB. Test case aborted.");
        return;
    }

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log(1, "Crashcode: $tcpar_crashtype, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");

	S_w2log(1, "Power on ECU");
    LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

    S_w2log(1, "Initialize CD and start CAN trace");
    GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start ( );

	S_w2log(1, "Set environments for crash as per result DB");
    CSI_PrepareEnvironment($crashSettings, 'init_complete');
    S_wait_ms(2000);

	S_w2log(1, "Clear crash recorder");
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(2000);

	S_w2log(1, "Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	S_w2log(1, "Read and evaluate fault memory before stimulation");
    my $faultsBeforeStimulation = PD_ReadFaultMemory();
    my $faultsVerdict = PD_evaluate_faults( $faultsBeforeStimulation, []);
    return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

	return 1;
}

sub TC_stimulation_and_measurement {

    #--------------------------------------------------------------
    # CRASH PREPARATION
    #
    S_teststep("Prepare crash", 'AUTO_NBR');
    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

    # Prepare crash
    CSI_LoadCrashSensorData2Simulator($crashSettings);

    # Power ON the ECU
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');
    
    CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    S_wait_ms(1000);

    S_teststep("Start recording of fire times.", 'AUTO_NBR');
    LC_MeasureTraceDigitalStart();
	
	if($tcpar_change_buckleState eq "changeBefore_SoE"){
		S_teststep("Change buckle state driver '$tcpar_change_buckleState'and inject '$tcpar_crashtype'", 'AUTO_NBR');
		
		( $result, $state_value, $state_unit ) = SYC_SWITCH_get_state($tcpar_Switch, $tcpar_SwitchState );
		LC_SetResistance( $tcpar_Switch, $state_value ) if ( $state_unit eq 'R' );
		LC_SetCurrent( $tcpar_Switch, $state_value ) if ( $state_unit eq 'I' );
		unless(defined $result) {
			S_set_error(" Switch $tcpar_Switch is not set to $tcpar_SwitchState " . "Check switch state in SYC or in TS");
			return 0;
		}
		S_wait_ms(1000);
		CSI_TriggerCrash();
	}
	elsif($tcpar_change_buckleState eq "changeAfter_SoE"){
		S_teststep("Inject '$tcpar_crashtype' and Change buckle state driver '$tcpar_change_buckleState' ", 'AUTO_NBR');
		CSI_TriggerCrash();
		S_wait_ms($tcpar_CrashT0_ms);
		
		( $result, $state_value, $state_unit ) = SYC_SWITCH_get_state($tcpar_Switch, $tcpar_SwitchState );
		LC_SetResistance( $tcpar_Switch, $state_value ) if ( $state_unit eq 'R' );
		LC_SetCurrent( $tcpar_Switch, $state_value ) if ( $state_unit eq 'I' );
		unless(defined $result) {
			S_set_error(" Switch $tcpar_Switch is not set to $tcpar_SwitchState " . "Check switch state in SYC or in TS");
			return 0;
		}	
		
	}
	else{
		S_set_error(" Condition specified in <change_buckleState> is incorrect. Must be 'changeAfter_SoE' or 'changeBefore_SoE' Testcase is aborted");
		return 0;
	}

	if (defined $tcpar_COMsignalsAfterCrash){
		foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
		{				
			my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
			S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
			COM_setSignalState($signal,$dataOnCOM);	
		}
	}
	
	S_teststep("Wait '$tcpar_wait_ms'", 'AUTO_NBR');
	S_wait_ms($tcpar_wait_ms);
	LC_MeasureTraceDigitalStop();
	
	S_teststep("Read EDR", 'AUTO_NBR', 'read_edr');			#measurement 1
	my $dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_".$tcpar_crashtype;

	$edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();

	unless(defined $edrNumberOfEventsToBeStored){
        S_set_error("Number of records to be stored in EDR not available in SYC - add or overwrite with Custlibrary Function");
        return;
    }
	
    PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');

	if ( lc( $tcpar_read_NHTSAEDR) eq 'yes' ) {
		EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
								"CrashLabel" => $tcpar_crashtype."_".$tcpar_change_buckleState,
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								"read_EDRType"=>'NHTSA')
	}
	if (lc($tcpar_read_CHINAEDR) eq 'yes'){
		$edrNumberOfEventsToBeStored=3;
		EDR_ReadAndStoreAllRecords ("DiagType" =>  $ChinaEDR_diagType,
								"CrashLabel" =>  $tcpar_crashtype."_".$tcpar_change_buckleState,
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								"read_EDRType"=>'CHINA');
	}	
	# Fire time measurement
	my $lctData = LC_MeasureTraceDigitalGetValues();
	EVAL_dump2UNV( $lctData, "$dataStoragePath/LCT_Measurement.txt.unv" );
	my $squibLabels_aref;
	foreach my $lctEDID (keys %{$tcpar_SquibLabels})
	{
		push(@{$squibLabels_aref}, $tcpar_SquibLabels -> {$lctEDID});
	}
	EDR_addFireTimesToCrashHandler ("LCT_Measurement" => $lctData,
									"SquibLabels" => $squibLabels_aref,
									"CrashLabel"  => $tcpar_crashtype."_".$tcpar_change_buckleState,
									"StoragePath" => $dataStoragePath);

	return 1;
}

sub TC_evaluation {
	
	if($tcpar_change_buckleState eq "changeBefore_SoE"){
		foreach my $EDID (keys %{$tcpar_Expected_Data})
		{
			my $dataElement = $record_handler -> GetDataElementEDID( "EDIDnr" => $EDID, "RecordNumber" => 1,
																  "CrashLabel" => $tcpar_crashtype."_".$tcpar_change_buckleState);
            S_teststep("EDID $EDID ($dataElement) firing for $tcpar_Switch = PositionA", 'AUTO_NBR', "PositionA_EDID_$EDID");         

			my $edidData = $record_handler -> GetDecodedEDID("CrashLabel" => $tcpar_crashtype."_".$tcpar_change_buckleState, "RecordNumber" => 1,"EDIDnr" => $EDID );
			my $Detectedvalue = $edidData -> {"DataValue"};
			my $unit = $edidData -> {"ValueUnit"};		 
		 
			unless(defined $Detectedvalue) {
				S_set_error("No data could be obtained for EDID $EDID .") unless($main::opt_offline);
				next;
			}
			my $expectedValue = $tcpar_Expected_Data -> {$EDID};
			S_w2log(1, "Compare expected and detected values", 'AUTO_NBR');
			EVAL_evaluate_string ( "EDID_$EDID\_Evaluation", $expectedValue, $Detectedvalue );	
			S_teststep_expected("$expectedValue firing duration", "PositionA_EDID_$EDID");			#evaluation 1
			S_teststep_detected("$Detectedvalue firing duration", "PositionA_EDID_$EDID");			
		}
	
	}
	elsif($tcpar_change_buckleState eq "changeAfter_SoE"){
		my $squibLabelString;
		foreach my $edid (keys %{$tcpar_SquibLabels}) {
			my $squibLabel = $tcpar_SquibLabels -> {$edid};
			$squibLabelString .= ", " if (defined $squibLabelString);
			$squibLabelString .= "EDID $edid ($squibLabel)";
		}

		S_teststep("Firing of given squib EDIDs for $tcpar_Switch = PositionB", 'AUTO_NBR', "PositionB_SquibValidation");			
		EDR_Eval_SquibFireTimes("CrashLabel" => $tcpar_crashtype."_".$tcpar_change_buckleState,
												   "EDID_SquibLabels" => $tcpar_SquibLabels,
												   "CrashTimeZero_ms" => $tcpar_CrashT0_ms,
												   "FireTimeTolerance_ms" => $tcpar_EvalTolerance_abs);								   	
	}
	else {
		S_set_error(" Switch $tcpar_Switch is not set to either 'PositionA' OR 'PositionB' --> no evaluation will be done");
		return 0;
	}

	return 1;
}

sub TC_finalization {


	S_w2rep("Delete all object instances created...");

	foreach my $recordNumber (1..$edrNumberOfEventsToBeStored)
	{
			$record_handler -> DeleteRecord(  "CrashLabel" => $tcpar_crashtype."_".$tcpar_change_buckleState,
                                      "RecordNumber" => $recordNumber );				
	}
    $crash_handler -> DeleteAllSources('CrashLabel' => $tcpar_crashtype."_".$tcpar_change_buckleState);	

	# Erase EDR
	PD_ClearCrashRecorder();
	S_wait_ms(2000);

	# Erase Fault memory
	PD_ClearFaultMemory();
	S_wait_ms(2000);

	# Read fault memory after clearing and erasing EDR
	PD_ReadFaultMemory();   
    S_wait_ms(2000);

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}


1;
