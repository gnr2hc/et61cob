#### TEST CASE MODULE
package TC_EDR_Initialization;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <AB12_TS_Feature_Event_Data_Recording>
#TS version in DOORS: <1.43> 
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_PD;
use LIFT_labcar;
use GENERIC_DCOM;
use LIFT_can_access;
use LIFT_evaluation;
use LIFT_general;
use LIFT_FaultMemory;
use INCLUDES_Project; #necessary
#include further modules here

##################################

our $PURPOSE = "<To Check EDR initializes only in plant mode and with PON cycle greater than one>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_Initialization

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFaultNoCT


I<B<Stimulation and Measurement>>

1. Flash the ECU and ensure the system is fault free.

2. Power up ECU and set the ECU to <mode>.

3. Set the variable <PD_Variable_PON_Counter> value to zero and reset the ECU. 

4. Reset the ECU again only  if <PON_Counter_Value> is equal to two.

5. Wait for <WaitTime_ms>

6. Read the <EDR_Initialization_Variable> via PD.


I<B<Evaluation>>

1. - 

2. - 

3. <PD_Variable_PON_Counter> value will be one .

4. -

5. - 

6. <EDR_Initialization_Variable> will be  <EDR_Initialization_Value>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'EDR_Initialization_Value' => '0x0000'
	SCALAR 'purpose' => ' To Check EDR initializes only in plant mode and with PON cycle greater than one'
	SCALAR 'mode' =>  'NormalMode'
	SCALAR 'PON_Counter_Value' => 2
	SCALAR 'PD_Variable_PON_Counter' => 'rb_tim_EcuOnTimeDataEe_st.POnCounter_u32'
	SCALAR 'WaitTime_ms' => 5000
	SCALAR 'EDR_Initialization_Variable' => 'rb_dcbm_FirstStartUpIndication_u16'


=head2 PARAMETER EXAMPLES

	purpose = ' To Check EDR initializes only in plant mode and with PON cycle greater than one'
	
	# ---------- Stimulation ------------ 
	mode =  '<Test Heading Head>'
	PON_Counter_Value = '<Test Heading Tail>'
	PD_Variable_PON_Counter = 'rb_tim_EcuOnTimeDataEe_st.POnCounter_u32'
	WaitTime_ms = 5000
	
	# ---------- Evaluation ------------ 
	EDR_Initialization_Variable = 'rb_dcbm_FirstStartUpIndication_u16'
	EDR_Initialization_Value = '0x0000'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_mode;
my $tcpar_PON_Counter_Value;
my $tcpar_PD_Variable_PON_Counter;
my $tcpar_WaitTime_ms;
my $tcpar_EDR_Initialization_Variable;
my $tcpar_UseAutoFlash;
my $tcpar_SWPath;
my $tcpar_FlashToolSerialNumber;
my $tcpar_ECUType;
my $expected_EDR_Initialization_Value;
my $detected_EDR_initialization_value;
my $detected_PON_Counter_Value;
my $tcpar_MandatoryFaults_href;

################ global parameter declaration ###################
#add any global variables here
my $faultsAfterStimulation;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_mode =  S_read_mandatory_testcase_parameter( 'mode' );
	if($tcpar_mode ne 'NormalMode' and $tcpar_mode ne 'PlantMode'){
	    S_set_error("Value '$tcpar_mode' is not supported for this test case! Allowed values: PlantMode, NormalMode", 110);
	    return;
	}
	$tcpar_MandatoryFaults_href = S_read_mandatory_testcase_parameter( 'Mandatory_Faults', 'byref' );
	$tcpar_PON_Counter_Value =  S_read_mandatory_testcase_parameter( 'PON_Counter_Value' );
	$tcpar_PD_Variable_PON_Counter =  S_read_mandatory_testcase_parameter( 'PD_Variable_PON_Counter' );
	$tcpar_WaitTime_ms =  S_read_mandatory_testcase_parameter( 'WaitTime_ms' );
	$tcpar_EDR_Initialization_Variable =  S_read_mandatory_testcase_parameter( 'EDR_Initialization_Variable' );
	$expected_EDR_Initialization_Value =  S_read_mandatory_testcase_parameter( 'EDR_Initialization_Value' );
	$tcpar_UseAutoFlash = S_read_optional_testcase_parameter('UseAutoFlash');
	if(defined $tcpar_UseAutoFlash and $tcpar_UseAutoFlash eq 'true'){
	    $tcpar_SWPath = S_read_mandatory_testcase_parameter( 'SW_Path' );
        $tcpar_FlashToolSerialNumber = S_read_mandatory_testcase_parameter( 'FlashToolSerialNumber' );
        $tcpar_ECUType = S_read_mandatory_testcase_parameter( 'ECU_Type' );
	}

	return 1;
}

sub TC_initialization {

    S_w2log(1, "Initialize CD and start CAN trace");
    GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start();

    S_w2log(1, "Power on ECU");
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

	S_w2log(1, "Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);

    S_w2log(1, "Reset ECU");
    LC_ECU_Reset();


	S_w2log(1, "Read and evaluate fault memory ");
    my $faultsBeforeStimulation = LIFT_FaultMemory -> read_fault_memory('Bosch');

	return 1;
}

sub TC_stimulation_and_measurement {

    if(defined $tcpar_UseAutoFlash and $tcpar_UseAutoFlash eq 'true'){
        S_teststep("Flash ECU with SW: $tcpar_SWPath", 'AUTO_NBR');      
        GEN_AutoECUFlash($tcpar_SWPath, $tcpar_FlashToolSerialNumber, $tcpar_ECUType);
    }
    else{
        S_teststep("Set the variable '$tcpar_PD_Variable_PON_Counter' value to zero and reset the ECU. ", 'AUTO_NBR');
        PD_WriteMemoryByName($tcpar_PD_Variable_PON_Counter,[0x00,0x00,0x00,0x00]);
        LC_ECU_Off(); #PON counter increments only on Hard reset.
        S_wait_ms('TIMER_ECU_OFF');
        LC_ECU_On();
        S_wait_ms('TIMER_ECU_READY');
    }

    S_teststep("read the variable '$tcpar_PD_Variable_PON_Counter' value ", 'AUTO_NBR', 'read_the_PON_variable_value'); #measurement 1
    $detected_PON_Counter_Value = S_aref2hex(PD_ReadMemoryByName_NOERROR( $tcpar_PD_Variable_PON_Counter ) ,U32 );

	S_teststep("Power up ECU and set the ECU to '$tcpar_mode'.", 'AUTO_NBR');
	if ($tcpar_mode eq "PlantMode"){
		PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [ 0x01 ] );
		PD_ECUreset();
		S_wait_ms('TIMER_ECU_READY');
	}

	if ($tcpar_PON_Counter_Value == 2 ){
        S_teststep("Reset the ECU ($tcpar_PD_Variable_PON_Counter = 2)", 'AUTO_NBR');
    	LC_ECU_Off();
        S_wait_ms('TIMER_ECU_OFF');
        LC_ECU_On();
    	S_wait_ms('TIMER_ECU_READY');
	}
	elsif($tcpar_PON_Counter_Value != 1) {
	    S_set_error("Power on counter parameter 'PON_Counter_Value' shall be either 1 or 2!(Given is: $tcpar_PON_Counter_Value)", 110);
	    return;
	}

	S_teststep("Wait for '$tcpar_WaitTime_ms'", 'AUTO_NBR');
	S_wait_ms(5000);

	S_teststep("Read the '$tcpar_EDR_Initialization_Variable' via PD.", 'AUTO_NBR', 'read_the_edr'); #measurement 2
	$detected_EDR_initialization_value = S_aref2hex(PD_ReadMemoryByName_NOERROR( $tcpar_EDR_Initialization_Variable ) ,U16 );

	S_teststep("Read primary fault memory", 'AUTO_NBR', 'read_fault_memory'); #measurement 2
	$faultsAfterStimulation = LIFT_FaultMemory -> read_fault_memory('Primary');

	return 1;
}

sub TC_evaluation {

	my $expected_PON_Counter_Value = 0x0001;
	S_teststep_expected("$expected_PON_Counter_Value", 'read_the_PON_variable_value'); #evaluation 1
	S_teststep_detected("$detected_PON_Counter_Value", 'read_the_PON_variable_value');
	EVAL_evaluate_value( "read_the_PON_variable_value", $detected_PON_Counter_Value, '==' , $expected_PON_Counter_Value );

	S_teststep_expected("'$tcpar_EDR_Initialization_Variable' is '$expected_EDR_Initialization_Value'", 'read_the_edr'); #evaluation 2
	S_teststep_detected("'$tcpar_EDR_Initialization_Variable' is '$detected_EDR_initialization_value'", 'read_the_edr');
	EVAL_evaluate_value( "read_the_edr", $detected_EDR_initialization_value, '==' , $expected_EDR_Initialization_Value );

	my $expected_faults_href;
	foreach my $faultName (keys %{$tcpar_MandatoryFaults_href}){
		S_teststep_expected("Fault '$faultName' is present in fault memory", 'read_fault_memory'); #evaluation 3
		my $faultIsPresent = $faultsAfterStimulation -> check_fault_presence($faultName);
		if($faultIsPresent eq 'present'){
			S_teststep_detected("Fault '$faultName' is present in fault memory", 'read_fault_memory'); #evaluation 3
			S_set_verdict('VERDICT_PASS');
		}
		else{
			S_teststep_detected("Fault '$faultName' is not present in fault memory", 'read_fault_memory'); #evaluation 3
			S_set_verdict('VERDICT_FAIL');
			next;					
		}
		
		my $rawStatusExpected = $tcpar_MandatoryFaults_href -> {$faultName};
		S_teststep_expected("Fault '$faultName' has status $rawStatusExpected", 'read_fault_memory'); #evaluation 3
		my $rawStatusDetected = "0x".sprintf("%02X", $faultsAfterStimulation -> get_fault_attribute({'FaultName' => $faultName,
																						'Attribute' => 'RawStatus'}));
		S_teststep_detected("Fault '$faultName' has status $rawStatusDetected", 'read_fault_memory'); #evaluation 3
		
		EVAL_evaluate_string ( 'fault_status' , $rawStatusExpected , $rawStatusDetected  );
	}
						
	return 1;
}

sub TC_finalization {

	if ($tcpar_mode eq "PlantMode"){
		PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [ 0x00 ] );
		PD_ECUreset();
		S_wait_ms('TIMER_ECU_READY');
	}

	#Erase Fault memory
	PD_ClearFaultMemory();
	S_wait_ms(2000);

	# Reset ECU
	PD_ECUreset();
	S_wait_ms('TIMER_ECU_READY');

	#Read fault memory after clearing
	PD_ReadFaultMemory();

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}


1;
