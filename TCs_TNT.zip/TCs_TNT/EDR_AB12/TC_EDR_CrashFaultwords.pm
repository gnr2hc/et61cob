#### TEST CASE MODULE
package TC_EDR_CrashFaultwords;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;

#include further modules here
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use GENERIC_DCOM;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;
use LIFT_can_access;
use LIFT_FaultMemory;
use Data::Dumper;

##################################

our $PURPOSE = "This test script is to evaluate fault qualified on crash injection";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_CrashFaultwords

=head1 PURPOSE

<This test script is to evaluate fault qualified on crash injection>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFaultNoCT


I<B<Stimulation and Measurement>>

1. Power up ECU

2. Inject <Crashcode>

3. Read fault memory

4. Read EDR <EventType>


I<B<Evaluation>>

1. - 

2. - 

3. Expect <FLTmand>

4. Read all crash telegrams stored in NVM and check for the correct <EventType> according to expected fault entry.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Crashcode' => 
	SCALAR 'FLTmand' => 
	HASH 'ExpectedRawValue_EventType' => 
	SCALAR 'purpose' => 
	SCALAR 'DiagType' => 
	SCALAR 'ResultDB' => 
	SCALAR 'WaitTime_ms' => 
	SCALAR 'NbrOfRecordsExpected' => 
	SCALAR 'EventType_EDID' => 


=head2 PARAMETER EXAMPLES

	purpose = 'Inject <Crashcode>crash and evaluate fault memory entry' # description of test case
	# ---------- Stimulation ------------ 
	DiagType = 'ProdDiag'
	ResultDB = 'EDR' # defined in CREIS project constants - will be set to 'DEFAULT' if not given
	WaitTime_ms = 15000
	# ---------- Evaluation ------------ 
	NbrOfRecordsExpected = 1
	Crashcode='Single_EDR_Front_Inflatable'
	
	FLTmand = ('rb_evm_FrontCrashDetected_flt'=>'0xAF')
	

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_ResultDB;
my $tcpar_WaitTime_ms;
my $tcpar_Crashcode;
my $tcpar_FLTmand;
my $tcpar_OptionalFaults_aref;

################ global parameter declaration ###################
#add any global variables here
my ( $crashSettings, $faultsAfterCrashInjection );

###############################################################

sub TC_set_parameters {

	$tcpar_purpose             = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_ResultDB            = S_read_mandatory_testcase_parameter('ResultDB');
	$tcpar_WaitTime_ms         = S_read_mandatory_testcase_parameter('WaitTime_ms');
	$tcpar_Crashcode           = S_read_mandatory_testcase_parameter('Crashcode');
	$tcpar_FLTmand             = S_read_mandatory_testcase_parameter( 'FLTmand', 'byref' );
	$tcpar_OptionalFaults_aref = S_read_optional_testcase_parameter( 'OptionalFaults_List', 'byref' );
	unless ( defined $tcpar_OptionalFaults_aref ) {
		$tcpar_OptionalFaults_aref = [];
	}

	return 1;
}

sub TC_initialization {

	S_teststep( "Test setup preparation", 'AUTO_NBR' );

	#--------------------------------------------------------------
	# PREPARE CRASH AND INITIALIZE EQUIPMENT
	#

	S_w2rep("Get crash settings for crash $tcpar_Crashcode");
	my $crashDetails_href = { "RESULTDB" => $tcpar_ResultDB, 'CRASHNAME' => $tcpar_Crashcode };
	$crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
	unless ( defined $crashSettings ) {
		S_set_error("Crash $tcpar_Crashcode not available in result DB $tcpar_ResultDB. Test case aborted.");
		return;
	}
	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log( 1, "Crashcode: $tcpar_Crashcode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)" );

	S_w2log( 1, "Power on ECU" );
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	S_w2log( 1, "Initialize CD and start CAN trace" );
	GDCOM_init();    # To fetch info for CD from mapping_diag
	CA_trace_start();

	S_w2log( 1, "Set environments for crash as per result DB" );
	CSI_PrepareEnvironment( $crashSettings, 'init_complete' );
	S_wait_ms(2000);

	S_w2log( 1, "Clear crash recorder" );
	PRD_Clear_EDR_NOERROR( { timeout_ms => 'TIMER_CLEAR_CRASH_RECORDER' } );
	S_wait_ms(2000);

	S_w2log( 1, "Clear fault memory" );
	PRD_Clear_Fault_Memory();
	S_wait_ms(2000);

	S_w2log( 1, "Read and evaluate fault memory before stimulation" );

	# read fault memory
	my $faultsBeforeStimulation_obj = LIFT_FaultMemory->read_fault_memory('Primary');

	#Fault memory must be empty
	my $faultsVerdict = $faultsBeforeStimulation_obj->evaluate_faults( {} );
	S_w2rep("Faults verdict: $faultsVerdict");
	return 0 unless ( $faultsVerdict eq 'VERDICT_PASS' );

	return 1;
}

sub TC_stimulation_and_measurement {

	#--------------------------------------------------------------
	# CRASH PREPARATION
	#
	S_teststep( "Prepare crash ", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	# Prepare crash
	CSI_LoadCrashSensorData2Simulator($crashSettings);

	# Power ON the ECU
	S_teststep( "Power up ECU", 'AUTO_NBR' );
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle', 'normal' );
	S_wait_ms(1000);

	#--------------------------------------------------------------
	# CRASH INJECTION
	#
	S_teststep( "Inject '$tcpar_Crashcode'", 'AUTO_NBR' );
	CSI_TriggerCrash();

	S_wait_ms(20000);

	S_teststep( "Read fault memory", 'AUTO_NBR', 'read_fault_memory' );    #measurement 1
	$faultsAfterCrashInjection = LIFT_FaultMemory->read_fault_memory('Primary');

	return 1;
}

sub TC_evaluation {

	my $expected_faults_href = {};
	$expected_faults_href->{'optional'} = $tcpar_OptionalFaults_aref;

	if (%$tcpar_FLTmand) {

		#GeneralStatus
		foreach my $faultName ( keys %{$tcpar_FLTmand} ) {
			$expected_faults_href->{'mandatory'}->{$faultName} = { 'RawStatus' => hex( $tcpar_FLTmand->{$faultName} ), };
		}
		$faultsAfterCrashInjection->evaluate_faults( $expected_faults_href, 'read_fault_memory' );
	}
	else {
		$faultsAfterCrashInjection->evaluate_faults( $expected_faults_href, 'read_fault_memory' );
	}

	return 1;
}

sub TC_finalization {

	# Erase EDR
	PRD_Clear_EDR_NOERROR( { timeout_ms => 'TIMER_CLEAR_CRASH_RECORDER' } );
	S_wait_ms(2000);

	# Erase Fault memory
	PRD_Clear_Fault_Memory();
	S_wait_ms(2000);

	# Read fault memory after clearing and erasing EDR
	LIFT_FaultMemory->read_fault_memory('Primary');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	return 1;
}

1;
