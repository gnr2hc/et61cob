#### TEST CASE MODULE
package TC_EDR_FaultHandling_Erase;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
#include further modules here
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use GENERIC_DCOM;
use LIFT_can_access;
use LIFT_FaultMemory;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;
use Data::Dumper;

##################################

our $PURPOSE = "<This test script tests fault erasure when EDR is erased or loched EDR is unlocked>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_FaultHandling_Erase

=head1 PURPOSE

<This test script tests fault erasure when EDR is erased or loched EDR is unlocked>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Inject (NumberOfEventsToBeStored - ThresholdValueForInternalError) <Crashcode> crash events.

2. Read fault memory.

3. Erase all the crash records.

4. Read fault memory.


I<B<Evaluation>>

1. -

2. Check for  <Fault_StateQualify>

3. - 

4. Check for <Fault_StateErase> 


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Crashcode' => 
	HASH 'Fault_StateQualify' => 
	HASH 'Fault_StateErase' => 
	SCALAR 'purpose' => 
	SCALAR 'NumerOfEventsToBeStored' => 
	SCALAR 'ThresholdValueForInternalError' => 


=head2 PARAMETER EXAMPLES

	purpose		 = 'Check that fault <Test Heading Head> is erased after having enough free crash records available again (by erasing existing records).'
	
	# ---------- Stimulation ------------ 
	Crashcode='Single_EDR_Front_Inflatable'
	Manipulation = 'Erase' # 'Unlock'
	#NumerOfEventsToBeStored = <Fetch {V_RefType2_B_Sample} {([1-6])}> 
	NumerOfEventsToBeStored = 2
	
	#ThresholdValueForInternalError= <Fetch {V_RefType2_B_Sample} {([1-2])}> 
	ThresholdValueForInternalError= 1
	
	# ---------- Evaluation ------------ 
	
	Fault_StateQualify = %('rb_edr_DataAreaFull_flt'=>'0xAF')
	PrimaryFault_StateDeQualify = %()
	BoschFault_StateDeQualify= %('rb_edr_DataAreaFull_flt'=>'0xAE')



=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_DiagService;
my $tcpar_Crashcode;
my $tcpar_Fault_StateQualify;
my $tcpar_Fault_StateDeQualify_Primary;
my $tcpar_Fault_StateDeQualify_Bosch;
my $tcpar_ResultDB;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_OptionalFaults_aref;

################ global parameter declaration ###################
#add any global variables here
my ($crashSettings, $edrNumberOfEventsToBeStored,$edrThresholdValueForInternalError,$faultsAfterCrashRecorderErasure_primary,$faultsAfterCrashRecorderErasure_bosch,$faultsAfterCrashInjection);

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_ResultDB =  S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_DiagService =  S_read_mandatory_testcase_parameter( 'Manipulation' );
	$tcpar_Crashcode =  S_read_mandatory_testcase_parameter( 'Crashcode' );
	$tcpar_Fault_StateQualify =  S_read_mandatory_testcase_parameter( 'Fault_StateQualify','byref'  );
	$tcpar_Fault_StateDeQualify_Primary =  S_read_mandatory_testcase_parameter( 'PrimaryFault_StateDeQualify','byref'  );
	$tcpar_Fault_StateDeQualify_Bosch =  S_read_mandatory_testcase_parameter( 'BoschFault_StateDeQualify','byref'  );
	$tcpar_COMsignalsAfterCrash =  S_read_optional_testcase_parameter( 'COMsignalsAfterCrash','byref');
    $tcpar_OptionalFaults_aref = S_read_optional_testcase_parameter( 'OptionalFaults_List','byref');
    unless(defined $tcpar_OptionalFaults_aref){
        $tcpar_OptionalFaults_aref = [];
    }

	return 1;
}

sub TC_initialization {

	S_teststep("Test setup preparation", 'AUTO_NBR');

	#--------------------------------------------------------------
    # PREPARE CRASH AND INITIALIZE EQUIPMENT
    #
	S_w2rep("Get crash settings for crash $tcpar_Crashcode");
    my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode};
    $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
    unless(defined $crashSettings) {
        S_set_error("Crash $tcpar_Crashcode not available in result DB $tcpar_ResultDB. Test case aborted.");
        return;
    }

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log(1, "Crashcode: $tcpar_Crashcode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");

	S_w2log(1, "Power on ECU");
    LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

    S_w2log(1, "Initialize CD and start CAN trace");
    GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start ( );
    
    # Set environment settings for crash
    CSI_PrepareEnvironment($crashSettings, 'init_complete');
    S_wait_ms(2000);

	S_w2log(1, "Clear crash recorder");
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(2000);

	S_w2log(1, "Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	S_w2log(1, "Read and evaluate fault memory before stimulation");
    my $faultsBeforeStimulation = LIFT_FaultMemory -> read_fault_memory('Bosch');

    #Fault memory must be empty
    my $faultsVerdict = $faultsBeforeStimulation -> evaluate_faults({});
    S_w2rep("Faults verdict: $faultsVerdict");
    return 0 unless ($faultsVerdict eq 'VERDICT_PASS');


	return 1;
}

sub TC_stimulation_and_measurement {
	
	$edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();
	unless(defined $edrNumberOfEventsToBeStored){
        S_set_error("Not available in SYC - add or overwrite with Custlibrary Function");
        return;
    }

	$edrThresholdValueForInternalError = SYC_EDR_get_ThresholdValueForInternalError();
	unless(defined $edrThresholdValueForInternalError){
        S_set_error("Not available in SYC - add or overwrite with Custlibrary Function");
        return;
    }

	S_teststep("Inject ($edrNumberOfEventsToBeStored-$edrThresholdValueForInternalError) '$tcpar_Crashcode' crash events", 'AUTO_NBR');

	my $CrashCount =1;
	while ($CrashCount <= ($edrNumberOfEventsToBeStored-$edrThresholdValueForInternalError))
	{	
		# Prepare crash
		LC_ECU_Off();
		S_wait_ms('TIMER_ECU_OFF');
        CSI_LoadCrashSensorData2Simulator($crashSettings);
        LC_ECU_On();
		S_wait_ms('TIMER_ECU_READY');
		
		CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    	S_wait_ms(1000);

		#--------------------------------------------------------------
		# CRASH INJECTION
		#
		S_teststep("Inject '$tcpar_Crashcode' $CrashCount time.", 'AUTO_NBR');
		S_w2rep("count=$CrashCount");
		CSI_TriggerCrash();
		S_wait_ms(10000);
		$CrashCount++;
    }
	
	if (defined $tcpar_COMsignalsAfterCrash){
		foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
		{				
			my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
			S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
			COM_setSignalState($signal,$dataOnCOM);	
		}
	}	

	S_teststep("Read fault memory", 'AUTO_NBR', 'read_fault_memory_after_crash_injection');			#measurement 1
    $faultsAfterCrashInjection = LIFT_FaultMemory -> read_fault_memory('Primary');
    S_wait_ms(5000); 

	S_teststep(" $tcpar_DiagService the crash record.", 'AUTO_NBR');
	
	if ($tcpar_DiagService  eq "Erase"){
		PD_ClearCrashRecorder_NOERROR();
	}
	else{
		EDR_CD_UnlockEDR(); 
	}
    S_wait_ms(4000); 
	
	S_teststep("Read primary fault memory.", 'AUTO_NBR', "read_primaryfault_memory_after_$tcpar_DiagService");			#measurement 2
	$faultsAfterCrashRecorderErasure_primary = LIFT_FaultMemory -> read_fault_memory('Primary');
	
	S_teststep("Read Bosch fault memory.", 'AUTO_NBR', "read_boschfault_memory_after_$tcpar_DiagService");			#measurement 2
	$faultsAfterCrashRecorderErasure_bosch = LIFT_FaultMemory -> read_fault_memory('Bosch');

	return 1;
}

sub TC_evaluation {

	
	# Qualification of data area full fault
	my $expectedFaults_AfterCrash_href = {'optional' => $tcpar_OptionalFaults_aref};
	foreach my $faultname ( keys %$tcpar_Fault_StateQualify )
	{
		$expectedFaults_AfterCrash_href -> {'mandatory'} -> {$faultname} = {
			'RawStatus' => hex($tcpar_Fault_StateQualify->{$faultname}),
		};
	}	
	$faultsAfterCrashInjection -> evaluate_faults( $expectedFaults_AfterCrash_href,
													'read_fault_memory_after_crash_injection');
	
    # Data area full fault erased from primary fault memory
    foreach my $faultname ( keys %$tcpar_Fault_StateDeQualify_Bosch )
    {
        S_teststep_expected("Check that $faultname in primary fault memory is erased after EDR $tcpar_DiagService", "read_primaryfault_memory_after_$tcpar_DiagService");          #evaluation 1
        my $faultPresence = $faultsAfterCrashRecorderErasure_primary -> check_fault_presence ($faultname);
        if(lc($faultPresence) eq 'present'){
        	my $found_status = $faultsAfterCrashRecorderErasure_primary -> get_fault_attribute({
                                                        'FaultName' => $faultname,
                                                        'Attribute' => 'RawStatus'});
            S_teststep_detected("Fault detected after crash injection: $faultname, status $found_status", "read_primaryfault_memory_after_$tcpar_DiagService");           
            #Evaluates read data with expected and reads the verdict
            S_set_verdict('VERDICT_FAIL');   
        }
        else{
            S_teststep_detected("Fault $faultname not present in primary fault memory", "read_primaryfault_memory_after_$tcpar_DiagService");           
            S_set_verdict('VERDICT_PASS');               
        }
    }	

	my $expectedFaults_AfterDequali_href = {'optional' => $tcpar_OptionalFaults_aref};
    # Data area full fault present in Bosch fault memory but dequalified
	foreach my $faultname ( keys %$tcpar_Fault_StateDeQualify_Bosch )
	{
		$expectedFaults_AfterDequali_href -> {'mandatory'} -> {$faultname} = {
			'RawStatus' => hex($tcpar_Fault_StateDeQualify_Bosch -> {$faultname}),
		};
	}

	$faultsAfterCrashRecorderErasure_bosch -> evaluate_faults( $expectedFaults_AfterDequali_href,
													"read_boschfault_memory_after_$tcpar_DiagService");

	return 1;
}

sub TC_finalization {

	# Erase EDR
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(2000);

	# Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	# Read fault memory after clearing and erasing EDR
    PD_ReadFaultMemory();   

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

	return 1;
}


1;
