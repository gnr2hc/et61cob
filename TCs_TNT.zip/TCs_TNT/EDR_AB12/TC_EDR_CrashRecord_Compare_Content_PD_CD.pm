#### TEST CASE MODULE
package TC_EDR_CrashRecord_Compare_Content_PD_CD;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general;
use LIFT_evaluation;
use LIFT_ProdDiag;
use LIFT_FaultMemory;
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_MDSRESULT;
use GENERIC_DCOM;
use LIFT_can_access;
use INCLUDES_Project;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;
use File::Basename;
use Data::Dumper;

use constant MILLISEC_TO_SECOND => 0.001;
##################################
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_CrashRecord_Compare_Content_PD_CD

=head1 PURPOSE

Compare the content of PD and CD response for the EDR records

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFaultNoCT


I<B<Stimulation and Measurement>>

1. Prepare crash and turn on ECU

2. Start fire time measurement

3. Inject <Crashcode> and wait for EDR storage to complete

4. Stop fire time measurement

5. Read EDR with Production Diagnosis

6. Read EDR with Customer Diagnosis

7. Store CAN trace


I<B<Evaluation>>

1. - 

2. - 

3. - 

4. - 

5. - 

6.  Compare content to result of production diagnosis

7. -


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

    SCALAR 'purpose' => decription of test case purpose
    SCALAR 'DiagType' => Diag type used to read CD response
    SCALAR 'ResultDB' => Mdb label given in CREIS mapping
    HASH 'COMsignalsAfterCrash' => List of COM signals and values to be set after crash (if required)
    SCALAR 'Crashcode' => Unique crashcode from EDR mdb
    SCALAR 'Protocol' => Flexray or Can


=head2 PARAMETER EXAMPLES

    purpose = 'Validate the customer and production diagnosis report the same content' # description of test case
    
    # ---------- Stimulation ------------ 
    DiagType = 'AKLV'
    ResultDB = 'EDR' # EDR is default if not given
    COMsignalsAfterCrash = %() # optional
    Crashcode = 'Parallel_All_Crashes'
    Protocol = 'CAN' # optional, 'CAN' is default
    
    # --- Options ----
    # In case the supplier EDID 999 is reported in various EDID IDs in the customer diagnosis, these EDID numbers can be given here
    # Supplier_EDID_Cust = @('8000', '8001', '8002')
    
    # In case the cust diag only reports part of the supplier EDID or no bytes of the supplier EDID at all, the number of bytes reported for the supplier EDID 999 can be given here
    # Supplier_EDID_Cust_Length = 50

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Crashtype;
my $tcpar_DiagType;
my $tcpar_ResultDB;
my $tcpar_Protocol;
my $tcpar_CrashTimeZero_ms;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_Supplier_EDID_Cust_aref;
my $tcpar_Supplier_EDID_Cust_Length;
my $tcpar_StorageOrder_CD;
my $tcpar_StorageOrder_PD;
my $tcpar_Expected_Nbr_Of_Records;
my $tcpar_AcceptedDelta_Nbr_Of_EDIDs;

################ global parameter declaration ###################
#add any global variables here
my ( $record_handler, $crashSettings, $crashDetails_href, $crashInfo_href, $numberOfRecords, );

our $PURPOSE;
our $TC_name = "TC_EDR_CrashInjection";

#-------------------------------------------------------------------------------
sub TC_set_parameters {

	#-------------------------------------------------------------------------------
	S_w2rep("Read testcase parameters");
	$tcpar_Crashtype = S_read_mandatory_testcase_parameter('Crashcode');
	$tcpar_ResultDB  = S_read_optional_testcase_parameter('ResultDB');
	if ( not defined $tcpar_ResultDB ) {
		$tcpar_ResultDB = 'EDR';
	}
	$tcpar_DiagType = S_read_mandatory_testcase_parameter('DiagType');
	$tcpar_Protocol = S_read_optional_testcase_parameter('Protocol');
	unless ( defined $tcpar_Protocol ) {
		$tcpar_Protocol = 'CAN';
	}

	$tcpar_StorageOrder_CD            = S_read_mandatory_testcase_parameter('StorageOrder_CD');
	$tcpar_StorageOrder_PD            = S_read_mandatory_testcase_parameter('StorageOrder_PD');
	$tcpar_Expected_Nbr_Of_Records    = S_read_mandatory_testcase_parameter('Expected_Nbr_Of_Records');
	$tcpar_AcceptedDelta_Nbr_Of_EDIDs = S_read_mandatory_testcase_parameter('AcceptedDelta_Nbr_Of_EDIDs');

	$tcpar_COMsignalsAfterCrash = S_read_optional_testcase_parameter( 'COMsignalsAfterCrash', 'byref' );

	# Options for supplier EDID 999
	$tcpar_Supplier_EDID_Cust_aref = S_read_optional_testcase_parameter( 'Supplier_EDID_Cust', 'byref' );
	unless ( defined $tcpar_Supplier_EDID_Cust_aref ) {
		$tcpar_Supplier_EDID_Cust_aref = [];
	}
	$tcpar_Supplier_EDID_Cust_Length = S_read_optional_testcase_parameter('Supplier_EDID_Cust_Length');

	return 1;
}

#-------------------------------------------------------------------------------
sub TC_initialization {

	#-------------------------------------------------------------------------------

	#--------------------------------------------------------------
	# INITIALIZE RECORD HANDLER
	#
	S_w2rep("Initialize Record Handler");
	$record_handler = EDR_init_RecordHandler() || return;

	#--------------------------------------------------------------
	# GET CRASH DETAILS
	#
	# Crash name or index and result DB from EDR mapping
	my $mappingEDR = S_get_contents_of_hash( ['Mapping_EDR'] );
	$crashDetails_href = $mappingEDR->{'CRASHFILES'}{$tcpar_Crashtype};
	unless ( defined $crashDetails_href ) {
		$crashDetails_href = { 'RESULTDB' => $tcpar_ResultDB, 'CRASHNAME' => $tcpar_Crashtype };
	}

	# Crash settings
	$crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
	unless ( defined $crashSettings ) {
		S_set_error("Crash code $tcpar_Crashtype not defined in given result DB. Test case will be aborted.");
		return 0;
	}

	# Name of Result DB
	my $resultDB = $crashDetails_href->{"RESULTDB"};
	unless ( defined $resultDB ) {
		$resultDB = "DEFAULT";
	}

	# Result DB path
	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$resultDB" ] );
	$crashInfo_href->{"MDB_Path"} = $resultDBDetails->{'PATH'};

	# Crash time Zero and EDR crash label -> crash name in EDR mapping
	$crashInfo_href->{"CrashTimeZero_ms"} = $tcpar_CrashTimeZero_ms;
	$crashInfo_href->{"CrashLabel"}       = $tcpar_Crashtype;

	#--------------------------------------------------------------
	# Initialize equipment
	#

	# configure digital fire time measurement
	LC_MeasureTraceDigitalConfigureThresholds( ['ALL'], 0.5 );

	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');
	CA_trace_start();

	# Set environment settings for crash
	CSI_PrepareEnvironment( $crashSettings, 'init_complete' );
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_EDR( { timeout_ms => 'TIMER_CLEAR_CRASH_RECORDER' } );
	S_wait_ms(2000);

	# erase FltMem
	PRD_Clear_Fault_Memory();
	S_wait_ms(2000);

	GDCOM_init();    # To fetch info for CD from mapping_diag

	# read fault memory
	my $faultsBeforeStimulation_obj = LIFT_FaultMemory->read_fault_memory('Primary');

	#Fault memory must be empty
	my $faultsVerdict = $faultsBeforeStimulation_obj->evaluate_faults( {} );
	return 0 unless ( $faultsVerdict eq 'VERDICT_PASS' );

	return 1;
}

#-------------------------------------------------------------------------------
sub TC_stimulation_and_measurement {

	#-------------------------------------------------------------------------------
	#--------------------------------------------------------------
	# CRASH PREPARATION
	#
	S_teststep( "Prepare crash and turn on ECU", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	# Prepare crash
	CSI_LoadCrashSensorData2Simulator($crashSettings);

	# Power ON the ECU
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle', 'normal' );
	S_wait_ms(1000);

	#--------------------------------------------------------------
	# START MEASUREMENTS
	#
	S_teststep( "Start LCT Measurement", 'AUTO_NBR' );
	LC_MeasureTraceDigitalStart();

	#--------------------------------------------------------------
	# CRASH INJECTION
	#
	S_teststep( "Inject crash", 'AUTO_NBR' );
	CSI_TriggerCrash();
	S_wait_ms(20000);

	#--------------------------------------------------------------
	# STOP MEASUREMENTS
	#
	S_teststep( "Stop LCT Measurement", 'AUTO_NBR' );
	LC_MeasureTraceDigitalStop();
	LC_MeasureTraceDigitalGetValues();    # Required to empty buffer
	if ( defined $tcpar_COMsignalsAfterCrash ) {
		foreach my $signal ( keys %{$tcpar_COMsignalsAfterCrash} ) {
			my $dataOnCOM = $tcpar_COMsignalsAfterCrash->{$signal};
			S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
			COM_setSignalState( $signal, $dataOnCOM );
		}

	}
	S_wait_ms(2000);

	#--------------------------------------------------------------
	# READ AND STORE CRASH RECORDS
	#
	my $dataStoragePath = "$main::REPORT_PATH/" . S_get_TC_number() . "_" . $tcpar_Crashtype;
	$numberOfRecords = SYC_EDR_get_NumberOfEventsToBeStored();

	# ************** 1 - ProductionDiag **************
	S_teststep( "Get all stored records via Production diag and store in record handler", 'AUTO_NBR', 'read_pd_record' );
	PRD_ECU_Login();
	S_wait_ms(1000);
	EDR_ReadAndStoreAllRecords(
		"DiagType"     => "ProdDiag",
		"CrashLabel"   => $tcpar_Crashtype . "_ProdDiag",
		"NbrOfRecords" => $numberOfRecords,
		"StoragePath"  => $dataStoragePath,
		"CrashInfo"    => $crashInfo_href,
		"read_EDRType" => 'NHTSA'
	);

	# ************** 2 - CustomerDiag **************
	S_teststep( "Get all stored records via Customer diag and store in record handler", 'AUTO_NBR', 'read_cd_record' );

	EDR_ReadAndStoreAllRecords(
		"DiagType"     => $tcpar_DiagType,
		"CrashLabel"   => $tcpar_Crashtype . "_CustDiag",
		"NbrOfRecords" => $numberOfRecords,
		"StoragePath"  => $dataStoragePath,
		"CrashInfo"    => $crashInfo_href,
	);

	my $pdRecordAvailable = $record_handler->IsRecordAvailable( "CrashLabel" => $tcpar_Crashtype . "_ProdDiag", "RecordNumber" => 1 );
	my $cdRecordAvailable = $record_handler->IsRecordAvailable( "CrashLabel" => $tcpar_Crashtype . "_CustDiag", "RecordNumber" => 1 );
	if ( not defined $pdRecordAvailable ) {
		S_teststep_expected( "PD records obtained from ECU", 'read_pd_record' );
		S_teststep_detected( "PD records not obtained from ECU", 'read_pd_record' );
		S_set_verdict('VERDICT_FAIL');
	}
	if ( not defined $cdRecordAvailable ) {
		S_teststep_expected( "CD records obtained from ECU", 'read_cd_record' );
		S_teststep_detected( "CD records not obtained from ECU", 'read_cd_record' );
		S_set_verdict('VERDICT_FAIL');
	}

	#--------------------------------------------------------------
	# STORE MEASUREMENTS
	#
	S_w2rep("Store $tcpar_Protocol Trace");
	my $fileName = "$dataStoragePath/LIFT_network_trace_$tcpar_Crashtype.asc";
	my $tracePath;
	$tracePath = CA_trace_store($fileName);
	S_w2rep("Trace File: $tracePath");

	# Restart Rest bus simulation - is stopped when storing!
	S_wait_ms(2000);
	CA_trace_start();

	my $lct_Data = LC_MeasureTraceDigitalGetValues();
	EVAL_dump2UNV( $lct_Data, "$dataStoragePath/LCT_Measurement_$tcpar_Crashtype.txt.unv" );

	return 1;
}

#-------------------------------------------------------------------------------
sub TC_evaluation {

	#-------------------------------------------------------------------------------
	S_w2rep("Compare all EDIDs from CD with those from PD");

	# in case there are differing EDID numbers for PD and CD, there must be a separate Mapping_EDR_CA

	my $EDRMapping_CA = S_get_contents_of_hash_NOERROR( ['Mapping_EDR_CA'] );
	my $edidStructure_CA;
	if ( defined $EDRMapping_CA ) {
		$edidStructure_CA = EDR_ReadEDR_Record_structure_info_from_mapping( undef, undef, 'Mapping_EDR_CA' );
	}
	else {
		$edidStructure_CA = EDR_ReadEDR_Record_structure_info_from_mapping();
	}

	my $edidsCA_DataElements_href;
	foreach my $edid ( keys %{ $edidStructure_CA->{'EDIDS'} } ) {
		my $dataElement = $edidStructure_CA->{'EDIDS'}->{$edid}->{'DataElement'};
		$edidsCA_DataElements_href->{$dataElement} = $edid;
	}

	# Mapping of PD <=> CD records
	my $swapPD_RecordNbr;
	if ( $tcpar_StorageOrder_CD eq 'MostRecentFirst' ) {
		$swapPD_RecordNbr = 1 if ( $tcpar_StorageOrder_PD eq 'MostRecentLast' );
		$swapPD_RecordNbr = 1 if ( $tcpar_StorageOrder_PD eq 'PhysicalOrder' );
		$swapPD_RecordNbr = 0 if ( $tcpar_StorageOrder_PD eq 'MostRecentFirst' );
	}
	elsif ( ( $tcpar_StorageOrder_CD eq 'MostRecentLast' ) or ( $tcpar_StorageOrder_CD eq 'PhysicalOrder' ) ) {
		$swapPD_RecordNbr = 0 if ( $tcpar_StorageOrder_PD eq 'MostRecentLast' );
		$swapPD_RecordNbr = 0 if ( $tcpar_StorageOrder_PD eq 'PhysicalOrder' );
		$swapPD_RecordNbr = 1 if ( $tcpar_StorageOrder_PD eq 'MostRecentFirst' );
	}
	else {
		S_set_error("CD storage order '$tcpar_StorageOrder_CD' not known! Choose MostRecentFirst, MostRecentLast, or PhysicalOrder");
		return 1;
	}

	unless ( defined $swapPD_RecordNbr ) {
		S_set_error("PD storage order '$tcpar_StorageOrder_PD' not known! Choose MostRecentFirst, MostRecentLast, or PhysicalOrder");
		return 1;
	}

	my $dumpVariable;
	foreach my $recordNbr ( 1 .. $tcpar_Expected_Nbr_Of_Records ) {
		my $pdRecordNbr;
		$pdRecordNbr = $recordNbr if ( $swapPD_RecordNbr == 0 );
		$pdRecordNbr = $tcpar_Expected_Nbr_Of_Records - $recordNbr + 1 if ( $swapPD_RecordNbr == 1 );
		S_teststep( "Start validation of CD record $recordNbr corresponding to PD record $pdRecordNbr", 'AUTO_NBR' );

		my $tableObject = HTML::Table->new(
			-align   => 'center',
			-rules   => 'all',
			-border  => 1,
			-width   => '70%',
			-spacing => 0,
			-padding => 3,
			-style   => 'color: black',
		);
		$tableObject->setCaption("Evaluation Result record $recordNbr");
		$tableObject->addRow( 'Data element', 'EDID CD', 'EDID PD', 'Data CD', 'Data PD', 'Verdict' );
		$tableObject->setRowBGColor( 1, "#E2E8EE" );
		my $rowNbr = 2;
		next unless ( $record_handler->IsRecordAvailable( "RecordNumber" => $pdRecordNbr, "CrashLabel" => $tcpar_Crashtype . "_ProdDiag" ) );
		my $listOfEDIDs_PD_aref = $record_handler->GetListOfEDIDsInRecord(
			"RecordNumber"  => $pdRecordNbr,
			"CrashLabel"    => $tcpar_Crashtype . "_ProdDiag",
			"MainEdidsOnly" => 1
		);

		if ( not defined $listOfEDIDs_PD_aref ) {
			S_set_error(" Cannot get lists of EDIDs for PD response ") unless ($main::opt_offline);
		}

		my $listOfEDIDs_CD_aref = $record_handler->GetListOfEDIDsInRecord(
			"RecordNumber"  => $recordNbr,
			"CrashLabel"    => $tcpar_Crashtype . "_CustDiag",
			"MainEdidsOnly" => 1
		);
		if ( not defined $listOfEDIDs_CD_aref ) {
			S_set_error(" Cannot get lists of EDIDs for CD response ") unless ($main::opt_offline);
		}
		$dumpVariable->{"Record_$recordNbr"}->{"ProdDiag"} = $listOfEDIDs_PD_aref;
		$dumpVariable->{"Record_$recordNbr"}->{"CustDiag"} = $listOfEDIDs_CD_aref;

		S_teststep( "Compare number of EDIDs stored in CustDiag and in ProdDiag", 'AUTO_NBR', "Compare_Nbr_EDIDs_Record_$recordNbr" );
		my $numberOfEDIDs_ProdDiag = scalar @{$listOfEDIDs_PD_aref};
		my $numberOfEDIDs_CustDiag = scalar @{$listOfEDIDs_CD_aref};
		S_teststep_expected( "Nbr of EDIDs reported in Prod and Cust Diag is equal (with accepted delta of $tcpar_AcceptedDelta_Nbr_Of_EDIDs EDIDs)", "Compare_Nbr_EDIDs_Record_$recordNbr" );
		S_teststep_detected( "$numberOfEDIDs_ProdDiag (PD) <=> $numberOfEDIDs_CustDiag (CD)", "Compare_Nbr_EDIDs_Record_$recordNbr" );

		EVAL_evaluate_value( "PD_equal_CD_NumberOfEDIDs", $numberOfEDIDs_ProdDiag, '==', $numberOfEDIDs_CustDiag, $tcpar_AcceptedDelta_Nbr_Of_EDIDs, 'absolute' );

		my $overallResultTable;
		for ( my $index = 0 ; $index < $numberOfEDIDs_CustDiag ; $index++ ) {
			my $edidCustDiag = $listOfEDIDs_CD_aref->[$index];
			my $dataElementCustDiag = $record_handler->GetDataElementEDID( "EDIDnr" => $edidCustDiag, "RecordNumber" => $recordNbr, "CrashLabel" => $tcpar_Crashtype . "_CustDiag" );

			my $edidProdDiag = $edidsCA_DataElements_href->{$dataElementCustDiag};
			unless ( defined $edidProdDiag ) {
				S_set_error("'$dataElementCustDiag' is not there in CA EDR mapping");
				next;
			}

			S_teststep( "Content '$dataElementCustDiag' (CD $edidCustDiag, PD $edidProdDiag)", 'AUTO_NBR', "EDID_$edidCustDiag\_Record_$recordNbr" );

			my $rawEDIDvalueProdDiag = $record_handler->GetRawEDID( "EDIDnr" => $edidProdDiag, "RecordNumber" => $pdRecordNbr, "CrashLabel" => $tcpar_Crashtype . "_ProdDiag", "FormatOption" => "HEX" );
			my $rawEDIDvalueCustDiag;
			if ( $edidProdDiag == 999 and @{$tcpar_Supplier_EDID_Cust_aref} ) {
				S_w2rep("Supplier data will be prepared for comparison");

				# Construct expected cust diag data with list of EDIDs and number of bytes if given
				foreach my $custEDID ( @{$tcpar_Supplier_EDID_Cust_aref} ) {
					my $thisEDIDrawArray = $record_handler->GetRawEDID( "EDIDnr" => $edidCustDiag, "RecordNumber" => $recordNbr, "CrashLabel" => $tcpar_Crashtype . "_CustDiag", "FormatOption" => "HEX" );
					next unless ( defined $thisEDIDrawArray );
					if ( not defined $rawEDIDvalueCustDiag ) {
						$rawEDIDvalueCustDiag = $thisEDIDrawArray;
						next;
					}
					my @combinedArray = ( @{$rawEDIDvalueCustDiag}, @{$thisEDIDrawArray} );
					$rawEDIDvalueCustDiag = \@combinedArray;
				}

			}
			else {
				$rawEDIDvalueCustDiag = $record_handler->GetRawEDID( "EDIDnr" => $edidCustDiag, "RecordNumber" => $recordNbr, "CrashLabel" => $tcpar_Crashtype . "_CustDiag", "FormatOption" => "HEX" );
			}
			unless ( defined $rawEDIDvalueProdDiag ) {
				S_set_verdict('VERDICT_FAIL');
				S_teststep_expected( "EDID $edidCustDiag : $rawEDIDvalueCustDiag in PD and CD", "EDID_$edidCustDiag\_Record_$recordNbr" );
				S_teststep_detected( "EDID $edidCustDiag not stored in PD", "EDID_$edidCustDiag\_Record_$recordNbr" );

				$tableObject->addRow( ( $dataElementCustDiag, $edidCustDiag, $edidProdDiag, 'not present in EDR', 'present in EDR', 'VERDICT_FAIL' ) );
				$tableObject->setCellBGColor( $rowNbr, 6, 'red' );
				$rowNbr++;
				next;
			}

			my ( $verdict, $stringProdDiag, $stringCustDiag );
			if ( ref $rawEDIDvalueCustDiag eq 'ARRAY' ) {
				my $index           = 0;
				my $prodDiagByteNbr = @{$rawEDIDvalueProdDiag};
				if ( $tcpar_Supplier_EDID_Cust_Length and $edidProdDiag == 999 ) {
					S_w2rep("Change number of prod diag bytes to fixed length $tcpar_Supplier_EDID_Cust_Length");
					$prodDiagByteNbr = $tcpar_Supplier_EDID_Cust_Length;
				}
				my $custDiagByteNbr = @{$rawEDIDvalueCustDiag};
				S_w2log( 4, "Nbr Bytes cust diag: $custDiagByteNbr" );
				S_w2log( 4, "Nbr Bytes prod diag: $prodDiagByteNbr" );
				$verdict = EVAL_evaluate_value( "Byte_Nbr_EDID_$edidCustDiag", $custDiagByteNbr, '==', $prodDiagByteNbr );
				foreach my $dataSampleCust ( @{$rawEDIDvalueCustDiag} ) {
					S_w2log( 4, "Cust Diag value: $dataSampleCust" );
					my $dataSampleProd = $rawEDIDvalueProdDiag->[$index];
					my $thisVerdict;
					if ( defined $dataSampleProd ) {
						S_w2log( 4, "(Cust Diag) $dataSampleCust <=> $dataSampleProd (Prod Diag)" );
						$thisVerdict = EVAL_evaluate_string_NOHTML( "PD_$edidProdDiag\_equal_CD_$edidCustDiag", $dataSampleCust, $dataSampleProd );
					}
					else {
						S_w2log( 4, "(Cust Diag) $dataSampleCust <=> no Prod Diag sample reported" );
						$thisVerdict = 'VERDICT_FAIL';
					}
					$verdict = $thisVerdict unless ( $verdict eq 'VERDICT_FAIL' );
					$stringProdDiag .= $dataSampleProd . " ";
					$stringCustDiag .= $dataSampleCust . " ";
					$index++;
				}
			}
			else {
				S_w2log( 4, "(Cust Diag) $rawEDIDvalueCustDiag <=> $rawEDIDvalueProdDiag (Prod Diag)" );
				$verdict        = EVAL_evaluate_string_NOHTML( "PD_$edidProdDiag\_equal_CD_$edidCustDiag", $rawEDIDvalueCustDiag, $rawEDIDvalueProdDiag );
				$stringProdDiag = $rawEDIDvalueProdDiag;
				$stringCustDiag = $rawEDIDvalueCustDiag;
			}

			S_teststep_expected( "(CD $edidCustDiag) $stringCustDiag", "EDID_$edidCustDiag\_Record_$recordNbr" );
			S_teststep_detected( "(PD $edidProdDiag) $stringProdDiag", "EDID_$edidCustDiag\_Record_$recordNbr" );

			$tableObject->addRow( ( $dataElementCustDiag, $edidCustDiag, $edidProdDiag, $stringCustDiag, $stringProdDiag, $verdict ) );
			$tableObject->setCellBGColor( $rowNbr, 6, 'red' )   if ( $verdict eq 'VERDICT_FAIL' );
			$tableObject->setCellBGColor( $rowNbr, 6, 'green' ) if ( $verdict eq 'VERDICT_PASS' );
			$rowNbr++;

			$overallResultTable->{$dataElementCustDiag}->{'CD_EDID'}  = $edidCustDiag;
			$overallResultTable->{$dataElementCustDiag}->{'PD_EDID'}  = $edidProdDiag;
			$overallResultTable->{$dataElementCustDiag}->{'PD_Value'} = $stringProdDiag;
			$overallResultTable->{$dataElementCustDiag}->{'CD_Value'} = $stringCustDiag;
			$overallResultTable->{$dataElementCustDiag}->{'Verdict'}  = $verdict;
		}

		push( @TC_HTML_TEXT, $tableObject );
	}

	S_dump2pmFile(
		"StoragePath"    => "$main::REPORT_PATH/" . S_get_TC_number() . "_" . $tcpar_Crashtype,
		"VariableToDump" => $dumpVariable,
		"VariableName"   => "EDID_Lists",
		"PackageName"    => "EDID_Lists_PD_CD"
	);

	return 1;
}

#-------------------------------------------------------------------------------
sub TC_finalization {

	#-------------------------------------------------------------------------------
	# Read fault memory after crash
	LIFT_FaultMemory->read_fault_memory('Primary');
	S_wait_ms(2000);

	# Erase EDR
	PRD_Clear_EDR( { timeout_ms => 'TIMER_CLEAR_CRASH_RECORDER' } );
	S_wait_ms(2000);

	# Erase Fault memory
	PRD_Clear_Fault_Memory();
	S_wait_ms(2000);

	# Reset ECU
	PRD_ECU_Reset();
	S_wait_ms('TIMER_ECU_READY');

	# Read fault memory after clearing and erasing EDR
	LIFT_FaultMemory->read_fault_memory('Primary');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	foreach my $recordNbr ( 1 .. $numberOfRecords ) {
		$record_handler->DeleteRecord( "CrashLabel" => $tcpar_Crashtype . "_ProdDiag", "RecordNumber" => $recordNbr );
		$record_handler->DeleteRecord( "CrashLabel" => $tcpar_Crashtype . "_CustDiag", "RecordNumber" => $recordNbr );
	}

	return 1;
}

1;
