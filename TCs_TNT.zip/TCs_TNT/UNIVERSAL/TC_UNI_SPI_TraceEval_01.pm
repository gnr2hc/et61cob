#### TEST CASE MODULE
package TC_UNI_SPI_TraceEval_01;

#### DONT MODIFY THIS SECTION ####
use strict;

# -------------------------------
our $VERSION = q$Revision: 1.2 $;
our $HEADER  = q$Header: UNIVERSAL/TC_UNI_SPI_TraceEval_01.pm 1.2 2018/06/24 19:00:07ICT Verma Nupur (RBEI/ESA-PP3) (ENU5KOR) develop  $;
##################################

use Data::Dumper;

#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general;
use LIFT_evaluation;
use LIFT_spi_access;
use LIFT_CSM;

use FuncLib_TNT_GEN;

##################################
our $PURPOSE = "UNIVERSAL TESTCASE MODULE FOR SPI TRACE EVALUATION";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=pod

=head1 TESTCASE MODULE

TC_UNI_SPI_TraceEval_01  $Revision: 1.2 $

=head1 PURPOSE

UNIVERSAL TESTCASE MODULE FOR SPI TRACE EVALUATION

=head1 PARAMETER DESCRIPTION

	purpose                 = 'Evakl something Cobra_Main::POM_READ_BIST::MISO::et0�
	USE_SPI_EVAL			= 'yes'
	_SPI_GetTime_T1_Docu	= 'T1 is when et0 is manipulated from 0 -> 1'
	_SPI_GetTime_T1			= @('T0', 'Cobra_Main::POM_READ_BIST::MISO::et0', '==', 1)
	_SPI_GetTime_T2_Docu	= 'T2 is when et0 is reset from 1 -> 0'
	_SPI_GetTime_T2			= @('T1', 'Cobra_Main::POM_READ_BIST::MISO::et0', '==', 0)
	_SPI_GetTime_T3_Docu	= 'T3 is when et0 is manipulated from 0 -> 1'
	_SPI_GetTime_T3			= @('T0', 'Cobra_Plausi::POM_READ_BIST::MISO::et0', '==', 1)
	_SPI_GetTime_T4_Docu	= 'T4 is when et0 is reset from 1 -> 0'
	_SPI_GetTime_T4			= @('T3', 'Cobra_Plausi::POM_READ_BIST::MISO::et0', '==', 0)
	_SPI_EvalTime0_T1_Docu	= 'Timing et0 check on Cobra_Main'
	_SPI_EvalTime0_T1		= @('T2', '>=', 2990, '<=', 3010 )
	_SPI_EvalTime1_T3_Docu	= 'Timing et0 check on Cobra_PLausi'
	_SPI_EvalTime1_T3		= @('T4', '>=', 2990, '<=', 3010 )

    #	OP: '=='  '!='  '>='  '<='  '<'  '>'  'MASK',   V_T1: value at time,  I_T1T2: time interval
	#   Legend: XxxxXxxx: mandatory parameters, XXXXXXXX: mandatory control parameters, _XxxxXxx: optional parameters

=cut	

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my ($tcpar_SRT_Id);
my ( $tcpar_USE_SPI_EVAL, $tcpar_SPI_GetTime_href, $tcpar_SPI_EvalTime_href, $tcpar_SPI_EvalSignal_href );
my ( $tcpar_USE_SPI_RECORD, $tcpar_SPI_TraceFilePath, $tcpar_SPI_Node, $tcpar_StartTime_ms, $tcpar_EndTime_ms );

my ( $tcpar_SPI_trace_nodes_aref, $tcpar_SPI_commands_expected_aref, $tcpar_CSM_search_keywords_fully_aref, $tcpar_CSM_search_keywords_partly_aref );

my ( $SPI_Data_href, $container_id );

# -----------------------------------------------------------------------------------------------------
#                                     READ TEST CASE PARAMETER
# -----------------------------------------------------------------------------------------------------
sub TC_set_parameters {

    undef $SPI_Data_href;
    undef $container_id;

    $tcpar_SPI_commands_expected_aref = S_read_mandatory_testcase_parameter('SPI_commands_expected');

    # received tcpar will be used from functions FuncLib_TNT_GEN::GEN_EVAL....
    ( $tcpar_SPI_GetTime_href, $tcpar_SPI_EvalTime_href, $tcpar_SPI_EvalSignal_href ) = GEN_get_trace_eval_params('SPI');

    # TODO : remove later
    # print Dumper($tcpar_SPI_GetTime_href);
    # print Dumper($tcpar_SPI_EvalTime_href);
    # print Dumper($tcpar_SPI_EvalSignal_href);

    # ------------------------------------------------------------------------
    # Show test case ID in report
    $tcpar_SRT_Id = S_read_optional_testcase_parameter( 'SRT_ID', 'byref', 'NOT_GIVEN' );

    $tcpar_SPI_trace_nodes_aref            = S_read_mandatory_testcase_parameter('SPI_trace_nodes');
    $tcpar_CSM_search_keywords_fully_aref  = S_read_optional_testcase_parameter('CSM_search_keywords_fully');
    $tcpar_CSM_search_keywords_partly_aref = S_read_optional_testcase_parameter('CSM_search_keywords_partly');

    return 1;
}

#******************************************************************************************************
#                                      TEST CASE INITIALIZATION                                       *
#******************************************************************************************************
sub TC_initialization {

    #    CSM_init() || return;   # initialize CSM Container handling  - to be done in Init campaign

    S_w2log( 3, " CSM search container in Local Working Area via keywords\n", "blue" );

    my $CSM_query_config = {};
    $CSM_query_config = { 'keywords_fully'  => $tcpar_CSM_search_keywords_fully_aref }  if defined $tcpar_CSM_search_keywords_fully_aref;
    $CSM_query_config = { 'keywords_partly' => $tcpar_CSM_search_keywords_partly_aref } if defined $tcpar_CSM_search_keywords_partly_aref;

    S_w2rep( " Searching Container (in CSM Local Working Area) \n", "blue" );
    my @Container_IDs_matching = CSM_search_local_container($CSM_query_config);

    unless ( scalar @Container_IDs_matching ) {
        S_set_error( "Could not find a container for given criteria : \n" . Dumper($CSM_query_config) . " \n" );
        return;
    }

    foreach my $temp_cont_id ( sort { $b cmp $a } @Container_IDs_matching ) {
        $container_id = $temp_cont_id;
        last;
    }

    S_w2rep( " CSM get container $container_id \n", "blue" );
    my $Container_Header = CSM_get_container($container_id) || return;
    my $keyword_listing_aref = $Container_Header->getKeywordListing();    # actually not needed at them moment ; might be just useful for printing

    #
    # container can have several user files
    #   each element in the container (user file) has a unique Content ID
    #
    S_w2log( 2, " CSM getContentIdentifiers 'UserFile' \n", 'blue' );
    my $found_userfile_ids_aref = $Container_Header->getContentIdentifiers('UserFile');
    unless ( scalar(@$found_userfile_ids_aref) ) {
        S_set_error("No ContentIdentifiers received , no userfiles are part of Container");
        return;
    }

    my $used_SPI_Trace_content_id;
    foreach my $user_file_ID (@$found_userfile_ids_aref) {

        #        next unless $user_file_ID =~ /Manitoo_SPI_trace/;    # is something like : Content_Identifier="Manitoo_SPI_trace_raw__20180620_155715.mbt">
        next unless $user_file_ID =~ /SPI_trace/;    # is something like : Content_Identifier="Manitoo_SPI_trace_raw__20180620_155715.mbt">
        $used_SPI_Trace_content_id = $user_file_ID;
        last;
    }

    unless ( defined $used_SPI_Trace_content_id ) {
        S_set_error("No ContentIdentifier 'SPI_Trace_file' found ");
        return;
    }

    S_w2log( 2, " CSM get userfile '$used_SPI_Trace_content_id' ( with extraction) \n", 'blue' );
    my $userfile_object = CSM_get_userfile(          #    now with extracting (is default)
        $container_id,
        $used_SPI_Trace_content_id,
        { extract => 1 },                            # option extract : 0 - no ; 1 - yes
    );

    my $filename_long_SPI_Trace = $userfile_object->getFilename_long();
    S_w2rep( "UserFile extracted Name: $filename_long_SPI_Trace \n", 'blue' );

    unless ( -e $filename_long_SPI_Trace ) {
        S_set_error("Data file '$filename_long_SPI_Trace' does not exist!");
        return;
    }

    my $meas_label = 'SPI_Measurement';
    SPI_trace_load_file(
        'MeasurementLabel' => $meas_label,
        'FileName'         => $filename_long_SPI_Trace,
    ) || return;

    foreach my $SPI_node (@$tcpar_SPI_trace_nodes_aref) {
        my $SPI_trace_dataref = SPI_trace_get_dataref(
            'MeasurementLabel' => $meas_label,
            'SPI_Node'         => $SPI_node,
        ) || return;

        S_dump2pmFile(    # TODO : to be deleted after development
            "VariableToDump" => $SPI_trace_dataref,
            "PackageName"    => "SPI_datref__" . $SPI_node,
        );

        # hash slices in order to comnbine to hashes ( See perl docu )
        @{$SPI_Data_href}{ keys %$SPI_trace_dataref } = values %$SPI_trace_dataref;
    }

    return 1;
}

#******************************************************************************************************
#                                   STIMULATION AND MEASUREMENT                                       *
#******************************************************************************************************
sub TC_stimulation_and_measurement {

    return 1;
}

#******************************************************************************************************
#                                        TEST CASE EVALUATION                                         *
#******************************************************************************************************
sub TC_evaluation {

    S_teststep( "----------------------------- Evaluate SPI Trace -----------------------------", 'NO_AUTO_NBR' );

    if ( scalar @$tcpar_SPI_commands_expected_aref ) {
        my ( $thisVerdict, $detectedSequence_aref ) = SPI_EVAL_check_command_sequence(
            'MeasurementData_href' => $SPI_Data_href,
            'CommandList'          => $tcpar_SPI_commands_expected_aref
        );
        S_teststep_expected( "Expected SPI command_sequence : " . join( "-> ", @$tcpar_SPI_commands_expected_aref ) );
        S_teststep_detected( "Measured SPI command_sequence : " . join( "-> ", @$detectedSequence_aref ) );
    }

    my ( $verdict, $sequence_time_value_href );
    if ( defined $tcpar_SPI_GetTime_href ) {
        ( $verdict, $sequence_time_value_href ) = GEN_EVAL_trace_sequence( $SPI_Data_href, $tcpar_SPI_GetTime_href );
    }

    #	    if($verdict eq 'PASS' and defined $tcpar_SPI_EvalTime_href ){   # TODO : to be checked whether we need the check for PASS
    if ( defined $tcpar_SPI_EvalTime_href ) {

        #	        my $verdictTimes = GEN_EVAL_trace_times($SPI_Data_href, $sequence_time_value_href, $tcpar_SPI_EvalTime_href);
        #	        my $verdictSignals = GEN_EVAL_trace_signals($SPI_Data_href, $sequence_time_value_href, $tcpar_SPI_EvalSignal_href) if(defined $tcpar_SPI_EvalSignal_href);
        GEN_EVAL_trace_times( $SPI_Data_href, $sequence_time_value_href, $tcpar_SPI_EvalTime_href );
    }

    #	    if($verdict eq 'PASS' and defined $tcpar_SPI_EvalSignal_href ){    # TODO : to be checked whether we need the check for PASS
    if ( defined $tcpar_SPI_EvalSignal_href ) {
        GEN_EVAL_trace_signals( $SPI_Data_href, $sequence_time_value_href, $tcpar_SPI_EvalSignal_href );
    }

    return 1;
}

#******************************************************************************************************
#                                        TEST CASE FINALIZATION                                       *
#******************************************************************************************************
sub TC_finalization {

    S_w2rep( "CSM clear container\n", 'blue' );
    CSM_clear_container($container_id) || return;

    return 1;
}

1;

__END__
