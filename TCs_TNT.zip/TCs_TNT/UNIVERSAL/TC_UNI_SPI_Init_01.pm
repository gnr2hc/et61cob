#### TEST CASE MODULE
package TC_UNI_SPI_Init_01;

#### DONT MODIFY THIS SECTION ####
use strict;

# -------------------------------
our $VERSION = q$Revision: 1.11 $;
our $HEADER  = q$Header: UNIVERSAL/TC_UNI_SPI_Init_01.pm 1.11 2018/06/22 23:50:31ICT Okrusch Thomas (CC-PS/EPS2) (OUT2SI) develop  $;
##################################

#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_evaluation;
use LIFT_PD;
use LIFT_spi_access;
use LIFT_CSM;

use FuncLib_TNT_GEN;

use Data::Dumper;
$Data::Dumper::Sortkeys = 1;    #Sort the keys in the output
##################################
our $PURPOSE = "UNIVERSAL TESTCASE MODULE FOR SPI STIMULATION IN STEADY STATE";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=pod

=head1 TESTCASE MODULE

TC_UNI_SPI_Init_01  $Revision: 1.11 $

=head1 PURPOSE

UNIVERSAL TESTCASE MODULE FOR SPI STIMULATION IN INIT STATE

=head1 PARAMETER DESCRIPTION

	purpose                 = 'Purpose of the test case�
	# ---------------------- TC_stimulation_and_measurement --------------------
	USE_SYNC_SIGNAL = 'yes'
	_SyncSig_Docu = "Synchronisation signal for the manipulation reference" # optional
	_SyncSig_Name = �<Node Name>::<Command Name>::<Signal Name>�     # HG sensor channel 1
	_SyncSig_Value = '0x40'  # value to be loaded in the signal
	_SyncSig_Duration_ms = 65 # Duration of manipulation time in milli seconds

	USE_SPI_SIGNALS = 'yes'

	# example for Pre trigger functions
	# USE_PRE_TRIGGER = 'yes' # only if this is set to yes, the below parameters will be read and considered
    _PT1_Name = '<Node Name>::<Command Name>'
    _PT1_ActiveTime_ms = '100'
    _PT2_Name = '<Node Name>::<Command Name>::<Signal Name>'
    _PT2_SignalValue = '100' # signal value decimal
    _PT2_ActiveTime_ms = '500'
	
    # example for _SigX_FrameCycles combined with _SigX_PreTrigger (1 Pre-Trigger)
	_Sig2_Docu = "Manipulating signal in SPI mode" # optional
    _Sig2_Name = �<Node Name>::<Command Name>::<Signal Name>'
    # writing dynamic values for the signal for the particular number of frames
    _Sig2_FrameCycles = @('23', '36', '50')    # sending value 7 for 23 cycles , then value 6 for 36 cycles, then ..
    _Sig2_Values =      @('7', '6', '5')
    _Sig2_PreTrigger = '<Node Name>::<Command Name>' # give single pretrigger (give PT Name here)    
    
    # example for _SigX_TimesValues combined with _SigX_PreTriggers  (multiple Pre-triggers)
	_Sig1_Docu = "Manipulating signal in Timer mode" # optional
    _Sig1_Name = �<Node Name>::<Command Name>::<Signal Name>'
    # Pairs of Times on x-axis , Values of y-axis (time must be always increasing)  / stop manipulation after 6000ms
    _Sig1_TimesValues = %( 0 => '0x10', 2000 => '0x20', 4000 => '0x30', 6000 => 'stop_manipulation' )        #value in hex, time in ms
    _Sig1_PreTriggers = @('<Node Name>::<Command Name>', '<Node Name>::<Command Name>::<Signal Name>') # up to 4 pretriggers supported per signal (give PT Name here), logic AND!    
    
	# example for _SigX_FrameCycles
    _Sig3_Docu = "Manipulating signal with a single value in SPI mode" # optional
    _Sig3_Name = �<Node Name>::<Command Name>::<Signal Name>'
    # writing single value for the signal for the particular number of frames
    _Sig3_FrameCycles = '34'
    _Sig3_Value      = '0xB'            # hex value format
    
	# example for _SigX_FrameCycles
    # writing single value for the signal for the particular number of frames
    _Sig4_Docu = "Manipulating signal with a single value in SPI mode" # optional
    _Sig4_Name = �<Node Name>::<Command Name>::<Signal Name>'
    _Sig4_FrameCycles = '34'
    _Sig4_Value      = '0bi'            # bin value format

    _Sig1_PreTrigger = 'CG904_M::EOP__EOP1'

	# example for _SigX_TimesValues
	# DYNAMIC -  UC 12   -  for dynamic stimulation with same timing , different values
	#
	# 1. Define the each signal name which needs to be manipulated sperated by '|'
	_Sig2_Name     = 'Cobra_Plausi::POM_READ_BIST:: et0|et1|et2 '
	# 2. Hash ref with Signalname as key, timestamps and signal value as value
	_Sig2_TimesValues = %('et0' =>' 0:3000:4000|1:0:stop_manipulation','et1' =>' 0:3000:4000|1:0:stop_manipulation' ,'et2' =>' 0:3000:4000|1:0:stop_manipulation' )  

	# example for _SigX_Signals_and_Values
	# STATIC  -  UC 13   -  for static manipulation( 3 signals in 1 manipulation module)
	# 1. Define the each signal name which needs to be manipulated sperated by '|'
	_Sig1_Name          = 'Cobra_Main::POM_READ_BIST::et0|et1|et2'
	# 2. Pass the Hash ref with signalname as key and signal value as value
	_Sig1_Signals_and_Values = %( 'et0' => '1','et1' => '1', 'et2' => '1')
		
	
	# example for LA(Logic Analyzer) Trace
	# USE_LA_TRACE = 'yes' # only if require to capture the trace
   	 LA_template_path         = 'C:\Airbag\Acute\AB12_ManiToo_LIFTInterface.law' #Pass the LA template path. 
	
	
USE_FDIAG_RECORD        = 'yes'
_FastDiagVar0			= '<Test Heading Head>_Ch1SensorValue' 
_FastDiagVar1			= 'CenSen_DataValid'

# PD_get_FDtrace, PD_ReadFaultMemory, PD_ReadMemoryByName 

# ---------------------- TC_evaluation -----------------------------------
USE_FLT_EVAL			= 'yes'
_FLT_state			    = %('FltCsAsicRolloverInternalMonitoring' => '0bxx011111')

USE_VAR_EVAL            = 'yes'
_EvalVar0_Docu			= 'Short test documetation'
_EvalVar0			    = @('CenSen_DataValid', 'OP', '<Test Heading Head>_DataValid_11')
_EvalVar1_Docu			= 'Short test documetation'
_EvalVar1			    = @('<Test Heading Head>_Ch1SensorValue', 'OP', 0)

USE_FDIAG_EVAL          = 'yes'
_FD_GetTime_T1			= @('T0', '<Test Heading Head>_MonitorData',  '==', 64)
_FD_GetTime_T2			= @('T1', 'WarningLampRequest', 'MASK',  '0bxxx1xxxx')
_FD_EvalTime0_T1_Docu	= 'Short test documetation'
_FD_EvalTime0_T1		= @('T2','OP', 112, 'OP', 142,)

USE_SPI_EVAL            = 'no'

# ---------------------- TC_finalization ---------------------------------



OP: '=='  '!='  '>='  '<='  '<'  '>'  'MASK',   V_T1: value at time,  I_T1T2: time interval
Legend: XxxxXxxx: mandatory parameters, XXXXXXXX: mandatory control parameters, _XxxxXxx: optional parameters


Remark: USE_SPI_EVAL = 'no', because SPI recording not yet implemented for ManiToo

=cut	

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
my ( $tcpar_USE_PT, $tcpar_PT_Docu, $tcpar_PT_Name, $tcpar_PT_ActiveTime, $tcpar_Sig_PreTrigger, $tcpar_Sig_PreTriggers_aref );
my ( $tcpar_WaitTimeAfterPowerUp_ms, $tcpar_DTC_exp_href );
my ( $tcpar_USE_FLT_EVAL,            @tcpar_FLTmand, $tcpar_FLT_state_href );
my ( $tcpar_USE_VAR_EVAL,            @tcpar_EvalVarDocu, @tcpar_EvalVar, @Eval_Var_Label, @Eval_Var_Operator, @Eval_Var_Value );
my ($tcpar_SRT_Id);
my ( $tcpar_USE_FDIAG_EVAL , $tcpar_USE_FDIAG_RECORD, @tcpar_FastDiagVar, $FastDiag_labels_href );
my ( $tcpar_FD_GetTime_href,  $tcpar_FD_EvalTime_href,  $tcpar_FD_EvalSignal_href );

my ( $tcpar_USE_SPI_EVAL,   $tcpar_SPI_GetTime_href, $tcpar_SPI_EvalTime_href, $tcpar_SPI_EvalSignal_href );
my ( $tcpar_USE_SPI_RECORD, $tcpar_SPI_TraceFilePath, $tcpar_SPI_Node, $tcpar_StartTime_ms, $tcpar_EndTime_ms );


my ( $tcpar_USE_SPI_SIGNALS,  $tcpar_SyncSig_Docu,      $tcpar_SyncSig_Name, $tcpar_SyncSig_Value, $tcpar_SyncSig_Duration_ms, $tcpar_SyncSig_FrameCycles );
my ( $tcpar_Sig_Docu,         $tcpar_Sig_Name,          $tcpar_Sig_Value, $tcpar_Sig_Duration_ms, $tcpar_Sig_FrameCycles, $tcpar_Sig_Values, $tcpar_Sig_TimesValues );
my ( $tcpar_smi7_Module, $tcpar_smi7_Page, $tcpar_USE_SYNC_SIGNAL, $tcpar_Sig_Signals_and_Values, $tcpar_Sig_Signals_Times_Values );

my ( $FD_data,                $FDtrace );
my ( @detected_var,           $flt_mem_struct,    $flt_mem_struct_plant );
my ( $tcpar_USE_SPI_TRACE, @nodes_for_SPI_trace, , $tcpar_SPI_Nodes_aref , $SPI_tracefile_name , $SPI_data, $tcpar_USE_LA_TRACE  );
my ( $tcpar_CheckManipulation ); # it's hash with nbr -> Min / Max / Detected
my $spi_load_signal        = {};
my $pretrigger_load_module = {};
my $manip_counter          = 0;    # controlled in _Convert_to_function_call()
my $MAX_MANIPULATION       = 4;    # maximum number of signal manipulations possible is 4
my ($cont_id,$tc_parameter_name, $sw_vars_file_init);

# -----------------------------------------------------------------------------------------------------
#                                     READ TEST CASE PARAMETER
# -----------------------------------------------------------------------------------------------------
sub TC_set_parameters {

    # ------------------------------------------------------------------------
    S_teststep( "Get Signal parameters from parameter file", 'AUTO_NBR' );
	$tc_parameter_name = S_get_TC_parameter_name();
    $tcpar_USE_SYNC_SIGNAL = S_read_optional_testcase_parameter( 'USE_SYNC_SIGNAL', 'byref', 'no' );

    if ( $tcpar_USE_SYNC_SIGNAL eq 'yes' ) {
        $MAX_MANIPULATION--;

        $tcpar_SyncSig_Docu        = S_read_optional_testcase_parameter('_SyncSig_Docu');
        $tcpar_SyncSig_Name        = S_read_mandatory_testcase_parameter('_SyncSig_Name');
        $tcpar_SyncSig_Value       = S_read_optional_testcase_parameter('_SyncSig_Value');
        $tcpar_SyncSig_Duration_ms = S_read_optional_testcase_parameter('_SyncSig_Duration_ms');
        $tcpar_SyncSig_FrameCycles = S_read_optional_testcase_parameter('_SyncSig_FrameCycles');

        _Convert_to_function_call( $tcpar_SyncSig_Docu, $tcpar_SyncSig_Name, $tcpar_SyncSig_Value, $tcpar_SyncSig_Duration_ms, $tcpar_SyncSig_FrameCycles );
    }

    $tcpar_USE_SPI_SIGNALS = S_read_optional_testcase_parameter( 'USE_SPI_SIGNALS', 'byref', 'yes' );

    my $nbrOfSignalsToManipulate = 0;
    if ( $tcpar_USE_SPI_SIGNALS eq 'yes' ) {
        foreach my $signal_count ( 1 .. $MAX_MANIPULATION ) {    # maximum four SPI_manipulations including reference signal

            $tcpar_Sig_Name = S_read_optional_testcase_parameter( '_Sig' . $signal_count . '_Name' );

            next unless defined $tcpar_Sig_Name;

            $nbrOfSignalsToManipulate++;

            $tcpar_Sig_Docu               = S_read_optional_testcase_parameter( '_Sig' . $signal_count . '_Docu' );
            $tcpar_Sig_Value              = S_read_optional_testcase_parameter( '_Sig' . $signal_count . '_Value' );
            $tcpar_Sig_Duration_ms        = S_read_optional_testcase_parameter( '_Sig' . $signal_count . '_Duration_ms' );
            $tcpar_Sig_FrameCycles        = S_read_optional_testcase_parameter( '_Sig' . $signal_count . '_FrameCycles' );
            $tcpar_Sig_Values             = S_read_optional_testcase_parameter( '_Sig' . $signal_count . '_Values' );
            $tcpar_Sig_TimesValues        = S_read_optional_testcase_parameter( '_Sig' . $signal_count . '_TimesValues' );
            $tcpar_smi7_Module            = S_read_optional_testcase_parameter( '_Sig' . $signal_count . '_Module' );
            $tcpar_smi7_Page              = S_read_optional_testcase_parameter( '_Sig' . $signal_count . '_Page' );
            $tcpar_Sig_PreTrigger         = S_read_optional_testcase_parameter( '_Sig' . $signal_count . '_PreTrigger' );
            $tcpar_Sig_PreTriggers_aref   = S_read_optional_testcase_parameter( '_Sig' . $signal_count . '_PreTriggers' );
            $tcpar_Sig_Signals_and_Values = S_read_optional_testcase_parameter( '_Sig' . $signal_count . '_Signals_and_Values' );
            $tcpar_Sig_Signals_Times_Values = S_read_optional_testcase_parameter( '_Sig' . $signal_count . '_Signals_Times_Values' );
            if ( defined $tcpar_Sig_PreTriggers_aref and not ref($tcpar_Sig_PreTriggers_aref) eq 'ARRAY' ) {
                $tcpar_Sig_PreTriggers_aref = undef;
                S_set_error( '_Sig' . $signal_count . '_PreTrigger' . " parameter not in expected format (ARRAY)", 110 );
                return;
            }

            return unless( _Convert_to_function_call(
                $tcpar_Sig_Docu,    $tcpar_Sig_Name,  $tcpar_Sig_Value,      $tcpar_Sig_Duration_ms,      $tcpar_Sig_FrameCycles,   $tcpar_Sig_Values, $tcpar_Sig_TimesValues,
                $tcpar_smi7_Module, $tcpar_smi7_Page, $tcpar_Sig_PreTrigger, $tcpar_Sig_PreTriggers_aref, $tcpar_Sig_Signals_and_Values, $tcpar_Sig_Signals_Times_Values
            ));
			
			my $manip_module = $signal_count;
			my $moduleNbr = S_read_optional_testcase_parameter( '_Sig' . $manip_module . '_CheckManipulation_moduleNbr' );
			
			if( defined $moduleNbr ) {
				$tcpar_CheckManipulation -> { $moduleNbr } { MIN } = S_read_mandatory_testcase_parameter( '_Sig' . $manip_module . '_CheckManipulation_min' );
				$tcpar_CheckManipulation -> { $moduleNbr } { MAX } = S_read_mandatory_testcase_parameter( '_Sig' . $manip_module . '_CheckManipulation_max' );
				if ( $tcpar_CheckManipulation -> { $moduleNbr } { MAX } < $tcpar_CheckManipulation -> { $moduleNbr } { MIN } ) {
					S_set_error( " MAX is smaller than MIN (module nbr $moduleNbr)" ); return;
				}
			}

        }
		
		unless ($nbrOfSignalsToManipulate) {
			S_set_error("No signals for SPI manipulation given in parameter file!");
			return;
		}
    }

    $tcpar_USE_PT = S_read_optional_testcase_parameter('USE_PRE_TRIGGER' , 'byref' , 'no' );
    if ( $tcpar_USE_PT eq 'yes' ) {
        foreach my $pt_module ( 1 .. $MAX_MANIPULATION ) {    # maximum four SPI_manipulations including reference signal

            $tcpar_PT_Name = S_read_testcase_parameter( '_PT' . $pt_module . '_Name' );

            next unless defined $tcpar_PT_Name;

            $tcpar_PT_Docu                                              = S_read_optional_testcase_parameter( '_PT' . $pt_module . '_Docu' );
            $tcpar_PT_ActiveTime                                        = S_read_optional_testcase_parameter( '_PT' . $pt_module . '_ActiveTime_ms' );
            $pretrigger_load_module->{$pt_module}->{'PT_ActiveTime_us'} = $tcpar_PT_ActiveTime * 1000;
            my @pre_trigger = split( /::/, $tcpar_PT_Name );
            $pretrigger_load_module->{$pt_module}->{'PT_Node'}    = $pre_trigger[0];    # node name
            $pretrigger_load_module->{$pt_module}->{'PT_Command'} = $pre_trigger[1];
            if ( @pre_trigger == 3 ) {
                $pretrigger_load_module->{$pt_module}->{'PT_SignalName'}  = $pre_trigger[2];
                $pretrigger_load_module->{$pt_module}->{'PT_SignalValue'} = S_read_mandatory_testcase_parameter( '_PT' . $pt_module . '_SignalValue' );
            }
        }
    }

	$tcpar_USE_SPI_TRACE = S_read_optional_testcase_parameter( 'USE_SPI_TRACE', 'byref', 'no' );
    if ( $tcpar_USE_SPI_TRACE eq 'yes' ) {
		$tcpar_SPI_Nodes_aref = S_read_optional_testcase_parameter( '_SPI_Nodes' );
		if( defined $tcpar_SPI_Nodes_aref ) {
			@nodes_for_SPI_trace = @$tcpar_SPI_Nodes_aref;
		}
		else { @nodes_for_SPI_trace = () }
   }
		
	$tcpar_USE_LA_TRACE = S_read_optional_testcase_parameter( 'USE_LA_TRACE', 'byref', 'no' );
	
    # ------------------------------------------------------------------------
    $tcpar_WaitTimeAfterPowerUp_ms = S_read_optional_testcase_parameter( 'WaitTimeAfterPowerUp_ms', 'byref', '6000' );

    # ------------------------------------------------------------------------
    $tcpar_USE_FDIAG_RECORD = S_read_optional_testcase_parameter( 'USE_FDIAG_RECORD', 'byref', 'no' );
    @tcpar_FastDiagVar = ();

    if ( $tcpar_USE_FDIAG_RECORD eq 'yes' ) {
        foreach my $i ( 0 .. 10 ) {
            my $expected_var = S_read_testcase_parameter( '_FastDiagVar' . $i );
            last unless $expected_var;
            push( @tcpar_FastDiagVar, $expected_var );
        }
    }

    # ------------------------------------------------------------------------
    $tcpar_USE_FLT_EVAL   = S_read_optional_testcase_parameter( 'USE_FLT_EVAL', 'byref', 'no' );
    $tcpar_FLT_state_href = ();
    @tcpar_FLTmand        = ();

    # TODO : Fault handling to be improved
    if ( $tcpar_USE_FLT_EVAL eq 'yes' ) {
        $tcpar_FLT_state_href = S_read_optional_testcase_parameter( '_FLT_state', 'byref' , {} );
		
        @tcpar_FLTmand = keys %$tcpar_FLT_state_href if $tcpar_FLT_state_href;

        $tcpar_DTC_exp_href = S_read_optional_testcase_parameter( '_DTC_EXP', 'byref' );
    }

    # ------------------------------------------------------------------------
    $tcpar_USE_VAR_EVAL = S_read_optional_testcase_parameter('USE_VAR_EVAL' , 'byref' , 'no' );
    @tcpar_EvalVar      = ();
    @Eval_Var_Label     = ();
    @Eval_Var_Value     = ();

    if ( $tcpar_USE_VAR_EVAL eq 'yes' ) {
        foreach my $i ( 0 .. 99 ) {
            $tcpar_EvalVarDocu[$i] = S_read_optional_testcase_parameter( '_EvalVar' . $i . '_Docu' );
            @tcpar_EvalVar = S_read_optional_testcase_parameter( '_EvalVar' . $i );
            last unless @tcpar_EvalVar;

            $Eval_Var_Label[$i] = $tcpar_EvalVar[0];

            $Eval_Var_Operator[$i] = $tcpar_EvalVar[1];

            $Eval_Var_Value[$i] = $tcpar_EvalVar[2];
        }
    }

    # ------------------------------------------------------------------------
    $tcpar_USE_FDIAG_EVAL = S_read_optional_testcase_parameter('USE_FDIAG_EVAL' , 'byref' , 'no');

    if ( $tcpar_USE_FDIAG_EVAL eq 'yes' ) {
        ( $tcpar_FD_GetTime_href, $tcpar_FD_EvalTime_href, $tcpar_FD_EvalSignal_href ) = GEN_get_trace_eval_params('FD');
    }

    # ------------------------------------------------------------------------
    $tcpar_USE_SPI_EVAL = S_read_optional_testcase_parameter('USE_SPI_EVAL'  , 'byref' , 'no' );

    if ( $tcpar_USE_SPI_EVAL eq 'yes' ) {
		# received tcpar will be used from functions FuncLib_TNT_GEN::GEN_EVAL....
        ( $tcpar_SPI_GetTime_href, $tcpar_SPI_EvalTime_href, $tcpar_SPI_EvalSignal_href ) = GEN_get_trace_eval_params('SPI');
        # TODO : remove later
	    # print Dumper($tcpar_SPI_GetTime_href);
	    # print Dumper($tcpar_SPI_EvalTime_href);
	    # print Dumper($tcpar_SPI_EvalSignal_href);    
    }

# _SPI_TRACE_PlotSignals

    # ------------------------------------------------------------------------
    # Show test case ID in report
    $tcpar_SRT_Id = S_read_testcase_parameter('SRT_ID');
	
    return 1;
}

#******************************************************************************************************
#                                      TEST CASE INITIALIZATION                                       *
#******************************************************************************************************
sub TC_initialization {

    CSM_init() || return;   # initialize CSM Container handling

    $cont_id = S_get_date_extension() . "__" . $tc_parameter_name;
    CSM_create_container( $cont_id );
	CSM_add_keywords( $cont_id, [ 'init-state-phase' ] );
	
	S_teststep( "Initialize ECU", 'NO_AUTO_NBR' );

    LC_ECU_On();
    S_wait_ms(1000);

    PD_ECUlogin();
    S_teststep_2nd_level( "PD_ReadFaultMemory", 'NO_AUTO_NBR' );
    $flt_mem_struct = PD_ReadFaultMemory(1);

    S_teststep_2nd_level( "PD_ClearFaultMemory", 'NO_AUTO_NBR' );
    PD_ClearFaultMemory();
    S_wait_ms(9000);
    $flt_mem_struct = PD_ReadFaultMemory(1);

    # Prepare data for Fast Diagnosis
    if ( $tcpar_USE_FDIAG_RECORD eq 'yes' ) {
        my $FD_VarName_labels_aref  = [];
        my $FD_VarName_formats_aref = [];

        $FastDiag_labels_href = {};

        foreach my $FD_var_name (@tcpar_FastDiagVar) {

            # extract  FD_VarName_labels and  FD_VarName_formats
            $FD_var_name =~ /(.+)_(\w+)$/;
            S_w2rep( " FastDiagVar : VAR : $FD_var_name LABEL : $1 FORMAT: => $2 \n", "green" );
            push( @$FD_VarName_labels_aref,  $1 );
            push( @$FD_VarName_formats_aref, $2 );

            $FastDiag_labels_href->{$FD_var_name} = $1;
        }

        $FDtrace = "FD_" . time();

        S_teststep( "Start PD Measurement (active with next PowerOn cycle", 'NO_AUTO_NBR' );
        PD_StartFastDiagName(
            $main::REPORT_PATH . "/$FDtrace.txt",
            \@tcpar_FastDiagVar ,	# $FD_VarName_labels_aref,
            $FD_VarName_formats_aref,
            undef,
            undef,
            1    # is next power on cycle
        );
    }

    S_wait_ms(1000);

    S_teststep( "Power OFF ECU", 'NO_AUTO_NBR' );
    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

    if ( defined $tcpar_USE_PT and $tcpar_USE_PT eq 'yes' ) {
        S_teststep( "Configuring pre trigger modules", 'AUTO_NBR' );
        foreach my $pt_module ( keys %$pretrigger_load_module ) {
            my $thisCommand     = $pretrigger_load_module->{$pt_module}->{'PT_Command'};
            my $thisNode        = $pretrigger_load_module->{$pt_module}->{'PT_Node'};
            my $activeTime_us   = $pretrigger_load_module->{$pt_module}->{'PT_ActiveTime_us'};
            my $thisSignal      = $pretrigger_load_module->{$pt_module}->{'PT_SignalName'};
            my $thisSignalValue = $pretrigger_load_module->{$pt_module}->{'PT_SignalValue'};
            S_teststep_2nd_level( "Prepare PreTrigger $thisNode :: $thisCommand :: $thisSignal  (value : $thisSignalValue ) (active for $activeTime_us us))", 'AUTO_NBR' );
            return unless SPI_load_pretrigger_module(
                'PT_Node'          => $thisNode,
                'PT_ActiveTime_us' => $activeTime_us,
                'PT_Command'       => $thisCommand,
                'PT_MOSI_Signal'   => $thisSignal,
                'PT_Signal_Value'  => $thisSignalValue
            );
			CSM_add_keywords( $cont_id, ["PRE_TRIGGER -- $thisNode :: $thisCommand :: $thisSignal = $thisSignalValue"] );
        }
    }

    S_teststep( "Pre-Loading SPI signals manipulations", 'AUTO_NBR' );
    foreach my $sig_cnt ( keys %$spi_load_signal ) {
        my $thisSignal  = $spi_load_signal->{$sig_cnt}{'Signal'};
        my $thisCommand = $spi_load_signal->{$sig_cnt}{'Command'};
        my $thisNode    = $spi_load_signal->{$sig_cnt}{'Node'};
        my $thisDocu    = $spi_load_signal->{$sig_cnt}{'docu'};
        S_teststep_2nd_level( "Prepare signal(s) $thisNode :: $thisCommand :: $thisSignal", 'AUTO_NBR' );
        S_teststep_2nd_level( "Purpose : $thisDocu", 'NO_AUTO_NBR' ) if defined $thisDocu;

        if ( ( defined $tcpar_Sig_Signals_and_Values ) or ( defined $tcpar_Sig_Signals_Times_Values ) ) {
            return unless SPI_load_signal_manipulation(
                'Node'                 => $spi_load_signal->{$sig_cnt}{'Node'},
                'SMI7_Module'          => $spi_load_signal->{$sig_cnt}{'SMI7_Module'},
                'SMI7_Page'            => $spi_load_signal->{$sig_cnt}{'SMI7_Page'},
                'Command'              => $spi_load_signal->{$sig_cnt}{'Command'},
                'Duration_ms'          => $spi_load_signal->{$sig_cnt}{'Duration_ms'},
                'FrameCycles'          => $spi_load_signal->{$sig_cnt}{'FrameCycles'},
                'PreTriggers'          => $spi_load_signal->{$sig_cnt}{'PreTriggers'},
                'Signals_and_Values'   => $spi_load_signal->{$sig_cnt}{'Signals_and_Values'},
                'Signals_Times_Values' => $spi_load_signal->{$sig_cnt}{'Signals_Times_Values'},
            );
			CSM_add_keywords( $cont_id, ["SPI_SIGNAL -- $thisNode :: $thisCommand :: $thisSignal"] );
        }
        else {
            return unless SPI_load_signal_manipulation(
                'Node'              => $spi_load_signal->{$sig_cnt}{'Node'},
                'SMI7_Module'       => $spi_load_signal->{$sig_cnt}{'SMI7_Module'},
                'SMI7_Page'         => $spi_load_signal->{$sig_cnt}{'SMI7_Page'},
                'Command'           => $spi_load_signal->{$sig_cnt}{'Command'},
                'Signal'            => $spi_load_signal->{$sig_cnt}{'Signal'},
                'SignalValues'      => $spi_load_signal->{$sig_cnt}{'SignalValues'},
                'SignalValue'       => $spi_load_signal->{$sig_cnt}{'SignalValue'},
                'SignalTimesValues' => $spi_load_signal->{$sig_cnt}{'SignalTimesValues'},
                'Duration_ms'       => $spi_load_signal->{$sig_cnt}{'Duration_ms'},
                'FrameCycles'       => $spi_load_signal->{$sig_cnt}{'FrameCycles'},
                'PreTriggers'       => $spi_load_signal->{$sig_cnt}{'PreTriggers'},
            );
			CSM_add_keywords( $cont_id, ["SPI_SIGNAL -- $thisNode :: $thisCommand :: $thisSignal"] );
        }
    }
		
    return 1;
}

#******************************************************************************************************
#                                   STIMULATION AND MEASUREMENT                                       *
#******************************************************************************************************
sub TC_stimulation_and_measurement {

	
    if ( defined $tcpar_USE_SPI_SIGNALS and $tcpar_USE_SPI_SIGNALS eq 'yes' ) {
		S_teststep( "Start SPI Manipulation", 'AUTO_NBR' );
		SPI_start_manipulation() || return;
	}
	
    if ( defined $tcpar_USE_SPI_TRACE and $tcpar_USE_SPI_TRACE eq 'yes' ) {

		# TODO : add here also SPI nodes which have to be measured / evaluated
		
        # trace ALL SPI devices which are going to be manipulated
		my $prev_node = "";
        foreach my $count ( 1 .. $MAX_MANIPULATION ) {
            my $node = $spi_load_signal->{$count}->{'Node'};
            next if ( $prev_node eq $node );    #Skip if both the signal is for same node
            push @nodes_for_SPI_trace, $node if defined $node;
            $prev_node = $node;
        }
		
		if( scalar @nodes_for_SPI_trace ) {
			S_teststep( "Start SPI Trace for Nodes " . join( ' ' , @nodes_for_SPI_trace ) . "", 'AUTO_NBR' );
			SPI_trace_start( [@nodes_for_SPI_trace] ) || return;
		} 
		else {   #  when no manipulation planned but trace required
			S_teststep( "Start SPI Trace" , 'AUTO_NBR' );
			SPI_trace_start( ) || return;
		}
    }
	
	if ( defined $tcpar_USE_LA_TRACE and $tcpar_USE_LA_TRACE eq 'yes' ) {
		S_teststep( "Start Logic Analzyer Trace", 'AUTO_NBR' );
		SPI_logicanalyzer_start() || return;
	}
	
    S_wait_ms(500);                             # just wait some time before switching on the ECU

    S_teststep( "Power ON ECU", 'AUTO_NBR' );
    LC_ECU_On();

    # Wait until fault is qualified
    S_teststep( "Wait $tcpar_WaitTimeAfterPowerUp_ms ms ", 'AUTO_NBR' );
    S_wait_ms($tcpar_WaitTimeAfterPowerUp_ms);
	
	if ( defined $tcpar_USE_SPI_TRACE and $tcpar_USE_SPI_TRACE eq 'yes' ) {
		S_teststep( "Stop SPI Trace", 'AUTO_NBR' );
		my $SPI_trace_orig_size_Bytes = SPI_trace_stop();
		S_w2rep( "Trace stopped with captured " . int ( $SPI_trace_orig_size_Bytes / 1000 ) . " kBytes\n" );
	}
	
	if ( defined $tcpar_USE_LA_TRACE and $tcpar_USE_LA_TRACE eq 'yes' ) {
		S_teststep( "Stop Logic Analzyer Trace", 'AUTO_NBR' );
		SPI_logicanalyzer_stop(); 
	}
	
    if ( $tcpar_USE_FDIAG_RECORD eq 'yes' ) {    # Fast Diagnosis active?
        S_teststep( "PD_StopFastDiag ", 'AUTO_NBR' );
        PD_StopFastDiag();
        $FD_data = PD_get_FDtrace( $main::REPORT_PATH . "/$FDtrace.txt" );
        my $FD_trace = "FD_trace_" . time();
        EVAL_dump2file( $FD_data, $main::REPORT_PATH . "/$FD_trace.txt" );
        PD_plot_FDtrace( $FD_data, $main::REPORT_PATH . "/$FDtrace.png" );
        S_add_pic2html( "./$FDtrace.png", '', "./$FDtrace.txt.unv", 'TYPE="text/unv"' );
		CSM_add_userfile( $cont_id, "./$FDtrace.png" , "SW_Vars_Daq_Dump_PNG" );   #  TODO
		CSM_add_userfile( $cont_id, "./$FDtrace.txt.unv" , "SW_Vars_Daq_Dump_UNV" );   #  TODO
		
		S_dump2pmFile(
			"VariableToDump" => $FD_data,
			"VariableName"   => "SW_Vars_Daq",
			"PackageName"    => "SW_Vars_Daq_Dump",
			"StoragePath"    => $main::REPORT_PATH,
		);
		my $daq_dump_file_name = $main::REPORT_PATH . "/SW_Vars_Daq_Dump.pm";
		unless ( -f $daq_dump_file_name ) {
			S_set_error("S_dump2pmFile doesnt created file : $daq_dump_file_name ");
			return;
		}
		CSM_add_userfile( $cont_id, $daq_dump_file_name, "SW_Vars_Daq_Dump" );
		CSM_add_keywords( $cont_id, ["SW_Vars_Daq_Dump"] );
		S_w2rep(" Delete file $daq_dump_file_name \n");
		unlink $daq_dump_file_name;    # delete local file in Report folder !!
    }

    if ( $tcpar_USE_VAR_EVAL eq 'yes' ) {        # Read PD RAM variables?
        my $SW_vars_href = {};
		S_teststep( "Reading PD_ReadMemoryByName ", 'AUTO_NBR' );
        foreach my $i ( 0 .. $#Eval_Var_Label ) {
            S_teststep_2nd_level( "Reading Var $Eval_Var_Label[$i]", 'AUTO_NBR' );
            $detected_var[$i] = S_aref2hex( PD_ReadMemoryByName($Eval_Var_Label[$i]) );
			$SW_vars_href->{$i}{$Eval_Var_Label[$i]} = $detected_var[$i];
			CSM_add_keywords( $cont_id, ["PD_SW_Variable -- $Eval_Var_Label[$i]"] );
        }
        S_dump2pmFile(
            "VariableToDump" => $SW_vars_href,
            "VariableName"   => "SW_Vars",
            "PackageName"    => "PD_SW_Vars_Dump",
            "StoragePath"    => $main::REPORT_PATH,
        );
        my $sw_vars_file = $main::REPORT_PATH . "/PD_SW_Vars_Dump.pm";
        CSM_add_userfile( $cont_id, $sw_vars_file_init, "PD_SW_Vars_Dump" );
        CSM_add_keywords( $cont_id, ["PD_SW_Vars_Dump"] );
        S_w2rep(" Delete file $sw_vars_file \n");
        unlink $sw_vars_file if -f $sw_vars_file;    # delete local file in Report folder !!
    }
    S_teststep( "Read Fault Memory - type PRIMARY", 'AUTO_NBR');
    $flt_mem_struct       = PD_ReadFaultMemory(1);  # Primary Fault Memory
    S_teststep( "Read Fault Memory - type BOSCH", 'AUTO_NBR');
    $flt_mem_struct_plant = PD_ReadFaultMemory(3);  # Bosch Fault Memory 

	S_dump2pmFile(
		"VariableToDump" => $flt_mem_struct,
		"VariableName"   => "FaultMemoryData",
		"PackageName"    => "PD_ReadFaultMemory_Dump",
		"StoragePath"    => $main::REPORT_PATH,
	);
	my $PD_fcm_file = $main::REPORT_PATH . "/PD_ReadFaultMemory_Dump.pm";
	CSM_add_userfile( $cont_id, $PD_fcm_file, "PD_ReadFaultMemory_Dump" );
	CSM_add_keywords( $cont_id, ["PD_ReadFaultMemory_Dump"] );
	S_w2rep(" Delete file $PD_fcm_file \n");
	unlink $PD_fcm_file if -f $PD_fcm_file;    # delete local file in Report folder !!

    if ( defined $tcpar_USE_SPI_SIGNALS and $tcpar_USE_SPI_SIGNALS eq 'yes' ) {
		S_teststep( "Stop Manipulation", 'AUTO_NBR');  # including check of Manipulation counter
		SPI_stop_manipulation();
        CSM_add_keywords( $cont_id, ["SPI_manipulation__YES"] );
	}
	else {
        CSM_add_keywords( $cont_id, ["SPI_manipulation__NO"] );
	}
	
    if ( defined $tcpar_USE_SPI_TRACE and $tcpar_USE_SPI_TRACE eq 'yes' ) {
		S_teststep( "Store SPI Trace", 'AUTO_NBR');
		$SPI_tracefile_name = SPI_trace_store();
		
        CSM_add_userfile( $cont_id, $SPI_tracefile_name, "SPI_Trace_file" );
        CSM_add_keywords( $cont_id, ["SPI_trace__YES"] );
#        CSM_add_keywords( $cont_id, ["SPI_Trace_size_bytes__". $SPI_trace_orig_size_Bytes ] );
        if( scalar @nodes_for_SPI_trace ) {
			CSM_add_keywords( $cont_id, [ 'SPI_trace_node__' . $_ ] ) foreach (@nodes_for_SPI_trace);
		}
	
        S_w2rep( " Delete file $SPI_tracefile_name \n", 'grey' );
        unlink $SPI_tracefile_name if -f $SPI_tracefile_name;          # delete local file in Report folder !!	
	}
	else {
        CSM_add_keywords( $cont_id, ["SPI_trace__NO"] );
	}
	
	if (defined $tcpar_USE_LA_TRACE and $tcpar_USE_LA_TRACE eq 'yes' ) {
		S_teststep( "Store Logic Analzyer Trace", 'AUTO_NBR' );
#		my $LA_label='SPI_LA_TRACE.law';
#		my $tcpar_LA_template_path = S_read_mandatory_testcase_parameter( 'LA_template_path', 'byref', 'no' );
#		unless( defined $tcpar_LA_template_path ) { 
#				S_set_error( "LA Template path is not defined" ); FSPI
#			}
#		SPI_logicanalyzer_store($LA_label,$tcpar_LA_template_path);
		
		my $stored_LA_dump_file_name = SPI_logicanalyzer_store( );
		S_w2rep( "Stored Logic Analyzer File : $stored_LA_dump_file_name \n" );

         CSM_add_userfile( $cont_id, $stored_LA_dump_file_name, "LogicAnalyzer_Dump" );
         CSM_add_keywords( $cont_id, ["LogicAnalyzer_Dump"] );
         S_w2rep( " Delete file $stored_LA_dump_file_name \n", 'grey' );
         unlink $stored_LA_dump_file_name if -f $stored_LA_dump_file_name;          # delete local file in Report folder !!
				
	}
		
	if( defined $tcpar_CheckManipulation ) { 
		S_teststep( "SPI_get_manipulation_counter()", 'AUTO_NBR' );
        my $manip_counter_href = SPI_get_manipulation_counter() || return;
		foreach my $manip_module ( sort keys %$tcpar_CheckManipulation ) {
			my $manip_counter_detected = $manip_counter_href->{$manip_module};
			unless( defined $manip_counter_detected ) { 
				S_set_error( "Could not get expected Manipulation coutner of Module nbr $manip_module" ); next;
			}
			S_teststep_2nd_level( "Read SPI Manipulation Counter Module Nbr $manip_module", 'AUTO_NBR' , "ManipModul_".$manip_module );
			$tcpar_CheckManipulation->{$manip_module}{DETECTED} = $manip_counter_detected;
			S_teststep_detected( "SPI Manipulation Counter Module $manip_module : $manip_counter_detected Frames manipulated", "ManipModul_".$manip_module );
		}
    }

	 S_w2rep( " CSM Close Container '$cont_id'\n", "blue" );
     CSM_pack_container($cont_id);

     S_w2rep( " CSM Archive container '$cont_id'\n", "blue" );
     CSM_archive_container( $cont_id, 'KeepLocalData' );


    return 1;
}

#******************************************************************************************************
#                                        TEST CASE EVALUATION                                         *
#******************************************************************************************************
sub TC_evaluation {


	if( defined $tcpar_CheckManipulation ) {
		foreach my $manip_module ( sort keys %$tcpar_CheckManipulation ) {
			my $manip_counter_min = $tcpar_CheckManipulation->{$manip_module}{MIN};
			my $manip_counter_max = $tcpar_CheckManipulation->{$manip_module}{MAX};
			my $manip_counter_det = $tcpar_CheckManipulation->{$manip_module}{DETECTED};
			S_teststep_expected( "SPI Manipulation Counter Module $manip_module : $manip_counter_min .. x .. $manip_counter_max", "ManipModul_".$manip_module );
			EVAL_evaluate_interval( "Manipulation Counter", $manip_counter_min, $manip_counter_max, $manip_counter_det );
		}
    }

    # Evaluate Fault Memory
    PD_evaluate_faults( $flt_mem_struct, \@tcpar_FLTmand );

    if ( $tcpar_USE_FLT_EVAL eq 'yes' ) {    # Check for mandatory faults?
        foreach my $fault_name ( keys %$tcpar_FLT_state_href ) {
            next unless PD_count_fault( $flt_mem_struct, $fault_name );

            # TODO : teststep functions to be added
            my $fault_state = $tcpar_FLT_state_href->{$fault_name};
		    if ( defined $fault_state ) {
                PD_check_fault_status( $flt_mem_struct, $fault_name, $fault_state, 'state' );
            }
            else {
                S_set_warning("Missing Fault State for Fault '$fault_name'");
            }

            # TODO : teststep functions to be added
            my $dtc_expected = $tcpar_DTC_exp_href->{$fault_name};
			if ( defined $dtc_expected ) {
                my $fault_index = PD_get_fault_index( $flt_mem_struct, $fault_name );
                my $dtc_detected = $flt_mem_struct->{'DTC'}->[$fault_index];
                EVAL_evaluate_string( 'DTC', $dtc_expected, $dtc_detected );
            }
            else {
                S_set_warning("Missing DTC for Fault '$fault_name'");
                next;
            }
        }
    }

    # Evaluate variables
    # TODO : teststep functions to be added
    if ( $tcpar_USE_VAR_EVAL eq 'yes' ) {
        foreach my $i ( 0 .. $#Eval_Var_Label ) {
            S_w2log( 3, $tcpar_EvalVarDocu[$i], "blue" );
            EVAL_evaluate_value( $Eval_Var_Label[$i], $detected_var[$i], $Eval_Var_Operator[$i], $Eval_Var_Value[$i] );
        }
    }

    # Evaluate Fast Diagnosis trace
    if ( $tcpar_USE_FDIAG_EVAL eq 'yes' ) {
        foreach my $timeStampNbr ( sort { $a <=> $b } keys %{$tcpar_FD_GetTime_href} ) {
            my $signalLabel = $tcpar_FD_GetTime_href->{$timeStampNbr}->{'SignalLabel'};
            $tcpar_FD_GetTime_href->{$timeStampNbr}->{'SignalLabel'} = $FastDiag_labels_href->{$signalLabel};
        }

        my ( $verdict, $sequence_time_value_href ) = GEN_EVAL_trace_sequence( $FD_data, $tcpar_FD_GetTime_href );

        if ( $verdict eq 'PASS' ) {
            GEN_EVAL_trace_times( $FD_data, $sequence_time_value_href, $tcpar_FD_EvalTime_href )
              if ( defined $tcpar_FD_EvalTime_href );
            GEN_EVAL_trace_signals( $FD_data, $sequence_time_value_href, $tcpar_FD_EvalSignal_href )
              if ( defined $tcpar_FD_EvalSignal_href );
        }
    }

	# Evaluate SPI trace	
	if ( $tcpar_USE_SPI_EVAL eq 'yes' ) {
	    
		my $meas_label = 'SPI_Measurement';
	    SPI_trace_load_file(
	        'MeasurementLabel' => $meas_label,
	        'FileName'         => $SPI_tracefile_name,
	    );
    
	    foreach my $SPI_node (@nodes_for_SPI_trace) {
	        my $measurement_temp_href = SPI_trace_get_dataref(
	            'MeasurementLabel' => $meas_label,
	            'SPI_Node'         => $SPI_node,
	        );
        
	        S_dump2pmFile (    "VariableToDump" => $measurement_temp_href );  # TODO : to be deleted after development

			# hash slices in order to comnbine to hashes ( See perl docu )
	        @{$SPI_data}{ keys %$measurement_temp_href } = values %$measurement_temp_href;
	    }

		S_teststep( "----------------------------- Evaluate SPI Trace -----------------------------", 'NO_AUTO_NBR' );
	    
	    my ( $verdict, $sequence_time_value_href );
	    if( defined $tcpar_SPI_GetTime_href ) {
	       ($verdict, $sequence_time_value_href) = GEN_EVAL_trace_sequence($SPI_data, $tcpar_SPI_GetTime_href);
	    }

#	    if($verdict eq 'PASS' and defined $tcpar_SPI_EvalTime_href ){   # TODO : to be checked whether we need the check for PASS
	    if( defined $tcpar_SPI_EvalTime_href ){
#	        my $verdictTimes = GEN_EVAL_trace_times($SPI_data, $sequence_time_value_href, $tcpar_SPI_EvalTime_href);
#	        my $verdictSignals = GEN_EVAL_trace_signals($SPI_data, $sequence_time_value_href, $tcpar_SPI_EvalSignal_href) if(defined $tcpar_SPI_EvalSignal_href);
	        GEN_EVAL_trace_times($SPI_data, $sequence_time_value_href, $tcpar_SPI_EvalTime_href);
	    }
#	    if($verdict eq 'PASS' and defined $tcpar_SPI_EvalSignal_href ){    # TODO : to be checked whether we need the check for PASS
	    if( defined $tcpar_SPI_EvalSignal_href ) {
	        GEN_EVAL_trace_signals($SPI_data, $sequence_time_value_href, $tcpar_SPI_EvalSignal_href);
	    }
	}

    return 1;
}

#******************************************************************************************************
#                                        TEST CASE FINALIZATION                                       *
#******************************************************************************************************
sub TC_finalization {

    PD_ClearFaultMemory();

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

    return 1;
}

sub _Convert_to_function_call {

    my $signal_docu            = shift;
    my $signalName             = shift;
    my $sig_Value              = shift;
    my $sig_Duration_ms        = shift;
    my $sig_FrameCycles        = shift;
    my $sig_Values             = shift;
    my $sig_TimesValues        = shift;
    my $smi7_Module            = shift;
    my $smi7_Page              = shift;
    my $preTrigger             = shift;
    my $preTriggers_aref       = shift;
    my $sig_Signals_and_Values      = shift;
    my $sig_Signals_Times_Values = shift;
    
	$manip_counter++;                                 # global variable 

	S_w2log(4 , " TC_UNI_SPI_Init_01::_Convert_to_function_call : Preparing Signal $signalName ( module '$manip_counter' )\n" );
	
    $spi_load_signal->{$manip_counter}->{'docu'} = $signal_docu
      if ( defined $signal_docu );    # signal/command docu

    my @sig_details = split( /::/, $signalName );
    unless ( scalar @sig_details == 3 ) {
        S_set_error("wrong signal definition given : $signalName ");
        return;
    }
    $spi_load_signal->{$manip_counter}->{'Node'}    = $sig_details[0];    # node name
    $spi_load_signal->{$manip_counter}->{'Command'} = $sig_details[1];    # command name
    $spi_load_signal->{$manip_counter}->{'Signal'}  = $sig_details[2];    # signal name

    if ( defined $sig_Value and defined $sig_FrameCycles ) {
        $spi_load_signal->{$manip_counter}->{'SignalValue'} = $sig_Value;          # scalar (static)
        $spi_load_signal->{$manip_counter}->{'FrameCycles'} = $sig_FrameCycles;    # scalar (static)
    }
    elsif ( defined $sig_Values and defined $sig_FrameCycles ) {
        $spi_load_signal->{$manip_counter}->{'SignalValues'} = $sig_Values;         # aref (SPI_MODE -> values)
        $spi_load_signal->{$manip_counter}->{'FrameCycles'}  = $sig_FrameCycles;    # aref (SPI_MODE -> frames)
    }
    elsif ( defined $sig_TimesValues and ref $sig_TimesValues eq 'HASH' ) {
        $spi_load_signal->{$manip_counter}->{'SignalTimesValues'} = $sig_TimesValues;    # href (TIMER_MODE -> times and values)
    }
    if ( defined $sig_Duration_ms and defined $sig_Value ) {
        $spi_load_signal->{$manip_counter}->{'Duration_ms'} = $sig_Duration_ms;
        $spi_load_signal->{$manip_counter}->{'SignalValue'} = $sig_Value;
    }
    if ( defined $smi7_Module ) {
        $spi_load_signal->{$manip_counter}->{'SMI7_Module'} = $smi7_Module;
    }
    if ( defined $smi7_Page ) {
        $spi_load_signal->{$manip_counter}->{'SMI7_Page'} = $smi7_Page;
    }
    if (    defined $sig_Value
        and not defined $sig_Duration_ms
        and not defined $sig_FrameCycles )
    {
        $spi_load_signal->{$manip_counter}->{'SignalValue'} = $sig_Value;
    }

    if ( defined $preTrigger ) {
        push( @{ $spi_load_signal->{$manip_counter}->{'PreTriggers'} }, $preTrigger );
    }

    if ( defined $preTriggers_aref ) {
        $spi_load_signal->{$manip_counter}->{'PreTriggers'} = $preTriggers_aref;
    }
    if ( defined $sig_Signals_and_Values and ref $sig_Signals_and_Values eq 'HASH' ) {
        $spi_load_signal->{$manip_counter}->{'Signals_and_Values'} = $sig_Signals_and_Values;    # href (TIMER_MODE -> times and values)
    }
    if ( defined $sig_FrameCycles ) {
        $spi_load_signal->{$manip_counter}->{'FrameCycles'} = $sig_FrameCycles;        # href (TIMER_MODE -> times and values)
    }
    if ( defined $sig_Duration_ms ) {
        $spi_load_signal->{$manip_counter}->{'Duration_ms'} = $sig_Duration_ms;        # href (TIMER_MODE -> times and values)
    }

    if ( defined $sig_Signals_Times_Values and ref $sig_Signals_Times_Values eq 'HASH' ) {
        my $signals_Times_Values;
        foreach my $sub_signal_in_same_frame ( keys %{$sig_Signals_Times_Values} ) {
            my $value = $sig_Signals_Times_Values->{$sub_signal_in_same_frame};

            my @Times_values = split( /\|/, $value );
            my @Times        = split( /:/,  $Times_values[0] );                        #0, 1000, 4000
            my @Values       = split( /:/,  $Times_values[1] );                        # 0, 1,

            unless ( scalar @Times == scalar @Values ) {
                S_set_error("wrong number of times and values given for signal $sub_signal_in_same_frame ");
                return;
            }

            foreach my $time_value_pair_index ( 0 .. ( scalar @Times ) - 1 ) {
                $signals_Times_Values->{$sub_signal_in_same_frame}->{ $Times[$time_value_pair_index] } = $Values[$time_value_pair_index];
            }
        }

        $spi_load_signal->{$manip_counter}->{'Signals_Times_Values'} = $signals_Times_Values;    # href (TIMER_MODE -> times and values)

    }
    return 1;
}

1;

__END__
