#
# only for taking version info into a package
#
package TC_UNI_SWITCH_State_Change_01;

use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.25 $;
our $HEADER  = q$Header: UNIVERSAL/TC_UNI_SWITCH_State_Change_01.pm 1.25 2017/11/28 21:37:42ICT GCH2SZH develop  $;

=head1 TESTCASE MODULE

TC_UNI_SWITCH_State_Change_01__EVAL_Network

=head1 PURPOSE

 .....

=head1 TESTCASE DESCRIPTION

 .....


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'Switch' => 
	SCALAR 'Network_Signal' 
    HASH   'Signal_values' => with different pairs of expected States and Values
    SCALAR 'Switch_Init_State' => 
	SCALAR 'Switch_Test_State' => 
    

=head2 PARAMETER EXAMPLES

	[TC_UNI_SWITCH_State_Change_01__EVAL_Network.PADS1]
    purpose	= 'To check Network Signals of switch PADS1 for all available measurements'
	Switch = 'PADS1'
    Network_Signal = 'ACU_PassengerAirbagStatus'
    Signal_values = %( 'InitValue' => 0 , 'PositionA' => 1 , 'PositionB' => 2 , 'Short2GND' => 3 , 'OpenLine' => 4 , 'Undefined' => 5 )
	
    [TC_UNI_SWITCH_State_Change_01__EVAL_Network.PADS1_PositionB]
    purpose = 'To check Network Signals of switch PADS1 only for init-phase measurement of PositionB '
    Switch = 'PADS1'
    Switch_Init_State =  'PositionB'             # optional
    Network_Signal = 'ACU_PassengerAirbagStatus'
    Signal_values = %(  'InitValue' => 0 , 'PositionB' => 2 )
    
    [TC_UNI_SWITCH_State_Change_01__EVAL_Network.PADS1_PositionB_PositionA]
    purpose = 'To check Network Signals of switch PADS1 only for measurement of state change from PositionB to PositionA'
    Switch = 'PADS1'
    Switch_Init_State =  'PositionB'             # optional
    Switch_Test_State =  'PositionA'             # optional
    Network_Signal = 'ACU_PassengerAirbagStatus'
    Signal_values = %(  'InitValue' => 0 , 'PositionA' => 1 , 'PositionB' => 2 )
    
=cut

#------------------------------------------------------------------------------
#
# TEST CASE MODULE   ---  TC_UNI_SWITCH_State_Change_01__EVAL_Network
#
package TC_UNI_SWITCH_State_Change_01__EVAL_Network;
#
#------------------------------------------------------------------------------

use strict;
use warnings;

use LIFT_general;
use LIFT_evaluation;
use LIFT_CSM;
use LIFT_NET_access;

my $tcpar_Switch;
my $tcpar_Network_Signal;
my $tcpar_Switch_Init_State;
my $tcpar_Switch_Test_State;
my $tcpar_Signal_values_href;
my $tcpar_Signal_unit;

my @Container_IDs_matching                 = ();
my @query_InitState_Container_IDs_matching = ();
my @query_TestState_Container_IDs_matching = ();

sub TC_set_parameters {

    undef $tcpar_Signal_values_href;

    $tcpar_Switch             = S_read_mandatory_testcase_parameter('Switch');
    $tcpar_Network_Signal     = S_read_mandatory_testcase_parameter('Network_Signal');
    $tcpar_Signal_values_href = S_read_mandatory_testcase_parameter('Signal_values');
    $tcpar_Signal_unit        = S_read_optional_testcase_parameter( 'Signal_unit', 'n/a' );    # not used currently
    $tcpar_Switch_Init_State  = S_read_optional_testcase_parameter('Switch_Init_State');
    $tcpar_Switch_Test_State  = S_read_optional_testcase_parameter('Switch_Test_State');

    return 1;
}

sub TC_initialization {
    CSM_init() || return;
    NET_Init() || return;

    S_w2log( 3, " CSM search container in Local Working Area via keywords\n", "blue" );

    if (    not defined $tcpar_Switch_Init_State
        and not defined $tcpar_Switch_Test_State )
    {
        S_w2rep( " Search Container : Switch = $tcpar_Switch \n", "blue" );
        @Container_IDs_matching = CSM_search_local_container(
            {
                'keywords_fully'     => ["switch-name-$tcpar_Switch"],
                'keywords_partially' => [ "Network_", "-state-phase", "switch-state-" ],
            }
        );

    }
    elsif ( defined $tcpar_Switch_Init_State
        and not defined $tcpar_Switch_Test_State )
    {
        S_w2rep( " Search Container : Switch = $tcpar_Switch and Init-State = $tcpar_Switch_Init_State \n", "blue" );
        @query_InitState_Container_IDs_matching = CSM_search_local_container(
            {
                'keywords_fully'     => [ "switch-name-$tcpar_Switch", 'init-state-phase', "switch-state-$tcpar_Switch_Init_State" ],
                'keywords_partially' => ["Network_"],
            }
        );

    }
    elsif ( not defined $tcpar_Switch_Init_State
        and defined $tcpar_Switch_Test_State )
    {
        S_w2rep( " Search Container : Switch = $tcpar_Switch and Test-State = $tcpar_Switch_Test_State \n", "blue" );
        @query_TestState_Container_IDs_matching = CSM_search_local_container(
            {
                'keywords_fully'     => [ "switch-name-$tcpar_Switch", 'test-state-phase', "switch-state-$tcpar_Switch_Test_State" ],
                'keywords_partially' => ["Network_"],
            }
        );
    }
    elsif ( defined $tcpar_Switch_Init_State
        and defined $tcpar_Switch_Test_State )
    {
        S_w2rep( " Search Container : Switch = $tcpar_Switch and Init-State = $tcpar_Switch_Init_State and Test-State = $tcpar_Switch_Test_State (Init State Phase)\n", "blue" );
        @query_InitState_Container_IDs_matching = CSM_search_local_container(
            {
                'keywords_fully'     => [ "switch-name-$tcpar_Switch", 'init-state-phase', "switch-state-$tcpar_Switch_Init_State", "followed-switch-state-$tcpar_Switch_Test_State" ],
                'keywords_partially' => ["Network_"],
            }
        );

        S_w2rep( " Search Container : Switch = $tcpar_Switch and Init-State = $tcpar_Switch_Init_State and Test-State = $tcpar_Switch_Test_State (Test State Phase)\n", "blue" );
        @query_TestState_Container_IDs_matching = CSM_search_local_container(
            {
                'keywords_fully'     => [ "switch-name-$tcpar_Switch", 'test-state-phase', "previous-switch-state-$tcpar_Switch_Init_State", "switch-state-$tcpar_Switch_Test_State" ],
                'keywords_partially' => ["Network_"],
            }
        );

    }

    push( @Container_IDs_matching, @query_InitState_Container_IDs_matching, @query_TestState_Container_IDs_matching );

    #
    # TODO : to be decided what to do when no container found
    #

    return 1;
}

sub TC_stimulation_and_measurement {
    return 1;
}

sub TC_evaluation {

  LOOP_CONTAINER:
    foreach my $container_id (@Container_IDs_matching) {
        S_w2rep( " CSM get container $container_id \n", "blue" );
        my $Container_Header = CSM_get_container($container_id) || return;

        my $keyword_listing_aref = $Container_Header->getKeywordListing();

        #
        # check for : switch-state-.....    (e.g. switch-state-PositionA)
        #
        my $used_switch_state;
        foreach my $keyword (@$keyword_listing_aref) {
            next unless $keyword =~ /^switch-state-/;    # e.g. switch-state-PositionA
            $used_switch_state = $keyword;
            $used_switch_state =~ s/^switch-state-//;
            last;                                        # Note : $used_switch_state is now e.g. PositionA or Undefined , ...
        }

        #
        # read for :
        #              init-state-phase
        #              test-state-phase
        #
        my $used_state_phase;
        foreach my $keyword (@$keyword_listing_aref) {
            next unless $keyword =~ /-state-phase/;    # e.g. init-state-phase or test-state-phase
            $used_state_phase = $keyword;
            last;                                      # Note : $used_state_phase = 'init-state-phase' or 'test-state-phase'
        }

        #
        # read for : previous-switch-state-.....    (e.g. previous-switch-state-PositionB)
        #
        my $used_previous_state;
        foreach my $keyword (@$keyword_listing_aref) {
            next unless $keyword =~ /^previous-switch-state-/;    # e.g. previous-switch-state-PositionB
            $used_previous_state = $keyword;
            $used_previous_state =~ s/^previous-switch-state-//;
            last;                                                 # Note : $used_previous_state = PositionB
        }

        #
        # read for : followed-switch-state-.....    (e.g. followed-switch-state-PositionB)
        #
        my $used_followed_state;
        foreach my $keyword (@$keyword_listing_aref) {
            next unless $keyword =~ /^followed-switch-state-/;    # e.g. followed-switch-state-PositionB
            $used_followed_state = $keyword;
            $used_followed_state =~ s/^followed-switch-state-//;
            last;                                                 # Note : $used_followed_state = PositionB
        }

        # previous-switch-state- ( is optional , required only for test-state-phase )

        my @all_defined_states = keys %{$tcpar_Signal_values_href};
        my $all_defined_states_text = join( " , ", @all_defined_states );

        unless ( defined $tcpar_Signal_values_href->{$used_switch_state} ) {
            S_w2rep("Signal Value of Signal '$tcpar_Network_Signal' for measured State '$used_switch_state' not given in TC Parameter 'Signal_values' (all defined : $all_defined_states_text)\n ");
            next LOOP_CONTAINER;
        }

        my $expected_Signal_value = $tcpar_Signal_values_href->{$used_switch_state};
        S_teststep_expected("Network Signal : '$tcpar_Network_Signal' => $expected_Signal_value (State : $used_switch_state)");

        my $expected_previous_Signal_value;
        if ( defined $used_previous_state ) {
            unless ( defined $tcpar_Signal_values_href->{$used_previous_state} ) {
                S_w2rep("Signal Value of Signal '$tcpar_Network_Signal' for measured Previous State '$used_previous_state' not given in TC Parameter 'Signal_values' (all defined : $all_defined_states_text)\n ");
                next LOOP_CONTAINER;
            }
            $expected_previous_Signal_value = $tcpar_Signal_values_href->{$used_previous_state};

            #            S_teststep_expected("Network Signal : '$tcpar_Network_Signal' => $expected_previous_Signal_value (for Previous State : $used_switch_state)");
        }

        my $expected_Signal_Init_value;
        if ( defined $tcpar_Signal_values_href->{'Init_Value'} ) {
            $expected_Signal_Init_value = $tcpar_Signal_values_href->{'Init_Value'};
        }

        #
        # container can have several user files
        #   each element in the container (user file) has a unique Content ID
        #
        S_w2log( 2, " CSM getContentIdentifiers 'UserFile' \n", 'blue' );
        my $found_userfile_ids_aref = $Container_Header->getContentIdentifiers('UserFile');
        unless ( scalar(@$found_userfile_ids_aref) ) {
            S_set_error("No ContentIdentifiers received , no userfiles are part of Container");
            next LOOP_CONTAINER;
        }

        my $used_userfile_Network_Vars_Dump;
        foreach my $user_file_ID (@$found_userfile_ids_aref) {
            next unless $user_file_ID =~ /Network_Vars_Dump/;
            $used_userfile_Network_Vars_Dump = $user_file_ID;
            last;
        }

        if ( defined $used_userfile_Network_Vars_Dump ) {
            S_w2log( 2, " CSM get userfile '$used_userfile_Network_Vars_Dump' ( with extraction) \n", 'blue' );
            my $userfile_object = CSM_get_userfile(    #    now with extracting (is default)
                $container_id,
                $used_userfile_Network_Vars_Dump,
                { extract => 1 },                      # option extract : 0 - no ; 1 - yes
            ) || next LOOP_CONTAINER;                  # next container

            my $filename_long_Network_Vars_Dump = $userfile_object->getFilename_long();
            S_w2rep( "UserFile extracted Name: $filename_long_Network_Vars_Dump \n", 'blue' );

            unless ( -e $filename_long_Network_Vars_Dump ) {
                S_set_error("Data file '$filename_long_Network_Vars_Dump' does not exist!");
                next LOOP_CONTAINER;
            }

            S_w2rep("Requiring Network data Dump $filename_long_Network_Vars_Dump\n");
            eval { require $filename_long_Network_Vars_Dump };
            if ($@) {
                S_set_error("Error occured while loading Network Data Dump '$filename_long_Network_Vars_Dump' : $@");
                next LOOP_CONTAINER;
            }

            my $network_data = $Network_Vars_Dump::Network_Vars;
            unless ( defined $network_data->{$tcpar_Network_Signal}{'Value'} ) {
                S_w2rep( "Network signal '$tcpar_Network_Signal' doesnt exist in Container '$container_id'", 'red' );
                next LOOP_CONTAINER;
            }

            my $obtained_Signal_value = $network_data->{$tcpar_Network_Signal}{'Value'};
            my $obtained_Signal_unit  = $network_data->{$tcpar_Network_Signal}{'Unit'};
            S_w2rep( "Network signal '$tcpar_Network_Signal' = $obtained_Signal_value [$obtained_Signal_unit] (found in Container '$container_id')", 'blue' );

            S_teststep_detected("Network Signal : '$tcpar_Network_Signal' => $obtained_Signal_value [$obtained_Signal_unit] (State : $used_switch_state)");
            EVAL_evaluate_value( " Network Signal '$tcpar_Network_Signal' : state '$used_switch_state' ", $obtained_Signal_value, '==', $expected_Signal_value );

        }

        my $used_userfile_Network_Trace;
        foreach my $user_file_ID (@$found_userfile_ids_aref) {
            next unless $user_file_ID =~ /Network_trace/;
            $used_userfile_Network_Trace = $user_file_ID;
            last;
        }

        if ( defined $used_userfile_Network_Trace ) {
            S_w2log( 2, " CSM get userfile '$used_userfile_Network_Trace' ( with extraction) \n", 'blue' );
            my $userfile_object = CSM_get_userfile(    #    now with extracting (is default)
                $container_id,
                $used_userfile_Network_Trace,
                { extract => 1 },                      # option extract : 0 - no ; 1 - yes
            ) || next LOOP_CONTAINER;                  # next container

            my $filename_long_Network_trace = $userfile_object->getFilename_long();
            S_w2rep( "UserFile extracted Name: $filename_long_Network_trace \n", 'blue' );

            unless ( -e $filename_long_Network_trace ) {
                S_set_error("Data file '$filename_long_Network_trace' does not exist!");
                next LOOP_CONTAINER;
            }

            S_w2rep( "Get Network trace data from Signal $tcpar_Network_Signal ( file: $filename_long_Network_trace) \n", 'blue' );
            my $Network_data_href = NET_trace_get_dataref(
                $filename_long_Network_trace,
                {
                    'SIGNALS' => [$tcpar_Network_Signal],
                }
            );

            unless ( defined $Network_data_href ) {
                S_w2rep( "Network signal '$tcpar_Network_Signal' doesnt exist in Container '$container_id'", 'red' );
                next LOOP_CONTAINER;
            }

            my $expected_signal_pattern;
            if ( $used_state_phase eq 'init-state-phase' ) {
                $expected_signal_pattern = $expected_Signal_Init_value . ":" . $expected_Signal_value;
            }
            if ( $used_state_phase eq 'test-state-phase' ) {
                $expected_signal_pattern = $expected_previous_Signal_value . ":" . $expected_Signal_value;
            }

            S_w2rep( "Performing Trace Evaluation $used_state_phase ( file: $filename_long_Network_trace )\n", "blue" );
            EVAL_evaluate_digital_pattern_over_time( $Network_data_href, $tcpar_Network_Signal, $expected_signal_pattern );

        }

        S_w2rep( "CSM clear container\n", 'blue' );
        CSM_clear_container($container_id);

    }

    return 1;
}

sub TC_finalization {
    return 1;
}

#------------------------------------------------------------------------------
#
# TEST CASE MODULE   ---  TC_UNI_SWITCH_State_Change_01__STIM
#
package TC_UNI_SWITCH_State_Change_01__STIM;
#
#------------------------------------------------------------------------------

#----------------------- TEST SPECIFICATION ------------------------------
#
# TODO : URL LINK TO TEST DESIGN TO BE ADDED HERE (ILM, BoschConnect)
#

#### INCLUDE ENGINE MODULES ####

use strict;
use warnings;
use File::Path;

use LIFT_general;
use LIFT_evaluation;
use LIFT_CSM;
use LIFT_PD;
use LIFT_CD;
use LIFT_labcar;
use FuncLib_SYC_INTERFACE;
use LIFT_NET_access;
use GENERIC_DCOM;
use INCLUDES_Project;

# use constant MAX_QUALIFICATION_TIME => 15000;   # currently not used
##################################

our $PURPOSE = "PowerUp ECU with Switch device from Initial state and perform state change to another Test state - multiple measurement features";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_UNI_SWITCH_State_Change_01

=head1 PURPOSE

PowerUp ECU with Switch device from Initial state and perform state change to another Test state - multiple measurement features

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault

[FD] Prepoare and start fast diagnosis for SW variables <List_FD_Vars> for FD PowerOn measurement of init state (optional);


I<B<Stimulation and Measurement>>

[Storage] Opening Measurements Archive Container ( for Init State and Test State )

[Switch] Set the init state of switch<Switch> to <Switch_Init_State> (ECU is off);

[Network] start network measurement on <bus> for init state (optional);

[FD] start fast diagnosis measurement of SW variables for init state (optional);

[Time] set timer zero <ECU_POWER_ON>;

[Power] power on the ECU;

[Time] wait until <Duration_Init_State_Measurement_ms> since timer <ECU_POWER_ON> (optional);

[FD] stop fast diagnosis measurement of init state (optional);

[Network] stop network measurement of init state (optional);

[SW vars] single read of <List_SW_Vars> of init state (optional);

[Network vars] single read of <List_Network_Vars> of init state (optional);

[FD] store fast diagnosis measurement of init state (optional);

[Network] store network measurement of init state (optional);

[RB FCM] read RB fault memory of init state (optional);

[CU FCM] read Cust fault memory of init state (optional);

[Diag] perform cust diag services of <List_Diag_Services> of init state (optional);

[FD] Prepare and start fast diagnosis for SW variables <List_FD_Vars> for FD PowerOn measurement of test state (optional);

[Network] start network measurement on <bus> of test state (optional);

[Time] set timer zero <SWITCH_STATE_CHANGE>;

[Switch] Set the test state of switch <Switch> to <Switch_Test_State>;

[Time] wait until <Duration_Test_State_Measurement_ms> since timer <SWITCH_STATE_CHANGE> (optional);

[Network] stop and store network measurement of test state (optional);

[FD] stop and store fast diagnosis measurement of test state (optional);

[SW vars] single read of <List_SW_Vars> of test state (optional);

[Network vars] single read of <List_Network_Vars> of test state (optional);

[RB FCM] read RB fault memory of test state (optional);

[CU FCM] read Cust fault memory of test state (optional);

[Diag] perform cust diag services of <List_Diag_Services> of test state (optional);

[Power] power off the ECU;

[Storage] Archive all measurements of init state in <Container_Init_State>;

[Storage] Archive all measurements of test state in <Container_Test_State>;


I<B<Evaluation>>


I<B<Finalisation>>

[Switch] Reset switch device to <local_State_Default>;

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'Switch' => 
	SCALAR 'Switch_Init_State' => 
	SCALAR 'Switch_Test_State' => 
	SCALAR 'Duration_Init_State_Measurement_ms' => 
	SCALAR 'Duration_Test_State_Measurement_ms' => 
	LIST 'List_FD_Vars' => 
	LIST 'List_SW_Vars' => 
	LIST 'List_Diag_Services' => 


=head2 PARAMETER EXAMPLES

	purpose	= 'To test the swicth status  when changeing in the same power cycle'
		
	Switch = 'BLFD'
	Switch_Init_State =  'PositionA'
	Switch_Test_State =  'PositionB'
    Read_RB_FCM = "Yes"                          # 'No' is default
    Read_Cust_FCM = "Yes"                        # 'No' is default
    Network_trace = "No"                         # 'Yes' is default
	Duration_Init_State_Measurement_ms=10000     # 8000 ms is default , only considered if Network_trace = 'Yes'
	Duration_Test_State_Measurement_ms=15000     # 8000 ms is default , only considered if Network_trace = 'Yes'
	List_SW_Vars_Daq=@( "ABC_U8" , "XYZ_S16|U8" , "DEF_U32" )   # 'ABC_U8' and "XYZ_16" will be measured as U8 , DEF as U32 
	List_SW_Vars_Point=@( )
	List_Network_Vars=@()
	List_Diag_Services=@()
	
=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Switch;
my $tcpar_Switch_Init_State;
my $tcpar_Switch_Test_State;
my $tcpar_Duration_Init_State_Measurement_ms;
my $tcpar_Duration_Test_State_Measurement_ms;
my $tcpar_Network_trace;
my $tcpar_Read_RB_FCM;
my $tcpar_Read_Cust_FCM;
my $tcpar_List_SW_Vars_Daq_aref;
my $tcpar_List_SW_Vars_Point_aref;
my $tcpar_List_Network_Vars_aref;
my $tcpar_List_Diag_Services_aref;

################ global parameter declaration ###################
my $glopar_diag_response_href;

# my $glopar_flt_mem_struct_pd;
my $glopar_flt_mem_struct_cd;
my $Daq_SW_Vars_href     = {};
my $SWITCH_Settings_href = {};
my $result;
my $tc_number;
my $tc_name;
my $tc_parameter_name;

#my @devices;

my $DEFAULT_Duration_Init_State_Measurement_ms = 8000;
my $DEFAULT_Duration_Test_State_Measurement_ms = 8000;

my $DEFAULT_Nbr_of_CAN_IDs_for_FD_measurement = 1;       # TODO : to be managed
my $DEFAULT_Type_FD_measurement               = 'U16';

###############################################################

###-----------------------------------------------------------------------------
sub TC_set_parameters {
###-----------------------------------------------------------------------------

    if ( S_get_exec_option( 'evaluation_only', 0 ) ) {
        S_w2rep( "Skip Testcase because exec option 'evaluation_only' is set\n", 'blue' );
        return 1;
    }

    $tc_number         = S_get_TC_number();
    $tc_name           = $main::CURRENT_TC;
    $tc_parameter_name = S_get_TC_parameter_name();

    undef $tcpar_purpose;
    undef $tcpar_Switch;
    undef $tcpar_Switch_Init_State;
    undef $tcpar_Switch_Test_State;
    undef $tcpar_Duration_Init_State_Measurement_ms;
    undef $tcpar_Duration_Test_State_Measurement_ms;
    undef $tcpar_Network_trace;
    undef $tcpar_Read_RB_FCM;
    undef $tcpar_Read_Cust_FCM;
    undef $tcpar_List_SW_Vars_Daq_aref;
    undef $tcpar_List_SW_Vars_Point_aref;
    undef $tcpar_List_Network_Vars_aref;
    undef $tcpar_List_Diag_Services_aref;
    $Daq_SW_Vars_href = {
        'Labels'                => [],
        'Types'                 => [],
        'FD_dirname_Init_State' => "",
        'FD_dirname_Test_State' => "",
    };

    $tcpar_purpose                            = S_read_mandatory_testcase_parameter('purpose');
    $tcpar_Switch                             = S_read_mandatory_testcase_parameter('Switch');
    $tcpar_Switch_Init_State                  = S_read_mandatory_testcase_parameter('Switch_Init_State');
    $tcpar_Switch_Test_State                  = S_read_mandatory_testcase_parameter('Switch_Test_State');
    $tcpar_Duration_Init_State_Measurement_ms = S_read_optional_testcase_parameter( 'Duration_Init_State_Measurement_ms', 'byref', $DEFAULT_Duration_Init_State_Measurement_ms );
    $tcpar_Duration_Test_State_Measurement_ms = S_read_optional_testcase_parameter( 'Duration_Test_State_Measurement_ms', 'byref', $DEFAULT_Duration_Test_State_Measurement_ms );
    $tcpar_Read_RB_FCM                        = S_read_optional_testcase_parameter( 'Read_RB_FCM', 'byref', "No" );
    $tcpar_Read_Cust_FCM                      = S_read_optional_testcase_parameter( 'Read_Cust_FCM', 'byref', "No" );
    $tcpar_Network_trace                      = S_read_optional_testcase_parameter( 'Network_trace', 'byref', "Yes" );
    $tcpar_List_SW_Vars_Daq_aref              = S_read_optional_testcase_parameter( 'List_SW_Vars_Daq', 'byref', [] );
    $tcpar_List_SW_Vars_Point_aref            = S_read_optional_testcase_parameter( 'List_SW_Vars_Point', 'byref', [] );
    $tcpar_List_Network_Vars_aref             = S_read_optional_testcase_parameter( 'List_Network_Vars', 'byref', [] );
    $tcpar_List_Diag_Services_aref            = S_read_optional_testcase_parameter( 'List_Diag_Services', 'byref', [] );

    if ( $tcpar_Switch_Init_State eq $tcpar_Switch_Test_State ) {
        S_set_error("Switch Init state and Test state must be different ( both are $tcpar_Switch_Init_State )");
        return;
    }

    if ( scalar(@$tcpar_List_SW_Vars_Daq_aref) ) {

        S_w2log( 2, "Preparing DAQ of SW-Vars\n" );

        $tc_name =~ s/\./-/;
        $Daq_SW_Vars_href->{'FD_dirname_Init_State'} = $main::REPORT_PATH . "/" . $tc_name . '-FDtrace-' . $tcpar_Switch . '-InitState';
        $Daq_SW_Vars_href->{'FD_dirname_Test_State'} = $main::REPORT_PATH . "/" . $tc_name . '-FDtrace-' . $tcpar_Switch . '-TestState';

        # processing list of elements like 'rb_itm_TestFinished_u64|U32'
        foreach my $fd_var (@$tcpar_List_SW_Vars_Daq_aref) {
            if ( $fd_var =~ /\|\w+/ ) {
                ( my $symbol, my $desired_type ) = split( /\|/, $fd_var );
                S_w2log( 2, "Measure SW Var '$symbol' with type '$desired_type' (desired)\n" );
                push( @{ $Daq_SW_Vars_href->{'Labels'} }, $symbol );
                push( @{ $Daq_SW_Vars_href->{'Types'} },  $desired_type );
            }
            else {
                my $fd_type = PD_get_type_from_name($fd_var);
                unless ( defined $fd_type ) {
                    $fd_type = $DEFAULT_Type_FD_measurement;
                    S_w2log( 2, "PD_get_type_from_name( $fd_var ) has not result -> use '$DEFAULT_Type_FD_measurement' per default\n" );
                }
                S_w2log( 2, "Measure SW Var '$fd_var' with type '$fd_type' (taken from symbol)\n" );
                push( @{ $Daq_SW_Vars_href->{'Labels'} }, $fd_var );
                push( @{ $Daq_SW_Vars_href->{'Types'} },  $fd_type );
            }
        }
    }

    return 1;
}

###-----------------------------------------------------------------------------
sub TC_initialization {
###-----------------------------------------------------------------------------

    if ( S_get_exec_option( 'evaluation_only', 0 ) ) {
        S_w2rep( "Skip Testcase because exec option 'evaluation_only' is set\n", 'blue' );
        return 1;
    }

    S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
    NET_simulation_start();
    S_wait_ms(2000);
    S_w2rep("Power on ECU");
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

    S_w2rep("Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);

    GDCOM_init();

    S_w2rep("Read and evaluate fault memory before stimulation");
    my $faultsBeforeStimulation = PD_ReadFaultMemory();
    my $faultsVerdict = PD_evaluate_faults( $faultsBeforeStimulation, [] );
    return 0 unless ( $faultsVerdict eq 'VERDICT_PASS' );

    #checking whether switch is configured or not
    $result = SYC_get_ConfigId_Content( 'Configured', [$tcpar_Switch] );
    my ( $real_config, $monitored_config, $programmed_config ) = PD_get_device_config($tcpar_Switch);
    S_w2rep("Real bit is $real_config, monitored bit is $monitored_config,programmed bit is $programmed_config");
    unless ( $result =~ /yes/i ) {
        S_set_warning(" Switch $tcpar_Switch is not configured in the software , Check the configuration through PS diag");
        ( $real_config, $monitored_config, $programmed_config ) = PD_get_device_config($tcpar_Switch);
        S_w2rep("Real bit is $real_config, monitored bit is $monitored_config,programmed bit is $programmed_config");
        if ( $programmed_config == 0 ) {
            S_set_error( " Switch $tcpar_Switch is not configured either in SYC or in PS diag " . "Dont Perfom this testcase as this is not applicable for the varient" );
            return 0;
        }
    }

    #checking whether switch is Mechanical or not
    ( $result, my $switch_type ) = SYC_SWITCH_get_type($tcpar_Switch);
    return 0 unless $result;
    S_w2rep( " Switch $tcpar_Switch is from Type '$switch_type'\n", 'blue' );

    ( $result, my $value_init_state, my $unit ) = SYC_SWITCH_get_state( $tcpar_Switch, $tcpar_Switch_Init_State );
    return 0 unless $result;

    ( $result, my $value_test_state ) = SYC_SWITCH_get_state( $tcpar_Switch, $tcpar_Switch_Test_State );
    return 0 unless $result;

    ( $result, my $default_condition ) = SYC_SWITCH_get_DefaultCondition($tcpar_Switch);
    return 0 unless $result;

    ( $result, my $value_default_state ) = SYC_SWITCH_get_state( $tcpar_Switch, $default_condition );
    return 0 unless $result;

    unless ( $unit =~ /I/ or $unit =~ /R/ ) {
        S_set_error( " Switch $tcpar_Switch has Unit " . $SWITCH_Settings_href->{$tcpar_Switch}{'Unit'} . " - functionality have to be implemented (TODO)" );
        return;
    }

    $SWITCH_Settings_href->{$tcpar_Switch}{'Unit'}                   = $unit;
    $SWITCH_Settings_href->{$tcpar_Switch}{$tcpar_Switch_Init_State} = $value_init_state;
    $SWITCH_Settings_href->{$tcpar_Switch}{$tcpar_Switch_Test_State} = $value_test_state;
    $SWITCH_Settings_href->{$tcpar_Switch}{'DefaultCondition'}       = $default_condition;
    $SWITCH_Settings_href->{$tcpar_Switch}{'ValueDefaultState'}      = $value_default_state;

    if (    ( $switch_type =~ /mechanical/ )
        and ( $tcpar_Switch_Init_State =~ m/Short2Gnd|OpenLine|Undefined|CrossCouple/ ) )
    {
        S_set_error( " Switch $tcpar_Switch is of type HAll and hence faults cannot be created for this switch " . "Dont Perfom this testcase" );
        return 0;
    }

    if (    ( $switch_type =~ /mechanical/ )
        and ( $tcpar_Switch_Test_State =~ m/Short2Gnd|OpenLine|Undefined|CrossCouple/ ) )
    {
        S_set_error( " Switch $tcpar_Switch is of type HAll and hence faults cannot be created for this switch " . "Dont Perfom this testcase" );
        return 0;
    }

    #
    #   ------------ Starting fast diag with POC here --------------------------
    #
    if ( scalar @$tcpar_List_SW_Vars_Daq_aref ) {
        S_teststep( "[FD] Prepare fast diagnosis for start of FD PowerOn measurement of init state in next PowerOnCycle (optional)", 'AUTO_NBR' );
        PD_StartFastDiagName(
            $Daq_SW_Vars_href->{'FD_dirname_Init_State'},
            $Daq_SW_Vars_href->{'Labels'},    # [ 'Symbol_1' , ... ]
            $Daq_SW_Vars_href->{'Types'},     # [ 'U8' , 'U16' , ... ]
            undef,                            # historical AB10 stuff
            $DEFAULT_Nbr_of_CAN_IDs_for_FD_measurement,
            1,                                # POWER ON CYCLE flag    -> measurement after next POC
        ) || return;
    }

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

    CSM_init() || return;

    return 1;
}

###-----------------------------------------------------------------------------
sub TC_stimulation_and_measurement {
###-----------------------------------------------------------------------------

    if ( S_get_exec_option( 'evaluation_only', 0 ) ) {
        S_w2rep( "Skip Testcase because exec option 'evaluation_only' is set\n", 'blue' );
        return 1;
    }

    #-------------------------------------------------------------------------------------------------------------------------- #
    #
    #   INIT STATE starting HERE
    #

    S_w2rep("[Storage] Opening Container for measurements of init state ( $tcpar_Switch -> $tcpar_Switch_Init_State)");
    my $init_state_cont_id = S_get_date_extension() . "__" . $tc_parameter_name . "__InitState";
    CSM_create_container($init_state_cont_id);
    CSM_add_keywords( $init_state_cont_id, [ "init-state-phase", "switch-name-$tcpar_Switch", "switch-state-$tcpar_Switch_Init_State", "followed-switch-state-$tcpar_Switch_Test_State" ] );

    #-------------------------------------------------- Step 3 --------------------------------------------------------------- #
    if ( $SWITCH_Settings_href->{$tcpar_Switch}{'Unit'} =~ /R/i ) {
        S_teststep( "[Switch] Set the init state of switch '$tcpar_Switch' to state '$tcpar_Switch_Init_State' (" . $SWITCH_Settings_href->{$tcpar_Switch}{$tcpar_Switch_Init_State} . " Ohm) (ECU is off)", 'AUTO_NBR' );
        LC_SetResistance( $tcpar_Switch, $SWITCH_Settings_href->{$tcpar_Switch}{$tcpar_Switch_Init_State} );
    }

    if ( $SWITCH_Settings_href->{$tcpar_Switch}{'Unit'} =~ /I/i ) {
        S_teststep( "[Switch] Set the init state of switch '$tcpar_Switch' to state '$tcpar_Switch_Init_State' (" . $SWITCH_Settings_href->{$tcpar_Switch}{$tcpar_Switch_Init_State} . " mA) (ECU is off)", 'AUTO_NBR' );
        LC_SetCurrent( $tcpar_Switch, $SWITCH_Settings_href->{$tcpar_Switch}{$tcpar_Switch_Init_State}{'Value'} );
    }

    #-------------------------------------------------- Step 4 --------------------------------------------------------------- #
    if ( $tcpar_Network_trace =~ /Yes/i ) {
        S_teststep( "[Network] start network measurement on '$tcpar_Network_trace' bus for init state (optional)", 'AUTO_NBR' );
        NET_trace_start();
    }

    #-------------------------------------------------- Step 6 --------------------------------------------------------------- #
    S_teststep( "[Time] set timer zero 'ECU_POWER_ON'", 'AUTO_NBR' );
    S_set_timer_zero('ECU_POWER_ON');

    #-------------------------------------------------- Step 7 --------------------------------------------------------------- #
    S_teststep( "[Power] power on the ECU", 'AUTO_NBR' );
    LC_ECU_On();

    #-------------------------------------------------- Step 8 --------------------------------------------------------------- #
    S_teststep( "[Time] wait until '$tcpar_Duration_Init_State_Measurement_ms' ms since timer 'ECU_POWER_ON' (optional)", 'AUTO_NBR' );
    S_wait_until_timer_ms( $tcpar_Duration_Init_State_Measurement_ms, 'ECU_POWER_ON' );

    #-------------------------------------------------- Step 9 --------------------------------------------------------------- #
    if ( $tcpar_Network_trace =~ /Yes/i ) {
        S_teststep( "[Network] stop and store network measurement of init state (optional)", 'AUTO_NBR' );
        NET_trace_stop();    # Storing will be done later down in the sequence (save time here)
    }

    #-------------------------------------------------- Step 10 --------------------------------------------------------------- #
    if ( scalar(@$tcpar_List_SW_Vars_Daq_aref) ) {
        S_teststep( "[FD] stop fast diagnosis measurement of init state (optional)", 'AUTO_NBR' );
        PD_StopFastDiag();    # Storing will be done later down in the sequence (save time here)
    }

    #-------------------------------------------------- Step 11 --------------------------------------------------------------- #
    if ( scalar @$tcpar_List_SW_Vars_Point_aref ) {
        S_teststep( "[SW vars] single read of SW variables of init state (optional)", 'AUTO_NBR' );
        my $SWVar_init_state_values_href = {};
        foreach my $sw_label (@$tcpar_List_SW_Vars_Point_aref) {
            S_teststep_2nd_level( "[SW vars] Read SW Var : '$sw_label'", 'AUTO_NBR', "SW_Var_" . $sw_label . "_init" );
            my $value_aref = PD_ReadMemoryByName($sw_label);
            next unless defined $value_aref;
            my $value_string = join( " ", @$value_aref );
            S_teststep_detected( "SW Var : '$sw_label' => $value_string", "SW_Var_" . $sw_label . "_init" );
            $SWVar_init_state_values_href->{$sw_label} = $value_aref;
        }
        S_dump2pmFile(
            "VariableToDump" => $SWVar_init_state_values_href,
            "VariableName"   => "SW_Vars",
            "PackageName"    => "PD_SW_Vars_Dump",
            "StoragePath"    => $main::REPORT_PATH,
        );
        my $sw_vars_file_init = $main::REPORT_PATH . "/PD_SW_Vars_Dump.pm";
        CSM_add_userfile( $init_state_cont_id, $sw_vars_file_init, "PD_SW_Vars_Dump" );
        CSM_add_keywords( $init_state_cont_id, ["PD_SW_Vars_Dump"] );
        S_w2rep(" Delete file $sw_vars_file_init \n");
        unlink $sw_vars_file_init if -f $sw_vars_file_init;    # delete local file in Report folder !!
    }

    #-------------------------------------------------- Step 12 --------------------------------------------------------------- #
    if ( scalar @$tcpar_List_Network_Vars_aref ) {
        S_teststep( "[Network vars] Single read of Network variables of init state (optional)", 'AUTO_NBR' );
        my $Network_data_init_state_href = {};
        foreach my $signal_label (@$tcpar_List_Network_Vars_aref) {
            S_teststep_2nd_level( "[Network vars] Read Network Signal : '$signal_label'", 'AUTO_NBR', "Network_Var_" . $signal_label . "_init" );
            my ( $value_phys, $unit ) = NET_read_signal( $signal_label, 'phys' );
            next unless defined $value_phys;
            S_teststep_detected( "Network Signal : '$signal_label' => $value_phys [$unit]", "Network_Var_" . $signal_label . "_init" );
            $Network_data_init_state_href->{$signal_label}{'Value'} = $value_phys;
            $Network_data_init_state_href->{$signal_label}{'Unit'}  = $unit;
        }
        S_dump2pmFile(
            "VariableToDump" => $Network_data_init_state_href,
            "VariableName"   => "Network_Vars",
            "PackageName"    => "Network_Vars_Dump",
            "StoragePath"    => $main::REPORT_PATH,
        );
        my $network_vars_file_init = $main::REPORT_PATH . "/Network_Vars_Dump.pm";
        CSM_add_userfile( $init_state_cont_id, $network_vars_file_init, "Network_Vars_Dump" );
        CSM_add_keywords( $init_state_cont_id, ["Network_Vars_Dump"] );
        S_w2rep(" Delete file $network_vars_file_init \n");
        unlink $network_vars_file_init if -f $network_vars_file_init;    # delete local file in Report folder !!
    }

    #-------------------------------------------------- Step 13 --------------- TO BE DEVELOPED ------------------------------ #
    if ( $tcpar_Read_RB_FCM =~ /yes/i ) {
        S_teststep( "[RB FCM] Read and store RB fault memory of init state (optional)", 'AUTO_NBR' );
        if ( my $PD_FCM_init_href = PD_ReadFaultMemory() ) {
            S_dump2pmFile(
                "VariableToDump" => $PD_FCM_init_href,
                "VariableName"   => "FaultMemoryData",
                "PackageName"    => "PD_ReadFaultMemory_Dump",
                "StoragePath"    => $main::REPORT_PATH,
            );
            my $PD_fcm_file_init = $main::REPORT_PATH . "/PD_ReadFaultMemory_Dump.pm";
            CSM_add_userfile( $init_state_cont_id, $PD_fcm_file_init, "PD_ReadFaultMemory_Dump" );
            CSM_add_keywords( $init_state_cont_id, ["PD_ReadFaultMemory_Dump"] );
            S_w2rep(" Delete file $PD_fcm_file_init \n");
            unlink $PD_fcm_file_init if -f $PD_fcm_file_init;    # delete local file in Report folder !!
        }
    }

    #-------------------------------------------------- Step 14 ---------------- TO BE DEVELOPED ------------------------------ #
    if ( $tcpar_Read_Cust_FCM =~ /yes/i ) {
        S_teststep( "[CU FCM] read Cust fault memory of init state", 'AUTO_NBR' );
        $glopar_flt_mem_struct_cd->{$tcpar_Switch}{$tcpar_Switch_Init_State} = CD_read_DTC( '02', '09' );
        S_dump2pmFile(
            "VariableToDump" => $glopar_flt_mem_struct_cd->{$tcpar_Switch}{$tcpar_Switch_Init_State},
            "VariableName"   => "FaultMemory_CD",
            "PackageName"    => "CD_ReadFaultMemory_Dump",
            "StoragePath"    => $main::REPORT_PATH,
        );
        my $CD_fcm_file_init = $main::REPORT_PATH . "/CD_ReadFaultMemory_Dump.pm";
        CSM_add_userfile( $init_state_cont_id, $CD_fcm_file_init, "CD_ReadFaultMemory_Dump" );
        CSM_add_keywords( $init_state_cont_id, ["CD_ReadFaultMemory_Dump"] );
        S_w2rep(" Delete file $CD_fcm_file_init \n");
        unlink $CD_fcm_file_init if -f $CD_fcm_file_init;    # delete local file in Report folder !!
    }

    #-------------------------------------------------- Step 15 --------------------------------------------------------------- #
    if ( scalar(@$tcpar_List_Diag_Services_aref) ) {
        S_teststep( "[Diag] perform cust diag services of '@$tcpar_List_Diag_Services_aref' of init state (optional)", 'AUTO_NBR' );
        _Perform_DiagService($tcpar_Switch_Init_State);
    }

    #-------------------------------------------------- Step 16 --------------------------------------------------------------- #
    if ( $tcpar_Network_trace =~ /Yes/i ) {
        S_w2rep( "[Network] Store network measurement of init state (optional)", 'AUTO_NBR' );
        my $network_trace_file_init_state = NET_trace_store('C:\temp\Network_trace_Init_Phase.asc');
        CSM_add_userfile( $init_state_cont_id, $network_trace_file_init_state, "Network_trace" );
        CSM_add_keywords( $init_state_cont_id, ["Network_trace"] );
        S_w2rep( " Delete file $network_trace_file_init_state \n", 'grey' );
        unlink $network_trace_file_init_state if -f $network_trace_file_init_state;          # delete local file in Report folder !!
    }

    if ( scalar(@$tcpar_List_SW_Vars_Daq_aref) ) {
        S_w2rep( "[FD] Store fast diagnosis measurement of init state (optional)", 'AUTO_NBR' );
        _store_FD_measurement( $Daq_SW_Vars_href->{'FD_dirname_Init_State'}, 'init_state', $init_state_cont_id );
    }

    #-------------------------------------------------------------------------------------------------------------------------- #
    #
    #   TEST STATE starting HERE
    #

    S_w2rep("[Storage] Opening Container for measurements of test state ( $tcpar_Switch -> $tcpar_Switch_Test_State)");
    my $test_state_cont_id = S_get_date_extension() . "__" . $tc_parameter_name . "__TestState";
    CSM_create_container($test_state_cont_id);
    CSM_add_keywords( $test_state_cont_id, [ "test-state-phase", "switch-name-$tcpar_Switch", "switch-state-$tcpar_Switch_Test_State", "previous-switch-state-$tcpar_Switch_Init_State" ] );

    #-------------------------------------------------- Step 16 --------------------------------------------------------------- #
    S_teststep( "[FD] Start fast diagnosis for FD measurement of test state (optional)", 'AUTO_NBR' );
    if ( scalar(@$tcpar_List_SW_Vars_Daq_aref) ) {
        PD_StartFastDiagName(
            $Daq_SW_Vars_href->{'FD_dirname_Test_State'},
            $Daq_SW_Vars_href->{'Labels'},    # [ 'Symbol_1' , ... ]
            $Daq_SW_Vars_href->{'Types'},     # [ 'U8' , 'U16' , ... ]
            undef,                            # historical AB10 stuff
            $DEFAULT_Nbr_of_CAN_IDs_for_FD_measurement,
            0,                                # POWER ON CYCLE flag    -> measurement directly
        );
    }

    #-------------------------------------------------- Step 17 --------------------------------------------------------------- #
    if ( $tcpar_Network_trace =~ /Yes/i ) {
        S_teststep( "[Network] start network measurement on '$tcpar_Network_trace' bus of test state (optional)", 'AUTO_NBR' );
        NET_trace_start();
    }

    #-------------------------------------------------- Step 18 --------------------------------------------------------------- #
    S_teststep( "[Time] set timer zero 'SWITCH_STATE_CHANGE'", 'AUTO_NBR' );
    S_set_timer_zero('SWITCH_STATE_CHANGE');

    #-------------------------------------------------- Step 19 --------------------------------------------------------------- #
    if ( $SWITCH_Settings_href->{$tcpar_Switch}{'Unit'} =~ /R/i ) {
        S_teststep( "[Switch] Set the test state of switch '$tcpar_Switch' to state '$tcpar_Switch_Test_State' (" . $SWITCH_Settings_href->{$tcpar_Switch}{$tcpar_Switch_Test_State} . " Ohm) ", 'AUTO_NBR' );
        LC_SetResistance( $tcpar_Switch, $SWITCH_Settings_href->{$tcpar_Switch}{$tcpar_Switch_Test_State} );
    }

    if ( $SWITCH_Settings_href->{$tcpar_Switch}{'Unit'} =~ /I/i ) {
        S_teststep( "[Switch] Set the test state of switch '$tcpar_Switch' to state '$tcpar_Switch_Test_State' (" . $SWITCH_Settings_href->{$tcpar_Switch}{$tcpar_Switch_Test_State} . " mA) ", 'AUTO_NBR' );
        LC_SetCurrent( $tcpar_Switch, $SWITCH_Settings_href->{$tcpar_Switch}{$tcpar_Switch_Test_State}{'Value'} );
    }

    #-------------------------------------------------- Step 20 --------------------------------------------------------------- #
    S_teststep( "[Time] wait until '$tcpar_Duration_Test_State_Measurement_ms' ms since timer 'SWITCH_STATE_CHANGE' (optional)", 'AUTO_NBR' );
    S_wait_until_timer_ms( $tcpar_Duration_Test_State_Measurement_ms, 'SWITCH_STATE_CHANGE' );

    #-------------------------------------------------- Step 21 --------------------------------------------------------------- #
    if ( scalar(@$tcpar_List_SW_Vars_Daq_aref) ) {
        S_teststep( "[FD] stop and store fast diagnosis measurement of test state (optional)", 'AUTO_NBR' );
        PD_StopFastDiag();
    }

    #-------------------------------------------------- Step 22 --------------------------------------------------------------- #
    if ( $tcpar_Network_trace =~ /Yes/i ) {
        S_teststep( "[Network] stop and store network measurement of test state (optional)", 'AUTO_NBR' );
        NET_trace_stop();
    }

    #-------------------------------------------------- Step 23 --------------------------------------------------------------- #
    if ( scalar @$tcpar_List_SW_Vars_Point_aref ) {
        S_teststep( "[SW vars] Single read of SW variables of test state '$tcpar_Switch_Test_State' (optional)", 'AUTO_NBR' );
        my $SWVar_test_state_values_href = {};
        foreach my $sw_label (@$tcpar_List_SW_Vars_Point_aref) {
            S_teststep_2nd_level( "[SW vars] Read SW Var : '$sw_label'", 'AUTO_NBR', "SW_Var_" . $sw_label . "_test_state" );
            my $value_aref = PD_ReadMemoryByName($sw_label);
            next unless defined $value_aref;
            my $value_string = join( " ", @$value_aref );
            S_teststep_detected( "SW Var : '$sw_label' => $value_string", "SW_Var_" . $sw_label . "_test_state" );
            $SWVar_test_state_values_href->{$sw_label} = $value_aref;
        }
        S_dump2pmFile(
            "VariableToDump" => $SWVar_test_state_values_href,
            "VariableName"   => "SW_Vars",
            "PackageName"    => "PD_SW_Vars_Dump",
            "StoragePath"    => $main::REPORT_PATH,
        );
        my $sw_vars_file_test = $main::REPORT_PATH . "/PD_SW_Vars_Dump.pm";
        CSM_add_userfile( $test_state_cont_id, $sw_vars_file_test, "PD_SW_Vars_Dump" );
        CSM_add_keywords( $test_state_cont_id, ["PD_SW_Vars_Dump"] );
        S_w2rep(" Delete file $sw_vars_file_test \n");
        unlink $sw_vars_file_test if -f $sw_vars_file_test;    # delete local file in Report folder !!
    }

    #-------------------------------------------------- Step 24 --------------------------------------------------------------- #
    if ( scalar @$tcpar_List_Network_Vars_aref ) {
        S_teststep( "[Network vars] Single read of Network variables of Test state (optional)", 'AUTO_NBR' );
        my $Network_data_test_state_href = {};
        foreach my $signal_label (@$tcpar_List_Network_Vars_aref) {
            S_teststep_2nd_level( "[Network vars] Read Network Signal : '$signal_label'", 'AUTO_NBR', "Network_Var_" . $signal_label . "_test_state" );
            my ( $value_phys, $unit ) = NET_read_signal( $signal_label, 'phys' );
            next unless defined $value_phys;
            S_teststep_detected( "Network Signal : '$signal_label' => $value_phys [$unit]", "Network_Var_" . $signal_label . "_test_state" );
            $Network_data_test_state_href->{$signal_label}{'Value'} = $value_phys;
            $Network_data_test_state_href->{$signal_label}{'Unit'}  = $unit;
        }
        S_dump2pmFile(
            "VariableToDump" => $Network_data_test_state_href,
            "VariableName"   => "Network_Vars",
            "PackageName"    => "Network_Vars_Dump",
            "StoragePath"    => $main::REPORT_PATH,
        );
        my $network_vars_file_test = $main::REPORT_PATH . "/Network_Vars_Dump.pm";
        CSM_add_userfile( $test_state_cont_id, $network_vars_file_test, "Network_Vars_Dump" );
        CSM_add_keywords( $test_state_cont_id, ["Network_Vars_Dump"] );
        S_w2rep(" Delete file $network_vars_file_test \n");
        unlink $network_vars_file_test if -f $network_vars_file_test;    # delete local file in Report folder !!
    }

    #-------------------------------------------------- Step 25 --------------------------------------------------------------- #
    if ( $tcpar_Read_RB_FCM =~ /yes/i ) {
        S_teststep( "[RB FCM] read RB fault memory of test state (optional)", 'AUTO_NBR' );
        if ( my $PD_FCM_test_href = PD_ReadFaultMemory() ) {
            S_dump2pmFile(
                "VariableToDump" => $PD_FCM_test_href,
                "VariableName"   => "FaultMemoryData",
                "PackageName"    => "PD_ReadFaultMemory_Dump",
                "StoragePath"    => $main::REPORT_PATH,
            );
            my $PD_fcm_file_test = $main::REPORT_PATH . "/PD_ReadFaultMemory_Dump.pm";
            CSM_add_userfile( $test_state_cont_id, $PD_fcm_file_test, "PD_ReadFaultMemory_Dump" );
            CSM_add_keywords( $test_state_cont_id, ["PD_ReadFaultMemory_Dump"] );
            S_w2rep(" Delete file $PD_fcm_file_test \n");
            unlink $PD_fcm_file_test if ( -f $PD_fcm_file_test );    # delete local file in Report folder !!
        }
    }

    #-------------------------------------------------- Step 26 --------------------------------------------------------------- #
    if ( $tcpar_Read_Cust_FCM =~ /yes/i ) {
        S_teststep( "[CU FCM] read Cust fault memory of test state (optional)", 'AUTO_NBR' );
        $glopar_flt_mem_struct_cd->{$tcpar_Switch}{$tcpar_Switch_Test_State} = CD_read_DTC( '02', '09' );
        S_dump2pmFile(
            "VariableToDump" => $glopar_flt_mem_struct_cd->{$tcpar_Switch}{$tcpar_Switch_Test_State},
            "VariableName"   => "FaultMemory_CD",
            "PackageName"    => "CD_ReadFaultMemory_Dump",
            "StoragePath"    => $main::REPORT_PATH,
        );
        my $CD_fcm_file_test = $main::REPORT_PATH . "/CD_ReadFaultMemory_Dump.pm";
        CSM_add_userfile( $test_state_cont_id, $CD_fcm_file_test, "CD_ReadFaultMemory_Dump" );
        CSM_add_keywords( $test_state_cont_id, ["CD_ReadFaultMemory_Dump"] );
        S_w2rep(" Delete file $CD_fcm_file_test \n");
        unlink $CD_fcm_file_test if -f $CD_fcm_file_test;    # delete local file in Report folder !!
    }

    #-------------------------------------------------- Step 27 --------------------------------------------------------------- #
    S_teststep( "[Diag] perform cust diag services of '$tcpar_List_Diag_Services_aref' of test state (optional)", 'AUTO_NBR' );
    _Perform_DiagService($tcpar_Switch_Test_State) if ( ( scalar @$tcpar_List_Diag_Services_aref ) );

    #-------------------------------------------------- Step 28 --------------------------------------------------------------- #
    if ( $tcpar_Network_trace =~ /Yes/i ) {
        S_w2rep( "[Network] Store network measurement of test state (optional)", 'AUTO_NBR' );
        my $network_trace_file_test_state = NET_trace_store('C:\temp\Network_trace_Test_State.asc');
        CSM_add_userfile( $test_state_cont_id, $network_trace_file_test_state, "Network_trace" );
        CSM_add_keywords( $test_state_cont_id, ["Network_trace"] );
        S_w2rep( " Delete file $network_trace_file_test_state \n", 'grey' );
        unlink $network_trace_file_test_state if -f $network_trace_file_test_state;    # delete local file in Report folder !!
    }

    #-------------------------------------------------- Step 29 --------------------------------------------------------------- #
    if ( scalar(@$tcpar_List_SW_Vars_Daq_aref) ) {
        S_w2rep( "[FD] Store fast diagnosis measurement of test state (optional)", 'AUTO_NBR' );
        _store_FD_measurement( $Daq_SW_Vars_href->{'FD_dirname_Test_State'}, 'test_state', $test_state_cont_id );
    }

    #-------------------------------------------------- Step 28 --------------------------------------------------------------- #
    S_teststep( "[Power] power off the ECU", 'AUTO_NBR' );
    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

    S_w2rep( " CSM Close Init container '$init_state_cont_id'\n", "blue" );
    CSM_pack_container($init_state_cont_id);

    S_w2rep( " CSM Archive Init container '$init_state_cont_id'\n", "blue" );
    CSM_archive_container( $init_state_cont_id, 'KeepLocalData' );

    S_w2rep( " CSM Close Test container '$test_state_cont_id'\n", "blue" );
    CSM_pack_container($test_state_cont_id);

    S_w2rep( " CSM Archive Test container '$test_state_cont_id'\n", "blue" );
    CSM_archive_container( $test_state_cont_id, 'KeepLocalData' );

    return 1;
}

###-----------------------------------------------------------------------------
sub TC_evaluation {
###-----------------------------------------------------------------------------

    if ( S_get_exec_option( 'evaluation_only', 0 ) ) {
        S_w2rep( "Skip Testcase because exec option 'evaluation_only' is set\n", 'blue' );
        return 1;
    }

    return 1;
}

###-----------------------------------------------------------------------------
sub TC_finalization {
###-----------------------------------------------------------------------------

    if ( S_get_exec_option( 'evaluation_only', 0 ) ) {
        S_w2rep( "Skip Testcase because exec option 'evaluation_only' is set\n", 'blue' );
        return 1;
    }

    my $default_condition = $SWITCH_Settings_href->{$tcpar_Switch}{'DefaultCondition'};
    S_w2rep( "[Switch] Set the state of switch '$tcpar_Switch' back to default state '$default_condition' (ECU is off)", 'AUTO_NBR' );
    if ( $tcpar_Switch_Test_State =~ m/PositionA|PositionB|Short2Gnd|OpenLine|Undefined/i ) {
        LC_SetResistance( $tcpar_Switch, $SWITCH_Settings_href->{$tcpar_Switch}{'ValueDefaultState'} )
          if ( $SWITCH_Settings_href->{$tcpar_Switch}{'Unit'} =~ /R/ );
        LC_SetCurrent( $tcpar_Switch, $SWITCH_Settings_href->{$tcpar_Switch}{'ValueDefaultState'} )
          if ( $SWITCH_Settings_href->{$tcpar_Switch}{'Unit'} =~ /I/i );

        #        if ( ($switch_type =~/mechanical/) and ( ($state_unit ne 'R') or ($state_unit ne 'I')))
        #        {
        #            if ($default_condition  eq 'PositionA')
        #            {
        #                LC_ConnectLine( $tcpar_Switch );
        #            }
        #            elsif ($default_condition  eq 'PositionB')
        #            {
        #                LC_DisconnectLine( $tcpar_Switch );
        #            }
        #        }
    }
    elsif ( $tcpar_Switch_Test_State =~ /Configuration/ ) {
        PD_Device_configuration( 'set', [$tcpar_Switch] );
        S_wait_ms('2000');
    }
    elsif ( $tcpar_Switch_Test_State =~ m/Short2Bat|CrossCouple/ ) {
        LC_UndoShortLines();
    }
    else {
        S_set_error(" Switch $tcpar_Switch is not set to its Default state ");
        return;
    }

    if ( $tcpar_Switch_Test_State =~ m/CrossCouple|Configuration/ ) {
        PD_ECUreset();
        S_wait_ms('TIMER_ECU_READY');
    }

    S_w2rep( "[Power] Power on ECU", 'AUTO_NBR' );
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

    S_w2rep( "[RB FCM] PD_ClearFaultMemory", 'AUTO_NBR' );
    PD_ClearFaultMemory();
    S_wait_ms('2000');

    S_w2rep( "[Power] Power off ECU", 'AUTO_NBR' );
    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

    return 1;
}

###-----------------------------------------------------------------------------
###-----------------------------------------------------------------------------
###-----------------------------------------------------------------------------

sub _Perform_DiagService {
    my $state = shift;
    unless ( defined $state ) {
        S_set_error( "Missing mandatory parameter: switch state!!!", 114 );
        return 0;
    }

    foreach my $diag_service (@$tcpar_List_Diag_Services_aref) {
        $glopar_diag_response_href->{$tcpar_Switch}{$state}{$diag_service} =
          GDCOM_request( $diag_service, '62', 'relax', "performe 22 service at the end of state '$state'" );
    }

    S_dump2pmFile(
        "VariableToDump" => $glopar_diag_response_href,
        "VariableName"   => "Value_DiagService_Variables",
        "PackageName"    => "Value_DiagService_Variables_$tcpar_Switch\_$state",
        "StoragePath"    => $main::REPORT_PATH,
    );

    return 1;
}

###-----------------------------------------------------------------------------
###-----------------------------------------------------------------------------
###-----------------------------------------------------------------------------

sub _store_FD_measurement {
    my $dirname    = shift;
    my $state_name = shift;
    my $cont_id    = shift;

    unless ( -d $dirname ) {
        S_set_error("FD measurement wasnt not successful , folder '$dirname' doesnt exist");
        return;
    }

    my $fd_data_href     = PD_get_FDtrace_NOERROR($dirname);
    my $fd_temp_filename = $tc_number . "_FD_trace_" . $state_name . "_" . $tcpar_Switch;
    PD_plot_FDtrace( $fd_data_href, $main::REPORT_PATH . "/" . $fd_temp_filename . ".png" );
    S_add_pic2html( "./" . $fd_temp_filename . ".png", '', "./" . $fd_temp_filename . ".txt.unv", 'TYPE="text/unv"' );

    S_dump2pmFile(
        "VariableToDump" => $fd_data_href,
        "VariableName"   => "SW_Vars_Daq",
        "PackageName"    => "SW_Vars_Daq_Dump",
        "StoragePath"    => $main::REPORT_PATH,
    );

    my $daq_dump_file_name = $main::REPORT_PATH . "/SW_Vars_Daq_Dump.pm";

    unless ( -f $daq_dump_file_name ) {
        S_set_error("S_dump2pmFile doesnt created file : $daq_dump_file_name ");
        return;
    }
    CSM_add_userfile( $cont_id, $daq_dump_file_name, "SW_Vars_Daq_Dump" );
    CSM_add_keywords( $cont_id, ["SW_Vars_Daq_Dump"] );
    S_w2rep(" Delete file $daq_dump_file_name \n");
    unlink $daq_dump_file_name;    # delete local file in Report folder !!

    S_w2rep(" Delete path '$dirname' .. \n");
    unless ( rmtree($dirname) ) {
        S_set_error("could not delete path '$dirname'");
        return;
    }

    return 1;
}

1;
