# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#    $Source: UNIVERSAL/TC_UNI_SWITCH_State_Steady_01.pm $
#    $Revision: 1.5 $
#    $Author: Baeuerle Katharina (CC-PS/EPS2) (ZIK1ABT) $
#    $State: develop $
#    $Date: 2017/04/05 19:49:42ICT $
#******************************************************************************************************

#### TEST CASE MODULE
package TC_UNI_SWITCH_State_Steady_01;

#### DONT MODIFY THIS SECTION ####
use strict;
###-------------------------------
our $VERSION = q$Revision: 1.5 $;
our $HEADER =
q$Header: UNIVERSAL/TC_UNI_SWITCH_State_Steady_01.pm 1.5 2017/04/05 19:49:42ICT Baeuerle Katharina (CC-PS/EPS2) (ZIK1ABT) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TC_UNI_SWITCH_State_Steady_01
#TS version in DOORS: 1.1
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use LIFT_CD;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_SYC_INTERFACE;
use INCLUDES_Project;
##################################

our $PURPOSE =
" test that a switch detects the correct state and measures the correct value ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_UNI_SWITCH_State_Steady_01 $Revision: 1.5 $

=head1 PURPOSE

 test that a switch detects the correct state and measures the correct value
 
=head1 TEST DESIGN

 L<Testdesign TC_UNI_SWITCH_State_Steady_01|https://connect.bosch.com/wikis/home?lang=en-us#!/wiki/Wad0c302c3442_4748_8eef_7d10157fb564/page/TC_UNI_SWITCH_State_xxxxx>.

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

    Ubat
    Pin
    Type
    Minimum
    Maximum
    CheckLSB
    CheckState
    FLTmand
    FLTopt  (optional)

    [initialisation]
    get temperature
    Ubat on
    clear fault memory
    read fault memory
    switch ECU off

    [stimulation & measurement]
    calculate switch value
    set switch value
    set Ubat
    wait for end of initialization
    read switch state and value in CD/PD
    read fault memory

    [evaluation]
    check switch state and value
    check if fault memory matches given faults CD/PD
    send mail if not

    [finalisation]
    switch ECU off


=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'ubat'          --> battery voltage value
    SCALAR 'pin'           --> ECU pin
    SCALAR 'type'          --> switch type
    LIST   'checkLSB' 	   --> label and lsb value
    LIST   'checkState'    --> label and state value
    LIST   'FLTmand'       --> list of mandatory faults (logical names)
    LIST   'FLTopt'        --> list of optional faults (logical names)
    
=head2 PARAMETER EXAMPLES

    [TC_FLT_Active.BLFD_Gnd]
    purpose='Checking Short2Gnd(active) BLFD' 
	Ubat=13.2
	Pin1='BLFD+'
	Pin2='B-'
	FLTmand='rb_swm_ShortLineBLFD_flt'
    
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my $fltmem1;
my ( $tcpar_ubat, $tcpar_pin, $tcpar_state, $tcpar_state_initial, 
    $tcpar_FLTmand, $tcpar_FLTopt, $tcpar_can_signal_switch_state,
    $tcpar_checkLSB, $tcpar_Diag_State_Request_Label,
    $tcpar_can_signal_change_time_max_exp_ms );
my ( $result, $switch_nbr, $fault_reaction, $tcpar_asic_connection );
my ( $result_initial, $state_value_initial, $state_value_unit_initial );
my ( $state_value,       $state_value_unit, $det_threshold_href );
my ( $value_aref,        $type,             $dec_value );
my ( $flt_mem_struct_CD, $det_cd_state,     $det_cd_Interpreted_State );
my $net_trace_href;
my @temperatures = ();    # Todo: Remove?

my $expected_SwitchInfo = {
    "Short2Gnd" => { "StatusFiltered_en" => 2, },
    "PositionA" => {
        "PositionFiltered_en" => 0,
        "StatusFiltered_en"   => 1,
    },
    "Undefined" => { "StatusFiltered_en" => 2, },
    "PositionB" => {
        "PositionFiltered_en" => 1,
        "StatusFiltered_en"   => 1,
    },
    "OpenLine" => { "StatusFiltered_en" => 2, },
};

sub TC_set_parameters {

    $tcpar_ubat    = S_read_mandatory_testcase_parameter('Ubat');
    $tcpar_pin     = S_read_mandatory_testcase_parameter('Pin');
    $tcpar_state   = S_read_mandatory_testcase_parameter('State');
    $tcpar_state_initial   = S_read_mandatory_testcase_parameter('State_Initial');
    $tcpar_can_signal_switch_state   = S_read_optional_testcase_parameter('CAN_Signal_Switch_State');
    if($tcpar_can_signal_switch_state){
        $tcpar_can_signal_change_time_max_exp_ms = S_read_mandatory_testcase_parameter('CAN_State_Change_Time_Max_ms');
    }
    $tcpar_FLTmand = S_read_optional_testcase_parameter( 'FLTmand', 'byref' );
    $tcpar_FLTopt  = S_read_optional_testcase_parameter( 'FLTopt', 'byref' );
    $tcpar_Diag_State_Request_Label =
      S_read_optional_testcase_parameter('Diag_State_Request_Label');

    if ( $tcpar_state =~ /(\w+)Value/ ) {
        $tcpar_state = $1;
    }

    # get initial state value from SYC
    ( $result_initial, $state_value_initial, $state_value_unit_initial ) =
      SYC_SWITCH_get_state( $tcpar_pin, $tcpar_state_initial );
    return 0 unless $result_initial;

    # get state to manipulate from SYC
    ( $result, $state_value, $state_value_unit ) =
      SYC_SWITCH_get_state( $tcpar_pin, $tcpar_state );
    return 0 unless $result;

    ( $result, $tcpar_asic_connection ) =
      SYC_SWITCH_get_ASIC_connection_NOERROR($tcpar_pin)
      ;    # Required to get the right PD variable for reading the state
    if ( $result == 1 ) {
        $tcpar_checkLSB =
          "rb_swma_AsicChannelData_ast($tcpar_asic_connection).Value10Bit_u16";
    }
    else {
        undef $tcpar_checkLSB;
        S_teststep_detected(
"Content of ConfigID 'AsicConnection' for switch '$tcpar_pin' is not in the expected format."
        );
    }

    $switch_nbr = PD_get_device_index($tcpar_pin);

    if (   $tcpar_state eq 'OpenLine'
        or $tcpar_state eq 'Undefined'
        or $tcpar_state eq 'Short2Gnd' )
    {

        ( $result, $fault_reaction ) = SYC_SWITCH_get_FaultReaction($tcpar_pin);
        return 0 unless $result;

        ( $result, $fault_reaction ) =
          SYC_SWITCH_get_DefaultCondition($tcpar_pin)
          if ( $fault_reaction =~ /default condition/ );
        ( $result, $fault_reaction ) =
          SYC_SWITCH_get_InitialCondition($tcpar_pin)
          if ( $fault_reaction =~ /keep last condition/ );
        return 0 unless $result;

        $expected_SwitchInfo->{$tcpar_state}{PositionFiltered_en} =
          $expected_SwitchInfo->{$fault_reaction}{PositionFiltered_en};

    }

    $tcpar_FLTmand = [ "rb_swm_ShortLine" . $tcpar_pin . "_flt" ]
      if $tcpar_state eq 'Short2Gnd';
    $tcpar_FLTmand = [ "rb_swm_Undefined" . $tcpar_pin . "_flt" ]
      if $tcpar_state eq 'Undefined';
    $tcpar_FLTmand = [ "rb_swm_OpenLine" . $tcpar_pin . "_flt" ]
      if $tcpar_state eq 'OpenLine';

    return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

    CA_simulation_start(); # will work for CAN and FR, only starts CANoe simulation

    LC_ECU_On('U_BATT_DEFAULT');
    S_wait_ms('TIMER_ECU_READY');

    PD_ClearFaultMemory();
    S_wait_ms('TIMER_ECU_READY');

    my $fltmem_init = PD_GetExtendedFaultInformation();
    PD_evaluate_faults( $fltmem_init, [] );

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

    return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {


    # Set initial switch state value
    if ( $state_value_unit_initial =~ /R/i ) {

        S_teststep( "Set switch '$tcpar_pin' to initial value '$state_value_initial' Ohm.",
            'AUTO_NBR' );
        LC_SetResistance( $tcpar_pin, $state_value_initial );
    }
    elsif ( $state_value_unit_initial =~ /I/i ) {

        S_teststep( "Set switch '$tcpar_pin' to initial value '$state_value_initial' mA.",
            'AUTO_NBR' );
        LC_SetCurrent( $tcpar_pin, $state_value_initial );
    }


    S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
    LC_ECU_On($tcpar_ubat);
    S_wait_ms('TIMER_ECU_READY');

    S_teststep( 'Start NET trace', 'AUTO_NBR' );
    CA_trace_start(); # works for both CAN and FR

    # Set switch state value
    if ( $state_value_unit =~ /R/i ) {

        S_teststep( "Set switch '$tcpar_pin' to '$state_value' Ohm.",
            'AUTO_NBR' );
        LC_SetResistance( $tcpar_pin, $state_value );
    }
    elsif ( $state_value_unit =~ /I/i ) {

        S_teststep( "Set switch '$tcpar_pin' to '$state_value' mA.",
            'AUTO_NBR' );
        LC_SetCurrent( $tcpar_pin, $state_value );
    }
    
    S_teststep( "Wait 4 seconds until switch state is changed and / or fault qualified", 'AUTO_NBR');
    S_wait_ms(4000);
    
    S_teststep('Stop and store NET trace');
    CA_trace_stop();
    my $returned_store_file_name = CA_trace_store ( );


    # Fault recorder measurements
    S_teststep( 'Read fault recorder', 'AUTO_NBR' );
    $fltmem1 = PD_GetExtendedFaultInformation();
    S_teststep_2nd_level( 'Read and evaluate fault recorder (PD)', 'AUTO_NBR', 'FLT' )
      ;    # adapt label to FLT_After_Stim -> general for all teststeps


    S_teststep_2nd_level( 'Check Fault Recorder with Customer Diagnostics',
        'AUTO_NBR', 'FaultMemory_CD' );
    $flt_mem_struct_CD = CD_read_DTC( "0x02", "0x01" );


    S_teststep( 'Check switch state', 'AUTO_NBR' );

    S_teststep_2nd_level( 'Check switch state in SW label', 'AUTO_NBR' );
    foreach
      my $labelState ( sort keys %{ $expected_SwitchInfo->{$tcpar_state} } )
    {
        S_teststep_2nd_level(
            "Check 'rb_swm_SwitchInfo_ast($switch_nbr).$labelState'.",
            "AUTO_NBR", $labelState );
        $value_aref =
          PD_ReadMemoryByName("rb_swm_SwitchInfo_ast($switch_nbr).$labelState");
        $type = 'U8';
        $dec_value = S_aref2dec( $value_aref, $type );

        $det_threshold_href->{$labelState} = $dec_value;
    }

    if ( defined $tcpar_Diag_State_Request_Label ) {
        S_teststep_2nd_level( 'Check switch state with Customer Diagnostics',
            'AUTO_NBR', 'switchState_CD' );
        ( $det_cd_state, $det_cd_Interpreted_State ) =
          DIAG_getStateFromResponse( $tcpar_Diag_State_Request_Label,
            $tcpar_pin );

        unless ( defined $det_cd_Interpreted_State ) {
            $det_cd_Interpreted_State = $det_cd_state;
            S_set_warning(
                "No State Defined for value $det_cd_state in Mapping_DIAG \n"
                  . "For details refer documentation of DIAG_getStateFromResponse in FunctLib_TNT_DIAG "
            );
        }
    }

    if ( defined $tcpar_can_signal_switch_state ) {
         S_teststep_2nd_level( 'Check switch state value change in NET trace', 'AUTO_NBR', 'switchStateValue_NET');
         S_teststep_2nd_level( 'Check time from stimulation to switch state change in NET trace', 'AUTO_NBR', 'switchStateTime_NET');     
         $net_trace_href = CA_trace_get_dataref($returned_store_file_name, [$tcpar_can_signal_switch_state, "LC__$tcpar_pin"]);
    }
 

    # Check LSB
    if ( defined $tcpar_checkLSB ) {
        S_teststep( 'Read LSB value', 'AUTO_NBR' );
        S_teststep_2nd_level( "Read '$tcpar_checkLSB'.",
            "AUTO_NBR", $tcpar_checkLSB );
        $value_aref = PD_ReadMemoryByName($tcpar_checkLSB);
        $type       = PD_get_type_from_name($tcpar_checkLSB);
        $dec_value  = S_aref2dec( $value_aref, $type );

        $det_threshold_href->{$tcpar_checkLSB} = $dec_value;
    }

    return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

    S_teststep_expected( 'Expected faults:', 'FLT' );
    foreach my $fault (@$tcpar_FLTmand) {
        S_teststep_expected($fault);
    }

    S_teststep_detected( 'Detected faults:', 'FLT' );
    foreach my $fault ( @{ $fltmem1->{fault_text} } ) {
        S_teststep_detected($fault);
    }
    PD_evaluate_faults( $fltmem1, $tcpar_FLTmand, $tcpar_FLTopt );

    S_teststep_expected( 'Expected faults:', 'FaultMemory_CD' );
    foreach my $fault (@$tcpar_FLTmand) {
        S_teststep_expected($fault);
    }

    S_teststep_detected( 'Detected faults:', 'FaultMemory_CD' );
    foreach my $fault_DTC ( @{ $flt_mem_struct_CD->{"DTC"} } ) {
        S_teststep_detected($fault_DTC);
    }
    CD_evaluate_faults( $flt_mem_struct_CD, $tcpar_FLTmand, $tcpar_FLTopt );


    # Switch state PD SW label
    foreach
      my $labelState ( sort keys %{ $expected_SwitchInfo->{$tcpar_state} } )
    {
        S_teststep_expected(
"'$labelState' == '$expected_SwitchInfo->{$tcpar_state}{$labelState}'",
            $labelState
        );
        S_teststep_detected(
            "'$labelState' == '$det_threshold_href->{$labelState}'",
            $labelState );
        EVAL_evaluate_value( "$labelState", $det_threshold_href->{$labelState},
            '==', $expected_SwitchInfo->{$tcpar_state}{$labelState} );
    }

    # Switch state Diag
     if ( defined $tcpar_Diag_State_Request_Label ) {
        S_teststep_expected( "$tcpar_state", 'switchState_CD' );
        S_teststep_detected( "$det_cd_Interpreted_State($det_cd_state) ",
            'switchState_CD' );
        EVAL_evaluate_string(
            "switchState_CD", $tcpar_state,
            $det_cd_Interpreted_State
        );
    }

    # Switch staet NET
    if ( defined $tcpar_can_signal_switch_state ) {

        # Evaluate sequence
        
        # Evaluate time for state change
    }

    # LSB evaluation
    S_teststep_detected( "'LSB' == '$det_threshold_href->{$tcpar_checkLSB}'",
        $tcpar_checkLSB )
      if ( defined $tcpar_checkLSB );

    return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

    # set default value
    LC_SetLogicalState( $tcpar_pin, 'DEFAULT' );
    S_wait_ms(5000);

    # switch ECU off
    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

    S_teststep_detected("UBat: $tcpar_ubat V");

    return 1;
}

1;

__END__
