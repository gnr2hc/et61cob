#### TEST CASE MODULE
package TC_CSEM_SMI7;
# !!!! only for use with ManiToo Firmware_20141205 !!!!

#### DONT MODIFY THIS SECTION ####
use strict;
# -------------------------------
our $VERSION = q$Revision: 1.3 $;
our $HEADER  = q$Header: CSEM/TC_CSEM_SMI7.pm 1.3 2015/04/30 22:44:24ICT Petkof Wilhelm (CC-PS/EPS2) (PFW2SI) develop  $;
##################################

#### HERE SELECTION OF AUTOTEST MODULES ####
#use LIFT_POWER;
use LIFT_general;
use LIFT_evaluation;
use LIFT_PD;
use LIFT_MANITOO_TEMP;
use Data::Dumper;
$Data::Dumper::Sortkeys = 1; #Sort the keys in the output
##################################

our $PURPOSE = "TC_CSEM_SMI7";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
=pod

=head1 TESTCASE MODULE

TC_CSEM_SMI7  $Revision: 1.3 $

=head1 PURPOSE

TESTCASE MODULE for SMI7xx

=head1 PARAMETER DESCRIPTION

purpose                 = 'Purpose of the test case�
# ---------------------- TC_initialization ---------------------------------
# MANITOO_OPEN(), MANITOO_RUN($tcpar_ManiToo_tcpar)

# ---------------------- TC_stimulation_and_measurement --------------------
ManipuManipuStartTime_ms			= 10 
USE_FDIAG_RECORD        = 'yes'
_FastDiagVar0			= '<Test Heading Head>_Ch1SensorValue' 
_FastDiagVar1			= 'CenSen_DataValid'
WaitTime_ms			    = 1200

# PD_get_FDtrace, PD_ReadFaultMemory, PD_ReadMemoryByName 

# ---------------------- TC_evaluation -----------------------------------
USE_FLT_EVAL			= 'yes'
_FLT_state			    = %('FltCsAsicRolloverInternalMonitoring' => '0bxx011111')
_FLT_EventDebug			= %('FltCsAsicRolloverInternalMonitoring' => '0bxx000101')
USE_VAR_EVAL            = 'yes'
_EvalVar0_Docu			= 'Short test documetation'
_EvalVar0			    = @('CenSen_DataValid', 'OP', '<Test Heading Head>_DataValid_11')
_EvalVar1_Docu			= 'Short test documetation'
_EvalVar1			    = @('<Test Heading Head>_Ch1SensorValue', 'OP', 0)
USE_FDIAG_EVAL          = 'yes'
_FD_GetTime_T1			= @('T0', '<Test Heading Head>_MonitorData',  '==', 64)
_FD_GetTime_T2			= @('T1', 'WarningLampRequest', 'MASK',  '0bxxx1xxxx')
_FD_EvalTime0_T1_Docu	= 'Short test documetation'
_FD_EvalTime0_T1		= @('T2','OP', 112, 'OP', 142,)
USE_SPI_EVAL            = 'no'
_SPI_GetTime_T1		    = @('T0', 'SMA560:SEL_G_RANGE:MISO', 'OP', '0b0011000000000000')
_SPI_GetTime_T2		    = @('T1', 'SMA560:DE_FOR_TEST:MOSI', 'OP', '0b0011100000001001')
_SPI_GetTime_T3 		= @('T2', 'SMA560:DE_FOR_TEST:MOSI', 'OP', 'V_T2')
                          check if time (T2�T1) is between 10 ms and 162 ms (OP used: > 26 and < 162)
_SPI_EvalTime0_T1_Docu	= 'Short test documetation'                          
_SPI_EvalTime0_T1	   	= @('T2', '>',20, '<', 162,) 
                           check from time T2 over 1750 ms if value at SPI_GetTime_T2 occurs 20 times
_SPI_EvalSignal0_T2_Docu = 'Check if MOSI command �DE_FOR_TEST�  is repeated 20 times'
_SPI_EvalSignal0_T2		 = @(1750, 'SMA560:DE_FOR_TEST:MOSI', '==', 'V_T2', '==',20)
                           check from time T2 over 'I_T2T3' ms if value at SPI_GetTime_T2 occurs 20 times
_SPI_EvalSignal1_T2_Docu = 'Check if MOSI command �DE_FOR_TEST�  is repeated 20 times'
_SPI_EvalSignal1_T2		 = @('I_T2T3',�SMA560:DE_FOR_TEST:MOSI', '==', '0b0011100000000110', '==',20)

# ---------------------- TC_finalization ---------------------------------
# MANITOO_CLOSE()


OP: '=='  '!='  '>='  '<='  '<'  '>'  'MASK',   V_T1: value at time,  I_T1T2: time interval
Legend: XxxxXxxx: mandatory parameters, XXXXXXXX: mandatory control parameters, _XxxxXxx: optional parameters


Remark: USE_SPI_EVAL = 'no', because SPI recording not yet implemented for ManiToo

=cut	

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
my( $tcpar_USE_SPI_EVAL, $SPINumberOfTimeStamps );
my( @tcpar_SPI_GetTime, @tcpar_SPI_GetTime_LogStart, @tcpar_SPI_GetTime_Signal, @tcpar_SPI_GetTime_Operator, @tcpar_SPI_GetTime_ExpValue, @SPI_CheckTimeIndex );	        	       		                	
my( @tcpar_SPI_EvalTimeDocu, @tcpar_SPI_EvalTime, @tcpar_SPI_EvalTime_Start, @tcpar_SPI_EvalTime_Operator1, @tcpar_SPI_EvalTime_ExpValue1, @tcpar_SPI_EvalTime_Operator2, @tcpar_SPI_EvalTime_ExpValue2 );
my( @tcpar_SPI_EvalSignalDocu, @tcpar_SPI_EvalSignal, @tcpar_SPI_EvalSignal_Signal, @tcpar_SPI_EvalSignal_Operator1, @tcpar_SPI_EvalSignal_ExpValue1, @tcpar_SPI_EvalSignal_Time, @tcpar_SPI_EvalSignal_Operator2, @tcpar_SPI_EvalSignal_ExpValue2 );
my( $tcpar_USE_FDIAG_EVAL, $FDNumberOfTimeStamps);
my( @tcpar_FD_GetTime, @tcpar_FD_GetTime_LogStart, @tcpar_FD_GetTime_Signal, @tcpar_FD_GetTime_Operator, @tcpar_FD_GetTime_ExpValue, @FD_CheckTimeIndex );      	       		                	
my( @tcpar_FD_EvalTimeDocu, @tcpar_FD_EvalTime, @tcpar_FD_EvalTime_Start, @tcpar_FD_EvalTime_Operator1, @tcpar_FD_EvalTime_ExpValue1, @tcpar_FD_EvalTime_Operator2, @tcpar_FD_EvalTime_ExpValue2 );
my( @tcpar_FD_EvalSignalDocu, @tcpar_FD_EvalSignal, @tcpar_FD_EvalSignal_Signal, @tcpar_FD_EvalSignal_Operator1, @tcpar_FD_EvalSignal_ExpValue1, @tcpar_FD_EvalSignal_Time, @tcpar_FD_EvalSignal_Operator2, @tcpar_FD_EvalSignal_ExpValue2 );
my( $tcpar_ManipuStartTime_ms, $tcpar_WaitTime_ms, $tcpar_DiagStartTime_ms );
my( $tcpar_USE_FLT_EVAL, @tcpar_FLTmand, %tcpar_FLT_state, %tcpar_FLT_EventDebug );
my( $tcpar_USE_VAR_EVAL, @tcpar_EvalVarDocu, @tcpar_EvalVar, @Eval_Var_Label, @Eval_Var_Operator, @Eval_Var_Value );
my( $SPI_data);
my( $tcpar_USE_FDIAG_RECORD, @tcpar_FastDiagVar );
my( @FDlabel, @FDformat, %FDiagLabel );
my( $FD_data, $FDtrace );
my( @detected_var, $flt_mem_struct );
my( $tcpar_SRT_Id, $tcpar_ManiToo_tcpar );

# -----------------------------------------------------------------------------------------------------
#                                     READ TEST CASE PARAMETER
# -----------------------------------------------------------------------------------------------------
sub TC_set_parameters {
    # ------------------------------------------------------------------------            
    $tcpar_ManiToo_tcpar = S_read_testcase_parameter( 'ManiToo_tcpar' );

    # ------------------------------------------------------------------------            
    $tcpar_ManipuStartTime_ms = S_read_testcase_parameter( 'ManipuStartTime_ms' );
    $tcpar_WaitTime_ms = S_read_testcase_parameter( 'WaitTime_ms' );
    $tcpar_DiagStartTime_ms = S_read_testcase_parameter( 'DiagStartTime_ms' );  

    # ------------------------------------------------------------------------            
    $tcpar_USE_FDIAG_RECORD = S_read_testcase_parameter( 'USE_FDIAG_RECORD' );
		@tcpar_FastDiagVar = ();

    if ($tcpar_USE_FDIAG_RECORD eq 'yes') {
  		for ( my $i = 0; $i <= 9; $i++ ) {
	        my $expected_var = S_read_testcase_parameter( '_FastDiagVar' . $i );
			if ($expected_var) {
				push ( @tcpar_FastDiagVar, $expected_var );					
			}
		}
    }
             
    # ------------------------------------------------------------------------            
    $tcpar_USE_FLT_EVAL = S_read_testcase_parameter('USE_FLT_EVAL');
    	%tcpar_FLT_state = ();
    	%tcpar_FLT_EventDebug = ();
    	@tcpar_FLTmand = ();
    
    if ( $tcpar_USE_FLT_EVAL eq 'yes' ) {
        %tcpar_FLT_state = S_read_testcase_parameter( '_FLT_state' );
        %tcpar_FLT_EventDebug = S_read_testcase_parameter( '_FLT_EventDebug' );
	    while ( my($key, $data) = each %tcpar_FLT_state ) {
			push(@tcpar_FLTmand, $key);
    	}
    }

    # ------------------------------------------------------------------------            
    $tcpar_USE_VAR_EVAL = S_read_testcase_parameter( 'USE_VAR_EVAL' );
		@tcpar_EvalVar =();
		@Eval_Var_Label = ();
		@Eval_Var_Value =();

    if( $tcpar_USE_VAR_EVAL eq 'yes' ) {
  		for ( my $i = 0; $i < 10; $i++ ) {
	        $tcpar_EvalVarDocu[$i] = S_read_testcase_parameter( '_EvalVar' . $i . '_Docu' );
	        @tcpar_EvalVar = S_read_testcase_parameter( '_EvalVar' . $i );
			if (@tcpar_EvalVar) {
        		if ( defined(my $newkey = $main::ProjectDefaults->{'EXPECTED_VAR'}->{$tcpar_EvalVar[0]}) ) {
					$Eval_Var_Label[$i] = $newkey;
        		}
        		else {
        			$Eval_Var_Label[$i] = $tcpar_EvalVar[0];
        		}
        		
				$Eval_Var_Operator[$i] = $tcpar_EvalVar[1];

        		if ( defined(my $data = $main::ProjectDefaults->{'EXPECTED_VAR'}->{$tcpar_EvalVar[2]}) ) {
					$Eval_Var_Value[$i] =  $data;
        		}
        		else {
					$Eval_Var_Value[$i] = $tcpar_EvalVar[2]	
        		}
			}
		}
    }
         
    # ------------------------------------------------------------------------            
    $tcpar_USE_FDIAG_EVAL = S_read_testcase_parameter( 'USE_FDIAG_EVAL' );
    	$FDNumberOfTimeStamps = 0;
    	@FD_CheckTimeIndex = ();

    if ( $tcpar_USE_FDIAG_EVAL eq 'yes' ) {
 		my $k = 0;
 		for (my $i = 1; $i <= 9; $i++) {
	        @tcpar_FD_GetTime = S_read_testcase_parameter( '_FD_GetTime_T' . $i );
			if ( @tcpar_FD_GetTime ) {
	        	$tcpar_FD_GetTime[0] =~ m/\w+(\d)/;
	        	$tcpar_FD_GetTime_LogStart[$i] = $1;
				$tcpar_FD_GetTime_Signal[$i] = $tcpar_FD_GetTime[1];
				$tcpar_FD_GetTime_Operator[$i] = $tcpar_FD_GetTime[2];
				$tcpar_FD_GetTime_ExpValue[$i] = $tcpar_FD_GetTime[3];				
				$FDNumberOfTimeStamps = $i;
				
				for ( my $j = 0; $j <= 9; $j++ ) {
		        	$tcpar_FD_EvalTimeDocu[$k] = S_read_testcase_parameter( '_FD_EvalTime' . $j  . '_T' . $i . '_Docu' );
					$tcpar_FD_EvalTime_Start[$k] = -1;
		        	@tcpar_FD_EvalTime = S_read_testcase_parameter( '_FD_EvalTime' . $j  . '_T' . $i);
					if (@tcpar_FD_EvalTime) {
				        $tcpar_FD_EvalTime[0] =~ m/\w+(\d+)/;
				        $tcpar_FD_EvalTime_Start[$k] = $1;
				        $tcpar_FD_EvalTime_Operator1[$k] = $tcpar_FD_EvalTime[1];
        				$tcpar_FD_EvalTime_ExpValue1[$k] = $tcpar_FD_EvalTime[2];
				        $tcpar_FD_EvalTime_Operator2[$k] = $tcpar_FD_EvalTime[3];
        				$tcpar_FD_EvalTime_ExpValue2[$k] = $tcpar_FD_EvalTime[4];
					}
		        	$tcpar_FD_EvalSignalDocu[$k] = S_read_testcase_parameter( '_FD_EvalSignal' . $j  . '_T' . $i . '_Docu');
					$tcpar_FD_EvalSignal_Time[$k] = -1;
			        @tcpar_FD_EvalSignal = S_read_testcase_parameter( '_FD_EvalSignal' . $j  . '_T' . $i );
					if ( @tcpar_FD_EvalSignal ) {
	        			$tcpar_FD_EvalSignal_Time[$k] = $tcpar_FD_EvalSignal[0];
						$tcpar_FD_EvalSignal_Signal[$k] = $tcpar_FD_EvalSignal[1];
						$tcpar_FD_EvalSignal_Operator2[$k] = $tcpar_FD_EvalSignal[2];
						$tcpar_FD_EvalSignal_ExpValue2[$k] = $tcpar_FD_EvalSignal[3];
	        			$tcpar_FD_EvalSignal_Operator1[$k] = $tcpar_FD_EvalSignal[4];
					    $tcpar_FD_EvalSignal_ExpValue1[$k] = $tcpar_FD_EvalSignal[5];						
					}
					$FD_CheckTimeIndex[$k] = $i;
					$k++;
				}	
			}
		}
    }	

    # ------------------------------------------------------------------------            
    $tcpar_USE_SPI_EVAL = S_read_testcase_parameter( 'USE_SPI_EVAL' );
    	$SPINumberOfTimeStamps = 0;
    	@SPI_CheckTimeIndex = ();

    if ( $tcpar_USE_SPI_EVAL eq 'yes' ) {
 		my $k = 0;
 		for ( my $i = 1; $i <= 16; $i++ ) {
	        @tcpar_SPI_GetTime = S_read_testcase_parameter( '_SPI_GetTime_T' . $i );
			if ( @tcpar_SPI_GetTime ) {
	        	$tcpar_SPI_GetTime[0] =~ m/\w+(\d)/;
	        	$tcpar_SPI_GetTime_LogStart[$i] = $1;
				$tcpar_SPI_GetTime_Signal[$i] = $tcpar_SPI_GetTime[1];
				$tcpar_SPI_GetTime_Operator[$i] = $tcpar_SPI_GetTime[2];
				$tcpar_SPI_GetTime_ExpValue[$i] = $tcpar_SPI_GetTime[3];				
				$SPINumberOfTimeStamps = $i;
				
				for ( my $j = 0; $j <= 9; $j++ ) {
		        	$tcpar_SPI_EvalTimeDocu[$k] = S_read_testcase_parameter( '_SPI_EvalTime' . $j  . '_T' . $i . '_Docu');
					$tcpar_SPI_EvalTime_Start[$k] = -1;
		        	@tcpar_SPI_EvalTime = S_read_testcase_parameter('_SPI_EvalTime' . $j  . '_T' . $i);
					if ( @tcpar_SPI_EvalTime ) {
				      $tcpar_SPI_EvalTime[0] =~ m/\w+(\d+)/;
				      $tcpar_SPI_EvalTime_Start[$k] = $1;
				      $tcpar_SPI_EvalTime_Operator1[$k] = $tcpar_SPI_EvalTime[1];
        				$tcpar_SPI_EvalTime_ExpValue1[$k] = $tcpar_SPI_EvalTime[2];
				      $tcpar_SPI_EvalTime_Operator2[$k] = $tcpar_SPI_EvalTime[3];
        				$tcpar_SPI_EvalTime_ExpValue2[$k] = $tcpar_SPI_EvalTime[4];
					}
		        	$tcpar_SPI_EvalSignalDocu[$k] = S_read_testcase_parameter( '_SPI_EvalSignal' . $j  . '_T' . $i . '_Docu');
					$tcpar_SPI_EvalSignal_Time[$k] = -1;
			        @tcpar_SPI_EvalSignal = S_read_testcase_parameter('_SPI_EvalSignal' . $j  . '_T' . $i);
					if ( @tcpar_SPI_EvalSignal ) {
	        			$tcpar_SPI_EvalSignal_Time[$k] = $tcpar_SPI_EvalSignal[0];
						$tcpar_SPI_EvalSignal_Signal[$k] = $tcpar_SPI_EvalSignal[1];
						$tcpar_SPI_EvalSignal_Operator2[$k] = $tcpar_SPI_EvalSignal[2];
						$tcpar_SPI_EvalSignal_ExpValue2[$k] = $tcpar_SPI_EvalSignal[3];
	        			$tcpar_SPI_EvalSignal_Operator1[$k] = $tcpar_SPI_EvalSignal[4];
					   $tcpar_SPI_EvalSignal_ExpValue1[$k] = $tcpar_SPI_EvalSignal[5];						
					}
					$SPI_CheckTimeIndex[$k] = $i;
					$k++;
				}	
			}
		}
    }	

    # ------------------------------------------------------------------------            
    # Show test case ID in report
    $tcpar_SRT_Id = S_read_testcase_parameter('SRT_ID');
    
    return 1;
}

#******************************************************************************************************
#                                      TEST CASE INITIALIZATION                                       *  
#******************************************************************************************************
sub TC_initialization {
    MANITOO_RUN_SERVICE('power_ON');
    MANITOO_RUN_SERVICE('disable_all_modules');
    MANITOO_RUN_SERVICE('start_manipulation');
    MANITOO_RUN_SERVICE('stop_manipulation');
    MANITOO_RUN_SERVICE('reset_manipulation');

    S_wait_ms( 600 );

    PD_ECUlogin();       
    $flt_mem_struct = PD_ReadFaultMemory(1);
    
    PD_ClearFaultMemory();
    S_wait_ms( 9000 );    
    $flt_mem_struct = PD_ReadFaultMemory(1);

    MANITOO_RUN_SERVICE('power_OFF');
    MANITOO_RUN_SERVICE('disable_all_modules');
    MANITOO_RUN_SERVICE('start_manipulation');
    MANITOO_RUN_SERVICE('stop_manipulation');
    MANITOO_RUN_SERVICE('reset_manipulation');
    
    S_wait_ms( 'TIMER_ECU_OFF' );

    if ($tcpar_ManipuStartTime_ms <= 0) {
        MANITOO_RUN_SERVICE('power_ON');
        MANITOO_RUN_TEST_SEQUENCE($tcpar_ManiToo_tcpar);
        MANITOO_RUN_SERVICE('start_manipulation');
    }
    else {
        MANITOO_RUN_SERVICE('power_ON');
        MANITOO_RUN_SERVICE('start_manipulation');
        MANITOO_RUN_SERVICE('stop_manipulation');
        MANITOO_RUN_SERVICE('reset_manipulation');
    
    }
    return 1;
}

#******************************************************************************************************
#                                   STIMULATION AND MEASUREMENT                                       *  
#******************************************************************************************************
sub TC_stimulation_and_measurement {
    S_wait_ms( $tcpar_DiagStartTime_ms );        
    PD_ECUlogin();
    
    if ($tcpar_ManipuStartTime_ms > 0) {
        S_wait_ms( $tcpar_ManipuStartTime_ms );        
    }
    
    # Prepare data for Fast Diagnosis
    if ($tcpar_USE_FDIAG_RECORD eq 'yes') {        
		@FDlabel = ();
		@FDformat = ();
		%FDiagLabel = ();
	    
        my $data;
        my $fdIndex = 0;

        foreach my $key_fast_diag (@tcpar_FastDiagVar) {
            if ( not defined($data = $main::ProjectDefaults->{'FAST_DIAG_VAR'}{$key_fast_diag}) ) {
                $data = $key_fast_diag;
            }
            # extract  FDlabel and  FDformat
            $data =~ /(.+)_(\w+)$/; 
            $FDlabel[$fdIndex] = $1;
            $FDformat[$fdIndex] = $2;

			$FDiagLabel{$key_fast_diag} = $FDlabel[$fdIndex];
            $fdIndex++;            
        }

		my ($key1, $data1);
	    while ( ($key1, $data1) = each %FDiagLabel ) {
        	S_w2log(5, " $key1 => $data1 \n", "blue");
    	}

        $FDtrace = "FD_".time();
        PD_StartFastDiagName( $main::REPORT_PATH."/$FDtrace.txt", \@FDlabel, \@FDformat);
    }

    if ($tcpar_ManipuStartTime_ms > 0) {
        MANITOO_RUN_SERVICE('power_ON');
        MANITOO_RUN_TEST_SEQUENCE($tcpar_ManiToo_tcpar);
        MANITOO_RUN_SERVICE('start_manipulation');
    }
    # Wait until fault is qualified
    S_wait_ms( $tcpar_WaitTime_ms );

    MANITOO_RUN_SERVICE('stop_manipulation');
    MANITOO_RUN_SERVICE('reset_manipulation');

    
    if ( $tcpar_USE_FDIAG_RECORD eq 'yes' ) {# Fast Diagnosis active?
        PD_StopFastDiag();
        $FD_data = PD_get_FDtrace( $main::REPORT_PATH."/$FDtrace.txt" );    
        my $FD_trace = "FD_trace_".time();
        EVAL_dump2file( $FD_data, $main::REPORT_PATH."/$FD_trace.txt" );
        PD_plot_FDtrace( $FD_data, $main::REPORT_PATH."/$FDtrace.txt" );
        S_add_pic2html ( "./$FDtrace.png",'', "./$FDtrace.txt.unv", 'TYPE="text/unv"' );
# debug
#		my $FD_trace_analysis = "FD_trace_analysis_".time();
#       open (FILE, ">", "$main::REPORT_PATH./$FD_trace_analysis.txt"); 
#       print FILE Dumper($FD_data);
#       close (FILE);
    }

    if ( $tcpar_USE_VAR_EVAL eq 'yes' ) { # Read RAM variables?
	    foreach my $i (0 .. $#Eval_Var_Label) {
            $detected_var[$i] = S_aref2hex( PD_ReadMemoryByName($Eval_Var_Label[$i]) );
       }
    }
        
    $flt_mem_struct = PD_ReadFaultMemory(1);
# debug
#   print Dumper($flt_mem_struct); 
    
    return 1;
}

#******************************************************************************************************
#                                        TEST CASE EVALUATION                                         *  
#******************************************************************************************************
sub TC_evaluation {    
    # Evaluate Fault Memory
    PD_evaluate_faults( $flt_mem_struct, \@tcpar_FLTmand );

    if ($tcpar_USE_FLT_EVAL eq 'yes') { # Check for mandatory faults?
        # Comparing the fault state to expected state
        foreach my $key (keys %tcpar_FLT_state) {
            if ( PD_count_fault($flt_mem_struct, $key) ) {
                PD_check_fault_status( $flt_mem_struct, $key, $tcpar_FLT_state{$key}, 'state' );
#                PD_check_fault_status( $flt_mem_struct, $key, $tcpar_FLT_EventDebug{$key}, 'EventDebug' );
            }
        }
    }

    # Evaluate variables
    if ( $tcpar_USE_VAR_EVAL eq 'yes' ) {
	    foreach my $i (0 .. $#Eval_Var_Label) {
			S_w2log( 5, $tcpar_EvalVarDocu[$i], "blue" );
            EVAL_evaluate_value ( $Eval_Var_Label[$i], $detected_var[$i], $Eval_Var_Operator[$i], $Eval_Var_Value[$i] );
        }
    }
    
    # Evaluate Fast Diagnosis trace
    if ($tcpar_USE_FDIAG_EVAL eq 'yes') {
		my @FDtime = ();
		my @FDvalue = ();
		my $verdict = 'PASS';

        foreach my $i ( 1 .. $FDNumberOfTimeStamps ) {
            S_w2log( 5, "Get timestamp T$i\n", "green" );           
            if ( $tcpar_FD_GetTime_ExpValue[$i] =~ /V_T(\d)/ ) {
            	$tcpar_FD_GetTime_ExpValue[$i] = $FDvalue[$1]	
            }
            $FDtime[$i] = EVAL_get_time_when( $FD_data, $FDiagLabel{$tcpar_FD_GetTime_Signal[$i]}, $tcpar_FD_GetTime_Operator[$i], $tcpar_FD_GetTime_ExpValue[$i], $FDtime[$tcpar_FD_GetTime_LogStart[$i]] + 0.001 );                

            if ( $FDtime[$i] == -1 ) { # SPI condition not matched?
                S_set_verdict (VERDICT_FAIL);
                $verdict = 'FAIL';
                last;
            }
            else {
	        	$FDvalue[$i] = EVAL_get_value_around_time( $FD_data, $FDtime[$i], $FDiagLabel{$tcpar_FD_GetTime_Signal[$i]} );            	
            }
        }
 
        if ($verdict eq 'PASS') {
	        foreach my $i ( 0 .. $#FD_CheckTimeIndex ) {
				# Evaluate signal delta time
				if ($tcpar_FD_EvalTime_Start[$i] != -1) {
					S_w2log( 5, $tcpar_FD_EvalTimeDocu[$i], "blue" );
					S_w2log( 5, "Check delta time T$FD_CheckTimeIndex[$i]-T$tcpar_FD_EvalTime_Start[$i]\n", "green" );
                	my $deltatime = $FDtime[$tcpar_FD_EvalTime_Start[$i]] - $FDtime[$FD_CheckTimeIndex[$i]];
                	EVAL_evaluate_value( "Delta time", $deltatime, $tcpar_FD_EvalTime_Operator1[$i], $tcpar_FD_EvalTime_ExpValue1[$i] );
                	EVAL_evaluate_value( "Delta time", $deltatime, $tcpar_FD_EvalTime_Operator2[$i], $tcpar_FD_EvalTime_ExpValue2[$i] );
				}
				# Check and count signals
	 			if ( $tcpar_FD_EvalSignal_Time[$i] != -1) {               
					my $FDcount = 0;
	            	if ( $tcpar_FD_EvalSignal_ExpValue2[$i] =~ /V_T(\d)/ ) {
    	        		$tcpar_FD_EvalSignal_ExpValue2[$i] = $FDvalue[$1]	
        	    	}
					my $TimeLogStart = $FDtime[$FD_CheckTimeIndex[$i]];
					if ( $tcpar_FD_EvalSignal_Time[$i] =~ /I_T(\d)T(\d)/ ) {
            			$tcpar_FD_EvalSignal_Time[$i] = abs($FDtime[$1] - $FDtime[$2]);
            		}
					my $TimeLogEnd = $TimeLogStart + $tcpar_FD_EvalSignal_Time[$i];

					S_w2log( 5, $tcpar_FD_EvalSignalDocu[$i], "blue" );
					S_w2log( 5, "Count number of signals from T$FD_CheckTimeIndex[$i] over $tcpar_FD_EvalSignal_Time[$i]mS\n", "green" );
					do  {
	    	        	$TimeLogStart = EVAL_get_time_when( $FD_data, $FDiagLabel{$tcpar_FD_EvalSignal_Signal[$i]}, $tcpar_FD_EvalSignal_Operator2[$i], $tcpar_FD_EvalSignal_ExpValue2[$i], $TimeLogStart, $TimeLogEnd );
	        	        if ($TimeLogStart != -1) {
	                		$TimeLogStart = $TimeLogStart + 0.001;
	            	    	$FDcount++;
		                }
	    	        }
	        	    until ($TimeLogStart == -1);
	                # Check number of signals	                
	            	EVAL_evaluate_value( "Number of signals", $FDcount, $tcpar_FD_EvalSignal_Operator1[$i], $tcpar_FD_EvalSignal_ExpValue1[$i] );	                
				}   
        	}              
        }                    
    }
       
    # Evaluate SPI trace
    if ($tcpar_USE_SPI_EVAL eq 'yes') {
		my @SPItime = ();
		my @SPIvalue = ();
		my $verdict = 'PASS';

        foreach my $i ( 1 .. $SPINumberOfTimeStamps ) {
            S_w2log(5, "Get timestamp T$i\n", "green");
            if ( $tcpar_SPI_GetTime_ExpValue[$i] =~ /V_T(\d)/ ) {
            	$tcpar_SPI_GetTime_ExpValue[$i] = $SPIvalue[$1]	
            }
            $SPItime[$i] = EVAL_get_time_when( $SPI_data, $tcpar_SPI_GetTime_Signal[$i], $tcpar_SPI_GetTime_Operator[$i], $tcpar_SPI_GetTime_ExpValue[$i], $SPItime[$tcpar_SPI_GetTime_LogStart[$i]] + 0.001 );                

            if ($SPItime[$i] == -1) { # SPI condition not matched?
                S_set_verdict( VERDICT_FAIL );
                $verdict = 'FAIL';
                last;
            }
            else {
	        	$SPIvalue[$i] = EVAL_get_value_around_time( $SPI_data, $SPItime[$i], $tcpar_SPI_GetTime_Signal[$i] );            	
            }
        }
 
        if ($verdict eq 'PASS') {
	        foreach my $i ( 0 .. $#SPI_CheckTimeIndex ) {
				# Evaluate SPI delta time
				if ($tcpar_SPI_EvalTime_Start[$i] != -1) {
					S_w2log( 5, $tcpar_SPI_EvalTimeDocu[$i], "blue" );
					S_w2log( 5, "Check delta time T$SPI_CheckTimeIndex[$i]-T$tcpar_SPI_EvalTime_Start[$i]\n", "green" );
                	my $deltatime = $SPItime[$tcpar_SPI_EvalTime_Start[$i]] - $SPItime[$SPI_CheckTimeIndex[$i]];
                	EVAL_evaluate_value( "Delta time", $deltatime, $tcpar_SPI_EvalTime_Operator1[$i], $tcpar_SPI_EvalTime_ExpValue1[$i] );
                	EVAL_evaluate_value( "Delta time", $deltatime, $tcpar_SPI_EvalTime_Operator2[$i], $tcpar_SPI_EvalTime_ExpValue2[$i] );
				}
				# Check and count SPI commands
				if ( $tcpar_SPI_EvalSignal_Time[$i] != -1) {                
					my $SPIcount = 0;
	            	if ( $tcpar_SPI_EvalSignal_ExpValue2[$i] =~ /V_T(\d)/ ) {
    	        		$tcpar_SPI_EvalSignal_ExpValue2[$i] = $SPIvalue[$1]	
        	    	}
					my $TimeLogStart = $SPItime[$SPI_CheckTimeIndex[$i]];										
					if ( $tcpar_SPI_EvalSignal_Time[$i] =~ /I_T(\d)T(\d)/ ) {
            			$tcpar_SPI_EvalSignal_Time[$i] = abs( $SPItime[$1] - $SPItime[$2] );
            		}
					my $TimeLogEnd = $TimeLogStart + $tcpar_SPI_EvalSignal_Time[$i];

					S_w2log( 5, $tcpar_SPI_EvalSignalDocu[$i], "blue" );
					S_w2log( 5, "Count number of SPI commands from T$SPI_CheckTimeIndex[$i] over $tcpar_SPI_EvalSignal_Time[$i]mS\n", "green");
					do  {
	        	    	$TimeLogStart = EVAL_get_time_when( $SPI_data, $tcpar_SPI_EvalSignal_Signal[$i], $tcpar_SPI_EvalSignal_Operator2[$i], $tcpar_SPI_EvalSignal_ExpValue2[$i], $TimeLogStart, $TimeLogEnd );
	          	     	if ( $TimeLogStart != -1 ) {
	            	    	$TimeLogStart = $TimeLogStart + 0.001;
	            	    	$SPIcount++;
	                	}
	            	}
	        	    until ($TimeLogStart == -1);
	                # Check number of SPI commands
	            	EVAL_evaluate_value( "Number of SPI commands", $SPIcount, $tcpar_SPI_EvalSignal_Operator1[$i], $tcpar_SPI_EvalSignal_ExpValue1[$i] );	                
				}    
        	}              
        }                    
    }
           
    return 1;
}
  
#******************************************************************************************************
#                                        TEST CASE FINALIZATION                                       *  
#******************************************************************************************************
sub TC_finalization {
    MANITOO_RUN_SERVICE('power_OFF');
    MANITOO_RUN_SERVICE('disable_all_modules');
    MANITOO_RUN_SERVICE('start_manipulation');
    MANITOO_RUN_SERVICE('stop_manipulation');
    MANITOO_RUN_SERVICE('reset_manipulation');

    S_wait_ms( 'TIMER_ECU_OFF' );

    return 1;
}

1;

__END__
