#### TEST CASE MODULE
package TC_ManiToo;

#### DONT MODIFY THIS SECTION ####
use strict;

# -------------------------------
our $VERSION = q$Revision: 2.15 $;
our $HEADER  = q$Header: CSEM/TC_ManiToo.pm 2.15 2020/05/13 22:48:34ICT Petkof Wilhelm (CC-PS/EPS2) (PFW2SI) develop  $;
##################################

#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_evaluation;
use LIFT_ProdDiag;
use LIFT_FaultMemory;
use FuncLib_TNT_GEN;
#use FuncLib_VDS;
use LIFT_manitoo;
use LIFT_spi_access;
use LIFT_can_access;
use LIFT_CD;
use LIFT_LA_AcuteTravelLogic;

use Data::Dumper;
$Data::Dumper::Sortkeys = 1;    #Sort the keys in the output

##################################
our $PURPOSE = "TC_CSEM_SMI7 / SMI8";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 NAME

TC_ManiToo.pm 2.2 : SMI7 and SMI8 sonsor tests with ManiToo

=head1 SYNOPSYS

- The USE_xxx_xxx parameters are controlling the test case flow.
- All USE_xxx_xxx parameters are optional.
- The default value for the USE_xxx_xxx parameters is 'no'. 
- If USE_xxx_xxx parameters are set to yes, 
  then other mandatorx _xxxxx are required

- If the test case is called with a dummy paramter
  then the ECU wil be switched on for a time of 12s.

                                  PARAMETER OVERVIEW
                    ************************************************
 
	Parameters                  |   Default values  |              Remark
----------------------------------------------------------------------------------------------
	Max_TC_Repetition           |        1          | - MAX_TC_REPETITION  
----------------------------------------------------------------------------------------------
	Timer_ECU_Off               |       4000        | - TIMER_ECU_OFF	
----------------------------------------------------------------------------------------------
	InitTest                    |	    'no'        | - Manipulation, SPI record and CAN trace
	                                                |    are started before power-ON
	StartTime_ms                |      8000 ms      | - TIMER_ECU_READY 
	MeasTime_ms                 |	   2000 ms      |    
	                            |                   |   
	if InitTest ='yes'          |	                | - Manipulation, SPI record and CAN trace
	                            |                   |   are started after StartTime_ms expired	
	StartTime_ms                |      150 ms       |   
	MeasTime_ms                 |     8000 ms       | - TMER_ECU_READY 
	                            |                   |   
----------------------------------------------------------------------------------------------
	USE_MANIPULATION            |	    'no'        |   
	   _ManipuDelayTime_ms      |	    200 ms      |   
	   _ManiToo_tcpar_S0        |                   |   
	USE_MANIPUCNT_EVAL          |	    'no'        |   
	   _EvalManipuCnt0_Docu     |                   |   
	   _EvalManipuCnt0          |                   |   
----------------------------------------------------------------------------------------------
	USE_FLTMEM_RECORD           |	    'no'        |   
	   _FLTMEM_Clear            |	    'yes'       |   
	USE_FLTMEM_EVAL             |	    'no'        |   
	   _FLT_state0              |                   |   
	   _EventDebug_Data0        |                   |   
	   _FLTopt                  |	                |   
----------------------------------------------------------------------------------------------
	USE_VAR_WRITE               |	    'no'        |   
	   _WriteVar0_Docu          |                   |   
   	   _WriteVar0               |                   |   
	USE_VAR_RECORD              |	    'no'        |   
	   _RecordVar0              |                   |   
	USE_VAR_EVAL                |	    'no'        |   
	   _EvalVar0_Docu           |                   |   
	   _EvalVar0                |                   |   
----------------------------------------------------------------------------------------------
	USE_FDIAG_RECORD            |	    'no'        |   
	   _FastDiagVar0            |                   |   
	USE_FDIAG_EVAL              |	    'no'        |   
	   _FD_GetTime_T1_Docu      |                   |   
	   _FD_GetTime_T1           |                   |   
	   _FD_EvalTime_T1_Docu     |                   |   
	   _FD_EvalTime_T1          |                   |   
	   _FD_EvalSignal_T1_Docu   |	                |   
	   _FD_EvalSignal_T1        |                   |   
----------------------------------------------------------------------------------------------
	USE_CAN_RECORD              |	    'no'        |   
	   _CANSignal0              |                   |   
	USE_CAN_EVAL                |	    'no'        |   
	   _CAN_GetTime_T1_Docu     |                   |   
	   _CAN_GetTime_T1          |                   |   
	   _CAN_EvalTime_T1_Docu    |	                |   
	   _CAN_EvalTime_T1         |                   |   
	   _CAN_EvalSignal_T1_Docu  |	                |   
	   _CAN_EvalSignal_T1       |                   |   
----------------------------------------------------------------------------------------------
	USE_SPI_RECORD              |       'no'        |   
	   _SPI_Node                |                   |   
	   _Leading_SPI_frames      |        10         |   
	   _Following_SPI_frames    |        10         |   
	USE_SPI_EVAL                |       'no'        |   
	   _SPI_GetTime_T1_Docu     |                   |   
	   _SPI_GetTime_T1          |                   |   
	   _SPI_EvalTime_T1_Docu    |	                |   
	   _SPI_EvalTime_T1         |                   |   
	   _SPI_EvalSignal_T1_Docu  |	                |   
	   _SPI_EvalSignal_T1       |                   |   
----------------------------------------------------------------------------------------------
	USE_LA_RECORD               |	    'no'        |   
	_LA_Channels                |                   | 
    _Line_break_time            |      0.0019 ms    |
----------------------------------------------------------------------------------------------
	USE_MODIFY_BYTE             |	    'no'        |   
	   _MODIFY_BYTE0            |                   |   
----------------------------------------------------------------------------------------------
	USE_SPECIFIC_TEST           |	    'no'        |   
	   _Specific_Test           |      '0x0000'     |   
----------------------------------------------------------------------------------------------


                                 Specific PARAMETERS
                    ************************************************
	Parameters                  |   Default values  |          Remark
----------------------------------------------------------------------------------------------
	_Specific_Test              |      '0x8001'     | SMI Verification  
	_Request_Verification_Data  |                   |
	_Check_Verification_Data    |                   |  
----------------------------------------------------------------------------------------------
	_Specific_Test              |      '0x8002'     | SMI7_FieldCalib_Start  
	_FieldCalib_Start           |                   |  
	_Specific_Test              |      '0x8004'     | SMI7_FieldCalib_Running  
	_FieldCalib_Runing          |                   | 
----------------------------------------------------------------------------------------------
	_Specific_Test              |      '0x4001'     | Enable_Flash_Erase  
	_ERASE_flash                |                   | _ERASE_flash = %( 'Start_Sector' => 0, 'End_Sector' => 511 ) 
----------------------------------------------------------------------------------------------
	_Specific_Test              |      '0x4002'     | SPI_Parameter_Test  
	_min_time_7_clks            |      665e-9 s     |   
	_min_delay_cs_clk           |       95e-9 s     |   
    _min_delay_clk_cs           |       95e-9 s     |  
	_min_time_cs_idle           |      200e-9 s     |   
----------------------------------------------------------------------------------------------




=head1 TEST CASE EXAMPLES

=head2 Test case initalization
	
	purpose                      = 'The purpose of the testcase'
	
	Max_TC_Repetition            = 1                      
	InitTest                     = 'yes'             
	StartTime_ms                 = 200               
	MeasTime_ms                  = 5000               

B<Explanation:>

=over

=item InitTest:

In case of InitTest the manipulation is started earlier than the ECU start. This way one can manipulate the init phase

=item StartTime_ms:

StartTime_ms is the waiting time after ECU Power-ON before SPI recording, Fast Diagnosis and manipulaiton are started. If it is an Init Test, then SPI recording
and manipulation are started before. Fast Diagnosis cannot be started before ECU Power-ON. CAN trace and Logic Analyzer are started before Power-ON ECU.
Power-ON.   

=item MeasTime_ms:

Measurement time. After this time every recording, measurement and manipulation are stopped (Fast Diagnosis, SPI recording, CAN recording, manipulation).
The following step is the evaluation.

=item Max_TC_Repetition:

If the test fails it will be repeated once more


                                                      
=head2 Fault memory                                   
    
	# Example 1
	USE_FLTMEM_RECORD          = 'yes'               
	   _FLTMEM_Clear           = 'yes'	   
												  
B<Explanation:>

=over

=item USE_FLTMEM_RECORD:

The fault memory is recorded, not evaluated

=item _FLTMEM_Clear:

The fault memory is cleared after test. If it is set to 'no', the faults will stay in the fault memory and will appear in the next testcase

=back

	# Example 2
	USE_FLTMEM_EVAL       = 'yes'               
	   _FLT_state0        = %( 'rb_csem_InitGroup1SmaMain_flt' => '0bx10101111')
	   _EventDebug_Data0  = %( 'rb_csem_InitGroup1SmaMain_flt' => '0x8002')
	   _FLTopt            = @( 'rb_coa_VehSpdRxMsgTimeout_flt')
	                                  

B<Explanation:>

=over

=item USE_FLTMEM_EVAL:

The fault memory is evaluated

=item _FLT_state0:

It is checked if rb_csem_InitGroup1SmaMain_flt appears in the fault memory with its corresponding Bosch Fault Memory data

=item _EventDebug_Data0:

It is checked if the Event Debug Data of rb_csem_InitGroup1SmaMain_flt's is 0x8002.

=item _FLTopt:

Optional faults can be listed here. 

=back

B<Others:>

=over

=item DTC:

The fault's DTC is always checked. The expected DTC can be set in the configuration file. 

=over
                                                     
=head2 RAM Variables                                 
                                                     
	USE_VAR_RECORD              = 'yes'               
	   _RecordVar0              = 'rb_cs6m_ChannelState_aen(0)'
	   

B<Explanation:>

=over

=item USE_VAR_RECORD:

RAM variable is recorded but not evaluated. The value of the variable is saved during the test.

=back

	USE_VAR_EVAL                = 'yes'               
	   _EvalVar0_Docu           = 'SMA660Main_DeviceId_V is checked whether it is 26208' 
	   _EvalVar0                = @( 'SMA660Main_DeviceId_V', '==', 26208 )

B<Explanation:>

=over

=item USE_VAR_EVAL:

It is evaluated whether the value of SMA660Main_DeviceId_V is 26208. The evaluation takes place after the
evaluation time. It is only a static value, that is recorded. For dynamic recording use fast diagnosis! 

                                                      
=head2 Fast Diagnosis                                 
                                                      
	USE_FDIAG_RECORD            = 'yes'               
	   _FastDiagVar0            = 'AccYHgMonChl_State_U8'

	USE_FDIAG_EVAL              = 'yes'               
	   _FD_GetTime_T1_Docu      = 'Get time when AccYHgMonChl_State_U8 has the value 3'
	   _FD_GetTime_T1           = @( 'T0', 'AccYHgMonChl_State_U8',  '==', 3)
	   
	   _FD_GetTime_T2_Docu      = 'Get time when AccYHgMonChl_State_U8 has the value 0'
	   _FD_GetTime_T2           = @( 'T1', 'AccYHgMonChl_State_U8',  '==', 0)
	   
	   _FD_EvalTime0_T1_Docu    = 'Check the fault qualification time'
	   _FD_EvalTime0_T1	        = @( 'T2', '>', 35.50, '<', 44.50 )
	   
	   _FD_EvalSignal0_T2_Docu= 'Check if AccZLgChl_State_U8 stays 0'                          
	   _FD_EvalSignal0_T2       = @( 1000, 'AccZLgChl_State_U8', '!=',  0, '==', 0 )

B<Explanation:>

=over

=item USE_FDIAG_RECORD:

AccYHgMonChl_State_U8 will be shown on a diagram. The start of the recording can be set by StartTime_ms. The duration of the recording can be
set by MeasTime_ms. The earliest possible beginning of the recording is 200ms after ECU start. If you want to observe the init phase, then use
init delay (USE_MODIFY_BYTE).  

=item USE_FDIAG_EVAL:

You can only evaluate fast diagnosis if you have also recorded. You can evaluate either time or signal, whose settings are defined by the following parameters.

=item _FD_GetTime_T1:

T0 is the time of ECU start (reference time). T1 is going to be the time, when AccYHgMonChl_State_U8 is 3. T2 is going to be the time
 when AccYHgMonChl_State_U8 changes to 0 (after time T1). Values before T1 are going to be ignored.

=item _FD_EvalTime0_T1:

In this case the elapsed time between T1 and T2 is going to be evaluated, if it is between 35.50 and 44.50

=item _FD_EvalSignal0_T1:

We check if AccZLgChl_State_U8 holds the value 0 for 1000 ms from T2 on. In the form double negative is used.
So we check if the the value of the variable differs 0 times 0. That means it hold's its value.

=back
               
                                                      
=head2 CAN communication                              
                                                      
	USE_CAN_RECORD              = 'yes'               
	   _CANSignal0              = 'yes'               
	USE_CAN_EVAL                = 'yes'               
	   _CAN_GetTime_T1_Docu     = 'yes'               
	   _CAN_GetTime_T1          = 'yes'               
	   _CAN_EvalTime_T1_Docu    = 'yes'               
	   _CAN_EvalTime_T1         = 'yes'               
	   _CAN_EvalSignal_T1_Docu  = 'yes'               
	   _CAN_EvalSignal_T1       = 'yes'               
                                                     
=head2 SPI communication                             
                                                     
	USE_SPI_RECORD              = 'yes'               
	   _SPI_Node                = @( 'SMA660_M' )              
	   _Leading_SPI_frames      = '20'               
	   _Following_SPI_frames    = '30'   
	   
	USE_SPI_EVAL                = 'yes'               
	   _SPI_GetTime_T1_Docu     = 'Get time for AccXHgMonChl = 240'
       _SPI_GetTime_T1          = @( 'T0', 'SMI::AccXHgMonChl::MISO::DATA', '==', 240') 
	   
       _SPI_GetTime_T2_Docu     = 'Get time for Yaw'
       _SPI_GetTime_T2          = @( 'T1', 'SMI::AccXHgMonChl::MISO::DATA', '!=', 240') 
	   
       _SPI_EvalTime0_T1_Docu   = 'Check time for AccXHgMonChl manipulation' 
       _SPI_EvalTime0_T1        = @( 'T2', '>=', 9.9, '<=', 10.1 )

B<Explanation:>

=over


=item USE_SPI_RECORD:

The messages on the SPI bus are going to be recorded. The result is stored in an mbt file. 
It contains time stamps, MISO and MOSI values, and the decoded values. 

=item _SPI_Node:

In this parameter a CS has to be given, on which the recording is executed.
'SMA660_M' is on CS2, which means every message will be recorded on CS2.
The Mapping_SPI_network contains on which CS are the sensors and ASICs. 

=back

B<Others:>

=over

=item When is the start of the SPI recording and how long does it last?:

If the test is an InitTest, then the SPI recording is started immediately after ECU Power-ON. If it is not the case
the SPI recording is started after StartTime_ms right before the start manipulation.

=item How to open the SPI recording?:

The result is an mbt file, which is in the report folder. This file has to be converted to .dat 
extension if you want to open it with SPIMaid. This can be done with the ManiToo
application or with SPIMaid. 

=over


 
                                                     
=head2 Manipulation                                  
                                                     
	USE_MANIPULATION            = 'yes'
	   _ManiToo_tcpar_S0        = '00_SMI_SPI_CS'			
	   _ManiToo_tcpar_S1        = '00_SMI_SensorMask'
	   _ManiToo_tcpar_S2        = '00_AccXLgChl'
	   _ManiToo_tcpar_S3        = '00_Mode_98ms'
	   _ManiToo_tcpar_S4        = '00_Set_Data_200_SMI'
	   _ManipuDelayTime_ms      = 200
	USE_MANIPUCNT_EVAL          = 'yes'               
	   _EvalManipuCnt0_Docu     = 'Check manipulation counter for Unit_0'
	   _EvalManipuCnt0          = @('Unit_0', '==', '3')

B<Explanation:>

=over

=item USE_MANIPULATION:

In case of USE_MANIPULATION we have to set in the following parameters the SPI and CS, where we want to manipulate,
the trigger mask, trigger pattern, manipulation mask, manipulation pattern and the manipulation mode. The two numbers at the beginning
of the parameter stand for the manipulation module.
  
=item USE_MANIPUCNT_EVAL:

Here we can check whether the manipulation unit has manipulated so many times as we wanted.

=item ManipuDelayTime_ms:

ManipuDelayTime_ms is the waiting time between the start of the fast diagnosis and the manipulation. The purpose is
to see what is happening before the manipulation. In this example the start_manipulation command is sent 200 ms after
the fast diagnosis is started.


=back

=head2 Extras 
    



    #Set 'power-OFF'
    #Wait 4000 ms (Timer_ECU_Off)

    USE_LA_RECORD            = 'yes'
	
  #------------------------ STIMULATION AND MEASUREMENT ------------------------ 
    USE_CAN_RECORD          = 'yes'
    _CANSignal0             = 'CAN_Trigger_U8'
    _CANSignal1             = 'VSD_ESPReferenceVelocity'

    #Set 'power-ON'
    StartTime_ms            = 30000
    
    USE_SPECIFIC_TEST       = 'yes'
    _FieldCalib_Start       = %('Cranking' => 0, 'VehSpeed' => 3) 
    _ManipuDelayTime_ms     = 100
    _USE_MANIPULATION       = 'yes'
    
    USE_FDIAG_RECORD        = 'yes'
    _FastDiagVar0           = 'FD_Trigger_S8'
    _FastDiagVar1           = 'VehSpeed_U8'
    _FastDiagVar2           = 'rb_cs7m_Smi7OffsCalcSampleCntRT_au16(0)_U8'
    	
    USE_SPI_RECORD          = 'yes'
    _SPI_Node               = 'SMI7xx'
    
    USE_MANIPULATION        = 'yes'
    _ManipuDelayTime_ms     = 100
    _ManiToo_tcpar_S0       = '<Test Heading Head>_<Test Heading Middle>'
    
    USE_SPECIFIC_TEST       = 'yes'
    _FieldCalib_Running     = %('VehSpeed' => 4, 'Delay_ms' => 40) 
  
    MeasTime_ms             = 1500
  
  #Stop Fast Diagnosis
  #Get Fast Diagnosis trace dataref in hash format
  
  #Stop SPI Trace
  #Stop Logic Analzyer Trace
  
  _USE_VAR_RECORD			= @('rb_cs7o_Smi7FieldCalibration_st.Cnt_u8')
  
  #Read variables
  
  #Read Primary Fault Memory
  #Read Bosch Fault Memory
  
  #Stop CAN trace
  #Store CAN trace
  
  #Read 'ALL' Manipulation Counters
  
  #Send 'stop_manipulation' request to ManiToo
  
  #Store SPI Trace
  #Store Logic Analzyer Trace
  
      USE_SPECIFIC_TEST       = 'yes'
    _Specific_Test          = '0x8006'

    USE_MODIFY_BYTE         = 'yes'  (used to change the configuration)
    #Set 'power-ON'
    _MODIFY_BYTE0           = %('varName' => 'varName_FielCalibNotDone,
                                'andMask' => 'andMask_FielCalibNotDone',
                                'orMask'  => 'orMask_FielCalibNotDone',
                                'restore' => 'restore_FielCalibNotDone_no')
  
  #------------------------ TEST CASE EVALUATION ------------------------ 
    USE_FLTMEM_EVAL         = 'yes'
	_FLT_state              = %('rb_csem_FieldCalibMissing_flt' => '0bxxxx1110')
    _EventDebug_Data        = %('rb_csem_FieldCalibMissing_flt' => '0x0001')
	_FLTopt					= @('rb_csem_MonTempYawRateLfChl_flt')
    	
    USE_VAR_EVAL            = 'yes'
    _EvalVar0_Docu          = 'Check FieldCalib counter for calibration and verification tries'
    _EvalVar0               = @('rb_cs7o_Smi7FieldCalibration_st.Cnt_u8', '==', 0)
    
    USE_FDIAG_EVAL          = 'yes'
    _FD_GetTime_T1_Docu     = 'Get time when FD_Trigger_A occurs'
    _FD_GetTime_T1          = @('T0', 'FD_Trigger_S8',  '==', 'FD_Trigger_A')
    
    _FD_GetTime_T2_Docu     = 'Get time when VSD_ESPReferenceVelocity == 4'
    _FD_GetTime_T2          = @('T1', 'VehSpeed_U8',  '==', 32)
    
    _FD_GetTime_T3_Docu     = 'Get time when VSD_ESPReferenceVelocity '!=' 4'
    _FD_GetTime_T3          = @('T2', 'VehSpeed_U8',  '!=', 32)
    
    _FD_EvalTime0_T2_Docu   = 'Check duration for velocity '=' 4 km/s' 
    _FD_EvalTime0_T2        = @('T3', '>', 50, '<', 120)
    
    USE_CAN_EVAL            = 'yes'
    _CAN_GetTime_T1_Docu    = 'Get time when CAN_Trigger_A occurs'
    _CAN_GetTime_T1         = @('T0', 'CAN_Trigger_U8',  '==', 'CAN_Trigger_A')
    
    _CAN_GetTime_T2_Docu    = 'Get time when VSD_ESPReferenceVelocity == 4'
    _CAN_GetTime_T2         = @('T1', 'VSD_ESPReferenceVelocity',  '==', 4)
    
    _CAN_GetTime_T3_Docu    = 'Get time when VSD_ESPReferenceVelocity '!=' 4'
    _CAN_GetTime_T3         = @('T2', 'VSD_ESPReferenceVelocity',  '!=', 4)
    
    _CAN_EVALSignal0_T3_Docu  = 'Check Timing on CAN bus for VSD_ESPReferenceVelocity in a time interval of 100 ms '
    _CAN_EVALSignal0_T3       = @(105, 'VSD_ESPReferenceVelocity', '!=',  4, '>', 4) 
    
    USE_SPI_EVAL            = 'yes'
    _SPI_GetTime_T1_Docu    = 'Get time when Yaw Sensor error_group_out register is read'
    _SPI_GetTime_T1         = @('T0', 'SMI7xx::YawSensorCom::MOSI::ADR', '==', '0xF', 'SMI7xx::YawSensorCom::MISO::PAGE', '==', '0x2')
    
    _SPI_GetTime_T2_Docu    = 'Get time when Yaw Sensor error_group_out register is read'
    _SPI_GetTime_T2         = @('T1', 'SMI7xx::YawSensorCom::MOSI::ADR', '==', '0xF', 'SMI7xx::YawSensorCom::MISO::PAGE', '==', '0x2')
    
    _SPI_EvalTime0_T1_Docu  = 'Check timing for reading of Yaw Sensor error_group_out register'
    _SPI_EvalTime0_T1       = @('T2', '>=', 0.980, '<=', 1.020 )
    
    _SPI_EvalSignal0_T1_Docu  = 'Check minimum number for reading Roll Sensor error_group_out register within 100 ms'
    _SPI_EvalSignal0_T1       = @(100, 'SMI7xx::RollSensorCom::MOSI::ADR', '==', '0x0F', 'SMI7xx::YawSensorCom::MISO::PAGE',  '==', '0x2', '>', 198)
    
    _SPI_EvalSignal1_T1_Docu  = 'Check maximum number for reading Roll Sensor error_group_out register within 100 ms'
    _SPI_EvalSignal1_T1       = @(100, 'SMI7xx::RollSensorCom::MOSI::ADR', '==', '0x0F', 'SMI7xx::YawSensorCom::MISO::PAGE',  '==', '0x2', '<', 202)
 
    USE_MANIPUCNT_EVAL      = 'yes'
    _EvalManipuCnt0_Docu    = 'Check manipulation counter for Unit_0'
    _EvalManipuCnt0         = @('Unit_0', '>', '1997', '<', '2003')
    _EvalManipuCnt1_Docu    = 'Check manipulation counter for Unit_01'
    _EvalManipuCnt1         = @('Unit_1', '>', '1997', '<', '2203')
 
 
  #------------------------ TEST CASE FINALIZATION ------------------------
  
  #Restore configuration
  
  USE_FLTMEM_Clear 		= 'yes'
    #Clear Fault Memory
    #Wait 2000 ms
  
  #Set 'power-OFF'
  #S_wait_ms( $Timer_ECU_Off );

  
  #------------------------------------------------------------------------
  
  Operators: '=='  '!='  '>='  '<='  '<'  '>'  'MASK',  V_T1: value at time,  I_T1T2: time interval

=cut	

my $Current_TC_Repetition = 0;
my ( $Max_TC_Repetition, $Timer_ECU_Off, $Timer_ECU_Ready );

my ( $tcpar_USE_SPECIFIC_TEST, $tcpar_Specific_Test );

my ( %tcpar_FieldCalib_Start, %tcpar_FieldCalib_Running );
my ( $rawData_href, $decodedData_href, %tcpar_Check_Verification_Data, %tcpar_Request_Verification_Data );

my ( $tcpar_USE_MODIFY_BYTE, $tcpar_MODIFY_BYTE, %MODIFY_BYTE);

my ( $tcpar_InitTest, $tcpar_StartTime_ms, $tcpar_MeasTime_ms );

my ( $tcpar_USE_MANIPULATION, $tcpar_ManipuDelayTime_ms, @tcpar_ManiToo_Seq );
my ( $tcpar_USE_MANIPUCNT_EVAL, @tcpar_EvalManipuCnt, @tcpar_EvalManipuCntDocu, @manipuCnt );
my ( @EvalManipuCnt_Module, @EvalManipuCnt_Operator1, @EvalManipuCnt_ExpValue1, @EvalManipuCnt_Operator2, @EvalManipuCnt_ExpValue2 );

my ( $tcpar_USE_FLTMEM_RECORD, $tcpar_FLTMEM_Clear );
my ( $tcpar_USE_FLTMEM_EVAL, @tcpar_FLTmand, %tcpar_FLT_state, %tcpar_EventDebug_Data, $tcpar_FLTopt );
my ( $faultMemory_Primary_obj, $faultMemory_Bosch_obj );

my ( %tcpar_ERASE_flash );

my ( $tcpar_USE_VAR_WRITE, @tcpar_WriteVarDocu, @Write_Var_Label, @Write_Var_Value );
my ( $tcpar_USE_VAR_EVAL, @tcpar_EvalVarDocu, @tcpar_EvalVar, @Eval_Var_Label, @Eval_Var_Operator, @Eval_Var_Value );
my ( $tcpar_USE_VAR_RECORD, %Eval_Var_Label, $tcpar_RecordVar ); 

my ( $tcpar_USE_FDIAG_RECORD, @tcpar_FastDiagVar, $FD_data );
my ( $tcpar_USE_FDIAG_EVAL, $tcpar_FD_GetTime_href, $tcpar_FD_EvalTime_href, $tcpar_FD_EvalSignal_href, %FDiagLabel );

my ( $tcpar_USE_SPI_RECORD, @tcpar_SPI_Node, $SPI_tracefile_name, $tcpar_Leading_SPI_frames, $tcpar_Following_SPI_frames, $SPI_data );

my ( $tcpar_USE_SPI_EVAL, $tcpar_SPI_GetTime_href, $tcpar_SPI_EvalTime_href, $tcpar_SPI_EvalSignal_href );

my ( $tcpar_USE_CAN_RECORD, @tcpar_CANsignals, $CAN_data );
my ( $tcpar_USE_CAN_EVAL, $tcpar_CAN_GetTime_href,  $tcpar_CAN_EvalTime_href, $tcpar_CAN_EvalSignal_href, %CANLabel );

my ( $tcpar_USE_LA_RECORD, @tcpar_LA_Channels, $LA_data_href, $tcpar_Line_break_time, @Eval_SPI_Para_Label, @tcpar_Eval_SPI_Para );
my ( $min_time_cs_idle, $min_delay_cs_clk, $min_delay_clk_cs, $min_time_7_clks ); 

my ( $tcpar_SRT_Id, $tcNumber );

# maximum number of parameter
use constant READ_PARA_LOOP_MAX => 99;

# SMI specific tests
#-------------------
# SMI Verification
my $SMI_Verification        = 0x8001;
# SMI Field Calibration
my $SMI7_FieldCalib_Start   = 0x8002;
my $SMI7_FieldCalib_Running = 0x8004;

# Other specific tests
#---------------------
# NOR Flash Erase 
my $Enable_Flash_Erase  = 0x4001;
# SPI Parameter Test 
my $SPI_Parameter_Test	= 0x4002;

# -----------------------------------------------------------------------------------------------------
#                                     READ TEST CASE PARAMETER
# -----------------------------------------------------------------------------------------------------
sub TC_set_parameters {
	# -------------------------------------------------------------------------------------------------
	if ( not defined( $Max_TC_Repetition = $main::ProjectDefaults->{'TC_MANITOO_MAP'}->{'MAX_TC_REPETITION'} ) ) {
		$Max_TC_Repetition = 1;
	}
	
	if ( not defined( $Timer_ECU_Ready = $main::ProjectDefaults->{'TIMER'}->{'TIMER_ECU_READY'} ) ) {
		$Timer_ECU_Ready = 8000;
	}
	
	if ( not defined( $Timer_ECU_Off = $main::ProjectDefaults->{'TIMER'}->{'TIMER_ECU_OFF'} ) ) {
		$Timer_ECU_Off = 4000;
	}
	
	# -------------------------------------------------------------------------------------------------
	$tcpar_InitTest = S_read_optional_testcase_parameter('InitTest', 'byvalue', 'no');

	if ( $tcpar_InitTest eq 'yes' ) {
		$tcpar_StartTime_ms = S_read_optional_testcase_parameter('StartTime_ms', 'byvalue', 150);
		$tcpar_MeasTime_ms  = S_read_optional_testcase_parameter('MeasTime_ms', 'byvalue', $Timer_ECU_Ready);	
	}
	else {
		$tcpar_StartTime_ms = S_read_optional_testcase_parameter('StartTime_ms', 'byvalue', $Timer_ECU_Ready);
		$tcpar_MeasTime_ms  = S_read_optional_testcase_parameter('MeasTime_ms', 'byvalue', 2000);	
	}

	# -------------------------------------------------------------------------------------------------
	$tcpar_USE_MANIPULATION = S_read_optional_testcase_parameter('USE_MANIPULATION', 'byvalue', 'no');
	
	if ( $tcpar_USE_MANIPULATION eq 'yes' ) {
		@tcpar_ManiToo_Seq = ();
		$tcpar_ManipuDelayTime_ms = S_read_optional_testcase_parameter('_ManipuDelayTime_ms', 'byvalue', 200);
		
		foreach my $i ( 0 .. READ_PARA_LOOP_MAX ) {
			my $tcpar_ManiToo = S_read_testcase_parameter('_ManiToo_tcpar_S' . $i );
			if ($tcpar_ManiToo) {
				push( @tcpar_ManiToo_Seq, $tcpar_ManiToo );
			}
			else {
				last;
			}
		}
		
		$tcpar_USE_MANIPUCNT_EVAL = S_read_optional_testcase_parameter('USE_MANIPUCNT_EVAL', 'byvalue', 'no');
		if ( $tcpar_USE_MANIPUCNT_EVAL eq 'yes' ) {
			@EvalManipuCnt_Module = ();
			
			foreach my $i ( 0 .. READ_PARA_LOOP_MAX ) {
				@tcpar_EvalManipuCnt = S_read_testcase_parameter( '_EvalManipuCnt' . $i );
				if (@tcpar_EvalManipuCnt) {
						$tcpar_EvalManipuCntDocu[$i] = S_read_testcase_parameter( '_EvalManipuCnt' . $i . '_Docu' );
						$EvalManipuCnt_Module[$i] = $tcpar_EvalManipuCnt[0];
						$EvalManipuCnt_Operator1[$i] = $tcpar_EvalManipuCnt[1];
						$EvalManipuCnt_ExpValue1[$i] = $tcpar_EvalManipuCnt[2];
						$EvalManipuCnt_Operator2[$i] = $tcpar_EvalManipuCnt[3];
						$EvalManipuCnt_ExpValue2[$i] = $tcpar_EvalManipuCnt[4];
				}
				else {
					last;
				}
			}
		}
	}

	# -------------------------------------------------------------------------------------------------
	$tcpar_FLTMEM_Clear = 'no';
	$tcpar_USE_FLTMEM_RECORD  = S_read_optional_testcase_parameter('USE_FLTMEM_RECORD', 'byvalue', 'no');
	if ( $tcpar_USE_FLTMEM_RECORD eq 'yes' ) {
		$tcpar_FLTMEM_Clear = S_read_optional_testcase_parameter('_FLTMEM_Clear', 'byvalue', 'yes');
		
		$tcpar_USE_FLTMEM_EVAL = S_read_optional_testcase_parameter('USE_FLTMEM_EVAL', 'byvalue', 'no');
		if ( $tcpar_USE_FLTMEM_EVAL eq 'yes' ) {
			%tcpar_FLT_state = ();
			@tcpar_FLTmand   = ();
			%tcpar_EventDebug_Data = ();
	
			foreach my $i ( 0 .. READ_PARA_LOOP_MAX ) {
				my %read_FLT_state = S_read_testcase_parameter('_FLT_state' . $i);
			
				if (%read_FLT_state) {
					%tcpar_FLT_state = (%tcpar_FLT_state, %read_FLT_state);
				}
				else {
					last;
				}
			}
			
			foreach my $i ( 0 .. READ_PARA_LOOP_MAX ) {
				my %read_FLT_state = S_read_testcase_parameter('_EventDebug_Data' . $i);
			
				if (%read_FLT_state) {
					%tcpar_EventDebug_Data = (%tcpar_EventDebug_Data, %read_FLT_state);
				}
				else {
					last;
				}
			}
			
			while ( my ( $key, $data ) = each %tcpar_FLT_state ) {
				push( @tcpar_FLTmand, $key );
			}
			
			$tcpar_FLTopt = S_read_optional_testcase_parameter('_FLTopt', 'byref', []);
			
			$tcpar_USE_FLTMEM_RECORD = 'yes';
		}	
	}
		
	# -------------------------------------------------------------------------------------------------
	$tcpar_USE_VAR_WRITE  = S_read_optional_testcase_parameter('USE_VAR_WRITE', 'byvalue', 'no');

	if ( $tcpar_USE_VAR_WRITE eq 'yes' ) {
		@Write_Var_Label = ();
		@Write_Var_Value = ();

		foreach my $i ( 0 .. READ_PARA_LOOP_MAX ) {
			$tcpar_WriteVarDocu[$i] = S_read_testcase_parameter( '_WriteVar' . $i . '_Docu' );

			my %write_data = S_read_testcase_parameter('_WriteVar' . $i);			
			if (%write_data) {
				($Write_Var_Label[$i], $Write_Var_Value[$i]) = each %write_data;			
			}
			else {
				last;
			}
		}
	}

	# -------------------------------------------------------------------------------------------------
	$tcpar_USE_VAR_RECORD = S_read_optional_testcase_parameter('USE_VAR_RECORD', 'byvalue', 'no');
	
	if ( $tcpar_USE_VAR_RECORD eq 'yes' ) {
		%Eval_Var_Label = ();

		foreach my $i ( 0 .. READ_PARA_LOOP_MAX ) {
			$tcpar_RecordVar = S_read_testcase_parameter( '_RecordVar' . $i );
			if ($tcpar_RecordVar) {
				if ( defined( my $newkey = $main::ProjectDefaults->{'TC_MANITOO_MAP'}->{ $tcpar_RecordVar } ) ) {
					$Eval_Var_Label{$newkey} = 1;
				}
				else {
					$Eval_Var_Label{$tcpar_RecordVar} = 1;
				}	
			}
			else {
				last;
			}
		}
	}
	
	$tcpar_USE_VAR_EVAL   = S_read_optional_testcase_parameter('USE_VAR_EVAL', 'byvalue', 'no');

	if ( $tcpar_USE_VAR_EVAL eq 'yes' ) {
		@tcpar_EvalVar  = ();
		@Eval_Var_Label = ();
		@Eval_Var_Value = ();

		foreach my $i ( 0 .. READ_PARA_LOOP_MAX ) {
			$tcpar_EvalVarDocu[$i] = S_read_testcase_parameter( '_EvalVar' . $i . '_Docu' );
			@tcpar_EvalVar = S_read_testcase_parameter( '_EvalVar' . $i );
			if (@tcpar_EvalVar) {
				if ( defined( my $newkey = $main::ProjectDefaults->{'TC_MANITOO_MAP'}->{ $tcpar_EvalVar[0] } ) ) {
					$Eval_Var_Label[$i] = $newkey;
					$Eval_Var_Label{$newkey} = 1;
				}
				else {
					$Eval_Var_Label[$i] = $tcpar_EvalVar[0];
					$Eval_Var_Label{$tcpar_EvalVar[0]} = 1;
				}
	
				$Eval_Var_Operator[$i] = $tcpar_EvalVar[1];
	
				if ( defined( my $data = $main::ProjectDefaults->{'TC_MANITOO_MAP'}->{ $tcpar_EvalVar[2] } ) ) {
					$Eval_Var_Value[$i] = $data;
				}
				else {
					$Eval_Var_Value[$i] = $tcpar_EvalVar[2];
				}
			}
			else {
				last;
			}			
		}
	}
	
	# -------------------------------------------------------------------------------------------------
	$tcpar_USE_FDIAG_RECORD = S_read_optional_testcase_parameter('USE_FDIAG_RECORD', 'byvalue', 'no');
	@tcpar_FastDiagVar      = ();
	
	if ( $tcpar_USE_FDIAG_RECORD eq 'yes' ) {
		foreach my $i ( 0 .. READ_PARA_LOOP_MAX ) {
			my $expected_var = S_read_testcase_parameter( '_FastDiagVar' . $i );
			if ($expected_var) {
				push( @tcpar_FastDiagVar, $expected_var );
			}
			else {
				last;
			}
		}
	
		$tcpar_USE_FDIAG_EVAL   = S_read_optional_testcase_parameter('USE_FDIAG_EVAL', 'byvalue', 'no');	
		if ( $tcpar_USE_FDIAG_EVAL eq 'yes' ) {
			($tcpar_FD_GetTime_href, $tcpar_FD_EvalTime_href, $tcpar_FD_EvalSignal_href) = GEN_get_trace_eval_params('FD');
			#debug
			#print Dumper($tcpar_FD_GetTime_href);
			#print Dumper($tcpar_FD_EvalTime_href);
			#print Dumper($tcpar_FD_EvalSignal_href);
		}
	}

	# -------------------------------------------------------------------------------------------------
	$tcpar_USE_CAN_RECORD = S_read_optional_testcase_parameter('USE_CAN_RECORD', 'byvalue', 'no');
	
	if ( $tcpar_USE_CAN_RECORD eq 'yes' ) {
		@tcpar_CANsignals = ();
		
		foreach my $i ( 0 .. READ_PARA_LOOP_MAX ) {
			my $CANSignal = S_read_testcase_parameter( '_CANSignal' . $i );
			if ($CANSignal) {
				push( @tcpar_CANsignals, $CANSignal );
			}
			else {
				last;
			}
		}
	
		$tcpar_USE_CAN_EVAL = S_read_optional_testcase_parameter('USE_CAN_EVAL', 'byvalue', 'no');
		if ( $tcpar_USE_CAN_EVAL eq 'yes' ) {
		($tcpar_CAN_GetTime_href, $tcpar_CAN_EvalTime_href, $tcpar_CAN_EvalSignal_href) = GEN_get_trace_eval_params('CAN');
			#debug
			#print Dumper($tcpar_CAN_GetTime_href);
			#print Dumper($tcpar_CAN_EvalTime_href);
			#print Dumper($tcpar_CAN_EvalSignal_href);
		}
	}

	# -------------------------------------------------------------------------------------------------
	$tcpar_USE_SPI_RECORD = S_read_optional_testcase_parameter('USE_SPI_RECORD', 'byvalue', 'no');

	if ( $tcpar_USE_SPI_RECORD eq 'yes' ) {
		@tcpar_SPI_Node = S_read_mandatory_testcase_parameter('_SPI_Node', 'byvalue');
		$tcpar_Leading_SPI_frames = S_read_optional_testcase_parameter('_Leading_SPI_frames', 'byvalue', 10);
		$tcpar_Following_SPI_frames = S_read_optional_testcase_parameter('_Following_SPI_frames', 'byvalue', 10);
		
		$tcpar_USE_SPI_EVAL   = S_read_optional_testcase_parameter('USE_SPI_EVAL', 'byvalue', 'no');
		if ( $tcpar_USE_SPI_EVAL eq 'yes' ) {
		($tcpar_SPI_GetTime_href, $tcpar_SPI_EvalTime_href, $tcpar_SPI_EvalSignal_href) = GEN_get_trace_eval_params('SPI');
			#debug
			#print Dumper($tcpar_SPI_GetTime_href);
			#print Dumper($tcpar_SPI_EvalTime_href);
			#print Dumper($tcpar_SPI_EvalSignal_href);
		}
	}

	# -------------------------------------------------------------------------------------------------
	$tcpar_USE_LA_RECORD = S_read_optional_testcase_parameter('USE_LA_RECORD', 'byvalue', 'no');		

	@tcpar_LA_Channels = ();
	if ( $tcpar_USE_LA_RECORD eq 'yes' ) {	
		@tcpar_LA_Channels = S_read_testcase_parameter('_LA_Channels');
		$tcpar_Line_break_time = S_read_optional_testcase_parameter('_Line_break_time', 'byvalue', '0.0019');
	}

	# -------------------------------------------------------------------------------------------------
	$tcpar_USE_MODIFY_BYTE = S_read_optional_testcase_parameter('USE_MODIFY_BYTE', 'byvalue', 'no');
	%MODIFY_BYTE = ();
	
	if ( $tcpar_USE_MODIFY_BYTE eq 'yes' ) {
		foreach my $i ( 0 .. READ_PARA_LOOP_MAX ) {
			$tcpar_MODIFY_BYTE = S_read_testcase_parameter( '_MODIFY_BYTE' . $i , 'byref');
			if ( $tcpar_MODIFY_BYTE ) {
				$MODIFY_BYTE{'Byte' . $i} = $tcpar_MODIFY_BYTE;
				
				if ( defined( my $data = $main::ProjectDefaults->{'TC_MANITOO_MAP'}{$MODIFY_BYTE{'Byte' . $i}{varName}} ) ) {
					$MODIFY_BYTE{'Byte' . $i}{varName} = $data;
					S_w2log( 3, "varName => $data", "grey" );
				}
				if ( defined( my $data = $main::ProjectDefaults->{'TC_MANITOO_MAP'}{$MODIFY_BYTE{'Byte' . $i}{andMask}} ) ) {
					$MODIFY_BYTE{'Byte' . $i}{andMask} = $data;
					S_w2log( 3, "andMask => $data", "grey" );
				}
				if ( defined( my $data = $main::ProjectDefaults->{'TC_MANITOO_MAP'}{$MODIFY_BYTE{'Byte' . $i}{orMask}} ) ) {
					$MODIFY_BYTE{'Byte' . $i}{orMask} = $data;
					S_w2log( 3, "orMask => $data", "grey" );
				}             
				if ( defined( my $data = $main::ProjectDefaults->{'TC_MANITOO_MAP'}{$MODIFY_BYTE{'Byte' . $i}{restore}} ) ) {
					$MODIFY_BYTE{'Byte' . $i}{restore} = $data;
					S_w2log( 3, "restore => $data", "grey" );
				}             
			}
			else {
				last;
			}
		}
		
		#debug
		#print Dumper(\%MODIFY_BYTE);
	}
    	
	# -------------------------------------------------------------------------------------------------
	$tcpar_USE_SPECIFIC_TEST = S_read_optional_testcase_parameter('USE_SPECIFIC_TEST', 'byvalue', 'no');

	if ( $tcpar_USE_SPECIFIC_TEST eq 'yes' ) {
		$tcpar_Specific_Test = S_0x2dec( S_read_optional_testcase_parameter('_Specific_Test', 'byvalue', '0x0000') );
	
		if ( ($tcpar_Specific_Test & $SMI7_FieldCalib_Start) == $SMI7_FieldCalib_Start ) {
			%tcpar_FieldCalib_Start = ();
			%tcpar_FieldCalib_Start = S_read_testcase_parameter('_FieldCalib_Start');
		}
		
		if ( ($tcpar_Specific_Test & $SMI7_FieldCalib_Running) == $SMI7_FieldCalib_Running ) {
			%tcpar_FieldCalib_Running = ();
			%tcpar_FieldCalib_Running = S_read_testcase_parameter('_FieldCalib_Running');
		}

	# -------------------------------------------------------------------------------------------------
		if ( ($tcpar_Specific_Test & $SMI_Verification) == $SMI_Verification ) {
			%tcpar_Check_Verification_Data = ();
			%tcpar_Request_Verification_Data = ();
		
			foreach my $i ( 0 .. READ_PARA_LOOP_MAX ) {
				my %Request_Verification_Data = S_read_testcase_parameter('_Request_Verification_Data' . $i);
			
				if (%Request_Verification_Data) {
					%tcpar_Request_Verification_Data = (%tcpar_Request_Verification_Data, %Request_Verification_Data);
				}
				else {
					last;
				}
			}

			foreach my $i ( 0 .. READ_PARA_LOOP_MAX ) {
				my %Check_Verification_Data = S_read_testcase_parameter('_Check_Verification_Data' . $i);
			
				if (%Check_Verification_Data) {
					%tcpar_Check_Verification_Data = (%tcpar_Check_Verification_Data, %Check_Verification_Data);
				}
				else {
					last;
				}
			}						
		}
		
	# -------------------------------------------------------------------------------------------------
		if ( ($tcpar_Specific_Test & $Enable_Flash_Erase) == $Enable_Flash_Erase ) {
			%tcpar_ERASE_flash = ();
			%tcpar_ERASE_flash = S_read_testcase_parameter('_ERASE_flash');
		}
	
	# -------------------------------------------------------------------------------------------------
		if ( ($tcpar_Specific_Test & $SPI_Parameter_Test) == $SPI_Parameter_Test ) {
			@Eval_SPI_Para_Label = ();
			@tcpar_Eval_SPI_Para = ();
			
			$tcpar_Eval_SPI_Para[0] = S_read_optional_testcase_parameter('_min_time_7_clks', 'byvalue', '665e-9');
			$tcpar_Eval_SPI_Para[1] = S_read_optional_testcase_parameter('_min_delay_cs_clk', 'byvalue', '95e-9');
			$tcpar_Eval_SPI_Para[2] = S_read_optional_testcase_parameter('_min_delay_clk_cs', 'byvalue', '95e-9');
			$tcpar_Eval_SPI_Para[3] = S_read_optional_testcase_parameter('_min_time_cs_idle', 'byvalue', '200e-9');
			
			$Eval_SPI_Para_Label[0] = 'min_time_7_clks';
			$Eval_SPI_Para_Label[1] = 'min_delay_cs_clk';
			$Eval_SPI_Para_Label[2] = 'min_delay_clk_cs';
			$Eval_SPI_Para_Label[3] = 'min_time_cs_idle';			
		}
	}

	# -------------------------------------------------------------------------------------------------
	# Show test case ID in report
	$tcpar_SRT_Id = S_read_testcase_parameter('SRT_ID');
	# Get test case number
	$tcNumber = S_get_TC_number();

	return 1;
}

#******************************************************************************************************
#                                      TEST CASE INITIALIZATION                                       *
#******************************************************************************************************
sub TC_initialization {
	# ************************** Change ECU configuration **********************************************
    if ( $tcpar_USE_MODIFY_BYTE ne 'no' ) {
		S_teststep( "--- Change configuration ---", 'AUTO_NBR' );

		S_teststep_2nd_level( "Set 'power-ON'", 'AUTO_NBR' );
		LC_ECU_On();

		S_teststep_2nd_level( "Wait 500 ms", 'AUTO_NBR' );
		S_wait_ms(500);

		my $byte_aref;
        my $byte_value;
        my @keys = sort { $a cmp $b } keys %MODIFY_BYTE;

        foreach my $key ( @keys ) {
            $byte_aref = PRD_Read_Memory("$MODIFY_BYTE{$key}{varName}");
            $byte_value = $$byte_aref[0];
		
            # save original byte_value, in order to restore a the end of the test
            $MODIFY_BYTE{$key}{origValue} = $byte_value;

            $byte_value = $byte_value & S_0x2dec($MODIFY_BYTE{$key}{andMask});
            $byte_value = $byte_value | S_0x2dec($MODIFY_BYTE{$key}{orMask});

            $MODIFY_BYTE{$key}{changedValue} = $byte_value;
            
            $$byte_aref[0] = $byte_value;
            
			S_teststep_2nd_level( "$MODIFY_BYTE{$key}{varName} = $byte_value", 'AUTO_NBR' );
            PRD_Write_Memory( "$MODIFY_BYTE{$key}{varName}", $byte_aref);
	
			S_teststep_2nd_level( "Wait 500 ms", 'AUTO_NBR' );
            S_wait_ms(500);            
        }
       
        #debug
	    #print Dumper(\%MODIFY_BYTE);
				
		S_teststep_2nd_level( "Set 'power-OFF'", 'AUTO_NBR' );
		LC_ECU_Off();
		
		S_teststep_2nd_level( "Wait $Timer_ECU_Off ms (Timer_ECU_Off)", 'AUTO_NBR' );
		S_wait_ms( $Timer_ECU_Off );
    }
    
	# ********************************** NOR Flash erase **********************************************
	if ( ($tcpar_Specific_Test & $Enable_Flash_Erase ) == $Enable_Flash_Erase ) {
		_NOR_Flash_Erase();	
	}
		
	# ************************** Load SPI manipulation data to ManiToo *********************************
	if ( $tcpar_USE_MANIPULATION ne 'no' ) {
		if ( defined (my $key = $LIFT_PROJECT::Defaults->{'MANITOO_TEMP'}{'SERVICES'}{'enable_SMI_page_detection'}) ){
			S_teststep( "Enable SMI page detection", 'AUTO_NBR' );
			MANITOO_RUN_SERVICE('enable_SMI_page_detection');
			S_w2rep("SMI page detection enabled \n");
		}
		S_teststep( "Load SPI manipulation data to ManiToo", 'AUTO_NBR' );		
		my $i = 0;
		foreach (@tcpar_ManiToo_Seq) { 			  
			MANITOO_RUN_TEST_SEQUENCE($tcpar_ManiToo_Seq[$i]);
			$i++;
		}
		S_w2rep("SPI manipulation data loaded to ManiToo \n");

		S_teststep_2nd_level( "--- Write manipulation data to FPGA registers ----", 'AUTO_NBR' );
		MANITOO_RUN_SERVICE('copy_data_to_PL');
		S_w2rep("Manipulation data written to FPGA registers \n");
	}

	return 1;
}

#******************************************************************************************************
#                                   STIMULATION AND MEASUREMENT                                       *
#******************************************************************************************************
sub TC_stimulation_and_measurement {
	my ( @FDlabel, @FDformat);
	my $FD_trace_DIR = $main::REPORT_PATH . "/" . $tcNumber . "_FD_trace_" . $Current_TC_Repetition . "/";
	%FDiagLabel = ();
	%CANLabel = ();
	
#	# ************************** Start CAN-recording before power-ON **********************************
	if ( $tcpar_USE_CAN_RECORD ne 'no' ) {
		S_teststep( "Start CANoe Restbus Simulation", 'AUTO_NBR' );
		CA_simulation_start();
		S_w2rep("CANoe restbus simulation started \n");		

		
		if ( $tcpar_InitTest ne 'no' ) {
			S_teststep_2nd_level( "Start CAN trace", 'AUTO_NBR' );
			CA_trace_start();
			S_w2rep("CAN trace started \n");		
		}
	}

	# ************************** Start Logic Analzyer recording ****************************************
	if ( $tcpar_USE_LA_RECORD ne 'no' ) {
		S_teststep( "Start Acute Logic Analzyer Record", 'AUTO_NBR' );
		return unless SPI_logicanalyzer_start();
		S_w2rep("Acute Logic Analzyer Record started \n");		
	}

	# ************************** Start SPI-manipulation before power-ON *******************************
	if ( $tcpar_InitTest ne 'no' ) {
		if ( $tcpar_USE_MANIPULATION ne 'no' ) {
			S_teststep( "Send 'start_manipulation' request to ManiToo", 'AUTO_NBR' );
			S_w2rep("Send 'start_manipulation' request to ManiToo \n");
			MANITOO_RUN_SERVICE('start_manipulation');
		}	
	}

	# ************************** Power-ON ECU *********************************************************
	S_teststep( "Power-ON ECU", 'AUTO_NBR' );
    LC_ECU_On();
	S_w2rep("ECU Powered ON \n");				
	
	if ( $tcpar_InitTest ne 'no' ) {
		if ( $tcpar_USE_SPI_RECORD ne 'no' ) {
			S_teststep( "Start SPI recording", 'AUTO_NBR' );
			return unless SPI_trace_start( [@tcpar_SPI_Node] );
			S_w2rep("SPI recording started \n");				
		}				
	}
	
	# ************************** Wait for start of measurement ****************************************
	S_teststep_2nd_level( "Wait $tcpar_StartTime_ms ms (StartTime_ms)", 'AUTO_NBR' );
	S_wait_ms($tcpar_StartTime_ms);
	S_w2rep("Waitung time of $tcpar_StartTime_ms ms expired \n");				
		
	# ****************************** Write Memory by Name***********************************************
	if ( $tcpar_USE_VAR_WRITE ne 'no' ) {
		S_teststep( "--- Write Memory by Name ---", 'AUTO_NBR' );
		foreach my $i ( 0 .. $#Write_Var_Label ) {
			S_teststep_2nd_level( "$tcpar_WriteVarDocu[$i] \n $Write_Var_Label[$i] => $Write_Var_Value[$i]", 'AUTO_NBR', "WriteVar$i" );
			PRD_Write_Memory( $Write_Var_Label[$i], $Write_Var_Value[$i] );
		}
		S_w2rep("Writing Memory by Name executed \n");				
	}
	
	# ************************** Start specific tests *********************************************
	if ( $tcpar_USE_SPECIFIC_TEST ne 'no' ) {
		if ( ($tcpar_Specific_Test & $SMI7_FieldCalib_Start) == $SMI7_FieldCalib_Start ) {
			_SMI7_FieldCalib_Start();			
		}		
    }

	# ******************************** Start CAN-recording  *******************************************
	if ( $tcpar_USE_CAN_RECORD ne 'no' ) {
		if ( $tcpar_InitTest ne 'yes' ) {
			S_teststep( "Start CAN trace", 'AUTO_NBR' );
			CA_trace_start();
			S_w2rep("CAN trace started \n");				
		}
	}

	# ************************** Start Fast Diagnosis *************************************************
	if ( $tcpar_USE_FDIAG_RECORD ne 'no' ) {
		my $data;
		my $fdIndex = 0;
		my $numCanIDs = 1;
		my @fastDiagLabels;

		foreach my $key_fast_diag (@tcpar_FastDiagVar) {
			if ( not defined( $data = $main::ProjectDefaults->{'TC_MANITOO_MAP'}{$key_fast_diag} ) ) {
				$data = $key_fast_diag;
			}

			# extract  FDlabel and  FDformat
			$data =~ /(.+)_(\w+)$/;
			$FDlabel[$fdIndex]  = $1;
			$FDformat[$fdIndex] = $2;
			$fastDiagLabels[$fdIndex] = "$1;$2";

			$FDiagLabel{$key_fast_diag} = $FDlabel[$fdIndex];
			$fdIndex++;
		}

		my ( $key1, $data1 );
		while ( ( $key1, $data1 ) = each %FDiagLabel ) {
			if ($key1 ne $data1) {
				S_w2log( 3, " $key1 => $data1 \n", "grey" );
			}
		}

		S_teststep( "Start Fast Diagnosis", 'AUTO_NBR' );
		PRD_Start_Fast_Diagnosis( {csv_data_file_path  => $FD_trace_DIR, labels => \@fastDiagLabels , number_of_BUS_Ids => $numCanIDs } );
		S_w2rep("Fast Diagnosis started \n");				
	}
		
	if ( $tcpar_InitTest ne 'yes' ) {
		if ( $tcpar_USE_SPI_RECORD ne 'no' ) {
			S_teststep( "Start SPI recording", 'AUTO_NBR' );
			return unless SPI_trace_start( [@tcpar_SPI_Node] );
			S_w2rep("SPI recording started \n");				
		}

		if ( $tcpar_USE_MANIPULATION ne 'no' ) {	
			S_teststep( "Wait $tcpar_ManipuDelayTime_ms ms (ManipuDelayTime_ms)", 'AUTO_NBR' );
			S_wait_ms($tcpar_ManipuDelayTime_ms);
			S_w2rep("Waiting time of $tcpar_ManipuDelayTime_ms ms expired (ManipuDelayTime_ms) \n");				
			
			S_teststep_2nd_level( "Send 'start_manipulation' request to ManiToo", 'AUTO_NBR' );
			MANITOO_RUN_SERVICE('start_manipulation');
			S_w2rep("Manipulation started \n");				
		}
	}
	
	# ************************** Start SMI specific tests *********************************************
	if ( $tcpar_USE_SPECIFIC_TEST ne 'no' ) {
		if ( ($tcpar_Specific_Test & $SMI7_FieldCalib_Running) == $SMI7_FieldCalib_Running ) {
			_SMI7_FieldCalib_Running();
		}

		if ( ($tcpar_Specific_Test & $SMI_Verification) == $SMI_Verification ) {
			$rawData_href = PRD_Sensor_Verification( {%tcpar_Request_Verification_Data} );
			$decodedData_href = VDS_ExtractSMIDataFromPD( $rawData_href->{response_href}{CompletePdMsg}, $tcpar_Request_Verification_Data{sensor_type} );
			#debug_SMI_Verification
			#my $report_name = $main::TC_REPORT_NAME;
			#open( FILE, ">", $main::REPORT_PATH . "/" . $report_name . "_Data" . ".txt" );
			#print( FILE Dumper( $decodedData_href ) );
			#close( FILE );
		}		
	}

	# ************************** Wait for end of measurement ******************************************
	S_teststep( "Wait $tcpar_MeasTime_ms ms (MeasTime_ms)", 'AUTO_NBR' );
	S_wait_ms( $tcpar_MeasTime_ms );	
	S_w2rep("Waiting time of $tcpar_MeasTime_ms ms experid (MeasTime_ms) \n");				

	# ******************************** Stop CAN trace *********************************************
	if ( $tcpar_USE_CAN_RECORD ne 'no' ) {
		S_teststep( "Stop CAN trace", 'AUTO_NBR' );
		CA_trace_stop();
		S_w2rep("CAN trace stoped \n");				
	}
	
	# ************************** Stop Fast Diagnosis and store Trace **********************************
	if ( $tcpar_USE_FDIAG_RECORD ne 'no' ) {
		S_teststep( "Stop Fast Diagnosis", 'AUTO_NBR' );
		PRD_Stop_Fast_Diagnosis();
		S_w2rep( "Fast Diagnosis stoped \n" );
		
		S_teststep_2nd_level( "--- Store Fast Diagnosis Trace ---", 'AUTO_NBR' );
		$FD_data = PRD_Get_Fast_Diagnosis_Data_NOERROR( {data_path => $FD_trace_DIR} );
		S_w2rep( "Fast Diagnosis Trace stored : $FD_trace_DIR \n" );
		
        my $date_extension = '_' . S_get_date_extension() . '_' . $Current_TC_Repetition;
		my $FD_trace = $main::TC_REPORT_NAME;
        $FD_trace =~ s/\.html/$date_extension/i;
		
		EVAL_createGraphFromMeasurement($FD_data, $FD_trace, {y => \@FDlabel}, undef, 1);
				 
		#debug_FD
		#open( FILE, ">", $main::REPORT_PATH . "/" . $FD_trace . ".txt" );
		#print( FILE Dumper( $FD_data ) );
		#close( FILE );
	}
	
	# ************************** Stop SPI recording ***************************************************
	if ( $tcpar_USE_SPI_RECORD ne 'no' ) {
		S_teststep( "Stop SPI recording", 'AUTO_NBR' );
		my $orig_trace_size = SPI_trace_stop();
		S_w2rep( "Trace stopped with captured " . int ( $orig_trace_size / 1000 ) . " kBytes \n" );
	}			

	# ************************** Stop Logic Analzyer recording ****************************************
	if ( $tcpar_USE_LA_RECORD ne 'no' ) {
		S_teststep( "Stop Logic Analzyer recording", 'AUTO_NBR' );
		SPI_logicanalyzer_stop(); 
		S_w2rep("Logic Analzyer recording stoped \n");				
	}
	
	# ****************************** Read Memory by Name***********************************************
	if ( ( $tcpar_USE_VAR_RECORD ne 'no' ) or ( $tcpar_USE_VAR_EVAL ne 'no' ) ) {
		S_teststep( "--- Read Memory by Name ---", 'AUTO_NBR' );

		foreach my $key (keys %Eval_Var_Label) {
		    my $value = S_aref2hex( PRD_Read_Memory( $key ) );
			$Eval_Var_Label{$key} = $value;		
			S_teststep_2nd_level( "$key = $value", 'AUTO_NBR', "$key" );
		}
		S_w2rep("Read Memory by Name executed \n");				
	}

	# ****************************** Read Fault Memory ***********************************************
	if ( $tcpar_USE_FLTMEM_RECORD ne 'no' ) {
		S_teststep( "--- Read Primary Fault Memory ---", 'AUTO_NBR' );
		$faultMemory_Primary_obj = LIFT_FaultMemory -> read_fault_memory('Primary');
		S_w2rep("Read Primary Fault Memory executed \n");				
		
		S_teststep_2nd_level( "--- Read Bosch Fault Memory ---", 'AUTO_NBR' );
		$faultMemory_Bosch_obj = LIFT_FaultMemory -> read_fault_memory('Bosch');
		S_w2rep("Read Bosch Fault Memory executed \n");				
	}

	# *********************************** Store CAN trace ********************************************
	if ( $tcpar_USE_CAN_RECORD ne 'no' ) {
		my $fh;
		my $CAN_trace    = $main::REPORT_PATH . "/" . $tcNumber . "_CAN_trace_" . $Current_TC_Repetition . ".asc";
 		my $CAN_trace_ms = $main::REPORT_PATH . "/" . $tcNumber . "_CAN_trace_ms_" .  $Current_TC_Repetition . ".asc";
		my $pattern = "[0-9]+\.[0-9]{6}"; # match floating point number 

		S_teststep_2nd_level( "Stop CAN bus simulation", 'AUTO_NBR' );
		CA_simulation_stop();
		S_w2rep( "CAN bus simulation stoped \n" );

		S_teststep_2nd_level( "--- Store original CAN trace ---", 'AUTO_NBR' );
		CA_trace_store( $CAN_trace ); # Remark :also stops trace and residual bus simulation!!
		S_w2rep( "Original CAN trace stored: $CAN_trace \n" );

		S_teststep_2nd_level( "Start CAN bus simulation", 'AUTO_NBR' );
		CA_simulation_start();		
		S_w2rep( "CAN bus simulation started \n" );
		
		S_teststep_2nd_level( "--- Store CAN trace with ms time stamp ---", 'AUTO_NBR' );
		CA_trace_store( $CAN_trace ); # Remark :also stops trace and residual bus simulation!!
		S_w2rep( "Stored CAN trace with ms time stamp : $CAN_trace_ms \n" );

		open $fh, '<', $CAN_trace;		
		# read recorded original CAN_trace.asc trace into array
		my @lines = <$fh>;
		close $fh;
				
		open $fh, '>', $CAN_trace_ms;
		foreach my $line (@lines) {
		    $line =~ m/($pattern)/;
			my $time_ms = $1 * 1000;
		    $line =~ s/$pattern/$time_ms/;
			# store original CAN_trace.asc with timestamps in seconds to CAN_trace_ms.asc with timestamps in milliseconds
			# Reason: use the same timing (ms) for Fast Diagnosis, SPI and CAN evaluation 
			print( $fh $line );
		}
		close( $fh );

		my @map_CANsignals;
		my $canIndex;
		my $data;
		
		foreach my $key_can_sig (@tcpar_CANsignals) {
			if ( not defined( $data = $main::ProjectDefaults->{'TC_MANITOO_MAP'}{$key_can_sig} ) ) {
				$data = $key_can_sig;
			}
			push( @map_CANsignals, $data );
			$CANLabel{$key_can_sig} = $map_CANsignals[$canIndex];
			$canIndex++;
		}

		my ( $key1, $data1 );
		while ( ( $key1, $data1 ) = each %CANLabel ) {
			if ($key1 ne $data1) {
				S_w2log( 3, " $key1 => $data1 \n", "grey" );
			}
		}
		
		return 1 if ($main::opt_offline);

		S_teststep_2nd_level( "Get CAN trace data", 'AUTO_NBR' );
		$CAN_data = CA_trace_get_dataref($CAN_trace_ms, \@map_CANsignals);
		S_w2rep("CAN data read: @map_CANsignals \n");				

		#[Work Item 1025542]  New:  EVAL_createGraphFromMeasurement: merge signals and times if several y-signal are provided with different number of signal values and/or time values [s]
		#EVAL_createGraphFromMeasurement( $CAN_data, $tcNumber . '_CAN_data_' . $Current_TC_Repetition, {'y' => \@map_CANsignals}, undef, 3 );	

		foreach my $canSignal (@map_CANsignals) {
			EVAL_createGraphFromMeasurement( $CAN_data, $tcNumber . '_CAN_data_' . $Current_TC_Repetition . "_" . $canSignal, {'y' => [$canSignal]}, undef, 3 );	
		} 

		#debug_CAN
		#open( FILE, ">", $main::REPORT_PATH . "/" . $tcNumber . "_CAN_trace_" . $Current_TC_Repetition . ".txt" );
		#print( FILE Dumper( $CAN_data ) );
		#close( FILE );
	}

	# ************************** Read manipulation counters and Stop manipulation *********************
	if ( $tcpar_USE_MANIPULATION ne 'no' ) {
		S_teststep( "--- Read Manipulation Counters ---", 'AUTO_NBR' );
		my ($status, $response_hex_aref, $manipulation_counter_aref);
        ($status, $response_hex_aref, $manipulation_counter_aref) = MANITOO_cmd_ReadManipulationCounter( 'ALL' );
        return unless $status;
		
		my $manip_module_index = 0;
        foreach( @$manipulation_counter_aref) {
           $manipuCnt[$manip_module_index] = $manipulation_counter_aref->[$manip_module_index];
            $manip_module_index++;
        }
		S_w2log( 3, "Manipulation counters: @manipuCnt", "green" );
		S_w2rep("Manipulation counters read \n");				
	
		S_teststep_2nd_level( "Send 'stop_manipulation' request to ManiToo", 'AUTO_NBR' );
		MANITOO_RUN_SERVICE('stop_manipulation');		
		S_w2rep("Manipulation stoped \n");				
	}

	# ************************** Store SPI Trace ******************************************************
    if ( $tcpar_USE_SPI_RECORD ne 'no' ) {
        my $date_extension = '_' . S_get_date_extension() . '_' . $Current_TC_Repetition;
        my $tc_name = $main::TC_REPORT_NAME;
        $tc_name =~ s/\.html/$date_extension.mbt/i;
        $SPI_tracefile_name = $main::REPORT_PATH . '/' . $tc_name;

		S_teststep( "--- Store SPI Trace ---", 'AUTO_NBR' );
		SPI_trace_store( $SPI_tracefile_name, $tcpar_Leading_SPI_frames, $tcpar_Following_SPI_frames );
		S_w2rep( "SPI Trace File stored : $SPI_tracefile_name \n" );
	}

	# ************************** Store Logic Analyzer Trace *******************************************
	if ( $tcpar_USE_LA_RECORD ne 'no' ) {
		S_teststep( "--- Store Logic Analyzer Trace ---", 'AUTO_NBR' );
		my $stored_LA_dump_file_name = SPI_logicanalyzer_store( );
		S_w2rep( "Logic Analyzer file stored : $stored_LA_dump_file_name \n" );

		if ( defined(@tcpar_LA_Channels) ) {
			my $data_href = {};
			S_teststep_2nd_level( "Get @tcpar_LA_Channels channels from Acute Logic Analyzer", 'AUTO_NBR' );
			my $success = LATL_get_values( \@tcpar_LA_Channels, 2, 2, $data_href );
			if ( $success != 0 ) {
				$LA_data_href = $data_href;
				S_w2rep( "Acute Logic Analyzer channel data stored \n" );
			}
			_SPI_Parameter_Extract();
		}
	}	
	
	return 1;
}

#******************************************************************************************************
#                                        TEST CASE EVALUATION                                         *
#******************************************************************************************************
sub TC_evaluation {
	# ****************************** Evaluate Fault Memorys *******************************************
	if ( ($tcpar_USE_FLTMEM_RECORD ne 'no') and ($tcpar_USE_FLTMEM_EVAL ne 'no') ) {
		$faultMemory_Primary_obj -> evaluate_faults( {mandatory => \@tcpar_FLTmand, optional => $tcpar_FLTopt} );
		
		S_teststep( "--- Evaluate Fault Memory ---", 'AUTO_NBR' );
		if ( %tcpar_FLT_state ) {
			foreach my $key_fault_name ( keys %tcpar_FLT_state ) {
				if ( $faultMemory_Primary_obj -> check_fault_presence ($key_fault_name) ) {
		
					# check Fault Status
					my $FLT_state_expected = $tcpar_FLT_state{$key_fault_name};
					my $FLT_state_detected = $faultMemory_Primary_obj -> get_fault_attribute({FaultName => $key_fault_name, Attribute => 'RawStatus'});
					
					my $FLT_state_detected_8bits = substr((S_dec2bin(S_hex2dec($FLT_state_detected))), -8);				
					
					EVAL_evaluate_value( $key_fault_name, $FLT_state_detected, 'MASK', $FLT_state_expected );

					S_teststep_2nd_level( "Evaluate Fault Status for $key_fault_name", 'AUTO_NBR', "FLT_state_$key_fault_name" );
					S_teststep_expected( "$FLT_state_expected", "FLT_state_$key_fault_name" ); 
					S_teststep_detected( "0b$FLT_state_detected_8bits", "FLT_state_$key_fault_name" );
		
					# check DTC
					my $dtc_expected = $main::ProjectDefaults->{'TC_MANITOO_MAP'}->{$key_fault_name};
					my $dtc_detected = $faultMemory_Primary_obj -> get_fault_attribute({FaultName => $key_fault_name, Attribute => 'DTC'});
					
					EVAL_evaluate_value( 'DTC', $dtc_detected, '==', $dtc_expected );				

					S_teststep_2nd_level( "Evaluate DTC for $key_fault_name", 'AUTO_NBR', "DTC_$key_fault_name" );
					S_teststep_expected( "$dtc_expected", "DTC_$key_fault_name" ); 
					S_teststep_detected( "$dtc_detected", "DTC_$key_fault_name" );
					
					
					# check EventDebug_Data
					my $EventDebug_Data = $faultMemory_Bosch_obj -> get_fault_attribute({FaultName => $key_fault_name, Attribute => 'EventDebugData'});
					
					if ( exists $tcpar_EventDebug_Data{$key_fault_name} ) {
						EVAL_evaluate_value ( "EventDebug_Data", $EventDebug_Data, '==', $tcpar_EventDebug_Data{$key_fault_name} );

						S_teststep_2nd_level( "Evaluate EventDebug_Data for $key_fault_name", 'AUTO_NBR', "EventDebug_Data_$key_fault_name" );
						S_teststep_expected( "$tcpar_EventDebug_Data{$key_fault_name}", "EventDebug_Data_$key_fault_name" ); 
						S_teststep_detected( "$EventDebug_Data", "EventDebug_Data_$key_fault_name" );					
					}	
				}
			}
			S_w2rep( "Fault Memory evaluated \n" );	
		}
	}

	# ****************************** Evaluate Memory by Name ******************************************
	if ( $tcpar_USE_VAR_EVAL ne 'no' ) {
		S_teststep( "--- Evaluate Memory by Name ---", 'AUTO_NBR' );		
		foreach my $i ( 0 .. $#Eval_Var_Label ) {
			EVAL_evaluate_value( $Eval_Var_Label[$i], $Eval_Var_Label{$Eval_Var_Label[$i]}, $Eval_Var_Operator[$i], $Eval_Var_Value[$i] );

			S_teststep_2nd_level( "$tcpar_EvalVarDocu[$i]", 'AUTO_NBR', "EvalVar$i" );
			S_teststep_expected( "$Eval_Var_Label[$i] $Eval_Var_Operator[$i] $Eval_Var_Value[$i]", "EvalVar$i"); 
			S_teststep_detected( "$Eval_Var_Label{$Eval_Var_Label[$i]}", "EvalVar$i" );
		}
		S_w2rep( "Memory by Name evaluated \n" );	
	}

	# **************************** Evaluate Fast Diagnosis trace **************************************
	if ( ($tcpar_USE_FDIAG_RECORD ne 'no') and ($tcpar_USE_FDIAG_EVAL ne 'no') ) {
		my ($verdict, $sequence_time_value_href);
		
		if( defined $tcpar_FD_GetTime_href ) {
		S_teststep( "--- Evaluate Fast Diagnosis Trace ---", 'NO_AUTO_NBR' );
			foreach my $timeStampNbr (keys %{$tcpar_FD_GetTime_href}) {
				my $signalLabel = $tcpar_FD_GetTime_href -> {$timeStampNbr} -> {'SignalLabel'};
				$tcpar_FD_GetTime_href -> {$timeStampNbr} -> {'SignalLabel'} = $FDiagLabel{$signalLabel};
			}	
			($verdict, $sequence_time_value_href) = GEN_EVAL_trace_sequence($FD_data, $tcpar_FD_GetTime_href);   
		}
		
		if( $verdict eq 'PASS' ){
			if( defined $tcpar_FD_EvalTime_href ){
				my $verdictTimes = GEN_EVAL_trace_times($FD_data, $sequence_time_value_href, $tcpar_FD_EvalTime_href);
			}
			
			if( defined $tcpar_FD_EvalSignal_href ){				
				foreach my $timeStampNbr (keys %{$tcpar_FD_EvalSignal_href}) {
					foreach my $evalNbr (keys %{$tcpar_FD_EvalSignal_href -> {$timeStampNbr}}) {
						my $signalLabel = $tcpar_FD_EvalSignal_href -> {$timeStampNbr} -> {$evalNbr} ->{'SignalLabel'};
						$tcpar_FD_EvalSignal_href -> {$timeStampNbr} -> {$evalNbr} -> {'SignalLabel'} = $FDiagLabel{$signalLabel};
					}
				}	
				my $verdictSignals = GEN_EVAL_trace_signals($FD_data, $sequence_time_value_href, $tcpar_FD_EvalSignal_href);		
			}
			S_w2rep( "Fast Diagnosis Trace evaluated \n" );	
		}
	}

	# ******************************** Evaluate CAN trace *********************************************	
	if ( ($tcpar_USE_CAN_RECORD ne 'no') and ($tcpar_USE_CAN_EVAL ne 'no') ) {
		 my ($verdict, $sequence_time_value_href);

		if( defined $tcpar_CAN_GetTime_href ) {
			S_teststep( "--- Evaluate CAN trace ---", 'NO_AUTO_NBR' );
			foreach my $timeStampNbr (keys %{$tcpar_CAN_GetTime_href}) {
				my $signalLabel = $tcpar_CAN_GetTime_href -> {$timeStampNbr} -> {'SignalLabel'};
				$tcpar_CAN_GetTime_href -> {$timeStampNbr} -> {'SignalLabel'} = $CANLabel{$signalLabel};
			}
			($verdict, $sequence_time_value_href) = GEN_EVAL_trace_sequence($CAN_data, $tcpar_CAN_GetTime_href);
		}
			
	    if($verdict eq 'PASS'){
			if( defined $tcpar_CAN_EvalTime_href ){
				my $verdictTimes = GEN_EVAL_trace_times($CAN_data, $sequence_time_value_href, $tcpar_CAN_EvalTime_href);
			}
			
			if(defined $tcpar_CAN_EvalSignal_href){				
				foreach my $timeStampNbr (keys %{$tcpar_CAN_EvalSignal_href}) {
					foreach my $evalNbr (keys %{$tcpar_CAN_EvalSignal_href -> {$timeStampNbr}}) {
						my $signalLabel = $tcpar_CAN_EvalSignal_href -> {$timeStampNbr} -> {$evalNbr} ->{'SignalLabel'};
						$tcpar_FD_EvalSignal_href -> {$timeStampNbr} -> {$evalNbr} -> {'SignalLabel'} = $CANLabel{$signalLabel};
					}
				}	
				my $verdictSignals = GEN_EVAL_trace_signals($CAN_data, $sequence_time_value_href, $tcpar_CAN_EvalSignal_href);		
			}
			S_w2rep( "CAN trace evaluated \n" );	
	    }
	}
	
	# ******************************* Evaluate SPI trace **********************************************	
	if ( ($tcpar_USE_SPI_RECORD ne 'no' ) and ( $tcpar_USE_SPI_EVAL ne 'no' ) ) {
		my ($verdict, $sequence_time_value_href);

        my $tc_name = $main::TC_REPORT_NAME;
        $tc_name =~ s/\.html/_/i;
		my $meas_label = $tc_name . $Current_TC_Repetition;		

		#debug_SPI_trace
		open( FILE, ">", $main::REPORT_PATH . "/" . $meas_label . "_Debug_SPI_Decoding.txt" );
	
	    SPI_trace_load_file(
	        'MeasurementLabel' => $meas_label,
	        'FileName'         => $SPI_tracefile_name,
	    );
    
	    foreach my $SPI_node (@tcpar_SPI_Node) {
	        my $measurement_temp_href = SPI_trace_get_dataref(
	            'MeasurementLabel' => $meas_label,
	            'SPI_Node'         => $SPI_node,
	        );
        
			# hash slices in order to comnbine to hashes ( See perl docu )
	        @{$SPI_data}{ keys %$measurement_temp_href } = values %$measurement_temp_href;

			#debug_SPI_trace
			print FILE Dumper( $measurement_temp_href );
	    }
		
		#debug_SPI_trace
		close( FILE );
	
		S_teststep( "--- Evaluate SPI Trace ---", 'NO_AUTO_NBR' );
		
	    if ( defined $tcpar_SPI_GetTime_href ) {
			($verdict, $sequence_time_value_href) = GEN_EVAL_trace_sequence($SPI_data, $tcpar_SPI_GetTime_href);
		}
			
	    if ( $verdict eq 'PASS' ){
			if ( defined $tcpar_SPI_EvalTime_href ){
				my $verdictTimes = GEN_EVAL_trace_times($SPI_data, $sequence_time_value_href, $tcpar_SPI_EvalTime_href) if(defined $tcpar_SPI_EvalTime_href);
			}

			if( defined $tcpar_SPI_EvalSignal_href ) {
				my $verdictSignals = GEN_EVAL_trace_signals($SPI_data, $sequence_time_value_href, $tcpar_SPI_EvalSignal_href) if(defined $tcpar_SPI_EvalSignal_href);
			}
			S_w2rep( "SPI Trace evaluated \n" );	
		}
	}

	# ************************** Evaluate Manipulation Counters ***************************************
	if ( ( $tcpar_USE_MANIPULATION ne 'no' ) and ($tcpar_USE_MANIPUCNT_EVAL ne 'no') )  {
		my $ManipuUnit;
		
		S_teststep( "--- Evaluate Manipulation Counters ---", 'AUTO_NBR' );				
		for( my $i = 0; $i <= $#EvalManipuCnt_Module; $i = $i + 1 ) {
			$EvalManipuCnt_Module[$i] =~ /(.+)_(\d+)$/;
			$ManipuUnit = $2;

			return 1 if ($main::opt_offline);
			
			EVAL_evaluate_value( $EvalManipuCnt_Module[$i], $manipuCnt[$ManipuUnit], $EvalManipuCnt_Operator1[$i], $EvalManipuCnt_ExpValue1[$i] );
			EVAL_evaluate_value( $EvalManipuCnt_Module[$i], $manipuCnt[$ManipuUnit], $EvalManipuCnt_Operator2[$i], $EvalManipuCnt_ExpValue2[$i] );

			S_teststep_2nd_level( "$tcpar_EvalManipuCntDocu[$i]", 'AUTO_NBR', "EvalCnt$i" );
			S_teststep_expected( "Manipulation Counter $EvalManipuCnt_Module[$i] $EvalManipuCnt_Operator1[$i] $EvalManipuCnt_ExpValue1[$i] AND $EvalManipuCnt_Operator2[$i] $EvalManipuCnt_ExpValue2[$i]", "EvalCnt$i"); 
			S_teststep_detected( "$manipuCnt[$ManipuUnit]", "EvalCnt$i" );
		}
		S_w2rep( "Manipulation Counters evaluated \n" );	
	}

	if ( $tcpar_USE_SPECIFIC_TEST ne 'no' ) {
	# ***************************** SMI Verification Test ******************************************
		if ( ($tcpar_Specific_Test & $SMI_Verification) == $SMI_Verification ) {
			_SMI_Verification_Eval();
		}

	# ***************************** SPI Parameter Test ******************************************
		if ( ($tcpar_Specific_Test & $SPI_Parameter_Test) == $SPI_Parameter_Test ) {
			_SPI_Parameter_Eval();	
		}	
	}
				
	return 1;
}

#******************************************************************************************************
#                                        TEST CASE FINALIZATION                                       *
#******************************************************************************************************
sub TC_finalization {
	# ************************** Restore ECU configuration ********************************************
    if ( $tcpar_USE_MODIFY_BYTE ne 'no' ) {
        my @restore_value;
        my @keys = sort { $a cmp $b } keys %MODIFY_BYTE;

		S_teststep( "Restore configuration", 'AUTO_NBR' );		
        foreach my $key ( @keys ) {
			if ($MODIFY_BYTE{$key}{restore} ne 'no' ) {
				$restore_value[0] = $MODIFY_BYTE{$key}{origValue};
				#write back original value
				S_teststep_2nd_level( "$MODIFY_BYTE{$key}{varName} = $restore_value[0]", 'AUTO_NBR');
				PRD_Write_Memory( "$MODIFY_BYTE{$key}{varName}", \@restore_value);
				S_teststep_2nd_level( "Wait 500 ms", 'AUTO_NBR' );
				S_wait_ms( 500 );
			}
			else {
				S_teststep_2nd_level( "$MODIFY_BYTE{$key}{varName} => not restored", 'AUTO_NBR');
			}
        }
		S_w2rep( "Configuration restored \n" );	
    }
	
	# ************************** Clear Fault Memory ***************************************************
	if ( ( $tcpar_FLTMEM_Clear ne 'no' ) ){
		S_teststep_2nd_level( "Request Clear Fault Memory", 'AUTO_NBR' );
		PRD_Clear_Fault_Memory();
		S_w2rep( "Request to clear Fault Memory executed \n" );	
		S_teststep_2nd_level( "Wait 2000 ms for clearing of Fault Memory", 'AUTO_NBR' );
		S_wait_ms( 2000 );
		S_w2rep( "Waiting time of 2000 ms expired \n" );	
	}

	# ************************** Power-OFF ECU ********************************************************
	S_teststep( "Set 'power-OFF'", 'AUTO_NBR' );
    LC_ECU_Off();
	S_w2rep( "ECU powered OFF \n" );	
	S_teststep_2nd_level( "Wait $Timer_ECU_Off ms (Timer_ECU_Off)", 'AUTO_NBR' );
	S_wait_ms( $Timer_ECU_Off );
	S_w2rep( "Waiting time of $Timer_ECU_Off ms for ECU OFF expired \n" );	
	
	my $current_verdict = S_get_current_verdict();
	if( ( $current_verdict eq VERDICT_PASS ) or ( $current_verdict eq VERDICT_NONE ) ){
		$Current_TC_Repetition = 0;     # reset global variable of Testcase package (in case of repetitions)

		return 1;
	}
	
	# ************************** Check for test case repetition **************************************
	S_teststep( "Testcase is FAILED: Repetition number -> $Current_TC_Repetition", 'AUTO_NBR' );
	if( $Current_TC_Repetition < $Max_TC_Repetition ) {
		S_set_warning( "Testcase is FAILED: Repetition number -> $Current_TC_Repetition - TC will be repeated \n" );
		S_repeat_testcase ();
		$Current_TC_Repetition++;

		return 1;
	}
	else {
		S_set_warning( "Maximum number of TC repetitions -> $Current_TC_Repetition reached - no more trials of this TC \n" );
		$Current_TC_Repetition = 0;
	}
	
	return 1;
}

#######################################################################################################
#                                       SPECIFIC TESTS
#######################################################################################################
sub _SMI_Verification_Eval {
	S_teststep( "--- Evaluate SMI Verification Data ---", 'NO_AUTO_NBR' );

	foreach my $key_verification_data ( keys %tcpar_Check_Verification_Data ) {
#		S_teststep( "Evaluate $key_verification_data", 'AUTO_NBR' );
	
		my $data_expected = $tcpar_Check_Verification_Data{$key_verification_data};
		my $data_detected = $decodedData_href->{$key_verification_data};
		my $hex_check = substr ($data_detected, 0, 2);

		if ( $hex_check eq '0x') { 
			EVAL_evaluate_string( 'Verification data', $data_expected, $data_detected );
		}
		else {
			EVAL_evaluate_value( 'Verification data', $data_detected, '==', $data_expected );
		}	

		S_teststep_2nd_level( "Evaluate $key_verification_data", 'AUTO_NBR', "Verification_Data_$key_verification_data" );
		S_teststep_expected( "$data_expected", "Verification_Data_$key_verification_data" ); 
		S_teststep_detected( "$data_detected", "Verification_Data_$key_verification_data" );	

	}

	S_w2rep( "SMI Verification Data executed \n" );	

 	return 1;
}

#******************************************************************************************************
sub _SMI7_FieldCalib_Start {
	S_teststep( "Specific TEST: SMI Field Calibration Start", 'AUTO_NBR' );
	
	my $Cranking = $tcpar_FieldCalib_Start{'Cranking'};
	S_teststep_2nd_level( "Set cranking status \n rb_csei_IgnitionOffOrEngineOn_bo = $Cranking", 'AUTO_NBR' );
	# Set 'Cranking' status   # 1 = Cranking  0 = no Cranking
	PRD_Write_Memory( 'rb_csei_IgnitionOffOrEngineOn_bo', [$Cranking]);
	
	my $VehSpeed = $tcpar_FieldCalib_Start{'VehSpeed'};
	S_teststep_2nd_level( "Set Vehicle Speed on CAN \n VehicleSpeed_Dashboard = $VehSpeed km/s", 'AUTO_NBR' );
	# Set Vehicle Speed on CAN
	my $status = CA_write_can_signal ("VSD_ESPReferenceVelocity", $VehSpeed);
	
	S_teststep_2nd_level( "Wait 100 ms", 'AUTO_NBR' );
	S_wait_ms(100);
	
	# Request Field Calibration
	S_teststep_2nd_level( "Send 'Field Calibration' request", 'AUTO_NBR' );
	CD_send_request_wait_response([0x31,0x01,0x60,0x00]);

	S_w2rep( "SMI Field Calibration started \n" );

	if ( $tcpar_InitTest ne 'yes' ) {
		if ( $tcpar_USE_MANIPULATION ne 'no' ) {	
			S_teststep( "Wait $tcpar_ManipuDelayTime_ms ms (ManipuDelayTime_ms)", 'AUTO_NBR' );
			S_wait_ms($tcpar_ManipuDelayTime_ms);
			S_w2rep("Waiting time of $tcpar_ManipuDelayTime_ms ms expired (ManipuDelayTime_ms) \n");				
			
			S_teststep_2nd_level( "Send 'start_manipulation' request to ManiToo", 'AUTO_NBR' );
			MANITOO_RUN_SERVICE('start_manipulation');
			S_w2rep("Manipulation started \n");				
		}
	}			
	S_w2rep( "Field Calibration started \n" );	

	return 1;
}	

#******************************************************************************************************
sub _SMI7_FieldCalib_Running {
	my $Delay_ms = $tcpar_FieldCalib_Running{'Delay_ms'};
	
	S_teststep( "Specific TEST: SMI7 Field Calibration Running", 'AUTO_NBR' );	
	S_teststep_2nd_level( "Wait $Delay_ms ms", 'AUTO_NBR' );
	S_wait_ms($Delay_ms);
	
	if ( exists $tcpar_FieldCalib_Running{'Cranking'} ) {
		my $Cranking = $tcpar_FieldCalib_Running{'Cranking'};
		S_teststep_2nd_level( "Set cranking status \n rb_csei_IgnitionOffOrEngineOn_bo = $Cranking", 'AUTO_NBR' );
		# Set 'Cranking' status   # 1 = Cranking  0 = no Cranking
		PRD_Write_Memory( 'rb_csei_IgnitionOffOrEngineOn_bo', [$Cranking]);
	}
	
	if ( exists $tcpar_FieldCalib_Running{'VehSpeed'} ) {
		my $VehSpeed = $tcpar_FieldCalib_Running{'VehSpeed'};
		S_teststep_2nd_level( "Set Vehicle Speed on CAN \n VehicleSpeed_Dashboard = $VehSpeed km/s", 'AUTO_NBR' );
		# Set VehSpeed on CAN
		my $status = CA_write_can_signal ("VSD_ESPReferenceVelocity", $VehSpeed);
	}
	S_teststep_2nd_level( "Wait 60 ms", 'AUTO_NBR' );
	S_wait_ms(60);
	
	if ( exists $tcpar_FieldCalib_Running{'Cranking'} ) {
		# Set 'Cranking' status to 0 (no Cranking)
		S_teststep_2nd_level( "Set cranking status \n rb_csei_IgnitionOffOrEngineOn_bo = 0", 'AUTO_NBR' );
		PRD_Write_Memory( 'rb_csei_IgnitionOffOrEngineOn_bo', [0]);
	}
		
	if ( exists $tcpar_FieldCalib_Running{'VehSpeed'} ) {
		S_teststep_2nd_level( "Set Vehicle Speed on CAN \n VehicleSpeed_Dashboard = 2 km/s", 'AUTO_NBR' );
		# Set VehSpeed on CAN
		my $status = CA_write_can_signal ("VSD_ESPReferenceVelocity", 2);
	}
	S_w2rep( "SMI Field Calibration Running parameters set \n" );	
	
	return 1;
}	

#******************************************************************************************************
sub _NOR_Flash_Erase {
	S_teststep( "Set 'power-ON'", 'AUTO_NBR' );
	LC_ECU_On();
	S_w2rep( "ECU powered ON \n" );	

	S_teststep_2nd_level( "Wait 1000 ms", 'AUTO_NBR' );
	S_wait_ms(1000);
	S_w2rep( "Waiting time of 1000 ms expired \n" );	

	my ($addr, $data, $hexaddr, $hexdata);
	my $sector = $tcpar_ERASE_flash{Start_Sector};
	
	S_teststep_2nd_level( "--- Start NOR Flash erase ---", 'AUTO_NBR' );
	while ( $sector <= $tcpar_ERASE_flash{End_Sector} ) {
		$addr = 1996488704 + $sector * 4096;
		$data = 255;
		$hexaddr = sprintf("%02X", $addr);
		$hexdata = sprintf("%02X", $data);
		
		S_teststep_2nd_level( "Erase_Flash_Sector_$sector  (Addr: 0x$hexaddr = 0x$hexdata)", 'AUTO_NBR' );
		PRD_Write_Memory( $addr, $data );

		$sector++;
	}
	S_w2rep( "Erasing of NOR Flash sectors $tcpar_ERASE_flash{Start_Sector} - $tcpar_ERASE_flash{End_Sector} completed \n" );	
	
	S_teststep_2nd_level( "Set 'power-OFF'", 'AUTO_NBR' );
	LC_ECU_Off();
	S_w2rep( "ECU powered OFF \n" );	
	
	S_teststep_2nd_level( "Wait $Timer_ECU_Off ms (Timer_ECU_Off)", 'AUTO_NBR' );
	S_wait_ms( $Timer_ECU_Off );
	S_w2rep( "Waiting time of $Timer_ECU_Off ms expired \n" );	
	
	return 1;
}

#******************************************************************************************************
sub _SPI_Parameter_Extract {
	#  				 Extract SPI parameters from Acute Logic Analyzer record
	#--------------------------------------------------------------------------------------
	my ( $i, @SPI_time );
	my ( $frame_start, $frame_cnt, $clk_cnt );
	my ( $ts_cs_start, $ts_cs_stop, $ts_first_clk, $ts_clk_eight, $ts_last_clk );
	my ( $cs_idle_time, $cs_clk_delay, $clk_cs_delay, $time_7_clks );
	
    my $tc_name = $main::TC_REPORT_NAME;
    $tc_name =~ s/\.html/_/i;
	my $meas_label = $tc_name . $Current_TC_Repetition;		
	
	$frame_start = 0;
	$frame_cnt = 1;
	$cs_idle_time = 0.150;

	my $SPI_CLK = $tcpar_LA_Channels[0];
	my $SPI_CS  = $tcpar_LA_Channels[1];
	my $time_arr_lenght = scalar(@{$LA_data_href->{'time_s'}});

	open( FILE1, ">", $main::REPORT_PATH . "/" . $meas_label . "_LA_SPI_Message.txt" );
	printf FILE1 ( "%5s; %5s; %12s; %12s; %12s; %12s; %12s; %12s; %12s; %12s; %12s; \n", 'f_cnt', 'b_cnt', 'time_cs_idle', 'ts_cs_start', 'ts_first_clk', 'ts_clk_eight', 'ts_last_clk', 'ts_cs_stop', 'cs_clk_delay', 'clk_cs_delay', 'time_8_clks' );  
	print  FILE1 ( "------------------------------------------------------------------------------------------------------------------------------------------- \n");  
	#debug
	#open( FILE2, ">", $main::REPORT_PATH . "/" . $meas_label . "_LA_record.txt" );

	S_teststep( "Extract SPI parameters from Acute LA record", 'AUTO_NBR' );
	for ($i = 1; $i < $time_arr_lenght; $i++) {
		#debug
		#printf FILE2 ( "%10.9f; %1d %1d \n", $LA_data_href->{'time_s'}[$i-1], $LA_data_href->{$SPI_CLK}[$i], $LA_data_href->{$SPI_CS}[$i] );
		
		# chip select falling edge?
		if ( ($LA_data_href->{$SPI_CS}[$i] == 1) and ($LA_data_href->{$SPI_CS}[$i+1] == 0) ) { 
			$ts_cs_start = $LA_data_href->{'time_s'}[$i];
			$clk_cnt = 1;
			$frame_start = 1;
		}
		
		if ( $frame_start == 1 ) {
			# clock rising edge?
			if ( ($LA_data_href->{$SPI_CLK}[$i-1] == 0) and ($LA_data_href->{$SPI_CLK}[$i] == 1) ) { 
				if ( $clk_cnt == 1 ) {
					$ts_first_clk = $LA_data_href->{'time_s'}[$i-1];
				}
				if ( $clk_cnt == 8 ) {
					$ts_clk_eight = $LA_data_href->{'time_s'}[$i-1];
				}					
				$clk_cnt++;	
			}
			# clock falling edge?
			if ( ($LA_data_href->{$SPI_CLK}[$i-1] == 1) and ($LA_data_href->{$SPI_CLK}[$i] == 0) ) { 
				$ts_last_clk = $LA_data_href->{'time_s'}[$i-1];
			}
			
			# chip select rising edge?
			if ( ($LA_data_href->{$SPI_CS}[$i] == 0) and ($LA_data_href->{$SPI_CS}[$i+1] == 1) ) { 
				$frame_start == 0;
				$ts_cs_stop = $LA_data_href->{'time_s'}[$i];
	
				# check for correct SPI frame
				if ( $clk_cnt > 8 ) {
					$SPI_time[$frame_cnt][0] = $ts_cs_start;
					$SPI_time[$frame_cnt][1] = $ts_first_clk;
					$SPI_time[$frame_cnt][2] = $ts_clk_eight;
					$SPI_time[$frame_cnt][3] = $ts_last_clk;
					$SPI_time[$frame_cnt][4] = $ts_cs_stop;
					
					$cs_clk_delay = $ts_first_clk - $ts_cs_start;
					$clk_cs_delay = $ts_cs_stop - $ts_last_clk ;
					
					$time_7_clks = $ts_clk_eight - $ts_first_clk;
					
					if ( $frame_cnt == 1 ) {
						$min_time_cs_idle = $cs_idle_time;
						$min_delay_cs_clk = $cs_clk_delay;
						$min_delay_clk_cs = $clk_cs_delay;
						$min_time_7_clks  = $time_7_clks;
					} 
					else {	
						$cs_idle_time = ($SPI_time[$frame_cnt][0] - $SPI_time[$frame_cnt-1][4]);
						
						if ( $cs_idle_time < $min_time_cs_idle ) {
							$min_time_cs_idle = $cs_idle_time;								
						}
						if ( $cs_clk_delay < $min_delay_cs_clk ) {
							$min_delay_cs_clk = $cs_clk_delay;								
						}
						if ( $clk_cs_delay < $min_delay_clk_cs ) {
							$min_delay_clk_cs = $clk_cs_delay;								
						}
						if ( $time_7_clks < $min_time_7_clks ) {
							$min_time_7_clks = $time_7_clks;								
						}
					}
										
					if ( $cs_idle_time > $tcpar_Line_break_time ) {
						printf FILE1 ( "\n" );
					}
					printf FILE1 ( "%5d; %5d; %12.9f; %12.9f; %12.9f; %12.9f; %12.9f; %12.9f; %12.9f; %12.9f; %12.9f; \n", $frame_cnt, $clk_cnt / 8, $cs_idle_time, $SPI_time[$frame_cnt][0], $SPI_time[$frame_cnt][1], $SPI_time[$frame_cnt][2], $SPI_time[$frame_cnt][3], $SPI_time[$frame_cnt][4], $cs_clk_delay, $clk_cs_delay, $time_7_clks );
					$frame_cnt++;
				}
			}
						
		}						
	}	

	my $s1 = sprintf("%1.9f", $min_time_7_clks);
	my $s2 = sprintf("%1.9f", $min_delay_cs_clk);
	my $s3 = sprintf("%1.9f", $min_delay_clk_cs);
	my $s4 = sprintf("%1.9f", $min_time_cs_idle);
		
	S_w2log( 3, "min_time_7_clks = $s1", "grey" );
	S_w2log( 3, "min_delay_cs_clk = $s2", "grey" );
	S_w2log( 3, "min_delay_clk_cs = $s3", "grey" );
	S_w2log( 3, "min_time_cs_idle = $s4", "grey" );
	S_w2rep( "SPI parameters extracted \n" );	
			
	printf FILE1 ( "\n %21s; %17s; %17s; %17s; \n", 'min_time_cs_idle', 'min_delay_cs_clk', 'min_delay_clk_cs', 'min_time_7_clks' );  
	print  FILE1 ( "   ---------------------------------------------------------------------------- \n");  
	printf FILE1 ( "%21.9f; %17.9f; %17.9f; %17.9f; \n", $min_time_cs_idle, $min_delay_cs_clk, $min_delay_clk_cs, $min_time_7_clks );
	close( FILE1 );
	#debug
	#close( FILE2 );
}

#******************************************************************************************************
sub _SPI_Parameter_Eval {
	my @Eval_SPI;

	$Eval_SPI[0] = $min_time_7_clks;
	$Eval_SPI[1] = $min_delay_cs_clk;
	$Eval_SPI[2] = $min_delay_clk_cs;
	$Eval_SPI[3] = $min_time_cs_idle;
	
	S_teststep( "--- Evaluate SPI Parameters ---", 'AUTO_NBR' );	
	foreach my $i ( 0 .. $#Eval_SPI_Para_Label ) {
		EVAL_evaluate_value( $Eval_SPI_Para_Label[$i], $Eval_SPI[$i], '>=', $tcpar_Eval_SPI_Para[$i] );

		S_teststep_2nd_level( "Evaluate $Eval_SPI_Para_Label[$i]", 'AUTO_NBR', "EvalSPI$i" );
		S_teststep_expected( "$Eval_SPI_Para_Label[$i] >= $tcpar_Eval_SPI_Para[$i]", "EvalSPI$i" ); 
		S_teststep_detected( "$Eval_SPI[$i]}", "EvalSPI$i" );			
	}
	S_w2rep( "SPI parameters evaluated \n" );	
}

1;

__END__
