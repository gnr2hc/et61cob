#### TEST CASE MODULE
package TC_DSM_ReadExtendedData_MemoryOverflow;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.3 $;
our $HEADER  = q$Header: DSM_AB12/TC_DSM_ReadExtendedData_MemoryOverflow.pm 1.3 2017/11/22 14:15:48ICT ver6cob develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_ReadDTCInformation
#TS version in DOORS: 4.9
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use GENERIC_DCOM;
use LIFT_CD;
use LIFT_evaluation;
##################################

our $PURPOSE = "to check that the ECU response to read extended data for a DTC with memory overflow";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_ReadExtendedData_MemoryOverflow

=head1 PURPOSE

to check that the ECU response to read extended data for a DTC with memory overflow

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Create <Faults> equal to the fault memory size

2. Create an additional fault <AdditionalFault>

3. Send request to read extended data for first created fault

4. Send request to read extended data for the additional fault 


I<B<Evaluation>>

3. Positive response with valid extended data records

4. Positive response with only the DTCAndStatusRecord (DTC and StatusByte). No extended data is reported.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	LIST 'Faults' => 
	SCALAR 'AdditionalFault' => 


=head2 PARAMETER EXAMPLES

	purpose = 'to check that the ECU sends the positive response containing only the DTCAndStatusRecord for requests to read extended data for a DTC with memory overflow' 
	# input parameters
	#fill the fault memory with cyclic faults (size of customer fault memory, see SYC)
	Faults = @('rb_sqm_SquibResistanceOpenAB1FD_flt', 'rb_sqm_SquibResistanceOpenAB1FP_flt', 'rb_sqm_SquibResistanceOpenSA1FL_flt', 'rb_sqm_SquibResistanceOpenSA1FR_flt', 'rb_sqm_SquibResistanceOpenBT1FD_flt', 'rb_sqm_SquibResistanceOpenBT1FP_flt', 'rb_sqm_SquibResistanceOpenAB2FD_flt', 'rb_sqm_SquibResistanceOpenAB2FP_flt', 'rb_sqm_SquibResistanceOpenBT1RL_flt', 'rb_sqm_SquibResistanceOpenBT1RR_flt', 'rb_sqm_SquibResistanceOpenIC1FL_flt', 'rb_sqm_SquibResistanceOpenIC1FR_flt', 'rb_sqm_SquibResistanceOpenALLFD_flt', 'rb_swm_OpenLineBLFD_flt', 'rb_swm_OpenLineBLFP_flt',) #fill with valid faults
	AdditionalFault = 'rb_sqm_SquibResistanceOpenAB3FD_flt'
	#output parameters

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my @tcpar_Faults;
my $tcpar_AdditionalFault;
my $tcpar_ReportDTCExtendedDataRecordByDTCNumber;

################ global parameter declaration ###################
#add any global variables here

###############################################################

sub TC_set_parameters {

    $tcpar_purpose                                = GEN_Read_mandatory_testcase_parameter('purpose');
    @tcpar_Faults                                 = GEN_Read_mandatory_testcase_parameter('Faults');
    $tcpar_AdditionalFault                        = GEN_Read_mandatory_testcase_parameter('AdditionalFault');
    $tcpar_ReportDTCExtendedDataRecordByDTCNumber = GEN_Read_mandatory_testcase_parameter('ReportDTCExtendedDataRecordByDTCNumber');

    return 1;
}

sub TC_initialization {

    S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
    GEN_StandardPrepNoFault();

    GDCOM_start_CyclicTesterPresent();

    return 1;
}

sub TC_stimulation_and_measurement {

    my %DataValue;
    $DataValue{'DTCExtendedDataRecordNumber'} = 'FF';

    S_teststep( "Create faults equal to the fault memory size", 'AUTO_NBR' );
    foreach (@tcpar_Faults) {
        FM_createFault($_);
    }
    S_wait_ms( 10000, 'wait for qualification time' );

    S_teststep( "Create an additional fault '$tcpar_AdditionalFault'", 'AUTO_NBR' );
    FM_createFault($tcpar_AdditionalFault);
    S_wait_ms( 10000, 'wait for qualification time' );
	CD_read_DTC ('0x02', '0x08');

    S_teststep( "Send request to read extended data for first created fault", 'AUTO_NBR', 'send_request_to_A' );    #measurement 1
    $DataValue{'DTC'} = CD_get_FaultDTC( $tcpar_Faults[0] );
    $DataValue{'DTC'} =~ s/(\w{2})/$1 /g;                                                                           #inserts a space after every 2 characters
	$DataValue{'DTC'} =~ s/\s+$//; #remove whitespace at end
    my $response_firstFault = GDCOM_request_general( "REQ_" . $tcpar_ReportDTCExtendedDataRecordByDTCNumber, 'PR_' . $tcpar_ReportDTCExtendedDataRecordByDTCNumber, \%DataValue );

    my $numOfBytes = scalar split / /, $response_firstFault;
    EVAL_evaluate_value( "RecordStatus_Active", $numOfBytes, '>=', 8 );                                             #min 1 record reported
    S_teststep_expected( "Number of response bytes >= 8 (Minimum 1 Record)", "send_request_to_A" );
    S_teststep_detected( "Number of response bytes = $numOfBytes", "send_request_to_A" );

    S_teststep( "Send request to read extended data for the additional fault ", 'AUTO_NBR', 'send_request_to_B' );    #measurement 2
    $DataValue{'DTC'} = CD_get_FaultDTC($tcpar_AdditionalFault);
    $DataValue{'DTC'} =~ s/(\w{2})/$1 /g;                                                                             #inserts a space after every 2 characters
	$DataValue{'DTC'} =~ s/\s+$//; #remove whitespace at end
    my $response_additionalFault = GDCOM_request_general( "REQ_" . $tcpar_ReportDTCExtendedDataRecordByDTCNumber, 'PR_' . $tcpar_ReportDTCExtendedDataRecordByDTCNumber, \%DataValue );

    $response_additionalFault = '59 06 01 00 30 39' if $main::opt_offline; #dummy for offline mode handling
    GDCOM_evaluate_response_bytes( "DTC", $response_additionalFault, 2, $DataValue{'DTC'} );
    my @respBytes_addnFlt = split / /, $response_additionalFault;
    EVAL_evaluate_value( "DTCStatus_AdditionalFault", $respBytes_addnFlt[5], 'MASK', '0bxxxxxxx1' ); #active

    $numOfBytes = scalar split / /, $response_additionalFault;
    EVAL_evaluate_value( "RecordStatus_Active", $numOfBytes, '==', 6 );                                               #only positive response bytes

    S_teststep_expected( "Number of response bytes = 6 (No Extended Data Record)", "send_request_to_B" );
    S_teststep_detected( "Number of response bytes = $numOfBytes", "send_request_to_B" );
    
    S_w2rep("Remove the faults created in the TC");
    foreach (@tcpar_Faults) {
        FM_removeFault($_);
    }
    FM_removeFault($tcpar_AdditionalFault);
    S_wait_ms( 10000, 'wait for dequalification time' );

    return 1;
}

sub TC_evaluation {

    S_w2rep("Evaluation is done above in stimulation_and_measurement");

    return 1;
}

sub TC_finalization {

    GDCOM_stop_CyclicTesterPresent();

    return 1;
}

1;
