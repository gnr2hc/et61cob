#### TEST CASE MODULE
package TC_DSM_SessionControl_OnlyOneSession;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.4 $;
our $HEADER = q$Header: DSM_AB12/TC_DSM_SessionControl_OnlyOneSession.pm 1.4 2018/04/24 17:59:35ICT ver6cob develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_SessionControl
#TS version in DOORS: 0.2
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use LIFT_labcar;
use GENERIC_DCOM;
use LIFT_evaluation;
use LIFT_PD;
##################################

our $PURPOSE = "To check that only one session is active at a time";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_SessionControl_OnlyOneSession

=head1 PURPOSE

To check that only one session is active at a time

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Set Addressing Mode and Protocol

2. Cycle power to the ECU.

3. Wait for 15 secs

4. Read the active session by sending <ReadActiveSession>

5. Send request to enter <Session>

6. Read the active session by sending <ReadActiveSession>

# Repeat the above steps for all supported Addressing modes as defined in the SPR


I<B<Evaluation>>

1. 

2.

3.

4. ECU should report Default Session

5. Positive response is observed

 

6. Observe positive response and in the last byte <Session> should be reported.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Purpose' => 
	SCALAR 'Session' => 
	SCALAR 'ReadActiveSession' => 
	SCALAR 'PR_ActiveSession_ByteNbr' => 
	SCALAR 'ActiveSession' => 

=head2 PARAMETER EXAMPLES

	Purpose = 'To check active session in server at a time'
	
	
	Session =  '<Test Heading>'
	ReadActiveSession =  'ReadActiveDiagnosticSession'
	PR_ActiveSession_ByteNbr => '03'
	ActiveSession => '01'


=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_Session;
my $tcpar_ReadActiveSession;
my $defaultSession = '01';
my $tcpar_PR_ActiveSession_ByteNbr;
my $tcpar_ActiveSession;

################ global parameter declaration ###################
#add any global variables here


###############################################################

sub TC_set_parameters {

	$tcpar_Purpose =  GEN_Read_mandatory_testcase_parameter( 'Purpose' );
	$tcpar_Session =  GEN_Read_mandatory_testcase_parameter( 'Session' );
	$tcpar_ReadActiveSession =  GEN_Read_mandatory_testcase_parameter( 'ReadActiveSession' );
	$tcpar_PR_ActiveSession_ByteNbr = GEN_Read_mandatory_testcase_parameter('PR_ActiveSession_ByteNbr');
	$tcpar_ActiveSession =  GEN_Read_mandatory_testcase_parameter( 'ActiveSession' );

	return 1;
}

sub TC_initialization {

	S_teststep("StandardPrepNoFault", 'AUTO_NBR');
	#    GEN_StandardPrepNoFault();
	DIAG_ECUReset_NOVERDICT ();
	S_wait_ms ('TIMER_ECU_READY', 'wait after reset');
	PD_ReadFaultMemory_NOERROR();
	
	# GDCOM_start_CyclicTesterPresent();
	# GDCOM_set_addressing_mode('physical');

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Set physical addressing mode", 'AUTO_NBR');
	GDCOM_set_addressing_mode('physical');;

	S_teststep("Cycle power to the ECU.", 'AUTO_NBR');
	GEN_Power_on_Reset('NO_WAIT');
	# DIAG_ECUReset_NOVERDICT ();
	
	S_teststep("Wait for 15 secs", 'AUTO_NBR');
	S_wait_ms( 15000 );
	

	S_teststep("Read the active session by sending '$tcpar_ReadActiveSession'", 'AUTO_NBR', 'read_the_active_A');			#measurement 1
	my $diagResp_ReadSession1 = ReadActiveSession ();
	my @activesession1_resp_byte = split( / / , $diagResp_ReadSession1);# Split all the response bytes of Step1 to array
	EVAL_evaluate_value ( 'read_the_active_A' , $activesession1_resp_byte[$tcpar_PR_ActiveSession_ByteNbr], '==', $defaultSession );
	S_teststep_expected("Current session shall be '$defaultSession'.",'read_the_active_A');			
	S_teststep_detected("Session obtained $activesession1_resp_byte[$tcpar_PR_ActiveSession_ByteNbr]",'read_the_active_A');
			
			
	S_teststep("Send request to enter '$tcpar_Session'", 'AUTO_NBR', 'send_request_to');									#measurement 2
	my $diagResponse_SessionControl = GDCOM_request_general("REQ_DiagnosticSessionControl_".$tcpar_Session,"PR_DiagnosticSessionControl_".$tcpar_Session);
	S_teststep_expected('Positive Response shall be obtained','send_request_to');			
	S_teststep_detected("Obtained Response is '$diagResponse_SessionControl'",'send_request_to');
	
	S_wait_ms( 3000, "Entry into programming session triggers a reset hence a delay is required" ) if ( $tcpar_Session =~ m/programming/i );
				
	S_teststep("Read the active session by sending '$tcpar_ReadActiveSession'", 'AUTO_NBR', 'read_the_active_B');			#measurement 3
	my $diagResp_ReadSession2 = ReadActiveSession ();
	my @activesession2_resp_byte = split( / / , $diagResp_ReadSession2);# Split all the response bytes of Step1 to array
	EVAL_evaluate_value ( 'read_the_active_B' , $activesession2_resp_byte[$tcpar_PR_ActiveSession_ByteNbr], '==', $tcpar_ActiveSession );
	S_teststep_expected("Current session shall be '$tcpar_ActiveSession'.",'read_the_active_B');			
	S_teststep_detected("Session obtained $activesession2_resp_byte[$tcpar_PR_ActiveSession_ByteNbr]",'read_the_active_B');
	
	return 1;
}

sub TC_evaluation {

	S_w2rep("Evaluation is done above in stimulation_and_measurement");

	return 1;
}

sub TC_finalization {

	return 1;
}

sub ReadActiveSession {
	
	if($tcpar_ReadActiveSession =~ m/rb_/i){ #read from SW variable
		return DIAG_ReadActiveSession_SW_var ( $tcpar_ReadActiveSession );
	}
	else{
		return GDCOM_request_general("REQ_".$tcpar_ReadActiveSession,"PR_".$tcpar_ReadActiveSession);
	}
}

1;
