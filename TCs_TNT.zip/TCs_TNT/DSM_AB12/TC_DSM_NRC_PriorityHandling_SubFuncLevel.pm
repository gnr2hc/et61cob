#### TEST CASE MODULE
package TC_DSM_NRC_PriorityHandling_SubFuncLevel;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.4 $;
our $HEADER = q$Header: DSM_AB12/TC_DSM_NRC_PriorityHandling_SubFuncLevel.pm 1.4 2017/08/31 14:50:34ICT ver6cob develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_NegativeResponseCodes
#TS version in DOORS: 0.3
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use GENERIC_DCOM;
use LIFT_PD;
##################################

our $PURPOSE = "To verify the priority handling for NRCs at SubFunction level";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_NRC_PriorityHandling_SubFuncLevel

=head1 PURPOSE

To verify the priority handling for NRCs at SubFunction level

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Create the NRC conditions based on below parameters:

<MinLengthIncorrect>

<SubFuncNotSupported>

<SubFuncNotSupportedInActiveSession>

<SubFuncSecurityNotTaken>

<RequestSequenceIncorrect>

<Manu_SupplierSpecificFailure>

2. Send <Request> in physical addressing mode

3. Send <Request> in functional addressing mode


I<B<Evaluation>>

1.  

2. <Response_phys> is received

3. <Response_func> is received


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Request' => 
	SCALAR 'Purpose' => 
	SCALAR 'MinLengthIncorrect' => 
	SCALAR 'SubFuncNotSupported' => 
	SCALAR 'SubFuncNotSupportedInActiveSession' => 
	SCALAR 'SubFuncSecurityNotTaken' => 
	SCALAR 'RequestSequenceIncorrect' => 
	SCALAR 'Manu_SupplierSpecificFailure' => 
	SCALAR 'Response_phys' => 
	SCALAR 'Response_func' => 


=head2 PARAMETER EXAMPLES

	Purpose = 'To check for NRC priority handling at SubFunction level - NRC13 over NRC12'
	
	MinLengthIncorrect = 'yes'
	SubFuncNotSupported = 'yes'
	SubFuncNotSupportedInActiveSession = 'NA'
	SubFuncSecurityNotTaken = 'NA'
	RequestSequenceIncorrect = 'NA'
	Manu_SupplierSpecificFailure = 'VoltageTooHigh' #project configurable
	
	Response_phys = 'NR_incorrectMessageLengthOrInvalidFormat'
	Response_func = 'NR_incorrectMessageLengthOrInvalidFormat'
	Request = '10 05' #any not supported sub function

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_MinLengthIncorrect;
my $tcpar_SubFuncNotSupported;
my $tcpar_SubFuncNotSupportedInActiveSession;
my $tcpar_SubFuncSecurityNotTaken;
my $tcpar_RequestSequenceIncorrect;
my $tcpar_Manu_SupplierSpecificFailure;
my $tcpar_Response_phys;
my $tcpar_Response_func;
my $tcpar_Request;
my ( %tcpar_CommunicationType, %tcpar_Key, %tcpar_Data, %tcpar_IOControlState, %tcpar_RoutineControlOption );
my ( $NRCdesc_phys, $NRCdesc_func );

################ global parameter declaration ###################
#add any global variables here
my %DataValue;
my %NRC_map = reverse %{ S_get_contents_of_hash( [ 'Mapping_DIAG', 'GlobalNRC' ] ) };

###############################################################

sub TC_set_parameters {

	$tcpar_Purpose =  GEN_Read_mandatory_testcase_parameter( 'Purpose' );
	$tcpar_MinLengthIncorrect =  GEN_Read_mandatory_testcase_parameter( 'MinLengthIncorrect' );
	$tcpar_SubFuncNotSupported =  GEN_Read_mandatory_testcase_parameter( 'SubFuncNotSupported' );
	$tcpar_SubFuncNotSupportedInActiveSession =  GEN_Read_mandatory_testcase_parameter( 'SubFuncNotSupportedInActiveSession' );
	$tcpar_SubFuncSecurityNotTaken =  GEN_Read_mandatory_testcase_parameter( 'SubFuncSecurityNotTaken' );
	$tcpar_RequestSequenceIncorrect =  GEN_Read_mandatory_testcase_parameter( 'RequestSequenceIncorrect' );
	$tcpar_Manu_SupplierSpecificFailure =  GEN_Read_mandatory_testcase_parameter( 'Manu_SupplierSpecificFailure' );
	$tcpar_Response_phys =  GEN_Read_mandatory_testcase_parameter( 'Response_phys' );
	$tcpar_Response_func =  GEN_Read_mandatory_testcase_parameter( 'Response_func' );
	$tcpar_Request =  GEN_Read_mandatory_testcase_parameter( 'Request' );
	
	#handle required bytes in request
    $DataValue{'StatusMask'}                  = GEN_Read_optional_testcase_parameter('StatusMask');
    $DataValue{'DTC'}                         = GEN_Read_optional_testcase_parameter('DTC');
    $DataValue{'DTCSnapshotRecordNumber'}     = GEN_Read_optional_testcase_parameter('DTCSnapshotRecordNumber');
    $DataValue{'DTCExtendedDataRecordNumber'} = GEN_Read_optional_testcase_parameter('DTCExtendedDataRecordNumber');

    %tcpar_CommunicationType    = GEN_Read_optional_testcase_parameter('CommunicationType');
    %tcpar_Key                  = GEN_Read_optional_testcase_parameter('Key');
    %tcpar_Data                 = GEN_Read_optional_testcase_parameter('Data');
    %tcpar_IOControlState       = GEN_Read_optional_testcase_parameter('IOControlState');
    %tcpar_RoutineControlOption = GEN_Read_optional_testcase_parameter('RoutineControlOption');
    
    $tcpar_Response_phys =~ m/NR_(.*)/i;
    $NRCdesc_phys = $1;
    
    $tcpar_Response_func =~ m/NR_(.*)/i;
    $NRCdesc_func = $1;

	return 1;
}

sub TC_initialization {

	S_teststep("StandardPrepNoFault", 'AUTO_NBR');
#	GEN_StandardPrepNoFault();
	DIAG_ECUReset_NOVERDICT ();
	S_wait_ms ('TIMER_ECU_READY', 'wait after reset');
	PD_ReadFaultMemory_NOERROR();
	
	GDCOM_start_CyclicTesterPresent();
	GDCOM_set_addressing_mode('physical');

	return 1;
}

sub TC_stimulation_and_measurement {
    
    my ( $supportedSessions, $notSupportedSessions, $NRCInfo, $SID, $service, $session_status, $ReqLength );
    
    if($tcpar_Request eq 'none'){
        S_teststep("No diag requests are applicable for this test case in project", 'NO_AUTO_NBR');
        return 1;
    }

	S_teststep("Create the NRC conditions based on below parameters:", 'NO_AUTO_NBR');

	S_teststep("Set MinLengthIncorrect = '$tcpar_MinLengthIncorrect'", 'AUTO_NBR');
	if ($tcpar_MinLengthIncorrect eq 'yes'){
	    S_set_error ("currently not possible to set only length without changing the actual number of request bytes. Perform test case manually");
	    return;
	}

	S_teststep("Set SubFuncNotSupported = '$tcpar_SubFuncNotSupported'", 'AUTO_NBR');
	unless ($tcpar_SubFuncNotSupported eq 'yes'){
        $tcpar_Request =~ m/(.*?)_(.*)/;
        $service = $1;
        
		my $SID = S_get_contents_of_hash( [ 'Mapping_DIAG', 'PRJ_SUPPORTED_SERVICES', $1]);
		my $SubFunc = S_get_contents_of_hash( [ 'Mapping_DIAG', 'DIAG_SERVICES', $1,'Supported_SubFuns', $2]);
        _fillRequestInputParameters ($SID, $SubFunc);
		
		if ($SID eq '2E'){ #for 2E service, write the same value as read by 22 service
    		my $DID = $SubFunc;
    		my $readdata = GDCOM_request_NOVERDICT ("22 $DID", "62 $DID", 'relax');
    		$readdata = substr($readdata, 9); #remove 62 DIDHB DIDLB
    		$DataValue{'Data'} = $readdata if (defined $readdata);
    	}
    }

	S_teststep("Set SubFuncNotSupportedInActiveSession = '$tcpar_SubFuncNotSupportedInActiveSession'", 'AUTO_NBR');
	if($tcpar_SubFuncNotSupported eq 'yes'){
	    ($SID) = split( / /, $tcpar_Request );
	    $service = _getServiceLabel($SID);
	    $supportedSessions = _getSupportedSessionsForService($service);
        S_w2rep("Sessions supported for service $SID: @$supportedSessions\n");    
	}
	else{
	    $supportedSessions = _getSupportedSessionsForRequest($tcpar_Request);
        S_w2rep("Sessions supported by '$tcpar_Request': @$supportedSessions");
	}

	if ( $tcpar_SubFuncNotSupportedInActiveSession eq 'yes' ) {
        my $service10   = _getServiceLabel('10');
        my $sessionInfo = GDCOM_getSupportedSubFunsfromMapping($service10);
        my @allSessions = keys(%$sessionInfo);
        
        #remove any session containing 'ForDisposal'
        my $index = 0;
		foreach (@allSessions) {
			if ($_ =~ m/ForDisposal/i) { 
				splice (@allSessions, $index, 1)
			} 
			else { 
				$index++;
			}
		}
        S_w2rep("All sessions supported in project: @allSessions");

        $notSupportedSessions = GEN_filterChildarrayFromParentarray( \@allSessions, $supportedSessions );
        S_teststep_2nd_level( "Sessions not supported by '$tcpar_Request': @$notSupportedSessions", 'NO_AUTO_NBR' );

        if ( scalar @$notSupportedSessions ) {    #not supported sessions
            foreach (@$notSupportedSessions){
                next if $_ =~ m/Safety|Disposal/i;
                S_teststep_2nd_level( "Enter session: $_", 'AUTO_NBR' );
                $session_status = DIAG_StartSession( $_ );
                S_wait_ms (5000, 'wait after session entry') if($_ =~ m/prog|boot/i);
                last;
            }
        }
        else {
            $session_status = 0;
            S_teststep_2nd_level( "There is no session in which '$tcpar_Request' is not supported. Cannot set SIDNotSupportedInActiveSession!", 'NO_AUTO_NBR' );
        }
        
        unless (defined $session_status){
            S_teststep_2nd_level( "There is no session other than disposal/safety session in which '$tcpar_Request' is not supported. Cannot set SIDNotSupportedInActiveSession!", 'NO_AUTO_NBR' );
        }
    }
    else {
        S_teststep_2nd_level( "Enter session: @$supportedSessions[0]", 'AUTO_NBR' );
        DIAG_StartSession( @$supportedSessions[0] );
    }


	S_teststep("Set SubFuncSecurityNotTaken = '$tcpar_SubFuncSecurityNotTaken'", 'AUTO_NBR');
	if ($tcpar_SubFuncNotSupported ne 'yes' and $tcpar_SubFuncSecurityNotTaken ne 'yes' ){
	    my $securityLevelsForRequest = _getSecurityLevelsForRequest($tcpar_Request);

        if ( @$securityLevelsForRequest[0] !~ m/None/i and @$securityLevelsForRequest[0] ne '---' and @$securityLevelsForRequest[0] ne 'n/a' ){ #in case security access is required
            S_teststep_2nd_level("Get required security access: @$securityLevelsForRequest", 'NO_AUTO_NBR');
            DIAG_getSecurityAccess (@$securityLevelsForRequest[0]) if (defined &DIAG_getSecurityAccess);
        }
        else{
            S_teststep_2nd_level("Security access not required for request '$tcpar_Request'", 'NO_AUTO_NBR');
        }

        GDCOM_GetAccessToRequest ($tcpar_Request); #handle any dependent services through request in Mapping_DIAG (if required)
	}
	

	S_teststep("Set RequestSequenceIncorrect = '$tcpar_RequestSequenceIncorrect'", 'AUTO_NBR');

	S_teststep_2nd_level("Manu_SupplierSpecificFailure = '$tcpar_Manu_SupplierSpecificFailure'", 'AUTO_NBR');
	DIAG_setProhibitingPrecondition($tcpar_Manu_SupplierSpecificFailure) if ( $tcpar_Manu_SupplierSpecificFailure ne 'no' and $tcpar_Manu_SupplierSpecificFailure ne 'NA' );   

		S_teststep("Send '$tcpar_Request' in physical addressing mode", 'AUTO_NBR', 'send_request_phys');			#measurement 1
		GDCOM_set_addressing_mode('physical');
	    if ( $tcpar_SubFuncNotSupported eq 'yes' ) {
        	my $response_phys = GDCOM_request( $tcpar_Request, "7F $SID $NRC_map{$NRCdesc_phys}", 'strict' );

	        S_teststep_expected( "7F $SID $NRC_map{$NRCdesc_phys}", 'send_request_phys' );                 #evaluation 1
	        S_teststep_detected( $response_phys, 'send_request_phys' );
	    }
	    else {
	        my $response_phys = GDCOM_request_general( "REQ_" . $tcpar_Request, $tcpar_Response_phys, \%DataValue );
	
	        $NRCInfo = GDCOM_getNRCfromMapping( $service, $tcpar_Response_phys );
	        S_teststep_expected( $NRCInfo->{'Response'}, "send_request_phys" );                                             #evaluation 1
	        S_teststep_detected( $response_phys, "send_request_phys" );
	    }
	
	
	
		S_teststep("Send '$tcpar_Request' in functional addressing mode", 'AUTO_NBR', 'send_request_func');			#measurement 2
		GDCOM_set_addressing_mode('functional');
	    if ( $tcpar_SubFuncNotSupported eq 'yes' and $tcpar_Response_func ne 'NoResponse' ) {
	        my $response_func = GDCOM_request( $tcpar_Request, "7F $SID $NRC_map{$NRCdesc_func}", 'strict' );
	
	        S_teststep_expected( "7F $SID $NRC_map{$NRCdesc_func}", 'send_request_func' );                 #evaluation 1
	        S_teststep_detected( $response_func, 'send_request_func' );
	    }
	    elsif ( $tcpar_SubFuncNotSupported eq 'yes' and $tcpar_Response_func eq 'NoResponse' ) {
	        my $response_func = GDCOM_request( $tcpar_Request, "", 'quiet' );
	
	        S_teststep_expected( "no response", "send_request_func" );                                                      #evaluation 2
	        S_teststep_detected( "-".$response_func, "send_request_func" );
	    }
	    elsif ( $tcpar_SubFuncNotSupported eq 'no' and $tcpar_Response_func eq 'NoResponse' ) {
	        my $requestBytes = GDCOM_getRequestLabelValue( "REQ_" . $tcpar_Request, \%DataValue );
        	my $response_func = GDCOM_request( $requestBytes, "", 'quiet' );
	
	        S_teststep_expected( "no response", "send_request_func" );                                                      #evaluation 2
	        S_teststep_detected( "-".$response_func, "send_request_func" );
	    }
	    else {
	        my $response_func = GDCOM_request_general( "REQ_" . $tcpar_Request, $tcpar_Response_func, \%DataValue );
	
	        S_teststep_expected( $NRCInfo->{'Response'}, "send_request_func" );                                             #evaluation 2
	        S_teststep_detected( $response_func, "send_request_func" );
	    }

	S_teststep( "\n", 'NO_AUTO_NBR' ); #newline for steps in TR

	return 1;
}

sub TC_evaluation {
    
    if($tcpar_Request eq 'none'){
        S_teststep("No diag requests are applicable for this test case in project", 'NO_AUTO_NBR');
        return 1;
    }

	S_w2rep("Evaluation is done above in stimulation_and_measurement");

	return 1;
}

sub TC_finalization {
    
    DIAG_removeProhibitingPrecondition($tcpar_Manu_SupplierSpecificFailure) if ( $tcpar_Manu_SupplierSpecificFailure ne 'no' and $tcpar_Manu_SupplierSpecificFailure ne 'NA' );    
    
    GDCOM_stop_CyclicTesterPresent();

	return 1;
}

sub _getServiceLabel {
    my $SID = shift;

    my $services = S_get_contents_of_hash( [ 'Mapping_DIAG', 'PRJ_SUPPORTED_SERVICES' ] );

    foreach my $serv ( keys %$services ) {
        return $serv if ( $services->{$serv} eq $SID );
    }
}

sub _getSupportedSessionsForRequest {
    my $reqLabel = shift;

    return GDCOM_getRequestInfofromMapping ($reqLabel)->{'allowed_in_sessions'};
}

sub _getProtocolForRequest {
    my $reqLabel = shift;

    return GDCOM_getRequestInfofromMapping ($reqLabel)->{'protocol'};
}

sub _getSecurityLevelsForRequest {
    my $reqLabel = shift;

    return GDCOM_getRequestInfofromMapping ($reqLabel)->{'allowed_in_securitylevels'};
}

sub _getSupportedSessionsForService {
    my $service = shift;

    my @allSessionsForService;
    foreach my $request ( keys( %{ S_get_contents_of_hash( [ 'Mapping_DIAG', 'Requests_Responses' ] ) } ) ) {

        #trace through Diag mapping file check for all the requests for service under test.
        if ( $request =~ /\Q$service\E_/ ) {
            next if ( _getProtocolForRequest ($request) ne 'UDS' );

            foreach my $session ( @{ _getSupportedSessionsForRequest ($request) } ) {
                unless ( grep { $_ eq $session } @allSessionsForService ) {
                    push( @allSessionsForService, $session );
                }
            }
        }
    }

    return \@allSessionsForService;
}

sub _fillRequestInputParameters {
    my $SID = shift;
    my $subFunc = shift;
    

    if($SID eq '27'){
        $DataValue{'Key'} = $tcpar_Key{$subFunc};
    }
    elsif($SID eq '28'){
        $DataValue{'CommunicationType'} = $tcpar_CommunicationType{$subFunc};
    }
    elsif($SID eq '2E'){
        $DataValue{'Data'} = $tcpar_Data{$subFunc};
    }
    elsif($SID eq '2F'){
        $DataValue{'IOControlState'} = $tcpar_IOControlState{$subFunc};
    }
    elsif($SID eq '2F'){
        $DataValue{'IOControlState'} = $tcpar_IOControlState{$subFunc};
    }
    elsif($SID eq '31'){
        $DataValue{'RoutineControlOption'} = $tcpar_RoutineControlOption{$subFunc};
    }

}


1;
