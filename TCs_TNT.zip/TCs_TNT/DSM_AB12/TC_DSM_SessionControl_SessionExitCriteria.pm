#### TEST CASE MODULE
package TC_DSM_SessionControl_SessionExitCriteria;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.7 $;
our $HEADER = q$Header: DSM_AB12/TC_DSM_SessionControl_SessionExitCriteria.pm 1.7 2018/12/22 16:23:07ICT Nguyen Van Truc (RBVH/EPS24) (GNR2HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_SessionControl
#TS version in DOORS: 0.2
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
use LIFT_labcar;
use GENERIC_DCOM;
use LIFT_evaluation;
use LIFT_DCOM;
use LIFT_can_access;
use LIFT_PD;
#include further modules here

##################################

our $PURPOSE = "This test case is to to verify the Exit Criteria from any Non-Default Session.";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_SessionControl_SessionExitCriteria

=head1 PURPOSE

TThis test case is to to verify the Exit Criteria from any Non-Default Session.

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Set Addressing Mode and Protocol

2. Send request to enter <Session>

3. Read the active session by sending <ReadActiveSession>

4. Create <Condition> and wait for 6 seconds

5. Read the active session by sending <ReadActiveSession>

# Repeat the above steps for all supported Addressing modes as defined in the SPR


I<B<Evaluation>>

1. 

2. Positive response is observed

 

3. Observe positive response and in the last byte <Session> should be reported.

4.

5. Defualt session should be reported 


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Purpose' => 
	SCALAR 'Session' => 
	SCALAR 'Condition' => 
	SCALAR 'ReadActiveSession' => 


=head2 PARAMETER EXAMPLES

	Purpose  = 'To check session exit criteria for non-default sessions'
	
	
	Session =  '<Test Heading Head>'
	Condition = '<Test Heading Tail>'
	ReadActiveSession =  'TBD'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_Session;
my $tcpar_Condition;
my $tcpar_ReadActiveSession;
my $tcpar_PR_ActiveSession_ByteNbr;
my $tcpar_ActiveSession;


################ global parameter declaration ###################
#add any global variables here


###############################################################

sub TC_set_parameters {

	$tcpar_Purpose =  GEN_Read_mandatory_testcase_parameter( 'Purpose' );
	$tcpar_Session =  GEN_Read_mandatory_testcase_parameter( 'Session' );
	$tcpar_Condition =  GEN_Read_mandatory_testcase_parameter( 'Condition' );
	$tcpar_ReadActiveSession =  GEN_Read_mandatory_testcase_parameter( 'ReadActiveSession' );
	$tcpar_PR_ActiveSession_ByteNbr = GEN_Read_mandatory_testcase_parameter('PR_ActiveSession_ByteNbr');
	$tcpar_ActiveSession =  GEN_Read_mandatory_testcase_parameter( 'ActiveSession' );
	

	return 1;
}

sub TC_initialization {

	S_teststep("StandardPrepNoFault", 'AUTO_NBR');
	#    GEN_StandardPrepNoFault();
	DIAG_ECUReset_NOVERDICT ();
	S_wait_ms ('TIMER_ECU_READY', 'wait after reset');
	PD_ReadFaultMemory_NOERROR();
	
	GDCOM_start_CyclicTesterPresent();
	GDCOM_set_addressing_mode('physical');
	S_wait_ms (100);

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Send request to enter '$tcpar_Session'", 'AUTO_NBR', "StartActiveSession");			#measurement 1
	my $session_Response = DIAG_StartSession($tcpar_Session);
	S_teststep_expected('Positive Response shall be obtained',"StartActiveSession");			
	S_teststep_detected("Obtained Response is '$session_Response'","StartActiveSession");
	if($tcpar_Session eq 'ProgrammingSession'){
		S_wait_ms('4000','To enter in a Programming Session');
	}
	S_teststep("Read the active session by sending '$tcpar_ReadActiveSession'", 'AUTO_NBR', "ReadActiveSession");			#measurement 2
	my $session_Response = ReadActiveSession ();
	my @activesession_res_1 = split( / / , $session_Response);# Split all the response bytes of Step1 to array
	EVAL_evaluate_value ( 'ReadActiveSession' , $activesession_res_1[$tcpar_PR_ActiveSession_ByteNbr], '==', $tcpar_ActiveSession );
	S_teststep_expected("Current session shall be '$tcpar_ActiveSession'.","ReadActiveSession");			
	S_teststep_detected("Session obtained $activesession_res_1[$tcpar_PR_ActiveSession_ByteNbr]","ReadActiveSession");
	
	S_teststep("Create '$tcpar_Condition' ", 'AUTO_NBR',"DefaultSessionRequest");
	if($tcpar_Condition  =~ m/DefaultSessionRequest/i){
		my $session_Response = DIAG_StartSession('DefaultSession');
		S_teststep_expected('Positive Response shall be obtained',"DefaultSessionRequest");			
		S_teststep_detected("Obtained Response is '$session_Response'","DefaultSessionRequest");
		S_wait_ms(2000,"To Enter in a $tcpar_Condition");
	}elsif($tcpar_Condition  =~ m/SessionTimeout/i){
		GDCOM_stop_CyclicTesterPresent(); 								 #To create Session Timeout
		S_wait_ms(6000,'Wait for more than 6 sec for session Timeout');
		GDCOM_start_CyclicTesterPresent();
		S_wait_ms (100);
	}elsif($tcpar_Condition  =~ m/ServerReset/i){
		DIAG_ECUReset();
		S_wait_ms(8000,'Wait for more than 5 sec for ServerReset');
		
	}else{
		S_set_error("$tcpar_Condition is not Valid. Testcase will be aborted");
		return ;
	}
	
	S_teststep("Read the active session by sending '$tcpar_ReadActiveSession'", 'AUTO_NBR', "ReadDefaultSession");			#measurement 3
	my $session_Response = ReadActiveSession ();
	my @activesession_res_1 = split( / / , $session_Response);# Split all the response bytes of Step1 to array
	EVAL_evaluate_value ( 'ReadDefaultSession' , $activesession_res_1[$tcpar_PR_ActiveSession_ByteNbr], '==', '01' );
	S_teststep_expected("Current session shall be Default Session","ReadDefaultSession");			
	S_teststep_detected("Session obtained $activesession_res_1[$tcpar_PR_ActiveSession_ByteNbr]","ReadDefaultSession");
		
	return 1;
}

sub TC_evaluation {

	S_w2rep("Evaluation is done above in stimulation_and_measurement");

	return 1;
}

sub TC_finalization {
	GDCOM_stop_CyclicTesterPresent();
	return 1;
}

sub ReadActiveSession {
	
	if($tcpar_ReadActiveSession =~ m/rb_/i){ #read from SW variable
		return DIAG_ReadActiveSession_SW_var ( $tcpar_ReadActiveSession );
	}
	else{
		return GDCOM_request_general("REQ_".$tcpar_ReadActiveSession,"PR_".$tcpar_ReadActiveSession);
	}
}

1;
