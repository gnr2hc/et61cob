#### TEST CASE MODULE
package TC_DSM_SessionControl_InvalidSubfunction;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.3 $;
our $HEADER = q$Header: DSM_AB12/TC_DSM_SessionControl_InvalidSubfunction.pm 1.3 2018/04/24 17:59:36ICT ver6cob develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_SessionControl
#TS version in DOORS: 0.2
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use GENERIC_DCOM;
use LIFT_DCOM;
use LIFT_labcar; 
use LIFT_evaluation;
use LIFT_CD;
use LIFT_PD;
##################################

our $PURPOSE = "To verify that ECU remains in current session if invalid session is requested";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_SessionControl_InvalidSubfunction

=head1 PURPOSE

To verify that ECU remains in current session if invalid session is requested

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Set Addressing Mode and Protocol

2. Transmit Tester Present periodically at 4.5 sec cycle time

3. Request <ValidSession>

4. Request <InvalidSession>

5. Read the active session by sending <ReadActiveSession>

# Repeat the above steps for all supported Addressing modes as defined in the SPR


I<B<Evaluation>>

1.

2.

3. ECU sends Positive response

4. ECU sends Negative response with NRC 12 (subfunction not supported) response.

5. ECU sends Positive Response and session reported is <ActiveSession>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Purpose' => 
	SCALAR 'ValidSession' => 
	SCALAR 'InvalidSession' => 
	SCALAR 'ReadActiveSession' => 
	SCALAR 'ActiveSession' => 


=head2 PARAMETER EXAMPLES

	Purpose  = 'To verify that ECU remains in current session if invalid session is requested'
	
	ValidSession	= '<Test Heading Head>'
	InvalidSession	= 25 # 'TBD' - Project Dependent
	ReadActiveSession =  'ReadDataByIdentifier_ActiveDiagnosticSession'
	ActiveSession	= '<Test Heading Head>'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_ValidSession;
my $tcpar_InvalidSession;
my $tcpar_ReadActiveSession;
my $tcpar_PR_ActiveSession_ByteNbr;
################ global parameter declaration ###################
#add any global variables here
my $ActiveSession;
my $Response_NRC;
my $request_invalid;
my $Response_Invalid; 
my @Session_Response;
my $Addressing_Mode;
my $msgID;
my $CycleTime = 4500;
my $msg_aref = [0x02,0x3E,0x80,0x00,0x00,0x00,0x00,0x00];
my $TP_handle;
my $mode;
my %Session_Active = (
	'DefaultSession'     => '01',
	'ProgrammingSession' => '02',
	'ExtendedSession'    => '03',
);
###############################################################

sub TC_set_parameters {

	$tcpar_Purpose =  GEN_Read_mandatory_testcase_parameter( 'Purpose' );
	$tcpar_ValidSession =  GEN_Read_mandatory_testcase_parameter( 'ValidSession' );
	$tcpar_InvalidSession =  GEN_Read_mandatory_testcase_parameter( 'InvalidSession' );
	$tcpar_ReadActiveSession =  GEN_Read_mandatory_testcase_parameter( 'ReadActiveSession' );
	$tcpar_PR_ActiveSession_ByteNbr = GEN_Read_mandatory_testcase_parameter('PR_ActiveSession_ByteNbr');

	return 1;
}

sub TC_initialization {

	S_teststep("StandardPrepNoFault", 'AUTO_NBR');
	#    GEN_StandardPrepNoFault();
	DIAG_ECUReset_NOVERDICT ();
	S_wait_ms ('TIMER_ECU_READY', 'wait after reset');
	PD_ReadFaultMemory_NOERROR();
	
	# GDCOM_start_CyclicTesterPresent();
	# GDCOM_set_addressing_mode('physical');

	return 1;
}

sub TC_stimulation_and_measurement {
	
	#Get addressing mode supported for request from Mapping Diag
    $Addressing_Mode = GDCOM_getRequestInfofromMapping ('DiagnosticSessionControl_' .$tcpar_ValidSession)->{'allowed_in_addressingmodes'};
    S_teststep("# Repeat the above steps for all supported Addressing modes as defined in the SPR", 'AUTO_NBR');
	foreach $mode (@$Addressing_Mode) {
	S_teststep( "Set Addressing Mode to: '$mode'", 'AUTO_NBR' );
		GDCOM_set_addressing_mode($mode);
	
	S_teststep("Transmit Tester Present periodically at 4.5 sec cycle time", 'AUTO_NBR');
	if ( $mode =~ /physical/i ) { 
			$msgID = $LIFT_PROJECT::Defaults->{"CUSTOMER_DIAGNOSIS"}{'RequestID_physical'};
		}
	if ( $mode =~ /functional/i ) {
			$msgID = $LIFT_PROJECT::Defaults->{"CUSTOMER_DIAGNOSIS"}{'RequestID_functional'};
		}
	  $TP_handle =  GDCOM_start_CyclicTesterPresent($msg_aref,$msgID,$CycleTime );
	  S_wait_ms(100); 
	
	S_teststep("Request 10 '$tcpar_ValidSession'", 'AUTO_NBR', "request_validsession_in_$mode");			#measurement 1
	my $Response_Valid = GDCOM_request_general( 'REQ_DiagnosticSessionControl_' . $tcpar_ValidSession, 'PR_DiagnosticSessionControl_' . $tcpar_ValidSession );
	S_teststep_expected("ECU sends Positive response","request_validsession_in_$mode");			#evaluation 1
	S_teststep_detected("Response from ECU is: $Response_Valid ","request_validsession_in_$mode");
	
	S_teststep("Request 10 '$tcpar_InvalidSession'", 'AUTO_NBR', "request_invalidsession_in_$mode");			#measurement 2
	 my $NRCInfo = GDCOM_getNRCfromMapping( 'DiagnosticSessionControl', 'NR_subFunctionNotSupported' );
	 $request_invalid='10 '.$tcpar_InvalidSession; #DID invalid session 09 11 23 34...
		if ( $mode =~ /physical/ ) { 
		# $Response_Invalid = DCOM_request($request_invalid,$Response_NRC,'relax');
		$Response_Invalid= GDCOM_request($request_invalid, $NRCInfo->{'Response'} ,'strict');
	S_teststep_expected("ECU sends Negative response with  NRC12 (subfunction not supported) ", "request_invalidsession_in_$mode");			#evaluation 2
	S_teststep_detected("Response from ECU is $Response_Invalid ", "request_invalidsession_in_$mode");
		}
	if ( $mode =~ /functional/ ) {
		 $Response_Invalid= GDCOM_request($request_invalid, $NRCInfo->{'Response'} ,'quiet');
	 S_teststep_expected("No response obtained from ECU", "request_invalidsession_in_$mode");			#evaluation 2
     S_teststep_detected("No response ", "request_invalidsession_in_$mode");
		}
	S_teststep("Read the active session by sending '$tcpar_ReadActiveSession'", 'AUTO_NBR', "read_the_activess_in_$mode");			#measurement 3
	 $ActiveSession = ReadActiveSession ();
	 @Session_Response = split( / /, $ActiveSession );
	S_teststep_expected( "ECU sends Positive Response and session reported is $Session_Active{$tcpar_ValidSession} ", "read_the_activess_in_$mode"	);                                               #evaluation 3
	S_teststep_detected( "ECU response is $Session_Response[$tcpar_PR_ActiveSession_ByteNbr]", "read_the_activess_in_$mode" );
	EVAL_evaluate_value( "Active Session",	$Session_Response[$tcpar_PR_ActiveSession_ByteNbr],	'==', $Session_Active{$tcpar_ValidSession} );

    GDCOM_stop_CyclicTesterPresent($TP_handle);
	}
	return 1;
}

sub TC_evaluation {

 S_w2rep("Evaluation is done above in stimulation_and_measurement");
	return 1;
}

sub TC_finalization {

	return 1;
}

sub ReadActiveSession {
	
	if($tcpar_ReadActiveSession =~ m/rb_/i){ #read from SW variable
		return DIAG_ReadActiveSession_SW_var ( $tcpar_ReadActiveSession );
	}
	else{
		return GDCOM_request_general("REQ_".$tcpar_ReadActiveSession,"PR_".$tcpar_ReadActiveSession);
	}
}


1;
