#### TEST CASE MODULE
package TC_DSM_NRC_ServiceNotSupportedInActiveSession;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.5 $;
our $HEADER  = q$Header: DSM_AB12/TC_DSM_NRC_ServiceNotSupportedInActiveSession.pm 1.5 2019/08/20 14:58:10ICT Nguyen Van Truc (RBVH/EPS24) (GNR2HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_NegativeResponseCodes
#TS version in DOORS: 0.1
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use GENERIC_DCOM;
use LIFT_PD;
##################################

our $PURPOSE = "To check for NRC 7F or no response if service is not supported in active session";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_NRC_ServiceNotSupportedInActiveSession

=head1 PURPOSE

To check for NRC 7F or no response if service is not supported in active session

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Enter a session in which the service is not supported (check in SPR/Mapping_DIAG)

2. Send <Request> in physical addressing mode

3. Send <Request> in functional addressing mode

4. Repeat the above steps for different sessions in which the service is not supported


I<B<Evaluation>>

1. -

2. <Response> is received

3. <Response> is received if <SUPPRESS_NRC_7F> is 'no'. Else no response is received

4. Same as above steps


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Request' => 
	SCALAR 'Purpose' => 
	SCALAR 'Response' => 
	SCALAR 'SUPPRESS_NRC_7F' => 


=head2 PARAMETER EXAMPLES

	Purpose = 'To check for NRC 7F or no response if service is not supported in active session'
	Response = 'NR_serviceNotSupportedInActiveSession'
	SUPPRESS_NRC_7F = 'yes' #or 'no' (See HLD Notes)
	Request = 'DiagnosticSessionControl_DefaultSession'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_Response;
my $tcpar_SUPPRESS_NRC_7F;
my $tcpar_Request;
my @tcpar_NotSupportedSessions;

################ global parameter declaration ###################
#add any global variables here
my %DataValue;

###############################################################

sub TC_set_parameters {

    $tcpar_Purpose         = GEN_Read_mandatory_testcase_parameter('Purpose');
    $tcpar_Response        = GEN_Read_mandatory_testcase_parameter('Response');
    $tcpar_SUPPRESS_NRC_7F = GEN_Read_mandatory_testcase_parameter('SUPPRESS_NRC_7F');
    $tcpar_Request         = GEN_Read_mandatory_testcase_parameter('Request');
	@tcpar_NotSupportedSessions = GEN_Read_mandatory_testcase_parameter('NotSupportedSessions');

    return 1;
}

sub TC_initialization {
	
	if(scalar @tcpar_NotSupportedSessions){
		S_teststep( "\nStandardPrepNoFault\n", 'NO_AUTO_NBR' );
		DIAG_ECUReset_NOVERDICT ();
		S_wait_ms ('TIMER_ECU_READY', 'wait after reset');
		
		PD_ReadFaultMemory_NOERROR();
		
	    GDCOM_start_CyclicTesterPresent();
	    S_wait_ms(500);
	    
	    GDCOM_set_addressing_mode('physical');
	}

    return 1;
}

sub TC_stimulation_and_measurement {

    S_teststep( "Enter a session in which the service is not supported (check in SPR/Mapping_DIAG)", 'NO_AUTO_NBR' );
    
    unless(scalar @tcpar_NotSupportedSessions){ #no not supported sessions
        S_teststep( "There is no session in which service '$tcpar_Request' is not supported. Not proceeding!\n", 'AUTO_NBR', 'NO_EVAL' );
        S_teststep_expected( "No evaluation", 'NO_EVAL' );
        S_teststep_detected( "There is no session in which service '$tcpar_Request' is not supported. No evaluation", 'NO_EVAL' );
        return 1;
    }

	#Repeat steps for different sessions in which the service is not supported
    foreach my $session (@tcpar_NotSupportedSessions) {
        S_w2rep ("************* Session: $session *************", 'orange');
        
        if ($session =~ m/safety|disposal/i){
        	S_teststep( "$session is not handled in this test case", 'NO_AUTO_NBR' );
        	return 1;
        }
        else{
        	S_teststep( "Enter session: $session", 'AUTO_NBR' );
	        DIAG_StartSession($session);
	        S_wait_ms (5000, 'wait after session entry') if($session =~ m/prog|boot/i);
	    
	        S_teststep( "Send service $tcpar_Request in physical addressing mode", 'AUTO_NBR', "send_request_phys_$session" );    #measurement 1
	        GDCOM_set_addressing_mode('physical');
	        
			my $response_phys = GDCOM_request( $tcpar_Request, "7F $tcpar_Request 7F", 'strict'  );
	
	        S_teststep_expected( "7F $tcpar_Request 7F", "send_request_phys_$session" );                                  #evaluation 1
	        S_teststep_detected( " ".$response_phys, "send_request_phys_$session" );
	
	        S_teststep( "Send service $tcpar_Request in functional addressing mode", 'AUTO_NBR', "send_request_func_$session" );    #measurement 2
	        GDCOM_set_addressing_mode('functional');
	
	        if ( $tcpar_SUPPRESS_NRC_7F eq 'no' ) {
	            my $response_func = GDCOM_request( $tcpar_Request, "7F $tcpar_Request 7F", 'strict'  );
	
	            S_teststep_expected( "7F $tcpar_Request 7F", "send_request_func_$session" );                                  #evaluation 2
	            S_teststep_detected( " ".$response_func, "send_request_func_$session" );
	        }
	        else { #no response expected
	            my $response_func = GDCOM_request( $tcpar_Request, "", 'quiet' );
	
	            S_teststep_expected( "no response", "send_request_func_$session" );                                           #evaluation 2
	            S_teststep_detected( "-". $response_func, "send_request_func_$session" );
	        }
	        
	        DIAG_ECUReset () if($session =~ m/prog|boot/i);
			S_wait_ms ('TIMER_ECU_READY', 'wait after reset');  
        }
        
        
        S_teststep( "\n", 'NO_AUTO_NBR' ); #newline for steps in TR
    }

    return 1;
}

sub TC_evaluation {

    S_w2rep("Evaluation is done above in stimulation_and_measurement");

    return 1;
}

sub TC_finalization {

    GDCOM_stop_CyclicTesterPresent() if(scalar @tcpar_NotSupportedSessions);

    return 1;
}




1;
