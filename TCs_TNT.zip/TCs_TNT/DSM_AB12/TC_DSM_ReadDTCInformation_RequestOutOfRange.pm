#### TEST CASE MODULE
package TC_DSM_ReadDTCInformation_RequestOutOfRange;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.2 $;
our $HEADER  = q$Header: DSM_AB12/TC_DSM_ReadDTCInformation_RequestOutOfRange.pm 1.2 2017/10/25 16:55:47ICT ver6cob develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_ReadDTCInformation
#TS version in DOORS: 4.9
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use GENERIC_DCOM;
##################################

our $PURPOSE = "to check for NRC 31 for 19 service";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_ReadDTCInformation_RequestOutOfRange

=head1 PURPOSE

to check for NRC 31 for 19 service

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Send <ReportDTCRecordByDTCNumber> for <DTC> with <DTCRecordNumber> in physical addressing mode

2. Send <ReportDTCRecordByDTCNumber> for <DTC> with <DTCRecordNumber> in functional addressing mode


I<B<Evaluation>>

1. NRC31 - RequestOutOfRange is received

2. No response is received


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	LIST 'DTC' => 
	SCALAR 'purpose' => 
	SCALAR 'ReportDTCRecordByDTCNumber' => 
	LIST 'DTCRecordNumber' => 


=head2 PARAMETER EXAMPLES

	purpose = 'to check that NRC 31 is received for 19 04, 19 06 services for invalid/not supported values of DTCMaskRecord, DTCRecordNumber,  DTCExtendedDataRecordNumber' 
	# input parameters
	ReportDTCRecordByDTCNumber = 'ReadDTCInformation_ReportDTCRecordByDTCNumber'
	DTCRecordNumber = @('01')
	#output parameters
	DTC = @('00 00 00', 'FF FF FF', 'AB CD EF')

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_ReportDTCRecordByDTCNumber;
my @tcpar_DTCRecordNumber;
my @tcpar_DTC;

################ global parameter declaration ###################
#add any global variables here

###############################################################

sub TC_set_parameters {

    $tcpar_purpose                    = GEN_Read_mandatory_testcase_parameter('purpose');
    $tcpar_ReportDTCRecordByDTCNumber = GEN_Read_mandatory_testcase_parameter('ReportDTCRecordByDTCNumber');
    @tcpar_DTCRecordNumber            = GEN_Read_mandatory_testcase_parameter('DTCRecordNumber');
    @tcpar_DTC                        = GEN_Read_mandatory_testcase_parameter('DTC');

    return 1;
}

sub TC_initialization {

    S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
    GEN_StandardPrepNoFault();

    GDCOM_start_CyclicTesterPresent();

    return 1;
}

sub TC_stimulation_and_measurement {

    my %DataValue;

    foreach my $DTCRecordNumber (@tcpar_DTCRecordNumber) {

        foreach my $DTC (@tcpar_DTC) {

            $DataValue{'DTC'} = $DTC;
            if ( $tcpar_ReportDTCRecordByDTCNumber =~ m/snapshot/i ) {
                $DataValue{'DTCSnapshotRecordNumber'} = $DTCRecordNumber;
            }
            elsif ( $tcpar_ReportDTCRecordByDTCNumber =~ m/ext/i ) {
                $DataValue{'DTCExtendedDataRecordNumber'} = $DTCRecordNumber;
            }


            S_teststep( "Send '$tcpar_ReportDTCRecordByDTCNumber' for DTC $DTC with DTCRecordNumber '$DTCRecordNumber' in physical addressing mode", 'AUTO_NBR', "send_ReportDTCRecordByDTCNumber_phys_$DTC"."_$DTCRecordNumber" );    #measurement 1
            GDCOM_set_addressing_mode('physical');
            my $response_physical = GDCOM_request_general( "REQ_" . $tcpar_ReportDTCRecordByDTCNumber, 'NR_requestOutOfRange', \%DataValue );

            S_teststep_expected( "NRC31 is received", "send_ReportDTCRecordByDTCNumber_phys_$DTC"."_$DTCRecordNumber" );                                                                                                        #evaluation 1
            S_teststep_detected( "response = $response_physical", "send_ReportDTCRecordByDTCNumber_phys_$DTC"."_$DTCRecordNumber" );


            S_teststep( "Send '$tcpar_ReportDTCRecordByDTCNumber' for DTC $DTC with DTCRecordNumber '$DTCRecordNumber' in functional addressing mode", 'AUTO_NBR', "send_ReportDTCRecordByDTCNumber_func_$DTC"."_$DTCRecordNumber" );    #measurement 2
            GDCOM_set_addressing_mode('functional');
            my $requestBytes = GDCOM_getRequestLabelValue( "REQ_" . $tcpar_ReportDTCRecordByDTCNumber, \%DataValue );
            my $response_functional = GDCOM_request( $requestBytes, "", 'quiet' );

            S_teststep_expected( "No response", "send_ReportDTCRecordByDTCNumber_func_$DTC"."_$DTCRecordNumber" );                                                                                                                #evaluation 2
            S_teststep_detected( "-" . $response_functional, "send_ReportDTCRecordByDTCNumber_func_$DTC"."_$DTCRecordNumber" );
        }

    }

    return 1;
}

sub TC_evaluation {

    S_w2rep("Evaluation is done above in stimulation_and_measurement");

    return 1;
}

sub TC_finalization {

    GDCOM_stop_CyclicTesterPresent();

    return 1;
}

1;
