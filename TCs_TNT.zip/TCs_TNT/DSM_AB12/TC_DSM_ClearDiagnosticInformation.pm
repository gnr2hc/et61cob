#### TEST CASE MODULE
package TC_DSM_ClearDiagnosticInformation;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.3 $;
our $HEADER  = q$Header: DSM_AB12/TC_DSM_ClearDiagnosticInformation.pm 1.3 2017/11/22 14:23:47ICT ver6cob develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_ClearDiagnosticInformation
#TS version in DOORS: 4.9
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use GENERIC_DCOM;
use LIFT_CD;
use LIFT_evaluation;
##################################

our $PURPOSE = "to check that service 14 resets/clears diagnostic information like DTC status byte, DTC snapshot data, DTC extended data";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_ClearDiagnosticInformation

=head1 PURPOSE

to check that service 14 resets/clears diagnostic information like DTC status byte, DTC snapshot data, DTC extended data

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault

Set <AddressingMode>, Enter <Session>


I<B<Stimulation and Measurement>>

1. Create <Faults> and wait for qualification time

2. Send request <ReadDTCInformation> for <Faults>

3. Send request <ClearDiagnosticInformation> and wait for 10 sec

4. Send request <ReadDTCInformation> for <Faults>

5. Remove (dequalify) the faults created in step 1 and wait for dequalification time

6. Send request <ClearDiagnosticInformation> and wait for 10 sec

7. Send request <ReadDTCInformation> for <Faults>


I<B<Evaluation>>

1. -

2. Positive response with <DTC_Status_Active> for 19 02 request.

Positive response with <DTC_RecordStatus_Active> for 19 04/19 06 request.

3. Positive response is received

4. Same as step 2

5. -

6. Positive response is received

7. Positive response with <DTC_Status_AfterClear> for 19 02 request.

Positive response with <DTC_RecordStatus_AfterClear> for 19 04/19 06 request.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'ReadDTCInformation' => 
	SCALAR 'StatusMask' => 
	SCALAR 'ClearDiagnosticInformation' => 
	SCALAR 'FaultToClear' => 
	HASH 'DTC_Status_Active' => 
	HASH 'DTC_Status_AfterClear' => 
	SCALAR 'purpose' => 
	SCALAR 'AddressingMode' => 
	SCALAR 'Session' => 
	LIST 'Faults' => 


=head2 PARAMETER EXAMPLES

	purpose = 'to check that service 19 0A reports all DTCs supported by the project with the corresponding statuses' 
	# input parameters
	AddressingMode = 'physical'
	Session = 'DefaultSession'
	Faults = @('rb_sqm_SquibResistanceOpenAB1FD_flt', 'rb_sqm_SquibResistanceOpenAB1FP_flt')
	#output parameters
	ReadDTCInformation = 'ReadDTCInformation_ReportDtcsByStatusMask'
	StatusMask = '08'
	ClearDiagnosticInformation = 'ClearDTCInformation_ClearIndividualDTC'
	FaultToClear = 'rb_sqm_SquibResistanceOpenAB1FP_flt' #individual fault to be cleared	
	DTC_Status_Active = %('rb_sqm_SquibResistanceOpenAB1FD_flt' => '0bxxxx1xx1', 'rb_sqm_SquibResistanceOpenAB1FP_flt' => '0bxxxx1xx1')
	DTC_Status_AfterClear = %('rb_sqm_SquibResistanceOpenAB1FD_flt' => '0bxxxx1xx0', 'rb_sqm_SquibResistanceOpenAB1FP_flt' => 'NotReported')

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_AddressingMode;
my $tcpar_Session;
my @tcpar_Faults;
my $tcpar_ReadDTCInformation;
my $tcpar_StatusMask;
my $tcpar_DTCSnapshotRecordNumber;
my $tcpar_DTCExtendedDataRecordNumber;
my $tcpar_ClearDiagnosticInformation;
my $tcpar_FaultToClear;
my %tcpar_DTC_Status_Active;
my %tcpar_DTC_Status_AfterClear;
my %tcpar_DTC_RecordStatus_Active;
my %tcpar_DTC_RecordStatus_AfterClear;

################ global parameter declaration ###################
#add any global variables here

###############################################################

sub TC_set_parameters {

    $tcpar_purpose                     = GEN_Read_mandatory_testcase_parameter('purpose');
    $tcpar_AddressingMode              = GEN_Read_mandatory_testcase_parameter('AddressingMode');
    $tcpar_Session                     = GEN_Read_mandatory_testcase_parameter('Session');
    @tcpar_Faults                      = GEN_Read_mandatory_testcase_parameter('Faults');
    $tcpar_ReadDTCInformation          = GEN_Read_mandatory_testcase_parameter('ReadDTCInformation');
    $tcpar_StatusMask                  = GEN_Read_optional_testcase_parameter('StatusMask');
    $tcpar_DTCSnapshotRecordNumber     = GEN_Read_optional_testcase_parameter('DTCSnapshotRecordNumber');
    $tcpar_DTCExtendedDataRecordNumber = GEN_Read_optional_testcase_parameter('DTCExtendedDataRecordNumber');
    $tcpar_ClearDiagnosticInformation  = GEN_Read_mandatory_testcase_parameter('ClearDiagnosticInformation');
    $tcpar_FaultToClear                = GEN_Read_optional_testcase_parameter('FaultToClear');
    %tcpar_DTC_Status_Active           = GEN_Read_optional_testcase_parameter('DTC_Status_Active');
    %tcpar_DTC_Status_AfterClear       = GEN_Read_optional_testcase_parameter('DTC_Status_AfterClear');
    %tcpar_DTC_RecordStatus_Active     = GEN_Read_optional_testcase_parameter('DTC_RecordStatus_Active');
    %tcpar_DTC_RecordStatus_AfterClear = GEN_Read_optional_testcase_parameter('DTC_RecordStatus_AfterClear');

    return 1;
}

sub TC_initialization {

    S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
    GEN_StandardPrepNoFault();
    GDCOM_start_CyclicTesterPresent();

    S_teststep( "Set Addressing mode: '$tcpar_AddressingMode', Enter session: '$tcpar_Session'", 'AUTO_NBR' );
    GDCOM_set_addressing_mode($tcpar_AddressingMode);
    DIAG_StartSession($tcpar_Session);

    return 1;
}

sub TC_stimulation_and_measurement {

    my %DataValue_19;
    $DataValue_19{'StatusMask'}                  = $tcpar_StatusMask;
    $DataValue_19{'DTCSnapshotRecordNumber'}     = $tcpar_DTCSnapshotRecordNumber;
    $DataValue_19{'DTCExtendedDataRecordNumber'} = $tcpar_DTCExtendedDataRecordNumber;

    my %DataValue_14;
    $DataValue_14{'DTC'} = CD_get_FaultDTC($tcpar_FaultToClear) if (defined $tcpar_FaultToClear);
    $DataValue_14{'DTC'} =~ s/(\w{2})/$1 /g; #inserts a space after every 2 characters 
	$DataValue_14{'DTC'} =~ s/\s+$//; #remove whitespace at end

    S_teststep( "Create faults: @tcpar_Faults and wait for qualification time", 'AUTO_NBR' );
    foreach (@tcpar_Faults) {
        FM_createFault($_);
    }
    S_wait_ms( 10000, 'wait for qualification time' );

    S_teststep( "Send request '$tcpar_ReadDTCInformation' for faults @tcpar_Faults", 'AUTO_NBR', 'send_request_readdtcinformation_A' );    #measurement 1
    if ($tcpar_ReadDTCInformation =~ m/ext|snapshot/i){ #19 04/06
        foreach my $fault (@tcpar_Faults){
            $DataValue_19{'DTC'} = CD_get_FaultDTC($fault);
            $DataValue_19{'DTC'} =~ s/(\w{2})/$1 /g; #inserts a space after every 2 characters
			$DataValue_19{'DTC'} =~ s/\s+$//; #remove whitespace at end
            S_teststep_2nd_level( "$tcpar_ReadDTCInformation for fault $fault with DTC $DataValue_19{'DTC'}", 'AUTO_NBR', "send_request_readafterqualify_$fault" );
            my $response_readafterqualify = GDCOM_request_general( "REQ_" . $tcpar_ReadDTCInformation, "PR_" . $tcpar_ReadDTCInformation, \%DataValue_19 );  
            my $numOfBytes = scalar split / /, $response_readafterqualify;
            
            if ( $tcpar_DTC_RecordStatus_Active{$fault} =~ m/NoSnapshotRecord|NoExtendedDataRecord/i ) {
                EVAL_evaluate_value( "RecordStatus_Active", $numOfBytes, '==', 6 ); #only positive response bytes
                S_teststep_expected("Number of response bytes = 6 (No Record)", "send_request_readafterqualify_$fault");
            }
            else {
                my $exp_MinNumOfBytes; 
                $exp_MinNumOfBytes = 11 if ($tcpar_ReadDTCInformation =~ m/snapshot/i);
                $exp_MinNumOfBytes = 8 if ($tcpar_ReadDTCInformation =~ m/ext/i);

                EVAL_evaluate_value( "RecordStatus_Active", $numOfBytes, '>=', $exp_MinNumOfBytes ); #min 1 record reported
                S_teststep_expected("Number of response bytes >= $exp_MinNumOfBytes (Minimum 1 Record)", "send_request_readafterqualify_$fault");
            }

            S_teststep_detected("Number of response bytes = $numOfBytes", "send_request_readafterqualify_$fault");
        }
    }
    else{ #19 02
        #use the CD function to evaluate the DTCs and status bytes
        my $DTC_struct_afterqualify = CD_read_DTC( '02', $tcpar_StatusMask );
        foreach my $fault ( keys %tcpar_DTC_Status_Active ) {
            if ( $tcpar_DTC_Status_Active{$fault} =~ m/NotReported/i ) {
                my $status = CD_get_fault_status( $DTC_struct_afterqualify, $fault );
                EVAL_evaluate_value( "DTCStatus_Active", $status, '==', 0 );
    
                S_teststep_expected("$fault status = NotReported (0)", 'send_request_readdtcinformation_A');
                S_teststep_detected("$fault status = $status", 'send_request_readdtcinformation_A');
            }
            else {
                my $status = CD_get_fault_status( $DTC_struct_afterqualify, $fault );
                EVAL_evaluate_value( "DTCStatus_Active", $status, 'MASK', $tcpar_DTC_Status_Active{$fault} );
    
                S_teststep_expected("$fault status = $tcpar_DTC_Status_Active{$fault}", 'send_request_readdtcinformation_A');
                S_teststep_detected("$fault status = $status", 'send_request_readdtcinformation_A');
            }
        }
    }
    

    S_teststep( "Send request '$tcpar_ClearDiagnosticInformation' and wait for 10 sec", 'AUTO_NBR', 'send_request_cleardiagnosticinformation_A' );    #measurement 2
    my $response_clearafterqualify = GDCOM_request_general( "REQ_" . $tcpar_ClearDiagnosticInformation, "PR_" . $tcpar_ClearDiagnosticInformation, \%DataValue_14 );

    S_teststep_expected( "Positive response", 'send_request_cleardiagnosticinformation_A' );                                              #evaluation 2
    S_teststep_detected( "Response: $response_clearafterqualify", 'send_request_cleardiagnosticinformation_A' );

    S_wait_ms( 10000, 'wait for re-qualification time' );

    S_teststep( "Send request '$tcpar_ReadDTCInformation' for faults @tcpar_Faults", 'AUTO_NBR', 'send_request_readdtcinformation_B' );                    #measurement 3
    if ($tcpar_ReadDTCInformation =~ m/ext|snapshot/i){ #19 04/06
        foreach my $fault (@tcpar_Faults){
            $DataValue_19{'DTC'} = CD_get_FaultDTC($fault);
            $DataValue_19{'DTC'} =~ s/(\w{2})/$1 /g; #inserts a space after every 2 characters
			$DataValue_19{'DTC'} =~ s/\s+$//; #remove whitespace at end
            S_teststep_2nd_level( "$tcpar_ReadDTCInformation for fault $fault with DTC $DataValue_19{'DTC'}", 'AUTO_NBR', "send_request_readafterqualify_clear_$fault" );
            my $response_readafterqualify_clear = GDCOM_request_general( "REQ_" . $tcpar_ReadDTCInformation, "PR_" . $tcpar_ReadDTCInformation, \%DataValue_19 );  
            my $numOfBytes = scalar split / /, $response_readafterqualify_clear;
            
            if ( $tcpar_DTC_RecordStatus_Active{$fault} =~ m/NoSnapshotRecord|NoExtendedDataRecord/i ) {
                EVAL_evaluate_value( "RecordStatus_Active", $numOfBytes, '==', 6 ); #only positive response bytes
                S_teststep_expected("Number of response bytes = 6 (No Record)", "send_request_readafterqualify_clear_$fault");
            }
            else {
                my $exp_MinNumOfBytes; 
                $exp_MinNumOfBytes = 11 if ($tcpar_ReadDTCInformation =~ m/snapshot/i);
                $exp_MinNumOfBytes = 8 if ($tcpar_ReadDTCInformation =~ m/ext/i);

                EVAL_evaluate_value( "RecordStatus_Active", $numOfBytes, '>=', $exp_MinNumOfBytes ); #min 1 record reported
                S_teststep_expected("Number of response bytes >= $exp_MinNumOfBytes (Minimum 1 Record)", "send_request_readafterqualify_clear_$fault");
            }

            S_teststep_detected("Number of response bytes = $numOfBytes", "send_request_readafterqualify_clear_$fault");
        }
    }
    else{
        #use the CD function to evaluate the DTCs and status bytes
        my $DTC_struct_afterqualify_clear = CD_read_DTC( '02', $tcpar_StatusMask );
        foreach my $fault ( keys %tcpar_DTC_Status_Active ) {
            if ( $tcpar_DTC_Status_Active{$fault} =~ m/NotReported/i ) {
                my $status = CD_get_fault_status( $DTC_struct_afterqualify_clear, $fault );
                EVAL_evaluate_value( "DTCStatus_Active", $status, '==', 0 );
    
                S_teststep_expected("$fault status = NotReported (0)", 'send_request_readdtcinformation_B');
                S_teststep_detected("$fault status = $status", 'send_request_readdtcinformation_B');
            }
            else {
                my $status = CD_get_fault_status( $DTC_struct_afterqualify_clear, $fault );
                EVAL_evaluate_value( "DTCStatus_Active", $status, 'MASK', $tcpar_DTC_Status_Active{$fault} );
    
                S_teststep_expected("$fault status = $tcpar_DTC_Status_Active{$fault}", 'send_request_readdtcinformation_B');
                S_teststep_detected("$fault status = $status", 'send_request_readdtcinformation_B');
            }
        }
    }
    

    S_teststep( "Remove (dequalify) the faults created in step 1 and wait for dequalification time", 'AUTO_NBR' );
    foreach (@tcpar_Faults) {
        FM_removeFault($_);
    }
    S_wait_ms( 10000, 'wait for dequalification time' );

    S_teststep( "Send request '$tcpar_ClearDiagnosticInformation' and wait for 10 sec", 'AUTO_NBR', 'send_request_cleardiagnosticinformation_B' );    #measurement 4
    my $response_clearafterdequalify = GDCOM_request_general( "REQ_" . $tcpar_ClearDiagnosticInformation, "PR_" . $tcpar_ClearDiagnosticInformation, \%DataValue_14 );
    
    S_teststep_expected( "Positive response", 'send_request_cleardiagnosticinformation_B' );                                              #evaluation 4
    S_teststep_detected( "Response: $response_clearafterdequalify", 'send_request_cleardiagnosticinformation_B' );
    
    S_wait_ms( 10000, 'wait for qualification time' );

    S_teststep( "Send request '$tcpar_ReadDTCInformation' for faults @tcpar_Faults", 'AUTO_NBR', 'send_request_readdtcinformation_C' );                    #measurement 5
    if ($tcpar_ReadDTCInformation =~ m/ext|snapshot/i){ #19 04/06
        foreach my $fault (@tcpar_Faults){
            $DataValue_19{'DTC'} = CD_get_FaultDTC($fault);
            $DataValue_19{'DTC'} =~ s/(\w{2})/$1 /g; #inserts a space after every 2 characters
			$DataValue_19{'DTC'} =~ s/\s+$//; #remove whitespace at end
            S_teststep_2nd_level( "$tcpar_ReadDTCInformation for fault $fault with DTC $DataValue_19{'DTC'}", 'AUTO_NBR', "send_request_readafterclear_$fault" );
            my $response_readafterclear = GDCOM_request_general( "REQ_" . $tcpar_ReadDTCInformation, "PR_" . $tcpar_ReadDTCInformation, \%DataValue_19 );  
            my $numOfBytes = scalar split / /, $response_readafterclear;
            
            if ( $tcpar_DTC_RecordStatus_AfterClear{$fault} =~ m/NoSnapshotRecord|NoExtendedDataRecord/i ) {
                EVAL_evaluate_value( "RecordStatus_Active", $numOfBytes, '==', 6 ); #only positive response bytes
                S_teststep_expected("Number of response bytes = 6 (No Record)", "send_request_readafterclear_$fault");
            }
            else {
                my $exp_MinNumOfBytes; 
                $exp_MinNumOfBytes = 11 if ($tcpar_ReadDTCInformation =~ m/snapshot/i);
                $exp_MinNumOfBytes = 8 if ($tcpar_ReadDTCInformation =~ m/ext/i);

                EVAL_evaluate_value( "RecordStatus_Active", $numOfBytes, '>=', $exp_MinNumOfBytes ); #min 1 record reported
                S_teststep_expected("Number of response bytes >= $exp_MinNumOfBytes (Minimum 1 Record)", "send_request_readafterclear_$fault");
            }

            S_teststep_detected("Number of response bytes = $numOfBytes", "send_request_readafterclear_$fault");
        }
    }#    my $response_readafterclear = GDCOM_request_general( "REQ_" . $tcpar_ReadDTCInformation, "PR_" . $tcpar_ReadDTCInformation, \%DataValue_19 );
    else{
        my $DTC_struct_afterclear = CD_read_DTC( '02', $tcpar_StatusMask );
        foreach my $fault ( keys %tcpar_DTC_Status_AfterClear ) {
            if ( $tcpar_DTC_Status_AfterClear{$fault} =~ m/NotReported/i ) {
                my $status = CD_get_fault_status( $DTC_struct_afterclear, $fault );
                EVAL_evaluate_value( "DTCStatus_AfterClear", $status, '==', 0 );
    
                S_teststep_expected("$fault status = NotReported (0)", 'send_request_readdtcinformation_C');
                S_teststep_detected("$fault status = $status", 'send_request_readdtcinformation_C');
            }
            else {
                my $status = CD_get_fault_status( $DTC_struct_afterclear, $fault );
                EVAL_evaluate_value( "DTCStatus_AfterClear", $status, 'MASK', $tcpar_DTC_Status_AfterClear{$fault} );
    
                S_teststep_expected("$fault status = $tcpar_DTC_Status_AfterClear{$fault}", 'send_request_readdtcinformation_C');
                S_teststep_detected("$fault status = $status", 'send_request_readdtcinformation_C');
            }
        }
    }


    return 1;
}

sub TC_evaluation {

    S_w2rep("Evaluation is done above in stimulation_and_measurement");

    return 1;
}

sub TC_finalization {
    
    GDCOM_stop_CyclicTesterPresent();

    return 1;
}

1;
