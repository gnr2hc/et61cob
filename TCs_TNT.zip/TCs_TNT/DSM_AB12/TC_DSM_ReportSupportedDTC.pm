#### TEST CASE MODULE
package TC_DSM_ReportSupportedDTC;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.3 $;
our $HEADER  = q$Header: DSM_AB12/TC_DSM_ReportSupportedDTC.pm 1.3 2017/11/09 19:16:30ICT ver6cob develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_ReadDTCInformation
#TS version in DOORS: 4.9
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use GENERIC_DCOM;
use LIFT_CD;
use LIFT_evaluation;
##################################

our $PURPOSE = "to check that service 19 0A reports all DTCs supported by the project with the corresponding statuses";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_ReportSupportedDTC

=head1 PURPOSE

to check that service 19 0A reports all DTCs supported by the project with the corresponding statuses

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Create faults with corresponding states <Fault_States> 

2. Send <ReportSupportedDTC>

3. Check the DTCStatus for faults created in step 1

4. Repeat steps 2, 3 in all supported addressing modes and all supported sessions


I<B<Evaluation>>

2. Positive response with format 

59 0A 

<DTCStatusAvailabilitymask> 

DTC#1 

statusOfDTC#1

:

DTC#m 

statusOfDTC#m

where m is total number of DTCs supported for the project

3. Appropriate status <Fault_Status_exp> is reported for all faults created in step 1


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	HASH 'Fault_States' => 
	SCALAR 'ReportSupportedDTC' => 
	SCALAR 'DTCStatusAvailabilitymask' => 
	HASH 'Fault_Status_exp' => 


=head2 PARAMETER EXAMPLES

	purpose = 'to check that service 19 0A reports all DTCs supported by the project with the corresponding statuses' 
	# input parameters
	Fault_States = %('rb_sqm_SquibResistanceOpenAB1FD_flt' => 'Active', 'rb_sqm_SquibResistanceOpenAB1FP_flt' => 'Latched', 'rb_sqm_SquibResistanceOpenSA1FL_flt' => 'Stored')
	ReportSupportedDTC = 'ReadDTCInformation_ReportSupportedDtcs'
	#output parameters
	DTCStatusAvailabilitymask = '39'
	Fault_Status_exp = %('rb_sqm_SquibResistanceOpenAB1FD_flt' => '0bxxxx1xx1', 'rb_sqm_SquibResistanceOpenAB1FP_flt' => '0bxxxx1xx0', 'rb_sqm_SquibResistanceOpenSA1FL_flt' => '0bxxxx1xx0',)

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my %tcpar_Fault_States;
my $tcpar_ReportSupportedDTC;
my $tcpar_DTCStatusAvailabilityMask;
my %tcpar_Fault_Status_exp;

################ global parameter declaration ###################
#add any global variables here

###############################################################

sub TC_set_parameters {

    $tcpar_purpose                   = GEN_Read_mandatory_testcase_parameter('purpose');
    %tcpar_Fault_States              = GEN_Read_mandatory_testcase_parameter('Fault_States');
    $tcpar_ReportSupportedDTC        = GEN_Read_mandatory_testcase_parameter('ReportSupportedDTC');
    $tcpar_DTCStatusAvailabilityMask = GEN_Read_mandatory_testcase_parameter('DTCStatusAvailabilityMask');
    %tcpar_Fault_Status_exp          = GEN_Read_mandatory_testcase_parameter('Fault_Status_exp');

    return 1;
}

sub TC_initialization {

    S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
    GEN_StandardPrepNoFault();
    GDCOM_start_CyclicTesterPresent();

    return 1;
}

sub TC_stimulation_and_measurement {

    S_teststep( "Create faults with corresponding states", 'AUTO_NBR' );
    foreach my $fault ( keys %tcpar_Fault_States ) {
        S_teststep_2nd_level("Create fault: $fault", 'NO_AUTO_NBR');
        FM_createFault($fault);
    }
    S_wait_ms( 10000, 'wait for qualification time' );

    #create faults in required states
    my %rhash_Fault_States = reverse %tcpar_Fault_States;
    my $stored_flt         = $rhash_Fault_States{'Stored'};
    my $latched_flt        = $rhash_Fault_States{'Latched'};
    my $active_flt         = $rhash_Fault_States{'Active'};

    #first stored fault
    FM_removeFault($stored_flt);
    S_wait_ms( 10000, 'wait for dequalification time' );
    GEN_Power_on_Reset();

    #latched fault
    FM_removeFault($latched_flt);
    S_wait_ms( 10000, 'wait for dequalification time' );

    my $addrModesForRequest = GDCOM_getRequestInfofromMapping($tcpar_ReportSupportedDTC)->{'allowed_in_addressingmodes'};
    my $sessionsForRequest  = GDCOM_getRequestInfofromMapping($tcpar_ReportSupportedDTC)->{'allowed_in_sessions'};

    foreach my $session (@$sessionsForRequest) {
        S_teststep( "Enter session: $session", 'AUTO_NBR' );
        DIAG_StartSession($session);

        foreach my $addrMode (@$addrModesForRequest) {
            S_teststep( "Set addressing mode: $addrMode", 'AUTO_NBR' );
            GDCOM_set_addressing_mode($addrMode);

            S_teststep( "Send '$tcpar_ReportSupportedDTC'", 'AUTO_NBR', "send_reportsupporteddtc_$addrMode"."_$session" );    #measurement 1
            #use the GDCOM function only to evaluate the positive response bytes
            my $response_ReadAllDTCs = GDCOM_request_general( "REQ_" . $tcpar_ReportSupportedDTC, "PR_" . $tcpar_ReportSupportedDTC );

            S_teststep_expected( "Positive response: 59 0A $tcpar_DTCStatusAvailabilityMask DTC1 Status1..", "send_reportsupporteddtc_$addrMode"."_$session" );    #evaluation 1
            S_teststep_detected( "Response = $response_ReadAllDTCs", "send_reportsupporteddtc_$addrMode"."_$session" );
            GDCOM_evaluate_response_bytes( "DTCStatusAvailabilityMask_AfterQualify", $response_ReadAllDTCs, 2, $tcpar_DTCStatusAvailabilityMask );

            #use the CD function to evaluate the DTCs and status bytes (request will be sent again)
            my $DTC_struct_ReadAllDTCs = CD_read_DTC_NOERROR('0x0A');

            S_teststep( "Check the DTCStatus for faults created in step 1", 'AUTO_NBR', "check_the_dtcstatus_$addrMode"."_$session" );                             #measurement 2
            foreach my $fault ( keys %tcpar_Fault_Status_exp ) {
                my $status = CD_get_fault_status( $DTC_struct_ReadAllDTCs, $fault );
                EVAL_evaluate_value( "DTCStatus_All", $status, 'MASK', $tcpar_Fault_Status_exp{$fault} );

                S_teststep_expected("$fault status = $tcpar_Fault_Status_exp{$fault}");
                S_teststep_detected("$fault status = $status");
            }
        }
    }

    #remove the active fault
    FM_removeFault($active_flt);
    S_wait_ms( 10000, 'wait for dequalification time' );

    return 1;
}

sub TC_evaluation {

    S_w2rep("Evaluation is done above in stimulation_and_measurement");

    return 1;
}

sub TC_finalization {
    
    GDCOM_stop_CyclicTesterPresent();
    GDCOM_set_addressing_mode('physical');

    return 1;
}

1;
