#### TEST CASE MODULE
package TC_DSM_ClearDiagnosticInformation_PriorityHandling;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.3 $;
our $HEADER  = q$Header: DSM_AB12/TC_DSM_ClearDiagnosticInformation_PriorityHandling.pm 1.3 2017/11/08 11:41:10ICT ver6cob develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_ClearDiagnosticInformation
#TS version in DOORS: 4.9
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use GENERIC_DCOM;
##################################

our $PURPOSE = "Check NRC priority handling for service 14";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_ClearDiagnosticInformation_PriorityHandling

=head1 PURPOSE

Check NRC priority handling for service 14

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Create the NRC conditions based on below parameters: 

<IncorrectLength>

<GODTCNotSupported>

<ConditionsNotCorrect>

2. Send <Request> in physical addressing mode

3. Send <Request> in functional addressing mode


I<B<Evaluation>>

1.  

2. <Response_phys> is received

3. <Response_func> is received


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Request' => 
	SCALAR 'purpose' => 
	SCALAR 'IncorrectLength' => 
	SCALAR 'GODTCNotSupported' => 
	SCALAR 'ConditionsNotCorrect' => 
	SCALAR 'Response_phys' => 
	SCALAR 'Response_func' => 


=head2 PARAMETER EXAMPLES

	purpose = 'to check that NRC 13 has higher priority over NRC31 for service 14' 
	# input parameters
	IncorrectLength = 'Yes' #handled with Request
	GODTCNotSupported = 'Yes' #handled with Request
	ConditionsNotCorrect = 'VehicleSpeedTooHigh' #choose dependent precondition from SPR
	#output parameters
	Response_phys = 'NR_incorrectMessageLengthOrInvalidFormat'
	Response_func = 'NR_incorrectMessageLengthOrInvalidFormat'
	Request = '14 00 00 00 01' #incorrect length and invalid group of DTC

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_IncorrectLength;
my $tcpar_GODTCNotSupported;
my $tcpar_ConditionsNotCorrect;
my $tcpar_Response_phys;
my $tcpar_Response_func;
my $tcpar_Request;

################ global parameter declaration ###################
#add any global variables here
my %PreconditionParameters;

###############################################################

sub TC_set_parameters {

    $tcpar_purpose              = GEN_Read_mandatory_testcase_parameter('purpose');
    $tcpar_IncorrectLength      = GEN_Read_mandatory_testcase_parameter('IncorrectLength');
    $tcpar_GODTCNotSupported    = GEN_Read_mandatory_testcase_parameter('GODTCNotSupported');
    $tcpar_ConditionsNotCorrect = GEN_Read_mandatory_testcase_parameter('ConditionsNotCorrect');
    $tcpar_Response_phys        = GEN_Read_mandatory_testcase_parameter('Response_phys');
    $tcpar_Response_func        = GEN_Read_mandatory_testcase_parameter('Response_func');
    $tcpar_Request              = GEN_Read_mandatory_testcase_parameter('Request');

    $PreconditionParameters{'SpeedSignalName'}   = GEN_Read_optional_testcase_parameter('SpeedSignalName');
    $PreconditionParameters{'SpeedSignalValue'}  = GEN_Read_optional_testcase_parameter('SpeedSignalValue');
    $PreconditionParameters{'InternalFaultName'} = GEN_Read_optional_testcase_parameter('InternalFaultName');

    return 1;
}

sub TC_initialization {

    S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
    GEN_StandardPrepNoFault();
    GDCOM_start_CyclicTesterPresent();

    return 1;
}

sub TC_stimulation_and_measurement {

    my $tcpar_Service = _getServiceLabel('14');
    my $NRCInfo_phys = GDCOM_getNRCfromMapping( $tcpar_Service, $tcpar_Response_phys );

    S_teststep( "Create the NRC conditions based on below parameters: ", 'AUTO_NBR' );
    S_teststep_2nd_level( "IncorrectLength = '$tcpar_IncorrectLength'",           'AUTO_NBR' );
    S_teststep_2nd_level( "GODTCNotSupported = '$tcpar_GODTCNotSupported'",       'AUTO_NBR' );
    S_teststep_2nd_level( "ConditionsNotCorrect = '$tcpar_ConditionsNotCorrect'", 'AUTO_NBR' );
    DIAG_setProhibitingPrecondition( $tcpar_ConditionsNotCorrect, \%PreconditionParameters ) if ( $tcpar_ConditionsNotCorrect ne 'No' );

    S_teststep( "Send '$tcpar_Request' in physical addressing mode", 'AUTO_NBR', 'send_request_in_A' );    #measurement 1
    GDCOM_set_addressing_mode('physical');
    my $response_physical = GDCOM_request( $tcpar_Request, $NRCInfo_phys->{'Response'}, 'strict' );

    S_teststep_expected( $NRCInfo_phys->{'Response'}, "send_request_in_A" );                                    #evaluation 2
    S_teststep_detected( "Response: $response_physical", "send_request_in_A" );


    S_teststep( "Send '$tcpar_Request' in functional addressing mode", 'AUTO_NBR', 'send_request_in_B' );    #measurement 2
    GDCOM_set_addressing_mode('functional');
    if ( $tcpar_Response_func eq 'NoResponse' ) {
        my $response_functional = GDCOM_request( $tcpar_Request, "", 'quiet' );

        S_teststep_expected( "No response", "send_request_in_B" );                                           #evaluation 2
        S_teststep_detected( "- " . $response_functional, "send_request_in_B" );
    }
    else {
        my $NRCInfo_func = GDCOM_getNRCfromMapping( $tcpar_Service, $tcpar_Response_func );
        my $response_functional = GDCOM_request( $tcpar_Request, $NRCInfo_func->{'Response'}, 'strict' );

        S_teststep_expected( $NRCInfo_func->{'Response'}, "send_request_in_B" );                                  #evaluation 2
        S_teststep_detected( "Response: $response_functional", "send_request_in_B" );
    }

    return 1;
}

sub TC_evaluation {

    S_w2rep("Evaluation is done above in stimulation_and_measurement");

    return 1;
}

sub TC_finalization {

    GDCOM_stop_CyclicTesterPresent();
    GDCOM_set_addressing_mode('physical');

    return 1;
}

sub _getServiceLabel {
    my $SID = shift;

    my $services = S_get_contents_of_hash( [ 'Mapping_DIAG', 'PRJ_SUPPORTED_SERVICES' ] );

    foreach my $serv ( keys %$services ) {
        return $serv if ( $services->{$serv} eq $SID );
    }
}

1;
