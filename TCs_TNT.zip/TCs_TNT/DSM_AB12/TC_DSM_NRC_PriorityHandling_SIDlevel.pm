#### TEST CASE MODULE
package TC_DSM_NRC_PriorityHandling_SIDlevel;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.6 $;
our $HEADER  = q$Header: DSM_AB12/TC_DSM_NRC_PriorityHandling_SIDlevel.pm 1.6 2019/08/12 19:40:39ICT Phan Khanh Duy (RBVH/EPS24) (PDA1HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_NegativeResponseCodes
#TS version in DOORS: 0.3
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use GENERIC_DCOM;
use LIFT_PD;
##################################

our $PURPOSE = "To check for NRC priority handling at SID level";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_NRC_PriorityHandling_SIDlevel

=head1 PURPOSE

To check for NRC priority handling at SID level

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Create the NRC conditions based on below parameters:

<ServerBusy>

<ManufacturerSpecificFailure>

<SIDNotSupported>

<SIDNotSupportedInActiveSession>

<SIDSecurityNotTaken>

<SupplierSpecificFailure>

2. Send <Request> in physical addressing mode

3. Send <Request> in functional addressing mode


I<B<Evaluation>>

1.  

2. <Response_phys> is received

3. <Response_func> is received


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Request' => 
	SCALAR 'Purpose' => 
	SCALAR 'ServerBusy' => 
	SCALAR 'ManufacturerSpecificFailure' => 
	SCALAR 'SIDNotSupported' => 
	SCALAR 'SIDNotSupportedInActiveSession' => 
	SCALAR 'SIDSecurityNotTaken' => 
	SCALAR 'SupplierSpecificFailure' => 
	SCALAR 'Response_phys' => 
	SCALAR 'Response_func' => 


=head2 PARAMETER EXAMPLES

	Purpose = 'To check for NRC priority handling at SID level - NRC21 over NRC for ManufacturerSpecificFailure'
	ServerBusy = 'yes'
	ManufacturerSpecificFailure = 'VehicleSpeedTooHigh' #project configurable
	SIDNotSupported = 'yes'
	SIDNotSupportedInActiveSession = 'NA'
	SIDSecurityNotTaken = 'NA'
	SupplierSpecificFailure = 'VoltageTooHigh' #project configurable
	Response_phys = 'NR_busyRepeatRequest'
	Response_func = 'NR_busyRepeatRequest'
	Request = '09' #any not supported service

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_ServerBusy;
my $tcpar_ManufacturerSpecificFailure;
my $tcpar_SIDNotSupported;
my $tcpar_SIDNotSupportedInActiveSession;
my $tcpar_SIDSecurityNotTaken;
my $tcpar_SupplierSpecificFailure;
my $tcpar_Response_phys;
my $tcpar_Response_func;
my $tcpar_Request;
my ( %tcpar_CommunicationType, %tcpar_Key, %tcpar_Data, %tcpar_IOControlState, %tcpar_RoutineControlOption );
my ( $NRCdesc_phys, $NRCdesc_func );

################ global parameter declaration ###################
#add any global variables here
my %DataValue;
my %PreconditionParameters;
my %NRC_map = reverse %{ S_get_contents_of_hash( [ 'Mapping_DIAG', 'GlobalNRC' ] ) };

###############################################################

sub TC_set_parameters {

	$tcpar_Purpose                        = GEN_Read_mandatory_testcase_parameter('Purpose');
	$tcpar_ServerBusy                     = GEN_Read_mandatory_testcase_parameter('ServerBusy');
	$tcpar_ManufacturerSpecificFailure    = GEN_Read_mandatory_testcase_parameter('ManufacturerSpecificFailure');
	$tcpar_SIDNotSupported                = GEN_Read_mandatory_testcase_parameter('SIDNotSupported');
	$tcpar_SIDNotSupportedInActiveSession = GEN_Read_mandatory_testcase_parameter('SIDNotSupportedInActiveSession');
	$tcpar_SIDSecurityNotTaken            = GEN_Read_mandatory_testcase_parameter('SIDSecurityNotTaken');
	$tcpar_SupplierSpecificFailure        = GEN_Read_mandatory_testcase_parameter('SupplierSpecificFailure');
	$tcpar_Response_phys                  = GEN_Read_mandatory_testcase_parameter('Response_phys');
	$tcpar_Response_func                  = GEN_Read_mandatory_testcase_parameter('Response_func');
	$tcpar_Request                        = GEN_Read_mandatory_testcase_parameter('Request');

	$PreconditionParameters{'SpeedSignalName'}   = GEN_Read_optional_testcase_parameter('SpeedSignalName');
	$PreconditionParameters{'SpeedSignalValue'}  = GEN_Read_optional_testcase_parameter('SpeedSignalValue');
	$PreconditionParameters{'InternalFaultName'} = GEN_Read_optional_testcase_parameter('InternalFaultName');

	#handle required bytes in request
	$DataValue{'StatusMask'}                  = GEN_Read_optional_testcase_parameter('StatusMask');
	$DataValue{'DTC'}                         = GEN_Read_optional_testcase_parameter('DTC');
	$DataValue{'DTCSnapshotRecordNumber'}     = GEN_Read_optional_testcase_parameter('DTCSnapshotRecordNumber');
	$DataValue{'DTCExtendedDataRecordNumber'} = GEN_Read_optional_testcase_parameter('DTCExtendedDataRecordNumber');

	%tcpar_CommunicationType    = GEN_Read_optional_testcase_parameter('CommunicationType');
	%tcpar_Key                  = GEN_Read_optional_testcase_parameter('Key');
	%tcpar_Data                 = GEN_Read_optional_testcase_parameter('Data');
	%tcpar_IOControlState       = GEN_Read_optional_testcase_parameter('IOControlState');
	%tcpar_RoutineControlOption = GEN_Read_optional_testcase_parameter('RoutineControlOption');

	$tcpar_Response_phys =~ m/NR_(.*)/i;
	$NRCdesc_phys = $1;

	$tcpar_Response_func =~ m/NR_(.*)/i;
	$NRCdesc_func = $1;

	return 1;
}

sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'NO_AUTO_NBR' );

	#	GEN_StandardPrepNoFault();
	DIAG_ECUReset_NOVERDICT();
	S_wait_ms( 'TIMER_ECU_READY', 'wait after reset' );
	PD_ReadFaultMemory_NOERROR();

	GDCOM_start_CyclicTesterPresent();
	GDCOM_set_addressing_mode('physical');

	return 1;
}

sub TC_stimulation_and_measurement {

	my ( $supportedSessions, $notSupportedSessions, $NRCInfo, $session_status );

	S_teststep( "Create the NRC conditions based on below parameters:", 'NO_AUTO_NBR' );

	S_teststep( "Set ServerBusy = '$tcpar_ServerBusy'", 'AUTO_NBR' );
	if ( $tcpar_ServerBusy eq 'yes' ) {

		#        S_set_error ("Server busy condition is not currently automated. Perform manually");
		S_teststep_2nd_level( "Send request to enter programming session", 'AUTO_NBR' );
		GDCOM_request( '10 03', '50 03', 'relax' );    #enter extended session before sending 10 02
		GDCOM_request( '10 02', '50 02', 'relax' );    #enter programming session

		#        return;
	}

	S_teststep( "Set ManufacturerSpecificFailure = '$tcpar_ManufacturerSpecificFailure'", 'AUTO_NBR' );
	DIAG_setProhibitingPrecondition( $tcpar_ManufacturerSpecificFailure, \%PreconditionParameters ) if ( $tcpar_ManufacturerSpecificFailure ne 'no' and $tcpar_ManufacturerSpecificFailure ne 'NA' );

	S_teststep_2nd_level( "SIDNotSupported = '$tcpar_SIDNotSupported'", 'AUTO_NBR' );
	unless ( $tcpar_SIDNotSupported eq 'yes' ) {
		$tcpar_Request =~ m/(.*?)_(.*)/;

		my $SID = S_get_contents_of_hash( [ 'Mapping_DIAG', 'PRJ_SUPPORTED_SERVICES', $1 ] );
		my $SubFunc = S_get_contents_of_hash( [ 'Mapping_DIAG', 'DIAG_SERVICES', $1, 'Supported_SubFuns', $2 ] );
		_fillRequestInputParameters( $SID, $SubFunc );

		if ( $SID eq '2E' ) {    #for 2E service, write the same value as read by 22 service
			my $DID = $SubFunc;
			my $readdata = GDCOM_request_NOVERDICT( "22 $DID", "62 $DID", 'relax' );
			$readdata = substr( $readdata, 9 );    #remove 62 DIDHB DIDLB
			$DataValue{'Data'} = $readdata if ( defined $readdata );
		}

		$supportedSessions = _getSupportedSessions($tcpar_Request);
		S_w2rep("Sessions supported by '$tcpar_Request': @$supportedSessions");
	}

	S_teststep( "Set SIDNotSupportedInActiveSession = '$tcpar_SIDNotSupportedInActiveSession'", 'AUTO_NBR' );
	if ( $tcpar_SIDNotSupportedInActiveSession eq 'yes' ) {
		my $service10   = _getServiceLabel('10');
		my $sessionInfo = GDCOM_getSupportedSubFunsfromMapping($service10);
		my @allSessions = keys(%$sessionInfo);

		#remove any session containing 'ForDisposal'
		my $index = 0;
		foreach (@allSessions) {
			if ( $_ =~ m/ForDisposal/i ) {
				splice( @allSessions, $index, 1 );
			}
			else {
				$index++;
			}
		}
		S_w2rep("All sessions supported in project: @allSessions");

		$notSupportedSessions = GEN_filterChildarrayFromParentarray( \@allSessions, $supportedSessions );
		S_teststep_2nd_level( "Sessions not supported by '$tcpar_Request': @$notSupportedSessions", 'NO_AUTO_NBR' );

		if ( scalar @$notSupportedSessions ) {    #not supported sessions
			foreach (@$notSupportedSessions) {
				next if $_ =~ m/Safety|Disposal/i;
				S_teststep( "Enter session: $_", 'AUTO_NBR' );
				$session_status = DIAG_StartSession($_);
				S_wait_ms( 5000, 'wait after session entry' ) if ( $_ =~ m/prog|boot/i );
				last;
			}
		}
		else {
			$session_status = 0;
			S_teststep_2nd_level( "There is no session in which '$tcpar_Request' is not supported. Cannot set SIDNotSupportedInActiveSession!\n", 'NO_AUTO_NBR' );
		}

		unless ( defined $session_status ) {
			S_teststep_2nd_level( "There is no session other than disposal/safety session in which '$tcpar_Request' is not supported. Cannot set SIDNotSupportedInActiveSession!\n", 'NO_AUTO_NBR' );
		}
	}
	elsif ( $tcpar_SIDNotSupported ne 'yes' ) {
		S_teststep_2nd_level( "Enter session: @$supportedSessions[0]", 'AUTO_NBR' );
		DIAG_StartSession( @$supportedSessions[0] );
	}

	S_teststep( "Set SIDSecurityNotTaken = '$tcpar_SIDSecurityNotTaken'", 'AUTO_NBR' );

	S_teststep( "Set SupplierSpecificFailure = '$tcpar_SupplierSpecificFailure'", 'AUTO_NBR' );
	DIAG_setProhibitingPrecondition( $tcpar_SupplierSpecificFailure, \%PreconditionParameters ) if ( $tcpar_SupplierSpecificFailure ne 'no' and $tcpar_SupplierSpecificFailure ne 'NA' );

	S_teststep( "Send '$tcpar_Request' in physical addressing mode", 'AUTO_NBR', 'send_request_phys' );    #measurement 1
	GDCOM_set_addressing_mode('physical');
	if ( $tcpar_SIDNotSupported eq 'yes' ) {
		my $response_phys = GDCOM_request( $tcpar_Request, "7F $tcpar_Request $NRC_map{$NRCdesc_phys}", 'strict' );

		S_teststep_expected( "7F $tcpar_Request $NRC_map{$NRCdesc_phys}", 'send_request_phys' );           #evaluation 1
		S_teststep_detected( $response_phys, 'send_request_phys' );
	}
	else {
		my $response_phys = GDCOM_request_general( "REQ_" . $tcpar_Request, $tcpar_Response_phys, \%DataValue );

		my @service = split( /_/, $tcpar_Request );
		$NRCInfo = GDCOM_getNRCfromMapping( $service[0], $tcpar_Response_phys );
		S_teststep_expected( $NRCInfo->{'Response'}, "send_request_phys" );                                #evaluation 1
		S_teststep_detected( $response_phys, "send_request_phys" );
	}

	S_teststep( "Send '$tcpar_Request' in functional addressing mode", 'AUTO_NBR', 'send_request_func' );    #measurement 2
	GDCOM_set_addressing_mode('functional');
	if ( $tcpar_SIDNotSupported eq 'yes' and $tcpar_Response_func ne 'NoResponse' ) {
		my $response_func = GDCOM_request( $tcpar_Request, "7F $tcpar_Request $NRC_map{$NRCdesc_func}", 'strict' );

		S_teststep_expected( "7F $tcpar_Request $NRC_map{$NRCdesc_func}", 'send_request_func' );             #evaluation 1
		S_teststep_detected( $response_func, 'send_request_func' );
	}
	elsif ( $tcpar_SIDNotSupported eq 'yes' and $tcpar_Response_func eq 'NoResponse' ) {
		my $response_func = GDCOM_request( $tcpar_Request, "", 'quiet' );

		S_teststep_expected( "no response", "send_request_func" );                                           #evaluation 2
		S_teststep_detected( "-" . $response_func, "send_request_func" );
	}
	elsif ( $tcpar_SIDNotSupported eq 'no' and $tcpar_Response_func eq 'NoResponse' ) {
		my $requestBytes = GDCOM_getRequestLabelValue( "REQ_" . $tcpar_Request, \%DataValue );
		my $response_func = GDCOM_request( $requestBytes, "", 'quiet' );

		S_teststep_expected( "no response", "send_request_func" );                                           #evaluation 2
		S_teststep_detected( "-" . $response_func, "send_request_func" );
	}
	else {
		my $response_func = GDCOM_request_general( "REQ_" . $tcpar_Request, $tcpar_Response_func, \%DataValue );

		S_teststep_expected( $NRCInfo->{'Response'}, "send_request_func" );                                  #evaluation 2
		S_teststep_detected( $response_func, "send_request_func" );
	}

	S_teststep( "\n", 'NO_AUTO_NBR' );                                                                       #newline for steps in TR

	return 1;
}

sub TC_evaluation {

	S_w2rep("Evaluation is done above in stimulation_and_measurement");

	return 1;
}

sub TC_finalization {

	DIAG_removeProhibitingPrecondition($tcpar_ManufacturerSpecificFailure, \%PreconditionParameters ) if ( $tcpar_ManufacturerSpecificFailure ne 'no' and $tcpar_ManufacturerSpecificFailure ne 'NA' );
	DIAG_removeProhibitingPrecondition($tcpar_SupplierSpecificFailure, \%PreconditionParameters )     if ( $tcpar_SupplierSpecificFailure     ne 'no' and $tcpar_SupplierSpecificFailure     ne 'NA' );

	GDCOM_stop_CyclicTesterPresent();

	return 1;
}

sub _getServiceLabel {
	my $SID = shift;

	my $services = S_get_contents_of_hash( [ 'Mapping_DIAG', 'PRJ_SUPPORTED_SERVICES' ] );

	foreach my $serv ( keys %$services ) {
		return $serv if ( $services->{$serv} eq $SID );
	}
}

sub _getSupportedSessions {
	my $reqLabel = shift;

	return GDCOM_getRequestInfofromMapping($reqLabel)->{'allowed_in_sessions'};
}

sub _fillRequestInputParameters {
	my $SID     = shift;
	my $subFunc = shift;

	if ( $SID eq '27' ) {
		$DataValue{'Key'} = $tcpar_Key{$subFunc};
	}
	elsif ( $SID eq '28' ) {
		$DataValue{'CommunicationType'} = $tcpar_CommunicationType{$subFunc};
	}
	elsif ( $SID eq '2E' ) {
		$DataValue{'Data'} = $tcpar_Data{$subFunc};
	}
	elsif ( $SID eq '2F' ) {
		$DataValue{'IOControlState'} = $tcpar_IOControlState{$subFunc};
	}
	elsif ( $SID eq '2F' ) {
		$DataValue{'IOControlState'} = $tcpar_IOControlState{$subFunc};
	}
	elsif ( $SID eq '31' ) {
		$DataValue{'RoutineControlOption'} = $tcpar_RoutineControlOption{$subFunc};
	}

}

1;
