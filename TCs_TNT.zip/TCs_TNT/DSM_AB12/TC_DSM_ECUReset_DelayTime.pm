#### TEST CASE MODULE
package TC_DSM_ECUReset_DelayTime;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.5 $;
our $HEADER  = q$Header: DSM_AB12/TC_DSM_ECUReset_DelayTime.pm 1.5 2018/04/25 15:15:12ICT Nguyen Van Truc (RBVH/EPS24) (GNR2HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_ECUReset
#TS version in DOORS: 0.4
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use GENERIC_DCOM;
use LIFT_DCOM;
use LIFT_PD;
use LIFT_can_access;
use LIFT_evaluation;
##################################

our $PURPOSE = "<To measure the ECU reset delay time and response to diagnostic requests when ECU reset is in progress>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_ECUReset_DelayTime

=head1 PURPOSE

To measure the ECU reset delay time and response to diagnostic requests when ECU reset is in progress

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Set Addressing Mode and Protocol

3. Send request to enter Session which supports ECU Reset

4. Trigger <ResetRequest> diagostic request

5. Immediately read active session by sending <ReadActiveSession> diagnostic request

6. Observe the time difference between the positive response to step 4 and the start of error frames in the CAN trace

# Repeat the above steps for all supported Addressing modes and all supported session as defined in the SPR


I<B<Evaluation>>

1. 

2.

3. Positive response is observed

4. Positive response is observed

5. <ResponseType> is received

6. The time difference should be between 0 to <MaxDelayTime> +/- <MaxDelayTimeTolerance> ms


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Purpose' => 
	SCALAR 'ResetRequest' => 
	SCALAR 'ReadActiveSession' => 
	SCALAR 'ResponseType' => 
	SCALAR 'MaxDelayTime' => 
	SCALAR 'MaxDelayTimeTolerance' => 


=head2 PARAMETER EXAMPLES

	Purpose = 'To check Max delay time and ECU response during reset'
	
	
	ResetRequest =  '<Test Heading>'
	
	ReadActiveSession =  'ReadActiveDiagnosticSession'
	
	
	ResponseType = 'NR_BusyRepeatRequest' # ResponseType = 'NoResponse'
	
	MaxDelayTime = 100
	MaxDelayTimeTolerance = 10

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_ResetRequest;
my $tcpar_Session;
my $tcpar_ResponseType;
my $tcpar_MaxDelayTime_ms;
my $tcpar_MaxDelayTimeTolerance_ms;
my $tcpar_Diag_Request;
################ global parameter declaration ###################
#add any global variables here
my $AddressingMode;
my $mode;
my $ResetDelayTime;
my $TracePath;
my @Positive_Response_time;
my @First_Err_Msg_time;
my $diag_Response;
my @Response_array;
my $P3_minTime_phys;
my $P3_minTime_func;

###############################################################

sub TC_set_parameters {

	$tcpar_Purpose                  = GEN_Read_mandatory_testcase_parameter('Purpose');
	$tcpar_ResetRequest             = GEN_Read_mandatory_testcase_parameter('ResetRequest');
	$tcpar_Session                  = GEN_Read_mandatory_testcase_parameter('Session');
	$tcpar_ResponseType             = GEN_Read_mandatory_testcase_parameter('ResponseType');
	$tcpar_MaxDelayTime_ms          = GEN_Read_mandatory_testcase_parameter('MaxDelayTime_ms');
	$tcpar_MaxDelayTimeTolerance_ms = GEN_Read_mandatory_testcase_parameter('MaxDelayTimeTolerance_ms');
	$tcpar_Diag_Request             = GEN_Read_mandatory_testcase_parameter('Diag_Request');
	return 1;
}

sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	# Temporarily store the value of P3 physical mintime, so that it can be restored later
	$P3_minTime_phys = $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{'P3_mintime_physical'};
	$main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{'P3_mintime_physical'} = 0;

	# Temporarily store the value of P3 functional mintime, so that it can be restored later
	$P3_minTime_func = $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{'P3_mintime_functional'};
	$main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{'P3_mintime_functional'} = 0;

	return 1;
}

sub TC_stimulation_and_measurement {

	$AddressingMode = GDCOM_getRequestInfofromMapping($tcpar_ResetRequest)->{'allowed_in_addressingmodes'};

	foreach $mode (@$AddressingMode) {
		S_teststep( "Set addressing mode to : $mode", 'AUTO_NBR' );
		GDCOM_set_addressing_mode($mode);
		S_wait_ms(200);
		CA_trace_start();

		S_teststep( "Send request to enter Session which supports ECU Reset", 'AUTO_NBR', 'send_request_to_' . $mode );    #measurement 1
		DIAG_StartSession($tcpar_Session);                                                                                 #evaluation 1

		S_wait_ms( 3000, "Entry into programming session triggers a reset hence a delay" ) if ( $tcpar_Session =~ m/programming/i );

		S_teststep( "Trigger '$tcpar_ResetRequest' diagostic request", 'AUTO_NBR', 'trigger_resetrequest_diagostic_' . $mode );    #measurement 2
		my $diag_Response = GDCOM_request_general( "REQ_" . $tcpar_ResetRequest, "PR_" . $tcpar_ResetRequest );
		S_teststep_expected( "Positive shall be obtained.", 'trigger_resetrequest_diagostic_' . $mode );
		S_teststep_detected( "Obtained Response is $diag_Response", 'trigger_resetrequest_diagostic_' . $mode );  
		   
		S_teststep("Immediately send $tcpar_Diag_Request", 'AUTO_NBR', 'immediately_send_diagreq_' . $mode );
        if ( $tcpar_ResponseType eq 'NR_busyRepeatRequest' ) {
            $diag_Response = GDCOM_request_general( "REQ_" . $tcpar_Diag_Request, 'NR_busyRepeatRequest' );
            S_teststep_expected( " NRC 21 shall be obtained . ", 'immediately_send_diagreq_' . $mode );
            S_teststep_detected( " Obtained Response is $diag_Response", 'immediately_send_diagreq_' . $mode );
        }
        elsif ( $tcpar_ResponseType eq 'NoResponse' ) {
            my $requestBytes = GDCOM_getRequestLabelValue( "REQ_" . $tcpar_Diag_Request );
            my $NoResponse = GDCOM_request( $requestBytes, '', 'quiet' );
            $NoResponse = " no response " unless ( defined $NoResponse );
            S_teststep_expected( " No ECU response ", 'immediately_send_diagreq_' . $mode );
            S_teststep_detected( " Obtained Response is $NoResponse", 'immediately_send_diagreq_' . $mode );
        }

        S_wait_ms(5000);
        $TracePath =
          GEN_printLink( CA_trace_store( GEN_generateUniqueTraceName() ) );
        S_teststep( " Observe the time difference between the positive response to step 3 and the start of error frames in the CAN trace ", 'AUTO_NBR', 'observe_the_time_' . $mode );    #measurement 4

        open( FH, $TracePath ) or die " Cant open $! ";
        while (<FH>) {

            if ( $_ =~ /02 51 01|02 51 02/ ) {
                @Positive_Response_time = split( /\s+/, $_ );
                S_w2rep(" Positive Response Time value $Positive_Response_time[1] ");

                while (<FH>) {
                    if ( $_ =~ /ErrorFrame/ )                                                                                                                                           #ErrorFrame
                    {
                        @First_Err_Msg_time = split( /\s+/, $_ );
                        S_w2rep( " First error frame detected time = $First_Err_Msg_time[1] " );
                        last;
                    }

                }
            }
        }
        close(FH);

        if ( scalar @First_Err_Msg_time ) {
            $ResetDelayTime =
              ( $First_Err_Msg_time[1] - $Positive_Response_time[1] ) * 1000;

            S_teststep_expected( " The time difference should be between 0 to '$tcpar_MaxDelayTime_ms' + /- '$tcpar_MaxDelayTimeTolerance_ms' ms", 'observe_the_time_' . $mode );
            S_teststep_detected( "Reset Delay time observed is  $ResetDelayTime miliseconds", 'observe_the_time_' . $mode );    #evaluation 4

            EVAL_evaluate_value( "Delay Time calculaion", $ResetDelayTime, '==', $tcpar_MaxDelayTime_ms, $tcpar_MaxDelayTimeTolerance_ms );
        }
        else {
            S_set_error( "Error frames not seen during reset. Test step cannot be evaluated. Try re-executing again " );
        }
    }
    return 1;
}

sub TC_evaluation {

    S_w2rep("Evaluation is done above in stimulation_and_measurement");

    return 1;
}

sub TC_finalization {

    # Restore functional and physical values
    $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{'P3_mintime_physical'}   = $P3_minTime_phys;
    $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{'P3_mintime_functional'} = $P3_minTime_func;

    return 1;
}

1;
