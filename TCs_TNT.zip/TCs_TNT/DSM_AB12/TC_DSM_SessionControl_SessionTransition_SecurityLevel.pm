#### TEST CASE MODULE
package TC_DSM_SessionControl_SessionTransition_SecurityLevel;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER = q$Header: DSM_AB12/TC_DSM_SessionControl_SessionTransition_SecurityLevel.pm 1.1 2017/09/07 16:12:58ICT ver6cob develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_SessionControl
#TS version in DOORS: 0.2
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use GENERIC_DCOM;
use LIFT_PD;
##################################

our $PURPOSE = "To verify that security resets when transition from one session to a new/same session occurs";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_SessionControl_SessionTransition_SecurityLevel

=head1 PURPOSE

To verify that security resets when transition from one session to a new/same session occurs

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Set physical addressing mode

2. Enter <Session_1>

3. Get security access required for <Request_Locked_by_Security>

4. Send <Request_Locked_by_Security> 

5. Enter <Session_2>

6. Send <Request_Locked_by_Security>


I<B<Evaluation>>

1.

2. ECU sends Positive response

3. -

4. ECU sends Positive response

5. ECU sends Positive response

6. ECU sends <Response> 


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Response' => 
	SCALAR 'Purpose' => 
	SCALAR 'Session_1' => 
	SCALAR 'Session_2' => 
	SCALAR 'Request_Locked_by_Security' => 


=head2 PARAMETER EXAMPLES

	Purpose  = 'To verify that security resets when transition from one session to a new/same session occurs'
	Session_1 = '<Test Heading Head>'
	Session_2 = '<Test Heading Tail>'
	Request_Locked_by_Security = 'WriteDataByIdentifier_OriginalVIN' 
	Response = 'NR_securityAccessDenied'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_Session_1;
my $tcpar_Session_2;
my $tcpar_Request_Locked_by_Security;
my $tcpar_Response;
my %tcpar_DataValue;

################ global parameter declaration ###################
#add any global variables here


###############################################################

sub TC_set_parameters {

	$tcpar_Purpose =  GEN_Read_mandatory_testcase_parameter( 'Purpose' );
	$tcpar_Session_1 =  GEN_Read_mandatory_testcase_parameter( 'Session_1' );
	$tcpar_Session_2 =  GEN_Read_mandatory_testcase_parameter( 'Session_2' );
	$tcpar_Request_Locked_by_Security =  GEN_Read_mandatory_testcase_parameter( 'Request_Locked_by_Security' );
	$tcpar_Response =  GEN_Read_mandatory_testcase_parameter( 'Response' );
	
	%tcpar_DataValue = GEN_Read_optional_testcase_parameter('DataValue');

	return 1;
}

sub TC_initialization {

	S_teststep("StandardPrepNoFault", 'AUTO_NBR');
#	GEN_StandardPrepNoFault();
    DIAG_ECUReset_NOVERDICT ();
    S_wait_ms ('TIMER_ECU_READY', 'wait after reset');
    PD_ReadFaultMemory_NOERROR();
    
    GDCOM_start_CyclicTesterPresent();
    GDCOM_set_addressing_mode('physical');

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Set physical addressing mode", 'AUTO_NBR');
	GDCOM_set_addressing_mode('physical');

	S_teststep("Enter session: '$tcpar_Session_1'", 'AUTO_NBR', 'enter_session_1');			#measurement 1
	my $session1_Response = GDCOM_request_general("REQ_DiagnosticSessionControl_".$tcpar_Session_1.'Session',"PR_DiagnosticSessionControl_".$tcpar_Session_1.'Session');        
    S_teststep_expected('Positive Response is obtained',"enter_session_1");            
    S_teststep_detected("Obtained Response is $session1_Response","enter_session_1");

	S_teststep("Get security access required for '$tcpar_Request_Locked_by_Security'", 'AUTO_NBR');
	my $securityLevelsForRequest = _getSecurityLevelsForRequest($tcpar_Request_Locked_by_Security);
	DIAG_getSecurityAccess (@$securityLevelsForRequest[0]);

	#to fill DataValue for request
	if (not defined %tcpar_DataValue and $tcpar_Request_Locked_by_Security =~ m/^write/i){ #DataValue parameter is not defined and request is a 2E service
	   S_w2rep ("Read data with service 22 to write same content later with service 2E");
	   my @request = split(/_/, $tcpar_Request_Locked_by_Security);
	   my $DID = S_get_contents_of_hash( [ 'Mapping_DIAG', 'DIAG_SERVICES', $request[0],'Supported_SubFuns', $request[1]]);
       my $readdata = GDCOM_request_NOVERDICT ("22 $DID", "62 $DID", 'relax');
       $readdata = substr($readdata, 9); #remove 62 DIDHB DIDLB
       $tcpar_DataValue{'Data'} = $readdata if (defined $readdata);
	}

	S_teststep("Send '$tcpar_Request_Locked_by_Security' ", 'AUTO_NBR', 'send_request_locked_A');			#measurement 2
	my $response_unlocked = GDCOM_request_general("REQ_".$tcpar_Request_Locked_by_Security,"PR_".$tcpar_Request_Locked_by_Security, \%tcpar_DataValue);        
    S_teststep_expected('Positive Response is obtained',"send_request_locked_A");            
    S_teststep_detected("Obtained Response is $response_unlocked","send_request_locked_A");


	S_teststep("Enter session: '$tcpar_Session_2'", 'AUTO_NBR', 'enter_session_2');			#measurement 3
	my $session2_Response = GDCOM_request_general("REQ_DiagnosticSessionControl_".$tcpar_Session_2.'Session',"PR_DiagnosticSessionControl_".$tcpar_Session_2.'Session');        
    S_teststep_expected('Positive Response is obtained',"enter_session_2");            
    S_teststep_detected("Obtained Response is $session2_Response","enter_session_2");
	S_wait_ms (4000, 'wait after session entry');


	S_teststep("Send '$tcpar_Request_Locked_by_Security'", 'AUTO_NBR', 'send_request_locked_B');			#measurement 4
	my $response_locked = GDCOM_request_general("REQ_".$tcpar_Request_Locked_by_Security,$tcpar_Response, \%tcpar_DataValue);        
    S_teststep_expected("ECU sends $tcpar_Response","send_request_locked_B");            
    S_teststep_detected("Obtained Response is $response_locked","send_request_locked_B");

	return 1;
}

sub TC_evaluation {

	S_w2rep("Evaluation is done above in stimulation_and_measurement");

	return 1;
}

sub TC_finalization {
    
    GDCOM_stop_CyclicTesterPresent();

	return 1;
}

sub _getSecurityLevelsForRequest {
    my $reqLabel = shift;

    return GDCOM_getRequestInfofromMapping ($reqLabel)->{'allowed_in_securitylevels'};
}


1;
