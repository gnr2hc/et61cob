#### TEST CASE MODULE
package TC_DSM_ReportDTCSnapshotRecordByDTCNumber;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.5 $;
our $HEADER  = q$Header: DSM_AB12/TC_DSM_ReportDTCSnapshotRecordByDTCNumber.pm 1.5 2019/08/14 17:27:59ICT Nguyen Van Truc (RBVH/EPS24) (GNR2HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_ReadDTCInformation
#TS version in DOORS: 4.9
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use GENERIC_DCOM;
use LIFT_CD;
use LIFT_evaluation;
use LIFT_PD;
##################################

our $PURPOSE = "to check that service 19 04 reports the snapshot data for a particular DTC";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_ReportDTCSnapshotRecordByDTCNumber

=head1 PURPOSE

to check that service 19 04 reports the snapshot data for a particular DTC

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Send <ReportDTCSnapshotRecordByDTCNumber> for DTC corresponding to <fault> and with<DTCSnapshotRecordNumber>

2. Create <fault>, wait for qualification time. Remove the fault and wait for dequalification time. Qualify the fault again

3. Send <ReportDTCSnapshotRecordByDTCNumber> for DTC corresponding to <fault> and with<DTCSnapshotRecordNumber>

4. Send <ReportDTCSnapshotRecordByDTCNumber> for DTC corresponding to <fault> and with DTCSnapshotRecordNumber as 0xFF

5. Compare the corresponding snapshot records reported from step 3 and step 4.

6. Repeat steps 3, 4, 5 in all supported addressing modes and all supported sessions


I<B<Evaluation>>

2. Positive response with format 59 04 DTC statusOfDTC (0x00)

3. Positive response with format 59 04 DTC statusOfDTC followed by content of each DTCSnapshotRecord.

4. Positive response with format 59 04 DTC statusOfDTC followed by content of all DTCSnapshotRecords supported by the project. 

5. Content of each individual snapshot record reported in step 3 matches with the content of that corresponding record reported in step 4 (which contains data for all supported records)


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'N' => 
	SCALAR 'purpose' => 
	SCALAR 'ReportDTCSnapshotRecordByDTCNumber' => 
	SCALAR 'fault' => 
	LIST 'DTCSnapshotRecordNumber' => 


=head2 PARAMETER EXAMPLES

	purpose = 'to check that service 19 04 reports the snapshot data for a particular DTC' 
	# input parameters
	ReportDTCSnapshotRecordByDTCNumber = 'ReadDTCInformation_ReportDtcSnapshotRecordByDtcNumber'
	fault = 'rb_sqm_SquibResistanceOpenAB1FD_flt'
	DTCSnapshotRecordNumber = @('10', '20') #all supported
	#output parameters
	N = 1

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_ReportDTCSnapshotRecordByDTCNumber;
my $tcpar_fault;
my @tcpar_DTCSnapshotRecordNumber;
my $tcpar_SnapshotRecordSize;
my $tcpar_StatusOfDTC;

################ global parameter declaration ###################
#add any global variables here

###############################################################

sub TC_set_parameters {

    $tcpar_purpose                            = GEN_Read_mandatory_testcase_parameter('purpose');
    $tcpar_ReportDTCSnapshotRecordByDTCNumber = GEN_Read_mandatory_testcase_parameter('ReportDTCSnapshotRecordByDTCNumber');
    $tcpar_fault                              = GEN_Read_mandatory_testcase_parameter('fault');
    @tcpar_DTCSnapshotRecordNumber            = GEN_Read_mandatory_testcase_parameter('DTCSnapshotRecordNumber');
    $tcpar_SnapshotRecordSize                 = GEN_Read_mandatory_testcase_parameter('SnapshotRecordSize');
    $tcpar_StatusOfDTC                        = GEN_Read_mandatory_testcase_parameter('StatusOfDTC');

    return 1;
}

sub TC_initialization {

    S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
    GEN_StandardPrepNoFault();

    GDCOM_start_CyclicTesterPresent();
    S_wait_ms(500);
    return 1;
}

sub TC_stimulation_and_measurement {

    my %DataValue;
    $DataValue{'DTC'} = CD_get_FaultDTC($tcpar_fault);
    $DataValue{'DTC'} =~ s/(\w{2})/$1 /g;    #inserts a space after every 2 characters
    $DataValue{'DTC'} =~ s/\s+$//;           #remove whitespace at end

    my $addrModesForRequest = GDCOM_getRequestInfofromMapping($tcpar_ReportDTCSnapshotRecordByDTCNumber)->{'allowed_in_addressingmodes'};
    my $sessionsForRequest  = GDCOM_getRequestInfofromMapping($tcpar_ReportDTCSnapshotRecordByDTCNumber)->{'allowed_in_sessions'};

    S_teststep( "Send '$tcpar_ReportDTCSnapshotRecordByDTCNumber' for DTC corresponding to  fault '$tcpar_fault'", 'AUTO_NBR', 'ReadDTC_noFault' );    #measurement 1
    foreach (@tcpar_DTCSnapshotRecordNumber) {
        S_teststep_2nd_level( "Request with DTCSnapshotRecordNumber: $_", 'AUTO_NBR', "ReadDTC_noFault_$_" );
        $DataValue{'DTCSnapshotRecordNumber'} = $_;
        my $response_noFault = GDCOM_request_general( "REQ_" . $tcpar_ReportDTCSnapshotRecordByDTCNumber, 'PR_' . $tcpar_ReportDTCSnapshotRecordByDTCNumber, \%DataValue );

        S_teststep_expected( "59 04 $DataValue{'DTC'} 00", "ReadDTC_noFault_$_" );                                                                     #evaluation 1
        S_teststep_detected( "Response = $response_noFault", "ReadDTC_noFault_$_" );
        GDCOM_evaluate_response_bytes( "DTC",       $response_noFault, 2, $DataValue{'DTC'} );
        GDCOM_evaluate_response_bytes( "DTCStatus", $response_noFault, 5, '00' );
    }

    S_teststep( "Create fault '$tcpar_fault', wait for qualification time. Remove the fault and wait for dequalification time. Qualify the fault again", 'AUTO_NBR' );
    FM_createFault($tcpar_fault);
    S_wait_ms( 10000, 'wait for qualification time' );
    FM_removeFault($tcpar_fault);
    S_wait_ms( 10000, 'wait for dequalification time' );
    FM_createFault($tcpar_fault);
    S_wait_ms( 10000, 'wait for qualification time' );

    foreach my $session (@$sessionsForRequest) {
        S_teststep( "Enter session: $session", 'AUTO_NBR' );
        DIAG_StartSession($session);

        foreach my $addrMode (@$addrModesForRequest) {
            S_teststep( "Set addressing mode: $addrMode", 'AUTO_NBR' );
            GDCOM_set_addressing_mode($addrMode);

            S_teststep( "Send '$tcpar_ReportDTCSnapshotRecordByDTCNumber' for DTC corresponding to '$tcpar_fault'", 'AUTO_NBR', "ReadIndivSnapshotRec_$addrMode" . "_$session" );
            my %response_bytes_IndvRec;
            foreach (@tcpar_DTCSnapshotRecordNumber) {
                S_teststep_2nd_level( "Request with DTCSnapshotRecordNumber: $_", 'AUTO_NBR', "ReadIndivSnapshotRec_$addrMode" . "_$session" . "$_" );
                $DataValue{'DTCSnapshotRecordNumber'} = $_;
                my $response_Fault = GDCOM_request_general( "REQ_" . $tcpar_ReportDTCSnapshotRecordByDTCNumber, 'PR_' . $tcpar_ReportDTCSnapshotRecordByDTCNumber, \%DataValue );

                $response_bytes_IndvRec{$_} = [ split / /, $response_Fault ];
                my $obs_numOfBytes = scalar @{ $response_bytes_IndvRec{$_} };
                my $exp_numOfBytes = 6 + 2 + $tcpar_SnapshotRecordSize;         #Positive response bytes + SnapshotRecNumber & SnapshotRecNumOfIdentifiers + SnapshotRecordSize
                EVAL_evaluate_value( "RecordSize - Individual Record", $obs_numOfBytes, '==', $exp_numOfBytes );    #1 record reported
                S_teststep_expected( "Number of response bytes == $exp_numOfBytes (1 Record)", "ReadIndivSnapshotRec_$addrMode" . "_$session" . "$_" );
                S_teststep_detected( "Number of response bytes == $obs_numOfBytes", "ReadIndivSnapshotRec_$addrMode" . "_$session" . "$_" );

                S_teststep_expected("59 04 $DataValue{'DTC'} $tcpar_StatusOfDTC", "ReadIndivSnapshotRec_$addrMode" . "_$session" . "$_");                               
                S_teststep_detected("Response = $response_Fault", "ReadIndivSnapshotRec_$addrMode" . "_$session" . "$_");
                GDCOM_evaluate_response_bytes( "DTC", $response_Fault, 2, $DataValue{'DTC'} );
                GDCOM_evaluate_response_bytes( "DTCStatus", $response_Fault, 5, $tcpar_StatusOfDTC );                     
            }

            S_teststep( "Send '$tcpar_ReportDTCSnapshotRecordByDTCNumber' for DTC corresponding to '$tcpar_fault' and with DTCSnapshotRecordNumber as 0xFF", 'AUTO_NBR', "ReadAllSnapshotRec_$addrMode" . "_$session" );    #measurement 2
            $DataValue{'DTCSnapshotRecordNumber'} = 'FF';
            my $response_Fault_AllRec = GDCOM_request_general( "REQ_" . $tcpar_ReportDTCSnapshotRecordByDTCNumber, 'PR_' . $tcpar_ReportDTCSnapshotRecordByDTCNumber, \%DataValue );

            my @response_bytes_AllRec = split / /, $response_Fault_AllRec;
            my $obs_numOfBytes_AllRec = scalar @response_bytes_AllRec;
            my $numOfSnapshotRecords  = scalar @tcpar_DTCSnapshotRecordNumber;
            my $exp_numOfBytes_AllRec = 6 + ( 2 + $tcpar_SnapshotRecordSize ) * $numOfSnapshotRecords;    #Positive response bytes + (SnapshotRecNumber & SnapshotRecNumOfIdentifiers + SnapshotRecordSize)*NumberOfSnapshotRecords
            EVAL_evaluate_value( "RecordSize - All Records", $obs_numOfBytes_AllRec, '==', $exp_numOfBytes_AllRec );    #1 record reported
            S_teststep_expected( "Number of response bytes == $exp_numOfBytes_AllRec (all Records)", "ReadAllSnapshotRec_$addrMode" . "_$session" );
            S_teststep_detected( "Number of response bytes == $obs_numOfBytes_AllRec", "ReadAllSnapshotRec_$addrMode" . "_$session" );

            S_teststep_expected("59 04 $DataValue{'DTC'} $tcpar_StatusOfDTC", "ReadAllSnapshotRec_$addrMode" . "_$session");                                      
            S_teststep_detected("Response = $response_Fault_AllRec", "ReadAllSnapshotRec_$addrMode" . "_$session");
            GDCOM_evaluate_response_bytes( "DTC", $response_Fault_AllRec, 2, $DataValue{'DTC'} );
            GDCOM_evaluate_response_bytes( "DTCStatus", $response_Fault_AllRec, 5, $tcpar_StatusOfDTC );                       
            
            S_teststep( "Compare the corresponding snapshot records reported from step 3 and step 4", 'AUTO_NBR', "CompareRecContent_$addrMode" . "_$session" );    #measurement 2
            splice @response_bytes_AllRec,0,6;     #remove positive response bytes (1 to 6)            
            foreach (@tcpar_DTCSnapshotRecordNumber) {
                splice @{ $response_bytes_IndvRec{$_} },0,6;  #remove positive response bytes (1 to 6)                                                                          
                my $recordBytes =  2 + $tcpar_SnapshotRecordSize ;
                my @response_bytes_AllRec = splice @response_bytes_AllRec, 0, $recordBytes;                                                                                 
                GEN_EVAL_CompareStrArrays( $response_bytes_IndvRec{$_}, \@response_bytes_AllRec, 'Equal' ) unless $main::opt_offline;
            }
        }
    }

    FM_removeFault($tcpar_fault);
    S_wait_ms( 10000, 'wait for dequalification time' );
    PD_ClearFaultMemory();

    return 1;
}

sub TC_evaluation {

    S_w2rep("Evaluation is done above in stimulation_and_measurement");

    return 1;
}

sub TC_finalization {

    GDCOM_stop_CyclicTesterPresent();
    GDCOM_set_addressing_mode('physical');

    return 1;
}

1;
