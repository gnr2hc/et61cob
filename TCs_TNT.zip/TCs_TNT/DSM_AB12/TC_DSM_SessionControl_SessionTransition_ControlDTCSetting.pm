#### TEST CASE MODULE
package TC_DSM_SessionControl_SessionTransition_ControlDTCSetting;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.2 $;
our $HEADER = q$Header: DSM_AB12/TC_DSM_SessionControl_SessionTransition_ControlDTCSetting.pm 1.2 2017/09/07 18:58:22ICT Verma Nupur (RBEI/ESA-PP3) (ENU5KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_SessionControl
#TS version in DOORS: 0.2
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
use LIFT_can_access;
use LIFT_labcar;
use GENERIC_DCOM;
use LIFT_PD;
use LIFT_CD;
use LIFT_evaluation;
use LIFT_DCOM;
#include further modules here

##################################

our $PURPOSE = "This test case is to verify status of Control DTC Setting when transition from one session to the another takes place.";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_SessionControl_SessionTransition_ControlDTCSetting

=head1 PURPOSE

This test case is to verify status of Control DTC Setting when transition from one session to the another takes place.

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Set Addressing Mode and Protocol

2. Enter <Session_1>

3. Send <Request_ControlDTCSettingOFF> to set ControlDTCSetting OFF.

4. Create a <Fault>

5. Send request to read fault memory with <StatusMask>

6. Enter <Session_2>

7. Send request to read fault memory with <StatusMask>

# Repeat the above steps for all supported Addressing modes as defined in the SPR


I<B<Evaluation>>

1.

2. Session Entry successful

3. <Response> shall be obtained

4. Fault DTC shall be obtained with <Status_1>

5. 

6. Session entry successful

7. Fault DTC shall be obtained with <Status_2>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Status_1' => 
	SCALAR 'Status_2' => 
	SCALAR 'Purpose' => 
	SCALAR 'FaultName' => 
	SCALAR 'Session_1' => 
	SCALAR 'Session_2' => 
	SCALAR 'Response' => 
	SCALAR 'Request_ControlDTCSettingOFF' => 
	SCALAR 'StatusMask' => 


=head2 PARAMETER EXAMPLES

	Purpose  = 'To verify Control DTC settings when transition from one session to a new/same session occurs'
	
	FaultName = 'TBD'
	
	Session_1 = '<Test Heading Head>'
	Session_2 = '<Test Heading Tail>'
	
	Response = 'PR_ControlDTCSetting_Off'
	
	Request_ControlDTCSettingOFF = 'ControlDTCSetting_Off'
	StatusMask = '0x39'
	Status_1	= '0b00000000'
	Status_2	 = '0bxxxx0xxx'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_Fault;
my $tcpar_Session_1;
my $tcpar_Session_2;
my $tcpar_Response;
my $tcpar_Request_ControlDTCSettingOFF;
my $tcpar_StatusMask;
my $tcpar_Status_1;
my $tcpar_Status_2;


################ global parameter declaration ###################
#add any global variables here


###############################################################

sub TC_set_parameters {

	$tcpar_Purpose =  GEN_Read_mandatory_testcase_parameter( 'Purpose' );
	$tcpar_Fault =  GEN_Read_mandatory_testcase_parameter( 'Fault' );
	$tcpar_Session_1 =  GEN_Read_mandatory_testcase_parameter( 'Session_1' );
	$tcpar_Session_2 =  GEN_Read_mandatory_testcase_parameter( 'Session_2' );
	$tcpar_Response =  GEN_Read_mandatory_testcase_parameter( 'Response' );
	$tcpar_Request_ControlDTCSettingOFF =  GEN_Read_mandatory_testcase_parameter( 'Request_ControlDTCSettingOFF' );
	$tcpar_StatusMask =  GEN_Read_mandatory_testcase_parameter( 'StatusMask' );
	$tcpar_Status_1 =  GEN_Read_mandatory_testcase_parameter( 'Status_1' );
	$tcpar_Status_2 =  GEN_Read_mandatory_testcase_parameter( 'Status_2' );
	

	return 1;
}

sub TC_initialization {

	S_teststep("StandardPrepNoFault", 'AUTO_NBR');
	GEN_StandardPrepNoFault();
	S_teststep("Send Tester present cyclically.");
	GDCOM_start_CyclicTesterPresent();

	return 1;
}

sub TC_stimulation_and_measurement {

		S_teststep("Enter '$tcpar_Session_1'", 'AUTO_NBR', "enter_session_1");			#measurement 1
		my $Request_Session1 = GDCOM_request_general("REQ_DiagnosticSessionControl_".$tcpar_Session_1,"PR_DiagnosticSessionControl_".$tcpar_Session_1);
		S_teststep_expected('Positive Response shall be obtained',"enter_session_1");			
		S_teststep_detected("Obtained Response is '$Request_Session1'","enter_session_1");
		
		S_teststep("Send '$tcpar_Request_ControlDTCSettingOFF' to set ControlDTCSetting OFF.", 'AUTO_NBR', "send_request_controldtcsettingoff");			#measurement 2
		my $ControlDTCOFFResponse  = GDCOM_request_general("REQ_".$tcpar_Request_ControlDTCSettingOFF,$tcpar_Response);
		S_teststep_expected("$tcpar_Response shall be obtained","send_request_controldtcsettingoff");			
		S_teststep_detected("Obtained Response is '$ControlDTCOFFResponse'","send_request_controldtcsettingoff");
		
		S_teststep("Create fault: $tcpar_Fault", 'AUTO_NBR');			#measurement 3
		FM_createFault($tcpar_Fault);
		S_wait_ms(10000,'Wait for 10sec for fault Qualification');

		S_teststep("Send request to read fault memory with status mask:'$tcpar_StatusMask'", 'AUTO_NBR');
		my $flt_mem_struct_cd_A = CD_read_DTC('02',$tcpar_StatusMask);
		CD_check_fault_status($flt_mem_struct_cd_A, $tcpar_Fault, $tcpar_Status_1);

		S_teststep("Enter '$tcpar_Session_2'", 'AUTO_NBR', "enter_session_2");			#measurement 4
		my $Request_Session2 = GDCOM_request_general("REQ_DiagnosticSessionControl_".$tcpar_Session_2,"PR_DiagnosticSessionControl_".$tcpar_Session_2);
		S_teststep_expected('Positive Response shall be obtained',"enter_session_2");			
		S_teststep_detected("Obtained Response is '$Request_Session2'","enter_session_2");
		
		S_wait_ms(10000,'Wait for 10sec for fault Qualification after session transition');
		
		S_teststep("Send request to read fault memory with Status mask '$tcpar_StatusMask'", 'AUTO_NBR');			#measurement 5
		my $flt_mem_struct_cd_B = CD_read_DTC('02',$tcpar_StatusMask);
		CD_check_fault_status($flt_mem_struct_cd_B, $tcpar_Fault, $tcpar_Status_2);
		
		FM_removeFault($tcpar_Fault);
		S_wait_ms(10000,'Wait for 10 sec for fault Dequalification');
		PD_ClearFaultMemory();

	return 1;
}

sub TC_evaluation {
	S_w2rep("Evaluation is done above in stimulation_and_measurement");
	return 1;
}

sub TC_finalization {
	GDCOM_stop_CyclicTesterPresent();
	DIAG_ECUReset();
	return 1;
}


1;
