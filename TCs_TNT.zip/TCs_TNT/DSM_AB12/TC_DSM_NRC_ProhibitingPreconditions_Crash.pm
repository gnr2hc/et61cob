#### TEST CASE MODULE
package TC_DSM_NRC_ProhibitingPreconditions_Crash;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.3 $;
our $HEADER = q$Header: DSM_AB12/TC_DSM_NRC_ProhibitingPreconditions_Crash.pm 1.3 2017/08/31 14:50:33ICT ver6cob develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_NegativeResponseCodes
#TS version in DOORS: 0.3
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use GENERIC_DCOM;
use LIFT_DCOM;
use LIFT_PD;
##################################

our $PURPOSE = "To verify the NRC for services which are dependent on crash related preconditions";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_NRC_ProhibitingPreconditions_Crash

=head1 PURPOSE

To verify the NRC for services which are dependent on crash related preconditions

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Enter session supported by the service. Get security access if required

2. Create <Precondition>

3. Send request

Repeat for all requests supported by a service


I<B<Evaluation>>

1. -

2. -

3. <Response> is received for the requests whose precondition is not fulfilled.

Positive response is received for requests which do not depend on the precondition


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Purpose' => 
	SCALAR 'Service' => 
	SCALAR 'Precondition' => 
	SCALAR 'Response' => 
	SCALAR 'CrashCode' => 
	SCALAR 'ResultDB' => 


=head2 PARAMETER EXAMPLES

	Purpose = 'To verify the NRC for services which are dependent on AlgoIsActiveOrCrashStorageInProgress Precondition'
	
	Precondition = 'AlgoIsActiveOrCrashStorageInProgress'
	Response = 'NR_conditionsNotCorrect'
	CrashCode = 'Multi_EDR_SideLeftAD_FrontAD_SideRightAD;5' #any crash with long duration
	ResultDB = 'EDR' # defined in CREIS mapping - will be set to 'DEFAULT' if not given

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_Service;
my $tcpar_Precondition;
my $tcpar_Response;
my $tcpar_CrashCode;
my $tcpar_ResultDB;
my ( %tcpar_CommunicationType, %tcpar_Key, %tcpar_Data, %tcpar_IOControlState, %tcpar_RoutineControlOption );

################ global parameter declaration ###################
#add any global variables here
my %DataValue;
my %PreconditionParameters;

###############################################################

sub TC_set_parameters {

	$tcpar_Purpose =  GEN_Read_mandatory_testcase_parameter( 'Purpose' );
	$tcpar_Service =  GEN_Read_mandatory_testcase_parameter( 'Service' );
	$tcpar_Precondition =  GEN_Read_mandatory_testcase_parameter( 'Precondition' );
	$tcpar_Response =  GEN_Read_mandatory_testcase_parameter( 'Response' );
	$tcpar_CrashCode =  GEN_Read_mandatory_testcase_parameter( 'CrashCode' );
	$tcpar_ResultDB =  GEN_Read_mandatory_testcase_parameter( 'ResultDB' );
	
	$PreconditionParameters{'CRASHNAME'} = $tcpar_CrashCode;
	$PreconditionParameters{'RESULTDB'} = $tcpar_ResultDB;
	
	%tcpar_CommunicationType    = GEN_Read_optional_testcase_parameter('CommunicationType');
	%tcpar_Key                  = GEN_Read_optional_testcase_parameter('Key');
	%tcpar_Data                 = GEN_Read_optional_testcase_parameter('Data');
	%tcpar_IOControlState       = GEN_Read_optional_testcase_parameter('IOControlState');
	%tcpar_RoutineControlOption = GEN_Read_optional_testcase_parameter('RoutineControlOption');


	return 1;
}

sub TC_initialization {

	S_teststep("StandardPrepNoFault", 'AUTO_NBR');
	# GEN_StandardPrepNoFault();

	DIAG_ECUReset_NOVERDICT();
	S_wait_ms( 'TIMER_ECU_READY', 'wait after reset' );
	PD_ReadFaultMemory_NOERROR();

	GDCOM_start_CyclicTesterPresent();
	GDCOM_set_addressing_mode('physical');

	return 1;
}

sub TC_stimulation_and_measurement {

	#    S_teststep("Repeat for all requests within a service", 'AUTO_NBR');

	my $SID = $tcpar_Service;
	$tcpar_Service = _getServiceLabel($tcpar_Service);
	my $SubFuncInfo = GDCOM_getSupportedSubFunsfromMapping($tcpar_Service);

	my $count = 0;
	foreach my $subFunc ( sort { hex( $SubFuncInfo->{$a} ) <=> hex( $SubFuncInfo->{$b} ) } keys %$SubFuncInfo ) {

		my $requestLabel = $tcpar_Service . "_" . $subFunc;
		S_w2rep( "************* $requestLabel *************", 'orange' );

		unless ( _getProtocolForRequest($requestLabel) eq 'UDS' ) {
			S_w2rep("Sub Function ($requestLabel) is not supported on UDS protocol. Go to next sub function..");
			next;
		}

		_fillRequestInputParameters( $SID, S_get_contents_of_hash( [ 'Mapping_DIAG', 'DIAG_SERVICES', $tcpar_Service, 'Supported_SubFuns', $subFunc ] ) );

		my $prohibitingPreconditionsForRequest = _getProhibitingPreconditionsForRequest($requestLabel);

		if ( grep { $_ =~ m/\Q$tcpar_Precondition\E/i } @$prohibitingPreconditionsForRequest ) {

			if ( $SID eq '2E' ) {    #for 2E service, write the same value as read by 22 service
				my $DID = S_get_contents_of_hash( [ 'Mapping_DIAG', 'DIAG_SERVICES', $tcpar_Service, 'Supported_SubFuns', $subFunc ] );
				my $readdata = GDCOM_request_NOVERDICT ( "22 $DID", "62 $DID", 'relax' );
				$readdata = substr( $readdata, 9 );    #remove 62 DIDHB DIDLB
				$DataValue{'Data'} = $readdata if (defined $readdata);
			}


			my $sessionsForRequest = _getSupportedSessionsForRequest($requestLabel);
			S_teststep( "Enter session: @$sessionsForRequest[0]", 'AUTO_NBR' );
			GDCOM_set_addressing_mode('disposal') if ( @$sessionsForRequest[0] =~ m/safety|disposal/i );
			GDCOM_StartSession( @$sessionsForRequest[0] );
			S_wait_ms( 5000, 'wait after session entry' ) if ( @$sessionsForRequest[0] =~ m/prog|boot/i );

			my $securityLevelsForRequest = _getSecurityLevelsForRequest($requestLabel);

			if ( @$securityLevelsForRequest[0] !~ m/None/i and @$securityLevelsForRequest[0] ne '---' ) {    #in case security access is required
				S_teststep( "Get required security access: @$securityLevelsForRequest", 'AUTO_NBR' );
				DIAG_getSecurityAccess( @$securityLevelsForRequest[0] ) if ( defined &DIAG_getSecurityAccess );
			}

			GDCOM_GetAccessToRequest($requestLabel);                                                         #handle any dependent services through request in Mapping_DIAG (if required)

			my $requestBytes = GDCOM_getRequestLabelValue( "REQ_" . $requestLabel, \%DataValue );
            
            S_teststep( "Create condition: $tcpar_Precondition", 'AUTO_NBR' );
            DIAG_setProhibitingPrecondition( $tcpar_Precondition, \%PreconditionParameters ) if ( defined &DIAG_setProhibitingPrecondition );    #TODO: function to be developed (Story 62110)

			S_teststep( "Send request $requestLabel: $requestBytes", 'AUTO_NBR', $subFunc . "send_request_$tcpar_Precondition" );
			#NRC expected
			my $response = GDCOM_request_general( "REQ_" . $requestLabel, $tcpar_Response, \%DataValue );

			my $NRCInfo = GDCOM_getNRCfromMapping( $tcpar_Service, $tcpar_Response );
			S_teststep_expected( $NRCInfo->{'Response'}, $subFunc . "send_request_$tcpar_Precondition" );                                        #evaluation 2
			S_teststep_detected( $response, $subFunc . "send_request_$tcpar_Precondition" );                                                     #no response expected

			DIAG_removeProhibitingPrecondition( $tcpar_Precondition, \%PreconditionParameters );
#			DIAG_ECUReset_NOVERDICT();
#			S_wait_ms( 'TIMER_ECU_READY', 'wait after reset' );

			$count++;
			
			S_teststep( "\n", 'NO_AUTO_NBR' );    #newline for steps in TR
		}
		else {
			S_w2rep( "Request '$requestLabel' doesn't depend on $tcpar_Precondition precondition" );
#			S_teststep_2nd_level( "Request '$requestLabel' doesn't depend on $tcpar_Precondition precondition", 'AUTO_NBR' );

			#            #positive response expected
			#            my $response = GDCOM_request_general( "REQ_" . $requestLabel, "PR_" . $requestLabel, \%DataValue );
			#
			#            my $ReqRespInfo = DCOM_getReqestResponseFromMapping( $requestLabel, \%DataValue );
			#            S_teststep_expected( $ReqRespInfo->{'Response'}, $subFunc . "send_request_$tcpar_Precondition" );                                 #evaluation 2
			#            S_teststep_detected( $response, $subFunc . "send_request_$tcpar_Precondition" ); #no response expected
		}

		

	}
	
	if($count == 0){ #for TR printout
		S_teststep( "No requests for service $SID depend on $tcpar_Precondition precondition\n", 'AUTO_NBR', 'NO_REQ' );
		S_teststep_expected( "No evaluation", 'NO_REQ' );
		S_teststep_detected( "No requests for service $SID depend on $tcpar_Precondition precondition\n", 'NO_REQ' );
	}

	return 1;
}

sub TC_evaluation {

	S_w2rep("Evaluation is done above in stimulation_and_measurement");

	return 1;
}

sub TC_finalization {

	GDCOM_stop_CyclicTesterPresent();

	return 1;
}

sub _getServiceLabel {
	my $SID = shift;

	my $services = S_get_contents_of_hash( [ 'Mapping_DIAG', 'PRJ_SUPPORTED_SERVICES' ] );

	foreach my $serv ( keys %$services ) {
		return $serv if ( $services->{$serv} eq $SID );
	}
}

sub _getSecurityLevelsForRequest {
	my $reqLabel = shift;

	return GDCOM_getRequestInfofromMapping($reqLabel)->{'allowed_in_securitylevels'};
}

sub _getProhibitingPreconditionsForRequest {
	my $reqLabel = shift;

	return GDCOM_getRequestInfofromMapping($reqLabel)->{'preconditions_prohibiting_execution'};
}

sub _getProtocolForRequest {
	my $reqLabel = shift;

	return GDCOM_getRequestInfofromMapping($reqLabel)->{'protocol'};
}

sub _getSupportedAddrModesForRequest {
	my $reqLabel = shift;

	return GDCOM_getRequestInfofromMapping($reqLabel)->{'allowed_in_addressingmodes'};
}

sub _getSupportedSessionsForRequest {
	my $reqLabel = shift;

	return GDCOM_getRequestInfofromMapping($reqLabel)->{'allowed_in_sessions'};
}


sub _fillRequestInputParameters {
	my $SID     = shift;
	my $subFunc = shift;

	if ( $SID eq '27' ) {
		$DataValue{'Key'} = $tcpar_Key{$subFunc};
	}
	elsif ( $SID eq '28' ) {
		$DataValue{'CommunicationType'} = $tcpar_CommunicationType{$subFunc};
	}
	elsif ( $SID eq '2E' ) {
		$DataValue{'Data'} = $tcpar_Data{$subFunc};
	}
	elsif ( $SID eq '2F' ) {
		$DataValue{'IOControlState'} = $tcpar_IOControlState{$subFunc};
	}
	elsif ( $SID eq '2F' ) {
		$DataValue{'IOControlState'} = $tcpar_IOControlState{$subFunc};
	}
	elsif ( $SID eq '31' ) {
		$DataValue{'RoutineControlOption'} = $tcpar_RoutineControlOption{$subFunc};
	}

}

1;
