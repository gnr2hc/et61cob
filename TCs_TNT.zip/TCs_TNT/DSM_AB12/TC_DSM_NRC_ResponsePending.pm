#### TEST CASE MODULE
package TC_DSM_NRC_ResponsePending;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.5 $;
our $HEADER = q$Header: DSM_AB12/TC_DSM_NRC_ResponsePending.pm 1.5 2018/04/24 17:59:36ICT ver6cob develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_NegativeResponseCodes
#TS version in DOORS: 0.3
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use GENERIC_DCOM;
use LIFT_DCOM;
use LIFT_PD;
use LIFT_CD_CAN;
use Data::Dumper;   
##################################

our $PURPOSE = "To check that NRC78 is sent if a request was correctly received but the response is not possible within P2CAN_Server time";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_NRC_ResponsePending

=head1 PURPOSE

To check that NRC $78 is sent if a request was correctly received but the response is not possible within P2CAN_Server time

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Enter session supported by the service. Get security access if required

2. Send <Request> and measure the time for ECU to send first response frame


I<B<Evaluation>>

2. If the first frame of the response (positive/negative) is not sent within P2CAN_Server time, NRC $78 is received. This NRC can be received multiple times till the final response (positive/negative) is sent.

After NRC $78, final response is received (positive/negative)


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Request' => 
	SCALAR 'Purpose' => 
	SCALAR 'Response' => 


=head2 PARAMETER EXAMPLES

	Purpose = 'To check that NRC $78 is sent if a request was correctly received but the response is not possible within P2CAN_Server time'
	
	Response = 'NRC_requestCorrectlyReceived_ResponsePending'
	Request = 'ClearDTCInformation_all'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_Request;
my ( %tcpar_CommunicationType, %tcpar_Key, %tcpar_Data, %tcpar_IOControlState, %tcpar_RoutineControlOption );

################ global parameter declaration ###################
#add any global variables here
my %DataValue;
my $reqresp_href;
my ($status, $time_aref, $response_aref);
my $P2CAN_Server_time;

###############################################################

sub TC_set_parameters {

	$tcpar_Purpose =  GEN_Read_mandatory_testcase_parameter( 'Purpose' );
	$tcpar_Request =  GEN_Read_mandatory_testcase_parameter( 'Request' );
	
	#handle required bytes in request
    $DataValue{'StatusMask'}                  = GEN_Read_optional_testcase_parameter('StatusMask');
    $DataValue{'DTC'}                         = GEN_Read_optional_testcase_parameter('DTC');
    $DataValue{'DTCSnapshotRecordNumber'}     = GEN_Read_optional_testcase_parameter('DTCSnapshotRecordNumber');
    $DataValue{'DTCExtendedDataRecordNumber'} = GEN_Read_optional_testcase_parameter('DTCExtendedDataRecordNumber');

    %tcpar_CommunicationType    = GEN_Read_optional_testcase_parameter('CommunicationType');
    %tcpar_Key                  = GEN_Read_optional_testcase_parameter('Key');
    %tcpar_Data                 = GEN_Read_optional_testcase_parameter('Data');
    %tcpar_IOControlState       = GEN_Read_optional_testcase_parameter('IOControlState');
    %tcpar_RoutineControlOption = GEN_Read_optional_testcase_parameter('RoutineControlOption');

	return 1;
}

sub TC_initialization {

	S_teststep("StandardPrepNoFault", 'AUTO_NBR');
#	GEN_StandardPrepNoFault();
	DIAG_ECUReset_NOVERDICT ();
	S_wait_ms ('TIMER_ECU_READY', 'wait after reset');
	PD_ReadFaultMemory_NOERROR();
	
	GDCOM_start_CyclicTesterPresent();
	GDCOM_set_addressing_mode('physical');
	S_wait_ms (100);

	return 1;
}

sub TC_stimulation_and_measurement {

#	S_teststep("Enter session supported by the service. Get security access if required", 'AUTO_NBR');
	$tcpar_Request =~ m/(.*?)_(.*)/;
	
    my $SID = S_get_contents_of_hash( [ 'Mapping_DIAG', 'PRJ_SUPPORTED_SERVICES', $1]);
	my $SubFunc = S_get_contents_of_hash( [ 'Mapping_DIAG', 'DIAG_SERVICES', $1,'Supported_SubFuns', $2]) if($1 !~ m/ReadDTC/i);
    _fillRequestInputParameters ($SID, $SubFunc) if($1 !~ m/ReadDTC/i);
		
	if ($SID eq '2E'){ #for 2E service, write the same value as read by 22 service
    	my $DID = $SubFunc;
    	my $readdata = GDCOM_request_NOVERDICT ("22 $DID", "62 $DID", 'relax');
    	$readdata = substr($readdata, 9); #remove 62 DIDHB DIDLB
    	$DataValue{'Data'} = $readdata if (defined $readdata);
    }
        
    my $supportedSessions = _getSupportedSessions($tcpar_Request);
    S_w2rep("Sessions supported by '$tcpar_Request': @$supportedSessions");
    
    S_teststep( "Enter session: @$supportedSessions[0]", 'AUTO_NBR' );
    my $session_resp = DIAG_StartSession( @$supportedSessions[0] );
    
    my $session_resp_aref = GEN_byteString2hexaref($session_resp);
    $P2CAN_Server_time = hex(@$session_resp_aref[3]);
    S_w2rep( "P2CAN_Server time = $P2CAN_Server_time ms" );
    
    my $securityLevelsForRequest = _getSecurityLevelsForRequest($tcpar_Request);

    if ( @$securityLevelsForRequest[0] !~ m/None/i and @$securityLevelsForRequest[0] ne '---' and @$securityLevelsForRequest[0] ne 'n/a' ){ #in case security access is required
    	S_teststep_2nd_level("Get required security access: @$securityLevelsForRequest", 'NO_AUTO_NBR');
    	DIAG_getSecurityAccess (@$securityLevelsForRequest[0]) if (defined &DIAG_getSecurityAccess);
    }
    else{
   		S_teststep_2nd_level("Security access not required for request '$tcpar_Request'", 'NO_AUTO_NBR');
    }

    GDCOM_GetAccessToRequest ($tcpar_Request); #handle any dependent services through request in Mapping_DIAG (if required)
	
	my $requestBytes = GDCOM_getRequestLabelValue( "REQ_" . $tcpar_Request, \%DataValue );

	S_teststep("Send '$tcpar_Request' and measure the time for ECU to send first response frame", 'AUTO_NBR', 'send_request_and');			#measurement 1
	GDCOM_CA_trace_stop();
	GDCOM_CA_trace_start();

	($status, $time_aref, $response_aref) = CD_CAN_send_request_wait_response ( GEN_byteString2hexaref($requestBytes) ); 
	
	S_w2rep ("response status: $status");
	S_w2rep ("response times: @$time_aref");
#	S_w2rep ("response bytes: @$response_aref");

	# store the request and reponse from the can log file
    my $Trace_StoredfilePath = GEN_printLink ( GEN_generateUniqueTraceName() );
    GDCOM_CA_trace_stop($Trace_StoredfilePath);
    
	S_teststep( "\n", 'NO_AUTO_NBR' ); #for newline in TR

	return 1;
}

sub TC_evaluation {

	S_teststep_expected("If the first frame of the response (positive/negative) is not sent within P2CAN_Server time, NRC $78 is received. After NRC $78, final response is received (positive/negative)", 'send_request_and');			#evaluation 1
	if(not defined $status or $status == 3){
		S_teststep_detected("No response received", 'send_request_and');
	}
	elsif($status == 0){
		S_teststep_detected("Positive response received (without NRC78). First frame of positive response received after @$time_aref[0] ms", 'send_request_and');
	}
	elsif($status == 1){
		S_teststep_detected("Response received after NRC78. NRC78 received after @$time_aref[0] ms", 'send_request_and');
	}
	elsif($status == 2){
		S_teststep_detected("Negative response (without NRC78) received after @$time_aref[0] ms", 'send_request_and');
	}
	
	
	if (not defined $status or $status == 3){
		S_teststep_detected("No evaluation possible since no response is received.");
		S_set_verdict ( 'VERDICT_PASS' );
	}
	else{
		if( @$time_aref[0] > $P2CAN_Server_time){ #in all cases (status 0 to 2), first response frame should be received within P2CAN_Server time
			S_teststep_detected("NRC78 or first response frame is NOT received within P2CAN_Server ($P2CAN_Server_time) ms");
			S_set_verdict ( 'VERDICT_FAIL' );
		}
		else{
			S_teststep_detected("NRC78 or first response frame is received within P2CAN_Server ($P2CAN_Server_time) ms");
			S_set_verdict ( 'VERDICT_PASS' );
		}
	}
	
	return 1;
}

sub TC_finalization {
	
	GDCOM_CA_trace_start();
	
	GDCOM_stop_CyclicTesterPresent();

	return 1;
}

sub _getSupportedSessions {
    my $reqLabel = shift;

    return GDCOM_getRequestInfofromMapping ($reqLabel)->{'allowed_in_sessions'};
}


sub _getSecurityLevelsForRequest {
    my $reqLabel = shift;

    return GDCOM_getRequestInfofromMapping ($reqLabel)->{'allowed_in_securitylevels'};
}

sub _fillRequestInputParameters {
    my $SID = shift;
    my $subFunc = shift;
    

    if($SID eq '27'){
        $DataValue{'Key'} = $tcpar_Key{$subFunc};
    }
    elsif($SID eq '28'){
        $DataValue{'CommunicationType'} = $tcpar_CommunicationType{$subFunc};
    }
    elsif($SID eq '2E'){
        $DataValue{'Data'} = $tcpar_Data{$subFunc};
    }
    elsif($SID eq '2F'){
        $DataValue{'IOControlState'} = $tcpar_IOControlState{$subFunc};
    }
    elsif($SID eq '2F'){
        $DataValue{'IOControlState'} = $tcpar_IOControlState{$subFunc};
    }
    elsif($SID eq '31'){
        $DataValue{'RoutineControlOption'} = $tcpar_RoutineControlOption{$subFunc};
    }

}


1;
