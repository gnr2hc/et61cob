#### TEST CASE MODULE
package TC_DSM_TesterPresent;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.6 $;
our $HEADER  = q$Header: DSM_AB12/TC_DSM_TesterPresent.pm 1.6 2018/04/23 14:43:12ICT Nguyen Van Truc (RBVH/EPS24) (GNR2HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_TesterPresent3E
#TS version in DOORS: 0.4
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use GENERIC_DCOM;
##################################

our $PURPOSE = "To verify that the server keeps Session alive till the Tester Present message is being received within the session expiry time";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_TesterPresent

=head1 PURPOSE

To verify that the server keeps Session alive till the Tester Present message is being received within the session expiry time

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Set Addressing_Mode as per Project specific SPR.

2. Send <Request_TesterPresent>.

3. Send request to enter <Session>.

4. Send Tester Present cyclically(default cyclic is 4000 msec)

5. Wait for <WaitTime> in msec.

6. Send request <Read_ActiveSession>.

7. Stop tester present.

8. Wait for <S3ServerTime > in msec.

9. Send request <Read_ActiveSession>.


I<B<Evaluation>>

1. 

2. <Response_Nature> shall be obtained.

3. Positive response shall be obtained.

4. 

5. 

6. Current session shall be <ActiveSession>.

7. 

8.

9. Current session shall be DefaultSession.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Session' => 
	SCALAR 'ActiveSession' => 
	SCALAR 'purpose' => 
	SCALAR 'WaitTime' => 
	SCALAR 'Request_TesterPresent' => 
	SCALAR 'S3ServerTime' => 
	SCALAR 'Read_ActiveSession' => 
	SCALAR 'Request_Type' => 
	SCALAR 'Request_TP' => 
	SCALAR 'Response_Nature' => 


=head2 PARAMETER EXAMPLES

	purpose = 'To verify that the server shall keep any session alive till the tester present message is being received within session expiry time'
	
	# input parameters 
	WaitTime = 10000 # less than S3server time and it is in ms
	Request_TesterPresent = 'TesterPresent_zeroSubfunction' #3E 00
	S3ServerTime = 5000 #it is in ms
	Read_ActiveSession = 'ReadDataByIdentifier_F186' # 22 F186
	PR_ActiveSession_ByteNbr= '03'#this is the byte number for active session in the read active session positive response, count from '0'.
	Request_Type =  '<Test Heading Tail>'
	Request_TP = 'TesterPresent_zeroSubfunction' #used only to fetch supported addressing modes from Diag mapping file for TCs with positive response suppression
	#output parameters
	Response_Nature = 'PR_TesterPresent_zeroSubfunction'
	Session = 'DiagnosticSessionControl_ExtendedSession'
	ActiveSession = '03'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_WaitTime;
my $tcpar_Request_TesterPresent;
my $tcpar_S3ServerTime;
my $tcpar_Read_ActiveSession;
my $tcpar_Request_Type;
my $tcpar_Request_TP;
my $tcpar_Response_Nature;
my $tcpar_Session;
my $tcpar_ActiveSession;
my $tcpar_PR_ActiveSession_ByteNbr;
################ global parameter declaration ###################
#add any global variables here
my $Addressing_Mode;
my $mode;
my $actses_resbef;
my $actses_resaft;
my @activesession_res;
my $defaultsession = 01;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose                  = GEN_Read_mandatory_testcase_parameter('purpose');
	$tcpar_WaitTime                 = GEN_Read_mandatory_testcase_parameter('WaitTime');
	$tcpar_Request_TesterPresent    = GEN_Read_mandatory_testcase_parameter('Request_TesterPresent');
	$tcpar_S3ServerTime             = GEN_Read_mandatory_testcase_parameter('S3ServerTime');
	$tcpar_Read_ActiveSession       = GEN_Read_mandatory_testcase_parameter('Read_ActiveSession');
	$tcpar_Request_Type             = GEN_Read_mandatory_testcase_parameter('Request_Type');
	$tcpar_Request_TP               = GEN_Read_mandatory_testcase_parameter('Request_TP');
	$tcpar_Response_Nature          = GEN_Read_mandatory_testcase_parameter('Response_Nature');
	$tcpar_Session                  = GEN_Read_mandatory_testcase_parameter('Session');
	$tcpar_ActiveSession            = GEN_Read_mandatory_testcase_parameter('ActiveSession');
	$tcpar_PR_ActiveSession_ByteNbr = GEN_Read_mandatory_testcase_parameter('PR_ActiveSession_ByteNbr');

	return 1;
}

sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();
	S_wait_ms(5000);
	return 1;
}

sub TC_stimulation_and_measurement {

	if ( $tcpar_Request_Type eq 'TPResponse' ) {
		$Addressing_Mode = GDCOM_getRequestInfofromMapping($tcpar_Request_TesterPresent)->{'allowed_in_addressingmodes'};
	}
	elsif ( $tcpar_Request_Type eq 'TPResponseSuppressed' ) {
		$Addressing_Mode = GDCOM_getRequestInfofromMapping($tcpar_Request_TP)->{'allowed_in_addressingmodes'};
	}

	S_teststep( "Supported Addressing_Mode as per Project specific SPR. @$Addressing_Mode", 'NO_AUTO_NBR' );

	foreach $mode (@$Addressing_Mode) {
		S_teststep( "Set addressing mode to : $mode", 'AUTO_NBR' );
		GDCOM_set_addressing_mode($mode);
		S_wait_ms(100);

		S_teststep( "Send '$tcpar_Request_TesterPresent'.", 'AUTO_NBR', "Send_tester_present_in_$mode" );
		if ( $tcpar_Request_Type eq 'TPResponse' ) {
			my $tp_withResponse = GDCOM_request_general( "REQ_" . $tcpar_Request_TesterPresent, $tcpar_Response_Nature );
			S_teststep_expected( "'$tcpar_Response_Nature' shall be obtained.", "Send_tester_present_in_$mode" );    #evaluation 2
			S_teststep_detected( "Obtained response is $tp_withResponse", "Send_tester_present_in_$mode" );
		}
		else {
			my $tp_withnoResponse = GDCOM_request( $tcpar_Request_TesterPresent, '', 'quiet' );
			S_teststep_expected( "'$tcpar_Response_Nature' shall be obtained.", "Send_tester_present_in_$mode" );
			S_teststep_detected( "Obtained response is $tp_withnoResponse", "Send_tester_present_in_$mode" );
		}

		S_teststep( "Send request to enter '$tcpar_Session'.", 'AUTO_NBR', "Enter session_in_$mode" );               #measurement 1
		my $session_Response = GDCOM_request_general( "REQ_" . $tcpar_Session, "PR_" . $tcpar_Session );
		S_teststep_expected( "Positive shall be obtained.", "Enter session_in_$mode" );                              #evaluation 1
		S_teststep_detected( "Obtained Response is $session_Response", "Enter session_in_$mode" );

		S_teststep( "Send '$tcpar_Request_TesterPresent' cyclically.", 'AUTO_NBR' );                                 #measurement 2
		GDCOM_start_CyclicTesterPresent();

		S_teststep( "Wait for '$tcpar_WaitTime' in msec.", 'AUTO_NBR' );
		S_wait_ms($tcpar_WaitTime);

		S_teststep( "Send request '$tcpar_Read_ActiveSession'.", 'AUTO_NBR', "Read_active_session_1_in_$mode" );
		my $actses_resbef_1     = ReadActiveSession();
		my @activesession_res_1 = split( / /, $actses_resbef_1 );                                                    # Split all the response bytes of Step1 to array
		_evaluateActiveSession( $tcpar_ActiveSession, $activesession_res_1[$tcpar_PR_ActiveSession_ByteNbr] );
		S_teststep_expected( "Current session shall be '$tcpar_ActiveSession'.", "Read_active_session_1_in_$mode" );    #evaluation 3
		S_teststep_detected( "Session obtained $activesession_res_1[$tcpar_PR_ActiveSession_ByteNbr]", "Read_active_session_1_in_$mode" );

		S_teststep( "Stop tester present.", 'AUTO_NBR' );
		GDCOM_stop_CyclicTesterPresent();

		S_teststep( "Wait for '$tcpar_S3ServerTime ' in msec.", 'AUTO_NBR' );
		S_wait_ms($tcpar_S3ServerTime);

		if ( $tcpar_ActiveSession eq '02' ) {

			#ECU reset is expected when server is comign out of Programming session. Hence additional delay given to read active session
			S_teststep( "ECU reset is expected when server is comign out of Programming session, hence additional delay of 1000 msec is given before reading active session", 'NO_AUTO_NBR' );
			S_wait_ms(1000);
		}

		S_teststep( "Send request '$tcpar_Read_ActiveSession'.", 'AUTO_NBR', "Read_active_session_2_in_$mode" );    #measurement 4
		my $actses_resbef_2 = ReadActiveSession();
		my @activesession_res_2 = split( / /, $actses_resbef_2 );                                                   # Split all the response bytes of Step1 to array
		_evaluateActiveSession( '01', $activesession_res_2[$tcpar_PR_ActiveSession_ByteNbr] );
		S_teststep_expected( "Current session shall be '01'.", "Read_active_session_2_in_$mode" );                  #evaluation 3
		S_teststep_detected( "Session obtained $activesession_res_2[$tcpar_PR_ActiveSession_ByteNbr]", "Read_active_session_2_in_$mode" );
	}
	return 1;
}

sub TC_evaluation {
	S_w2rep("Evaluation is done above in stimulation_and_measurement");
	return 1;
}

sub TC_finalization {

	#Revert back to physical addressing mode
	GDCOM_set_addressing_mode('physical');
	S_wait_ms(5000);
	return 1;
}

sub _evaluateActiveSession {

	#function to evaluate current session based on the obatined active session against the expected session
	my $expected_Session = shift;
	my $obtained_Session = shift;

	if ( hex($obtained_Session) == $expected_Session ) {
		S_set_verdict('VERDICT_PASS');
	}
	else {
		S_set_verdict('VERDICT_FAIL');
	}
}

sub ReadActiveSession {

	if ( $tcpar_Read_ActiveSession =~ m/rb_/i ) {    #read from SW variable
		return DIAG_ReadActiveSession_SW_var($tcpar_Read_ActiveSession);
	}
	else {
		return GDCOM_request_general( "REQ_" . $tcpar_Read_ActiveSession, "PR_" . $tcpar_Read_ActiveSession );
	}
}

1;
