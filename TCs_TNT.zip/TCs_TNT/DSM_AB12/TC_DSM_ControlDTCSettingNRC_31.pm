#### TEST CASE MODULE
package TC_DSM_ControlDTCSettingNRC_31;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.2 $;
our $HEADER = q$Header: DSM_AB12/TC_DSM_ControlDTCSettingNRC_31.pm 1.2 2017/08/29 20:56:37ICT Chetan Balkunje Shenoy (RBEI/ESA-PP3) (chb1kor) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_ControlDTCSetting 
#TS version in DOORS: 0.2
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
use LIFT_can_access;
use LIFT_labcar;
use GENERIC_DCOM;
use LIFT_PD;
use LIFT_CD;
use LIFT_evaluation;
use LIFT_DCOM;
#include further modules here

##################################

our $PURPOSE = "To verify that NRC 31 is received when conditions are met.";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_CtrlDTCSettingNRCs

=head1 PURPOSE

To verify that NRC 31 is received when conditions are met.

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>


I<B<Evaluation>>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'Session' => 
	SCALAR 'ControlDTCOFF' => 
	SCALAR 'ControlDTCON' => 
	LIST 'DTCSettingControlOptionRecord' => 
	SCALAR 'Response' => 


=head2 PARAMETER EXAMPLES

	purpose		 = 'Check NRC handling for the the request COntrolDTCSettings with different conditions'
	# input parameters
	Session = 'TBD'
	ControlDTCOFF 	= 'ControlDTCSetting_OFF' #85 02
	ControlDTCON 	= 'ControlDTCSetting_On' #85 01
	DTCSettingControlOptionRecord = @('05', '06', 'FF')
	
	Response = '<Test Heading>'
	
	# output parameters

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Session;
my $tcpar_ControlDTCOFF;

my @tcpar_DTCSettingControlOptionRecord;

################ global parameter declaration ###################
#add any global variables here


###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_Session =  GEN_Read_mandatory_testcase_parameter( 'Session' );
	$tcpar_ControlDTCOFF =  GEN_Read_mandatory_testcase_parameter( 'ControlDTCOFF' );
	@tcpar_DTCSettingControlOptionRecord = GEN_Read_mandatory_testcase_parameter( 'DTCSettingControlOptionRecord');
	return 1;
}

sub TC_initialization {

	S_teststep("StandardPrepNoFault", 'AUTO_NBR');
	GEN_StandardPrepNoFault();
	S_wait_ms(5000);
	S_teststep("Send Tester present cyclically.", 'AUTO_NBR');
	GDCOM_start_CyclicTesterPresent();
	return 1;
}

sub TC_stimulation_and_measurement {
	S_teststep("Set Addressing_Mode as per Project specific SPR.", 'AUTO_NBR');
	my $Addressing_Mode = GDCOM_getRequestInfofromMapping ($tcpar_ControlDTCOFF)->{'allowed_in_addressingmodes'};
	foreach my $mode (@$Addressing_Mode) {	
		S_teststep("Set addressing mode to : $mode", 'AUTO_NBR');
		GDCOM_set_addressing_mode($mode);
		
		S_teststep("Send request to enter '$tcpar_Session'.", 'AUTO_NBR', );			#measurement 1
		my $session_Response = GDCOM_request_general("REQ_".$tcpar_Session,"PR_".$tcpar_Session);		
		S_teststep_expected("Positive shall be obtained.");			
		S_teststep_detected("Obtained Response is $session_Response");
		foreach my $record(@tcpar_DTCSettingControlOptionRecord){
			my $ControlDTCOFFResponse  = GDCOM_request('85 02 '.$record, '7F 85 31','strict');
			S_teststep_expected("7F 85 31' shall be obtained.");			
			S_teststep_detected("Obtained response is $ControlDTCOFFResponse");
			S_wait_ms(5000);
			
			my $ControlDTCONResponse  = GDCOM_request('85 01 '.$record, '7F 85 31','strict');
			S_teststep_expected("7F 85 31' shall be obtained.");			
			S_teststep_detected("Obtained response is $ControlDTCONResponse");
			S_wait_ms(5000);
		}
	}
	return 1;
}

sub TC_evaluation {
	S_w2rep("Evaluation is done above in stimulation_and_measurement");
	return 1;
}

sub TC_finalization {
	PD_ClearFaultMemory();
	S_wait_ms(5000);
	GDCOM_stop_CyclicTesterPresent();
	LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');
	return 1;
}


1;
