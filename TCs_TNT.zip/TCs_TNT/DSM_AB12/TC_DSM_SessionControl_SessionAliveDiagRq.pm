#### TEST CASE MODULE
package TC_DSM_SessionControl_SessionAliveDiagRq;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.3 $;
our $HEADER =
q$Header: DSM_AB12/TC_DSM_SessionControl_SessionAliveDiagRq.pm 1.3 2018/04/24 17:59:36ICT ver6cob develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_SessionControl
#TS version in DOORS: 0.1
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use GENERIC_DCOM;
use LIFT_DCOM;
use LIFT_evaluation;
use LIFT_labcar;
use LIFT_PD;
##################################

our $PURPOSE =
"To verify that ECU remains in current session session is kept alive by a Diagnostic reqeust";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_SessionControl_SessionAliveDiagRq

=head1 PURPOSE

To verify that ECU remains in current session session is kept alive by a Diagnostic reqeust

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Set Addressing Mode and Protocol

2. Start sending a <DiagReadRequest> periodically at 4.5 sec cycle time

3. Request <Session>

4. Wait for 15 secs

5. Read the active session by sending <ReadActiveSession>

6. Stop the periodic transmission of  

<DiagReadRequest>

# Repeat the above steps for all supported Addressing modes as defined in the SPR


I<B<Evaluation>>

1.

2. Positive Response with current session is reported

3. Postive Response is obtained

4. 

5. ECU sends Positive Response and session reported is <Session>

6.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'DiagReadRequest' => 
	SCALAR 'Purpose' => 
	SCALAR 'Session' => 
	SCALAR 'ReadActiveSession' => 
	SCALAR 'PR_ActiveSession_ByteNbr' => 


=head2 PARAMETER EXAMPLES

	Purpose  = 'To verify that ECU remains in current session session is kept alive by a Diagnostic reqeust'
	
	Session       = 'DiagnosticSessionControl_<Test Heading Head>'
	ReadActiveSession =  'ReadDataByIdentifier_ActiveDiagnosticSession'
	PR_ActiveSession_ByteNbr= '03'#this is the byte number for active session in the read active session positive response, count from '0'.
	DiagReadRequest = 'ReadDataByIdentifier_ECUSerialNumber'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_Session;
my $tcpar_ReadActiveSession;
my $tcpar_PR_ActiveSession_ByteNbr;
my $tcpar_DiagReadRequest;

################ global parameter declaration ###################
#add any global variables here
my $Addressing_Mode;
my $msgID;
my $CycleTime = 4500;
my $ActiveSession;
my $response;
my @session_Response;
my %Session_active = (
	'DefaultSession'     => '01',
	'ProgrammingSession' => '02',
	'ExtendedSession'    => '03',
);
###############################################################

sub TC_set_parameters {

	$tcpar_Purpose 					= GEN_Read_mandatory_testcase_parameter('Purpose');
	$tcpar_Session 					= GEN_Read_mandatory_testcase_parameter('Session');
	$tcpar_ReadActiveSession 		= GEN_Read_mandatory_testcase_parameter('ReadActiveSession');
	$tcpar_PR_ActiveSession_ByteNbr = GEN_Read_mandatory_testcase_parameter('PR_ActiveSession_ByteNbr');
	$tcpar_DiagReadRequest 			= GEN_Read_mandatory_testcase_parameter('DiagReadRequest');

	return 1;
}

sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	#    GEN_StandardPrepNoFault();
	DIAG_ECUReset_NOVERDICT ();
	S_wait_ms ('TIMER_ECU_READY', 'wait after reset');
	PD_ReadFaultMemory_NOERROR();
	
	# GDCOM_start_CyclicTesterPresent();
	# GDCOM_set_addressing_mode('physical');

	return 1;
}

sub TC_stimulation_and_measurement {

	#Get addressing mode supported for request from Mapping Diag
	$Addressing_Mode = GDCOM_getRequestInfofromMapping(	'DiagnosticSessionControl_' . $tcpar_Session )->{'allowed_in_addressingmodes'};

	#Get the request value of $tcpar_DiagReadRequest to prepare for DCOM_start_CyclicMessage function
	my $requestdata = GDCOM_getRequestLabelValue( 'REQ_' . $tcpar_DiagReadRequest );
	my @request_bytes = split( / /, $requestdata );
	foreach (@request_bytes) { $_ = hex($_); }
	unshift( @request_bytes, scalar(@request_bytes) );
	for ( my $index = $#request_bytes + 1 ; $index < 8 ; $index++ ) {
		push( @request_bytes, 0 );
	}
	S_teststep( "# Repeat test steps for all supported Addressing modes as defined in the SPR",	'AUTO_NBR'	);
	foreach my $mode (@$Addressing_Mode) {
		S_teststep( "Set Addressing Mode to: '$mode'", 'AUTO_NBR' );
		GDCOM_set_addressing_mode($mode);

		S_teststep( "Start sending a '$tcpar_DiagReadRequest' periodically at 4.5 sec cycle time", 'AUTO_NBR', "start_sending_in_$mode"	);    #measurement 1
		if ( $mode =~ /physical/ ) { 
			$msgID = $LIFT_PROJECT::Defaults->{"CUSTOMER_DIAGNOSIS"}{'RequestID_physical'};
		}
		if ( $mode =~ /functional/ ) {
			$msgID = $LIFT_PROJECT::Defaults->{"CUSTOMER_DIAGNOSIS"}{'RequestID_functional'};
		}
		my $MSG_Handle =  DCOM_start_CyclicMessage( \@request_bytes, $msgID, $CycleTime );
		S_wait_ms(2000);

		S_teststep( "Request '$tcpar_Session'",	'AUTO_NBR', "request_session_in_$mode" );    #measurement 2
		$response = GDCOM_request_general( 'REQ_DiagnosticSessionControl_' . $tcpar_Session, 'PR_DiagnosticSessionControl_' . $tcpar_Session );
		S_teststep_expected( "Postive Response is obtained" , "request_session_in_$mode" );			#evaluation 2
		S_teststep_detected( "Response from ECU is: '$response'", "request_session_in_$mode" );

		S_teststep( "Wait for 15 secs", 'AUTO_NBR' );
		S_wait_ms(15000);

		S_teststep(	"Read the active session by sending '$tcpar_ReadActiveSession'", 'AUTO_NBR', "read_the_active_in_$mode" );    #measurement 3
		$ActiveSession = ReadActiveSession ();
		@session_Response = split( / /, $ActiveSession );
		S_teststep_expected( "ECU sends Positive Response and session reported is '$tcpar_Session'", "read_the_active_in_$mode"	);                                               #evaluation 3
		S_teststep_detected( "ECU response is $session_Response[$tcpar_PR_ActiveSession_ByteNbr]", "read_the_active_in_$mode" );
		EVAL_evaluate_value( "Active Session",	$session_Response[$tcpar_PR_ActiveSession_ByteNbr],	'==', $Session_active{$tcpar_Session} );

		S_teststep(	"Stop the periodic transmission of '$tcpar_DiagReadRequest'", 'AUTO_NBR' );
		DCOM_stop_CyclicMessage($MSG_Handle);
	}

	return 1;
}

sub TC_evaluation {

	S_w2rep("Evaluation is done above in stimulation_and_measurement");

	return 1;
}

sub TC_finalization {

	GDCOM_set_addressing_mode('physical');
	S_wait_ms(6000);
	# LC_ECU_Off();
	# S_wait_ms('TIMER_ECU_OFF');

	return 1;
}

sub ReadActiveSession {
	
	if($tcpar_ReadActiveSession =~ m/rb_/i){ #read from SW variable
		return DIAG_ReadActiveSession_SW_var ( $tcpar_ReadActiveSession );
	}
	else{
		return GDCOM_request_general("REQ_".$tcpar_ReadActiveSession,"PR_".$tcpar_ReadActiveSession);
	}
}

1;