#### TEST CASE MODULE
package TC_DSM_NRC_BusyRepeatRequest_ServerNotReady;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.2 $;
our $HEADER = q$Header: DSM_AB12/TC_DSM_NRC_BusyRepeatRequest_ServerNotReady.pm 1.2 2017/08/11 16:08:07ICT ver6cob develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_NegativeResponseCodes
#TS version in DOORS: 0.3
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use GENERIC_DCOM;
use LIFT_PD;
##################################

our $PURPOSE = "To verify that NRC21 is sent when the server is not ready or busy";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_NRC_BusyRepeatRequest_ServerNotReady

=head1 PURPOSE

To verify that NRC21 is sent when the server is not ready or busy

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1.  Send <Request>

2.  Send <Service> immediately after Request1 


I<B<Evaluation>>

1. -

2. <Response> is received


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'Request' => 
	SCALAR 'Service' => 
	SCALAR 'Response' => 


=head2 PARAMETER EXAMPLES

	purpose = 'To verify that NRC $21 is received if the ECU is busy/multiple requests are received at the same time'
	
	Request = 'DiagnosticSessionControl_ProgrammingSession'
	Service = '<Test Heading 2>'
	Response = 'NR_BusyRepeatRequest'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Request;
my $tcpar_Service;
my $tcpar_Response;

################ global parameter declaration ###################
#add any global variables here


###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_Request =  GEN_Read_mandatory_testcase_parameter( 'Request' );
	$tcpar_Service =  GEN_Read_mandatory_testcase_parameter( 'Service' );
	$tcpar_Response =  GEN_Read_mandatory_testcase_parameter( 'Response' );

	return 1;
}

sub TC_initialization {

	S_teststep("StandardPrepNoFault", 'AUTO_NBR');
#	GEN_StandardPrepNoFault();

	DIAG_ECUReset_NOVERDICT ();
	S_wait_ms ('TIMER_ECU_READY', 'wait after reset');
	PD_ReadFaultMemory_NOERROR();
    
    GDCOM_start_CyclicTesterPresent();
    GDCOM_set_addressing_mode('physical');
    
    GDCOM_request ('10 03', '50 03', 'relax'); #enter extended session before sending 10 02

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Send '$tcpar_Request'", 'AUTO_NBR');
	GDCOM_request_general( "REQ_" . $tcpar_Request,  "PR_" . $tcpar_Request);

	S_teststep("Send request '$tcpar_Service' immediately after above request ", 'AUTO_NBR', 'send_service_immediately');			#measurement 1
	if ($tcpar_Response eq 'NoResponse'){
		my $response = GDCOM_request( $tcpar_Service, "", 'quiet' );

        S_teststep_expected( "no response", 'send_service_immediately' );                           #evaluation 1
        S_teststep_detected( $response, 'send_service_immediately' );
	}
	else{
		my $response = GDCOM_request( $tcpar_Service, "7F $tcpar_Service 21", 'strict' );

	    S_teststep_expected( "7F $tcpar_Service 21", 'send_service_immediately' );                        #evaluation 1
	    S_teststep_detected( $response, 'send_service_immediately' );
	}
	
    
    S_wait_ms (5000);

	return 1;
}

sub TC_evaluation {

	S_w2rep("Evaluation is done above in stimulation_and_measurement");
	
	return 1;
}

sub TC_finalization {
	
	GDCOM_stop_CyclicTesterPresent();

	return 1;
}


1;
