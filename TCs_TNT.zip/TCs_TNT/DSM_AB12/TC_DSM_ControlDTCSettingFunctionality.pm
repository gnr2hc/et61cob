#### TEST CASE MODULE
package TC_DSM_ControlDTCSettingFunctionality;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.4 $;
our $HEADER  = q$Header: DSM_AB12/TC_DSM_ControlDTCSettingFunctionality.pm 1.4 2019/08/16 22:28:26ICT Nguyen Van Truc (RBVH/EPS24) (GNR2HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_ControlDTCSetting
#TS version in DOORS: 0.2
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
use LIFT_can_access;
use LIFT_labcar;
use GENERIC_DCOM;
use LIFT_PD;
use LIFT_CD;
use LIFT_evaluation;
use LIFT_DCOM;
##################################

our $PURPOSE = "To cross check the functionality of ControlDTCSettings request DTCSettingType as ON and OFF for external and internal faults. ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_CtrlDTCSettingFunctionality

=head1 PURPOSE

To cross check the functionality of ControlDTCSettings request DTCSettingType as ON and OFF for external and internal faults. 

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation

Send Tester present continuously.


I<B<Stimulation and Measurement>>

1. Set Addressing_Mode as per Project specific SPR.

2. Send request to enter <Session>.

3. Send request <ControlDTCOFF>. 

4. Wait for 500 msec. Send request <ControlDTCOFF> again after receiving positive response for previous request.

5. Create faults <ExternalFaults> and <InternalFaults>. Wait for <WaitTime> in msec.

6. Read Fault Recorder using PD and CD.

7. Send Request <ControlDTCON>. 

8. Wait for 500 msec. Send Request <ControlDTCON> again after receiving positive response for previous request.

9. Wait for <WaitTime> in msec. 

10. Read Fault Recorder using PD and CD.

11. Send request <ControlDTCOFF>. 

12. Remove faults <ExternalFaults> and wait for <WaitTime> in msec.

13. Read Fault Recorder using PD and CD.

14. Send Request <ControlDTCON>. Wait for <WaitTime> in msec.

15. Read Fault Recorder using PD and CD.


I<B<Evaluation>>

1. 

2. Positive response obtained.

3. <Response_Nature_OFF> obtained the request.

4. <Response_Nature_OFF> obtained the request.

5. 

6. <ExternalFaults> are not present in the fault recorder.

Faults <InternalFaults> has status <QualiStatus>.

7.  <Response_Nature_ON> obtained the request.

8. <Response_Nature_ON> obtained the request.

9. 

10. Faults <ExternalFaults> has status <QualiStatus>.

Faults <InternalFaults> has status <QualiStatus>.

11. <Response_Nature_OFF> obtained the request.

12. 

13. Faults <ExternalFaults> has status <QualiStatus>.

Faults <InternalFaults> has status <QualiStatus>.

14. <Response_Nature_OFF> obtained the request.

15. Faults <ExternalFaults> has status <DeQualiStatus>.

Faults <InternalFaults> has status <QualiStatus>.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'ControlDTCOFF' => 
	SCALAR 'ControlDTCON' => 
	SCALAR 'Session' => 
	LIST 'ExternalFaults' => 
	SCALAR 'InternalFaults' => 
	SCALAR 'WaitTime' => 
	SCALAR 'Message' => 
	SCALAR 'QualiStatus' => 
	SCALAR 'DeQualiStatus' =>  


=head2 PARAMETER EXAMPLES

	purpose = 'To check the functionality of the request COntrolDTCSettings with ON and OFF subfunction' 
	
	# input parameters 
	ControlDTCOFF 	= 'ControlDTCSetting_Off' #85 02
	ControlDTCON 	= 'ControlDTCSetting_On' #85 01
	Session = 'TBD'
	ExternalFaults = @('rb_sqm_SquibResistanceOpenAB1FD_flt', 'rb_swm_OpenLineBLFD_flt', 'rb_psem_OpenLineUFSD_flt')
	InternalFaults = 'TBD'
	WaitTime = 10000 #in msec
	Message = 'TBD' # provide message name to be stopped to create timeout fault.
	
	#output parameters
	QualiStatus = 'TBD' 
	DeQualiStatus = 'TBD'
	Response_Nature_OFF = 'PR_ControlDTCSetting_Off'
	Response_Nature_ON = 'PR_ControlDTCSetting_On'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_ControlDTCOFF;
my $tcpar_ControlDTCON;
my $tcpar_Session;
my @tcpar_ExternalFaults;
my @tcpar_InternalFaults;
my $tcpar_WaitTime;
my $tcpar_Message;
my $tcpar_QualiStatus;
my $tcpar_DeQualiStatus;
my $tcpar_No_ExtFaultStatus;
my $tcpar_Request_Type;

################ global parameter declaration ###################
#add any global variables here

my $mode;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose           = GEN_Read_mandatory_testcase_parameter('purpose');
	$tcpar_ControlDTCOFF     = GEN_Read_mandatory_testcase_parameter('ControlDTCOFF');
	$tcpar_ControlDTCON      = GEN_Read_mandatory_testcase_parameter('ControlDTCON');
	$tcpar_Session           = GEN_Read_mandatory_testcase_parameter('Session');
	@tcpar_ExternalFaults    = GEN_Read_mandatory_testcase_parameter('ExternalFaults');
	@tcpar_InternalFaults    = GEN_Read_optional_testcase_parameter('InternalFaults');
	$tcpar_WaitTime          = GEN_Read_mandatory_testcase_parameter('WaitTime');
	$tcpar_Message           = GEN_Read_optional_testcase_parameter('Message');
	$tcpar_QualiStatus       = GEN_Read_mandatory_testcase_parameter('QualiStatus');
	$tcpar_DeQualiStatus     = GEN_Read_mandatory_testcase_parameter('DeQualiStatus');
	$tcpar_Request_Type      = GEN_Read_mandatory_testcase_parameter('Request_Type');
	$tcpar_No_ExtFaultStatus = GEN_Read_mandatory_testcase_parameter('No_ExtFaultStatus');

	return 1;
}

sub TC_initialization {

	S_teststep( "Standard_Preparation", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( "Send Tester present continuously.", 'AUTO_NBR' );
	GDCOM_start_CyclicTesterPresent();
	S_wait_ms(500);

	return 1;
}

sub TC_stimulation_and_measurement {

	S_w2rep( "Set Addressing_Mode as per Project specific SPR.", 'AUTO_NBR' );
	my $Addressing_Mode = GDCOM_getRequestInfofromMapping($tcpar_ControlDTCOFF)->{'allowed_in_addressingmodes'};
	foreach $mode (@$Addressing_Mode) {
		S_teststep( "Set addressing mode to : $mode", 'AUTO_NBR' );
		GDCOM_set_addressing_mode($mode);

		S_teststep( "Send request to enter '$tcpar_Session'.", 'AUTO_NBR' );    #measurement 1
		my $session_Response = GDCOM_request_general( "REQ_" . $tcpar_Session, "PR_" . $tcpar_Session );
		S_teststep_expected("Positive shall be obtained.");
		S_teststep_detected("Obtained Response is $session_Response");

		S_teststep( "Send request '$tcpar_ControlDTCOFF'. ", 'AUTO_NBR' );      #measurement 2
		my $response = SendControlDTCOFFRequest();

		S_teststep( "Wait for 500 msec. Send request '$tcpar_ControlDTCOFF' again after receiving positive response for previous request.", 'AUTO_NBR' );    #measurement 3
		S_wait_ms(500);

		return 0 unless ($response);
		SendControlDTCOFFRequest();

		S_teststep( "Create faults '@tcpar_ExternalFaults' and '@tcpar_InternalFaults'. Wait for '$tcpar_WaitTime' in msec.", 'AUTO_NBR' );
		foreach my $fault (@tcpar_ExternalFaults) {
			S_teststep_2nd_level( "Create external fault: $fault", 'AUTO_NBR' );
			FM_createFault($fault);
		}

		if ( defined $tcpar_InternalFaults[0] ) {
			foreach my $fault (@tcpar_InternalFaults) {
				S_teststep_2nd_level( "Create internal fault: $fault", 'AUTO_NBR' );
				FM_createFault($fault);
			}
		}
		S_teststep( "Wait for $tcpar_WaitTime ms", 'AUTO_NBR' );
		S_wait_ms($tcpar_WaitTime);

		S_teststep( "Read Fault Recorder using PD and CD.", 'AUTO_NBR' );    #measurement 4
		my $flt_mem_struct_pd_A = PD_ReadFaultMemory();                      #only for checking fault in report
		my $flt_mem_struct_cd_A = CD_read_DTC( '02', '08' );

		foreach my $fault (@tcpar_ExternalFaults) {
			S_teststep_2nd_level( "Check external fault: $fault should not in memory by CD", 'AUTO_NBR' );    #measurement 4
			CD_check_fault_status( $flt_mem_struct_cd_A, $fault, $tcpar_No_ExtFaultStatus );
		}

		if ( defined $tcpar_InternalFaults[0] ) {
			foreach my $fault (@tcpar_InternalFaults) {
				S_teststep_2nd_level( "Check internal fault: $fault in memory", 'AUTO_NBR' );
				CD_check_fault_status( $flt_mem_struct_cd_A, $fault, $tcpar_QualiStatus );
			}
		}

		S_teststep( "Send request '$tcpar_ControlDTCON'. ", 'AUTO_NBR' );                                     #measurement 2
		$response = SendControlDTCONRequest();

		S_teststep( "Wait for 500 msec. Send Request '$tcpar_ControlDTCON' again after receiving positive response for previous request.", 'AUTO_NBR' );    #measurement 6
		S_wait_ms(500);

		return 0 unless ($response);
		S_teststep( "Send Request '$tcpar_ControlDTCON'. ", 'AUTO_NBR' );                                                                                   #measurement 5
		SendControlDTCONRequest();

		S_teststep( "Wait for '$tcpar_WaitTime' in msec. ", 'AUTO_NBR' );
		S_wait_ms($tcpar_WaitTime);

		S_teststep( "Read Fault Recorder using PD and CD.", 'AUTO_NBR' );                                                                                   #measurement 7
		my $flt_mem_struct_pd_B = PD_ReadFaultMemory();
		my $flt_mem_struct_cd_B = CD_read_DTC( '02', '08' );

		foreach my $fault (@tcpar_ExternalFaults) {
			S_teststep_2nd_level( "Check external fault: $fault should not in memory by CD", 'AUTO_NBR' );                                                  #measurement 4
			CD_check_fault_status( $flt_mem_struct_cd_B, $fault, $tcpar_QualiStatus );
		}

		if ( defined $tcpar_InternalFaults[0] ) {
			foreach my $fault (@tcpar_InternalFaults) {
				S_teststep_2nd_level( "Check internal fault: $fault in memory", 'AUTO_NBR' );
				CD_check_fault_status( $flt_mem_struct_cd_B, $fault, $tcpar_QualiStatus );
			}
		}

		S_teststep( "Send request '$tcpar_ControlDTCOFF'. ", 'AUTO_NBR' );                                                                                  #measurement 8
		SendControlDTCOFFRequest();

		S_teststep( "Remove faults '@tcpar_ExternalFaults' and wait for '$tcpar_WaitTime' in msec.", 'AUTO_NBR' );
		foreach my $fault (@tcpar_ExternalFaults) {
			FM_removeFault($fault);
		}

		S_teststep( "Wait for '$tcpar_WaitTime' in msec. ", 'AUTO_NBR' );
		S_wait_ms($tcpar_WaitTime);

		S_teststep( "Read Fault Recorder using PD and CD.", 'AUTO_NBR' );                                                                                   #measurement 9
		my $flt_mem_struct_pd_C = PD_ReadFaultMemory();
		my $flt_mem_struct_cd_C = CD_read_DTC( '02', '08' );

		foreach my $fault (@tcpar_ExternalFaults) {
			S_teststep_2nd_level( "Check external fault: $fault should not in memory by CD", 'AUTO_NBR' );                                                  #measurement 4
			CD_check_fault_status( $flt_mem_struct_cd_C, $fault, $tcpar_QualiStatus );
		}
		if ( defined $tcpar_InternalFaults[0] ) {
			foreach my $fault (@tcpar_InternalFaults) {
				S_teststep_2nd_level( "Check internal fault: $fault in memory", 'AUTO_NBR' );
				CD_check_fault_status( $flt_mem_struct_cd_C, $fault, $tcpar_QualiStatus );
			}
		}

		S_teststep( "Send Request '$tcpar_ControlDTCON'. Wait for '$tcpar_WaitTime' in msec.", 'AUTO_NBR' );                                                #measurement 10
		SendControlDTCONRequest();

		S_teststep( "Wait for '$tcpar_WaitTime' in msec. ", 'AUTO_NBR' );
		S_wait_ms($tcpar_WaitTime);

		S_teststep( "Read Fault Recorder using PD and CD.", 'AUTO_NBR' );                                                                                   #measurement 11
		my $flt_mem_struct_pd_D = PD_ReadFaultMemory();
		my $flt_mem_struct_cd_D = CD_read_DTC( '02', '08' );

		foreach my $fault (@tcpar_ExternalFaults) {
			S_teststep_2nd_level( "Check external fault: $fault should not in memory by CD", 'AUTO_NBR' );                                                  #measurement 4
			CD_check_fault_status( $flt_mem_struct_cd_D, $fault, $tcpar_DeQualiStatus );
		}

		if ( defined $tcpar_InternalFaults[0] ) {
			foreach my $fault (@tcpar_InternalFaults) {
				S_teststep_2nd_level( "Check internal fault: $fault in memory", 'AUTO_NBR' );
				CD_check_fault_status( $flt_mem_struct_cd_D, $fault, $tcpar_QualiStatus );
			}
			foreach my $fault (@tcpar_InternalFaults) {
				S_teststep_2nd_level( "Remove internal fault:$fault ", 'AUTO_NBR' );                                                                        #measurement 4
				FM_removeFault($fault);
			}
		}
		S_teststep( "Wait for '$tcpar_WaitTime' in msec. ", 'AUTO_NBR' );
		S_wait_ms($tcpar_WaitTime);

		S_teststep( "Clear fault memory by PD", 'AUTO_NBR' );
		PD_ClearFaultMemory();
		S_wait_ms( 1000, 'wait for clear fault memory' )

	}
	return 1;
}

sub TC_evaluation {

	S_w2rep("Evaluation is done above in stimulation_and_measurement");
	return 1;
}

sub TC_finalization {

	S_teststep( "Stop tester present", 'AUTO_NBR' );
	GDCOM_stop_CyclicTesterPresent();

	S_teststep( "Reset ECU to remove setting for control DTC", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	return 1;
}

sub SendControlDTCOFFRequest {
	if ( $tcpar_Request_Type eq 'WithoutSuppression' ) {
		my $ControlDTCOFFResponse = GDCOM_request_general( "REQ_" . $tcpar_ControlDTCOFF, "PR_" . $tcpar_ControlDTCOFF );
		S_teststep_detected("Obtained response is $ControlDTCOFFResponse");
	}
	else {
		my $request_value = GDCOM_getRequestLabelValue( "REQ_" . $tcpar_ControlDTCOFF );

		$request_value = _suppressbit_enable($request_value);

		my $tp_withnoResponse = GDCOM_request( $request_value, '', 'quiet' );
		S_teststep_detected("Obtained response is $tp_withnoResponse");
	}
	return 1;
}

sub SendControlDTCONRequest {
	if ( $tcpar_Request_Type eq 'WithoutSuppression' ) {
		my $ControlDTCONResponse = GDCOM_request_general( "REQ_" . $tcpar_ControlDTCON, "PR_" . $tcpar_ControlDTCON );
		S_teststep_detected("Obtained response is $ControlDTCONResponse");
	}
	else {
		my $request_value = GDCOM_getRequestLabelValue( "REQ_" . $tcpar_ControlDTCON );

		$request_value = _suppressbit_enable($request_value);

		my $tp_withnoResponse = GDCOM_request( $request_value, '', 'quiet' );
		S_teststep_detected("Obtained response is $tp_withnoResponse");
	}
	return 1;
}

sub _suppressbit_enable {

	my $request_value = shift;

	my @request_value_arr = split( / /, $request_value );

	$request_value_arr[1] = sprintf( "%02X", hex( $request_value_arr[1] ) | hex(80) );    #the second byte will always is where the suppress bit setting
	$request_value = join( ' ', @request_value_arr );

	return $request_value;
}

1;
