#### TEST CASE MODULE
package TC_DSM_ReadDTC_ChangeInNumberOfFaults;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.3 $;
our $HEADER  = q$Header: DSM_AB12/TC_DSM_ReadDTC_ChangeInNumberOfFaults.pm 1.3 2017/11/22 14:43:44ICT ver6cob develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_ReadDTCInformation
#TS version in DOORS: 4.9
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use GENERIC_DCOM;
use LIFT_CD;
use LIFT_evaluation;
##################################

our $PURPOSE = "to check the behaviour if the number of DTCs decreases while creating a ReadDTC response";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_ReadDTC_ChangeInNumberOfFaults

=head1 PURPOSE

to check the behaviour if the number of DTCs decreases while creating a ReadDTC response

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Create a fault and send request to read active faults (19 02 01)

2. Remove this fault and immediately keep sending requests to read active faults until the fault has dequalified 


I<B<Evaluation>>

1. DTC is reported with qualified status

2. DTC can be reported with qualified status unitil the fault has dequalified, after that there can be the below possibilities:

DTC 0x000000 can be reported with status 0x00 (if fault was dequalified while creating the response)

No DTC is reported (if fault was already dequalified when request was received) 


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'fault' => 


=head2 PARAMETER EXAMPLES

	purpose = 'to check the behaviour if the number of DTCs decreases while creating a ReadDTC response' 
	# input parameters
	fault = 'rb_sqm_SquibResistanceOpenAB1FD_flt'
	#output parameters

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_fault;

################ global parameter declaration ###################
#add any global variables here

###############################################################

sub TC_set_parameters {

    $tcpar_purpose = GEN_Read_mandatory_testcase_parameter('purpose');
    $tcpar_fault   = GEN_Read_mandatory_testcase_parameter('fault');

    return 1;
}

sub TC_initialization {

    S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
    GEN_StandardPrepNoFault();

    return 1;
}

sub TC_stimulation_and_measurement {

    S_teststep( "Create a fault and send request to read active faults (19 02 01)", 'AUTO_NBR', 'create_a_fault' );    #measurement 1
    FM_createFault($tcpar_fault);
    S_wait_ms( 10000, 'wait for qualification time' );
    my $DTC_struct_createFlt = CD_read_DTC( '02', '01' );
	
	my $status = CD_get_fault_status( $DTC_struct_createFlt, $tcpar_fault );
	EVAL_evaluate_value( "DTCStatus", $status, 'MASK', '0bxxxx1xx1' );

	S_teststep_expected("status = 0bxxxx1xx1", 'create_a_fault');
	S_teststep_detected("status = $status", 'create_a_fault');
				

    S_teststep( "Remove this fault and immediately keep sending requests to read active faults until the fault has dequalified ", 'AUTO_NBR', 'remove_this_fault' );    #measurement 2
    FM_removeFault($tcpar_fault);
    foreach ( 1 .. 10 ) {
        my $DTC_struct_removeFlt = CD_read_DTC( '02', '01' );
        my $status = CD_get_fault_status( $DTC_struct_removeFlt, $tcpar_fault );
		
		S_teststep_expected("status = 0bxxxx1xx1 or 0x00", 'remove_this_fault');
		S_teststep_detected("status = $status", 'remove_this_fault');

        unless ( $status ) { #DTC not present in response
            EVAL_evaluate_value( "DTCStatus_RemoveFault", $status, '==', 0 );
            
            my $status_DTC0 = CD_get_fault_status_NOERROR( $DTC_struct_removeFlt, '0x000000' ); #check for DTC 0x000000
            EVAL_evaluate_value( "DTC000000_Status_RemoveFault", $status_DTC0, '==', 0 );
        }
    }

    return 1;
}

sub TC_evaluation {

    S_w2rep("Evaluation is done above in stimulation_and_measurement");

    return 1;
}

sub TC_finalization {

    return 1;
}

1;
