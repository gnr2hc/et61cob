#### TEST CASE MODULE
package TC_DSM_ECUReset_POC;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
###-------------------------------###
our $VERSION = q$Revision: 1.5 $;
our $HEADER  = q$Header: DSM_AB12/TC_DSM_ECUReset_POC.pm 1.5 2018/04/23 14:42:42ICT Nguyen Van Truc (RBVH/EPS24) (GNR2HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_ECUReset
#TS version in DOORS: 0.4
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use GENERIC_DCOM;
use LIFT_PD;
##################################

our $PURPOSE = "<To measure the Power On Counter increment strategy and check the active session after reset>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_ECUReset_POC

=head1 PURPOSE

 Measure the Power On Counter increment strategy and check the active session after reset

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Send request to enter Session which supports ECU Reset

2.  Read the Power On Counter (POC)

3. Trigger <ResetRequest> diagostic request

4. Read the active session by sending <ReadActiveSession>

5. Read the Power On Counter (POC)

# Repeat the above steps for all supported session as defined in the SPR


I<B<Evaluation>>

1. 

2.

3. Positive response is observed

4. ECU reports Default Session

 

5. If <IncrementPOC> is 'Yes', the value of power on counter is incremented by 1 from step 3. Else the value is same as step 3.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'IncrementPOC' => 
	SCALAR 'Purpose' => 
	SCALAR 'ResetRequest' => 
	SCALAR 'ReadActiveSession' => 


=head2 PARAMETER EXAMPLES

	Purpose = 'To check POC behaviour and active session on reset'
	
	
	ResetRequest =  '<Test Heading>'
	
	ReadActiveSession =  'ReadActiveDiagnosticSession'
	IncrementPOC = 'Yes' # IncrementPOC = 'No'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_ResetRequest;
my $tcpar_ReadActiveSession;
my $tcpar_IncrementPOC;
my $tcpar_POCVarName;
my $tcpar_PR_ActiveSession_ByteNbr;

################ global parameter declaration ###################
#add any global variables here
my $AddressingMode;
my $mode;
my $SupportedSession;
my $session;
my $POCvalueOld;
my $POCvalueNew;
my $POCvalueOldRef;
my $POCvalueNewRef;
my @activesession;
my $defaultsession = '01';

###############################################################

sub TC_set_parameters {

	$tcpar_Purpose                  = GEN_Read_mandatory_testcase_parameter('Purpose');
	$tcpar_ResetRequest             = GEN_Read_mandatory_testcase_parameter('ResetRequest');
	$tcpar_ReadActiveSession        = GEN_Read_mandatory_testcase_parameter('ReadActiveSession');
	$tcpar_IncrementPOC             = GEN_Read_mandatory_testcase_parameter('IncrementPOC');
	$tcpar_POCVarName               = GEN_Read_mandatory_testcase_parameter('POCVarName');
	$tcpar_PR_ActiveSession_ByteNbr = GEN_Read_mandatory_testcase_parameter('PR_ActiveSession_ByteNbr');

	return 1;
}

sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();
	GDCOM_start_CyclicTesterPresent();

	return 1;
}

sub TC_stimulation_and_measurement {

	$AddressingMode   = GDCOM_getRequestInfofromMapping($tcpar_ResetRequest)->{'allowed_in_addressingmodes'};
	$SupportedSession = GDCOM_getRequestInfofromMapping($tcpar_ResetRequest)->{'allowed_in_sessions'};

	foreach $mode (@$AddressingMode) {
		S_teststep( "Set addressing mode to : $mode", 'AUTO_NBR' );
		GDCOM_set_addressing_mode($mode);
       S_wait_ms(200);  
		foreach $session (@$SupportedSession) {
			if ( $session =~ m/safety|disposal/i ) {
				S_w2rep("Behaviour in $session is not tested here");
				next;
			}

			S_teststep( "Read the Power On Counter (POC) before ECU Reset", 'AUTO_NBR' );
			$POCvalueOldRef = PD_ReadMemoryByName($tcpar_POCVarName);
			S_w2rep( "Power On Counter Value BEFORE Reset= @$POCvalueOldRef", 'NO_AUTO_NBR' );

			S_teststep( "Send request to enter Session which supports ECU Reset :$session ", 'AUTO_NBR' );
			DIAG_StartSession($session);

			S_wait_ms( 3000, "Entry into programming session triggers a reset hence a delay" ) if ( $session =~ m/programming/i );

			S_teststep( "Trigger '$tcpar_ResetRequest' diagostic request", 'AUTO_NBR', 'trigger_resetrequest_diagostic_' . $session . '_' . $mode );    #measurement 1
			my $diag_Response = GDCOM_request_general( "REQ_" . $tcpar_ResetRequest, "PR_" . $tcpar_ResetRequest );
			S_teststep_expected( "Positive shall be obtained.", 'trigger_resetrequest_diagostic_' . $session . '_' . $mode );
			S_teststep_detected( "Obtained Response is $diag_Response", 'trigger_resetrequest_diagostic_' . $session . '_' . $mode );                   #evaluation 1

			S_wait_ms( 10000, "ECU may take longer time to reset during programming session" );

			S_teststep( "Read the active session by sending '$tcpar_ReadActiveSession'", 'AUTO_NBR', 'read_the_active_' . $session . '_' . $mode );     #measurement 
			my $diag_Response = ReadActiveSession();
			my @activesession = split( / /, $diag_Response );                                                                                           # Split all the response bytes                                                                                                                                          #GDCOM_evaluate_response_bytes('read_the_active_' . $session . '_' . $mode,$diag_Response,'3',$defaultsession);
			S_teststep_expected( "Current session shall be $defaultsession", 'read_the_active_' . $session . '_' . $mode );
			S_teststep_detected( "Session observed is $activesession[$tcpar_PR_ActiveSession_ByteNbr]", 'read_the_active_' . $session . '_' . $mode );    #evaluation 2
			if ( $defaultsession == hex($activesession[$tcpar_PR_ActiveSession_ByteNbr]) ) {
				S_set_verdict('VERDICT_PASS');
			}
			else {
				S_set_verdict('VERDICT_FAIL');
			}

			S_teststep( "Read the Power On Counter (POC) after ECU Reset", 'AUTO_NBR', 'read_the_power_' . $session . '_' . $mode );                      #measurement 3
			$POCvalueNewRef = PD_ReadMemoryByName($tcpar_POCVarName);

			#$POCvalueNew    = GEN_readPowerONCounter();
			S_w2rep("Power On Counter Value AFTER Reset = @$POCvalueNewRef");

			$POCvalueNew = S_aref2dec( $POCvalueNewRef, 'U32' );
			$POCvalueOld = S_aref2dec( $POCvalueOldRef, 'U32' );

			if ( $tcpar_IncrementPOC eq 'Yes' ) {
				S_teststep_expected( "The value of power on counter should be $POCvalueOld + 1", 'read_the_power_' . $session . '_' . $mode );
				S_teststep_detected( "The value of power on counter observed is $POCvalueNew", 'read_the_power_' . $session . '_' . $mode );              #evaluation 3

				if ( $POCvalueNew == $POCvalueOld + 1 )                                                                                                   # Checking if the POC has incremented
				{
					S_set_verdict('VERDICT_PASS');
				}
				else {
					S_set_verdict('VERDICT_FAIL');
				}
			}
			elsif ( $tcpar_IncrementPOC eq 'No' ) {
				S_teststep_expected( "The value of power on counter should be $POCvalueOld", 'read_the_power_' . $session . '_' . $mode );
				S_teststep_detected( "The value of power on counter observed is $POCvalueNew", 'read_the_power_' . $session . '_' . $mode );              #evaluation 3

				if ( $POCvalueNew == $POCvalueOld ) {
					S_set_verdict('VERDICT_PASS');
				}
				else {
					S_set_verdict('VERDICT_FAIL');
				}
			}

		}
	}

	return 1;
}

sub TC_evaluation {

	S_w2rep("Evaluation is done above in stimulation_and_measurement");
	return 1;
}

sub TC_finalization {

	GDCOM_stop_CyclicTesterPresent();
	return 1;
}

sub ReadActiveSession {

	if ( $tcpar_ReadActiveSession =~ m/rb_/i ) {    #read from SW variable
		return DIAG_ReadActiveSession_SW_var($tcpar_ReadActiveSession);
	}
	else {
		return GDCOM_request_general( "REQ_" . $tcpar_ReadActiveSession, "PR_" . $tcpar_ReadActiveSession );
	}
}

1;
