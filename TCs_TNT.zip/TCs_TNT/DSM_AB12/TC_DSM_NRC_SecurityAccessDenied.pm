#### TEST CASE MODULE
package TC_DSM_NRC_SecurityAccessDenied;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.7 $;
our $HEADER  = q$Header: DSM_AB12/TC_DSM_NRC_SecurityAccessDenied.pm 1.7 2019/10/31 18:30:59ICT Phan Khanh Duy (RBVH/EPS24) (PDA1HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_NegativeResponseCodes
#TS version in DOORS: 0.3
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use GENERIC_DCOM;
use LIFT_PD;
##################################

our $PURPOSE = "To verify that NRC 33 is received for services with sub functions which are protected by security access";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_NRC_SecurityAccessDenied

=head1 PURPOSE

To verify that NRC 33 is received for services with sub functions which are protected by security access

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

Choose requests which are protected by security access from SPR/Mapping_DIAG

1. Enter supported session for the request

2. Send the request in physical addressing mode (without getting security access)

3. Send the request in functional addressing mode (without getting security access)

4. Repeat for all sub functions supported by the service which are protected by security access


I<B<Evaluation>>

1.  

2. <Response> is received

3. <Response> is received


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Purpose' => 
	SCALAR 'Service' => 
	SCALAR 'Response' => 


=head2 PARAMETER EXAMPLES

	Purpose = 'To check the negative response NRC $33 at sub function level'
	
	Service = '<Test Heading 2>'
	Response = 'NR_securityAccessDenied'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_Service;
my $tcpar_Response;
my ( %tcpar_CommunicationType, %tcpar_Key, %tcpar_Data, %tcpar_IOControlState, %tcpar_RoutineControlOption );

################ global parameter declaration ###################
#add any global variables here
my %DataValue;

###############################################################

sub TC_set_parameters {

	$tcpar_Purpose  = GEN_Read_mandatory_testcase_parameter('Purpose');
	$tcpar_Service  = GEN_Read_mandatory_testcase_parameter('Service');
	$tcpar_Response = GEN_Read_mandatory_testcase_parameter('Response');

	#handle required bytes in request
	$DataValue{'StatusMask'}                  = GEN_Read_optional_testcase_parameter('StatusMask');
	$DataValue{'DTC'}                         = GEN_Read_optional_testcase_parameter('DTC');
	$DataValue{'DTCSnapshotRecordNumber'}     = GEN_Read_optional_testcase_parameter('DTCSnapshotRecordNumber');
	$DataValue{'DTCExtendedDataRecordNumber'} = GEN_Read_optional_testcase_parameter('DTCExtendedDataRecordNumber');

	%tcpar_CommunicationType    = GEN_Read_optional_testcase_parameter('CommunicationType');
	%tcpar_Key                  = GEN_Read_optional_testcase_parameter('Key');
	%tcpar_Data                 = GEN_Read_optional_testcase_parameter('Data');
	%tcpar_IOControlState       = GEN_Read_optional_testcase_parameter('IOControlState');
	%tcpar_RoutineControlOption = GEN_Read_optional_testcase_parameter('RoutineControlOption');

	return 1;
}

sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'NO_AUTO_NBR' );

	#    GEN_StandardPrepNoFault();
	DIAG_ECUReset_NOVERDICT();
	S_wait_ms( 'TIMER_ECU_READY', 'wait after reset' );
	PD_ReadFaultMemory_NOERROR();

	GDCOM_start_CyclicTesterPresent();
	GDCOM_set_addressing_mode('physical');

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Choose requests which are protected by security access from SPR/Mapping_DIAG", 'NO_AUTO_NBR' );
	my $SID = $tcpar_Service;
	$tcpar_Service = _getServiceLabel($tcpar_Service);
	my $SubFuncInfo = GDCOM_getSupportedSubFunsfromMapping($tcpar_Service);

	my $count = 0;    #to check if any request was executed
	foreach my $subFunc ( sort { hex( $SubFuncInfo->{$a} ) <=> hex( $SubFuncInfo->{$b} ) } keys %$SubFuncInfo ) {
		S_w2rep( "************* Sub Function: $subFunc *************", 'orange' );
		my $requestLabel = $tcpar_Service . "_" . $subFunc;

		unless ( _getProtocolForRequest($requestLabel) eq 'UDS' ) {
			S_w2rep("Sub Function ($requestLabel) is not supported on UDS protocol. Go to next sub function..");
			next;
		}

		my $securityLevelsForRequest = _getSecurityLevelsForRequest($requestLabel);

		if ( @$securityLevelsForRequest[0] =~ m/None/i or @$securityLevelsForRequest[0] eq '---' or @$securityLevelsForRequest[0] eq 'n/a' ) {    #in case security access is required
			S_w2rep("Sub Function ($requestLabel) does not require security access. Test case not applicable for this request. Go to next sub function..");
			next;
		}

		_fillRequestInputParameters( $SID, S_get_contents_of_hash( [ 'Mapping_DIAG', 'DIAG_SERVICES', $tcpar_Service, 'Supported_SubFuns', $subFunc ] ) );

		if ( $SID eq '2E' ) {                                                                                                                     #for 2E service, write the same value as read by 22 service
			GDCOM_set_addressing_mode('disposal') if ( _getProtocolForRequest($requestLabel) =~ m/disposal/i );
			my $DID = S_get_contents_of_hash( [ 'Mapping_DIAG', 'DIAG_SERVICES', $tcpar_Service, 'Supported_SubFuns', $subFunc ] );
			S_teststep_2nd_level( "For 2E service, read data by 22 service and write the same value", 'NO_AUTO_NBR' );
			my $readdata = GDCOM_request_NOVERDICT( "22 $DID", "62 $DID", 'relax' );

			#try to read again in extended session if response is
			if ( $readdata eq '7F' ) {
				S_teststep_2nd_level( "Enter extended session as got negative response in default session", 'NO_AUTO_NBR' );
				GDCOM_request( "10 03", "50 03", 'relax' );

				S_teststep_2nd_level( "Try to read data again by 22 service and write the same value", 'NO_AUTO_NBR' );
				$readdata = GDCOM_request( "22 $DID", "62 $DID", 'relax' );
			}
			$readdata = substr( $readdata, 9 );    #remove 62 DIDHB DIDLB
			$DataValue{'Data'} = $readdata if ( defined $readdata );
		}

		S_teststep( "----- $requestLabel -----", 'NO_AUTO_NBR', $subFunc );    #for steps in TR
		S_teststep_expected( "--- $requestLabel ---", $subFunc );
		S_teststep_detected( "--- $requestLabel ---",, $subFunc );

		my $sessionsForRequest = _getSupportedSessionsForRequest($requestLabel);
		S_w2rep("Sessions supported for request: @$sessionsForRequest");
		S_teststep( "Enter session: @$sessionsForRequest[0]", 'AUTO_NBR' );
		DIAG_StartSession( @$sessionsForRequest[0] );
		S_wait_ms( 4000, 'wait after session entry' ) if ( @$sessionsForRequest[0] =~ m/prog|boot/i );

		S_teststep( "Send the request in physical addressing mode (without getting security access)", 'AUTO_NBR', $subFunc . "send_request_phys" );    #measurement 1
		GDCOM_set_addressing_mode('physical');
		my $response_phys = GDCOM_request_general( "REQ_" . $requestLabel, $tcpar_Response, \%DataValue );

		my $NRCInfo = GDCOM_getNRCfromMapping( $tcpar_Service, $tcpar_Response );
		S_teststep_expected( $NRCInfo->{'Response'}, $subFunc . "send_request_phys" );                                                                 #evaluation 1
		S_teststep_detected( $response_phys, $subFunc . "send_request_phys" );

		S_teststep( "Send the request in functional addressing mode (without getting security access)", 'AUTO_NBR', $subFunc . "send_request_func" );    #measurement 2
		my $addrModesForRequest = _getSupportedAddrModesForRequest($requestLabel);
		if ( grep { $_ =~ m/functional/i } @$addrModesForRequest ) {
			GDCOM_set_addressing_mode('functional');
			my $response_func = GDCOM_request_general( "REQ_" . $requestLabel, $tcpar_Response, \%DataValue );

			S_teststep_expected( $NRCInfo->{'Response'}, $subFunc . "send_request_func" );                                                               #evaluation 2
			S_teststep_detected( $response_func, $subFunc . "send_request_func" );
		}
		else {
			S_teststep_expected( "Request is not supported in functional addressing mode. No action done", $subFunc . "send_request_func" );             #evaluation 2
			S_teststep_detected( "Request is not supported in functional addressing mode. No action done", $subFunc . "send_request_func" );
		}

		$count++;

		S_teststep( "\n", 'NO_AUTO_NBR' );                                                                                                               #newline for steps in TR
	}

	if ( $count == 0 ) {                                                                                                                                 #for TR printout
		S_teststep( "No requests for service $SID are protected by security access\n", 'AUTO_NBR', 'NO_REQ' );
		S_teststep_expected( "No evaluation", 'NO_REQ' );
		S_teststep_detected( "No requests for service $SID are protected by security access\n", 'NO_REQ' );
	}

	return 1;
}

sub TC_evaluation {

	S_w2rep("Evaluation is done above in stimulation_and_measurement");

	return 1;
}

sub TC_finalization {

	GDCOM_stop_CyclicTesterPresent();

	return 1;
}

sub _getServiceLabel {
	my $SID = shift;

	my $services = S_get_contents_of_hash( [ 'Mapping_DIAG', 'PRJ_SUPPORTED_SERVICES' ] );

	foreach my $serv ( keys %$services ) {
		return $serv if ( $services->{$serv} eq $SID );
	}
}

sub _getSupportedAddrModesForRequest {
	my $reqLabel = shift;

	return GDCOM_getRequestInfofromMapping($reqLabel)->{'allowed_in_addressingmodes'};
}

sub _getSecurityLevelsForRequest {
	my $reqLabel = shift;

	return GDCOM_getRequestInfofromMapping($reqLabel)->{'allowed_in_securitylevels'};
}

sub _getProtocolForRequest {
	my $reqLabel = shift;

	return GDCOM_getRequestInfofromMapping($reqLabel)->{'protocol'};
}

sub _getSupportedSessionsForRequest {
	my $reqLabel = shift;

	return GDCOM_getRequestInfofromMapping($reqLabel)->{'allowed_in_sessions'};
}

sub _fillRequestInputParameters {
	my $SID     = shift;
	my $subFunc = shift;

	if ( $SID eq '27' ) {
		$DataValue{'Key'} = $tcpar_Key{$subFunc};
	}
	elsif ( $SID eq '28' ) {
		$DataValue{'CommunicationType'} = $tcpar_CommunicationType{$subFunc};
	}
	elsif ( $SID eq '2E' ) {
		$DataValue{'Data'} = $tcpar_Data{$subFunc};
	}
	elsif ( $SID eq '2F' ) {
		$DataValue{'IOControlState'} = $tcpar_IOControlState{$subFunc};
	}
	elsif ( $SID eq '2F' ) {
		$DataValue{'IOControlState'} = $tcpar_IOControlState{$subFunc};
	}
	elsif ( $SID eq '31' ) {
		$DataValue{'RoutineControlOption'} = $tcpar_RoutineControlOption{$subFunc};
	}

}

1;
