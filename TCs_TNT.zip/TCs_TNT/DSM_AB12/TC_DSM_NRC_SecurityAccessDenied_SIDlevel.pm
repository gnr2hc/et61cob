#### TEST CASE MODULE
package TC_DSM_NRC_SecurityAccessDenied_SIDlevel;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.3 $;
our $HEADER  = q$Header: DSM_AB12/TC_DSM_NRC_SecurityAccessDenied_SIDlevel.pm 1.3 2017/08/16 13:45:52ICT ver6cob develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_NegativeResponseCodes
#TS version in DOORS: 0.3
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use GENERIC_DCOM;
##################################

our $PURPOSE = "To verify that negative response NRC $33 is received for services which are generally protected by security access (at SID level)";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_NRC_SecurityAccessDenied_SIDlevel

=head1 PURPOSE

To verify that negative response NRC $33 is received for services which are generally protected by security access (at SID level)

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Enter <Session>

2. Send <Request> in physical addressing mode (without getting security access)

3. Send <Request> in functional addressing mode (without getting security access)


I<B<Evaluation>>

1.  

2. <Response> is received

3. <Response> is received


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Request' => 
	SCALAR 'Purpose' => 
	SCALAR 'Service' => 
	SCALAR 'Session' => 
	SCALAR 'Response' => 


=head2 PARAMETER EXAMPLES

	Purpose = 'To check for NRC $33 when security access is not taken at SID level'
	Service = '<Test Heading 2>'
	Session = 'ExtendedSession' 
	Response = 'NR_securityAccessDenied'
	Request = '2E' #1 byte SID

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_Session;
my $tcpar_Response;
my $tcpar_Request;

################ global parameter declaration ###################
#add any global variables here

###############################################################

sub TC_set_parameters {

    $tcpar_Purpose  = GEN_Read_mandatory_testcase_parameter('Purpose');
    $tcpar_Session  = GEN_Read_mandatory_testcase_parameter('Session');
    $tcpar_Response = GEN_Read_mandatory_testcase_parameter('Response');
    $tcpar_Request  = GEN_Read_mandatory_testcase_parameter('Request');

    return 1;
}

sub TC_initialization {

    S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
    GEN_StandardPrepNoFault();
    GDCOM_start_CyclicTesterPresent();

    return 1;
}

sub TC_stimulation_and_measurement {

    S_teststep( "Enter $tcpar_Session", 'AUTO_NBR' );
    DIAG_StartSession($tcpar_Session);

    S_teststep( "Send '$tcpar_Request' in physical addressing mode (without getting security access)", 'AUTO_NBR', 'send_request_phys' );    #measurement 1
    GDCOM_set_addressing_mode('physical');
    my $response_phys = GDCOM_request( $tcpar_Request, "7F $tcpar_Request 33", 'strict' );

    S_teststep_expected( "7F $tcpar_Request 33", 'send_request_phys' );                                                                      #evaluation 1
    S_teststep_detected( $response_phys, 'send_request_phys' );

    S_teststep( "Send '$tcpar_Request' in functional addressing mode (without getting security access)", 'AUTO_NBR', 'send_request_func' );    #measurement 2
    GDCOM_set_addressing_mode('functional');

    my $response_func = GDCOM_request( $tcpar_Request, "7F $tcpar_Request 33", 'strict' );

    S_teststep_expected( "7F $tcpar_Request 33", 'send_request_func' );                                                                        #evaluation 1
    S_teststep_detected( $response_func, 'send_request_func' );

    return 1;
}

sub TC_evaluation {

    S_w2rep("Evaluation is done above in stimulation_and_measurement");

    return 1;
}

sub TC_finalization {

    GDCOM_stop_CyclicTesterPresent();

    return 1;
}

1;
