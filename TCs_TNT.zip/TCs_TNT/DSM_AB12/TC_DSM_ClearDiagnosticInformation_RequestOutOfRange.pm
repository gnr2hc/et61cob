#### TEST CASE MODULE
package TC_DSM_ClearDiagnosticInformation_RequestOutOfRange;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.2 $;
our $HEADER  = q$Header: DSM_AB12/TC_DSM_ClearDiagnosticInformation_RequestOutOfRange.pm 1.2 2017/11/08 11:41:11ICT ver6cob develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_ClearDiagnosticInformation
#TS version in DOORS: 4.9
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use GENERIC_DCOM;
##################################

our $PURPOSE = "NRC31 check for service 14";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_ClearDiagnosticInformation_RequestOutOfRange 

=head1 PURPOSE

NRC31 check for service 14

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Send request <ClearDiagnosticInformation> with <GroupOfDTC> in physical addressing mode

2. Send request <ClearDiagnosticInformation> with <GroupOfDTC> in functional addressing mode


I<B<Evaluation>>

1. NRC31 - RequestOutOfRange is received

2. No response is received (NRC31 is functionally suppressed)


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	LIST 'GroupOfDTC' => 
	SCALAR 'purpose' => 
	SCALAR 'ClearDiagnosticInformation' => 


=head2 PARAMETER EXAMPLES

	purpose = 'to check that NRC 31 is received for 14 service for invalid/not supported value for groupOfDTC' 
	# input parameters
	ClearDiagnosticInformation = 'ClearDTCInformation_ClearIndividualDTC'
	#output parameters
	GroupOfDTC = @('00 00 00', 'FF FF FE', 'AB CD EF')

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_ClearDiagnosticInformation;
my @tcpar_GroupOfDTC;

################ global parameter declaration ###################
#add any global variables here

###############################################################

sub TC_set_parameters {

    $tcpar_purpose                    = GEN_Read_mandatory_testcase_parameter('purpose');
    $tcpar_ClearDiagnosticInformation = GEN_Read_mandatory_testcase_parameter('ClearDiagnosticInformation');
    @tcpar_GroupOfDTC                 = GEN_Read_mandatory_testcase_parameter('GroupOfDTC');

    return 1;
}

sub TC_initialization {

    S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
    GEN_StandardPrepNoFault();
    GDCOM_start_CyclicTesterPresent();

    return 1;
}

sub TC_stimulation_and_measurement {

    S_teststep( "Send request '$tcpar_ClearDiagnosticInformation' with 'GroupOfDTC' in physical addressing mode", 'AUTO_NBR', 'send_request_cleardiagnosticinformation_A' );    #measurement 1
    GDCOM_set_addressing_mode('physical');
    foreach (@tcpar_GroupOfDTC){
        S_teststep_2nd_level( "Send request '$tcpar_ClearDiagnosticInformation' with GroupOfDTC = $_ in physical addressing mode", 'AUTO_NBR', "send_request_cleardiagnosticinformation_phys_$_" );    #measurement 1
        my $response_physical = GDCOM_request_general( "REQ_" . $tcpar_ClearDiagnosticInformation, "NR_requestOutOfRange", { 'DTC' => $_ } );

        S_teststep_expected( "NRC31 is received", "send_request_cleardiagnosticinformation_phys_$_" );                                                                                           #evaluation 1
        S_teststep_detected( "response = $response_physical", "send_request_cleardiagnosticinformation_phys_$_" );
    }


    S_teststep( "Send request '$tcpar_ClearDiagnosticInformation' with 'GroupOfDTC' in functional addressing mode", 'AUTO_NBR', 'send_request_cleardiagnosticinformation_B' );    #measurement 2
    GDCOM_set_addressing_mode('functional');
    foreach (@tcpar_GroupOfDTC){
        S_teststep_2nd_level( "Send request '$tcpar_ClearDiagnosticInformation' with GroupOfDTC = $_ in functional addressing mode", 'AUTO_NBR', "send_request_cleardiagnosticinformation_func_$_" );    #measurement 1
        my $requestBytes = GDCOM_getRequestLabelValue( "REQ_" . $tcpar_ClearDiagnosticInformation, { 'DTC' => $_ } );
        my $response_functional = GDCOM_request( $requestBytes, "", 'quiet' );

        S_teststep_expected( "No response", "send_request_cleardiagnosticinformation_func_$_" );                                                                                           #evaluation 1
        S_teststep_detected( "-" . $response_functional, "send_request_cleardiagnosticinformation_func_$_" );
    }

    return 1;
}

sub TC_evaluation {

    S_w2rep("Evaluation is done above in stimulation_and_measurement");

    return 1;
}

sub TC_finalization {

    GDCOM_stop_CyclicTesterPresent();
    GDCOM_set_addressing_mode('physical');

    return 1;
}

1;
