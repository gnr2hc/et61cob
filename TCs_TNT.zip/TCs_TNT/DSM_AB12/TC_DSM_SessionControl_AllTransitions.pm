#### TEST CASE MODULE
package TC_DSM_SessionControl_AllTransitions;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1.1.6 $;
our $HEADER = q$Header: DSM_AB12/TC_DSM_SessionControl_AllTransitions.pm 1.1.1.6 2018/04/24 17:59:36ICT ver6cob develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_SessionControl
#TS version in DOORS: 0.2
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
use LIFT_labcar;
use GENERIC_DCOM;
use LIFT_evaluation;
use LIFT_DCOM;
use LIFT_can_access;
use LIFT_PD;
#necessary
#include further modules here

##################################

our $PURPOSE = "This test case is to test all the different combinations of transition paths from one session to another session";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_SessionControl_AllTransitions

=head1 PURPOSE

 This test case is to test all the different combinations of transition paths from one session to another session.

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Set Addressing Mode and Protocol

2. Enter a session which supports transition to <Session_1> as per the SPR

3. Send request to enter <Session_1>

4. Read the active session by sending <ReadActiveSession>

5. Send request to enter <Session_2>

6. Read the active session by sending <ReadActiveSession>

# Repeat the above steps for all supported Addressing modes as defined in the SPR


I<B<Evaluation>>

1.

2.

3. Positive response is obtained

4. Observe positive response and the active session is <ActiveSession_1>.

5. For physical addressing mode: <ResponseNature_phy>

For functional addressing mode: <ResponseNature_func> is obtained

6. Observe positive response and the active session is <ActiveSession_2>.

#In case NRC is received in the step 5, then Active session is <ActiveSession_1>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'ActiveSession_1' => 
	SCALAR 'ActiveSession_2' => 
	SCALAR 'Purpose' => 
	SCALAR 'Session_1' => 
	SCALAR 'ReadActiveSession' => 
	SCALAR 'Session_2' => 
	SCALAR 'ResponseNature_phy' => 
	SCALAR 'ResponseNature_func' => 
	SCALAR 'PR_ActiveSession_ByteNbr' => 


=head2 PARAMETER EXAMPLES

	Purpose  = 'To check all session trasnition paths'
	
	
	Session_1 =  '<Test Heading Head>'
	ReadActiveSession =  'ReadDataByIdentifier_ActiveDiagnosticSession'
	Session_2 =  '<Test Heading Tail>'
	
	ResponseNature_phy  = 'PR_DiagnosticSessionControl_'
	ResponseNature_func = 'PR_DiagnosticSessionControl_'
	
	PR_ActiveSession_ByteNbr = '03'
	ActiveSession_1 = '01'
	ActiveSession_2 = '01'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_Session_1;
my $tcpar_ReadActiveSession;
my $tcpar_Session_2;
my $tcpar_ResponseNature_phy;
my $tcpar_ResponseNature_func;
my $tcpar_PR_ActiveSession_ByteNbr;
my $tcpar_ActiveSession_1;
my $tcpar_ActiveSession_2;

################ global parameter declaration ###################
#add any global variables here
my $mode;

###############################################################

sub TC_set_parameters {

	$tcpar_Purpose =  GEN_Read_mandatory_testcase_parameter( 'Purpose' );
	$tcpar_Session_1 =  GEN_Read_mandatory_testcase_parameter( 'Session_1' );
	$tcpar_ReadActiveSession =  GEN_Read_mandatory_testcase_parameter( 'ReadActiveSession' );
	$tcpar_Session_2 =  GEN_Read_mandatory_testcase_parameter( 'Session_2' );
	$tcpar_ResponseNature_phy =  GEN_Read_mandatory_testcase_parameter( 'ResponseNature_phy' );
	$tcpar_ResponseNature_func =  GEN_Read_mandatory_testcase_parameter( 'ResponseNature_func' );
	$tcpar_PR_ActiveSession_ByteNbr =  GEN_Read_mandatory_testcase_parameter( 'PR_ActiveSession_ByteNbr' );
	$tcpar_ActiveSession_1 =  GEN_Read_mandatory_testcase_parameter( 'ActiveSession_1' );
	$tcpar_ActiveSession_2 =  GEN_Read_mandatory_testcase_parameter( 'ActiveSession_2' );

	return 1;
}

sub TC_initialization {

	S_teststep("StandardPrepNoFault", 'AUTO_NBR');
	#    GEN_StandardPrepNoFault();
	DIAG_ECUReset_NOVERDICT ();
	S_wait_ms ('TIMER_ECU_READY', 'wait after reset');
	PD_ReadFaultMemory_NOERROR();
	
	GDCOM_start_CyclicTesterPresent();
	S_wait_ms (100);
	# GDCOM_set_addressing_mode('physical');

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Set Addressing Mode and Protocol", 'AUTO_NBR');
	my $Addressing_Mode = GDCOM_getRequestInfofromMapping ("DiagnosticSessionControl_".$tcpar_Session_1)->{'allowed_in_addressingmodes'};
	foreach $mode (@$Addressing_Mode) {	
		S_teststep("Set addressing mode to : $mode", 'AUTO_NBR');
		GDCOM_set_addressing_mode($mode);
		
		S_teststep("Enter a session which supports transition to '$tcpar_Session_1' as per the SPR", 'AUTO_NBR');
		my $allowedSessions =  GDCOM_getRequestInfofromMapping ("DiagnosticSessionControl_".$tcpar_Session_1)->{'allowed_in_sessions'};
		unless(grep{$_ eq 'DefaultSession'} @$allowedSessions) 
		{	
			DIAG_StartSession(@$allowedSessions[0]);
			S_w2rep("Enteretd in the @$allowedSessions[0] to set the precondition for $tcpar_Session_1", 'yellow');
		}	
		S_teststep("Send request to enter '$tcpar_Session_1'", 'AUTO_NBR', "send_request_to_A_$mode");							#measurement 1
		my $Request_Session1_phy = GDCOM_request_general("REQ_DiagnosticSessionControl_".$tcpar_Session_1,"PR_DiagnosticSessionControl_".$tcpar_Session_1);
		S_teststep_expected('Positive Response shall be obtained',"send_request_to_A_$mode");			
		S_teststep_detected("Obtained Response is '$Request_Session1_phy'","send_request_to_A_$mode");
		S_wait_ms('5000',"To enter $tcpar_Session_1");
		
		S_teststep("Read the active session by sending '$tcpar_ReadActiveSession'", 'AUTO_NBR', "read_the_active_A_$mode");			#measurement 2
		my $session_Response1 = ReadActiveSession ();
		my @activesession_res_1 = split( / / , $session_Response1);																	# Split all the response bytes of Step1 to array
		EVAL_evaluate_value ( "read_the_active_A_$mode" , $activesession_res_1[$tcpar_PR_ActiveSession_ByteNbr], '==', $tcpar_ActiveSession_1 );
		S_teststep_expected("Current session shall be '$tcpar_ActiveSession_1'.","read_the_active_A_$mode");		
		S_teststep_detected("Session obtained $activesession_res_1[$tcpar_PR_ActiveSession_ByteNbr]","read_the_active_A_$mode");
			
		S_teststep("Send request to enter '$tcpar_Session_2'", 'AUTO_NBR', "send_request_to_B_$mode");								#measurement 3
		if($mode eq 'physical'){
			if($tcpar_ResponseNature_phy =~ /^PR_/ ){
				my $Request_Session2_phy = GDCOM_request_general("REQ_DiagnosticSessionControl_".$tcpar_Session_2,"$tcpar_ResponseNature_phy".$tcpar_Session_2);
				S_teststep_expected('Positive Response shall be obtained',"send_request_to_B_$mode");			
				S_teststep_detected("Obtained Response is '$Request_Session2_phy'","send_request_to_B_$mode");
			}
			else{
				my $Request_Session2_phy = GDCOM_request_general("REQ_DiagnosticSessionControl_".$tcpar_Session_2, $tcpar_ResponseNature_phy);
				S_teststep_expected('NRC shall be obtained',"send_request_to_B_$mode");			
				S_teststep_detected("Obtained Response is '$Request_Session2_phy'","send_request_to_B_$mode");
			}
		}
		else{
			if($tcpar_ResponseNature_func =~ /^PR_/ ){
				my $Request_Session2_func = GDCOM_request_general("REQ_DiagnosticSessionControl_".$tcpar_Session_2,"$tcpar_ResponseNature_func".$tcpar_Session_2);
				S_teststep_expected('Positive Response shall be obtained',"send_request_to_B_$mode");			
				S_teststep_detected("Obtained Response is '$Request_Session2_func'","send_request_to_B_$mode");
			}
			else{
				my $request =	GDCOM_getRequestInfofromMapping ("DiagnosticSessionControl_$tcpar_Session_2")->{"REQ_DiagnosticSessionControl_".$tcpar_Session_2};
				my $Request_Session2_func = GDCOM_request("$request",'', 'quiet');	
				S_teststep_expected('NRC shall be obtained',"send_request_to_B_$mode");			
				S_teststep_detected("Obtained Response is '$Request_Session2_func'","send_request_to_B_$mode");
			}
		}
		S_wait_ms('5000',"To enter $tcpar_Session_2");
		
		S_teststep("Read the active session by sending '$tcpar_ReadActiveSession'", 'AUTO_NBR', "read_the_active_B_$mode");			#measurement 4
		if($tcpar_ResponseNature_phy =~ /^PR_/ ){
				my $session_Response2 = ReadActiveSession ();
				my @activesession_res_1 = split( / / , $session_Response2);														# Split all the response bytes of Step1 to array
				EVAL_evaluate_value ( "read_the_active_B_$mode" , $activesession_res_1[$tcpar_PR_ActiveSession_ByteNbr], '==', $tcpar_ActiveSession_2 );
				S_teststep_expected("Current session shall be '$tcpar_ActiveSession_2'.","read_the_active_B_$mode");			
				S_teststep_detected("Session obtained $activesession_res_1[$tcpar_PR_ActiveSession_ByteNbr]","read_the_active_B_$mode");
			
			}
			else{
				
				my $session_Response2 = ReadActiveSession ();
				my @activesession_res_1 = split( / / , $session_Response2);														# Split all the response bytes of Step1 to array
				EVAL_evaluate_value ( "read_the_active_B_$mode" , $activesession_res_1[$tcpar_PR_ActiveSession_ByteNbr], '==', $tcpar_ActiveSession_1 );
				S_teststep_expected("Current session shall be '$tcpar_ActiveSession_2'.","read_the_active_B_$mode");			
				S_teststep_detected("Session obtained $activesession_res_1[$tcpar_PR_ActiveSession_ByteNbr]","read_the_active_B_$mode");
			
			}
		GDCOM_stop_CyclicTesterPresent();
		S_wait_ms('6000','To Enter Default Session'); 
		GDCOM_start_CyclicTesterPresent();
		S_wait_ms (1000);
	}	

	return 1;
}

sub TC_evaluation {
	S_w2rep("Evaluation is done above in stimulation_and_measurement");
	return 1;
}

sub TC_finalization {
	
	DIAG_ECUReset();
	GDCOM_stop_CyclicTesterPresent();
	S_wait_ms (1000);
	return 1;
}

sub ReadActiveSession {
	
	if($tcpar_ReadActiveSession =~ m/rb_/i){ #read from SW variable
		return DIAG_ReadActiveSession_SW_var ( $tcpar_ReadActiveSession );
	}
	else{
		return GDCOM_request_general("REQ_".$tcpar_ReadActiveSession,"PR_".$tcpar_ReadActiveSession);
	}
}


1;
