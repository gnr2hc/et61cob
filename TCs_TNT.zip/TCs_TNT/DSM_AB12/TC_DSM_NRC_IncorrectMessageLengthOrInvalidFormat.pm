#### TEST CASE MODULE
package TC_DSM_NRC_IncorrectMessageLengthOrInvalidFormat;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.5 $;
our $HEADER = q$Header: DSM_AB12/TC_DSM_NRC_IncorrectMessageLengthOrInvalidFormat.pm 1.5 2018/04/24 17:59:36ICT ver6cob develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_NegativeResponseCodes
#TS version in DOORS: 0.1
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use GENERIC_DCOM;
use LIFT_PD;
##################################

our $PURPOSE = "To verify that NRC 13 is received if length of the request is incorrect";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_NRC_IncorrectMessageLengthOrInvalidFormat

=head1 PURPOSE

To verify that NRC 13 is received if length of the request is incorrect

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Enter session supported by the service. Get security access if required

2. Send the service with length = 1

3. Send the service with correct length - 1

4. Send the service with correct length + 1

5. Repeat in all addressing modes supported by the request

6. Repeat for all sub services within a service


I<B<Evaluation>>

2 to 6. NRC $13 is received


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Purpose' => 


=head2 PARAMETER EXAMPLES

	Purpose = 'To verify that NRC 13 is received if length of the request is incorrect'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_Service;
my $tcpar_FuncReqSupported;
my (%tcpar_CommunicationType, %tcpar_Key, %tcpar_Data, %tcpar_IOControlState, %tcpar_RoutineControlOption);

################ global parameter declaration ###################
#add any global variables here
my %DataValue;

###############################################################

sub TC_set_parameters {

	$tcpar_Purpose =  GEN_Read_mandatory_testcase_parameter( 'Purpose' );
	$tcpar_Service = GEN_Read_mandatory_testcase_parameter('Service');
	$tcpar_FuncReqSupported = S_read_optional_testcase_parameter('FuncReqSupported', undef, 'no');
	
	#handle required bytes in request
    $DataValue{'StatusMask'}               = GEN_Read_optional_testcase_parameter('StatusMask');
    $DataValue{'DTC'}                         = GEN_Read_optional_testcase_parameter('DTC');
    $DataValue{'DTCSnapshotRecordNumber'}     = GEN_Read_optional_testcase_parameter('DTCSnapshotRecordNumber');
    $DataValue{'DTCExtendedDataRecordNumber'} = GEN_Read_optional_testcase_parameter('DTCExtendedDataRecordNumber');

    %tcpar_CommunicationType           = GEN_Read_optional_testcase_parameter('CommunicationType');
    %tcpar_Key                         = GEN_Read_optional_testcase_parameter('Key');
    %tcpar_Data                        = GEN_Read_optional_testcase_parameter('Data');
    %tcpar_IOControlState              = GEN_Read_optional_testcase_parameter('IOControlState');
    %tcpar_RoutineControlOption        = GEN_Read_optional_testcase_parameter('RoutineControlOption');

	return 1;
}

sub TC_initialization {

	S_teststep("\nStandardPrepNoFault\n", 'NO_AUTO_NBR');
#	GEN_StandardPrepNoFault();
	DIAG_ECUReset_NOVERDICT ();
	S_wait_ms ('TIMER_ECU_READY', 'wait after reset');
	PD_ReadFaultMemory_NOERROR();
	
	GDCOM_start_CyclicTesterPresent();
	GDCOM_set_addressing_mode('physical');
	S_wait_ms (100);

	return 1;
}

sub TC_stimulation_and_measurement {
    
	#Repeat for all sub services within a service
    my $SID = $tcpar_Service;
    $tcpar_Service = _getServiceLabel($tcpar_Service);
    my $SubFuncInfo = GDCOM_getSupportedSubFunsfromMapping($tcpar_Service);
    
    my $NRCInfo = GDCOM_getNRCfromMapping( $tcpar_Service, 'NR_incorrectMessageLengthOrInvalidFormat' );
 
	my $count = 0; 
	my $modifiedrequest_old = '';
	
    foreach my $subFunc (sort { hex($SubFuncInfo->{$a}) <=> hex($SubFuncInfo->{$b}) } keys %$SubFuncInfo) {
        S_w2rep ("************* Sub Function: $subFunc *************",'orange');
        my $requestLabel = $tcpar_Service . "_" . $subFunc;

        unless (_getProtocolForRequest ($requestLabel) eq 'UDS'){
            S_w2rep("Sub Function ($requestLabel) is not supported on UDS protocol. Go to next sub function..");
            next;
        }
        
        if($count != 0){ #for proper display in TR
	        S_teststep( "----- $requestLabel -----", 'NO_AUTO_NBR', $subFunc ); #for steps in TR
	        S_teststep_expected( "--- $subFunc ---", $subFunc ); 
	        S_teststep_detected( "--- $subFunc ---", , $subFunc ); 
        }
        
        _fillRequestInputParameters ($SID, S_get_contents_of_hash( [ 'Mapping_DIAG', 'DIAG_SERVICES', $tcpar_Service,'Supported_SubFuns', $subFunc]));
        
        if ($SID eq '2E'){ #for 2E service, write the same value as read by 22 service
    		my $DID = S_get_contents_of_hash( [ 'Mapping_DIAG', 'DIAG_SERVICES', $tcpar_Service,'Supported_SubFuns', $subFunc]);
    		my $readdata = GDCOM_request_NOVERDICT ("22 $DID", "62 $DID", 'relax');
    		$readdata = substr($readdata, 9); #remove 62 DIDHB DIDLB
    		$DataValue{'Data'} = $readdata if (defined $readdata);
    	}

    	my $sessionsForRequest = _getSupportedSessionsForRequest($requestLabel);
        S_w2rep("Sessions supported for request: @$sessionsForRequest");
        S_teststep("Enter session: @$sessionsForRequest[0]", 'AUTO_NBR');
        DIAG_StartSession(@$sessionsForRequest[0]);
        S_wait_ms (5000, 'wait after session entry') if(@$sessionsForRequest[0] =~ m/prog|boot/i);

        
        my $securityLevelsForRequest = _getSecurityLevelsForRequest($requestLabel);

        if ( @$securityLevelsForRequest[0] !~ m/None/i and @$securityLevelsForRequest[0] ne '---' and @$securityLevelsForRequest[0] ne 'n/a' ){ #in case security access is required
            S_teststep("Get required security access: @$securityLevelsForRequest", 'AUTO_NBR');
            DIAG_getSecurityAccess (@$securityLevelsForRequest[0]) if (defined &DIAG_getSecurityAccess);
        }

        GDCOM_GetAccessToRequest ($requestLabel); #handle any dependent services through request in Mapping_DIAG (if required)
        
        
        if($count == 0){ #do this only once since sub func is not included in the request
        	S_teststep("Send request = $SID (length = 1) in physical addressing mode", 'AUTO_NBR',  "len1_phys");      
		    GDCOM_set_addressing_mode('physical');   
		    my $response_1_phys = GDCOM_request( $SID, $NRCInfo->{'Response'} , 'strict');
		    S_teststep_expected( $NRCInfo->{'Response'}, "len1_phys" );                                 
		    S_teststep_detected( $response_1_phys,  "len1_phys" ) if($response_1_phys eq $NRCInfo->{'Response'});
		    S_teststep_detected( "MISMATCH".$response_1_phys,  "len1_phys" ) if($response_1_phys ne $NRCInfo->{'Response'});
		    
		    if($tcpar_FuncReqSupported =~ m/yes/i){
				S_teststep("Send request = $SID (length = 1) in functional addressing mode\n", 'AUTO_NBR',  "len1_func");      
				GDCOM_set_addressing_mode('functional');   
				my $response_1_func = GDCOM_request( $SID, $NRCInfo->{'Response'} , 'strict');
				S_teststep_expected( $NRCInfo->{'Response'}."\n", "len1_func" );                                 
				S_teststep_detected( $response_1_func."\n",  "len1_func" ) if($response_1_func eq $NRCInfo->{'Response'});
				S_teststep_detected( "MISMATCH:".$response_1_func."\n",  "len1_func" ) if($response_1_func ne $NRCInfo->{'Response'});
			}
		    
		    #for proper display in TR
		    S_teststep( "----- $requestLabel -----", 'NO_AUTO_NBR', $subFunc ); #for steps in TR
	        S_teststep_expected( "--- $subFunc ---", $subFunc ) ; 
	        S_teststep_detected( "--- $subFunc ---", , $subFunc ); 
        }
        

		#Repeat in all addressing modes supported by the request
        my $addrModesForRequest = _getSupportedAddrModesForRequest($requestLabel);
        my $modified_request_less;
        
        foreach (@$addrModesForRequest){
			next if ($tcpar_FuncReqSupported =~ m/no/i and $_ =~ m/func/i);
			
            S_teststep("Set addressing mode: $_", 'AUTO_NBR');
            GDCOM_set_addressing_mode($_);
            
#            S_teststep("Send request = $SID (length = 1)", 'AUTO_NBR',  $subFunc . "len1_func_$_");         
#            my $response_a = GDCOM_request( $SID, $NRCInfo->{'Response'} , 'strict');
#            S_teststep_expected( $NRCInfo->{'Response'}, $subFunc . "len1_func_$_" );                                 
#            S_teststep_detected( $response_a,  $subFunc . "len1_func_$_" );

			DIAG_request_DependentServices($requestLabel); #send dependent services for the current request

            my $modified_request = GDCOM_requestlength_manipulation("REQ_".$requestLabel,\%DataValue,+1);
            S_teststep("Send request = $modified_request (length + 1)", 'AUTO_NBR',  $subFunc . "lenplus1_func_$_");
            my $response_b = GDCOM_request($modified_request, $NRCInfo->{'Response'} , 'strict');
            
            S_teststep_expected( $NRCInfo->{'Response'}, $subFunc . "lenplus1_func_$_" );                                 
            S_teststep_detected( $response_b,  $subFunc . "lenplus1_func_$_" ) if($response_b eq $NRCInfo->{'Response'});
            S_teststep_detected( "MISMATCH:".$response_b,  $subFunc . "lenplus1_func_$_" ) if($response_b ne $NRCInfo->{'Response'});
            
            
			$modified_request_less = GDCOM_requestlength_manipulation("REQ_".$requestLabel,\%DataValue,-1);
            if ($modified_request_less ne $modifiedrequest_old and $modified_request_less ne $SID){ #only if the request is diff from the previous request
            
            	DIAG_request_DependentServices($requestLabel); #send dependent services for the current request

	            S_teststep("Send request = $modified_request_less (length - 1)", 'AUTO_NBR', $subFunc . "lenminus1_func_$_");
	            my $response_c = GDCOM_request($modified_request_less, $NRCInfo->{'Response'} , 'strict');
	            
	            S_teststep_expected( $NRCInfo->{'Response'}, $subFunc . "lenminus1_func_$_" );                                 
	            S_teststep_detected( $response_c,  $subFunc . "lenminus1_func_$_" ) if($response_c eq $NRCInfo->{'Response'});
	            S_teststep_detected( "MISMATCH:".$response_c,  $subFunc . "lenminus1_func_$_" ) if($response_c ne $NRCInfo->{'Response'});
            }
        }
        
        $modifiedrequest_old = $modified_request_less;
        
        if(@$sessionsForRequest[0] =~ m/prog|boot/i){
        	DIAG_ECUReset ();
			S_wait_ms ('TIMER_ECU_READY', 'wait after reset');
        }
        
        S_teststep( "\n", 'NO_AUTO_NBR' ); #newline for steps in TR
        $count++;
        
    }

	

	return 1;
}

sub TC_evaluation {

	S_w2rep("Evaluation is done above in stimulation_and_measurement");

	return 1;
}

sub TC_finalization {
    
    GDCOM_stop_CyclicTesterPresent();

	return 1;
}

sub _getServiceLabel {
    my $SID = shift;

    my $services = S_get_contents_of_hash( [ 'Mapping_DIAG', 'PRJ_SUPPORTED_SERVICES' ] );

    foreach my $serv ( keys %$services ) {
        return $serv if ( $services->{$serv} eq $SID );
    }
}

sub _getSecurityLevelsForRequest {
    my $reqLabel = shift;

    return GDCOM_getRequestInfofromMapping ($reqLabel)->{'allowed_in_securitylevels'};
}

sub _getProtocolForRequest {
    my $reqLabel = shift;

    return GDCOM_getRequestInfofromMapping ($reqLabel)->{'protocol'};
}

sub _getSupportedAddrModesForRequest {
    my $reqLabel = shift;

    return GDCOM_getRequestInfofromMapping ($reqLabel)->{'allowed_in_addressingmodes'};
}

sub _getSupportedSessionsForRequest {
    my $reqLabel = shift;

    return GDCOM_getRequestInfofromMapping ($reqLabel)->{'allowed_in_sessions'};
}

sub _fillRequestInputParameters {
    my $SID = shift;
    my $subFunc = shift;
    

    if($SID eq '27'){
        $DataValue{'Key'} = $tcpar_Key{$subFunc};
    }
    elsif($SID eq '28'){
        $DataValue{'CommunicationType'} = $tcpar_CommunicationType{$subFunc};
    }
    elsif($SID eq '2E'){
        $DataValue{'Data'} = $tcpar_Data{$subFunc};
    }
    elsif($SID eq '2F'){
        $DataValue{'IOControlState'} = $tcpar_IOControlState{$subFunc};
    }
    elsif($SID eq '2F'){
        $DataValue{'IOControlState'} = $tcpar_IOControlState{$subFunc};
    }
    elsif($SID eq '31'){
        $DataValue{'RoutineControlOption'} = $tcpar_RoutineControlOption{$subFunc};
    }

}


1;
