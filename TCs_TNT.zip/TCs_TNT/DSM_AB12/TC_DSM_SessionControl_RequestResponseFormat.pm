#### TEST CASE MODULE
package TC_DSM_SessionControl_RequestResponseFormat ;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.3 $;
our $HEADER = q$Header: DSM_AB12/TC_DSM_SessionControl_RequestResponseFormat.pm 1.3 2018/04/24 17:59:37ICT ver6cob develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_SessionControl
#TS version in DOORS: 0.2
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use LIFT_labcar;
use GENERIC_DCOM;
use LIFT_evaluation;
use LIFT_PD;
##################################

our $PURPOSE = "To check the request response format of Diagnostic Session Control";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_SessionControl_RequestResponseFormat 

=head1 PURPOSE

To check the request response format of Diagnostic Session Control

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Set Addressing Mode and Protocol

2. Send <Request> to enter desired Session


# Repeat the above steps for all supported Addressing modes as defined in the SPR


I<B<Evaluation>>

1. 

2. Positive response is observed in the following format 

<Diagnostic_SesionControl_PRSId>, <DiagnosticSessionType >, <P2CAN_Server_Max>, <P2Star_CAN_Server_Max>  in data record field.


I<B<Finalisation>>

Reset Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'DiagnosticSessionType' => 
	SCALAR 'Purpose' => 
	SCALAR 'DiagnosticSessionControl_PRSId' => 
	SCALAR 'P2_CAN_Server_Max' => 
	SCALAR 'P2Star_CAN_Server_Max' => 
	SCALAR 'Request' => 

=head2 PARAMETER EXAMPLES

	Purpose  = 'To verify request respone format for 0x10 service'
	
	DiagnosticSessionControl_PRSId = '50'
	P2_CAN_Server_Max = '00 32'
	P2Star_CAN_Server_Max = '01 F4'
	
	Request = '<Test Heading>'
	DiagnosticSessionType = '03'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_DiagnosticSessionControl_PRSId;
my $tcpar_P2_CAN_Server_Max;
my $tcpar_P2Star_CAN_Server_Max;
my $tcpar_Request;
my $tcpar_DiagnosticSessionType;

################ global parameter declaration ###################
#add any global variables here
my $AddressingMode;
my $mode;

###############################################################

sub TC_set_parameters {

	$tcpar_Purpose =  GEN_Read_mandatory_testcase_parameter( 'Purpose' );
	$tcpar_DiagnosticSessionControl_PRSId =  GEN_Read_mandatory_testcase_parameter( 'DiagnosticSessionControl_PRSId' );
	$tcpar_P2_CAN_Server_Max =  GEN_Read_mandatory_testcase_parameter( 'P2_CAN_Server_Max' );
	$tcpar_P2Star_CAN_Server_Max =  GEN_Read_mandatory_testcase_parameter( 'P2Star_CAN_Server_Max' );
	$tcpar_Request =  GEN_Read_mandatory_testcase_parameter( 'Request' );
	$tcpar_DiagnosticSessionType =  GEN_Read_mandatory_testcase_parameter( 'DiagnosticSessionType' );

	return 1;
}

sub TC_initialization {

	S_teststep("StandardPrepNoFault", 'AUTO_NBR');
	#    GEN_StandardPrepNoFault();
	DIAG_ECUReset_NOVERDICT ();
	S_wait_ms ('TIMER_ECU_READY', 'wait after reset');
	PD_ReadFaultMemory_NOERROR();
	
	# GDCOM_start_CyclicTesterPresent();
	# GDCOM_set_addressing_mode('physical');

	return 1;
}

sub TC_stimulation_and_measurement {

    $AddressingMode = GDCOM_getRequestInfofromMapping('DiagnosticSessionControl_'.$tcpar_Request)->{'allowed_in_addressingmodes'};

    foreach $mode (@$AddressingMode)
	{
		S_teststep("Setting Addressing Mode to $mode", 'AUTO_NBR');
		GDCOM_set_addressing_mode($mode);

		S_teststep("Send '$tcpar_Request' to enter desired Session", 'AUTO_NBR', 'send_request_to_'.$mode);			#measurement 1
		my $diagResp_SessionControl = GDCOM_request_general("REQ_DiagnosticSessionControl_".$tcpar_Request,"PR_DiagnosticSessionControl_".$tcpar_Request);
		my @sessionControl_RespByte = split( / / , $diagResp_SessionControl);# Split all the response bytes of Step1 to array
		S_teststep_expected("Positive response is observed in the following format - '$tcpar_DiagnosticSessionControl_PRSId', '$tcpar_DiagnosticSessionType ', '$tcpar_P2_CAN_Server_Max', '$tcpar_P2Star_CAN_Server_Max'  in data record field.", 'send_request_to_'.$mode);			#evaluation 1
		S_teststep_detected("Response observed is '$sessionControl_RespByte[0]', '$sessionControl_RespByte[1]', '$sessionControl_RespByte[2] $sessionControl_RespByte[3]', '$sessionControl_RespByte[4] $sessionControl_RespByte[5]'",'send_request_to_'.$mode);
		
		EVAL_evaluate_value ( 'resp_positive' , $sessionControl_RespByte[0], '==', $tcpar_DiagnosticSessionControl_PRSId );
		EVAL_evaluate_value ( 'resp_session' , $sessionControl_RespByte[1], '==', $tcpar_DiagnosticSessionType );
		EVAL_evaluate_string ( 'resp_P2' , $tcpar_P2_CAN_Server_Max , $sessionControl_RespByte[2].' '.$sessionControl_RespByte[3]  );
		EVAL_evaluate_string ( 'resp_P2Star' , $tcpar_P2Star_CAN_Server_Max , $sessionControl_RespByte[4].' '.$sessionControl_RespByte[5]  );
	
		S_wait_ms( 3000, "Entry into programming session triggers a reset hence a delay is required" ) if ( $tcpar_Request =~ m/programming/i );
	
	}

	return 1;
}

sub TC_evaluation {

	S_w2rep("Evaluation is done above in stimulation_and_measurement");

	return 1;
}

sub TC_finalization {

	return 1;
}


1;
