#### TEST CASE MODULE
package TC_DSM_NRC_SubFunctionNotSupportedInActiveSession;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.3 $;
our $HEADER  = q$Header: DSM_AB12/TC_DSM_NRC_SubFunctionNotSupportedInActiveSession.pm 1.3 2017/08/11 16:08:13ICT ver6cob develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_NegativeResponseCodes
#TS version in DOORS: 0.1
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use GENERIC_DCOM;
use LIFT_PD;
##################################

our $PURPOSE = "To check the negative response NRC 7E";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_NRC_SubFunctionNotSupportedInActiveSession

=head1 PURPOSE

To check the negative response NRC 7E

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Enter a session in which a service is supported but sub function is not supported (check in SPR/Mapping_DIAG)

2. Send <Request> in physical addressing mode

3. Send <Request> in functional addressing mode

4. Repeat the above steps for different sessions in which the service is not supported


I<B<Evaluation>>

1. -

2. <Response> is received

3. <Response> is received if <SUPPRESS_NRC_7E> is 'no'. Else no response is received

4. Same as above


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Request' => 
	SCALAR 'Purpose' => 
	SCALAR 'Response' => 
	SCALAR 'SUPPRESS_NRC_7E' => 


=head2 PARAMETER EXAMPLES

	Purpose = 'To check the negative response NRC 7E'
	Response = 'NR_subFunctionNotSupportedInActiveSession'
	SUPPRESS_NRC_7E = 'yes' #or 'no'
	Request = 'DiagnosticSessionControl_DefaultSession'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_Response;
my $tcpar_SUPPRESS_NRC_7E;
my $tcpar_Service;
my (%tcpar_CommunicationType, %tcpar_Key, %tcpar_Data, %tcpar_IOControlState, %tcpar_RoutineControlOption);

################ global parameter declaration ###################
#add any global variables here
my %DataValue;

###############################################################

sub TC_set_parameters {

    $tcpar_Purpose         = GEN_Read_mandatory_testcase_parameter('Purpose');
    $tcpar_Response        = GEN_Read_mandatory_testcase_parameter('Response');
    $tcpar_SUPPRESS_NRC_7E = GEN_Read_mandatory_testcase_parameter('SUPPRESS_NRC_7E');
    $tcpar_Service         = GEN_Read_mandatory_testcase_parameter('Service');

    #handle required bytes in request
    $DataValue{'StatusMask'}               = GEN_Read_optional_testcase_parameter('StatusMask');
    $DataValue{'DTC'}                         = GEN_Read_optional_testcase_parameter('DTC');
    $DataValue{'DTCSnapshotRecordNumber'}     = GEN_Read_optional_testcase_parameter('DTCSnapshotRecordNumber');
    $DataValue{'DTCExtendedDataRecordNumber'} = GEN_Read_optional_testcase_parameter('DTCExtendedDataRecordNumber');

    %tcpar_CommunicationType           = GEN_Read_optional_testcase_parameter('CommunicationType');
    %tcpar_Key                         = GEN_Read_optional_testcase_parameter('Key');
    %tcpar_Data                        = GEN_Read_optional_testcase_parameter('Data');
    %tcpar_IOControlState              = GEN_Read_optional_testcase_parameter('IOControlState');
    %tcpar_RoutineControlOption        = GEN_Read_optional_testcase_parameter('RoutineControlOption');

    return 1;
}

sub TC_initialization {

    S_teststep( "\nStandardPrepNoFault\n", 'NO_AUTO_NBR' );
#    GEN_StandardPrepNoFault();
	DIAG_ECUReset_NOVERDICT ();
	S_wait_ms ('TIMER_ECU_READY', 'wait after reset');
	PD_ReadFaultMemory_NOERROR();
	
    GDCOM_start_CyclicTesterPresent();
    GDCOM_set_addressing_mode('physical');

    return 1;
}

sub TC_stimulation_and_measurement {

    my $SID = $tcpar_Service;
    $tcpar_Service = _getServiceLabel($tcpar_Service);
    my $SubFuncInfo = GDCOM_getSupportedSubFunsfromMapping($tcpar_Service);

    my $allSessionsForService = _getSupportedSessionsForService($tcpar_Service);
    S_teststep("All sessions supported for service: @$allSessionsForService\n", 'NO_AUTO_NBR');

    foreach my $subFunc (sort { hex($SubFuncInfo->{$a}) <=> hex($SubFuncInfo->{$b}) } keys %$SubFuncInfo) {
        S_w2rep ("************* Sub Function: $subFunc *************",'orange');
        my $requestLabel = $tcpar_Service . "_" . $subFunc;
        
        unless (_getProtocolForRequest ($requestLabel) eq 'UDS'){
            S_w2rep("Sub Function ($requestLabel) is not supported on UDS protocol. Go to next sub function..");
            next;
        }

        S_teststep( "Enter a session in which $tcpar_Service is supported but sub function $subFunc is not supported (check in SPR/Mapping_DIAG)", 'AUTO_NBR', $subFunc.'NO_EVAL' );
        my $sessionsForRequest = _getSupportedSessionsForRequest($requestLabel);
        S_w2rep("Sessions supported for request: @$sessionsForRequest");

        my $notSupportedSessions = GEN_filterChildarrayFromParentarray( $allSessionsForService, $sessionsForRequest );
        S_w2rep("Sessions in which service ($tcpar_Service) is supported but sub function ($requestLabel) is not supported: @$notSupportedSessions");

        unless ( scalar @$notSupportedSessions ) {    #no not supported sessions
            S_teststep_2nd_level( "There are no sessions in which service ($tcpar_Service) is supported but sub function ($requestLabel) is not supported. Not proceeding!\n", 'NO_AUTO_NBR' );
            S_teststep_expected( "No evaluation\n", $subFunc.'NO_EVAL' );
            S_teststep_detected( "There are no sessions in which service ($tcpar_Service) is supported but sub function ($requestLabel) is not supported. No evaluation.\n", $subFunc.'NO_EVAL' );
            next;
        }
        
        _fillRequestInputParameters ($SID, S_get_contents_of_hash( [ 'Mapping_DIAG', 'DIAG_SERVICES', $tcpar_Service,'Supported_SubFuns', $subFunc]));

		#Repeat the steps for different sessions in which the service is not supported
        foreach my $session (@$notSupportedSessions) {
#        	next if ($session =~ m/safety|disposal/i);
        	
            S_w2rep ("************* Session: $session *************");
            S_teststep( "Enter session: $session", 'AUTO_NBR' );
            DIAG_StartSession($session);
            S_wait_ms (4000, 'wait after session entry') if($session =~ m/prog|boot/i);
            
            my $requestBytes = GDCOM_getRequestLabelValue( "REQ_" . $requestLabel, \%DataValue );

            S_teststep( "Send $requestLabel ($requestBytes) in physical addressing mode", 'AUTO_NBR', $subFunc . "send_request_phys_$session" );    #measurement 1
            GDCOM_set_addressing_mode('physical');
            my $response_phys = GDCOM_request_general( "REQ_" . $requestLabel, $tcpar_Response, \%DataValue );

            my @service = split( /_/, $requestLabel );
            my $NRCInfo = GDCOM_getNRCfromMapping( $tcpar_Service, $tcpar_Response );
            S_teststep_expected( $NRCInfo->{'Response'}, $subFunc . "send_request_phys_$session" );                                   #evaluation 1
            S_teststep_detected( $response_phys, $subFunc . "send_request_phys_$session" );

            S_teststep( "Send $requestLabel ($requestBytes) in functional addressing mode\n", 'AUTO_NBR', $subFunc . "send_request_func_$session" );    #measurement 2
            GDCOM_set_addressing_mode('functional');

            if ( $tcpar_SUPPRESS_NRC_7E eq 'no' ) {
                my $response_func = GDCOM_request_general( "REQ_" . $requestLabel, $tcpar_Response, \%DataValue );

                S_teststep_expected( $NRCInfo->{'Response'}."\n", $subFunc . "send_request_func_$session" );                                 #evaluation 2
                S_teststep_detected( $response_func."\n", $subFunc . "send_request_func_$session" );
            }
            else {                                                                                                                      #no response expected
                
                my $response_func = GDCOM_request( $requestBytes, "", 'quiet' );

                S_teststep_expected( "no response"."\n", $subFunc . "send_request_func_$session" );                                          #evaluation 2
                S_teststep_detected( "-".$response_func."\n", $subFunc . "send_request_func_$session" );
            }
        }
        
        DIAG_ECUReset ();
		S_wait_ms ('TIMER_ECU_READY', 'wait after reset');  
        S_teststep( "\n", 'NO_AUTO_NBR' ); #newline for steps in TR
    }

    return 1;
}

sub TC_evaluation {

    S_w2rep("Evaluation is done above in stimulation_and_measurement");

    return 1;
}

sub TC_finalization {

    GDCOM_stop_CyclicTesterPresent();

    return 1;
}

sub _getServiceLabel {
    my $SID = shift;

    my $services = S_get_contents_of_hash( [ 'Mapping_DIAG', 'PRJ_SUPPORTED_SERVICES' ] );

    foreach my $serv ( keys %$services ) {
        return $serv if ( $services->{$serv} eq $SID );
    }
}

sub _getSupportedSessionsForRequest {
    my $reqLabel = shift;

    return GDCOM_getRequestInfofromMapping ($reqLabel)->{'allowed_in_sessions'};
}

sub _getProtocolForRequest {
    my $reqLabel = shift;

    return GDCOM_getRequestInfofromMapping ($reqLabel)->{'protocol'};
}

sub _getSupportedSessionsForService {
    my $service = shift;

    my @allSessionsForService;
    foreach my $request ( keys( %{ S_get_contents_of_hash( [ 'Mapping_DIAG', 'Requests_Responses' ] ) } ) ) {

        #trace through Diag mapping file check for all the requests for service under test.
        if ( $request =~ /\Q$service\E_/ ) {
            next if ( _getProtocolForRequest ($request) ne 'UDS' );

            foreach my $session ( @{ _getSupportedSessionsForRequest ($request) } ) {
                unless ( grep { $_ eq $session } @allSessionsForService ) {
                    push( @allSessionsForService, $session );
                }
            }
        }
    }

    return \@allSessionsForService;
}

sub _fillRequestInputParameters {
    my $SID = shift;
    my $subFunc = shift;
    

    if($SID eq '27'){
        $DataValue{'Key'} = $tcpar_Key{$subFunc};
    }
    elsif($SID eq '28'){
        $DataValue{'CommunicationType'} = $tcpar_CommunicationType{$subFunc};
    }
    elsif($SID eq '2E'){
        $DataValue{'Data'} = $tcpar_Data{$subFunc};
    }
    elsif($SID eq '2F'){
        $DataValue{'IOControlState'} = $tcpar_IOControlState{$subFunc};
    }
    elsif($SID eq '2F'){
        $DataValue{'IOControlState'} = $tcpar_IOControlState{$subFunc};
    }
    elsif($SID eq '31'){
        $DataValue{'RoutineControlOption'} = $tcpar_RoutineControlOption{$subFunc};
    }

}



1;
