#### TEST CASE MODULE
package TC_DSM_SessionControl_ConditionsNotCorrect;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.5 $;
our $HEADER = q$Header: DSM_AB12/TC_DSM_SessionControl_ConditionsNotCorrect.pm 1.5 2018/05/29 17:44:56ICT Nguyen Van Truc (RBVH/EPS24) (GNR2HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_SessionControl
#TS version in DOORS: 0.2
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use GENERIC_DCOM;
use LIFT_DCOM;
use LIFT_evaluation;
use LIFT_labcar;
use LIFT_PD;
##################################

our $PURPOSE = "To verify that ECU remains in current session if any preconditions prohibiting execution is present";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_SessionControl_ConditionsNotCorrect

=head1 PURPOSE

To verify that ECU remains in current session if any preconditions prohibiting execution is present

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Set Addressing Mode and Protocol

2. Transmit Tester Present periodically at 4.5 sec cycle time

3. Request <Session_1>

4. Set any precondition prohibiting execution as defined in SPR

5. Request <Session_2>

6. Read the active session by sending <ReadActiveSession>

# Repeat the above steps for all supported Addressing modes as defined in the SPR


I<B<Evaluation>>

1.

2.

3. ECU sends Positive response with the current session as <ActiveSession_1>

4.

5. <Response> is obtained.

6. ECU sends Positive Response and session reported is <ActiveSession_2>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'ActiveSession_1' => 
	SCALAR 'ActiveSession_2' => 
	SCALAR 'Purpose' => 
	SCALAR 'Session_1' => 
	SCALAR 'Session_2' => 
	SCALAR 'ReadActiveSession' => 
	SCALAR 'Response' => 
	SCALAR 'PR_ActiveSession_ByteNbr' => 


=head2 PARAMETER EXAMPLES

	Purpose  = 'To verify that ECU remains in current session if any preconditions prohibiting execution is present'
	
	Session_1 = '<Test Heading Head>'
	Session_2 = '<Test Heading Tail>'
	
	
	ReadActiveSession =  'ReadDataByIdentifier_ActiveDiagnosticSession'
	Response           = 'NR_conditionsNotCorrect' #NRC 22
	PR_ActiveSession_ByteNbr= '03'#this is the byte number for active session in the read active session positive response, count from '0'
	ActiveSession_1 = '03'
	ActiveSession_2 = '03'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_Session_1;
my $tcpar_Session_2;
my $tcpar_ReadActiveSession;
my $tcpar_Response;
my $tcpar_PR_ActiveSession_ByteNbr;
my $tcpar_ActiveSession_1;
my $tcpar_ActiveSession_2;
my $tcpar_Precondition;
################ global parameter declaration ###################
#add any global variables here
my $TP_handle;
my $response_2;
my $Preconditions;
my %PreconditionParameters;
my $Addressing_Mode;
my $msg_aref=[0x02,0x3E,0x80,0x00,0x00,0x00,0x00,0x00];
my $msgID;
my $CycleTime = 4500;
my $ActiveSession;
my @session_Response;
my %Session_active = (
	'DefaultSession'     => '01',
	'ProgrammingSession' => '02',
	'ExtendedSession'    => '03',
);

 

###############################################################

sub TC_set_parameters {

	$tcpar_Purpose =  GEN_Read_mandatory_testcase_parameter( 'Purpose' );
	$tcpar_Session_1 =  GEN_Read_mandatory_testcase_parameter( 'Session_1' );
	$tcpar_Session_2 =  GEN_Read_mandatory_testcase_parameter( 'Session_2' );
	$tcpar_ReadActiveSession =  GEN_Read_mandatory_testcase_parameter( 'ReadActiveSession' );
	$tcpar_Response =  GEN_Read_mandatory_testcase_parameter( 'Response' );
	$tcpar_PR_ActiveSession_ByteNbr =  GEN_Read_mandatory_testcase_parameter( 'PR_ActiveSession_ByteNbr' );
	$tcpar_ActiveSession_1 =  GEN_Read_mandatory_testcase_parameter( 'ActiveSession_1' );
	$tcpar_ActiveSession_2 =  GEN_Read_mandatory_testcase_parameter( 'ActiveSession_2' );
	$tcpar_Precondition = GEN_Read_mandatory_testcase_parameter('Precondition');
	##############################  
	$PreconditionParameters{'SpeedSignalName'}   =  GEN_Read_optional_testcase_parameter('SpeedSignalName');
	$PreconditionParameters{'SpeedSignalValue'}  =  GEN_Read_optional_testcase_parameter('SpeedSignalValue');
	$PreconditionParameters{'InternalFaultName'} =  GEN_Read_optional_testcase_parameter('InternalFaultName');
	return 1;
}

sub TC_initialization {

	S_teststep("StandardPrepNoFault", 'AUTO_NBR');
	#    GEN_StandardPrepNoFault();
	DIAG_ECUReset_NOVERDICT ();
	S_wait_ms ('TIMER_ECU_READY', 'wait after reset');
	PD_ReadFaultMemory_NOERROR();
	
	# GDCOM_start_CyclicTesterPresent();
	# GDCOM_set_addressing_mode('physical');

	return 1;
}

sub TC_stimulation_and_measurement {
	
	#Get addressing mode supported for request from Mapping Diag
	$Addressing_Mode = GDCOM_getRequestInfofromMapping(	'DiagnosticSessionControl_' . $tcpar_Session_1 )->{'allowed_in_addressingmodes'};
	
	S_teststep( "# Repeat test steps for all supported Addressing modes as defined in the SPR",	'AUTO_NBR'	);
	foreach my $mode (@$Addressing_Mode) {
		S_teststep( "Set Addressing Mode to: '$mode'", 'AUTO_NBR' );
		GDCOM_set_addressing_mode($mode);
	
		S_teststep("Transmit Tester Present periodically at 4.5 sec cycle time", 'AUTO_NBR');
			if ( $mode =~ /physical/i ) { 
			$msgID = $LIFT_PROJECT::Defaults->{"CUSTOMER_DIAGNOSIS"}{'RequestID_physical'};
		}
		if ( $mode =~ /functional/i ) {
			$msgID = $LIFT_PROJECT::Defaults->{"CUSTOMER_DIAGNOSIS"}{'RequestID_functional'};
		}
	   $TP_handle =  GDCOM_start_CyclicTesterPresent($msg_aref,$msgID,$CycleTime );
	    S_wait_ms(100); 
	    
		S_teststep("Request '$tcpar_Session_1'", 'AUTO_NBR', "request_session_1_in_$mode");			#measurement 1
		my $response_1 = GDCOM_request_general( 'REQ_DiagnosticSessionControl_' . $tcpar_Session_1, 'PR_DiagnosticSessionControl_' . $tcpar_Session_1 );
		S_teststep_expected("ECU sends Positive response ", "request_session_1_in_$mode");			#evaluation 1
	    S_teststep_detected("Response from ECU is: $response_1", "request_session_1_in_$mode"); 
	    S_teststep("Set any precondition prohibiting execution as defined in SPR", 'AUTO_NBR');
	    S_teststep("Request '$tcpar_Session_2'", 'AUTO_NBR', "request_session_2_in_$mode");			#measurement 2
		my $reqLabel= 'DiagnosticSessionControl_'.$tcpar_Session_2;
		my $prohibitingPreconditionsForRequest = GDCOM_getRequestInfofromMapping($reqLabel)->{'preconditions_prohibiting_execution'};
			if ( grep { $_ =~ m/\Q$tcpar_Precondition\E/i } @$prohibitingPreconditionsForRequest ) 
		{
		  DIAG_setProhibitingPrecondition($tcpar_Precondition, \%PreconditionParameters ); 
          S_wait_ms(500);		  
	      $response_2 = GDCOM_request_general( 'REQ_DiagnosticSessionControl_' . $tcpar_Session_2,$tcpar_Response ); 
	      S_teststep_expected("NRC 22 is obtained if set existence precondition and was excuted ", "request_session_2_in_$mode");			
	      S_teststep_detected("Response from ECU is: $response_2", "request_session_2_in_$mode");
	     
	    S_teststep("Read the active session by sending '$tcpar_ReadActiveSession'", 'AUTO_NBR', "read_the_active_in_$mode");			#measurement 3
	    $ActiveSession = ReadActiveSession ();
	    @session_Response = split( / /, $ActiveSession );
		S_teststep_expected( "ECU sends Positive Response and session reported is '$tcpar_Session_1'", "read_the_active_in_$mode");                                               #evaluation 3
		S_teststep_detected( "ECU response is $session_Response[$tcpar_PR_ActiveSession_ByteNbr]", "read_the_active_in_$mode" );
		EVAL_evaluate_value( "Active Session",	$session_Response[$tcpar_PR_ActiveSession_ByteNbr],	'==', $Session_active{$tcpar_Session_1} );
		DIAG_removeProhibitingPrecondition( $tcpar_Precondition, \%PreconditionParameters );
         }
		else
		 {
	  S_w2rep( "Request enter session doesn't depend on $tcpar_Precondition precondition, just evaluate session_2 response" );
	  S_set_error( " No precondition apply for this test case" );
		 }
    
	 GDCOM_stop_CyclicTesterPresent($TP_handle);
	}
		
	return 1;
}

sub TC_evaluation {
 S_w2rep("Evaluation is done above in stimulation_and_measurement");
	return 1;
}

sub TC_finalization {

	return 1;
}

sub ReadActiveSession {
	
	if($tcpar_ReadActiveSession =~ m/rb_/i){ #read from SW variable
		return DIAG_ReadActiveSession_SW_var ( $tcpar_ReadActiveSession );
	}
	else{
		return GDCOM_request_general("REQ_".$tcpar_ReadActiveSession,"PR_".$tcpar_ReadActiveSession);
	}
}


1;
