#### TEST CASE MODULE
package TC_DSM_ReportDTCExtendedDataRecordByDTCNumber;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.4 $;
our $HEADER  = q$Header: DSM_AB12/TC_DSM_ReportDTCExtendedDataRecordByDTCNumber.pm 1.4 2017/11/09 19:16:27ICT ver6cob develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_ReadDTCInformation
#TS version in DOORS: 4.9
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use GENERIC_DCOM;
use LIFT_CD;
use LIFT_evaluation;
##################################

our $PURPOSE = "to check that service 19 06 reports the extended data for a particular DTC";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_ReportDTCExtendedDataRecordByDTCNumber

=head1 PURPOSE

to check that service 19 06 reports the extended data for a particular DTC

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Send <ReportDTCExtendedDataRecordByDTCNumber> for DTC corresponding to <fault> and with<DTCExtendedDataRecordNumber>

2. Create <fault> and wait for qualification time. Remove the fault and wait for dequalification time. Qualify the fault again

3. Send <ReportDTCExtendedDataRecordByDTCNumber> for DTC corresponding to <fault> and with<DTCExtendedDataRecordNumber>

4. Send <ReportDTCExtendedDataRecordByDTCNumber> for DTC corresponding to <fault> and with DTCExtendedDataRecordNumber as 0xFF

5. Compare the corresponding extended data records reported from step 3 and step 4.

6. Repeat steps 3, 4, 5 in all supported addressing modes and all supported sessions


I<B<Evaluation>>

2. Positive response with format 59 06 DTC statusOfDTC (0x00)

3. Positive response with format 59 06 DTC statusOfDTC followed by content of each DTCExtendedDataRecord

4. Positive response with format 59 06 DTC statusOfDTC followed by content of all DTCExtendedDataRecords supported by the project. 

5. Content of each individual extended data record reported in step 3 matches with the content of that corresponding record reported in step 4 (which contains data for all supported records)


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'N' => 
	SCALAR 'purpose' => 
	SCALAR 'ReportDTCExtendedDataRecordByDTCNumber' => 
	SCALAR 'fault' => 
	LIST 'DTCExtendedDataRecordNumber' => 


=head2 PARAMETER EXAMPLES

	purpose = 'to check that service 19 06 reports the extended data for a particular DTC' 
	# input parameters
	ReportDTCExtendedDataRecordByDTCNumber = 'ReadDTCInformation_RepotDtcExtDataRecordByDtcNumber'
	fault = 'rb_sqm_SquibResistanceOpenAB1FD_flt'
	DTCExtendedDataRecordNumber = @('01') #all supported
	#output parameters
	N = 1

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_ReportDTCExtendedDataRecordByDTCNumber;
my $tcpar_fault;
my @tcpar_DTCExtendedDataRecordNumber;
my $tcpar_ExtDataRecordSize;
my $tcpar_StatusOfDTC;

################ global parameter declaration ###################
#add any global variables here

###############################################################

sub TC_set_parameters {

    $tcpar_purpose                                = GEN_Read_mandatory_testcase_parameter('purpose');
    $tcpar_ReportDTCExtendedDataRecordByDTCNumber = GEN_Read_mandatory_testcase_parameter('ReportDTCExtendedDataRecordByDTCNumber');
    $tcpar_fault                                  = GEN_Read_mandatory_testcase_parameter('fault');
    @tcpar_DTCExtendedDataRecordNumber            = GEN_Read_mandatory_testcase_parameter('DTCExtendedDataRecordNumber');
    $tcpar_ExtDataRecordSize                      = GEN_Read_mandatory_testcase_parameter('ExtDataRecordSize');
    $tcpar_StatusOfDTC                            = GEN_Read_mandatory_testcase_parameter('StatusOfDTC');

    return 1;
}

sub TC_initialization {

    S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
    GEN_StandardPrepNoFault();

    GDCOM_start_CyclicTesterPresent();

    return 1;
}

sub TC_stimulation_and_measurement {

    my %DataValue;
    $DataValue{'DTC'} = CD_get_FaultDTC($tcpar_fault);
    $DataValue{'DTC'} =~ s/(\w{2})/$1 /g;    #inserts a space after every 2 characters
	$DataValue{'DTC'} =~ s/\s+$//; #remove whitespace at end

    my $addrModesForRequest = GDCOM_getRequestInfofromMapping($tcpar_ReportDTCExtendedDataRecordByDTCNumber)->{'allowed_in_addressingmodes'};
    my $sessionsForRequest  = GDCOM_getRequestInfofromMapping($tcpar_ReportDTCExtendedDataRecordByDTCNumber)->{'allowed_in_sessions'};

    S_teststep( "Send '$tcpar_ReportDTCExtendedDataRecordByDTCNumber' for DTC corresponding to fault '$tcpar_fault'", 'AUTO_NBR', 'ReadDTC_noFault' );    #measurement 1
    foreach (@tcpar_DTCExtendedDataRecordNumber) {
        S_teststep_2nd_level( "Request with DTCExtendedDataRecordNumber: $_", 'AUTO_NBR', "ReadDTC_noFault_$_" );
        $DataValue{'DTCExtendedDataRecordNumber'} = $_;
        my $response_noFault = GDCOM_request_general( "REQ_" . $tcpar_ReportDTCExtendedDataRecordByDTCNumber, 'PR_' . $tcpar_ReportDTCExtendedDataRecordByDTCNumber, \%DataValue );

        S_teststep_expected( "59 06 $DataValue{'DTC'} 00", "ReadDTC_noFault_$_" );                                                                         #evaluation 1
        S_teststep_detected( "Response = $response_noFault", "ReadDTC_noFault_$_" );
        GDCOM_evaluate_response_bytes( "DTC",       $response_noFault, 2, $DataValue{'DTC'} );
        GDCOM_evaluate_response_bytes( "DTCStatus", $response_noFault, 5, '00' );
    }

    S_teststep( "Create fault '$tcpar_fault', wait for qualification time. Remove the fault and wait for dequalification time. Qualify the fault again", 'AUTO_NBR' );
    FM_createFault($tcpar_fault);
    S_wait_ms( 10000, 'wait for qualification time' );
    FM_removeFault($tcpar_fault);
    S_wait_ms( 10000, 'wait for dequalification time' );
    FM_createFault($tcpar_fault);
    S_wait_ms( 10000, 'wait for qualification time' );

    foreach my $session (@$sessionsForRequest) {
        S_teststep( "Enter session: $session", 'AUTO_NBR' );
        DIAG_StartSession($session);

        foreach my $addrMode (@$addrModesForRequest) {
            S_teststep( "Set addressing mode: $addrMode", 'AUTO_NBR' );
            GDCOM_set_addressing_mode($addrMode);

            S_teststep( "Send '$tcpar_ReportDTCExtendedDataRecordByDTCNumber' for DTC corresponding to '$tcpar_fault'", 'AUTO_NBR', "ReadIndivExtendedDataRec_$addrMode" . "_$session" );
            my %response_bytes_IndvRec;
            foreach (@tcpar_DTCExtendedDataRecordNumber) {
                S_teststep_2nd_level( "Request with DTCExtendedDataRecordNumber: $_", 'AUTO_NBR', "ReadIndivExtendedDataRec_$addrMode" . "_$session" . "$_" );
                $DataValue{'DTCExtendedDataRecordNumber'} = $_;
                my $response_Fault = GDCOM_request_general( "REQ_" . $tcpar_ReportDTCExtendedDataRecordByDTCNumber, 'PR_' . $tcpar_ReportDTCExtendedDataRecordByDTCNumber, \%DataValue );

                $response_bytes_IndvRec{$_} = [ split / /, $response_Fault ];
                my $obs_numOfBytes = scalar @{$response_bytes_IndvRec{$_}};
                my $exp_numOfBytes = 6 + 1 + $tcpar_ExtDataRecordSize;    #Positive response bytes + ExtendedDataRecNumber & ExtendedDataRecNumOfIdentifiers + ExtendedDataRecordSize
                EVAL_evaluate_value( "RecordSize - Individual Record", $obs_numOfBytes, '==', $exp_numOfBytes );    #1 record reported
                S_teststep_expected( "Number of response bytes == $exp_numOfBytes (1 Record)", "ReadIndivExtendedDataRec_$addrMode" . "_$session" . "$_" );
                S_teststep_detected( "Number of response bytes == $obs_numOfBytes", "ReadIndivExtendedDataRec_$addrMode" . "_$session" . "$_" );
                
                S_teststep_expected("59 06 $DataValue{'DTC'} $tcpar_StatusOfDTC", "ReadIndivExtendedDataRec_$addrMode" . "_$session" . "$_");                               
                S_teststep_detected("Response = $response_Fault", "ReadIndivExtendedDataRec_$addrMode" . "_$session" . "$_");
                GDCOM_evaluate_response_bytes( "DTC", $response_Fault, 2, $DataValue{'DTC'} );
                GDCOM_evaluate_response_bytes( "DTCStatus", $response_Fault, 5, $tcpar_StatusOfDTC ); 
            }

            S_teststep( "Send '$tcpar_ReportDTCExtendedDataRecordByDTCNumber' for DTC corresponding to '$tcpar_fault' and with DTCExtendedDataRecordNumber as 0xFF", 'AUTO_NBR', "ReadAllExtendedDataRec_$addrMode" . "_$session" );    #measurement 2
            $DataValue{'DTCExtendedDataRecordNumber'} = 'FF';
            my $response_Fault_AllRec = GDCOM_request_general( "REQ_" . $tcpar_ReportDTCExtendedDataRecordByDTCNumber, 'PR_' . $tcpar_ReportDTCExtendedDataRecordByDTCNumber, \%DataValue );

            my @response_bytes_AllRec    = split / /, $response_Fault_AllRec;
            my $obs_numOfBytes_AllRec    = scalar @response_bytes_AllRec;
            my $numOfExtendedDataRecords = scalar @tcpar_DTCExtendedDataRecordNumber;
            my $exp_numOfBytes_AllRec    = 6 + ( 1 + $tcpar_ExtDataRecordSize ) * $numOfExtendedDataRecords;    #Positive response bytes + (ExtendedDataRecNumber & ExtendedDataRecNumOfIdentifiers + ExtendedDataRecordSize)*NumberOfExtendedDataRecords
            EVAL_evaluate_value( "RecordSize - All Records", $obs_numOfBytes_AllRec, '==', $exp_numOfBytes_AllRec );          #1 record reported
            S_teststep_expected( "Number of response bytes == $exp_numOfBytes_AllRec (all Records)", "ReadAllExtendedDataRec_$addrMode" . "_$session" );
            S_teststep_detected( "Number of response bytes == $obs_numOfBytes_AllRec", "ReadAllExtendedDataRec_$addrMode" . "_$session" );
            
            S_teststep_expected("59 06 $DataValue{'DTC'} $tcpar_StatusOfDTC", "ReadAllExtendedDataRec_$addrMode" . "_$session");                                      
            S_teststep_detected("Response = $response_Fault_AllRec", "ReadAllExtendedDataRec_$addrMode" . "_$session");
            GDCOM_evaluate_response_bytes( "DTC", $response_Fault_AllRec, 2, $DataValue{'DTC'} );
            GDCOM_evaluate_response_bytes( "DTCStatus", $response_Fault_AllRec, 5, $tcpar_StatusOfDTC ); 
            

            S_teststep( "Compare the corresponding ExtendedData records reported from step 3 and step 4", 'AUTO_NBR', "CompareRecContent_$addrMode" . "_$session" );    #measurement 2
            my $recCnt = 0;
            foreach (@tcpar_DTCExtendedDataRecordNumber) {
                splice @{ $response_bytes_IndvRec{$_} }, 0, 6;                                                                                #remove positive response bytes (1 to 6)
				my @Recordbytes_IndvRec = @{ $response_bytes_IndvRec{$_} };
                my $recordSize = 1 + $tcpar_ExtDataRecordSize;
				splice @response_bytes_AllRec, 0, 6; #remove positive response bytes (1 to 6)
                my @RecordBytes_AllRec = splice @response_bytes_AllRec, $recordSize*$recCnt, $recordSize; #remove bytes for each record
        
				S_w2rep ("Recordbytes_IndvRec: @Recordbytes_IndvRec");
				S_w2rep ("RecordBytes_AllRec: @RecordBytes_AllRec");
                GEN_EVAL_CompareStrArrays( \@Recordbytes_IndvRec, \@RecordBytes_AllRec, 'Equal' ) unless $main::opt_offline;
                $recCnt++;
            }
        }

    }

    FM_removeFault($tcpar_fault);
    S_wait_ms( 10000, 'wait for dequalification time' );

    return 1;
}

sub TC_evaluation {

    S_w2rep("Evaluation is done above in stimulation_and_measurement");

    return 1;
}

sub TC_finalization {

    GDCOM_stop_CyclicTesterPresent();
    GDCOM_set_addressing_mode('physical');

    return 1;
}

1;
