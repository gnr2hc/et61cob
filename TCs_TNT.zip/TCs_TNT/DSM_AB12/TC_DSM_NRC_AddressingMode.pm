#### TEST CASE MODULE
package TC_DSM_NRC_AddressingMode;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.4 $;
our $HEADER = q$Header: DSM_AB12/TC_DSM_NRC_AddressingMode.pm 1.4 2017/08/31 14:42:17ICT ver6cob develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_NegativeResponseCodes
#TS version in DOORS: 0.1
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use GENERIC_DCOM;
use LIFT_PD;
##################################

our $PURPOSE = "To verify the NRCs if a service is not supported on a particular addressing mode";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_NRC_AddressingMode

=head1 PURPOSE

To verify the NRCs if a service is not supported on a particular addressing mode

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Enter session supported by the service. Get security access if required

2. Send the service in a not supported addressing mode

Repeat for all requests within a service


I<B<Evaluation>>

1. <Response> is received. NRC $31 is suppressed in functional addressing mode if <DCMAPPL_SUPPRESS_NRC> is 'yes'


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Purpose' => 
	SCALAR 'Response' => 


=head2 PARAMETER EXAMPLES

	Purpose = 'To verify the NRCs if a service is not supported on a particular addressing mode'
	Response = 'NR_subFunctionNotSupported'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_Service;
my $tcpar_Response;
my $tcpar_allAddressingModes;
my $tcpar_DCMAPPL_SUPPRESS_NRC;
my (%tcpar_CommunicationType, %tcpar_Key, %tcpar_Data, %tcpar_IOControlState, %tcpar_RoutineControlOption);

################ global parameter declaration ###################
#add any global variables here
my %DataValue;

###############################################################

sub TC_set_parameters {

	$tcpar_Purpose =  GEN_Read_mandatory_testcase_parameter( 'Purpose' );
	$tcpar_Service = GEN_Read_mandatory_testcase_parameter('Service');
	$tcpar_Response =  GEN_Read_mandatory_testcase_parameter( 'Response' );
	$tcpar_allAddressingModes = GEN_Read_mandatory_testcase_parameter( 'AlladdressingModes', 'byref' );
	
	#handle required bytes in request
    $DataValue{'StatusMask'}               = GEN_Read_optional_testcase_parameter('StatusMask');
    $DataValue{'DTC'}                         = GEN_Read_optional_testcase_parameter('DTC');
    $DataValue{'DTCSnapshotRecordNumber'}     = GEN_Read_optional_testcase_parameter('DTCSnapshotRecordNumber');
    $DataValue{'DTCExtendedDataRecordNumber'} = GEN_Read_optional_testcase_parameter('DTCExtendedDataRecordNumber');

    %tcpar_CommunicationType           = GEN_Read_optional_testcase_parameter('CommunicationType');
    %tcpar_Key                         = GEN_Read_optional_testcase_parameter('Key');
    %tcpar_Data                        = GEN_Read_optional_testcase_parameter('Data');
    %tcpar_IOControlState              = GEN_Read_optional_testcase_parameter('IOControlState');
    %tcpar_RoutineControlOption        = GEN_Read_optional_testcase_parameter('RoutineControlOption');

	return 1;
}

sub TC_initialization {

	S_teststep("\nStandardPrepNoFault\n", 'NO_AUTO_NBR');
#	GEN_StandardPrepNoFault();
	DIAG_ECUReset_NOVERDICT ();
	S_wait_ms ('TIMER_ECU_READY', 'wait after reset');
	PD_ReadFaultMemory_NOERROR();
	
	GDCOM_start_CyclicTesterPresent();
	GDCOM_set_addressing_mode('physical');

	return 1;
}

sub TC_stimulation_and_measurement {
    
	#Repeat for all requests within a service
    
    my $SID = $tcpar_Service;
    $tcpar_Service = _getServiceLabel($tcpar_Service);
    my $SubFuncInfo = GDCOM_getSupportedSubFunsfromMapping($tcpar_Service);

    foreach my $subFunc (sort { hex($SubFuncInfo->{$a}) <=> hex($SubFuncInfo->{$b}) } keys %$SubFuncInfo) {
    	
        my $requestLabel = $tcpar_Service . "_" . $subFunc;
        S_w2rep ("************* $requestLabel *************",'orange');
        
        if ($SID eq '22' and _getProtocolForRequest ($requestLabel) =~ m/disposal/i){
            S_w2rep("Disposal DIDs ($requestLabel) are supported both in Default and Disposal/Safety session. Go to next DID..");
            next;
        }
        
        next if ($SID eq '10' and $subFunc =~ m/default/i); #skip for 10 01 in any addressing mode
	
		my $addrModesForRequest;
		if(_getProtocolForRequest ($requestLabel) =~ m/disposal/i){
			$addrModesForRequest = ['disposal'];
		}
		else{
			$addrModesForRequest = _getSupportedAddrModesForRequest($requestLabel);
		}

        my $notSupportedAddrModes = GEN_filterChildarrayFromParentarray( $tcpar_allAddressingModes, $addrModesForRequest );
        S_teststep("Addressing modes in which '$requestLabel' is not supported: @$notSupportedAddrModes", 'NO_AUTO_NBR');

        unless ( scalar @$notSupportedAddrModes ) {    #no not supported addr modes
            S_teststep( "There are no addressing modes in which request ($requestLabel) is not supported. Not proceeding!", 'NO_AUTO_NBR' );
            next;
        }
        
        _fillRequestInputParameters ($SID, S_get_contents_of_hash( [ 'Mapping_DIAG', 'DIAG_SERVICES', $tcpar_Service,'Supported_SubFuns', $subFunc]));
        
        if ($SID eq '2E'){ #for 2E service, write the same value as read by 22 service
        	GDCOM_set_addressing_mode('disposal') if (_getProtocolForRequest ($requestLabel) =~ m/disposal/i);
    		my $DID = S_get_contents_of_hash( [ 'Mapping_DIAG', 'DIAG_SERVICES', $tcpar_Service,'Supported_SubFuns', $subFunc]);
    		my $readdata = GDCOM_request_NOVERDICT ("22 $DID", "62 $DID", 'relax');
    		$readdata = substr($readdata, 9); #remove 62 DIDHB DIDLB
    		$DataValue{'Data'} = $readdata if (defined $readdata);
    	}
        
        my $NRCInfo = GDCOM_getNRCfromMapping( $tcpar_Service, $tcpar_Response );
        my $requestBytes = GDCOM_getRequestLabelValue( "REQ_" . $requestLabel, \%DataValue );
        
        
        if ($requestBytes =~ m/11 01/i){ #skip for 11 01 (supported in all addressing modes){
        	S_teststep("11 01 is supported in all addressing modes. Not proceeding.\n", 'NO_AUTO_NBR');
        	next;
        }
        
        my $sessionsForRequest = _getSupportedSessionsForRequest($requestLabel);
        S_teststep("Enter session: @$sessionsForRequest[0]", 'AUTO_NBR');
        GDCOM_set_addressing_mode('disposal') if (@$sessionsForRequest[0] =~ m/safety|disposal/i);
        DIAG_StartSession(@$sessionsForRequest[0]);
        S_wait_ms (5000, 'wait after session entry') if(@$sessionsForRequest[0] =~ m/prog|boot/i);
        
        my $securityLevelsForRequest = _getSecurityLevelsForRequest($requestLabel);

        if ( @$securityLevelsForRequest[0] !~ m/None/i and @$securityLevelsForRequest[0] ne '---' ){ #in case security access is required
            S_teststep("Get required security access: @$securityLevelsForRequest", 'AUTO_NBR');
            DIAG_getSecurityAccess (@$securityLevelsForRequest[0]) if (defined &DIAG_getSecurityAccess);
        }

        GDCOM_GetAccessToRequest ($requestLabel); #handle any dependent services through request in Mapping_DIAG (if required)

        
        foreach my $addrMode (@$notSupportedAddrModes){

        	next if ($subFunc =~ m/safety|disposal/i and $addrMode =~ m/disposal/i); #skip for 10 04 in disposal addressing mode
        	
        	
            S_teststep("Send $requestLabel ($requestBytes) in $addrMode addressing mode", 'AUTO_NBR', $subFunc . "send_request_$addrMode");
            GDCOM_set_addressing_mode($addrMode);
            
            if ( $addrMode eq 'functional' ) {
                
                my $response_func = GDCOM_request( $requestBytes, "", 'quiet' );

                S_teststep_expected( "no response", $subFunc . "send_request_$addrMode" );                                          #evaluation 2
                S_teststep_detected( "no response", $subFunc . "send_request_$addrMode" ) if($response_func eq '');
                S_teststep_detected( "MISMATCH: $response_func", $subFunc . "send_request_$addrMode" ) if($response_func ne '');
            }
            else { 
                my $response = GDCOM_request_general( "REQ_" . $requestLabel, $tcpar_Response, \%DataValue );

                S_teststep_expected( $NRCInfo->{'Response'}, $subFunc . "send_request_$addrMode" );                                 #evaluation 2
                S_teststep_detected( $response, $subFunc . "send_request_$addrMode" ) if($response eq $NRCInfo->{'Response'});
                S_teststep_detected( "MISMATCH:".$response, $subFunc . "send_request_$addrMode" ) if($response ne $NRCInfo->{'Response'});  
            }
            
        }
        
        if(@$sessionsForRequest[0] =~ m/prog|boot/i){
        	DIAG_ECUReset ();
			S_wait_ms ('TIMER_ECU_READY', 'wait after reset');
        }
        else{
        	GDCOM_set_addressing_mode('physical');	
        }
        
        
        S_teststep( "\n", 'NO_AUTO_NBR' ); #newline for steps in TR
    }

	return 1;
}

sub TC_evaluation {
    
    S_w2rep("Evaluation is done above in stimulation_and_measurement");

	return 1;
}

sub TC_finalization {
    
    GDCOM_stop_CyclicTesterPresent();

	return 1;
}

sub _getServiceLabel {
    my $SID = shift;

    my $services = S_get_contents_of_hash( [ 'Mapping_DIAG', 'PRJ_SUPPORTED_SERVICES' ] );

    foreach my $serv ( keys %$services ) {
        return $serv if ( $services->{$serv} eq $SID );
    }
}

sub _getSecurityLevelsForRequest {
    my $reqLabel = shift;

    return GDCOM_getRequestInfofromMapping ($reqLabel)->{'allowed_in_securitylevels'};
}

sub _getProtocolForRequest {
    my $reqLabel = shift;

    return GDCOM_getRequestInfofromMapping ($reqLabel)->{'protocol'};
}

sub _getSupportedAddrModesForRequest {
    my $reqLabel = shift;

    return GDCOM_getRequestInfofromMapping ($reqLabel)->{'allowed_in_addressingmodes'};
}

sub _getSupportedSessionsForRequest {
    my $reqLabel = shift;

    return GDCOM_getRequestInfofromMapping ($reqLabel)->{'allowed_in_sessions'};
}

sub _fillRequestInputParameters {
    my $SID = shift;
    my $subFunc = shift;
    

    if($SID eq '27'){
        $DataValue{'Key'} = $tcpar_Key{$subFunc};
    }
    elsif($SID eq '28'){
        $DataValue{'CommunicationType'} = $tcpar_CommunicationType{$subFunc};
    }
    elsif($SID eq '2E'){
        $DataValue{'Data'} = $tcpar_Data{$subFunc};
    }
    elsif($SID eq '2F'){
        $DataValue{'IOControlState'} = $tcpar_IOControlState{$subFunc};
    }
    elsif($SID eq '2F'){
        $DataValue{'IOControlState'} = $tcpar_IOControlState{$subFunc};
    }
    elsif($SID eq '31'){
        $DataValue{'RoutineControlOption'} = $tcpar_RoutineControlOption{$subFunc};
    }

}


1;
