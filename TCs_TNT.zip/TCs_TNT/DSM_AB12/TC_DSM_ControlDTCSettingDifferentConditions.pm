#### TEST CASE MODULE
package TC_DSM_ControlDTCSettingDifferentConditions;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.4.2.4 $;
our $HEADER  = q$Header: DSM_AB12/TC_DSM_ControlDTCSettingDifferentConditions.pm 1.4.2.4 2020/04/30 18:25:04ICT Anurag G N (RBEI/ESA-PP3) (UAG6KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_ControlDTCSetting
#TS version in DOORS:0.2
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary
use LIFT_can_access;
use LIFT_labcar;
use GENERIC_DCOM;
use LIFT_PD;
use LIFT_CD;
use LIFT_evaluation;
use LIFT_DCOM;

#include further modules here

##################################

our $PURPOSE = "To cross check the functionality of ControlDTCSettings request in different conditions like diagnostic sessions, ECU reset and reenabling the ControlDTCSetting ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_CtrlDTCSettingDifferentConditions

=head1 PURPOSE

To cross check the functionality of ControlDTCSettings request in different conditions like diagnostic sessions, ECU reset and reenabling the ControlDTCSetting

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Set Addressing_Mode as per Project specific SPR.

2. Send Tester present cyclically.

3. Send request to enter <Session>.

4. Send request <ControlDTCOFF>. 

5. Create faults <ExternalFaults>. Wait for <WaitTime>.

6. Read Fault Recorder using PD and CD.

7. Create test condition <Condition>. 

8. Wait for <WaitTime>.

9. Read Fault Recorder using PD and CD.

10. Send Tester present cyclically. Send request to enter <Session>. 

11. Send request <ControlDTCOFF>. 

12. Remove faults <ExternalFaults>. Wait for <WaitTime>.

13. Read Fault Recorder using PD and CD.

14. Create test condition <Condition>. Wait for <WaitTime>.

15. Read Fault Recorder using PD and CD.


I<B<Evaluation>>

1.

2.

3. Positive response obtained.

4. Positive response obtained.

5.

6. Faults have status <No_ExtFaultStatus>.

7. 

8. 

9. Faults have status <ExtFaultStatus_Quali>.

10. Positive response obtained.

11. Positive response obtained.

12. 

13. Faults have status <ExtFaultStatus_Quali>.

14. 

15. Faults have status <ExtFaultStatus_Dequali>.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'ExtFaultStatus_Dequali' => 
	SCALAR 'purpose' => 
	SCALAR 'ControlDTCOFF' => 
	SCALAR 'Session' => 
	LIST 'ExternalFaults' => 
	SCALAR 'Condition' => 
	SCALAR 'WaitTime' => 
	SCALAR 'No_ExtFaultStatus' => 
	SCALAR 'ExtFaultStatus_Quali' => 


=head2 PARAMETER EXAMPLES

	purpose		 = 'Check ControlDTCSettings functionality in different conditions'
	
	# input parameters
	ControlDTCOFF 	= 'ControlDTCSetting_Off' #85 02
	Session = 'ExtendedSession'
	
	ExternalFaults = @('rb_sqm_SquibResistanceOpenAB1FD_flt', 'rb_swm_OpenLineBLFD_flt', 'rb_psem_OpenLineUFSD_flt')
	
	Condition  = '<Test Heading>'
	
	WaitTime = 10000 #in msec
	
	# output parameters
	No_ExtFaultStatus = 'TBD'
	ExtFaultStatus_Quali = 'TBD'
	ExtFaultStatus_Dequali = 'TBD' #Faults not qualified

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_ControlDTCOFF;
my $tcpar_Session;
my @tcpar_ExternalFaults;
my $tcpar_Condition;
my $tcpar_WaitTime;
my $tcpar_No_ExtFaultStatus;
my $tcpar_ExtFaultStatus_Quali;
my $tcpar_ExtFaultStatusafterReset_Dequali;
my %tcpar_ExtFaultStatus_Dequali;
my %tcpar_ExtFaultStatusafterReset_Dequali;
my $tcpar_VehcileSpeedSignal;
my $tcpar_Speedvalue;
my $tcpar_CrashCode;
my $tcpar_ResultDB;
################ global parameter declaration ###################
#add any global variables here
my ( $mode, $Addressing_Mode );
my %PreconditionParameters;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose                          = GEN_Read_mandatory_testcase_parameter('purpose');
	$tcpar_ControlDTCOFF                    = GEN_Read_mandatory_testcase_parameter('ControlDTCOFF');
	$tcpar_Session                          = GEN_Read_mandatory_testcase_parameter('Session');
	@tcpar_ExternalFaults                   = GEN_Read_mandatory_testcase_parameter('ExternalFaults');
	$tcpar_Condition                        = GEN_Read_mandatory_testcase_parameter('Condition');
	$tcpar_WaitTime                         = GEN_Read_mandatory_testcase_parameter('WaitTime');
	$tcpar_No_ExtFaultStatus                = GEN_Read_mandatory_testcase_parameter('No_ExtFaultStatus');
	$tcpar_ExtFaultStatus_Quali             = GEN_Read_mandatory_testcase_parameter('ExtFaultStatus_Quali');
	%tcpar_ExtFaultStatus_Dequali           = GEN_Read_mandatory_testcase_parameter('ExtFaultStatus_Dequali');
	%tcpar_ExtFaultStatusafterReset_Dequali = GEN_Read_optional_testcase_parameter('ExtFaultStatusafterReset_Dequali');
	$tcpar_VehcileSpeedSignal               = GEN_Read_optional_testcase_parameter('VehcileSpeedSignal');
	$tcpar_Speedvalue                       = GEN_Read_optional_testcase_parameter('Speedvalue');
	$tcpar_CrashCode                        = GEN_Read_optional_testcase_parameter('CrashCode');
	$tcpar_ResultDB                         = GEN_Read_optional_testcase_parameter('ResultDB');

	$PreconditionParameters{'CRASHNAME'} = $tcpar_CrashCode;
	$PreconditionParameters{'RESULTDB'}  = $tcpar_ResultDB;

	return 1;
}

sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( "Send Tester present cyclically.", 'AUTO_NBR' );
	GDCOM_start_CyclicTesterPresent();
	S_wait_ms(500);
	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Set Addressing_Mode as per Project specific SPR.", 'AUTO_NBR' );
	my $Addressing_Mode = GDCOM_getRequestInfofromMapping($tcpar_ControlDTCOFF)->{'allowed_in_addressingmodes'};
	foreach $mode (@$Addressing_Mode) {

		S_w2rep( "Set addressing mode to : $mode", 'AUTO_NBR' );
		GDCOM_set_addressing_mode($mode);

		S_teststep( "Send request to enter '$tcpar_Session'.", 'AUTO_NBR', );    #measurement 1
		my $session_Response = GDCOM_request_general( "REQ_DiagnosticSessionControl_" . $tcpar_Session, "PR_DiagnosticSessionControl_" . $tcpar_Session );
		S_teststep_expected("Positive shall be obtained.");
		S_teststep_detected("Obtained Response is $session_Response");

		S_teststep( "Send request '$tcpar_ControlDTCOFF'. ", 'AUTO_NBR', );      #measurement 2
		my $ControlDTCOFFResponse = GDCOM_request_general( "REQ_" . $tcpar_ControlDTCOFF, "PR_" . $tcpar_ControlDTCOFF );
		S_teststep_expected("PR_.$tcpar_ControlDTCOFF' shall be obtained.");
		S_teststep_detected("Obtained response is $ControlDTCOFFResponse");

		S_teststep( "Create faults '@tcpar_ExternalFaults'. Wait for '$tcpar_WaitTime'.", 'AUTO_NBR' );
		foreach my $fault (@tcpar_ExternalFaults) {
			FM_createFault($fault);

		}
		S_wait_ms($tcpar_WaitTime);

		S_teststep( "Read Fault Recorder using PD and CD.", 'AUTO_NBR' );        #measurement 3
		my $flt_mem_struct_pd_A = PD_ReadFaultMemory();
		my $flt_mem_struct_cd_A = CD_read_DTC( '02', '08' );

		foreach my $fault (@tcpar_ExternalFaults) {
			CD_check_fault_status( $flt_mem_struct_cd_A, $fault, $tcpar_No_ExtFaultStatus );
		}

		S_teststep( "Create test condition '$tcpar_Condition'. ", 'AUTO_NBR' );
		setcondition( $tcpar_Condition, $mode );

		S_teststep( "Wait for '$tcpar_WaitTime ms'.", 'AUTO_NBR' );
		S_wait_ms($tcpar_WaitTime);

		S_teststep( "Read Fault Recorder using PD and CD.", 'AUTO_NBR' );    #measurement 4
		my $flt_mem_struct_pd_B = PD_ReadFaultMemory();
		my $flt_mem_struct_cd_B = CD_read_DTC( '02', '08' );

		foreach my $fault (@tcpar_ExternalFaults) {
			my $faultproperty = FM_fetchFaultInfo($fault);
			my $faulttype     = $faultproperty->{'FaultType'};
			S_w2rep("$fault is $faulttype type fault");
			if ( $faulttype eq ( 'init' or 'Init' ) ) {
				if ( $tcpar_Condition eq 'ECUOffOn' or $tcpar_Condition eq 'ECUReset' ) {
					CD_check_fault_status( $flt_mem_struct_cd_B, $fault, $tcpar_ExtFaultStatus_Quali );
				}
				else {
					CD_check_fault_status( $flt_mem_struct_cd_B, $fault, $tcpar_No_ExtFaultStatus );
				}
			}
			else {
				CD_check_fault_status( $flt_mem_struct_cd_B, $fault, $tcpar_ExtFaultStatus_Quali );
			}
		}
		S_teststep( "Send request to enter '$tcpar_Session'. ", 'AUTO_NBR' );    #measurement 5
		if ( $tcpar_Condition eq 'StopTesterPresent' ) {
			GDCOM_start_CyclicTesterPresent();
			S_wait_ms(500);
		}

		if ( $tcpar_Condition eq 'VehicleSpeedTooHigh' ) {
			my $parameters_href = { "SpeedSignalName" => $tcpar_VehcileSpeedSignal };
			DIAG_removeProhibitingPrecondition( 'VehicleSpeedTooHigh', $parameters_href );
		}

		my $session_Response = GDCOM_request_general( "REQ_DiagnosticSessionControl_" . $tcpar_Session, "PR_DiagnosticSessionControl_" . $tcpar_Session );
		S_teststep_expected("Positive shall be obtained.");
		S_teststep_detected("Obtained Response is $session_Response");

		S_teststep( "Send request '$tcpar_ControlDTCOFF'. ", 'AUTO_NBR' );    #measurement 6
		my $ControlDTCOFFResponse = GDCOM_request_general( "REQ_" . $tcpar_ControlDTCOFF, "PR_" . $tcpar_ControlDTCOFF );
		S_teststep_expected("'PR_'.$tcpar_Condition shall be obtained.");
		S_teststep_detected("Obtained response is $ControlDTCOFFResponse");

		S_teststep( "Remove faults '@tcpar_ExternalFaults'. Wait for '$tcpar_WaitTime'.", 'AUTO_NBR' );
		foreach my $fault (@tcpar_ExternalFaults) {
			FM_removeFault($fault);
		}
		S_wait_ms($tcpar_WaitTime);

		S_teststep( "Read Fault Recorder using PD and CD.", 'AUTO_NBR' );     #measurement 7
		my $flt_mem_struct_pd_C = PD_ReadFaultMemory();
		my $flt_mem_struct_cd_C = CD_read_DTC( '02', '08' );

		foreach my $fault (@tcpar_ExternalFaults) {
			my $faultproperty = FM_fetchFaultInfo($fault);
			my $faulttype     = $faultproperty->{'FaultType'};
			S_w2rep("$fault is $faulttype type fault");
			if ( $faulttype eq ( 'init' or 'Init' ) ) {
				if ( $tcpar_Condition eq 'ECUOffOn' or $tcpar_Condition eq 'ECUReset' ) {
					CD_check_fault_status( $flt_mem_struct_cd_C, $fault, $tcpar_ExtFaultStatus_Quali );
				}
				else {
					CD_check_fault_status( $flt_mem_struct_cd_C, $fault, $tcpar_No_ExtFaultStatus );
				}
			}
			else {
				CD_check_fault_status( $flt_mem_struct_cd_C, $fault, $tcpar_ExtFaultStatus_Quali );
			}
		}
		S_teststep( "Create test condition '$tcpar_Condition'. Wait for '$tcpar_WaitTime'.", 'AUTO_NBR' );

		setcondition( $tcpar_Condition, $mode );

		S_wait_ms($tcpar_WaitTime);
		S_teststep( "Read Fault Recorder using PD and CD.", 'AUTO_NBR' );    #measurement 8
		my $flt_mem_struct_pd_D = PD_ReadFaultMemory();
		my $flt_mem_struct_cd_D = CD_read_DTC( '02', '08' );

		foreach my $fault (@tcpar_ExternalFaults) {
			my $faultproperty = FM_fetchFaultInfo($fault);
			my $faulttype     = $faultproperty->{'FaultType'};
			S_w2rep("$fault is $faulttype type fault");
			if ( $faulttype eq ( 'init' or 'Init' ) ) {
				if ( $tcpar_Condition eq 'ECUOffOn' or $tcpar_Condition eq 'ECUReset' ) {

					#my $tcpar_ExtFaultStatusafterReset_Dequali  =  GEN_Read_mandatory_testcase_parameter( 'ExtFaultStatussfterReset_Dequali' );
					CD_check_fault_status( $flt_mem_struct_cd_D, $fault, $tcpar_ExtFaultStatusafterReset_Dequali{$fault} );
				}
				else {
					CD_check_fault_status( $flt_mem_struct_cd_D, $fault, $tcpar_No_ExtFaultStatus );
				}
			}
			else {
				if ( $tcpar_Condition eq 'ECUOffOn' or $tcpar_Condition eq 'ECUReset' ) {

					#my $tcpar_ExtFaultStatusafterReset_Dequali  =  GEN_Read_mandatory_testcase_parameter( 'ExtFaultStatussfterReset_Dequali' );
					CD_check_fault_status( $flt_mem_struct_cd_D, $fault, $tcpar_ExtFaultStatusafterReset_Dequali{$fault} );
				}
				else {
					CD_check_fault_status( $flt_mem_struct_cd_D, $fault, $tcpar_ExtFaultStatus_Dequali{$fault} );
				}
			}
		}
		if ( $tcpar_Condition eq 'StopTesterPresent' ) {
			GDCOM_start_CyclicTesterPresent();
			S_wait_ms(500);
		}
		if ( $tcpar_Condition eq 'VehicleSpeedTooHigh' ) {
			my $parameters_href = { "SpeedSignalName" => $tcpar_VehcileSpeedSignal };
			DIAG_removeProhibitingPrecondition( 'VehicleSpeedTooHigh', $parameters_href );
		}

		PD_ClearFaultMemory();
	}
	return 1;
}

sub TC_evaluation {
	S_w2rep("Evaluation is done above in stimulation_and_measurement");
	return 1;
}

sub TC_finalization {

	PD_ClearFaultMemory();
	S_wait_ms(2000);

	GDCOM_stop_CyclicTesterPresent();

	return 1;
}

sub setcondition {
	my $condition       = shift;
	my $Addressing_Mode = shift;    #Defined this parameter if codition is ECU Reset or ECU on/off
	unless ( defined $condition ) {
		S_set_error("Mandatory parameter $condition is nor defined");
		return 1;
	}

	if ( $condition eq 'ExtendedSession' or $condition eq 'DefaultSession' ) {
		my $session_Response = GDCOM_request_general( "REQ_DiagnosticSessionControl_" . $condition, "PR_DiagnosticSessionControl_" . $condition );
		S_teststep_expected("Positive shall be obtained.");    #evaluation 1
		S_teststep_detected("Obtained Response is $session_Response");
	}
	elsif ( $condition eq 'ECUReset' ) {
		DIAG_ECUReset();
		S_wait_ms(500);
		S_teststep( "$condition is performed.", 'AUTO_NBR' );
		S_wait_ms(500);
		GDCOM_set_addressing_mode($Addressing_Mode);
	}
	elsif ( $condition eq 'ECUOffOn' ) {
		LC_ECU_Off();
		S_wait_ms(5000);
		LC_ECU_On();
	}
	elsif ( $condition eq 'VehicleSpeedTooHigh' ) {
		my $parameters_href = { "SpeedSignalName" => $tcpar_VehcileSpeedSignal, "SpeedSignalValue" => $tcpar_Speedvalue };
		DIAG_setProhibitingPrecondition( 'VehicleSpeedTooHigh', $parameters_href );
	}
	elsif ( $condition eq 'StopTesterPresent' ) {
		GDCOM_stop_CyclicTesterPresent();
		S_wait_ms(500);
	}
	elsif ( $condition eq 'CrashOccured' ) {
		DIAG_setProhibitingPrecondition('AnyEventStored', \%PreconditionParameters );
	}
}

1;
