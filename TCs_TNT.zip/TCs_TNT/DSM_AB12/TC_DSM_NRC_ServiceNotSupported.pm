#### TEST CASE MODULE
package TC_DSM_NRC_ServiceNotSupported;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.4 $;
our $HEADER  = q$Header: DSM_AB12/TC_DSM_NRC_ServiceNotSupported.pm 1.4 2019/08/20 13:18:05ICT Nguyen Van Truc (RBVH/EPS24) (GNR2HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_NegativeResponseCodes
#TS version in DOORS: 0.1
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use GENERIC_DCOM;
use LIFT_PD;
##################################

our $PURPOSE = "To verify that NRC 11 or no response is received for not supported services";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_NRC_ServiceNotSupported

=head1 PURPOSE

To verify that NRC 11 or no response is received for not supported services

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Enter <Session>

2. Set <Protocol_AddressingMode>

3. Send <Services_Set1>

4. Send <Services_Set2>

Repeat the above steps for each Session supported in the project


I<B<Evaluation>>

1.  

2.

3. <Response_Set1> is received if <DcmRespondAllRequest> is 'yes'. Else no response is received

4. <Response_Set2> is received


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Response_Set1' => 
	SCALAR 'Response_Set2' => 
	SCALAR 'purpose' => 
	LIST 'Session' => 
	SCALAR 'Protocol_AddressingMode' => 
	LIST 'Services_Set1' => 
	LIST 'Services_Set2' => 
	SCALAR 'DcmRespondAllRequest' => 


=head2 PARAMETER EXAMPLES

	purpose = 'To verify that NRC 11 or no response is received for not supported services'
	Session = @('Default', 'Extended', 'Safety')
	Protocol_AddressingMode = '<Test Heading>'
	Services_Set1 = @('40', '60', '7F', 'C0', 'E0', 'FF')
	Services_Set2 = @('00', '01', '09', '13', '25', '3F', '80', 'A0', 'BF')
	DcmRespondAllRequest = 'yes' #or 'no' (see HLD Notes)
	Response_Set1 = 'NR_serviceNotSupported' 
	Response_Set2 = 'NR_serviceNotSupported'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my @tcpar_Session;
my $tcpar_Protocol_AddressingMode;
my @tcpar_Services_Set1;
my @tcpar_Services_Set2;
my $tcpar_DcmRespondAllRequest;
my $tcpar_Response_Set1;
my $tcpar_Response_Set2;

################ global parameter declaration ###################
#add any global variables here

###############################################################

sub TC_set_parameters {

    $tcpar_purpose                 = GEN_Read_mandatory_testcase_parameter('purpose');
    @tcpar_Session                 = GEN_Read_mandatory_testcase_parameter('Session');
    $tcpar_Protocol_AddressingMode = GEN_Read_mandatory_testcase_parameter('Protocol_AddressingMode');
    @tcpar_Services_Set1           = GEN_Read_mandatory_testcase_parameter('Services_Set1');
    @tcpar_Services_Set2           = GEN_Read_mandatory_testcase_parameter('Services_Set2');
    $tcpar_DcmRespondAllRequest    = GEN_Read_mandatory_testcase_parameter('DcmRespondAllRequest');
    $tcpar_Response_Set1           = GEN_Read_mandatory_testcase_parameter('Response_Set1');
    $tcpar_Response_Set2           = GEN_Read_mandatory_testcase_parameter('Response_Set2');

    return 1;
}

sub TC_initialization {

    S_teststep( "\nStandardPrepNoFault\n", 'NO_AUTO_NBR' );
    GEN_StandardPrepNoFault();
    GDCOM_set_addressing_mode('physical');
    
    GDCOM_start_CyclicTesterPresent();
    S_wait_ms(500);

    return 1;
}

sub TC_stimulation_and_measurement {

    foreach my $session (@tcpar_Session) {
    	if ($session =~ m/safety|disposal/i){
    		S_w2rep ("$session not handled");
    		next;
    	}
    if (lc($tcpar_Protocol_AddressingMode) =~ m/disposal/i){
    		S_w2rep ("$tcpar_Protocol_AddressingMode not handled");
    		next;
   	}
    	
        S_w2rep ("************* Session: $session *************", 'orange');
        S_teststep( "Enter session: $session", 'AUTO_NBR' ); 
        DIAG_StartSession($session);      
        S_wait_ms (5000, 'wait after session entry') if($session =~ m/prog|boot/i);
        
        S_teststep( "Set addressing mode '$tcpar_Protocol_AddressingMode'", 'AUTO_NBR' );
        GDCOM_set_addressing_mode(lc($tcpar_Protocol_AddressingMode));


        S_teststep( "Send services @tcpar_Services_Set1", 'AUTO_NBR', "send_services_set1_$session" );    #measurement 1
        S_teststep_expected( "-", "send_services_set1_$session" ); #for TR
        S_teststep_detected( "-", "send_services_set1_$session" ); #for TR

        foreach my $request (@tcpar_Services_Set1) {
            S_teststep_2nd_level( "Send request $request", 'AUTO_NBR', $request.$session );
            my $response;
            if ( $tcpar_DcmRespondAllRequest eq 'yes' and $tcpar_Response_Set1 ne 'NoResponse' ) {
                $response = GDCOM_request( $request, "7F $request 11", 'strict' );

                S_teststep_expected( "7F $request 11", $request.$session );                        #evaluation 1
                S_teststep_detected( $response, $request.$session );
            }
            else { #no response
                $response = GDCOM_request( $request, "", 'quiet' );

                S_teststep_expected( "no response", $request.$session );                           #evaluation 1
                S_teststep_detected( "-". $response, $request.$session );
            }
        }

        S_teststep( "Send services @tcpar_Services_Set2", 'AUTO_NBR', "send_services_set2_$session" );    #measurement 2
        S_teststep_expected( "-", "send_services_set2_$session" );
        S_teststep_detected( "-", "send_services_set2_$session" );

        foreach my $request (@tcpar_Services_Set2) {
            S_teststep_2nd_level( "Send request $request", 'AUTO_NBR', $request.$session );
            my $response;
            if ( $tcpar_Response_Set2 ne 'NoResponse' ) {
                $response = GDCOM_request( $request, "7F $request 11", 'strict' );

                S_teststep_expected( "7F $request 11", $request.$session );                        #evaluation 1
                S_teststep_detected( $response, $request.$session );
            }
            else { #no response
                $response = GDCOM_request( $request, "", 'quiet' );

                S_teststep_expected( "no response", $request.$session );                           #evaluation 1
                S_teststep_detected( "-". $response, $request.$session );
            }
        }
        
        S_teststep( "\n", 'NO_AUTO_NBR' ); #newline for steps in TR

    }

    return 1;
}

sub TC_evaluation {

    S_w2rep("Evaluation is done above in stimulation_and_measurement");

    return 1;
}

sub TC_finalization {
	
    GDCOM_set_addressing_mode('physical');
    GDCOM_stop_CyclicTesterPresent();
    S_wait_ms(500);

    return 1;
}

1;
