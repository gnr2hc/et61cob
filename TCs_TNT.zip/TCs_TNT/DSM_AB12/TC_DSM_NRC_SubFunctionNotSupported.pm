#### TEST CASE MODULE
package TC_DSM_NRC_SubFunctionNotSupported;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.4 $;
our $HEADER  = q$Header: DSM_AB12/TC_DSM_NRC_SubFunctionNotSupported.pm 1.4 2018/04/24 17:59:36ICT ver6cob develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_NegativeResponseCodes
#TS version in DOORS: 0.1
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use GENERIC_DCOM;
use LIFT_PD;
##################################

our $PURPOSE = "To check for NRC 12 in case of not supported sub functions";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_NRC_SubFunctionNotSupported

=head1 PURPOSE

To check for NRC 12 in case of not supported sub functions

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Enter session supported by <Service>

2. Send <Service> with random subfunction other than a valid sub function in physical addressing mode

3. Send <Service> with random subfunction other than a valid sub function in functional addressing mode

4. Repeat for all sessions supported by the service


I<B<Evaluation>>

1. -

2. <Response> is received

3. No response is received

4. Same as above steps


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Purpose' => 
	SCALAR 'Service' => 
	SCALAR 'Response' => 


=head2 PARAMETER EXAMPLES

	Purpose = 'To check for NRC 12 in case of not supported sub functions'
	Service = '<Test Heading 2>'
	Response = 'NR_subFunctionNotSupported'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_Service;
my $tcpar_Response;
my $tcpar_FuncReqSupported;
my (%tcpar_CommunicationType, %tcpar_Key, %tcpar_Data, %tcpar_IOControlState, %tcpar_RoutineControlOption);

################ global parameter declaration ###################
#add any global variables here
my %DataValue;

###############################################################

sub TC_set_parameters {

    $tcpar_Purpose  = GEN_Read_mandatory_testcase_parameter('Purpose');
    $tcpar_Service  = GEN_Read_mandatory_testcase_parameter('Service');
    $tcpar_Response = GEN_Read_mandatory_testcase_parameter('Response');
	$tcpar_FuncReqSupported = S_read_optional_testcase_parameter('FuncReqSupported', undef, 'no');

    #handle required bytes in request
    $DataValue{'StatusMask'}               = GEN_Read_optional_testcase_parameter('StatusMask');
    $DataValue{'DTC'}                         = GEN_Read_optional_testcase_parameter('DTC');
    $DataValue{'DTCSnapshotRecordNumber'}     = GEN_Read_optional_testcase_parameter('DTCSnapshotRecordNumber');
    $DataValue{'DTCExtendedDataRecordNumber'} = GEN_Read_optional_testcase_parameter('DTCExtendedDataRecordNumber');

    %tcpar_CommunicationType           = GEN_Read_optional_testcase_parameter('CommunicationType');
    %tcpar_Key                         = GEN_Read_optional_testcase_parameter('Key');
    %tcpar_Data                        = GEN_Read_optional_testcase_parameter('Data');
    %tcpar_IOControlState              = GEN_Read_optional_testcase_parameter('IOControlState');
    %tcpar_RoutineControlOption        = GEN_Read_optional_testcase_parameter('RoutineControlOption');

    return 1;
}

sub TC_initialization {

    S_teststep( "\nStandardPrepNoFault\n", 'NO_AUTO_NBR' );
#    GEN_StandardPrepNoFault();
	DIAG_ECUReset_NOVERDICT ();
	S_wait_ms ('TIMER_ECU_READY', 'wait after reset');
	PD_ReadFaultMemory_NOERROR();
	
    GDCOM_start_CyclicTesterPresent();
    GDCOM_set_addressing_mode('physical');
	S_wait_ms (100);

    return 1;
}

sub TC_stimulation_and_measurement {

    my ( @validSubFuncs, @InvalidSet );
    
    my $SID = $tcpar_Service;
    $tcpar_Service = _getServiceLabel($tcpar_Service);
    my $SubFuncInfo = GDCOM_getSupportedSubFunsfromMapping($tcpar_Service);

    #Get all supported valid sub functions for the service under test
    foreach my $SubFuncKey ( keys %$SubFuncInfo ) {
        push( @validSubFuncs, $SubFuncInfo->{$SubFuncKey} );
        _fillRequestInputParameters ($SID, S_get_contents_of_hash( [ 'Mapping_DIAG', 'DIAG_SERVICES', $tcpar_Service,'Supported_SubFuns', $SubFuncKey]));
    }

    #Get all invalid sub functions from supported valid sub functions
    @InvalidSet = _generateInvalidSubFuncs( \@validSubFuncs );

    S_teststep("Valid set sub funcs: @validSubFuncs",  'NO_AUTO_NBR');
    S_teststep("Invalid set sub funcs: @InvalidSet\n",  'NO_AUTO_NBR');

    my $NRCInfo = GDCOM_getNRCfromMapping( $tcpar_Service, $tcpar_Response );

    my ($requestInfo, $requestLabel);

    foreach my $request ( keys( %{ S_get_contents_of_hash( [ 'Mapping_DIAG', 'Requests_Responses' ] ) } ) ) {
        #trace through Diag mapping file check for all the requests for service under test.
        if ( $request =~ /\Q$tcpar_Service\E_/ ) {
            $requestInfo = GDCOM_getRequestInfofromMapping($request);
            next if ( $requestInfo->{'protocol'} ne 'UDS' );
            $requestLabel = $request;
            last;
        }
    }

    foreach my $session ( @{ $requestInfo->{'allowed_in_sessions'} } ) {
    	next if ($session =~ m/safety|disposal/i);
    	
        S_w2rep ("************* Session: $session *************", 'orange');
        
        S_teststep( "Enter session: $session", 'AUTO_NBR' );
        DIAG_StartSession($session);
        S_wait_ms (4000, 'wait after session entry') if($session =~ m/prog|boot/i);

        #DIAG_request_DependentServices($request);

        my $actual_ReqString = GDCOM_getRequestLabelValue("REQ_" .$requestLabel,\%DataValue); #$requestInfo->{'Requests'}{ "REQ_" . $requestLabel }{'Request'};     
        my @actual_ReqArray = split( / /, $actual_ReqString );

        S_teststep( "Send '$tcpar_Service' with random subfunction other than a valid sub function in physical addressing mode", 'AUTO_NBR', $tcpar_Service . $session . "_phys" );
        GDCOM_set_addressing_mode('physical');

        foreach (@InvalidSet) {
            $actual_ReqArray[1] = $_;
            my $modified_Request = join( ' ', @actual_ReqArray );
            S_teststep_2nd_level( "Request: $modified_Request", 'AUTO_NBR', $tcpar_Service . $session . $modified_Request . "_phys" );
            my $response = GDCOM_request( $modified_Request, $NRCInfo->{'Response'}, 'strict' );

            S_teststep_expected( $NRCInfo->{'Response'}, $tcpar_Service . $session . $modified_Request . "_phys" );
            S_teststep_detected( $response, $tcpar_Service . $session . $modified_Request . "_phys" );
        }

        if($tcpar_FuncReqSupported =~ m/yes/i){
			S_teststep( "Send '$tcpar_Service' with random subfunction other than a valid sub function in functional addressing mode", 'AUTO_NBR', $tcpar_Service . $session . "_func" );
			GDCOM_set_addressing_mode('functional');

			foreach (@InvalidSet) {
				$actual_ReqArray[1] = $_;
				my $modified_Request = join( ' ', @actual_ReqArray );
				S_teststep_2nd_level( "Request: $modified_Request", 'AUTO_NBR', $tcpar_Service . $session . $modified_Request . "_func" );
				my $response = GDCOM_request( $modified_Request, $NRCInfo->{'Response'}, 'quiet' );

				S_teststep_expected( "no response", $tcpar_Service . $session . $modified_Request . "_func" );
				S_teststep_detected( "-". $response, $tcpar_Service . $session . $modified_Request . "_func" );
			}
		}
        
        S_teststep( "\n", 'NO_AUTO_NBR' ); #newline for steps in TR
    }

    #	S_teststep("Repeat for all sessions supported by the service", 'AUTO_NBR', 'repeat_for_all');			#measurement 3

    return 1;
}

sub TC_evaluation {

    S_w2rep("Evaluation is done above in stimulation_and_measurement");

    return 1;
}

sub TC_finalization {

    GDCOM_stop_CyclicTesterPresent();

    return 1;
}

sub _getServiceLabel {
    my $SID = shift;

    my $services = S_get_contents_of_hash( [ 'Mapping_DIAG', 'PRJ_SUPPORTED_SERVICES' ] );

    foreach my $serv ( keys %$services ) {
        return $serv if ( $services->{$serv} eq $SID );
    }
}

sub _getSupportedSessions {
    my $reqLabel = shift;

    return GDCOM_getRequestInfofromMapping ($reqLabel)->{'allowed_in_sessions'};
}

sub _generateInvalidSubFuncs {
    my $validSubFuncs = shift;

    while($validSubFuncs){
        my $rand = int rand(255);
        unless(grep { hex($_) == $rand } @$validSubFuncs){
            return (sprintf("%02X",$rand));   
        } 
    }   
}

sub _fillRequestInputParameters {
    my $SID = shift;
    my $subFunc = shift;
    

    if($SID eq '27'){
        $DataValue{'Key'} = $tcpar_Key{$subFunc};
    }
    elsif($SID eq '28'){
        $DataValue{'CommunicationType'} = $tcpar_CommunicationType{$subFunc};
    }
    elsif($SID eq '2E'){
        $DataValue{'Data'} = $tcpar_Data{$subFunc};
    }
    elsif($SID eq '2F'){
        $DataValue{'IOControlState'} = $tcpar_IOControlState{$subFunc};
    }
    elsif($SID eq '2F'){
        $DataValue{'IOControlState'} = $tcpar_IOControlState{$subFunc};
    }
    elsif($SID eq '31'){
        $DataValue{'RoutineControlOption'} = $tcpar_RoutineControlOption{$subFunc};
    }

}

1;
