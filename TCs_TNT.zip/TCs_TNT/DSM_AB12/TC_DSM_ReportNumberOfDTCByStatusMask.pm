#### TEST CASE MODULE
package TC_DSM_ReportNumberOfDTCByStatusMask;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.3 $;
our $HEADER  = q$Header: DSM_AB12/TC_DSM_ReportNumberOfDTCByStatusMask.pm 1.3 2017/11/09 19:16:29ICT ver6cob develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_ReadDTCInformation
#TS version in DOORS: 4.9
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use GENERIC_DCOM;
use LIFT_CD;
use LIFT_evaluation;
##################################

our $PURPOSE = "to check that service 19 01 reports the correct number of DTCs that match a particular status mask";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_ReportNumberOfDTCByStatusMask

=head1 PURPOSE

to check that service 19 01 reports the correct number of DTCs that match a particular status mask

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault

Set <AddressingMode>, Enter <Session>


I<B<Stimulation and Measurement>>

1. Create <Faults_Qualify> and wait for qualification time

2. Send <RdNbrOfDTCByStatusMask> with <StatusMask>

3. Remove <Faults_Dequalify> and wait for dequalification time

4. Send <RdNbrOfDTCByStatusMask> with <StatusMask>

5. Reset ECU twice

6. Send <RdNbrOfDTCByStatusMask> with <StatusMask>

7. Clear fault memory and wait for qualification time

8. Send <RdNbrOfDTCByStatusMask> with <StatusMask>

9. Remove all remaining faults created in step 1 (if not removed in step 3)


I<B<Evaluation>>

2. Positive response with <DTCStatusAvailabilityMask>, <DTCFormatIdentifier> and <NbrOfDTCs_AfterQualify>

4. Positive response with <DTCStatusAvailabilityMask>, <DTCFormatIdentifier> and <NbrOfDTCs_AfterDequalify>

6. Positive response with <DTCStatusAvailabilityMask>, <DTCFormatIdentifier> and <NbrOfDTCs_AfterReset>

8. Positive response with <DTCStatusAvailabilityMask>, <DTCFormatIdentifier> and <NbrOfDTCs_AfterClear>

In any of the above steps, if 'NbrOfDTCs_AfterXYZ' parameter is 0, the response format is positive response bytes followed <DTCStatusAvailabilityMask>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	LIST 'Faults_Qualify' => 
	LIST 'Faults_Dequalify' => 
	SCALAR 'NbrOfDTCs_AfterQualify' => 
	SCALAR 'NbrOfDTCs_AfterDequalify' => 
	SCALAR 'NbrOfDTCs_AfterReset' => 
	SCALAR 'NbrOfDTCs_AfterClear' => 
	SCALAR 'purpose' => 
	SCALAR 'AddressingMode' => 
	SCALAR 'Session' => 
	SCALAR 'RdNbrOfDTCByStatusMask' => 
	SCALAR 'StatusMask' => 
	SCALAR 'DTCStatusAvailabilityMask' => 
	SCALAR 'DTCFormatIdentifier' => 


=head2 PARAMETER EXAMPLES

	purpose = 'to check that service 19 01 reports the correct number of DTCs that match a particular status mask' 
	# input parameters
	AddressingMode = 'physical'
	Session = 'DefaultSession'
	RdNbrOfDTCByStatusMask = 'ReadDTCInformation_ReportNumberOfDtcByStatusMask'
	StatusMask = '<Test Heading 2>'
	#output parameters
	DTCStatusAvailabilityMask = '39'
	DTCFormatIdentifier = '01'
	#any 5 cyclic faults
	Faults_Qualify = @('rb_sqm_SquibResistanceOpenAB1FD_flt', 'rb_sqm_SquibResistanceOpenAB1FP_flt', 'rb_sqm_SquibResistanceOpenSA1FL_flt', 'rb_sqm_SquibResistanceOpenSA1FR_flt', 'rb_sqm_SquibResistanceOpenBT1FD_flt')
	Faults_Dequalify = @('rb_sqm_SquibResistanceOpenAB1FD_flt', 'rb_sqm_SquibResistanceOpenAB1FP_flt')
	NbrOfDTCs_AfterQualify = 5 #5 active
	NbrOfDTCs_AfterDequalify = 3 #3 active, 2 latched
	NbrOfDTCs_AfterReset = 3, #3 active, 2 stored
	NbrOfDTCs_AfterClear = 3, #3 active

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_AddressingMode;
my $tcpar_Session;
my $tcpar_RdNbrOfDTCByStatusMask;
my $tcpar_StatusMask;
my $tcpar_DTCStatusAvailabilityMask;
my $tcpar_DTCFormatIdentifier;
my @tcpar_Faults_Qualify;
my @tcpar_Faults_Dequalify;
my $tcpar_NbrOfDTCs_AfterQualify;
my $tcpar_NbrOfDTCs_AfterDequalify;
my $tcpar_NbrOfDTCs_AfterReset;
my $tcpar_NbrOfDTCs_AfterClear;

################ global parameter declaration ###################
#add any global variables here

###############################################################

sub TC_set_parameters {

    $tcpar_purpose                   = GEN_Read_mandatory_testcase_parameter('purpose');
    $tcpar_AddressingMode            = GEN_Read_mandatory_testcase_parameter('AddressingMode');
    $tcpar_Session                   = GEN_Read_mandatory_testcase_parameter('Session');
    $tcpar_RdNbrOfDTCByStatusMask    = GEN_Read_mandatory_testcase_parameter('RdNbrOfDTCByStatusMask');
    $tcpar_StatusMask                = GEN_Read_mandatory_testcase_parameter('StatusMask');
    $tcpar_DTCStatusAvailabilityMask = GEN_Read_mandatory_testcase_parameter('DTCStatusAvailabilityMask');
    $tcpar_DTCFormatIdentifier       = GEN_Read_mandatory_testcase_parameter('DTCFormatIdentifier');
    @tcpar_Faults_Qualify            = GEN_Read_mandatory_testcase_parameter('Faults_Qualify');
    @tcpar_Faults_Dequalify          = GEN_Read_mandatory_testcase_parameter('Faults_Dequalify');
    $tcpar_NbrOfDTCs_AfterQualify    = GEN_Read_mandatory_testcase_parameter('NbrOfDTCs_AfterQualify');
    $tcpar_NbrOfDTCs_AfterDequalify  = GEN_Read_mandatory_testcase_parameter('NbrOfDTCs_AfterDequalify');
    $tcpar_NbrOfDTCs_AfterReset      = GEN_Read_mandatory_testcase_parameter('NbrOfDTCs_AfterReset');
    $tcpar_NbrOfDTCs_AfterClear      = GEN_Read_mandatory_testcase_parameter('NbrOfDTCs_AfterClear');

    return 1;
}

sub TC_initialization {

    S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
    GEN_StandardPrepNoFault();
    GDCOM_start_CyclicTesterPresent();

    S_teststep( "Set addressing mode: '$tcpar_AddressingMode', Enter session: '$tcpar_Session'", 'AUTO_NBR' );
    GDCOM_set_addressing_mode($tcpar_AddressingMode);
    DIAG_StartSession($tcpar_Session);

    return 1;
}

sub TC_stimulation_and_measurement {

    S_teststep( "Create 'Faults_Qualify' and wait for qualification time", 'AUTO_NBR' );
    foreach (@tcpar_Faults_Qualify) {
        FM_createFault($_);
    }
    S_wait_ms( 10000, 'wait for qualification time' );

    S_teststep( "Send '$tcpar_RdNbrOfDTCByStatusMask' with StatusMask '$tcpar_StatusMask'", 'AUTO_NBR', 'send_rdnbrofdtcbystatusmask_with_A' );    #measurement 1
    my $requestBytes = GDCOM_getRequestLabelValue( "REQ_" . $tcpar_RdNbrOfDTCByStatusMask, { 'StatusMask' => $tcpar_StatusMask } );

    # if ( $tcpar_NbrOfDTCs_AfterQualify eq '00' ) {
        # my $response_afterqualify = GDCOM_request( $requestBytes, "59 01 $tcpar_DTCStatusAvailabilityMask", 'strict' );

        # S_teststep_expected( "Response = 59 01 $tcpar_DTCStatusAvailabilityMask", 'send_rdnbrofdtcbystatusmask_with_A' );               #evaluation 1
        # S_teststep_detected( "Response = $response_afterqualify", 'send_rdnbrofdtcbystatusmask_with_A' );
    # }
    # else {
        my $response_afterqualify = GDCOM_request_general( "REQ_" . $tcpar_RdNbrOfDTCByStatusMask, "PR_" . $tcpar_RdNbrOfDTCByStatusMask, { 'StatusMask' => $tcpar_StatusMask } );

        S_teststep_expected( "Positive response: 59 01 $tcpar_DTCStatusAvailabilityMask $tcpar_DTCFormatIdentifier 00 $tcpar_NbrOfDTCs_AfterQualify", 'send_rdnbrofdtcbystatusmask_with_A' );    #evaluation 1
        S_teststep_detected( "Response = $response_afterqualify", 'send_rdnbrofdtcbystatusmask_with_A' );
        GDCOM_evaluate_response_bytes( "DTCStatusAvailabilityMask_AfterQualify", $response_afterqualify, 2, $tcpar_DTCStatusAvailabilityMask );
        GDCOM_evaluate_response_bytes( "DTCFormatIdentifier_AfterQualify",       $response_afterqualify, 3, $tcpar_DTCFormatIdentifier );
        GDCOM_evaluate_response_bytes( "NbrOfDTCs_AfterQualify",                 $response_afterqualify, 4, "00 $tcpar_NbrOfDTCs_AfterQualify" );
    # }


    S_teststep( "Remove 'Faults_Dequalify' and wait for dequalification time", 'AUTO_NBR' );
    foreach (@tcpar_Faults_Dequalify) {
        FM_removeFault($_);
    }
    S_wait_ms( 10000, 'wait for dequalification time' );

    S_teststep( "Send '$tcpar_RdNbrOfDTCByStatusMask' with StatusMask '$tcpar_StatusMask'", 'AUTO_NBR', 'send_rdnbrofdtcbystatusmask_with_B' );    #measurement 2
    # if ( $tcpar_NbrOfDTCs_AfterDequalify eq '00' ) {
        # my $response_afterdequalify = GDCOM_request( $requestBytes, "59 01 $tcpar_DTCStatusAvailabilityMask", 'strict' );

        # S_teststep_expected( "Response = 59 01 $tcpar_DTCStatusAvailabilityMask", 'send_rdnbrofdtcbystatusmask_with_B' );               #evaluation 1
        # S_teststep_detected( "Response = $response_afterdequalify", 'send_rdnbrofdtcbystatusmask_with_B' );
    # }
    # else {
        my $response_afterdequalify = GDCOM_request_general( "REQ_" . $tcpar_RdNbrOfDTCByStatusMask, "PR_" . $tcpar_RdNbrOfDTCByStatusMask, { 'StatusMask' => $tcpar_StatusMask } );

        S_teststep_expected( "Positive response: 59 01 $tcpar_DTCStatusAvailabilityMask $tcpar_DTCFormatIdentifier 00 $tcpar_NbrOfDTCs_AfterDequalify", 'send_rdnbrofdtcbystatusmask_with_B' );    #evaluation 2
        S_teststep_detected( "Response = $response_afterdequalify", 'send_rdnbrofdtcbystatusmask_with_B' );
        GDCOM_evaluate_response_bytes( "DTCStatusAvailabilityMask_AfterDequalify", $response_afterdequalify, 2, $tcpar_DTCStatusAvailabilityMask );
        GDCOM_evaluate_response_bytes( "DTCFormatIdentifier_AfterDequalify",       $response_afterdequalify, 3, $tcpar_DTCFormatIdentifier );
        GDCOM_evaluate_response_bytes( "NbrOfDTCs_AfterDequalify",                 $response_afterdequalify, 4, "00 $tcpar_NbrOfDTCs_AfterDequalify" );
    # }


    S_teststep( "Reset ECU twice", 'AUTO_NBR' );
    GEN_Power_on_Reset();
    GEN_Power_on_Reset();

    S_teststep( "Send '$tcpar_RdNbrOfDTCByStatusMask' with StatusMask '$tcpar_StatusMask'", 'AUTO_NBR', 'send_rdnbrofdtcbystatusmask_with_C' );                                                               #measurement 3
    # if ( $tcpar_NbrOfDTCs_AfterReset eq '00' ) {
        # my $response_afterreset = GDCOM_request( $requestBytes, "59 01 $tcpar_DTCStatusAvailabilityMask", 'strict' );

        # S_teststep_expected( "Response = 59 01 $tcpar_DTCStatusAvailabilityMask", 'send_rdnbrofdtcbystatusmask_with_C' );                                                                          #evaluation 1
        # S_teststep_detected( "Response = $response_afterreset", 'send_rdnbrofdtcbystatusmask_with_C' );
    # }
    # else {
        my $response_afterreset = GDCOM_request_general( "REQ_" . $tcpar_RdNbrOfDTCByStatusMask, "PR_" . $tcpar_RdNbrOfDTCByStatusMask, { 'StatusMask' => $tcpar_StatusMask } );

        S_teststep_expected( "Positive response: 59 01 $tcpar_DTCStatusAvailabilityMask $tcpar_DTCFormatIdentifier 00 $tcpar_NbrOfDTCs_AfterReset", 'send_rdnbrofdtcbystatusmask_with_C' );        #evaluation 3
        S_teststep_detected( "Response = $response_afterreset", 'send_rdnbrofdtcbystatusmask_with_C' );
        GDCOM_evaluate_response_bytes( "DTCStatusAvailabilityMask_AfterReset", $response_afterreset, 2, $tcpar_DTCStatusAvailabilityMask );
        GDCOM_evaluate_response_bytes( "DTCFormatIdentifier_AfterReset",       $response_afterreset, 3, $tcpar_DTCFormatIdentifier );
        GDCOM_evaluate_response_bytes( "NbrOfDTCs_AfterReset",                 $response_afterreset, 4, "00 $tcpar_NbrOfDTCs_AfterReset" );
    # }


    S_teststep( "Clear fault memory and wait for qualification time", 'AUTO_NBR' );
    CD_clear_DTC();
    S_wait_ms( 10000, 'wait for qualification time' );

    S_teststep( "Send '$tcpar_RdNbrOfDTCByStatusMask' with StatusMask '$tcpar_StatusMask'", 'AUTO_NBR', 'send_rdnbrofdtcbystatusmask_with_D' );    #measurement 4
    # if ( $tcpar_NbrOfDTCs_AfterClear eq '00' ) {
        # my $response_afterclear = GDCOM_request( $requestBytes, "59 01 $tcpar_DTCStatusAvailabilityMask", 'strict' );

        # S_teststep_expected( "Response = 59 01 $tcpar_DTCStatusAvailabilityMask", 'send_rdnbrofdtcbystatusmask_with_D' );               #evaluation 1
        # S_teststep_detected( "Response = $response_afterclear", 'send_rdnbrofdtcbystatusmask_with_D' );
    # }
    if ( $tcpar_NbrOfDTCs_AfterClear eq 'X' ) {                                                                                      #can be any number of untested DTCs/init faults
        my $response_afterclear = GDCOM_request_general( "REQ_" . $tcpar_RdNbrOfDTCByStatusMask, "PR_" . $tcpar_RdNbrOfDTCByStatusMask, { 'StatusMask' => $tcpar_StatusMask } );

        S_teststep_expected( "Response = 59 01 $tcpar_DTCStatusAvailabilityMask $tcpar_DTCFormatIdentifier XY", 'send_rdnbrofdtcbystatusmask_with_D' );    #evaluation 1
        S_teststep_detected( "Response = $response_afterclear", 'send_rdnbrofdtcbystatusmask_with_D' );
        GDCOM_evaluate_response_bytes( "DTCStatusAvailabilityMask_AfterClear", $response_afterclear, 2, $tcpar_DTCStatusAvailabilityMask );
        GDCOM_evaluate_response_bytes( "DTCFormatIdentifier_AfterClear",       $response_afterclear, 3, $tcpar_DTCFormatIdentifier );

        #check that NbrOfDTCs_AfterClear is non-zero
        $response_afterclear = '59 01 39 01 00 30' if $main::opt_offline; #dummy for offline mode handling
        my @response_bytes = split( / /, $response_afterclear );
        my $NbrOfDTCs_AfterClear = S_aref2dec( [ '0x' . $response_bytes[4], '0x' . $response_bytes[5] ], 'U16' );
        EVAL_evaluate_value( "NbrOfDTCs_AfterClear", $NbrOfDTCs_AfterClear, '>', 0 );
    }
    else {
        my $response_afterclear = GDCOM_request_general( "REQ_" . $tcpar_RdNbrOfDTCByStatusMask, "PR_" . $tcpar_RdNbrOfDTCByStatusMask, { 'StatusMask' => $tcpar_StatusMask } );

        S_teststep_expected( "Positive response: 59 01 $tcpar_DTCStatusAvailabilityMask $tcpar_DTCFormatIdentifier 00 $tcpar_NbrOfDTCs_AfterClear", 'send_rdnbrofdtcbystatusmask_with_D' );    #evaluation 4
        S_teststep_detected( "Response = $response_afterclear", 'send_rdnbrofdtcbystatusmask_with_D' );
        GDCOM_evaluate_response_bytes( "DTCStatusAvailabilityMask_AfterClear", $response_afterclear, 2, $tcpar_DTCStatusAvailabilityMask );
        GDCOM_evaluate_response_bytes( "DTCFormatIdentifier_AfterClear",       $response_afterclear, 3, $tcpar_DTCFormatIdentifier );
        GDCOM_evaluate_response_bytes( "NbrOfDTCs_AfterClear",                 $response_afterclear, 4, "00 $tcpar_NbrOfDTCs_AfterClear" );
    }


    S_teststep( "Remove all remaining faults created in step 1 (if not removed in step 3)", 'AUTO_NBR' );
    foreach my $fault (@tcpar_Faults_Qualify) {
        next if ( grep { $_ eq $fault } @tcpar_Faults_Dequalify );
        FM_removeFault($fault);
    }
    S_wait_ms( 10000, 'wait for dequalification time' );

    return 1;
}

sub TC_evaluation {

    S_w2rep("Evaluation is done above in stimulation_and_measurement");

    return 1;
}

sub TC_finalization {

    GDCOM_stop_CyclicTesterPresent();
    GDCOM_set_addressing_mode('physical');

    return 1;
}

1;
