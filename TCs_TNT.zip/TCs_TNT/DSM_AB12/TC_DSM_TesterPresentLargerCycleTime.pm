#### TEST CASE MODULE
package TC_DSM_TesterPresentLargerCycleTime;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.7 $;
our $HEADER  = q$Header: DSM_AB12/TC_DSM_TesterPresentLargerCycleTime.pm 1.7 2018/04/23 14:43:24ICT Nguyen Van Truc (RBVH/EPS24) (GNR2HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_TesterPresent3E
#TS version in DOORS: 0.7
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use GENERIC_DCOM;
use LIFT_labcar;
##################################

our $PURPOSE = "To verify that the server changes to default session when Tester Present message is being received with more than the session expiry time cyclically";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_TesterPresentLargerCycleTime

=head1 PURPOSE

To verify that the server changes to default session when Tester Present message is being received with more than the session expiry time cyclically

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Set Addressing_Mode as per Project specific SPR.

2. Send Tester Present cyclically with <CycleTime>.

3. Send request to enter <Session>.

4. Wait for <WaitTime> in msec.

5. Send request <Read_ActiveSession>.


I<B<Evaluation>>

1. 

2. 

3. Positive response shall be obtained.

4. 

5. Current session shall be <ActiveSession>.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Session' => 
	SCALAR 'ActiveSession' => 
	SCALAR 'purpose' => 
	SCALAR 'CycleTime' => 
	SCALAR 'WaitTime' => 
	SCALAR 'Read_ActiveSession' => 


=head2 PARAMETER EXAMPLES

	purpose = 'To verify that the server shall keep any session alive till the tester present message is being received within session expiry time'
	
	# input parameters 
	CycleTime = 6000 #in msec
	WaitTime = <Test Heading Tail> #in msec
	Read_ActiveSession = 'ReadDataByIdentifier_F186' # 22 F186
	PR_ActiveSession_ByteNbr= '03'#this is the byte number for active session in the read active session positive response, count from '0'.

	# output parameters 
	Session = 'DiagnosticSessionControl_ExtendedSession'
	ActiveSession = '03'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_CycleTime;
my $tcpar_WaitTime;
my $tcpar_Read_ActiveSession;
my $tcpar_Session;
my $tcpar_ActiveSession;
my $tcpar_Request_TesterPresent;
my $tcpar_PR_ActiveSession_ByteNbr;

################ global parameter declaration ###################
#add any global variables here
my $Addressing_Mode;
my $mode;
my $msg_aref = [ 0x02, 0x3E, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00 ];
my $msg_ID_phy;
my $msg_ID_func;
my $TP_handle;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose                  = GEN_Read_mandatory_testcase_parameter('purpose');
	$tcpar_CycleTime                = GEN_Read_mandatory_testcase_parameter('CycleTime');
	$tcpar_WaitTime                 = GEN_Read_mandatory_testcase_parameter('WaitTime');
	$tcpar_Read_ActiveSession       = GEN_Read_mandatory_testcase_parameter('Read_ActiveSession');
	$tcpar_Session                  = GEN_Read_mandatory_testcase_parameter('Session');
	$tcpar_ActiveSession            = GEN_Read_mandatory_testcase_parameter('ActiveSession');
	$tcpar_Request_TesterPresent    = GEN_Read_mandatory_testcase_parameter('Request_TesterPresent');
	$tcpar_PR_ActiveSession_ByteNbr = GEN_Read_mandatory_testcase_parameter('PR_ActiveSession_ByteNbr');

	return 1;
}

sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'NO_AUTO_NBR' );
	GEN_StandardPrepNoFault();
	$msg_ID_func = $LIFT_PROJECT::Defaults->{"CUSTOMER_DIAGNOSIS"}{'RequestID_functional'};
	$msg_ID_phy  = $LIFT_PROJECT::Defaults->{"CUSTOMER_DIAGNOSIS"}{'RequestID_physical'};
	return 1;
}

sub TC_stimulation_and_measurement {

	$Addressing_Mode = GDCOM_getRequestInfofromMapping($tcpar_Request_TesterPresent)->{'allowed_in_addressingmodes'};
	S_teststep( "Supported Addressing_Mode as per Project specific SPR. @$Addressing_Mode", 'NO_AUTO_NBR' );

	foreach $mode (@$Addressing_Mode) {

		S_teststep( "Set Addressing_Mode as per Project specific SPR.", 'AUTO_NBR' );
		GDCOM_set_addressing_mode($mode);

		S_teststep( "Send Tester Present cyclically with '$tcpar_CycleTime'.", 'AUTO_NBR' );
		if ( $mode eq 'functional' ) {
			$TP_handle = GDCOM_start_CyclicTesterPresent( $msg_aref, $msg_ID_func, $tcpar_CycleTime );
		}
		elsif ( $mode eq 'physical' ) {
			$TP_handle = GDCOM_start_CyclicTesterPresent( $msg_aref, $msg_ID_phy, $tcpar_CycleTime );
		}
		S_wait_ms(100);    #Wait for 100 msec before sending next request

		S_teststep( "Send request to enter '$tcpar_Session'.", 'AUTO_NBR', "Enter_session_in_$mode" );    #measurement 1
		my $session_Response = GDCOM_request_general( "REQ_" . $tcpar_Session, "PR_" . $tcpar_Session );
		S_teststep_expected( "Positive shall be obtained.", "Enter_session_in_$mode" );
		S_teststep_detected( "Obtained Response is $session_Response", "Enter_session_in_$mode" );

		S_teststep( "Wait for '$tcpar_WaitTime' in msec.", 'AUTO_NBR' );
		S_wait_ms($tcpar_WaitTime);

		if ( $tcpar_WaitTime > 5000 ) {
			if ( $tcpar_Session =~ /ProgrammingSession/ ) {

				#ECU reset is expected when server is comign out of Programming session. Hence additional delay given to read active session
				S_teststep( "ECU reset is expected when server is comign out of Programming session, hence additional delay of 500 msec is given before reading active session", 'NO_AUTO_NBR' );
				S_wait_ms(500);
			}
		}

		S_teststep( "Send request '$tcpar_Read_ActiveSession'.", 'AUTO_NBR', "Read_active_session_in_$mode" );    #measurement 2
		my $actses_resbef     = ReadActiveSession();
		my @activesession_res = split( / /, $actses_resbef );                                                     # Split all the response bytes of Step1 to array
		_evaluateActiveSession( $tcpar_ActiveSession, $activesession_res[$tcpar_PR_ActiveSession_ByteNbr] );
		S_teststep_expected( "Current session shall be '$tcpar_ActiveSession'.", "Read_active_session_in_$mode" );    #evaluation 3
		S_teststep_detected( "Session obtained $activesession_res[$tcpar_PR_ActiveSession_ByteNbr]", "Read_active_session_in_$mode" );

		#This is required since the loop is going to execute multiple time. Once TP is started, it is expecetd to stop before starting TP again.
		if ( $mode eq 'functional' ) {
			GDCOM_stop_CyclicTesterPresent($TP_handle);
		}
		elsif ( $mode eq 'physical' ) {
			GDCOM_stop_CyclicTesterPresent($TP_handle);
		}
	}    #end of for loop
	return 1;
}

sub TC_evaluation {

	S_w2rep("Evaluation is done above in stimulation_and_measurement");
	return 1;
}

sub TC_finalization {

	#Revert back to physical addressing mode
	GDCOM_set_addressing_mode('physical');
	LC_ECU_Off();
	S_wait_ms(5000);
	return 1;
}

sub _evaluateActiveSession {

	#function to evaluate current session based on the obatined active session against the expected session
	my $expected_Session = shift;
	my $obtained_Session = shift;

	if ( hex($obtained_Session) == $expected_Session ) {
		S_set_verdict('VERDICT_PASS');
	}
	else {
		S_set_verdict('VERDICT_FAIL');
	}
}

sub ReadActiveSession {

	if ( $tcpar_Read_ActiveSession =~ m/rb_/i ) {    #read from SW variable
		return DIAG_ReadActiveSession_SW_var($tcpar_Read_ActiveSession);
	}
	else {
		return GDCOM_request_general( "REQ_" . $tcpar_Read_ActiveSession, "PR_" . $tcpar_Read_ActiveSession );
	}
}

1;
