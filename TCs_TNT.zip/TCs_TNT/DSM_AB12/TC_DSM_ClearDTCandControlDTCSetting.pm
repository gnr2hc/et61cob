#### TEST CASE MODULE
package TC_DSM_ClearDTCandControlDTCSetting;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.2 $;
our $HEADER  = q$Header: DSM_AB12/TC_DSM_ClearDTCandControlDTCSetting.pm 1.2 2017/10/25 16:55:49ICT ver6cob develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_ClearDiagnosticInformation
#TS version in DOORS: 4.9
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use GENERIC_DCOM;
use LIFT_CD;
##################################

our $PURPOSE = "to check that if a clearDiagnosticInformation service is sent by the client, the ControlDTCSetting shall not prohibit clearing the fault memory";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_ClearDTCandControlDTCSetting

=head1 PURPOSE

to check that if a clearDiagnosticInformation service is sent by the client, the ControlDTCSetting shall not prohibit clearing the fault memory

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Create <Faults> in stored state (not active)

2. Send request to enter <Session>

3. Send request <ControlDTCSetting>

4. Send request <ClearDiagnosticInformation> and wait for 10 sec

5. Read fault memory through CD


I<B<Evaluation>>

1. -

2. -

3. Positive response is received

4. Positive response is received

5. No faults are present in fault memory (stored faults are cleared)


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	LIST 'Faults' => 
	SCALAR 'Session' => 
	SCALAR 'ControlDTCSetting' => 
	SCALAR 'ClearDiagnosticInformation' => 


=head2 PARAMETER EXAMPLES

	purpose = 'to check that if a clearDiagnosticInformation ($14) service is sent by the client, the ControlDTCSetting ($85) shall not prohibit clearing the fault memory.' 
	# input parameters
	Faults = @('rb_sqm_SquibResistanceOpenAB1FD_flt', 'rb_sqm_SquibResistanceOpenAB1FP_flt')
	Session = 'ExtendedSession'
	ControlDTCSetting = 'ControlDTCSetting_Off'
	ClearDiagnosticInformation = 'ClearDTCInformation_all'
	#output parameters

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my @tcpar_Faults;
my $tcpar_Session;
my $tcpar_ControlDTCSetting;
my $tcpar_ClearDiagnosticInformation;

################ global parameter declaration ###################
#add any global variables here

###############################################################

sub TC_set_parameters {

    $tcpar_purpose                    = GEN_Read_mandatory_testcase_parameter('purpose');
    @tcpar_Faults                     = GEN_Read_mandatory_testcase_parameter('Faults');
    $tcpar_Session                    = GEN_Read_mandatory_testcase_parameter('Session');
    $tcpar_ControlDTCSetting          = GEN_Read_mandatory_testcase_parameter('ControlDTCSetting');
    $tcpar_ClearDiagnosticInformation = GEN_Read_mandatory_testcase_parameter('ClearDiagnosticInformation');

    return 1;
}

sub TC_initialization {

    S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
    GEN_StandardPrepNoFault();
    GDCOM_start_CyclicTesterPresent();

    return 1;
}

sub TC_stimulation_and_measurement {

    S_teststep( "Create faults: @tcpar_Faults in stored state (not active)", 'AUTO_NBR' );
    foreach (@tcpar_Faults) {
        FM_createFault($_);
    }
    S_wait_ms( 10000, 'wait for qualification time' );

    #dequalify
    foreach (@tcpar_Faults) {
        FM_removeFault($_);
    }
    S_wait_ms( 10000, 'wait for qualification time' );
	CD_read_DTC( '02', '08' );

    S_teststep( "Send request to enter '$tcpar_Session'", 'AUTO_NBR' );
    DIAG_StartSession($tcpar_Session);

    S_teststep( "Send request '$tcpar_ControlDTCSetting'", 'AUTO_NBR', 'send_request_controldtcsetting' );    #measurement 1
    my $response_CtrlDTC = GDCOM_request_general( "REQ_" . $tcpar_ControlDTCSetting, "PR_" . $tcpar_ControlDTCSetting );

    S_teststep_expected( "Positive response", 'send_request_controldtcsetting' );                             #evaluation 1
    S_teststep_detected( "Response: $response_CtrlDTC", 'send_request_controldtcsetting' );

    S_teststep( "Send request '$tcpar_ClearDiagnosticInformation' and wait for 10 sec", 'AUTO_NBR', 'send_request_cleardiagnosticinformation' );    #measurement 2
	if($tcpar_ClearDiagnosticInformation =~ m/all/i){
		my $response_clear = GDCOM_request_general( "REQ_" . $tcpar_ClearDiagnosticInformation, "PR_" . $tcpar_ClearDiagnosticInformation );

		S_teststep_expected( "Positive response", 'send_request_cleardiagnosticinformation' );                                                          #evaluation 2
		S_teststep_detected( "Response: $response_clear", 'send_request_cleardiagnosticinformation' );
	}
	else{
		my %DataValue;
		foreach my $fault (@tcpar_Faults){
			$DataValue{'DTC'} = CD_get_FaultDTC($fault);
			$DataValue{'DTC'} =~ s/(\w{2})/$1 /g; #inserts a space after every 2 characters 
			$DataValue{'DTC'} =~ s/\s+$//; #remove whitespace at end
			
			my $response_clear = GDCOM_request_general( "REQ_" . $tcpar_ClearDiagnosticInformation, "PR_" . $tcpar_ClearDiagnosticInformation, \%DataValue );

			S_teststep_expected( "Positive response" );                                                          #evaluation 2
			S_teststep_detected( "Response: $response_clear" );
		}
	}

    S_wait_ms( 10000, 'wait for qualification time' );

    S_teststep( "Read fault memory through CD", 'AUTO_NBR', 'read_fault_memory' );                                                                  #measurement 3
    my $DTCstruct = CD_read_DTC( '02', '08' );

    CD_evaluate_faults( $DTCstruct, [] );                                                                                                           #check if empty

    S_teststep_expected( "No faults are present in fault memory (stored faults are cleared)", 'read_fault_memory' );                                #evaluation 3
    S_teststep_detected( "Detected DTCs: - @{$DTCstruct->{'DTC'}}", 'read_fault_memory' );

    return 1;
}

sub TC_evaluation {

    S_w2rep("Evaluation is done above in stimulation_and_measurement");

    return 1;
}

sub TC_finalization {

    GDCOM_stop_CyclicTesterPresent();

    return 1;
}

1;
