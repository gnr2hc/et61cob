#### TEST CASE MODULE
package TC_SEC_SecureFlash_SecureAccess;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.2 $;
our $HEADER = q$Header: SECURITY/TC_SEC_SecureFlash_SecureAccess.pm 1.2 2020/05/05 15:53:58ICT D Souza Deepthi Mariate (RBEI/ESA-PP3) (DDE3KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_evaluation;
use LIFT_PD;
use LIFT_labcar;
use GENERIC_DCOM;
use LIFT_can_access;
use INCLUDES_Project;
use Data::Dumper;
use LIFT_CD;
use LIFT_VFlash_ECU_Flash;

##################################

our $PURPOSE = "<summarize what this test is good for>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SEC_SecureFlash_SecureAccess

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1.switch ECU on

2.Activate security mechanism 

3. access ECU with the related Diagnosis Tool with the  <secure_access> 

4. start reprogramming

5.Perform ECU reset

6.access ECU with the related Diagnosis Tool with the  <secure_access> 

7. start reprogramming

8. switch ECU off


I<B<Evaluation>>

1. -

2. -

3. 

4. <reprog_state> is  expected

5. -

6.

7.<reprog_state> is expected

8.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'secure_access' => 
	SCALAR 'reprog_state' => 
	SCALAR 'purpose' => 


=head2 PARAMETER EXAMPLES

	# description of test case
	purpose='check secure flashing for <Test Heading> ' 
	# Diagnosis Tool is VFlash
	# input parameter (used for stimulation and measurement)
	secure_access = '<Test Heading>'
	
	# output parameter (used for evaluation)
	reprog_state = 'rejected' 

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_secure_access;
my $tcpar_reprog_state;
my $tcpar_vflashfilepath;
my $tcpar_hexfilepath ;
my $tcpar_crcfilepath ;
my $tcpar_seedkeydllpath;
my $tcpar_ECU_state;
my $tcpar_ByteNbr;
my $tcpar_session_active;

################ global parameter declaration ###################
#add any global variables here
my ($result_beforeECUreset,$activeSession_beforeECUreset,$result_afterECUreset,$activeSession_afterECUreset);
my $flashing_required=0;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_secure_access =  S_read_mandatory_testcase_parameter( 'secure_access' );
	$tcpar_reprog_state =  S_read_mandatory_testcase_parameter( 'reprog_state' );
	$tcpar_vflashfilepath =  S_read_mandatory_testcase_parameter( 'vflashfilepath' );
	$tcpar_hexfilepath =  S_read_mandatory_testcase_parameter( 'hexfilepath' );
	$tcpar_crcfilepath =  S_read_mandatory_testcase_parameter( 'crcfilepath' );
	$tcpar_seedkeydllpath =  S_read_mandatory_testcase_parameter( 'seedkeydllpath' );
	$tcpar_ByteNbr = S_read_mandatory_testcase_parameter('byte_position');
	$tcpar_session_active			= S_read_mandatory_testcase_parameter('session_active');
	$tcpar_ECU_state 			= S_read_mandatory_testcase_parameter('ECU_state');
	

	$tcpar_vflashfilepath =~s/-/\\/g; # Replace all "-" with "\"
	$tcpar_hexfilepath =~s/-/\\/g; # Replace all "-" with "\"
	$tcpar_crcfilepath =~s/-/\\/g; # Replace all "-" with "\"
	$tcpar_seedkeydllpath =~s/-/\\/g; # Replace all "-" with "\"
	
	S_w2rep("vflashfilepath =$tcpar_vflashfilepath");
	S_w2rep("hexfilepath =$tcpar_hexfilepath");
	S_w2rep("crcfilepath =$tcpar_crcfilepath");
	S_w2rep("seedkeydllpath =$tcpar_seedkeydllpath");

	return 1;
}

sub TC_initialization {

	S_teststep("TestPreparation", 'AUTO_NBR');
	
	S_w2log(1, "Power on ECU");
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

    S_w2log(1, "Initialize CD and start CAN trace");
    GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start ( );

	S_w2log(1, "Clear crash recorder");
    PD_ClearCrashRecorder();
    S_wait_ms(2000);

	S_w2log(1, "Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	S_w2log(1, "Reset ECU");
    PD_ECUreset();
    S_wait_ms('TIMER_ECU_READY');
	
	my $faultsBeforeStimulation = PD_ReadFaultMemory();
	my $faultsVerdict = PD_evaluate_faults( $faultsBeforeStimulation,[]); 
	return 0 unless ($faultsVerdict eq 'VERDICT_PASS');


	return 1;
}

sub TC_stimulation_and_measurement {


	S_teststep("access ECU with the related Diagnosis Tool with the  condition for secure access='$tcpar_secure_access' ", 'AUTO_NBR');

	S_teststep("start reprogramming", 'AUTO_NBR', 'start_reprogramming_beforeReset');			#measurement 1
	
	my $result_beforeECUreset = VFlash_ECU_AutoFlash(
		{
			"vflashfilepath" => $tcpar_vflashfilepath,
			"hexfilepath"    => $tcpar_hexfilepath,
			"crcfilepath"    => $tcpar_crcfilepath,
			"seedkeydllpath" => $tcpar_seedkeydllpath
		}
	);
	
	#$result_beforeECUreset=1 if $main::opt_offline;

	S_teststep("Send diagnostic service '$tcpar_session_active' ", 'AUTO_NBR', 'read_ECU_state_beforeReset');			#measurement 2
	
	$activeSession_beforeECUreset = GDCOM_request_general("REQ_".$tcpar_session_active,"PR_".$tcpar_session_active);
	
	S_teststep("Perform ECU reset", 'AUTO_NBR');
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

	S_teststep("access ECU with the related Diagnosis Tool with the  '$tcpar_secure_access' after ECU reset", 'AUTO_NBR');
	
	S_teststep("start reprogramming", 'AUTO_NBR', 'start_reprogramming_afterReset');			#measurement 3
	my $result_afterECUreset = VFlash_ECU_AutoFlash(
		{
			"vflashfilepath" => $tcpar_vflashfilepath,
			"hexfilepath"    => $tcpar_hexfilepath,
			"crcfilepath"    => $tcpar_crcfilepath,
			"seedkeydllpath" => $tcpar_seedkeydllpath
		}
	);
	
	#$result_afterECUreset=1 if $main::opt_offline;
	S_teststep("Send diagnostic service '$tcpar_session_active' ", 'AUTO_NBR', 'read_ECU_state_afterReset');			#measurement 4
	
	$activeSession_afterECUreset = GDCOM_request_general("REQ_".$tcpar_session_active,"PR_".$tcpar_session_active);
	

	return 1;
}

sub TC_evaluation {
	my (@session_Response_beforeECUreset,@session_Response_afterECUreset);
	
	S_w2rep (" ********************Check for Secure access before ECU reset**************",'orange');
	@session_Response_beforeECUreset = split( / /, $activeSession_beforeECUreset );
	$tcpar_ByteNbr =0 if $main::opt_offline;
	S_teststep_expected( "ECU responds with $tcpar_ECU_state ", "read_ECU_state_beforeReset");       #evaluation 1
	S_teststep_detected( "ECU response is $session_Response_beforeECUreset[$tcpar_ByteNbr]", "read_ECU_state_beforeReset" );
	my $verdict_before_reset=EVAL_evaluate_value( "Active Session",	$session_Response_beforeECUreset[$tcpar_ByteNbr],	'==', $tcpar_ECU_state );
	
	S_teststep_expected("Reprogramming '$tcpar_reprog_state' is  expected", 'start_reprogramming_beforeReset');			#evaluation 2
	if ($result_beforeECUreset and $verdict_before_reset eq 'VERDICT_PASS')  {
		S_teststep_detected("Secure flashing is $tcpar_reprog_state", 'start_reprogramming_beforeReset');
	}
	elsif (not defined $result_beforeECUreset and $verdict_before_reset eq 'VERDICT_FAIL'){
		S_teststep_detected("Secure flashing is NOT $tcpar_reprog_state", 'start_reprogramming_beforeReset');
		$flashing_required=1;
	}

	
	S_w2rep (" *******************Check for Secure access after ECU reset******************",'orange');
	@session_Response_afterECUreset = split( / /, $activeSession_afterECUreset );

	S_teststep_expected( "ECU responds with $tcpar_ECU_state ", "read_ECU_state_afterReset");      				 #evaluation 3
	S_teststep_detected( "ECU response is $session_Response_afterECUreset[$tcpar_ByteNbr]", "read_ECU_state_afterReset" );
	my $verdict_after_reset=EVAL_evaluate_value( "Active Session",	$session_Response_afterECUreset[$tcpar_ByteNbr],	'==', $tcpar_ECU_state );
	
	S_teststep_expected("Reprogramming '$tcpar_reprog_state' is  expected", 'start_reprogramming_afterReset');			#evaluation 4
	if ($result_afterECUreset and $verdict_after_reset eq 'VERDICT_PASS')  {
		S_teststep_detected("Secure flashing is $tcpar_reprog_state", 'start_reprogramming_afterReset');
	}
	elsif (not defined $result_afterECUreset and $verdict_after_reset ne 'VERDICT_PASS'){
		S_teststep_detected("Secure flashing is NOT $tcpar_reprog_state", 'start_reprogramming_afterReset');
		$flashing_required=1;
	}

	return 1;
}

sub TC_finalization {

	if ($flashing_required ==1 or $tcpar_reprog_state eq 'rejected'){
		my $result = VFlash_ECU_AutoFlash();    #Flashes the ECU with already configured .vflash file in testbench
	}
	
	# Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(5000);

	# Read fault memory 
    PD_ReadFaultMemory();   


	return 1;
}


1;
