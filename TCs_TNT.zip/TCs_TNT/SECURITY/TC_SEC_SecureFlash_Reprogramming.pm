#### TEST CASE MODULE
package TC_SEC_SecureFlash_Reprogramming;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER = q$Header: SECURITY/TC_SEC_SecureFlash_Reprogramming.pm 1.1 2020/05/05 15:53:36ICT D Souza Deepthi Mariate (RBEI/ESA-PP3) (DDE3KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_evaluation;
use LIFT_PD;
use LIFT_labcar;
use GENERIC_DCOM;
use LIFT_can_access;
use INCLUDES_Project;
use Data::Dumper;
use LIFT_CD;
use LIFT_VFlash_ECU_Flash;

##################################

our $PURPOSE = "<summarize what this test is good for>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SEC_SecureFlash_Reprogramming

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>


I<B<Stimulation and Measurement>>

1. flash the ECU with correctly signed SW

2. read fault recorder

3. start reprogramming <reprog_file> with <signature_state> using <hexfilepath>,<crcfilepath>,<seedkeydllpath>

4. Send diagnostic service <session_active>and check for  <byte_position> in response,record <HSMLog>

5. check warning lamp state <Warning_Lamp>

6. Perform ECU reset.

7. Send diagnostic service <session_active>and check for  <byte_position> in response

record <ECUstate>,record <HSMLog>

8. check warning lamp state <Warning_Lamp>

9.  flash the ECU with correct SW with correct signature using <vflashfilepath_default>

10. Send diagnostic service <session_active>and check for  <byte_position> in response

11.check warning lamp state


I<B<Evaluation>>

1. -

2. ECU is fault free

3.-

4. <ECU_state> is expected at <byte_position><HSMLog> is  expected.

5. -<Warning_Lamp>is  expected

6. -

7. <ECU_state> is expected at <byte_position>.<HSMLog> is  expected.

8. -<Warning_Lamp>is  expected

9.

10.-ECU is in normal mode.<ECU_default_state> is expected at <byte_position>

11.- warning lamp is off


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'reprog_file' => 
	SCALAR 'hexfilepath' => 
	SCALAR 'crcfilepath' => 
	SCALAR 'ECU_state' => 
	SCALAR 'Warning_Lamp' => 
	SCALAR 'HSMLog' => 
	SCALAR 'purpose' => 
	SCALAR 'signature_state' => 
	SCALAR 'session_active' => 
	SCALAR 'byte_position' => 
	SCALAR 'vflashfilepath_default' => 
	SCALAR 'seedkeydllpath' => 
	SCALAR 'ECU_default_state' => 


=head2 PARAMETER EXAMPLES

	# description of test case
	purpose='check ECU state after reprogramming with  <Test Heading>' 
	signature_state= '<Test Heading 1>_<Test Heading 2>'
	session_active='ReadDatabyID_F186_ActiveDiagnosticSession'
	byte_position='03'
	vflashfilepath_default='.-config-Vflash-CorrectResponse-Project1.vflash'
	seedkeydllpath = '.-config-Vflash-CorrectResponse-KeyGenerator.dll'
	ECU_default_state=1 # ECU is in application state
	#Signature is present only for Application block in platform.If any other blocks has signature then customer project should add new testcases for these blocks
	#Note: 
	#Steps for reprogramming
	#1. Connect the MULTI Debugger and flash merged hex file.
	#2. Disconnect the multi debugger from the ECU 
	#3. Cut the Application section(from iROM_0 to iROM_0 + LENGTH -1 in RenP1XLinkerDirective.ld) from merged hex file available in results and store it
	#4. Sign the new Appl. hex file using SignX tool with Smart card(Docupedia link - https://inside-docupedia.bosch.com/confluence/display/aeos/4.+Enjoy+Software+Signing+with+SignX-Tool)
	#5. Calculate CRC for the signed Application in Hex view tool and store it as .crc file
	#6. Run the test suit 'VFlash' tool after loading the signed Application and CRC file and enter correct pin from pin Details available with Smart card. Verify complete SW download sequence.
	#Tools used for reprogramming
	#1.use signX tool sign the hex file
	#2.Use Hexview editor to extract application section
	#3.V Flash for flashing
	# input parameter (used for stimulation and measurement)
	reprog_file = 'Correct_ApplicationBlock'
	
	 hexfilepath   ='.-config-Vflash-ModifiedSignature-application_S.hex'
	
	crcfilepath    = '.-config-Vflash-ModifiedSignature-application_S.crc'
	
	
	# output parameter (used for evaluation)
	ECU_state=2# ECU stays in bootloader mode
	Warning_Lamp='On'
	HSMLog='NRC'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_signature_state;
my $tcpar_session_active;
my $tcpar_byte_position;
my $tcpar_vflashfilepath_default;
my $tcpar_seedkeydllpath;
my $tcpar_ECU_default_state;
my $tcpar_reprog_file;
my $tcpar_hexfilepath;
my $tcpar_crcfilepath;
my $tcpar_ECU_state;
my $tcpar_Warning_Lamp;
my $tcpar_PD_Variable_WarningLamp;
my $tcpar_HSMLog;

################ global parameter declaration ###################
#add any global variables here
my ($activeSession_beforeECUreset,$detected_warningLampState_beforeReset,
$activeSession_afterECUreset,$detected_warningLampState_afterReset,
$activeSession_afterReflashing,$detected_warningLampState_afterReflashing);

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_signature_state =  S_read_mandatory_testcase_parameter( 'signature_state' );
	$tcpar_session_active =  S_read_mandatory_testcase_parameter( 'session_active' );
	$tcpar_byte_position =  S_read_mandatory_testcase_parameter( 'byte_position' );
	$tcpar_vflashfilepath_default =  S_read_mandatory_testcase_parameter( 'vflashfilepath_default' );
	$tcpar_seedkeydllpath =  S_read_mandatory_testcase_parameter( 'seedkeydllpath' );
	$tcpar_ECU_default_state =  S_read_mandatory_testcase_parameter( 'ECU_default_state' );
	$tcpar_PD_Variable_WarningLamp = S_read_optional_testcase_parameter( 'PD_Variable_WarningLamp');
	if (not defined $tcpar_PD_Variable_WarningLamp){
		S_set_warning("Warning lamp variable will be set to default value: rb_wimi_SysWIStatus_aen(0)");
        $tcpar_PD_Variable_WarningLamp = 'rb_wimi_SysWIStatus_aen(0)';
	}
	$tcpar_reprog_file =  S_read_mandatory_testcase_parameter( 'reprog_file' );
	$tcpar_hexfilepath =  S_read_mandatory_testcase_parameter( 'hexfilepath' );
	$tcpar_crcfilepath =  S_read_mandatory_testcase_parameter( 'crcfilepath' );
	$tcpar_ECU_state =  S_read_mandatory_testcase_parameter( 'ECU_state' );
	$tcpar_Warning_Lamp =  S_read_mandatory_testcase_parameter( 'Warning_Lamp' );
	$tcpar_HSMLog =  S_read_mandatory_testcase_parameter( 'HSMLog' );

	return 1;
}

sub TC_initialization {

	S_teststep("TestPreparation", 'AUTO_NBR');
	
	S_w2log(1, "Power on ECU");
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

    S_w2log(1, "Initialize CD and start CAN trace");
    GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start ( );

	S_w2log(1, "Clear crash recorder");
    PD_ClearCrashRecorder();
    S_wait_ms(2000);

	S_w2log(1, "Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	S_w2log(1, "Reset ECU");
    PD_ECUreset();
    S_wait_ms('TIMER_ECU_READY');
	

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("flash the ECU with correctly signed SW", 'AUTO_NBR');
	S_w2rep(" ECU is already flashed with correct SW with correct signature");

	S_teststep("read fault recorder", 'AUTO_NBR', 'read_fault_recorder');			#measurement 1
	my $faultsBeforeStimulation = PD_ReadFaultMemory();
	my $faultsVerdict = PD_evaluate_faults( $faultsBeforeStimulation,[]); 
	return 0 unless ($faultsVerdict eq 'VERDICT_PASS');								#evaluation 1

	S_teststep("start reprogramming '$tcpar_reprog_file' with '$tcpar_signature_state' ", 'AUTO_NBR');
	VFlash_ECU_AutoFlash(
		{
			"hexfilepath"    => $tcpar_hexfilepath,
			"crcfilepath"    => $tcpar_crcfilepath,
			"seedkeydllpath" => $tcpar_seedkeydllpath
		}
	);

	S_teststep("Before Reset:Send diagnostic service '$tcpar_session_active'and check for  '$tcpar_byte_position' in response", 'AUTO_NBR', 'read_ECU_state_beforeReset');			#measurement 2
	
	$activeSession_beforeECUreset = GDCOM_request_general("REQ_".$tcpar_session_active,"PR_".$tcpar_session_active);
	
	S_teststep("Before Reset:record HSM Log'",'AUTO_NBR', 'HSM_log_beforeReset');								#measurement 3
	S_set_warning("HSM log cannot be read as secure logging is not supported yet");
	
	S_teststep("Before Reset:check warning lamp state '$tcpar_Warning_Lamp'", 'AUTO_NBR', 'check_warning_lamp_beforeReset');			#measurement 4
	my $sysWL_value_aref_beforeReset = PD_ReadMemoryByName($tcpar_PD_Variable_WarningLamp);
	$detected_warningLampState_beforeReset =S_aref2dec($sysWL_value_aref_beforeReset,U8);

	S_teststep("Perform ECU reset", 'AUTO_NBR');
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

	S_teststep("After Reset:Send diagnostic service '$tcpar_session_active'and check for  '$tcpar_byte_position' in response", 'AUTO_NBR', 'read_ECU_state_afterReset');			#measurement 5
	$activeSession_afterECUreset = GDCOM_request_general("REQ_".$tcpar_session_active,"PR_".$tcpar_session_active);
	
	S_teststep("After Reset:record 'HSM Log'",'AUTO_NBR', 'HSM_log_afterReset');							#measurement 6
	S_set_warning("HSM log cannot be read as secure logging is not supported yet");

	S_teststep("After Reset:check warning lamp state '$tcpar_Warning_Lamp'", 'AUTO_NBR', 'check_warning_lamp_afterReset');			#measurement 7
	my $sysWL_value_aref_afterReset = PD_ReadMemoryByName($tcpar_PD_Variable_WarningLamp);
	$detected_warningLampState_afterReset =S_aref2dec($sysWL_value_aref_afterReset,U8);
	
	if ($tcpar_ECU_state eq '2'){
		S_teststep("Flash the ECU with correct SW with correct signature ", 'AUTO_NBR');
		VFlash_ECU_AutoFlash(
			{
				vflashfilepath => $tcpar_vflashfilepath_default,	
			}
		);

		S_teststep("After Reflashing:Send diagnostic service '$tcpar_session_active'and check for  '$tcpar_byte_position' in response", 'AUTO_NBR', 'send_diagnostic_service_afterReflashing');			#measurement 8
		$activeSession_afterReflashing = GDCOM_request_general("REQ_".$tcpar_session_active,"PR_".$tcpar_session_active);

		S_teststep("After Reflashing:check warning lamp state", 'AUTO_NBR', 'check_warning_lamp_afterReflashing');			#measurement 9
		my $sysWL_value_aref_afterReflashing = PD_ReadMemoryByName($tcpar_PD_Variable_WarningLamp);
		$detected_warningLampState_afterReflashing =S_aref2dec($sysWL_value_aref_afterReflashing,U8);
	}

	return 1;
}

sub TC_evaluation {
	
	
	my (@session_Response_beforeECUreset,@session_Response_afterECUreset,@session_Response_afterReflashing);
	
	S_w2rep (" ********************Check for Secure flashing before ECU reset**************",'orange');
	@session_Response_beforeECUreset = split( / /, $activeSession_beforeECUreset );
	$tcpar_byte_position =0 if $main::opt_offline;
	S_teststep_expected( "ECU responds with $tcpar_ECU_state ", "read_ECU_state_beforeReset");       #evaluation 2
	S_teststep_detected( "ECU response is $session_Response_beforeECUreset[$tcpar_byte_position]", "read_ECU_state_beforeReset" );
	my $verdict_before_reset=EVAL_evaluate_value( "Active Session",	$session_Response_beforeECUreset[$tcpar_byte_position],	'==', $tcpar_ECU_state );
	
	S_teststep_expected("$tcpar_HSMLog is expected for HSM log", 'HSM_log_beforeReset');			#evaluation 3
	S_teststep_detected("HSM log is not available as secure logging is not supported yet ", 'HSM_log_beforeReset');

	S_teststep_expected(" Warning lamp is '$tcpar_Warning_Lamp' ", 'check_warning_lamp_beforeReset');			#evaluation 4
	S_teststep_detected(" Warning lamp is $detected_warningLampState_beforeReset", 'check_warning_lamp_beforeReset');
	EVAL_evaluate_value( "Active Session",$detected_warningLampState_beforeReset,	'==', $tcpar_Warning_Lamp );
	
	
	S_w2rep (" ********************Check for Secure flashing before ECU reset**************",'orange');
	
	@session_Response_afterECUreset = split( / /, $activeSession_afterECUreset );

	S_teststep_expected( "ECU responds with $tcpar_ECU_state ", "read_ECU_state_afterReset");      				 #evaluation 5
	S_teststep_detected( "ECU response is $session_Response_afterECUreset[$tcpar_byte_position]", "read_ECU_state_afterReset" );
	my $verdict_after_reset=EVAL_evaluate_value( "Active Session",	$session_Response_afterECUreset[$tcpar_byte_position],	'==', $tcpar_ECU_state );

	S_teststep_expected("'$tcpar_HSMLog' is  expected for HSM log.", 'HSM_log_afterReset');			#evaluation 6
	S_teststep_detected("HSM log cannot be read as secure logging is not supported yet", 'HSM_log_afterReset');

	S_teststep_expected("Warning lamp is '$tcpar_Warning_Lamp' ", 'check_warning_lamp_afterReset');			#evaluation 7
	S_teststep_detected("Warning lamp is $detected_warningLampState_afterReset", 'check_warning_lamp_afterReset');
	EVAL_evaluate_value( "Active Session",$detected_warningLampState_afterReset,	'==', $tcpar_Warning_Lamp );
	
	if ($tcpar_ECU_state eq '02'){

		@session_Response_afterReflashing = split( / /, $activeSession_afterReflashing );
		S_teststep_expected("ECU responds with $tcpar_ECU_default_state", 'send_diagnostic_service_afterReflashing');			#evaluation 8
		S_teststep_detected("ECU response is $session_Response_afterReflashing[$tcpar_byte_position]", 'send_diagnostic_service_afterReflashing');
		my $verdict_after_Reflashing=EVAL_evaluate_value( "Active Session",	$session_Response_afterReflashing[$tcpar_byte_position],	'==', $tcpar_ECU_default_state );

		S_teststep_expected("warning lamp is 00", 'check_warning_lamp_afterReflashing');			#evaluation 9
		S_teststep_detected("Warning lamp is $detected_warningLampState_afterReflashing", 'check_warning_lamp_afterReflashing');
		EVAL_evaluate_value( "Active Session",$detected_warningLampState_afterReflashing, '==', '00' );
	
	}

	return 1;
}

sub TC_finalization {

	# Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(5000);

	# Read fault memory 
    PD_ReadFaultMemory(); 

	return 1;
}


1;
