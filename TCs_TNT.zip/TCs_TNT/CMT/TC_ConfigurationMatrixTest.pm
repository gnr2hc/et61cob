#### TEST CASE MODULE
package TC_ConfigurationMatrixTest;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.6 $;
our $HEADER = q$Header: CMT/TC_ConfigurationMatrixTest.pm 1.6 2017/11/28 15:20:04ICT D Souza Deepthi Mariate (RBEI/ESA-PP3) (DDE3KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_evaluation;
use LIFT_PD;
use LIFT_labcar;
use GENERIC_DCOM;
use LIFT_can_access;
use INCLUDES_Project;
use Data::Dumper;
use LIFT_CD;
use FuncLib_SYC_INTERFACE;

##################################

our $PURPOSE = "To check configuration state of all peripherals for a variant";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_ConfigurationMatrixTest

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

TestPreparationCMT


I<B<Stimulation and Measurement>>

1. Check the <ConfigState> for <Device>

2.If <DeviceType> is 'Switch', check for <SwitchType>

3.If <ConfigState> is 'yes', create <Condition> 

4.Read fault memory 

5.Remove the <Condition> 

6.Erase the fault memory


I<B<Evaluation>>

1.

2.

3.

4.If <ConfigState> is 'yes',<Fault1> is qualified

If <ConfigState> is 'no',<Fault2> is qualified

5.

6.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'Device' => 
	SCALAR 'Fault1' => 
	SCALAR 'Fault2' => 
	SCALAR 'DeviceType' => 
	SCALAR 'Condition' => 


=head2 PARAMETER EXAMPLES

	purpose = 'To check configuration state of '<Test Heading Head>' for a variant' 
	
	#Data from SYC
	
	#ConfigState= '<Fetch {V_Catalog_C1A_VHRC}'
	
	Device='<Test Heading Head>'
	
	Fault1='rb_sqm_SquibResistanceOpen<Test Heading Head>_flt'
	
	Fault2='rb_sqm_Unexpected<Test Heading Head>_flt'
	
	DeviceType='Squib'
	
	Condition='Openline'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Device;
my $tcpar_Fault1;
my $tcpar_Fault2;
my $tcpar_DeviceType;
my $tcpar_Condition1;
my $tcpar_Condition2;
my $ConfigState;
my $SwitchType;
my $tcpar_faultstatus;
my $tcpar_SYC_Device;

################ global parameter declaration ###################
#add any global variables here
my $faultsAfterStimulation;
my ($status_notconfigured,$status_configured);
my ($Real,$Monitored_ID,$Prog,$detected_configState,$MonitorState,$no_eval);
###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_Device =  S_read_mandatory_testcase_parameter( 'Device' );
	$tcpar_SYC_Device =  S_read_optional_testcase_parameter( 'SYC_Device' );
	$tcpar_Fault1 =  S_read_optional_testcase_parameter( 'Fault1' );
	$tcpar_Fault2 =  S_read_optional_testcase_parameter( 'Fault2' );
	$tcpar_DeviceType =  S_read_mandatory_testcase_parameter( 'DeviceType' );
	$tcpar_Condition1 =  S_read_mandatory_testcase_parameter( 'Condition1' );
	$tcpar_Condition2 =  S_read_mandatory_testcase_parameter( 'Condition2' );
	$tcpar_faultstatus =  S_read_mandatory_testcase_parameter( 'faultstatus');
	
	
	if (not defined $tcpar_SYC_Device){
		$tcpar_SYC_Device=$tcpar_Device;
	}

	return 1;
}

sub TC_initialization {

	S_teststep("TestPreparationCMT", 'AUTO_NBR');
	
	S_w2log(1, "Power on ECU");
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

    S_w2log(1, "Initialize CD and start CAN trace");
    GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start ( );

	S_w2log(1, "Clear crash recorder");
    PD_ClearCrashRecorder();
    S_wait_ms(2000);

	S_w2log(1, "Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	S_w2log(1, "Reset ECU");
    PD_ECUreset();
    S_wait_ms('TIMER_ECU_READY');
	
	my $faultsBeforeStimulation = PD_ReadFaultMemory();
	my $faultsVerdict = PD_evaluate_faults( $faultsBeforeStimulation,[]); 
	return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Check the ConfigState for '$tcpar_Device'", 'AUTO_NBR','Config_state');
	
	my $result;
	
	if ( $tcpar_DeviceType eq 'Squib'){
		($result, $ConfigState)=SYC_SQUIB_get_Configured($tcpar_SYC_Device )
	
	}
	elsif ( $tcpar_DeviceType eq 'Switch'){
		($result, $ConfigState)=SYC_SWITCH_get_Configured($tcpar_SYC_Device )
	
	}
	elsif ( $tcpar_DeviceType eq 'Sensor'){
		($result, $ConfigState)=SYC_SENSOR_get_Configured($tcpar_SYC_Device )
	
	}
	elsif ( $tcpar_DeviceType eq 'Lamp'){
		($result, $ConfigState)=SYC_AnalogueOutput_get_Configured($tcpar_SYC_Device )
	
	}
	else {
	
		S_set_error("$tcpar_DeviceType is not Squib/Switch/Sensor/Lamp. Testcase will be aborted");
		return ;
	
	}
	
	unless (defined $ConfigState){
		S_set_error("Not available in SYC - add or overwrite with Custlibrary Function/Check if SYC has the configuration data for device '$tcpar_Device'");
        return;
	
	}
	
	($Real,$Monitored_ID,$Prog) = PD_get_device_config( $tcpar_Device );
	
	if ($Prog == 1){
	$Prog='yes';
	}
	else {
	
	$Prog='no';
	}
	
	my $VERDICT = EVAL_evaluate_string ('compare config state from SYC to SW' , $ConfigState , $Prog  ); 
	if ( $VERDICT eq 'VERDICT_FAIL'){
		S_set_error(" config state in SYC is   $ConfigState  , Config state in Sw is $Prog  , hence testcase aborted" )unless($main::opt_offline); 
		
		return unless($main::opt_offline); 
	}
	
	
	if ($tcpar_DeviceType eq 'Switch'){
		S_teststep("Check for SwitchType ", 'AUTO_NBR');
		($result, $SwitchType)=	SYC_SWITCH_get_type($tcpar_Device);
		unless (defined $SwitchType ){
			S_set_error("Switch type for $tcpar_Device is Not available in SYC -Testcase will be aborted");
			return;
		}
	}
	

	if (lc($ConfigState) eq 'yes'){
		if( defined $SwitchType and $SwitchType =~/mechanical/){
			S_teststep("Since $tcpar_Device is mechanical switch and no line faults can be created , check the configuration state in SW via PD", 'AUTO_NBR','Software_bit_status');
			($Real,$Monitored_ID,$Prog) = PD_get_device_config( $tcpar_Device );
			S_w2rep("Real bit is $Real, monitored bit is $Monitored_ID,programmed bit is $Prog for device $tcpar_Device");
			
		}
		else {	
			S_teststep("Create '$tcpar_Condition1' fault on device $tcpar_Device, since config state is '$ConfigState'", 'AUTO_NBR');
			$status_configured=DEVICE_setDeviceState( $tcpar_Device, $tcpar_Condition1);
		}
	
	}
	elsif (lc($ConfigState) eq 'no'){
		S_teststep("Check monitoring state of device $tcpar_Device ,since config state is '$ConfigState'", 'AUTO_NBR');
		$tcpar_DeviceType = 'Actuator' if ($tcpar_DeviceType eq 'Squib');
        ( $result, $MonitorState ) = SYC_get_ConfigId_Content_NOERROR( 'Monitored', [ $tcpar_DeviceType, $tcpar_Device ] );
        ( $result, $MonitorState ) = SYC_get_ConfigId_Content( 'Monitored', [ $tcpar_DeviceType, ".*" . $tcpar_Device . ".*" ] ) unless $result;
		if (lc($MonitorState) eq 'yes'){
			unless ( defined $SwitchType and $SwitchType =~/mechanical/){
				S_teststep("Create '$tcpar_Condition2' fault on device $tcpar_Device, since config state is '$ConfigState', monitor state is '$MonitorState'", 'AUTO_NBR');
				$status_notconfigured=DEVICE_resetDeviceState( $tcpar_Device, $tcpar_Condition1 );
			}
			else {
				S_teststep("Check for real bit, monitor bit and config bit in SW for device $tcpar_Device, since config state is '$ConfigState', monitor state is '$MonitorState' as per SYC",'AUTO_NBR', 'Software_bit_status');
				($Real,$Monitored_ID,$Prog) = PD_get_device_config( $tcpar_Device );
				S_w2rep("Real bit is $Real, monitored bit is $Monitored_ID,programmed bit is $Prog for device $tcpar_Device");
			}
		}
		elsif (lc($MonitorState) eq 'no') {
			S_set_warning("For device '$tcpar_Device': Monitor state is '$MonitorState',ConfigState  is '$ConfigState',hence device not supported for the variant under test,testcase is aborted");
			$no_eval=1;
			return 1;
		}
		
	}
	elsif ($ConfigState eq ('N/A' or 'NA')){
		S_teststep("Check monitoring state of device $tcpar_Device ,since config state is '$ConfigState'", 'AUTO_NBR');
		$tcpar_DeviceType = 'Actuator' if ($tcpar_DeviceType eq 'Squib');
		( $result , $MonitorState ) = SYC_get_ConfigId_Content( 'Monitored', [$tcpar_DeviceType,$tcpar_Device ]);
		S_set_warning("For device '$tcpar_Device':Monitor state is $MonitorState ,ConfigState is '$ConfigState',hence device not supported for the variant under test,testcase is aborted");
		$no_eval=1;
        return 1;
	
	}
	else {
		S_set_error(" Config state for device '$tcpar_Device' is '$ConfigState'. It should be yes/no/NA(N/A). Hence Testcase is aborted");
		return;

	}
	S_teststep("Wait for fault qualification time", 'AUTO_NBR');
	S_wait_ms( 5000, 'wait after fault creation' );
	S_teststep("Read fault memory ", 'AUTO_NBR', 'read_fault_memory');			#measurement 1
	$faultsAfterStimulation = PD_ReadFaultMemory();
		
	if (defined $status_configured){
		S_teststep("Remove the '$tcpar_Condition1' fault on device $tcpar_Device ", 'AUTO_NBR');
		DEVICE_resetDeviceState( $tcpar_Device, $tcpar_Condition1 );
		
	}
	elsif (defined $status_notconfigured){
		S_teststep("Remove the '$tcpar_Condition2' fault on device $tcpar_Device ", 'AUTO_NBR');
		DEVICE_setDeviceState( $tcpar_Device, $tcpar_Condition1);
	
	}
	S_teststep("Wait for fault dequalification time", 'AUTO_NBR');
	S_wait_ms( 5000, 'wait after fault removal' );
	
	PD_ReadFaultMemory();
	S_wait_ms(2000);
	S_teststep("Erase the fault memory", 'AUTO_NBR');
	PD_ClearFaultMemory();
	S_wait_ms(6000);
	

	return 1;
}

sub TC_evaluation {

	if (defined $no_eval){
		($Real,$Monitored_ID,$Prog) = PD_get_device_config( $tcpar_Device );
		S_teststep_expected("For device '$tcpar_Device': Monitor state is '$MonitorState',ConfigState  is '$ConfigState' ","Config_state");		#evaluation 1
		S_teststep_detected("For device '$tcpar_Device': Monitor state is '$Monitored_ID',ConfigState  is '$Prog',hence device not supported for the variant under test,testcase is aborted", "Config_state");
		EVAL_evaluate_value ( 'Monitored bit check' , $Monitored_ID, '==', 0 );
		EVAL_evaluate_value ( 'Configured bit check' , $Prog, '==', 0 );
		
		return 1;
	}
	
	my ($tcpar_Fault,$tcpar_Condition);
	
	if (defined $tcpar_Condition1){
		$tcpar_Fault=$tcpar_Fault1;
		$tcpar_Condition=$tcpar_Condition1;
	}
	else {
		$tcpar_Fault=$tcpar_Fault2;
		$tcpar_Condition=$tcpar_Condition2;
	}

	if (not defined $tcpar_Fault and defined $status_configured){
		my $MySearch->{'DeviceType'} = $tcpar_DeviceType;
		$MySearch->{'Device'} = $tcpar_Device;
		$MySearch->{'Condition'} = $tcpar_Condition;
		my $tcpar_Fault = FM_fetchFaultName($MySearch);
		unless (defined $tcpar_Fault){
			S_set_error(" Fault for condition '$tcpar_Condition' on device '$tcpar_Device' is not available in Mapping_Fault.pm . Hence Testcase is aborted");
			return;
	
		}
	}
	
	my $expected_mandatory_fault;
	if ($ConfigState eq 'yes'){
		$expected_mandatory_fault= $tcpar_Fault1;		
	}	
	else {
		$expected_mandatory_fault= $tcpar_Fault2;
	}
	

	if (defined $Prog){
		$detected_configState= 'yes' if ($Prog==1);
		$detected_configState= 'no' if ($Prog==0);
	}

	
	if ( defined $SwitchType and $SwitchType =~/mechanical/){
	
		S_teststep_expected("Config state is '$ConfigState' as per SYC", 'Software_bit_status');			#evaluation 1
		S_teststep_detected("Config state is '$detected_configState' as per SW configuration ", "Software_bit_status");    
		my $VERDICT = EVAL_evaluate_string ( $tcpar_DeviceType."_".$tcpar_Device , $ConfigState , $detected_configState );
	
	}
	
	else {
		S_teststep_expected("Config state is '$ConfigState' ,'$expected_mandatory_fault' should be qualified", 'read_fault_memory');			#evaluation 1
			
		if(PD_check_fault_exists($faultsAfterStimulation, $expected_mandatory_fault)){ 	
			#Reads the data for given state_name
			my $found_status = PD_GetFaultAttribute( $faultsAfterStimulation, $expected_mandatory_fault, 'state' );
			S_teststep_detected("Fault $expected_mandatory_fault, state '$found_status'", "read_fault_memory");           
					
			#Evaluates read data with expected and reads the verdict
			EVAL_evaluate_value( "STATUS_" . $expected_mandatory_fault, $found_status, "==", $tcpar_faultstatus );
		}
		else {
			S_teststep_detected("Fault $tcpar_Fault is not qualified", "read_fault_memory");  
		
		}
	
	}
	

	return 1;
}

sub TC_finalization {

	# Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(5000);

	# Read fault memory 
    PD_ReadFaultMemory();   

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');
	return 1;

}


1;
