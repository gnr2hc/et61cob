#### TEST CASE MODULE
package TC_EDID_COMSignal_Validation;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
use FuncLib_EDR_Framework; #necessary
#include further modules here
use FuncLib_SYC_INTERFACE;
use LIFT_evaluation;
use Data::Dumper;
use EDR_Framework::FuncLib_EDR_Offline_xmlLogging;

use constant MILLISEC_TO_SECOND => 0.001;
use constant SECOND_TO_MILLISEC => 1000;

##################################

our $PURPOSE = "Validation of COM signals from data injected in previous crash";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDID_COMSignal_Validation

=head1 PURPOSE

Validation of COM signals from data injected in previous crash

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

no stimulation needed - call TC_EDR_CrashDataRetrieval or TC_EDR_CrashInjection before calling this test case

I<B<Evaluation>>

1.<COMSignal> should be reported in EDR according to COM trace


I<B<Finalisation>>

-


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => purpose of test case
	SCALAR 'EDID' => Data element ID
	SCALAR 'COMSignal' => Label for COM signal in Diag mapping

=head2 PARAMETER EXAMPLES

	purpose		 = 'check COM signal relevant EDID for Speed, vehicle indicated Quality factor'
	
	EDID = '<Fetch {OEM specific DID List, Ford RESS 8.0}>'
	COMSignal = 'VehVActlEng_D_Qf'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_EDID;
my $tcpar_COMSignal;
my $tcpar_Tolerance_Value_abs;
my $tcpar_LastSpeedDataSample_EDID;

################ global parameter declaration ###################
#add any global variables here
my (
	$record_handler,
	$crash_handler,
	$storedCrashLabels_aref,
);


###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_EDID =  GEN_Read_mandatory_testcase_parameter( 'EDID' );
	$tcpar_COMSignal =  GEN_Read_mandatory_testcase_parameter( 'COMSignal' );
	S_add2eval_collection ( 'EDID' , $tcpar_EDID);
	my $allAttributes = EDR_fetchEDIDallAttributes_by_ID($tcpar_EDID);
	S_add2eval_collection('EDID From', $allAttributes -> {'From'}) if (defined $allAttributes -> {'From'});
	$tcpar_Tolerance_Value_abs = GEN_Read_optional_testcase_parameter('ToleranceValue_abs');
	$tcpar_LastSpeedDataSample_EDID = GEN_Read_optional_testcase_parameter('LastSpeedDataSample_EDID');

	return 1;
}

sub TC_initialization {

	S_teststep("Initialize record and crash handler", 'AUTO_NBR');
	$record_handler = EDR_init_RecordHandler() || return;
	$crash_handler  = EDR_init_CrashHandler() || return;

	return 1;
}

sub TC_stimulation_and_measurement {

	$storedCrashLabels_aref = $record_handler -> GetListOfStoredRecords();

	# Prepare evaluation keywords - no actual crash injection
	foreach my $crash (@{$storedCrashLabels_aref})
	{
		S_teststep("Read EDR (EDID $tcpar_EDID) corresponding to COM signal $tcpar_COMSignal for crash $crash", 
		           'AUTO_NBR', 
		           "Read EDID $tcpar_EDID crash $crash"); # evaluation label
	}


	return 1;
}

sub TC_evaluation {

	#--------------------------------------------------------------
    # GET STORAGE ORDER
    #    
    my $storageOrder = EDR_getStorageOrder();
    return unless(defined $storageOrder);

    if($storageOrder eq 'PhysicalOrder'){
       $storageOrder =  'MostRecentLast'; #same behavior as there is no overwriting
    }


	my $numberOfRecords = SYC_EDR_get_NumberOfEventsToBeStored();
	unless(defined $numberOfRecords){
		S_set_error("'NumberOfEventsToBeStored' not available in SYC - add or overwrite 'SYC_EDR_get_NumberOfEventsToBeStored' with Custlibrary Function");
		return;
	}

	foreach my $crash (@{$storedCrashLabels_aref})
	{
		#--------------------------------------------------------------
		# GET EXPECTED COM SIGNAL VALUE
		#    
		S_w2log(1, "Get expected COM signal value '$tcpar_COMSignal' in crash $crash");
		my $comSignalDataSamples;

		my $functionName = "EDR_COM_GetExpectedValue_$tcpar_COMSignal";
		if(exists &$functionName) {
		   S_w2log( 4, "Call '$tcpar_COMSignal' function to get expected COM signal data samples\n" );
		   {
				no strict 'refs'; #disable strict refs only for this section
				$comSignalDataSamples = &$functionName($crash);
				return if not $comSignalDataSamples;
		   }
			
		}
		else {
			my $sourceData = $crash_handler -> GetSourceDataSamples("SourceLabel" => $tcpar_COMSignal, "CrashLabel" => $crash); 
			
			unless(defined $sourceData) {
				S_set_error("No COM signal values found for crash $crash. EDID will not be evaluated.", 110);
				return;
			}

			$comSignalDataSamples = $sourceData -> {"DataSamples"};
		}

		#--------------------------------------------------------------
		# GET CRASH TIME ZERO ON COM AND EDR
		#    
		my $comTraceTimeZero_ms = $crash_handler -> Get_COM_TraceTimeZero_ms(  "SourceLabel" => $tcpar_COMSignal, "CrashLabel" => $crash );		

		if(not defined $comTraceTimeZero_ms){
			S_set_error("COM trace time zero could not be found in CAN trace.\n"
						."Is event trigger connected to TSG4?\n"
						."Is EventTrigger message (ID = 7) defined in CAN mapping?\n"
						."Is the TSG4 firmware up to date? (Minimum firmware version 17 required)");
			return;
		}

		S_w2rep("Com trace time zero: $comTraceTimeZero_ms ms");



		my $crashTimeZero = $crash_handler -> GetSourceDataValues ( "SourceLabel" => "CrashTimeZero",
															        "CrashLabel"  => $crash );
		unless(defined $crashTimeZero) {
			S_set_error("No crash time zero stored for crash $crash. No evaluation of ring buffer possible. Try next crash.", 110);
			next;
		}
		my $crashTimeZero_ms = $crashTimeZero -> {"DataValues"};
		my $crashTimeZeroUnit = $crashTimeZero -> {"DataUnit"};
		if($crashTimeZeroUnit ne "ms") {
			S_set_error("Crash Time zero must be stored in ms!! Go to next crash.", 110);
			next;
		}
		S_w2rep("Crash time zero: $crashTimeZero_ms ms");


		my @allCrashTimeZeros = split('_', $crashTimeZero_ms);
		my $numberOfIncidents = @allCrashTimeZeros;
		S_w2rep("Number of incidents: $numberOfIncidents");
		my $crashTimeZero_href;

		my $numberOfRecordsToEvaluate;
		if($numberOfIncidents > $numberOfRecords){ #Extended event
			$numberOfRecordsToEvaluate = $numberOfRecords;
		}
		else {
			$numberOfRecordsToEvaluate = $numberOfIncidents;
		}

		foreach my $incidentNumber (1..$numberOfRecordsToEvaluate)
		{
			$crashTimeZero_href -> {"Record_$incidentNumber"} = $allCrashTimeZeros[$incidentNumber-1] if($storageOrder eq 'MostRecentLast');
			$crashTimeZero_href -> {"Record_$incidentNumber"} = $allCrashTimeZeros[$numberOfRecordsToEvaluate - $incidentNumber] if($storageOrder eq 'MostRecentFirst');		
		}

		S_w2rep("Number of records to evaluate: $numberOfRecordsToEvaluate");

		
		foreach my $recordNbr (1..$numberOfRecordsToEvaluate)
		{
			S_w2rep("---- Record $recordNbr ----");
			my $thisCrashTimeZero = $crashTimeZero_href -> {"Record_$recordNbr"};
			S_w2rep("Crash time zero: $thisCrashTimeZero ms");

			# Synchronize T0
			S_w2rep("Crash time zero given for this crash is: $thisCrashTimeZero");
			S_teststep_2nd_level("Synchronize given T0 ($thisCrashTimeZero) for EDID $tcpar_EDID.", 'AUTO_NBR');
		    if(defined $tcpar_LastSpeedDataSample_EDID)
		    {
		    	S_set_warning("Usage of parameter 'LastSpeedDataSample_EDID' outdated. Fill 'TimeSynchronization' section in EDR mapping instead!");
	
		        my $edidData = $record_handler -> GetDecodedEDID("CrashLabel" => $crash, "RecordNumber" => $recordNbr,"EDIDnr" => $tcpar_LastSpeedDataSample_EDID );
		        unless(defined $edidData) {
		            S_set_error("No EDID data found for given EDID $tcpar_LastSpeedDataSample_EDID (last speed data sample) crash $crash, record $recordNbr, return nothing", 110);
		            return;
		        }
		        $thisCrashTimeZero = $thisCrashTimeZero - $edidData -> {DataValue} * MILLISEC_TO_SECOND;
		    }
		    else{
				$thisCrashTimeZero = EDR_synchronize_T0_for_EDID($tcpar_EDID, $thisCrashTimeZero,		    	
																 $crash, $recordNbr);
		    }
	
			S_teststep("Synchronized T0: $thisCrashTimeZero ms", 'NO_AUTO_NBR');
	
			#-----------------------------------------------------------------------
			# Get EDID data
			#-----------------------------------------------------------------------
			S_teststep("Read EDID '$tcpar_EDID' corresponding to COM signal $tcpar_COMSignal in Record $recordNbr", 'AUTO_NBR', "compareEDID_Record$recordNbr");			#measurement 1
	
			# EDID value
			S_w2rep("Get decoded EDID value");
			my $edidData = $record_handler -> GetDecodedEDID("CrashLabel" => $crash, "RecordNumber" => $recordNbr,"EDIDnr" => $tcpar_EDID );
			unless(defined $edidData) {
				S_set_error("No EDID data found for crash $crash, record $recordNbr, return nothing", 110);
				return;
			}
			
			if(ref($edidData -> {"DataValue"}) ne 'ARRAY'){
				S_w2rep("EDID is static, i.e. there is only one data sample to validate");
				my $detectedEDIDvalue = $edidData -> {"DataValue"};
				my $comValueAtRecStart;
				my $crashTimeZeroOnCOM_sec = ($comTraceTimeZero_ms + $crashTimeZero_href -> {"Record_$recordNbr"}) * MILLISEC_TO_SECOND;
				S_w2rep("EDR recording start time: $crashTimeZeroOnCOM_sec sec");
				foreach my $comTimeStamp (sort {$a <=> $b} keys %{$comSignalDataSamples})
				{
					next if($comTimeStamp < $crashTimeZeroOnCOM_sec);
					$comValueAtRecStart = $comSignalDataSamples -> {$comTimeStamp};
					S_w2rep("COM value at recording start time of EDID is $comValueAtRecStart");
					last;
				}
				S_teststep_expected("Expected value for EDID $tcpar_EDID: $comValueAtRecStart", "compareEDID_Record$recordNbr");
				S_teststep_detected("Detected value for EDID $tcpar_EDID: $detectedEDIDvalue", "compareEDID_Record$recordNbr");
				my $verdict;
				if($comValueAtRecStart=~ m/[a-zA-Z]/ or $detectedEDIDvalue =~ m/[a-zA-Z]/){
					$verdict = EVAL_evaluate_string("EDID_$tcpar_EDID\_$tcpar_COMSignal", $comValueAtRecStart, $detectedEDIDvalue);
				}
				else{
					$verdict = EVAL_evaluate_value( "EDID_$tcpar_EDID\_$tcpar_COMSignal",
													$detectedEDIDvalue, '==', $comValueAtRecStart,
													$tcpar_Tolerance_Value_abs , 'absolute');				
				}
				if(S_get_exec_option_NOERROR('CreisOfflineEvalReporting')){
					my $description = $record_handler -> GetDataElementEDID("CrashLabel" => $crash,
																			"RecordNumber" =>  $recordNbr,
																			"EDIDnr" => $tcpar_EDID);
					FLEDR_XML_addStaticEdidNode(
							$recordNbr, # record number
							'NET_Data',
							$tcpar_EDID,
							$description,
							$comValueAtRecStart,
							$detectedEDIDvalue,
							$tcpar_Tolerance_Value_abs,
							$edidData -> {"ValueUnit"},
							$verdict,
					);
			    }

				next;
			}

			# Eval start and end time
			S_w2rep("Get EDID recording start and end time");
			my $recordingStartTime_ms = $record_handler -> GetRecStartTimeMillisecEDID("CrashLabel" => $crash, "RecordNumber" => $recordNbr,"EDIDnr" => $tcpar_EDID );
			my $recordingEndTime_ms = $record_handler -> GetRecEndTimeMillisecEDID("CrashLabel" => $crash, "RecordNumber" => $recordNbr,"EDIDnr" => $tcpar_EDID );
			
			# Ringbuffer COM signal -> more than one data sample!
			my $edidDataSamples = $edidData -> {"DataSamples"};
			unless(defined $edidDataSamples) {
				S_set_error("No EDID data samples could be obtained for EDID $tcpar_EDID in record $recordNbr!", 110);
				return;
			}
	
			# EDID Sample Rate
			S_w2rep("Get EDID sample rate in Hz");
			my $edidSampleRate_Hz = $record_handler -> Get_EDID_SampleRateHz("CrashLabel" => $crash, "RecordNumber" => $recordNbr,"EDIDnr" => $tcpar_EDID );
			my $tolerance_sec;
			if($edidSampleRate_Hz > 0) {
				$tolerance_sec = 1 / $edidSampleRate_Hz;
			}
			else {
				S_set_error("No EDID sample rate greater than zero given - check sample rate in EDR mapping", 110);
				return;
			}
			
			
			# Check whether complete validation period has valid COM measurement
			if(S_get_exec_option_NOERROR('CreisOfflineEvalReporting')){
				S_teststep("Evaluate data samples before NET trace start", 'AUTO_NBR', 'eval_pre_trace_start');
				my $evalStartTime_s = ($comTraceTimeZero_ms + $thisCrashTimeZero + $recordingStartTime_ms) * MILLISEC_TO_SECOND  - $tolerance_sec;
				S_w2rep("COM trace T0 $comTraceTimeZero_ms ms; Rec Start time $recordingStartTime_ms ms; tol $tolerance_sec sec");
				S_w2rep("Eval start time: $evalStartTime_s");
				my $firstTimeStampComAfterEvalStart;
				foreach my $timeStamp (sort {$a <=> $b} keys %{$comSignalDataSamples}){
					next if($timeStamp <= $evalStartTime_s);
					$firstTimeStampComAfterEvalStart = $timeStamp;
					last;
				}
				S_w2rep("First detected COM time stamp: $firstTimeStampComAfterEvalStart");
				my $affectedDataSamples = int((($firstTimeStampComAfterEvalStart - $evalStartTime_s) / $tolerance_sec) + 0.5) + 1;
				if($affectedDataSamples > 0){
					S_w2rep("First $affectedDataSamples data samples might be 'DataNotAvailable'");
					my $dataSampleNbr = 1;
					foreach my $edidDataTimeStamp(sort {$a <=> $b} keys %{$edidDataSamples}){
						my $edidValue = $edidDataSamples -> {$edidDataTimeStamp};
						last if($edidValue ne 'DataNotAvailable');
						S_teststep_expected("Data sample $dataSampleNbr, time stamp $edidDataTimeStamp: 'DataNotAvailable'", 'eval_pre_trace_start');
						S_teststep_detected("Data sample $dataSampleNbr, time stamp $edidDataTimeStamp: $edidValue", 'eval_pre_trace_start');
						$dataSampleNbr++;
						$recordingStartTime_ms += $tolerance_sec * 1000; # update recording start time - remove already evaluated data sample
						delete $edidDataSamples -> {$edidDataTimeStamp}; # remove already evaluated data sample
						last if($dataSampleNbr > $affectedDataSamples);
					}
				}
			}	
			#-----------------------------------------------------------------------
			# Compare expected and detected
			#-----------------------------------------------------------------------
			S_teststep("Start evaluation of '$tcpar_EDID' corresponding to COM signal $tcpar_COMSignal in Record $recordNbr, crash $crash", 'AUTO_NBR');
			my ($verdict, $busData_href) = EDR_Eval_Ringbuffer_COMsignal( "EDID_DataSamples" => $edidDataSamples,
											 "COM_Signal_DataSamples" => $comSignalDataSamples,
											 "Rec_Start_Time_ms" => $recordingStartTime_ms, 
											 "Rec_End_Time_ms" => $recordingEndTime_ms,
											 "Crash_TimeZero_s" => $thisCrashTimeZero * MILLISEC_TO_SECOND,
											 "COM_trace_TimeZero_ms" => $comTraceTimeZero_ms,
											 "EDID_ID" => $tcpar_EDID,
											 "Absolute_Tolerance_Time_sec" => $tolerance_sec,
											 "Absolute_Tolerance_Value" => $tcpar_Tolerance_Value_abs,
											 "DataUnit" => $edidData -> {"ValueUnit"},
											 "CompareTitle" => "COM_Signal_$tcpar_COMSignal\_Crash_$crash\_Record_$recordNbr");						
	
			S_teststep_expected("'EDID $tcpar_EDID' corresponding to COM signal '$tcpar_COMSignal' should be reported as in CAN trace", "compareEDID_Record$recordNbr");			#evaluation 1
			S_teststep_detected("Detected EDID COM signal state: equal to COM signal in trace", "compareEDID_Record$recordNbr") if ($verdict eq 'VERDICT_PASS');
			S_teststep_detected("Detected EDID COM signal state: not equal to COM signal in trace", "compareEDID_Record$recordNbr") if ($verdict eq 'VERDICT_FAIL');


			if(S_get_exec_option_NOERROR('CreisOfflineEvalReporting')){
				my $edidDataString;
	
				foreach my $edidDataSample(sort {$a <=> $b} keys %{$edidData -> {"DataSamples"}}){
					if(not defined $edidDataString){
						$edidDataString = $edidData -> {"DataSamples"} -> {$edidDataSample};
					}
					else{
						$edidDataString .= " ".$edidData -> {"DataSamples"} -> {$edidDataSample};
					}
				}
				
				my $description = $record_handler -> GetDataElementEDID("CrashLabel" => $crash,
																		"RecordNumber" =>  $recordNbr,
																		"EDIDnr" => $tcpar_EDID);

				my $busDataString;
				foreach my $timeStamp (sort {$a <=> $b} keys %{$busData_href}){
					if(not defined $busDataString){
						$busDataString = $busData_href -> {$timeStamp};
					}
					else{
						$busDataString .= " ".$busData_href -> {$timeStamp};
					}
				}
	
				FLEDR_XML_addDynamicEdidNode(
						$recordNbr, # record number
						'NET_Data',
						$tcpar_EDID,
						$description,
						$busDataString,
						$edidDataString,
						$tcpar_Tolerance_Value_abs,
						$edidData -> {"ValueUnit"},
						$recordingStartTime_ms,
						$recordingEndTime_ms,
						$edidData -> {"SampleRateHz"},
						$verdict,
				);
		    }
		}
	}

	return 1;
}

sub TC_finalization {

	return 1;
}


1;
