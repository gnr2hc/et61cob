#### TEST CASE MODULE
package TC_EDID_Switch_VaryingStates;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS_EDID_GenericEDIDList>
#TS version in DOORS: <1.1>
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use LIFT_crash_simulation;
use LIFT_PD;
use GENERIC_DCOM;
use LIFT_can_access;
use LIFT_labcar;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use FuncLib_SYC_INTERFACE;
use FuncLib_EDR_Framework;

##################################

our $PURPOSE = "<This TestScript Validates SwitchRelated EDIDs with Different Switchstaes for Multievent crashes by varying switch staet between the crashes>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDID_Switch_VaryingStates

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Set the <Switch> to <SwitchState1>

2. Wait for 1 second

3. Inject a MultiEvent Crash <Crashcode>

4. Change the <Switch> to  <SwitchState2> at <WaitTime_ms> before <CrashTimeZero_ms_Event2> of event 2

5. Read <EDID> value corresponding to <Switch> state in EDR1.

6.  Read <EDID> value corresponding to <Switch> state in EDR2.


I<B<Evaluation>>

1. -

2. -

3. -

4. -

5. <EDID> should report the value <SwitchState_Value1> in EDR

6. <EDID> should report the value <SwitchState_Value2> in EDR


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'CrashCode' => 
	SCALAR 'CrashTimeZero_ms_Event1' => 
	SCALAR 'CrashTimeZero_ms_Event2' => 
	SCALAR 'WaitTime_ms' => 
	SCALAR 'SwitchState_Value1' => 
	SCALAR 'purpose' => 
	SCALAR 'Switch' => 
	SCALAR 'SwitchState1' => 
	SCALAR 'SwitchState2' => 
	SCALAR 'EDID' => 
	SCALAR 'NHTSA_Table' => 
	SCALAR 'DiagType' => 
	SCALAR 'SwitchState_Value2' => 


=head2 PARAMETER EXAMPLES

	purpose		 = 'Validate SWITCH states for all Switches by varying switch states incase of Multitevents'
	
	Switch = '<Test Heading 1>'
	SwitchState1 = 'PositionA'
	SwitchState2 = 'PositionB'
	EDID = '<Fetch {EDID}>'
	NHTSA_Table = '<Fetch {From}>'
	DiagType  = 'ProdDiag' 
	SwitchState_Value2 = '00' #Oldest in next record
	CrashCode = 'Multi_EDR_Front_AD_Side_AD;1'
	CrashTimeZero_ms_Event1 = '11.76'#msec
	CrashTimeZero_ms_Event2 = '4839.26'#msec
	WaitTime_ms = '0'
	SwitchState_Value1 = '00' #Most Recent first

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_EDID;
my $tcpar_DiagType;
my $tcpar_Switch;
my $tcpar_ResultDB;
my $tcpar_Crashcode;
my $tcpar_WaitTime_ms;
my $tcpar_COMsignalsAfterCrash;
my $T0ofEvent1_ms;
my $T0ofEvent2_ms;
my $tcpar_SwitchState1;
my $tcpar_SwitchState2;
my $detectedSwitchState;
my $tcpar_SwitchState_Value1;
my $tcpar_SwitchState_Value2;
my $tcpar_SwitchType;
my $tcpar_read_NHTSAEDR;
my $tcpar_read_CHINAEDR;

################ global parameter declaration ###################
#add any global variables here
my $record_handler;
my $crashSettings;
my $edrNumberOfEventsToBeStored;
my $crashLabel;
my $ChinaEDR_diagType;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose            = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_Switch             = S_read_mandatory_testcase_parameter('Switch');
	$tcpar_ResultDB           = S_read_mandatory_testcase_parameter('ResultDB');
	$tcpar_SwitchState1       = S_read_mandatory_testcase_parameter('SwitchState1');
	$tcpar_SwitchState2       = S_read_mandatory_testcase_parameter('SwitchState2');
	$tcpar_EDID               = S_read_mandatory_testcase_parameter('EDID');
	$tcpar_DiagType           = S_read_mandatory_testcase_parameter('DiagType');
	$tcpar_Crashcode          = S_read_mandatory_testcase_parameter('Crashcode');
	$T0ofEvent1_ms            = S_read_mandatory_testcase_parameter('CrashTimeZero_ms_Event1');
	$T0ofEvent2_ms            = S_read_mandatory_testcase_parameter('CrashTimeZero_ms_Event2');
	$tcpar_WaitTime_ms        = S_read_mandatory_testcase_parameter('WaitTime_ms');
	$tcpar_SwitchState_Value1 = S_read_mandatory_testcase_parameter('SwitchState_Value1');
	$tcpar_SwitchState_Value2 = S_read_mandatory_testcase_parameter('SwitchState_Value2');
	$tcpar_SwitchType         = S_read_optional_testcase_parameter('SwitchType');
	$tcpar_read_NHTSAEDR      = S_read_optional_testcase_parameter('read_NHTSAEDR');
	$tcpar_read_CHINAEDR      = S_read_optional_testcase_parameter('read_CHINAEDR');
	if ( not defined $tcpar_SwitchType ) {
		$tcpar_SwitchType = 'res\hall';
	}

	if ( not defined $tcpar_read_CHINAEDR ) {
		$tcpar_read_NHTSAEDR = 'yes';
		$tcpar_read_CHINAEDR = 'no';
	}
	else {
		$tcpar_read_NHTSAEDR = 'no';
		my $storageOrder = EDR_getStorageOrder();
		return unless ( defined $storageOrder );

		if ( $storageOrder eq 'PhysicalOrder' ) {
			$ChinaEDR_diagType = 'ProdDiag';    #In platform NHTSA and China EDR is read via proddiag
		}
		else {
			$ChinaEDR_diagType = 'CHINA_Payload';
		}
	}

	$crashLabel = $tcpar_Crashcode . "_" . $tcpar_Switch . "_" . $tcpar_SwitchState1 . "_" . $tcpar_SwitchState2;

	return 1;
}

sub TC_initialization {

	S_w2rep( "StandardPrepNoFault", 'AUTO_NBR' );

	S_w2rep("Initialize Record Handler");
	$record_handler = EDR_init_RecordHandler();

	S_w2log( 1, "Power on ECU" );
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	S_w2log( 1, "Initialize CD and start CAN trace" );
	GDCOM_init();    # To fetch info for CD from mapping_diag
	CA_trace_start();

	S_w2log( 1, "Clear crash recorder" );
	PD_ClearCrashRecorder();
	S_wait_ms(6000);

	S_w2log( 1, "Clear fault memory" );
	PD_ClearFaultMemory();
	S_wait_ms(2000);

	S_w2log( 1, "Read and evaluate fault memory before stimulation" );
	my $faultsBeforeStimulation = PD_ReadFaultMemory();
	my $faultsVerdict = PD_evaluate_faults( $faultsBeforeStimulation, [] );
	return 0 unless ( $faultsVerdict eq 'VERDICT_PASS' );

	PD_ECUreset();
	S_wait_ms('TIMER_ECU_READY');

	#checking whether switch is configured or not
	my ( $result, $configured ) = SYC_SWITCH_get_Configured($tcpar_Switch);
	S_w2rep("Switch configuration state: $configured");
	if ( $configured !~ /yes/ ) {
		S_set_warning(" Switch $tcpar_Switch is not configured in the software , Check the configuration through PS diag");
		my ( $Real, $Monitored_ID, $Prog ) = PD_get_device_config($tcpar_Switch);
		S_w2rep("Real bit is $Real, monitored bit is $Monitored_ID,programmed bit is $Prog");
		if ( $Prog == 0 ) {
			S_set_error( " Switch $tcpar_Switch is not configured either in SYC or in PS diag " . "Dont Perfom this testcase as this is not applicable for the varient" );
			return 0;
		}
	}

	if ( $tcpar_SwitchState1 and $tcpar_SwitchState2 !~ /PositionA|PositionB/ ) {
		S_set_error( "Switch states $tcpar_SwitchState1 or $tcpar_SwitchState2 is not PositionA or  PositionB" . "Change the switch States to PositionA or  PositionB to fetch from SYC" );
		return 0;
	}

	#--------------------------------------------------------------
	# CRASH PREPARATION
	S_w2log( 1, "Prepare crash" );

	# PREPARE CRASH AND INITIALIZE EQUIPMENT
	S_w2rep("Get crash settings for crash $tcpar_Crashcode");
	my $crashDetails_href = { "RESULTDB" => $tcpar_ResultDB, 'CRASHNAME' => $tcpar_Crashcode };
	$crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
	unless ( defined $crashSettings ) {
		S_set_error("Crash $tcpar_Crashcode not available in result DB $tcpar_ResultDB. Test case aborted.");
		return;
	}

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log( 1, "Crashcode: $tcpar_Crashcode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)" );
	S_w2log( 1, "Set environments for crash as per result DB" );
	CSI_PrepareEnvironment( $crashSettings, 'init_complete' );

	#--------------------------------------------------------------
	# CRASH PREPARATION
	#
	S_teststep( "Prepare crash", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	# Prepare crash
	CSI_LoadCrashSensorData2Simulator($crashSettings);

	# Power ON the ECU
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Set the '$tcpar_Switch' to '$tcpar_SwitchState1'", 'AUTO_NBR' );

	#Syc Interface for setting the switch states to PositionA/PositionB

	if ( ( $tcpar_SwitchType !~ /mech/ ) ) {
		my ( $result, $state_value, $state_unit ) = SYC_SWITCH_get_state( $tcpar_Switch, $tcpar_SwitchState1 );
		LC_SetResistance( $tcpar_Switch, $state_value ) if ( $state_unit eq 'R' );
		LC_SetCurrent( $tcpar_Switch, $state_value ) if ( $state_unit eq 'I' );
	}
	elsif ( $tcpar_SwitchType =~ /mech/ ) {
		if ( $tcpar_SwitchState1 eq 'PositionA' ) {
			LC_ConnectLine($tcpar_Switch);
		}
		elsif ( $tcpar_SwitchState1 eq 'PositionB' ) {
			LC_DisconnectLine($tcpar_Switch);
		}

	}
	else {
		S_set_error( "Switch $tcpar_Switch is not set to $tcpar_SwitchState1\n" . "Check switch state in SYC or in TS" );
		return;
	}

	# Wait for 1 second till till switch state is changed
	S_teststep( "Wait for 1.5 seconds", 'AUTO_NBR' );
	S_wait_ms(1500);
	
	CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    S_wait_ms(1000);

	S_teststep( "Inject a MultiEvent Crash '$tcpar_Crashcode'", 'AUTO_NBR' );
	CSI_TriggerCrash();

	S_teststep( "Change the '$tcpar_Switch' to  '$tcpar_SwitchState2' at '$tcpar_WaitTime_ms' before '$T0ofEvent2_ms' of event 2", 'AUTO_NBR' );
	my $waitTimeAfterCrash = $T0ofEvent2_ms - $tcpar_WaitTime_ms;

	#wait time after first event to change the switch state before T0 of second event
	S_wait_ms($waitTimeAfterCrash);

	#Syc Interface for PositionA, PositionB,
	if ( ( $tcpar_SwitchType !~ /mech/ ) ) {
		my ( $result, $state_value, $state_unit ) = SYC_SWITCH_get_state( $tcpar_Switch, $tcpar_SwitchState2 );
		LC_SetResistance( $tcpar_Switch, $state_value ) if ( $state_unit eq 'R' );
		LC_SetCurrent( $tcpar_Switch, $state_value ) if ( $state_unit eq 'I' );
	}
	elsif ( $tcpar_SwitchType =~ /mech/ ) {
		if ( $tcpar_SwitchState2 eq 'PositionA' ) {
			LC_ConnectLine($tcpar_Switch);
		}
		elsif ( $tcpar_SwitchState2 eq 'PositionB' ) {
			LC_DisconnectLine($tcpar_Switch);
		}

	}
	else {
		S_set_error( "Switch $tcpar_Switch is not set to $tcpar_SwitchState2\n" . "Check switch state in SYC or in TS" );
		return;
	}

	if ( defined $tcpar_COMsignalsAfterCrash ) {
		foreach my $signal ( keys %{$tcpar_COMsignalsAfterCrash} ) {
			my $dataOnCOM = $tcpar_COMsignalsAfterCrash->{$signal};
			S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
			COM_setSignalState( $signal, $dataOnCOM );
		}
	}

	# wait time after crash
	S_wait_ms(15000);

	S_w2rep("Read fault memory after crash");
	PD_ReadFaultMemory();

	S_teststep( "Read '$tcpar_EDID' value corresponding to '$tcpar_Switch' state in all Records.", 'AUTO_NBR' );    #measurement

	my $dataStoragePath = "$main::REPORT_PATH/" . S_get_TC_number() . "_" . $tcpar_Crashcode;

	# Edr records
	$edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();

	unless ( defined $edrNumberOfEventsToBeStored ) {
		S_set_error("Number of records to be stored in EDR not available in SYC - add or overwrite with Custlibrary Function");
		return;
	}

	S_w2rep("Read and store all available records ($edrNumberOfEventsToBeStored records)");
	if ( lc($tcpar_read_NHTSAEDR) eq 'yes' ) {
		EDR_ReadAndStoreAllRecords(
			"DiagType"     => $tcpar_DiagType,
			"CrashLabel"   => $crashLabel,
			"NbrOfRecords" => $edrNumberOfEventsToBeStored,
			"StoragePath"  => $dataStoragePath,
			"read_EDRType" => 'NHTSA'
		);
	}
	if ( lc($tcpar_read_CHINAEDR) eq 'yes' ) {
		$edrNumberOfEventsToBeStored = 3;
		EDR_ReadAndStoreAllRecords(
			"DiagType"     => $ChinaEDR_diagType,
			"CrashLabel"   => $crashLabel,
			"NbrOfRecords" => $edrNumberOfEventsToBeStored,
			"StoragePath"  => $dataStoragePath,
			"read_EDRType" => 'CHINA'
		);
	}

	return 1;
}

sub TC_evaluation {

	my $storageOrder = EDR_getStorageOrder();
	return unless ( defined $storageOrder );

	if ( $storageOrder eq 'PhysicalOrder' ) {
		$storageOrder = 'MostRecentLast';    #same behavior as there is no overwriting
	}

	my $expectedSwitchstate;
	$expectedSwitchstate = { "Record_1" => $tcpar_SwitchState_Value1, "Record_2" => $tcpar_SwitchState_Value2 } if ( $storageOrder eq 'MostRecentLast' );
	$expectedSwitchstate = { "Record_1" => $tcpar_SwitchState_Value2, "Record_2" => $tcpar_SwitchState_Value1 } if ( $storageOrder eq 'MostRecentFirst' );

	my $dataElement = $record_handler->GetDataElementEDID(
		"EDIDnr"       => $tcpar_EDID,
		"RecordNumber" => 1,
		"CrashLabel"   => $crashLabel,
	);

	foreach my $recordNbr ( 1 .. 2 ) {
		S_teststep( "Validate EDID $tcpar_EDID ($dataElement) in record $recordNbr", 'AUTO_NBR', "Record_$recordNbr" );
		$detectedSwitchState = $record_handler->GetRawEDID(
			"EDIDnr"       => $tcpar_EDID,
			"RecordNumber" => $recordNbr,
			"CrashLabel"   => $crashLabel,
			"FormatOption" => "HEX"
		);
		unless ( defined $detectedSwitchState ) {
			S_w2rep("No EDID data found for crash $tcpar_Crashcode, record $recordNbr. EDID cannot not be evaluated. Go to next record");
			next;
		}

		if ( ref($detectedSwitchState) eq 'ARRAY' ) {
			my $detectedSwitchStateString;
			foreach my $element ( @{$detectedSwitchState} ) {
				$detectedSwitchStateString .= $element;
			}
			$detectedSwitchState = "0b" . $detectedSwitchStateString;
		}
		else {
			$detectedSwitchState = "0x" . $detectedSwitchState;
		}

		my $expectedswitchstateforrecord = $expectedSwitchstate->{"Record_$recordNbr"};
		S_w2rep( "EDID return value = $detectedSwitchState ", 'green' );
		S_teststep_expected( "Expected switch state for EDID in EDR Record '$recordNbr' is '$expectedswitchstateforrecord'", "Record_$recordNbr" );    #evaluation
		S_teststep_detected( "Detected switch state for EDID in EDR Record '$recordNbr' is '$detectedSwitchState'", "Record_$recordNbr" );
		S_w2rep("Compare expected and detected values");
		my $verdict = EVAL_evaluate_value( "EDID_$tcpar_EDID\_Evaluation", $detectedSwitchState, '==', $expectedswitchstateforrecord );
	}
	return 1;
}

sub TC_finalization {
	S_w2rep("Start test case finalization");

	#Delete Record Handler
	foreach my $recordNbr ( 1 .. $edrNumberOfEventsToBeStored ) {
		$record_handler->DeleteRecord( "CrashLabel" => $crashLabel, "RecordNumber" => $recordNbr );
	}

	#--------------------------------------------------------------------------------------------------------
	# Remove the Condition which is created in the test case
	S_w2rep(" Reset Device state for Switch $tcpar_Switch to Default State ");
	my $default_condition;
	if ( $tcpar_SwitchState1 or $tcpar_SwitchState2 = /PositionA|PositionB/ ) {
		my ( $resultDefaultCondition, $default_condition ) = SYC_SWITCH_get_DefaultCondition($tcpar_Switch);
		my ( $result, $state_value, $state_unit ) = SYC_SWITCH_get_state( $tcpar_Switch, $default_condition );
		if ( $tcpar_SwitchType =~ /mech/ ) {
			if ( $default_condition eq 'PositionA' ) {
				LC_ConnectLine($tcpar_Switch);
			}
			elsif ( $default_condition eq 'PositionB' ) {
				LC_DisconnectLine($tcpar_Switch);
			}
		}
		else {
			LC_SetResistance( $tcpar_Switch, $state_value ) if ( $state_unit eq 'R' );
			LC_SetCurrent( $tcpar_Switch, $state_value ) if ( $state_unit eq 'I' );
		}
	}
	else {
		S_set_error(" Switch $tcpar_Switch is not set to its Default state ");
		return;
	}
	S_wait_ms('8000');

	#--------------------------------------------------------------------------------------------------------

	#Clearing crash recorder
	PD_ClearCrashRecorder();
	S_wait_ms(6000);

	#Erase Fault memory
	PD_ClearFaultMemory();
	S_wait_ms(2000);

	# Reset ECU
	PD_ECUreset();
	S_wait_ms('TIMER_ECU_READY');

	#Read fault memory after clearing and erasing EDR
	PD_ReadFaultMemory();

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}

1;
