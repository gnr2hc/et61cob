#### TEST CASE MODULE
package TC_EDID_Disposal_Validation;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general;
use LIFT_evaluation;
use File::Basename;
use Data::Dumper;
use FuncLib_EDR_Framework;
##################################
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_FireTime_Validation  $Revision: 1.3 $

requires previous crash injection
   with storage of fire times and EDR records in
   Crash / Record handler
   e.g. use TC_EDR_CrashInjection.pm (ONLINE)
   or TC_EDR_CrashDataRetrieval.pm (OFFLINE)

TC does not require any equipment - only previously
   obtained data will be used

=head1 PURPOSE

to validate deployment times stored in EDR

=head1 TESTCASE DESCRIPTION 

    [initialisation]
    initialize record handler

    [stimulation & measurement]
	not needed

    [evaluation]
    1. get list of stored records
    2. evaluate fire time of squib xy for each stored record

    [finalisation]
    not needed

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

	SquibLabel --> Label of squib to be evaluated
	EDID --> EDID number of squib to be evaluated
	Crashcode --> Crash code for which to validate disposal EDID
	DeploymentType --> type of squib deployment: 'None', 'Disposal', 'Regular'
  	

=head2 PARAMETER EXAMPLES

    [TC_EDID_Disposal_Validation.AB1FD]
	# From here on: applicable Lift Default Parameters
	SquibLabel = 'AB2FD'
	Crashcode = 'Single_EDR_Front_Inflatable_Stage1'
	EDID = 54
	DeploymentType = 'Disposal' #msec

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_EDIDNbr;
my $tcpar_SquibLabel;
my $tcpar_Crashcode;
my $tcpar_purpose;
my $tcpar_DeploymentType;
my $tcpar_ExpectedValue;

################ global parameter declaration ###################
#add any global variables here
my(
    $record_handler,
    $crash_handler,
);

my $expectedValue_Default = {
	'None'     => 'DataNotAvailable',
	'Regular'  => 'No Disposal',
	'Disposal' => 'Disposal',
};

our $PURPOSE;
our $TC_name = "TC_EDID_FireTimeValidation";

#-------------------------------------------------------------------------------
sub TC_set_parameters {
#-------------------------------------------------------------------------------
    $tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_EDIDNbr = S_read_mandatory_testcase_parameter('EDID');
    $tcpar_SquibLabel = S_read_mandatory_testcase_parameter('SquibLabel');
    $tcpar_Crashcode = S_read_mandatory_testcase_parameter('Crashcode');
    $tcpar_DeploymentType = S_read_mandatory_testcase_parameter('DeploymentType');
    $tcpar_ExpectedValue = S_read_optional_testcase_parameter('ExpectedValue');
    
    if(not defined $tcpar_ExpectedValue){
    	$tcpar_ExpectedValue = $expectedValue_Default -> {$tcpar_DeploymentType};
    	if(not defined $tcpar_ExpectedValue){
            S_set_error("No default expected value for deployment type '$tcpar_DeploymentType' defined.\n".
                       "Supported deployment types: 'None', 'Regular', 'Disposal'");
            return;     	    
    	}
    }
    
	S_add2eval_collection ( 'EDID' , $tcpar_EDIDNbr);
	my $allAttributes = EDR_fetchEDIDallAttributes_by_ID($tcpar_EDIDNbr);
	S_add2eval_collection('EDID From', $allAttributes -> {'From'}) if (defined $allAttributes -> {'From'});

	return 1;
}

#-------------------------------------------------------------------------------
sub TC_initialization {
#-------------------------------------------------------------------------------
	#--------------------------------------------------------------
    # INITIALIZE RECORD AND CRASH HANDLER
    #    
	$record_handler = EDR_init_RecordHandler() || return;
	$crash_handler  = EDR_init_CrashHandler() || return;

    return 1;
}

#-------------------------------------------------------------------------------
sub TC_stimulation_and_measurement {
#-------------------------------------------------------------------------------
	S_w2rep("No stimulation needed.");

    return 1;
}

#-------------------------------------------------------------------------------
sub TC_evaluation {
#-------------------------------------------------------------------------------
	my $fireTimeValidationResult_href;
	my $storedCrashLabels_aref = $record_handler -> GetListOfStoredRecords();
	my $recordAvailable = $record_handler -> IsRecordAvailable("CrashLabel" => $tcpar_Crashcode, "RecordNumber" => 1 );
	
	unless($recordAvailable) {
		S_set_error("Crash '$tcpar_Crashcode' must be injected previously with TC_EDR_CrashInjection!")unless ($main::opt_offline);
		return;
	}
	
	my $crashCode_MDS = $crash_handler -> GetSourceDataValues ( "SourceLabel" => "CrashCode_MDS", "CrashLabel"  => $tcpar_Crashcode );
	$crashCode_MDS = $crashCode_MDS -> {"DataValues"};

	my $path_MDB = $crash_handler -> GetSourceDataValues ( "SourceLabel" => "MDB_Path", "CrashLabel"  => $tcpar_Crashcode );
	$path_MDB = $path_MDB -> {"DataValues"};
		
	S_w2rep("-------------------------------------------------------------");
    S_teststep("Validation of disposal for squib $tcpar_SquibLabel, crash $tcpar_Crashcode, record 1", 'AUTO_NBR', "DisposalTime_1\_Crash_$tcpar_Crashcode");
	S_w2log(1, "Crash code: $crashCode_MDS");
	S_w2log(1, "Result DB path: $path_MDB");
	S_w2rep("-------------------------------------------------------------");
	#--------------------------------------------------------------
    # GET CRASH TIME ZERO
	#    
	my $crashTimeZero = $crash_handler -> GetSourceDataValues ( "SourceLabel" => "CrashTimeZero",
														        "CrashLabel"  => $tcpar_Crashcode );
	unless(defined $crashTimeZero) {
		S_set_error("No crash time zero stored for crash $tcpar_Crashcode. No evaluation of fire times possible. Try next crash.", 110)unless ($main::opt_offline);
		next;
	}

	my $crashTimeZero_ms = $crashTimeZero -> {"DataValues"};
	my $crashTimeZeroUnit = $crashTimeZero -> {"DataUnit"};
	if($crashTimeZeroUnit ne "ms") {
		S_set_error("Crash Time zero must be stored in ms!! Go to next crash.", 110);
        return;
	}

    my $decodedEDID_href = $record_handler -> GetDecodedEDID("CrashLabel" => $tcpar_Crashcode, "RecordNumber" => 1, "EDIDnr" => $tcpar_EDIDNbr);
    unless($decodedEDID_href){
    	S_set_error("No data could be obtained for EDID $tcpar_EDIDNbr. No evaluation possible")unless ($main::opt_offline);
    	return;
    }
    
    my $detected = $decodedEDID_href -> {'DataValue'};

	S_teststep_expected("$tcpar_ExpectedValue", "DisposalTime_1\_Crash_$tcpar_Crashcode"); #evaluation 1
	S_teststep_detected("$detected", "DisposalTime_1\_Crash_$tcpar_Crashcode");

    EVAL_evaluate_string("EDID_$tcpar_EDIDNbr", $tcpar_ExpectedValue, $detected);	
    return 1;
}


#-------------------------------------------------------------------------------------------------------------------
###
# Internal functions
###

1;