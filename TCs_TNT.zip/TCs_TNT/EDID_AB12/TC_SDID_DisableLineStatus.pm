#### TEST CASE MODULE
package TC_SDID_DisableLineStatus;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS_EDR_EDIDList_SupplierData> 
#TS version in DOORS: <0.22> 
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use INCLUDES_Project;
use LIFT_PD;
use LIFT_can_access;
use GENERIC_DCOM;
use LIFT_labcar;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use LIFT_crash_simulation;
use LIFT_FaultMemory;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;
use Data::Dumper;

#necessary
#include further modules here
##################################

our $PURPOSE = "<This scripts validates Disable Line Status  recorded in EDR for different crash scenarios>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SDID_DisableLineStatus

=head1 PURPOSE

<This scripts validates Disable Line Status  recorded in EDR for different crash scenarios>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Power on  ECU and Inject <Crashcode>

2.Wait for <WaitTime_ms> 

3. Read <SDID>  in the latest entry of EDR through PD


I<B<Evaluation>>

1.

2. 

3. <SDID should report the value equal to the value <Expected_Value_RawHex_Incident1>in the latest entry of EDR  and  <Expected_Value_RawHex_Incident2> in the older recored.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Expected_Value_RawHex_Incident1' => Expected value for the EDIDs in first record i.e most recent record
	SCALAR 'purpose' => This scripts validates the Algo sections update,Event Directions,Event Severity,Multi event Number reported in EDR for different crash scenarios
	SCALAR 'SDID' => Unique Supplier EDID ID.
	SCALAR 'Data_Element' => Data element name of the SDID.
	SCALAR 'WaitTime_ms' => wait time.
	SCALAR 'Crashcode' => The crash file to be injected.
	SCALAR 'Expected_Value_RawHex_Incident2' => Expected value for the EDIDs in second record i.e old record
	


=head2 PARAMETER EXAMPLES

	purpose	 = 'To validate the Algo sections update,Event Directions,Event Severity,Multi event Number reported in EDR '
	
	SDID= '5500_254'
	WaitTime_ms=6000 #ms
	Crashcode='<Test Heading>'
	Expected_Value_RawHex_Incident2='none'
	DiagType  = 'ProdDiag' 
	ResultDB = 'EDR'
	COMsignalsAfterCrash = %()
	Expected_Value_RawHex_Incident1 ='0x00'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_SDID;
my $tcpar_Crashcode;
my $tcpar_DiagType;
my $tcpar_ResultDB;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_EDIDNr_Supplier;
my $tcpar_CrashTimeZero_ms;
my $tcpar_CrashTimeEnd_ms;
my $tcpar_CrashTimeZero_Event2_ms;
my $tcpar_CrashTimeEnd_Event2_ms;
my $tcpar_Condition;
my $tcpar_Algo_Variable_DisableLineStatus;
my $tcpar_FD_Variables_aref;
my $tcpar_FD_VariablesTypes_aref;

################ global parameter declaration ###################
my $record_handler;
my $tcpar_EDID;
my $edrNumberOfEventsToBeStored;
my $crashSettings;
my $disableLineStatus_SOE;
my $disableLineStatus_EOE;
my $disableLineStatus_Event2_SOE;
my $disableLineStatus_Event2_EOE;
my $recordNbr;
my $numberOfDetectedRecords = 0;
#add any global variables here


###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_SDID =  S_read_mandatory_testcase_parameter( 'SDID' );
	$tcpar_EDIDNr_Supplier =  S_read_optional_testcase_parameter( 'EDIDNr_Supplier');
	$tcpar_Crashcode =  S_read_mandatory_testcase_parameter( 'Crashcode' );
	$tcpar_DiagType =  S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_ResultDB =  S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_COMsignalsAfterCrash =  S_read_mandatory_testcase_parameter( 'COMsignalsAfterCrash','byref');
	$tcpar_CrashTimeZero_ms = S_read_mandatory_testcase_parameter('CrashTimeZero_ms');
	$tcpar_CrashTimeEnd_ms = S_read_mandatory_testcase_parameter('CrashTimeEnd_ms');
	$tcpar_CrashTimeZero_Event2_ms = S_read_optional_testcase_parameter('CrashTimeZero_Event2_ms');
	$tcpar_CrashTimeEnd_Event2_ms = S_read_optional_testcase_parameter('CrashTimeEnd_Event2_ms');
	$tcpar_Condition = S_read_mandatory_testcase_parameter('Condition');
	$tcpar_Algo_Variable_DisableLineStatus =  S_read_mandatory_testcase_parameter('Algo_Variable_DisableLineStatus');
	$tcpar_EDIDNr_Supplier =  S_read_optional_testcase_parameter( 'EDIDNr_Supplier');
    $tcpar_FD_Variables_aref = S_read_optional_testcase_parameter( 'FD_Variables', 'byref');
    if($tcpar_FD_Variables_aref){
        $tcpar_FD_VariablesTypes_aref = S_read_mandatory_testcase_parameter( 'FD_Variables_Types', 'byref');    
    }
	$tcpar_EDID = EDR_Convert_SDID_To_Integer ($tcpar_SDID);
	if(not defined $tcpar_EDID){
		S_w2rep("Converting DOORS SDID to integer was not successful. Test case can't be performed.");
		return;
	}
	if(not defined $tcpar_EDIDNr_Supplier){
		S_w2rep("Setting the Supplier EDID number as 999 by default");
		$tcpar_EDIDNr_Supplier = 999; 
	}
	return 1;
}
sub TC_initialization {
	#--------------------------------------------------------------
    # INITIALIZE RECORD HANDLER
    #--------------------------------------------------------------    
	S_w2log(1,"Initialize Record Handler");
	$record_handler = EDR_init_RecordHandler() || return;


	#--------------------------------------------------------------
    # CRASH PREPARATION
	S_w2log(1, "Prepare crash" );

	# PREPARE CRASH AND INITIALIZE EQUIPMENT
	S_w2rep("Get crash settings for crash $tcpar_Crashcode");
	my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode};
	$crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
	if(not defined $crashSettings and not $main::opt_offline) {
		S_set_error("Crash code $tcpar_Crashcode not defined in given result DB. Test case will be aborted.", 110);
		return;
	}
	if( $main::opt_offline) {
		$crashSettings -> { 'CRASHNAME' } = $tcpar_Crashcode;
	}

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log(1, "Crashcode: $tcpar_Crashcode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");
	
	
	S_w2log(1, "Power on ECU");
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

    S_w2log(1, "Initialize CD and start CAN trace");
    GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start();

	
	S_w2log(1, "Set environments for crash as per result DB");
	CSI_PrepareEnvironment($crashSettings,'init_complete');
	S_wait_ms('TIMER_ECU_READY');
	
	S_w2log(1, "Clear crash recorder");
    PD_ClearCrashRecorder();
    S_wait_ms(2000);

	S_w2log(1, "Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	S_w2log(1, "Reset ECU");
    PD_ECUreset();
    S_wait_ms('TIMER_ECU_READY');

	S_w2log(1, "Read and evaluate fault memory before stimulation");
    my $faultsBeforeStimulation_obj = LIFT_FaultMemory -> read_fault_memory('Bosch');
    my $faultsVerdict = $faultsBeforeStimulation_obj -> evaluate_faults({});
    return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

    S_w2log(1, "Download crash sensor data to simulator");
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_READY');

	#Prepare crash
	CSI_LoadCrashSensorData2Simulator( $crashSettings );

	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	return 1;
}

sub TC_stimulation_and_measurement {

    # Get number of records to be stored
	$edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();
	unless(defined $edrNumberOfEventsToBeStored){
		S_set_error("Number of records to be stored in EDR not available in SYC - add or overwrite with Custlibrary Function");
		return;
	}
	
	
	# Check whether PD variable is available
	S_teststep("Read variable '$tcpar_Algo_Variable_DisableLineStatus' to get expected value", 'AUTO_NBR', 'read_pd_var_disLine');
	my $result_VariableAvailable_aref = PD_ReadMemoryByName_NOERROR( $tcpar_Algo_Variable_DisableLineStatus );
	if(not defined $result_VariableAvailable_aref){
		S_set_verdict('VERDICT_FAIL');
		S_teststep_expected("Variable '$tcpar_Algo_Variable_DisableLineStatus' present in SAD file", 'read_pd_var_disLine');
		S_teststep_detected("Variable '$tcpar_Algo_Variable_DisableLineStatus' can't be read with PD", 'read_pd_var_disLine');
		return;
	}
	if(scalar(@{$result_VariableAvailable_aref}) < 1){
		S_set_verdict('VERDICT_FAIL');
		S_teststep_expected("Variable '$tcpar_Algo_Variable_DisableLineStatus' present in SAD file", 'read_pd_var_disLine');
		S_teststep_detected("Variable '$tcpar_Algo_Variable_DisableLineStatus' can't be read with PD", 'read_pd_var_disLine');
        return;
	}
	
	my $tcpar_CrashTimeEnd_actual_ms = ($tcpar_CrashTimeEnd_ms - $tcpar_CrashTimeZero_ms);

    my ($tcpar_CrashTimeZero_Event2_actual_ms,$tcpar_CrashTimeEnd_Event2_actual_ms);
	if (defined $tcpar_CrashTimeZero_Event2_ms and $tcpar_CrashTimeEnd_Event2_ms){
    	$tcpar_CrashTimeZero_Event2_actual_ms =($tcpar_CrashTimeZero_Event2_ms - $tcpar_CrashTimeEnd_ms );
    	$tcpar_CrashTimeEnd_Event2_actual_ms = ($tcpar_CrashTimeEnd_Event2_ms - $tcpar_CrashTimeZero_Event2_ms);
	}

    #--------------------------------------------------------------
    # CRASH INJECTION
    #---------------------------------------------------------------
	#######################
	CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    S_wait_ms(1000);
    
	my $fastDiag;
    if($tcpar_FD_Variables_aref){
        my @fd_variable_shifts;
        foreach my $fd_variable (@{$tcpar_FD_Variables_aref})
        {
            push @fd_variable_shifts, 0;           
        }
        $fastDiag = PD_StartFastDiagName( "$main::REPORT_PATH/".S_get_TC_number()."__FastDiagMeasurement" , $tcpar_FD_Variables_aref , $tcpar_FD_VariablesTypes_aref , \@fd_variable_shifts, 4);    
    }
	#########################
	S_teststep("Inject '$tcpar_Crashcode' and note down the Value of '$tcpar_Algo_Variable_DisableLineStatus' at T0 and Tend " , 'AUTO_NBR');
    S_teststep_2nd_level("Trigger crash '$tcpar_Crashcode'" , 'AUTO_NBR');
	CSI_TriggerCrash();

    S_teststep_2nd_level("Wait $tcpar_CrashTimeZero_ms ms and read '$tcpar_Algo_Variable_DisableLineStatus' at T0 of event 1" , 'AUTO_NBR');
	S_wait_ms($tcpar_CrashTimeZero_ms);
	$disableLineStatus_SOE = S_aref2dec(PD_ReadMemoryByName_NOERROR( $tcpar_Algo_Variable_DisableLineStatus ) ,U8 );

    S_teststep_2nd_level("Wait $tcpar_CrashTimeEnd_actual_ms ms and read '$tcpar_Algo_Variable_DisableLineStatus' at Tend of event 1" , 'AUTO_NBR');
	S_wait_ms($tcpar_CrashTimeEnd_actual_ms);
	$disableLineStatus_EOE = S_aref2dec(PD_ReadMemoryByName_NOERROR( $tcpar_Algo_Variable_DisableLineStatus ) ,U8 );

	if (defined $tcpar_CrashTimeZero_Event2_ms and $tcpar_CrashTimeEnd_Event2_ms){
        S_teststep_2nd_level("Wait $tcpar_CrashTimeZero_ms ms and read '$tcpar_Algo_Variable_DisableLineStatus' at T0 of event 2" , 'AUTO_NBR');
    	S_wait_ms($tcpar_CrashTimeZero_Event2_actual_ms);
    	$disableLineStatus_Event2_SOE = S_aref2dec(PD_ReadMemoryByName_NOERROR( $tcpar_Algo_Variable_DisableLineStatus ) ,U8 );

        S_teststep_2nd_level("Wait $tcpar_CrashTimeEnd_actual_ms ms and read '$tcpar_Algo_Variable_DisableLineStatus' at Tend of event 2" , 'AUTO_NBR');
    	S_wait_ms($tcpar_CrashTimeEnd_Event2_actual_ms);
    	$disableLineStatus_Event2_EOE = S_aref2dec(PD_ReadMemoryByName_NOERROR( $tcpar_Algo_Variable_DisableLineStatus ) ,U8 );
	}

    S_teststep("Wait 10 seconds until EDR is stored", 'AUTO_NBR');
	S_wait_ms(10000);
	##################
	if($tcpar_FD_Variables_aref and $fastDiag){
	    PD_StopFastDiag();
    }
	################
	if (defined $tcpar_COMsignalsAfterCrash){
        S_w2log(1, "Send post crash COM signals");
    	foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash}){
    		my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
    		S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
    		COM_setSignalState($signal,$dataOnCOM);
		}
	}

	S_teststep("Read EDR record for crash combination $tcpar_Crashcode", 'AUTO_NBR');
	S_teststep_2nd_level("Read and print all EDR data", 'AUTO_NBR');
	my $dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_".$tcpar_Crashcode;
	$tcpar_Crashcode = $tcpar_Crashcode."_DisableLine";
	PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');
	EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
							 	"CrashLabel" => $tcpar_Crashcode,
							 	"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
							 	"StoragePath" => $dataStoragePath,
							 	);
	# add supplier section
	############################
	S_teststep_2nd_level("Extract and parse supplier data", 'AUTO_NBR');
	my $recordStructureSupplier_href = EDR_ReadEDR_Record_structure_info_from_mapping_NOERROR('Supplier',0,'Mapping_EDR','SUPPLIER_EDIDS');
	if(not defined $recordStructureSupplier_href){
        S_set_warning("Supplier EDID section is not available in EDR mapping.\n".
        "Generate mapping newly with this section if the EDID to be evaluated is part of Supplier section");
        return 1;
    }
	
	foreach my $recordNbr (1..$edrNumberOfEventsToBeStored)
	{
		my $recordAvailable = $record_handler -> IsRecordAvailable("CrashLabel" => $tcpar_Crashcode, "RecordNumber"=> $recordNbr);
		next unless($recordAvailable);

		$numberOfDetectedRecords ++;

		my $recordData_aref = $record_handler -> GetRawEDID( "EDIDnr" => $tcpar_EDIDNr_Supplier,
															"RecordNumber" => $recordNbr,
															"CrashLabel" => $tcpar_Crashcode,);

		$record_handler -> AddCrashRecord(  "RecordNumber" => $recordNbr,
											"CrashLabel"   => $tcpar_Crashcode.'_Supplier',
											"RecordStructureInfo" => $recordStructureSupplier_href,
											"RawDataGeneric" => $recordData_aref,);
		$record_handler -> PrintRawEDIDs( "RecordNumber" => $recordNbr,
											"CrashLabel" => $tcpar_Crashcode.'_Supplier',);
	}
	return 1;
}

sub TC_evaluation {

	my $storageOrder = EDR_getStorageOrder();
	return unless(defined $storageOrder);
	$storageOrder = 'MostRecentLast' if($storageOrder eq 'PhysicalOrder');
	
	if($numberOfDetectedRecords == 0){
		S_set_error("No record stored. Evaluation aborted.");
		return;
	}

	my $expected_EDIDvalue;
	
	if(($numberOfDetectedRecords == 1) and ($tcpar_Condition eq 'SOE')){
		$expected_EDIDvalue = {"Record_1" => $disableLineStatus_SOE};
	}
	elsif(($numberOfDetectedRecords == 1) and ($tcpar_Condition eq 'EOE')){
		$expected_EDIDvalue = {"Record_1" => $disableLineStatus_EOE};
	}
    elsif($tcpar_Condition eq 'SOE'){
		$expected_EDIDvalue  = {"Record_1" => $disableLineStatus_SOE, "Record_2" => $disableLineStatus_Event2_SOE} if($storageOrder eq 'MostRecentLast');
		$expected_EDIDvalue  = {"Record_1" => $disableLineStatus_Event2_SOE, "Record_2" => $disableLineStatus_SOE} if($storageOrder eq 'MostRecentFirst');
    }
	elsif($tcpar_Condition eq 'EOE'){
		$expected_EDIDvalue  = {"Record_1" => $disableLineStatus_EOE, "Record_2" => $disableLineStatus_Event2_EOE} if($storageOrder eq 'MostRecentLast');
		$expected_EDIDvalue  = {"Record_1" => $disableLineStatus_Event2_EOE, "Record_2" => $disableLineStatus_EOE} if($storageOrder eq 'MostRecentFirst');
    }
	else{
		S_set_error("'$tcpar_Condition' should be either 'SOE' or 'EOE'in the test case.");
		return;
	}
	
	
    foreach my $recordNbr (1..$numberOfDetectedRecords)
	{
		my $dataElement = $record_handler -> GetDataElementEDID("EDIDnr" => $tcpar_EDID,
														  "RecordNumber" => $recordNbr,
														  "CrashLabel" => $tcpar_Crashcode.'_Supplier');
		
		
		S_teststep("Validate EDID $tcpar_EDID ($dataElement), record $recordNbr", 'AUTO_NBR', "EDID_$tcpar_EDID\_Record_$recordNbr");
		
		my $detected_EDIDvalue = $record_handler -> GetRawEDID("EDIDnr" => $tcpar_EDID,
													 "RecordNumber" => $recordNbr,
													 "CrashLabel" => $tcpar_Crashcode.'_Supplier',
													 "FormatOption" => "DEC");
		unless(defined $detected_EDIDvalue) {
			S_set_error("No data could be obtained for EDID $tcpar_EDID in record $recordNbr.");
			next;
		}

		if(ref $detected_EDIDvalue eq 'ARRAY') {
			my $detectedEDIDvalueString;
			foreach my $hexElement (@{$detected_EDIDvalue})
			{
				$detectedEDIDvalueString .= $hexElement;
			}
			$detected_EDIDvalue = $detectedEDIDvalueString;
		}
		else{
			$detected_EDIDvalue = $detected_EDIDvalue;
		}
	
		my $expected_EDIDvalueforRecord = $expected_EDIDvalue -> {"Record_$recordNbr"};
        $expected_EDIDvalueforRecord = '1' if ($main::opt_offline); #PD does not return value in offline mode

		S_teststep_detected ("$detected_EDIDvalue","EDID_$tcpar_EDID\_Record_$recordNbr");
		S_teststep_expected ("$expected_EDIDvalueforRecord","EDID_$tcpar_EDID\_Record_$recordNbr");
		EVAL_evaluate_value( "EDID_$tcpar_EDID\_Evaluation", $detected_EDIDvalue, '==' , $expected_EDIDvalueforRecord );
		
	}
	return 1;
}

sub TC_finalization {

    S_w2rep("Start test case finalization...");

	# Erase EDR
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(2000);

	# Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	# Read fault memory after clearing and erasing EDR
    LIFT_FaultMemory -> read_fault_memory('Bosch');

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

	S_w2rep("Clean up record handler");
    foreach my $recordNumber (1..$edrNumberOfEventsToBeStored)
    {
        $record_handler -> DeleteRecord("CrashLabel" => $tcpar_Crashcode, "RecordNumber" => $recordNumber);
        $record_handler -> DeleteRecord("CrashLabel" => $tcpar_Crashcode."_Supplier", "RecordNumber" => $recordNumber);
    }   

	return 1;
}


1;
