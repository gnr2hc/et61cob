#### TEST CASE MODULE
package TC_EDID_SensorFault_Ringbuffer;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_evaluation;
use LIFT_PD;
use LIFT_crash_simulation;
use LIFT_CANoe;
use LIFT_labcar;
use LIFT_QuaTe;
use LIFT_MDSRESULT;
use LIFT_equipment;
use GENERIC_DCOM;
use LIFT_can_access;
use LIFT_flexray_access;
use LIFT_evaluation;
use LIFT_spi_access;
use INCLUDES_Project;
use File::Basename;
use Data::Dumper;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;

##################################

our $PURPOSE = "<Validation of all sensor related data elments in the case of a faulty sensor>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDID_SensorFault_Ringbuffer

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Create fault on sensor <SensorLabel>

2. Inject crash <CrashCode>

3. Read EDR


I<B<Evaluation>>

1. Fault is qualified in fault memory

2. -

3. EDIDs <Affected_EDIDs> should all be reported with the expected value for sensor fault


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	LIST 'Affected_EDIDs' => 
	SCALAR 'Device' => 
	SCALAR 'Channel' => 
	SCALAR 'CrashCode' => 
	SCALAR 'SensorType' => 
	SCALAR 'purpose' => 
	SCALAR 'ExpectedHexValue' => 
	SCALAR 'SensorFault 'rb_xxx'' => 
	HASH 'COMsignalsAfterCrash' => 
	SCALAR 'ResultDB' => 


=head2 PARAMETER EXAMPLES

	purpose = 'To validate RGB data reported in EDR when source sensor is faulty'
	
	ExpectedHexValue = 'FF'
	SensorFault 'rb_xxx'
	COMsignalsAfterCrash = %()
	ResultDB = 'EDR'
	Affected_EDIDs = @('23', '31', '33', '35', '37', '40')
	Device = 'SMA660'
	Channel = 'Acc_HG_M45' # Longitudinal High G
	CrashCode = 'Single_EDR_SideLeft_Inflatable'
	SensorType = 'Internal'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_SensorFault;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_ResultDB;
my $tcpar_ExpectedDecodedValue_EDIDs;
my $tcpar_Device;
my $tcpar_Channel;
my $tcpar_CrashCode;
my $tcpar_SensorType;
my $tcpar_DiagType;
my $tcpar_NbrOfExpectedRecords;
my $tcpar_SpiNode;
my $tcpar_SpiCommand;
my $tcpar_SpiSignal;
my $tcpar_SpiSignalValue;
my $tcpar_ManipulationCycles;

################ global parameter declaration ###################
#add any global variables here
my $internalSensorFaultMapping = {
    'SMA660' => {'Channel0' => 'SPI_SI_CRC',
                 'Channel1' => 'SPI_SO_CRC',},
    'SMA760' => {'Channel0' => 'SPI_SI_CRC',
                 'Channel1' => 'SPI_SO_CRC',},
};
my ($crashDetails_href, $crashSettings, $record_handler, $faultsAfterStimulation, $sensorLabel, $faultKey, $crashInfo_href,
		$skipEval,
		$stimulationTool);

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_SensorFault =  S_read_mandatory_testcase_parameter( 'SensorFaultExpected' );
	$tcpar_COMsignalsAfterCrash =  S_read_mandatory_testcase_parameter( 'COMsignalsAfterCrash', 'byref' );
	$tcpar_ResultDB =  S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_ExpectedDecodedValue_EDIDs =  S_read_mandatory_testcase_parameter( 'ExpectedDecodedValue_EDIDs', 'byref');
	$tcpar_Device =  S_read_mandatory_testcase_parameter( 'Device' );
	$tcpar_CrashCode =  S_read_mandatory_testcase_parameter( 'CrashCode' );
	$tcpar_SensorType =  S_read_mandatory_testcase_parameter( 'SensorType' );
	$tcpar_DiagType = S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_NbrOfExpectedRecords = S_read_mandatory_testcase_parameter('NbrOfExpectedRecords');

    $sensorLabel = $tcpar_Device;
    $sensorLabel .= "::".$tcpar_Channel if (defined $tcpar_Channel);

    my $quateDevice_href = $internalSensorFaultMapping -> {$tcpar_Device};
    if(not defined $quateDevice_href){
    	S_w2log(1, "No fault key for Quate stimulation found. Manitoo stimulation required");
        $tcpar_SpiNode = S_read_mandatory_testcase_parameter( 'SpiNode' );
		$tcpar_SpiCommand = S_read_mandatory_testcase_parameter( 'SpiCommand' );
		$tcpar_SpiSignal = S_read_mandatory_testcase_parameter( 'SpiSignal' );
		$tcpar_SpiSignalValue = S_read_mandatory_testcase_parameter( 'SpiSignalValue' );
		$stimulationTool = 'Manitoo';
    }
    else{
    	$stimulationTool = 'Quate';
		$tcpar_Channel =  S_read_mandatory_testcase_parameter( 'Channel' );
    }

	return 1;
}

sub TC_initialization {

	#--------------------------------------------------------------
    # INITIALIZE RECORD AND CRASH HANDLER
    #    
	S_w2rep("Initialize Record Handler");
	$record_handler = EDR_init_RecordHandler() || return;

	#--------------------------------------------------------------
    # GET CRASH DETAILS
    #    
	# Crash name or index and result DB from EDR mapping
    $crashDetails_href = {'RESULTDB' => $tcpar_ResultDB, 'CRASHNAME' => $tcpar_CrashCode};

	# Crash settings
    $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
    unless(defined $crashSettings) {
        S_set_error("Crash $tcpar_CrashCode not available in result DB $tcpar_ResultDB. Test case aborted.");
        return;
    }
	
	# Crash code in World DB
	$crashInfo_href -> {"CrashCode_MDS"} = '$tcpar_CrashCode';

	# Name of Result DB
	my $resultDB = $crashDetails_href -> {"RESULTDB"};
	unless(defined $resultDB) {
		$resultDB = "DEFAULT";
	}

	# Result DB path
	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$resultDB" ] );
	$crashInfo_href -> {"MDB_Path"} = $resultDBDetails->{'PATH'};

	#--------------------------------------------------------------
    # Initialize equipment
    #    
	LC_MeasureTraceDigitalConfigureThresholds( ['ALL'], 0.5 );	

	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');
    GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start();

	# Set environment settings for crash
    CSI_PrepareEnvironment($crashSettings, 'init_complete');
	S_wait_ms('TIMER_ECU_READY');
  
    PD_ClearCrashRecorder();
    S_wait_ms(2000);
 
    # erase FltMem
    PD_ClearFaultMemory();
    S_wait_ms(2000);
 

	# read fault memory
    my $faultsBeforeStimulation = PD_ReadFaultMemory();
	
	#Fault memory must be empty
    my $faultsVerdict = PD_evaluate_faults_NOVERDICT( $faultsBeforeStimulation, []);
 
 	return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

	return 1;
}

sub TC_stimulation_and_measurement {

	#--------------------------------------------------------------
    # CRASH PREPARATION
    #
	S_teststep("Prepare crash '$tcpar_CrashCode'", 'AUTO_NBR');
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	# Prepare crash
    CSI_LoadCrashSensorData2Simulator($crashSettings);

	# Power ON the ECU
	LC_ECU_On();
 	S_wait_ms('TIMER_ECU_READY');
 	
 	CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    S_wait_ms(1000);
 
	S_teststep("Create fault on sensor '$tcpar_Device'", 'AUTO_NBR', 'create_fault_on');			#measurement 1
	if(lc($tcpar_SensorType) eq 'internal' and $stimulationTool eq 'Quate'){
	    S_teststep_2nd_level( "Get channel index for $sensorLabel Quate mapping", 'AUTO_NBR');
	    my ($QuateIndex, $DeviceIndex, $channelIndex) = LIFT_QuaTe::QuaTe_GetIndexFromDeviceChannel($tcpar_Device, $tcpar_Channel);
	    $faultKey = $internalSensorFaultMapping -> {$tcpar_Device} -> {"Channel$channelIndex"};
	    unless(defined $faultKey){
	        S_set_warning("No fault key for manipulating $sensorLabel with Quate could be found.\n".
	                       "Sensor device might not be supported for sensor fault creation (Supported Devices: SMA660)");
	        $skipEval = 1;
	        return 1;
	    }
	    S_teststep_2nd_level( "Create sensor fault with fault key '$faultKey' on Quate", 'AUTO_NBR');
     	QuaTe_SetStaticFSMode($tcpar_Device, $tcpar_Channel, { $faultKey => 1 });	    
	}
	elsif(lc($tcpar_SensorType) eq 'internal' and $stimulationTool eq 'Manitoo'){
		S_teststep("Download $tcpar_SpiNode value via Manitoo", 'AUTO_NBR'); #Daten werden auf den Manitoo geladen
    	SPI_load_signal_manipulation('Node'=>$tcpar_SpiNode,                 #Knoten
                                 'Command' => $tcpar_SpiCommand,             #Kommando (aus spi file)
                                 'Signal'=>$tcpar_SpiSignal,								#Signal (aus spi file)
                                 'SignalValue' => $tcpar_SpiSignalValue,								#Wert f�r Signal
                                 'Duration_ms' => 6000,								#Dauer der Manipulation
                                 );
		SPI_start_manipulation(); #Start Manipulation (vgl. Trigger QuaTe)	
	}
	elsif(lc($tcpar_SensorType) eq 'external') {
	    S_teststep_2nd_level( "Create sensor fault for $tcpar_Device by disconnecting line", 'AUTO_NBR');
	    LC_DisconnectLine($tcpar_Device);
	}
	else {
	    S_set_error("Given sensor type $tcpar_SensorType not supported (Supported: Internal and External)");
	    return;
	}

	S_teststep_2nd_level( "Wait 3 sec for fault qualification", 'AUTO_NBR');
	S_wait_ms(3000);

	S_teststep_2nd_level( "Read fault memory", 'AUTO_NBR');
    $faultsAfterStimulation = PD_ReadFaultMemory();

	#--------------------------------------------------------------
    # START MEASUREMENTS
    #
	S_teststep("Start LCT Measurement", 'AUTO_NBR');
    LC_MeasureTraceDigitalStart();
    

	#--------------------------------------------------------------
    # CRASH INJECTION
    #
	S_teststep("Inject crash '$tcpar_CrashCode'", 'AUTO_NBR');
	CSI_TriggerCrash();
    S_wait_ms(10000);

	if(lc($tcpar_SensorType) eq 'internal' and $stimulationTool eq 'Manitoo'){
		SPI_stop_manipulation(); #Start Manipulation (vgl. Trigger QuaTe)	
	}

	#--------------------------------------------------------------
    # STOP MEASUREMENTS
    #
	S_teststep("Stop LCT Measurement", 'AUTO_NBR');
    LC_MeasureTraceDigitalStop();
	if (defined $tcpar_COMsignalsAfterCrash){
		foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
		{				
			my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
			S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
			COM_setSignalState($signal,$dataOnCOM);
		}

	}
	S_wait_ms(2000);


	#--------------------------------------------------------------
    # READ AND STORE CRASH RECORDS
    #
    my $dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_".$tcpar_CrashCode;
  
	S_teststep("Read EDR", 'AUTO_NBR', 'read_edr');			#measurement 2

	my $numberOfRecords = SYC_EDR_get_NumberOfEventsToBeStored();
	unless(defined $numberOfRecords){
        S_set_error("Number of records to be stored not available in SYC - add or overwrite with Custlibrary Function");
        return;
    }

	PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');	
	EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
								"CrashLabel" => $tcpar_CrashCode."_$sensorLabel\_Faulty",
								"NbrOfRecords" =>  $numberOfRecords,
								"StoragePath" => $dataStoragePath,
								"CrashInfo" => $crashInfo_href,);

	return 1;
}

sub TC_evaluation {
    
    return 1 if($skipEval);

    #
    # Sensor fault was qualified
    #    
	S_teststep_expected("Fault qualified: $tcpar_SensorFault", 'create_fault_on');			#evaluation 1
	my $detectedFaults_aref = $faultsAfterStimulation -> {'fault_text'};
	my $faultVerdict = 'VERDICT_FAIL';
	my $detectedFaultsString;
	foreach my $detectedFault (@{$detectedFaults_aref}){
	    if($detectedFault eq $tcpar_SensorFault){
	        S_set_verdict('VERDICT_PASS');
	        $faultVerdict = 'VERDICT_PASS';
	    }
	    
	    $detectedFaultsString .= " $detectedFault";
	}
	S_teststep_detected("Fault(s) qualified: $detectedFaultsString", 'create_fault_on');
	
	if($faultVerdict eq 'VERDICT_FAIL'){
    	S_set_verdict('VERDICT_FAIL') ;
	    return 1;
	}	

    #
    # EDIDs reported with correct value
    #
    foreach my $edid (sort {$a <=> $b} keys %{$tcpar_ExpectedDecodedValue_EDIDs})
    {
        my $expectedDecodedValue = $tcpar_ExpectedDecodedValue_EDIDs -> {$edid};
        foreach my $recordNbr (1..$tcpar_NbrOfExpectedRecords)
        {
    		my $dataElement = $record_handler -> GetDataElementEDID(  "EDIDnr" => $edid,
																  "RecordNumber" => $recordNbr,
																  "CrashLabel" => $tcpar_CrashCode."_$sensorLabel\_Faulty");


            S_teststep("Validate EDID $edid ($dataElement), record $recordNbr", 'AUTO_NBR', "EDID_$edid\_Record_$recordNbr");
            my $decodedData = $record_handler -> GetDecodedEDID( "EDIDnr" => $edid, 
                                                       "RecordNumber" => $recordNbr, 
                                                       "CrashLabel" => $tcpar_CrashCode."_$sensorLabel\_Faulty");
    		my $edidDataSamples = $decodedData -> {"DataSamples"}; 
    		
    		unless(defined $edidDataSamples) {
    		    $edidDataSamples -> {0} = $decodedData -> {'DataValue'};
     		}

    		unless(defined $edidDataSamples -> {0}) {
       			S_set_error("No EDID data samples could be obtained for EDID $edid in record $recordNbr!", 110) unless($main::opt_offline);
    			next;
    		}
    		
            my $expectedString;
            my $detectedString;
    		foreach my $timeStampEDID (keys %{$edidDataSamples})
    		{
                EVAL_evaluate_string("EDID_$edid\_Record_$recordNbr", $expectedDecodedValue , $edidDataSamples -> {$timeStampEDID});
                $expectedString .= " $expectedDecodedValue";
                $detectedString .= " ".$edidDataSamples -> {$timeStampEDID};
    		}

        	S_teststep_expected("$expectedString", "EDID_$edid\_Record_$recordNbr");			#evaluation 2
        	S_teststep_detected("$detectedString", "EDID_$edid\_Record_$recordNbr");
        }
    }

	return 1;
}

sub TC_finalization {

    # Erase EDR
    PD_ClearCrashRecorder();
    S_wait_ms(2000);
    
    S_teststep("Reset sensor fault manipulation", 'AUTO_NBR');
	if(lc($tcpar_SensorType) eq 'internal' and defined $faultKey){
	    S_teststep_2nd_level( "Reset sensor fault with fault key '$faultKey' on Quate", 'AUTO_NBR');
     	QuaTe_SetStaticFSMode($tcpar_Device, $tcpar_Channel, { $faultKey => 0 });	    
	}
	elsif(lc($tcpar_SensorType) eq 'external') {
	    S_teststep_2nd_level( "Connect line $tcpar_Device", 'AUTO_NBR');
	    LC_ConnectLine($tcpar_Device);
	}
    S_wait_ms(5000);

    # Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(2000);	

	PD_ECUreset();
    S_wait_ms('TIMER_ECU_READY');

    S_teststep("Delete crashes from record handler", 'AUTO_NBR');
    foreach my $recordNbr (1..$tcpar_NbrOfExpectedRecords)
    {
        $record_handler -> DeleteRecord("RecordNumber" => $recordNbr, "CrashLabel" => $tcpar_CrashCode."_$sensorLabel\_Faulty",);
    }

	# Reset ECU    
    PD_ECUreset();
    S_wait_ms('TIMER_ECU_READY');

	# Read fault memory after clearing and erasing EDR
    PD_ReadFaultMemory();   
    
    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF'); 

	return 1;
}


1;
