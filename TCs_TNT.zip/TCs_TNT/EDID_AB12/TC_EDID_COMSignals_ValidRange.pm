#### TEST CASE MODULE
package TC_EDID_COMSignals_ValidRange;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use LIFT_evaluation;
use LIFT_PD;
use LIFT_crash_simulation;
use LIFT_CANoe;
use LIFT_labcar;
use LIFT_MDSRESULT;
use GENERIC_DCOM;
use FuncLib_SYC_INTERFACE;
use FuncLib_EDR_Framework;
use LIFT_can_access;
use LIFT_flexray_access;
use LIFT_numerics;
use Data::Dumper;
use Readonly;

use constant MILLISEC_TO_SECOND => 0.001;
use constant SECOND_TO_MILLISEC => 1000;
use constant SINE_CURVE_FREQUENCY_HZ => 0.2;
use constant SINE_CURVE_STEPWIDTH_MS => 100;
#use constant SINE_CURVE_NUMBER_OF_PERIODS => 1;

Readonly my $PI => 4 * atan2(1, 1);

##################################

our $PURPOSE = "<summarize what this test is good for>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDID_COMSignals

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Set <Condition>

2.Set <COMSignal> to <COMSignalState>

3. Wait for 5 sec till the signal is transmitted on the COM bus

4. Inject a Crash

5. Read <EDID> corresponding to COM signal

#Test is repeated by injecting all crashfile mentioned in LIFT Project Parameters

#EDR data element physical value = (data received in DID 5817 (or 5818)) * (data element scale) + (data element offset)


I<B<Evaluation>>

1. -

2. -

3. -

4. -

5.<COMSignalValue> corresponding to <COMSignalState> should be reported 


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES
 
	SCALAR 'purpose' => # mandatory
	SCALAR 'EDID' => # mandatory
	SCALAR 'COMSignal' => # mandatory
	SCALAR 'COMSignalState' => # mandatory
	SCALAR 'Crashcode' => # mandatory
	SCALAR 'CrashTimeZero_ms' => # mandatory
	SCALAR 'DiagType' => # mandatory
	SCALAR 'StepValue1' => # required for StepUp and Square
	SCALAR 'StepValue2' => # required for StepUp and Square
	SCALAR 'ResultDB' => # optional, default 'DEFAULT'
	SCALAR 'Protocol' => # optional, default 'CAN'
	HASH 'Condition' => # optional, default empty
	HASH 'COMsignalsAfterCrash' => # optional, default empty


=head2 PARAMETER EXAMPLES

  1) Sine Wave
	[TC_EDID_COMSignals_ValidRange.SpeedVehicleIndicated_SineWave_Single]   #ID: TS_EDID_1149
	purpose = 'Validate COM signal related EDIDs for Different COM signals with Valid Range Data on COM Signal'
	EDID = '91'
	COMSignal = 'VSD_ESPReferenceVelocity'
	COMSignalState = 'SineWave'
	Crashcode = 'Single_EDR_Front_above_8kph_NoDeployment'
	CrashTimeZero_ms = '76.26'
	DiagType  = 'ProdDiag' 
	ResultDB = 'EDR'
	Condition = %('VehVActlEng_D_Qf' => '3') # Quality factor for speed must be set to valid
	COMsignalsAfterCrash = %()

  2) Step Up
	[TC_EDID_COMSignals_ValidRange.ABSActivity_StepUp_Single]   #ID: TS_EDID_1149
	purpose = 'Validate COM signal related EDIDs for Different COM signals with Valid Range Data on COM Signal'
	EDID = '96'
	COMSignal = 'AbsActivity'
	COMSignalState = 'StepUp'
	Crashcode = 'Single_EDR_Front_above_8kph_NoDeployment'
	CrashTimeZero_ms = '76.26'
	DiagType  = 'ProdDiag'
	StepValue1 = '0'
	StepValue2 = '1'
	ResultDB = 'EDR'
	Condition = %()
	COMsignalsAfterCrash = %('ImpactEvntFdbck_D_Stat' => '2', 'eCallConfirmation' => '2') #these COM signals will be sent after crash

  3) Square Wave
	[TC_EDID_COMSignals_ValidRange.SpeedVehicleIndicated_SquareWave_Single]   #ID: TS_EDID_1149
	purpose = 'Validate COM signal related EDIDs for Different COM signals with Valid Range Data on COM Signal'
	EDID = '91'
	COMSignal = 'VSD_ESPReferenceVelocity'
	COMSignalState = 'SquareWave'
	Crashcode = 'Single_EDR_Front_above_8kph_NoDeployment'
	CrashTimeZero_ms = '76.26'
	DiagType  = 'ProdDiag'
	StepValue1 = '30'
	StepValue2 = '80'
	ResultDB = 'EDR'
	Condition = %()
	COMsignalsAfterCrash = %('ImpactEvntFdbck_D_Stat' => '2', 'eCallConfirmation' => '2') #these COM signals will be sent after crash

  4) Ramp Up
	[TC_EDID_COMSignals_ValidRange.SpeedVehicleIndicated_RampUp_Extended]   #ID: TS_EDID_1149
	purpose		 = 'Validate COM signal related EDIDs for Different COM signals with Valid Range Data on COM Signal'
	EDID = '91'
	COMSignal = 'VSD_ESPReferenceVelocity'
	COMSignalState = 'RampUp'
	Crashcode = 'Multi_EDR_Extended_Front_ND_Side_AD_Front_AD'
	CrashTimeZero_ms = '43.76_139.76'
	DiagType  = 'ProdDiag' 
	ResultDB = 'EDR'
	Condition = %()
	COMsignalsAfterCrash = %() #no COM signals will be sent after crash	

	5) Static Value
	
		a) Numeric Value
		[TC_EDID_COMSignals_ValidRange.SpeedVehicleIndicated_50_kmph_Single]   #ID: TS_EDID_1149
		purpose		 = 'Validate COM signal related EDIDs for Different COM signals with Valid Range Data on COM Signal'
		EDID = '91'
		COMSignal = 'VSD_ESPReferenceVelocity'
		COMSignalState = '50' # COM Signal will be set to static value 50
		Crashcode = 'Single_EDR_Front_above_8kph_NoDeployment'
		CrashTimeZero_ms = '76.26'
		DiagType  = 'ProdDiag' 
		ResultDB = 'EDR'
		Condition = %()

		b) Value defined in COM Mapping, under 'DataValueTable' of according signal
		[TC_EDID_COMSignals_ValidRange.SpeedVehicleIndicated_50_kmph_Single]   #ID: TS_EDID_1149
		purpose		 = 'Validate COM signal related EDIDs for Different COM signals with Valid Range Data on COM Signal'
		EDID = '91'
		COMSignal = 'VSD_ESPReferenceVelocity'
		COMSignalState = 'Min_Value' # COM Signal will be set to 'Min_Value', which must be defined in COM mapping (CAN or Flexray mapping)
		Crashcode = 'Single_EDR_Front_above_8kph_NoDeployment'
		CrashTimeZero_ms = '76.26'
		DiagType  = 'ProdDiag' 
		ResultDB = 'EDR'
		Condition = %()
	
=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_EDID;
my $tcpar_COMSignal;
my $tcpar_COMSignalState;
my $tcpar_Crash_Type;
my $tcpar_Crash_Time_Zero_ms;
my $tcpar_StepValue1;
my $tcpar_StepValue2;
my $tcpar_Protocol;
my $tcpar_Condition;
my $tcpar_ResultDB;
my $tcpar_DiagType;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_Tolerance_Value_abs;
my $tcpar_LastSpeedDataSample_EDID;
my $tcpar_Mode;
my $tcpar_read_NHTSAEDR;
my $tcpar_read_CHINAEDR;
my $tcpar_value_max;
my $tcpar_value_min;
################ global parameter declaration ###################
#add any global variables here
my (
	$record_handler,
	$crash_handler,
	$mappingEDR,
	$mappingCAN,
	$numberOfRecords,
	$crashLabel,
	$manipulatedCOMsignals,
	$crashSettings,
	$crashDetails_href,
	$crashInfo_href,
	$numberOfRecordsToEvaluate,
	$mappingFlexRay,
	$tcpar_minValue,
	$tcpar_maxValue,
	$ChinaEDR_diagType
);

my $dispatchTable ||= {
      SineWave => \&_createSineWaveOnCOM,
      RampUp   => \&_createRampUpOnCOM,
      StepUp   => \&_createStepUpOnCOM,
      SquareWave   => \&_createSquareWaveOnCOM,
  }; 

my $onlyEval = 0; # TODO: replace with optional test case parameter

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_EDID =  S_read_mandatory_testcase_parameter( 'EDID' );
	$tcpar_DiagType = S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_COMSignal =  S_read_mandatory_testcase_parameter( 'COMSignal' );
	$tcpar_COMSignalState =  S_read_mandatory_testcase_parameter( 'COMSignalState' );
	$tcpar_Crash_Type =  S_read_project_parameter( 'CrashFile' );
	$tcpar_Crash_Type =  S_read_mandatory_testcase_parameter( 'Crashcode' ) unless (defined $tcpar_Crash_Type);
	$tcpar_ResultDB =  S_read_optional_testcase_parameter( 'ResultDB' );
	$tcpar_ResultDB = 'Default' unless(defined $tcpar_ResultDB);
	$tcpar_Crash_Time_Zero_ms = S_read_project_parameter( 'CrashTimeZero_ms' );
	$tcpar_Crash_Time_Zero_ms = S_read_mandatory_testcase_parameter( 'CrashTimeZero_ms' ) unless (defined $tcpar_Crash_Time_Zero_ms);

	$tcpar_Protocol = S_read_optional_testcase_parameter('Protocol');
	$tcpar_Mode = S_read_optional_testcase_parameter('Mode');
	unless (defined $tcpar_Mode){
		S_w2rep("Set Mode to default ='phys' ");
		$tcpar_Mode='phys' 
	}
	$tcpar_StepValue1 = S_read_optional_testcase_parameter('StepValue1');
	$tcpar_StepValue2 = S_read_optional_testcase_parameter('StepValue2');
	$tcpar_minValue = S_read_optional_testcase_parameter('minValue');
	$tcpar_maxValue = S_read_optional_testcase_parameter('maxValue');
	$tcpar_Condition = S_read_optional_testcase_parameter('Condition', 'byref');
	$tcpar_COMsignalsAfterCrash =  S_read_optional_testcase_parameter( 'COMsignalsAfterCrash', 'byref' );
	$tcpar_Tolerance_Value_abs = S_read_mandatory_testcase_parameter('ToleranceValue_abs');
	$tcpar_LastSpeedDataSample_EDID = S_read_optional_testcase_parameter('LastSpeedDataSample_EDID');
	
	$tcpar_value_max= S_read_optional_testcase_parameter( 'value_max');
    $tcpar_value_max= '500' if (not defined $tcpar_value_max);
    $tcpar_value_min= S_read_optional_testcase_parameter( 'value_min');
    $tcpar_value_min= '0' if (not defined $tcpar_value_min);

	unless(lc($tcpar_Protocol) =~ m/can/i or lc($tcpar_Protocol) =~ m/flexray/i) {
		S_w2rep("Set communication protocol to default CAN");
		$tcpar_Protocol = 'CAN';
	}

	$crashLabel = $tcpar_COMSignal."_".$tcpar_COMSignalState."_".$tcpar_Crash_Type;
	$tcpar_read_NHTSAEDR=S_read_optional_testcase_parameter('read_NHTSAEDR');
	$tcpar_read_CHINAEDR=S_read_optional_testcase_parameter('read_CHINAEDR');
	
	if(not defined $tcpar_read_CHINAEDR) {
		$tcpar_read_NHTSAEDR = 'yes';
		$tcpar_read_CHINAEDR = 'no';
	}
	else {
		$tcpar_read_NHTSAEDR = 'no';
		my $storageOrder = EDR_getStorageOrder();
		return unless(defined $storageOrder);

		if($storageOrder eq 'PhysicalOrder'){
			$ChinaEDR_diagType= 'ProdDiag';  #In platform NHTSA and China EDR is read via proddiag
		}
		else {
			$ChinaEDR_diagType= 'CHINA_Payload';
		}
	}

	return 1;
}

sub TC_initialization {
 	$mappingEDR = S_get_contents_of_hash(['Mapping_EDR']) unless defined $mappingEDR;

	S_teststep("Initialize record and crash handler", 'AUTO_NBR');
	$record_handler = EDR_init_RecordHandler() || return;
	$crash_handler  = EDR_init_CrashHandler() || return;

    $numberOfRecords = SYC_EDR_get_NumberOfEventsToBeStored();
    unless(defined $numberOfRecords){
        S_set_error("'NumberOfEventsToBeStored' not available in SYC - add or overwrite 'SYC_EDR_get_NumberOfEventsToBeStored' with Custlibrary Function");
        return;
    }

	return 1 if $onlyEval;

	#--------------------------------------------------------------
    # ADD EDR CRASH TIME ZERO AS CRASH SOURCE
    #    
    $crash_handler -> AddCrashSource( "CrashLabel" => $crashLabel,
    								  "SourceLabel" => 'CrashTimeZero', 
                                      "OriginalSourceData" => $tcpar_Crash_Time_Zero_ms,
                                      "SourceUnit" => 'ms',);    


	#--------------------------------------------------------------
    # GET CRASH DETAILS
    #    
	# Crash name or index and result DB from EDR mapping
    $crashDetails_href = $mappingEDR -> {'CRASHFILES'}{$tcpar_Crash_Type};
    unless(defined $crashDetails_href) {
        $crashDetails_href = {'RESULTDB' => $tcpar_ResultDB, 'CRASHNAME' => $tcpar_Crash_Type};
    }

	# Crash settings
    $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
    unless(defined $crashSettings) {
        S_set_error("Crash $tcpar_Crash_Type not available in result DB $tcpar_ResultDB. Test case aborted.");
        return;
    }
	
	# Crash code in World DB
    if( defined $crashSettings -> { 'CRASHNAME' } ) {
	     $crash_handler -> AddCrashSource( "CrashLabel" => $crashLabel,
	    								  "SourceLabel" => 'CrashCode_MDS', 
	                                      "OriginalSourceData" => $crashSettings -> { 'CRASHNAME' }, );

		$crashInfo_href -> {"CrashCode_MDS"} = $crashSettings -> { 'CRASHNAME' };
    }

	# Name of Result DB
	my $resultDB = $crashDetails_href -> {"RESULTDB"};
	unless(defined $resultDB) {
		$resultDB = "DEFAULT";
	}

	# Result DB path
	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$resultDB" ] );
	$crash_handler -> AddCrashSource( "CrashLabel" => $crashLabel,
									  "SourceLabel" => 'MDB_Path', 
	                                  "OriginalSourceData" => $resultDBDetails->{'PATH'}, );

	$crashInfo_href -> {"MDB_Path"} = $resultDBDetails->{'PATH'};

	# Crash time Zero and EDR crash label -> crash name in EDR mapping
	$crashInfo_href -> {"CrashTimeZero_ms"} = $tcpar_Crash_Time_Zero_ms;
	$crashInfo_href -> {"CrashLabel"} = $crashLabel;


	#--------------------------------------------------------------
    # PREPARE TEST SETUP
    #    
    # Power On the ECU
    S_w2log(1, "Power on ECU");
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

    S_w2log(1, "Initialize CD and start CAN trace");
    GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start ( );
	
    # Erase EDR
    PD_ClearCrashRecorder();
    S_wait_ms(2000);

	S_w2log(1, "Set environments for crash as per result DB");
    CSI_PrepareEnvironment($crashSettings, 'init_complete');
    S_wait_ms(2000);
 
    # Erase adn read FltMem
    PD_ClearFaultMemory();
    S_wait_ms(5000);

    PD_ReadFaultMemory();
    S_wait_ms(2000);
 
    # Reset and wait for iniend to make sure that all init fault are available
    PD_ECUreset();
    S_wait_ms('TIMER_ECU_READY');

	return 1;
}

sub TC_stimulation_and_measurement {

	return 1 if $onlyEval;

	#--------------------------------------------------------------
    # PREPARE CRASH INJECTION AND REPORT FILES
    #    
	my $edr_COMsignals_aref = undef;
	$edr_COMsignals_aref = $mappingEDR -> {'EDR_COM_SIGNAL_LABELS'};
	unless(defined $edr_COMsignals_aref) {		
		S_w2rep("No EDR relevant COM signals given in EDR mapping under 'EDR_COM_SIGNAL_LABELS' - only dataref of given COM signal $tcpar_COMSignal will be stored.");	
	}

    my $dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_COM_Signal_".$tcpar_COMSignal;

    S_teststep("Prepare crash", 'AUTO_NBR');
    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

    # Prepare crash
    CSI_LoadCrashSensorData2Simulator($crashSettings);

    # Power ON the ECU
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');
    
    CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    S_wait_ms(1000);

	#--------------------------------------------------------------
    # COM SIGNAL STIMULATION
    #    
	S_teststep("Start CAN Trace", 'AUTO_NBR');
    CA_trace_start();
	S_wait_ms(2000);
	my $allSignalStatesDuringCrash_href;
	my $manipulatedCOMsignals_aref;

	# Set Condition if required
	if(defined $tcpar_Condition) {
		foreach my $signal (keys %{$tcpar_Condition})
		{
			$manipulatedCOMsignals -> {$signal} = CA_read_can_signal($signal, 'phys') if (lc($tcpar_Protocol) =~ m/can/i);
            $manipulatedCOMsignals -> {$signal} = FR_read_flxr_signal($signal, $tcpar_Mode) if (lc($tcpar_Protocol) =~ m/flexray/i);
			push(@{$manipulatedCOMsignals_aref}, $signal);
			my $value = $tcpar_Condition -> {$signal};
			S_teststep("Set '$signal' to '$value' as precondition.", 'AUTO_NBR');		
			if($tcpar_Condition -> {$signal} eq 'SignalNotAvailable') {
		        my $signalInfo = COM_fetchSignalInfo($signal, $tcpar_Protocol);
		        my $message = $signalInfo -> {'MESSAGE'};
				COM_stopMessages($message, $tcpar_Protocol);
			}
			else {
				COM_setSignalState($signal, $tcpar_Condition -> {$signal}, $tcpar_Protocol);		
			}
		}
	}

	# Store current value of COM signal for resetting later
	($manipulatedCOMsignals -> {$tcpar_COMSignal}) = CA_read_can_signal($tcpar_COMSignal, 'phys') if (lc($tcpar_Protocol) =~ m/can/i);
    ($manipulatedCOMsignals -> {$tcpar_COMSignal}) = FR_read_flxr_signal($tcpar_COMSignal, $tcpar_Mode) if (lc($tcpar_Protocol) =~ m/flexray/i);
	push(@{$manipulatedCOMsignals_aref}, $tcpar_COMSignal);

	S_teststep("Set '$tcpar_COMSignal' to '$tcpar_COMSignalState'", 'AUTO_NBR');
	if(	exists $dispatchTable -> {$tcpar_COMSignalState}){
		$dispatchTable -> {$tcpar_COMSignalState} -> ();
	}
	else { 	# Static Signal value
		COM_setSignalState($tcpar_COMSignal, $tcpar_COMSignalState, $tcpar_Protocol);
		S_w2rep("Wait for 6 sec till the signal is transmitted on the COM bus");
		S_wait_ms(6000);
	}

	my $random_value_ms = NUM_RandomNumber( $tcpar_value_max, {value_min =>$tcpar_value_min} );
	S_teststep("Wait for $random_value_ms ms before crash", 'AUTO_NBR');
	S_wait_ms($random_value_ms);
	#--------------------------------------------------------------
    # CRASH INJECTION
    #    
	S_teststep("Inject crash $tcpar_Crash_Type", 'AUTO_NBR');
    CSI_TriggerCrash();
	
	# Continue Sine Wave after Crash injection
	if($tcpar_COMSignalState eq 'SineWave') {
		$dispatchTable -> {$tcpar_COMSignalState} -> ();
	}    
	
	S_wait_ms(20000);

	# Set COM signals which are required after crash
	if (defined $tcpar_COMsignalsAfterCrash){
		foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
		{				
			my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
			S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
			COM_setSignalState($signal,$dataOnCOM, $tcpar_Protocol);	
		}
	}
	S_wait_ms(1000);

	#--------------------------------------------------------------
    # DATA COLLECTION AND STORAGE
    #    
	S_teststep("Read and print all available EDR records", 'AUTO_NBR');

	if ( lc( $tcpar_read_NHTSAEDR) eq 'yes' ) {
		S_w2rep("Nbr of records: $numberOfRecords");
		EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
								"CrashLabel" => $crashLabel,
								"NbrOfRecords" =>  $numberOfRecords,
								"StoragePath" => $dataStoragePath,
								"CrashInfo" => $crashInfo_href,
								"read_EDRType"=>'NHTSA')
	}
	if (lc($tcpar_read_CHINAEDR) eq 'yes'){
		$numberOfRecords=3;
		S_w2rep("Nbr of records: $numberOfRecords");
		EDR_ReadAndStoreAllRecords ("DiagType" =>  $ChinaEDR_diagType,
								"CrashLabel" => $crashLabel,
								"NbrOfRecords" =>  $numberOfRecords,
								"StoragePath" => $dataStoragePath,
								"CrashInfo" => $crashInfo_href,
								"read_EDRType"=>'CHINA');
	}	
	
	# Store CAN signal
	S_w2rep("Store $tcpar_Protocol Trace");
	my $fileName = "$dataStoragePath/LIFT_network_trace_$tcpar_Crash_Type.asc";
	my $tracePath;
	$tracePath = CA_trace_store($fileName) if (lc($tcpar_Protocol) =~ m/can/i);
	$tracePath = FR_trace_store($fileName) if (lc($tcpar_Protocol) =~ m/flexray/i);
	GEN_printLink($tracePath);

	S_wait_ms(2000);

	# Restart measurement after storage
    CA_trace_start() if (lc($tcpar_Protocol) =~ m/can/i);
    FR_trace_start() if (lc($tcpar_Protocol) =~ m/flexray/i);

	my $com_trace_dataref;
	my $eventTrigger_dataref;

	unless($main::opt_offline) {
		S_w2rep("Get COM trace data reference for all manipulated COM signals");
		$eventTrigger_dataref = CA_trace_get_dataref($fileName, ['EventTrigger']);
		unless(defined $eventTrigger_dataref){
    		S_set_error("COM signal time zero could not be obtained from CAN trace (message 'EventTrigger').\n"
    		              ."- Check whether message is seen in CANoe trace.\n"
    		              ."- Check whether message is filtered out in logging block of CANoe.\n"
    		              ."- Check whether message is defined in CAN mapping\n"
                          ."- Check whether the TSG4 firmware is up to date (Minimum firmware version 17 required)");
    	   return;		    
		}
		$com_trace_dataref = CA_trace_get_dataref($fileName, $manipulatedCOMsignals_aref) if (lc($tcpar_Protocol) =~ m/can/i);
		$com_trace_dataref = FR_trace_get_dataref($fileName, $manipulatedCOMsignals_aref) if (lc($tcpar_Protocol) =~ m/flexray/i);
	}

	S_w2rep("Dump COM trace data reference for all manipulated COM signals for reuse");
	S_dump2pmFile ("VariableToDump" => $com_trace_dataref,
		 "VariableName" => "comTraceDataref",
		 "PackageName" => "EDR_COM_Trace",
		 "StoragePath" => $dataStoragePath);		

	# Get COM time stamp at which Quate injection is triggered
	my ($value_aref, $time_aref) = EVAL_get_values_and_times_over_time( $eventTrigger_dataref , "EventTrigger") unless($main::opt_offline);
	my $comSignalTimeZero = $time_aref -> [0];
	$comSignalTimeZero = 0 if($main::opt_offline);
	unless(defined $comSignalTimeZero){
		S_set_error("COM signal time zero could not be obtained from CAN trace (message 'EventTrigger').\n"
		              ."- Check whether message is seen in CANoe trace.\n"
		              ."- Check whether message is filtered out in logging block of CANoe.\n"
		              ."- Check whether message is defined in CAN mapping\n"
                      ."- Check whether the TSG4 firmware is up to date (Minimum firmware version 17 required)");
	   return;
	}
	S_w2rep("Event Trigger time stamp: $comSignalTimeZero seconds");

	S_teststep("Store manipulated COM signals in crash handler", 'AUTO_NBR');
	my $edr_COMSignalValues_href;
	foreach my $signalLabel (keys %{$manipulatedCOMsignals})
	{
		S_w2rep("COM signal $signalLabel");

		my($COMSignalValues_aref, $signalTimeStamps_aref); 
		($COMSignalValues_aref, $signalTimeStamps_aref) = EVAL_get_values_and_times_over_time($com_trace_dataref, $signalLabel) unless ($main::opt_offline or $tcpar_COMSignalState eq 'SignalNotAvailable'); 

		if($main::opt_offline){
			$COMSignalValues_aref = [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0];
			$signalTimeStamps_aref = [-10, -9, -8, -7, -6, -5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
		}			

		next if (not defined $COMSignalValues_aref or not defined $signalTimeStamps_aref);

		$crash_handler -> AddCrashSource ( "CrashLabel"  => $crashLabel,
											"SourceType"  => 'COM_Signal',
											"SourceLabel" => $signalLabel,
											"OriginalSourceName" => $signalLabel,
											"OriginalSourceData" => $COMSignalValues_aref,
											"SignalTimeStamps" => $signalTimeStamps_aref,
											"TraceTimeZero_ms" => $comSignalTimeZero * SECOND_TO_MILLISEC );

		$edr_COMSignalValues_href -> {$signalLabel} -> {'Data'} = $COMSignalValues_aref;
		$edr_COMSignalValues_href -> {$signalLabel} -> {'TimeStamps'} = $signalTimeStamps_aref;
		$edr_COMSignalValues_href -> {$signalLabel} -> {'ValueDuringCrash'}= $allSignalStatesDuringCrash_href -> {$signalLabel};
	}

	S_dump2pmFile ("VariableToDump" => $edr_COMSignalValues_href,
		 "VariableName" => "comSignalsDuringCrash",
		 "PackageName" => "EDR_COM_Signal_Values_Crash",
		 "StoragePath" => $dataStoragePath);		

	return 1;
}

sub TC_evaluation {

	#--------------------------------------------------------------
    # GET STORAGE ORDER
    #    
    my $storageOrder = EDR_getStorageOrder ();
    return unless(defined $storageOrder);

    if($storageOrder eq 'PhysicalOrder'){
       $storageOrder =  'MostRecentLast'; #same behavior as there is no overwriting
    }

	#--------------------------------------------------------------
    # GET EXPECTED COM SIGNAL VALUE
    #    
	S_w2log(1, "Get expected COM signal value '$tcpar_COMSignal' in crash $tcpar_Crash_Type");
	my $comSignalDataSamples;

	my $functionName = "EDR_COM_GetExpectedValue_$tcpar_COMSignal";
	if(exists &$functionName) {
	   S_w2log( 4, "Call '$tcpar_COMSignal' function to get expected COM signal data samples\n" );
 	   {
	        no strict 'refs'; #disable strict refs only for this section
	        $comSignalDataSamples = &$functionName($crashLabel);
	        return if not $comSignalDataSamples;
 	   }
		
	}
	else {
	    my $sourceData = $crash_handler -> GetSourceDataSamples("SourceLabel" => $tcpar_COMSignal, "CrashLabel" => $crashLabel); 
		
		unless(defined $sourceData) {
			S_set_error("No COM signal values found for crash $crashLabel. EDID will not be evaluated.", 110);
			return;
		}

		$comSignalDataSamples = $sourceData -> {"DataSamples"};
	}

 	#--------------------------------------------------------------
    # GET CRASH TIME ZERO ON COM AND EDR
    #    
    my $comTraceTimeZero_ms = $crash_handler -> Get_COM_TraceTimeZero_ms(  "SourceLabel" => $tcpar_COMSignal, "CrashLabel" => $crashLabel );		

	my @allCrashTimeZeros = split('_', $tcpar_Crash_Time_Zero_ms);
	my $numberOfIncidents = @allCrashTimeZeros;
	S_w2rep("Number of incidents: $numberOfIncidents");
	my $crashTimeZero_href;

    if($numberOfIncidents > $numberOfRecords){ #Extended event
        $numberOfRecordsToEvaluate = $numberOfRecords;
    }
    else {
        $numberOfRecordsToEvaluate = $numberOfIncidents;
    }

	foreach my $incidentNumber (1..$numberOfRecordsToEvaluate)
	{
		$crashTimeZero_href -> {"Record_$incidentNumber"} = $allCrashTimeZeros[$incidentNumber-1] if($storageOrder eq 'MostRecentLast');
		$crashTimeZero_href -> {"Record_$incidentNumber"} = $allCrashTimeZeros[$numberOfRecordsToEvaluate - $incidentNumber] if($storageOrder eq 'MostRecentFirst');		
	}

 	S_w2rep("Number of records to evaluate: $numberOfRecordsToEvaluate");
 	#--------------------------------------------------------------
    # VALIDATE REPORTED COM SIGNALS FOR ALL INCIDENTS / RECORDS
    #
	foreach my $recordNbr (1..$numberOfRecordsToEvaluate)
	{
        S_teststep("\n", 'NO_AUTO_NBR');
        S_teststep_expected_NOHTML("\n");
        S_teststep_detected_NOHTML("\n");

		S_teststep("---- Record $recordNbr ----", 'NO_AUTO_NBR');
        S_teststep_expected_NOHTML("---- Record $recordNbr ----");
        S_teststep_detected_NOHTML("---- Record $recordNbr ----");
		my $thisCrashTimeZero = $crashTimeZero_href -> {"Record_$recordNbr"};

		# Synchronize T0
		S_w2rep("Crash time zero given for this crash is: $thisCrashTimeZero");
		S_teststep_2nd_level("Synchronize given T0 ($thisCrashTimeZero) for EDID $tcpar_EDID.", 'AUTO_NBR');
	    if(defined $tcpar_LastSpeedDataSample_EDID)
	    {
	    	S_set_warning("Usage of parameter 'LastSpeedDataSample_EDID' outdated. Fill 'TimeSynchronization' section in EDR mapping instead!");

	        my $edidData = $record_handler -> GetDecodedEDID("CrashLabel" => $crashLabel, "RecordNumber" => $recordNbr,"EDIDnr" => $tcpar_LastSpeedDataSample_EDID );
	        unless(defined $edidData) {
	            S_set_error("No EDID data found for given EDID $tcpar_LastSpeedDataSample_EDID (last speed data sample) crash $tcpar_Crash_Type, record $recordNbr, return nothing", 110);
	            return;
	        }
	        $thisCrashTimeZero = $thisCrashTimeZero - $edidData -> {DataValue} * MILLISEC_TO_SECOND;
	    }
	    else{
			$thisCrashTimeZero = EDR_synchronize_T0_for_EDID($tcpar_EDID, $thisCrashTimeZero,		    	
															 $crashLabel, $recordNbr);
	    }

		S_teststep("Synchronized T0: $thisCrashTimeZero ms", 'NO_AUTO_NBR');

		#-----------------------------------------------------------------------
		# Get EDID data
		#-----------------------------------------------------------------------
		S_teststep("Read EDID '$tcpar_EDID' corresponding to COM signal $tcpar_COMSignal in Record $recordNbr, crash $tcpar_Crash_Type", 'AUTO_NBR', "compareEDID_Record$recordNbr");			#measurement 1

		# Eval start and end time
		S_w2rep("Get EDID recording start and end time");
		my $recordingStartTime_ms = $record_handler -> GetRecStartTimeMillisecEDID("CrashLabel" => $crashLabel, "RecordNumber" => $recordNbr,"EDIDnr" => $tcpar_EDID );
		my $recordingEndTime_ms = $record_handler -> GetRecEndTimeMillisecEDID("CrashLabel" => $crashLabel, "RecordNumber" => $recordNbr,"EDIDnr" => $tcpar_EDID );

		# EDID value
		S_w2rep("Get decoded EDID value");
		my $edidData = $record_handler -> GetDecodedEDID("CrashLabel" => $crashLabel, "RecordNumber" => $recordNbr,"EDIDnr" => $tcpar_EDID );
		unless(defined $edidData) {
			S_set_error("No EDID data found for crash $tcpar_Crash_Type, record $recordNbr, return nothing", 110);
			return;
		}
		
		# TODO: EDID has only one Data Sample, evaluate directly with COM signal value at time zero - try out in Ford
		if(ref($edidData -> {"DataValue"}) ne 'ARRAY'){
			S_w2rep("EDID is static, i.e. there is only one data sample to validate");
			S_w2rep("Recording start time: $recordingStartTime_ms ms");
			my $detectedEDIDvalue = $edidData -> {"DataValue"};
			my $comValueAtRecStart;
			my $crashTimeZeroOnCOM_sec = ($comTraceTimeZero_ms + $thisCrashTimeZero + $recordingStartTime_ms) * MILLISEC_TO_SECOND;
			S_w2rep("EDR recording start time: $crashTimeZeroOnCOM_sec sec");
			foreach my $comTimeStamp (sort {$a <=> $b} keys %{$comSignalDataSamples})
			{
				next if($comTimeStamp < $crashTimeZeroOnCOM_sec);
				$comValueAtRecStart = $comSignalDataSamples -> {$comTimeStamp};
				S_w2rep("COM value at recording start time of EDID is $comValueAtRecStart");
				last;
			}
			S_teststep_expected("Expected value for EDID $tcpar_EDID: $comValueAtRecStart", "compareEDID_Record$recordNbr");
			S_teststep_detected("Detected value for EDID $tcpar_EDID: $detectedEDIDvalue", "compareEDID_Record$recordNbr");
			EVAL_evaluate_value( "EDID_$tcpar_EDID\_$tcpar_COMSignal" , $detectedEDIDvalue, '==', $comValueAtRecStart, 0.5 , 'absolute');
			next;
		}
		
		# Ringbuffer COM signal -> more than one data sample!
		my $edidDataSamples = $edidData -> {"DataSamples"};
		unless(defined $edidDataSamples) {
			S_set_error("No EDID data samples could be obtained for EDID $tcpar_EDID in record $recordNbr!", 110);
			return;
		}

		# EDID Sample Rate
		S_w2rep("Get EDID sample rate in Hz");
		my $edidSampleRate_Hz = $record_handler -> Get_EDID_SampleRateHz("CrashLabel" => $crashLabel, "RecordNumber" => $recordNbr,"EDIDnr" => $tcpar_EDID );
		my $tolerance_sec;
		if($edidSampleRate_Hz > 0) {
			$tolerance_sec = 1 / $edidSampleRate_Hz;
		}
		else {
			S_set_error("No EDID sample rate greater than zero given - check sample rate in EDR mapping", 110);
			return;
		}

		#-----------------------------------------------------------------------
		# Compare expected and detected
		#-----------------------------------------------------------------------
		S_teststep("Start evaluation of '$tcpar_EDID' corresponding to COM signal $tcpar_COMSignal in Record $recordNbr, crash $tcpar_Crash_Type", 'AUTO_NBR');
		my ($firstVerdict, $busData_href) = EDR_Eval_Ringbuffer_COMsignal_NOVERDICT( "EDID_DataSamples" => $edidDataSamples,
										 "COM_Signal_DataSamples" => $comSignalDataSamples,
										 "Rec_Start_Time_ms" => $recordingStartTime_ms, 
										 "Rec_End_Time_ms" => $recordingEndTime_ms,
										 "Crash_TimeZero_s" => $thisCrashTimeZero * MILLISEC_TO_SECOND,
										 "COM_trace_TimeZero_ms" => $comTraceTimeZero_ms,
										 "EDID_ID" => $tcpar_EDID,
										 "Absolute_Tolerance_Time_sec" => $tolerance_sec,
										 "Absolute_Tolerance_Value" => $tcpar_Tolerance_Value_abs,
										 "DataUnit" => $edidData -> {"ValueUnit"},
										 "CompareTitle" => "COM_Signal_$tcpar_COMSignal\_Crash_$tcpar_Crash_Type\_Record_$recordNbr");						

		S_w2rep("First verdict: $firstVerdict");

		my ($thisEdidSynchronizationEdid, $thisEdidSyncType);
		if(not defined $tcpar_LastSpeedDataSample_EDID){
			($thisEdidSynchronizationEdid, $thisEdidSyncType) = EDR_get_synchronization_EDID ($tcpar_EDID);
		}
		else{
			$thisEdidSynchronizationEdid = $tcpar_LastSpeedDataSample_EDID;
		}

        my $secondVerdict;
        my $shiftTimesec = 0;
        if($firstVerdict eq 'VERDICT_FAIL' and not defined $thisEdidSynchronizationEdid ){
        	
	        S_teststep("No synchronization EDID given - shift T0 by half sample time and validate again", 'AUTO_NBR');
		    my $sampleRate = $record_handler -> Get_EDID_SampleRateHz(  "EDIDnr" => $tcpar_EDID, 
	                                                                    "RecordNumber" => $recordNbr, 
	                                                                    "CrashLabel" => $crashLabel);
        	unless(defined $sampleRate){
        		S_set_error("No sample rate defined for EDID. Signal can not be shifted for validation. Abort validation.");
        		return;
        	}
     	    $shiftTimesec = 1/$sampleRate;	        	
	
	        S_teststep("Start validation with T0 shift of $shiftTimesec seconds", 'NO_AUTO_NBR');
	        my $busData_href;
	        ($secondVerdict, $busData_href) = EDR_Eval_Ringbuffer_COMsignal_NOVERDICT( "EDID_DataSamples" => $edidDataSamples, 
	                                         "COM_Signal_DataSamples" => $comSignalDataSamples,
	                                         "Rec_Start_Time_ms" => $recordingStartTime_ms, 
	                                         "Rec_End_Time_ms" => $recordingEndTime_ms,
	                                         "Crash_TimeZero_s" => $thisCrashTimeZero * MILLISEC_TO_SECOND - $shiftTimesec,
	                                         "COM_trace_TimeZero_ms" => $comTraceTimeZero_ms,
	                                         "EDID_ID" => $tcpar_EDID,
	                                         "Absolute_Tolerance_Time_sec" => $tolerance_sec,
	                                         "Absolute_Tolerance_Value" => $tcpar_Tolerance_Value_abs,
	                                         "DataUnit" => $edidData -> {"ValueUnit"},
	                                         "CompareTitle" => "COM_Signal_$tcpar_COMSignal\_Crash_$tcpar_Crash_Type\_Record_$recordNbr\_shifted");                     
	
	         S_w2rep("Second verdict (shifted): $secondVerdict");      	
        }
	
		#-----------------------------------------------------------------------
		# Set verdict and report result
		#-----------------------------------------------------------------------
		my $verdict;
		if(($firstVerdict eq 'VERDICT_PASS') or ($secondVerdict eq 'VERDICT_PASS')) {
			$verdict = 'VERDICT_PASS';
		}
		else {
			$verdict = 'VERDICT_FAIL';
		}
		
		S_set_verdict($verdict);

		S_teststep_expected("'EDID $tcpar_EDID' corresponding to COM signal '$tcpar_COMSignal' should be reported as in CAN trace", "compareEDID_Record$recordNbr");			#evaluation 1
		S_teststep_detected("Detected EDID COM signal state: equal to COM signal in trace", "compareEDID_Record$recordNbr") if ($verdict eq 'VERDICT_PASS');
		S_teststep_detected("Detected EDID COM signal state: not equal to COM signal in trace", "compareEDID_Record$recordNbr") if ($verdict eq 'VERDICT_FAIL');
	}

	return 1;
}

sub TC_finalization {

	return 1 if $onlyEval;
	
 	#--------------------------------------------------------------
    # RESET STIMULATION
    #    
	if($tcpar_COMSignalState eq 'SignalNotAvailable') {
		S_w2rep("Restart stopped CAN messages");
        my $signalInfo = COM_fetchSignalInfo($tcpar_COMSignal, $tcpar_Protocol);
        my $message = $signalInfo -> {'MESSAGE'};
        my $startMessageSuccessful = COM_startMessages($message, $tcpar_Protocol);

		unless($startMessageSuccessful) {
			S_set_error("Restarting can message $message was not successful!");
		}

		S_w2rep("Wait for 2 sec till the signal is transmitted on the COM bus", 'AUTO_NBR');
		S_wait_ms(2000);
	}
	
	S_w2rep("Reset manipulated COM signals to their original value.");
	foreach my $manipulatedSignal (keys %{$manipulatedCOMsignals})
	{
		if($manipulatedSignal ne $tcpar_COMSignal) {
			my $signalInfo = COM_fetchSignalInfo($manipulatedSignal, $tcpar_Protocol);
			my $message = $signalInfo -> {'MESSAGE'};
			COM_startMessages($message, $tcpar_Protocol) if $tcpar_Condition -> {$manipulatedSignal} eq 'SignalNotAvailable';
		}

		my $originalValue = $manipulatedCOMsignals -> {$manipulatedSignal};
		COM_setSignalState($manipulatedSignal, $originalValue, $tcpar_Protocol);
	}


	# Delete stored records
	foreach my $recordNbr (1..$numberOfRecordsToEvaluate)
	{
		$record_handler -> DeleteRecord("CrashLabel" => $crashLabel, "RecordNumber" => $recordNbr);
	}

 	#--------------------------------------------------------------
    # RESET HARDWARE TO INITIAL STATE
    #    
    PD_ClearCrashRecorder();
    S_wait_ms(2000);

    PD_ClearFaultMemory();
    S_wait_ms(5000);

	LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF'); 

	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');
    
    PD_ReadFaultMemory();
    S_wait_ms(2000);
    
    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

 	return 1;
}

#----------------------------------------------
# internal functions
#----------------------------------------------
sub _getRangeValues {

	my $dataStartFromByteIndex = 4 if ($tcpar_DiagType  eq 'ProdDiag');
	$dataStartFromByteIndex = 0 if ($tcpar_DiagType  eq 'AKLV');
	my $recordStructure_href;
	my $rangeOfMinMax;
	if (defined $ChinaEDR_diagType){
		$recordStructure_href = EDR_ReadCHINAEDR_Record_structure_info_from_mapping();
	}
	else {
		$recordStructure_href = EDR_ReadEDR_Record_structure_info_from_mapping($tcpar_DiagType, $dataStartFromByteIndex);			
	}
				
	$rangeOfMinMax->{'Range_Min'}=	$recordStructure_href -> {'EDIDS'}->{$tcpar_EDID}->{'Range_Min'};
	$rangeOfMinMax->{'Range_Max'}=	$recordStructure_href -> {'EDIDS'}->{$tcpar_EDID}->{'Range_Max'};
	
	return $rangeOfMinMax;
}

sub _getSineCurveValues{
    my $amplitude = shift;
    my $offset = shift;
    my $frequency_Hz = shift;
    my $stepWidth_ms = shift;
    my $numberOfPeriods = shift;
    
    my $numberOfPoints = int( $numberOfPeriods / $frequency_Hz / $stepWidth_ms *1000 +1.5);
    
    my @curvePoints;
    foreach my $index ( 0 .. $numberOfPoints - 1 ){
        my $x = $index * $stepWidth_ms / 1000 *2 * $PI;
        my $y = $amplitude * sin($frequency_Hz * $x ) + $offset;
        push(@curvePoints, $y);
    }
    
    return \@curvePoints;
}

sub _createSineWaveOnCOM{

	S_w2rep("Sine curve");
	my $range_href = _getRangeValues();
	
	my $range_Min = $range_href -> {'Range_Min'};
	my $minValue=$range_Min;
	S_w2rep("Range_Min for EDID: $minValue");
	
	my $range_Max = $range_href -> {'Range_Max'};
	my $maxValue=$range_Max;
	S_w2rep("Range_Max for EDID: $maxValue");
	
	my $signalInfo = COM_fetchSignalInfo($tcpar_COMSignal, $tcpar_Protocol);
	if (not defined $minValue or $minValue eq 'NotSpecified'){
		$minValue = $signalInfo->{'DataValueTable'}->{'Min_Value'};
		unless(defined $minValue) {
			S_set_error("No 'Min_Value' defined in 'DataValueTable' in COM mapping for signal $tcpar_COMSignal! Or No min value available in Mapping EDR.No sine wave can be generated, function will be aborted!", 110);
			return;
		}
		S_w2rep("Min value: $minValue");
	}
	
	if(not defined $maxValue or $maxValue eq 'NotSpecified'){
		$maxValue = $signalInfo->{'DataValueTable'}->{'Max_Value'};
		unless(defined $maxValue) {
			S_set_error("No 'Max_Value' defined in 'DataValueTable' in COM mapping for signal $tcpar_COMSignal! Or No min value available in Mapping EDR. No sine wave can be generated, function will be aborted!", 110);
			return;
		}
		S_w2rep(" Max value: $maxValue");
	}
	
	my $absolute_max=abs $maxValue;
	my $absolute_min=abs $minValue;
	my $amplitude = ($maxValue - $minValue) / 2; 
	S_w2rep (" absolute_max=$absolute_max");
	S_w2rep (" absolute_min=$absolute_min");
	S_w2rep (" Amplitude =$amplitude");
	my $offset = $amplitude + $minValue;
	S_w2rep("Offset: $offset");
	
	S_w2rep("Get EDID recording start and end time");
	
    my $recordStructure_href = EDR_ReadEDR_Record_structure_info_from_mapping($tcpar_DiagType);
	my $recordingStartTime_ms = $recordStructure_href -> {'EDIDS'}{$tcpar_EDID}{'RecStartTimeMillisec'};
	$recordingStartTime_ms = $recordStructure_href -> {'EDIDS'}{$tcpar_EDID}{'StartTime_ms'} if (not defined $recordingStartTime_ms);
	my $recordingEndTime_ms = $recordStructure_href -> {'EDIDS'}{$tcpar_EDID}{'RecEndTimeMillisec'};
	$recordingEndTime_ms = $recordStructure_href -> {'EDIDS'}{$tcpar_EDID}{'EndTime_ms'} if(not defined $recordingEndTime_ms);
	my $total_recording_time= abs ($recordingStartTime_ms)+ abs ($recordingEndTime_ms);
	$total_recording_time = 5000 unless($total_recording_time);
	
	my $SINE_CURVE_NUMBER_OF_PERIODS= 1 if ($total_recording_time<=5000);
	$SINE_CURVE_NUMBER_OF_PERIODS= 3 if ($total_recording_time>5000 and $total_recording_time<=10000);
	$SINE_CURVE_NUMBER_OF_PERIODS= 6 if ($total_recording_time>10000 and $total_recording_time<=15000);
	$SINE_CURVE_NUMBER_OF_PERIODS= 9 if ($total_recording_time>15000 and $total_recording_time<=20000);
	
	S_w2rep("SINE_CURVE_NUMBER_OF_PERIODS=$SINE_CURVE_NUMBER_OF_PERIODS");
	
	my $curvePoints_aref = _getSineCurveValues($amplitude, $offset, SINE_CURVE_FREQUENCY_HZ, SINE_CURVE_STEPWIDTH_MS, $SINE_CURVE_NUMBER_OF_PERIODS);

	unless(defined $curvePoints_aref) {
		S_set_error("Curve points for sine wave could not be created, function will be aborted. Check whether Min_Value and Max_Value given for $tcpar_COMSignal in COM mapping are valid", 110);
		return;
	}

	S_wait_ms(SINE_CURVE_STEPWIDTH_MS);		
	foreach my $physicalValue (@{$curvePoints_aref})
	{
		S_w2log(3, "Set $tcpar_COMSignal to $physicalValue");
		 my $valueSet;
		$valueSet = CA_write_can_signal ( $tcpar_COMSignal, $physicalValue, 'phys' ) if (lc($tcpar_Protocol) =~ m/can/i);
        $valueSet = FR_write_flxr_signal ( $tcpar_COMSignal, $physicalValue, $tcpar_Mode ) if (lc($tcpar_Protocol) =~ m/flexray/i);
		unless(defined $valueSet) {		
			S_set_warning("Setting Signal $tcpar_COMSignal to '$physicalValue' was not successful. Go to next signal value.");	
		}
		S_wait_ms(SINE_CURVE_STEPWIDTH_MS);
	}
	
	return 1;
}

sub _createRampUpOnCOM {

	S_w2rep("Ramp up signal $tcpar_COMSignal");

	my $rangeOfMinMax= _getRangeValues();
	
	my $range_Min =  $rangeOfMinMax -> {'Range_Min'};
	$tcpar_minValue=$range_Min;
	S_w2rep("Range_Min for EDID: $range_Min");
	
	my $range_Max =  $rangeOfMinMax -> {'Range_Max'};
	S_w2rep("Range_Max for EDID: $range_Max");
	$tcpar_maxValue=$range_Max;
	
	my $signalInfo = COM_fetchSignalInfo($tcpar_COMSignal, $tcpar_Protocol);
	unless(defined $tcpar_minValue or $range_Min eq 'NotSpecified') {
		my $minValue = $signalInfo->{'DataValueTable'}->{'Min_Value'};
		$tcpar_minValue=$minValue;
	}

	unless(defined $tcpar_maxValue or $range_Max eq 'NotSpecified') {
		my $maxValue = $signalInfo->{'DataValueTable'}->{'Max_Value'};
		$tcpar_maxValue=$maxValue;
	}
	
	
	S_w2rep("Min value: $tcpar_minValue, max value: $tcpar_maxValue");
	my $recordStructure_href = EDR_ReadEDR_Record_structure_info_from_mapping($tcpar_DiagType);
	my $recordingStartTime_ms = $recordStructure_href -> {'EDIDS'}{$tcpar_EDID}{'RecStartTimeMillisec'};
	$recordingStartTime_ms = $recordStructure_href -> {'EDIDS'}{$tcpar_EDID}{'StartTime_ms'} if (not defined $recordingStartTime_ms);
	my $recordingEndTime_ms = $recordStructure_href -> {'EDIDS'}{$tcpar_EDID}{'RecEndTimeMillisec'};
	$recordingEndTime_ms = $recordStructure_href -> {'EDIDS'}{$tcpar_EDID}{'EndTime_ms'} if(not defined $recordingEndTime_ms);
	my $total_recording_time= abs ($recordingStartTime_ms)+ abs ($recordingEndTime_ms);
	$total_recording_time = 5000 unless($total_recording_time);

	my $nbrOfValues = $total_recording_time / 250; # -> 20 values for a recording time of 5sec
	S_w2rep("Number of values in Ramp = $nbrOfValues (recording time: $total_recording_time ms");
	COM_rampUpSignal( $tcpar_COMSignal, 250 , $nbrOfValues , $tcpar_minValue, $tcpar_maxValue, $tcpar_Protocol);

	return 1;
}

sub _createStepUpOnCOM {

	S_teststep("Wait for 2 sec before transmitting step on the COM bus", 'AUTO_NBR');
	my $recordStructure_href = EDR_ReadEDR_Record_structure_info_from_mapping($tcpar_DiagType);
	my $recordingStartTime_ms = $recordStructure_href -> {'EDIDS'}{$tcpar_EDID}{'RecStartTimeMillisec'};
	$recordingStartTime_ms = $recordStructure_href -> {'EDIDS'}{$tcpar_EDID}{'StartTime_ms'} if (not defined $recordingStartTime_ms);
	my $recordingEndTime_ms = $recordStructure_href -> {'EDIDS'}{$tcpar_EDID}{'RecEndTimeMillisec'};
	$recordingEndTime_ms = $recordStructure_href -> {'EDIDS'}{$tcpar_EDID}{'EndTime_ms'} if(not defined $recordingEndTime_ms);
	my $total_recording_time= abs ($recordingStartTime_ms)+ abs ($recordingEndTime_ms);
	$total_recording_time = 5000 unless($total_recording_time);
	
	my $duration_ms = $total_recording_time;
	unless(defined $tcpar_StepValue1 and defined $tcpar_StepValue2) {
		S_set_error("StepUp can not be performed due to missing parameters StepValue1 and StepValue2 -> stimulation aborted");
		return;
	}
	COM_stepOrSquareSignal($tcpar_COMSignal, $tcpar_StepValue1, $duration_ms, $tcpar_StepValue2,$tcpar_Protocol);
	my $waitTimeUntilCrash = $total_recording_time / 2;
	S_teststep_2nd_level("Wait $waitTimeUntilCrash ms before injecting crash.", 'AUTO_NBR');
	S_wait_ms($waitTimeUntilCrash);

	return 1;
}

sub _createSquareWaveOnCOM {

	S_teststep("Create square wave for EDID $tcpar_EDID", 'AUTO_NBR');
	my $recordStructure_href = EDR_ReadEDR_Record_structure_info_from_mapping($tcpar_DiagType);
	my $recordingStartTime_ms = $recordStructure_href -> {'EDIDS'}{$tcpar_EDID}{'RecStartTimeMillisec'};
	$recordingStartTime_ms = $recordStructure_href -> {'EDIDS'}{$tcpar_EDID}{'StartTime_ms'} if (not defined $recordingStartTime_ms);
	my $recordingEndTime_ms = $recordStructure_href -> {'EDIDS'}{$tcpar_EDID}{'RecEndTimeMillisec'};
	$recordingEndTime_ms = $recordStructure_href -> {'EDIDS'}{$tcpar_EDID}{'EndTime_ms'} if(not defined $recordingEndTime_ms);
	my $total_recording_time= abs ($recordingStartTime_ms)+ abs ($recordingEndTime_ms);
	$total_recording_time = 5000 unless($total_recording_time);
	
	my $duration_ms = $total_recording_time;
	my $squareDuration_ms = 1000;
	unless(defined $tcpar_StepValue1 and defined $tcpar_StepValue2) {
		S_set_error("Square can not be performed due to missing parameters StepValue1 and StepValue2 -> stimulation aborted");
		return;
	}
	COM_stepOrSquareSignal($tcpar_COMSignal, $tcpar_StepValue1, $duration_ms, $tcpar_StepValue2, $tcpar_Protocol, $squareDuration_ms);
	my $waitTimeUntilCrash = $total_recording_time / 2;
	S_teststep_2nd_level("Wait $waitTimeUntilCrash ms before injecting crash.", 'AUTO_NBR');
	S_wait_ms($waitTimeUntilCrash);

	return 1;
}


1;
