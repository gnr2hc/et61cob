#### TEST CASE MODULE
package TC_EDID_EventType;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS_EDID_GenericEDIDList> 
#TS version in DOORS: <1.1> 
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use LIFT_crash_simulation;
use LIFT_PD;
use GENERIC_DCOM;
use LIFT_can_access;
use LIFT_labcar;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;

##################################

our $PURPOSE = "<This scripts validates the event type reported in EDR for different crash scenarios>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDID_EventType

=head1 PURPOSE

<This testcase used to validate event type recorded in EDR>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Inject a Crash <Crashcode>

2. Read <EDID> in all EDR records


I<B<Evaluation>>

1. -

2. <EDID> should have <EventType1> in most recent record and  <EventType2> in  oldest record


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'EventType1' => 
	SCALAR 'purpose' => 
	SCALAR 'EDID' => 
	SCALAR 'DiagType' => 
	SCALAR 'ResultDB' => 
	SCALAR 'Crashcode' => 
	SCALAR 'EventType2' => 
	SCALAR 'EventType3' => 
	SCALAR 'EventType4' => 
	SCALAR 'EventType5' => 
	SCALAR 'EventType6' => 
	SCALAR 'From' => 
	SCALAR 'EventsToBeRecorded' => 


=head2 PARAMETER EXAMPLES

	purpose		 = 'To Validate EDID event Type Reported in EDR'
	
	EDID = '<Fetch {EDID}>'
	DiagType  = 'ProdDiag' 
	ResultDB = 'EDR'
	Crashcode =  '<Fetch {Crash file name in worldDB}>'
	EventType2 = 'DafaultData'
	#DefaultData (FF) is stored in Empty Crash recorder
	From = '<Fetch {From}>'
	EventType1 = '0x00'
	EventsToBeRecorded = '1'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_EDID;
my $tcpar_DiagType;
my $tcpar_ResultDB;
my $tcpar_Crashcode;
my $tcpar_EventType1;
my $tcpar_EventType2;
my $tcpar_EventType3;
my $tcpar_EventType4;
my $tcpar_EventType5;
my $tcpar_EventType6;
my $tcpar_EventsToBeRecorded;
my $tcpar_COMsignalsAfterCrash;
my $recordNbr;

################ global parameter declaration ###################
#add any global variables here
my $record_handler;
my $recordIsThere;
my $crashSettings;
my $edrNumberOfEventsToBeStored;
my @expectedValuesPerIncident;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_EDID =  S_read_mandatory_testcase_parameter( 'EDID' );
	$tcpar_DiagType =  S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_ResultDB =  S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_Crashcode =  S_read_mandatory_testcase_parameter( 'Crashcode' );
	$tcpar_EventType1 =  S_read_mandatory_testcase_parameter( 'EventType1' );
	$tcpar_EventType2 =  S_read_optional_testcase_parameter( 'EventType2' );
	$tcpar_EventType3 =  S_read_optional_testcase_parameter( 'EventType3' );
	$tcpar_EventType4 =  S_read_optional_testcase_parameter( 'EventType4' );
	$tcpar_EventType5 =  S_read_optional_testcase_parameter( 'EventType5' );
	$tcpar_EventType6 =  S_read_optional_testcase_parameter( 'EventType6' );
	$tcpar_EventsToBeRecorded =  S_read_mandatory_testcase_parameter( 'EventsToBeRecorded' );
	$tcpar_COMsignalsAfterCrash = S_read_optional_testcase_parameter( 'COMsignalsAfterCrash','byref');

	return if(S_get_current_verdict() eq 'VERDICT_INCONC');

	$record_handler = EDR_init_RecordHandler();
	$recordIsThere = $record_handler -> IsRecordAvailable("CrashLabel" => $tcpar_Crashcode,
															"RecordNumber"      => 1 );

	if(not defined $recordIsThere){
		S_w2rep("crash will be injected and EDR data will be read in Simulation and Measurement");
		$recordIsThere=0;
	}
	 push(@expectedValuesPerIncident, $tcpar_EventType1);
	 push(@expectedValuesPerIncident, $tcpar_EventType2) if (defined $tcpar_EventType2 );
	 push(@expectedValuesPerIncident, $tcpar_EventType3) if (defined $tcpar_EventType3 );
	 push(@expectedValuesPerIncident, $tcpar_EventType4) if (defined $tcpar_EventType4 );
	 push(@expectedValuesPerIncident, $tcpar_EventType4) if (defined $tcpar_EventType5 );
	 push(@expectedValuesPerIncident, $tcpar_EventType4) if (defined $tcpar_EventType6 );

	return 1;
}

sub TC_initialization {

	S_w2rep("StandardPrepNoFault");

	S_w2rep("Initialize Record Handler");
	$record_handler = EDR_init_RecordHandler();

    if($recordIsThere == 0){
		S_w2log(1, "Power on ECU");
	    LC_ECU_On();
		S_wait_ms('TIMER_ECU_READY');
        S_w2log(1, "Initialize CD and start CAN trace");
        GDCOM_init () ; # To fetch info for CD from mapping_diag
        CA_trace_start ( );
		S_w2log(1, "Clear crash recorder");
	    PD_ClearCrashRecorder();
	    S_wait_ms(6000);
		S_w2log(1, "Clear fault memory");
	    PD_ClearFaultMemory();
	    S_wait_ms(2000);

		S_w2log(1, "Read and evaluate fault memory before stimulation");
	    my $faultsBeforeStimulation = PD_ReadFaultMemory();
        my $faultsVerdict = PD_evaluate_faults( $faultsBeforeStimulation, []);
        return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

		#--------------------------------------------------------------
        # CRASH PREPARATION
		S_w2log(1, "Prepare crash" );

	    # PREPARE CRASH AND INITIALIZE EQUIPMENT
		S_w2rep("Get crash settings for crash $tcpar_Crashcode");
	    my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode};
        $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
        unless(defined $crashSettings) {
            S_set_error("Crash $tcpar_Crashcode not available in result DB $tcpar_ResultDB. Test case aborted.");
            return;
        }

		my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
		my $resultDB_Path = $resultDBDetails->{'PATH'};
		S_w2log(1, "Crashcode: $tcpar_Crashcode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");
	    S_w2log(1, "Set environments for crash as per result DB");
        CSI_PrepareEnvironment($crashSettings, 'init_complete');

	    LC_ECU_Off();
		S_wait_ms('TIMER_ECU_READY');

		#Prepare crash
        CSI_LoadCrashSensorData2Simulator($crashSettings);

	    LC_ECU_On();
		S_wait_ms('TIMER_ECU_READY');

    }

	return 1;
}

sub TC_stimulation_and_measurement {

	# number of EDR records supported for Project
	$edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();

	unless(defined $edrNumberOfEventsToBeStored){
		S_set_error("Number of records to be stored in EDR not available in SYC - add or overwrite with Custlibrary Function");
		return;
	}

	if($recordIsThere == 0){
		
		CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    	S_wait_ms(1000);
		
		S_teststep("Inject a Crash '$tcpar_Crashcode'", 'AUTO_NBR');
		CSI_TriggerCrash();

		if (defined $tcpar_COMsignalsAfterCrash){
			foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
			{
				my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
				S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
				COM_setSignalState($signal,$dataOnCOM);
			}
		}

		#Wait time after crash
		S_wait_ms(15000);
		S_teststep("Read EDID '$tcpar_EDID' in all EDR records ", 'AUTO_NBR');
		my $dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_".$tcpar_Crashcode;
        PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');
		EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
								 	"CrashLabel" => $tcpar_Crashcode,
								 	"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								 	"StoragePath" => $dataStoragePath,
								 	);
	}
	else{
		S_teststep("Crash '$tcpar_Crashcode' is injected in 'TC_EDR_CrashInjection'", 'AUTO_NBR');
		S_teststep("Read EDID '$tcpar_EDID' in all EDR records ", 'AUTO_NBR');
	}
	return 1;
}

sub TC_evaluation {
	my $expectedData_href;
	my $storageOrder = EDR_getStorageOrder();
    return unless(defined $storageOrder);

    if($storageOrder eq 'PhysicalOrder'){
       $storageOrder =  'MostRecentLast'; #same behavior as there is no overwriting
    }
	if ($tcpar_EventsToBeRecorded==1){
		$expectedData_href -> {"Record_1"} = $tcpar_EventType1;
	}
	else {
		foreach my $incidentNbr (1..$tcpar_EventsToBeRecorded)
		{
			$recordNbr = $incidentNbr if($storageOrder eq 'MostRecentLast');
			$recordNbr = $tcpar_EventsToBeRecorded - $incidentNbr + 1 if($storageOrder eq 'MostRecentFirst');
			my $expectedDataThisIncident = $expectedValuesPerIncident[$incidentNbr - 1];
			$expectedData_href -> {"Record_$recordNbr"} = $expectedDataThisIncident;
		}
	}
	
    S_w2rep("Number of expected records = $tcpar_EventsToBeRecorded");
	for ($recordNbr = 1; $recordNbr <= $tcpar_EventsToBeRecorded; $recordNbr++)
	{
	    S_teststep("Get value for event type EDID $tcpar_EDID in record $recordNbr (crash $tcpar_Crashcode)", 'AUTO_NBR', "EventType_Record_$recordNbr");
	    my $detectedEventType = $record_handler -> GetRawEDID("EDIDnr" => $tcpar_EDID,
                                                       	 "RecordNumber" => $recordNbr,
														 "CrashLabel" => $tcpar_Crashcode,
														 "FormatOption" => "HEX");

        unless(defined $detectedEventType) {
            S_w2rep("No EDID data found for crash $tcpar_Crashcode, record $recordNbr. EDID cannot not be evaluated. Go to next record");
	        next;
		}

		my $expectedEventType = $expectedData_href -> {"Record_$recordNbr"};
		$detectedEventType = "0x".$detectedEventType;

		S_teststep_expected("'$expectedEventType'", "EventType_Record_$recordNbr"); #evaluation
		S_teststep_detected("'$detectedEventType'", "EventType_Record_$recordNbr");

		EVAL_evaluate_value( "EDID_$tcpar_EDID\_Evaluation", $detectedEventType, '==' , $expectedEventType );
    }

	return 1;
}

sub TC_finalization {
	if($recordIsThere == 0){
		S_w2log(1, "Delete record objects");
		foreach my $record (1..$edrNumberOfEventsToBeStored)
		{
			$record_handler -> DeleteRecord("CrashLabel" => $tcpar_Crashcode, "RecordNumber" => $record);
		}

		#Clearing crash recorder
		PD_ClearCrashRecorder();
		S_wait_ms(6000);
		#Erase Fault memory
		PD_ClearFaultMemory();
		S_wait_ms(2000);
		# Reset ECU
		PD_ECUreset();
		S_wait_ms('TIMER_ECU_READY');
		#Read fault memory after clearing and erasing EDR
		PD_ReadFaultMemory();

		LC_ECU_Off();
		S_wait_ms('TIMER_ECU_OFF');

	}

	return 1;
}


1;
