#### TEST CASE MODULE
package TC_EDID_EventCounter;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use GENERIC_DCOM;
use LIFT_can_access;
use LIFT_flexray_access;
use FuncLib_EDR_Framework;
use FuncLib_TNT_SYC_INTERFACE;
use Data::Dumper;


##################################

our $PURPOSE = "<To Validate Event Counter reported in EDR on Occurance of Every Crash>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDID_EventCounter

=head1 PURPOSE

<To Validate Event Counter reported in EDR on Occurance of Every Crash>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Inject  <Crashtype1> equal to <NumberOfCrashRecorders>

2.  Read  <EDID> in most recent Entry of EDR 

3. Inject  <Crashtype2> .

4  Read  <EDID>  in most recent Entry of EDR 

5. Change the Variable value to <MaxValidValue>-1

6. Read  <EDID>  in most recent Entry of EDR 

7. Inject <Crashtype1>

8. Read  <EDID>  in most recent Entry of EDR 

9. Inject  <Crashtype1>

10.Read  <EDID>  in most recent Entry of EDR

11. Inject <Crashtype1>

12.Read  <EDID>  in most recent Entry of EDR 


I<B<Evaluation>>

1.

2.  <EDID> EventCounter = <NumberOfCrashRecorders>

3.

4. EventCounter = <NumberOfCrashRecorders>+<NumberOfStoredEvents>

5.

6.

a)EventCounter = <MaxValidValue> only if all Injected crashes are no Deployment crashes

b)EventCounter = <NumberOfStoredEvents> Injected crashes are other than no Deployment crashes

7.

8 a)EventCounter = <MaxValidValue>+1 only if all Injected crashes are no Deployment crashes

b)EventCounter = <NumberOfStoredEvents> Injected crashes are other than no Deployment crashes

9.

10.a)EventCounter = <MaxValidValue>+2 only if all Injected crashes are no Deployment crashes

b)EventCounter = <NumberOfStoredEvents> Injected crashes are other than no Deployment crashes

11.

12. a)EventCounter = <MaxValidValue>+3 only if all Injected crashes are no Deployment crashes

b)EventCounter = <NumberOfStoredEvents> Injected crashes are other than no Deployment crashes


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Crashtype1' => 
	SCALAR 'Crashtype2' => 
	SCALAR 'NumberOfStoredEvents' => 
	SCALAR 'purpose' => 
	SCALAR 'EDID' => 
	SCALAR 'EventCounter_Variable' => 
	SCALAR 'NumberOfCrashRecorders' => 
	SCALAR 'MaxValidValue' => 
	SCALAR 'DiagType' => 
	SCALAR 'ResultDB' => 
	HASH 'COMsignalsAfterCrash' => 


=head2 PARAMETER EXAMPLES

	purpose = 'To Validate Event Counter reported in EDR on Occurance of Every Crash'
	
	EDID = '<Fetch {EDID}>'
	EventCounter_Variable=''
	NumberOfCrashRecorders =   '<Fetch {V_AB12Base_2015B}>'
	MaxValidValue = '3FFD'#0x3FFD
	DiagType  = 'ProdDiag' 
	ResultDB = 'EDR'
	COMsignalsAfterCrash = %()
	Crashtype1 = 'Single_EDR_Front_above_8kph_NoDeployment'
	Crashtype2 =  'Single_EDR_Side_above_8kph_NoDeployment'
	NumberOfStoredEvents = 'NumberOfCrashRecorders+1'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_EDID;
my $tcpar_DiagType;
my $tcpar_ResultDB;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_Crashtype1;
my $tcpar_Crashtype2;
my $tcpar_LockSeverity1;
my $tcpar_LockSeverity2;
my $tcpar_COM_Signal;
my $tcpar_COM_Signal_Values_aref;
my $tcpar_Protocol;

################ global parameter declaration ###################
#add any global variables here
my ($record_handler, 
	$crash_handler,
	$crashSettings1,
	$crashSettings2,
	$edrNumberOfEventsToBeStored,
	$dataStoragePath,
	$nvmStorage_href);

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_EDID =  S_read_mandatory_testcase_parameter( 'EDID' );
	$tcpar_DiagType =  S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_ResultDB =  S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_COMsignalsAfterCrash =  S_read_mandatory_testcase_parameter( 'COMsignalsAfterCrash','byref' );
	$tcpar_Crashtype1 =  S_read_mandatory_testcase_parameter( 'Crashtype1' );
	$tcpar_LockSeverity1 =  S_read_mandatory_testcase_parameter( 'LockSeverity1' );
	$tcpar_Crashtype2 =  S_read_mandatory_testcase_parameter( 'Crashtype2' );
	$tcpar_LockSeverity2 =  S_read_mandatory_testcase_parameter( 'LockSeverity2' );
	$tcpar_COM_Signal =  S_read_optional_testcase_parameter( 'COM_Signal' );
	$tcpar_COM_Signal_Values_aref =  S_read_optional_testcase_parameter( 'COM_Signal_Values' , 'byref');
	$tcpar_Protocol = S_read_optional_testcase_parameter('Protocol');
	unless(lc($tcpar_Protocol) =~ m/can/i or lc($tcpar_Protocol) =~ m/flexray/i) {
		S_w2rep("Set communication protocol to default CAN");
		$tcpar_Protocol = 'CAN';
	}

	$edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();
	unless(defined $edrNumberOfEventsToBeStored){
		S_set_error("Not available in SYC - add or overwrite with Custlibrary Function");
		return;
	}
	
	if($tcpar_LockSeverity1 ne 'NoLock' and $tcpar_LockSeverity1 ne 'Lock'){
		S_set_error("LockSeverity1 ($tcpar_LockSeverity1) given for Crashtype1 is not known. Must be either 'NoLock' or 'Lock'");
		return;
	}

	if($tcpar_LockSeverity2 ne 'NoLock' and $tcpar_LockSeverity2 ne 'Lock'){
		S_set_error("LockSeverity2 ($tcpar_LockSeverity2) given for Crashtype2 is not known. Must be either 'NoLock' or 'Lock'");
		return;
	}

	return 1;
}

sub TC_initialization {

	S_teststep("Test setup preparation", 'AUTO_NBR');

	#--------------------------------------------------------------
    # INITIALIZE RECORD AND CRASH HANDLER
    #    
	S_w2rep("Initialize Record Handler");
	$record_handler = EDR_init_RecordHandler() || return;
	
	#--------------------------------------------------------------
    # PREPARE CRASH AND INITIALIZE EQUIPMENT
    #
	S_w2rep("Get crash settings for crash $tcpar_Crashtype1");
    my $crashDetails_href1 = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashtype1};
	$crashSettings1 = CSI_GetCrashDataFromMDS($crashDetails_href1);
	unless(defined $crashSettings1) {
		S_set_error("Crash $tcpar_Crashtype1 not available in result DB $tcpar_ResultDB. Test case aborted.");
		return;
	}

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log(1, "Crashcode: $tcpar_Crashtype1, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");
	
	my $crashDetails_href2 = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashtype2};
	$crashSettings2 = CSI_GetCrashDataFromMDS($crashDetails_href2);
	unless(defined $crashSettings2) {
		S_set_error("Crash $tcpar_Crashtype2 not available in result DB $tcpar_ResultDB. Test case aborted.");
		return;
	}
	
	S_w2log(1, "Crashcode: $tcpar_Crashtype2, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");

	S_w2log(1, "Power on ECU");
    LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

    S_w2log(1, "Initialize CD and start CAN trace");
    GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start ( );

	S_w2log(1, "Set environments for crash as per result DB");
    CSI_PrepareEnvironment($crashSettings1, 'init_complete');
    S_wait_ms(2000);

	S_w2log(1, "Clear crash recorder");
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(2000);

	S_w2log(1, "Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	S_w2log(1, "Read and evaluate fault memory before stimulation");
    my $faultsBeforeStimulation = PD_ReadFaultMemory();
    my $faultsVerdict = PD_evaluate_faults( $faultsBeforeStimulation, []);
    return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Inject '$tcpar_Crashtype1' for '$edrNumberOfEventsToBeStored' times", 'AUTO_NBR');

	if($tcpar_COM_Signal)
	{
		my $physValue = $tcpar_COM_Signal_Values_aref -> [0];
		if(defined $physValue){
			CA_write_can_signal ( $tcpar_COM_Signal, $physValue, 'phys' ) if (lc($tcpar_Protocol) =~ m/can/i);
			FR_write_flxr_signal($tcpar_COM_Signal, $physValue, 'phys')	 if (lc($tcpar_Protocol) =~ m/flexray/i);
		}
		S_wait_ms(5000); 
	}

	foreach my $crashNumber (1..$edrNumberOfEventsToBeStored){
		# Prepare crash
		CSI_LoadCrashSensorData2Simulator($crashSettings1) unless $main::opt_offline;
		S_wait_ms(1000); 
		
		CSI_PrepareEnvironment( $crashSettings1, 'before_crash_same_cycle','normal' );
    	S_wait_ms(1000);
		#--------------------------------------------------------------
		# CRASH INJECTION
		#
		S_w2rep("Crash number = $crashNumber");
		$nvmStorage_href -> {"StimulationStep_1"} -> {$crashNumber} -> {'LockSeverity'} = $tcpar_LockSeverity1;
        $nvmStorage_href -> {"StimulationStep_1"} -> {$crashNumber} -> {'CrashNumber'} = $crashNumber;
		CSI_TriggerCrash();
		S_wait_ms(8000);
    }
	
	if (defined $tcpar_COMsignalsAfterCrash){
		foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
		{				
			my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
			S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
			COM_setSignalState($signal,$dataOnCOM);	
		}
	}	

	S_wait_ms(10000);
	S_teststep("Read  '$tcpar_EDID' in most recent Entry of EDR after injecting $edrNumberOfEventsToBeStored $tcpar_Crashtype1 crash", 'AUTO_NBR');			#measurement 1
	
	$dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_".$tcpar_Crashtype1;
	
	EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
							 	"CrashLabel" => $tcpar_Crashtype1."_$edrNumberOfEventsToBeStored\_Times",
							 	"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
							 	"StoragePath" => $dataStoragePath,
							 	);

	# Prepare crash
	if($tcpar_COM_Signal)
	{
		my $physValue = $tcpar_COM_Signal_Values_aref -> [1];
		if(defined $physValue){
			CA_write_can_signal ( $tcpar_COM_Signal, $physValue, 'phys' ) if (lc($tcpar_Protocol) =~ m/can/i);
			FR_write_flxr_signal($tcpar_COM_Signal, $physValue, 'phys')	 if (lc($tcpar_Protocol) =~ m/flexray/i);				
		}
		S_wait_ms(5000); 
	}

	CSI_LoadCrashSensorData2Simulator($crashSettings2);
	S_wait_ms(1000); 
	
	CSI_PrepareEnvironment( $crashSettings2, 'before_crash_same_cycle','normal' );
    S_wait_ms(1000);
	
	
	my $thisCrashNumber = $edrNumberOfEventsToBeStored + 1;		
    $nvmStorage_href -> {"StimulationStep_2"} = _copy_hash($nvmStorage_href -> {"StimulationStep_1"});
    if($tcpar_LockSeverity1 eq 'NoLock'){
        # Crash will overwrite the first stored not locked event
        $nvmStorage_href -> {"StimulationStep_2"} -> {1} -> {'LockSeverity'} = $tcpar_LockSeverity2;
        $nvmStorage_href -> {"StimulationStep_2"} -> {1} -> {'CrashNumber'} = $thisCrashNumber;
    }

	S_teststep("Inject  '$tcpar_Crashtype2' (crash $thisCrashNumber)", 'AUTO_NBR');
	#--------------------------------------------------------------
	# CRASH INJECTION
	#
	CSI_TriggerCrash();	

	S_teststep("Read '$tcpar_EDID' in most recent Entry of EDR after injecting $tcpar_Crashtype2 on full EDR (crash $thisCrashNumber)", 'AUTO_NBR');			#measurement 2
	
	$dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_".$tcpar_Crashtype2;
	S_wait_ms(15000); 
	
	EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
							 	"CrashLabel" => $tcpar_Crashtype2."_OnceAfterEDRfull",
							 	"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
							 	"StoragePath" => $dataStoragePath,
							 	);

    my $stimulationStep = 3;
	for (my $count=0; $count<=3; $count++)
	{
	    $thisCrashNumber++;

        my $previousStimulationStep = $stimulationStep - 1;
        $nvmStorage_href -> {"StimulationStep_$stimulationStep"} = _copy_hash($nvmStorage_href -> {"StimulationStep_$previousStimulationStep"});
        if($tcpar_LockSeverity1 eq 'NoLock'){
            # Crash will overwrite the first stored not locked event
            my $nvmBufferToOverwrite;
            my $oldestNotLockedCrashNumber;
            foreach my $nvmBuffer (1..$edrNumberOfEventsToBeStored){
                my $lockSeverity = $nvmStorage_href -> {"StimulationStep_$stimulationStep"} -> {$nvmBuffer} -> {'LockSeverity'};
                next unless($lockSeverity eq 'NoLock');
                my $currentCrashNumber = $nvmStorage_href -> {"StimulationStep_$stimulationStep"} -> {$nvmBuffer} -> {'CrashNumber'};
                if(not defined $oldestNotLockedCrashNumber){
                    $oldestNotLockedCrashNumber = $currentCrashNumber;
                    $nvmBufferToOverwrite = $nvmBuffer;
                    next;
                }
                if($currentCrashNumber < $oldestNotLockedCrashNumber){
                    $oldestNotLockedCrashNumber = $currentCrashNumber;
                    $nvmBufferToOverwrite = $nvmBuffer;                    
                }
            }
            if(defined $nvmBufferToOverwrite){
                $nvmStorage_href -> {"StimulationStep_$stimulationStep"} -> {$nvmBufferToOverwrite} -> {'LockSeverity'} = $tcpar_LockSeverity1;
                $nvmStorage_href -> {"StimulationStep_$stimulationStep"} -> {$nvmBufferToOverwrite} -> {'CrashNumber'} = $thisCrashNumber;                
            }
        }
        # else nothing will be overwritten

		# Prepare crash
		if($tcpar_COM_Signal)
		{
			my $physValue = $tcpar_COM_Signal_Values_aref -> [$count + 2];
			if(defined $physValue){
				CA_write_can_signal ( $tcpar_COM_Signal, $physValue, 'phys' ) if (lc($tcpar_Protocol) =~ m/can/i);
				FR_write_flxr_signal($tcpar_COM_Signal, $physValue, 'phys')	 if (lc($tcpar_Protocol) =~ m/flexray/i);				
			}			
			S_wait_ms(5000); 
		}

		CSI_LoadCrashSensorData2Simulator($crashSettings1);
		S_wait_ms(1000); 
		
		CSI_PrepareEnvironment( $crashSettings1, 'before_crash_same_cycle','normal' );
    	S_wait_ms(1000);
		
		
		S_teststep("Inject '$tcpar_Crashtype1' (crash $thisCrashNumber)", 'AUTO_NBR');
		CSI_TriggerCrash();
		S_wait_ms(15000);

		S_teststep("Read  '$tcpar_EDID'  in most recent Entry of EDR (after $thisCrashNumber crashes)", 'AUTO_NBR');					#measurement 3
		
		$dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_".$tcpar_Crashtype1."_$count";
        my $Crash_Label = $tcpar_Crashtype1."_$thisCrashNumber\_Crashes";
		
		EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
									"CrashLabel" => $Crash_Label,
									"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
									"StoragePath" => $dataStoragePath,
									);
	   $stimulationStep++;
	}

	return 1;
}

sub TC_evaluation {

    my $storageOrder = EDR_getStorageOrder ();
    unless(defined $storageOrder) {
        S_set_error("Define storage order in EDR mapping! Must be 'MostRecentFirst', 'MostRecentLast', or 'PhysicalOrder'");
        return;
    }

    # Add record numbers to expected NVM buffers according to storage order
    foreach my $stimulationStep(1..6){
        my $crashNumbersStored_href; #CrashNumber -> NVM buffer
        foreach my $nvmBuffer(1..$edrNumberOfEventsToBeStored){
            if($storageOrder eq 'PhysicalOrder'){
                $nvmStorage_href -> {"StimulationStep_$stimulationStep"} -> {$nvmBuffer} -> {'RecordNumber'} = $nvmBuffer;
            }
            else{
                #sort in chronological order
                $crashNumbersStored_href -> {$nvmStorage_href -> {"StimulationStep_$stimulationStep"} -> {$nvmBuffer} -> {'CrashNumber'}} = $nvmBuffer;
            }
        }
        if($storageOrder ne 'PhysicalOrder'){
            my $recordNbr;
            $recordNbr = 1 if($storageOrder eq 'MostRecentLast');
            $recordNbr = $edrNumberOfEventsToBeStored if($storageOrder eq 'MostRecentFirst');
            foreach my $crashNumber(sort {$a <=> $b} keys %{$crashNumbersStored_href}){
                my $thisCrashNvmBuffer = $crashNumbersStored_href -> {$crashNumber};
                $nvmStorage_href -> {"StimulationStep_$stimulationStep"} -> {$thisCrashNvmBuffer} -> {'RecordNumber'} = $recordNbr;
                $recordNbr++ if($storageOrder eq 'MostRecentLast');
                $recordNbr-- if($storageOrder eq 'MostRecentFirst');
            }
        }
    }

    my $dataElement;
    foreach my $stimulationStep (1..6){
        my ($recordLabel, $numberOfCrashes);
        if($stimulationStep == 1){
            $recordLabel = $tcpar_Crashtype1."_$edrNumberOfEventsToBeStored\_Times"; #Number of NVM buffers = Number of crashes
            $dataElement = $record_handler -> GetDataElementEDID( "EDIDnr" => $tcpar_EDID,
                                                                    "RecordNumber" => 1,
                                                                    "CrashLabel" => $recordLabel);
            $numberOfCrashes = $edrNumberOfEventsToBeStored;
        }
        elsif($stimulationStep == 2){
            $recordLabel = $tcpar_Crashtype2."_OnceAfterEDRfull"; #Number of NVM bufffers + 1 = Number of crashes
            $numberOfCrashes = $edrNumberOfEventsToBeStored + 1;
        }
        else{
            $numberOfCrashes = $edrNumberOfEventsToBeStored + $stimulationStep - 1;
            $recordLabel = $tcpar_Crashtype1."_$numberOfCrashes\_Crashes";
        }

        S_teststep( "EDID $tcpar_EDID ($dataElement) validation after $numberOfCrashes crashes", 'AUTO_NBR', "$recordLabel");
        foreach my $nvmBuffer (1..$edrNumberOfEventsToBeStored){
            my $record_number = $nvmStorage_href -> {"StimulationStep_$stimulationStep"} -> {$nvmBuffer} -> {'RecordNumber'};

            S_teststep_2nd_level( "NVM buffer $nvmBuffer, stored in record number $record_number", 'AUTO_NBR', "$recordLabel\_$record_number");
                            
            my $edidData = $record_handler -> GetDecodedEDID("CrashLabel" => $recordLabel, "RecordNumber" => $record_number,"EDIDnr" => $tcpar_EDID );
            my $detectedValue = $edidData -> {"DataValue"};
            my $unit = $edidData -> {"ValueUnit"};          
                     
            unless(defined $detectedValue) {
                S_set_error("No data could be obtained for EDID $tcpar_EDID ");
                next;
            }
            
            my $expected_data = $nvmStorage_href -> {"StimulationStep_$stimulationStep"} -> {$nvmBuffer} -> {'CrashNumber'};
            EVAL_evaluate_value ( "EDID_$tcpar_EDID\_Evaluation", $detectedValue,'==', $expected_data );
            S_teststep_expected("EDID '$tcpar_EDID' EventCounter = $expected_data", "$recordLabel\_$record_number");         #evaluation 1
            S_teststep_detected("EDID '$tcpar_EDID' EventCounter = $detectedValue", "$recordLabel\_$record_number");
        }    
    }
	
	return 1;
}

sub TC_finalization {

	S_w2rep("Start test case finalization...");

	foreach my $recordNumber (1..$edrNumberOfEventsToBeStored)
	{
		$record_handler -> DeleteRecord("CrashLabel" => $tcpar_Crashtype1."_$edrNumberOfEventsToBeStored\_Times", "RecordNumber" => $recordNumber);
		$record_handler -> DeleteRecord("CrashLabel" => $tcpar_Crashtype2."_OnceAfterEDRfull", "RecordNumber" => $recordNumber);
		my $thisNumber = $edrNumberOfEventsToBeStored + 2;
        $record_handler -> DeleteRecord("CrashLabel" => $tcpar_Crashtype1."_$thisNumber\_Crashes", "RecordNumber" => $recordNumber);
        $thisNumber = $edrNumberOfEventsToBeStored + 3;
        $record_handler -> DeleteRecord("CrashLabel" => $tcpar_Crashtype1."_$thisNumber\_Crashes", "RecordNumber" => $recordNumber);
        $thisNumber = $edrNumberOfEventsToBeStored + 4;
        $record_handler -> DeleteRecord("CrashLabel" => $tcpar_Crashtype1."_$thisNumber\_Crashes", "RecordNumber" => $recordNumber);
        $thisNumber = $edrNumberOfEventsToBeStored + 5;
        $record_handler -> DeleteRecord("CrashLabel" => $tcpar_Crashtype1."_$thisNumber\_Crashes", "RecordNumber" => $recordNumber);		
	}

	# Erase EDR
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(5000);

	# Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	# Read fault memory after clearing and erasing EDR
    PD_ReadFaultMemory();   

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

	return 1;
}

sub _copy_hash {
    my $inputHash = shift;
    
    my $outputHash;
    foreach my $nvmBuffer (1..$edrNumberOfEventsToBeStored){
        $outputHash -> {$nvmBuffer} -> {'LockSeverity'} = $inputHash -> {$nvmBuffer} -> {'LockSeverity'};
        $outputHash -> {$nvmBuffer} -> {'CrashNumber'} = $inputHash -> {$nvmBuffer} -> {'CrashNumber'};
    }
    
    return $outputHash;
}

1;
