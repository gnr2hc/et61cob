#### TEST CASE MODULE
package TC_EDID_SwitchState_Validation;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general;
use LIFT_evaluation;
use FuncLib_EDR_Framework;
use File::Basename;
use Data::Dumper;
use EDR_Framework::FuncLib_EDR_Offline_xmlLogging;

##################################
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_SwitchState_Validation  $Revision: 1.10 $

requires raw EDR data (setup already done in IC)

default state is faultfree ECU powered ON

=head1 PURPOSE

to implement EDR Testing Framework

=head1 TESTCASE DESCRIPTION 

    [initialisation]
    initialize record handler
    initialize crash handler

    [stimulation & measurement]
	1. Inject Crash (No actual crash injection, crash data in crash handler is used)
	2. Read EDR for crash (stored data in record handler is used)

    [evaluation]
    1. Compare expected switch state to the one stored in EDR

    [finalisation]
    not needed

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

	EDID 					--> data element ID of the switch to be validated
	SwitchLabel 			--> Label of the switch to be validated

=head2 PARAMETER EXAMPLES

	[TC_EDID_SwitchState_Validation.BLFD] 
	EDID = '2002'
	SwitchLabel = 'BLFD'

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_EDIDNbr;
my $tcpar_SwitchLabel;
my $tcpar_purpose;
my $tcpar_ExpectedSwitchStateNotKnown; # switch state is not known e.g. if the switch is not configured and not monitored

################ global parameter declaration ###################
#add any global variables here
my(
    $record_handler,
    $crash_handler,
);

our $PURPOSE;
our $TC_name = "TC_EDR_SwitchState_Validation";

#-------------------------------------------------------------------------------
sub TC_set_parameters {
#-------------------------------------------------------------------------------
    $tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_EDIDNbr = S_read_mandatory_testcase_parameter('EDID');
    $tcpar_SwitchLabel = S_read_mandatory_testcase_parameter('SwitchLabel');
    $tcpar_ExpectedSwitchStateNotKnown = S_read_optional_testcase_parameter('ExpectedSwitchStateNotKnown');
    $tcpar_ExpectedSwitchStateNotKnown = 'Unknown' unless(defined $tcpar_ExpectedSwitchStateNotKnown);
	S_add2eval_collection ( 'EDID' , $tcpar_EDIDNbr);
	my $allAttributes = EDR_fetchEDIDallAttributes_by_ID($tcpar_EDIDNbr);
	S_add2eval_collection('EDID From', $allAttributes -> {'From'}) if (defined $allAttributes -> {'From'});

	return 1;
}

#-------------------------------------------------------------------------------
sub TC_initialization {
#-------------------------------------------------------------------------------
	#--------------------------------------------------------------
    # INITIALIZE RECORD AND CRASH HANDLER
    #    
	$record_handler = EDR_init_RecordHandler() || return;
	$crash_handler  = EDR_init_CrashHandler() || return;

    return 1;
}

#-------------------------------------------------------------------------------
sub TC_stimulation_and_measurement {
#-------------------------------------------------------------------------------
	S_w2rep("No stimulation needed");
    return 1;
}

#-------------------------------------------------------------------------------
sub TC_evaluation {
#-------------------------------------------------------------------------------
	my $storedCrashLabels_aref = $record_handler -> GetListOfStoredRecords();
	
	foreach my $crash (@{$storedCrashLabels_aref})
	{
		my $crashCode_MDS = $crash_handler -> GetSourceDataValues ( "SourceLabel" => "CrashCode_MDS", "CrashLabel"  => $crash );
		$crashCode_MDS = $crashCode_MDS -> {"DataValues"};

		my $path_MDB = $crash_handler -> GetSourceDataValues ( "SourceLabel" => "MDB_Path", "CrashLabel"  => $crash );
		$path_MDB = $path_MDB -> {"DataValues"};

		S_w2rep("#---------------------------------------------");
		S_w2rep("Switch $tcpar_SwitchLabel, Crash $crash");
		S_w2log(1, "Crash code: $crashCode_MDS");
		S_w2log(1, "Result DB path: $path_MDB");
		S_w2rep("#---------------------------------------------");

        #-----------------------------------------------------------------------
        # Get crash time zero
        #-----------------------------------------------------------------------
		my $crashTimeZero = $crash_handler -> GetSourceDataValues ( "SourceLabel" => "CrashTimeZero",
															        "CrashLabel"  => $crash );
		unless(defined $crashTimeZero) {
			S_set_error("No crash time zero stored for crash $crash. No evaluation possible. Try next crash.", 110);
			next;
		}
		my $crashTimeZero_ms = $crashTimeZero -> {"DataValues"};
		my $crashTimeZeroUnit = $crashTimeZero -> {"DataUnit"};
		if($crashTimeZeroUnit ne "ms") {
			S_set_error("Crash Time zero must be stored in ms!! Go to next crash.", 110);
			next;
		}

		#--------------------------------------------------------------
	    # GET SWITCH STATE DURING CRASH
		#    
		S_w2log(1, "Get expected switch state for '$tcpar_SwitchLabel' in crash $crash");
		my $sourceData = $crash_handler -> GetSourceDataSamples ( "SourceLabel" => $tcpar_SwitchLabel,
																  "CrashLabel"  => $crash ); 

		my $expectedSwitchState;
		if(defined $sourceData) {
			$expectedSwitchState = $sourceData -> {'DataValues'};		}
		else {
			S_w2rep("No switch state data found for crash $crash. Expected switch state will be set to $tcpar_ExpectedSwitchStateNotKnown");
			$expectedSwitchState = $tcpar_ExpectedSwitchStateNotKnown;
		}

        my $switchStateMapping = S_get_contents_of_hash_NOERROR(['Mapping_EDR', 'SwitchStates']);
        my $edrSwitchStates_href = {};
        if(defined $switchStateMapping){
	       foreach my $specifiedSwitchState (sort keys %{$switchStateMapping}){
	        	foreach my $edrSwitchState (@{$switchStateMapping -> {$specifiedSwitchState}}){
	        		$edrSwitchStates_href -> {$edrSwitchState} = $specifiedSwitchState;
	        	}
	        }        	
        }

		#--------------------------------------------------------------
	    # GET SWITCH STATE STORED IN EDR
		#    
		my @allCrashTimeZeros = split('_', $crashTimeZero_ms);
		my $numberOfIncidents = @allCrashTimeZeros;

		S_w2rep("Crash $crash has $numberOfIncidents incidents stored in EDR");
		my $thisSwitchDataElement = $record_handler -> GetDataElementEDID("EDIDnr" => $tcpar_EDIDNbr, 
                                                            "RecordNumber" => 1, 
                                                            "CrashLabel" => $crash);


		S_teststep("Evaluate EDID $tcpar_EDIDNbr ($thisSwitchDataElement)", 'AUTO_NBR');
		
		foreach my $recordNbr (1..$numberOfIncidents)
		{
			S_teststep("Switch State Evaluation for Crash $crash, record $recordNbr", 'AUTO_NBR', "Evaluation EDID $tcpar_EDIDNbr crash $crash record $recordNbr");
			S_w2log(1, "Get EDID data for switch '$tcpar_SwitchLabel' from crash $crash (record $recordNbr");
	        my $edidData = $record_handler -> GetDecodedEDID("CrashLabel" => $crash, 
	                                                         "RecordNumber" => $recordNbr,
	                                                         "EDIDnr" => $tcpar_EDIDNbr ); 	    

			unless(defined $edidData) {
				S_w2rep("No EDID data found for crash $crash, record $recordNbr. EDID will not be evaluated. Go to next record");
				next;
			}

			my $detectedSwitchState = $edidData -> {'DataValue'};
			if(defined $edrSwitchStates_href -> {$detectedSwitchState}){
				$detectedSwitchState = $edrSwitchStates_href -> {$detectedSwitchState};
			}

			#--------------------------------------------------------------
		    # COMPARE EXPECTED AND DETECTED SWITCH STATE
			#    
			S_teststep_expected("Expected switch state: $expectedSwitchState", "Evaluation EDID $tcpar_EDIDNbr crash $crash record $recordNbr");
			S_teststep_detected("Detected switch state: $detectedSwitchState", "Evaluation EDID $tcpar_EDIDNbr crash $crash record $recordNbr");

			S_w2log(1, "Compare expected and detected values", 'AUTO_NBR');
	        my $verdict = EVAL_evaluate_string ( $tcpar_SwitchLabel,
	            	    						 $expectedSwitchState,
	    	    								 $detectedSwitchState,
	        							   	   );

			if(S_get_exec_option_NOERROR('CreisOfflineEvalReporting')){
				$thisSwitchDataElement =~s/'/_/g;
				FLEDR_XML_addStaticEdidNode(
						$recordNbr, # record number
						'Switches',
						$tcpar_EDIDNbr,
						$tcpar_SwitchLabel." - ".$thisSwitchDataElement,
						$expectedSwitchState,
						$detectedSwitchState,
						'n/a',
						'n/a',
						$verdict,
				);
		    }
		}
	    # next crash 
	}
	
    return 1;
}

#-------------------------------------------------------------------------------
sub TC_finalization {
#-------------------------------------------------------------------------------
	S_w2rep("Finalization - nothing to be done");

	return 1;
}


#-------------------------------------------------------------------------------------------------------------------


1;