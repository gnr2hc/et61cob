#### TEST CASE MODULE
package TC_EDID_ClippingTime_Validation;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use GENERIC_DCOM;
use LIFT_can_access;
use constant MILLISEC_TO_SECOND => 0.001;
use FuncLib_EDR_Framework;
use FuncLib_TNT_SYC_INTERFACE;
use Data::Dumper;
use EDR_Framework::FuncLib_EDR_Offline_xmlLogging;

##################################

our $PURPOSE = "<To validate the time when sensor measured signal value first exceeds its design range>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDID_ClippingTime_Validation

=head1 PURPOSE

<To validate the time when sensor measured signal value first exceeds its design range>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Inject  <Crashcode> 

2. Wait <WaitTimeBetweenCrashes> if <Crashcode2> is defined

3. Inject <Crashcode2>

4. Read all EDR records

5. Extract <EDID> from record


I<B<Evaluation>>

1. -

2. -

3. -

4. -

5. <EDID> should have the time value when sensor went to clipping as per injected crash scenario.

Check Data is Stored according to defined coordinate system. 

Note: For Parallel and Multi event crashes it has to be ensured that the data is captured wrt to T0 of each event. For T0. Check Across the Injected Crash File


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Crashcode' => 
	SCALAR 'CrashTimeZero_ms' => 
	SCALAR 'purpose' => 
	SCALAR 'EDID' => 
	SCALAR 'EvalType' => 
	SCALAR 'EvalTolerance_abs' => 
	SCALAR 'SensorLabel' => 
	HASH 'COMsignalsAfterCrash' => 


=head2 PARAMETER EXAMPLES

	purpose = 'To validate RGB data reported in EDR'
	
	EDID = '<Fetch {EDID}>'
	EvalType = 'ClippingTime'
	EvalTolerance_abs = '2'
	SensorLabel = 'ECU: Acc_MG: -X: SMI7x0_sync_axay_35g_246Hz' # High G X
	COMsignalsAfterCrash = %()
	Crashcode = 'Single_EDR_Front_ClipEcuX'
	CrashTimeZero_ms = '11.76'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_EDID;
my $tcpar_EvalTolerance_abs;
my $tcpar_SensorLabel;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_Crashcode1;
my $tcpar_Crashcode2;
my $tcpar_CrashTimeZero1_ms;
my $tcpar_CrashTimeZero2_ms;
my $tcpar_DiagType;
my $tcpar_ResultDB;
my $tcpar_WaitTimeBetweenCrashes;
my $tcpar_Expected_NoClipping;
my $tcpar_read_NHTSAEDR;
my $tcpar_read_CHINAEDR;
my $tcpar_ClippingNotExpectedInRecord;
################ global parameter declaration ###################
#add any global variables here
my ( $record_handler, $crash_handler,$recordIsThere_FirstCrash, $recordIsThere_SecondCrash, $crashSettings, $crashSettings_Crash2, $edrNumberOfEventsToBeStored, $CrashLabel, $tcpar_CompareValues_CT, $dataStoragePath, $crashDuration_Incident1, $crashDuration_Incident2, $ChinaEDR_diagType );

###############################################################

sub TC_set_parameters {

	# Parameters required for online and offline tests
	$tcpar_purpose           = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_EDID              = S_read_mandatory_testcase_parameter('EDID');
	$tcpar_EvalTolerance_abs = S_read_mandatory_testcase_parameter('EvalTolerance_abs');
	$tcpar_SensorLabel       = S_read_optional_testcase_parameter('SensorLabel');
	if ( not defined $tcpar_SensorLabel ) {
		$tcpar_SensorLabel = EDR_getEdidSensorLabel($tcpar_EDID);
	}

	$tcpar_Expected_NoClipping = S_read_optional_testcase_parameter('Expected_NoClipping');

	$record_handler = EDR_init_RecordHandler() || return;
	$crash_handler  = EDR_init_CrashHandler()  || return;
	my $storedCrashLabels_aref = $record_handler->GetListOfStoredRecords();

	if (  S_get_exec_option_NOERROR('OfflineReportValidation')) {

		$tcpar_Crashcode1 = $storedCrashLabels_aref->[0];    # in report validation, only one crash code is injected at beginning of list
		my $crashTimeZero = $crash_handler->GetSourceDataValues(
			"SourceLabel" => "CrashTimeZero",
			"CrashLabel"  => $tcpar_Crashcode1,
		);

		unless ( defined $crashTimeZero ) {
			S_set_error( "No crash time zero stored for crash $tcpar_Crashcode1. No evaluation of clipping time possible", 110 );
			return;
		}
		$tcpar_CrashTimeZero1_ms = $crashTimeZero->{"DataValues"};
		my $crashTimeZeroUnit = $crashTimeZero->{"DataUnit"};
		if ( $crashTimeZeroUnit ne "ms" ) {
			S_set_error( "Crash Time zero must be stored in ms!! No validation possible", 110 );
			return;
		}
	}
	else {    # parameters required only for online test
		$tcpar_DiagType               = S_read_mandatory_testcase_parameter('DiagType');
		$tcpar_ResultDB               = S_read_mandatory_testcase_parameter('ResultDB');
		$tcpar_WaitTimeBetweenCrashes = S_read_optional_testcase_parameter('WaitTimeBetweenCrashes');
		$tcpar_COMsignalsAfterCrash   = S_read_optional_testcase_parameter( 'COMsignalsAfterCrash', 'byref' );
		$tcpar_Crashcode1             = S_read_mandatory_testcase_parameter('Crashcode1');
		$tcpar_CrashTimeZero1_ms      = S_read_mandatory_testcase_parameter('CrashTimeZero1_ms');
		$tcpar_Crashcode2             = S_read_optional_testcase_parameter('Crashcode2');
		$tcpar_CrashTimeZero2_ms      = S_read_optional_testcase_parameter('CrashTimeZero2_ms');
		$tcpar_ClippingNotExpectedInRecord=S_read_optional_testcase_parameter('ClippingNotExpectedInRecord');
	}

	$tcpar_read_NHTSAEDR = S_read_optional_testcase_parameter('read_NHTSAEDR');
	$tcpar_read_CHINAEDR = S_read_optional_testcase_parameter('read_CHINAEDR');

	if ( not defined $tcpar_read_CHINAEDR ) {
		$tcpar_read_NHTSAEDR = 'yes';
		$tcpar_read_CHINAEDR = 'no';
	}
	else {
		$tcpar_read_NHTSAEDR = 'no';
		my $storageOrder = EDR_getStorageOrder();
		return unless ( defined $storageOrder );

		if ( $storageOrder eq 'PhysicalOrder' ) {
			$ChinaEDR_diagType = 'ProdDiag';    #In platform NHTSA and China EDR is read via proddiag
		}
		else {
			$ChinaEDR_diagType = 'CHINA_Payload';
		}
	}

	S_add2eval_collection( 'EDID', $tcpar_EDID );
	my $allAttributes = EDR_fetchEDIDallAttributes_by_ID($tcpar_EDID);
	S_add2eval_collection( 'EDID From', $allAttributes->{'From'} ) if ( defined $allAttributes->{'From'} );

	$recordIsThere_FirstCrash = $record_handler->IsRecordAvailable( "CrashLabel" => $tcpar_Crashcode1, "RecordNumber" => 1 );
	
	if (not defined $recordIsThere_FirstCrash){
		S_w2rep("Crash will be injected and EDR data will be read in Simulation and Measurement");
		$recordIsThere_FirstCrash=0;
	}	

	if(defined $tcpar_Crashcode2){
		$CrashLabel= $tcpar_Crashcode1."_".$tcpar_Crashcode2;
		$recordIsThere_FirstCrash=0; # Crash will have to be injected because of the multi-event timing, even if the first crash code is available
	}
	else {
		$CrashLabel = $tcpar_Crashcode1;
	}

	$dataStoragePath = "$main::REPORT_PATH/" . S_get_TC_number() . "_" . $CrashLabel;

	return 1;
}

sub TC_initialization {
	
	if ( $recordIsThere_FirstCrash == 0 ) {

		S_teststep( "Test setup preparation", 'AUTO_NBR' );

		#--------------------------------------------------------------
		# PREPARE CRASH AND INITIALIZE EQUIPMENT
		#
		S_w2rep("Get crash settings for crash $tcpar_Crashcode1");
		my $crashDetails_href = { "RESULTDB" => $tcpar_ResultDB, 'CRASHNAME' => $tcpar_Crashcode1 };
		$crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
		unless ( defined $crashSettings ) {
			S_set_error("Crash $tcpar_Crashcode1 not available in result DB $tcpar_ResultDB. Test case aborted.");
			return;
		}
		$crashDuration_Incident1 = $crashSettings->{'METADATA'}->{'CRASHDURATION_MS'};
		$crash_handler->AddCrashSource(
			"CrashLabel"         => $tcpar_Crashcode1,
			"SourceLabel"        => 'CrashDuration',
			"OriginalSourceData" => $crashDuration_Incident1,
			"SourceUnit"         => 'ms',
		);
		S_w2rep("crashDuration_Incident1=$crashDuration_Incident1");

		my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
		my $resultDB_Path = $resultDBDetails->{'PATH'};
		S_w2log( 1, "Crashcode: $tcpar_Crashcode1, ResultDB: $tcpar_ResultDB (path: $resultDB_Path) loaded" );

		EDR_addSensorDataToCrashHandler( "Crash_href" => $crashDetails_href, "CrashLabel" => $tcpar_Crashcode1, );

		if ( defined $tcpar_Crashcode2 ) {
			S_w2rep("Get crash settings for crash $tcpar_Crashcode2");
			$crashDetails_href       = { "RESULTDB" => $tcpar_ResultDB, 'CRASHNAME' => $tcpar_Crashcode2 };
			$crashSettings_Crash2    = CSI_GetCrashDataFromMDS($crashDetails_href);
			$crashDuration_Incident2 = $crashSettings_Crash2->{'METADATA'}->{'CRASHDURATION_MS'};
			$crash_handler->AddCrashSource(
				"CrashLabel"         => $tcpar_Crashcode2,
				"SourceLabel"        => 'CrashDuration',
				"OriginalSourceData" => $crashDuration_Incident2,
				"SourceUnit"         => 'ms',
			);
			unless ( defined $crashSettings ) {
				S_set_error("Crash $tcpar_Crashcode2 not available in result DB $tcpar_ResultDB. Test case aborted.");
				return;
			}
			EDR_addSensorDataToCrashHandler( "Crash_href" => $crashDetails_href, "CrashLabel" => $tcpar_Crashcode2, );

			S_w2log( 1, "Crashcode: $tcpar_Crashcode2, ResultDB: $tcpar_ResultDB (path: $resultDB_Path) loaded" );
		}

		S_w2log( 1, "Power on ECU" );
		LC_ECU_On();
		S_wait_ms('TIMER_ECU_READY');

		S_w2log( 1, "Initialize CD and start CAN trace" );
		GDCOM_init();    # To fetch info for CD from mapping_diag
		CA_trace_start();

		S_w2log( 1, "Set environments for crash as per result DB" );
		CSI_PrepareEnvironment( $crashSettings, 'init_complete' );
		S_wait_ms(2000);

		S_w2log( 1, "Clear crash recorder" );
		PD_ClearCrashRecorder_NOERROR();
		S_wait_ms(2000);

		S_w2log( 1, "Clear fault memory" );
		PD_ClearFaultMemory();
		S_wait_ms(2000);

		S_w2log( 1, "Read and evaluate fault memory before stimulation" );
		my $faultsBeforeStimulation = PD_ReadFaultMemory();
		my $faultsVerdict = PD_evaluate_faults( $faultsBeforeStimulation, [] );
		return 0 unless ( $faultsVerdict eq 'VERDICT_PASS' );

		# Prepare crash
		S_teststep( "Prepare crash", 'AUTO_NBR' );
		LC_ECU_Off();
		S_wait_ms('TIMER_ECU_OFF');

		# Prepare crash
		CSI_LoadCrashSensorData2Simulator($crashSettings);

		# Power ON the ECU
		LC_ECU_On();
		S_wait_ms('TIMER_ECU_READY');
	}

	return 1;
}

sub TC_stimulation_and_measurement {

	#--------------------------------------------------------------
	# CRASH INJECTION
	#
	if ( $recordIsThere_FirstCrash == 0 ) {
		CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    	S_wait_ms(1000);
		S_teststep( "Inject  '$tcpar_Crashcode1' ", 'AUTO_NBR' );
		CSI_TriggerCrash();
	}
	else {
		S_teststep( "'$tcpar_Crashcode1' is already injected, no crash injection will be done ", 'AUTO_NBR' );
		return 1;
	}

	if ( not defined $tcpar_Crashcode2 ) {
		S_wait_ms(15000);
	}
	else {
		my $time_start_sec = S_get_TC_time();

		#--------------------------------------------------------------
		# PREPARE CRASH
		#
		S_wait_ms(500);
		CSI_LoadCrashSensorData2Simulator($crashSettings_Crash2);

		my $time_end_sec     = S_get_TC_time();
		my $time_elapsed_sec = $time_end_sec - $time_start_sec;

		my $time_elapsed = $time_elapsed_sec * 1000;    # converted time from secs to millisecs

		if ( $time_elapsed < $tcpar_WaitTimeBetweenCrashes ) {
			my $wait_time = $tcpar_WaitTimeBetweenCrashes - $time_elapsed;
			S_teststep( "Wait '$wait_time' msec since $time_elapsed msec is elapsed. ", 'AUTO_NBR' );
			S_wait_ms($wait_time);
		}
		else {
			S_teststep( " Waited for '$time_elapsed' msec already, no additional wait time is required. ", 'AUTO_NBR' );
		}

		CSI_PrepareEnvironment( $crashSettings_Crash2, 'before_crash_same_cycle','normal' );
    	S_wait_ms(1000);
		S_teststep( "Inject '$tcpar_Crashcode2'", 'AUTO_NBR' );

		#--------------------------------------------------------------
		# CRASH INJECTION
		#
		CSI_TriggerCrash();
		S_wait_ms(15000);
	}

	if ( defined $tcpar_COMsignalsAfterCrash ) {
		foreach my $signal ( keys %{$tcpar_COMsignalsAfterCrash} ) {
			my $dataOnCOM = $tcpar_COMsignalsAfterCrash->{$signal};
			S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
			COM_setSignalState( $signal, $dataOnCOM );
		}

	}

	$edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();
	unless ( defined $edrNumberOfEventsToBeStored ) {
		S_set_error("Number of records to store not available in SYC - add or overwrite with Custlibrary Function");
		return;
	}

	S_teststep( "Read all EDR records", 'AUTO_NBR' );
	PD_ECUlogin() if ( $tcpar_DiagType eq 'ProdDiag' );
	if ( lc($tcpar_read_NHTSAEDR) eq 'yes' ) {
		EDR_ReadAndStoreAllRecords(
			"DiagType"     => $tcpar_DiagType,
			"CrashLabel"   => $CrashLabel,
			"NbrOfRecords" => $edrNumberOfEventsToBeStored,
			"StoragePath"  => $dataStoragePath,
			"read_EDRType" => 'NHTSA'
		);
	}
	if ( lc($tcpar_read_CHINAEDR) eq 'yes' ) {
		$edrNumberOfEventsToBeStored = 3;
		EDR_ReadAndStoreAllRecords(
			"DiagType"     => $ChinaEDR_diagType,
			"CrashLabel"   => $CrashLabel,
			"NbrOfRecords" => $edrNumberOfEventsToBeStored,
			"StoragePath"  => $dataStoragePath,
			"read_EDRType" => 'CHINA'
		);

	}

	return 1;
}

sub TC_evaluation {

	my $storageOrder = EDR_getStorageOrder();
	unless ( defined $storageOrder ) {
		S_set_error("Define storage order in EDR mapping!");
		return;
	}
	if ( $storageOrder eq 'PhysicalOrder' ) {
		$storageOrder = 'MostRecentLast';    #same behavior as there is no overwriting
	}

	my $CrashRecord;
	my $detectedClippingTime;
	if ( defined $tcpar_Crashcode2 ) {
		$CrashRecord = { 'Record_1' => { 'CrashTimeZero' => $tcpar_CrashTimeZero1_ms, 'CrashCode' => $tcpar_Crashcode1 }, 'Record_2' => { 'CrashTimeZero' => $tcpar_CrashTimeZero2_ms, 'CrashCode' => $tcpar_Crashcode2 } } if ( $storageOrder eq 'MostRecentLast' );
		$CrashRecord = { 'Record_1' => { 'CrashTimeZero' => $tcpar_CrashTimeZero2_ms, 'CrashCode' => $tcpar_Crashcode2 }, 'Record_2' => { 'CrashTimeZero' => $tcpar_CrashTimeZero1_ms, 'CrashCode' => $tcpar_Crashcode1 } } if ( $storageOrder eq 'MostRecentFirst' );
	}
	else {
		$CrashRecord = { 'Record_1' => { 'CrashTimeZero' => $tcpar_CrashTimeZero1_ms, 'CrashCode' => $tcpar_Crashcode1 } };
	}

	foreach my $recordNbr ( 1 .. 2 ) {
		my $crash = $CrashRecord->{"Record_$recordNbr"}->{'CrashCode'};
		next unless ( defined $crash );

		S_w2rep("#---------------------------------------------");
		S_teststep( "Evaluate EDID $tcpar_EDID for crash $crash, record $recordNbr", 'AUTO_NBR' );
		S_w2log( 1, "Crash code: $crash" );
		S_w2rep("#---------------------------------------------");

		#-----------------------------------------------------------------------
		# Get source data
		#-----------------------------------------------------------------------
		S_w2log( 1, "Get source data (label: $tcpar_SensorLabel)" );

		my $sourceData = $crash_handler->GetSourceDataSamples(
			"SourceLabel"      => $tcpar_SensorLabel,
			"CoordinateSystem" => "NHTSA",
			"CrashLabel"       => $crash
		);    # contains samplerate, time unit, data samples

		unless ( defined $sourceData ) {
			if ( S_get_exec_option_NOERROR('OfflineReportValidation') ) {
				S_w2log( 1, "No Sensor data obtained from crash handler for '$crash' - go to next crash" );
				next;
			}
			else {
				S_set_error( "No Sensor data obtained from crash handler for '$crash' - record can't be evaluated", 110 );
				next;
			}
		}

		my $sourceSampleRateHz = $crash_handler->GetSourceSampleRateHz( "SourceLabel" => $tcpar_SensorLabel, "CrashLabel" => $crash );

		my $sensorDetailsMapping = S_get_contents_of_hash_NOERROR( [ 'Mapping_EDR', 'SensorMapping', "$tcpar_SensorLabel" ] );
		my $sensorRange;
		if ($sensorDetailsMapping) {
			$sensorRange = $sensorDetailsMapping->{'SensorRange'};
		}
	
		#-----------------------------------------------------------------------
		# Get EDID data
		#-----------------------------------------------------------------------
		S_teststep_2nd_level( "Read '$tcpar_EDID' from EDR record $recordNbr", 'AUTO_NBR', "read_edid_data_record_$recordNbr" );    #measurement 1
		my $EDID_data;
		if ($tcpar_Expected_NoClipping =~/0x/ and $recordNbr==$tcpar_ClippingNotExpectedInRecord){
			my $detectedEDIDvalue = $record_handler -> GetRawEDID("EDIDnr" => $tcpar_EDID,
                                                       	 "RecordNumber" => $recordNbr,
														 "CrashLabel" => $CrashLabel,
														 "FormatOption" => "HEX");
			unless(defined $detectedEDIDvalue) {
				S_set_error("No EDID data found for crash $crash, record $recordNbr. EDID cannot not be evaluated. Go to next record",110);
				next;
			}
			if(ref $detectedEDIDvalue eq 'ARRAY') {
				my $detectedEDIDvalueString;
				foreach my $hexElement (@{$detectedEDIDvalue})
				{
					$detectedEDIDvalueString .= $hexElement;
				}
				$detectedClippingTime = $detectedEDIDvalueString;
			}
			else{
				$detectedClippingTime=$detectedEDIDvalue;
			}
			$detectedClippingTime = "0x".$detectedClippingTime;										 
		}
		else {
			
			$EDID_data = $record_handler->GetDecodedEDID( "CrashLabel" => $CrashLabel, "RecordNumber" => $recordNbr, "EDIDnr" => $tcpar_EDID );

			unless ( defined $EDID_data ) {
				S_set_error( "No EDID data obtained from record $recordNbr - record can't be evaluated", 'red' );
				return 1;
			}
			$detectedClippingTime=$EDID_data->{"DataValue"}
		}

		#-----------------------------------------------------------------------
		# Get recording start and end time
		#-----------------------------------------------------------------------
		S_w2log( 1, "Get recording start and end time" );

		# Recording Start Time
		my $recStartTime_ms = $record_handler->GetRecStartTimeMillisecEDID_NOERROR( "CrashLabel" => $CrashLabel, "RecordNumber" => $recordNbr, "EDIDnr" => $tcpar_EDID );
		$recStartTime_ms = 0 if ( $recStartTime_ms eq 'T0' );
		if ( not defined $recStartTime_ms ) {
			S_w2rep("Recording start time set to default value: 0ms");
			$recStartTime_ms = 0;
		}
		else {
			S_w2log( 1, "Recording start time for EDID: $recStartTime_ms ms" );
		}

		# Recording End Time
		my $recEndTime_ms = $record_handler->GetRecEndTimeMillisecEDID_NOERROR( "CrashLabel" => $CrashLabel, "RecordNumber" => $recordNbr, "EDIDnr" => $tcpar_EDID );
		
		if ( ( not defined $recEndTime_ms ) or ( $recEndTime_ms eq 'Tend' ) ) {
			unless ($main::opt_offline){
				my $crashDuration_href = $crash_handler->GetSourceDataValues(
					"SourceLabel" => 'CrashDuration',
					"CrashLabel"  => $crash,
				);
				my $Crash_duration=Dumper($crashDuration_href);
				S_w2rep("Crash_duration=$Crash_duration");
				$recEndTime_ms = $crashDuration_href->{'DataValues'};
			}
			else{
				$recEndTime_ms=300;
			}
			S_w2rep("Recording end time set to crash duration value: $recEndTime_ms ms");
		}
		
		else {
			S_w2log( 1, "Recording end time for EDID: $recEndTime_ms ms" );
		}
		
		# Range_Exceeded_Upper_Boundary  
		my $rangeExceededUpperBoundary = $record_handler -> GetRange_Exceeded_Upper_Boundary("CrashLabel" => $crash, "RecordNumber" => $recordNbr,"EDIDnr" => $tcpar_EDID);
		S_w2rep("Range_Exceeded_Upper_Boundary for EDID: $rangeExceededUpperBoundary");

		my $crash_time_zero = $CrashRecord->{"Record_$recordNbr"}->{'CrashTimeZero'};

		#-----------------------------------------------------------------------
		# Evaluate ClippingTime
		#-----------------------------------------------------------------------
		my ( $verdict, $expectedClippingTime );
		( $verdict, $expectedClippingTime ) = EDR_Eval_ClippingTime(
			"ClippingTime_EDID_value"         => $detectedClippingTime,
			"Sensor_DataSamples"        => $sourceData->{"DataSamples"},
			"EDIDnr"                    =>$tcpar_EDID,
			"Sensor_DataUnit"           => $sourceData->{"DataUnit"},
			"Sensor_Range"              => $sensorRange,
			"Absolute_Tolerance_Time"   => $tcpar_EvalTolerance_abs,
			"Rec_Start_Time_ms"         => $recStartTime_ms,
			"Rec_End_Time_ms"           => $recEndTime_ms,
			"Crash_TimeZero_s"          => ( $CrashRecord->{"Record_$recordNbr"}->{'CrashTimeZero'} ) * MILLISEC_TO_SECOND,
			"ExpectedString_NoClipping" => $tcpar_Expected_NoClipping,
			"Range_Exceeded_Upper_Boundary"=>$rangeExceededUpperBoundary,
		);

		S_teststep_expected( "Clipping time record $recordNbr: $expectedClippingTime ms ", "read_edid_data_record_$recordNbr" );    #evaluation 1
		S_teststep_detected( "Clipping time record $recordNbr: $detectedClippingTime ms (tolerance $tcpar_EvalTolerance_abs) ", "read_edid_data_record_$recordNbr" );

		if ( S_get_exec_option_NOERROR('CreisOfflineEvalReporting') ) {
			my $dataElement = $record_handler->GetDataElementEDID(
				"CrashLabel"   => $crash,
				"RecordNumber" => $recordNbr,
				"EDIDnr"       => $tcpar_EDID
			);

			FLEDR_XML_addStaticEdidNode(
				$recordNbr,                                                                                                         # record number
				'SensorData',
				$tcpar_EDID,
				$dataElement,
				$expectedClippingTime,
				$detectedClippingTime,
				$tcpar_EvalTolerance_abs,
				$EDID_data->{"ValueUnit"},
				$verdict,
			);
		}

		# next record
	}

	return 1;
}

sub TC_finalization {

	if ( $recordIsThere_FirstCrash == 0 ) {
		S_w2rep("Start test case finalization...");

		foreach my $recordNumber ( 1 .. $edrNumberOfEventsToBeStored ) {
			$record_handler->DeleteRecord( "CrashLabel" => $CrashLabel, "RecordNumber" => $recordNumber );
		}

		# Erase EDR
		PD_ClearCrashRecorder_NOERROR();
		S_wait_ms(2000);

		# Erase Fault memory
		PD_ClearFaultMemory();
		S_wait_ms(2000);

		# Read fault memory after clearing and erasing EDR
		PD_ReadFaultMemory();

		LC_ECU_Off();
		S_wait_ms('TIMER_ECU_OFF');
	}
	else {
		S_w2rep("Testcase finalization is done");
	}

	return 1;
}

1;
