#### TEST CASE MODULE
package TC_EDID_IgnitionCycleDownload;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use GENERIC_DCOM;
use LIFT_can_access;
use FuncLib_EDR_Framework;
use FuncLib_TNT_SYC_INTERFACE;
use Data::Dumper;

##################################

our $PURPOSE = "<To validate EDID for Ignition Cycle Download recorded in EDR>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDID_IgnitionCycleDownload

=head1 PURPOSE

<To validate EDID for Ignition Cycle Download recorded in EDR>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Note down the Value of <Variable_IgnitionCycle_LowByte ><Variable_IgnitionCycle_HighByte>

2. Inject <CrashType1>

3. Read <EDID> value 

4. Reset ECU

5. Read <EDID> value in the corresponding EDR 

6 Reset ECU 3 times

7. Inject <CrashType2> 

8. Read <EDID> value in the corresponding EDR 1 and EDR 2


I<B<Evaluation>>

1. -

2. -

3. IgnitionCycleCrash should have value same as current Ignition Cycle.

4. -

5. IgnitonCycleCrash should have value Incremented by 1 value compared to step 3

6.

7.

8. IgnitonCycleCrash should have value same as current Ignition Cycle for both crash recorders(Incremented by 4 value compared to step 3)


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'EDID' => 
	SCALAR 'DiagType' => 
	SCALAR 'ResultDB' => 
	SCALAR 'CrashType1' => 
	SCALAR 'CrashType2' => 
	SCALAR 'Variable_IgnitionCycle_LowByte' => 
	SCALAR 'Variable_IgnitionCycle_HighByte' => 
	HASH 'COMsignalsAfterCrash' => 


=head2 PARAMETER EXAMPLES

	purpose		 = 'To validate Ignition Cycle Crash download recorded in EDR'
	
	EDID = '<Fetch {EDID}>'
	DiagType  = 'ProdDiag' 
	ResultDB = 'EDR'
	CrashType1 = 'Single_EDR_Front_above_8kph_NoDeployment;5'
	CrashType2 = 'Single_EDR_Front_Inflatable;5'
	
	Variable_IgnitionCycle_LowByte = 'rb_tim_EcuOnTimeDataEe_st(0)'
	Variable_IgnitionCycle_HighByte = 'rb_tim_EcuOnTimeDataEe_st(1)'
	COMsignalsAfterCrash = %()

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_EDID;
my $tcpar_DiagType;
my $tcpar_ResultDB;
my $tcpar_CrashType1;
my $tcpar_CrashType2;
my $NumberOfECU_Reset;
my $tcpar_Variable_IgnitionCycle_LowByte;
my $tcpar_Variable_IgnitionCycle_HighByte;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_read_NHTSAEDR;
my $tcpar_read_CHINAEDR;
################ global parameter declaration ###################
#add any global variables here
my ($record_handler, $crash_handler, $crashSettings, $edrNumberOfEventsToBeStored,$ChinaEDR_diagType);
my ($ignitionCycle_BeforeCrash1,$ignitionCycle_AfterCrash1AndReset,$ignitionCycle_BeforeCrash2,$ignitionCycle_crash2);

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_EDID =  S_read_mandatory_testcase_parameter( 'EDID' );
	$tcpar_DiagType =  S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_ResultDB =  S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_CrashType1 =  S_read_mandatory_testcase_parameter( 'CrashType1' );
	$tcpar_CrashType2 =  S_read_mandatory_testcase_parameter( 'CrashType2' );
	$NumberOfECU_Reset=  S_read_mandatory_testcase_parameter( 'NumberOfECU_Reset' );
	$tcpar_Variable_IgnitionCycle_LowByte =  S_read_mandatory_testcase_parameter( 'Variable_IgnitionCycle_LowByte' );
	$tcpar_Variable_IgnitionCycle_HighByte =  S_read_mandatory_testcase_parameter( 'Variable_IgnitionCycle_HighByte' );
	$tcpar_COMsignalsAfterCrash =  S_read_mandatory_testcase_parameter( 'COMsignalsAfterCrash','byref' );
	$tcpar_read_NHTSAEDR=S_read_optional_testcase_parameter('read_NHTSAEDR');
	$tcpar_read_CHINAEDR=S_read_optional_testcase_parameter('read_CHINAEDR');
	
	if(not defined $tcpar_read_CHINAEDR) {
		$tcpar_read_NHTSAEDR = 'yes';
		$tcpar_read_CHINAEDR = 'no';
	}
	else {
		$tcpar_read_NHTSAEDR = 'no';
		my $storageOrder = EDR_getStorageOrder();
		return unless(defined $storageOrder);

		if($storageOrder eq 'PhysicalOrder'){
			$ChinaEDR_diagType= 'ProdDiag';  #In platform NHTSA and China EDR is read via proddiag
		}
		else {
			$ChinaEDR_diagType= 'CHINA_Payload';
		}
	}

	return 1;
}

sub TC_initialization {

	S_teststep("Test setup preparation", 'AUTO_NBR');

	#--------------------------------------------------------------
    # INITIALIZE RECORD AND CRASH HANDLER
    #    
	S_w2rep("Initialize Record Handler");
	$record_handler = EDR_init_RecordHandler() || return;
	

	#--------------------------------------------------------------
    # PREPARE CRASH AND INITIALIZE EQUIPMENT
    #
	S_w2rep("Get crash settings for crash $tcpar_CrashType1");
    my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_CrashType1};
	$crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
	unless(defined $crashSettings) {
		S_set_error("Crash $tcpar_CrashType1 not available in result DB $tcpar_ResultDB. Test case aborted.");
		return;
	}

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log(1, "Crashcode: $tcpar_CrashType1, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");

	S_w2log(1, "Power on ECU");
    LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

    GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start();

	S_w2log(1, "Clear crash recorder");
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(2000);

	S_w2log(1, "Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);
	
	S_w2log(1, "Set environments for crash as per result DB");
    CSI_PrepareEnvironment($crashSettings, 'init_complete');
    S_wait_ms(2000);

	S_w2log(1, "Read and evaluate fault memory before stimulation");
	my $faultsBeforeStimulation = PD_ReadFaultMemory();
    my $faultsVerdict = PD_evaluate_faults_NOVERDICT( $faultsBeforeStimulation, []);
    return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

	return 1;
}

sub TC_stimulation_and_measurement {

    #--------------------------------------------------------------
    # CRASH PREPARATION
    #
    S_teststep("Prepare crash '$tcpar_CrashType1'", 'AUTO_NBR');
    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

    # Prepare crash
    CSI_LoadCrashSensorData2Simulator($crashSettings);

    # Power ON the ECU
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

	CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    S_wait_ms(1000);

    #--------------------------------------------------------------
    # READ IGNITION CYCLE VALUE
    #
    S_teststep("Note down the Value of '$tcpar_Variable_IgnitionCycle_LowByte','$tcpar_Variable_IgnitionCycle_HighByte'", 'AUTO_NBR');
    my  $ignitionCycleBeforeCrash_LowByte = S_aref2hex(PD_ReadMemoryByName_NOERROR($tcpar_Variable_IgnitionCycle_LowByte));
    my  $ignitionCycleBeforeCrash_HighByte = S_aref2hex(PD_ReadMemoryByName_NOERROR($tcpar_Variable_IgnitionCycle_HighByte));
    $ignitionCycle_BeforeCrash1 =$ignitionCycleBeforeCrash_HighByte.$ignitionCycleBeforeCrash_LowByte;
    $ignitionCycle_BeforeCrash1=~ m/0x(.*)0x(.*)/;          #concatenated and removed 0x
    $ignitionCycle_BeforeCrash1 = '0x'.$1.$2;
	
	if ($ignitionCycle_BeforeCrash1 ge '0x65533'){
		$ignitionCycle_BeforeCrash1=0x65533;
	}
    if($ignitionCycle_BeforeCrash1 == 0){
        S_set_warning ( "Variables are not present in .sad file hence variable 'rb_tim_EcuOnTimeDataEe_st.POnCounter_u32' is read \n" );
        $ignitionCycle_BeforeCrash1 = S_aref2hex(PD_ReadMemoryByName('rb_tim_EcuOnTimeDataEe_st.POnCounter_u32'));
    }

    $ignitionCycle_BeforeCrash1 = S_0x2dec ( $ignitionCycle_BeforeCrash1 ); 
    S_w2rep("variable value is $ignitionCycle_BeforeCrash1");
	
	#--------------------------------------------------------------
	# CRASH INJECTION
	#	
    S_teststep("Inject '$tcpar_CrashType1'", 'AUTO_NBR');
	CSI_TriggerCrash();
	S_wait_ms(15000);

	if (defined $tcpar_COMsignalsAfterCrash){
		foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
		{				
			my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
			S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
			COM_setSignalState($signal,$dataOnCOM);	
		}

	}
	my $dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_"."$tcpar_CrashType1._BeforeReset";

	$edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();
	unless(defined $edrNumberOfEventsToBeStored){
		S_set_error("'NumberOfEventsToBeStored' is not available in SYC - add or overwrite 'SYC_EDR_get_NumberOfEventsToBeStored' with Custlibrary Function");
        return;
    }

    #--------------------------------------------------------------
    # READ EDR BEFORE RESET
    #
	S_teststep("Read '$tcpar_EDID' value before ECU reset", 'AUTO_NBR', 'read_edid_value_BeforeReset');			#measurement 1
    PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');

	if ( lc( $tcpar_read_NHTSAEDR) eq 'yes' ) {
		S_w2rep("Nbr of records: $edrNumberOfEventsToBeStored");
		EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
								"CrashLabel" => "$tcpar_CrashType1._BeforeReset",
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								"read_EDRType"=>'NHTSA')
	}
	if (lc($tcpar_read_CHINAEDR) eq 'yes'){
		$edrNumberOfEventsToBeStored=3;
		S_w2rep("Nbr of records: $edrNumberOfEventsToBeStored");
		EDR_ReadAndStoreAllRecords ("DiagType" =>  $ChinaEDR_diagType,
								"CrashLabel" => "$tcpar_CrashType1._BeforeReset",
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								"read_EDRType"=>'CHINA');
	}								
	S_teststep("Reset ECU", 'AUTO_NBR');
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');
	
    #--------------------------------------------------------------
    # READ IGNITION CYCLE VALUE AFTER 1 RESET
    #
	S_teststep("Read the ignition cycle value after reset", 'AUTO_NBR');
    my  $ignitionCycleAfterCrash1AndReset_LowByte = S_aref2hex(PD_ReadMemoryByName_NOERROR($tcpar_Variable_IgnitionCycle_LowByte));
    my  $ignitionCycleAfterCrash1AndReset_HighByte = S_aref2hex(PD_ReadMemoryByName_NOERROR($tcpar_Variable_IgnitionCycle_HighByte));
    $ignitionCycle_AfterCrash1AndReset =$ignitionCycleAfterCrash1AndReset_HighByte.$ignitionCycleAfterCrash1AndReset_LowByte;
    $ignitionCycle_AfterCrash1AndReset=~ m/0x(.*)0x(.*)/;          #concatenated and removed 0x
    $ignitionCycle_AfterCrash1AndReset = '0x'.$1.$2;
	if ($ignitionCycle_AfterCrash1AndReset ge '0x65533'){
		$ignitionCycle_AfterCrash1AndReset=0x65533;
	}
    if($ignitionCycle_AfterCrash1AndReset == 0){
        S_set_warning ( "Variables are not present in .sad file hence variable 'rb_tim_EcuOnTimeDataEe_st.POnCounter_u32' is read \n" );
        $ignitionCycle_AfterCrash1AndReset = S_aref2hex(PD_ReadMemoryByName('rb_tim_EcuOnTimeDataEe_st.POnCounter_u32'));
    }

    $ignitionCycle_AfterCrash1AndReset = S_0x2dec ( $ignitionCycle_AfterCrash1AndReset ); 
    S_w2rep("Ignition cycle value is $ignitionCycle_AfterCrash1AndReset");
	

    #--------------------------------------------------------------
    # READ EDR AFTER RESET
    #
	$dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_"."$tcpar_CrashType1._AfterReset";
	S_teststep("Read '$tcpar_EDID' value after ECU reset", 'AUTO_NBR', 'read_edid_value_AfterReset');			#measurement 2
    PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');
						
	if ( lc( $tcpar_read_NHTSAEDR) eq 'yes' ) {
		S_w2rep("Nbr of records: $edrNumberOfEventsToBeStored");
		EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
								"CrashLabel" => "$tcpar_CrashType1._AfterReset",
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								"read_EDRType"=>'NHTSA')
	}
	if (lc($tcpar_read_CHINAEDR) eq 'yes'){
		$edrNumberOfEventsToBeStored=3;
		S_w2rep("Nbr of records: $edrNumberOfEventsToBeStored");
		EDR_ReadAndStoreAllRecords ("DiagType" =>  $ChinaEDR_diagType,
								"CrashLabel" => "$tcpar_CrashType1._AfterReset",
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								"read_EDRType"=>'CHINA');
	}	
    #--------------------------------------------------------------
    # RESET ECU VARIOUS TIMES
    #
	S_teststep("Reset ECU '$NumberOfECU_Reset' times", 'AUTO_NBR');
	
    foreach my $ecuReset (1..$NumberOfECU_Reset)
    {
        LC_ECU_Off();
        S_wait_ms('TIMER_ECU_OFF');
        LC_ECU_On();
        S_wait_ms('TIMER_ECU_READY');        
    }

	
    #--------------------------------------------------------------
    # PREPARE CRASH INJECTION 2
    #
    S_teststep("Prepare crash '$tcpar_CrashType2'", 'AUTO_NBR');
	S_w2rep("Get crash settings for crash $tcpar_CrashType2");
    my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_CrashType2};
	$crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
	unless(defined $crashSettings) {
		S_set_error("Crash $tcpar_CrashType2 not available in result DB $tcpar_ResultDB. Test case aborted.");
		return;
	}

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log(1, "Crashcode: $tcpar_CrashType2, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");

	S_w2log(1, "Set environments for crash as per result DB");
    CSI_PrepareEnvironment($crashSettings, 'init_complete');
    S_wait_ms(2000);

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');
    CSI_LoadCrashSensorData2Simulator($crashSettings);
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

    #--------------------------------------------------------------
    # READ IGNITION CYCLE VALUE AFTER 1 RESET
    #
    S_teststep("Note down the Value of '$tcpar_Variable_IgnitionCycle_LowByte','$tcpar_Variable_IgnitionCycle_HighByte' before second crash", 'AUTO_NBR');
    my  $ignitionCycle_BeforeCrash2_LowByte = S_aref2hex(PD_ReadMemoryByName_NOERROR($tcpar_Variable_IgnitionCycle_LowByte));
    my  $ignitionCycle_BeforeCrash2_HighByte = S_aref2hex(PD_ReadMemoryByName_NOERROR($tcpar_Variable_IgnitionCycle_HighByte));
    $ignitionCycle_BeforeCrash2 =$ignitionCycle_BeforeCrash2_HighByte.$ignitionCycle_BeforeCrash2_LowByte;
    $ignitionCycle_BeforeCrash2=~ m/0x(.*)0x(.*)/;          #concatenated and removed 0x
    $ignitionCycle_BeforeCrash2 = '0x'.$1.$2;
	if ($ignitionCycle_BeforeCrash2 ge '0x65533'){
		$ignitionCycle_BeforeCrash2=0x65533;
	}

    if($ignitionCycle_BeforeCrash2 == 0){
        S_set_warning ( "Variables are not present in .sad file hence variable 'rb_tim_EcuOnTimeDataEe_st.POnCounter_u32' is read \n" );
        $ignitionCycle_BeforeCrash2 = S_aref2hex(PD_ReadMemoryByName('rb_tim_EcuOnTimeDataEe_st.POnCounter_u32'));
    }

    $ignitionCycle_BeforeCrash2 = S_0x2dec ( $ignitionCycle_BeforeCrash2 ); 
    S_w2rep("Ignition cycle value is $ignitionCycle_BeforeCrash2");	
	
    #--------------------------------------------------------------
    # CRASH INJECTION 2
    #
    S_teststep("Inject '$tcpar_CrashType2' ", 'AUTO_NBR');
	CSI_TriggerCrash();
	S_wait_ms(15000);

	if (defined $tcpar_COMsignalsAfterCrash){
		foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
		{				
			my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
			S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
			COM_setSignalState($signal,$dataOnCOM);	
		}
	}

    #--------------------------------------------------------------
    # READ EDR AFTER CRASH2
    #
    $dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_".$tcpar_CrashType2;	
	S_teststep("Read '$tcpar_EDID' value in the corresponding EDR after injecting another crash ", 'AUTO_NBR', 'read_edid_value');			#measurement 3
    PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');

	if ( lc( $tcpar_read_NHTSAEDR) eq 'yes' ) {
		S_w2rep("Nbr of records: $edrNumberOfEventsToBeStored");
		EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
								"CrashLabel" => $tcpar_CrashType2,
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								"read_EDRType"=>'NHTSA')
	}
	if (lc($tcpar_read_CHINAEDR) eq 'yes'){
		$edrNumberOfEventsToBeStored=3;
		S_w2rep("Nbr of records: $edrNumberOfEventsToBeStored");
		EDR_ReadAndStoreAllRecords ("DiagType" =>  $ChinaEDR_diagType,
								"CrashLabel" => $tcpar_CrashType2,
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								"read_EDRType"=>'CHINA');
	}	
	return 1;
}

sub TC_evaluation {

    # Ignition Cycle Download directly after crash 1, no reset
    my $dataElement = $record_handler -> GetDataElementEDID( "EDIDnr" => $tcpar_EDID,
                                                            "RecordNumber" => 1,
                                                            "CrashLabel" => "$tcpar_CrashType1._BeforeReset");
    S_w2log(1, "EDID $tcpar_EDID ($dataElement) validation in record 1 after crash injection 1, no ECU reset ");
    my $edidData = $record_handler -> GetDecodedEDID("CrashLabel" => "$tcpar_CrashType1._BeforeReset", "RecordNumber" => 1,"EDIDnr" => $tcpar_EDID );
    my $detectedvalue = $edidData -> {"DataValue"};
    my $unit = $edidData -> {"ValueUnit"};    
    unless(defined $detectedvalue) {
        S_set_error("No data could be obtained for EDID $tcpar_EDID in record read after first crash injection");
        return 1;
    }

    S_teststep_expected("$ignitionCycle_BeforeCrash1 cycles", 'read_edid_value_BeforeReset'); #evaluation 1
    S_teststep_detected("$detectedvalue cycles", 'read_edid_value_BeforeReset');
    EVAL_evaluate_value ( "EDID_$tcpar_EDID\_Evaluation_BeforeReset", $detectedvalue,'==', $ignitionCycle_BeforeCrash1 );
    
    # Ignition Cycle Download after crash 1, 1 reset
    S_w2log(1, "EDID $tcpar_EDID ($dataElement) validation in record 1 after crash injection 1 and ECU reset ");
    $edidData = $record_handler -> GetDecodedEDID("CrashLabel" => "$tcpar_CrashType1._AfterReset", "RecordNumber" => 1,"EDIDnr" => $tcpar_EDID );
    $detectedvalue = $edidData -> {"DataValue"};
    $unit = $edidData -> {"ValueUnit"};    
    unless(defined $detectedvalue) {
        S_set_error("No data could be obtained for EDID $tcpar_EDID in record read after first crash injection");
        return 1;
    }

    S_teststep_expected("$ignitionCycle_AfterCrash1AndReset cycles", 'read_edid_value_AfterReset'); #evaluation 2
    S_teststep_detected("$detectedvalue cycles", 'read_edid_value_AfterReset');
    EVAL_evaluate_value ( "EDID_$tcpar_EDID\_Evaluation_AfterReset", $detectedvalue,'==', $ignitionCycle_AfterCrash1AndReset );

    # Ignition Cycle Download after crash 2


    S_teststep_2nd_level("EDID $tcpar_EDID ($dataElement) validation in record 1 after ECU reset and crash injection 2", 'AUTO_NBR', "Crash_2_Record_1");
    $edidData = $record_handler -> GetDecodedEDID("CrashLabel" => $tcpar_CrashType2, "RecordNumber" => 1,"EDIDnr" => $tcpar_EDID );
    $detectedvalue = $edidData -> {"DataValue"};
    $unit = $edidData -> {"ValueUnit"};    
    unless(defined $detectedvalue) {
        S_set_error("No data could be obtained for EDID $tcpar_EDID in record read after first crash injection");
        return 1;
    }

    S_teststep_expected("$ignitionCycle_BeforeCrash2 cycles", 'Crash_2_Record_1'); #evaluation 2
    S_teststep_detected("$detectedvalue cycles", 'Crash_2_Record_1');
    EVAL_evaluate_value ( "EDID_$tcpar_EDID\_Evaluation_Crash2Rec1", $detectedvalue,'==', $ignitionCycle_BeforeCrash2 );

    S_teststep_2nd_level("EDID $tcpar_EDID ($dataElement) validation in record 2 after ECU reset and crash injection 2", 'AUTO_NBR', "Crash_2_Record_2");
    $edidData = $record_handler -> GetDecodedEDID("CrashLabel" => $tcpar_CrashType2, "RecordNumber" => 2,"EDIDnr" => $tcpar_EDID );
    $detectedvalue = $edidData -> {"DataValue"};
    $unit = $edidData -> {"ValueUnit"};    
    unless(defined $detectedvalue) {
        S_set_error("No data could be obtained for EDID $tcpar_EDID in record read after first crash injection");
        return 1;
    }

    S_teststep_expected("$ignitionCycle_BeforeCrash2 cycles", 'Crash_2_Record_2'); #evaluation 2
    S_teststep_detected("$detectedvalue cycles", 'Crash_2_Record_2');
    EVAL_evaluate_value ( "EDID_$tcpar_EDID\_Evaluation_Crash2Rec1", $detectedvalue,'==', $ignitionCycle_BeforeCrash2 );

	return 1;
}

sub TC_finalization {

	S_w2rep("Start test case finalization...");
    #Delete Record Handler
    foreach my $recordNumber (1..$edrNumberOfEventsToBeStored)
    {
        $record_handler -> DeleteRecord("CrashLabel" => "$tcpar_CrashType1._BeforeReset", "RecordNumber" => $recordNumber);
        $record_handler -> DeleteRecord("CrashLabel" => "$tcpar_CrashType1._AfterReset", "RecordNumber" => $recordNumber);
        $record_handler -> DeleteRecord("CrashLabel" => $tcpar_CrashType2, "RecordNumber" => $recordNumber);
    }

	# Erase EDR
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(2000);

	# Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	# Read fault memory after clearing and erasing EDR
    PD_ReadFaultMemory();
	S_wait_ms(2000);	

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

	return 1;
}


1;
