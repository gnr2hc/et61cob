#### TEST CASE MODULE
package TC_SDID_ExternalDeviceConfiguration;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS_EDR_EDIDList_SupplierData>
#TS version in DOORS: <1.4>
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
use LIFT_PD;
use LIFT_can_access;
use GENERIC_DCOM;
use LIFT_labcar;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use LIFT_crash_simulation;
use LIFT_FaultMemory;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;
use Data::Dumper; #necessary
#include further modules here

##################################

our $PURPOSE = "<to validate the data element 'Squib Configuration','switch Configuration','sensor Configuration' and 'Aout Configuration' recorded in EDR>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_SDID_ExternalDeviceConfiguration

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

1.StandardPreparation


I<B<Stimulation and Measurement>>

1. Power on ECU and Create <Condition>  

2.Inject <Crashcode>

3.Wait for <WaitTime_ms> 

4. Read <Data _Element>corresponding to the <SDID>  in the latest entry of EDR


I<B<Evaluation>>

1.

2.

3.

4. <Data _Element> should report all the sampled External Device Configuration data<Val_ExtDeviceConfiguration> as per the <Condition>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	LIST 'Val_ExtDeviceConfiguration' => 
	SCALAR 'purpose' => 
	SCALAR 'Condition' => 
	SCALAR 'SDID' => 
	SCALAR 'Data_Element' => 
	SCALAR 'WaitTime_ms' => 
	SCALAR 'Crashcode' => 


=head2 PARAMETER EXAMPLES

	purpose	 = 'to validate the data element 'Squib Configuration' recorded in EDR'
	
	Condition= '<Test Heading>'
	
	
	SDID= '<Fetch {SDID}>'
	Data_Element= '<Fetch {Object Text}>'
	WaitTime_ms=6000 #ms
	
	
	Crashcode='Single_EDR_Side_above_8kph_NoDeployment;5'
	Val_ExtDeviceConfiguration=@('0x0f','0xfe','0xdb','0xef')

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Condition;
my $tcpar_SDID;
my $tcpar_DiagType;
my $tcpar_ResultDB;
my $tcpar_EDIDNr_Supplier;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_WaitTime_ms;
my $tcpar_Crashcode;
my $tcpar_DeviceConfigVar_aref;
my @configValues;
my @deconfigValues;

################ global parameter declaration ###################
#add any global variables here
my $record_handler;
my $tcpar_EDID;
my $crashSettings;
my $recordNbr;
my $numberOfDetectedRecords = 0;
my $edrNumberOfEventsToBeStored;
my $expected_EDIDvalue;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_Condition =  S_read_mandatory_testcase_parameter( 'Condition' );
	$tcpar_SDID =  S_read_mandatory_testcase_parameter( 'SDID' );
	$tcpar_WaitTime_ms =  S_read_mandatory_testcase_parameter( 'WaitTime_ms' );
	$tcpar_Crashcode =  S_read_mandatory_testcase_parameter( 'Crashcode' );
	$tcpar_EDIDNr_Supplier =  S_read_optional_testcase_parameter( 'EDIDNr_Supplier');
	$tcpar_DiagType =  S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_ResultDB =  S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_COMsignalsAfterCrash =  S_read_optional_testcase_parameter( 'COMsignalsAfterCrash','byref');
	$tcpar_DeviceConfigVar_aref = S_read_mandatory_testcase_parameter('DeviceConfigVar','byref');
	$tcpar_EDID = EDR_Convert_SDID_To_Integer ($tcpar_SDID);
	if(not defined $tcpar_EDID){
		S_w2rep("Converting DOORS SDID to integer was not successful. Test case can't be performed.");
		return;
	}
	if(not defined $tcpar_EDIDNr_Supplier){
		S_w2rep("Setting the Supplier EDID number as 999 by default");
		$tcpar_EDIDNr_Supplier = 999; 
	}
	my @tcpar_Condition_array = split(/_/, $tcpar_Condition);
	$tcpar_Condition = $tcpar_Condition_array[1];
	return 1;
}

sub TC_initialization {
	#--------------------------------------------------------------
    # INITIALIZE RECORD HANDLER
    #--------------------------------------------------------------    
	S_w2log(1,"Initialize Record Handler");
	$record_handler = EDR_init_RecordHandler() || return;


	#--------------------------------------------------------------
    # CRASH PREPARATION
	S_w2log(1, "Prepare crash" );

	# PREPARE CRASH AND INITIALIZE EQUIPMENT
	S_w2rep("Get crash settings for crash $tcpar_Crashcode");
	my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode};
	$crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
	if(not defined $crashSettings) {
		S_set_error("Crash code $tcpar_Crashcode not defined in given result DB. Test case will be aborted.", 110);
		return;
	}
	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log(1, "Crashcode: $tcpar_Crashcode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");
	
	
	S_w2log(1, "Power on ECU");
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

    S_w2log(1, "Initialize CD and start CAN trace");
    GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start();

	
	S_w2log(1, "Set environments for crash as per result DB");
	CSI_PrepareEnvironment($crashSettings,'init_complete');
	S_wait_ms(2000);
	
	S_w2log(1, "Clear crash recorder");
    PD_ClearCrashRecorder();
    S_wait_ms(2000);

	S_w2log(1, "Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	S_w2log(1, "Reset ECU");
    PD_ECUreset();
    S_wait_ms('TIMER_ECU_READY');

	S_w2log(1, "Read and evaluate fault memory before stimulation");
    my $faultsBeforeStimulation_obj = LIFT_FaultMemory -> read_fault_memory('Bosch');
    my $faultsVerdict = $faultsBeforeStimulation_obj -> evaluate_faults({});
    return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

    S_w2log(1, "Download crash sensor data to simulator");
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_READY');

	#Prepare crash
	CSI_LoadCrashSensorData2Simulator( $crashSettings );

	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	return 1;
}

sub TC_stimulation_and_measurement {
	
	# Read the device configuration for squibs/switches/sensors/Aout
	foreach my $config_var (@{$tcpar_DeviceConfigVar_aref}){
		my $val = S_aref2hex(PD_ReadMemoryByName_NOERROR( $config_var ) ,U8 );
		my @val_array = split (/0x/,$val);
		push (@configValues, $val_array[1]);
	}
		
	if ($tcpar_Condition eq 'AllDevices'){
		foreach my $config_var (@{$tcpar_DeviceConfigVar_aref}){
		PD_WriteMemoryByName( $config_var, [0x00] );
		push (@deconfigValues, '00');
		PD_ECUreset();
		S_wait_ms('TIMER_ECU_READY');
		}
	}elsif($tcpar_Condition eq 'none')
	{
		S_w2rep("");#do nothing
	}
	else
	{
		PD_ECUlogin();
		S_wait_ms(2000);
		PD_Device_configuration('clear', [$tcpar_Condition]);
		S_wait_ms(2000);
		PD_ECUreset();
		S_wait_ms('TIMER_ECU_READY');
		foreach my $config_var (@{$tcpar_DeviceConfigVar_aref}){
			my $val = S_aref2hex(PD_ReadMemoryByName_NOERROR( $config_var ) ,U8 );
			my @val_array = split (/0x/,$val);
			push (@deconfigValues, $val_array[1]);
		}
	}
	
	CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    S_wait_ms(1000);
	#--------------------------------------------------------------
	# CRASH INJECTION
	#
	S_teststep("Inject '$tcpar_Crashcode' ", 'AUTO_NBR');
	CSI_TriggerCrash();
    S_teststep("Wait 10 seconds until EDR is stored", 'AUTO_NBR');
	S_wait_ms(10000);

	if (defined $tcpar_COMsignalsAfterCrash){
        S_w2log(1, "Send post crash COM signals");
    	foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash}){
    		my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
    		S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
    		COM_setSignalState($signal,$dataOnCOM);
		}
	}

	S_teststep("Read EDR record for crash combination $tcpar_Crashcode", 'AUTO_NBR');
	S_teststep_2nd_level("Read and print all EDR data", 'AUTO_NBR');
	my $dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_".$tcpar_Crashcode;
	PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');
	$edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();
	
	EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
							 	"CrashLabel" => $tcpar_Crashcode,
							 	"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
							 	"StoragePath" => $dataStoragePath,
							 	);
	# add supplier section
	############################
	S_teststep_2nd_level("Extract and parse supplier data", 'AUTO_NBR');
	my $recordStructureSupplier_href = EDR_ReadEDR_Record_structure_info_from_mapping_NOERROR('Supplier',0,'Mapping_EDR','SUPPLIER_EDIDS');
	if(not defined $recordStructureSupplier_href){
        S_set_warning("Supplier EDID section is not available in EDR mapping.\n".
        "Generate mapping newly with this section if the EDID to be evaluated is part of Supplier section");
        return 1;
    }

	
	foreach my $recordNbr (1..$edrNumberOfEventsToBeStored)
	{
		my $recordAvailable = $record_handler -> IsRecordAvailable("CrashLabel" => $tcpar_Crashcode, "RecordNumber"=> $recordNbr);
		next unless($recordAvailable);

		$numberOfDetectedRecords ++;

		my $recordData_aref = $record_handler -> GetRawEDID( "EDIDnr" => $tcpar_EDIDNr_Supplier,
															"RecordNumber" => $recordNbr,
															"CrashLabel" => $tcpar_Crashcode,);

		$record_handler -> AddCrashRecord(  "RecordNumber" => $recordNbr,
											"CrashLabel"   => $tcpar_Crashcode.'_Supplier',
											"RecordStructureInfo" => $recordStructureSupplier_href,
											"RawDataGeneric" => $recordData_aref,);
		$record_handler -> PrintRawEDIDs( "RecordNumber" => $recordNbr,
											"CrashLabel" => $tcpar_Crashcode.'_Supplier',
											"FormatOption" => 'HEX',);
	}

	return 1;
}

sub TC_evaluation {
	my $expectedEDIDvalueString;
	if ($tcpar_Condition eq 'none'){
		foreach my $hexElement (@configValues)
		{
			$expectedEDIDvalueString .= $hexElement;
		}
		$expected_EDIDvalue = "0x".$expectedEDIDvalueString;

	}else
	{
		foreach my $hexElement (@deconfigValues)
		{
			$expectedEDIDvalueString .= $hexElement;
		}
		$expected_EDIDvalue = "0x".$expectedEDIDvalueString;
	}
	
	
    foreach my $recordNbr (1..$numberOfDetectedRecords)
	{
		my $dataElement = $record_handler -> GetDataElementEDID("EDIDnr" => $tcpar_EDID,
														  "RecordNumber" => $recordNbr,
														  "CrashLabel" => $tcpar_Crashcode.'_Supplier');
		
		
		S_teststep("Validate EDID $tcpar_EDID ($dataElement), record $recordNbr", 'AUTO_NBR', "EDID_$tcpar_EDID\_Record_$recordNbr");
		
		my $detected_EDIDvalue = $record_handler -> GetRawEDID("EDIDnr" => $tcpar_EDID,
													 "RecordNumber" => $recordNbr,
													 "CrashLabel" => $tcpar_Crashcode.'_Supplier',
													 "FormatOption" => "HEX");
		unless(defined $detected_EDIDvalue) {
			S_set_error("No data could be obtained for EDID $tcpar_EDID in record $recordNbr.");
			next;
		}

		if(ref $detected_EDIDvalue eq 'ARRAY') {
			my $detectedEDIDvalueString;
			foreach my $hexElement (@{$detected_EDIDvalue})
			{
				$detectedEDIDvalueString .= $hexElement;
			}
			$detected_EDIDvalue = "0x".$detectedEDIDvalueString;
		}
		else{
			$detected_EDIDvalue = "0x".$detected_EDIDvalue;
		}
	
        $expected_EDIDvalue = '01' if ($main::opt_offline); #PD does not return value in offline mode

		S_teststep_detected ("$detected_EDIDvalue","EDID_$tcpar_EDID\_Record_$recordNbr");
		S_teststep_expected ("$expected_EDIDvalue","EDID_$tcpar_EDID\_Record_$recordNbr");
		EVAL_evaluate_string( "EDID_$tcpar_EDID\_Evaluation", $expected_EDIDvalue,$detected_EDIDvalue );
		
	}

	return 1;
}

sub TC_finalization {
	
    S_w2rep("Start test case finalization...");

	# Erase EDR
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(2000);
    
    if ($tcpar_Condition ne 'none'){
		my @tcpar_DeviceConfigVar_aref_reversed = reverse (@$tcpar_DeviceConfigVar_aref); #inorder to write the correct value to the variable.
		foreach my $config_var (@tcpar_DeviceConfigVar_aref_reversed){
			my $val = pop (@configValues);
			$val = "0x".$val;
			PD_WriteMemoryByName( $config_var, [$val]);
			PD_ECUreset();
			S_wait_ms('TIMER_ECU_READY');
		}
	}
	# Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	# Read fault memory after clearing and erasing EDR
    LIFT_FaultMemory -> read_fault_memory('Bosch');

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

	S_w2rep("Clean up record handler");
    foreach my $recordNumber (1..$edrNumberOfEventsToBeStored)
    {
        $record_handler -> DeleteRecord("CrashLabel" => $tcpar_Crashcode, "RecordNumber" => $recordNumber);
        $record_handler -> DeleteRecord("CrashLabel" => $tcpar_Crashcode."_Supplier", "RecordNumber" => $recordNumber);
    }   

	return 1;
}

1;
