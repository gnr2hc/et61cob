#### TEST CASE MODULE
package TC_EDID_OperatingTimeValidation;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use GENERIC_DCOM;
use LIFT_can_access;
use FuncLib_EDR_Framework;
use FuncLib_TNT_SYC_INTERFACE;
use Data::Dumper;
use constant MILLISEC_TO_SECOND => 0.001;
use constant SECOND_TO_MINUTE => 0.0167;

##################################

our $PURPOSE = "<To validate operating time data recorded in EDR>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDID_OperatingTimeValidation

=head1 PURPOSE

<To validate operating time data recorded in EDR>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Note down the Value of <PD_Variable_Operating_Time>

2. Inject a <Crashcode>

3. Read <EDID> in all EDR records


I<B<Evaluation>>

1. -

2. -

3. EDID should have value equal to<Variable_Operating_Time> with tolerance <EvalTolerance_abs>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Crashcode' => 
	SCALAR 'CrashTimeZero' => 
	SCALAR 'purpose' => 
	SCALAR 'EDID' => 
	SCALAR 'DiagType' => 
	SCALAR 'ResultDB' => 
	SCALAR 'EvalTolerance_abs' => 
	SCALAR 'PD_Variable_Operating_Time' => 
	HASH 'COMsignalsAfterCrash' => 


=head2 PARAMETER EXAMPLES

	purpose		 = 'To validate RGB data recorded in EDR'
	
	EDID = '<Fetch {EDID}>'
	
	DiagType  = 'ProdDiag' 
	ResultDB = 'EDR'
	EvalTolerance_abs = 1 #s
	PD_Variable_Operating_Time = 'rb_tim_EcuOnTimeDataEe_nvmst.PoOnTime_u32'
	COMsignalsAfterCrash = %()
	Crashcode = 'Multi_EDR_Side_before5s_Front'
	CrashTimeZero='11.76_4839.26'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_EDID;
my $tcpar_DiagType;
my $tcpar_ResultDB;
my $tcpar_EvalTolerance_abs;
my $tcpar_PD_Variable_Operating_Time;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_Crashcode;
my $tcpar_CrashTimeZero_ms;
my $tcpar_expected_nr_of_records;
my $tcpar_Wait_Time_Min;

################ global parameter declaration ###################
#add any global variables here
my ($record_handler, $crashSettings, $edrNumberOfEventsToBeStored,$operating_time_min,$operating_time_sec);

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_EDID =  S_read_mandatory_testcase_parameter( 'EDID' );
	$tcpar_DiagType =  S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_ResultDB =  S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_EvalTolerance_abs =  S_read_mandatory_testcase_parameter( 'EvalTolerance_abs' );
	$tcpar_PD_Variable_Operating_Time =  S_read_mandatory_testcase_parameter( 'PD_Variable_Operating_Time' );
	$tcpar_COMsignalsAfterCrash =  S_read_mandatory_testcase_parameter( 'COMsignalsAfterCrash','byref' );
	$tcpar_Crashcode =  S_read_mandatory_testcase_parameter( 'Crashcode' );
	$tcpar_CrashTimeZero_ms =  S_read_mandatory_testcase_parameter( 'CrashTimeZero_ms' );
	$tcpar_Wait_Time_Min = S_read_optional_testcase_parameter( 'Wait_Time_Min' );

	return 1;
}

sub TC_initialization {

	S_teststep("Test setup preparation", 'AUTO_NBR');

	#--------------------------------------------------------------
    # INITIALIZE RECORD AND CRASH HANDLER
    #    
	S_w2rep("Initialize Record Handler");
	$record_handler = EDR_init_RecordHandler() || return;

	#--------------------------------------------------------------
    # PREPARE CRASH AND INITIALIZE EQUIPMENT
    #

	S_w2rep("Get crash settings for crash $tcpar_Crashcode");
	my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode};
	$crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
	unless(defined $crashSettings) {
		S_set_error("Crash $tcpar_Crashcode not available in result DB $tcpar_ResultDB. Test case aborted.");
		return;
	}

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log(1, "Crashcode: $tcpar_Crashcode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");


	S_w2log(1, "Power on ECU");
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');
    GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start();

	S_w2log(1, "Clear crash recorder");
	PD_ClearCrashRecorder_NOERROR();
	S_wait_ms(2000);

	S_w2log(1, "Clear fault memory");
	PD_ClearFaultMemory();
	S_wait_ms(2000);

    S_w2log(1, "Set environments for crash as per result DB");
    CSI_PrepareEnvironment($crashSettings, 'init_complete');
    S_wait_ms(2000);
		
	S_w2log(1, "Read and evaluate fault memory before stimulation");
	my $faultsBeforeStimulation = PD_ReadFaultMemory();
    my $faultsVerdict = PD_evaluate_faults_NOVERDICT( $faultsBeforeStimulation, []);
    return 0 unless ($faultsVerdict eq 'VERDICT_PASS');
	
	return 1;
}

sub TC_stimulation_and_measurement {
    #--------------------------------------------------------------
    # CRASH PREPARATION
    #
    S_teststep("Prepare crash '$tcpar_Crashcode'", 'AUTO_NBR');
    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');
    # Prepare crash
    CSI_LoadCrashSensorData2Simulator($crashSettings);
    # Power ON the ECU
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');
    
    CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    S_wait_ms(1000);
    

    if(defined $tcpar_Wait_Time_Min){
        S_teststep("Wait $tcpar_Wait_Time_Min minutes before crash injection", 'AUTO_NBR');
        my $waitTimeMs = $tcpar_Wait_Time_Min * 60 * 1000;
        S_wait_ms($waitTimeMs);
    }
    #--------------------------------------------------------------
    # READ OPERATING TIME VARIABLE
    #
	S_teststep("Note down the Value of '$tcpar_PD_Variable_Operating_Time'", 'AUTO_NBR');
	my $value_aref = PD_ReadMemoryByName( $tcpar_PD_Variable_Operating_Time );
	unless(@{$value_aref}){
	    S_set_error("No value obtained for PD variable '$tcpar_PD_Variable_Operating_Time'");
	    return;
	}
	$operating_time_sec = S_aref2dec ( $value_aref , U32 );
	
	#--------------------------------------------------------------
	# CRASH INJECTION
	#
	S_teststep("Inject '$tcpar_Crashcode' ", 'AUTO_NBR');
	CSI_TriggerCrash();	
	if (defined $tcpar_COMsignalsAfterCrash){
		foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
		{				
			my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
			S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
			COM_setSignalState($signal,$dataOnCOM);	
		}

	}
		
	S_wait_ms(20000); 

    #--------------------------------------------------------------
    # READ EDR
    #
	S_teststep("Read EDR", 'AUTO_NBR', 'read_edr');			#measurement 1
		
	my $dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_".$tcpar_Crashcode;
	$edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();
	unless(defined $edrNumberOfEventsToBeStored){
		S_set_error("Not available in SYC - add or overwrite with Custlibrary Function");
		return;
	}

	$tcpar_Crashcode .= "_OperatingTime";
    PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');
	EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
								"CrashLabel" => $tcpar_Crashcode,
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								);

	return 1;
}

sub TC_evaluation {

	my $expected_operating_time_min;
	my $expected_operating_time_sec;

	my ($numberOfIncidents, $crashTimeZero_href) = EDR_getCrashTimeZeroPerRecord ($tcpar_CrashTimeZero_ms);
	
	foreach my $recordNumber (1..$numberOfIncidents)
	{
		
		S_teststep("Validate operating time for '$tcpar_EDID' in record $recordNumber", 'AUTO_NBR', "OperatingTime_Record_$recordNumber");			#measurement 1
		my $crashT0_ms = $crashTimeZero_href -> {"Record_$recordNumber"};
		my $crashtime_sec =$crashT0_ms * MILLISEC_TO_SECOND;
		$expected_operating_time_sec = $operating_time_sec +$crashtime_sec;
		$expected_operating_time_min = ($expected_operating_time_sec/60);
		my $dataElement = $record_handler -> GetDataElementEDID( "EDIDnr" => $tcpar_EDID,
																"RecordNumber" => $recordNumber,
																"CrashLabel" => $tcpar_Crashcode);

		S_w2log(1, "--------------------");
		S_w2rep( "\tEDID $tcpar_EDID ($dataElement) validation",'teal');
		S_w2log(1, "--------------------");
						
		my $edidData = $record_handler -> GetDecodedEDID("CrashLabel" => $tcpar_Crashcode, "RecordNumber" => $recordNumber,"EDIDnr" => $tcpar_EDID );
		my $Detected_operating_time = $edidData -> {"DataValue"};
		my $unit = $edidData -> {"ValueUnit"};			
				 
		unless(defined $Detected_operating_time) {
			S_set_error("No data could be obtained for EDID $tcpar_EDID ");
			}
		if($Detected_operating_time eq 'DataNotAvailable'){
			S_set_verdict('VERDICT_FAIL');
			S_w2log(1, "Expected data for $dataElement but $Detected_operating_time is obtained!");
			}
		else{
			if ($unit eq 'sec'){
				EVAL_evaluate_value ( "EDID_$tcpar_EDID\_Evaluation", $Detected_operating_time,'==', $expected_operating_time_sec,$tcpar_EvalTolerance_abs,'absolute');
				S_teststep_expected("'$expected_operating_time_sec' sec (+/- '$tcpar_EvalTolerance_abs' sec)", "OperatingTime_Record_$recordNumber");			#evaluation 1
				S_teststep_detected("$Detected_operating_time sec", "OperatingTime_Record_$recordNumber");
			}
			else{
				EVAL_evaluate_value ( "EDID_$tcpar_EDID\_Evaluation", $Detected_operating_time,'==', $expected_operating_time_min,$tcpar_EvalTolerance_abs,'absolute');
				S_teststep_expected("'$expected_operating_time_min' min (+/- '$tcpar_EvalTolerance_abs' min)", "OperatingTime_Record_$recordNumber");			#evaluation 1
				S_teststep_detected("$Detected_operating_time min", "OperatingTime_Record_$recordNumber");	
			}
			
		}	
					
	}

	return 1;
}

sub TC_finalization {

	S_w2rep("Start test case finalization...");

	foreach my $recordNumber (1..$edrNumberOfEventsToBeStored)
	{
		$record_handler -> DeleteRecord ("CrashLabel" => $tcpar_Crashcode, "RecordNumber" => $recordNumber );
	}

	# Erase EDR
	PD_ClearCrashRecorder_NOERROR();
	S_wait_ms(2000);

	# Erase Fault memory
	PD_ClearFaultMemory();
	S_wait_ms(2000);

	# Read fault memory after clearing and erasing EDR
	PD_ReadFaultMemory();   

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}


1;
