#### TEST CASE MODULE
package TC_EDID_SquibFaulty;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_evaluation;
use LIFT_PD;
use LIFT_crash_simulation;
use LIFT_CANoe;
use LIFT_labcar;
use LIFT_QuaTe;
use LIFT_MDSRESULT;
use LIFT_equipment;
use GENERIC_DCOM;
use LIFT_can_access;
use LIFT_flexray_access;
use LIFT_evaluation;
use LIFT_FaultMemory;
use INCLUDES_Project;
use File::Basename;
use Data::Dumper;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;

##################################

our $PURPOSE = "<Validation of all sensor related data elments in the case of a faulty sensor>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDID_SquibFaulty

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

	(1) Prepare crash <CrashCode>
	(2) Create squib faults on squibs <SquibLabel_Asic1> and <SquibLabel_Asic2>
	(2-1) Create <FaultCondition_Asic1> fault on <SquibLabel_Asic1>
	(2-2) Create <FaultCondition_Asic2> fault on <SquibLabel_Asic2>
	(2-3) Wait for fault qualification
	(2-4) Read fault memory
	(3) Start fire time Measurement
	(4) Inject crash <CrashCode>
	(5) Stop fire time Measurement
	(6) Read EDR after crash (EDID <EDID_SquibLabel_Asic1> and <EDID_SquibLabel_Asic2>). 

I<B<Evaluation>>

(2) Check that faults are qualified and no additional faults are stored
(6)
    a) Number of stored records
    b) Correct values stored for <EDID_SquibLabel_Asic1> and <EDID_SquibLabel_Asic2> in all records


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'CrashCode' => MDB crash code which is to be injected
	SCALAR 'InvalidDataFault' => Fault for invalid squib (Options: Short2Gnd|Short2Bat|Crosscoupling|OpenLine|Short)
	SCALAR 'CrosscouplingSquib' => In case Crosscoupling is the invalid fault, give squib for crosscoupling
	SCALAR 'EDID_SquibLabel_Asic1' => EDID number for Asic 1 squib
	SCALAR 'EDID_SquibLabel_Asic2' => EDID number for Asic 2 squib
	SCALAR 'purpose' => Description of test case purpose
	SCALAR 'ResultDB' => Result DB label which is specified in CREIS mapping
	SCALAR 'DiagType' => Diagnostic readout type (AKLV, ProdDiag, or customer specific)
	SCALAR 'DataNotAvailableFault' => Fault for data not available squib
	SCALAR 'SquibLabel_Asic1' => Squib label for asic 1 squib
	SCALAR 'SquibLabel_Asic2' => Squib label for asic 2 squib
	SCALAR 'NbrOfExpectedRecords' => number of records expected for injected crash
	SCALAR 'FaultCondition_Asic1' => fault condition to be applied for squib asic 1 (Options: InvalidData|DataNotAvailable)
	SCALAR 'FaultCondition_Asic2' => fault condition to be applied for squib asic 2 (Options: InvalidData|DataNotAvailable)
	SCALAR 'ExpectedValue_DataNotAvailable' => expected value for EDID with data not available fault
	SCALAR 'ExpectedValue_InvalidData' => expected value for EDID with invalid data fault

=head2 PARAMETER EXAMPLES

	purpose = 'To Validate EDIDs related to squib deployment time when squib is faulty'
	
	# Stimulation
	ResultDB = 'EDR'
	DiagType = 'ProdDiag'
	
	DataNotAvailableFault = 'NotConfigured'
	
	SquibLabel_Asic1 =  'IC1FP'
	SquibLabel_Asic2 = 'BT2FP'
	
	# Evaluation
	NbrOfExpectedRecords = 2
	
	FaultCondition_Asic1 = 'DataNotAvailable'
	FaultCondition_Asic2 = 'InvalidData'
	
	ExpectedValue_DataNotAvailable = 'Not deployed'
	ExpectedValue_InvalidData = 'ValidFireTime' # The keyword 'ValidFireTime' will evaluate the squib checking that a fire time >= 0 is stored. This is the CA behavior. If there is a different handling in your project, you can give a different value here based on the interpreted value stored, e.g. 'InvalidData' or 'SquibFaulty'
	CrashCode = 'Parallel_EDR_Rollover_Inflate_Front_Inflate;5'
	InvalidDataFault = 'Short'
	CrosscouplingSquib = 'NoCrosscoupling'
	EDID_SquibLabel_Asic1 = '66'
	EDID_SquibLabel_Asic2 = '110'


=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_SquibLabel_Asic1;
my $tcpar_SquibLabel_Asic2;
my $tcpar_EDID_SquibLabel_Asic1;
my $tcpar_EDID_SquibLabel_Asic2;
my $tcpar_FaultCondition_Asic1;
my $tcpar_FaultCondition_Asic2;
my $tcpar_ExpectedValue_DataNotAvailable;
my $tcpar_ExpectedValue_InvalidData;
my $tcpar_InvalidDataFault;
my $tcpar_DataNotAvailableFault;
my $tcpar_CrosscouplingSquib;
my $tcpar_CrashCode;
my $tcpar_DiagType;
my $tcpar_NbrOfExpectedRecords;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_ResultDB;

################ global parameter declaration ###################
#add any global variables here
my ($crashDetails_href,
    $crashSettings,
    $record_handler,
    $faultsAfterStimulation,
    $crashInfo_href,
    @faultsCreated,
    $edrNumberOfEventsToBeStored);

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
    $tcpar_COMsignalsAfterCrash =  S_read_optional_testcase_parameter( 'COMsignalsAfterCrash', 'byref' );

    $tcpar_SquibLabel_Asic1 =  S_read_mandatory_testcase_parameter( 'SquibLabel_Asic1' );
	$tcpar_SquibLabel_Asic2 =  S_read_mandatory_testcase_parameter( 'SquibLabel_Asic2' );
	$tcpar_EDID_SquibLabel_Asic1 =  S_read_mandatory_testcase_parameter( 'EDID_SquibLabel_Asic1' );
	$tcpar_EDID_SquibLabel_Asic2 =  S_read_mandatory_testcase_parameter( 'EDID_SquibLabel_Asic2');
	$tcpar_FaultCondition_Asic1 =  S_read_mandatory_testcase_parameter( 'FaultCondition_Asic1' );
	if($tcpar_FaultCondition_Asic1 !~ m/InvalidData|DataNotAvailable/){
	    S_set_error("Fault condition given for Asic 1 ('$tcpar_FaultCondition_Asic1') not supported!\n".
	               "Supported fault conditions are: InvalidData, DataNotAvailable");
	}
	$tcpar_FaultCondition_Asic2 =  S_read_mandatory_testcase_parameter( 'FaultCondition_Asic2' );
    if($tcpar_FaultCondition_Asic2 !~ m/InvalidData|DataNotAvailable/){
        S_set_error("Fault condition given for Asic 1 ('$tcpar_FaultCondition_Asic2') not supported!\n".
                   "Supported fault conditions are: InvalidData, DataNotAvailable");
    }

    $tcpar_InvalidDataFault =  S_read_mandatory_testcase_parameter( 'InvalidDataFault' );
    if($tcpar_InvalidDataFault !~ m/Short2Gnd|Short2Bat|Crosscoupling|OpenLine|Short/){
        S_set_error("Fault type given for InvalidData ('$tcpar_InvalidDataFault') not supported!\n".
                   "Supported fault types are: Short2Gnd, Short2Bat, Crosscoupling, OpenLine, Short");
    }
    $tcpar_DataNotAvailableFault = S_read_mandatory_testcase_parameter( 'DataNotAvailableFault' );
    if($tcpar_DataNotAvailableFault !~ m/NotConfigured/){
        S_set_error("Fault type given for DataNotAvailable ('$tcpar_DataNotAvailableFault') not supported!\n".
                   "Supported fault types are: NotConfigured");
    }

    $tcpar_CrosscouplingSquib =  S_read_mandatory_testcase_parameter( 'CrosscouplingSquib' )
        if($tcpar_InvalidDataFault eq 'Crosscoupling');

	$tcpar_CrashCode =  S_read_mandatory_testcase_parameter( 'CrashCode' );
	$tcpar_ResultDB = S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_DiagType = S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_NbrOfExpectedRecords = S_read_mandatory_testcase_parameter('NbrOfExpectedRecords');

    $tcpar_ExpectedValue_DataNotAvailable =  S_read_mandatory_testcase_parameter( 'ExpectedValue_DataNotAvailable' );
    $tcpar_ExpectedValue_InvalidData = S_read_mandatory_testcase_parameter( 'ExpectedValue_InvalidData' );

	return 1;
}

sub TC_initialization {

	#--------------------------------------------------------------
    # INITIALIZE RECORD AND CRASH HANDLER
    #    
	S_w2rep("Initialize Record Handler");
	$record_handler = EDR_init_RecordHandler() || return;

	#--------------------------------------------------------------
    # GET CRASH DETAILS
    #    
	# Crash name or index and result DB from EDR mapping
    $crashDetails_href = {'RESULTDB' => $tcpar_ResultDB, 'CRASHNAME' => $tcpar_CrashCode};

	# Crash settings
    $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
    unless(defined $crashSettings) {
        S_set_error("Crash $tcpar_CrashCode not available in result DB $tcpar_ResultDB. Test case aborted.");
        return;
    }

	# Crash code in World DB
	$crashInfo_href -> {"CrashCode_MDS"} = '$tcpar_CrashCode';

	# Name of Result DB
	my $resultDB = $crashDetails_href -> {"RESULTDB"};
	unless(defined $resultDB) {
		$resultDB = "DEFAULT";
	}

	# Result DB path
	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$resultDB" ] );
	$crashInfo_href -> {"MDB_Path"} = $resultDBDetails->{'PATH'};

	#--------------------------------------------------------------
    # Initialize equipment
    #    
	LC_MeasureTraceDigitalConfigureThresholds( ['ALL'], 0.5 );

	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');
    GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start();

	# Set environment settings for crash
    CSI_PrepareEnvironment($crashSettings, 'init_complete');
	S_wait_ms('TIMER_ECU_READY');

    PD_ClearCrashRecorder();
    S_wait_ms(2000);

    # erase FltMem
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	# read fault memory
    my $faultsBeforeStimulation = LIFT_FaultMemory -> read_fault_memory('Bosch');

	#Fault memory must be empty
    my $faultsVerdict = $faultsBeforeStimulation -> evaluate_faults({});
	return 0 if ($faultsVerdict eq 'VERDICT_FAIL');

	return 1;
}

sub TC_stimulation_and_measurement {

	#--------------------------------------------------------------
    # CRASH PREPARATION
    #
	S_teststep("Prepare crash '$tcpar_CrashCode'", 'AUTO_NBR');
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	# Prepare crash
    CSI_LoadCrashSensorData2Simulator($crashSettings);

	# Power ON the ECU
	LC_ECU_On();
 	S_wait_ms('TIMER_ECU_READY');
 	
 	CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    S_wait_ms(1000);

	S_teststep("Create squib faults on squibs '$tcpar_SquibLabel_Asic1' and '$tcpar_SquibLabel_Asic2'",
	           'AUTO_NBR',
	           "Squib_Fault_Creation");
    S_teststep_2nd_level( "Create $tcpar_FaultCondition_Asic1 fault on $tcpar_SquibLabel_Asic1", 'AUTO_NBR');
    _create_squib_fault($tcpar_SquibLabel_Asic1, $tcpar_InvalidDataFault, $tcpar_CrosscouplingSquib)
        if ($tcpar_FaultCondition_Asic1 eq 'InvalidData');
    _create_squib_fault($tcpar_SquibLabel_Asic1, $tcpar_DataNotAvailableFault)
        if ($tcpar_FaultCondition_Asic1 eq 'DataNotAvailable');

    S_teststep_2nd_level( "Create $tcpar_FaultCondition_Asic2 fault on $tcpar_SquibLabel_Asic2", 'AUTO_NBR');
    _create_squib_fault($tcpar_SquibLabel_Asic2, $tcpar_InvalidDataFault, $tcpar_CrosscouplingSquib)
        if ($tcpar_FaultCondition_Asic2 eq 'InvalidData');
    _create_squib_fault($tcpar_SquibLabel_Asic2, $tcpar_DataNotAvailableFault)
        if ($tcpar_FaultCondition_Asic2 eq 'DataNotAvailable');

	S_teststep_2nd_level( "Wait 5 sec for fault qualification", 'AUTO_NBR');
	S_wait_ms(5000);

	S_teststep_2nd_level( "Read fault memory", 'AUTO_NBR');
    $faultsAfterStimulation = LIFT_FaultMemory -> read_fault_memory('Bosch');

	#--------------------------------------------------------------
    # START MEASUREMENTS
    #
	S_teststep("Start LCT Measurement", 'AUTO_NBR');
    LC_MeasureTraceDigitalStart();

	#--------------------------------------------------------------
    # CRASH INJECTION
    #
	S_teststep("Inject crash '$tcpar_CrashCode'", 'AUTO_NBR');
	CSI_TriggerCrash();
    S_wait_ms(10000);

	#--------------------------------------------------------------
    # STOP MEASUREMENTS
    #
	S_teststep("Stop LCT Measurement", 'AUTO_NBR');
    LC_MeasureTraceDigitalStop();
	if (defined $tcpar_COMsignalsAfterCrash){
		foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
		{
			my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
			S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
			COM_setSignalState($signal,$dataOnCOM);
		}
        S_wait_ms(2000);
	}

	#--------------------------------------------------------------
    # READ AND STORE CRASH RECORDS
    #
    my $dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_".$tcpar_CrashCode;

	S_teststep("Read EDR after crash (EDID $tcpar_EDID_SquibLabel_Asic1 and $tcpar_EDID_SquibLabel_Asic2)",
	               'AUTO_NBR', 'read_edr');

	$edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();
	unless(defined $edrNumberOfEventsToBeStored){
        S_set_error("Number of records to be stored not available in SYC - add or overwrite with Custlibrary Function");
        return;
    }

	PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');
	EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
								"CrashLabel" => $tcpar_CrashCode."_$tcpar_SquibLabel_Asic1\_$tcpar_SquibLabel_Asic2\_Faulty",
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								"CrashInfo" => $crashInfo_href,);

	my $lct_Data = LC_MeasureTraceDigitalGetValues();
	my $squibLabels_aref;
	# Get list of all measured squib labels
	foreach my $lctTimeStamp (keys %{$lct_Data})
	{
		foreach my $squib (keys %{$lct_Data -> {$lctTimeStamp}})
		{
			push(@{$squibLabels_aref}, $squib);
		}
		last;
	}
	if(defined $squibLabels_aref) {
		EVAL_dump2UNV( $lct_Data, "$dataStoragePath/LCT_Measurement_$tcpar_CrashCode.txt.unv" );
		EDR_addFireTimesToCrashHandler ("LCT_Measurement" => $lct_Data,
										"SquibLabels" => $squibLabels_aref,
										"CrashLabel"  => $tcpar_CrashCode,
										"StoragePath" => $dataStoragePath);
	}

	return 1;
}

sub TC_evaluation {

    #--------------------------------------------------------------
    # FAULT QUALIFICATION
    #
    my $expectedFaults_href = {};
    my $faultIndex = 1;
    foreach my $fault (@faultsCreated){
        $expectedFaults_href -> {'mandatory'} -> {$fault} = {
            'DecodedStatus' => { 'TestFailed' => 1,}, # fault in qualified state     
        };
    }

	my $faultsVerdict = $faultsAfterStimulation -> evaluate_faults( $expectedFaults_href, 'Squib_Fault_Creation' );

	if($faultsVerdict eq 'VERDICT_FAIL' and not $main::opt_offline){
	    S_w2rep("As intended faults were not stimulated, continuing the test is not useful.\n"
	               ." Check why fault creation failed and repeat test.");
    	S_set_verdict('VERDICT_FAIL') ;
	    return 1;
	}

    my $crashLabel = $tcpar_CrashCode."_$tcpar_SquibLabel_Asic1\_$tcpar_SquibLabel_Asic2\_Faulty";

    #--------------------------------------------------------------
    # NUMBER OF EXPECTED RECORDS
    #
    S_teststep("--------------------------------------------------------", 'NO_AUTO_NBR');
    S_teststep("NUMBER OF EXPECTED RECORDS", 'NO_AUTO_NBR');
    S_teststep_expected_NOHTML("--------------------------------------------------------");
    S_teststep_expected_NOHTML("NUMBER OF EXPECTED RECORDS");
    S_teststep_detected_NOHTML("--------------------------------------------------------");
    S_teststep_detected_NOHTML("NUMBER OF EXPECTED RECORDS");

    my $detectedNbrOfStoredRecords = 0;
    foreach my $recordNumber (1..$edrNumberOfEventsToBeStored)
    {
        my $recordAvailable = $record_handler -> IsRecordAvailable("CrashLabel" => $crashLabel,
                                                                   "RecordNumber"=> $recordNumber);
        $detectedNbrOfStoredRecords++ if ($recordAvailable);
    }
    S_teststep_expected("Expected records: $tcpar_NbrOfExpectedRecords", 'read_edr'); #evaluation 1
    my $verdict= EVAL_evaluate_value("NumberOfRecords", $detectedNbrOfStoredRecords,
                                        '==', $tcpar_NbrOfExpectedRecords);
    S_teststep_detected("Records stored: $detectedNbrOfStoredRecords", 'read_edr');

    if($detectedNbrOfStoredRecords == 0) {
        S_w2rep("No further evaluation done since no record was stored.");
        return 1;
    }

    #--------------------------------------------------------------
    # SQUIB VALUE VALIDATION
    #
    S_teststep("--------------------------------------------------------", 'NO_AUTO_NBR');
    S_teststep("SQUIB VALUE VALIDATION", 'NO_AUTO_NBR');
    S_teststep_expected_NOHTML("--------------------------------------------------------");
    S_teststep_expected_NOHTML("SQUIB VALUE VALIDATION");
    S_teststep_detected_NOHTML("--------------------------------------------------------");
    S_teststep_detected_NOHTML("SQUIB VALUE VALIDATION");

    my $dataElement_Asic1 = $record_handler -> GetDataElementEDID(  "EDIDnr" => $tcpar_EDID_SquibLabel_Asic1,
                                                                     "RecordNumber" => 1,
                                                                     "CrashLabel" => $crashLabel);
    my $dataElement_Asic2 = $record_handler -> GetDataElementEDID(  "EDIDnr" => $tcpar_EDID_SquibLabel_Asic2,
                                                                     "RecordNumber" => 1,
                                                                     "CrashLabel" => $crashLabel);
    S_teststep("Read EDID $tcpar_EDID_SquibLabel_Asic1 ($dataElement_Asic1) and ".
                "EDID $tcpar_EDID_SquibLabel_Asic2 ($dataElement_Asic2) in all records.",
                'AUTO_NBR');

    my $expectedValues_href = {};
    $expectedValues_href -> {$tcpar_EDID_SquibLabel_Asic1} = $tcpar_ExpectedValue_InvalidData
        if($tcpar_FaultCondition_Asic1 eq 'InvalidData');
    $expectedValues_href -> {$tcpar_EDID_SquibLabel_Asic1} = $tcpar_ExpectedValue_DataNotAvailable
        if($tcpar_FaultCondition_Asic1 eq 'DataNotAvailable');
    $expectedValues_href -> {$tcpar_EDID_SquibLabel_Asic2} = $tcpar_ExpectedValue_InvalidData
        if($tcpar_FaultCondition_Asic2 eq 'InvalidData');
    $expectedValues_href -> {$tcpar_EDID_SquibLabel_Asic2} = $tcpar_ExpectedValue_DataNotAvailable
        if($tcpar_FaultCondition_Asic2 eq 'DataNotAvailable');

    foreach my $recordNumber (1..$detectedNbrOfStoredRecords){
        # Squib Asic 1
    	_evaluate_squib_value( $tcpar_SquibLabel_Asic1,
    							$tcpar_EDID_SquibLabel_Asic1,
    							$expectedValues_href -> {$tcpar_EDID_SquibLabel_Asic1},
    							$crashLabel,
    							$recordNumber);

        # Squib Asic 2
    	_evaluate_squib_value(  $tcpar_SquibLabel_Asic2,
    							$tcpar_EDID_SquibLabel_Asic2,
    							$expectedValues_href -> {$tcpar_EDID_SquibLabel_Asic2},
    							$crashLabel,
    							$recordNumber);
        # next record
    }

	return 1;
}

sub TC_finalization {

    S_teststep("Delete crashes from record handler and ECU", 'AUTO_NBR');
    foreach my $recordNbr (1..$tcpar_NbrOfExpectedRecords)
    {
        $record_handler -> DeleteRecord(
                    "RecordNumber" => $recordNbr,
                    "CrashLabel" => $tcpar_CrashCode."_$tcpar_SquibLabel_Asic1\_$tcpar_SquibLabel_Asic2\_Faulty"
        );
    }

    # Erase EDR
    PD_ClearCrashRecorder();

    S_teststep("Reset squib fault manipulation", 'AUTO_NBR');
    _remove_squib_fault($tcpar_SquibLabel_Asic1, $tcpar_InvalidDataFault, $tcpar_CrosscouplingSquib)
        if ($tcpar_FaultCondition_Asic1 =~ m/Invalid|InvalidData/);
    _remove_squib_fault($tcpar_SquibLabel_Asic1, $tcpar_DataNotAvailableFault)
        if ($tcpar_FaultCondition_Asic1 eq 'DataNotAvailable');

    _remove_squib_fault($tcpar_SquibLabel_Asic2, $tcpar_InvalidDataFault, $tcpar_CrosscouplingSquib)
        if ($tcpar_FaultCondition_Asic2 =~ m/Invalid|InvalidData/);
    _remove_squib_fault($tcpar_SquibLabel_Asic2, $tcpar_DataNotAvailableFault)
        if ($tcpar_FaultCondition_Asic2 eq 'DataNotAvailable');

	# Erase Fault memory
    PD_ClearFaultMemory();

	# Reset ECU    
    PD_ECUreset();
    S_wait_ms('TIMER_ECU_READY');

	# Read fault memory after clearing and erasing EDR
    PD_ReadFaultMemory();

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

	return 1;
}

sub _evaluate_squib_value {
	my $squibLabel = shift;
	my $squibEdid = shift;
	my $expectedValue = shift;
	my $crashLabel = shift;
	my $recordNbr = shift;

    S_teststep_2nd_level("Read EDID $squibEdid in record $recordNbr",
                        'AUTO_NBR',
                        "EDID_$squibEdid\_Record_$recordNbr");
    my $detectedSquibState_href = $record_handler -> GetDecodedEDID(
                                                         "EDIDnr" => $squibEdid,
                                                         "RecordNumber" => $recordNbr,
                                                         "CrashLabel" => $crashLabel);
    unless(defined $detectedSquibState_href){
    	S_set_error("No EDID data obtained for EDID $squibEdid in record $recordNbr.\n".
                   	"Check whether EDR is reported or squib $squibLabel is configured or not");
        return 1;
    }

    my $detectedValueSquib = $detectedSquibState_href -> {"DataValue"};

    if($expectedValue eq 'ValidFireTime'){
	    S_teststep_expected($expectedValue." -> greater than 0",
	                            "EDID_$squibEdid\_Record_$recordNbr" );
	    S_teststep_detected($detectedValueSquib,
	                            "EDID_$squibEdid\_Record_$recordNbr" );

		if($detectedValueSquib =~ /^[A-Z]|[a-z]/){
			S_set_verdict('VERDICT_FAIL');
		}
		else{
		    EVAL_evaluate_value ( "EDID_$squibEdid\_Record_$recordNbr" ,
		     						$detectedValueSquib,
		       						'>=',
		                            0);
		}
	}
	else{
	   # COMPARE EXPECTED AND DETECTED SQUIB STATE
        S_teststep_expected($expectedValue,
	                            "EDID_$squibEdid\_Record_$recordNbr" );
	    S_teststep_detected($detectedValueSquib,
	                            "EDID_$squibEdid\_Record_$recordNbr" );

	    EVAL_evaluate_string ( "EDID_$squibEdid\_Record_$recordNbr" ,
	                            $expectedValue ,
	                            $detectedValueSquib  );
	}

	return 1;
}

sub _create_squib_fault{
    my $squibLabel = shift;
    my $faultType = shift;
    my $crosscouplingSquib = shift;

    if($faultType eq 'Short2Bat'){
        LC_ShortLines( [$squibLabel.'+', 'B+'] );
        push(@faultsCreated, 'rb_sqm_TerminalShort2Bat'.$squibLabel.'_flt');
    }
    elsif($faultType eq 'Short2Gnd'){
        LC_ShortLines( [$squibLabel.'+', 'B-'] );
        push(@faultsCreated, 'rb_sqm_TerminalShort2Gnd'.$squibLabel.'_flt');
    }
    elsif($faultType eq 'Crosscoupling'){
        LC_ShortLines([$squibLabel.'+', $crosscouplingSquib.'+'] );
        push(@faultsCreated, 'rb_sqm_Crosscoupling'.$squibLabel.'_flt');
        push(@faultsCreated, 'rb_sqm_Crosscoupling'.$crosscouplingSquib.'_flt');
    }
    elsif($faultType eq 'Short'){
        LC_ShortLines( [$squibLabel.'+', $squibLabel.'-'] );
        push(@faultsCreated, 'rb_sqm_SquibResistanceShort'.$squibLabel.'_flt');
    }
    elsif($faultType eq 'OpenLine'){
        LC_DisconnectLine( $squibLabel );
        push(@faultsCreated, 'rb_sqm_SquibResistanceOpen'.$squibLabel.'_flt');
    }
    elsif($faultType eq 'NotConfigured'){
        PD_Device_configuration( 'clear', [$squibLabel] );
        LC_DisconnectLine( $squibLabel );
    }
    else{
        S_set_error("Given fault type '$faultType' not known!");
    }

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

    return 1;
}

sub _remove_squib_fault{
    my $squibLabel = shift;
    my $faultType = shift;
    my $crosscouplingSquib = shift;

	S_w2log(4, "_remove_squib_fault -> Fault type: $faultType");
    if($faultType =~ m/Short2Bat|Short2Gnd|Crosscoupling|Short/){
        LC_UndoShortLines();
    }
    elsif($faultType eq 'OpenLine'){
        LC_ConnectLine( $squibLabel );
    }
    elsif($faultType eq 'NotConfigured'){
        PD_Device_configuration( 'set', [$squibLabel] );
        LC_ConnectLine( $squibLabel );
    }

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');


    return 1;
}

1;
