#### TEST CASE MODULE
package TC_EDR_SDID_RecordCompleteAndMandatoryDataCompleteStatus;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_PD;
use LIFT_can_access;
use GENERIC_DCOM;
use LIFT_labcar;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;
use LIFT_FaultMemory;
use Data::Dumper;

##################################

our $PURPOSE = "To validate the data element Record complete status and mandatory data record recorded in EDR through CD";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_SDID_RecordCompleteAndMandatoryDataCompleteStatus

=head1 PURPOSE

To validate the data element Record complete status and mandatory data record recorded in EDR through CD

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Power on ECU 

2.Inject <Crashcode> ,wait for T0 and cut power if <CrashCondition> is Autarky.

3.Wait for <WaitTime_ms> 

4. Read <Data _Element>corresponding to the <SDID>  in the latest entry of EDR through CD


I<B<Evaluation>>

1.

2. 

3. <Data _Element> should report the value equal to the value <Val_RecordCompleteStatus> 


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Val_RecordCompleteStatus' => 
	SCALAR 'purpose' => 
	SCALAR 'SDID' => 
	SCALAR 'WaitTime_ms' => 
	SCALAR 'Crashcode' => 
	SCALAR 'CrashTimeZero_ms' => 
	SCALAR 'CrashCondition' => 
	SCALAR 'DiagType' => 
	SCALAR 'ResultDB' => 
	HASH 'COMsignalsAfterCrash' => 


=head2 PARAMETER EXAMPLES

	purpose	 = 'to validate the data element "Record complete status and mandatory data record " recorded in EDR through CD'
	
	SDID= '5000_5501'
	WaitTime_ms=10000 #ms
	Crashcode='Single_EDR_Front_AD_longer300ms;5'
	CrashTimeZero_ms = '5.76'#ms(T0 of the first event)given in crash list.
	CrashCondition= '<Test Heading 2>'
	DiagType  = 'ProdDiag'
	ResultDB = 'EDR'
	COMsignalsAfterCrash = %()
	Val_RecordCompleteStatus= '0x5A'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_SDID;
my $tcpar_WaitTime_ms;
my $tcpar_Crashcode;
my $tcpar_CrashTimeZero_ms;
my $tcpar_CrashCondition;
my $tcpar_DiagType;
my $tcpar_ResultDB;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_Val_RecordCompleteStatus;
my $tcpar_Val_RecordCompleteStatus_Optional;
my $tcpar_Val_RecordCompleteStatus_Alternative_Incident1;
my $tcpar_Val_RecordCompleteStatus_Alternative_Incident2;
my $tcpar_EDID;
my $tcpar_EDIDNr_Supplier;

################ global parameter declaration ###################
#add any global variables here
my ($record_handler, $crashSettings, $edrNumberOfEventsToBeStored);
my $numberOfDetectedRecords = 0;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_SDID =  S_read_mandatory_testcase_parameter( 'SDID' );
	$tcpar_WaitTime_ms =  S_read_mandatory_testcase_parameter( 'WaitTime_ms' );
	$tcpar_EDIDNr_Supplier=  S_read_optional_testcase_parameter( 'EDIDNr_Supplier' );
	$tcpar_Crashcode =  S_read_mandatory_testcase_parameter( 'Crashcode' );
	$tcpar_CrashTimeZero_ms =  S_read_mandatory_testcase_parameter( 'CrashTimeZero_ms' );
	$tcpar_CrashCondition =  S_read_mandatory_testcase_parameter( 'CrashCondition' );
	$tcpar_DiagType =  S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_ResultDB =  S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_COMsignalsAfterCrash =  S_read_optional_testcase_parameter( 'COMsignalsAfterCrash','byref' );
	$tcpar_Val_RecordCompleteStatus =  S_read_mandatory_testcase_parameter( 'Val_RecordCompleteStatus' );
	$tcpar_Val_RecordCompleteStatus_Optional =  S_read_optional_testcase_parameter('Val_RecordCompleteStatus_Optional');
    $tcpar_Val_RecordCompleteStatus_Alternative_Incident1 =  S_read_optional_testcase_parameter('Val_RecordCompleteStatus_Alternative_Incident1');
    $tcpar_Val_RecordCompleteStatus_Alternative_Incident2 =  S_read_optional_testcase_parameter('Val_RecordCompleteStatus_Alternative_Incident2');
	
	
	if( defined $tcpar_EDIDNr_Supplier){
		$tcpar_EDID = EDR_Convert_SDID_To_Integer ($tcpar_SDID);
	}
	else{
		$tcpar_EDID = $tcpar_SDID;
	}


	return 1;
}

sub TC_initialization {

#--------------------------------------------------------------
    # INITIALIZE RECORD HANDLER
    #    
	S_w2rep("Initialize Record Handler");
	$record_handler = EDR_init_RecordHandler() || return;

	S_w2log(1, "Power on ECU");
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

	S_w2log(1, "Clear crash recorder");
    PD_ClearCrashRecorder();
    S_wait_ms(2000);

	S_w2log(1, "Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);
	
    S_w2log(1, "Init CD and start CAN trace");
	GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start();

	S_w2log(1, "Read and evaluate fault memory before stimulation");
    my $faultsBeforeStimulation_obj = LIFT_FaultMemory -> read_fault_memory('Bosch');
    my $faultsVerdict = $faultsBeforeStimulation_obj -> evaluate_faults({});
    return 0 unless ($faultsVerdict eq 'VERDICT_PASS');;

	#--------------------------------------------------------------
    # CRASH PREPARATION
	S_teststep("Prepare crash", 'AUTO_NBR');

	# PREPARE CRASH AND INITIALIZE EQUIPMENT
	S_w2log(1, "Get crash settings for crash $tcpar_Crashcode");
	my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode};
	$crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
	if(not defined $crashSettings and not $main::opt_offline) {
		S_set_error("Crash code $tcpar_Crashcode not defined in given result DB. Test case will be aborted.", 110);
		return;
	}
	if( $main::opt_offline) {
		$crashSettings -> { 'CRASHNAME' } = $tcpar_Crashcode;
	}

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log(1, "Crashcode: $tcpar_Crashcode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");
	
	
	S_w2log(1, "Set environments for crash as per result DB");
	CSI_PrepareEnvironment($crashSettings,'init_complete');
	S_wait_ms('TIMER_ECU_READY');

    S_w2log(1, "Download crash sensor data to simulator");
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_READY');

	#Prepare crash
	CSI_LoadCrashSensorData2Simulator( $crashSettings );

	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');


	return 1;
}

sub TC_stimulation_and_measurement {

	CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    S_wait_ms(1000);
    
	S_teststep("Inject '$tcpar_Crashcode'", 'AUTO_NBR');
	
	CSI_TriggerCrash();
	
	if ($tcpar_CrashCondition eq 'Autarky') {
		S_teststep("Wait for $tcpar_CrashTimeZero_ms ms (T0) and cut power ", 'AUTO_NBR');			
		S_wait_ms($tcpar_CrashTimeZero_ms);
		LC_ECU_Off();
	}

	S_teststep("Wait for '$tcpar_WaitTime_ms' ms", 'AUTO_NBR');			
	S_wait_ms($tcpar_WaitTime_ms);

    if ($tcpar_CrashCondition eq 'Autarky') {
        S_teststep("Turn ECU back on", 'AUTO_NBR');          
    	LC_ECU_On();
    	S_wait_ms('TIMER_ECU_READY');
    }

	if (defined $tcpar_COMsignalsAfterCrash){
	    S_w2log(1, "Send post crash COM signals");
		foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
		{				
			my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
			S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
			COM_setSignalState($signal,$dataOnCOM);	
		}
        S_wait_ms(2000);
	}
	
	S_teststep("Read EDID $tcpar_SDID in the latest entry of EDR", 'AUTO_NBR');			#measurement 1
	
	$edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();
	unless(defined $edrNumberOfEventsToBeStored){
		S_set_error("Number of records to be stored in EDR not available in SYC - add or overwrite with Custlibrary Function");
		return;
	}
		
	my $dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_".$tcpar_Crashcode."_$tcpar_SDID";
		
		
	S_teststep_2nd_level("Read and print all EDR data", 'AUTO_NBR', 'Read_EDR');
		
    PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');
	EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
								"CrashLabel" => $tcpar_Crashcode."_$tcpar_SDID",
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								);	

								
	# add supplier section
	############################
	
	S_teststep_2nd_level("Extract and parse supplier data", 'AUTO_NBR');
	my $recordStructureSupplier_href = EDR_ReadEDR_Record_structure_info_from_mapping_NOERROR('Supplier',0,'Mapping_EDR','SUPPLIER_EDIDS');
	if(not defined $recordStructureSupplier_href){
        S_set_warning("Supplier EDID section is not available in EDR mapping.\n".
        "Generate mapping newly with this section if the EDID to be evaluated is part of Supplier section");
        return 1;
	}

	my @detectedRecordNbrs;
	
	foreach my $recordNbr (1..$edrNumberOfEventsToBeStored)
	{
		my $recordAvailable = $record_handler -> IsRecordAvailable("CrashLabel" => $tcpar_Crashcode."_$tcpar_SDID", "RecordNumber"=> $recordNbr);
		next unless($recordAvailable);
		
		if ($recordAvailable){
            $numberOfDetectedRecords++;
		    push(@detectedRecordNbrs, $recordNbr);
		}
		if ($recordAvailable and defined $tcpar_EDIDNr_Supplier)
		{
			my $recordData_aref = $record_handler -> GetRawEDID( "EDIDnr" => $tcpar_EDIDNr_Supplier,
																"RecordNumber" => $recordNbr,
																"CrashLabel" => $tcpar_Crashcode."_$tcpar_SDID",);

			$record_handler -> AddCrashRecord(  "RecordNumber" => $recordNbr,
												"CrashLabel"   => $tcpar_Crashcode."_$tcpar_SDID".'_Supplier',
												"RecordStructureInfo" => $recordStructureSupplier_href,
												"RawDataGeneric" => $recordData_aref,);
												
			$record_handler -> PrintRawEDIDs( "RecordNumber" => $recordNbr,
											  "CrashLabel" => $tcpar_Crashcode."_$tcpar_SDID".'_Supplier',);
		}
		else
		{
			S_w2rep("Requested EDR record is empty.NO supplier edids will be printed.");
			next;
		}
		
	}							
								
	return 1;
}

sub TC_evaluation {

	if ($numberOfDetectedRecords == 0){
		S_teststep_expected("1 or more records stored", 'Read_EDR');
        S_teststep_detected("EDR empty", 'Read_EDR');
		S_set_verdict ( 'VERDICT_FAIL' );
		return 1;	
	}

    my $storageOrder = EDR_getStorageOrder();
    return unless(defined $storageOrder);

    if($storageOrder eq 'PhysicalOrder'){
       $storageOrder =  'MostRecentLast'; #same behavior as there is no overwriting
    }

	$numberOfDetectedRecords = 1 if($main::opt_offline and not defined $tcpar_Val_RecordCompleteStatus_Optional);
	$numberOfDetectedRecords = 2 if($main::opt_offline and defined $tcpar_Val_RecordCompleteStatus_Optional);
	
    my ($expected_Value_RawHex, $expected_Value_Alternative_RawHex);
	if($numberOfDetectedRecords == 1){
		$expected_Value_RawHex = {"Record_1" => $tcpar_Val_RecordCompleteStatus};
        $expected_Value_Alternative_RawHex = {"Record_1" => $tcpar_Val_RecordCompleteStatus_Alternative_Incident1};
	}
    elsif($numberOfDetectedRecords == 2) {
        if($storageOrder eq 'MostRecentFirst'){
            $expected_Value_RawHex  = {"Record_1" => $tcpar_Val_RecordCompleteStatus_Optional,
                                       "Record_2" => $tcpar_Val_RecordCompleteStatus};
            $expected_Value_Alternative_RawHex -> {"Record_1"} = $tcpar_Val_RecordCompleteStatus_Alternative_Incident2
                if(defined $tcpar_Val_RecordCompleteStatus_Alternative_Incident2);
            $expected_Value_Alternative_RawHex -> {"Record_2"} = $tcpar_Val_RecordCompleteStatus_Alternative_Incident1
                if(defined $tcpar_Val_RecordCompleteStatus_Alternative_Incident1);
            
        }
        elsif($storageOrder eq 'MostRecentLast'){
            $expected_Value_RawHex  = {"Record_1" => $tcpar_Val_RecordCompleteStatus,
                                       "Record_2" => $tcpar_Val_RecordCompleteStatus_Optional};       
            $expected_Value_Alternative_RawHex -> {"Record_1"} = $tcpar_Val_RecordCompleteStatus_Alternative_Incident1
                if(defined $tcpar_Val_RecordCompleteStatus_Alternative_Incident1);
            $expected_Value_Alternative_RawHex -> {"Record_2"} = $tcpar_Val_RecordCompleteStatus_Alternative_Incident2
                if(defined $tcpar_Val_RecordCompleteStatus_Alternative_Incident2);
        }
    }
    else {
    	S_set_error("Number of detected records is greater than 2 - this is not supported by the test case.");
    	return;
    }
	
	if(defined $tcpar_EDIDNr_Supplier){
		$tcpar_Crashcode = $tcpar_Crashcode."_$tcpar_SDID".'_Supplier';
	}
	else {
		$tcpar_Crashcode =$tcpar_Crashcode."_$tcpar_SDID";
	}

    foreach my $recordNbr(1..$numberOfDetectedRecords)
	{
	    my $compareOperator;
	    if(defined $expected_Value_Alternative_RawHex -> {"Record_$recordNbr"}){
	        $compareOperator = 'or';
	    }
	    else{
	        $compareOperator = '==';
	    }

	    my $edidExists = $record_handler -> CheckEdidExistence("EDIDnr" => $tcpar_EDID."_".$recordNbr,
	                                                              "RecordNumber" => $recordNbr,
	                                                              "CrashLabel" => $tcpar_Crashcode);
	
	    my $individualRecord = $tcpar_EDID."_".$recordNbr;
	    if($edidExists == 0){
	        $individualRecord = $tcpar_EDID;
	    }

		my $verdict_final = EDR_Eval_evaluate_EDID_Raw_Hex ("EDIDnr" => $individualRecord,
															"RecordNumber" => $recordNbr,
															"CrashLabel" => $tcpar_Crashcode,
															"EvalOperator" => $compareOperator,
															"Expected_Raw_Hex" => $expected_Value_RawHex -> {"Record_$recordNbr"},
															"Expected_Raw_Hex_Alternative" => $expected_Value_Alternative_RawHex -> {"Record_$recordNbr"});
	}

	return 1;
}

sub TC_finalization {

	S_w2rep("Start test case finalization...");

	foreach my $recordNumber (1..$edrNumberOfEventsToBeStored)
	{
		$record_handler -> DeleteRecord("CrashLabel" => $tcpar_Crashcode."_$tcpar_SDID", "RecordNumber" => $recordNumber);
		$record_handler -> DeleteRecord("CrashLabel" => $tcpar_Crashcode."_$tcpar_SDID"."_Supplier", "RecordNumber" => $recordNumber);
	}

	# Erase EDR
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(2000);

	# Erase Fault memory
    LIFT_FaultMemory -> read_fault_memory('Bosch');
    S_wait_ms(2000);

	# Read fault memory after clearing and erasing EDR
    PD_ReadFaultMemory();   

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

	return 1;
}


1;
