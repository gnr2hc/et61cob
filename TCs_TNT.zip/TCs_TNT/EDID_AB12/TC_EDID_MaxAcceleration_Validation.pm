#### TEST CASE MODULE
package TC_EDID_MaxAcceleration_Validation;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general;
use LIFT_evaluation;
use INCLUDES_Project;
use File::Basename;
use Data::Dumper;
use FuncLib_Project_EDR;
use FuncLib_EDR_Framework;

use constant MILLISEC_TO_SECOND => 0.001;
use constant SENSOR_RESAMPLING_RATE_HZ => 2000;
##################################
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDID_MaxDeltaV_Validation  $Revision: 1.3 $

requires raw EDR data (setup already done in IC)

default state is faultfree ECU powered ON

=head1 PURPOSE

to test max acceleration and time at max acceleration


=head1 TESTCASE DESCRIPTION 

    [initialisation]
    initialize record handler
    initialize crash handler

    [stimulation & measurement]
	1. Inject Crash (No actual crash injection, crash data in crash handler is used)
	2. Read EDR for crash (stored data in record handler is used)

    [evaluation]
    1. Max Acceration Value evaluation
	2. Max Acceration Value time evaluation

    [finalisation]
    destroy record handler

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

    purpose                  --> Purpose of the test case
	EvalType 				 --> Choose between 'MaxAcceleration_Value' and 'MaxAcceleration_Time'
	EvalUnit 				 --> Will be 'kmph' (max delta v value) or 'msec' (max delta v time)
	SensorLabel				 --> Give sensor name according to project
	EvalTolerance_abs 		--> absolute tolerance
	EDID 					--> data element ID
  	

=head2 PARAMETER EXAMPLES

	[TC_EDID_MaxAcceleration_Validation.MaxAcceleration_Longitudinal]
	purpose = 'To validate RGB data recorded in EDR'
	EDID = '2'
	EvalType = 'MaxAcceleration_Value'
	EvalUnit = 'g'
	SensorLabel ='ECU: Acc_HG: -M45: SMA660_sync_axay_96g_426Hz'
	EvalTolerance_abs = '1'

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_EDIDNbr;
my $tcpar_SourceLabel;
my $tcpar_EvalType;
my $tcpar_EvalToleranceTime_abs;
my $tcpar_EvalToleranceValue_abs;
my $tcpar_CrashScenarioList;


################ global parameter declaration ###################
#add any global variables here
my (
		$record_handler,
		$crash_handler,
	);

our $PURPOSE;
our $TC_name = "TC_EDID_MaxDeltaV_Validation";

#-------------------------------------------------------------------------------
sub TC_set_parameters {
#-------------------------------------------------------------------------------
    $tcpar_EDIDNbr = GEN_Read_mandatory_testcase_parameter('EDID');
    $tcpar_SourceLabel = GEN_Read_mandatory_testcase_parameter('SensorLabel');

    $tcpar_EvalType = GEN_Read_mandatory_testcase_parameter('EvalType');
    $tcpar_EvalToleranceValue_abs = GEN_Read_optional_testcase_parameter('EvalToleranceValue_abs');
	$tcpar_EvalToleranceTime_abs = GEN_Read_optional_testcase_parameter('EvalToleranceTime_abs');
	
	$tcpar_CrashScenarioList = GEN_Read_optional_testcase_parameter('CrashScenarioList', 'byref');


	S_w2rep("My eval type: $tcpar_EvalType", 'DodgerBlue');

	return 1;
}

#-------------------------------------------------------------------------------
sub TC_initialization {
#-------------------------------------------------------------------------------
	#--------------------------------------------------------------
    # INITIALIZE RECORD AND CRASH HANDLER
    #    
	S_w2rep("Initialize Record and Crash Handler", 'DodgerBlue');
	$record_handler = EDR_init_RecordHandler() || return;
	$crash_handler  = EDR_init_CrashHandler() || return;

    return 1;
}

#-------------------------------------------------------------------------------
sub TC_stimulation_and_measurement {
#-------------------------------------------------------------------------------
	S_w2rep("No stimulation needed");
    return 1;
}

#-------------------------------------------------------------------------------
sub TC_evaluation {
#-------------------------------------------------------------------------------
	
	my $storedCrashLabels_aref;
	
    if(defined $tcpar_CrashScenarioList) {
        $storedCrashLabels_aref = $tcpar_CrashScenarioList;
    }
    else {
        $storedCrashLabels_aref = $record_handler -> GetListOfStoredRecords();    
    }
	
    my $storageOrder = EDR_getStorageOrder();
    return unless(defined $storageOrder);

    if($storageOrder eq 'PhysicalOrder'){
       $storageOrder =  'MostRecentLast'; #same behavior as there is no overwriting
    }
	

	foreach my $crash (@{$storedCrashLabels_aref})
	{  
		S_w2rep("~~~~~~~~~~~~~~~~~$crash~~~~~~~~~~~~~~~~~~");
	
		S_wait_ms (1000); #Delay to avoid wrong graph creation
		
		my $crashCode_MDS = $crash_handler -> GetSourceDataValues ( "SourceLabel" => "CrashCode_MDS", "CrashLabel"  => $crash );
		$crashCode_MDS = $crashCode_MDS -> {"DataValues"};

		my $path_MDB = $crash_handler -> GetSourceDataValues ("SourceLabel" => "MDB_Path", "CrashLabel"  => $crash );
		$path_MDB = $path_MDB -> {"DataValues"};

		S_w2rep("#---------------------------------------------");
		S_teststep("Evaluate EDID $tcpar_EDIDNbr for crash $crash", 'AUTO_NBR', "Evaluation EDID $tcpar_EDIDNbr crash $crash");
		S_w2log(1, "Crash code: $crashCode_MDS");
		S_w2log(1, "Result DB path: $path_MDB");
        S_w2rep("#---------------------------------------------");

        #-----------------------------------------------------------------------
        # Get source data
        #-----------------------------------------------------------------------
        S_w2log(1, "Get source data (label: $tcpar_SourceLabel)");

        my $sourceData = $crash_handler -> GetSourceDataSamples( "SourceLabel" => $tcpar_SourceLabel,
        														 "CoordinateSystem" => "NHTSA",
        														 "CrashLabel" => $crash); # contains samplerate, time unit, data samples

        unless(defined $sourceData){
            S_w2rep("No Sensor data obtained from crash handler. Try next crash.", 'red');
            S_set_verdict('VERDICT_NONE');
            next unless($main::opt_offline);
            return 1;
        }

        my $sourceSampleRateHz = $crash_handler -> GetSourceSampleRateHz("SourceLabel" => $tcpar_SourceLabel, "CrashLabel"=>$crash );

        #-----------------------------------------------------------------------
        # Get crash time zero
        #-----------------------------------------------------------------------
		my $crashTimeZero = $crash_handler -> GetSourceDataValues ( "SourceLabel" => "CrashTimeZero",
															        "CrashLabel"  => $crash );
		unless(defined $crashTimeZero) {
			S_set_error("No crash time zero stored for crash $crash. No evaluation of fire times possible. Try next crash.", 110);
			next;
		}

		my $crashTimeZero_ms = $crashTimeZero -> {"DataValues"};
		my $crashTimeZeroUnit = $crashTimeZero -> {"DataUnit"};
		if($crashTimeZeroUnit ne "ms") {
			S_set_error("Crash Time zero must be stored in ms!! Go to next crash.", 110);
			next;
		}

		#-----------------------------------------------------------------------
		# Get number of expected records
		#-----------------------------------------------------------------------
		my ($numberOfRecords, $crashTimeZero_href);
		
		if($crash =~ /Multi/) { # multi event
			$numberOfRecords = 2;
			($crashTimeZero_href -> {'Record_2'}, $crashTimeZero_href -> {'Record_1'}) = split(/_/, $crashTimeZero_ms) if($storageOrder eq 'MostRecentFirst');
			($crashTimeZero_href -> {'Record_1'}, $crashTimeZero_href -> {'Record_2'}) = split(/_/, $crashTimeZero_ms) if($storageOrder eq 'MostRecentLast');
			my $crashTimeZero_Rec1 = $crashTimeZero_href -> {'Record_1'};
			my $crashTimeZero_Rec2 = $crashTimeZero_href -> {'Record_2'};

			S_w2rep("Record 1 T0: $crashTimeZero_Rec1 ms; Record 2 T0: $crashTimeZero_Rec2");
		}
		else{ # single or parallel event
			$numberOfRecords = 1;
			$crashTimeZero_href -> {'Record_1'} = $crashTimeZero_ms;
		}

		for (my $recordNbr = 1; $recordNbr <= $numberOfRecords; $recordNbr++)
		{
			S_w2rep("---- Record $recordNbr ----");

	        #-----------------------------------------------------------------------
	        # Get EDID data
	        #-----------------------------------------------------------------------
			S_w2log(1, "Get EDID data (EDID $tcpar_EDIDNbr)");
	        my $EDID_data = $record_handler -> GetDecodedEDID("CrashLabel" => $crash, "RecordNumber" =>  $recordNbr,"EDIDnr" => $tcpar_EDIDNbr);
	
	        unless(defined $EDID_data){
	            S_w2rep("No EDID data obtained from record. Try next crash.", 'red');
	            S_set_verdict('VERDICT_NONE');
	            next unless($main::opt_offline);
	            return 1;
	        }
	
	        #-----------------------------------------------------------------------
	        # Get recording start and end time
	        #-----------------------------------------------------------------------
		    S_w2log(1, "Get recording start and end time");
	
	 	    # Recording Start Time
	 	    my $recStartTime_ms = $record_handler -> GetRecStartTimeMillisecEDID("CrashLabel" => $crash, "RecordNumber" => $recordNbr,"EDIDnr" => $tcpar_EDIDNbr);
	 	    
		    S_w2log(1, "Recording start time for EDID: $recStartTime_ms ms");
	
		    # Recording End Time    
		    my $recEndTime_ms = $record_handler -> GetRecEndTimeMillisecEDID("CrashLabel" => $crash, "RecordNumber" => $recordNbr,"EDIDnr" => $tcpar_EDIDNbr);
		    S_w2log(1, "Recording end time for EDID: $recEndTime_ms ms");

	
	        #-----------------------------------------------------------------------
	        # Evaluate maximum Acceration Value and Time
	        #-----------------------------------------------------------------------
			my ($verdict, $expectedMaxAccelValue, $expectedTimeMaxAccelValue);
	   
			if ($tcpar_EvalType eq "MaxAcceleration_Value"){
			
				($verdict, $expectedMaxAccelValue) = EDR_Eval_maximumAcceleration (
			 							  "MaximumAcceleration_EDID" => $EDID_data->{"DataValue"},
										  "Sensor_DataSamples" => $sourceData -> {"DataSamples"},
										  "Sensor_DataUnit" => $sourceData -> {"DataUnit"},
										  "Absolute_Tolerance_Value" => $tcpar_EvalToleranceValue_abs,
										  "ResamplingRateHz" => SENSOR_RESAMPLING_RATE_HZ,
										  "Rec_Start_Time_ms" => $recStartTime_ms,
										  "Rec_End_Time_ms" => $recEndTime_ms,
										  "Crash_TimeZero_s" => ($crashTimeZero_href -> {"Record_$recordNbr"}) * MILLISEC_TO_SECOND,
										  "Evaltype" => $tcpar_EvalType,
										 );
			}
			elsif ($tcpar_EvalType eq "MaxAcceleration_Time") {
	
				($verdict, $expectedTimeMaxAccelValue) = EDR_Eval_maximumAcceleration (
			 							  "TimeMaximumAcceleration_EDID" => $EDID_data->{"DataValue"},
										  "Sensor_DataSamples" => $sourceData -> {"DataSamples"},
										  "Sensor_DataUnit" => $sourceData -> {"DataUnit"},
										  "Absolute_Tolerance_Time" => $tcpar_EvalToleranceTime_abs,
										  "ResamplingRateHz" => SENSOR_RESAMPLING_RATE_HZ,
										  "Rec_Start_Time_ms" => $recStartTime_ms,
										  "Rec_End_Time_ms" => $recEndTime_ms,
										  "Crash_TimeZero_s" => ($crashTimeZero_href -> {"Record_$recordNbr"}) * MILLISEC_TO_SECOND,
										  "Evaltype" => $tcpar_EvalType,
										 );
	
			}
			
			# Test result for DOORS
			my $maxAccelerationValuedetected = $EDID_data->{"DataValue"};
			if ($tcpar_EvalType eq "MaxAcceleration_Value")
			{
				S_teststep_expected("Max acceleration value within +/- $tcpar_EvalToleranceValue_abs g of max acceleration sensor ($expectedMaxAccelValue g)","Evaluation EDID $tcpar_EDIDNbr crash $crash");
				S_teststep_detected("Max acceleration detected is $maxAccelerationValuedetected g","Evaluation EDID $tcpar_EDIDNbr crash $crash");
				
			}
		    elsif ($tcpar_EvalType eq "MaxAcceleration_Time"){
				S_teststep_expected("Max acceleration values around +/- $tcpar_EvalToleranceTime_abs ms of max acceleration time recorded in EDR are within 0.1g tolerance of max acceleration value from acceleration sensor ($expectedMaxAccelValue g)","Evaluation EDID $tcpar_EDIDNbr crash $crash");
				S_teststep_detected("Max acceleration values around +/- $tcpar_EvalToleranceTime_abs ms of max acceleration time $expectedTimeMaxAccelValue ms not within0.1g tolerance of max acceleration value from acceleration sensor ($expectedMaxAccelValue g)","Evaluation EDID $tcpar_EDIDNbr crash $crash") if $verdict eq 'VERDICT_FAIL';
				S_teststep_detected("Max acceleration values around +/- $tcpar_EvalToleranceTime_abs ms of max acceleration time $expectedTimeMaxAccelValue ms is within 01.g tolerance of max acceleration value from acceleration sensor ($expectedMaxAccelValue g)","Evaluation EDID $tcpar_EDIDNbr crash $crash") if $verdict eq 'VERDICT_PASS';
	       
		    }
				       
	   
        	# next record
		}
		# next crash
	}

    return 1;
}

1;