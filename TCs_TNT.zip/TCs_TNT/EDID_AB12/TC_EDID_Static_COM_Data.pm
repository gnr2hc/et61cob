#### TEST CASE MODULE
package TC_EDID_Static_COM_Data;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
use LIFT_labcar;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;
use LIFT_can_access;
use LIFT_flexray_access;
use LIFT_crash_simulation;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use GENERIC_DCOM;
use LIFT_PD;
#include further modules here

##################################

our $PURPOSE = "<summarize what this test is good for>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDID_Static_COM_Data

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Set the  <COMSignal> to default state

2. Wait for <WaitTimeTransmitSignal_msec> until the signal is transmitted on the COM bus

3. Create <Condition>on <COMSignal>

4. Wait <WaitTimeAfterCondition_msec>

5. Inject a Crash <Crashcode>

6. Read <EDID> corresponding to COM signal


I<B<Evaluation>>

1. -

2. -

3. -

4. -

5. -

6. 

COMSignalValue corresponding to <ExpectedCOMSignalData> should be reported in EDR


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Crashcode' => 
	SCALAR 'CrashTimeZero_ms' => 
	SCALAR 'ValueChange_Incident1' => 
	HASH 'DataValue1' => 
	HASH 'DataValue2' => 
	SCALAR 'NbrOfExpectedRecords' => 
	HASH 'ExpectedValue_Incident1' => 
	SCALAR 'purpose' => 
	SCALAR 'ResultDB' => 
	SCALAR 'DiagType' => 
	LIST 'EDIDs' => 
	HASH 'DataSource' => 
	HASH 'DataSourceType' => 
	SCALAR 'CapturingTime_ms' => 
	SCALAR 'CapturingTimeTolerance_ms' => 
	HASH 'DataValue3' => 


=head2 PARAMETER EXAMPLES

	purpose		 = 'Validate static COM signal reported in EDR'
	ResultDB = 'EDR'
	DiagType = 'ProdDiag'
	# List of EDIDs to be evaluated
	# Prerequisite for various EDIDs: They have to be changeable at the same time, e.g. all signals within one CAN message
	EDIDs = @('1003', '1004', '1005', '1006', '1007', '1008', '1009')
	# Data Source for each individual EDID, e.g. CAN or FR signal
	DataSource = %('1003' => 'Edr_AccidentYear', '1004' => 'Edr_AccidentMonth', '1005' => 'Edr_AccidentDay', '1006' => 'Edr_AccidentHour', '1007' => 'Edr_AccidentMinute', '1008' => 'Edr_AccidentSecond', '1009' => 'Edr_AccidentMilliSecond')
	# Data Source Type (e.g. CAN, Flexray,...)
	DataSourceType = %('1003' => 'CAN', '1004' => 'CAN', '1005' => 'CAN', '1006' => 'CAN', '1007' => 'CAN', '1008' => 'CAN', '1009' => 'CAN')
	# Capturing time related to T0 of event
	CapturingTime_ms = 0
	CapturingTimeTolerance_ms = 100 #e.g. cycle time of CAN signal
	# Below are the data values given to the data source - they should vary for the same data element throughout the various test cases
	DataValue3 = %() # optional
	#ValueChange_Incident1 = 'BeforeCapturing' # AfterCapturing/NoChange - mandatory
	#ValueChange_Incident2 = 'BeforeCapturing' # AfterCapturing/NoChange - optional
	# Expected values to be reported in EDR record(s)
	# ExpectedValue_Incident2 = '' # optional
	Crashcode = 'Parallel_EDR_Front_ND_Side_ND;5'
	CrashTimeZero_ms = '17.76'
	
	ValueChange_Incident1 = 'AfterCapturing'
	
	# Valid values, lower boundary
	DataValue1 = %('1003' => '0', '1004' => '1', '1005' => '1', '1006' => '0', '1007' => '0', '1008' => '0', '1009' => '0')
	# Valid values, mid of range
	DataValue2 = %('1003' => '150', '1004' => '6', '1005' => '15', '1006' => '10', '1007' => '30', '1008' => '31', '1009' => '500')
	
	NbrOfExpectedRecords = 1
	ExpectedValue_Incident1 = %('1003' => '2000', '1004' => '1', '1005' => '1', '1006' => '0', '1007' => '0', '1008' => '0', '1009' => '0')

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_ResultDB;
my $tcpar_DiagType;
my $tcpar_EDIDs;
my $tcpar_DataSource;
my $tcpar_DataSourceType;
my $tcpar_CapturingTime_ms;
my $tcpar_CapturingTimeTolerance_ms;
my $tcpar_DataValue3;
my $tcpar_Crashcode;
my $tcpar_CrashTimeZero_ms;
my $tcpar_ValueChange_Incident1;
my $tcpar_ValueChange_Incident2;
my $tcpar_DataValue1;
my $tcpar_DataValue2;
my $tcpar_NbrOfExpectedRecords;
my $tcpar_WaitTimeStorageCompletion_msec;
my $tcpar_ExpectedValue_Incident1;
my $tcpar_ExpectedValue_Incident2;
my $tcpar_ExpectedValue_Incident3;
my $tcpar_Protocol;
my $tcpar_read_NHTSAEDR;
my $tcpar_read_CHINAEDR;

################ global parameter declaration ###################
#add any global variables here
my (
    $record_handler,
    $crash_handler,
    $numberOfRecords,
    $crashDetails_href,
    $crashSettings,
    $crashInfo_href,
	$ChinaEDR_diagType
);

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_ResultDB =  S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_DiagType =  S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_EDIDs =  S_read_mandatory_testcase_parameter( 'EDIDs' );
	$tcpar_DataSource =  S_read_mandatory_testcase_parameter( 'DataSource' );
	$tcpar_DataSourceType =  S_read_mandatory_testcase_parameter( 'DataSourceType' );
	$tcpar_CapturingTime_ms =  S_read_mandatory_testcase_parameter( 'CapturingTime_ms' );
	$tcpar_CapturingTimeTolerance_ms =  S_read_mandatory_testcase_parameter( 'CapturingTimeTolerance_ms' );
	$tcpar_DataValue3 =  S_read_mandatory_testcase_parameter( 'DataValue3' );
	$tcpar_Crashcode =  S_read_mandatory_testcase_parameter( 'Crashcode' );
	$tcpar_CrashTimeZero_ms =  S_read_mandatory_testcase_parameter( 'CrashTimeZero_ms' );
	$tcpar_ValueChange_Incident1 =  S_read_mandatory_testcase_parameter( 'ValueChange_Incident1' );
	if($tcpar_ValueChange_Incident1 !~ (/BeforeCapturing|AfterCapturing|NoChange/)) {
	   S_set_error("Give one of following values for parameter 'ValueChange_Incident1': BeforeCapturing|AfterCapturing|NoChange");
	   return;
	}
	$tcpar_ValueChange_Incident2 =  S_read_optional_testcase_parameter( 'ValueChange_Incident2' );
	if(defined $tcpar_ValueChange_Incident2 and $tcpar_ValueChange_Incident1 !~ (/BeforeCapturing|AfterCapturing|NoChange/)) {
	   S_set_error("Give one of following values for parameter 'ValueChange_Incident2': BeforeCapturing|AfterCapturing|NoChange");
	   return;
	}
	$tcpar_DataValue1 =  S_read_mandatory_testcase_parameter( 'DataValue1' );
	$tcpar_DataValue2 =  S_read_mandatory_testcase_parameter( 'DataValue2' );
	$tcpar_NbrOfExpectedRecords =  S_read_mandatory_testcase_parameter( 'NbrOfExpectedRecords' );
	if($tcpar_NbrOfExpectedRecords > 3){
	    S_set_error("This script only supports automated validation for 3 records!");
	    return;
	}
	$tcpar_WaitTimeStorageCompletion_msec = S_read_mandatory_testcase_parameter( 'WaitTimeStorageCompletion_msec' );
	$tcpar_ExpectedValue_Incident1 =  S_read_mandatory_testcase_parameter( 'ExpectedValue_Incident1' );
	$tcpar_ExpectedValue_Incident2 =  S_read_optional_testcase_parameter( 'ExpectedValue_Incident2' );
	$tcpar_ExpectedValue_Incident3 =  S_read_optional_testcase_parameter( 'ExpectedValue_Incident3' );

	$tcpar_Protocol =  S_read_optional_testcase_parameter( 'Protocol' );
	$tcpar_Protocol = 'CAN' if(not defined $tcpar_Protocol);
	$tcpar_read_NHTSAEDR=S_read_optional_testcase_parameter('read_NHTSAEDR');
	$tcpar_read_CHINAEDR=S_read_optional_testcase_parameter('read_CHINAEDR');
	if(not defined $tcpar_read_CHINAEDR) {
		$tcpar_read_NHTSAEDR = 'yes';
		$tcpar_read_CHINAEDR = 'no';
	}
	else {
		$tcpar_read_NHTSAEDR = 'no';
		my $storageOrder = EDR_getStorageOrder();
		return unless(defined $storageOrder);

		if($storageOrder eq 'PhysicalOrder'){
			$ChinaEDR_diagType= 'ProdDiag';  #In platform NHTSA and China EDR is read via proddiag
		}
		else {
			$ChinaEDR_diagType= 'CHINA_Payload';
		}
	}

	return 1;
}

sub TC_initialization {


	S_teststep("Initialize record and crash handler", 'AUTO_NBR');
	$record_handler = EDR_init_RecordHandler() || return;
	$crash_handler  = EDR_init_CrashHandler() || return;

    $numberOfRecords = SYC_EDR_get_NumberOfEventsToBeStored();
    unless(defined $numberOfRecords){
        S_set_error("'NumberOfEventsToBeStored' not available in SYC - add or overwrite 'SYC_EDR_get_NumberOfEventsToBeStored' with Custlibrary Function");
        return;
    }

	#--------------------------------------------------------------
    # ADD EDR CRASH TIME ZERO AS CRASH SOURCE
    #    
    $crash_handler -> AddCrashSource( "CrashLabel" => $tcpar_Crashcode,
    								  "SourceLabel" => 'CrashTimeZero', 
                                      "OriginalSourceData" => $tcpar_CrashTimeZero_ms,
                                      "SourceUnit" => 'ms',);    


	#--------------------------------------------------------------
    # GET CRASH DETAILS
    #    
	# Crash name or index and result DB from EDR mapping
    $crashDetails_href = {'RESULTDB' => $tcpar_ResultDB, 'CRASHNAME' => $tcpar_Crashcode};
    unless(defined $crashDetails_href){
        S_set_error("Crash $tcpar_Crashcode not available in result DB $tcpar_ResultDB. Test case aborted.\n".
                    "Check whether 'RESULTDB' -> $tcpar_ResultDB is defined in CREIS mapping!");
        return;
    }

	# Crash settings
    $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
    unless(defined $crashSettings) {
        S_set_error("Crash $tcpar_Crashcode not available in result DB $tcpar_ResultDB. Test case aborted.");
        return;
    }
	
	# Crash code in World DB
    if( defined $crashSettings -> { 'CRASHNAME' } ) {
	     $crash_handler -> AddCrashSource( "CrashLabel" => $tcpar_Crashcode,
	    								  "SourceLabel" => 'CrashCode_MDS', 
	                                      "OriginalSourceData" => $crashSettings -> { 'CRASHNAME' }, );

		$crashInfo_href -> {"CrashCode_MDS"} = $crashSettings -> { 'CRASHNAME' };
    }

	# Name of Result DB
	my $resultDB = $crashDetails_href -> {"RESULTDB"};
	unless(defined $resultDB) {
		$resultDB = "DEFAULT";
	}

	# Result DB path
	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$resultDB" ] );
	$crash_handler -> AddCrashSource( "CrashLabel" => $tcpar_Crashcode,
									  "SourceLabel" => 'MDB_Path', 
	                                  "OriginalSourceData" => $resultDBDetails->{'PATH'}, );

	$crashInfo_href -> {"MDB_Path"} = $resultDBDetails->{'PATH'};

	# Crash time Zero and EDR crash label -> crash name in EDR mapping
	$crashInfo_href -> {"CrashTimeZero_ms"} = $tcpar_CrashTimeZero_ms;
	$crashInfo_href -> {"CrashLabel"} = $tcpar_Crashcode;


	#--------------------------------------------------------------
    # PREPARE TEST SETUP
    #    
    # Power On the ECU
    S_w2log(1, "Power on ECU");
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

    S_w2log(1, "Initialize CD and start CAN trace");
    GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start ( );
	
    # Erase EDR
    PD_ClearCrashRecorder();
    S_wait_ms(2000);

	S_w2log(1, "Set environments for crash as per result DB");
    CSI_PrepareEnvironment($crashSettings, 'init_complete');
    S_wait_ms(2000);
 
    # Erase adn read FltMem
    PD_ClearFaultMemory();
    S_wait_ms(5000);
 
    # Reset and wait for iniend to make sure that all init fault are available
    PD_ECUreset();
    S_wait_ms('TIMER_ECU_READY');

    PD_ReadFaultMemory();
    S_wait_ms(2000);

	return 1;
}

sub TC_stimulation_and_measurement {

	#--------------------------------------------------------------
    # PREPARE CRASH INJECTION AND REPORT FILES
    #    
    S_teststep("Prepare crash", 'AUTO_NBR');
    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

    # Prepare crash
    CSI_LoadCrashSensorData2Simulator($crashSettings);

    # Power ON the ECU
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');
    
    CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    S_wait_ms(1000);

 	my $mappingEDR = S_get_contents_of_hash(['Mapping_EDR']);
	my $edr_COMsignals_aref = undef;
	$edr_COMsignals_aref = $mappingEDR -> {'EDR_COM_SIGNAL_LABELS'};
	unless(defined $edr_COMsignals_aref) {		
		S_w2rep("No EDR relevant COM signals given in EDR mapping under 'EDR_COM_SIGNAL_LABELS' ".
		              " - only dataref of tested COM signals will be stored.");	
	}
	
	my @crashTimeZeroPerIncident = split('_', $tcpar_CrashTimeZero_ms);
	my $t0NumberOfIncideents = @crashTimeZeroPerIncident;
	unless($t0NumberOfIncideents >= $tcpar_NbrOfExpectedRecords){
	    S_set_error("Given T0 ($tcpar_CrashTimeZero_ms ms) has $t0NumberOfIncideents incidents, "
	                   ."while $tcpar_NbrOfExpectedRecords records are expected.");
	    return;
	}
	
	my($waitTimeIncident1, $waitTimeIncident2);
	if($tcpar_ValueChange_Incident1 eq 'BeforeCapturing'){
	    $waitTimeIncident1 = $crashTimeZeroPerIncident[0] + $tcpar_CapturingTime_ms - $tcpar_CapturingTimeTolerance_ms;
	}
	elsif($tcpar_ValueChange_Incident1 eq 'AfterCapturing'){
	    $waitTimeIncident1 = $crashTimeZeroPerIncident[0] + $tcpar_CapturingTime_ms + $tcpar_CapturingTimeTolerance_ms;
	}

    if($tcpar_NbrOfExpectedRecords > 1){
    	if($tcpar_ValueChange_Incident2 eq 'BeforeCapturing'){
    	    $waitTimeIncident2 = $crashTimeZeroPerIncident[1] + $tcpar_CapturingTime_ms - $tcpar_CapturingTimeTolerance_ms;
    	}
    	elsif($tcpar_ValueChange_Incident2 eq 'AfterCapturing'){
    	    $waitTimeIncident2 = $crashTimeZeroPerIncident[1] + $tcpar_CapturingTime_ms + $tcpar_CapturingTimeTolerance_ms;
    	} 
    }


    my @comSignalsToManipulate;
    foreach my $edid (sort {$a <=> $b} keys %{$tcpar_DataSource}){
        push(@comSignalsToManipulate, $tcpar_DataSource -> {$edid});
    }

	S_teststep("Start bus trace", 'AUTO_NBR');
    CA_trace_start ( );

    S_teststep("Set the signals '@comSignalsToManipulate' to 'DataValue1' and wait 5sec", 'AUTO_NBR');
    _set_DataValue($tcpar_DataValue1);
    S_wait_ms(5000);

    if(defined $waitTimeIncident1 and $waitTimeIncident1 < 0){
        S_teststep("Set the signals '@comSignalsToManipulate' to 'DataValue2'", 'AUTO_NBR');
        _set_DataValue($tcpar_DataValue2);
        my $waitTime1_abs = abs($waitTimeIncident1);
        
        if(defined $waitTimeIncident2 and  $waitTimeIncident2 < 0 ){
            my $waitTime2_abs = abs($waitTimeIncident2);
            my $waitTimeDataValue2 = $waitTime1_abs - $waitTime2_abs;
        	S_teststep("Wait $waitTimeDataValue2 ms before setting DataValue3", 'AUTO_NBR');
            S_wait_ms($waitTime2_abs);
            S_teststep("Set the signals '@comSignalsToManipulate' to 'DataValue3'", 'AUTO_NBR');
            _set_DataValue($tcpar_DataValue3);
        	S_teststep("Wait $waitTime2_abs ms before injecting crash", 'AUTO_NBR');
            S_wait_ms($waitTime2_abs);
            
        }
        else{
            S_teststep("Wait $waitTime1_abs ms before injecting crash", 'AUTO_NBR');
            S_wait_ms($waitTime1_abs);
        }
        
        S_teststep("Trigger crash", 'AUTO_NBR');
        CSI_TriggerCrash();
        
        if(defined $waitTimeIncident2 and  $waitTimeIncident2 > 0){
           	S_teststep("Wait $waitTimeIncident2 ms before setting DataValue3", 'AUTO_NBR');
            S_wait_ms($waitTimeIncident2);
            S_teststep("Set the signals '@comSignalsToManipulate' to 'DataValue3'", 'AUTO_NBR');
            _set_DataValue($tcpar_DataValue3);
        }
    }

    if(defined $waitTimeIncident1 and $waitTimeIncident1 >= 0){
        S_teststep("Trigger crash", 'AUTO_NBR');

        CSI_TriggerCrash();

        S_teststep("Wait $waitTimeIncident1 ms to set DataValue2", 'AUTO_NBR');
        S_wait_ms($waitTimeIncident1);
        S_teststep("Set the signals '@comSignalsToManipulate' to 'DataValue2'", 'AUTO_NBR');
        _set_DataValue($tcpar_DataValue2);
        
        $waitTimeIncident2 = $waitTimeIncident2 - $waitTimeIncident1 if(defined $waitTimeIncident2);
    }
    
    if(not defined $waitTimeIncident1) {
        S_teststep("Trigger crash", 'AUTO_NBR');
        CSI_TriggerCrash();        
    } 

    if(defined $waitTimeIncident2 and $waitTimeIncident2 >= 0){
        if(defined $waitTimeIncident1){
            S_teststep("Wait $waitTimeIncident2 ms to set DataValue3", 'AUTO_NBR');
            S_wait_ms($waitTimeIncident2);
            S_teststep("Set the signals '@comSignalsToManipulate' to 'DataValue3'", 'AUTO_NBR');
            _set_DataValue($tcpar_DataValue3);
        }
        else{ # No change for first incident
            S_teststep("Wait $waitTimeIncident2 ms to set DataValue2", 'AUTO_NBR');
            S_wait_ms($waitTimeIncident2);
            S_teststep("Set the signals '@comSignalsToManipulate' to 'DataValue2'", 'AUTO_NBR');
            _set_DataValue($tcpar_DataValue2);
        }
    }

	S_teststep("Wait for completion of EDR storage", 'AUTO_NBR');
	S_wait_ms($tcpar_WaitTimeStorageCompletion_msec);

    my @edids = @{$tcpar_EDIDs};
	S_teststep("Read EDIDs '@edids' corresponding to manipulated COM signals", 'AUTO_NBR', 'ReadCrashRecords');
	my $dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_Static_COM";

	if ( lc( $tcpar_read_NHTSAEDR) eq 'yes' ) {
		S_w2rep("Nbr of records: $numberOfRecords");
		EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
								"CrashLabel" => $tcpar_Crashcode,
								"NbrOfRecords" =>  $numberOfRecords,
								"StoragePath" => $dataStoragePath,
								"read_EDRType"=>'NHTSA')
	}
	if (lc($tcpar_read_CHINAEDR) eq 'yes'){
		$numberOfRecords=3;
		S_w2rep("Nbr of records: $numberOfRecords");
		EDR_ReadAndStoreAllRecords ("DiagType" =>  $ChinaEDR_diagType,
								"CrashLabel" => $tcpar_Crashcode,
								"NbrOfRecords" =>  $numberOfRecords,
								"StoragePath" => $dataStoragePath,
								"read_EDRType"=>'CHINA');
	}								

	# Store CAN signal
	S_w2rep("Store $tcpar_Protocol Trace");
	my $fileName = "$dataStoragePath/LIFT_network_trace_$tcpar_Crashcode.asc";
	my $tracePath;
	$tracePath = CA_trace_store($fileName) if (lc($tcpar_Protocol) =~ m/can/i);
	$tracePath = FR_trace_store($fileName) if (lc($tcpar_Protocol) =~ m/flexray/i);
	GEN_printLink($tracePath);

	S_wait_ms(2000);

	# Restart measurement after storage
    CA_trace_start() if (lc($tcpar_Protocol) =~ m/can/i);
    FR_trace_start() if (lc($tcpar_Protocol) =~ m/flexray/i);

	my $eventTrigger_dataref;
	unless($main::opt_offline) {
		S_w2rep("Get COM trace data reference for all manipulated COM signals");
		$eventTrigger_dataref = CA_trace_get_dataref($fileName, ['EventTrigger']);
		unless(defined $eventTrigger_dataref){
    		S_set_error("COM signal time zero could not be obtained from CAN trace (message 'EventTrigger').\n"
    		              ."- Check whether message is seen in CANoe trace.\n"
    		              ."- Check whether message is filtered out in logging block of CANoe.\n"
    		              ."- Check whether message is defined in CAN mapping\n"
                          ."- Check whether the TSG4 firmware is up to date (Minimum firmware version 17 required)");
    	   return;		    
		}
	}

	my ($value_aref, $time_aref) = EVAL_get_values_and_times_over_time( $eventTrigger_dataref , "EventTrigger") unless($main::opt_offline);
	my $comSignalTimeZero = $time_aref -> [0];
	$comSignalTimeZero = 0 if($main::opt_offline);
	unless(defined $comSignalTimeZero){
		S_set_error("COM signal time zero could not be obtained from CAN trace (message 'EventTrigger').\n"
		              ."- Check whether message is seen in CANoe trace.\n"
		              ."- Check whether message is filtered out in logging block of CANoe.\n"
		              ."- Check whether message is defined in CAN mapping\n"
                      ."- Check whether the TSG4 firmware is up to date (Minimum firmware version 17 required)");
	   return;
	}
	S_w2rep("Event Trigger time stamp: $comSignalTimeZero seconds");

	return 1;
}

sub TC_evaluation {

    my $expectedDataRecords_href;
    
    
    my $storageOrder = EDR_getStorageOrder();
    return unless($storageOrder);
    
    if($tcpar_NbrOfExpectedRecords == 3){
        if($storageOrder =~ /MostRecentLast|PhysicalOrder/){
            $expectedDataRecords_href = {
                1 => $tcpar_ExpectedValue_Incident1,
        	    2 => $tcpar_ExpectedValue_Incident2,
        	    3 => $tcpar_ExpectedValue_Incident3,   
            };
        }
        elsif($storageOrder eq 'MostRecentFirst'){
            $expectedDataRecords_href = {
                3 => $tcpar_ExpectedValue_Incident1,
        	    2 => $tcpar_ExpectedValue_Incident2,
        	    1 => $tcpar_ExpectedValue_Incident3,   
            };        
        }        
    }
    elsif($tcpar_NbrOfExpectedRecords == 2){
        if($storageOrder =~ /MostRecentLast|PhysicalOrder/){
            $expectedDataRecords_href = {
                1 => $tcpar_ExpectedValue_Incident1,
        	    2 => $tcpar_ExpectedValue_Incident2,
            };
        }
        elsif($storageOrder eq 'MostRecentFirst'){
            $expectedDataRecords_href = {
                2 => $tcpar_ExpectedValue_Incident1,
        	    1 => $tcpar_ExpectedValue_Incident2,
            };        
        }            
    }
    elsif($tcpar_NbrOfExpectedRecords == 1){
        $expectedDataRecords_href = {1 => $tcpar_ExpectedValue_Incident1};
    }

	S_teststep_expected("$tcpar_NbrOfExpectedRecords records stored", 'ReadCrashRecords');
    my $detectedNumberOfRecords = 0;
    foreach my $recordNbr (1..$tcpar_NbrOfExpectedRecords){
        
        my $recordAvailable = $record_handler -> IsRecordAvailable( "CrashLabel" => $tcpar_Crashcode,
                                                                    "RecordNumber"=> $recordNbr);
        $detectedNumberOfRecords++ if($recordAvailable);     
    }
	my $verdict= EVAL_evaluate_value("NumberOfRecords", $detectedNumberOfRecords,'==', $tcpar_NbrOfExpectedRecords);
	S_teststep_detected("$detectedNumberOfRecords records stored", 'ReadCrashRecords');

	unless ($verdict eq "VERDICT_PASS"){
		S_w2rep("Number of detected records is incorrect, no further EDID validation is done");
		return 1;
	}	

    foreach my $recordNbr (1..$tcpar_NbrOfExpectedRecords){
        my $expectedValuesThisRecord_href = $expectedDataRecords_href ->{$recordNbr};

        S_teststep("--- Record $recordNbr ---", 'NO_AUTO_NBR');
        foreach my $edid (sort {$a <=> $b} keys %{$expectedValuesThisRecord_href})
        {
            S_teststep("Evaluate EDID $edid in record $recordNbr", 'AUTO_NBR', "EDID_$edid\_Record_$recordNbr");
            my $expectedEdidValue = $expectedValuesThisRecord_href -> {$edid};
            S_teststep_expected("$expectedEdidValue", "EDID_$edid\_Record_$recordNbr");
 
            my $edidData = $record_handler -> GetDecodedEDID( "CrashLabel" => $tcpar_Crashcode,
                                                                 "RecordNumber"=> $recordNbr,
                                                                 "EDIDnr" => $edid);
																 
			
            unless(defined $edidData){
                S_teststep_detected("EDID $edid not stored in record $recordNbr", "EDID_$edid\_Record_$recordNbr");
                S_set_verdict('VERDICT_FAIL');
                next;
            }
            
            my $detectedEdidValue = $edidData -> {DataValue};
			
            if($detectedEdidValue =~ /^[0-9]+$/i and $expectedEdidValue  =~ /^[0-9]+$/i){
                EVAL_evaluate_value("EDID_$edid\_Record_$recordNbr", $detectedEdidValue,'==', $expectedEdidValue);
            }
            else{
				$detectedEdidValue=~ s/\s+$//;
                EVAL_evaluate_string("EDID_$edid\_Record_$recordNbr", $expectedEdidValue, $detectedEdidValue);
            }
            S_teststep_detected("$detectedEdidValue", "EDID_$edid\_Record_$recordNbr");
        }
     }


	return 1;
}

sub TC_finalization {


	S_w2rep("Start test case finalization");

	#Delete Record Handler
	foreach my $record (1..$numberOfRecords){
    	$record_handler -> DeleteRecord(  "CrashLabel" => $tcpar_Crashcode,
    									  "RecordNumber" => $record );	    
	}

	#--------------------------------------------------------------------------------------------------------
	#Clearing crash recorder
	PD_ClearCrashRecorder();
	S_wait_ms(2000);

	#Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	# Reset ECU
	PD_ECUreset();
	S_wait_ms('TIMER_ECU_READY');

	#Read fault memory after clearing and erasing EDR
	PD_ReadFaultMemory();

	LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

	return 1;
}

sub _set_DataValue {
    
    my $dataValue_href = shift;
    
    foreach my $edid (sort {$a <=> $b} keys %{$tcpar_DataSource}){
        my $dataSourceType = $tcpar_DataSourceType -> {$edid};
        unless(defined $dataSourceType){
            S_set_error("No data source type specified for EDID $edid in parameter 'DataSourceType'");
            next;
        }
        my $dataValue = $dataValue_href -> {$edid};
        unless(defined $dataValue){
            S_set_error("No value specified for EDID $edid in parameter 'DataValue1'");
            next;
        }
        my $comSignal = $tcpar_DataSource -> {$edid};
        if(lc($dataSourceType) eq 'can'){
            S_teststep_2nd_level("Set CAN signal $comSignal to value $dataValue", 'AUTO_NBR');
            CA_write_can_signal($comSignal, $dataValue, 'phys');
        }
        elsif(lc($dataSourceType) eq 'flexray'){
            S_teststep_2nd_level("Set Flexray signal $comSignal to value $dataValue", 'AUTO_NBR');
            FR_write_flxr_signal($comSignal, $dataValue, 'phys');
        }
        else{
            S_set_error("Data source type $dataSourceType for EDID $edid is not supported!\n".
                        "Supported data types are: CAN, Flexray");
                        next;
        }
    }
    
    return 1;
    
}


1;
