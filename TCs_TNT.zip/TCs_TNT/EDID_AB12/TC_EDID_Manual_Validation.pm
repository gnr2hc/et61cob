#### TEST CASE MODULE
package TC_EDID_Manual_Validation;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general;
use FuncLib_EDR_Framework;
use File::Basename;
use Data::Dumper;
##################################
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDID_Manual_Validation  $Revision: 1.4 $

requires previous crash injection
   with storage of fire times and EDR records in
   Crash / Record handler
   e.g. use TC_EDR_CrashInjection.pm (ONLINE)
   or TC_EDR_CrashDataRetrieval.pm (OFFLINE)

TC does not require any equipment - only previously
   obtained data will be used

=head1 PURPOSE

to get raw data for specific EDIDs for manual validation

=head1 TESTCASE DESCRIPTION 

    [initialisation]
    initialize record handler

    [stimulation & measurement]
	not needed

    [evaluation]
    1. get list of stored records
    2. extract raw data for EDID and print it

    [finalisation]
    not needed

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

	EDID --> EDID number to be evaluated  	

=head2 PARAMETER EXAMPLES

    [TC_EDID_Manual_Validation.CompleteFileRecorded]
	# From here on: applicable Lift Default Parameters
	EDID = 51

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_EDID;
my $tcpar_purpose;
################ global parameter declaration ###################
#add any global variables here
my(
    $record_handler,
    $crash_handler,
);

our $PURPOSE;
our $TC_name = "TC_EDID_FireTimeValidation";

#-------------------------------------------------------------------------------
sub TC_set_parameters {
#-------------------------------------------------------------------------------
    $tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_EDID = S_read_mandatory_testcase_parameter('EDID');
	S_add2eval_collection ( 'EDID' , $tcpar_EDID);
	my $allAttributes = EDR_fetchEDIDallAttributes_by_ID($tcpar_EDID);
	S_add2eval_collection('EDID From', $allAttributes -> {'From'}) if (defined $allAttributes -> {'From'});

	return 1;
}

#-------------------------------------------------------------------------------
sub TC_initialization {
#-------------------------------------------------------------------------------
	#--------------------------------------------------------------
    # INITIALIZE RECORD AND CRASH HANDLER
    #    
	$record_handler = EDR_init_RecordHandler() || return;
	$crash_handler  = EDR_init_CrashHandler() || return;

    return 1;
}

#-------------------------------------------------------------------------------
sub TC_stimulation_and_measurement {
#-------------------------------------------------------------------------------
	S_w2rep("No stimulation needed.");

    return 1;
}

#-------------------------------------------------------------------------------
sub TC_evaluation {
#-------------------------------------------------------------------------------
	my $storedCrashLabels_aref = $record_handler -> GetListOfStoredRecords();
	
	foreach my $crash (@{$storedCrashLabels_aref})
	{
		my $crashCode_MDS = $crash_handler -> GetSourceDataValues ( "SourceLabel" => "CrashCode_MDS",															        "CrashLabel"  => $crash );
		$crashCode_MDS = $crashCode_MDS -> {"DataValues"};

		my $path_MDB = $crash_handler -> GetSourceDataValues ( "SourceLabel" => "MDB_Path",															        "CrashLabel"  => $crash );
		$path_MDB = $path_MDB -> {"DataValues"};
		
		S_w2rep("-------------------------------------------------------------");
		S_w2rep("Squib Evaluation for Crash $crash");
		S_w2log(1, "Crash code: $crashCode_MDS");
		S_w2log(1, "Result DB path: $path_MDB");
		S_w2rep("-------------------------------------------------------------");
		#--------------------------------------------------------------
	    # GET CRASH TIME ZERO
		#    
		my $crashTimeZero = $crash_handler -> GetSourceDataValues ( "SourceLabel" => "CrashTimeZero",
															        "CrashLabel"  => $crash );
		unless(defined $crashTimeZero) {
			S_set_error("No crash time zero stored for crash $crash. No evaluation of fire times possible. Try next crash.", 110);
			next;
		}
		my $crashTimeZero_ms = $crashTimeZero -> {"DataValues"};
		my $crashTimeZeroUnit = $crashTimeZero -> {"DataUnit"};
		if($crashTimeZeroUnit ne "ms") {
			S_set_error("Crash Time zero must be stored in ms!! Go to next crash.", 110);
			next;
		}

		my @crashTimeZeros_array = split(/_/, $crashTimeZero_ms);
		my $numberOfRecords = @crashTimeZeros_array;

		for (my $record = 1; $record <= $numberOfRecords; $record++)
		{
			my $rawEDIDdata = $record_handler -> GetRawEDID( "CrashLabel" => $crash,
			                                                 "RecordNumber" => $record,
			                                                 "EDIDnr" => $tcpar_EDID,
			                                                 "FormatOption" => 'HEX' );
			unless(defined $rawEDIDdata){
				S_set_error("No EDR data for EDID '$tcpar_EDID' (crash $crash).");
				return;
			}
			
			if(ref($rawEDIDdata) eq 'ARRAY') {
				my $rawEDIDstring;
				foreach my $rawDataSample (@{$rawEDIDdata})
				{
					$rawEDIDstring = $rawEDIDstring."$rawDataSample ";
				}
				$rawEDIDdata = $rawEDIDstring;
			}

            my $decodedEDIDdata = $record_handler -> GetDecodedEDID( "CrashLabel" => $crash,
                                                             "RecordNumber" => $record,
                                                             "EDIDnr" => $tcpar_EDID);
            my $decodedValue;
            my $decodedUnit;
            if(not defined $decodedEDIDdata){
                S_set_warning("No decoded EDR data for EDID '$tcpar_EDID' (crash $crash).");
            }
            else{
                $decodedValue = $decodedEDIDdata -> {'DataValue'};
                my $decodedArray = $decodedEDIDdata -> {'DataValuesArray'};
                $decodedUnit = $decodedEDIDdata -> {'ValueUnit'};
                if($decodedArray){
                    foreach my $decodedDataSample (@{$decodedArray})
                    {
                        $decodedValue = $decodedValue."$decodedDataSample ";
                    }  
                }
            }

			S_teststep("Validation EDID  $tcpar_EDID, crash $crash, record $record", 'AUTO_NBR', "EDID_$tcpar_EDID\_record_$record\_Crash$crash");
			S_teststep_expected("Manual expectation:", "EDID_$tcpar_EDID\_record_$record\_Crash$crash"); #evaluation 1
			S_teststep_detected("Raw (hex): $rawEDIDdata", "EDID_$tcpar_EDID\_record_$record\_Crash$crash");
            S_teststep_detected("Decoded ($decodedUnit): $decodedValue", "EDID_$tcpar_EDID\_record_$record\_Crash$crash");
		}
		
		# next Crash
	}
	
    return 1;
}

1;