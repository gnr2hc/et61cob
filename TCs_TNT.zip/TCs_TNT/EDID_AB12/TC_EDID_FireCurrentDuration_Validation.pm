#### TEST CASE MODULE
package TC_EDID_FireCurrentDuration_Validation;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general;
use LIFT_evaluation;
use File::Basename;
use Data::Dumper;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;
use EDR_Framework::FuncLib_EDR_Offline_xmlLogging;

##################################
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDID_FireCurrentDuration_Validation  $Revision: 1.11 $

requires previous crash injection
   with storage of fire times and fire current duration and EDR records in
   Crash / Record handler
   e.g. use TC_EDR_CrashInjection.pm (ONLINE)
   or TC_EDR_CrashDataRetrieval.pm (OFFLINE)

TC does not require any equipment - only previously
   obtained data will be used

=head1 PURPOSE

to validate fire current durations stored in EDR

=head1 TESTCASE DESCRIPTION 

    [initialisation]
    initialize record handler

    [stimulation & measurement]
	not needed

    [evaluation]
    1. get list of stored records
    2. evaluate fire current duration of squib xy for each stored record

    [finalisation]
    not needed

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

	SquibLabel --> Label of squib to be evaluated
	EDID --> EDID number of squib to be evaluated
	EDID_FireTime --> EDID number of fire time of corresponding SquibLabel
	EvalTolerance_abs --> Tolerance in ms for deployment time
  	

=head2 PARAMETER EXAMPLES

    [TC_EDID_FireCurrentDuration_Validation.AB1FD]
	# From here on: applicable Lift Default Parameters
	SquibLabel = 'AB1FD'
	EDID = '865'
	EDID_FireTime = '51'
	EvalTolerance_abs = 0.025 #msec -> 25�sec

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_EDIDNbr;
my $tcpar_SquibLabel;
my $tcpar_EvalTolerance_abs;
my $tcpar_EvalToleranceFireTime_msec_abs;
my $tcpar_EDIDNbr_FireTime;
my $tcpar_CrashList_aref;
my $tcpar_purpose;
my $tcpar_ExpectedValueNotConfigured;
my $tcpar_FiringCurrentLevel;
my $tcpar_FireCounterEval;


################ global parameter declaration ###################
#add any global variables here
my(
    $record_handler,
    $crash_handler,
);

our $PURPOSE;
our $TC_name = "TC_EDID_FireTimeValidation";

#-------------------------------------------------------------------------------
sub TC_set_parameters {
#-------------------------------------------------------------------------------
	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
    $tcpar_EDIDNbr = S_read_mandatory_testcase_parameter('EDID');
    $tcpar_SquibLabel = S_read_mandatory_testcase_parameter('SquibLabel');
    $tcpar_EvalTolerance_abs = S_read_mandatory_testcase_parameter('EvalTolerance_msec_abs');
	$tcpar_EvalToleranceFireTime_msec_abs = S_read_optional_testcase_parameter('EvalToleranceFireTime_msec_abs');
	if (not defined $tcpar_EvalToleranceFireTime_msec_abs){
		S_w2rep (" Setting tolerance for fire time to default 3ms");
		$tcpar_EvalToleranceFireTime_msec_abs=3;
	}
    $tcpar_EDIDNbr_FireTime = S_read_mandatory_testcase_parameter('EDID_FireTime');
    $tcpar_CrashList_aref = S_read_optional_testcase_parameter('CrashList', 'byref');
    $tcpar_ExpectedValueNotConfigured = S_read_optional_testcase_parameter('ExpectedValueNotConfigured');
    $tcpar_FireCounterEval = S_read_optional_testcase_parameter('FireCounterEval');
    if(defined $tcpar_FireCounterEval and lc($tcpar_FireCounterEval) eq 'true'){
        $tcpar_FiringCurrentLevel = S_read_mandatory_testcase_parameter('FiringCurrentLevel');        
    }
    else{
        $tcpar_FireCounterEval = 'false';
    }
	S_add2eval_collection ( 'EDID' , $tcpar_EDIDNbr);
	my $allAttributes = EDR_fetchEDIDallAttributes_by_ID($tcpar_EDIDNbr);
	S_add2eval_collection('EDID From', $allAttributes -> {'From'}) if (defined $allAttributes -> {'From'});

	return 1;
}

#-------------------------------------------------------------------------------
sub TC_initialization {
#-------------------------------------------------------------------------------
	#--------------------------------------------------------------
    # INITIALIZE RECORD AND CRASH HANDLER
    #    
	$record_handler = EDR_init_RecordHandler() || return;
	$crash_handler  = EDR_init_CrashHandler() || return;

    return 1;
}

#-------------------------------------------------------------------------------
sub TC_stimulation_and_measurement {
#-------------------------------------------------------------------------------
	S_w2rep("No stimulation needed.");

    return 1;
}

#-------------------------------------------------------------------------------
sub TC_evaluation {
#-------------------------------------------------------------------------------
	my ($fireTimeValidationResult_href, $storedCrashLabels_aref);
	if(defined $tcpar_CrashList_aref) {
		$storedCrashLabels_aref = $tcpar_CrashList_aref;
	}
	else {
		$storedCrashLabels_aref = $record_handler -> GetListOfStoredRecords();
	}
	
	foreach my $crash (@{$storedCrashLabels_aref})
	{
        # check whether EDID is there in record
        my $edidData = $record_handler -> GetDecodedEDID("CrashLabel" => $crash, "RecordNumber" => 1, "EDIDnr" => $tcpar_EDIDNbr_FireTime);
        next unless($edidData);

		my $sourceDataCrashLabel;
		if($crash =~ m/(.*)_Supplier/){
			my @splitCrashCode = split('_Supplier', $crash);
			$sourceDataCrashLabel = $splitCrashCode[0];			
		}
		else {
			$sourceDataCrashLabel = $crash;
		}
		
		my $compareOperator = '==';

		my $crashCode_MDS = $crash_handler -> GetSourceDataValues ( "SourceLabel" => "CrashCode_MDS", "CrashLabel"  => $sourceDataCrashLabel );
		$crashCode_MDS = $crashCode_MDS -> {"DataValues"};

		my $path_MDB = $crash_handler -> GetSourceDataValues ( "SourceLabel" => "MDB_Path",	"CrashLabel"  => $sourceDataCrashLabel );
		$path_MDB = $path_MDB -> {"DataValues"};
		
		S_w2rep("-------------------------------------------------------------");
		S_w2rep("Squib Evaluation for Crash $crash");
		S_w2log(1, "Crash code: $crashCode_MDS");
		S_w2log(1, "Result DB path: $path_MDB");
		S_w2rep("-------------------------------------------------------------");

		my $crashTimeZero = $crash_handler -> GetSourceDataValues ( "SourceLabel" => "CrashTimeZero",
															        "CrashLabel"  => $sourceDataCrashLabel );
		unless(defined $crashTimeZero) {
			S_set_error("No crash time zero stored for crash $crash. No evaluation of fire times possible. Try next crash.", 110)unless ($main::opt_offline);
			next;
		}
		my $crashTimeZero_ms = $crashTimeZero -> {"DataValues"};
		my $crashTimeZeroUnit = $crashTimeZero -> {"DataUnit"};
		if($crashTimeZeroUnit ne "ms") {
			S_set_error("Crash Time zero must be stored in ms!! Go to next crash.", 110);
			next;
		}

		my ($squibVerdict, $allResults) = EDR_Eval_SquibFireTimes_NOVERDICT("CrashLabel" => $crash,
													"CrashLabel_FireTimes" => $sourceDataCrashLabel,
		                                           "EDID_SquibLabels" => {$tcpar_EDIDNbr_FireTime => $tcpar_SquibLabel},
		                                           "CrashTimeZero_ms" => $crashTimeZero_ms,
		                                           "FireTimeTolerance_ms" => $tcpar_EvalToleranceFireTime_msec_abs);
		
		foreach my $record (sort keys %{$allResults -> {$tcpar_SquibLabel}})
		{
			my $expected = $allResults -> {$tcpar_SquibLabel} -> {$record} -> {'CurrentDuration'};
			my $configured = 'yes';
			if(not defined $expected) {
			    my $result;
				( $result, $configured ) = SYC_SQUIB_get_Configured( $tcpar_SquibLabel);
				S_w2rep("Result: $result , configured: $configured");
				$configured = 'no' unless($result);
				$expected = $tcpar_ExpectedValueNotConfigured if($configured ne 'yes');
				$expected = 0 if($configured eq 'yes' or $main::opt_offline);	
			}
			
		    if((lc($tcpar_FireCounterEval) eq 'true') and ($configured eq 'yes')){
		        S_teststep_2nd_level("Extract expected data from fire counter value stored in crash handler", 'AUTO_NBR');
                my $fireCounterSourceLabel;
                $fireCounterSourceLabel = $tcpar_SquibLabel."_FireCounter_LowLevel_ms" if(lc($tcpar_FiringCurrentLevel) eq 'low');
                $fireCounterSourceLabel = $tcpar_SquibLabel."_FireCounter_HighLevel_ms" if(lc($tcpar_FiringCurrentLevel) eq 'high');
                my $fireCounter_href = $crash_handler -> GetSourceDataValues ( "SourceLabel" => $fireCounterSourceLabel,
                                                                            "CrashLabel"  => $sourceDataCrashLabel );
                unless(defined $fireCounter_href) {
                    S_set_error("Fire counter value not stored. Evaluation not possible for this squib.", 110);
                    next;
                }
                $expected = $fireCounter_href -> {"DataValues"};
		    }
			my @recordNbr_array = split(/_/, $record);
			my $recordNbr = $recordNbr_array[1];
			my $edidData = $record_handler -> GetDecodedEDID("CrashLabel" => $crash, "RecordNumber" => $recordNbr, "EDIDnr" => $tcpar_EDIDNbr);
			next unless($edidData);

            my $edidValue = $edidData -> { DataValue };
            my $edidUnit = $edidData -> {ValueUnit};

			my $fireCurrentDataElement = $record_handler -> GetDataElementEDID("CrashLabel" => $crash,
																			"RecordNumber" => $recordNbr,
																			"EDIDnr" => $tcpar_EDIDNbr);

            my $verdict;
            if($edidValue =~ /[a-zA-Z]/) {
               $verdict = EVAL_evaluate_string ( "FireCurrentDuration_$crash\_Record$record",
                                                  $expected,
                                                  $edidValue,);
            }
            else {
            	$verdict = EVAL_evaluate_value ( "FireCurrentDuration_$crash\_Record$record",
                                                    $edidValue,
                                                    '==',
                                                    $expected,
                                                    $tcpar_EvalTolerance_abs,
                                                    'absolute');
            }

			S_teststep("Validation of fire current duration squib $tcpar_SquibLabel, crash $crash, record $recordNbr", 'AUTO_NBR', "FireCurrentDuration_$record\_Crash$crash");
			S_teststep_expected("$expected (ms)", "FireCurrentDuration_$record\_Crash$crash"); #evaluation 1
			S_teststep_detected("$edidValue (ms)", "FireCurrentDuration_$record\_Crash$crash");

			if(S_get_exec_option_NOERROR('CreisOfflineEvalReporting')){
				FLEDR_XML_addStaticEdidNode(
						$recordNbr, # record number
						'Deployment',
						$tcpar_EDIDNbr,
						$tcpar_SquibLabel." - ".$fireCurrentDataElement,
						$expected,
						$edidValue,
						$tcpar_EvalTolerance_abs,
						$edidUnit,
						$verdict,
				);
		    }

		}
		
		# next Crash
	}
	
    return 1;
}

1;