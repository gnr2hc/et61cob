#### TEST CASE MODULE
package TC_EDID_MultiEvent_Validation;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general;
use LIFT_evaluation;
use INCLUDES_Project;
use File::Basename;
use Data::Dumper;
##################################
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDID_MultiEvent_Validation  $Revision: 1.4 $

requires raw EDR data (setup already done in IC)

default state is faultfree ECU powered ON

=head1 PURPOSE

to implement EDR Testing Framework

=head1 TESTCASE DESCRIPTION 

    [initialisation]
    initialize record handler
    initialize crash handler

    [stimulation & measurement]
	1. Inject Crash (No actual crash injection, crash data in crash handler is used)
	2. Read EDR for crash (stored data in record handler is used)

    [evaluation]
    1. Compare multi-event number and time between previous and current event to expected values

    [finalisation]
    not needed

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

	Tolerance_Time => Tolerance for multi-event time in ms
	EDID_MEnumber => data element ID for multi-event number
	EDID_MEtime => data element ID for time between previous and current event

=head2 PARAMETER EXAMPLES

	[TC_EDID_MultiEvent_Validation.BLFD] 
	Tolerance_Time = '2'
	EDID_MEnumber = '14'
	EDID_MEtime = '15'

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_EDID_MEnumber;
my $tcpar_EDID_MEtime;
my $tcpar_Tolerance_Time;
my $tcpar_purpose;

################ global parameter declaration ###################
#add any global variables here
my(
    $record_handler,
    $crash_handler,
);

our $PURPOSE;
our $TC_name = "TC_EDID_MultiEvent_Validation";

#-------------------------------------------------------------------------------
sub TC_set_parameters {
#-------------------------------------------------------------------------------
    $tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_EDID_MEnumber = GEN_Read_mandatory_testcase_parameter('EDID_MEnumber');
    $tcpar_EDID_MEtime = GEN_Read_mandatory_testcase_parameter('EDID_MEtime');
    $tcpar_Tolerance_Time = GEN_Read_mandatory_testcase_parameter('Tolerance_Time');
	S_add2eval_collection ( 'EDID' , $tcpar_EDID_MEnumber.", ".$tcpar_EDID_MEtime);
	my $allAttributes_MEnumber = EDR_fetchEDIDallAttributes_by_ID($tcpar_EDID_MEnumber);
	my $from_MEnumber = $allAttributes_MEnumber -> {'From'};
	my $allAttributes_MEtime = EDR_fetchEDIDallAttributes_by_ID($tcpar_EDID_MEtime);
	my $from_MEtime = $allAttributes_MEtime -> {'From'};
	S_add2eval_collection('EDID From', $from_MEnumber.", ".$from_MEtime) if (defined $allAttributes_MEnumber -> {'From'});

	return 1;
}

#-------------------------------------------------------------------------------
sub TC_initialization {
#-------------------------------------------------------------------------------
	#--------------------------------------------------------------
    # INITIALIZE RECORD AND CRASH HANDLER
    #    
	$record_handler = EDR_init_RecordHandler() || return;
	$crash_handler  = EDR_init_CrashHandler() || return;

    return 1;
}

#-------------------------------------------------------------------------------
sub TC_stimulation_and_measurement {
#-------------------------------------------------------------------------------
	S_w2rep("No stimulation needed");
    return 1;
}

#-------------------------------------------------------------------------------
sub TC_evaluation {
#-------------------------------------------------------------------------------
	my $storedCrashLabels_aref = $record_handler -> GetListOfStoredRecords();
	
	foreach my $crash (@{$storedCrashLabels_aref})
	{
		my $crashCode_MDS = $crash_handler -> GetSourceDataValues ( "SourceLabel" => "CrashCode_MDS",															        "CrashLabel"  => $crash );
		$crashCode_MDS = $crashCode_MDS -> {"DataValues"};

		my $path_MDB = $crash_handler -> GetSourceDataValues ( "SourceLabel" => "MDB_Path",															        "CrashLabel"  => $crash );
		$path_MDB = $path_MDB -> {"DataValues"};

		S_w2rep("#---------------------------------------------");
		S_w2rep("Multi event number and time, Crash $crash");
		S_w2log(1, "Crash code: $crashCode_MDS");
		S_w2log(1, "Result DB path: $path_MDB");
		S_w2rep("#---------------------------------------------");

        #-----------------------------------------------------------------------
        # Get crash time zero
        #-----------------------------------------------------------------------
		my $crashTimeZero = $crash_handler -> GetSourceDataValues ( "SourceLabel" => "CrashTimeZero",
															        "CrashLabel"  => $crash );
		unless(defined $crashTimeZero) {
			S_set_error("No crash time zero stored for crash $crash. No evaluation of ring buffer possible. Try next crash.", 110);
			next;
		}
		my $crashTimeZero_ms = $crashTimeZero -> {"DataValues"};
		my $crashTimeZeroUnit = $crashTimeZero -> {"DataUnit"};
		if($crashTimeZeroUnit ne "ms") {
			S_set_error("Crash Time zero must be stored in ms!! Go to next crash.", 110);
			next;
		}

		#--------------------------------------------------------------
	    # GET SWITCH STATE STORED IN EDR
		#    
		my @allCrashTimeZeros = split('_', $crashTimeZero_ms);
		my $numberOfIncidents = @allCrashTimeZeros;

		S_w2rep("Crash $crash has $numberOfIncidents incidents stored in EDR");
		for (my $recordNbr = 1; $recordNbr <= $numberOfIncidents; $recordNbr++)
		{
			S_teststep("Multi-event Evaluation for Crash $crash, record $recordNbr", 'AUTO_NBR', "Evaluation multi-event crash $crash record $recordNbr");
			S_w2log(1, "Get EDID data for multi-event number from crash $crash (record $recordNbr");
	        my $edidData_MEnumber = $record_handler -> GetDecodedEDID("CrashLabel" => $crash, 
	                                                         "RecordNumber" => $recordNbr,
	                                                         "EDIDnr" => $tcpar_EDID_MEnumber ); 	    
	
			unless(defined $edidData_MEnumber) {
				S_w2rep("No EDID data for multi-event number found for crash $crash, record $recordNbr. EDID will not be evaluated. Go to next record");
				next;
			}
			
			my $meNumber = $edidData_MEnumber -> {'DataValue'};

			S_w2log(1, "Get EDID data for time between initial and current event from crash $crash (record $recordNbr");
	        my $edidData_MEtime = $record_handler -> GetDecodedEDID("CrashLabel" => $crash, 
	                                                         "RecordNumber" => $recordNbr,
	                                                         "EDIDnr" => $tcpar_EDID_MEtime ); 	    
	
			unless(defined $edidData_MEtime) {
				S_w2rep("No EDID data for time between initial and current event found for crash $crash, record $recordNbr. EDID will not be evaluated. Go to next record");
				next;
			}
			
			my $meTime = $edidData_MEtime -> {'DataValue'};
			
			my ($expectedMEnumber, $expectedMEtime);
			if($recordNbr == 1) {
				$expectedMEnumber = 1;
				$expectedMEtime = 'DataNotAvailable';
			}
			elsif($recordNbr == 2) {
				$expectedMEnumber = 2;
				$expectedMEtime = $allCrashTimeZeros[1] - $allCrashTimeZeros[0];				
			}
			else {
				S_set_error("Evaluation currently supports only two incidents! Evaluate manually!");
				return;
			}
	
			#--------------------------------------------------------------
		    # COMPARE EXPECTED AND DETECTED SWITCH STATE
			#    
			S_teststep_expected("Multi-event number: $expectedMEnumber, Time between initial and current event: $expectedMEtime (ms)", "Evaluation multi-event crash $crash record $recordNbr");
			S_teststep_detected("Multi-event number: $meNumber, Time between initial and current event: $meTime (ms)", "Evaluation multi-event crash $crash record $recordNbr");
	
			S_w2log(1, "Compare expected and detected values", 'AUTO_NBR');

			EVAL_evaluate_value ( 'MultiEvent_Number',
								  $meNumber, '==', $expectedMEnumber );			

			if($expectedMEtime eq 'DataNotAvailable'){
				EVAL_evaluate_string ( 'TimeBetweenInitialAndCurrent',
            	    				   $expectedMEtime,
    	    						   $meTime,
        							  );
				
			}
			else {
				EVAL_evaluate_value ( 'TimeBetweenInitialAndCurrent',
									  $meTime, '==', $expectedMEtime, $tcpar_Tolerance_Time, 'absolute' );							
			}
		}
	    # next crash 
	}
	
    return 1;
}

#-------------------------------------------------------------------------------
sub TC_finalization {
#-------------------------------------------------------------------------------
	S_w2rep("Finalization - nothing to be done");

	return 1;
}


#-------------------------------------------------------------------------------------------------------------------


1;