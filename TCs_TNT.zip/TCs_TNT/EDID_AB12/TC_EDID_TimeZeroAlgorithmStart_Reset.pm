#### TEST CASE MODULE
package TC_EDID_TimeZeroAlgorithmStart_Reset;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use GENERIC_DCOM;
use LIFT_can_access;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;
use Data::Dumper;

##################################

our $PURPOSE = "To Validate Time from Time Zero to Algorithm Start and Time from Time Zero to Algorithm Reset reported in EDR";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDID_TimeZeroAlgorithmStart_Reset

=head1 PURPOSE

<To Validate Time from Time Zero to Algorithm Start and Time from Time Zero to Algorithm Reset reported in EDR>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Inject a Crash <Crashcode>

2. Read  EDR

3.Read <Default_EDIDs_CT1>

<Default_EDIDs_CT2>


I<B<Evaluation>>

1. -

2. <CompareValues_CT1>,<CompareValues_CT2>  should have data as per the Crash injected

3.<Default_EDIDs_CT1> should store default data


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Crashcode' => 
	HASH 'Default_EDIDs_CT1' => 
	HASH 'CompareValues_CT1' => 
	SCALAR 'purpose' => 
	SCALAR 'expected_nr_of_records' => 
	SCALAR 'DiagType' => 
	SCALAR 'ResultDB' => 
	HASH 'COMsignalsAfterCrash' => 
	SCALAR 'AlgoStartTime_Tolerance' => 


=head2 PARAMETER EXAMPLES

	purpose		 = 'To Validate EDIDs TimeZeroAlgorithmStart_Reset Recorded in EDR'
	
	
	expected_nr_of_records  = 1
	
	DiagType  = 'ProdDiag' 
	ResultDB = 'EDR'
	COMsignalsAfterCrash = %()
	
	AlgoStartTime_Tolerance= '3'  #ms
	Crashcode='Single_EDR_Front_above_8kph_NoDeployment'
	Default_EDIDs_CT1=%('5' => 'DataNotAvailable','6' => 'DataNotAvailable','18' =>'DataNotAvailable','13' => 'DataNotAvailable','14' => 'DataNotAvailable','15' => 'DataNotAvailable')
	CompareValues_CT1 = %('4'=>'0','12'=>'97.5')

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_expected_nr_of_records;
my $tcpar_DiagType;
my $tcpar_ResultDB;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_AlgoStartTime_Tolerance;
my $tcpar_Crashcode;
my $tcpar_Default_EDIDs_CT1;
my $tcpar_Default_EDIDs_CT2;
my $tcpar_Default_EDIDs_CT3;
my $tcpar_CompareValues_CT1;
my $tcpar_CompareValues_CT2;
my $tcpar_CompareValues_CT3;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_wait_ms ;

################ global parameter declaration ###################
#add any global variables here
my ($record_handler,$recordIsThere, $crashSettings, $edrNumberOfEventsToBeStored,$tcpar_Default_EDIDs,$tcpar_CompareValues_CT);

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_expected_nr_of_records =  S_read_mandatory_testcase_parameter( 'expected_nr_of_records' );
	$tcpar_DiagType =  S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_ResultDB =  S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_AlgoStartTime_Tolerance =  S_read_mandatory_testcase_parameter( 'AlgoStartTime_Tolerance' );
	$tcpar_Crashcode =  S_read_mandatory_testcase_parameter( 'Crashcode' );
	$tcpar_COMsignalsAfterCrash =  S_read_optional_testcase_parameter( 'COMsignalsAfterCrash','byref');
	$tcpar_wait_ms =  S_read_mandatory_testcase_parameter( 'wait_ms' );
	$tcpar_Default_EDIDs_CT1 =  S_read_mandatory_testcase_parameter( 'Default_EDIDs_CT1','byref' );
	$tcpar_Default_EDIDs_CT2 =  S_read_optional_testcase_parameter( 'Default_EDIDs_CT2','byref' );
	$tcpar_Default_EDIDs_CT3 =  S_read_optional_testcase_parameter( 'Default_EDIDs_CT3','byref' );
	$tcpar_CompareValues_CT1 =  S_read_mandatory_testcase_parameter( 'CompareValues_CT1','byref' );
	$tcpar_CompareValues_CT2 =  S_read_optional_testcase_parameter( 'CompareValues_CT2','byref' );
	$tcpar_CompareValues_CT3 =  S_read_optional_testcase_parameter( 'CompareValues_CT3','byref' );
	
	$record_handler = EDR_init_RecordHandler();
	$recordIsThere = $record_handler -> IsRecordAvailable("CrashLabel" => $tcpar_Crashcode,
															"RecordNumber"      => 1 );

	if(not defined $recordIsThere){
		S_w2rep("crash will be injected and EDR data will be read in Simulation and Measurement");
		$recordIsThere=0;
	}

	return 1;
}

sub TC_initialization {

	S_teststep("Test setup preparation", 'AUTO_NBR');

	#--------------------------------------------------------------
    # INITIALIZE RECORD HANDLER
    #    
	S_w2rep("Initialize Record Handler");
	$record_handler = EDR_init_RecordHandler() || return;

	#--------------------------------------------------------------
    # PREPARE CRASH AND INITIALIZE EQUIPMENT
    #
	if($recordIsThere == 0){
		S_w2rep("Get crash settings for crash $tcpar_Crashcode");
		my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode};
        $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
        unless(defined $crashSettings) {
            S_set_error("Crash $tcpar_Crashcode not available in result DB $tcpar_ResultDB. Test case aborted.");
            return;
        }

		my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
		my $resultDB_Path = $resultDBDetails->{'PATH'};
		S_w2log(1, "Crashcode: $tcpar_Crashcode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");

		S_w2log(1, "Power on ECU");
		LC_ECU_On();
		S_wait_ms('TIMER_ECU_READY');

        S_w2log(1, "Initialize CD and start CAN trace");
        GDCOM_init () ; # To fetch info for CD from mapping_diag
        CA_trace_start ( );

		S_w2log(1, "Set environments for crash as per result DB");
        CSI_PrepareEnvironment($crashSettings, 'init_complete');
		S_wait_ms(2000);

		S_w2log(1, "Clear crash recorder");
		PD_ClearCrashRecorder_NOERROR();
		S_wait_ms(2000);

		S_w2log(1, "Clear fault memory");
		PD_ClearFaultMemory();
		S_wait_ms(2000);
		
		S_w2log(1, "Read and evaluate fault memory before stimulation");
		my $faultsBeforeStimulation = PD_ReadFaultMemory();
        my $faultsVerdict = PD_evaluate_faults( $faultsBeforeStimulation, []);
        return 0 unless ($faultsVerdict eq 'VERDICT_PASS');
   
		# Prepare crash
        LC_ECU_Off();
        S_wait_ms('TIMER_ECU_READY');

        #Prepare crash
        CSI_LoadCrashSensorData2Simulator($crashSettings);

        LC_ECU_On();
        S_wait_ms('TIMER_ECU_READY');
	}
	return 1;
}

sub TC_stimulation_and_measurement {

	$edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();
	unless(defined $edrNumberOfEventsToBeStored){
		S_set_error("Not available in SYC - add or overwrite with Custlibrary Function");
		return;
	}
	
	#--------------------------------------------------------------
	# CRASH INJECTION
	#
	if($recordIsThere == 0){
		
		CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    	S_wait_ms(1000);
		S_teststep("Inject '$tcpar_Crashcode' ", 'AUTO_NBR');
		CSI_TriggerCrash();	
		if (defined $tcpar_COMsignalsAfterCrash){
			foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
			{				
				my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
				S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
				COM_setSignalState($signal,$dataOnCOM);	
			}

		}
		S_teststep("Wait '$tcpar_wait_ms'", 'AUTO_NBR');
		S_wait_ms($tcpar_wait_ms);

		S_teststep("Read EDR", 'AUTO_NBR', 'read_edr');			#measurement 1
		
		my $dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_".$tcpar_Crashcode;
		 
		S_w2rep("edrNumberOfEventsToBeStored=$edrNumberOfEventsToBeStored");
		PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');
		EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
									"CrashLabel" => $tcpar_Crashcode,
									"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
									"StoragePath" => $dataStoragePath,
									);
	}
	else {
		S_teststep("Read EDR", 'AUTO_NBR', 'read_edr');			#measurement 1
		S_teststep("Crash '$tcpar_Crashcode' is injected in 'TC_EDR_CrashInjection'", 'AUTO_NBR');
	}
	
	S_teststep("Read the algo start and reset timings of activated algo stored in EDR", 'AUTO_NBR', 'CompareValues');			#measurement 2

	S_teststep("Read the algo start and reset timings of Non activated algo stored in EDR", 'AUTO_NBR','read_default_edids');   #measurement 3

	return 1;
}

sub TC_evaluation {

	my $verdict_eval='VERDICT_PASS';
	my $FinalVerdict='VERDICT_PASS';;
	#--------------------------------------------------------------
    # NUMBER OF EXPECTED RECORDS
    #
	S_w2rep("");
	S_w2rep("--------------------------------------------------------", 'purple');
	S_w2rep("NUMBER OF EXPECTED RECORDS", 'purple');
	my $detectedNbrOfStoredRecords = 0;
	for(my $recordNumber = 1; $recordNumber <= $edrNumberOfEventsToBeStored; $recordNumber++)
	{
		my $recordAvailable = $record_handler -> IsRecordAvailable("CrashLabel" => $tcpar_Crashcode, "RecordNumber"=> $recordNumber);
		$detectedNbrOfStoredRecords++ if ($recordAvailable);
	}
	S_teststep_expected("Number of records expected is '$tcpar_expected_nr_of_records'", 'read_edr');	#evaluation 1
	my $verdict=EVAL_evaluate_value("NumberOfRecords", $detectedNbrOfStoredRecords, '==',$tcpar_expected_nr_of_records);
	S_teststep_detected("Number of stored records is $detectedNbrOfStoredRecords", 'read_edr');
	unless ($verdict eq "VERDICT_PASS"){
		S_w2rep(" Expected number of records does not match with detected records, hence no evaluation will be done further.");
		return 1 unless $main::opt_offline;
		S_w2rep("Continue due to offline mode");
	}
	#--------------------------------------------------------------
    # EDID Validation
    #
	S_w2rep("",'teal');
	S_w2rep("*****************************************", 'teal');	
	S_w2rep("Algo Start and Reset time of expected algo", 'teal');
	for(my $recordNumber = 1; $recordNumber <= $tcpar_expected_nr_of_records; $recordNumber++)
	{
		$tcpar_CompareValues_CT = $tcpar_CompareValues_CT1 if ($recordNumber == 1);
		$tcpar_CompareValues_CT = $tcpar_CompareValues_CT2 if ($recordNumber == 2);
		$tcpar_CompareValues_CT = $tcpar_CompareValues_CT3 if ($recordNumber == 3);
		foreach my $rawEDID (keys %{$tcpar_CompareValues_CT})
		{
					
			my $expectedValue = $tcpar_CompareValues_CT -> {$rawEDID};
			my $dataElement = $record_handler -> GetDataElementEDID( "EDIDnr" => $rawEDID,
																	 "RecordNumber" => $recordNumber,
																	 "CrashLabel" => $tcpar_Crashcode);

			S_teststep( "EDID $rawEDID ($dataElement) validation record $recordNumber",'AUTO_NBR', "CompareValues_EDID_$rawEDID\_Record_$recordNumber");
					
			my $edidData = $record_handler -> GetDecodedEDID("CrashLabel" => $tcpar_Crashcode, "RecordNumber" => $recordNumber,"EDIDnr" => $rawEDID );
			my $Detectedvalue = $edidData -> {"DataValue"};
			my $unit = $edidData -> {"ValueUnit"};			
			 
			unless(defined $Detectedvalue) {
				S_set_error("No data could be obtained for EDID $rawEDID ");
				next;
			}
						
			S_w2log(1, "Compare expected and detected values");
							
			if($Detectedvalue eq 'DataNotAvailable' or $Detectedvalue eq 'Algorithm not activated'){
				S_set_verdict('VERDICT_FAIL');
				S_w2log(1, "Expected algo data for $dataElement but algo is not active!");
				$verdict_eval = 'VERDICT_FAIL';
				next;
			}
			else{	
				$verdict_eval = EVAL_evaluate_value ( "EDID_$rawEDID\_Evaluation", $Detectedvalue,'==', $expectedValue,$tcpar_AlgoStartTime_Tolerance,'absolute');
			}
			$FinalVerdict = 'VERDICT_FAIL' if $verdict_eval eq 'VERDICT_FAIL';

			S_teststep_expected("EDID $rawEDID (Record $recordNumber): $expectedValue", "CompareValues_EDID_$rawEDID\_Record_$recordNumber");#evaluation 2			
			S_teststep_detected("EDID $rawEDID (Record $recordNumber): $Detectedvalue", "CompareValues_EDID_$rawEDID\_Record_$recordNumber");
		}
	}

	
    S_w2rep("",'teal');
    S_w2rep("*****************************************", 'teal');   
    S_w2rep("Default Algo Start and Reset time for non active algo", 'teal');

	for(my $recordNumber = 1; $recordNumber <= $tcpar_expected_nr_of_records; $recordNumber++)
	{
		$tcpar_Default_EDIDs = $tcpar_Default_EDIDs_CT1 if ($recordNumber == 1);
		$tcpar_Default_EDIDs = $tcpar_Default_EDIDs_CT2 if ($recordNumber == 2);
		$tcpar_Default_EDIDs = $tcpar_Default_EDIDs_CT3 if ($recordNumber == 3);
		foreach my $EDID (keys %{$tcpar_Default_EDIDs})
		{
				
			my $expectedValue = $tcpar_Default_EDIDs -> {$EDID};
			my $dataElement = $record_handler -> GetDataElementEDID( "EDIDnr" => $EDID,
																	 "RecordNumber" => $recordNumber,
																	 "CrashLabel" => $tcpar_Crashcode);

			S_teststep( "EDID $EDID ($dataElement) validation in record $recordNumber",'AUTO_NBR', "DefaultValues_EDID_$EDID\_Record_$recordNumber");
				
			my $edidData = $record_handler -> GetDecodedEDID("CrashLabel" => $tcpar_Crashcode, "RecordNumber" => $recordNumber,"EDIDnr" => $EDID );
			my $Detectedvalue = $edidData -> {"DataValue"};
			my $unit = $edidData -> {"ValueUnit"};	
		 
			unless(defined $Detectedvalue) {
				S_set_error("No data could be obtained for EDID $EDID ");
				next;
			}

			S_teststep_expected("$expectedValue", "DefaultValues_EDID_$EDID\_Record_$recordNumber");#evaluation 3			
			S_teststep_detected("$Detectedvalue", "DefaultValues_EDID_$EDID\_Record_$recordNumber");
            EVAL_evaluate_string ( "EDID_$EDID\_Evaluation", $expectedValue, $Detectedvalue );  
		}		
	}

	return 1;
}

sub TC_finalization {

	if($recordIsThere == 0){
		S_w2rep("Start test case finalization...");

		foreach my $recordNumber (1..$edrNumberOfEventsToBeStored)
		{
			$record_handler -> DeleteRecord("CrashLabel" => $tcpar_Crashcode, "RecordNumber" => $recordNumber);
		}

		# Erase EDR
		PD_ClearCrashRecorder_NOERROR();
		S_wait_ms(2000);

		# Erase Fault memory
		PD_ClearFaultMemory();
		S_wait_ms(2000);

		# Read fault memory after clearing and erasing EDR
		PD_ReadFaultMemory();   

		LC_ECU_Off();
		S_wait_ms('TIMER_ECU_OFF');
	}
	else{
		S_w2rep("Testcase finalization is done");
	}

	return 1;
}


1;
