#### TEST CASE MODULE
package TC_EDID_Switch_SingleEvent;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS_EDID_GenericEDIDList>
#TS version in DOORS: <0.24>
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_PD;
use GENERIC_DCOM;
use LIFT_can_access;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use FuncLib_SYC_INTERFACE;
use FuncLib_EDR_Framework;

#include further modules here

##################################

our $PURPOSE = "<This TestScript Validates SwitchRelated EDIDs with Different Switchstates for Single and Parallel crashes>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDID_Switch

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Set <Switch> to <SwitchState>

2. Wait for <Wait_time> till the switch state is changed.

3. Inject a <Crashcode>

4. Read <EDID> value  corresponding to <Switch> state


I<B<Evaluation>>

1. -

2. -

3. -

4. Value <SwitchStateValue> should be reported in record1 if it is single event or parallel event


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	
	SCALAR 'SwitchStateValue' => 
	SCALAR 'Crashcode' => 
	SCALAR 'purpose' => 
	SCALAR 'EDID' => 
	SCALAR 'Switch' => 
	SCALAR 'Wait_time' => 
	SCALAR 'SwitchState' => 
	SCALAR 'NHTSA_Table' => 
	SCALAR 'DiagType' => 


=head2 PARAMETER EXAMPLES

   purpose = 'To validate Switch state related to generic EDID's for single and Parallel crashes with Different Switch states'
	
   Switch = 'BeltLockFrontDriver'
   SwitchState = '<Test Heading>'
   EDID = '<Fetch {EDID}>'
   NHTSA_Table = '<Fetch {From}>'
   Wait_time = '6000'#msec
   DiagType  = 'ProdDiag' 
   Default_DeviceType = 'positionA'
   SwitchStateValue='0x01'
   Crashcode = 'Single_EDR_Front_above_8kph_NoDeployment'


=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_EDID;
my $tcpar_DiagType;
my $tcpar_Switch;
my $tcpar_ResultDB;
my $tcpar_Crashcode;
my $tcpar_WaitTime_ms;
my $tcpar_SwitchState;
my $tcpar_ExpectedSwitchState;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_SwitchType;
my $tcpar_read_NHTSAEDR;
my $tcpar_read_CHINAEDR;

################ global parameter declaration ###################
my $record_handler;
my $crashSettings;
my $crashLabel;
my $edrNumberOfEventsToBeStored;
my $ChinaEDR_diagType;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose              = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_EDID                 = S_read_mandatory_testcase_parameter('EDID');
	$tcpar_ResultDB             = S_read_mandatory_testcase_parameter('ResultDB');
	$tcpar_DiagType             = S_read_mandatory_testcase_parameter('DiagType');
	$tcpar_Switch               = S_read_mandatory_testcase_parameter('Switch');
	$tcpar_Crashcode            = S_read_mandatory_testcase_parameter('Crashcode');
	$tcpar_WaitTime_ms          = S_read_mandatory_testcase_parameter('Wait_time_msec');
	$tcpar_SwitchState          = S_read_mandatory_testcase_parameter('SwitchState');
	$tcpar_ExpectedSwitchState  = S_read_mandatory_testcase_parameter('SwitchStateValue');
	$tcpar_COMsignalsAfterCrash = S_read_optional_testcase_parameter( 'COMsignalsAfterCrash', 'byref' );
	$tcpar_SwitchType           = S_read_optional_testcase_parameter('SwitchType');
	$tcpar_read_NHTSAEDR        = S_read_optional_testcase_parameter('read_NHTSAEDR');
	$tcpar_read_CHINAEDR        = S_read_optional_testcase_parameter('read_CHINAEDR');

	if ( not defined $tcpar_SwitchType ) {
		$tcpar_SwitchType = 'res\hall';
	}

	$crashLabel = $tcpar_Crashcode . "_" . $tcpar_Switch . "_" . $tcpar_SwitchState;

	#checking the switch states fetched form TS
	if ( $tcpar_SwitchState !~ (/PositionA|PositionB|Short2Gnd|OpenLine|Undefined|CrossCouple|Configuration|Short2Bat/) ) {
		S_set_error(" SwitchState is not valid. It should be either PositionA/PositionB/Short2Gnd/OpenLine/Undefined/CrossCouple/Configuration/Short2Bat ");
		return 0;
	}

	if ( not defined $tcpar_read_CHINAEDR ) {
		$tcpar_read_NHTSAEDR = 'yes';
		$tcpar_read_CHINAEDR = 'no';
	}
	else {
		$tcpar_read_NHTSAEDR = 'no';
		my $storageOrder = EDR_getStorageOrder();
		return unless ( defined $storageOrder );

		if ( $storageOrder eq 'PhysicalOrder' ) {
			$ChinaEDR_diagType = 'ProdDiag';    #In platform NHTSA and China EDR is read via proddiag
		}
		else {
			$ChinaEDR_diagType = 'CHINA_Payload';
		}
	}

	return 1;
}

sub TC_initialization {

	S_w2rep("StandardPrepNoFault");
	S_w2rep("Initialize Record Handler");
	$record_handler = EDR_init_RecordHandler();

	S_w2log( 1, "Power on ECU" );
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	S_w2log( 1, "Initialize CD and start CAN trace" );
	GDCOM_init();    # To fetch info for CD from mapping_diag
	CA_trace_start();

	S_w2log( 1, "Clear crash recorder" );
	PD_ClearCrashRecorder();
	S_wait_ms(2000);

	S_w2log( 1, "Clear fault memory" );
	PD_ClearFaultMemory();
	S_wait_ms(2000);

	S_w2log( 1, "Read and evaluate fault memory before stimulation" );
	my $faultsBeforeStimulation = PD_ReadFaultMemory();
	my $faultsVerdict = PD_evaluate_faults( $faultsBeforeStimulation, [] );
	return 0 unless ( $faultsVerdict eq 'VERDICT_PASS' );

	PD_ECUreset();
	S_wait_ms('TIMER_ECU_READY');

	#checking whether switch is configured or not
	my ( $result, $configured ) = SYC_SWITCH_get_Configured($tcpar_Switch);
	S_w2rep("Switch configuration state: $configured");
	if ( $configured !~ /yes/ ) {
		S_set_warning(" Switch $tcpar_Switch is not configured in the software , Check the configuration through PS diag");
		my ( $real, $monitored_ID, $prog ) = PD_get_device_config($tcpar_Switch);
		S_w2rep("Real bit is $real, monitored bit is $monitored_ID,programmed bit is $prog");
		if ( $prog == 0 ) {
			S_set_error( " Switch $tcpar_Switch is not configured either in SYC or in PS diag " . "Dont Perfom this testcase as this is not applicable for the varient" );
			return 0;
		}
	}

	#checking whether switch is Mechanical or not

	if ( ( $tcpar_SwitchType =~ /mech/ ) and ( $tcpar_SwitchState =~ m/Short2Gnd|OpenLine|Undefined|CrossCouple/ ) ) {
		S_set_error(" Switch $tcpar_Switch is of type $tcpar_SwitchType and hence faults cannot be created for this switch .Dont Perfom this testcase");
		return 0;
	}

	#--------------------------------------------------------------
	# CRASH PREPARATION
	S_w2log( 1, "Prepare crash" );

	# PREPARE CRASH AND INITIALIZE EQUIPMENT
	S_w2rep("Get crash settings for crash $tcpar_Crashcode");
	my $crashDetails_href = { "RESULTDB" => $tcpar_ResultDB, 'CRASHNAME' => $tcpar_Crashcode };
	$crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
	unless ( defined $crashSettings ) {
		S_set_error("Crash $tcpar_Crashcode not available in result DB $tcpar_ResultDB. Test case aborted.");
		return;
	}

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log( 1, "Crashcode: $tcpar_Crashcode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)" );
	S_w2log( 1, "Set environments for crash as per result DB" );
	CSI_PrepareEnvironment( $crashSettings, 'init_complete' );

	#--------------------------------------------------------------
	# CRASH PREPARATION
	#
	S_teststep( "Prepare crash", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	# Prepare crash
	CSI_LoadCrashSensorData2Simulator($crashSettings);

	# Power ON the ECU
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');
	PD_ECUlogin();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( " Set Switch '$tcpar_Switch' to '$tcpar_SwitchState' ", 'AUTO_NBR' );

	#Append "Value" to $tcpar_SwitchState for fetching info from SYC
	if ( $tcpar_SwitchState =~ m/Short2Gnd|OpenLine|Undefined/ ) {
		$tcpar_SwitchState = $tcpar_SwitchState . "Value";
		S_w2rep("SwitchState = $tcpar_SwitchState");
	}

	#Syc Interface for PositionA,PositionB,Shorttognd,OpenLine,Undefined
	if ( ( $tcpar_SwitchState =~ m/PositionA|PositionB|Short2Gnd|OpenLine|Undefined/ ) and ( $tcpar_SwitchType !~ /mech/ ) ) {
		my ( $result, $state_value, $state_unit ) = SYC_SWITCH_get_state( $tcpar_Switch, $tcpar_SwitchState );
		LC_SetResistance( $tcpar_Switch, $state_value ) if ( $state_unit eq 'R' );
		LC_SetCurrent( $tcpar_Switch, $state_value ) if ( $state_unit eq 'I' );
	}
	elsif ( ( $tcpar_SwitchState =~ /Short2Bat/ ) and ( $tcpar_SwitchType !~ /mech/ ) ) {
		LC_ShortLines( [ $tcpar_Switch . '+', 'B+' ] );
	}
	elsif ( $tcpar_SwitchState =~ /CrossCouple/ ) {
		my ( $result, $configured_switches_aref ) = SYC_SWITCH_get_all_configured();
		my $crosscouple;
		foreach my $beltLock (@$configured_switches_aref) {
			next if ( $tcpar_Switch eq $beltLock );
			my ( $result_type, $switch_type ) = SYC_SWITCH_get_type($beltLock);
			S_w2rep(" switch type=$switch_type, switch used for crosscouple=$beltLock");
			if ( $switch_type =~ m/res|hal/i ) {
				LC_ShortLines( [ $tcpar_Switch . '+', $beltLock . '+' ] );
				$crosscouple = 'yes';
				last;
			}
			else {
				next;
			}
		}
		S_set_error(" Switch used for crosscouple is not available, check if testcase is really applicable for switch $tcpar_Switch") if ( $crosscouple ne "yes" );
		PD_ECUreset();
		S_wait_ms('TIMER_ECU_READY');
	}
	elsif ( $tcpar_SwitchState =~ /Configuration/ ) {
		PD_Device_configuration( 'clear', [$tcpar_Switch] );
		S_wait_ms(2000);
		PD_ECUreset();
		S_wait_ms('TIMER_ECU_READY');
	}
	elsif ( ( defined $tcpar_SwitchType ) and ( $tcpar_SwitchType =~ /mech/ ) ) {
		if ( $tcpar_SwitchState eq 'PositionA' ) {
			LC_ConnectLine($tcpar_Switch);
		}
		elsif ( $tcpar_SwitchState eq 'PositionB' ) {
			LC_DisconnectLine($tcpar_Switch);
		}
		elsif ( $tcpar_SwitchState =~ /Short2Bat/ ) {
			LC_DisconnectLine($tcpar_Switch);
			LC_ShortLines( [ $tcpar_Switch . '+', 'B+' ] );
		}
	}
	else {
		S_set_error( "Switch state $tcpar_SwitchState not supported for this switch\n" . "Check Project constant under TSG4 Defaults" );
		return;
	}

	S_teststep( " Wait for $tcpar_WaitTime_ms millisec till the switch state is changed", 'AUTO_NBR' );
	S_wait_ms($tcpar_WaitTime_ms);

	S_w2rep("Read fault memory before crash");
	PD_ReadFaultMemory();
	
	CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    S_wait_ms(1000);

	S_teststep( " Inject the crash '$tcpar_Crashcode' ", 'AUTO_NBR' );
	CSI_TriggerCrash();

	# wait time after crash
	S_wait_ms(15000);
	if ( defined $tcpar_COMsignalsAfterCrash ) {
		foreach my $signal ( keys %{$tcpar_COMsignalsAfterCrash} ) {
			my $dataOnCOM = $tcpar_COMsignalsAfterCrash->{$signal};
			S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
			COM_setSignalState( $signal, $dataOnCOM );
		}
	}

	#Read fault memory after injecting the crash
	S_w2rep("Read fault memory after crash");
	S_wait_ms(2000);
	PD_ReadFaultMemory();

	S_teststep( "Read EDID '$tcpar_EDID' value for Switch '$tcpar_Switch' in Crash Recorder", 'AUTO_NBR', 'Read CrashRecorder1' );
	my $dataStoragePath = "$main::REPORT_PATH/" . S_get_TC_number() . "_" . $tcpar_Switch . "_" . $tcpar_SwitchState;

	# Only one record will be read and evaluated in NHTSA, as script is for single and parallel events
	if ( lc($tcpar_read_NHTSAEDR) eq 'yes' ) {
		EDR_ReadAndStoreAllRecords(
			"DiagType"     => $tcpar_DiagType,
			"CrashLabel"   => $crashLabel,
			"NbrOfRecords" => 1,
			"StoragePath"  => $dataStoragePath,
			"read_EDRType" => 'NHTSA'
		);
	}
	if ( lc($tcpar_read_CHINAEDR) eq 'yes' ) {
		$edrNumberOfEventsToBeStored = 3;
		EDR_ReadAndStoreAllRecords(
			"DiagType"     => $ChinaEDR_diagType,
			"CrashLabel"   => $crashLabel,
			"NbrOfRecords" => $edrNumberOfEventsToBeStored,
			"StoragePath"  => $dataStoragePath,
			"read_EDRType" => 'CHINA'
		);
	}

	return 1;
}

sub TC_evaluation {

	my $dataElement = $record_handler->GetDataElementEDID(
		"EDIDnr"       => $tcpar_EDID,
		"RecordNumber" => 1,
		"CrashLabel"   => $crashLabel
	);

	S_teststep( "Evaluate EDID $tcpar_EDID ($dataElement) in record 1", 'AUTO_NBR', "EDID_$tcpar_EDID\_Record_1" );

	S_w2rep("Get EDID data (EDID $tcpar_EDID)");
	my $detectedSwitchState = $record_handler->GetRawEDID(
		"EDIDnr"       => $tcpar_EDID,
		"RecordNumber" => 1,
		"CrashLabel"   => $crashLabel,
		"FormatOption" => "HEX"
	);

	unless ( defined $detectedSwitchState ) {
		S_set_error(" No EDID data obtained for the Record - Check whether EDID $tcpar_EDID is reported or Switch $tcpar_Switch is configured or not");
		return;
	}

	if ( ref($detectedSwitchState) eq 'ARRAY' ) {
		my $detectedSwitchStateString;
		foreach my $element ( @{$detectedSwitchState} ) {
			$detectedSwitchStateString .= $element;
		}
		$detectedSwitchState = "0b" . $detectedSwitchStateString;
	}
	else {
		$detectedSwitchState = "0x" . $detectedSwitchState;
	}

	# COMPARE EXPECTED AND DETECTED SWITCH STATE
	S_teststep_expected( "$tcpar_ExpectedSwitchState", "EDID_$tcpar_EDID\_Record_1" );
	S_teststep_detected( "$detectedSwitchState", "EDID_$tcpar_EDID\_Record_1" );

	S_w2rep("Compare expected and detected values");
	my $verdict = EVAL_evaluate_value( "EDID_$tcpar_EDID\_Evaluation", $detectedSwitchState, '==', $tcpar_ExpectedSwitchState );

	return 1;
}

sub TC_finalization {

	S_w2rep("Start test case finalization");

	#Delete Record Handler
	$record_handler->DeleteRecord(
		"CrashLabel"   => $crashLabel,
		"RecordNumber" => 1
	);

	#--------------------------------------------------------------------------------------------------------
	# Remove the Condition which is created in the test case
	S_w2rep(" Reset Device state for Switch $tcpar_Switch to Default State ");
	if ( $tcpar_SwitchState =~ m/PositionA|PositionB|Short2Gnd|OpenLine|Undefined/ ) {
		my ( $resultDefaultCondition, $default_condition ) = SYC_SWITCH_get_DefaultCondition($tcpar_Switch);
		my ( $result, $state_value, $state_unit ) = SYC_SWITCH_get_state( $tcpar_Switch, $default_condition );
		if ( $tcpar_SwitchType =~ /mech/ ) {
			if ( $default_condition eq 'PositionA' ) {
				LC_ConnectLine($tcpar_Switch);
			}
			elsif ( $default_condition eq 'PositionB' ) {
				LC_DisconnectLine($tcpar_Switch);
			}
		}
		else {
			LC_SetResistance( $tcpar_Switch, $state_value ) if ( $state_unit eq 'R' );
			LC_SetCurrent( $tcpar_Switch, $state_value ) if ( $state_unit eq 'I' );
		}
	}
	elsif ( $tcpar_SwitchState =~ /Configuration/ ) {
		PD_Device_configuration( 'set', [$tcpar_Switch] );
		S_wait_ms(2000);
	}
	elsif ( $tcpar_SwitchState =~ m/Short2Bat|CrossCouple/ ) {
		LC_UndoShortLines();
	}
	else {
		S_set_error(" Switch $tcpar_Switch is not set to its Default state ");
		return;
	}

	if ( $tcpar_SwitchState =~ m/CrossCouple|Configuration/ ) {
		PD_ECUreset();
		S_wait_ms('TIMER_ECU_READY');
	}
	S_wait_ms('8000');

	#--------------------------------------------------------------------------------------------------------
	#Clearing crash recorder
	PD_ClearCrashRecorder();
	S_wait_ms(6000);

	#Erase Fault memory
	PD_ClearFaultMemory();
	S_wait_ms(2000);

	# Reset ECU
	PD_ECUreset();
	S_wait_ms('TIMER_ECU_READY');

	#Read fault memory after clearing and erasing EDR
	PD_ReadFaultMemory();

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}

1;
