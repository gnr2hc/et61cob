#### TEST CASE MODULE
package TC_EDID_PD_Variable_Validation;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general;
use LIFT_evaluation;
use FuncLib_EDR_Framework;
use File::Basename;
use Data::Dumper;
use EDR_Framework::FuncLib_EDR_Offline_xmlLogging;

##################################
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDID_PD_Variable_Validation  $Revision: 1.10 $

requires previous crash injection
   with storage of fire times and EDR records in
   Crash / Record handler
   e.g. use TC_EDR_CrashInjection.pm (ONLINE)
   or TC_EDR_CrashDataRetrieval.pm (OFFLINE)

TC does not require any equipment - only previously
   obtained data will be used

=head1 PURPOSE

to validate PD variable values which are stored in EDR

=head1 TESTCASE DESCRIPTION 

    [initialisation]
    initialize record handler

    [stimulation & measurement]
	not needed

    [evaluation]
    1. get list of stored records
    2. evaluate PD variable stored in EDID for each crash

    [finalisation]
    not needed

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

	EDID --> EDID number of data element to be validated
	PD_VariableLabel --> Label of variable with which it was stored in crash hndler
  	

=head2 PARAMETER EXAMPLES

    [TC_EDID_PD_Variable_Validation.PowerOnCounter]
	EDID = 51
	PD_VariableLabel = 'PowerOnCounter_Crash'

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_EDID;
my $tcpar_PD_VariableLabel;
my $tcpar_EvalTolerance_abs;
my $tcpar_purpose;
my $tcpar_ConversionFactor;
my $tcpar_ConversionDividend;
my $tcpar_CompareOperator;
################ global parameter declaration ###################
#add any global variables here
my(
    $record_handler,
    $crash_handler,
);

our $PURPOSE;
our $TC_name = "TC_EDID_PD_Variable_Validation";

#-------------------------------------------------------------------------------
sub TC_set_parameters {
#-------------------------------------------------------------------------------
    $tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_EDID = S_read_mandatory_testcase_parameter('EDID');
    $tcpar_PD_VariableLabel = S_read_mandatory_testcase_parameter('PD_VariableLabel');
    $tcpar_EvalTolerance_abs = S_read_optional_testcase_parameter('EvalTolerance_abs');
    $tcpar_ConversionFactor = S_read_optional_testcase_parameter('ConversionFactor');
    $tcpar_ConversionDividend = S_read_optional_testcase_parameter('ConversionDividend');
    $tcpar_CompareOperator = S_read_optional_testcase_parameter('CompareOperator');
    $tcpar_CompareOperator = '==' if(not defined $tcpar_CompareOperator);
	S_add2eval_collection ( 'EDID' , $tcpar_EDID);
	my $allAttributes = EDR_fetchEDIDallAttributes_by_ID($tcpar_EDID);
	S_add2eval_collection('EDID From', $allAttributes -> {'From'}) if (defined $allAttributes -> {'From'});

	return 1;
}

#-------------------------------------------------------------------------------
sub TC_initialization {
#-------------------------------------------------------------------------------
	#--------------------------------------------------------------
    # INITIALIZE RECORD AND CRASH HANDLER
    #    
	$record_handler = EDR_init_RecordHandler() || return;
	$crash_handler  = EDR_init_CrashHandler() || return;

    return 1;
}

#-------------------------------------------------------------------------------
sub TC_stimulation_and_measurement {
#-------------------------------------------------------------------------------
	S_w2rep("No stimulation needed.");

    return 1;
}

#-------------------------------------------------------------------------------
sub TC_evaluation {
#-------------------------------------------------------------------------------
	my $fireTimeValidationResult_href;
	my $storedCrashLabels_aref = $record_handler -> GetListOfStoredRecords();
	
	foreach my $crash (@{$storedCrashLabels_aref})
	{
		my $compareOperator = '==';

		my $crashCode_MDS = $crash_handler -> GetSourceDataValues ( "SourceLabel" => "CrashCode_MDS",															        "CrashLabel"  => $crash );
		$crashCode_MDS = $crashCode_MDS -> {"DataValues"};

		my $path_MDB = $crash_handler -> GetSourceDataValues ( "SourceLabel" => "MDB_Path",															        "CrashLabel"  => $crash );
		$path_MDB = $path_MDB -> {"DataValues"};
		
		S_w2rep("-------------------------------------------------------------");
		S_w2rep("Squib Evaluation for Crash $crash");
		S_w2log(1, "Crash code: $crashCode_MDS");
		S_w2log(1, "Result DB path: $path_MDB");
		S_w2rep("-------------------------------------------------------------");
		#--------------------------------------------------------------
	    # GET CRASH TIME ZERO
		#    
		my $crashTimeZero = $crash_handler -> GetSourceDataValues ( "SourceLabel" => "CrashTimeZero",
															        "CrashLabel"  => $crash );
		unless(defined $crashTimeZero) {
			S_set_error("No crash time zero stored for crash $crash. No evaluation of fire times possible. Try next crash.", 110);
			next;
		}
		my $crashTimeZero_ms = $crashTimeZero -> {"DataValues"};
		my $crashTimeZeroUnit = $crashTimeZero -> {"DataUnit"};
		if($crashTimeZeroUnit ne "ms") {
			S_set_error("Crash Time zero must be stored in ms!! Go to next crash.", 110);
			next;
		}

		my @crashTimeZeros_array = split(/_/, $crashTimeZero_ms);
		my $numberOfRecords = @crashTimeZeros_array;

		foreach my $record (1..$numberOfRecords)
		{
            S_teststep("Validation of PD variable  $tcpar_PD_VariableLabel, crash $crash, record $record", 'AUTO_NBR', "PD_record_$record\_Crash$crash");
            S_teststep_2nd_level("Get data for EDID $tcpar_EDID in record $record", 'AUTO_NBR');
			my $EDID_data = $record_handler -> GetDecodedEDID("CrashLabel" => $crash, "RecordNumber" => $record,"EDIDnr" => $tcpar_EDID );
			unless(defined $EDID_data){
				S_set_error("No EDR data for PD variable '$tcpar_PD_VariableLabel' (EDID $tcpar_EDID) found (crash $crash).");
				return;
			}
			my $pdVariableEDID = $EDID_data -> { DataValue };
			my $pdVariableEDID_unit = $EDID_data -> { "ValueUnit"};

			my $pdVariableDataElement = $record_handler -> GetDataElementEDID("CrashLabel" => $crash,
																			"RecordNumber" => $record,
																			"EDIDnr" => $tcpar_EDID);


            S_teststep_2nd_level("Get PD variable value", 'AUTO_NBR');
			my $pdVariableSource = $crash_handler -> GetSourceDataValues ( "SourceLabel" => $tcpar_PD_VariableLabel,
																        "CrashLabel"  => $crash );

			my $pdVariableData = $pdVariableSource -> {"DataValues"};
			if($tcpar_ConversionFactor){
                S_teststep_2nd_level("Convert PD variable value by multiplying with $tcpar_ConversionFactor", 'AUTO_NBR');
			    $pdVariableData = $pdVariableData * $tcpar_ConversionFactor;
			}
			if($tcpar_ConversionDividend){
                S_teststep_2nd_level("Convert PD variable value by dividing by $tcpar_ConversionDividend", 'AUTO_NBR');
			    $pdVariableData = $pdVariableData / $tcpar_ConversionDividend;				
			}
			my $pdVariableUnit = $pdVariableSource -> {"DataUnit"};
			if($pdVariableUnit eq 'sec') {
			    my $thisCrashT0 = $crashTimeZeros_array[$record - 1];
				S_teststep("Subtract crash time zero of incident ($thisCrashT0 ms) to measured value ($pdVariableData sec) at Quate injection start.", 'AUTO_NBR');
				$pdVariableData = $pdVariableData - $crashTimeZeros_array[$record - 1] * 0.001;
			}

			S_teststep_expected("$pdVariableData ($pdVariableUnit)", "PD_record_$record\_Crash$crash"); #evaluation 1
			S_teststep_detected("$pdVariableEDID ($pdVariableEDID_unit)", "PD_record_$record\_Crash$crash");

			my $verdict = EVAL_evaluate_value ( 'PDvariable_'.$tcpar_PD_VariableLabel,
								  $pdVariableEDID, $tcpar_CompareOperator, $pdVariableData, $tcpar_EvalTolerance_abs, 'absolute' );			


			if(S_get_exec_option_NOERROR('CreisOfflineEvalReporting')){
				FLEDR_XML_addStaticEdidNode(
						$record, # record number
						'Misc_Static',
						$tcpar_EDID,
						$pdVariableDataElement."\n(".$tcpar_PD_VariableLabel.")",
						$pdVariableData,
						$pdVariableEDID,
						$tcpar_EvalTolerance_abs,
						$pdVariableEDID_unit,
						$verdict,
				);
		    }
		}
		
		# next Crash
	}
	
    return 1;
}


#-------------------------------------------------------------------------------------------------------------------
###
# Internal functions
###

1;