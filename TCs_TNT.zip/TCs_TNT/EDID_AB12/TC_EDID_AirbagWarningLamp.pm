#### TEST CASE MODULE
package TC_EDID_AirbagWarningLamp;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use LIFT_FaultMemory;
use LIFT_crash_simulation;
use LIFT_PD;
use GENERIC_DCOM;
use LIFT_labcar;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;
use LIFT_can_access;
use LIFT_LIN_Access;
use LIFT_flexray_access;

##################################

our $PURPOSE = "<This test script validates Airbag warning lamp state reported in EDR>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDID_AirbagWarningLamp

=head1 PURPOSE

<To Validate Airbag warning lamp state reported in EDR>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Create <Condition1> to Set <Lamp> to <WLState1> 

2. Wait for <Fault_Quali_Dequali_time1 > till the warning lamp state is changed.

3. Create <Condition2> to Set  <Lamp> to <WLState2> and wait for  <Fault_Quali_Dequali_time2>

4. Inject a Crash <Crashcode>

5. Wait time  <WaitTimeBeforeT02_ms> before t0 of second event

6. Wait for 6 seconds till EDR data is stored

7. Read <EDID> corresponding to warning lamp state in all EDR records


I<B<Evaluation>>

1. -

2. -


3. -

4. - 

5. - 

6. -

7. Value <ExpectedLampState_Value1> in most recent record  and  <ExpectedLampState_Value2> in oldest record

I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'ExpectedLampState_Value1' => 
	SCALAR 'Crashcode' => 
	SCALAR 'purpose' => 
	SCALAR 'Lamp' => 
	SCALAR 'WLState1' => 
	SCALAR 'WLState2' => 
	SCALAR 'WLType' => 
	SCALAR 'ExpectedLampState_Value2' => 
	SCALAR 'EDID' => 
	SCALAR 'FaultQualiDequalitime1' => 
	SCALAR 'Fault_Quali_Dequali_time2' => 
	SCALAR 'DiagType' => 
	SCALAR 'ResultDB' => 
	HASH 'COMsignalsAfterCrash' => 
	SCALAR 'CrashTimeZero_ms' => 
	SCALAR 'Supplier_EDID' =>


=head2 PARAMETER EXAMPLES

	purpose	 = 'Validate Airbag Warning Lamp state reported in EDR'

	Lamp = 'AWL'
	WLState1 = '<Test Heading>'
	WLState2 = 'None'

	WLType = 'Hardware' #Alternative: CAN/LIN/FlexRay
	#If WL type is CAN/LIN/FlexRay then only ON and OFF states are applicable.
	COMSignal = 'Optional' #Provide CAN/LIN/FlexRay COM signal name
	ExpectedLampState_Value1 = '0xFF'
	ExpectedLampState_Value2 = 'Optional'
	ExpectedNumberofRecords = '1'
	EDID = '<Fetch {EDID}>'
	WaitTimeBeforeT02_ms = '0'
	DiagType  = 'ProdDiag'
	ResultDB = 'EDR'
	Fault_Quali_Dequali_time1 = '2100'
	Fault_Quali_Dequali_time2 = '0'
	COMsignalsAfterCrash = %()
	T0ofEvent1_ms =  'NA'
	T0ofEvent2_ms = 'NA'
	Condition1 = 'None'
	Condition2 = 'None'
	#Create any fault for which airbag warnng should be OFF
	ExpectedLampState_Value1 = '0x00'
	Crashcode = 'Single_EDR_Front_above_8kph_NoDeployment'
	Supplier_EDID = '999' # optional: Give only if AWL status is stored in Supplier data section

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Lamp;
my $tcpar_WLState1;
my $tcpar_WLState2;
my $tcpar_WLType;
my $tcpar_PD_Variable_WarningLamp;
my $tcpar_ExpectedLampState_Value2;
my $tcpar_EDID;
my $tcpar_DiagType;
my $tcpar_ResultDB;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_T0ofEvent1_ms;
my $tcpar_T0ofEvent2_ms;
my $tcpar_ExpectedLampState_Value1;
my $tcpar_Crashcode;
my $edrNumberOfEventsToBeStored;
my $tcpar_Condition;
my $tcpar_ExpectedNumberofRecords;
my $tcpar_COMSignal;
my $tcpar_WaitTimeBeforeCrash;
my $tcpar_WL_State_Precondition;
my $tcpar_Fault_Precondition;
my $tcpar_Supplier_EDID;
my $tcpar_OptionalFaults_AfterCrash_aref;
my $tcpar_read_NHTSAEDR;
my $tcpar_read_CHINAEDR;

################ global parameter declaration ###################
#add any global variables here
my ($record_handler, $crashSettings, $ChinaEDR_diagType);
my ($sysWL_value1,$sysWL_value2);
###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_Lamp =  S_read_mandatory_testcase_parameter( 'Lamp' );
	$tcpar_WLState1 =  S_read_mandatory_testcase_parameter( 'WLState1' );
	$tcpar_WLState2 =  S_read_optional_testcase_parameter( 'WLState2' );
	$tcpar_WLType =  S_read_mandatory_testcase_parameter( 'WLType' );
	$tcpar_EDID =  S_read_mandatory_testcase_parameter( 'EDID' );
	$tcpar_DiagType =  S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_ResultDB =  S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_COMsignalsAfterCrash =  S_read_optional_testcase_parameter( 'COMsignalsAfterCrash','byref');
	$tcpar_T0ofEvent1_ms =  S_read_optional_testcase_parameter( 'T0ofEvent1_ms' );
	$tcpar_T0ofEvent2_ms =  S_read_optional_testcase_parameter( 'T0ofEvent2_ms' );
	$tcpar_ExpectedLampState_Value1 =  S_read_mandatory_testcase_parameter( 'ExpectedLampState_Value1' );
	$tcpar_ExpectedLampState_Value2 =  S_read_optional_testcase_parameter( 'ExpectedLampState_Value2' );
	$tcpar_Crashcode =  S_read_mandatory_testcase_parameter( 'Crashcode' );
	$tcpar_Condition =  S_read_optional_testcase_parameter( 'Fault' );
	$tcpar_ExpectedNumberofRecords =  S_read_mandatory_testcase_parameter( 'ExpectedNumberofRecords' );
	$tcpar_COMSignal =  S_read_optional_testcase_parameter( 'COMSignal' );
	$tcpar_WaitTimeBeforeCrash =  S_read_optional_testcase_parameter( 'WaitTimeBeforeCrash' );
	$tcpar_WL_State_Precondition =  S_read_optional_testcase_parameter( 'WL_State_Precondition' );
    $tcpar_Fault_Precondition =  S_read_mandatory_testcase_parameter( 'Fault_Precondition' ) if (defined $tcpar_WL_State_Precondition);
    $tcpar_Supplier_EDID = S_read_optional_testcase_parameter( 'Supplier_EDID');
    $tcpar_PD_Variable_WarningLamp = S_read_optional_testcase_parameter( 'PD_Variable_WarningLamp');
    $tcpar_OptionalFaults_AfterCrash_aref = S_read_optional_testcase_parameter( 'OptionalFaults_AfterCrash', 'byref');
    $tcpar_read_NHTSAEDR=S_read_optional_testcase_parameter('read_NHTSAEDR');
	$tcpar_read_CHINAEDR=S_read_optional_testcase_parameter('read_CHINAEDR');
	
    if(not defined $tcpar_PD_Variable_WarningLamp){
        S_set_warning("Warning lamp variable will be set to default value: rb_wimi_SysWIStatus_aen(0)");
        $tcpar_PD_Variable_WarningLamp = 'rb_wimi_SysWIStatus_aen(0)';
    }
    if($tcpar_Supplier_EDID and $tcpar_EDID =~ /\./){
        S_w2log(3, "Convert given SDID ($tcpar_EDID) to integer");
        $tcpar_EDID = EDR_Convert_SDID_To_Integer($tcpar_EDID);
    }

	if((defined $tcpar_Condition) and ($tcpar_Condition eq 'NotApplicable')){
		S_set_error(" Fault is $tcpar_Condition , dont perform the testcase as this is not applicable");
		return 0;
	}

	if( not defined $tcpar_Condition and $tcpar_WLState1 ne 'OFF'){
		S_set_error("Warning lamp is $tcpar_WLState1  but fault is not given. Give an applicable 'Fault'. ");
		return 0;
	}
	
	if(not defined $tcpar_read_CHINAEDR) {
		$tcpar_read_NHTSAEDR = 'yes';
		$tcpar_read_CHINAEDR = 'no';
	}
	else {
		$tcpar_read_NHTSAEDR = 'no';
		my $storageOrder = EDR_getStorageOrder();
		return unless(defined $storageOrder);

		if($storageOrder eq 'PhysicalOrder'){
			$ChinaEDR_diagType= 'ProdDiag';  #In platform NHTSA and China EDR is read via proddiag
		}
		else {
			$ChinaEDR_diagType= 'CHINA_Payload';
		}
	}

	return 1;
}

sub TC_initialization {

	S_w2rep("Initialize Record Handler");
	$record_handler = EDR_init_RecordHandler();

	#--------------------------------------------------------------
    # CRASH PREPARATION
	S_w2log(1, "Get crash settings" );

    # PREPARE CRASH AND INITIALIZE EQUIPMENT
	S_w2rep("Get crash settings for crash $tcpar_Crashcode");
    my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode};
	$crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
	unless(defined $crashSettings) {
		S_set_error("$tcpar_Crashcode not available in given .mdb file. Please check crash code.");
		return;
	}

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log(1, "Crashcode: $tcpar_Crashcode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");
    S_w2log(1, "Set environments for crash as per result DB");

	$tcpar_Crashcode .= "_AWL_$tcpar_WLState1\_$tcpar_WLState2\_$tcpar_WaitTimeBeforeCrash\_ms";

    S_w2log(1, "Power on ECU");
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');
    CA_trace_start();
    GDCOM_init () ; # To fetch info for CD from mapping_diag

    CSI_PrepareEnvironment($crashSettings, 'init_complete');
    S_wait_ms(2000);

    PD_ClearCrashRecorder();
    S_wait_ms(2000);

    S_w2log(1, "Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	return 1;
}

sub TC_stimulation_and_measurement {

    S_teststep("Prepare crash '$tcpar_Crashcode'", 'AUTO_NBR');
    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

    # Prepare crash
    CSI_LoadCrashSensorData2Simulator($crashSettings);

    # Power ON the ECU
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Read and evaluate fault memory before stimulation", 'AUTO_NBR');   
    my $faultsBeforeStimulation = LIFT_FaultMemory->read_fault_memory('Primary');
    $faultsBeforeStimulation->evaluate_faults( {} );    #Fault memory must be empty
	S_wait_ms(2000);

	S_teststep("Read warning lamp status through PD before starting the testcase", 'AUTO_NBR');
	S_wait_ms(4000);
    my $sysWL_value1_aref = PD_ReadMemoryByName($tcpar_PD_Variable_WarningLamp);
    if(@{$sysWL_value1_aref}){
        $sysWL_value1 =S_aref2dec($sysWL_value1_aref,U8);
    }
    else {
        S_set_error ( "Variable '$tcpar_PD_Variable_WarningLamp' is not present in .sad file.\n".
                        "Check variable given as parameter 'PD_Variable_WarningLamp'.\n".
                        "(If no value is given, default 'rb_wimi_SysWIStatus_aen(0)' is taken)" );
    }
	$sysWL_value1 = '00'if ($main::opt_offline);
	S_w2rep("Warning lamp value before test case stimulation is '$sysWL_value1'");
	if($sysWL_value1 != 00){
		S_set_error("$tcpar_Lamp is not OFF , make sure that the system is faultfree before starting the testcase");
		return 0;
	}
    # Set WL to precondition state if required
    if(defined $tcpar_WL_State_Precondition and $tcpar_WL_State_Precondition eq 'ON'){
        S_teststep("Set WL to state '$tcpar_WL_State_Precondition' as precondition with given fault '$tcpar_Fault_Precondition'", 'AUTO_NBR');
        S_teststep_2nd_level("Create fault '$tcpar_Fault_Precondition'", 'AUTO_NBR');
        FM_createFault($tcpar_Fault_Precondition);
		my $faultproperty = FM_fetchFaultInfo($tcpar_Fault_Precondition);      #get the type from Fault mapping file
		my $qualificationtime    = $faultproperty->{'CyclicQualificationtime'};
        S_teststep_2nd_level("Wait '$qualificationtime' ms for fault qualification", 'AUTO_NBR');
        S_wait_ms($qualificationtime);

        my $sysWL_valuePreCond;
        my $thisSysWL_value1_aref = PD_ReadMemoryByName_NOERROR('rb_wimi_SysWIStatus_aen(0)');
        if(@{$thisSysWL_value1_aref}){
            $sysWL_valuePreCond =S_aref2dec($thisSysWL_value1_aref,U8);
        }
        else {
            S_set_warning ( "Variable 'rb_wimi_SysWIStatus_aen(0)' is not present in .sad file hence variable 'rb_wimi_SysWIStatus_en(0)' is read \n" );
            $sysWL_valuePreCond=S_aref2dec(PD_ReadMemoryByName('rb_wimi_SysWIStatus_en(0)'),U8);
        }
        S_teststep_2nd_level("WL state is $sysWL_valuePreCond", 'AUTO_NBR');
    }

	#------------------------------------------------------------------------	
	#Set the lamp to state1 
	if ($tcpar_WLState1 eq 'OFF'){
		S_teststep("Set '$tcpar_Lamp' to state'$tcpar_WLState1' before crash ", 'AUTO_NBR');
		S_w2rep("Read warning lamp status before crash");
		#read AWL through COM
		if($tcpar_WLType ne 'Hardware'){
			$sysWL_value1 = CA_read_can_signal($tcpar_COMSignal, 'phys')if($tcpar_WLType eq 'CAN');
			$sysWL_value1 = LIN_read_LIN_signal($tcpar_COMSignal, 'phys')if($tcpar_WLType eq 'LIN');
			$sysWL_value1 = FR_read_flxr_signal($tcpar_COMSignal, 'phys')if($tcpar_WLType eq 'FlexRay');
			$sysWL_value1 = 00 if($sysWL_value1 == 0);
		}
	}
	else{
		S_teststep("Create fault $tcpar_Condition which will set '$tcpar_Lamp' to state '$tcpar_WLState1' before crash ", 'AUTO_NBR');
		#Create any fault which will trigger AWL ON
		FM_createFault($tcpar_Condition);
		LC_ECU_Reset() if($tcpar_Condition =~ m/Unexpected/);
		my $faultproperty = FM_fetchFaultInfo($tcpar_Condition);      #get the type from Fault mapping file
		my $qualificationtime    = $faultproperty->{'CyclicQualificationtime'};
        S_teststep_2nd_level("Wait '$qualificationtime' ms + 1000 ms for fault qualification", 'AUTO_NBR');
        S_wait_ms($qualificationtime);
        S_wait_ms(1000);
		my  $expectedFaults;
		S_teststep("Read fault memory before crash", 'AUTO_NBR', 'read_fault_before_crash');
        my $faults_before_crash = LIFT_FaultMemory->read_fault_memory('Primary');
        $expectedFaults->{'mandatory'}->{$tcpar_Condition} = { 'DecodedStatus' => { 'ConfirmedDTC' => 1, 'TestFailed' => 1}, };
        $expectedFaults->{'mandatory'}->{$tcpar_Fault_Precondition} = { 'DecodedStatus' => { 'ConfirmedDTC' => 1, 'TestFailed' => 1}, } if(defined $tcpar_Fault_Precondition);
        my $faultVerdict = $faults_before_crash -> evaluate_faults($expectedFaults, 'read_fault_before_crash');
	   if($faultVerdict ne 'VERDICT_PASS' and not $main::opt_offline) {
            S_set_error("'ON' condition cannot be created for $tcpar_Lamp because fault $tcpar_Condition was not created.");
        }
		my $sysWL_value1_aref = PD_ReadMemoryByName_NOERROR('rb_wimi_SysWIStatus_aen(0)');
		if(@{$sysWL_value1_aref}){
			 $sysWL_value1 =S_aref2dec($sysWL_value1_aref,U8);
		}
		else {
			S_set_warning ( "Variable 'rb_wimi_SysWIStatus_aen(0)' is not present in .sad file hence variable 'rb_wima_SysWIStatus_en' is read \n" );
			$sysWL_value1=S_aref2dec(PD_ReadMemoryByName('rb_wima_SysWIStatus_en'),U8);
		}
		S_w2rep("Warning lamp value read on PD when set to state $tcpar_WLState1 is '$sysWL_value1'");
		#read AWL through COM
		if($tcpar_WLType ne 'Hardware'){
			$sysWL_value1 = CA_read_can_signal($tcpar_COMSignal, 'phys')if($tcpar_WLType eq 'CAN');
			$sysWL_value1 = LIN_read_LIN_signal($tcpar_COMSignal, 'phys')if($tcpar_WLType eq 'LIN');
			$sysWL_value1 = FR_read_flxr_signal($tcpar_COMSignal, 'phys')if($tcpar_WLType eq 'FlexRay');
		}
		$sysWL_value1 = '01'if ($main::opt_offline);
	}
	S_w2rep("Warning lamp value read on COM when set to state $tcpar_WLState1 is  '$sysWL_value1'");
#------------------------------------------------------------------------	
	#Changing the warning lamp to state2 for multievent crashes
	if(defined $tcpar_WLState2){
		if ($tcpar_WLState2 eq 'OFF'){
			S_teststep("Remove fault '$tcpar_Condition' which will set '$tcpar_Lamp' to state '$tcpar_WLState2'  ", 'AUTO_NBR');
			#remove fault which had triggered AWL to ON earlier
			FM_removeFault($tcpar_Condition);
		}
		else{
			S_teststep("Create '$tcpar_Condition' which will set '$tcpar_Lamp' to state '$tcpar_WLState2' ", 'AUTO_NBR');
			#Create any fault which will trigger AWL ON
			FM_createFault($tcpar_Condition);
		}
		S_teststep("Wait for '$tcpar_WaitTimeBeforeCrash'  msec before crash ", 'AUTO_NBR');
		S_wait_ms($tcpar_WaitTimeBeforeCrash);
	}
#------------------------------------------------------------------------

    CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    S_wait_ms(1000);
    
	S_teststep("Inject a Crash '$tcpar_Crashcode'", 'AUTO_NBR');
	CSI_TriggerCrash();


	if(defined $tcpar_WLState2 ){
		if (defined $tcpar_T0ofEvent2_ms){
			S_teststep("Wait for crash time t0 of second event '$tcpar_T0ofEvent2_ms'  msec after crash ", 'AUTO_NBR');
			S_wait_ms($tcpar_T0ofEvent2_ms);
		}
		S_w2rep("Read warning lamp status through PD during crash");
		my $sysWL_value2_aref = PD_ReadMemoryByName_NOERROR('rb_wimi_SysWIStatus_aen(0)');
		if(@{$sysWL_value2_aref}){
			 $sysWL_value2 =S_aref2dec($sysWL_value2_aref,U8);
		}
		else {
			S_set_warning ( "Variable 'rb_wimi_SysWIStatus_aen(0)' is not present in .sad file hence variable 'rb_wima_SysWIStatus_en' is read \n" );
			$sysWL_value2=S_aref2dec(PD_ReadMemoryByName('rb_wima_SysWIStatus_en'),U8);
		}
		S_w2rep("Warning lamp value read on PD when set to state $tcpar_WLState2 is '$sysWL_value2'");
		#read AWL through COM
		if($tcpar_WLType ne 'Hardware'){
			$sysWL_value2 = CA_read_can_signal($tcpar_COMSignal, 'phys')if($tcpar_WLType eq 'CAN');
			$sysWL_value2 = LIN_read_LIN_signal($tcpar_COMSignal, 'phys')if($tcpar_WLType eq 'LIN');
			$sysWL_value2 = FR_read_flxr_signal($tcpar_COMSignal, 'phys')if($tcpar_WLType eq 'FlexRay');
		}
		$sysWL_value2 = '01'if ($main::opt_offline);
		S_w2rep("Warning lamp value read on COM when set to state $tcpar_WLState2 is '$sysWL_value2'");
		my $expectedFaults;
		S_teststep('Read fault memory after crash', 'AUTO_NBR', 'read_fault_after_crash');
        my $faults_after_crash = LIFT_FaultMemory->read_fault_memory('Primary');
        $expectedFaults->{'mandatory'}->{$tcpar_Condition} = { 'DecodedStatus' => { 'ConfirmedDTC' => 1}, };
        $expectedFaults->{'mandatory'}->{$tcpar_Fault_Precondition} = { 'DecodedStatus' => { 'ConfirmedDTC' => 1}, } if(defined $tcpar_Fault_Precondition);
		$expectedFaults->{'optional'} = $tcpar_OptionalFaults_AfterCrash_aref if(defined $tcpar_OptionalFaults_AfterCrash_aref);
        $faults_after_crash -> evaluate_faults($expectedFaults, 'read_fault_after_crash');
	}

	S_teststep("Wait for 15 seconds till EDR data is stored", 'AUTO_NBR');
	S_wait_ms(15000);
	
	S_w2rep("Read fault memory after 15sec");
	LIFT_FaultMemory->read_fault_memory('Primary');
	
	if (defined $tcpar_COMsignalsAfterCrash){
        foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
        {
            my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
            S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
            COM_setSignalState($signal,$dataOnCOM);
        }
    }

	# Edr records supported for the project
	$edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();

	S_teststep("Read the EDID '$tcpar_EDID' corresponding to warning lamp state in all '$edrNumberOfEventsToBeStored' EDR Recorders", 'AUTO_NBR'); #measurement 1
	my $dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_".$tcpar_Crashcode;
	if ( lc( $tcpar_read_NHTSAEDR) eq 'yes' ) {
		EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
								"CrashLabel" => $tcpar_Crashcode,
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								"read_EDRType"=>'NHTSA')
	}
	if (lc($tcpar_read_CHINAEDR) eq 'yes'){
		$edrNumberOfEventsToBeStored=3;
		EDR_ReadAndStoreAllRecords ("DiagType" =>  $ChinaEDR_diagType,
								"CrashLabel" => $tcpar_Crashcode,
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								"read_EDRType"=>'CHINA');
	
	}

    if(defined $tcpar_Supplier_EDID){
        my $recordStructureSupplier_href = EDR_ReadEDR_Record_structure_info_from_mapping_NOERROR('Supplier',0,'Mapping_EDR','SUPPLIER_EDIDS');
        if(not $recordStructureSupplier_href){
            S_set_error("Supplier data can not be extracted and parsed because section 'SUPPLIER_EDIDS' is missing in EDR mapping!");
            return;
        }

        foreach my $recordNbr (1..$edrNumberOfEventsToBeStored)
        {
            my $supplierRecordData_aref = $record_handler -> GetRawEDID( "EDIDnr" => $tcpar_Supplier_EDID,
                                                                    "RecordNumber" => $recordNbr,
                                                                    "CrashLabel" => $tcpar_Crashcode,);
            next unless($supplierRecordData_aref);

            S_teststep_2nd_level("Add obtained supplier data for crash record $recordNbr to record handler", 'AUTO_NBR');
            $record_handler -> AddCrashRecord(  "RecordNumber" => $recordNbr,
                                                    "CrashLabel"   => $tcpar_Crashcode.'_Supplier',
                                                    "RecordStructureInfo" => $recordStructureSupplier_href,
                                                    "RawDataGeneric" => $supplierRecordData_aref,);
            S_teststep_2nd_level("Print supplier data crash record $recordNbr", 'AUTO_NBR');
            $record_handler -> PrintRawEDIDs( "RecordNumber" => $recordNbr,
                                                "CrashLabel" => $tcpar_Crashcode.'_Supplier',
                                                "FormatOption" => 'HEX',);
        }
    }


	return 1;
}

sub TC_evaluation {

    my $crashLabel;
    if(defined $tcpar_Supplier_EDID){
        $crashLabel = $tcpar_Crashcode."_Supplier";
    }
    else {
        $crashLabel = $tcpar_Crashcode;
    }

	# Assign expected values according to StorageOrder
	my $storageOrder = EDR_getStorageOrder();
	unless(defined $storageOrder) {
		S_set_error("Define 'StorageOrder' in EDR mapping! Must be 'MostRecentFirst' or 'MostRecentLast'");
		return;
	}
	$storageOrder =  'MostRecentLast'if($storageOrder eq 'PhysicalOrder'); #same behavior as there is no overwriting
	my $expectedAWLstate;
	if($tcpar_ExpectedNumberofRecords == 1){
		$expectedAWLstate = {"Record_1" => $tcpar_ExpectedLampState_Value1};
	}
	else{
		$expectedAWLstate  = {"Record_1" => $tcpar_ExpectedLampState_Value2, "Record_2" => $tcpar_ExpectedLampState_Value1} if($storageOrder eq 'MostRecentFirst');
		$expectedAWLstate  = {"Record_1" => $tcpar_ExpectedLampState_Value1, "Record_2" => $tcpar_ExpectedLampState_Value2} if($storageOrder eq 'MostRecentLast');
    }

	#Getting the detected AWL state in EDR
	my $detectedAWLState;
	for(my $recordNbr = 1; $recordNbr <= $tcpar_ExpectedNumberofRecords; $recordNbr++)
	{
        S_teststep("Validate AWL state for (EDID $tcpar_EDID) in EDR Record '$recordNbr'", 'AUTO_NBR', "AWL_state_record_$recordNbr");#evaluation 1
	    $detectedAWLState = $record_handler -> GetRawEDID("EDIDnr" => $tcpar_EDID,
                                                       	 "RecordNumber" => $recordNbr,
														 "CrashLabel" => $crashLabel,
														 "FormatOption" => "HEX");
        unless(defined $detectedAWLState) {
			S_w2rep("No EDID data found for crash $tcpar_Crashcode, record $recordNbr. EDID cannot not be evaluated. Go to next record");
			S_set_verdict("VERDICT_FAIL");
			return;
		}
		$detectedAWLState = "0x".$detectedAWLState;
		my $expectedAWLstateforrecord = $expectedAWLstate -> {"Record_$recordNbr"};

        EVAL_evaluate_value( "EDID_$tcpar_EDID\_Evaluation", $detectedAWLState, '==' , $expectedAWLstateforrecord );
        S_teststep_expected("$expectedAWLstateforrecord", "AWL_state_record_$recordNbr");#evaluation 1
        S_teststep_detected("$detectedAWLState", "AWL_state_record_$recordNbr");
    }

	return 1;
}

sub TC_finalization {

	S_w2rep("Start test case finalization");

	#Delete Record Handler
	S_w2rep("Delete all object instances created...");
	foreach my $recordNumber (1..$edrNumberOfEventsToBeStored)
	{
		$record_handler -> DeleteRecord("CrashLabel" => $tcpar_Crashcode, "RecordNumber" => $recordNumber);
	}

	#Clearing crash recorder
	PD_ClearCrashRecorder();
	S_wait_ms(6000);

	#Remove Faults created
	if (($tcpar_WLState1 ne 'OFF') or ($tcpar_WLState2 eq 'ON')){
		FM_removeFault($tcpar_Condition);
		my $faultproperty = FM_fetchFaultInfo($tcpar_Condition);      #get the type from Fault mapping file
		my $dequalificationtime    = $faultproperty->{'CyclicDequalificationtime'};
		S_wait_ms($dequalificationtime);
	}
	if(defined $tcpar_Fault_Precondition){
		FM_removeFault($tcpar_Fault_Precondition);
		my $faultproperty = FM_fetchFaultInfo($tcpar_Fault_Precondition);      #get the type from Fault mapping file
		my $preCond_Dequalificationtime    = $faultproperty->{'CyclicDequalificationtime'};
		S_wait_ms($preCond_Dequalificationtime);
	}
	#Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	# Reset ECU
	PD_ECUreset();
	S_wait_ms('TIMER_ECU_READY');

	#Read fault memory after clearing 
    LIFT_FaultMemory->read_fault_memory('Primary');
	S_wait_ms(2000);

    LC_ECU_Off();();
    S_wait_ms('TIMER_ECU_OFF');

	return 1;
}


1;