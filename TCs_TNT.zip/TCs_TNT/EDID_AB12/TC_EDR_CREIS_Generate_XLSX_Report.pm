#### TEST CASE MODULE
package TC_EDR_CREIS_Generate_XLSX_Report;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use EDR_Framework::FuncLib_EDR_Offline_xlsxReporting;
use EDR_Framework::FuncLib_EDR_Offline_xmlLogging;
use File::Basename;

##################################

our $PURPOSE = "Create xlsx report from EDID validation";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_CREIS_Generate_XLSX_Report

=head1 PURPOSE

Create xlsx report from EDID validation

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

I<B<Stimulation and Measurement>>

I<B<Evaluation>>

I<B<Finalisation>>

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

=head2 PARAMETER EXAMPLES

=cut

###############################################################

sub TC_set_parameters {

	return 1;
}

sub TC_initialization {

	return 1;
}

sub TC_stimulation_and_measurement {

	S_w2rep("Generate xlsx report from XML.");
	my $xmlFile = FLEDR_get_XML_filename();
	my $excelFileDir = dirname($xmlFile);
	my $excelFileName = basename($xmlFile, '.xml');
	my $completePathExcel= $excelFileDir.$excelFileName.'xlsx';
	S_w2rep("My path: $completePathExcel");
	FLEDR_XLSX_createReport($xmlFile, $excelFileDir.'\\'.$excelFileName.'.xlsx');

	return 1;
}

sub TC_evaluation {
    
	return 1;
}

sub TC_finalization {

	return 1;
}


1;
