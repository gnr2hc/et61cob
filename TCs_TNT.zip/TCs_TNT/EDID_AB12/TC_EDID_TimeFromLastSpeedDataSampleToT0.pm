#### TEST CASE MODULE
package TC_EDID_TimeFromLastSpeedDataSampleToT0;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####


use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use LIFT_crash_simulation;
use LIFT_PD;
use GENERIC_DCOM;
use LIFT_labcar;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use LIFT_can_access;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;

##################################

our $PURPOSE = "<This script evaluates Time From Last Speed Data Sample To T0 in EDR>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDID_TimeFromLastSpeedDataSampleToT0

=head1 PURPOSE

<Evaluates Time From Last Speed Data Sample To T0 is lessthan the Sample rate of Vehicle speed data in EDR >

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Inject a crash<Crashcode>

2. Read <EDID> in all EDR records 


I<B<Evaluation>>

1.-

2. <EDID> should have value less than <SampleTime_VehicleSpeed>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'DiagType' => 
	SCALAR 'EDID' => 
	SCALAR 'ResultDB' => 
	SCALAR 'Crashcode' => 
	SCALAR 'ExpectedNumberofRecords' => 
	SCALAR 'SampleTime_VehicleSpeed' => 


=head2 PARAMETER EXAMPLES

	purpose		 = 'To validate the Time from Last Speed Data Sample (Precrash) to Time Zero Reported in EDR'
	
	EDID = '<Fetch {EDID}>'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_EDID;
my $tcpar_DiagType;
my $tcpar_ResultDB;
my $tcpar_Crashcode;
my $tcpar_ExpectedNumberofRecords;
my $tcpar_SampleTime_VehicleSpeed;
my $tcpar_purpose;

################ global parameter declaration ###################
#add any global variables here
my ($record_handler, $crashSettings, $recordIsThere, $edrNumberOfEventsToBeStored);


###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_EDID =  S_read_mandatory_testcase_parameter( 'EDID' );
	$tcpar_DiagType =  S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_ResultDB =  S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_Crashcode =  S_read_mandatory_testcase_parameter( 'Crashcode' );
	$tcpar_ExpectedNumberofRecords =  S_read_mandatory_testcase_parameter( 'ExpectedNumberofRecords' );
	$tcpar_SampleTime_VehicleSpeed =  S_read_mandatory_testcase_parameter( 'SampleTime_VehicleSpeed' );

	S_w2rep("Initialize Record Handler and check whether record for $tcpar_Crashcode is available");
	$record_handler = EDR_init_RecordHandler();
	$recordIsThere = $record_handler -> IsRecordAvailable("CrashLabel" => $tcpar_Crashcode,
															"RecordNumber"      => 1 );

	if(not defined $recordIsThere){
		S_w2rep("Crash will be injected and EDR data will be read in Simulation and Measurement");
		$recordIsThere=0;
	}
	return 1;
}

sub TC_initialization {

	if($recordIsThere == 0){
    	S_w2log(1, "Power on ECU");
		LC_ECU_On();
		S_wait_ms('TIMER_ECU_READY');

        S_w2log(1, "Initialize DCOM and start CAN trace");
        GDCOM_init () ;
        CA_trace_start();

        S_w2log(1, "Clear EDR");
		PD_ClearCrashRecorder();
		S_wait_ms(2000);

		S_w2log(1, "Clear fault memory");
		PD_ClearFaultMemory();
		S_wait_ms(2000);

		S_w2log(1, "Read fault memory before stimulation");
		my $faultsBeforeStimulation = PD_ReadFaultMemory();
        my $faultsVerdict = PD_evaluate_faults_NOVERDICT( $faultsBeforeStimulation, []);
        return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

		#--------------------------------------------------------------
		# CRASH PREPARATION
		S_w2log(1, "Prepare crash $tcpar_Crashcode" );

		# PREPARE CRASH AND INITIALIZE EQUIPMENT
		S_w2rep("Get crash settings for crash $tcpar_Crashcode");
		my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode};
		$crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
		unless(defined $crashSettings) {
			S_set_error("$tcpar_Crashcode not available in given .mdb file. Please check crash code.");
			return;
		}

		my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
		my $resultDB_Path = $resultDBDetails->{'PATH'};
		S_w2log(1, "Crashcode: $tcpar_Crashcode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");
		S_w2log(1, "Set environments for crash as per result DB");
        CSI_PrepareEnvironment($crashSettings, 'init_complete');

		#Prepare crash
        S_w2log(1, "Power off ECU");
        LC_ECU_Off();
        S_wait_ms('TIMER_ECU_READY');
    
        #Prepare crash
        S_w2log(1, "Load data to simulator");
        CSI_LoadCrashSensorData2Simulator($crashSettings);
    
        S_w2log(1, "Power on ECU");
        LC_ECU_On();
        S_wait_ms('TIMER_ECU_READY');

	}

	return 1;

}

sub TC_stimulation_and_measurement {

	# number of EDR records supported for Project
	my $edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();

	unless(defined $edrNumberOfEventsToBeStored){
		S_set_error("Number of records to be stored in EDR not available in SYC - add or overwrite with Custlibrary Function");
		return;
	}
	
	if($recordIsThere == 0){
		
		CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    	S_wait_ms(1000);
    
		S_teststep("Inject a crash '$tcpar_Crashcode'", 'AUTO_NBR');
		CSI_TriggerCrash();

		S_w2rep("Wait for 10 seconds time after crash");
		S_wait_ms(10000);

		S_w2log(1, "Read fault memory after stimulation");
		PD_ReadFaultMemory();


		# Edr records supported for the project
		S_teststep("Read EDID '$tcpar_EDID' in all '$edrNumberOfEventsToBeStored' EDR records ", 'AUTO_NBR', 'read_edid');#measurement 1

		my $dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_".$tcpar_Crashcode;
		PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');
		EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
										"CrashLabel" => $tcpar_Crashcode,
										"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
										"StoragePath" => $dataStoragePath,
										);
	}
	else{
		S_teststep("Crash '$tcpar_Crashcode' is injected in 'TC_EDR_CrashInjection'", 'AUTO_NBR');
		S_teststep("Read EDID '$tcpar_EDID' in all '$edrNumberOfEventsToBeStored' EDR records ", 'AUTO_NBR', 'read_edid');#measurement 1
	}
	
	return 1;
}

sub TC_evaluation {

	foreach my $recordNbr (1..$tcpar_ExpectedNumberofRecords)
	{
	    S_teststep_2nd_level("Evaluate EDID $tcpar_EDID in record $recordNbr", 'AUTO_NBR', "Validate_Record_$recordNbr");

		my $detectedEDIDvalue = $record_handler -> GetDecodedEDID( "EDIDnr" => $tcpar_EDID,
															 "RecordNumber" => $recordNbr,
															 "CrashLabel" => $tcpar_Crashcode,);

		my $detectedSpeedData = $detectedEDIDvalue -> {"DataValue"};

		unless(defined $detectedSpeedData) {
			S_w2rep("No EDID data found for crash $tcpar_Crashcode, record $recordNbr. EDID cannot not be evaluated. Go to next record");
			return;
		}

		S_teststep_expected("EDID '$tcpar_EDID' value < '$tcpar_SampleTime_VehicleSpeed' msec", "Validate_Record_$recordNbr");#evaluation 1
		S_teststep_detected("EDID '$tcpar_EDID' value: $detectedSpeedData msec", "Validate_Record_$recordNbr");
		my $verdict = EVAL_evaluate_value ( "EDID_$tcpar_EDID\_Evaluation for $recordNbr " , $detectedSpeedData, '<' , $tcpar_SampleTime_VehicleSpeed );

	}

	return 1;
}

sub TC_finalization {
	
	if($recordIsThere == 0){

		S_w2rep("Delete created record objects");
		foreach my $recordNumber (1..$edrNumberOfEventsToBeStored)
		{
			$record_handler -> DeleteRecord ("CrashLabel" => $tcpar_Crashcode, "RecordNumber" => $recordNumber );
		}

		#Clearing crash recorder
		PD_ClearCrashRecorder();
		S_wait_ms(2000);

		#Erase Fault memory
		PD_ClearFaultMemory();
		S_wait_ms(2000);

		# Reset ECU
		PD_ECUreset();
		S_wait_ms('TIMER_ECU_READY');

		#Read fault memory after clearing and erasing EDR
		PD_ReadFaultMemory();

		LC_ECU_Off();
		S_wait_ms('TIMER_ECU_OFF');
	}

	return 1;
}


1;
