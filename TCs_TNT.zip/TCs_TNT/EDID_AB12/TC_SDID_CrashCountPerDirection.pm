#### TEST CASE MODULE
package TC_SDID_CrashCountPerDirection;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS_EDR_EDIDList_SupplierData> 
#TS version in DOORS: <0.18>
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use INCLUDES_Project;
use LIFT_general;
use LIFT_PD;
use GENERIC_DCOM;
use LIFT_can_access;
use LIFT_labcar;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use LIFT_crash_simulation;
use LIFT_FaultMemory;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;
use Data::Dumper;
 #necessary
#include further modules here

##################################

our $PURPOSE = "<This scripts validates the CrashCountPerDirection reported in EDR for different crash scenarios>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SDID_CrashCountPerDirection

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Clear crash recorder and resetECU.

2. Write the variable <Var_CrashCount> with the value <Val_CrashCount> through PD.

3. Inject <Crashcode1>

4.Wait for <WaitTime_ms> 

5.Inject a <Crashcode2> and Wait for <WaitTime_ms> 

6. Read the  <Data _Element> corresponding to the <SDID> EventCounter value in most recent Entry of EDR

7. Cleasr the Crash recorder and power down the ECU.


I<B<Evaluation>>

1.

2. 

3.

4. 

5. 

6.

7. <Data _Element> should report the value equal to the value <Expected_Value_RawHex_Incident>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Var_CrashCount' => PD Variable for Crashcount.
	SCALAR 'Val_CrashCount' => Value to be written i the variable.
	SCALAR 'Crashcode1' =>  The crash file to be injected.
	SCALAR 'Crashcode2' =>  The crash file to be injected.
	SCALAR 'Expected_Value_RawHex_Incident' => Expected raw value after injection of Crashcode1 and Crashcode2
	SCALAR 'purpose' => To validate the CrashCountPerDirection reported in EDR for different crash scenarios
	SCALAR 'SDID' => Unique Supplier EDID ID.
	SCALAR 'Data_Element' => Data element name of the SDID.
	SCALAR 'WaitTime_ms' => wait time.
	


=head2 PARAMETER EXAMPLES

	purpose	 = 'to validate the data element "Crash Count Per Direction" recorded in EDR through CD'
	
	SDID= '<Fetch {SDID}>'
	Data_Element= '<Fetch {Object Text}>'
	WaitTime_ms=6000 #ms
	DiagType = 'ProdDiag'
	ResultDB = 'EDR'
	EDIDNr_Supplier = '999'
	COMsignalsAfterCrash = %()
	Var_CrashCount='rb_dcc_HeaderPublic_dfst.CrashCountPerDirection_au16(0)' #Variable used to check thecrash countper direction.
	Val_CrashCount='NA'
	Crashcode1='Single_EDR_Front_above_8kph_NoDeployment'
	Crashcode2='Single_EDR_Front_Inflatable'
	Expected_Value_RawHex_Incident = %('999103_1' => '0001', '999103_2' => '0000','999103_3' => '0000','999103_4' => '0000','999103_5' => '0000','999103_6' => '0000')


=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_SDID;
my $tcpar_DiagType;
my $tcpar_ResultDB;
my $tcpar_EDIDNr_Supplier;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_Crashcode1;
my $tcpar_Crashcode2;
my $tcpar_Expected_Value_RawHex_Incident;

################ global parameter declaration ###################
my ($crashlabel_Complete,
	$record_handler,
 	$tcpar_EDID,
	$edrNumberOfEventsToBeStored,
	$crashSettings_href,
	$crashCodes_aref);

#add any global variables here


###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_SDID =  S_read_mandatory_testcase_parameter( 'SDID' );
	$tcpar_DiagType =  S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_ResultDB =  S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_EDIDNr_Supplier =  S_read_optional_testcase_parameter( 'EDIDNr_Supplier' );
	$tcpar_COMsignalsAfterCrash =  S_read_optional_testcase_parameter( 'COMsignalsAfterCrash','byref' );
	$tcpar_Crashcode1 =  S_read_mandatory_testcase_parameter( 'Crashcode1' );
	push(@{$crashCodes_aref}, $tcpar_Crashcode1);
	$tcpar_Crashcode2 =  GEN_Read_optional_testcase_parameter( 'Crashcode2' );
	my @crashCode1_array = split(/;/, $tcpar_Crashcode1);
	if(defined $tcpar_Crashcode2){
		my @crashCode2_array = split(/;/, $tcpar_Crashcode2);
		$crashlabel_Complete = $crashCode1_array[0]."_".$crashCode2_array[0];
		push(@{$crashCodes_aref}, $tcpar_Crashcode2);
	}
	else{
		$crashlabel_Complete = $crashCode1_array[0];
	}
	
	$tcpar_Expected_Value_RawHex_Incident =  S_read_mandatory_testcase_parameter( 'Expected_Value_RawHex_Incident','byref' );
	$tcpar_EDID = EDR_Convert_SDID_To_Integer ($tcpar_SDID);
	if(not defined $tcpar_EDID){
		S_w2rep("Converting DOORS SDID to integer was not successful. Test case can't be performed.");
		return;
	}

	if(not defined $tcpar_EDIDNr_Supplier){
		S_w2rep("Setting the Supplier EDID number as 999 by default");
		$tcpar_EDIDNr_Supplier = 999;
	}
	return 1;
}
#---------------------------------------------------------------------------------------------
sub TC_initialization {
#--------------------------------------------------------------------------------------------
	#INTIALIZE RECORD AND CRASH HANDLER
	S_w2rep("Initialize Record Handler");
	$record_handler = EDR_init_RecordHandler() || return;

	#--------------------------------------------------------------
    # CRASH PREPARATION
	S_w2log(1, "Prepare crash" );

	# PREPARE CRASH AND INITIALIZE EQUIPMENT
	S_w2rep("Get crash settings for crash $tcpar_Crashcode1");
	my $crashDetails_href1 = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode1};
	$crashSettings_href -> {$tcpar_Crashcode1} = CSI_GetCrashDataFromMDS($crashDetails_href1);
	if(not defined $crashSettings_href -> {$tcpar_Crashcode1}) {
		S_set_error("Crash code $tcpar_Crashcode1 not defined in given result DB. Test case will be aborted.", 110);
		return;
	}

	if(defined $tcpar_Crashcode2){
		my $crashDetails_href2 = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode2};
		$crashSettings_href -> {$tcpar_Crashcode2} = CSI_GetCrashDataFromMDS($crashDetails_href2);
		if(not defined $crashSettings_href -> {$tcpar_Crashcode2}) {
			S_set_error("Crash code $tcpar_Crashcode2 not defined in given result DB. Test case will be aborted.", 110);
			return;
		}		
	}

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log(1, "Crashcode: $tcpar_Crashcode1, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");

	S_w2log(1, "Power on ECU");
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

    S_w2log(1, "Start CAN trace");
	GDCOM_init ();
	CA_trace_start();

	S_w2log(1, "Set environments for crash as per result DB");
	CSI_PrepareEnvironment(($crashSettings_href -> {$tcpar_Crashcode1}), 'init_complete');
	S_wait_ms('TIMER_ECU_READY');

	S_w2log(1, "Clear crash recorder");
	PD_ClearCrashRecorder();
	S_wait_ms(6000);

	S_w2log(1, "Clear fault memory");
	PD_ClearFaultMemory();
	S_wait_ms(2000);

    S_w2log(1, "Read and evaluate fault memory before stimulation");
    my $faultsBeforeStimulation_obj = LIFT_FaultMemory -> read_fault_memory('Bosch');
    my $faultsVerdict = $faultsBeforeStimulation_obj -> evaluate_faults({});
    return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

	return 1;
}

#---------------------------------------------------------------------------------------------------
sub TC_stimulation_and_measurement {
#-------------------------------------------------------------------------------------------------

    # number of EDR records supported for Project
	$edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();

	unless(defined $edrNumberOfEventsToBeStored){
		S_set_error("Number of records to be stored in EDR not available in SYC - add or overwrite with Custlibrary Function");
		return;
	}
	
	# Providing data storage label for a injecting crash and storing the data.
	foreach my $crashlabel (@{$crashCodes_aref})
	{
		my $crashSettings = $crashSettings_href -> {$crashlabel};
		#--------------------------------------------------------------------------------------------------#
		#Prepare crash
		CSI_LoadCrashSensorData2Simulator( $crashSettings );
		S_wait_ms(2000);
		
		CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    	S_wait_ms(1000);
		
		#Inject crash
		S_teststep("Inject '$crashlabel'", 'AUTO_NBR');
		CSI_TriggerCrash();
		S_wait_ms(15000);#wait time after crash
	
		if (defined $tcpar_COMsignalsAfterCrash){
			foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
			{
				my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
				S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
				COM_setSignalState($signal,$dataOnCOM);
			}
		}

		
	# next crash code
	}
	my $dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_".$crashlabel_Complete;
		
	S_teststep("Read EDR record for crash combination $crashlabel_Complete", 'AUTO_NBR');
	S_teststep_2nd_level("Read and print all EDR data", 'AUTO_NBR');
	PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');
	EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
								"CrashLabel" => $crashlabel_Complete,
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								);
										
	# add supplier section
	############################
	S_teststep_2nd_level("Extract and parse supplier data", 'AUTO_NBR');
	my $recordStructureSupplier_href = EDR_ReadEDR_Record_structure_info_from_mapping_NOERROR('Supplier',0,'Mapping_EDR','SUPPLIER_EDIDS');
	if(not defined $recordStructureSupplier_href){
        S_set_warning("Supplier EDID section is not available in EDR mapping.\n".
        "Generate mapping newly with this section if the EDID to be evaluated is part of Supplier section");
        return 1;
	}

    #--------------------------------------------------------------
    # ADD SUPPLIER EDIDS   
    # ----------------------------------------------------------- 
	foreach my $recordNbr (1..$edrNumberOfEventsToBeStored)
	{
		my $recordAvailable = $record_handler -> IsRecordAvailable("CrashLabel" => $crashlabel_Complete, "RecordNumber"=> $recordNbr);
		next unless($recordAvailable);

		my $recordData_aref = $record_handler -> GetRawEDID( "EDIDnr" => $tcpar_EDIDNr_Supplier,
															"RecordNumber" => $recordNbr,
															"CrashLabel" => $crashlabel_Complete,);

		$record_handler -> AddCrashRecord(  "RecordNumber" => $recordNbr,
											"CrashLabel"   => $crashlabel_Complete.'_Supplier',
											"RecordStructureInfo" => $recordStructureSupplier_href,
											"RawDataGeneric" => $recordData_aref,);
		$record_handler -> PrintRawEDIDs( "RecordNumber" => $recordNbr,
											"CrashLabel" => $crashlabel_Complete.'_Supplier',);
	}

	return 1;
}
#-------------------------------------------------------------------------------
sub TC_evaluation {
#-------------------------------------------------------------------------------
    my $storageOrder = EDR_getStorageOrder();
    return unless(defined $storageOrder);

    if($storageOrder eq 'PhysicalOrder'){
       $storageOrder =  'MostRecentLast'; #same behavior as there is no overwriting
    }

	my $numberOfStoredRecords = $record_handler -> GetNumberOfStoredRecords("CrashLabel" => $crashlabel_Complete.'_Supplier');
	if($numberOfStoredRecords == 0){
		S_set_error("No records stored during crash injection. Abort evaluation.");
		return;
	}

    my $record_number;
	$record_number=  1 if ( $storageOrder  eq 'MostRecentFirst');
	$record_number= $numberOfStoredRecords if ( $storageOrder  eq 'MostRecentLast');

	my $dataElement = $record_handler -> GetDataElementEDID( "EDIDnr" => $tcpar_EDID,
															"RecordNumber" => $record_number,
															"CrashLabel" => $crashlabel_Complete.'_Supplier',);

	S_teststep("Validate EDID $tcpar_EDID ($dataElement) in record $record_number.", 'AUTO_NBR');

	foreach my $rawEDID (keys %{$tcpar_Expected_Value_RawHex_Incident})
	{
		my $dataElement = $record_handler -> GetDataElementEDID( "EDIDnr" => $rawEDID,
															"RecordNumber" => $record_number,
															"CrashLabel" => $crashlabel_Complete.'_Supplier',);

		S_teststep_2nd_level("Get $rawEDID ($dataElement)", 'AUTO_NBR', "EDID_$rawEDID\_record_$record_number");

		my $detected_subEDIDvalue = $record_handler -> GetRawEDID("EDIDnr" => $rawEDID,
                                                      	 "RecordNumber" => $record_number,
													 "CrashLabel" => $crashlabel_Complete.'_Supplier',
													 "FormatOption" => "HEX");
		unless(defined $detected_subEDIDvalue) {
			S_set_error("No data could be obtained for EDID $rawEDID in record $record_number.");
			next;
		}
		if(ref $detected_subEDIDvalue eq 'ARRAY') {
			my $detectedsubEDIDvalueString;
			foreach my $hexElement (@{$detected_subEDIDvalue})
			{
				$detectedsubEDIDvalueString .= $hexElement;
			}
			$detected_subEDIDvalue = $detectedsubEDIDvalueString;
		}
		else{
			$detected_subEDIDvalue = $detected_subEDIDvalue;
		}
		S_teststep_detected ("$detected_subEDIDvalue","EDID_$rawEDID\_record_$record_number");
		my $expected_subEDIDvalue = $tcpar_Expected_Value_RawHex_Incident -> {$rawEDID};
		S_teststep_expected ("$expected_subEDIDvalue","EDID_$rawEDID\_record_$record_number");
		EVAL_evaluate_value( "EDID_$rawEDID\_Evaluation", $detected_subEDIDvalue, '==' , $expected_subEDIDvalue);
	}
	
	return 1;
}


#----------------------------------------------------------------------------
sub TC_finalization {
#----------------------------------------------------------------------------
	
	S_w2rep("Start test case finalization");
	S_w2log(1, "Delete record objects");
	foreach my $record (1..$edrNumberOfEventsToBeStored)
	{
		$record_handler -> DeleteRecord("CrashLabel" => $crashlabel_Complete, "RecordNumber" => $record);
		$record_handler -> DeleteRecord("CrashLabel" => $crashlabel_Complete.'_Supplier', "RecordNumber" => $record);
	}

	PD_ReadFaultMemory();

	#Clearing crash recorder
	PD_ClearCrashRecorder();
	S_wait_ms(2000);

	#Erase Fault memory
	PD_ClearFaultMemory();
	S_wait_ms(2000);

	# Reset ECU
	PD_ECUreset();
	S_wait_ms('TIMER_ECU_READY');

	#Read fault memory after clearing and erasing EDR
	LIFT_FaultMemory -> read_fault_memory('Bosch');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_w2rep("Testcase finalization is done");

	return 1;
}

###############local subs###################


	
1;
