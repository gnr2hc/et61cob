#### TEST CASE MODULE
package TC_EDID_COMSignals_InValidData;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_can_access;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use GENERIC_DCOM;
use FuncLib_EDR_Framework;
use FuncLib_TNT_SYC_INTERFACE;
use Data::Dumper;


##################################

our $PURPOSE = "<To validate COM EDID in EDR when invalid data is sent on bus>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDID_COMSignals_InValidData

=head1 PURPOSE

<To validate COM EDID in EDR when invalid data is sent on bus>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Set the <COMSignal> to its default state which is fetched from mapping

2. Wait for <WaitTimeTransmitSignal_msec> till the signal is transmitted on the COM bus

3. Create <InvalidState> for <COMSignal>

4. Wait <TimeInvalidBeforeCrash_msec>

5. Inject a Crash

6. Read <EDID> corresponding to COM signal


I<B<Evaluation>>

1. -

2. -

3. -

4. - 

5. -

6. COMSignalValue corresponding to <COMSignalAfterInvalidState>should be reported in EDR


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'COMSignal' => 
	SCALAR 'COMsignal_Qbit' => 
	SCALAR 'Condition' => 
	SCALAR 'purpose' => 
	SCALAR 'EDID' => 
	SCALAR 'WaitTimeTransmitSignal_msec' => 
	SCALAR 'TimeInvalidBeforeCrash_msec' => 
	SCALAR 'COMSignalAfterInvalidState' => 
	SCALAR 'InvalidState' => 
	SCALAR 'Protocol' => 
	HASH 'COMsignalsAfterCrash' => 


=head2 PARAMETER EXAMPLES

	purpose		 = 'Validate COM signal relavent EDID in EDR when Invalid data is obtained on COM signal'
	
	EDID = '<Fetch {EDID}>'
	
	WaitTimeTransmitSignal_msec = '6000'
	TimeInvalidBeforeCrash_msec = '6000'
	
	# COMSignal = 'TBD'
	COMSignalAfterInvalidState = 'FE' #InvalidState
	InvalidState = <Test Heading 2>
	Protocol='CAN'
	COMsignalsAfterCrash = %()
	#As defined in CAN mappile file
	COMSignal = 'VSD_ESPReferenceVelocity'
	COMsignal_Qbit= 'VehicleSpeed_QualityFactor'
	Condition='Set_Qbit'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_EDID;
my $tcpar_WaitTimeTransmitSignal_msec;
my $tcpar_TimeInvalidBeforeCrash_msec;
my $tcpar_COMSignalAfterInvalidState;
my $tcpar_expected_nr_of_records;
my $tcpar_Protocol;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_COMSignal;
my $tcpar_COM_Message;
my $tcpar_COMsignal_Qbit;
my $tcpar_Condition;
my $tcpar_wait_ms;
my $tcpar_Crashcode;
my $tcpar_DiagType;
my $tcpar_ResultDB ;
my $tcpar_Method;
my $tcpar_Q_BitValue;
my $tcpar_Faulty_value;
my $tcpar_COM_Defaultstate;
my $tcpar_Manipulated_COM_Signals;
my $tcpar_read_NHTSAEDR;
my $tcpar_read_CHINAEDR;

################ global parameter declaration ###################
#add any global variables here
my ($record_handler, $crash_handler, $crashSettings, $edrNumberOfEventsToBeStored,$manipulatedCOMsignals,$ChinaEDR_diagType,$default_value,$unit);

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_EDID =  S_read_mandatory_testcase_parameter( 'EDID' );
	$tcpar_wait_ms =  S_read_mandatory_testcase_parameter( 'wait_ms' );
	$tcpar_Crashcode =  S_read_mandatory_testcase_parameter( 'Crashcode' );
	$tcpar_expected_nr_of_records =  S_read_mandatory_testcase_parameter( 'expected_nr_of_records' );
	$tcpar_DiagType =  S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_ResultDB =  S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_WaitTimeTransmitSignal_msec =  S_read_mandatory_testcase_parameter( 'WaitTimeTransmitSignal_msec' );
	$tcpar_TimeInvalidBeforeCrash_msec =  S_read_mandatory_testcase_parameter( 'TimeInvalidBeforeCrash_msec' );
	$tcpar_COMSignalAfterInvalidState =  S_read_optional_testcase_parameter( 'COMSignalAfterInvalidState');
	$tcpar_Faulty_value =  S_read_optional_testcase_parameter( 'Faulty_value');
	$tcpar_Protocol =  S_read_mandatory_testcase_parameter( 'Protocol' );
	$tcpar_COMsignalsAfterCrash = S_read_optional_testcase_parameter( 'COMsignalsAfterCrash','byref' );
	$tcpar_Manipulated_COM_Signals = S_read_optional_testcase_parameter( 'Manipulated_COM_Signals','byref' );
	$tcpar_COMSignal =  S_read_mandatory_testcase_parameter( 'COMSignal' );
	$tcpar_COM_Message =  S_read_optional_testcase_parameter( 'COM_Message' );
	$tcpar_COM_Defaultstate =  S_read_optional_testcase_parameter( 'COM_Defaultstate' );
	$tcpar_Q_BitValue =  S_read_optional_testcase_parameter( 'Q_BitValue' );
	$tcpar_COMsignal_Qbit =  S_read_optional_testcase_parameter( 'COMsignal_Qbit' );
	$tcpar_Condition =  S_read_mandatory_testcase_parameter( 'Condition' );
	$tcpar_Method = S_read_optional_testcase_parameter( 'Method' );
	
	unless( defined $tcpar_Method ) {
  		S_w2rep(" -->  Missing optional parameter 'Method', By default script uses 'Constant' as the method. \n");
  		$tcpar_Method = 'Constant';
	}
	$tcpar_read_NHTSAEDR=S_read_optional_testcase_parameter('read_NHTSAEDR');
	$tcpar_read_CHINAEDR=S_read_optional_testcase_parameter('read_CHINAEDR');
	
	if(not defined $tcpar_read_CHINAEDR) {
		$tcpar_read_NHTSAEDR = 'yes';
		$tcpar_read_CHINAEDR = 'no';
	}
	else {
		$tcpar_read_NHTSAEDR = 'no';
		my $storageOrder = EDR_getStorageOrder();
		return unless(defined $storageOrder);

		if($storageOrder eq 'PhysicalOrder'){
			$ChinaEDR_diagType= 'Prodiag';  #In platform NHTSA and China EDR is read via proddiag
		}
		else {
			$ChinaEDR_diagType= 'CHINA_Payload';
		}
	}
	return 1;
}

sub TC_initialization {

	S_teststep("Test setup preparation", 'AUTO_NBR');

	#--------------------------------------------------------------
    # INITIALIZE RECORD AND CRASH HANDLER
    #    
	S_w2rep("Initialize Record and Crash Handler");
	$record_handler = EDR_init_RecordHandler() || return;
	$crash_handler  = EDR_init_CrashHandler() || return;

	#--------------------------------------------------------------
    # PREPARE CRASH AND INITIALIZE EQUIPMENT
    #
	S_w2rep("Get crash settings for crash $tcpar_Crashcode");
    my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode};
    $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
    unless(defined $crashSettings) {
       S_set_error("Crash $tcpar_Crashcode not available in result DB $tcpar_ResultDB. Test case aborted.");
       return;
    }

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log(1, "Crashcode: $tcpar_Crashcode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");

	S_w2log(1, "Power on ECU");
    LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');
    
    S_w2log(1, "Initialize CD ");
    GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start();

    S_w2log(1, "Set environments for crash as per result DB");
    CSI_PrepareEnvironment($crashSettings, 'init_complete');
    S_wait_ms(2000);

	S_w2log(1, "Clear crash recorder");
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(2000);

	S_w2log(1, "Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	S_w2log(1, "Read and evaluate fault memory before stimulation");
    my $faultsBeforeStimulation = PD_ReadFaultMemory();
    my $faultsVerdict = PD_evaluate_faults( $faultsBeforeStimulation, []);
    return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

	return 1;
}

sub TC_stimulation_and_measurement {
    #--------------------------------------------------------------
    # PREPARE CRASH INJECTION AND REPORT FILES
    #    
    S_teststep("Prepare crash", 'AUTO_NBR');
    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

    # Prepare crash
    CSI_LoadCrashSensorData2Simulator($crashSettings);

    # Power ON the ECU
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

	CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    S_wait_ms(1000);

    #--------------------------------------------------------------
    # START COM SIGNAL MANIPULATION
    # 
	S_teststep("Set the '$tcpar_COMSignal' to default state given in can mapping OR signal state given in TS", 'AUTO_NBR');
	if (defined $tcpar_COM_Defaultstate){
		S_teststep_2nd_level (" Setting COM signal to  to $tcpar_COM_Defaultstate", 'AUTO_NBR');
		COM_setSignalState($tcpar_COMSignal,$tcpar_COM_Defaultstate,$tcpar_Protocol);
	}
	
	($default_value,$unit) = CA_read_can_signal($tcpar_COMSignal, 'phys')if($tcpar_Protocol eq 'CAN');
	($default_value,$unit) = FR_read_flxr_signal($tcpar_COMSignal, 'phys')if($tcpar_Protocol eq 'FlexRay');
	
	S_w2rep("default_value=$default_value");
	
	$default_value=1 if ($main::opt_offline);

	S_teststep("Wait for '$tcpar_WaitTimeTransmitSignal_msec' till the signal is transmitted on the COM bus", 'AUTO_NBR');
	S_wait_ms($tcpar_WaitTimeTransmitSignal_msec);
	
	if (defined $tcpar_Manipulated_COM_Signals){
		my $data;
		foreach my $signal (keys %{$tcpar_Manipulated_COM_Signals})
		{
			($data,$unit) = CA_read_can_signal($signal, 'phys') if (lc($tcpar_Protocol) =~ m/can/i);
            ($data,$unit) = FR_read_flxr_signal($signal, 'phys') if (lc($tcpar_Protocol) =~ m/flexray/i);
			$manipulatedCOMsignals -> {$signal}=$data;
			my $dataOnCOM = $tcpar_Manipulated_COM_Signals -> {$signal};
			S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
			COM_setSignalState($signal,$dataOnCOM);
		}
	}

	S_teststep("Create '$tcpar_Condition' on '$tcpar_COMSignal'", 'AUTO_NBR');
	if ($tcpar_Condition eq 'Set_Qbit'){
		my $Qbit_data;
		# Store current value of COM signal for resetting later
		($Qbit_data,$unit) = CA_read_can_signal($tcpar_COMsignal_Qbit, 'phys') if (lc($tcpar_Protocol) =~ m/can/i);
		($Qbit_data,$unit) = FR_read_flxr_signal($tcpar_COMsignal_Qbit, 'phys') if (lc($tcpar_Protocol) =~ m/flexray/i);
		$manipulatedCOMsignals -> {$tcpar_COMsignal_Qbit}= $Qbit_data;
		if (defined $tcpar_Q_BitValue){
			S_teststep_2nd_level (" Setting Qbit to $tcpar_Q_BitValue", 'AUTO_NBR');
			COM_setSignalState($tcpar_COMsignal_Qbit,$tcpar_Q_BitValue,$tcpar_Protocol);
		}
		else {
			S_teststep_2nd_level (" Setting Qbit to 1", 'AUTO_NBR');
			COM_setSignalState($tcpar_COMsignal_Qbit,'1',$tcpar_Protocol);
		}
	}
	elsif($tcpar_Condition eq 'CRC_Error'){
		COM_CreateCRCErrors([$tcpar_COM_Message],$tcpar_Method,$tcpar_Protocol);
	}
	elsif($tcpar_Condition eq 'Signal_Faulty'){
		if (defined $tcpar_Faulty_value){
			COM_setSignalState($tcpar_COMSignal,$tcpar_Faulty_value,$tcpar_Protocol);
		}
		else{
			COM_setSignalState($tcpar_COMSignal,'FAULTY',$tcpar_Protocol);
		}
	}
	elsif(($tcpar_Condition eq 'OutOfRangeValue') or ($tcpar_Condition eq 'RangeExceeded')or ($tcpar_Condition eq 'RangeDeceeded')){
		if (defined $tcpar_Faulty_value){
			COM_setSignalState($tcpar_COMSignal,$tcpar_Faulty_value,$tcpar_Protocol);
		}
		else{
			COM_setSignalState($tcpar_COMSignal,$tcpar_Condition,$tcpar_Protocol);
		}
	}
	else {
		S_set_error(" Condition mentioned is incorrect, hence test case is aborted");
		return 1;
	}

	S_teststep("Wait '$tcpar_TimeInvalidBeforeCrash_msec'", 'AUTO_NBR');
	S_wait_ms($tcpar_TimeInvalidBeforeCrash_msec);

	S_teststep("Inject a Crash", 'AUTO_NBR');
	CSI_TriggerCrash();

	S_wait_ms(2000);

	if (defined $tcpar_COMsignalsAfterCrash){
		foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
		{
			my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
			S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
			COM_setSignalState($signal,$dataOnCOM);
		}
	}

	S_teststep("Wait '$tcpar_wait_ms'", 'AUTO_NBR');
	S_wait_ms($tcpar_wait_ms);
	my $dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_".$tcpar_Crashcode;
	
	S_w2rep("Store Trace");
	my $fileName = "$main::REPORT_PATH/".S_get_TC_number()."_LIFT_network_trace.asc";
	my $tracePath;
	$tracePath = CA_trace_store($fileName) if (lc($tcpar_Protocol) =~ m/can/i);
	$tracePath = FR_trace_store($fileName) if (lc($tcpar_Protocol) =~ m/flexray/i);
	GEN_printLink($tracePath);

	S_wait_ms(2000);

	# Restart measurement after storage
    CA_trace_start() if (lc($tcpar_Protocol) =~ m/can/i);
    FR_trace_start() if (lc($tcpar_Protocol) =~ m/flexray/i);
	

	$edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();
	unless(defined $edrNumberOfEventsToBeStored){
		S_set_error("Not available in SYC - add or overwrite with Custlibrary Function");
		return;
	}

	S_w2rep("edrNumberOfEventsToBeStored=$edrNumberOfEventsToBeStored");
	S_teststep("Read all EDR records", 'AUTO_NBR');
    PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');

	if ( lc( $tcpar_read_NHTSAEDR) eq 'yes' ) {
		EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
								"CrashLabel" =>$tcpar_Crashcode."_".$tcpar_COMSignal,
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								"read_EDRType"=>'NHTSA')
	}
	if (lc($tcpar_read_CHINAEDR) eq 'yes'){
		$edrNumberOfEventsToBeStored=3;
		EDR_ReadAndStoreAllRecords ("DiagType" => $ChinaEDR_diagType,
								"CrashLabel" => $tcpar_Crashcode."_".$tcpar_COMSignal,
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								"read_EDRType"=>'CHINA');
	}

	S_w2rep("Reset manipulated COM signals");
	if (defined $manipulatedCOMsignals){
		foreach my $manipulatedSignal (keys %{$manipulatedCOMsignals})
		{
			my $originalValue = $manipulatedCOMsignals -> {$manipulatedSignal};
			S_w2rep("manSignal =$manipulatedSignal,Data to be sent=$originalValue");
			COM_setSignalState($manipulatedSignal, $originalValue);
		}

	}
	return 1;
}

sub TC_evaluation {

	my $verdict_eval='VERDICT_PASS';
	my $FinalVerdict='VERDICT_PASS';
	my $edidValue;

	for(my $recordNumber = 1; $recordNumber <= $tcpar_expected_nr_of_records; $recordNumber++)
	{
		my $dataElement = $record_handler -> GetDataElementEDID(  "EDIDnr" => $tcpar_EDID,
																  "RecordNumber" => $recordNumber,
																  "CrashLabel" =>$tcpar_Crashcode."_".$tcpar_COMSignal);

		S_w2log(1, "--------------------");
		S_w2rep( "\tEDID $tcpar_EDID ($dataElement) validation",'teal');
		S_w2log(1, "--------------------");
		
		my $range_Exceeded_Upper_Boundary = $record_handler -> GetRange_Exceeded_Upper_Boundary("CrashLabel" => $tcpar_Crashcode."_".$tcpar_COMSignal, "RecordNumber" => $recordNumber,"EDIDnr" => $tcpar_EDID);
		my $range_Exceeded_Lower_Boundary = $record_handler -> GetRange_Exceeded_Lower_Boundary("CrashLabel" => $tcpar_Crashcode."_".$tcpar_COMSignal, "RecordNumber" => $recordNumber,"EDIDnr" => $tcpar_EDID);
		S_w2rep("range_Exceeded_Upper_Boundary for EDID: $range_Exceeded_Upper_Boundary");
		S_w2rep("range_Exceeded_Lower_Boundary for EDID: $range_Exceeded_Lower_Boundary");
		
		if (not defined $tcpar_COMSignalAfterInvalidState ){
			if($range_Exceeded_Upper_Boundary ne "NotSpecified" and $range_Exceeded_Lower_Boundary eq "NotSpecified"){
				$tcpar_COMSignalAfterInvalidState =$range_Exceeded_Upper_Boundary;
			}
			elsif($range_Exceeded_Upper_Boundary ne "NotSpecified" and $range_Exceeded_Lower_Boundary ne "NotSpecified"){
				if ($tcpar_Faulty_value  =~ /^-/){
					$tcpar_COMSignalAfterInvalidState=$range_Exceeded_Lower_Boundary;
				}
				else {
					$tcpar_COMSignalAfterInvalidState=$range_Exceeded_Upper_Boundary;
				}
			
			}
			elsif($range_Exceeded_Upper_Boundary eq "NotSpecified" and $range_Exceeded_Lower_Boundary eq "NotSpecified" and (not defined $tcpar_COMSignalAfterInvalidState)) {
				S_set_error(" Expected State 'COMSignalAfterInvalidState' is not given, test is aborted");
				return;
			}
		}
		
		S_teststep("EDID $tcpar_EDID ($dataElement) in record $recordNumber", 'AUTO_NBR', "read_edid_data_$recordNumber"); #measurement 1
		if ($tcpar_COMSignalAfterInvalidState =~/0x/){
			my $detectedEDIDvalue = $record_handler -> GetRawEdidDataSamples( "EDIDnr" => $tcpar_EDID,
                                               "RecordNumber" => $recordNumber,
                                               "CrashLabel" => $tcpar_Crashcode."_".$tcpar_COMSignal,
                                               "FormatOption" => "HEX");
			unless(defined $detectedEDIDvalue) {
				S_set_error("No EDID data found for crash $tcpar_Crashcode, record $recordNumber. EDID cannot not be evaluated. Go to next record",110);
				return;
			}
			foreach my $edidValue (@{$detectedEDIDvalue})
			{
                $edidValue="0x".$edidValue;
				$verdict_eval = EVAL_evaluate_value ( "EDID_$tcpar_EDID\_Evaluation", $edidValue,'==',$tcpar_COMSignalAfterInvalidState );
			}
		}
		else {
			my $edidData = $record_handler -> GetDecodedEDID("CrashLabel" => $tcpar_Crashcode."_".$tcpar_COMSignal, "RecordNumber" => $recordNumber,"EDIDnr" => $tcpar_EDID );
			my $edidDataSamples = $edidData -> {"DataSamples"}; 
			
			unless(defined $edidDataSamples) {
				S_set_error("No EDID data samples could be obtained for EDID $tcpar_EDID in record $recordNumber!", 110);
				next;
			}
			foreach my $timeStampEDID (keys %{$edidDataSamples})
			{
			# get EDID value corresponding to time stamp
			$edidValue = $edidDataSamples -> {$timeStampEDID};
			if ($tcpar_COMSignalAfterInvalidState =~ /[a-zA-Z]/) {
				$verdict_eval = EVAL_evaluate_string ( "EDID_$tcpar_EDID\_Evaluation", $tcpar_COMSignalAfterInvalidState, $edidValue );	
			}
			elsif (not $tcpar_COMSignalAfterInvalidState  =~ /[a-zA-Z]/) {
				$verdict_eval = EVAL_evaluate_value ( "EDID_$tcpar_EDID\_Evaluation", $edidValue,'==',$tcpar_COMSignalAfterInvalidState );	
			}
			
			}
		}
		
		$FinalVerdict = 'VERDICT_FAIL' if $verdict_eval eq 'VERDICT_FAIL';	
		S_teststep_expected("'$tcpar_COMSignalAfterInvalidState'", "read_edid_data_$recordNumber");			#evaluation 1
		S_teststep_detected("$edidValue", "read_edid_data_$recordNumber");
	}

	return 1;
}

sub TC_finalization {
	
    S_w2rep("Reset manipulated COM signals");
	if ($tcpar_Condition eq 'Set_Qbit'){
		COM_setSignalState($tcpar_COMsignal_Qbit,'0',$tcpar_Protocol);
	}
	elsif($tcpar_Condition eq 'CRC_Error'){
		COM_RemoveCRCErrors([$tcpar_COM_Message],$tcpar_Protocol);
	}
	elsif($tcpar_Condition eq 'Signal_Faulty' or $tcpar_Condition eq 'OutOfRangeValue' or $tcpar_Condition eq 'RangeDeceeded'or $tcpar_Condition eq 'RangeExceeded'){
		COM_setSignalState($tcpar_COMSignal,$default_value,$tcpar_Protocol);
	}
	
	S_w2rep("Delete all object instances created...");
	foreach my $recordNumber (1..$edrNumberOfEventsToBeStored)
	{
		$record_handler -> DeleteRecord("CrashLabel" => $tcpar_Crashcode."_COM_Invalid_".$tcpar_Method, "RecordNumber" => $recordNumber);	
	}

	# Erase EDR
	PD_ClearCrashRecorder_NOERROR();
	S_wait_ms(2000);

	# Erase Fault memory
	PD_ClearFaultMemory();
	S_wait_ms(2000);

	# Read fault memory after clearing and erasing EDR
	PD_ReadFaultMemory();   

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}


1;
