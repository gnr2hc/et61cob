#### TEST CASE MODULE
package TC_SDID_Generic_Validation;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS_EDR_EDIDList_SupplierData> 
#TS version in DOORS: <0.16> 
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
use LIFT_PD;
use LIFT_can_access;
use GENERIC_DCOM;
use LIFT_labcar;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use LIFT_crash_simulation;
use LIFT_FaultMemory;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;
use Data::Dumper;

#necessary
#include further modules here
##################################

our $PURPOSE = "<This scripts validates the Algo sections update,Event Directions,Event Severity,Multi event Number reported in EDR for different crash scenarios>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SDID_Generic_Validation

=head1 PURPOSE

<This scripts validates the Algo sections update,Event Directions,Event Severity,Multi event Number reported in EDR for different crash scenarios>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Power on  ECU and Inject <Crashcode>

2.Wait for <WaitTime_ms> 

3. Read <Data _Element>corresponding to the <SDID>  in the latest entry of EDR through PD


I<B<Evaluation>>

1.

2. 

3. <Data _Element> should report the value equal to the value <Expected_Value_RawHex_Incident1>in the latest entry of EDR  and  <Expected_Value_RawHex_Incident2> in the older recored.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Expected_Value_RawHex_Incident1' => Expected value for the EDIDs in first record i.e most recent record
	SCALAR 'purpose' => This scripts validates the Algo sections update,Event Directions,Event Severity,Multi event Number reported in EDR for different crash scenarios
	SCALAR 'SDID' => Unique Supplier EDID ID.
	SCALAR 'Data_Element' => Data element name of the SDID.
	SCALAR 'WaitTime_ms' => wait time.
	SCALAR 'Crashcode' => The crash file to be injected.
	SCALAR 'Expected_Value_RawHex_Incident2' => Expected value for the EDIDs in second record i.e old record
	


=head2 PARAMETER EXAMPLES

	purpose	 = 'To validate the Algo sections update,Event Directions,Event Severity,Multi event Number reported in EDR '
	
	SDID= '<Fetch {SDID}>'
	Data_Element= '<Fetch {Object Text}>'
	WaitTime_ms=6000 #ms
	Crashcode='<Test Heading>'
	Expected_Value_RawHex_Incident2='none'
	DiagType  = 'ProdDiag' 
	ResultDB = 'EDR'
	COMsignalsAfterCrash = %()
	Expected_Value_RawHex_Incident1 ='0x00'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_SDID;
my $tcpar_Crashcode;
my $tcpar_Condition;
my $tcpar_powerCutOffTime;
my $tcpar_Expected_Value_RawHex_Incident2;
my $tcpar_Expected_Value_RawHex_Incident3;
my $tcpar_DiagType;
my $tcpar_ResultDB;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_Expected_Value_RawHex_Incident1;
my $tcpar_EDIDNr_Supplier;

################ global parameter declaration ###################
my $record_handler;
my $crash_handler;
my $tcpar_EDID;
my $recordIsThere;
my $edrNumberOfEventsToBeStored;
my $crashSettings;
#add any global variables here


###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_Condition =  S_read_optional_testcase_parameter( 'Condition' );
	$tcpar_powerCutOffTime =  S_read_mandatory_testcase_parameter( 'powerCutOffTime' ) if ($tcpar_Condition eq 'Autarky');
	$tcpar_SDID =  S_read_mandatory_testcase_parameter( 'SDID' );
	$tcpar_EDIDNr_Supplier =  S_read_optional_testcase_parameter( 'EDIDNr_Supplier');
	$tcpar_Crashcode =  S_read_mandatory_testcase_parameter( 'Crashcode' );
	$tcpar_Expected_Value_RawHex_Incident2 =  S_read_optional_testcase_parameter( 'Expected_Value_RawHex_Incident2' );
	if(not defined $tcpar_Expected_Value_RawHex_Incident2){
	    $tcpar_Expected_Value_RawHex_Incident2 = 'none';
	}
	$tcpar_Expected_Value_RawHex_Incident3 =  S_read_optional_testcase_parameter( 'Expected_Value_RawHex_Incident3' );
    if(not defined $tcpar_Expected_Value_RawHex_Incident3){
        $tcpar_Expected_Value_RawHex_Incident3 = 'none';
    }
	$tcpar_DiagType =  S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_ResultDB =  S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_COMsignalsAfterCrash =  S_read_optional_testcase_parameter( 'COMsignalsAfterCrash','byref');
	$tcpar_Expected_Value_RawHex_Incident1 =  S_read_mandatory_testcase_parameter( 'Expected_Value_RawHex_Incident1');
	if( defined $tcpar_EDIDNr_Supplier){
		$tcpar_EDID = EDR_Convert_SDID_To_Integer ($tcpar_SDID);
	}
	else{
		$tcpar_EDID = $tcpar_SDID;
	}
	
	S_w2log(3, "SDID $tcpar_SDID is EDID number $tcpar_EDID in record.");
	

	#check if the crash data  already available.
	$record_handler = EDR_init_RecordHandler();
	$recordIsThere = $record_handler -> IsRecordAvailable("CrashLabel" => $tcpar_Crashcode,
															"RecordNumber"      => 1 );
	if(not defined $recordIsThere){
		S_w2rep("crash will be injected and EDR data will be read in Simulation and Measurement");
		$recordIsThere=0;
	}
	return 1;
}
#---------------------------------------------------------------------------------------------
sub TC_initialization {
#--------------------------------------------------------------------------------------------
	#INTIALIZE RECORD AND CRASH HANDLER
	S_w2rep("Initialize Record and Crash Handler",'DodgerBlue');
	$record_handler = EDR_init_RecordHandler() || return;
	$crash_handler  = EDR_init_CrashHandler() || return;

    if(($recordIsThere == 0) or($tcpar_Condition eq 'Autarky')){
		S_w2log(1, "Power on ECU");
	    LC_ECU_On();
		S_wait_ms('TIMER_ECU_READY');

        GDCOM_init ();
        CA_trace_start();

		S_w2log(1, "Clear crash recorder");
	    PD_ClearCrashRecorder();
	    S_wait_ms(2000);

		S_w2log(1, "Clear fault memory");
	    PD_ClearFaultMemory();
	    S_wait_ms(2000);


		#--------------------------------------------------------------
        # CRASH PREPARATION
		S_w2log(1, "Prepare crash" );

	    # PREPARE CRASH AND INITIALIZE EQUIPMENT
		S_w2rep("Get crash settings for crash $tcpar_Crashcode");
	    my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode};
		$crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
		unless(defined $crashSettings) {
			S_set_error("Crash code $tcpar_Crashcode not defined in given result DB. Test case will be aborted.", 110);
			return;
		}

	    if( $main::opt_offline) {
			 $crashSettings -> { 'CRASHNAME' } = $tcpar_Crashcode;
	    }

		my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
		my $resultDB_Path = $resultDBDetails->{'PATH'};
		S_w2log(1, "Crashcode: $tcpar_Crashcode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");
		

		
	    S_w2log(1, "Set environments for crash as per result DB");
		CSI_PrepareEnvironment($crashSettings, 'init_complete');

        S_w2log(1, "Read and evaluate fault memory before stimulation");
        my $faultsBeforeStimulation_obj = LIFT_FaultMemory -> read_fault_memory('Bosch');
        my $faultsVerdict = $faultsBeforeStimulation_obj -> evaluate_faults({});
        return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

        S_w2log(1, "Turn off ECU to prepare crash");
	    LC_ECU_Off();
		S_wait_ms('TIMER_ECU_READY');

		#Prepare crash
		CSI_LoadCrashSensorData2Simulator( $crashSettings );
		S_wait_ms(2000);

	    LC_ECU_On();
		S_wait_ms('TIMER_ECU_READY');
		
	}
	return 1;
}

#---------------------------------------------------------------------------------------------------
sub TC_stimulation_and_measurement {
#-------------------------------------------------------------------------------------------------
	# Get a list of all crash labels for which EDR records were stored in
	# previous test cases
    # number of EDR records supported for Project
	$edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();

	unless(defined $edrNumberOfEventsToBeStored){
		S_set_error("Number of records to be stored in EDR not available in SYC - add or overwrite with Custlibrary Function");
		return;
	}
	
	if(($recordIsThere == 0) or($tcpar_Condition eq 'Autarky')){
		
		CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    	S_wait_ms(1000);
		S_teststep("Inject crash '$tcpar_Crashcode'", 'AUTO_NBR');
		CSI_TriggerCrash();
		if ($tcpar_Condition eq 'Autarky'){
				S_wait_ms($tcpar_powerCutOffTime);
				S_teststep_2nd_level("Cut power", 'AUTO_NBR');
				LC_ECU_Off();
				S_wait_ms('TIMER_ECU_OFF');
	
				S_teststep("Turn ECU on", 'AUTO_NBR');
				LC_ECU_On();
				S_wait_ms('TIMER_ECU_READY');
	    }
		else {
	    	S_wait_ms(20000); #wait time after crash (no autarky)
		}
			
		if (defined $tcpar_COMsignalsAfterCrash){
			foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
			{
				my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
				S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
				COM_setSignalState($signal,$dataOnCOM);
			}
		}

        $tcpar_Crashcode = $tcpar_Crashcode."_Autarky" if($tcpar_Condition eq 'Autarky');

		S_teststep("Read EDID '$tcpar_EDID' in all '$edrNumberOfEventsToBeStored' EDR records ", 'AUTO_NBR');
		my $dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_".$tcpar_Crashcode;
		PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');
		EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
								 	"CrashLabel" => $tcpar_Crashcode,
								 	"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								 	"StoragePath" => $dataStoragePath,
								 	);
									
		# add supplier section
		############################
        my $recordStructure_href = EDR_ReadEDR_Record_structure_info_from_mapping_NOERROR('Supplier',0,'Mapping_EDR','SUPPLIER_EDIDS');
        unless(defined $recordStructure_href){
            S_set_warning("No supplier section found in EDR mapping. Supplier EDIDs will not be added.\n".
                        "Evaluation might not be successful if EDID to be evaluated is in supplier section");
            return 1;
        }
        
        #--------------------------------------------------------------
        # PRINT SUPPLIER EDIDS   
        # ----------------------------------------------------------- 
        foreach my $recordNbr ( 1..$edrNumberOfEventsToBeStored )
		{
			my $recordAvailable = $record_handler -> IsRecordAvailable("CrashLabel" => $tcpar_Crashcode, "RecordNumber"=> $recordNbr);
            unless ($recordAvailable) {
                S_w2rep("Requested EDR record $recordNbr is empty. NO Supplier EDIDs will be added.");
                next;                
            }
			if ($recordAvailable and defined $tcpar_EDIDNr_Supplier)
			{

				my $recordData_aref = $record_handler -> GetRawEDID( "EDIDnr" => $tcpar_EDIDNr_Supplier,
																	"RecordNumber" => $recordNbr,
																	"CrashLabel" => $tcpar_Crashcode,);
				if(defined $recordData_aref){
					$record_handler -> AddCrashRecord(
													"RecordNumber" => $recordNbr,
													"CrashLabel"   => $tcpar_Crashcode.'_Supplier',
													"RecordStructureInfo" => $recordStructure_href,
													"RawDataGeneric" => $recordData_aref,);
					$record_handler -> PrintRawEDIDs( "RecordNumber" => $recordNbr,
												"CrashLabel" => $tcpar_Crashcode.'_Supplier',);													
				}
			}
			else
			{
				S_w2rep("Requested EDR record is empty.NO supplier edids will be printed.");
				next;
			}
 	    # next record	
	    }
	}

    return 1;
}
#-------------------------------------------------------------------------------
sub TC_evaluation {
#-------------------------------------------------------------------------------

    # Obtain expected value according to EDR storage order
    my $storageOrder = EDR_getStorageOrder();
    return unless(defined $storageOrder);

    if($storageOrder eq 'PhysicalOrder'){
       $storageOrder =  'MostRecentLast'; #same behavior as there is no overwriting
    }
	
	my $numberOfExpectedRecords;
    my $expected_Value_RawHex_Project;
	if($tcpar_Expected_Value_RawHex_Incident2 =~ m/none/){
		$expected_Value_RawHex_Project = {"Record_1" => $tcpar_Expected_Value_RawHex_Incident1};
		$numberOfExpectedRecords = 1;
	}
	elsif($tcpar_Expected_Value_RawHex_Incident3 =~ m/none/){
        $expected_Value_RawHex_Project  = { "Record_1" => $tcpar_Expected_Value_RawHex_Incident1,
                                            "Record_2" => $tcpar_Expected_Value_RawHex_Incident2}
                                                if($storageOrder eq 'MostRecentLast');
        $expected_Value_RawHex_Project  = { "Record_1" => $tcpar_Expected_Value_RawHex_Incident2,
                                            "Record_2" => $tcpar_Expected_Value_RawHex_Incident1}
                                                if($storageOrder eq 'MostRecentFirst');
        $numberOfExpectedRecords = 2;	    
	}
    else{
		$expected_Value_RawHex_Project  = {"Record_1" => $tcpar_Expected_Value_RawHex_Incident1,
		                                   "Record_2" => $tcpar_Expected_Value_RawHex_Incident2,
                                           "Record_3" => $tcpar_Expected_Value_RawHex_Incident3,}
		                                          if($storageOrder eq 'MostRecentLast');
        $expected_Value_RawHex_Project  = { "Record_1" => $tcpar_Expected_Value_RawHex_Incident3,
                                            "Record_2" => $tcpar_Expected_Value_RawHex_Incident2,
                                            "Record_3" => $tcpar_Expected_Value_RawHex_Incident1,}
                                                if($storageOrder eq 'MostRecentFirst');
		$numberOfExpectedRecords = 3;
    }
     
	my $evaluationCrashcode = $tcpar_Crashcode;
	if(defined $tcpar_EDIDNr_Supplier){
		$evaluationCrashcode = $tcpar_Crashcode.'_Supplier';
	}
	
    # check if number of expected matching.
	my $numberOfDetectedRecords = 0;
	my @detectedRecordNbrs;
	S_teststep("Number of stored records should be $numberOfExpectedRecords",'AUTO_NBR', 'read_stored_records');
	foreach my $recordNbr (1..$edrNumberOfEventsToBeStored)
	{
		my $recordAvailable = $record_handler -> IsRecordAvailable("CrashLabel" => $evaluationCrashcode, "RecordNumber"=> $recordNbr);
		if ($recordAvailable){
            $numberOfDetectedRecords++;
		    push(@detectedRecordNbrs, $recordNbr);
		}
	}
	S_teststep_expected("Expect $numberOfExpectedRecords records to be stored", 'read_stored_records');
	S_teststep_detected("Number of stored records is $numberOfDetectedRecords", 'read_stored_records');
	my $verdict= EVAL_evaluate_value("NumberOfRecords", $numberOfDetectedRecords,'==', $numberOfExpectedRecords);

    # validate EDID content
    return 1 unless($verdict eq "VERDICT_PASS");

    foreach my $recordNbr (@detectedRecordNbrs)
	{
	    
	     my $edidExists = $record_handler -> CheckEdidExistence("EDIDnr" => $tcpar_EDID."_".$recordNbr,
                                                          "RecordNumber" => $recordNbr,
                                                          "CrashLabel" => $evaluationCrashcode);

         my $individualRecord = $tcpar_EDID."_".$recordNbr;
         if($edidExists == 0){
             $individualRecord = $tcpar_EDID;
         }
		 EDR_Eval_evaluate_EDID_Raw_Hex ("EDIDnr" => $individualRecord,
														"RecordNumber" => $recordNbr,
														"CrashLabel" => $evaluationCrashcode,
														"Expected_Raw_Hex" => $expected_Value_RawHex_Project -> {"Record_$recordNbr"}) unless($main::opt_offline);
	}

	return 1;
}


#----------------------------------------------------------------------------
sub TC_finalization {
#----------------------------------------------------------------------------
	
	S_w2rep("Start test case finalization");

	if(($recordIsThere == 0) or($tcpar_Condition eq 'Autarky')){
	
		S_w2log(1, "Delete record objects");
		foreach my $record (1..$edrNumberOfEventsToBeStored)
		{
			$record_handler -> DeleteRecord("CrashLabel" => $tcpar_Crashcode, "RecordNumber" => $record);
			$record_handler -> DeleteRecord("CrashLabel" => $tcpar_Crashcode.'_Supplier', "RecordNumber" => $record);
		}

		PD_ReadFaultMemory();

		#Clearing crash recorder
		PD_ClearCrashRecorder();
		S_wait_ms(2000);

		#Erase Fault memory
		PD_ClearFaultMemory();
		S_wait_ms(2000);

		# Reset ECU
		PD_ECUreset();
		S_wait_ms('TIMER_ECU_READY');

		#Read fault memory after clearing and erasing EDR
		PD_ReadFaultMemory();

		LC_ECU_Off();
		S_wait_ms('TIMER_ECU_OFF');

	}

	S_w2rep("Testcase finalization is done");

	return 1;
}

	
1;
