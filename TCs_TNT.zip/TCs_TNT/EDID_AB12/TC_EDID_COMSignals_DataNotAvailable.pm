#### TEST CASE MODULE
package TC_EDID_COMSignals_DataNotAvailable;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use GENERIC_DCOM;
use LIFT_can_access;
use FuncLib_EDR_Framework;
use FuncLib_TNT_SYC_INTERFACE;
use Data::Dumper;
##################################

our $PURPOSE = "<To validate COM signal reported in EDR When CAN timeout or DLC error is created>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDID_COMSignals_DataNotAvailable

=head1 PURPOSE

<To validate COM signal reported in EDR When CAN timeout or DLC error is created>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Set the  <COMSignal> to default state

2. Wait for <WaitTimeTransmitSignal_msec> until the signal is transmitted on the COM bus

3. Create <Condition> on the  <COMSignal>

4. Wait <WaitTimeAfterCondition_msec>

5. Inject a Crash

6. Read <EDID> corresponding to COM signal


I<B<Evaluation>>

1. -

2. -

3. -

4. -

5. -

6. 

COMSignalValue corresponding to <COMSignalAfterTimeOut> should be reported in EDR


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'COMSignal' => 
	SCALAR 'purpose' => 
	SCALAR 'EDID' => 
	SCALAR 'WaitTimeTransmitSignal_msec' => 
	SCALAR 'WaitTimeAfterCondition_msec' => 
	HASH 'COMsignalsAfterCrash' => 
	SCALAR 'COMSignalAfterTimeOut' => 


=head2 PARAMETER EXAMPLES

	purpose		 = 'Validate COM signal  reported in EDR When CAN timeout  is created'
	
	EDID = '<Fetch {EDID}>'
	WaitTimeTransmitSignal_msec = '6000'
	WaitTimeAfterCondition_msec = '2000'
	COMsignalsAfterCrash = %()
	#As defined in CAN mapping file
	
	COMSignalAfterTimeOut= 'DataNotAvailable'#FF
	COMSignal = 'VSD_ESPReferenceVelocity'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_EDID;
my $tcpar_WaitTimeTransmitSignal_msec;
my $tcpar_WaitTimeAfterCondition_msec;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_ExpectedCOMSignalData;
my $tcpar_COM_Message;
my $tcpar_DiagType;
my $tcpar_ResultDB;
my $tcpar_Protocol;
my $tcpar_wait_ms ;
my $tcpar_Crashcode;
my $tcpar_COM_Signal;
my $tcpar_Condition;
my $tcpar_COM_Defaultstate;
my $tcpar_expected_nr_of_records;
my $tcpar_read_NHTSAEDR;
my $tcpar_read_CHINAEDR;

################ global parameter declaration ###################
#add any global variables here
my ($record_handler, $crash_handler, $crashSettings, $edrNumberOfEventsToBeStored,$ChinaEDR_diagType);

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_EDID =  S_read_mandatory_testcase_parameter( 'EDID' );
	$tcpar_DiagType =  S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_ResultDB =  S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_wait_ms =  S_read_mandatory_testcase_parameter( 'wait_ms' );
	$tcpar_Crashcode =  S_read_mandatory_testcase_parameter( 'Crashcode' );
	$tcpar_Condition =  S_read_mandatory_testcase_parameter( 'Condition' );
	$tcpar_expected_nr_of_records =  S_read_mandatory_testcase_parameter( 'expected_nr_of_records' );
	$tcpar_WaitTimeTransmitSignal_msec =  S_read_mandatory_testcase_parameter( 'WaitTimeTransmitSignal_msec' );
	$tcpar_WaitTimeAfterCondition_msec =  S_read_mandatory_testcase_parameter( 'WaitTimeAfterCondition_msec' );
	$tcpar_COMsignalsAfterCrash =  S_read_mandatory_testcase_parameter( 'COMsignalsAfterCrash','byref' );
	$tcpar_ExpectedCOMSignalData =  S_read_mandatory_testcase_parameter( 'ExpectedCOMSignalData' );
	$tcpar_COM_Message =  S_read_mandatory_testcase_parameter( 'COM_Message' );
	$tcpar_COM_Signal =  S_read_mandatory_testcase_parameter( 'COMSignal' );
	$tcpar_COM_Defaultstate =  S_read_optional_testcase_parameter( 'COM_Defaultstate' );
	$tcpar_Protocol =  S_read_mandatory_testcase_parameter( 'Protocol' );
	$tcpar_read_NHTSAEDR=S_read_optional_testcase_parameter('read_NHTSAEDR');
	$tcpar_read_CHINAEDR=S_read_optional_testcase_parameter('read_CHINAEDR');
	
	if(not defined $tcpar_read_CHINAEDR) {
		$tcpar_read_NHTSAEDR = 'yes';
		$tcpar_read_CHINAEDR = 'no';
	}
	else {
		$tcpar_read_NHTSAEDR = 'no';
		my $storageOrder = EDR_getStorageOrder();
		return unless(defined $storageOrder);

		if($storageOrder eq 'PhysicalOrder'){
			$ChinaEDR_diagType= 'Prodiag';  #In platform NHTSA and China EDR is read via proddiag
		}
		else {
			$ChinaEDR_diagType= 'CHINA_Payload';
		}
	}
	

	return 1;
}

sub TC_initialization {

	S_teststep("Test setup preparation", 'AUTO_NBR');

	#--------------------------------------------------------------
    # INITIALIZE RECORD AND CRASH HANDLER
    #    
	S_w2rep("Initialize Record Handler");
	$record_handler = EDR_init_RecordHandler() || return;

	#--------------------------------------------------------------
    # PREPARE CRASH AND INITIALIZE EQUIPMENT
    #
	S_w2rep("Get crash settings for crash $tcpar_Crashcode");
    my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode};
    $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
    unless(defined $crashSettings) {
        S_set_error("Crash $tcpar_Crashcode not available in result DB $tcpar_ResultDB. Test case aborted.");
        return;
    }
    

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log(1, "Crashcode: $tcpar_Crashcode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");

	CA_trace_start() if (lc($tcpar_Protocol) =~ m/can/i);
	FR_trace_start() if (lc($tcpar_Protocol) =~ m/flexray/i);	
	S_wait_ms(2000);

	S_w2log(1, "Power on ECU");
    LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');
	
	S_w2log(1, "Initialize CD ");
    GDCOM_init () ; # To fetch info for CD from mapping_diag

    S_w2log(1, "Set environments for crash as per result DB");
    CSI_PrepareEnvironment($crashSettings, 'init_complete');
    S_wait_ms(2000);

	S_w2log(1, "Clear crash recorder");
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(2000);

	S_w2log(1, "Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	S_w2log(1, "Read and evaluate fault memory before stimulation");
    my $faultsBeforeStimulation = PD_ReadFaultMemory();
    my $faultsVerdict = PD_evaluate_faults( $faultsBeforeStimulation, []);
    return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

	return 1;
}

sub TC_stimulation_and_measurement {
    #--------------------------------------------------------------
    # PREPARE CRASH INJECTION AND REPORT FILES
    #    
    S_teststep("Prepare crash", 'AUTO_NBR');
    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

    # Prepare crash
    CSI_LoadCrashSensorData2Simulator($crashSettings);

    # Power ON the ECU
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

	CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    S_wait_ms(1000);

    #--------------------------------------------------------------
    # START COM SIGNAL MANIPULATION
    #    
	S_teststep("Set the '$tcpar_COM_Signal' to default state given in can mapping OR signal state given in TS", 'AUTO_NBR');
	if (defined $tcpar_COM_Defaultstate){
		S_teststep_2nd_level (" Setting COM signal to  to $tcpar_COM_Defaultstate", 'AUTO_NBR');
		COM_setSignalState($tcpar_COM_Signal,$tcpar_COM_Defaultstate,$tcpar_Protocol);
	}
	else {
		S_teststep_2nd_level (" Setting COM signal to default value defined in Mapping_CAN", 'AUTO_NBR');
		COM_setSignalState($tcpar_COM_Signal,'DefaultValue',$tcpar_Protocol);
	}
	

	S_teststep("Wait for '$tcpar_WaitTimeTransmitSignal_msec' until the signal is transmitted on the COM bus", 'AUTO_NBR');
	S_wait_ms($tcpar_WaitTimeTransmitSignal_msec);
	
	S_teststep("Create $tcpar_Condition on'$tcpar_COM_Message'", 'AUTO_NBR');
	if ($tcpar_Condition eq "Timeout"){
		COM_stopMessages([$tcpar_COM_Message],$tcpar_Protocol);
	}
	elsif ($tcpar_Condition eq "DLCerror"){
		COM_CreateDLCErrors([$tcpar_COM_Message]);
	}
	elsif ($tcpar_Condition eq "BusOff"){
		CA_trace_stop() if (lc($tcpar_Protocol) =~ m/can/i);
		FR_trace_stop() if (lc($tcpar_Protocol) =~ m/flexray/i);
	}
	else{
		S_set_error("$tcpar_Condition is incorrect, it should be either Timeout or DLCerror. Test case aborted");
		return;
	}
    my $faultsAfterStimulation = PD_ReadFaultMemory();

	S_teststep("Wait '$tcpar_WaitTimeAfterCondition_msec'", 'AUTO_NBR');
	S_wait_ms($tcpar_WaitTimeAfterCondition_msec);

	S_teststep("Inject a Crash", 'AUTO_NBR');
    CSI_TriggerCrash();
	
	if (defined $tcpar_COMsignalsAfterCrash){
		foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
		{				
			my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
			S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
			COM_setSignalState($signal,$dataOnCOM);	
		}
	}
	
	S_teststep("Wait '$tcpar_wait_ms'", 'AUTO_NBR');
	S_wait_ms($tcpar_wait_ms);

	if($tcpar_Condition ne "BusOff"){
		my $fileName = "$main::REPORT_PATH/".S_get_TC_number()."_LIFT_network_trace.asc";
		my $tracePath;
		$tracePath = CA_trace_store($fileName) if (lc($tcpar_Protocol) =~ m/can/i);
		$tracePath = FR_trace_store($fileName) if (lc($tcpar_Protocol) =~ m/flexray/i);
		S_w2rep("Trace File: $tracePath");		
	}
 
	# Restart Rest bus simulation - is stopped when storing!
	S_wait_ms(2000);
	CA_trace_start() if (lc($tcpar_Protocol) =~ m/can/i);
	FR_trace_start() if (lc($tcpar_Protocol) =~ m/flexray/i);	
	if($tcpar_Condition eq "BusOff")
	{
		S_teststep("Reset ECU after restarting the bus simulation", 'AUTO_NBR');
	    LC_ECU_Off();
		S_wait_ms('TIMER_ECU_OFF');
	    LC_ECU_On();
		S_wait_ms('TIMER_ECU_READY');
	}
	
	S_teststep("Read all EDR records", 'AUTO_NBR');
	my $dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_".$tcpar_Crashcode;

	$edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();
	unless(defined $edrNumberOfEventsToBeStored){
		S_set_error("Not available in SYC - add or overwrite with Custlibrary Function");
		return;
	}
		 
	S_w2rep("edrNumberOfEventsToBeStored=$edrNumberOfEventsToBeStored");
	
	PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');								

	if ( lc( $tcpar_read_NHTSAEDR) eq 'yes' ) {
		EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
								"CrashLabel" => $tcpar_Crashcode."_".$tcpar_Condition,
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								"read_EDRType"=>'NHTSA')
	}
	if (lc($tcpar_read_CHINAEDR) eq 'yes'){
		$edrNumberOfEventsToBeStored=3;
		EDR_ReadAndStoreAllRecords ("DiagType" => $ChinaEDR_diagType,
								"CrashLabel" => $tcpar_Crashcode."_".$tcpar_Condition,
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath,
								"read_EDRType"=>'CHINA');
	}

	return 1;
}

sub TC_evaluation {
	my $edidValue;
	for(my $recordNumber = 1; $recordNumber <= $tcpar_expected_nr_of_records; $recordNumber++)
	{
		my $dataElement = $record_handler -> GetDataElementEDID(  "EDIDnr" => $tcpar_EDID,
																  "RecordNumber" => $recordNumber,
																  "CrashLabel" => $tcpar_Crashcode."_".$tcpar_Condition);
		
		S_teststep("EDID $tcpar_EDID ($dataElement) in record $recordNumber", 'AUTO_NBR',"read_edid_data_$recordNumber");				#measurement 1
		
		if ($tcpar_ExpectedCOMSignalData=~/0x/){
			my $detectedEDIDvalue = $record_handler -> GetRawEdidDataSamples( "EDIDnr" => $tcpar_EDID,
                                               "RecordNumber" => $recordNumber,
                                               "CrashLabel" => $tcpar_Crashcode."_".$tcpar_Condition,
                                               "FormatOption" => "HEX");
			unless(defined $detectedEDIDvalue) {
				S_set_error("No EDID data found for crash $tcpar_Crashcode, record $recordNumber. EDID cannot not be evaluated. Go to next record",110);
				return;
			}
			if(ref $detectedEDIDvalue ne 'ARRAY') {
				S_teststep_2nd_level("Read '$tcpar_EDID' ", 'AUTO_NBR',"read_edid_data_$recordNumber");
				$edidValue ="0x".$detectedEDIDvalue;
				EVAL_evaluate_value ( "EDID_$tcpar_EDID\_Evaluation", $edidValue,'==',$tcpar_ExpectedCOMSignalData );
				S_teststep_expected("'$tcpar_ExpectedCOMSignalData'", "read_edid_data_$recordNumber");
				S_teststep_detected("'$edidValue'", "read_edid_data_$recordNumber");
			}
			else{
				my $dataSample=1;
				foreach $edidValue (@{$detectedEDIDvalue})
				{
					S_teststep_2nd_level("Read '$tcpar_EDID' data sample $dataSample", 'AUTO_NBR',"read_edid_data_$recordNumber\_data_sample_$dataSample");
					$edidValue="0x".$edidValue;
					EVAL_evaluate_value ( "EDID_$tcpar_EDID\_Evaluation", $edidValue,'==',$tcpar_ExpectedCOMSignalData );
					S_teststep_expected("'$tcpar_ExpectedCOMSignalData'", "read_edid_data_$recordNumber\_data_sample_$dataSample");
					S_teststep_detected("'$edidValue'", "read_edid_data_$recordNumber\_data_sample_$dataSample");
					$dataSample++;
				}
			}	
		
		}
		
		else {
			my $edidData = $record_handler -> GetDecodedEDID("CrashLabel" => $tcpar_Crashcode."_".$tcpar_Condition, "RecordNumber" => $recordNumber,"EDIDnr" => $tcpar_EDID );
			unless(defined $edidData) {
				S_set_error("No EDID data found for crash $tcpar_Crashcode, record $recordNumber, return nothing", 110);
				return;
			}
			if(ref($edidData -> {"DataValue"}) ne 'ARRAY'){
				S_w2rep("EDID is static, i.e. there is only one data sample to validate");
				my $edidValue = $edidData -> {"DataValue"};
				EVAL_evaluate_string ( "EDID_$tcpar_EDID\_Evaluation", $tcpar_ExpectedCOMSignalData, $edidValue );
				S_teststep_expected("'$tcpar_ExpectedCOMSignalData'", "read_edid_data_$recordNumber");
				S_teststep_detected("'$edidValue'", "read_edid_data_$recordNumber");
			}
			else{
				my $edidDataSamples = $edidData -> {"DataSamples"}; 
				
				unless(defined $edidDataSamples) {
					S_set_error("No EDID data samples could be obtained for EDID $tcpar_EDID in record $recordNumber!", 110);
					next;
				}
				
				foreach my $timeStampEDID (sort {$a <=> $b} keys %{$edidDataSamples})
				{
					S_teststep_2nd_level("Read '$tcpar_EDID' at time $timeStampEDID s", 'AUTO_NBR',"read_edid_data_$recordNumber\_time_$timeStampEDID");				#measurement 1
					# get EDID value corresponding to time stamp
					my $edidValue = $edidDataSamples -> {$timeStampEDID};
					EVAL_evaluate_string ( "EDID_$tcpar_EDID\_Evaluation", $tcpar_ExpectedCOMSignalData, $edidValue );	
					S_teststep_expected("'$tcpar_ExpectedCOMSignalData'", "read_edid_data_$recordNumber\_time_$timeStampEDID");
					S_teststep_detected("'$edidValue'", "read_edid_data_$recordNumber\_time_$timeStampEDID");		
				}
			}
		}	
	}


	return 1;
}

sub TC_finalization {

	S_w2rep("Reset manipulated COM signals");
	if ($tcpar_Condition eq "Timeout"){
		COM_startMessages([$tcpar_COM_Message],$tcpar_Protocol);
	}
	elsif ($tcpar_Condition eq "DLCerror"){
		COM_RemoveDLCErrors([$tcpar_COM_Message]);
	}
	elsif($tcpar_Condition eq "BusOff"){
		S_w2log(2, "Bus off condition already reset.");
	}
	else{
		S_set_error("$tcpar_Condition is incorrect, it should be either Timeout or DLCerror. Test case aborted");
		return;
	}
	
	S_wait_ms(4000);

	S_w2rep("Delete all object instances created...");
	foreach my $recordNbr (1..$edrNumberOfEventsToBeStored){
        $record_handler -> DeleteRecord(  "CrashLabel" => $tcpar_Crashcode."_".$tcpar_Condition,
                                          "RecordNumber" => $recordNbr );
    }					  
	
	# Erase EDR
	PD_ClearCrashRecorder_NOERROR();
	S_wait_ms(2000);

	# Erase Fault memory
	PD_ClearFaultMemory();
	S_wait_ms(2000);

	# Read fault memory after clearing and erasing EDR
	PD_ReadFaultMemory();   

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}


1;
