#### TEST CASE MODULE
package TC_SDID_AutarkyTimeStamp;


#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS_EDR_EDIDList_SupplierData> 
#TS version in DOORS: <0.22> 
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_PD;
use LIFT_can_access;
use GENERIC_DCOM;
use LIFT_labcar;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;
use LIFT_FaultMemory;
use Data::Dumper;

##################################

our $PURPOSE = "<to validate the data element 'Autarky Time Stamp' recorded in EDR through PD>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SDID_AutarkyTimeStamp

=head1 PURPOSE

<to validate the data element "Autarky Time Stamp " recorded in EDR through PD>>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Power on ECU.

2.  If <CrashCondition> is Normal then Inject <Crashcode> If <CrashCondition> is AutarkyBeforeT0 then Inject <Crashcode> and soon after that power off the ECU i.e.before <CrashTimeZero_ms>
If <CrashCondition> is AutarkyAfterT0 then Inject <Crashcode> wait for <CrashTimeZero_ms+waitTime_ms> and power off ECU.

3. Read <Data _Element>  corresponding to the <SDID> in EDR through PD


I<B<Evaluation>>

1.

2. 

3. <Data _Element> should report the value <expAutarkyTime> in the record.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'SDID' => 
	SCALAR 'Data_Element' => 
	SCALAR 'purpose' => 
	SCALAR 'Crashcode' => 
	SCALAR 'CrashCondition' => 
	SCALAR 'CrashTimeZero_ms' => 
	SCALAR 'waitTime_ms' => 
	HASH 'DiagType' => 
	HASH 'NbrOfExpectedRecords' => 
	HASH 'ResultDB' => 
	SCALAR 'COMsignalsAfterCrash' => 


=head2 PARAMETER EXAMPLES

	purpose	 = 'to validate the data element "Autarky Time Stamp " recorded in EDR through PD'

	SDID= '<Fetch {SDID}>'
	Data_Element= '<Fetch {Object Text}>'
	Crashcode= 'Single_EDR_Side_above_8kph_NoDeployment;5'
	CrashCondition='<Test Heading>'
	CrashTimeZero_ms='139.26' #ms
	waitTime_ms = '0'
	DiagType  = 'ProdDiag'
	NbrOfExpectedRecords = '1'
	ResultDB = 'EDR'
	COMsignalsAfterCrash = %()

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_SDID;
my $tcpar_Crashcode;
my $tcpar_ResultDB;
my $tcpar_waitTime_ms;
my $tcpar_CrashCondition;
my $tcpar_CrashTimeZero_ms;
my $tcpar_EvalTolerance_abs;
my $tcpar_NbrOfExpectedRecords;
my $tcpar_DiagType;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_EDIDNr_Supplier;
my $tcpar_FilterTime_ms;

################ global parameter declaration ###################
#add any global variables here
my ($record_handler,
 	$tcpar_EDID,
	$edrNumberOfEventsToBeStored,
	$crashSettings,
	$crashTimeZero_href,
	$powerCutOffTime_ms,
	$crashInjectionRepetitions);
###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_SDID =  S_read_mandatory_testcase_parameter( 'SDID' );
	$tcpar_Crashcode =  S_read_mandatory_testcase_parameter( 'Crashcode' );
	$tcpar_CrashCondition =  S_read_mandatory_testcase_parameter( 'CrashCondition' );
	$tcpar_EDIDNr_Supplier =  S_read_optional_testcase_parameter( 'EDIDNr_Supplier' );
	$tcpar_ResultDB =  S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_DiagType =  S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_waitTime_ms =  S_read_mandatory_testcase_parameter( 'waitTime_ms' );
	$tcpar_CrashTimeZero_ms =  S_read_mandatory_testcase_parameter( 'CrashTimeZero_ms' );
	$tcpar_EvalTolerance_abs = S_read_mandatory_testcase_parameter('EvalTolerance_abs');
	$tcpar_FilterTime_ms = S_read_mandatory_testcase_parameter('FilterTime_ms');
	$tcpar_COMsignalsAfterCrash =  S_read_optional_testcase_parameter( 'COMsignalsAfterCrash','byref');
	$tcpar_EDID = EDR_Convert_SDID_To_Integer ($tcpar_SDID);
	if(not defined $tcpar_EDID){
		S_w2rep("Converting DOORS SDID to integer was not successful. Test case can't be performed.");
		return;
	}

	if(not defined $tcpar_EDIDNr_Supplier){
		S_w2rep("Setting the Supplier EDID number as 999 by default");
		$tcpar_EDIDNr_Supplier = 999;
	}

    $edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();
    unless(defined $edrNumberOfEventsToBeStored){
        S_set_error("Number of records to be stored in EDR not available in SYC - add or overwrite with Custlibrary Function");
        return;
    }

	($tcpar_NbrOfExpectedRecords, $crashTimeZero_href) = EDR_getCrashTimeZeroPerRecord ($tcpar_CrashTimeZero_ms);
	if($tcpar_NbrOfExpectedRecords == 1){
	    $crashInjectionRepetitions = $edrNumberOfEventsToBeStored;
	    foreach my $record(1..$edrNumberOfEventsToBeStored){
	        $crashTimeZero_href -> {"Record_$record"} = $crashTimeZero_href -> {"Record_1"};
	    }
	    $tcpar_NbrOfExpectedRecords = $edrNumberOfEventsToBeStored;
	}
	else{
	    $crashInjectionRepetitions = 1; # no repetition
	}
	
	return 1;
}

sub TC_initialization {
	#--------------------------------------------------------------
    # INITIALIZE RECORD HANDLER
    #    
	S_w2rep("Initialize Record Handler");
	$record_handler = EDR_init_RecordHandler() || return;

    S_w2log(1, "Start CAN trace");
    GDCOM_init () ; # To fetch info for CD from mapping_diag
    CA_trace_start();

	S_w2log(1, "Power on ECU");
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

	S_w2log(1, "Clear crash recorder");
    PD_ClearCrashRecorder();
    S_wait_ms(2000);

	S_w2log(1, "Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	#--------------------------------------------------------------
    # CRASH PREPARATION
	S_w2log(1, "Prepare crash" );

	# PREPARE CRASH AND INITIALIZE EQUIPMENT
	S_w2rep("Get crash settings for crash $tcpar_Crashcode");
	my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode};
	$crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
	if(not defined $crashSettings) {
		S_set_error("Crash code $tcpar_Crashcode not defined in given result DB. Test case will be aborted.", 110);
		return;
	}

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log(1, "Crashcode: $tcpar_Crashcode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");
	
	S_w2log(1, "Set environments for crash as per result DB");
	CSI_PrepareEnvironment($crashSettings,'init_complete');

    S_w2log(1, "Read and evaluate fault memory before stimulation");
    my $faultsBeforeStimulation_obj = LIFT_FaultMemory -> read_fault_memory('Bosch');
    my $faultsVerdict = $faultsBeforeStimulation_obj -> evaluate_faults({});
    return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

    S_w2log(1, "Turn off power and load sensor data to simulator");
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}

sub TC_stimulation_and_measurement {

	#--------------------------------------------------------------
    # CRASH INJECTION
    #---------------------------------------------------------------
	
	foreach my $iteration (1..$crashInjectionRepetitions){
        S_teststep("Inject crash '$tcpar_Crashcode' for record $iteration", 'AUTO_NBR');
        
        #Prepare crash  
        S_teststep_2nd_level("Prepare crash and power up", 'AUTO_NBR');
        CSI_LoadCrashSensorData2Simulator( $crashSettings );
    
        LC_ECU_On();
        S_wait_ms('TIMER_ECU_READY');
        
        CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
   		S_wait_ms(1000);
    
        if($tcpar_CrashCondition eq 'Normal'){
            S_teststep_2nd_level("Trigger crash, no autarky", 'AUTO_NBR');
            CSI_TriggerCrash();
            S_teststep_2nd_level("Wait 10 seconds", 'AUTO_NBR');
            S_wait_ms(10000);#wait time after crash
            $powerCutOffTime_ms = 'NoPowerCutOff';
            S_teststep_2nd_level("Cut power to prepare for next crash", 'AUTO_NBR');            
            LC_ECU_Off();
            S_wait_ms('TIMER_ECU_OFF');            
        }
        elsif ($tcpar_CrashCondition eq 'AutarkyBeforeT0') {
            S_teststep_2nd_level("Cut power", 'AUTO_NBR');
            LC_ECU_Off();
            S_teststep_2nd_level("Trigger crash", 'AUTO_NBR');
            $powerCutOffTime_ms = 0;
            CSI_TriggerCrash();
            S_wait_ms('TIMER_ECU_OFF');
        }
        elsif ($tcpar_CrashCondition eq 'AutarkyAfterT0') {
            $powerCutOffTime_ms = $crashTimeZero_href -> {'Record_1'} + $tcpar_waitTime_ms;
            S_teststep_2nd_level("Trigger crash", 'AUTO_NBR');
            CSI_TriggerCrash();
            S_teststep_2nd_level("Wait $powerCutOffTime_ms ms", 'AUTO_NBR');
            S_wait_ms($powerCutOffTime_ms);
            S_teststep_2nd_level("Cut power", 'AUTO_NBR');
            LC_ECU_Off();
            S_wait_ms('TIMER_ECU_OFF');
        }
        else{
            S_set_error("CrashCondition should be either 'Normal','AutarkyBeforeT0' or 'AutarkyAfterT0'.");
            return 0;
        }    
	}
	

    S_teststep("Turn ECU on", 'AUTO_NBR');
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');
	
	if (defined $tcpar_COMsignalsAfterCrash){
	    S_w2log(1, "Send post crash COM signals");
    	foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
    	{
    		my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
    		S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
    		COM_setSignalState($signal,$dataOnCOM);
    	}
	}

	S_teststep("Read EDID '$tcpar_EDID'  EDR records ", 'AUTO_NBR');
    PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');
	my $dataStoragePath = "$main::REPORT_PATH/".$tcpar_Crashcode;
    $tcpar_Crashcode = $tcpar_Crashcode."_".$tcpar_CrashCondition;
	EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
							 	"CrashLabel" => $tcpar_Crashcode,
							 	"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
							 	"StoragePath" => $dataStoragePath,
							 	);
	# add supplier section
	############################
	S_teststep_2nd_level("Extract and parse supplier data", 'AUTO_NBR');
	my $recordStructureSupplier_href = EDR_ReadEDR_Record_structure_info_from_mapping_NOERROR('Supplier',0,'Mapping_EDR','SUPPLIER_EDIDS');
	if(not defined $recordStructureSupplier_href){
        S_set_warning("Supplier EDID section is not available in EDR mapping.\n".
        "Generate mapping newly with this section if the EDID to be evaluated is part of Supplier section");
        return 1;
	}

	foreach my $recordNbr (1..$edrNumberOfEventsToBeStored)
	{
		my $recordAvailable = $record_handler -> IsRecordAvailable("CrashLabel" => $tcpar_Crashcode, "RecordNumber"=> $recordNbr);
		next unless($recordAvailable);

		my $recordData_aref = $record_handler -> GetRawEDID( "EDIDnr" => $tcpar_EDIDNr_Supplier,
															"RecordNumber" => $recordNbr,
															"CrashLabel" => $tcpar_Crashcode,);

		$record_handler -> AddCrashRecord(  "RecordNumber" => $recordNbr,
											"CrashLabel"   => $tcpar_Crashcode.'_Supplier',
											"RecordStructureInfo" => $recordStructureSupplier_href,
											"RawDataGeneric" => $recordData_aref,);
		$record_handler -> PrintRawEDIDs( "RecordNumber" => $recordNbr,
											"CrashLabel" => $tcpar_Crashcode.'_Supplier',);
	}

	return 1;
}

sub TC_evaluation {
	#--------------------------------------------------------------
    # NUMBER OF EXPECTED RECORDS
    #--------------------------------------------------------------
	foreach my $recordNbr (1..$tcpar_NbrOfExpectedRecords)
	{
		my $dataElement = $record_handler -> GetDataElementEDID("EDIDnr" => $tcpar_EDID,
														  "RecordNumber" => $recordNbr,
														  "CrashLabel" => $tcpar_Crashcode.'_Supplier');

        S_teststep("Validate EDID $tcpar_EDID ($dataElement), record $recordNbr", 'AUTO_NBR', "EDID_$tcpar_EDID\_Record_$recordNbr");

        my $edidExists = $record_handler -> CheckEdidExistence("EDIDnr" => $tcpar_EDID."_".$recordNbr,
                                                              "RecordNumber" => $recordNbr,
                                                              "CrashLabel" => $tcpar_Crashcode.'_Supplier');

        my $individualRecord = $tcpar_EDID."_".$recordNbr;
        if($edidExists == 0){
            $individualRecord = $tcpar_EDID;
        }

        my $decodedData = $record_handler -> GetDecodedEDID( "EDIDnr" => $individualRecord, 
                                                     "RecordNumber" => $recordNbr, 
                                                     "CrashLabel" => $tcpar_Crashcode.'_Supplier');

		my $detected_autarky_time = $decodedData -> {"DataValue"};
		my $unit = $decodedData -> {"ValueUnit"};

		unless(defined $detected_autarky_time) {
      		S_set_error("No EDID data samples could be obtained for EDID $tcpar_EDID in record $recordNbr!", 110) unless($main::opt_offline);
			next;
		}
		
		# Get expected autarky time
		my $thisEventT0 = $crashTimeZero_href -> {"Record_$recordNbr"};

		my $expectedAutarkyTime_ms;
		if($powerCutOffTime_ms eq 'NoPowerCutOff'){
            EVAL_evaluate_value ( "EDID_$tcpar_EDID\_Evaluation", $detected_autarky_time,'==', 0);
            S_teststep_expected("0 (No Autarky)", "EDID_$tcpar_EDID\_Record_$recordNbr");
            S_teststep_detected("$detected_autarky_time", "EDID_$tcpar_EDID\_Record_$recordNbr");
		}
		elsif($tcpar_CrashCondition eq 'AutarkyBeforeT0'){
            EVAL_evaluate_value ( "EDID_$tcpar_EDID\_Evaluation", $detected_autarky_time,'==', 0.5);		    
            S_teststep_expected("0.5 ms (smallest possible time)", "EDID_$tcpar_EDID\_Record_$recordNbr");
            S_teststep_detected("$detected_autarky_time ms", "EDID_$tcpar_EDID\_Record_$recordNbr");
		}
		else{
            $expectedAutarkyTime_ms = $powerCutOffTime_ms - $thisEventT0 + $tcpar_FilterTime_ms;
            $expectedAutarkyTime_ms = 0 if($expectedAutarkyTime_ms < 0);		    
            EVAL_evaluate_value ( "EDID_$tcpar_EDID\_Evaluation", $detected_autarky_time,'==', $expectedAutarkyTime_ms,$tcpar_EvalTolerance_abs,'absolute');
            S_teststep_expected("$expectedAutarkyTime_ms ms (+/- $tcpar_EvalTolerance_abs ms)", "EDID_$tcpar_EDID\_Record_$recordNbr");
            S_teststep_detected("$detected_autarky_time ms", "EDID_$tcpar_EDID\_Record_$recordNbr");
		}
    }

	return 1;
}

sub TC_finalization {

    S_w2rep("Start test case finalization...");

	# Erase EDR
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(2000);

	# Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	# Read fault memory after clearing and erasing EDR
    PD_ReadFaultMemory();

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

	S_w2rep("Clean up record handler");
    foreach my $recordNumber (1..$edrNumberOfEventsToBeStored)
    {
        $record_handler -> DeleteRecord("CrashLabel" => $tcpar_Crashcode, "RecordNumber" => $recordNumber);
        $record_handler -> DeleteRecord("CrashLabel" => $tcpar_Crashcode."_Supplier", "RecordNumber" => $recordNumber);
    }

	return 1;
}


1;
