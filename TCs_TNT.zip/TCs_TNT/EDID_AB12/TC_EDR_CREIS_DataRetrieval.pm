#### TEST CASE MODULE
package TC_EDR_CREIS_DataRetrieval;
#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
###-------------------------------

##################################
#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general;
use LIFT_evaluation;
use LIFT_LCT;
use FuncLib_EDR_Framework;
use EDR_Framework::FuncLib_EDR_Offline_xmlLogging;
use File::Basename;
use Data::Dumper;
use XML::LibXML;
use LIFT_MDSRESULT;
use FuncLib_SYC_INTERFACE;
use LIFT_CSM;
use LIFT_crash_simulation;
use constant MILLISEC_TO_SECOND => 0.001;
use constant SECOND_TO_MILLISEC => 1000;
##################################
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_CrashDataRetrieval  $Revision: 1.9 $

requires test setup with
	- Quate
	- MDS data base
	- LCT 64
	- CANoe
	- TSG4

default state is faultfree ECU powered ON

=head1 PURPOSE

inject crashes and store all data in record and crash handler for use in later test cases

=head1 TESTCASE DESCRIPTION 

    [initialisation]
    initialize record handler
    initialize crash handler
    clear crash recorder and fault memory

    [stimulation & measurement]
	1. start LCT measurement
    2. inject crash
    3. stop LCT measurement
    4. read all crash records and add to record handler
    5. get all sensor data and add to crash handler
    6. add all fire times to crash handler

    [evaluation]
    1. no evaluation required

    [finalisation]
    1. clear fault memory
    2. clear crash recorder
    3. reset ECU

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

    purpose --> Purpose of the test case
    crashtype --> Type/name of crash. Name must be defined in Mapping_EDR.pm!
  	DiagType --> AKLV, Ford, ProdDiag, or Geely
	StorageOptions --> Import COM signals, sensor data, fire times, switches depending on this parameter
	StoragePath --> In this path, the test case will look for a folder with the same name as the crashtype
	                In that folder, the stored crash data is expected

=head2 PARAMETER EXAMPLES

    [TC_EDR_CrashDataRetrieval.xxx]
	# From here on: applicable Lift Default Parameters
	purpose = 'retrieve crash data'
	crashtype = 'Rollover'
	DiagType = 'AKLV'
	StorageOptions = %('COM_Signals' => 'no', 'SensorData' => 'yes', 'FireTimes' => 'yes', 'SwitchStates' => 'yes')
	StoragePath = 'C:\TurboLIFT\AB12\CrashData\'

=cut
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_CrashName;
my $tcpar_IterationNumber;
my $tcpar_CrashNumber;
my $tcpar_EnvironmentState;
my $tcpar_MDSResult;
my $tcpar_CREIS_xml_filepath;
my $tcpar_XML_Summary_filepath;
my $tcpar_COM_Protocol;
################ global parameter declaration ###################
#add any global variables here
my ( $record_handler, $crash_handler, $crashLabel, $mdb_file, );
our $PURPOSE;
our $TC_name = "TC_EDR_CREIS_DataRetrieval";

#-------------------------------------------------------------------------------
sub TC_set_parameters {

    #-------------------------------------------------------------------------------
    S_w2rep("Read testcase parameters");
    $tcpar_CrashName          = S_read_mandatory_testcase_parameter('CrashName');
    $tcpar_IterationNumber    = S_read_mandatory_testcase_parameter('IterationNumber');
    $tcpar_CrashNumber        = S_read_mandatory_testcase_parameter('CrashNumber');
    $tcpar_EnvironmentState   = S_read_mandatory_testcase_parameter('EnvironmentState');
    $tcpar_CREIS_xml_filepath = S_read_mandatory_testcase_parameter('CREISTest_summary_XML');
    $tcpar_MDSResult          = S_read_mandatory_testcase_parameter('MDSDB');
    $tcpar_COM_Protocol		  = S_read_mandatory_testcase_parameter('COM_Protocol');
    $mdb_file                 = basename($tcpar_MDSResult);
    $crashLabel               = $tcpar_CrashName . "_" . $tcpar_CrashNumber;

    $tcpar_XML_Summary_filepath = S_read_optional_testcase_parameter('EDR_EvalSummary_XML');
	if(not defined $tcpar_XML_Summary_filepath){
		my $directory = dirname($tcpar_CREIS_xml_filepath);
		$tcpar_XML_Summary_filepath = $directory.'\\EDR_Eval_Summary.xml';
		S_w2rep("XML Summary will be printed in default location: $tcpar_XML_Summary_filepath");
	}
    return 1;
}

#-------------------------------------------------------------------------------
sub TC_initialization {

    #-------------------------------------------------------------------------------
    #--------------------------------------------------------------
    # INITIALIZE RECORD AND CRASH HANDLER
    #
    S_w2rep("Initialize Record and Crash Handler");
    $record_handler = EDR_init_RecordHandler() || return;
    $crash_handler  = EDR_init_CrashHandler()  || return;
    MDSRESULT_Init();
    CSM_init( { 'LocalWorkingArea_Path' => dirname($tcpar_CREIS_xml_filepath) } );

    my $localWorkingAreaDirectory = dirname($tcpar_CREIS_xml_filepath);

    return 1;
}

#-------------------------------------------------------------------------------
sub TC_stimulation_and_measurement {

    #-------------------------------------------------------------------------------
    #--------------------------------------------------------------
    # SEARCH AND SETUP CSM CONTAINER
    #
    my $mdbFileName = fileparse($mdb_file);
    S_w2log(3, "MDB file name short: $mdbFileName\n");
    S_teststep( " CSM search container in Local Working Area via keywords\n", "AUTO_NBR" );
    my $query_href_match = {
                            'keywords_fully' => [
                                "CrashNumber::$tcpar_CrashNumber", "State::$tcpar_EnvironmentState",
                                "Iteration::$tcpar_IterationNumber"
                            ],
                            'keywords_partially' => [$mdbFileName],
    };
    my @query_result_keywords_match = CSM_search_local_container_NOERROR_NOHTML($query_href_match);
    S_w2rep("Results matching: @query_result_keywords_match");
    if ( @query_result_keywords_match == 0 ) {
        S_set_error(
                     "No crash found in given CREIS summary with:\n"
                       . "Crash name = $tcpar_CrashName,\n"
                       . "Crash number = $tcpar_CrashNumber,\n"
                       . "Iteration = $tcpar_IterationNumber",
                     10
        );    #abort testlist
        return;
    }
    if ( @query_result_keywords_match > 1 ) {
        S_set_error(
                     "More than one crash found in CREIS summary with:\n"
                       . "Crash name = $tcpar_CrashName,\n"
                       . "Crash number = $tcpar_CrashNumber,\n"
                       . "Iteration = $tcpar_IterationNumber",
                     112
        );    #abort testlist
        return;
    }
    S_teststep( "CSM get a list of all user files stored in container", "AUTO_NBR" );
    my $container_id = $query_result_keywords_match[0];

    # get container header object, user file IDs and project data
    my $containerHeader_obj     = CSM_get_container($container_id);
    my $found_userfile_ids_aref = $containerHeader_obj->getContentIdentifiers('UserFile');

	my $crashDetails_href = {
		'CrashName' => $tcpar_CrashName,
		'CrashNumber' => $tcpar_CrashNumber,
		'Iteration' => $tcpar_IterationNumber,
		'EnvironmentState' => $tcpar_EnvironmentState,
	};


    #--------------------------------------------------------------
    # GET CRASH RECORDS
    #
    S_teststep( "Get all stored records via ProdDiag and store in record handler", 'AUTO_NBR' );

    # Get number of records in EDR
    S_teststep_2nd_level( "Get number of stored records in EDR from SYC", 'AUTO_NBR' );
    my ( $result, $numberOfRecords ) = SYC_EDR_get_NumberOfEventsToBeStored();
    unless ($result) {
        S_set_error(
              "Number of records could not be obtained from SYC_EDR_get_NumberOfEventsToBeStored()",
              112 );
        return;
    }
    S_teststep_2nd_level( "Get record structure info from EDR mapping", 'AUTO_NBR' );
    my $recordStructure_href = EDR_ReadEDR_Record_structure_info_from_mapping( 'ProdDiag', 4 )
      ;    #Data start from byte index 4;
    my $edrRecordObtained = 0;
	my $deploymentRecordNumber = _get_DeploymentRecordNumber_ForMultiEvent($tcpar_CrashName);
    foreach my $content_ID_userfile ( @{$found_userfile_ids_aref} ) {
        S_w2log( 2, " CSM get userfile $content_ID_userfile ( without extraction) \n" );
        my $userfile_object = CSM_get_userfile(    #    without extracting
            $container_id,
            $content_ID_userfile,
            { extract => 0 },                      # option extract : 0 - no ; 1 - yes
        );
        my $userfile_description = $userfile_object->getDescription();
        S_w2log( 2, " $userfile_description file found \n" );
        next unless $userfile_description eq "edrReader";

        S_teststep_2nd_level( "Extract EDR record from container", 'AUTO_NBR' );
        $userfile_object = CSM_get_userfile(       #    now with extracting (is default)
                                             $container_id,
                                             $content_ID_userfile,
        );

        my $pdDumpFile = $userfile_object->getFilename_long();
        S_w2rep("$pdDumpFile");
        $pdDumpFile =~ m/.*(\d\d).txt/;
        my $recordNbr = hex($1) + 1;
        if(defined $deploymentRecordNumber){
        	next unless($recordNbr == $deploymentRecordNumber);
        	S_teststep_2nd_level("Crash scenario has more than 1 record, where 1 is a deployment.\n".
        						 "Given record $recordNbr contains the deployment incident - only this will be evaluated.\n".
        						 "Record $recordNbr will be mapped to record nbr 1 in record handler for evaluation!");
        	$recordNbr = 1;
        }
        S_teststep_2nd_level(
                           "Get record data for record $recordNbr from stored file ('$pdDumpFile')",
                           'AUTO_NBR' );
        my ( $recordData_aref, $metaData_href ) = EDR_get_ProdDiagResponseFromDump($pdDumpFile);
        unless ( defined $recordData_aref ) {
            S_w2rep(
                "No valid response was retrieved for request of record $recordNbr. Try next slot.");
            next;
        }
        if($recordData_aref->[1] eq '127' and $recordData_aref->[3] eq '85') {
            S_w2rep("Requested record is empty. Will not be added to record handler.");
            next;
        }

        $edrRecordObtained++;

        S_teststep_2nd_level( "Add obtained crash record $recordNbr to record handler",
                              'AUTO_NBR' );
        S_w2rep("Crash record meta data:");
        foreach my $dataKey (sort keys %{$metaData_href}){
            my $value = $metaData_href -> {$dataKey};
            S_w2rep("$dataKey: $value");
        }
        $record_handler->AddCrashRecord(
                                         "RecordNumber"        => $recordNbr,
                                         "CrashLabel"          => $crashLabel,
                                         "RecordStructureInfo" => $recordStructure_href,
                                         "RawDataGeneric"      => $recordData_aref,);

        if ($record_handler->IsRecordAvailable( "RecordNumber" => $recordNbr,
                                                 "CrashLabel"   => $crashLabel ))
        {
            S_teststep_2nd_level(
                        "Print added crash record in raw decimal and hex as well as decoded format",
                        'AUTO_NBR' );
            $record_handler->PrintRawEDIDs( "RecordNumber" => $recordNbr,
                                            "CrashLabel"   => $crashLabel, );
            $record_handler->PrintRawEDIDs(
                                            "RecordNumber" => $recordNbr,
                                            "CrashLabel"   => $crashLabel,
                                            "FormatOption" => 'HEX'
            );
            $record_handler->PrintDecodedEDIDs( "RecordNumber" => $recordNbr,
                                                "CrashLabel"   => $crashLabel, );                                                
        }
    }

    unless($edrRecordObtained){
        S_set_error("Given container does not contain EDR records. Possible issues:\n".
        " - CREIS not executed with EDR storage option\n".
        " - Noise crashs which does not reach EDR storage threshold", 112);
        FLEDR_XML_addNonEvaluatedCrash($tcpar_XML_Summary_filepath, $crashDetails_href, "No EDR Records");
        return 1;
    }
	if($edrRecordObtained > 1){
		S_set_error("More than one record detected for crash, and it is not clear which is the deployment record!\n"
					."This can currently not be evaluated.\n"
					."You can specify the deployment incident of a multi-event in the mapping 'EDR_Offline_CrashDetails'!", 112);
        FLEDR_XML_addNonEvaluatedCrash(	$tcpar_XML_Summary_filepath,
        								$crashDetails_href,
        								"$edrRecordObtained EDR records (T0 can't be obtained)");			
		return 1;
	}

    #--------------------------------------------------------------
    # GET CRASH DATA FROM MDS
    #
    # ************** 1 - SENSOR DATA **************
    S_teststep( "Get stored physical sensor values and add to crash handler", 'AUTO_NBR' );
    my $crashDetailsForSensorData_href =
      { 'RESULTDB' => $tcpar_MDSResult, 'CRASHINDEX' => $tcpar_CrashNumber, "MDSTYPE" => "MDSNG" };
    EDR_addSensorDataToCrashHandler( "CrashLabel" => $crashLabel,
                                     "Crash_href" => $crashDetailsForSensorData_href );

    #--------------------------------------------------------------
    # GET CRASH DATA FROM CREIS XML
    #

    # Get measurement zip folder name from CREIS summary
    S_teststep_2nd_level( "Load CREIS XML to get switch settings during crash", 'AUTO_NBR' );
    my ( $base, $path, $type ) = fileparse($tcpar_CREIS_xml_filepath);
    my $parser = XML::LibXML->new();

    # important for formatting
    $parser->keep_blanks(0);

    # load the existing XML file
    my $creisSummaryXML = $parser->load_xml( location => $tcpar_CREIS_xml_filepath );

    # get the reference to root element
    my $rootElement = $creisSummaryXML->documentElement;
    my $xpc         = XML::LibXML::XPathContext->new($rootElement);
    S_teststep_2nd_level( "Search for '$crashLabel' in CREIS XML", 'AUTO_NBR' );

    # get crash node for given crash (must be unique)
    my @crashNodes;
    if ( defined $tcpar_EnvironmentState ) {
        @crashNodes = $xpc->findnodes(
"./Crash[\@id='$tcpar_CrashNumber' and \@iteration='$tcpar_IterationNumber' and \@envstate='$tcpar_EnvironmentState']"
        );
    }
    else {
        @crashNodes = $xpc->findnodes(
                     "./Crash[\@id='$tcpar_CrashNumber' and \@iteration='$tcpar_IterationNumber']");
    }
    my $numberOfNodes = @crashNodes;
    S_w2rep("$numberOfNodes nodes found for crash $tcpar_CrashNumber");
    if ( $numberOfNodes == 0 ) {
        S_set_error(
                     "No crash found in given CREIS summary with:\n"
                       . "Crash name = $tcpar_CrashName,\n"
                       . "Crash number = $tcpar_CrashNumber,\n"
                       . "Iteration = $tcpar_IterationNumber",
                     112
        );
        return;
    }
    elsif ( $numberOfNodes > 1 ) {
        S_set_error(
                     "More than one crash found in CREIS summary with:\n"
                       . "Crash name = $tcpar_CrashName,\n"
                       . "Crash number = $tcpar_CrashNumber,\n"
                       . "Iteration = $tcpar_IterationNumber",
                     112
        );
        return;
    }
    my $thisCrashNode = $crashNodes[0];

    # ************** 1 - SWITCH STATES **************
    S_teststep( "Get switch states during crash", 'AUTO_NBR' );
    my $crashSwitchStates;
    my @staticSwitchNodesConfigured = $xpc->findnodes(
"./Settings/StaticEnvironment[contains(\@name, 'Switch') and contains(\@name, 'Configured')]"
    );

    # Extract all switch states defined in MDS
    my $mdsSwitchStates = { 0 => 'PositionA', 1 => 'PositionB', 2 => 'Undefined', 3 => 'Openline' };
    foreach my $configuredSwitchNode (@staticSwitchNodesConfigured) {
        $configuredSwitchNode->getAttribute('name') =~ m/Switch_(.*)_Configured/;
        my $switchLabel = $1;
        S_teststep_2nd_level( "Get switch state for '$switchLabel' from CREIS XML",
                              'AUTO_NBR' );
        $crashSwitchStates->{$switchLabel}->{'Configured'} =
          $configuredSwitchNode->getAttribute('value');
        my @thisSwitchStateNode = $xpc->findnodes(
"./Settings/StaticEnvironment[contains(\@name, 'Switch') and contains(\@name, 'State') and contains(\@name, '$switchLabel')]"
        );
        my $numberOfStates = @thisSwitchStateNode;
        if ( $numberOfStates == 0 ) {
            @thisSwitchStateNode = $thisCrashNode->findnodes(
"./CollectedDynamicEnvironements/DynamicEnvironment[contains(\@name, 'Switch') and contains(\@name, 'State') and contains(\@name, '$switchLabel')]"
            );
            $numberOfStates = @thisSwitchStateNode;
        }
        if ( $numberOfStates == 1 ) {
            $crashSwitchStates->{$switchLabel}->{'State'} =
              $thisSwitchStateNode[0]->getAttribute('value');
        }

        # Add switch to crash handler
        my $switchStatePhysical;
        if ( $crashSwitchStates->{$switchLabel}->{"Configured"} ) {
            my $switchStateMDS = $crashSwitchStates->{$switchLabel}->{"State"};
            $switchStatePhysical = $mdsSwitchStates->{$switchStateMDS};
        }
        else {
            # switch not configured
            $switchStatePhysical = 'DataNotAvailable';
        }
        $crashSwitchStates->{$switchLabel}->{"StatePhysical"} = $switchStatePhysical;
    }

    # Take default states from TSG4 mapping for rest of states
    my ( $switchResult, $allSwitchNamesInMapping_aref ) = SYC_SWITCH_get_all_configured();
    unless ($switchResult) {
        S_set_error( "No switches could be obtained from SYC!!", 112 );
        return;
    }
    foreach my $switchLabel ( @{$allSwitchNamesInMapping_aref} ) {
        next if ( $crashSwitchStates->{$switchLabel}->{"StatePhysical"} );
        S_teststep_2nd_level( "Get default switch state for '$switchLabel' SYC", 'AUTO_NBR' );
        my ( $resultSwitchConfigured, $configured ) = SYC_SWITCH_get_Configured($switchLabel);
        next unless ($resultSwitchConfigured);
        if ( $configured eq 'yes' ) {
            my ( $resultDefaultCondition, $default_condition ) = SYC_SWITCH_get_DefaultCondition($switchLabel);
            next unless ($resultDefaultCondition);
            $crashSwitchStates->{$switchLabel}->{"StatePhysical"} = $default_condition;
        }
        else {
            $crashSwitchStates->{$switchLabel}->{"Configured"}    = 0;
            $crashSwitchStates->{$switchLabel}->{"StatePhysical"} = 'DataNotAvailable';
        }
    }

    # Add all obtained switch states to crash handler
    foreach my $switch ( keys %{$crashSwitchStates} ) {
        my $switchStatePhysical = $crashSwitchStates->{$switch}->{"StatePhysical"};
        S_teststep_2nd_level(
                           "Add switch state '$switchStatePhysical' for '$switch' to crash handler",
                           'AUTO_NBR' );
        $crash_handler->AddCrashSource(
                                        "CrashLabel"         => $crashLabel,
                                        "SourceType"         => 'Switch',
                                        "SourceLabel"        => $switch,
                                        "OriginalSourceData" => $switchStatePhysical
        );
    }


    # ************** 2 - PD Variable values **************
    my @PDLabelsBeforeCrash =  $thisCrashNode->findnodes("./PdLabelValuesBeforeCrash");

    foreach my $pdLabelNode (@PDLabelsBeforeCrash) {
        my $pdLabel = $pdLabelNode -> getAttribute('Name');
        my $pdUnit = 'n/a';
        $pdUnit = 'sec' if ($pdLabel eq 'Power On Time');
        $pdLabel .= "_BeforeCrash";
        S_teststep_2nd_level( "Get PD value '$pdLabel' from CREIS XML",
                              'AUTO_NBR' );
        my $pdValue = $pdLabelNode -> getAttribute('Value');
        $crash_handler->AddCrashSource(
                                        "CrashLabel"         => $crashLabel,
                                        "SourceType"         => 'PD_Variable',
                                        "SourceLabel"        => $pdLabel,
                                        "OriginalSourceData" => $pdValue,
                                        "SourceUnit"   => $pdUnit,
        );
    }

    my @PDLabelsAfterCrash =  $thisCrashNode->findnodes("./PdLabelValuesAfterCrash");

    foreach my $pdLabelNode (@PDLabelsAfterCrash) {
        my $pdLabel = $pdLabelNode -> getAttribute('Name');
        $pdLabel .= "_AfterCrash";
        S_teststep_2nd_level( "Get PD value '$pdLabel' from CREIS XML",
                              'AUTO_NBR' );
        my $pdValue = $pdLabelNode -> getAttribute('Value');
        $crash_handler->AddCrashSource(
                                        "CrashLabel"         => $crashLabel,
                                        "SourceType"         => 'PD_Variable',
                                        "SourceLabel"        => $pdLabel,
                                        "OriginalSourceData" => $pdValue
        );
    }

    # ************** 3 - Fire times and fire counter values **************
    my @SimDevices =  $thisCrashNode->findnodes("./SimDevice");

    foreach my $simDeviceNode (@SimDevices) {
        my $squibLabel = $simDeviceNode -> getAttribute('Name');
        S_teststep_2nd_level( "Get fire time and fire counter values (high level and low level) for '$squibLabel' from CREIS XML",
                              'AUTO_NBR' );

        my $fireTime_ms = $simDeviceNode -> getAttribute('ActualFiringTime_ms');
        S_w2log(3, "Fire time $fireTime_ms ms");
        $crash_handler->AddCrashSource(
                                        "CrashLabel"         => $crashLabel,
                                        "SourceType"         => 'FireTime',
                                        "SourceLabel"        => $squibLabel,
                                        "OriginalSourceData" => $fireTime_ms,
                                        "SourceUnit"   => 'ms',);

        my $fireCounterLow = $simDeviceNode -> getAttribute('FireCounter_LowLevel_ms');
        S_w2log(3, "Fire counter low level $fireCounterLow ms");
        $crash_handler->AddCrashSource(
                                        "CrashLabel"         => $crashLabel,
                                        "SourceType"         => 'FireCounter_LowLevel_ms',
                                        "SourceLabel"        => $squibLabel."_FireCounter_LowLevel_ms",
                                        "OriginalSourceData" => $fireCounterLow,
                                        "SourceUnit"   => 'ms',);

        my $fireCounterHigh = $simDeviceNode -> getAttribute('FireCounter_HighLevel_ms');
        S_w2log(3, "Fire counter high level $fireCounterHigh ms");
        $crash_handler->AddCrashSource(
                                        "CrashLabel"         => $crashLabel,
                                        "SourceType"         => 'FireCounter_HighLevel_ms',
                                        "SourceLabel"        => $squibLabel."_FireCounter_HighLevel_ms",
                                        "OriginalSourceData" => $fireCounterHigh,
                                        "SourceUnit"   => 'ms',);
    }


    #--------------------------------------------------------------
    # GET CRASH DATA FROM MEASUREMENTS
    #
    # Get contents of hash $mappingEDR for COM signals and fire times
    my $mappingEDR = S_get_contents_of_hash( ['Mapping_EDR'] );

    # ************** 1 - COM SIGNALS **************
    S_teststep( "Get stored COM trace dataref", 'AUTO_NBR' );
    S_teststep_2nd_level( "Get list of EDR relevant COM signals from EDR mapping", 'AUTO_NBR' );
    my $edr_COM_signals_aref = $mappingEDR->{'EDR_COM_SIGNAL_LABELS'};
    foreach my $content_ID_userfile ( @{$found_userfile_ids_aref} ) {
        S_w2log( 2, " CSM get userfile $content_ID_userfile ( without extraction) \n" );
        my $userfile_object = CSM_get_userfile(    #    without extracting
            $container_id,
            $content_ID_userfile,
            { extract => 0 },                      # option extract : 0 - no ; 1 - yes
        );
        my $userfile_description = $userfile_object->getDescription();
        S_w2log( 2, " $userfile_description file found \n" );
        next if($userfile_description ne 'can_access');

        $userfile_object = CSM_get_userfile(       #    now with extracting (is default)
                                             $container_id,
                                             $content_ID_userfile,);

        my $comFile = $userfile_object->getFilename_long();
        S_teststep_2nd_level( "Add com signals from file '$comFile' to crash handler", 'AUTO_NBR' );
        EDR_addCOMsignalsToCrashHandler(
                                         "COM_SignalLabels"  => $edr_COM_signals_aref,
                                         "CrashLabel"        => $crashLabel,
                                         "COM_TraceFileName" => $comFile,
                                         "COM_Protocol"		=> $tcpar_COM_Protocol,
        ) if (@{$edr_COM_signals_aref});
        last;                                      #only one COM user file expected
    }

    # ************** GENERAL CRASH INFO **************
    S_teststep( "Calculate crash time zero with measured and stored fire times", 'AUTO_NBR' );
    my $squibEDIDMapping = $mappingEDR->{'SquibLabelMapping'};
    if ( not defined $squibEDIDMapping ) {
        S_set_error("Can't calculate T0. 'SquibLabelMapping' must be added to EDR mapping.");
        return;
    }
    S_teststep_2nd_level( "Search for squib which has fired", 'AUTO_NBR' );
    my $valueNotDeployed = $mappingEDR->{'SquibValueNotDeployed_Decoded'};
    my $crashTimeZero_ms;
    my $minimumFireTime_EDR;
    my $minimumFireTime_Measured;
    my $minimumFiredSquib;
    foreach my $squib ( keys %{$squibEDIDMapping} ) {
        my $sourceData =
          $crash_handler->GetSourceDataValues( "SourceLabel" => $squib,
                                               "CrashLabel"  => $crashLabel );
        next unless ( defined $sourceData );
        my $edidData =
          $record_handler->GetDecodedEDID(
                                           "CrashLabel"   => $crashLabel,
                                           "RecordNumber" => 1,
                                           "EDIDnr"       => $squibEDIDMapping->{$squib}
          );
        next unless ( defined $edidData );
        S_w2log(2, "Get reported fire time for squib $squib");
        my $edrFireTime = $edidData->{'DataValue'};
        next if ( $edrFireTime eq 'DataNotAvailable' or  $edrFireTime eq $valueNotDeployed);
        $minimumFireTime_EDR = $edrFireTime if(not defined $minimumFireTime_EDR);
        next if($minimumFireTime_EDR < $edrFireTime);
        S_w2log(2, "Get measured fire time for squib $squib" );
        my $realFireTime;

		my $fireTimeDump = Dumper($sourceData);
		S_w2rep("Fire times: $fireTimeDump");

        if ( ref( $sourceData->{'DataValues'} ) eq 'ARRAY' ) {
            $realFireTime = $sourceData->{'DataValues'}->[0];
        }
        else {
            $realFireTime = $sourceData->{'DataValues'};
        }
        $minimumFireTime_Measured = $realFireTime if(not defined $minimumFireTime_Measured);
        next if($minimumFireTime_Measured < $realFireTime);
        S_teststep_2nd_level( "Current minimum fire time is: $squib", 'AUTO_NBR' );
        $minimumFireTime_Measured = $realFireTime;
        $minimumFiredSquib = $squib;
        $minimumFireTime_EDR = $edrFireTime;

        next;
    }
    
    if(not defined $minimumFireTime_EDR){
        S_set_error(
                     "Crash time zero could not be obtained (no devices fired?)"
                       . "Validation of crash not possible - testlist will be aborted.",
                     112
        );    #112 is system fail error which will abort testlist  
        FLEDR_XML_addNonEvaluatedCrash($tcpar_XML_Summary_filepath, $crashDetails_href, "No devices fired (T0 can't be obtained)");
        return;      
    }
    else{
        S_teststep_2nd_level(
                      "Calculate crash time zero from squib $minimumFiredSquib\n"
                        . "Crash time zero = Measured - EDR\n"
                        . "EDR reported fire time: $minimumFireTime_EDR, Measured fire time: $minimumFireTime_Measured",
                      'AUTO_NBR'
        );
        $crashTimeZero_ms = $minimumFireTime_Measured - $minimumFireTime_EDR;      
    }
    
    S_teststep_2nd_level( "Add crash time zero ($crashTimeZero_ms ms) to crash handler",
                          'AUTO_NBR' );
    $crash_handler->AddCrashSource(
                                    "CrashLabel"         => $crashLabel,
                                    "SourceLabel"        => 'CrashTimeZero',
                                    "OriginalSourceData" => $crashTimeZero_ms,
                                    "SourceUnit"         => 'ms',
    );
    unless ($crashTimeZero_ms) {
        S_set_error(
                     "Crash time zero could not be obtained (no devices fired?)"
                       . "Validation of crash not possible - testlist will be aborted.",
                     112
        );    #112 is system fail error which will abort testlist
 
        FLEDR_XML_addNonEvaluatedCrash($tcpar_XML_Summary_filepath, $crashDetails_href, "No devices fired (T0 can't be obtained)");
        return;
    }
    S_teststep( "Add MDS crash code to crash handler", 'AUTO_NBR' );
    $crash_handler->AddCrashSource(
                                    "CrashLabel"         => $crashLabel,
                                    "SourceLabel"        => 'CrashCode_MDS',
                                    "OriginalSourceData" => $tcpar_CrashName
    );
    S_teststep( "Add mdb file path to crash handler", 'AUTO_NBR' );
    $crash_handler->AddCrashSource(
                                    "CrashLabel"         => $crashLabel,
                                    "SourceLabel"        => 'MDB_Path',
                                    "OriginalSourceData" => $tcpar_MDSResult,
    );
    
    S_teststep( "Add crash duration to crash handler - currently default value", 'AUTO_NBR' );
    $crash_handler -> AddCrashSource( "CrashLabel" => $crashLabel,
    								  "SourceLabel" => 'CrashDuration', 
                                      "OriginalSourceData" => 5000,
                                      "SourceUnit" => 'ms',);
    
    
    FLEDR_XML_addCrash($tcpar_XML_Summary_filepath, $crashDetails_href);
	foreach my $record (1..$edrRecordObtained){
        FLEDR_XML_addEdrRecord($record);		
	}

    
    
    return 1;
}

#-------------------------------------------------------------------------------
sub TC_evaluation {

    #-------------------------------------------------------------------------------
    S_w2rep( "No evaluation in this test case", 'AUTO_NBR' );
    return 1;
}

#-------------------------------------------------------------------------------
sub TC_finalization {

    #-------------------------------------------------------------------------------
    S_w2rep( "Offline testcase, no finalization required", 'AUTO_NBR' );
    return 1;
}

sub EDR_get_ProdDiagResponseFromDump {
    my $fileName = shift;
    S_w2log( 1, "Starting EDR_get_ProdDiagResponseFromDump" );
    unless ( -e $fileName ) {
        S_set_error( "Given file '$fileName' does not exist", 112 );
        return;
    }
    my ( $date, $swVersion, $pdService, $record_aref );
    my $metaData_href;
    my $lineNumber = 0;
    my $success = 1;

    my $fileFormat_href = {};
    $fileFormat_href -> {"Version_2"} -> {'HeaderData'} = {
                                                            2 => 'TimeStamp',
                                                            3 => 'SoftwareVersion',
                                                            4 => 'VariantNumber',
                                                            5 => 'VariantVersion',
                                                            6 => 'AlgoProjectID',
                                                            7 => 'AlgoParameterID',
                                                            8 => 'CrashEntry',};

    my $dataKeyMapping;
    open( my $pdDump, "<", $fileName ) or S_set_error( "unable to open '$fileName' ", 112 );
    while (<$pdDump>) {
        $lineNumber++;
        chop($_);

        if ( $lineNumber == 1 ) {
            $_ =~ m/:(.*)\s#/;
            $dataKeyMapping = $fileFormat_href -> {"Version_$1"} -> {'HeaderData'};
            if(not defined $dataKeyMapping){
                S_set_error("EDR_get_ProdDiagResponseFromDump is not implemented for PD EDR Dump file format version $1.\n".
                            "Request implementation update in Bosch Connect EDR forum!");
                $success = 0;
                last;
            }
            $metaData_href -> {'FileFormatVersion'} = $1;
            next;
        }
        elsif(defined $dataKeyMapping -> {$lineNumber}){
            $_ =~ m/:(.*)\s#/;
            my $dataKey = $dataKeyMapping -> {$lineNumber};
            $metaData_href -> {$dataKey} = $1;
            next;            
        }
        push( @{$record_aref}, hex($_) );
    }
    close($pdDump);

    unless($success){
        return;
    }

    return ( $record_aref, $metaData_href );
}

sub _get_DeploymentRecordNumber_ForMultiEvent{
	my $thisCrashName = shift;

	my $crashDetails_href = S_get_contents_of_hash_NOERROR(['EDR_Offline_CrashDetails']);
	return unless(defined $crashDetails_href);

	my $thisCrashDetails = $crashDetails_href -> {$thisCrashName};
	return unless(defined $thisCrashDetails);

	my $crashType = $thisCrashDetails -> {"CrashType"};
	return unless(defined $crashType);
	
	if($crashType ne 'Multi'){
		S_set_error("More than 1 record detected for '$thisCrashName'. CrashType expected in 'EDR_Offline_CrashDetails' is 'Multi'");
		return;
	}
	
	my $deploymentRecord = $thisCrashDetails -> {"DeploymentRecordNumber"};

	return $deploymentRecord;
}

1;
