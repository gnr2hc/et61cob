#### TEST CASE MODULE
package TC_EDID_Voltage;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_PD;
use LIFT_can_access;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use GENERIC_DCOM;
use FuncLib_EDR_Framework;
use FuncLib_TNT_SYC_INTERFACE;
use Data::Dumper;

##################################

our $PURPOSE = "<To validate EDID for Ignition Cycle Crash recorded in EDR>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDID_Voltage

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Set the Supply voltage to <VBat_Voltage_BeforeCrash>

2. Inject any Crash

3.Read <EDID_VBat_BeforeCrash> and <EDID_EnergyReserveVolt_BeforeCrash> values in EDR through CD.


I<B<Evaluation>>

1.

2

3. value of 

<EDID_VBat_BeforeCrash>=<Exp_VBat_VoltageBeforeCrash> 

 

<EDID_EnergyReserveVolt_BeforeCrash>=<Exp_EnergyReserveVolt_VoltageBeforeCrash> 


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

    SCALAR 'Exp_VBat_VoltageBeforeCrash' => 
    SCALAR 'Exp_EnergyReserveVolt_VoltageBeforeCrash' => 
    SCALAR 'purpose' => 
    SCALAR 'VBat_Voltage_BeforeCrash' => 
    SCALAR 'EDID_VBat_BeforeCrash' => 
    SCALAR 'EDID_EnergyReserveVolt_BeforeCrash' => 
    SCALAR 'condition' => 


=head2 PARAMETER EXAMPLES

    purpose  = 'To check the Vbat and VER voltages before the crash recorded in EDR.'
    
    VBat_Voltage_BeforeCrash = '<Test Heading 2>'
    
    EDID_VBat_BeforeCrash='975'
    EDID_EnergyReserveVolt_BeforeCrash='974'

    Exp_VBat_VoltageBeforeCrash=12 #V
    Exp_EnergyReserveVolt_VoltageBeforeCrash=33 #V

=cut


#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_VBat_Voltage_BeforeCrash;
my $tcpar_VBat_Voltage_AfterCrash;
my $tcpar_EDID_VBat_BeforeCrash;
my $tcpar_EDID_VBat_AfterCrash;
my $tcpar_EDID_EnergyReserveVolt_BeforeCrash;
my $tcpar_EDID_EnergyReserveVolt_AfterCrash;
my $tcpar_PD_Variable_EnergyReserveVoltage;
my $tcpar_PD_Variable_EnergyReserveVoltage_Type;
my $tcpar_VBatTolerance_abs;
my $tcpar_EnergyReserveTolerance_abs;
my $tcpar_DiagType;
my $tcpar_ResultDB;
my $tcpar_CrashType;
my $tcpar_CrashTimeZero_ms;
my $tcpar_CrashTimeEnd_ms;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_Supplier_EDID;


################ global parameter declaration ###################
#add any global variables here
my ($record_handler, $crashSettings, $edrNumberOfEventsToBeStored, @crashTimeZero_ms_array);
my ($expected_Voltage_EnergyReserve, $expected_Voltage_Battery, $fdTrace_VER, $fdTraceTimeOffset_ms, $canTrace);

###############################################################

sub TC_set_parameters {


    $tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
    $tcpar_VBat_Voltage_BeforeCrash =  S_read_mandatory_testcase_parameter( 'VBat_Voltage_BeforeCrash' );
    $tcpar_VBat_Voltage_AfterCrash =  S_read_optional_testcase_parameter( 'VBat_Voltage_AfterCrash' );
    $tcpar_EDID_VBat_BeforeCrash =  S_read_optional_testcase_parameter( 'EDID_VBat_BeforeCrash' );
    $tcpar_EDID_VBat_AfterCrash =  S_read_optional_testcase_parameter( 'EDID_VBat_AfterCrash' );
    $tcpar_EDID_EnergyReserveVolt_BeforeCrash =  S_read_optional_testcase_parameter( 'EDID_EnergyReserveVolt_BeforeCrash' );
    $tcpar_EDID_EnergyReserveVolt_AfterCrash =  S_read_optional_testcase_parameter( 'EDID_EnergyReserveVolt_AfterCrash' );
    $tcpar_PD_Variable_EnergyReserveVoltage =  S_read_mandatory_testcase_parameter( 'PD_Variable_EnergyReserveVoltage' );
    $tcpar_PD_Variable_EnergyReserveVoltage_Type =  S_read_mandatory_testcase_parameter( 'PD_Variable_EnergyReserveVoltage_Type' );
    $tcpar_VBatTolerance_abs =  S_read_mandatory_testcase_parameter( 'VBat_Tolerance_abs' );
    $tcpar_EnergyReserveTolerance_abs =  S_read_mandatory_testcase_parameter( 'EnergyReserve_Tolerance_abs' );
	$tcpar_DiagType =  S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_ResultDB =  S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_CrashType =  S_read_mandatory_testcase_parameter( 'CrashType' );
	$tcpar_CrashTimeZero_ms =  S_read_mandatory_testcase_parameter( 'CrashTimeZero_ms' );
	$tcpar_CrashTimeEnd_ms =  S_read_optional_testcase_parameter( 'CrashTimeEnd_ms' );
	$tcpar_COMsignalsAfterCrash = S_read_optional_testcase_parameter( 'COMsignalsAfterCrash' , 'byref');
	$tcpar_Supplier_EDID = S_read_optional_testcase_parameter( 'Supplier_EDID');

	if($tcpar_EDID_EnergyReserveVolt_AfterCrash and not $tcpar_CrashTimeEnd_ms){
		S_set_error("Energy reserve voltage after crash can't be validated without CrashTimeEnd_ms given!");
		return;
	}

	@crashTimeZero_ms_array = split(/_/, $tcpar_CrashTimeZero_ms);

	return 1;
}

sub TC_initialization {

	S_teststep("Test setup preparation", 'AUTO_NBR');

	#--------------------------------------------------------------
    # INITIALIZE RECORD HANDLER
    #    
	S_teststep_2nd_level("Initialize Record Handler", 'AUTO_NBR');
	$record_handler = EDR_init_RecordHandler() || return;

	#--------------------------------------------------------------
    # PREPARE CRASH AND INITIALIZE EQUIPMENT
    #

	S_teststep_2nd_level("Power on ECU and wait until ECU is ready", 'AUTO_NBR');
    LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

    S_teststep_2nd_level("Start CAN trace and diagnosis", 'AUTO_NBR');
    CA_trace_start();
    GDCOM_init () ;

	S_teststep_2nd_level("Clear crash recorder", 'AUTO_NBR');
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(2000);

	S_teststep_2nd_level("Clear fault memory", 'AUTO_NBR');
    PD_ClearFaultMemory();
    S_wait_ms(2000);
	
    S_teststep_2nd_level("Get crash settings for crash $tcpar_CrashType", 'AUTO_NBR');
    my $crashDetails_href = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_CrashType};
    $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
    unless(defined $crashSettings) {
        S_set_error("Crash $tcpar_CrashType not available in result DB $tcpar_ResultDB. Test case aborted.");
        return;
    }

    my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
    my $resultDB_Path = $resultDBDetails->{'PATH'};
    S_w2log(1, "Crashcode: $tcpar_CrashType, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");

	S_teststep_2nd_level("Set environments for crash as per result DB", 'AUTO_NBR');
    CSI_PrepareEnvironment($crashSettings, 'init_complete');
    S_wait_ms(2000);

	S_teststep_2nd_level("Read and evaluate fault memory before stimulation", 'AUTO_NBR');
    my $faultsBeforeStimulation = PD_ReadFaultMemory();
    my $faultsVerdict = PD_evaluate_faults_NOVERDICT( $faultsBeforeStimulation, []);
    return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

    S_teststep_2nd_level("Prepare '$tcpar_CrashType'", 'AUTO_NBR');
    S_w2log(1, "Power off ECU");
    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_READY');

    #Prepare crash
    S_w2log(1, "Prepare crash");
    CSI_LoadCrashSensorData2Simulator($crashSettings);

    S_w2log(1, "Power on ECU");
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

	return 1;
}

sub TC_stimulation_and_measurement {
	
	CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    S_wait_ms(1000);

	my $dataStoragePath = "$main::REPORT_PATH/".S_get_TC_number()."_"."$tcpar_CrashType";
	mkdir($dataStoragePath);

    S_teststep("Start measurement of energy reserve voltage variable '$tcpar_PD_Variable_EnergyReserveVoltage'", 'AUTO_NBR');
    PD_StartFastDiagName( $dataStoragePath."/PD_FastDiag_VER.txt",
    						[$tcpar_PD_Variable_EnergyReserveVoltage, 'rb_evm_EventTimer_au16(0)'],
    						[$tcpar_PD_Variable_EnergyReserveVoltage_Type, 'U16'] );

    S_teststep("Set the Supply voltage to '$tcpar_VBat_Voltage_BeforeCrash'", 'AUTO_NBR');
    LC_SetVoltage($tcpar_VBat_Voltage_BeforeCrash);
    $expected_Voltage_Battery -> {1} -> {'Before'} = $tcpar_VBat_Voltage_BeforeCrash;

    S_teststep("Inject $tcpar_CrashType", 'AUTO_NBR');
    CSI_TriggerCrash();

    S_teststep("Wait $crashTimeZero_ms_array[0] ms for T0 of first incident", 'AUTO_NBR');
    S_wait_ms($crashTimeZero_ms_array[0]);

    
    if(defined $tcpar_VBat_Voltage_AfterCrash){
	    S_teststep("Set the Supply voltage to '$tcpar_VBat_Voltage_AfterCrash' 100 ms after start of first incident", 'AUTO_NBR');
        S_wait_ms(100);
	    LC_SetVoltage($tcpar_VBat_Voltage_AfterCrash);
	    my @crashTimeEnd_ms_array = split(/_/, $tcpar_CrashTimeEnd_ms);
	    my $voltageChangeAt_ms = $crashTimeZero_ms_array[0] + 100;
	    my $crashTimeEndFirstIncident = $crashTimeEnd_ms_array[0];
	    my $crashTimeZeroSecondIncident =  	$crashTimeZero_ms_array[1];
	    my $crashTimeEndSecondIncident = $crashTimeEnd_ms_array[1];
	    if($crashTimeEndFirstIncident > $voltageChangeAt_ms){
	        $expected_Voltage_Battery -> {1} -> {'After'} = $tcpar_VBat_Voltage_AfterCrash;
	    }
	    else {
	        $expected_Voltage_Battery -> {1} -> {'After'} = $tcpar_VBat_Voltage_BeforeCrash;
	    }
	    
	    if($crashTimeZeroSecondIncident > $voltageChangeAt_ms){
            $expected_Voltage_Battery -> {2} -> {'Before'} = $tcpar_VBat_Voltage_AfterCrash;
            $expected_Voltage_Battery -> {2} -> {'After'} = $tcpar_VBat_Voltage_AfterCrash;	        
	    }
	    elsif($crashTimeEndSecondIncident > $voltageChangeAt_ms){
            $expected_Voltage_Battery -> {2} -> {'Before'} = $tcpar_VBat_Voltage_BeforeCrash;
            $expected_Voltage_Battery -> {2} -> {'After'} = $tcpar_VBat_Voltage_AfterCrash;         	        
	    }
	    else{
            $expected_Voltage_Battery -> {2} -> {'Before'} = $tcpar_VBat_Voltage_BeforeCrash;
            $expected_Voltage_Battery -> {2} -> {'After'} = $tcpar_VBat_Voltage_BeforeCrash;                     	        
	    }
    }
    else {
	    $expected_Voltage_Battery -> {1} -> {'After'} = $tcpar_VBat_Voltage_BeforeCrash;
	    $expected_Voltage_Battery -> {2} -> {'Before'} = $tcpar_VBat_Voltage_BeforeCrash;
	    $expected_Voltage_Battery -> {2} -> {'After'} = $tcpar_VBat_Voltage_BeforeCrash;    	
    }
   
    S_teststep("Wait 15 seconds for EDR storage", 'AUTO_NBR');
    S_wait_ms(15000);
	
	if (defined $tcpar_COMsignalsAfterCrash){
		foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
		{				
			my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
			S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
			COM_setSignalState($signal,$dataOnCOM);	
		}

	}

    S_teststep("Set ECU to default voltage and stop measurement of energy reserve voltage variable '$tcpar_PD_Variable_EnergyReserveVoltage'", 'AUTO_NBR');
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');
    PD_StopFastDiag();
    $fdTrace_VER = PD_get_FDtrace($dataStoragePath."/PD_FastDiag_VER.txt");

	my $tracePath = CA_trace_store($dataStoragePath."/CANoe_Trace.asc");
	S_wait_ms(2000);
	CA_trace_start(); # Restart RBS
	
	$fdTraceTimeOffset_ms = EVAL_get_time_when( $fdTrace_VER ,
                                    'rb_evm_EventTimer_au16(0)' ,
                                    ">=" ,
                                    1 );
	
	# $fdTraceTimeOffset_ms is related to T0 of the first incident
	# In order to relate it to start of CREIS_Inject, T0 of first incident has to be subtracted
	$fdTraceTimeOffset_ms = $fdTraceTimeOffset_ms - $crashTimeZero_ms_array[0];
	S_w2rep("PD offset to CREIS_Inject: $fdTraceTimeOffset_ms");

	$edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();
	unless(defined $edrNumberOfEventsToBeStored){
		S_set_error("'NumberOfEventsToBeStored' is not available in SYC - add or overwrite 'SYC_EDR_get_NumberOfEventsToBeStored' with Custlibrary Function");
        return;
    }

    S_teststep("Read $edrNumberOfEventsToBeStored EDR records", 'AUTO_NBR');
    PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');
	EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
							 	"CrashLabel" => "$tcpar_CrashType",
							 	"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
							 	"StoragePath" => $dataStoragePath,);
							 	
    if(defined $tcpar_Supplier_EDID){
        my $recordStructureSupplier_href = EDR_ReadEDR_Record_structure_info_from_mapping_NOERROR('Supplier',0,'Mapping_EDR','SUPPLIER_EDIDS');
        if(not $recordStructureSupplier_href){
        	S_set_error("Supplier data can not be extracted and parsed because section 'SUPPLIER_EDIDS' is missing in EDR mapping!");
        	return;
        }

    	foreach my $recordNbr (1..$edrNumberOfEventsToBeStored)
    	{
	        my $supplierRecordData_aref = $record_handler -> GetRawEDID( "EDIDnr" => $tcpar_Supplier_EDID,
	                                                                "RecordNumber" => $recordNbr,
	                                                                "CrashLabel" => $tcpar_CrashType,);
	        
	        next unless($supplierRecordData_aref);

	        S_teststep_2nd_level("Add obtained supplier data for crash record $recordNbr to record handler", 'AUTO_NBR');
	        $record_handler -> AddCrashRecord(  "RecordNumber" => $recordNbr,
	                                                "CrashLabel"   => $tcpar_CrashType.'_Supplier',
	                                                "RecordStructureInfo" => $recordStructureSupplier_href,
	                                                "RawDataGeneric" => $supplierRecordData_aref,);
	
	        S_teststep_2nd_level("Print supplier data crash record $recordNbr", 'AUTO_NBR');
	        $record_handler -> PrintRawEDIDs( "RecordNumber" => $recordNbr,
	                                            "CrashLabel" => $tcpar_CrashType.'_Supplier',
	                                            "FormatOption" => 'HEX',);
    	}
    }
								
	return 1;
}

sub TC_evaluation {

	my $crashLabel;
	if(defined $tcpar_Supplier_EDID){
		$crashLabel = $tcpar_CrashType."_Supplier";
	}
	else {
		$crashLabel = $tcpar_CrashType;
	}
	
	my $numberOfIncidents = @crashTimeZero_ms_array;
	my $record_Incident_Mapping;
	if($numberOfIncidents == 1){
		$record_Incident_Mapping -> {1} = 1;
	}
	elsif($numberOfIncidents == 2){
		# Mapping of records to incidents:
		my $storageOrder = EDR_getStorageOrder();
		return unless($storageOrder);
        if($storageOrder eq 'PhysicalOrder'){
           $storageOrder =  'MostRecentLast'; #same behavior as there is no overwriting
        }
		if($storageOrder eq 'MostRecentFirst'){
			$record_Incident_Mapping -> {1} = 2; # Incident 2 stored in record 1
			$record_Incident_Mapping -> {2} = 1; # Incident 1 stored in record 2
		}
		elsif($storageOrder eq 'MostRecentLast'){
			$record_Incident_Mapping -> {1} = 1; # Incident 1 stored in record 1		
			$record_Incident_Mapping -> {2} = 2; # Incident 2 stored in record 2		
		}
		
	}
	else{
		S_set_error("Too many incidents in crash code ($numberOfIncidents). Max 2 supported in evaluation.");
		return;
	}


	# VBat Before crash
	if($tcpar_EDID_VBat_BeforeCrash){
	    my $dataElement_VBat = $record_handler -> GetDataElementEDID( "EDIDnr" => $tcpar_EDID_VBat_BeforeCrash,
	                                                               "RecordNumber" => 1,
	                                                               "CrashLabel" => $crashLabel);
	    unless(defined $dataElement_VBat){
	    	S_set_error("EDID $tcpar_EDID_VBat_BeforeCrash for battery voltage not present in EDR record. No evaluation will be done.");
	    	return;
	    }
		foreach my $recordNbr (1..$numberOfIncidents)
		{
	        S_teststep("Get '$tcpar_EDID_VBat_BeforeCrash' ($dataElement_VBat) value for record  $recordNbr", 'AUTO_NBR', "VBat_Record_$recordNbr");
	        my $edidData = $record_handler -> GetDecodedEDID("CrashLabel" => $crashLabel, "RecordNumber" => $recordNbr,"EDIDnr" => $tcpar_EDID_VBat_BeforeCrash );
	        my $detectedvalue_Vbat = $edidData -> {"DataValue"};
	        my $unit_Vbat = $edidData -> {"ValueUnit"};
	        if($unit_Vbat eq 'mV'){
	        	$detectedvalue_Vbat = $detectedvalue_Vbat / 1000;
	        	$unit_Vbat = 'V';
	        }
	       unless(defined $detectedvalue_Vbat) {
	           S_set_error("No data could be obtained for EDID $tcpar_EDID_VBat_BeforeCrash in record $recordNbr");
	           return;
	       }
	       EVAL_evaluate_value ( "EDID_$tcpar_EDID_VBat_BeforeCrash\_Evaluation", 
	       							$detectedvalue_Vbat,'==',
	       							$expected_Voltage_Battery -> {$record_Incident_Mapping -> {$recordNbr}} -> {'Before'},
	       							$tcpar_VBatTolerance_abs, 'absolute' );
	       S_teststep_expected($expected_Voltage_Battery -> {$record_Incident_Mapping -> {$recordNbr}} -> {'Before'}." V", "VBat_Record_$recordNbr");
	       S_teststep_detected("$detectedvalue_Vbat $unit_Vbat", "VBat_Record_$recordNbr");  	   	
		}		
	}

	# VBat After crash
	if($tcpar_EDID_VBat_AfterCrash){
	    my $dataElement_VBat = $record_handler -> GetDataElementEDID( "EDIDnr" => $tcpar_EDID_VBat_AfterCrash,
	                                                               "RecordNumber" => 1,
	                                                               "CrashLabel" => $crashLabel);
	    unless(defined $dataElement_VBat){
	    	S_set_error("EDID $tcpar_EDID_VBat_AfterCrash for battery voltage not present in EDR record. No evaluation will be done.");
	    	return;
	    }
		foreach my $recordNbr (1..$numberOfIncidents)
		{
	        S_teststep("Get '$tcpar_EDID_VBat_AfterCrash' ($dataElement_VBat) value for record  $recordNbr", 'AUTO_NBR', "VBat_After_Record_$recordNbr");
	        my $edidData = $record_handler -> GetDecodedEDID("CrashLabel" => $crashLabel, "RecordNumber" => $recordNbr,"EDIDnr" => $tcpar_EDID_VBat_AfterCrash );
	        my $detectedvalue_Vbat = $edidData -> {"DataValue"};
	        my $unit_Vbat = $edidData -> {"ValueUnit"};
	        if($unit_Vbat eq 'mV'){
	        	$detectedvalue_Vbat = $detectedvalue_Vbat / 1000;
	        	$unit_Vbat = 'V';
	        }
	       unless(defined $detectedvalue_Vbat) {
	           S_set_error("No data could be obtained for EDID $tcpar_EDID_VBat_AfterCrash in record $recordNbr");
	           return;
	       }
	       if($detectedvalue_Vbat =~ m/[a-zA-Z]/){
	           my $expectedVoltage = $expected_Voltage_Battery -> {$record_Incident_Mapping -> {$recordNbr}} -> {'After'};
	           $expectedVoltage = 'DataNotAvailable' if($tcpar_VBat_Voltage_AfterCrash == 0); #Autarky
	           EVAL_evaluate_string("EDID_$tcpar_EDID_VBat_AfterCrash\_Evaluation", 
                                        $expectedVoltage,
                                        $detectedvalue_Vbat);
	       }
	       else {
               EVAL_evaluate_value ( "EDID_$tcpar_EDID_VBat_AfterCrash\_Evaluation", 
                                        $detectedvalue_Vbat,'==',
                                        $expected_Voltage_Battery -> {$record_Incident_Mapping -> {$recordNbr}} -> {'After'},
                                        $tcpar_VBatTolerance_abs, 'absolute' );	           
	       }
	       S_teststep_expected($expected_Voltage_Battery -> {$record_Incident_Mapping -> {$recordNbr}} -> {'After'}." V", "VBat_After_Record_$recordNbr");
	       S_teststep_detected("$detectedvalue_Vbat $unit_Vbat", "VBat_After_Record_$recordNbr");  	   	
		}		
	}


	# VER Before crash
	if($tcpar_EDID_EnergyReserveVolt_BeforeCrash){
	    my $dataElement_VEnergyReserve = $record_handler -> GetDataElementEDID( "EDIDnr" => $tcpar_EDID_EnergyReserveVolt_BeforeCrash,
	                                                               "RecordNumber" => 1,
	                                                               "CrashLabel" => $crashLabel);
	    unless(defined $dataElement_VEnergyReserve){
	        S_set_error("EDID $tcpar_EDID_EnergyReserveVolt_BeforeCrash for energy reserve voltage not present in EDR record. No evaluation will be done.");
	        return;
	    }

		foreach my $recordNbr (1..$numberOfIncidents)
		{

			# Get expected value for energy reserve
			my $incidentNbr = $record_Incident_Mapping -> {$recordNbr};

			my ( $atT0 , $atT0_alternate ) = EVAL_get_value_around_time ( 	$fdTrace_VER , 
																			$fdTraceTimeOffset_ms + $crashTimeZero_ms_array[$incidentNbr - 1] ,
																			$tcpar_PD_Variable_EnergyReserveVoltage );
		
			unless($atT0){
				$atT0 = $atT0_alternate;
			}
		
			# Convert to Volt
			my $expected_VER_BeforeCrash = $atT0 * 10 * 0.001; # 10mv per LSB -> conversion to Volt


	        S_teststep("Get '$tcpar_EDID_EnergyReserveVolt_BeforeCrash' ($dataElement_VEnergyReserve) value for record  $recordNbr", 'AUTO_NBR', "VER_Record_$recordNbr");
	        my $edidData = $record_handler -> GetDecodedEDID("CrashLabel" => $crashLabel,
	        										"RecordNumber" => $recordNbr,
	        										"EDIDnr" => $tcpar_EDID_EnergyReserveVolt_BeforeCrash );

	        my $detectedvalue_VER = $edidData -> {"DataValue"};
	        my $unit_VER = $edidData -> {"ValueUnit"};
	       unless(defined $detectedvalue_VER) {
	           S_set_error("No data could be obtained for EDID $tcpar_EDID_EnergyReserveVolt_BeforeCrash in record $recordNbr");
	           return;
	       }
	        if($unit_VER eq 'mV'){
	        	$detectedvalue_VER = $detectedvalue_VER / 1000;
	        	$unit_VER = 'V';
	        }
	       EVAL_evaluate_value ( "EDID_$tcpar_EDID_EnergyReserveVolt_BeforeCrash\_Evaluation",
	       							$detectedvalue_VER,'==',
	       							$expected_VER_BeforeCrash,
	       							$tcpar_EnergyReserveTolerance_abs, 'absolute' );

	       S_teststep_expected($expected_VER_BeforeCrash." V", "VER_Record_$recordNbr");
	       S_teststep_detected("$detectedvalue_VER $unit_VER", "VER_Record_$recordNbr");  	   	
		}		
	}

    # VER After crash
    if($tcpar_EDID_EnergyReserveVolt_AfterCrash){
        my $dataElement_VEnergyReserve = $record_handler -> GetDataElementEDID( "EDIDnr" => $tcpar_EDID_EnergyReserveVolt_AfterCrash,
                                                                   "RecordNumber" => 1,
                                                                   "CrashLabel" => $crashLabel);
        unless(defined $dataElement_VEnergyReserve){
            S_set_error("EDID $tcpar_EDID_EnergyReserveVolt_AfterCrash for energy reserve voltage not present in EDR record. No evaluation will be done.");
            return;
        }
        my @crashTimeEnd_ms_array = split(/_/, $tcpar_CrashTimeEnd_ms);

        foreach my $recordNbr (1..$numberOfIncidents)
        {

            # Get expected value for energy reserve
            my $incidentNbr = $record_Incident_Mapping -> {$recordNbr};

            my ( $atTend , $atTend_alternate ) = EVAL_get_value_around_time (   $fdTrace_VER , 
                                                                            $fdTraceTimeOffset_ms + $crashTimeEnd_ms_array[$incidentNbr - 1] ,
                                                                            $tcpar_PD_Variable_EnergyReserveVoltage );
        
            unless($atTend){
                $atTend = $atTend_alternate;
            }
        
            # Convert to Volt
            my $expected_VER_AfterCrash = $atTend * 10 * 0.001; # 10mv per LSB -> conversion to Volt


            S_teststep("Get '$tcpar_EDID_EnergyReserveVolt_AfterCrash' ($dataElement_VEnergyReserve) value for record  $recordNbr", 'AUTO_NBR', "VER_After_Record_$recordNbr");
            my $edidData = $record_handler -> GetDecodedEDID("CrashLabel" => $crashLabel,
                                                    "RecordNumber" => $recordNbr,
                                                    "EDIDnr" => $tcpar_EDID_EnergyReserveVolt_AfterCrash );

            my $detectedvalue_VER = $edidData -> {"DataValue"};
            my $unit_VER = $edidData -> {"ValueUnit"};
           unless(defined $detectedvalue_VER) {
               S_set_error("No data could be obtained for EDID $tcpar_EDID_EnergyReserveVolt_BeforeCrash in record $recordNbr");
               return;
           }
            if($unit_VER eq 'mV'){
                $detectedvalue_VER = $detectedvalue_VER / 1000;
                $unit_VER = 'V';
            }

           if($detectedvalue_VER =~ m/[a-zA-Z]/){
               $expected_VER_AfterCrash = 'DataNotAvailable' if($tcpar_VBat_Voltage_AfterCrash == 0); #Autarky
               EVAL_evaluate_string("EDID_$tcpar_EDID_VBat_AfterCrash\_Evaluation", 
                                        $expected_VER_AfterCrash,
                                        $detectedvalue_VER);
           }
           else {
               EVAL_evaluate_value ( "EDID_$tcpar_EDID_EnergyReserveVolt_BeforeCrash\_Evaluation",
                                        $detectedvalue_VER,'==',
                                        $expected_VER_AfterCrash,
                                        $tcpar_EnergyReserveTolerance_abs, 'absolute' );
           }
           S_teststep_expected($expected_VER_AfterCrash." V", "VER_After_Record_$recordNbr");
           S_teststep_detected("$detectedvalue_VER $unit_VER", "VER_After_Record_$recordNbr");        
        }       
    }


	return 1;
}

sub TC_finalization {

	S_w2rep("Start test case finalization...");
	
	#Delete Record Handler
	foreach my $recordNumber (1..$edrNumberOfEventsToBeStored)
	{
		$record_handler -> DeleteRecord("CrashLabel" => $tcpar_CrashType, "RecordNumber" => $recordNumber);
		if(defined $tcpar_Supplier_EDID){
			$record_handler -> DeleteRecord("CrashLabel" => $tcpar_CrashType."_Supplier", "RecordNumber" => $recordNumber);
		}

	}

	# Erase EDR
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(2000);

	# Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	# Read fault memory after clearing and erasing EDR
    PD_ReadFaultMemory();   

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

	return 1;
}


1;
