#### TEST CASE MODULE
package TC_EDR_SDID_TotalEventCountAndCrashNumber;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_PD;
use LIFT_can_access;
use GENERIC_DCOM;
use LIFT_labcar;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use LIFT_FaultMemory;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;
use Data::Dumper;

##################################

our $PURPOSE = "<To validate the data element Crash number and TotalEventCount recorded in EDR through CD>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_SDID_TotalEventCountAndCrashNumber

=head1 PURPOSE

<To validate the data element Crash number and TotalEventCount recorded in EDR through CD>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1.Inject a <Crashcode1>

2. Read the  <Data _Element> corresponding to the <SDID> EventCounter value in most recent Entry of EDR through CD

3.Inject a <Crashcode2> equal to <NumOfEdrRecords>

4. Read the  <Data _Element> corresponding to the <SDID> EventCounter value in most recent Entry of EDR through CD

5.Inject a <Crashcode3>

6. Read the  <Data _Element> corresponding to the <SDID> EventCounter value in most recent Entry of EDR through CD

7. Clear the Crash recorder


I<B<Evaluation>>

1.

2. <Data _Element> will report the value <Expected_Value1>

3.

4. <Data _Element> will report the value <Expected_Value2>

5.

6. <Data _Element> will report the value <Expected_Value3>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Expected_Value1' => 
	SCALAR 'Expected_Value2' => 
	SCALAR 'Expected_Value3' => 
	SCALAR 'CounterType' => 
	SCALAR 'purpose' => 
	SCALAR 'SDID' => 
	SCALAR 'Data_Element' => 
	SCALAR 'NumOfEdrRecords' => 
	SCALAR 'Crashcode1' => 
	SCALAR 'Crashcode2' => 
	SCALAR 'Crashcode3' => 


=head2 PARAMETER EXAMPLES

	purpose	 = 'to validate the data element "Total Event Count" recorded in EDR through CD'
	SDID= '<Fetch {SDID}>'
	Data_Element= '<Fetch {Object Text}>'
	#NumOfEdrRecords=  '<Fetch {V_RefType3_B4_Sample}>'#project Specific
	NumOfEdrRecords=2
	Crashcode1= 'Single_EDR_Side_above_8kph_NoDeployment'
	Crashcode2='Multi_EDR_Side_ND_Front_AD'# only two records in case of coreasset.
	Crashcode3='Multi_EDR_Extended_Front_ND_Side_AD_Front_AD' #3Events
	
	Expected_Value1 ='0x0001'
	Expected_Value2= '0x0005'
	Expected_Value3= '0x0008'
	CounterType = 'TotalEventCount'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_SDID;
my $tcpar_Crashcode1;
my $tcpar_Crashcode2;
my $tcpar_Crashcode3;
my $tcpar_ResultDB;
my $tcpar_Expected_Value1;
my $tcpar_Expected_Value2;
my $tcpar_Expected_Value3;
my $tcpar_CounterType;
my $tcpar_DiagType;
my $tcpar_COMsignalsAfterCrash;
my $tcpar_EDIDNr_Supplier;
my $crashSettings1;
my $crashSettings2;
my $crashSettings3;

################ global parameter declaration ###################
#add any global variables here
my ($record_handler,
 	$tcpar_EDID,
	$edrNumberOfEventsToBeStored,
	$crashSettings_href,
	$crashCodes_aref);

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_SDID =  S_read_mandatory_testcase_parameter( 'SDID' );
	$tcpar_EDIDNr_Supplier =  S_read_optional_testcase_parameter( 'EDIDNr_Supplier' );
	$tcpar_ResultDB =  S_read_mandatory_testcase_parameter( 'ResultDB' );
	$tcpar_DiagType =  S_read_mandatory_testcase_parameter( 'DiagType' );
	$tcpar_Crashcode1 =  S_read_mandatory_testcase_parameter( 'Crashcode1' );
	$tcpar_Crashcode2 =  S_read_mandatory_testcase_parameter( 'Crashcode2' );
	$tcpar_Crashcode3 =  S_read_mandatory_testcase_parameter( 'Crashcode3' );
	$tcpar_Expected_Value1 =  S_read_mandatory_testcase_parameter( 'Expected_Value1' , 'byref');
	$tcpar_Expected_Value2 =  S_read_mandatory_testcase_parameter( 'Expected_Value2' , 'byref' );
	$tcpar_Expected_Value3 =  S_read_mandatory_testcase_parameter( 'Expected_Value3' , 'byref' );
	$tcpar_CounterType =  S_read_mandatory_testcase_parameter( 'CounterType' );
	$tcpar_COMsignalsAfterCrash =  S_read_optional_testcase_parameter( 'COMsignalsAfterCrash','byref');
	
	
	push(@{$crashCodes_aref}, $tcpar_Crashcode1);
	push(@{$crashCodes_aref}, $tcpar_Crashcode2);
	push(@{$crashCodes_aref}, $tcpar_Crashcode3);
	
	if( defined $tcpar_EDIDNr_Supplier){
		$tcpar_EDID = EDR_Convert_SDID_To_Integer ($tcpar_SDID);
	}
	else{
		$tcpar_EDID = $tcpar_SDID;
	}
	
	if(not defined $tcpar_EDID){
		S_set_error("Converting DOORS SDID to integer was not successful. Test case can't be performed.");
		return;
	}

	return 1;
}

sub TC_initialization {

	#--------------------------------------------------------------
    # INITIALIZE RECORD HANDLER
    #    
	S_w2rep("Initialize Record Handler");
	$record_handler = EDR_init_RecordHandler() || return;

	S_w2log(1, "Power on ECU and start CAN trace");
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');
    CA_trace_start();
    GDCOM_init () ; # To fetch info for CD from mapping_diag

	S_w2log(1, "Clear crash recorder");
    PD_ClearCrashRecorder();
    S_wait_ms(2000);

	S_w2log(1, "Clear fault memory");
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	#--------------------------------------------------------------
    # CRASH PREPARATION
	S_w2log(1, "Prepare crash" );

	
	# PREPARE CRASH AND INITIALIZE EQUIPMENT
	S_w2rep("Get crash settings for crash $tcpar_Crashcode1");
	my $crashDetails_href1 = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode1};
	$crashSettings_href -> {$tcpar_Crashcode1} = CSI_GetCrashDataFromMDS($crashDetails_href1);
	if(not defined $crashSettings_href -> {$tcpar_Crashcode1}) {
		S_set_error("Crash code $tcpar_Crashcode1 not defined in given result DB. Test case will be aborted.", 110);
		return;
	}
	
	my $crashDetails_href2 = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode2};
	$crashSettings_href -> {$tcpar_Crashcode2} = CSI_GetCrashDataFromMDS($crashDetails_href2);
	if(not defined $crashSettings_href -> {$tcpar_Crashcode2}) {
		S_set_error("Crash code $tcpar_Crashcode2 not defined in given result DB. Test case will be aborted.", 110);
		return;
	}


	my $crashDetails_href3 = {"RESULTDB" => $tcpar_ResultDB, 'CRASHNAME'=> $tcpar_Crashcode3};
	$crashSettings_href -> {$tcpar_Crashcode3} = CSI_GetCrashDataFromMDS($crashDetails_href3);
	if(not defined $crashSettings_href -> {$tcpar_Crashcode3}) {
		S_set_error("Crash code $tcpar_Crashcode3 not defined in given result DB. Test case will be aborted.", 110);
		return;
	}

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log(1, "Crashcode: $tcpar_Crashcode1, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)");
	
	S_w2log(1, "Set environments for crash as per result DB");
	CSI_PrepareEnvironment(($crashSettings_href -> {$tcpar_Crashcode1}), 'init_complete');
	S_wait_ms(2000);

    S_w2log(1, "Read and evaluate fault memory before stimulation");
    my $faultsBeforeStimulation_obj = LIFT_FaultMemory -> read_fault_memory('Bosch');
    my $faultsVerdict = $faultsBeforeStimulation_obj -> evaluate_faults({});
    return 0 unless ($faultsVerdict eq 'VERDICT_PASS');

	return 1;
}

sub TC_stimulation_and_measurement {

    $edrNumberOfEventsToBeStored = SYC_EDR_get_NumberOfEventsToBeStored();
    unless(defined $edrNumberOfEventsToBeStored){
        S_set_error("Number of records to be stored in EDR not available in SYC - add or overwrite with Custlibrary Function");
        return;
    }

	my $crashSettings = $crashSettings_href -> {$tcpar_Crashcode1};
	#--------------------------------------------------------------------------------------------------#
	#Prepare crash
	CSI_LoadCrashSensorData2Simulator( $crashSettings );
	S_wait_ms(2000);
	
	CSI_PrepareEnvironment( $crashSettings, 'before_crash_same_cycle','normal' );
    S_wait_ms(1000);
		
	#Inject crash
	S_teststep("Inject '$tcpar_Crashcode1'", 'AUTO_NBR');
	CSI_TriggerCrash();
	S_wait_ms(15000);#wait time after crash
	
	if (defined $tcpar_COMsignalsAfterCrash){
		foreach my $signal (keys %{$tcpar_COMsignalsAfterCrash})
		{
			my $dataOnCOM = $tcpar_COMsignalsAfterCrash -> {$signal};
			S_w2rep("Signal =$signal,Data to be sent=$dataOnCOM");
			COM_setSignalState($signal,$dataOnCOM);
		}
	}
		
	S_teststep("Read the  supplier EDID '$tcpar_SDID' value in most recent Entry of EDR after injecting $tcpar_Crashcode1",
	               'AUTO_NBR', "read_the_data_$tcpar_Crashcode1");			#measurement 1
    S_teststep_2nd_level("Read and print all EDR data", 'AUTO_NBR');
	my $dataStoragePath1 = "$main::REPORT_PATH/".S_get_TC_number()."_".$tcpar_Crashcode1;	
	PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');	
	EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
								"CrashLabel" => $tcpar_Crashcode1."_$tcpar_SDID",
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath1,);	
									

	$crashSettings = $crashSettings_href -> {$tcpar_Crashcode2};
	#--------------------------------------------------------------------------------------------------#
	#Prepare crash
	CSI_LoadCrashSensorData2Simulator( $crashSettings );
	S_wait_ms(2000);
		
	#Inject crash
	S_teststep("Inject '$tcpar_Crashcode2'", 'AUTO_NBR');
	CSI_TriggerCrash();
	S_wait_ms(10000);
	
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep("Read the  supplier EDID '$tcpar_SDID' value in most recent Entry of EDR after injecting $tcpar_Crashcode2",
	               'AUTO_NBR', "read_the_data_$tcpar_Crashcode2");			#measurement 1
	
	
	my $dataStoragePath2 = "$main::REPORT_PATH/".S_get_TC_number()."_".$tcpar_Crashcode2;
		
	PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');
		
	S_teststep_2nd_level("Read and print all EDR data", 'AUTO_NBR');
		
	EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
								"CrashLabel" => $tcpar_Crashcode2."_$tcpar_SDID",
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath2,
								);	

	$crashSettings = $crashSettings_href -> {$tcpar_Crashcode3};
	#--------------------------------------------------------------------------------------------------#
	#Prepare crash
	CSI_LoadCrashSensorData2Simulator( $crashSettings );
	S_wait_ms(2000);
			
	#Inject crash
	S_teststep("Inject '$tcpar_Crashcode3'", 'AUTO_NBR');
	CSI_TriggerCrash();
	S_wait_ms(20000);							
	
	S_teststep("Read the  supplier EDID '$tcpar_SDID' value in most recent Entry of EDR after injecting $tcpar_Crashcode3",
	               'AUTO_NBR', "read_the_data_$tcpar_Crashcode3");			#measurement 1
	
	
	my $dataStoragePath3 = "$main::REPORT_PATH/".S_get_TC_number()."_".$tcpar_Crashcode3;
		
	PD_ECUlogin() if($tcpar_DiagType eq 'ProdDiag');
		
	S_teststep_2nd_level("Read and print all EDR data", 'AUTO_NBR');
		
	EDR_ReadAndStoreAllRecords ("DiagType" => $tcpar_DiagType,
								"CrashLabel" => $tcpar_Crashcode3."_$tcpar_SDID",
								"NbrOfRecords" =>  $edrNumberOfEventsToBeStored,
								"StoragePath" => $dataStoragePath3,
								);	
	
	
	# add supplier section
	############################
	
	S_teststep_2nd_level("Extract and parse supplier data", 'AUTO_NBR');
	my $recordStructureSupplier_href = EDR_ReadEDR_Record_structure_info_from_mapping_NOERROR('Supplier',0,'Mapping_EDR','SUPPLIER_EDIDS');
	if(not defined $recordStructureSupplier_href){
		S_set_warning("Supplier EDID section is not available in EDR mapping.\n".
		"Generate mapping newly with this section if the EDID to be evaluated is part of Supplier section");
		return 1;
	}
	
	foreach my $crashlabel (@{$crashCodes_aref})
	{
		foreach my $recordNbr (1..$edrNumberOfEventsToBeStored)
		{
			#--------------------------------------------------------------
			# ADD SUPPLIER EDIDS   
			# ----------------------------------------------------------- 
			my $recordAvailable = $record_handler -> IsRecordAvailable("CrashLabel" => $crashlabel."_$tcpar_SDID",
			                                                           "RecordNumber"=> $recordNbr);
			next unless($recordAvailable);
			
			if ($recordAvailable and defined $tcpar_EDIDNr_Supplier)
			{	
				my $recordData_aref = $record_handler -> GetRawEDID( "EDIDnr" => $tcpar_EDIDNr_Supplier,
																	"RecordNumber" => $recordNbr,
																	"CrashLabel" => $crashlabel."_$tcpar_SDID",);

				$record_handler -> AddCrashRecord(  "RecordNumber" => $recordNbr,
													"CrashLabel"   => $crashlabel."_$tcpar_SDID".'_Supplier',
													"RecordStructureInfo" => $recordStructureSupplier_href,
													"RawDataGeneric" => $recordData_aref,);
				$record_handler -> PrintRawEDIDs( "RecordNumber" => $recordNbr,
													"CrashLabel" => $crashlabel."_$tcpar_SDID".'_Supplier',);
			}
			else
			{
				S_w2rep("Requested EDR record is empty. No supplier edids will be printed.");
				next;
			}
		}

		# next crash code
	}
	
	return 1;
}

sub TC_evaluation {

    foreach my $crash (1..3)
	{

	
		my ($label, $expected_data,$crash_label);
		if($crash == 1){
			$label= $tcpar_Crashcode1;
			$expected_data = $tcpar_Expected_Value1;
		}
		elsif($crash == 2){
			$label= $tcpar_Crashcode2;
            $expected_data = $tcpar_Expected_Value2;
		}
		else {
			$label= $tcpar_Crashcode3;
            $expected_data = $tcpar_Expected_Value3;
		}
		
		if(defined $tcpar_EDIDNr_Supplier){
			$crash_label = $label."_$tcpar_SDID".'_Supplier';
		}
		else {
			$crash_label=$label."_$tcpar_SDID"
		}
		
		foreach my $recordNbr (1..$edrNumberOfEventsToBeStored){
		    
		    my $expectedValue = $expected_data -> {"Record_$recordNbr"};
		    next unless($expectedValue);
		    
    		my $dataElement = $record_handler -> GetDataElementEDID("EDIDnr" => $tcpar_EDID,
    															  "RecordNumber" => $recordNbr,
    															  "CrashLabel" => $crash_label);

            S_teststep_2nd_level("Validate Supplier EDID $tcpar_SDID ($dataElement) value in record $recordNbr after crash $crash_label",
                                    'AUTO_NBR',"$crash_label\_$recordNbr");

            my $edidExists = $record_handler -> CheckEdidExistence("EDIDnr" => $tcpar_EDID."_".$recordNbr,
                                                                  "RecordNumber" => $recordNbr,
                                                                  "CrashLabel" => $crash_label);

            my $individualRecord = $tcpar_EDID."_".$recordNbr;
            if($edidExists == 0){
                $individualRecord = $tcpar_EDID;
            }

    		my $decodedData = $record_handler -> GetDecodedEDID( "EDIDnr" => $individualRecord, 
    														 "RecordNumber" => $recordNbr, 
    														 "CrashLabel" => $crash_label);

    		my $detected_data = $decodedData -> {"DataValue"};
    
    		unless(defined $detected_data) {
    			S_set_error("No EDID data samples could be obtained for EDID $tcpar_EDID in record $recordNbr!", 110);
    			next;
    		}

            EVAL_evaluate_value ( "EDID_$tcpar_EDID\_Evaluation", $detected_data,'==', $expectedValue);             #evaluation 1
            S_teststep_expected($expectedValue, "$crash_label\_$recordNbr");
            S_teststep_detected($detected_data, "$crash_label\_$recordNbr");
		}
			

		
	}

	return 1;
}

sub TC_finalization {

	S_w2rep("Start test case finalization...");

	foreach my $recordNumber (1..$edrNumberOfEventsToBeStored)
	{
		$record_handler -> DeleteRecord("CrashLabel" => $tcpar_Crashcode1."_$tcpar_SDID", "RecordNumber" => $recordNumber);
		$record_handler -> DeleteRecord("CrashLabel" => $tcpar_Crashcode2."_$tcpar_SDID", "RecordNumber" => $recordNumber);
		$record_handler -> DeleteRecord("CrashLabel" => $tcpar_Crashcode3."_$tcpar_SDID", "RecordNumber" => $recordNumber);
		$record_handler -> DeleteRecord("CrashLabel" => $tcpar_Crashcode1."_$tcpar_SDID"."_Supplier", "RecordNumber" => $recordNumber);
		$record_handler -> DeleteRecord("CrashLabel" => $tcpar_Crashcode2."_$tcpar_SDID"."_Supplier", "RecordNumber" => $recordNumber);
		$record_handler -> DeleteRecord("CrashLabel" => $tcpar_Crashcode3."_$tcpar_SDID"."_Supplier", "RecordNumber" => $recordNumber);
	}

	# Erase EDR
    PD_ClearCrashRecorder_NOERROR();
    S_wait_ms(2000);

	# Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(2000);

	# Read fault memory after clearing and erasing EDR
    PD_ReadFaultMemory();   

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

	return 1;
}


1;
