#### TEST CASE MODULE
package TC_EDID_Simple_Validation;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_evaluation;
use FuncLib_SYC_INTERFACE;
use FuncLib_EDR_Framework;

##################################

our $PURPOSE = "To test EDIDs reported in EDR";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDID_Simple_Validation

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Inject a Crash <Crashcode>

2.Read EDR

3. Read  <EDID>


I<B<Evaluation>>

1. -

2.<ExpectedNbrOfRecords> should be observed.

3. <ExpectedValue_Decoded>  should have data as per the Crash injected




I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Crashcode' => if not given, all stored records will be evaluated
	HASH 'ExpectedValue_Decoded' => can also be a scalar if there is only one record or expected value is the same for all records
	HASH 'ExpectedValue_Raw' => can also be a scalar if there is only one record or expected value is the same for all records
	SCALAR 'EvalTolerance_abs' => 
	SCALAR 'purpose' => purpose of test case
	SCALAR 'EDID' => 
	SCALAR 'ExpectedNbrOfRecords' => 
	SCALAR 'EvalOperator' => check EDR_Eval_evaluate_EDID_Decoded and EDR_Eval_evaluate_EDID_Raw_Hex for options


=head2 PARAMETER EXAMPLES

	purpose = 'To EDID TEnd which indicates timing of event end relative to T0'
	EDID = 2055
	ExpectedNbrOfRecords = 1 # optional
	Crashcode = 'Single_EDR_Side_above_8kph_NoDeployment;5' # optional
	ExpectedValue_Decoded = %('Record_1' => 32)
	EvalTolerance_abs = 3
	EvalOperator = '>'

	purpose = 'To EDID TEnd which indicates timing of event end relative to T0'
	EDID = 2055
	ExpectedNbrOfRecords = 1 # optional
	Crashcode = 'Single_EDR_Side_above_8kph_NoDeployment;5' # optional
	ExpectedValue_Raw = 32
	EvalOperator = '=='

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_EDID;
my $tcpar_ExpectedNbrOfRecords;
my $tcpar_Crashcode;
my $tcpar_ExpectedValue_Decoded;
my $tcpar_EvalTolerance_abs;
my $tcpar_ExpectedValue_Raw;
my $tcpar_EvalOperator;

################ global parameter declaration ###################
#add any global variables here
my (
		$record_handler,
		$storedCrashLabels_aref,
	);

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_EDID =  S_read_mandatory_testcase_parameter( 'EDID' );
	$tcpar_ExpectedNbrOfRecords =  S_read_optional_testcase_parameter( 'ExpectedNbrOfRecords' );
	if(not defined $tcpar_ExpectedNbrOfRecords){
		$tcpar_ExpectedNbrOfRecords = SYC_EDR_get_NumberOfEventsToBeStored();
	}
	$tcpar_Crashcode =  S_read_optional_testcase_parameter( 'Crashcode');
	$tcpar_ExpectedValue_Decoded =  S_read_optional_testcase_parameter( 'ExpectedValue_Decoded','byref' );
	$tcpar_ExpectedValue_Raw =  S_read_optional_testcase_parameter( 'ExpectedValue_Raw','byref' );
	$tcpar_EvalTolerance_abs =  S_read_optional_testcase_parameter( 'EvalTolerance_abs' );
	$tcpar_EvalOperator =  S_read_optional_testcase_parameter( 'EvalOperator' );
	$tcpar_EvalOperator = '==' if(not defined $tcpar_EvalOperator);
	if ((not defined $tcpar_ExpectedValue_Decoded) and (not defined $tcpar_ExpectedValue_Raw)){
		S_set_error(" Missing parameter 'ExpectedValue_Decoded' or 'ExpectedValue_Raw'");
		return 1;
	}

	return 1;
}

sub TC_initialization {

	# INITIALIZE RECORD AND CRASH HANDLER 
	S_w2rep("Initialize Record and Crash Handler", 'DodgerBlue');
	$record_handler = EDR_init_RecordHandler() || return;

	return 1;
}

sub TC_stimulation_and_measurement {

    if(defined $tcpar_Crashcode) {
        push(@{$storedCrashLabels_aref}, $tcpar_Crashcode);
    }
    else {
        $storedCrashLabels_aref = $record_handler -> GetListOfStoredRecords();
    }

	foreach my $crashCode (@{$storedCrashLabels_aref}){
		S_teststep("Get data of stored crash $crashCode which is injected previously", 'AUTO_NBR');
	}
	return 1;
}

sub TC_evaluation {
	foreach my $crashCode (@{$storedCrashLabels_aref}){
		foreach my $recordNbr (1..$tcpar_ExpectedNbrOfRecords)
		{
			next unless($record_handler -> IsRecordAvailable("CrashLabel" => $crashCode,"RecordNumber" => $recordNbr ));
			if (defined $tcpar_ExpectedValue_Decoded){
				my $thisRecordExpectedValue;
				if(ref($tcpar_ExpectedValue_Decoded) eq 'HASH'){
					$thisRecordExpectedValue = $tcpar_ExpectedValue_Decoded -> {"Record_$recordNbr"};
				}
				else{
					$thisRecordExpectedValue = $tcpar_ExpectedValue_Decoded;
				}
				S_teststep("Validate EDID $tcpar_EDID for crash $crashCode", 'AUTO_NBR');       #evaluation 1
				EDR_Eval_evaluate_EDID_Decoded ("EDIDnr" => $tcpar_EDID,
								"RecordNumber" => $recordNbr,
								"CrashLabel" => $crashCode,
								"ExpectedValueDecoded" => $thisRecordExpectedValue,
								"EvalOperator" => $tcpar_EvalOperator,
								"EvalTolerance_abs" => $tcpar_EvalTolerance_abs);
			}
			if (defined $tcpar_ExpectedValue_Raw){
				my $thisRecordExpectedValue;
				if(ref($tcpar_ExpectedValue_Raw) eq 'HASH'){
					$thisRecordExpectedValue = $tcpar_ExpectedValue_Raw->{"Record_$recordNbr"};
				}
				else{
					$thisRecordExpectedValue = $tcpar_ExpectedValue_Raw;
				}
				S_teststep("Validate EDID $tcpar_EDID for crash $tcpar_Crashcode", 'AUTO_NBR');       #evaluation 1
				EDR_Eval_evaluate_EDID_Raw_Hex ("EDIDnr" => $tcpar_EDID,
								"RecordNumber" => $recordNbr,
								"CrashLabel" => $crashCode,
								"Expected_Raw_Hex" => $thisRecordExpectedValue,
								"EvalOperator" => $tcpar_EvalOperator);
			}
		} # next record
	} # next crash
	return 1;
}

sub TC_finalization {

	return 1;
}


1;
