#### DONT MODIFY THIS SECTION ####
use strict;
###-------------------------------
our $VERSION = q$Revision: 1.4 $;
our $HEADER = q$Header: DSM/TC_DSM_InvalidLength.pm 1.4 2018/01/19 00:14:24ICT Okrusch Thomas (CC-PS/EPS2) (OUT2SI) develop  $;

##################################

#-------------------------------------------------------------------------------
#---->  TC_DSM_InvalidLength
#-------------------------------------------------------------------------------

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE 

   TC_DSM_InvalidLength

=head1 PURPOSE

   To check Invalid length request response is NR_incorrectMessageLengthOrInvalidFormat

=cut

=head1 TESTCASE DESCRIPTION

    [parameters used]
     
    Testcase Parameters : 
    
    optional parameter  : purpose, address_mode, Key, RoutineControlOption, LoopId, DismantlerInfo
    Mandatory Parameter : Request, Response
    
    [initialisation]
    ECU On
    Normal Mode
    Speed = 0
    
    [stimulation & measurement]
        Enter supported session for Request
        form invalid length request, and send the same.      

    [evaluation]
      No special evaluation
      
    [finalisation]
        UZ off
        Ubatt 0 volt

=head2 PARAMETER NAMES

        SCALAR 'purpose'                --> Purpose of the Testcase
        SCALAR 'address_mode'           --> addressing mode (Functional , Physical, Disposal)(optional)
        SCALAR 'Request'       			--> Request for each service  
		SCALAR 'Response'       		--> Expected response for the Request
        SCALAR 'Key'					--> Valid key for security access
		SCALAR 'RoutineControlOption'   --> Routine Control Option
		SCALAR 'LoopId'					--> Loop to be fired
		SCALAR 'DismantlerInfo'			--> Dismantler information to be written

=head2 PARAMETER EXAMPLES
[TC_DSM_InvalidLength.NRC13_Service_ExecuteSPL_00]
purpose					= 'Check NRC 13 for service 31 01 E2 00 00 for invalid length request'
Request					= 'RoutineControl_StartRoutine_ExecuteDisposalProgramLoader'
RoutineControlOption	= '00'
address_mode			= 'Disposal'
Response				= 'NR_incorrectMessageLengthOrInvalidFormat'
=cut

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> END OF DOCUMENTATION >>>>>>>>>>>>

package  TC_DSM_InvalidLength;

use LIFT_general;   # this is always required
use LIFT_evaluation;
use LIFT_PD;
use INCLUDES_Project;
use GENERIC_DCOM;
use DCOM_FaultMonitoring;

my  $TC_ID   = "TC_DSM_InvalidLength";
our $PURPOSE = 'To check supported services in a given session';

my $tcpar_purpose;
my $tcpar_address_mode;
my $tcpar_Request;
my $tcpar_Response;
my $tcpar_Key;
my $tcpar_RoutineControlOption;
my $tcpar_LoopId;
my $tcpar_DismantlerInfo;
my $TP_handle;

sub TC_set_parameters
{
   
   $tcpar_purpose               = GDCOM_tcpar_optional  ('purpose'); 
   $tcpar_address_mode          = GDCOM_tcpar_optional  ('address_mode');
   $tcpar_Request			    = GDCOM_tcpar_mandatory ('Request');
   $tcpar_Response			    = GDCOM_tcpar_mandatory ('Response');
   $tcpar_Key        			= GDCOM_tcpar_optional  ('Key');
   $tcpar_RoutineControlOption  = GDCOM_tcpar_optional  ('RoutineControlOption');
   $tcpar_LoopId				= GDCOM_tcpar_optional  ('LoopId');
   $tcpar_DismantlerInfo		= GDCOM_tcpar_optional  ('DismantlerInfo');
   
   return 1;
}# Ends TC_set_parameters

sub TC_initialization
{
   GDCOM_init( 'ECU_on' , 'FCM_DEL' , 'CA_CONFIG');    
   return 1;
}# Ends TC_initialization

sub TC_stimulation_and_measurement 
{
    # Local variables defined which are being used.
    my(
        $session,
        $request,
        $response,
        $sample_request,
        $service,
        $RequestInfo,
        @split_data,
        %DataValue,
        $NRCInfo,
    );
	
    GDCOM_w2TestStep("Heading" , "\nSTIM:");
	$tcpar_address_mode = lc($tcpar_address_mode); #Test
	
    if (defined $tcpar_address_mode)
    { 
        GDCOM_set_addressing_mode($tcpar_address_mode);
    }
	
	if ( $tcpar_address_mode =~ m/^disposal$/i){
		my $msg_ID = $LIFT_PROJECT::Defaults->{"CUSTOMER_DIAGNOSIS"}{'RequestID_disposal'};
		my $cycle  = 4500;
		my $msg_aref = $LIFT_PROJECT::Defaults->{"CUSTOMER_DIAGNOSIS"}{"TesterPresent_SupressPosResp"}{"Requests"}{"REQ_TesterPresent_SupressPosResp"}{'Requests'};
		$TP_handle = GDCOM_start_CyclicTesterPresent($msg_aref,$msg_ID,$cycle);
	}
	else{
		$TP_handle = GDCOM_start_CyclicTesterPresent();
	}
	
    #Read Key data if defined
    if (defined $tcpar_Key)
    {
        $DataValue{'Key'} = $tcpar_Key;
    }
    
    #Read RoutineControlOption data if defined
    if (defined $tcpar_RoutineControlOption)
    {
        $DataValue{'RoutineControlOption'} = $tcpar_RoutineControlOption;
    }

	#Read LoopId data if defined
    if (defined $tcpar_LoopId)
    {
        $DataValue{'LoopId'} = $tcpar_LoopId;
    }
	
	#Read DismantlerInfo data if defined
    if (defined $tcpar_DismantlerInfo)
    {
        $DataValue{'DismantlerInfo'} = $tcpar_DismantlerInfo;
    }	

        #Splits the sample request to read the first data to add comment for which service the test is being done   
        @split_data = split(/_/,$tcpar_Request);
        $service = $split_data[0];
        
        GDCOM_comment('M',"$tcpar_Response Check for $service");

        $RequestInfo = GDCOM_getRequestInfofromMapping($tcpar_Request);
		S_wait_ms(2000);
                
        # Loop2: The loop runs for all the allowed sessions. 
        foreach $session(@{$RequestInfo->{'allowed_in_sessions'}})
        {
            # Enters the sessions and validates the same.
            GDCOM_StartSession ($session);
			DIAG_request_DependentServices($tcpar_Request);

            $request  = "REQ_".$tcpar_Request;
            
            my $modified_request = GDCOM_getRequestLabelValue("$request",\%DataValue);
			
			S_w2rep(" modified_request = $modified_request");
			
            my @ReqStrToAry = split(' ', $modified_request);
            my $TotalReqLen = scalar(@ReqStrToAry);
            S_w2rep("TotalReqLen = $TotalReqLen");
            $NRCInfo = GDCOM_getNRCfromMapping($split_data[0],"$tcpar_Response");
                        
            # Loop3: The below loop runs for all the combinations below the exact length.
            for (my $AddNoOfBytes = 1; $AddNoOfBytes < $TotalReqLen; $AddNoOfBytes++) 
            {
                $modified_request = GDCOM_requestlength_manipulation($request,\%DataValue,-$AddNoOfBytes);
                GDCOM_request($modified_request, $NRCInfo->{'Response'} , 'strict');
            }# Ends Loop3

            # Loop4: The below loop runs for all the combinations above the exact length.
            for (my $AddNoOfBytes = 1; $AddNoOfBytes < 3; $AddNoOfBytes++) 
            {
                $modified_request = GDCOM_requestlength_manipulation($request,\%DataValue,+$AddNoOfBytes);
                GDCOM_request($modified_request, $NRCInfo->{'Response'} , 'strict');
            }# Ends Loop4
            
        }# Ends Loop2
	
    return 1;
}# Ends TC_stimulation_and_measurement

sub TC_evaluation
{
    GDCOM_comment('M',"Evaluation is done in stimulation_and_measurement section");
	
    return 1;
}# Ends TC Evaluation 

sub TC_finalization
{
    GDCOM_final('FCM_DEL','ECU_OFF');
    GDCOM_stop_CyclicTesterPresent($TP_handle);
    return 1;
}# Ends TC_finalization

1;

#Ends Package TC_DSM_InvalidLength

