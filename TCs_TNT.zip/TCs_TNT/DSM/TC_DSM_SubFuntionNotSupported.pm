#### DONT MODIFY THIS SECTION ####
use strict;
###-------------------------------
our $VERSION = q$Revision: 1.4 $;
our $HEADER = q$Header: DSM/TC_DSM_SubFuntionNotSupported.pm 1.4 2018/01/19 00:14:25ICT Okrusch Thomas (CC-PS/EPS2) (OUT2SI) develop  $;

##################################

#-------------------------------------------------------------------------------
#---->  TC_DSM_SubFuntionNotSupported 
#-------------------------------------------------------------------------------

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE 

   TC_DSM_SubFuntionNotSupported

=head1 PURPOSE

   To check Response of request for invalid sub function.

=cut

=head1 TESTCASE DESCRIPTION

    [parameters used]
     
    Testcase Parameters : 
    
    optional parameter  : purpose, address_mode, RoutineControlOption, LoopId, Key
    Mandatory Parameter : Service, Response,
    
    [initialisation]
    ECU On
    Normal Mode
    Speed = 0
    
    [stimulation & measurement]
        Enter supported session for request
        form request with invalid sub function. and send the same     
  
    [evaluation]
      No special evaluation
      
    [finalisation]
        UZ off
        Ubatt 0 volt

=head2 PARAMETER NAMES

      SCALAR 'purpose'					--> Purpose of the Testcase
      SCALAR 'address_mode'				--> addressing mode (Functional , Physical)(optional)
      SCALAR 'Service'        			--> Service from which NRC to be tested
	  SCALAR 'Response'        			--> Expected NRC
	  SCALAR 'RoutineControlOption'     --> Read valid routine control option
	  SCALAR 'LoopId'        			--> Read valid Loop ID.
	  SCALAR 'Key'        				--> Valid key for security access

=head2 PARAMETER EXAMPLES
[TC_CD_SubFuntionNotSupported.SubFunNotSupported_Service31]   #ID: SRTP_DIS_1777
purpose					= 'Check NRC 12 for service 31 for sub function not supported'
Service					= 'RoutineControl'
Response				= 'NR_subFunctionNotSupported'
RoutineControlOption	= '00'
LoopId					= '01'
address_mode			= 'Disposal'
=cut

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> END OF DOCUMENTATION >>>>>>>>>>>>

package  TC_DSM_SubFuntionNotSupported;

use LIFT_general;   # this is always required
use LIFT_evaluation;
use LIFT_PD;
use INCLUDES_Project;
use GENERIC_DCOM;
use DCOM_FaultMonitoring;
use Data::Dumper;

my  $TC_ID   = "TC_DSM_SubFuntionNotSupported";
our $PURPOSE = 'To check supported services in a given session to check the Sub function not supported';

my $tcpar_purpose;
my $tcpar_address_mode;
my $tcpar_Service;
my $tcpar_Response;
my $tcpar_RoutineControlOption;
my $tcpar_LoopId;
my $tcpar_Key;
my $TP_handle;

sub TC_set_parameters
{
   
    $tcpar_purpose              = GDCOM_tcpar_optional  ('purpose'); 
    $tcpar_address_mode         = GDCOM_tcpar_optional  ('address_mode');
    $tcpar_Service			    = GDCOM_tcpar_mandatory ('Service');
    $tcpar_Response			    = GDCOM_tcpar_mandatory ('Response');
    $tcpar_RoutineControlOption = GDCOM_tcpar_optional  ('RoutineControlOption');
	$tcpar_LoopId 				= GDCOM_tcpar_optional  ('LoopId');
	$tcpar_Key	 				= GDCOM_tcpar_optional  ('Key');
   
    return 1;
}# Ends TC_set_parameters

sub TC_initialization
{
    GDCOM_init( 'ECU_on' , 'FCM_DEL' , 'CA_CONFIG');    
    return 1;
}# Ends TC_initialization

sub TC_stimulation_and_measurement 
{
	my(
		$session,
        $index,
        $SubFunInfo,
        $SubFunKey,
        $Lp3,
        $NRCInfo,
        $mode,
		$ServiceInfo,
		@validSubFunAry,
		@InvalidSet,
		$ID,
		%DataValue,
    );
	
	my $DiagMapping = $LIFT_PROJECT::Defaults->{"Mapping_DIAG"};	
	
    GDCOM_w2TestStep("Heading" , "\nSTIM:");
	$tcpar_address_mode = lc($tcpar_address_mode); #Test
	
    if (defined $tcpar_address_mode)
    { 
        GDCOM_set_addressing_mode($tcpar_address_mode);
    }
	
	if ( $tcpar_address_mode =~ m/^disposal$/i){
		my $msg_ID = $LIFT_PROJECT::Defaults->{"CUSTOMER_DIAGNOSIS"}{'RequestID_disposal'};
		my $cycle  = 4500;
		my $msg_aref = $LIFT_PROJECT::Defaults->{"CUSTOMER_DIAGNOSIS"}{"TesterPresent_SupressPosResp"}{"Requests"}{"REQ_TesterPresent_SupressPosResp"}{'Requests'};
		$TP_handle = GDCOM_start_CyclicTesterPresent($msg_aref,$msg_ID,$cycle);
	}
	else{
		$TP_handle = GDCOM_start_CyclicTesterPresent();
	}

    #Read RoutineControlOption data if defined
    if (defined $tcpar_RoutineControlOption)
    {
        $DataValue{'RoutineControlOption'} = $tcpar_RoutineControlOption;
    }
    #Read LoopId data if defined
    if (defined $tcpar_LoopId)
    {
        $DataValue{'LoopId'} = $tcpar_LoopId;
    }
    #Read Key data if defined
    if (defined $tcpar_Key)
    {
        $DataValue{'Key'} = $tcpar_Key;
    }
	
    if (($tcpar_address_mode eq 'physical') or ($tcpar_address_mode eq 'disposal'))
    {
        $mode = 'strict'
    }
    
    if ($tcpar_address_mode eq 'Functional')
    {
        $mode = 'quiet'
    }

	#Get a reference to the supported sub functions
	$SubFunInfo = GDCOM_getSupportedSubFunsfromMapping($tcpar_Service);
	S_wait_ms(2000);

    #$index = 0;
	#Get all supported valid sub functions for the service under test
    foreach $SubFunKey (keys  %$SubFunInfo)                  
    {
		push(@validSubFunAry,$SubFunInfo->{$SubFunKey});
    }
	
	#Get all invalid sub functions from supported valid sub functions
    @InvalidSet = GDCOM_GenerateInvalidSet(\@validSubFunAry, $tcpar_Service);
	
	$ServiceInfo = GDCOM_getServiceInfofromMapping($tcpar_Service);
	S_wait_ms(2000);
                
    # Loop2: The loop runs for all the allowed sessions. 
	if($tcpar_address_mode ne 'disposal'){
		my $valid_Request = 0;
		foreach my $request (keys (%{$DiagMapping->{'Requests_Responses'}})){
			#trace through Diag mapping file check for all the requests for service under test.
			if($request =~ /\Q$tcpar_Service\E_/ ){
				my $request_Info = GDCOM_getRequestInfofromMapping($request);
				foreach my $session (@{$request_Info->{'allowed_in_sessions'}}){
					unless($session =~ /^Disposal/){
						$valid_Request = 1;
						last;						
					}
				}
				if($valid_Request == 1){
					foreach my $session (@{$request_Info->{'allowed_in_sessions'}}){
						GDCOM_StartSession($_, 'CheckActiveSession');
						DIAG_request_DependentServices($request);
						my $actual_ReqString = $request_Info->{'Requests'}{"REQ_".$request}{'Request'};
						my @actual_ReqArray = split(/ /,$actual_ReqString);
						if($actual_ReqArray[$#actual_ReqArray] eq 'RoutineControlOption'){
							$actual_ReqArray[$#actual_ReqArray] = $tcpar_RoutineControlOption;
						}
						elsif($actual_ReqArray[$#actual_ReqArray] eq 'LoopId'){
							$actual_ReqArray[$#actual_ReqArray] = $tcpar_LoopId;
						}
						elsif($actual_ReqArray[$#actual_ReqArray] eq 'Key'){
							$actual_ReqArray[$#actual_ReqArray] = $tcpar_Key;
						}						
						else{
							#do nothing
						}
						foreach(@InvalidSet){
							$actual_ReqArray[1] = $_;
							my $modified_Request = join(' ', @actual_ReqArray);
							GDCOM_request($modified_Request, $NRCInfo->{'Response'} , $mode);
						}
					}
					$valid_Request = 0; #reset
				}
			}
		}
	}
	else{
		my @allowad_session = ("DisposalSession","DisposalSession_supressPOSResp");
		my $valid_Request = 0;
		$NRCInfo = GDCOM_getNRCfromMapping($tcpar_Service,$tcpar_Response);
		foreach my $request (keys (%{$DiagMapping->{'Requests_Responses'}})){
			#trace through Diag mapping file check for all the requests for service under test.
			if($request =~ /\Q$tcpar_Service\E_/ ){
				my $request_Info = GDCOM_getRequestInfofromMapping($request);
				foreach my $session (@{$request_Info->{'allowed_in_sessions'}}){
					if($session =~ /^Disposal/){
						$valid_Request = 1;
						last;						
					}
				}
				if($valid_Request == 1){
					foreach(@allowad_session){
						GDCOM_StartSession($_);
						DIAG_request_DependentServices($request);
						my $actual_ReqString = $request_Info->{'Requests'}{"REQ_".$request}{'Request'};
						my @actual_ReqArray = split(/ /,$actual_ReqString);
						if($actual_ReqArray[$#actual_ReqArray] eq 'RoutineControlOption'){
							$actual_ReqArray[$#actual_ReqArray] = $tcpar_RoutineControlOption;
						}
						elsif($actual_ReqArray[$#actual_ReqArray] eq 'LoopId'){
							$actual_ReqArray[$#actual_ReqArray] = $tcpar_LoopId;
						}
						elsif($actual_ReqArray[$#actual_ReqArray] eq 'Key'){
							$actual_ReqArray[$#actual_ReqArray] = $tcpar_Key;
						}						
						else{
							#do nothing
						}
						foreach(@InvalidSet){
							$actual_ReqArray[1] = $_;
							my $modified_Request = join(' ', @actual_ReqArray);
							GDCOM_request($modified_Request, $NRCInfo->{'Response'} , $mode);
						}
					}
					$valid_Request = 0; #reset
				}
			}
		}
	}
    return 1;
}# Ends TC_stimulation_and_measurement

sub TC_evaluation
{
    # Local variables defined which are being used.


    return 1;
}# Ends TC Evaluation 

sub TC_finalization
{
    GDCOM_final('FCM_DEL','ECU_OFF');
	GDCOM_stop_CyclicTesterPresent($TP_handle);
    return 1;
}# Ends TC_finalization

1;

#Ends Package TC_DSM_SubFuntionNotSupported