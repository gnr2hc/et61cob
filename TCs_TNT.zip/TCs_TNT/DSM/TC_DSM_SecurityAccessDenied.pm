#### DONT MODIFY THIS SECTION ####
use strict;
###-------------------------------
our $VERSION = q$Revision: 1.3 $;
our $HEADER = q$Header: DSM/TC_DSM_SecurityAccessDenied.pm 1.3 2014/02/18 12:33:49ICT BAA1BMH develop  $;

##################################

#-------------------------------------------------------------------------------
#---->  TC_DSM_SecurityAccessDenied 
#-------------------------------------------------------------------------------

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE 

   TC_DSM_SecurityAccessDenied

=head1 PURPOSE

   To check Response of request without required security access

=cut

=head1 TESTCASE DESCRIPTION

    [parameters used]
     
    Testcase Parameters : 
    
    optional parameter  : purpose, address_mode, RoutineControlOption
    Mandatory Parameter : Request, Response
    
    [initialisation]
    ECU On
    Normal Mode
    Speed = 0
    
    [stimulation & measurement]
        Enter supported session for Request
        send the request without taking required security access.     
 
    [evaluation]
      No special evaluation
      
    [finalisation]
        UZ off
        Ubatt 0 volt

=head2 PARAMETER NAMES

        SCALAR 'purpose'                --> Purpose of the Testcase
        SCALAR 'address_mode'           --> addressing mode (Functional , Physical, Disposal)(optional)
        STRING 'Request'       			--> Request for each service  
		STRING 'Response'       		--> Expected response for the Requeste from each service  
		SCALAR 'RoutineControlOption'   --> Routine Control Option

=head2 PARAMETER EXAMPLES
[TC_DSM_SecurityAccessDenied.NRC33_SecurityAccessDenied]
purpose					= 'Check NRC 33 for service 31 executed without security access'
Request					= 'RoutineControl_StartRoutine_ExecuteDisposalProgramLoader'
RoutineControlOption	= '00'
address_mode			= 'Disposal'
Response				= 'NR_securityAccessDenied'
=cut

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> END OF DOCUMENTATION >>>>>>>>>>>>

package  TC_DSM_SecurityAccessDenied;

use LIFT_general;   # this is always required
use INCLUDES_Project;
use GENERIC_DCOM;
use Data::Dumper;

my  $TC_ID   = "TC_DSM_SecurityAccessDenied";
our $PURPOSE = 'To check supported services in a active session';

my $tcpar_purpose;
my $tcpar_address_mode;
my $tcpar_Request;
my $tcpar_Response;
my $tcpar_RoutineControlOption;
my $TP_handle;

sub TC_set_parameters
{
   
    $tcpar_purpose              = GDCOM_tcpar_optional  ('purpose'); 
    $tcpar_address_mode         = GDCOM_tcpar_optional  ('address_mode');
    $tcpar_Request			    = GDCOM_tcpar_mandatory ('Request');
    $tcpar_Response			    = GDCOM_tcpar_mandatory ('Response');
    $tcpar_RoutineControlOption = GDCOM_tcpar_optional  ('RoutineControlOption');
   
    return 1;
}# Ends TC_set_parameters

sub TC_initialization
{
    GDCOM_init( 'ECU_on' , 'FCM_DEL' , 'CA_CONFIG');    
    return 1;
}# Ends TC_initialization

sub TC_stimulation_and_measurement 
{
	# Local variables defined which are being used.
	my(
		$session,
        %DataValue,
		$requestInfo,
	);
	
    GDCOM_w2TestStep("Heading" , "\nSTIM:");
	$tcpar_address_mode = lc($tcpar_address_mode); #Test
	
    if (defined $tcpar_address_mode)
    { 
        GDCOM_set_addressing_mode($tcpar_address_mode);
    }
	
	if ( $tcpar_address_mode =~ m/^disposal$/i){
		my $msg_ID = $LIFT_PROJECT::Defaults->{"CUSTOMER_DIAGNOSIS"}{'RequestID_disposal'};
		my $cycle  = 4500;
		my $msg_aref = $LIFT_PROJECT::Defaults->{"CUSTOMER_DIAGNOSIS"}{"TesterPresent_SupressPosResp"}{"Requests"}{"REQ_TesterPresent_SupressPosResp"}{'Requests'};
		$TP_handle = GDCOM_start_CyclicTesterPresent($msg_aref,$msg_ID,$cycle);
	}
	else{
		$TP_handle = GDCOM_start_CyclicTesterPresent();
	}
    
    #Read RoutineControlOption data if defined
    if (defined $tcpar_RoutineControlOption)
    {
        $DataValue{'RoutineControlOption'} = $tcpar_RoutineControlOption;
    }
	
	#Get the information about request under test.
	$requestInfo = GDCOM_getRequestInfofromMapping($tcpar_Request);
	
	S_wait_ms(2000); #wait

    # Loop: Runs for all the allowed sessions. 
    foreach $session (@{$requestInfo->{'allowed_in_sessions'}})
    {  
		#Enter in to the $session.
		GDCOM_StartSession($session);
		
		#Send the service under test in wrong $session.
		GDCOM_request_general ( "REQ_".$tcpar_Request , $tcpar_Response, \%DataValue);
	}
	
    return 1;
}# Ends TC_stimulation_and_measurement

sub TC_evaluation
{
    
	S_w2rep("Evaluation is done in stimulation_and_measurement by using GDCOM function");

    return 1;
}# Ends TC Evaluation 

sub TC_finalization
{
    GDCOM_final('FCM_DEL','ECU_OFF');
    GDCOM_stop_CyclicTesterPresent($TP_handle);
    return 1;
}# Ends TC_finalization

1;

#Ends Package TC_DSM_SecurityAccessDenied