#### TEST CASE MODULE
package TC_BAT_Health_Status;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.4 $;
our $HEADER =
q$Header: BAT_AB12/TC_BAT_Health_Status.pm 1.4 2018/10/09 11:47:53ICT Phan Khanh Duy (RBVH/EPS24) (PDA1HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_BaselineAcceptanceTest
#TS version in DOORS: 0.8
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;

#include further modules here
use LIFT_PD;
use LIFT_evaluation;
use FuncLib_TNT_GEN;
##################################

our $PURPOSE = "To ensure the functionality Health-State";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_BAT_Health_Status

=head1 PURPOSE

To ensure the functionality Health-State

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Enter all required <plant_mode>

2. Reset ECU

3. Create fault ('rb_sqm_UnexpectedAB1FD_flt') not in while list and wait for <WaitTime_ms>

4. Read Health Status via  rb_prhs_HealthStatusOk_bo


I<B<Evaluation>>

1.

2.

3.

4. Health Status is <Health_State> (rb_prhs_HealthStatusOk_bo= 0)


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'plant_mode' => 
	SCALAR 'Health_State' => 


=head2 PARAMETER EXAMPLES

	purpose = 'to test the Health State is in positive'
	plant_mode = @(1, 3, 5, 6, 10, 12, 13, 14)
	Health_State = '<Test Heading>'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_plant_mode_aref;
my $tcpar_WaitTime_ms;
my $tcpar_Health_State;

################ global parameter declaration ###################
#add any global variables here
my @plant_value_set = (
	0x000000,    #clear plant mode value
	0x000001,    #set plant mode 1 value
	0x000002,    #set plant mode 2 value
	0x000004,    #set plant mode 3 value
	0x000008,    #set plant mode 4 value
	0x000010,    #set plant mode 5 value
	0x000020,    #set plant mode 6 value
	0x000040,    #set plant mode 7 value
	0x000080,    #set plant mode 8 value
	0x000100,    #set plant mode 9 value
	0x000200,    #set plant mode 10 value
	0x000400,    #set plant mode 11 value
	0x000800,    #set plant mode 12 value
	0x001000,    #set plant mode 13 value
	0x002000,    #set plant mode 14 value
	0x004000,    #set plant mode 15 value
	0x008000,    #set plant mode 16 value
	0x010000,    #set plant mode 17 value
	0x020000,    #set plant mode 18 value
	0x040000     #set plant mode 19 value
);
my $value_aref;
my ( $health_state_aref, $state_machine_aref );
###############################################################

sub TC_set_parameters {

	$tcpar_purpose 			= S_read_mandatory_testcase_parameter('purpose');
	$tcpar_plant_mode_aref 	= S_read_mandatory_testcase_parameter( 'plant_mode', 'byref' );
	$tcpar_WaitTime_ms 	 	= S_read_optional_testcase_parameter('WaitTime_ms');
	$tcpar_Health_State 	= S_read_mandatory_testcase_parameter('Health_State');

	return 1;
}

sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Enter all required plant mode", 'AUTO_NBR' );
	_set_plant_mode($tcpar_plant_mode_aref);

	if ( $tcpar_Health_State =~ 'Negative' ) {

		S_teststep( "Create fault ('rb_sqm_UnexpectedAB1FD_flt') not in white list and wait for $tcpar_WaitTime_ms ms", 'AUTO_NBR' );
		PD_Device_configuration( "clear", ['AB1FD'] );
		S_wait_ms($tcpar_WaitTime_ms);

	}

	S_teststep ("Read Fault memory before checking for Health Status", 'NO_AUTO_NBR');
	PD_ReadFaultMemory();

	S_teststep( "Read Health Status via  rb_prhs_HealthStatusOk_bo", 'AUTO_NBR', 'read_health_status' );    #measurement 1
	my $check = PD_GetAddressByName_NOERROR_NOHTML( 'rb_prhs_HealthStatusOk_bo' );
	if ( $check ne '0x1' ) {

		$value_aref = PD_ReadMemoryByName( 'rb_prhs_HealthStatusOk_bo' );
		if ( $tcpar_Health_State =~ 'Negative' ) {

			S_teststep_expected( "Health Status is '$tcpar_Health_State' (rb_prhs_HealthStatusOk_bo = 0)", 'read_health_status'	);                                 #evaluation 1
			S_teststep_detected( "Health Status detected is '$$value_aref[0]'", 'read_health_status' );
			EVAL_evaluate_value( "Health Status", $$value_aref[0], '==', 0 );

		}
		else {

			S_teststep_expected( "Health Status is '$tcpar_Health_State' (rb_prhs_HealthStatusOk_bo = 1)", 'read_health_status' );                                 #evaluation 1
			S_teststep_detected( "Health Status detected is '$$value_aref[0]'", 'read_health_status' );
			EVAL_evaluate_value( "Health Status", $$value_aref[0], '==', 1 );

		}
	}
	else {

		S_teststep_2nd_level( "Read Health check state machine via  rb_prhs_StateMachine_en", 'AUTO_NBR', 'read_state_machine' );
		$state_machine_aref = PD_ReadMemoryByName( 'rb_prhs_StateMachine_en' );
		S_teststep_expected( "Health check state machine had done (rb_prhs_StateMachine_en = 6)", 'read_state_machine' );    #evaluation 1
		S_teststep_detected( "Health check state machine detected is '$$state_machine_aref[0]'", 'read_state_machine' );
		my $verdict = EVAL_evaluate_value( "Health check state machine", $$state_machine_aref[0], '==', 6 );

		S_teststep_2nd_level( "Read Health State via  rb_prhs_EcuHealthState_en", 'AUTO_NBR', 'read_health_state' );
		if ( $verdict eq 'VERDICT_PASS' ) {

			$health_state_aref = PD_ReadMemoryByName( 'rb_prhs_EcuHealthState_en' );
			if ( $tcpar_Health_State =~ 'Negative' ) {

				S_teststep_expected( "Health State is '$tcpar_Health_State' (rb_prhs_EcuHealthState_en = 2)", 'read_health_state' );    #evaluation 1
				S_teststep_detected( "Health State detected is '$$health_state_aref[0]'", 'read_health_status' );
				EVAL_evaluate_value( "Health State", $$health_state_aref[0], '==', 2 );

			}
			else {

				S_teststep_expected( "Health State is '$tcpar_Health_State' (rb_prhs_EcuHealthState_en = 1)", 'read_health_state' );    #evaluation 1
				S_teststep_detected( "Health State detected is '$$health_state_aref[0]'", 'read_health_status' );
				EVAL_evaluate_value( "Health State", $$health_state_aref[0], '==', 1 );

			}
		}
		else {

			S_set_error("Health state machine is not DONE");

		}

	}

	return 1;
}

sub TC_evaluation {

	S_w2rep("Evaluation is done above in stimulation_and_measurement");
	return 1;
}

sub TC_finalization {

	#Clear plan mode
	_clear_plant_mode();

	#Remove fault if Negative

	if ( $tcpar_Health_State =~ 'Negative' ) {

		PD_Device_configuration( "set", ['AB1FD'] );
		S_wait_ms( $tcpar_WaitTime_ms) ;

	}

	return 1;
}

sub _set_plant_mode {
	my $plan_mode = shift;
	my $plantmode_value = 0;
	my ( $data_aref0, $data_aref1, $data_aref2, $detected_value );
	my $data_href;

	foreach (@$plan_mode) {

		$plantmode_value = ( $plantmode_value | $plant_value_set[$_] );

	}

	$plantmode_value = sprintf( '%#.06x', $plantmode_value ); #format to hex with 0x form
	S_w2rep("plant mode set is: '$plantmode_value'");

	my $plantmode_set = $plantmode_value;
	$plantmode_set =~ s/0x//; #remove 0x
	$plantmode_set =~ s/(\w{2})/$1 /g; #inserts a space after every 2 characters
	$plantmode_set =~ s/\s+$//; #remove whitespace at end

	my @plant_set = split( / /, $plantmode_set );

	#Set plan mode
	for ( my $index = 0 ; $index < scalar(@plant_set) ; $index++ ) {

		PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(' . $index . ')', [ '0x' . $plant_set[ -$index - 1 ] ] );
		S_wait_ms(2000);

	}

	#Do ECU reset
	PD_ECUreset();
	S_wait_ms( 'TIMER_ECU_READY' );

	#Check plant mode active or not

	$data_aref0     = PD_ReadMemoryByName( 'rb_sycg_ActivePlantModes_au8(0)' );
	$data_aref1     = PD_ReadMemoryByName( 'rb_sycg_ActivePlantModes_au8(1)' );
	$data_aref2     = PD_ReadMemoryByName( 'rb_sycg_ActivePlantModes_au8(2)' );
	$detected_value = sprintf( '%#.06x', ( ( $$data_aref2[0] << 16 ) | ( $$data_aref1[0] << 8 ) | ( $$data_aref0[0] ) ) );

	S_teststep_expected( "Plant mode set should be $plantmode_value" );
	S_teststep_detected( "Plant mode detected is $detected_value" );
	EVAL_evaluate_value( "Plant mode active", ( $detected_value & $plantmode_value ), '==', $plantmode_value );

	$data_href = PD_ReadLampStates();
	S_teststep_expected( "WL should be On" );
	S_teststep_detected( "WL detected is $data_href->{'System Warning Lamp'}" );
	EVAL_evaluate_string( "WL active", 'On', $data_href->{'System Warning Lamp'} );

	return 1;
}

sub _clear_plant_mode {

	my ( $data_aref0, $data_aref1, $data_aref2, $detected_value );
	my $data_href;

	#clear plan mode
	for ( my $index = 0 ; $index < 3 ; $index++ ) {

		PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(' . $index . ')', [ $plant_value_set[0] ] );
		S_wait_ms(2000);

	}

	#Do ECU reset
	PD_ECUreset();
	S_wait_ms('TIMER_ECU_READY');

	#Check plant mode active or not

	$data_aref0     = PD_ReadMemoryByName('rb_sycg_ActivePlantModes_au8(0)');
	$data_aref1     = PD_ReadMemoryByName('rb_sycg_ActivePlantModes_au8(1)');
	$data_aref2     = PD_ReadMemoryByName('rb_sycg_ActivePlantModes_au8(2)');
	$detected_value = sprintf( '%#.06x', ( ( $$data_aref2[0] << 16 ) | ( $$data_aref1[0] << 8 ) | ( $$data_aref0[0] ) ) );
	S_teststep_expected( "Plant mode should be $plant_value_set[0]" );
	S_teststep_detected( "Plant mode detected is $detected_value" );
	EVAL_evaluate_value( "Plant mode active", $detected_value, '==', $plant_value_set[0] );

	$data_href = PD_ReadLampStates();
	S_teststep_expected( "WL should be Off" );
	S_teststep_detected( "WL detected is $data_href->{'System Warning Lamp'}" );
	EVAL_evaluate_string( "WL active", 'Off', $data_href->{'System Warning Lamp'} );

	return 1;
}

1;
