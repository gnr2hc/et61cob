#### TEST CASE MODULE
package TC_BAT_fault_memories;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.4 $;
our $HEADER  = q$Header: BAT_AB12/TC_BAT_fault_memories.pm 1.4 2018/07/19 16:02:34ICT ver6cob develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_BaselineAcceptanceTest
#TS version in DOORS: 
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use LIFT_evaluation;

##################################

our $PURPOSE = "check all fault memories";


#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_BAT_fault_memories $Revision: 1.4 $

=head1 PURPOSE

check all fault memories

=head1 TESTCASE DESCRIPTION

this test will check 1. if all fault memories are empty 2. inject a fault and check if all fault memories contain this fault 

if device is not given, step 2 will be skipped

sets Jenkins to YELLOW if failed

=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

    SCALAR 'device'     --> device which shall be deconfigured to inject a fault
    LIST   'FLTmand'    --> list of mandatory faults (logical names)
    LIST   'FLTopt'     --> list of optional faults (logical names)


=head2 PARAMETER EXAMPLES

    [TC_BAT_fault_memories.AB1FD]
    purpose  = 'check AB1FD configuration fault'
    device   = 'AB1FD'
    FLTmand  = @('rb_sqm_UnexpectedAB1FD_flt')
    FLTopt   = @('rb_dem_UnexpectedDeviceFault_flt')

=cut

#PARAMETERS
################ Parameters from .par file ###################

################ global parameter declaration ###################
#add any global variables here
my ($tcpar_device,@tcpar_FLTmand,@tcpar_FLTopt);

###############################################################

sub TC_set_parameters {

	$tcpar_device = S_read_testcase_parameter( 'device' );

	@tcpar_FLTmand = S_read_testcase_parameter( 'FLTmand' );
	@tcpar_FLTopt = S_read_testcase_parameter( 'FLTopt' );

    return 1;
}

sub TC_initialization {

    LC_ECU_On('U_BATT_DEFAULT');
    S_wait_ms('TIMER_ECU_READY');
    PD_ECUlogin();
    PD_ClearFaultMemory();
    S_wait_ms('TIMER_ECU_READY');
    PD_ReadFaultMemory();
    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');
    LC_ECU_On('U_BATT_DEFAULT');
    S_wait_ms(20000);
    PD_ECUlogin();
    
    return 1;
}

sub TC_stimulation_and_measurement {
	my $flt_aref;
	
	S_teststep( "Read all fault memories", 'AUTO_NBR' );

	# 0 - Plant 1 - Primary 3 - Bosch 4 - Disturbance
	S_teststep_2nd_level("Plant fault memory", 'AUTO_NBR', 'read_fault_memory_plant');
	$flt_aref = PD_ReadFaultMemory(0);
	
	S_teststep_expected( "Expected faults: none", 'read_fault_memory_plant' );

	S_teststep_detected( 'Detected faults:', 'read_fault_memory_plant' );
    foreach my $fault ( @{ $flt_aref->{fault_text} } ) {
        S_teststep_detected($fault);
    }
	PD_evaluate_faults( $flt_aref, [], []);

	S_teststep_2nd_level("Primary fault memory", 'AUTO_NBR', 'read_fault_memory_primary');
	$flt_aref = PD_ReadFaultMemory(1);
	
	S_teststep_expected( "Expected faults: none", 'read_fault_memory_primary' );

	S_teststep_detected( 'Detected faults:', 'read_fault_memory_primary' );
    foreach my $fault ( @{ $flt_aref->{fault_text} } ) {
        S_teststep_detected($fault);
    }
	PD_evaluate_faults( $flt_aref, [], []);

	S_teststep_2nd_level("Bosch fault memory",'AUTO_NBR', 'read_fault_memory_bosch');
	$flt_aref = PD_ReadFaultMemory(3);
	
	S_teststep_expected( "Expected faults: none", 'read_fault_memory_bosch' );

	S_teststep_detected( 'Detected faults:', 'read_fault_memory_bosch' );
    foreach my $fault ( @{ $flt_aref->{fault_text} } ) {
        S_teststep_detected($fault);
    }
	PD_evaluate_faults( $flt_aref, [], []);

	S_teststep_2nd_level("Disturbance fault memory",'AUTO_NBR', 'read_fault_memory_disturbance');
	$flt_aref = PD_ReadFaultMemory(4);
	
	S_teststep_expected( "Expected faults: none", 'read_fault_memory_disturbance' );

	S_teststep_detected( 'Detected faults:', 'read_fault_memory_disturbance' );
    foreach my $fault ( @{ $flt_aref->{fault_text} } ) {
        S_teststep_detected($fault);
    }
	PD_evaluate_faults( $flt_aref, [], []);

	if ($tcpar_device){
		S_teststep("Create device configuration fault and check if all FMs show this fault",'AUTO_NBR');

	    PD_Device_configuration( "clear", [$tcpar_device]);
	    S_wait_ms('TIMER_ECU_READY');

		S_teststep_2nd_level("Plant fault memory", 'AUTO_NBR', 'read_fault_memory_plant_2');
		$flt_aref = PD_ReadFaultMemory(0);
		
		S_teststep_expected( 'Expected faults:', 'read_fault_memory_plant_2' );
		foreach my $fault (@tcpar_FLTmand) {
			S_teststep_expected($fault);
		}

		S_teststep_detected( 'Detected faults:', 'read_fault_memory_plant_2' );
		foreach my $fault ( @{ $flt_aref->{fault_text} } ) {
			S_teststep_detected($fault);
		}
		PD_evaluate_faults( $flt_aref,  \@tcpar_FLTmand, \@tcpar_FLTopt);

		
		S_teststep_2nd_level("Primary fault memory", 'AUTO_NBR', 'read_fault_memory_primary_2');
		$flt_aref = PD_ReadFaultMemory(1);
		
		S_teststep_expected( 'Expected faults:', 'read_fault_memory_primary_2' );
		foreach my $fault (@tcpar_FLTmand) {
			S_teststep_expected($fault);
		}

		S_teststep_detected( 'Detected faults:', 'read_fault_memory_primary_2' );
		foreach my $fault ( @{ $flt_aref->{fault_text} } ) {
			S_teststep_detected($fault);
		}
		PD_evaluate_faults( $flt_aref,  \@tcpar_FLTmand, \@tcpar_FLTopt);

		S_teststep_2nd_level("Bosch fault memory", 'AUTO_NBR', 'read_fault_memory_bosch_2');
		$flt_aref = PD_ReadFaultMemory(3);
		
		S_teststep_expected( 'Expected faults:', 'read_fault_memory_bosch_2' );
		foreach my $fault (@tcpar_FLTmand) {
			S_teststep_expected($fault);
		}

		S_teststep_detected( 'Detected faults:', 'read_fault_memory_bosch_2' );
		foreach my $fault ( @{ $flt_aref->{fault_text} } ) {
			S_teststep_detected($fault);
		}
		PD_evaluate_faults( $flt_aref,  \@tcpar_FLTmand, \@tcpar_FLTopt);

		
		S_teststep_2nd_level("Disturbance fault memory", 'AUTO_NBR', 'read_fault_memory_disturbance_2');
		$flt_aref = PD_ReadFaultMemory(4);
		
		S_teststep_expected( 'Expected faults:', 'read_fault_memory_disturbance_2' );
		foreach my $fault (@tcpar_FLTmand) {
			S_teststep_expected($fault);
		}

		S_teststep_detected( 'Detected faults:', 'read_fault_memory_disturbance_2' );
		foreach my $fault ( @{ $flt_aref->{fault_text} } ) {
			S_teststep_detected($fault);
		}
		PD_evaluate_faults( $flt_aref,  \@tcpar_FLTmand, \@tcpar_FLTopt);

	    PD_Device_configuration( "set", [$tcpar_device]  );
	    S_wait_ms('TIMER_ECU_READY');

	    PD_ClearFaultMemory();

	}
	else{
		S_teststep("skipped check with configuration fault because no device was given",'AUTO_NBR');
	}

	S_w2rep("LIFT_SET_JENKINS_STATUS_YELLOW since fault memories are not behaving correctly",'blue') if (S_get_current_verdict ( ) eq VERDICT_FAIL);

    return 1;
}

sub TC_evaluation {

    return 1;
}

sub TC_finalization {



    return 1;
}

1;
