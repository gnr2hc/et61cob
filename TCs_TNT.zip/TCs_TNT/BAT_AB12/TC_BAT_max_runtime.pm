#### TEST CASE MODULE
package TC_BAT_max_runtime;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.3 $;
our $HEADER  = q$Header: BAT_AB12/TC_BAT_max_runtime.pm 1.3 2018/07/19 16:02:34ICT ver6cob develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_BaselineAcceptanceTest
#TS version in DOORS: 
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use LIFT_evaluation;

##################################

our $PURPOSE = "check maximum runtime in init and steady";


#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_BAT_max_runtime $Revision: 1.3 $

=head1 PURPOSE

check maximum runtime in init and steady

sets Jenkins to YELLOW if failed

=head1 TESTCASE DESCRIPTION


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES



=head2 PARAMETER EXAMPLES


=cut

#PARAMETERS
################ Parameters from .par file ###################

################ global parameter declaration ###################
#add any global variables here

my $tcpar_max_runtime = 500;

###############################################################

sub TC_set_parameters {

    return 1;
}

sub TC_initialization {

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');
    LC_ECU_On('U_BATT_DEFAULT');
    S_wait_ms('TIMER_ECU_READY');
    PD_ECUlogin();

    return 1;
}

sub TC_stimulation_and_measurement {
	my $data_aref;
	my $runtime_steady;
	my $runtime_init;
	
	S_teststep( "Read the maximum runtime", 'AUTO_NBR' );
	S_teststep_2nd_level("Read the maximum runtime during steady state", 'AUTO_NBR', 'runtime_steady');
    $data_aref = PD_ReadMemoryByName("rb_rt_RunTimeSteady_st.MaximumTime_u32");
    $runtime_steady = S_aref2dec($data_aref, 'U32');
	
	S_teststep_expected( "Max runtime during steady state < $tcpar_max_runtime us", 'runtime_steady' );
	S_teststep_detected( "Max runtime during steady state = $runtime_steady us", 'runtime_steady' );
	EVAL_evaluate_value ( "RunTimeSteady not exceeded", $runtime_steady, '<', $tcpar_max_runtime );
	
	S_teststep_2nd_level("Read the maximum runtime during init", 'AUTO_NBR', 'runtime_init');
    $data_aref = PD_ReadMemoryByName("rb_rt_RunTimeInit_st.MaximumTime_u32");
    $runtime_init = S_aref2dec($data_aref, 'U32');
	
	S_teststep_expected( "Max runtime during init < $tcpar_max_runtime us", 'runtime_init' );
	S_teststep_detected( "Max runtime during init = $runtime_init us", 'runtime_init' );
	EVAL_evaluate_value ( "RunTimeInit not exceeded", $runtime_init, '<', $tcpar_max_runtime );
	
	S_w2rep(" RunTimeInit = $runtime_init us, RunTimeSteady = $runtime_steady us, allowed max = $tcpar_max_runtime us\n");

	S_w2rep("LIFT_SET_JENKINS_STATUS_YELLOW since max runtime is exceeded in steady stae",'blue') if (S_get_current_verdict ( ) eq VERDICT_FAIL);

    return 1;
}

sub TC_evaluation {

    return 1;
}

sub TC_finalization {

    return 1;
}


1;
