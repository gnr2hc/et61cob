#### TEST CASE MODULE
package TC_BAT_NVM_checks;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.2 $;
our $HEADER  = q$Header: BAT_AB12/TC_BAT_NVM_checks.pm 1.2 2017/07/26 21:51:12ICT Okrusch Thomas (CC-PS/EPS2) (OUT2SI) develop  $;


#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use LIFT_evaluation;

##################################

our $PURPOSE = "Check for increasing power on counter and reorg counter in range";


#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_BAT_NVM_checks $Revision: 1.2 $

=head1 PURPOSE

check for increasing power on counter and reorg counter in range

=head1 TESTCASE DESCRIPTION


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES



=head2 PARAMETER EXAMPLES


=cut

#PARAMETERS
################ Parameters from .par file ###################

################ global parameter declaration ###################
#add any global variables here

my $PowerOn_Counter_RAM = 'rb_tim_EcuOnTimeDataEe_st.POnCounter_u32';
my $PowerOn_Counter_NVM = 'rb_tim_EcuOnTimeDataEe_dfst.POnCounter_u32';
my $PowerOn_Time_NVM    = 'rb_tim_EcuOnTimeDataEe_dfst.PoOnTime_u32';

my $NBR_POWER_CYCLES = 5;


###############################################################

sub TC_set_parameters {

	S_set_warning( "TESTSPEC MUST BE UPDATED" );

	S_set_error( "'U_BATT_DEFAULT' not found in Project Defaults 'VEHICLE'", 114 ) unless (defined $main::ProjectDefaults->{'VEHICLE'}{'U_BATT_DEFAULT'});
	S_set_error( "'TIMER_ECU_OFF' not found in Project Defaults 'TIMER'", 114 ) unless (defined $main::ProjectDefaults->{'TIMER'}{'TIMER_ECU_OFF'});
	S_set_error( "'TIMER_ECU_READY' not found in Project Defaults 'TIMER'", 114 ) unless (defined $main::ProjectDefaults->{'TIMER'}{'TIMER_ECU_READY'});

    return 1;
}

sub TC_initialization {

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

    LC_ECU_On('U_BATT_DEFAULT');
    S_wait_ms('TIMER_ECU_READY');
    PD_ECUlogin();

    return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Compare POC from NVM and RAM" , 'AUTO_NBR' , 'POC_RAM_NVM_diff_begin' );

	S_teststep_2nd_level( "Read initial POC from NVM (label: $PowerOn_Counter_NVM)" , 'AUTO_NBR' );
	my $data_aref = PD_ReadMemoryByName( $PowerOn_Counter_NVM );
	my $poncount_NVM_measured = S_aref2dec($data_aref, 'U32');
	S_teststep_detected("Initial POC from NVM measured : $poncount_NVM_measured" );
	
	S_teststep_2nd_level( "Read initial POC from RAM (label: $PowerOn_Counter_RAM)" , 'AUTO_NBR' );
	my $data2_aref = PD_ReadMemoryByName( $PowerOn_Counter_RAM );
	my $poncount_RAM = S_aref2dec($data2_aref, 'U32');
	S_teststep_detected("Initial POC from RAM measured : $poncount_RAM" );


	my $POC_diff_calculated = $poncount_RAM - $poncount_NVM_measured;
	S_teststep_detected("Calculated POC Difference of RAM vs NVM : $poncount_RAM - $poncount_NVM_measured => $POC_diff_calculated  "  , 'POC_RAM_NVM_diff_begin' );
	my $POC_diff_expected = 0;
	S_teststep_expected("Expected POC Difference  of RAM vs NVM : $POC_diff_expected"  , 'POC_RAM_NVM_diff_begin' );

	EVAL_evaluate_value ( 
	                        "POC difference of RAM and NVM ( $poncount_RAM - $poncount_NVM_measured = $POC_diff_calculated  )",
							$POC_diff_calculated ,
							'==',
							$POC_diff_expected ,
							);

	

	S_teststep( "Read initial Power On Time from NVM  (label: $PowerOn_Time_NVM)" , 'AUTO_NBR' );
	$data_aref = PD_ReadMemoryByName( $PowerOn_Time_NVM );
	my $pontime_old = S_aref2dec($data_aref, 'U32');

	my $pontime_value;
	my $poncount_NVM_expected = $poncount_NVM_measured;
	S_teststep( "Perform $NBR_POWER_CYCLES Power On cycles loop and check NVM value and Power Time" , 'NO_AUTO_NBR'  );

	foreach my $poc_cycle ( 1 .. $NBR_POWER_CYCLES ){
		
		S_teststep( "Perform Power On cycle LOOP nbr $poc_cycle " , 'AUTO_NBR'  );

		LC_ECU_Off();
		S_wait_ms('TIMER_ECU_OFF');
		LC_ECU_On('U_BATT_DEFAULT');
		S_wait_ms('TIMER_ECU_READY');
		PD_ECUlogin();
		
		$poncount_NVM_expected++;

		S_teststep_2nd_level( "Read POC (loop ($poc_cycle)) from NVM" , 'AUTO_NBR' , 'POC_NVM_check_cycle'.$poc_cycle );
		$data_aref = PD_ReadMemoryByName( $PowerOn_Counter_NVM );
		$poncount_NVM_measured = S_aref2dec($data_aref, 'U32');
		S_teststep_detected("POC of NVM measured : $poncount_NVM_measured" , 'POC_NVM_check_cycle'.$poc_cycle );
		S_teststep_expected("POC of NVM expected : $poncount_NVM_expected" , 'POC_NVM_check_cycle'.$poc_cycle );
		EVAL_evaluate_value ( 
	                        "Check of POC of NVM ",
							$poncount_NVM_measured ,
							'==',
							$poncount_NVM_expected ,
							);

		S_teststep_2nd_level( "Read Power On Time (loop ($poc_cycle)) from NVM (label: $PowerOn_Time_NVM)" , 'AUTO_NBR' , 'POC_NVM_check_time'.$poc_cycle );
		$data_aref = PD_ReadMemoryByName( $PowerOn_Time_NVM );
		$pontime_value = S_aref2dec($data_aref, 'U32');
		S_teststep_detected("Power On time of NVM measured : $pontime_value  (label: $PowerOn_Time_NVM)" , 'POC_NVM_check_time'.$poc_cycle );
		S_teststep_expected("Power On time of NVM ($pontime_value) should be increased and higher than the last measurement ($pontime_old)" , 'POC_NVM_check_time'.$poc_cycle );
		EVAL_evaluate_value ( 
							"POntime increased", 
							$pontime_value, 
							'>', 
							$pontime_old 
							);
		
		# store current time for next evaluation loop
		$pontime_old = $pontime_value;
	}

	S_w2rep("Check if reorg counter is in range with power on counter",'blue');

	# Fee_LLSectorOrder_st(0).SecChngCnt_u32 <= 2.5  x   rb_tim_EcuOnTimeDataEe_dfst(0)
	$data_aref = PD_ReadMemoryByName( 'Fee_LLSectorOrder_st(0).SecChngCnt_u32' );
	my $reorg_value = S_aref2dec($data_aref, 'U32');
	EVAL_evaluate_value ( "reorg counter < 2.5* power on counter ?", $reorg_value, '<', 2.5* $poncount_NVM_measured);

    return 1;
}

sub TC_evaluation {


    return 1;
}

sub TC_finalization {

    return 1;
}

1;
