#### TEST CASE MODULE
package TC_BAT_PowerOn_Counter;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.2 $;
our $HEADER  = q$Header: BAT_AB12/TC_BAT_PowerOn_Counter.pm 1.2 2018/09/18 16:20:48ICT Phan Khanh Duy (RBVH/EPS24) (PDA1HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: -
#TS version in DOORS: -
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####


#include further modules here
use LIFT_general;
use LIFT_evaluation;
use LIFT_labcar;
use File::Spec;
use FuncLib_TNT_GEN;    #necessary
##################################

our $PURPOSE = "Check Robustness of MEM Stack";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_BAT_PowerOn_Counter

=head1 PURPOSE

Check Power On Counter

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

-


I<B<Stimulation and Measurement>>

1. read POC counter

2. POW Off/On for tcpar_POC_TC cycles

3. read POC Counter

I<B<Evaluation>>

1. -

2. -

3. POC is incremented by n - cycles


I<B<Finalisation>>

-

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

	SCALAR 'PowOffTime_msec' => ECU Off duration
	SCALAR 'PowOnTime_msec' => ECU On duration
	SCALAR 'POC_TC' => Number of ECU Off/On repetitions

=head2 PARAMETER EXAMPLES

	purpose 		= 'Power On Counter test' 
	PowOffTime_msec = 4000
	PowOnTime_msec 	= 6000
	POC_TC 			= 10

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_PowOffTime_msec;
my $tcpar_PowOnTime_msec;
my $tcpar_POC_TC;

################ global parameter declaration ###################
#add any global variables here
my $POC_initial_dec;
my $POC_after_reset_dec;
###############################################################

sub TC_set_parameters {

    $tcpar_purpose         = S_read_optional_testcase_parameter( 'purpose',         'byvalue', 'Power On Counter test' );
    $tcpar_PowOffTime_msec = S_read_optional_testcase_parameter( 'PowOffTime_msec', 'byvalue', 4000 );
    $tcpar_PowOnTime_msec  = S_read_optional_testcase_parameter( 'PowOnTime_msec',  'byvalue', 6000 );
    $tcpar_POC_TC          = S_read_optional_testcase_parameter( 'POC_TC',          'byvalue', 5 );

    return 1;
}

sub TC_initialization {

    return 1;
}

sub TC_stimulation_and_measurement {

    S_teststep( "Read POC counter", 'AUTO_NBR' );
    $POC_initial_dec  = GEN_readPowerONCounter();

    S_teststep( "Perform ECU Off/On, $tcpar_POC_TC times", 'AUTO_NBR' );
    foreach ( 1 .. $tcpar_POC_TC ) {
        LC_ECU_Off();
        S_wait_ms( $tcpar_PowOffTime_msec, 'wait after power off' );
        LC_ECU_On();
        S_wait_ms( $tcpar_PowOnTime_msec, 'wait after power on' );
    }

    S_teststep( "Read POC counter", 'AUTO_NBR', 'eval_POC' );
    $POC_after_reset_dec = GEN_readPowerONCounter();

    return 1;
}

sub TC_evaluation {

    S_teststep_expected( "POC counter = $POC_initial_dec + $tcpar_POC_TC", 'eval_POC' );
    S_teststep_detected( "POC counter = $POC_after_reset_dec", 'eval_POC' );
    EVAL_evaluate_value( "POC", $POC_after_reset_dec, '==', $POC_initial_dec + $tcpar_POC_TC );

    return 1;
}

sub TC_finalization {

    LC_ECU_Off();
    S_wait_ms( $tcpar_PowOffTime_msec, 'wait after power off' );

    return 1;
}


1;
