#### TEST CASE MODULE
package TC_BAT_RTRollingCounter;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.4 $;
our $HEADER  = q$Header: BAT_AB12/TC_BAT_RTRollingCounter.pm 1.4 2018/07/19 16:02:34ICT ver6cob develop  $;


#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use LIFT_evaluation;

##################################

our $PURPOSE = "check Fast Diagnosis and indirectly runtime";


#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_BAT_RTRollingCounter $Revision: 1.4 $

=head1 PURPOSE

check Fast Diagnosis and indirectly runtime

=head1 TESTCASE DESCRIPTION

read rb_prfd_RTRollingCounter_u8 with fast diagnosis and check that no values are missing (saw tooth signal from 0 to 63)

sets Jenkins to YELLOW if failed

=head1 PARAMETER DESCRIPTION

no parameters used


=cut

#PARAMETERS
################ Parameters from .par file ###################

################ global parameter declaration ###################
#add any global variables here
my ($FDlabel);

$FDlabel = 'rb_prfd_RTRollingCounter_u8';

my ( $FDtrace1, $FDdata1 );

###############################################################

sub TC_set_parameters {

	S_set_error( "'U_BATT_DEFAULT' not found in Project Defaults 'VEHICLE'", 114 ) unless (defined $main::ProjectDefaults->{'VEHICLE'}{'U_BATT_DEFAULT'});
	S_set_error( "'TIMER_ECU_OFF' not found in Project Defaults 'TIMER'", 114 ) unless (defined $main::ProjectDefaults->{'TIMER'}{'TIMER_ECU_OFF'});
	S_set_error( "'TIMER_ECU_READY' not found in Project Defaults 'TIMER'", 114 ) unless (defined $main::ProjectDefaults->{'TIMER'}{'TIMER_ECU_READY'});

    return 1;
}

sub TC_initialization {

    LC_ECU_On('U_BATT_DEFAULT');
    S_wait_ms('TIMER_ECU_READY');
    PD_ECUlogin();
    PD_ClearFaultMemory();
    S_wait_ms('TIMER_ECU_READY');
    PD_ReadFaultMemory();
    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');
    LC_ECU_On('U_BATT_DEFAULT');
    S_wait_ms('TIMER_ECU_READY');
    PD_ECUlogin();

    return 1;
}

sub TC_stimulation_and_measurement {


    $FDtrace1 = "FDtrace1" . time();
	
	S_teststep( "Read rb_prfd_RTRollingCounter_u8 with fast diagnosis", 'AUTO_NBR', 'roll_counter' );
    PD_StartFastDiagName( $main::REPORT_PATH . "/$FDtrace1.txt", [$FDlabel], ['U8'] );

    S_wait_ms(1000);
    PD_StopFastDiag();
    $FDdata1 = PD_get_FDtrace( $main::REPORT_PATH . "/$FDtrace1.txt" );
    PD_plot_FDtrace( $FDdata1, $main::REPORT_PATH . "/$FDtrace1.txt" );
    S_add_pic2html( "./$FDtrace1.png", '', "./$FDtrace1.txt.unv", 'TYPE="text/unv"' );
    PD_ReadFaultMemory();

    return 1;
}

sub TC_evaluation {

	S_teststep_expected( "No values are missing", 'roll_counter' );
	
    my $verdict = EVAL_evaluate_alive_counter( $FDdata1, $FDlabel, 1, 0, 63 );
	
	if ($verdict eq VERDICT_FAIL){
		S_teststep_detected( "Error detected in rolling counter values", 'roll_counter' );
	}
	else{
		S_teststep_detected( "No values are missing", 'roll_counter' );
	}
	
	S_w2rep("LIFT_SET_JENKINS_STATUS_YELLOW since RTRollingCounter signal with fast diagnosis is not behaving correctly",'blue') if (S_get_current_verdict ( ) eq VERDICT_FAIL);

    return 1;
}

sub TC_finalization {


    return 1;
}

1;
