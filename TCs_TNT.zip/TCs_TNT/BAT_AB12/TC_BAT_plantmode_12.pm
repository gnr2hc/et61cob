# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#    $Source: BAT_AB12/TC_BAT_plantmode_12.pm $
#    $Revision: 1.2 $
#    $Author: Phan Khanh Duy (RBVH/EPS24) (PDA1HC) $
#    $State: develop $
#    $Date: 2018/10/10 14:21:18ICT $
#******************************************************************************************************

#### TEST CASE MODULE
package TC_BAT_plantmode_12;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.2 $;
our $HEADER  = q$Header: BAT_AB12/TC_BAT_plantmode_12.pm 1.2 2018/10/10 14:21:18ICT Phan Khanh Duy (RBVH/EPS24) (PDA1HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Plant
#TS version in DOORS: 1.x
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use LIFT_evaluation;
use FuncLib_TNT_GEN;
##################################

our $PURPOSE = "check plant mode 12: only plant fault memory active";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_BAT_plantmode_12

=head1 PURPOSE

check plant mode 12: only plant fault memory active 

=head1 TESTCASE DESCRIPTION

This script is based on 

I<B<Initialisation>>

PROD_Standard_Preparation


Set <TestCondition>


I<B<Stimulation and Measurement>>



I<B<Evaluation>>






I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES



=head2 PARAMETER EXAMPLES


	[TC_BAT_plantmode_12.RefType3]
	purpose = 'check the function of plant mode 12 with ECU' 
	Ubat = 13.5
	DevicesPMInactive  = @( 'AB1FD', 'BLFP', 'UFSD' )
	DevicesPMActive   = @( 'AB1FP', 'BLFD', 'UFSP' )
	FLTmandPMInactive = @('rb_sqm_SquibResistanceOpenAB1FD_flt', 'rb_swm_OpenLineBLFP_flt', 'rb_psem_OpenLineUFSD_flt')
	FLTmandPMActive = @('rb_sqm_SquibResistanceOpenAB1FP_flt', 'rb_swm_OpenLineBLFD_flt', 'rb_psem_OpenLineUFSP_flt')


=cut

#PARAMETERS
################ Parameters from .par file ###################
my ( $tcpar_FLTmandPMInactive, $tcpar_FLToptPMInactive, $tcpar_FLTmandPMActive, $tcpar_FLToptPMActive );
my ($tcpar_Ubat_V);
my ( @tcpar_DevicesPMInactive, @tcpar_DevicesPMActive );

################ global parameter declaration ###################
my $plantmode12_set = 0b00001000;
my $plantmode_clear = 0b00000000;
my ( $data_aref1, $data_aref2 );
my ( $data_href1, $data_href2 );
my ($fltmem1);
my ( $fltmem_plant_PMInactive, $fltmem_primary_PMInactive, $fltmem_bosch_PMInactive, $fltmem_disturbance_PMInactive );
my ( $fltmem_plant_PMActive,   $fltmem_primary_PMActive,   $fltmem_bosch_PMActive,   $fltmem_disturbance_PMActive );

###############################################################

sub TC_set_parameters {

	$tcpar_Ubat_V            = S_read_mandatory_testcase_parameter('Ubat');
	@tcpar_DevicesPMInactive = S_read_mandatory_testcase_parameter('DevicesPMInactive', 'byref');
	@tcpar_DevicesPMActive   = S_read_mandatory_testcase_parameter('DevicesPMActive', 'byref');
	$tcpar_FLTmandPMInactive = S_read_mandatory_testcase_parameter('FLTmandPMInactive');
	$tcpar_FLToptPMInactive  = S_read_optional_testcase_parameter('FLToptPMInactive');
	$tcpar_FLTmandPMActive   = S_read_mandatory_testcase_parameter('FLTmandPMActive');
	$tcpar_FLToptPMActive    = S_read_optional_testcase_parameter('FLToptPMActive');

	return 1;
}

sub TC_initialization {

	S_teststep( "Initialize ECU", 'AUTO_NBR' );
	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	S_w2rep( "PD Clear FaultMemory\n", 'blue' );
	PD_ClearFaultMemory();
	S_wait_ms('TIMER_ECU_READY');

	S_w2rep( "Power OFF the ECU\n", 'blue' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_w2rep( "Switch ECU on with Ubat = $tcpar_Ubat_V V\n", 'blue' );
	LC_ECU_On($tcpar_Ubat_V);
	S_wait_ms('TIMER_ECU_READY');

	S_w2rep( "PD Get Extended Fault Information\n", 'blue' );
	PD_GetExtendedFaultInformation();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Check if plantmode is not yet activated", 'AUTO_NBR', 'mode_inactive' );
	$data_aref1 = PD_ReadMemoryByName('rb_sycg_ActivePlantModes_au8(1)');
	$data_href1 = PD_ReadLampStates();

	S_teststep( "Check if that no faults qualified", 'AUTO_NBR', 'checkFaultPMInactive' );
	$fltmem1 = PD_GetExtendedFaultInformation();

	S_teststep( "Deconfigure one squib, one peripheral sensor and one switch", 'AUTO_NBR' );
	PD_Device_configuration( "clear", @tcpar_DevicesPMInactive);

	S_teststep( "Wait for fault qualification", 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Read all fault recorder", 'AUTO_NBR', 'checkFRPMInactive' );
	S_teststep_2nd_level( "plant fault memory", 'AUTO_NBR', 'checkFRPMInactive_plant' );
	$fltmem_plant_PMInactive = PD_ReadFaultMemory(PLANT_FLT_MEM);
	S_teststep_2nd_level( "primary fault memory", 'AUTO_NBR', 'checkFRPMInactive_primary' );
	$fltmem_primary_PMInactive = PD_ReadFaultMemory(PRIMARY_FLT_MEM);
	S_teststep_2nd_level( "Bosch fault memory", 'AUTO_NBR', 'checkFRPMInactive_bosch' );
	$fltmem_bosch_PMInactive = PD_ReadFaultMemory(BOSCH_FLT_MEM);
	S_teststep_2nd_level( "disturbance fault memory", 'AUTO_NBR', 'checkFRPMInactive_disturbance' );
	$fltmem_disturbance_PMInactive = PD_ReadFaultMemory(DISTURBANCE_FLT_MEM);

	S_teststep( "Reconfigure devices", 'AUTO_NBR' );
	PD_Device_configuration( "set", @tcpar_DevicesPMInactive);
	S_wait_ms(3000);

	S_teststep( "Set plantmode", 'AUTO_NBR' );
	PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(1)', [$plantmode12_set] );

	S_teststep( "Do SW reset", 'AUTO_NBR' );
	PD_ECUreset();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Erase fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Check if plantmode is activated", 'AUTO_NBR', 'mode_active' );
	$data_aref2 = PD_ReadMemoryByName('rb_sycg_ActivePlantModes_au8(1)');
	$data_href2 = PD_ReadLampStates();

	S_teststep( "Deconfigure one squib, one peripheral sensor and one switch", 'AUTO_NBR' );
	PD_Device_configuration( "clear", @tcpar_DevicesPMActive);

	S_teststep( "Wait for fault qualification", 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Read all fault recorder", 'AUTO_NBR', 'checkFRPMActive' );
	S_teststep_2nd_level( "plant fault memory", 'AUTO_NBR', 'checkFRPMActive_plant' );
	$fltmem_plant_PMActive = PD_ReadFaultMemory(PLANT_FLT_MEM);
	S_teststep_2nd_level( "primary fault memory", 'AUTO_NBR', 'checkFRPMActive_primary' );
	$fltmem_primary_PMActive = PD_ReadFaultMemory(PRIMARY_FLT_MEM);
	S_teststep_2nd_level( "Bosch fault memory", 'AUTO_NBR', 'checkFRPMActive_bosch' );
	$fltmem_bosch_PMActive = PD_ReadFaultMemory(BOSCH_FLT_MEM);
	S_teststep_2nd_level( "disturbance fault memory", 'AUTO_NBR', 'checkFRPMActive_disturbance' );
	$fltmem_disturbance_PMActive = PD_ReadFaultMemory(DISTURBANCE_FLT_MEM);

	S_teststep( "Reconfigure devices", 'AUTO_NBR' );
	PD_Device_configuration( "set", @tcpar_DevicesPMActive);

	return 1;
}

sub TC_evaluation {

	### Plant Mode deactivated ###

	S_teststep_expected( "Plant mode 12 == 0", 'mode_inactive' );
	S_teststep_detected( "Plant mode 12 is $$data_aref1[0]", 'mode_inactive' );
	EVAL_evaluate_value( "Plant mode 12 inactive", $$data_aref1[0], '==', 0 );

	S_teststep_expected( "WL == Off" . "\n", 'mode_inactive' );
	S_teststep_detected( "WL is $data_href1->{'System Warning Lamp'}" . "\n", 'mode_inactive' );
	EVAL_evaluate_string( "WL inactive", 'Off', $data_href1->{'System Warning Lamp'} );

	S_teststep_expected( 'Expected faults:', 'checkFaultPMInactive' );

	S_teststep_expected('no fault');
	S_teststep_expected("\n");

	S_teststep_detected( 'Detected faults:', 'checkFaultPMInactive' );
	foreach my $fault ( @{ $fltmem1->{fault_text} } ) {
		S_teststep_detected($fault);
	}
	S_teststep_detected("\n");
	PD_evaluate_faults( $fltmem1, [] );

	### evaluation of different fault memories ###
	S_teststep_expected( 'Expected faults for all fault memories:', 'checkFRPMInactive' );
	foreach my $fault (@$tcpar_FLTmandPMInactive) {
		S_teststep_expected($fault);
	}
	S_teststep_expected("\n");

	S_teststep_detected( 'Detected faults in plant fault memory:', 'checkFRPMInactive_plant' );
	foreach my $fault ( @{ $fltmem_plant_PMInactive->{fault_text} } ) {
		S_teststep_detected($fault);
	}
	S_teststep_detected("\n");
	PD_evaluate_faults( $fltmem_plant_PMInactive, $tcpar_FLTmandPMInactive, $tcpar_FLToptPMInactive );

	S_teststep_detected( 'Detected faults in primary fault memory:', 'checkFRPMInactive_primary' );
	foreach my $fault ( @{ $fltmem_primary_PMInactive->{fault_text} } ) {
		S_teststep_detected($fault);
	}
	S_teststep_detected("\n");
	PD_evaluate_faults( $fltmem_primary_PMInactive, $tcpar_FLTmandPMInactive, $tcpar_FLToptPMInactive );

	S_teststep_detected( 'Detected faults in Bosch fault memory:', 'checkFRPMInactive_bosch' );
	foreach my $fault ( @{ $fltmem_bosch_PMInactive->{fault_text} } ) {
		S_teststep_detected($fault);
	}
	S_teststep_detected("\n");
	PD_evaluate_faults( $fltmem_bosch_PMInactive, $tcpar_FLTmandPMInactive, $tcpar_FLToptPMInactive );

	### Plant Mode activated ###

	S_teststep_expected( "Plant mode 12 == $plantmode12_set", 'mode_active' );
	S_teststep_detected( "Plant mode 12 is $$data_aref2[0]", 'mode_active' );
	EVAL_evaluate_value( "Plant mode 12 active", $$data_aref2[0], '==', $plantmode12_set );

	S_teststep_expected( "WL == On" . "\n", 'mode_active' );
	S_teststep_detected( "WL is $data_href2->{'System Warning Lamp'}" . "\n", 'mode_active' );
	EVAL_evaluate_string( "WL active", 'On', $data_href2->{'System Warning Lamp'} );

	S_teststep_expected( 'Expected faults in plant and Bosch fault memory:', 'checkFRPMActive' );
	foreach my $fault (@$tcpar_FLTmandPMActive) {
		S_teststep_expected($fault);
	}
	S_teststep_expected("\n");

	S_teststep_detected( 'Detected faults in plant fault memory:', 'checkFRPMActive_plant' );
	foreach my $fault ( @{ $fltmem_plant_PMActive->{fault_text} } ) {
		S_teststep_detected($fault);
	}
	S_teststep_detected("\n");
	PD_evaluate_faults( $fltmem_plant_PMActive, $tcpar_FLTmandPMActive, $tcpar_FLToptPMActive );

	S_teststep_detected( 'Detected faults in primary fault memory:', 'checkFRPMActive_primary' );
	foreach my $fault ( @{ $fltmem_primary_PMActive->{fault_text} } ) {
		S_teststep_detected($fault);
	}
	S_teststep_detected("\n");
	PD_evaluate_faults( $fltmem_primary_PMActive, [] );

	S_teststep_detected( 'Detected faults in Bosch fault memory:', 'checkFRPMActive_bosch' );
	foreach my $fault ( @{ $fltmem_bosch_PMActive->{fault_text} } ) {
		S_teststep_detected($fault);
	}
	S_teststep_detected("\n");
	PD_evaluate_faults( $fltmem_bosch_PMActive, $tcpar_FLTmandPMActive, $tcpar_FLToptPMActive );

	return 1;
}

sub TC_finalization {

	S_teststep( "Set battery voltage to default value", 'AUTO_NBR' );
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Erase fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();

	S_teststep( "Deactivate plantmode", 'AUTO_NBR' );
	PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(1)', [$plantmode_clear] );
	PD_ECUreset();
	S_wait_ms('TIMER_ECU_READY');

	my $data_aref = PD_ReadMemoryByName('rb_sycg_ActivePlantModes_au8(1)');
	EVAL_evaluate_value( "Plant mode inactive", $$data_aref[0], '==', $plantmode_clear );

	S_teststep_detected("UBat: $tcpar_Ubat_V V");
	return 1;
}

1;
