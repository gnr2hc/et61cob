#### TEST CASE MODULE
package TC_EDID_ValidateEDID;
#-> package name has to match file name ! case sensitive !

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
###-------------------------------
our $VERSION = q$Revision: 1.20 $;
our $HEADER = q$Header: EDID/TC_EDID_ValidateEDID.pm 1.20 2013/10/28 13:45:55ICT ver6cob develop  $;
##################################


#### INCLUDE ENGINE MODULES ####
use LIFT_general;   # this is always required
use LIFT_evaluation;
use INCLUDES_Project;
##################################


#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

#-> update documentation that somebody else can use the test without asking you
#-> delete parameter section if no paramteres are used
#-> note that POD documentation needs entirely empty lines before and after keywords (e.g. =head1, =cut ...) 

=head1 TESTCASE MODULE

TC_EDID_ValidateEDID  $Revision: 1.20 $

=head1 PURPOSE

Evaluate each EDID value

=head1 TESTCASE DESCRIPTION

    [initialisation]
    StandardPreparation

    [stimulation & measurement]
    Read EDID value in EDR through CD.

    [evaluation]
    EDID value should be as expected (same as set in set precondition)

    [finalisation]
    Clear Crash Telegram and Fault memory
    ECU off

=head1 PARAMETER

=head2 PARAMETER NAMES

  purpose = 'To validate Data Elements recorded in EDR according to the SET precondition'
  EDID    = 'EDID number' 

=head2 PARAMETER EXAMPLES
	EDID = '<Fetch {EDID}>'
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#-> define variables here which sall be used across subroutines
#-> test case parameters shall start with tcpar_
my ($tcpar_EDID, 
	$dataElement,
	$dataSource,
	$EDIDlength,
	$EDIDlabel,
	$stateOfLabel,
	$dataValue,
	$obtainedEDIDdata_aref,
	$expectedEDIDdata_aref,
	$response_aref,
	$noEvalFlag,
    );
    
our $PURPOSE;

sub TC_set_parameters {
	
	$tcpar_EDID = GEN_Read_mandatory_testcase_parameter('EDID');
	$dataElement = EDR_fetchDataElement($tcpar_EDID);   	
	$dataSource = EDR_fetchEDIDDataSource ($tcpar_EDID);	
	$EDIDlabel = EDR_fetchEDIDLabel($tcpar_EDID);
	
	$noEvalFlag = 0; #perform evaluation
	
	our $PURPOSE = "To validate the EDID$tcpar_EDID (Data Element: $dataElement)";	
	
	#based on data source
	if($dataSource =~ m/EventType/i){
		my @expected = S_read_project_parameter ( 'EventType' );
		$expectedEDIDdata_aref = \@expected;
	}
	elsif($dataSource =~ m/MultiEventNumber/i){
		$dataValue = EDR_fetchEDIDDataValue ($tcpar_EDID, 'Event1');
		$expectedEDIDdata_aref = EDR_generateExpectedEDIDData ($tcpar_EDID, $dataValue);
	}
	elsif($dataSource =~ m/CompleteFileRecorded/i){
		$dataValue = EDR_fetchEDIDDataValue ($tcpar_EDID, 'completed successfully');
		$expectedEDIDdata_aref = EDR_generateExpectedEDIDData ($tcpar_EDID, $dataValue);
	}	
	elsif($dataSource =~ m/Switch|SystemWarningLamp|POL/i){		
		#fetch the state corresponding to the EDIDlabel from .par file
		$stateOfLabel = GEN_Read_optional_testcase_parameter($EDIDlabel);
		
		#fetch the expected EDID data value
		$dataValue = EDR_fetchEDIDDataValue ($tcpar_EDID, $stateOfLabel);
		$expectedEDIDdata_aref = EDR_generateExpectedEDIDData ($tcpar_EDID, $dataValue);								 
	}
	elsif($dataSource =~ m/CAN|FlexRay/i){		
		#fetch the state corresponding to the EDIDlabel from .par file
		$stateOfLabel = GEN_Read_optional_testcase_parameter($EDIDlabel);
		
		#fetch the expected EDID data value		
		if($stateOfLabel eq 'SignalNotAvailable'){
			$dataValue = EDR_fetchEDIDDataValue ($tcpar_EDID, 'DataNotAvailable');
			$expectedEDIDdata_aref = EDR_generateExpectedEDIDData ($tcpar_EDID, $dataValue, 'DataNotAvailable') if (defined $dataValue);
		}
		elsif($stateOfLabel eq 'InvalidData'){
			$dataValue = EDR_fetchEDIDDataValue ($tcpar_EDID, 'InvalidData');
			$expectedEDIDdata_aref = EDR_generateExpectedEDIDData ($tcpar_EDID, $dataValue, 'InvalidData') if (defined $dataValue);
		}
		elsif($stateOfLabel eq 'OutOfRangeValue'){
			$dataValue = COM_fetchSignalDataValue ($EDIDlabel, 'MaxValue');
			$expectedEDIDdata_aref = EDR_generateExpectedEDIDData ($tcpar_EDID, $dataValue) if (defined $dataValue);
		}
		elsif($stateOfLabel eq 'RandomInRangeValue'){
			$dataValue = $main::ProjectDefaults->{'TEMP'}{$EDIDlabel}{'RandomInRangeValue'}; #value stored by SetPreconditions.pm file
			$expectedEDIDdata_aref = EDR_generateExpectedEDIDData ($tcpar_EDID, $dataValue) if (defined $dataValue);
		}
		else{
			$dataValue = COM_fetchSignalDataValue ($EDIDlabel, $stateOfLabel);
			$expectedEDIDdata_aref = EDR_generateExpectedEDIDData ($tcpar_EDID, $dataValue) if (defined $dataValue);
		}
	}
	elsif($dataSource =~ m/SWVariable/i){
		my $var;
		if($EDIDlabel =~ m/IgnitionCycle/i){
			$var = 'V_POnCounter_U16E';		
		}
		elsif($EDIDlabel =~ m/OperatingTime/i){
			$var = 'V_PoOnTime_U32E';		
		}
		$expectedEDIDdata_aref = PD_ReadMemoryByName($var);
	}
	else{
		S_set_error("This EDID (EDID$tcpar_EDID : $dataElement) is not handeled currently!!", 0); #warning!
		$PURPOSE = "This EDID (EDID$tcpar_EDID : $dataElement) is not evaluated!!";	
		$noEvalFlag = 1;
	}
    		
  	return 1;
  
}

#### INITIALIZE TC #####
sub TC_initialization {
	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {	

	$response_aref = $main::ProjectDefaults->{'TEMP'}{'Respone_aref'};

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {
	
	$obtainedEDIDdata_aref= EDR_CD_getEDIDdata ($response_aref,$tcpar_EDID,'generic');
	if($noEvalFlag != 1){
		GEN_EVAL_CompareNumArrays ($obtainedEDIDdata_aref, $expectedEDIDdata_aref, 'Equal') if (defined $obtainedEDIDdata_aref and $obtainedEDIDdata_aref != 0);
	}
	else{
		S_set_error("This EDID (EDID$tcpar_EDID : $dataElement) is not handeled currently. NO EVALUATION DONE!!", 0); #warning!
	}
	
	
	return 1;
}

#### TC FINALIZATION #####
sub TC_finalization {

	return 1;
}

1;

