#### TEST CASE MODULE
package TC_EDR_RGB_NHTSA;

#### DONT MODIFY THIS SECTION ####
use strict;
###-------------------------------
our $VERSION = q$Revision: 1.66 $;
our $HEADER  = q$Header: EDID/TC_EDR_RGB_NHTSA.pm 1.66 2014/07/24 22:25:32ICT Okrusch Thomas (CC-PS/EPS2) (OUT2SI) develop  $;
##################################

#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_POWER;
use LIFT_general;
use LIFT_evaluation;
use LIFT_PD;
use LIFT_IDEFIX;
use Data::Dumper;
use LIFT_POWER;
use INCLUDES_Project;
use Sys::Hostname;
##################################

our $PURPOSE = "TC_EDR_RGB_NHTSA";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=pod

=head1 TESTCASE MODULE

TC_EDR_RGB_NHTSA  $Revision: 1.66 $

=head1 PURPOSE

TESTCASE MODULE for all sensors

=head1 PARAMETER DESCRIPTION

	# ---------------------- TC_stimulation_and_measurement --------------------	
	USE_IDX_CRASH_INJECT            = 'yes'
	_IDX_Config                     = 'PL_V11A_I1_I2.ifc'
	_IDX_Crash_File                 = 'CrashFile.asc'

	StartTime                    	  = 4000 

	USE_FDIAG_RECORD                = 'yes'
	_fast_diag_var                  = @('V_EdrMultiEventTimerINTW_U16R_U16', 'S_CsSensorDataINTW_XXR.A_SensorValue_S16X(0)_U8', 'S_CsSensorDataINTW_XXR.A_SensorValue_S16X(0)_U8')

	# start crash injection	
	# IDX_CRASH_INJECT ready?
	# FDIAG_RECORD stop
	# Read Fault Memory
	# VAR_EVAL read

	# ---------------------- TC_evaluation -----------------------------------
	# Evaluate Fault Memory for mandatory and optional faults
	USE_FLT_MAND_EVAL               = 'yes'
	_expected_flt_status            = %('FltCsAsicRolloverInternalMonitoring' => '0bxx000000')
	_expected_flt_info              = %('FltCsAsicRolloverInternalMonitoring' => '0bxx000000')

	USE_VAR_EVAL                    = 'yes'
	_expected_var                   = %('S_CsSensorDataINTW_XXR.F_DataValid_U32X' => '0bxxxxxxxxxxxx00')
	
	# ---------------------- TC_finalization ---------------------------------

	OP: '=='  '!='  '>='  '<='  '<'  '>'  'MASK' 

=cut	

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my $all_EDID;

# The sample time for a Idefix crash file with async. PAS is 0.456 ms
# PAS values are transmitted every 228 uS -> two valus per line (old and new value) => 2*228 uS = 0.456 ms
# my $tcpar_crash_sample_time_ms = 0.456;

# the sample time for a Idefix crash file with sync. PAS is 0.5 ms
my $tcpar_crash_sample_time_ms;

my ( 
    $tcpar_crashfile, 
    $tcpar_USE_IDX_CRASH_INJECT, 
    $tcpar_time_startInjection ,
    $tcpar_USE_IDX_DATA_EVALUATION ,
    $tcpar_USE_FLT_MAND_EVAL, 
    @tcpar_FLTmand, 
    %tcpar_expected_flt_status, 
    %tcpar_expected_flt_info ,
    $configfile, 
    $IXS_trace, 
    $filePath 
    );

my ( 
    $tcpar_USE_VAR_EVAL, 
    @tcpar_expected_var, 
    @Eval_Var_Label, 
    @Eval_Var_Operator, 
    @Eval_Var_Value , 
    );

my ( 
    $tcpar_USE_FDIAG_RECORD, 
    @tcpar_fast_diag_var ,
    @FDlabel, 
    @FDformat, 
    %FDiagLabel ,
    $FD_trace ,
    $FD_data_hash ,
    @detected_var ,
    $flt_mem_struct,
    );

my $tcpar_time_T0_ms;

#**********************************************************************************
# The parameter below should be placed in ProjectConst_Main_EL or other config file
#**********************************************************************************
# take the orientation from Idefix crash file
my $tcpar_sensor_orientation = {};
my $tcpar_sensor_resolution = {};
my $tcpar_sensor_file_index = {};
my $tcpar_BOSCH_NHTSA_corr = {};


my (
   $tcpar_abs_tolerance_dv,
   $tcpar_abs_tolerance_dv_time,
   $tcpar_abs_tolerance_dv_res_sq,
   $tcpar_abs_tolerance_roll_angle,
   $tcpar_abs_tolerance_pressure ,
    );

my $factor_dv_crash_inj;
my $factor_Rollangle_crash_inj;

my $Acc_data_dummy_value = 0.0000077;
my $Acc_data2_dummy_value = 0.0000044;
my $Press_data_dummy_value = 0.0000088;
my $Rollrate_data_dummy_value = 0.0000099;

#**********************************************************************************

#******************************************************************************************************
#*                                     READ TEST CASE PARAMETER                                       *
#******************************************************************************************************
sub TC_set_parameters {

    my @EDIDS = qw ( 21 22 23 24 25 27 31 32 33 34 35 36 37 38 39 751 752 788 887 888 890 891 892 894 896 898 899 900 901 902 903 904 905 906 907 908 );

    foreach my $edid ( @EDIDS  ) {
        my $par_name = "EDID_".$edid;
        $all_EDID->{ $edid }{'isUsed'} = GEN_Read_mandatory_testcase_parameter( $par_name );
    }
    
    #**********************************************************************************
    # The parameter below should be placed in ProjectConst_Main_EL or other config file
    #**********************************************************************************
    # take the orientation from Idefix crash file

    $tcpar_sensor_orientation->{ XY }        = GEN_Read_mandatory_testcase_parameter('sensor_orientation_XY');      # parameters: -M45-P45 / +M45+P45 / M45-P45 / -M45+P45
    $tcpar_sensor_orientation->{ ECU_LowX }  = GEN_Read_optional_testcase_parameter('sensor_orientation_ECU_LowX');    # parameters: X / -Y
    $tcpar_sensor_orientation->{ ECU_LowY }  = GEN_Read_optional_testcase_parameter('sensor_orientation_ECU_LowY');    # parameters: Y / -Y
    $tcpar_sensor_orientation->{ ECU_LowZ }  = GEN_Read_optional_testcase_parameter('sensor_orientation_ECU_LowZ');    # parameters: Z / -Z
    $tcpar_sensor_orientation->{ PAS_LX }    = GEN_Read_optional_testcase_parameter('sensor_orientation_PAS_LX');    # parameters: X / -Y
    $tcpar_sensor_orientation->{ PAS_LY }    = GEN_Read_optional_testcase_parameter('sensor_orientation_PAS_LY');    # parameters: Y / -Y
    $tcpar_sensor_orientation->{ VDS_LowY }  = GEN_Read_optional_testcase_parameter('sensor_orientation_VDS_LowY');    # parameters: Y / -Y
    $tcpar_sensor_orientation->{ VDS_LowX }  = GEN_Read_optional_testcase_parameter('sensor_orientation_VDS_LowX');    # parameters: X / -Y
    $tcpar_sensor_orientation->{ VDS_HighY } = GEN_Read_optional_testcase_parameter('sensor_orientation_VDS_HighY');    # parameters: Y / -Y
    $tcpar_sensor_orientation->{ VDS_HighX } = GEN_Read_optional_testcase_parameter('sensor_orientation_VDS_HighX');    # parameters: X / -Y
    $tcpar_sensor_orientation->{ Roll }      = GEN_Read_mandatory_testcase_parameter('sensor_orientation_Roll');    # parameters: X / -X
    $tcpar_sensor_orientation->{ UFS }       = GEN_Read_optional_testcase_parameter('sensor_orientation_UFS');    # parameters: X / -X
    $tcpar_sensor_orientation->{ PCS }       = GEN_Read_optional_testcase_parameter('sensor_orientation_PCS');    # parameters: X / -X
    $tcpar_sensor_orientation->{ PAS_M_D }   = GEN_Read_optional_testcase_parameter('sensor_orientation_PAS_M_D');    # parameters: X / -Y
    $tcpar_sensor_orientation->{ PAS_M_P }   = GEN_Read_optional_testcase_parameter('sensor_orientation_PAS_M_P');    # parameters: Y / -Y

    $tcpar_BOSCH_NHTSA_corr->{ Accel_X }     = GEN_Read_optional_testcase_parameter('BOSCH_NHTSA_corr_Accel_X');
    $tcpar_BOSCH_NHTSA_corr->{ Accel_Y }     = GEN_Read_optional_testcase_parameter('BOSCH_NHTSA_corr_Accel_Y');
    $tcpar_BOSCH_NHTSA_corr->{ Accel_Z }     = GEN_Read_optional_testcase_parameter('BOSCH_NHTSA_corr_Accel_Z');
    $tcpar_BOSCH_NHTSA_corr->{ Roll }        = GEN_Read_optional_testcase_parameter('BOSCH_NHTSA_corr_Roll');
    $tcpar_BOSCH_NHTSA_corr->{ Yaw }         = GEN_Read_optional_testcase_parameter('BOSCH_NHTSA_corr_Yaw');
    $tcpar_BOSCH_NHTSA_corr->{ Pitch }       = GEN_Read_optional_testcase_parameter('BOSCH_NHTSA_corr_Pitch');
    

    # resolution of the sensor (from data sheet you can get the g and LSB range)
    $tcpar_sensor_resolution->{ HG_XY_G_perLSB }        = GEN_Read_mandatory_testcase_parameter('sensor_resolution_HG_XY_GperLSB');
    $tcpar_sensor_resolution->{ PAS_XY_G_perLSB }       = GEN_Read_optional_testcase_parameter('sensor_resolution_PAS_XY_GperLSB');
    $tcpar_sensor_resolution->{ UFS_DP_G_perLSB }       = GEN_Read_optional_testcase_parameter('sensor_resolution_UFS_DP_GperLSB');
    $tcpar_sensor_resolution->{ PCS_DMP_G_perLSB }      = GEN_Read_optional_testcase_parameter('sensor_resolution_PCS_DMP_GperLSB');
    $tcpar_sensor_resolution->{ PAS_M_DP_G_perLSB }     = GEN_Read_optional_testcase_parameter('sensor_resolution_PAS_M_DP_GperLSB');
    $tcpar_sensor_resolution->{ VDS_Low_XY_G_perLSB }   = GEN_Read_optional_testcase_parameter('sensor_resolution_VDS_Low_XY_GperLSB');
    $tcpar_sensor_resolution->{ VDS_High_XY_G_perLSB }  = GEN_Read_optional_testcase_parameter('sensor_resolution_VDS_High_XY_GperLSB');
    $tcpar_sensor_resolution->{ ECU_LowXYZ_G_perLSB }   = GEN_Read_optional_testcase_parameter('sensor_resolution_ECU_LowXYZ_GperLSB');
    $tcpar_sensor_resolution->{ Rollrate_X_DEGperSecperLSB } = GEN_Read_optional_testcase_parameter('sensor_resolution_Rollrate_X_DEGperSecperLSB');
    $tcpar_sensor_resolution->{ PTS_DP_promilleLSB }   = GEN_Read_optional_testcase_parameter('sensor_resolution_PTS_DP_promilleLSB');
    $tcpar_sensor_resolution->{ PPS_DP_promilleLSB }   = GEN_Read_optional_testcase_parameter('sensor_resolution_PPS_DP_promilleLSB');


    # index_HG_M45    = 1
    # index_HG_P45    = 2
    # index_Rollrate      = 3
    # index_ECU_LowY      = 4
    # index_ECU_LowZ      = 5
    # # index_ECU_LowZ = 4
    # index_ECU_LowX      = 6           # ?????????    not used
    # # index_ECU_LowX = 4
    # index_VDSHi_g_X = 6  
    # index_VDSHi_g_Y = 7  
    # index_VDSLo_g_X = 8  
    # index_VDSLo_g_Y = 9  
    # index_UFS_D     = 10         # UFS_L
    # index_UFS_P     = 11         # UFS_R
    # index_PPS_FL    = 12
    # index_PPS_FR    = 13
    # index_PAS_M_D   = 14         # PAS_ML
    # index_PAS_M_P   = 15         # PAS_MR
    # index_PCS_D     = 16         # PCS_L
    # index_PCS_M     = 17
    # index_PCS_P     = 18         # PCS_R
    # index_PAS_LX    = 19
    # index_PAS_LY    = 20
    # index_PTS_FL    = 21
    # index_PTS_FR    = 22
    # index_PAS_FL    = 23
    # index_PAS_FR    = 24
    # index_BSS_HF    = 25
    # index_BSS_LF    = 26
    

    # the index is the column number from the Idefix crash file
    $tcpar_sensor_file_index->{ ECU_X }   = GEN_Read_optional_testcase_parameter('index_ECU_X');
    $tcpar_sensor_file_index->{ ECU_Y }   = GEN_Read_optional_testcase_parameter('index_ECU_Y');
    
    $tcpar_sensor_file_index->{ HG_M45 }  = GEN_Read_optional_testcase_parameter('index_HG_M45');
    $tcpar_sensor_file_index->{ HG_P45 }  = GEN_Read_optional_testcase_parameter('index_HG_P45');
    
    $tcpar_sensor_file_index->{ PAS_LX }  = GEN_Read_optional_testcase_parameter('index_PAS_LX');
    $tcpar_sensor_file_index->{ PAS_LY }  = GEN_Read_optional_testcase_parameter('index_PAS_LY');
    
    $tcpar_sensor_file_index->{ Rollrate }    = GEN_Read_optional_testcase_parameter('index_Rollrate');
    
    $tcpar_sensor_file_index->{ ECU_LowZ }  = GEN_Read_optional_testcase_parameter('index_ECU_LowZ');
    $tcpar_sensor_file_index->{ ECU_LowY }  = GEN_Read_optional_testcase_parameter('index_ECU_LowY');
    $tcpar_sensor_file_index->{ ECU_LowX }  = GEN_Read_optional_testcase_parameter('index_ECU_LowX');
    
    $tcpar_sensor_file_index->{ VDS_LowY }  = GEN_Read_optional_testcase_parameter('index_VDS_LowY');
    $tcpar_sensor_file_index->{ VDS_LowX }  = GEN_Read_optional_testcase_parameter('index_VDS_LowX');
    
    $tcpar_sensor_file_index->{ VDS_HighY }  = GEN_Read_optional_testcase_parameter('index_VDS_HighY');
    $tcpar_sensor_file_index->{ VDS_HighX }  = GEN_Read_optional_testcase_parameter('index_VDS_HighX');
    
    $tcpar_sensor_file_index->{ UFS_D }  = GEN_Read_optional_testcase_parameter('index_UFS_D');
    $tcpar_sensor_file_index->{ UFS_P }  = GEN_Read_optional_testcase_parameter('index_UFS_P');
    
    $tcpar_sensor_file_index->{ PCS_D }  = GEN_Read_optional_testcase_parameter('index_PCS_D');
    $tcpar_sensor_file_index->{ PCS_M }  = GEN_Read_optional_testcase_parameter('index_PCS_M');
    $tcpar_sensor_file_index->{ PCS_P }  = GEN_Read_optional_testcase_parameter('index_PCS_P');
    
    $tcpar_sensor_file_index->{ PAS_M_D }  = GEN_Read_optional_testcase_parameter('index_PAS_M_D');
    $tcpar_sensor_file_index->{ PAS_M_P }  = GEN_Read_optional_testcase_parameter('index_PAS_M_P');
    
    $tcpar_sensor_file_index->{ PTS_D }  = GEN_Read_optional_testcase_parameter('index_PTS_D');
    $tcpar_sensor_file_index->{ PTS_P }  = GEN_Read_optional_testcase_parameter('index_PTS_P');
    
    $tcpar_sensor_file_index->{ PPS_D }  = GEN_Read_optional_testcase_parameter('index_PPS_D');
    $tcpar_sensor_file_index->{ PPS_P }  = GEN_Read_optional_testcase_parameter('index_PPS_P');

    # tolerance to calculate MIN and MAX values from Idefix crash data
    # my $tcpar_rel_tolerance_acc        = GEN_Read_mandatory_testcase_parameter('rel_tolerance_acc');           # not used (because delta-v method)
    # my $tcpar_abs_tolerance_long_acc   = GEN_Read_mandatory_testcase_parameter('abs_tolerance_long_acc');      # not used (because delta-v method)
    # my $tcpar_abs_tolerance_lat_acc    = GEN_Read_mandatory_testcase_parameter('abs_tolerance_lat_acc');       # not used (because delta-v method)
    # my $tcpar_abs_tolerance_norm_acc   = GEN_Read_mandatory_testcase_parameter('abs_tolerance_norm_acc');      # not used (because delta-v method)
    $tcpar_abs_tolerance_dv         = GEN_Read_mandatory_testcase_parameter('abs_tolerance_dv');
    $tcpar_abs_tolerance_dv_time    = GEN_Read_mandatory_testcase_parameter('abs_tolerance_dv_time');
    $tcpar_abs_tolerance_dv_res_sq  = GEN_Read_mandatory_testcase_parameter('abs_tolerance_dv_res_sq');
    $tcpar_abs_tolerance_roll_angle = GEN_Read_mandatory_testcase_parameter('abs_tolerance_roll_angle');
    $tcpar_abs_tolerance_pressure = GEN_Read_mandatory_testcase_parameter('abs_tolerance_pressure');    

    $tcpar_USE_IDX_CRASH_INJECT = S_read_testcase_parameter('USE_IDX_CRASH_INJECT');
    $tcpar_USE_IDX_DATA_EVALUATION = S_read_testcase_parameter('USE_IDX_DATA_EVALUATION');

    $tcpar_crash_sample_time_ms = GEN_Read_mandatory_testcase_parameter('crash_sample_time_ms');


    # faktor for dv calculation
    # ----------------------------------------------------------------------------------
    # Formula: deltaV = intergral of (Acc * deltaT)        (Acc is in g, deltaT is in ms,)
    # Faktor calculation for high g XY:
    # #                g/LSB                  g -> m/s**2   deltaT (in ms)       ms -> s   m/s -> km/h
    # my $factor_dv_crash_inj = $tcpar_sensor_resolution->{ HG_XY_G_perLSB } * 9.81 * $tcpar_crash_sample_time_ms * 0.001 * 3.6;    # = 0,0032208192
    #                 g -> m/s**2   deltaT (in ms)       ms -> s   m/s -> km/h
    $factor_dv_crash_inj = 9.81 * $tcpar_crash_sample_time_ms * 0.001 * 3.6;    # = 0,0032208192
    
    # faktor for roll angle calculation
    # ----------------------------------------------------------------------------------
    # Formula: delta roll angle = integral of (roll rate * deltaT)
    # Faktor calculation for roll angle:
    #                      DEGperSecperLSB               deltaT (in ms)       ms -> s
    # my $factor_Rollangle_crash_inj = $tcpar_sensor_resolution->{ Rollrate_X_DEGperSecperLSB } * $tcpar_crash_sample_time_ms * 0.001;
    # #                      deltaT (in ms)       ms -> s
    $factor_Rollangle_crash_inj =  $tcpar_crash_sample_time_ms * 0.001;

    #$configfile = ();
    #$projectpar_crashfile = ();

    if ( $tcpar_USE_IDX_CRASH_INJECT eq 'yes' ) {

        # $configfile = $LIFT_config::LIFT_IDXConfig;
        my $host = hostname;
        S_w2rep(" Hostname -> $host \n ");
        
        $configfile = $LIFT_Testbenches::Testbench->{$host}{'Devices'}{'Idefix'}{'IdefixConfigFile'};
        S_w2rep(" IdefixConfigFile -> $configfile \n ");
                
        $tcpar_crashfile = S_read_project_parameter('CrashFile');
        $filePath        = EDR_getCrashFilePath($tcpar_crashfile);
        
        unless( -f $filePath ) {
            S_set_error( " IDEFIX file '$filePath' doesnt exists !! (given file was '$tcpar_crashfile')" );
            return;
        }        
    }

    $tcpar_time_T0_ms = S_read_testcase_parameter('time_T0_ms');

    if( int( $tcpar_time_T0_ms ) == 0 ) {
        S_w2rep(" time T0 = 0  --> T0 will be determined from internal SW variable \n ");
    }

    $tcpar_time_startInjection = S_read_testcase_parameter('time_startInjection');

    $tcpar_USE_FDIAG_RECORD = S_read_testcase_parameter('USE_FDIAG_RECORD');
    @tcpar_fast_diag_var    = ();

    if ( $tcpar_USE_FDIAG_RECORD eq 'yes' ) {
        for ( 0 .. 9 ) {
            my $expected_var = S_read_testcase_parameter( '_fast_diag_var' . $_ );
            push( @tcpar_fast_diag_var, $expected_var ) if defined $expected_var;
        }
    }

    $tcpar_USE_FLT_MAND_EVAL   = S_read_testcase_parameter('USE_FLT_MAND_EVAL');
    %tcpar_expected_flt_status = ();
    %tcpar_expected_flt_info   = ();
    @tcpar_FLTmand             = ();

    if ( $tcpar_USE_FLT_MAND_EVAL eq 'yes' ) {
        %tcpar_expected_flt_status = S_read_testcase_parameter('_expected_flt_status');
        %tcpar_expected_flt_info   = S_read_testcase_parameter('_expected_flt_info');
        while ( my ( $key, $data ) = each %tcpar_expected_flt_status ) {
            push( @tcpar_FLTmand, $key );
        }
    }

    $tcpar_USE_VAR_EVAL = S_read_testcase_parameter('USE_VAR_EVAL');
    @tcpar_expected_var = ();
    @Eval_Var_Label     = ();
    @Eval_Var_Value     = ();

    if ( $tcpar_USE_VAR_EVAL eq 'yes' ) {
        foreach my $i ( 0 .. 9 ) {
            @tcpar_expected_var = S_read_testcase_parameter( '_expected_var' . $i );
            if (@tcpar_expected_var) {
                if ( defined( my $newkey = $main::ProjectDefaults->{'EXPECTED_VAR'}->{ $tcpar_expected_var[0] } ) ) {
                    $Eval_Var_Label[$i] = $newkey;
                }
                else {
                    $Eval_Var_Label[$i] = $tcpar_expected_var[0];
                }
                $Eval_Var_Operator[$i] = $tcpar_expected_var[1];

                if ( defined( my $data = $main::ProjectDefaults->{'EXPECTED_VAR'}->{ $tcpar_expected_var[2] } ) ) {
                    $Eval_Var_Value[$i] = $data;
                }
                else {
                    $Eval_Var_Value[$i] = $tcpar_expected_var[2];
                }
            }
        }
    }

    # ------------------------------------------------------------------------
    # Show test case ID in report
    S_read_testcase_parameter('SRT_ID');

    return 1;
}

#******************************************************************************************************
#*                                     TEST CASE INITIALIZATION                                       *
#******************************************************************************************************
sub TC_initialization {

    if ( $tcpar_USE_IDX_CRASH_INJECT eq 'yes' ) {
        S_w2rep( "File:: $filePath", 'indigo' );
        IDX_PrepareInjection( $configfile, $filePath, 0 );
        POW_voltage('U_BATT_DEFAULT');
        POW_on();
        S_wait_ms($tcpar_time_startInjection);

        PD_ClearCrashRecorder();
        PD_ReadFaultMemory();
        PD_ClearFaultMemory();
    }



    return 1;
}

#******************************************************************************************************
#*                                  STIMULATION AND MEASUREMENT                                       *
#******************************************************************************************************
sub TC_stimulation_and_measurement {

    # Prepare data for Fast Diagnosis
    if ( $tcpar_USE_FDIAG_RECORD eq 'yes' ) {
        @FDlabel    = ();
        @FDformat   = ();
        %FDiagLabel = ();

        PD_ECUlogin();
        my @expectedFaults = ();
        push( @expectedFaults, @tcpar_FLTmand );

        my $data;
        my $fdIndex = 0;
        foreach my $key_fast_diag (@tcpar_fast_diag_var) {
            unless ( $data = $main::ProjectDefaults->{'FAST_DIAG_VAR'}{$key_fast_diag} ) {
                $data = $key_fast_diag;
            }
            $data =~ /(.+)_(\w+)$/;
            $FDlabel[$fdIndex]          = $1;
            $FDformat[$fdIndex]         = $2;
            $FDiagLabel{$key_fast_diag} = $FDlabel[$fdIndex];
            $fdIndex++;
        }

        my ( $key1, $data1 );
        while ( ( $key1, $data1 ) = each %FDiagLabel ) {
            S_w2log( 5, " $key1 => $data1 \n", "blue" );
        }

        $FD_trace = "FD_trace_" . time();
        PD_StartFastDiagName( $main::REPORT_PATH . "/$FD_trace.txt", \@FDlabel, \@FDformat );
        S_wait_ms(100);
    }

    if ( $tcpar_USE_IDX_CRASH_INJECT eq 'yes' ) {    # Trigger crash injection?
        IDX_TriggerInjection();

        S_wait_ms(100);
        my $progress = IDX_GetInjectionProgress();
        while ( $progress < 100 ) {                  # crash injection not ready?
            S_w2log( 5, "Injection Progress :: $progress", "orange" );
            $progress = IDX_GetInjectionProgress();
            S_wait_ms(100);
        }
    }

    S_wait_ms(50);
    
    if ( $tcpar_USE_FDIAG_RECORD eq 'yes' ) {        # Fast Diagnosis active?
        PD_StopFastDiag();
        $FD_data_hash = PD_get_FDtrace( $main::REPORT_PATH . "/$FD_trace.txt" );    # read data to hash
        PD_plot_FDtrace( $FD_data_hash, $main::REPORT_PATH . "/$FD_trace.txt" );
        S_add_pic2html( "./$FD_trace.png", '', "./$FD_trace.txt.unv", 'TYPE="text/unv"' );
    }

    if( $tcpar_USE_FLT_MAND_EVAL eq 'yes' ) {
        # Read Fault Memory
        $flt_mem_struct = PD_ReadFaultMemory();
        # print Dumper($flt_mem_struct);
    }

    # Read variables
    if ( $tcpar_USE_VAR_EVAL eq 'yes' ) {
        foreach my $i ( 0 .. $#Eval_Var_Label ) {
            $detected_var[$i] = S_aref2hex( PD_ReadMemoryByName( $Eval_Var_Label[$i] ) );
        }
    }

    #****************************************************************************
    # The data below must be read from Crash Recorder via customer diagnosis
    #****************************************************************************
    
    S_wait_ms( 25000 );

    S_w2rep( "Reading Generic EDIDS over Customer Diag\n", "blue" );
    
    my $response_GenericEDIDs_aref = EDR_CD_ReadEDR( 1 , 'Generic' );      #read 1st Generic EDR entry (most recent)
    unless( defined $response_GenericEDIDs_aref ) {
        S_w2rep( "Reading Generic EDID was not successful \n", "red" );
        return;
    }

    my $EDID_struct_generic = EDR_CD_parseEDID(  $response_GenericEDIDs_aref , 'Generic' );
    unless( defined $EDID_struct_generic ) {
        S_w2rep( "EDR_CD_parseEDID was not successful \n", "red" );
        return;
    }
    
    S_w2rep( "Reading OEM EDIDS over Customer Diag\n", "blue" );

    my $response_OEMEDIDs_aref = EDR_CD_ReadEDR( 1 , 'OEM' );              #read 1st OEM EDR entry (most recent)
    unless( defined $response_OEMEDIDs_aref ) {
        S_w2rep( "Reading OEM EDID was not successful \n", "red" );
        return;
    }

    my $EDID_struct_OEM = EDR_CD_parseEDID(  $response_OEMEDIDs_aref , 'OEM' );
    unless( defined $EDID_struct_OEM ) {
        S_w2rep( "EDR_CD_parseEDID was not successful \n", "red" );
        return;
    }
    
    S_w2rep( "Reading SupplierSpecific EDIDS over Customer Diag\n", "blue" );

    # my $response_SupplierSpecificEDIDs_aref = EDR_CD_ReadEDR( 1 , 'SupplierSpecific' );              #read 1st Supplier EDR entry (most recent)
    # unless( defined $response_SupplierSpecificEDIDs_aref ) {
        # S_w2rep( "Reading SupplierSpecific EDID was not successful \n", "red" );
        # return;
    # }

#     my $EDID_struct_SupplierSpecific = EDR_CD_parseEDID(  $response_SupplierSpecificEDIDs_aref , 'SupplierSpecific' );
#     unless( defined $EDID_struct_SupplierSpecific ) {
#         S_w2rep( "EDR_CD_parseEDID was not successful \n", "red" );
#         return;
#     }
    
    S_w2rep( "Retrieving Data for Generic EDIDS from Response\n", "blue" );

    my $raw_EDID_data_aref ;
    foreach my $edid_no ( sort {$a <=> $b } keys %$all_EDID ) {
        next unless $all_EDID->{ $edid_no }{ 'isUsed' };
        
        S_w2rep( " Obtaining data of EDID $edid_no\n", "blue" );
        
        my $EDID_type = FuncLib_TNT_EDR::EDR_fetchEDIDHashName( $edid_no );
        unless( $EDID_type ) { 
            S_w2rep( "Could not get EDR_fetchEDIDHashName($edid_no) \n", "red" );
            next;
        }
        unless( $EDID_type =~/generic|oem/i ) { 
            S_w2rep( " EDR_fetchEDIDHashName($edid_no) returned '$EDID_type' - but just Generic or OEM is epxected\n", "red" );
            next;
        }
        
        undef $raw_EDID_data_aref;
        
        if( $EDID_type =~/generic/i and defined $EDID_struct_generic) {
            $raw_EDID_data_aref = EDR_CD_getEDIDdata( $response_GenericEDIDs_aref, $edid_no , 'Generic' , $EDID_struct_generic );
        }
        
        if( $EDID_type =~/oem/i and defined $EDID_struct_OEM) {
            $raw_EDID_data_aref = EDR_CD_getEDIDdata( $response_OEMEDIDs_aref, $edid_no , 'OEM' , $EDID_struct_OEM );
        }

        unless( defined $raw_EDID_data_aref ) {
            S_w2rep( " Failed EDR_CD_getEDIDdata( .. , $edid_no , .. )\n", "red" );
            $all_EDID->{ $edid_no }{ 'EDID_available' } = 0;
            next;
        }

        my $EDID_data = EDR_CD_convertResponse ( $raw_EDID_data_aref , $edid_no );

        unless( defined $EDID_data ) {
            S_w2rep( " Failed EDR_CD_convertResponse( .. , $edid_no , .. )\n", "red" );
            $all_EDID->{ $edid_no }{ 'EDID_available' } = 0;
            next;
        }

        $all_EDID->{ $edid_no }{ 'RAW_RESPONSE' } = $raw_EDID_data_aref;
        $all_EDID->{ $edid_no }{ 'RAW_SAMPLES' }  = $EDID_data->{'RAW_SAMPLES'};
        $all_EDID->{ $edid_no }{ 'PHYS_SAMPLES' } = $EDID_data->{'PHYS_SAMPLES'};
        $all_EDID->{ $edid_no }{ 'DATA_NOT_AVALABLE_ELEMENTS' } = $EDID_data->{'DATA_NOT_AVALABLE_ELEMENTS'};
        $all_EDID->{ $edid_no }{ 'BYTES_PER_SAMPLE' } = $EDID_data->{'BYTES_PER_SAMPLE'};
        $all_EDID->{ $edid_no }{ 'NBR_OF_SAMPLES' } = $EDID_data->{'NBR_OF_SAMPLES'};
        $all_EDID->{ $edid_no }{ 'EDID_available' } = 1;
    
    }

    return 1;
}

#******************************************************************************************************
#*                                       TEST CASE EVALUATION                                         *
#******************************************************************************************************
sub TC_evaluation {

    my ( 
        $All_crash_data ,
        
        @Acc_data ,
        $time_T0_ms ,
        $line ,

        $Roll_rate_X_value ,

        $Acc_HG_M45_value ,
        $Acc_HG_P45_value ,

        $Acc_HG_X_value ,
        $Acc_HG_Y_value ,

        $Acc_ECU_X_value ,
        $Acc_ECU_Y_value ,
        $Acc_ECU_LowY_value ,
        $Acc_ECU_LowZ_value ,
        $Acc_ECU_LowX_value ,


        $Acc_PAS_LX_value ,
        $Acc_PAS_LY_value ,

        $Acc_PAS_M_D_value ,
        $Acc_PAS_M_P_value ,

        $Acc_VDS_LowY_value ,
        $Acc_VDS_LowX_value ,
        $Acc_VDS_HighY_value ,
        $Acc_VDS_HighX_value ,

        $Acc_UFS_D_value ,
        $Acc_UFS_P_value ,

        $Acc_PTS_D_value ,
        $Acc_PTS_P_value ,

        $Acc_PPS_D_value ,
        $Acc_PPS_P_value ,

        $Acc_PCS_D_value ,
        $Acc_PCS_M_value ,
        $Acc_PCS_P_value ,
        );
    

    my $start_data_section = 0;

    my $time = 0;

    if ( $tcpar_USE_FLT_MAND_EVAL eq 'yes' ) {
        PD_evaluate_faults( $flt_mem_struct, \@tcpar_FLTmand );

        # Comparing the fault state to expected state
        foreach my $key ( keys %tcpar_expected_flt_status ) {
            if ( PD_count_fault( $flt_mem_struct, $key ) ) {
                S_w2log( 5, "L-468\n", "red" );
                EVAL_test_fault_status( $flt_mem_struct, $key, $tcpar_expected_flt_status{$key} );
                my $flt_info = PD_get_fault_info( $flt_mem_struct, $key );
                EVAL_evaluate_value( "test additional fault info.", $flt_info, '==', $tcpar_expected_flt_info{$key} );
            }
        }
    }

    # Evaluate variables
    if ( $tcpar_USE_VAR_EVAL eq 'yes' ) {
        S_w2log( 5, "L-478\n", "red" );
        foreach my $i ( 0 .. $#Eval_Var_Label ) {
            EVAL_evaluate_value( $Eval_Var_Label[$i], $detected_var[$i], $Eval_Var_Operator[$i], $Eval_Var_Value[$i] );
        }
    }

    my $line_nr = 0;         # must be initialyzed !
    my $file = $filePath;    #"$LIFT_config::LIFT_PRJCFG_path/Tools/Idefix/C031545_Front_AB_Deployment.asc";

    if ( $tcpar_USE_FDIAG_RECORD eq 'yes' ) {    
        # Fast Diagnosis active?
        # Strategy to calculate time_T0_ms
        # *******************************************************************************************
        # The following variables are recorded every 1 ms with the Fast Diagnosis
        #   _fast_diag_var0	 = 'V_EdrMultiEventTimerINTW_U16R_U16'
        #   _fast_diag_var1	 = 'S_CsSensorDataINTW_XXR.A_SensorValue_S16X(0)_U8' : low byte high G X
        #   _fast_diag_var2	 = 'S_CsSensorDataINTW_XXR.A_SensorValue_S16X(1)_U8' : low byte high G Y
        #
        # At time T0 the counter V_EdrMultiEventTimerINTW_U16R_U16 starts counting up from zero.
        #
        # How to find T0 in crash injection file:
        # 1) Search for the time when V_EdrMultiEventTimerINTW_U16R_U16 starts counting from zero
        # 2) Get the values for X and Y at this time
        # 3) Saerch for the X and Y values pattern in the crash injection file
        # 4) calculate T0 = crash_file_line_number * sample_time
        # *******************************************************************************************

        #	my $crash_start_time_ECU_ms = EVAL_get_time_when ($FD_data_hash, $FDlabel[0], ">", 0);

        # get time when counter V_EdrMultiEventTimerINTW_U16R_U16 restarts
        my $crash_start_time_ECU_ms = EVAL_get_time_when( $FD_data_hash, $FDlabel[0], "<", 3 );    # old
                #	my $crash_start_time_ECU_ms = EVAL_get_time_when ($FD_data_hash, $FDlabel[0], ">", 0);		# new
        my ( $CH1_value1, $CH2_value1 ) = EVAL_get_values_at_time( $FD_data_hash, $crash_start_time_ECU_ms, $FDlabel[1], $FDlabel[2] );

        $crash_start_time_ECU_ms++;
        my ( $CH1_value2, $CH2_value2 ) = EVAL_get_values_at_time( $FD_data_hash, $crash_start_time_ECU_ms, $FDlabel[1], $FDlabel[2] );

        S_w2rep( " Opening file $file .. \n" );
        open( FILEHANDLE, $file );

        while ( defined( $line = <FILEHANDLE> ) ) 
        {
            chomp($line);
            last if $line =~ /EOF/ ; 

            if ( $line =~ /END OF HEADER/ ) 
            {   #start of crash data in idefix crash injection file detected?
                $start_data_section = 1;
                S_w2log( 5 , "IDFX : END OF HEADER -> Data section started \n" );
                next;
            }
            
            next unless $start_data_section;

            $line_nr++;

#             S_w2log( 5 , "IDFX : $line \n" );
            
            @Acc_data = split( /,/, $line );    # store the columns from crash file to array @Acc_data

            if(defined $tcpar_sensor_file_index->{ HG_M45 } and defined $tcpar_sensor_file_index->{ HG_P45 }) {
                my $M45 = $Acc_data[$tcpar_sensor_file_index->{ HG_M45 }];
                my $P45 = $Acc_data[$tcpar_sensor_file_index->{ HG_P45 }];
                
                $M45 += 256 if $M45 < 0;  # negative value
                $P45 += 256 if $P45 < 0;  # negative value
    
                if ( ( $M45 == $CH1_value1 ) and ( $P45 == $CH2_value1 ) ) {
                    $time_T0_ms = $line_nr * $tcpar_crash_sample_time_ms;
                    S_w2log( 5, "calculated time T0 = $time_T0_ms ms\n", "blue" );
                    last;
                }
            }
            
            if(defined $tcpar_sensor_file_index->{ ECU_X } and defined $tcpar_sensor_file_index->{ ECU_Y }) {
                my $ECU_X = $Acc_data[$tcpar_sensor_file_index->{ ECU_X }];
                my $ECU_Y = $Acc_data[$tcpar_sensor_file_index->{ ECU_Y }];
                
                $ECU_X += 256 if $ECU_X < 0;  # negative value
                $ECU_Y += 256 if $ECU_Y < 0;  # negative value
    
                if ( ( $ECU_X == $CH1_value1 ) and ( $ECU_Y == $CH2_value1 ) ) {
                    $time_T0_ms = $line_nr * $tcpar_crash_sample_time_ms;
                    S_w2log( 5, "calculated time_T0_ms = $time_T0_ms ms\n", "blue" );
                    last;
                }
            }
            
        }
        close(FILEHANDLE);
        
    }

    # *******************************************************************************************

    if ( $tcpar_time_T0_ms != 0 ) {                 # T0 provided from aplication team?
        $time_T0_ms = $tcpar_time_T0_ms;
    }

    open( FILEHANDLE, $file );
    $start_data_section = 0;
   
    my $data_line_nr = 0 ; 
    while ( defined( $line = <FILEHANDLE> ) ) {

        # read the data line by line from Idefix crash file
        chomp($line);
        
        last if $line =~ /EOF/i ;

        if ( $line =~ /END OF HEADER/ ) {    #start of crash data in idefix crash injection file detected?
            $start_data_section = 1;
            S_w2log( 5 , "IDFX : END OF HEADER -> Data section started \n" );
            next;
        }

        next unless $start_data_section;

        # time = sample_number * sample_time
        $time = $data_line_nr * $tcpar_crash_sample_time_ms;

        $data_line_nr++;
        
        @Acc_data = split( /,/, $line );    # store the columns from crash file to array @Acc_data

        # calculate the data from crash file - storing is done below under correct timing condition

        #
        # M45/P45 is used
        #
        $Acc_HG_M45_value = $Acc_data[$tcpar_sensor_file_index->{ HG_M45 }]  if defined $tcpar_sensor_file_index->{ HG_M45 };
        $Acc_HG_P45_value = $Acc_data[$tcpar_sensor_file_index->{ HG_P45 }]  if defined $tcpar_sensor_file_index->{ HG_P45 };
        #
        # or ECU_X/ECU_Y is used
        #
        $Acc_ECU_X_value = $Acc_data[$tcpar_sensor_file_index->{ ECU_X }]        if defined $tcpar_sensor_file_index->{ ECU_X };
        $Acc_ECU_Y_value = $Acc_data[$tcpar_sensor_file_index->{ ECU_Y }]        if defined $tcpar_sensor_file_index->{ ECU_Y };

        $Acc_ECU_LowY_value = $Acc_data[$tcpar_sensor_file_index->{ ECU_LowY }]  if defined $tcpar_sensor_file_index->{ ECU_LowY };
        $Acc_ECU_LowZ_value = $Acc_data[$tcpar_sensor_file_index->{ ECU_LowZ }]  if defined $tcpar_sensor_file_index->{ ECU_LowZ };
        $Acc_ECU_LowX_value = $Acc_data[$tcpar_sensor_file_index->{ ECU_LowX }]  if defined $tcpar_sensor_file_index->{ ECU_LowX };

        $Acc_VDS_LowY_value = $Acc_data[$tcpar_sensor_file_index->{ VDS_LowY }]  if defined $tcpar_sensor_file_index->{ VDS_LowY };
        $Acc_VDS_LowX_value = $Acc_data[$tcpar_sensor_file_index->{ VDS_LowX }]  if defined $tcpar_sensor_file_index->{ VDS_LowX };

        $Acc_VDS_HighY_value = $Acc_data[$tcpar_sensor_file_index->{ VDS_HighY }]  if defined $tcpar_sensor_file_index->{ VDS_HighY };
        $Acc_VDS_HighX_value = $Acc_data[$tcpar_sensor_file_index->{ VDS_HighX }]  if defined $tcpar_sensor_file_index->{ VDS_HighX };

        $Acc_PAS_LX_value = $Acc_data[$tcpar_sensor_file_index->{ PAS_LX }]      if defined $tcpar_sensor_file_index->{ PAS_LX };
        $Acc_PAS_LY_value = $Acc_data[$tcpar_sensor_file_index->{ PAS_LY }]      if defined $tcpar_sensor_file_index->{ PAS_LY };

        $Acc_UFS_D_value = $Acc_data[$tcpar_sensor_file_index->{ UFS_D }]    if defined $tcpar_sensor_file_index->{ UFS_D };
        $Acc_UFS_P_value = $Acc_data[$tcpar_sensor_file_index->{ UFS_P }]    if defined $tcpar_sensor_file_index->{ UFS_P };

        $Acc_PCS_D_value = $Acc_data[$tcpar_sensor_file_index->{ PCS_D }]    if defined $tcpar_sensor_file_index->{ PCS_D };
        $Acc_PCS_M_value = $Acc_data[$tcpar_sensor_file_index->{ PCS_M }]    if defined $tcpar_sensor_file_index->{ PCS_M };
        $Acc_PCS_P_value = $Acc_data[$tcpar_sensor_file_index->{ PCS_P }]    if defined $tcpar_sensor_file_index->{ PCS_P };

        $Acc_PAS_M_D_value = $Acc_data[$tcpar_sensor_file_index->{ PAS_M_D }]    if defined $tcpar_sensor_file_index->{ PAS_M_D };
        $Acc_PAS_M_P_value = $Acc_data[$tcpar_sensor_file_index->{ PAS_M_P }]    if defined $tcpar_sensor_file_index->{ PAS_M_P };

        $Roll_rate_X_value = $Acc_data[$tcpar_sensor_file_index->{ Rollrate }]   if defined $tcpar_sensor_file_index->{ Rollrate };

        $Acc_PTS_D_value = $Acc_data[$tcpar_sensor_file_index->{ PTS_D }]    if defined $tcpar_sensor_file_index->{ PTS_D };
        $Acc_PTS_P_value = $Acc_data[$tcpar_sensor_file_index->{ PTS_P }]    if defined $tcpar_sensor_file_index->{ PTS_P };

        $Acc_PPS_D_value = $Acc_data[$tcpar_sensor_file_index->{ PPS_D }]    if defined $tcpar_sensor_file_index->{ PPS_D };
        $Acc_PPS_P_value = $Acc_data[$tcpar_sensor_file_index->{ PPS_P }]    if defined $tcpar_sensor_file_index->{ PPS_P };


        if ( defined $Acc_HG_M45_value and defined $Acc_HG_P45_value) {
            # calculate HG_X and HG_Y acceleration value of M45 and P45 values
            # according NHTSA coordinate system (sensor is mounted with 45 degree)
            if ( $tcpar_sensor_orientation->{ XY } eq "-M45-P45" ) {
                $Acc_HG_X_value = 0.707 * ( -$Acc_HG_M45_value - $Acc_HG_P45_value );
                $Acc_HG_Y_value = 0.707 * ( -$Acc_HG_M45_value + $Acc_HG_P45_value );
            }
            elsif ( $tcpar_sensor_orientation->{ XY } eq "+M45+P45" ) {
                $Acc_HG_X_value = 0.707 * ( $Acc_HG_M45_value + $Acc_HG_P45_value );
                $Acc_HG_Y_value = 0.707 * ( $Acc_HG_M45_value - $Acc_HG_P45_value );
            }
            elsif ( $tcpar_sensor_orientation->{ XY } eq "+M45-P45" ) {
                $Acc_HG_X_value = 0.707 * ( $Acc_HG_M45_value - $Acc_HG_P45_value );
                $Acc_HG_Y_value = 0.707 * ( $Acc_HG_M45_value + $Acc_HG_P45_value );
            }
            elsif ( $tcpar_sensor_orientation->{ XY } eq "-M45+P45" ) {
                $Acc_HG_X_value = 0.707 * ( -$Acc_HG_M45_value + $Acc_HG_P45_value );
                $Acc_HG_Y_value = 0.707 * ( -$Acc_HG_M45_value + $Acc_HG_P45_value );
            }
            else {
                S_w2rep( "unexpected settings for 'XY_orientation' and 'index_HG_M45' and 'index_HG_P45' \n" , 'red' );
                last;
            }
        }
        
        if ( defined $Acc_ECU_X_value and defined $Acc_ECU_Y_value) {
            # calculate HG_X and HG_Y acceleration value of M45 and P45 values
            # according NHTSA coordinate system (sensor is mounted with 45 degree)
            if ( $tcpar_sensor_orientation->{ XY } eq "-M90-P90" ) {
                $Acc_HG_X_value = -$Acc_ECU_X_value;
                $Acc_HG_Y_value = $Acc_ECU_Y_value;
            }
            elsif ( $tcpar_sensor_orientation->{ XY } eq "M90-P90" ) {
                $Acc_HG_X_value = $Acc_ECU_X_value;
                $Acc_HG_Y_value = $Acc_ECU_Y_value;
            }
            elsif ( $tcpar_sensor_orientation->{ XY } eq "-M90+P90" ) {
                $Acc_HG_X_value = -$Acc_ECU_X_value;
                $Acc_HG_Y_value = -$Acc_ECU_Y_value;
            }
            elsif ( $tcpar_sensor_orientation->{ XY } eq "+M90+P90" ) {
                $Acc_HG_X_value = $Acc_ECU_X_value;
                $Acc_HG_Y_value = -$Acc_ECU_Y_value;
            }
            else {
                S_w2rep( "unexpected settings for 'XY_orientation' and 'index_HG_M45' and 'index_HG_P45' \n" , 'red' );
                last;
            }
        }
        
        push ( @{$All_crash_data->{ 'time' }} ,  $time );
        
        $Acc_HG_X_value *= $tcpar_sensor_resolution->{ HG_XY_G_perLSB };
        $Acc_HG_Y_value *= $tcpar_sensor_resolution->{ HG_XY_G_perLSB };

        push ( @{$All_crash_data->{ 'Acc_HG_X_value' } } , $Acc_HG_X_value );
        push ( @{$All_crash_data->{ 'Acc_HG_Y_value' } } , $Acc_HG_Y_value );

#             S_w2log( 5, sprintf ( "[%d ms] HG_X = %.2f [g] HG_Y %.2f [g] (acc.NHTSA) \n" , $time , $Acc_HG_X_value , $Acc_HG_Y_value ) );


        if( defined $Roll_rate_X_value ) {
            $Roll_rate_X_value = -$Roll_rate_X_value if $tcpar_sensor_orientation->{ Roll } eq '-X';
            $Roll_rate_X_value = -$Roll_rate_X_value if $tcpar_BOSCH_NHTSA_corr->{ Roll } eq "-Roll";
            $Roll_rate_X_value *= $tcpar_sensor_resolution->{ Rollrate_X_DEGperSecperLSB };
            push ( @{$All_crash_data->{ 'Roll_rate_X_value' } } , $Roll_rate_X_value );
        }

        if( defined $Acc_ECU_LowX_value ) {
            $Acc_ECU_LowX_value = -$Acc_ECU_LowX_value if $tcpar_sensor_orientation->{ ECU_LowX } eq "-X";
            $Acc_ECU_LowX_value = -$Acc_ECU_LowX_value if $tcpar_BOSCH_NHTSA_corr->{ Accel_X } eq "-X";
            $Acc_ECU_LowX_value *= $tcpar_sensor_resolution->{ ECU_LowXYZ_G_perLSB };
            push ( @{$All_crash_data->{ 'Acc_ECU_LowX_value' }  } , $Acc_ECU_LowX_value );
        }
        
        if( defined $Acc_ECU_LowY_value ) {
            $Acc_ECU_LowY_value = -$Acc_ECU_LowY_value if $tcpar_sensor_orientation->{ ECU_LowY } eq "-Y" ;
            $Acc_ECU_LowY_value = -$Acc_ECU_LowY_value if $tcpar_BOSCH_NHTSA_corr->{ Accel_Y } eq "-Y" ;
            $Acc_ECU_LowY_value *= $tcpar_sensor_resolution->{ ECU_LowXYZ_G_perLSB };
            push ( @{$All_crash_data->{ 'Acc_ECU_LowY_value' }  } , $Acc_ECU_LowY_value );
        }
        
        if( defined $Acc_ECU_LowZ_value ) {
            $Acc_ECU_LowZ_value = -$Acc_ECU_LowZ_value if $tcpar_sensor_orientation->{ ECU_LowZ } eq "-Z" ;
            $Acc_ECU_LowZ_value = -$Acc_ECU_LowZ_value if $tcpar_BOSCH_NHTSA_corr->{ Accel_Z } eq "-Z" ;
            $Acc_ECU_LowZ_value *= $tcpar_sensor_resolution->{ ECU_LowXYZ_G_perLSB };
            push ( @{$All_crash_data->{ 'Acc_ECU_LowZ_value' }  } , $Acc_ECU_LowZ_value );
        }

        if( defined $Acc_PAS_LX_value ) {
            $Acc_PAS_LX_value = -$Acc_PAS_LX_value if $tcpar_sensor_orientation->{ PAS_LX } eq "-X" ;
            $Acc_PAS_LX_value = -$Acc_PAS_LX_value if $tcpar_BOSCH_NHTSA_corr->{ Accel_X } eq "-X" ;
            $Acc_PAS_LX_value *= $tcpar_sensor_resolution->{ PAS_XY_G_perLSB };
            push ( @{$All_crash_data->{ 'Acc_PAS_LX_value' }    } , $Acc_PAS_LX_value );
        }

        if( defined $Acc_PAS_LY_value ) {
            $Acc_PAS_LY_value = -$Acc_PAS_LY_value if $tcpar_sensor_orientation->{ PAS_LY } eq "-Y" ;
            $Acc_PAS_LY_value = -$Acc_PAS_LY_value if $tcpar_BOSCH_NHTSA_corr->{ Accel_Y } eq "-Y" ;
            $Acc_PAS_LY_value *= $tcpar_sensor_resolution->{ PAS_XY_G_perLSB };
            push ( @{$All_crash_data->{ 'Acc_PAS_LY_value' }    } , $Acc_PAS_LY_value );
        }

        if( defined $Acc_UFS_D_value ) {
            $Acc_UFS_D_value = -$Acc_UFS_D_value if $tcpar_sensor_orientation->{ UFS } eq "-X" ;
            $Acc_UFS_D_value = -$Acc_UFS_D_value if $tcpar_BOSCH_NHTSA_corr->{ Accel_X } eq "-X" ;
            $Acc_UFS_D_value *= $tcpar_sensor_resolution->{ UFS_DP_G_perLSB };
            push ( @{$All_crash_data->{ 'Acc_UFS_D_value' }    } , $Acc_UFS_D_value );
        }

        if( defined $Acc_UFS_P_value ) {
            $Acc_UFS_P_value = -$Acc_UFS_P_value if $tcpar_sensor_orientation->{ UFS } eq "-X" ;
            $Acc_UFS_P_value = -$Acc_UFS_P_value if $tcpar_BOSCH_NHTSA_corr->{ Accel_X } eq "-X" ;
            $Acc_UFS_P_value *= $tcpar_sensor_resolution->{ UFS_DP_G_perLSB };
            push ( @{$All_crash_data->{ 'Acc_UFS_P_value' }    } , $Acc_UFS_P_value );
        }

        if( defined $Acc_PCS_D_value ) {
            $Acc_PCS_D_value = -$Acc_PCS_D_value if $tcpar_sensor_orientation->{ PCS } eq "-X" ;
            $Acc_PCS_D_value = -$Acc_PCS_D_value if $tcpar_BOSCH_NHTSA_corr->{ Accel_X } eq "-X" ;
            $Acc_PCS_D_value *= $tcpar_sensor_resolution->{ PCS_DMP_G_perLSB };
            push ( @{$All_crash_data->{ 'Acc_PCS_D_value' }    } , $Acc_PCS_D_value );
        }

        if( defined $Acc_PCS_M_value ) {
            $Acc_PCS_M_value = -$Acc_PCS_M_value if $tcpar_sensor_orientation->{ PCS } eq "-X" ;
            $Acc_PCS_M_value = -$Acc_PCS_M_value if $tcpar_BOSCH_NHTSA_corr->{ Accel_X } eq "-X" ;
            $Acc_PCS_M_value *= $tcpar_sensor_resolution->{ PCS_DMP_G_perLSB };
            push ( @{$All_crash_data->{ 'Acc_PCS_M_value' }    } , $Acc_PCS_M_value );
        }

        if( defined $Acc_PCS_P_value ) {
            $Acc_PCS_P_value = -$Acc_PCS_P_value if $tcpar_sensor_orientation->{ PCS } eq "-X" ;
            $Acc_PCS_P_value = -$Acc_PCS_P_value if $tcpar_BOSCH_NHTSA_corr->{ Accel_X } eq "-X" ;
            $Acc_PCS_P_value *= $tcpar_sensor_resolution->{ PCS_DMP_G_perLSB };
            push ( @{$All_crash_data->{ 'Acc_PCS_P_value' }    } , $Acc_PCS_P_value );
        }
                  
        if( defined $Acc_PAS_M_D_value ) {
            $Acc_PAS_M_D_value = -$Acc_PAS_M_D_value if $tcpar_sensor_orientation->{ PAS_M_D } eq "-Y" ;
            $Acc_PAS_M_D_value = -$Acc_PAS_M_D_value if $tcpar_BOSCH_NHTSA_corr->{ Accel_Y } eq "-Y" ;
            $Acc_PAS_M_D_value *= $tcpar_sensor_resolution->{ PAS_M_DP_G_perLSB };
            push ( @{$All_crash_data->{ 'Acc_PAS_M_D_value' }    } , $Acc_PAS_M_D_value );
        }

        if( defined $Acc_PAS_M_P_value ) {
            $Acc_PAS_M_P_value = -$Acc_PAS_M_P_value if $tcpar_sensor_orientation->{ PAS_M_P } eq "-Y" ;
            $Acc_PAS_M_P_value = -$Acc_PAS_M_P_value if $tcpar_BOSCH_NHTSA_corr->{ Accel_Y } eq "-Y" ;
            $Acc_PAS_M_P_value *= $tcpar_sensor_resolution->{ PAS_M_DP_G_perLSB };
            push ( @{$All_crash_data->{ 'Acc_PAS_M_P_value' }    } , $Acc_PAS_M_P_value );
        }

        if( defined $Acc_VDS_LowX_value ) {
            $Acc_VDS_LowX_value = -$Acc_VDS_LowX_value if $tcpar_sensor_orientation->{ VDS_LowX } eq "-X";
            $Acc_VDS_LowX_value = -$Acc_VDS_LowX_value if $tcpar_BOSCH_NHTSA_corr->{ Accel_X } eq "-X";
            $Acc_VDS_LowX_value *= $tcpar_sensor_resolution->{ VDS_Low_XY_G_perLSB };
            push ( @{$All_crash_data->{ 'Acc_VDS_LowX_value' }    } , $Acc_VDS_LowX_value );
        }

        if( defined $Acc_VDS_LowY_value ) {
            $Acc_VDS_LowY_value = -$Acc_VDS_LowY_value if $tcpar_sensor_orientation->{ VDS_LowY } eq "-Y";
            $Acc_VDS_LowY_value = -$Acc_VDS_LowY_value if $tcpar_BOSCH_NHTSA_corr->{ Accel_Y } eq "-Y";
            $Acc_VDS_LowY_value *= $tcpar_sensor_resolution->{ VDS_Low_XY_G_perLSB };
            push ( @{$All_crash_data->{ 'Acc_VDS_LowY_value' }    } , $Acc_VDS_LowY_value );
        }

        if( defined $Acc_VDS_HighX_value ) {
            $Acc_VDS_HighX_value = -$Acc_VDS_HighX_value if $tcpar_sensor_orientation->{ VDS_HighX } eq "-X";
            $Acc_VDS_HighX_value = -$Acc_VDS_HighX_value if $tcpar_BOSCH_NHTSA_corr->{ Accel_X } eq "-X";
            $Acc_VDS_HighX_value *= $tcpar_sensor_resolution->{ VDS_High_XY_G_perLSB };
            push ( @{$All_crash_data->{ 'Acc_VDS_HighX_value' }    } , $Acc_VDS_HighX_value );
        }

        if( defined $Acc_VDS_HighY_value ) {
            $Acc_VDS_HighY_value = -$Acc_VDS_HighY_value if $tcpar_sensor_orientation->{ VDS_HighY } eq "-Y";
            $Acc_VDS_HighY_value = -$Acc_VDS_HighY_value if $tcpar_BOSCH_NHTSA_corr->{ Accel_Y } eq "-Y";
            $Acc_VDS_HighY_value *= $tcpar_sensor_resolution->{ VDS_High_XY_G_perLSB };
            push ( @{$All_crash_data->{ 'Acc_VDS_HighY_value' }    } , $Acc_VDS_HighY_value );
        }

        if( defined $Acc_PTS_D_value ) {
#             $Acc_PTS_D_value = -$Acc_PTS_D_value if $tcpar_sensor_orientation->{ PTS_D } eq "-X" ;
            $Acc_PTS_D_value *= $tcpar_sensor_resolution->{ PTS_DP_promilleLSB };
            push ( @{$All_crash_data->{ 'Acc_PTS_D_value' }    } , $Acc_PTS_D_value );
        }

        if( defined $Acc_PTS_P_value ) {
#             $Acc_PTS_P_value = -$Acc_PTS_P_value if $tcpar_sensor_orientation->{ PTS_P } eq "Y" ;
            $Acc_PTS_P_value *= $tcpar_sensor_resolution->{ PTS_DP_promilleLSB };
            push ( @{$All_crash_data->{ 'Acc_PTS_P_value' }    } , $Acc_PTS_P_value );
        }

        if( defined $Acc_PPS_D_value ) {
#             $Acc_PPS_D_value = -$Acc_PPS_D_value if $tcpar_sensor_orientation->{ PPS_D } eq "-X" ;
            $Acc_PPS_D_value *= $tcpar_sensor_resolution->{ PPS_DP_promilleLSB };
            push ( @{$All_crash_data->{ 'Acc_PPS_D_value' }    } , $Acc_PPS_D_value );
        }

        if( defined $Acc_PPS_P_value ) {
#             $Acc_PPS_P_value = -$Acc_PPS_P_value if $tcpar_sensor_orientation->{ PPS_P } eq "Y" ;
            $Acc_PPS_P_value *= $tcpar_sensor_resolution->{ PPS_DP_promilleLSB };
            push ( @{$All_crash_data->{ 'Acc_PPS_P_value' }    } , $Acc_PPS_P_value );
        }

        
    }

    close(FILEHANDLE);

    #
    # this data must be provided to script from other data sources (e.g. mappings/parameter)
    #
    my $additional_EDID_info = {
        '21' => { 
                    'EDID_data_type'        => 'acceleration' , 
                    'EDID_abbr'             => 'Acc__21__ECU_LowY' ,
                    'EDID_sample_rate_Hz'   => 100 , 
                    'EDID_start_time_ms'    => 0 , 
                    'EDID_end_time_ms'      => 250 , 
                    'crash_acc_data'        => 'Acc_ECU_LowY_value' ,
                    'eval_tolerance_abs'    => $tcpar_abs_tolerance_dv ,                     
                },
        '22' => { 
                    'EDID_data_type'        => 'acceleration' , 
                    'EDID_abbr'             => 'Acc__22__ECU_HG_Y' ,
                    'EDID_sample_rate_Hz'   => 100 , 
                    'EDID_start_time_ms'    => 0 , 
                    'EDID_end_time_ms'      => 250 , 
                    'crash_acc_data'        => 'Acc_HG_Y_value' ,
                    'eval_tolerance_abs'    => $tcpar_abs_tolerance_dv ,                     
                },
        '23' => { 
                    'EDID_data_type'        => 'acceleration' , 
                    'EDID_abbr'             => 'Acc__23__ECU_HG_X' ,
                    'EDID_sample_rate_Hz'   => 100 , 
                    'EDID_start_time_ms'    => 0 , 
                    'EDID_end_time_ms'      => 250 , 
                    'crash_acc_data'        => 'Acc_HG_X_value' ,
                    'eval_tolerance_abs'    => $tcpar_abs_tolerance_dv ,                     
                },
        '24' => { 
                    'EDID_data_type'        => 'acceleration' , 
                    'EDID_abbr'             => 'Acc__24__ECU_LowX' ,
                    'EDID_sample_rate_Hz'   => 100 , 
                    'EDID_start_time_ms'    => 0 , 
                    'EDID_end_time_ms'      => 250 , 
                    'crash_acc_data'        => 'Acc_ECU_LowX_value' ,
                    'eval_tolerance_abs'    => $tcpar_abs_tolerance_dv ,                     
                },
        '25' => { 
                    'EDID_data_type'        => 'acceleration' , 
                    'EDID_abbr'             => 'Acc__25__ECU_LowZ' ,
                    'EDID_sample_rate_Hz'   => 100 , 
                    'EDID_start_time_ms'    => 0 , 
                    'EDID_end_time_ms'      => 250 , 
                    'crash_acc_data'        => 'Acc_ECU_LowZ_value' ,
                    'eval_tolerance_abs'    => $tcpar_abs_tolerance_dv ,                     
                },
        '27' => { 
                    'EDID_data_type'        => 'rollangle' , 
                    'EDID_abbr'             => 'Roll_angle__27__ECU_X' ,
                    'EDID_sample_rate_Hz'   => 10 , 
                    'EDID_start_time_ms'    => -1000 , 
                    'EDID_end_time_ms'      => 5000 , 
                    'crash_rollrate_data'   => 'Roll_rate_X_value' ,
                    'eval_tolerance_abs'    => $tcpar_abs_tolerance_roll_angle ,                     
                },
        '31' => { 
                    'EDID_data_type'        => 'delta-v' ,  
                    'EDID_abbr'             => 'dv__31__HG_X' ,
                    'EDID_sample_rate_Hz'   => 100 , 
                    'EDID_start_time_ms'    => 0 , 
                    'EDID_end_time_ms'      => 250 , 
                    'crash_acc_data'        => 'Acc_HG_X_value' ,
                    'eval_tolerance_abs'    => $tcpar_abs_tolerance_dv ,                     
                },
        '32' => { 
                    'EDID_data_type'        => 'delta-v' ,  
                    'EDID_abbr'             => 'dv__32__HG_Y' ,
                    'EDID_sample_rate_Hz'   => 100 , 
                    'EDID_start_time_ms'    => 0 , 
                    'EDID_end_time_ms'      => 250 , 
                    'crash_acc_data'        => 'Acc_HG_Y_value' ,
                    'eval_tolerance_abs'    => $tcpar_abs_tolerance_dv ,                     
                },
        '33' => { 
                    'EDID_data_type'        => 'delta-v maximum value' , 
                    'EDID_abbr'             => 'max_dv__33__HG_X' ,
                    'EDID_sample_rate_Hz'   => undef , 
                    'EDID_start_time_ms'    => 0 , 
                    'EDID_end_time_ms'      => 300 , 
                    'crash_acc_data'        => 'Acc_HG_X_value' ,
                    'eval_tolerance_abs'    => $tcpar_abs_tolerance_dv ,                     
                },
        '34' => { 
                    'EDID_data_type'        => 'delta-v maximum value' , 
                    'EDID_abbr'             => 'max_dv__34__HG_Y' ,
                    'EDID_sample_rate_Hz'   => undef , 
                    'EDID_start_time_ms'    => 0 , 
                    'EDID_end_time_ms'      => 300 , 
                    'crash_acc_data'        => 'Acc_HG_Y_value' ,
                    'eval_tolerance_abs'    => $tcpar_abs_tolerance_dv ,                     
                },
        '35' => { 
                    'EDID_data_type'        => 'delta-v maximum time' , 
                    'EDID_abbr'             => 'max_dv_time__35__HG_X' ,
                    'EDID_sample_rate_Hz'   => undef , 
                    'EDID_start_time_ms'    => 0 , 
                    'EDID_end_time_ms'      => 300 , 
                    'crash_acc_data'        => 'Acc_HG_X_value' ,
                    'eval_tolerance_abs'    => $tcpar_abs_tolerance_dv_time ,                     
                },
        '36' => { 
                    'EDID_data_type'        => 'delta-v maximum time' ,  
                    'EDID_abbr'             => 'max_dv_time__36__HG_Y' ,
                    'EDID_sample_rate_Hz'   => undef , 
                    'EDID_start_time_ms'    => 0 , 
                    'EDID_end_time_ms'      => 300 , 
                    'crash_acc_data'        => 'Acc_HG_Y_value' ,
                    'eval_tolerance_abs'    => $tcpar_abs_tolerance_dv_time ,                     
                },
        '37' => { 
                    'EDID_data_type'        => 'result delta-v maximum time' ,  
                    'EDID_abbr'             => 'max_dv_time__37__HG_resultant' ,
                    'EDID_sample_rate_Hz'   => undef , 
                    'EDID_start_time_ms'    => 0 , 
                    'EDID_end_time_ms'      => 300 , 
                    'crash_acc_data'        => 'Acc_HG_X_value' ,
                    'crash_acc2_data'       => 'Acc_HG_Y_value' ,
                    'eval_tolerance_abs'    => $tcpar_abs_tolerance_dv_time ,                     
                },
#         '38' => { 
#                     'EDID_data_type'        => 'result delta-v maximum value exp2' ,  
#                     'EDID_abbr'             => 'max_dv_exp2__38__HG_resultant' ,
#                     'EDID_sample_rate_Hz'   => undef , 
#                     'EDID_start_time_ms'    => 0 , 
#                     'EDID_end_time_ms'      => 300 , 
#                     'crash_acc_data'        => 'Acc_HG_X_value' ,
#                     'crash_acc2_data'       => 'Acc_HG_Y_value' ,
#                     'eval_tolerance_abs'    => $tcpar_abs_tolerance_dv ,                     
#                 },
        '39' => { 
                    'EDID_data_type'        => 'result delta-v maximum value' ,  
                    'EDID_abbr'             => 'max_dv__39__HG_resultant' ,
                    'EDID_sample_rate_Hz'   => undef , 
                    'EDID_start_time_ms'    => 0 , 
                    'EDID_end_time_ms'      => 250 , 
                    'crash_acc_data'        => 'Acc_HG_X_value' ,
                    'crash_acc2_data'       => 'Acc_HG_Y_value' ,
                    'eval_tolerance_abs'    => $tcpar_abs_tolerance_dv ,                     
                },
        '751' => { 
                    'EDID_data_type'        => 'acceleration' , 
                    'EDID_abbr'             => 'Acc__751__VDS_HighY' ,
                    'EDID_sample_rate_Hz'   => 500 , 
                    'EDID_start_time_ms'    => -10 , 
                    'EDID_end_time_ms'      => 100 , 
                    'crash_acc_data'        => 'Acc_VDS_HighY_value' ,
                    'eval_tolerance_abs'    => $tcpar_abs_tolerance_dv ,                     
                },
        '752' => { 
                    'EDID_data_type'        => 'acceleration' , 
                    'EDID_abbr'             => 'Acc__752__VDS_HighX' ,
                    'EDID_sample_rate_Hz'   => 500 , 
                    'EDID_start_time_ms'    => -10 , 
                    'EDID_end_time_ms'      => 100 , 
                    'crash_acc_data'        => 'Acc_VDS_HighX_value' ,
                    'eval_tolerance_abs'    => $tcpar_abs_tolerance_dv ,                     
                },
        '788' => { 
                    'EDID_data_type'        => 'acceleration' , 
                    'EDID_abbr'             => 'Acc__788__VDS_LowX' ,
                    'EDID_sample_rate_Hz'   => 500 , 
                    'EDID_start_time_ms'    => -10 , 
                    'EDID_end_time_ms'      => 80 , 
                    'crash_acc_data'        => 'Acc_VDS_LowX_value' ,
                    'eval_tolerance_abs'    => $tcpar_abs_tolerance_dv ,                     
                },
        '887' => { 
                    'EDID_data_type'        => 'acceleration' , 
                    'EDID_abbr'             => 'Acc__887__ECU_LowY' ,
                    'EDID_sample_rate_Hz'   => 50 , 
                    'EDID_start_time_ms'    => -1500 , 
                    'EDID_end_time_ms'      => 200 , 
                    'crash_acc_data'        => 'Acc_ECU_LowY_value' ,
                    'eval_tolerance_abs'    => $tcpar_abs_tolerance_dv ,                     
                },
        '888' => { 
                    'EDID_data_type'        => 'rollrate' , 
                    'EDID_abbr'             => 'Roll_rate__888__ECU_X' ,
                    'EDID_sample_rate_Hz'   => 50 , 
                    'EDID_start_time_ms'    => -1500 , 
                    'EDID_end_time_ms'      => 200 , 
                    'crash_rollrate_data'   => 'Roll_rate_X_value' ,
                    'eval_tolerance_abs'    => $tcpar_abs_tolerance_roll_angle ,                     
                },
        '890' => { 
                    'EDID_data_type'        => 'pressure' , 
                    'EDID_abbr'             => 'Acc__890__PTS_P' ,
                    'EDID_sample_rate_Hz'   => 1000 , 
                    'EDID_start_time_ms'    => -10 , 
                    'EDID_end_time_ms'      => 30 , 
                    'crash_pressure_data'   => 'Acc_PTS_P_value' ,
                    'eval_tolerance_abs'    => $tcpar_abs_tolerance_pressure ,                     
                },
        '891' => { 
                    'EDID_data_type'        => 'pressure' , 
                    'EDID_abbr'             => 'Acc__891__PTS_D' ,
                    'EDID_sample_rate_Hz'   => 1000 , 
                    'EDID_start_time_ms'    => -10 , 
                    'EDID_end_time_ms'      => 30 , 
                    'crash_pressure_data'   => 'Acc_PTS_D_value' ,
                    'eval_tolerance_abs'    => $tcpar_abs_tolerance_pressure ,                     
                },
        '892' => { 
                    'EDID_data_type'        => 'acceleration' , 
                    'EDID_abbr'             => 'Acc__892__PCS_P' ,
                    'EDID_sample_rate_Hz'   => 500 , 
                    'EDID_start_time_ms'    => -10 , 
                    'EDID_end_time_ms'      => 50 , 
                    'crash_acc_data'        => 'Acc_PCS_P_value' ,
                    'eval_tolerance_abs'    => $tcpar_abs_tolerance_dv ,                     
                },
        '894' => { 
                    'EDID_data_type'        => 'acceleration' , 
                    'EDID_abbr'             => 'Acc__894__PCS_M' ,
                    'EDID_sample_rate_Hz'   => 500 , 
                    'EDID_start_time_ms'    => -10 , 
                    'EDID_end_time_ms'      => 50 , 
                    'crash_acc_data'        => 'Acc_PCS_M_value' ,
                    'eval_tolerance_abs'    => $tcpar_abs_tolerance_dv ,                     
                },
        '896' => { 
                    'EDID_data_type'        => 'acceleration' , 
                    'EDID_abbr'             => 'Acc__896__PCS_D' ,
                    'EDID_sample_rate_Hz'   => 500 , 
                    'EDID_start_time_ms'    => -10 , 
                    'EDID_end_time_ms'      => 50 , 
                    'crash_acc_data'        => 'Acc_PCS_D_value' ,
                    'eval_tolerance_abs'    => $tcpar_abs_tolerance_dv ,                     
                },
        '898' => { 
                    'EDID_data_type'        => 'acceleration' , 
                    'EDID_abbr'             => 'Acc__898__UFS_P' ,
                    'EDID_sample_rate_Hz'   => 500 , 
                    'EDID_start_time_ms'    => -10 , 
                    'EDID_end_time_ms'      => 80 , 
                    'crash_acc_data'        => 'Acc_UFS_P_value' ,
                    'eval_tolerance_abs'    => $tcpar_abs_tolerance_dv ,                     
                },
        '899' => { 
                    'EDID_data_type'        => 'acceleration' , 
                    'EDID_abbr'             => 'Acc__899__UFS_D' ,
                    'EDID_sample_rate_Hz'   => 500 , 
                    'EDID_start_time_ms'    => -10 , 
                    'EDID_end_time_ms'      => 80 , 
                    'crash_acc_data'        => 'Acc_UFS_D_value' ,
                    'eval_tolerance_abs'    => $tcpar_abs_tolerance_dv ,                     
                },
        '900' => { 
                    'EDID_data_type'        => 'pressure' , 
                    'EDID_abbr'             => 'Acc__900__PPS_P' ,
                    'EDID_sample_rate_Hz'   => 1000 , 
                    'EDID_start_time_ms'    => -10 , 
                    'EDID_end_time_ms'      => 30 , 
                    'crash_pressure_data'   => 'Acc_PPS_P_value' ,
                    'eval_tolerance_abs'    => $tcpar_abs_tolerance_pressure ,                     
                },
        '901' => { 
                    'EDID_data_type'        => 'pressure' , 
                    'EDID_abbr'             => 'Acc__901__PPS_D' ,
                    'EDID_sample_rate_Hz'   => 1000 , 
                    'EDID_start_time_ms'    => -10 , 
                    'EDID_end_time_ms'      => 30 , 
                    'crash_pressure_data'   => 'Acc_PPS_D_value' ,
                    'eval_tolerance_abs'    => $tcpar_abs_tolerance_pressure ,                     
                },
        '902' => { 
                    'EDID_data_type'        => 'acceleration' , 
                    'EDID_abbr'             => 'Acc__902__PAS_M_P' ,
                    'EDID_sample_rate_Hz'   => 500 , 
                    'EDID_start_time_ms'    => -10 , 
                    'EDID_end_time_ms'      => 30 , 
                    'crash_acc_data'        => 'Acc_PAS_M_P_value' ,
                    'eval_tolerance_abs'    => $tcpar_abs_tolerance_dv ,                     
                },
        '903' => { 
                    'EDID_data_type'        => 'acceleration' , 
                    'EDID_abbr'             => 'Acc__903__PAS_M_D' ,
                    'EDID_sample_rate_Hz'   => 500 , 
                    'EDID_start_time_ms'    => -10 , 
                    'EDID_end_time_ms'      => 30 , 
                    'crash_acc_data'        => 'Acc_PAS_M_D_value' ,
                    'eval_tolerance_abs'    => $tcpar_abs_tolerance_dv ,                     
                },
        '904' => { 
                    'EDID_data_type'        => 'acceleration' , 
                    'EDID_abbr'             => 'Acc__904__PAS_LY' ,
                    'EDID_sample_rate_Hz'   => 500 , 
                    'EDID_start_time_ms'    => -10 , 
                    'EDID_end_time_ms'      => 100 , 
                    'crash_acc_data'        => 'Acc_PAS_LY_value' ,
                    'eval_tolerance_abs'    => $tcpar_abs_tolerance_dv ,                     
                },
        '905' => { 
                    'EDID_data_type'        => 'acceleration' , 
                    'EDID_abbr'             => 'Acc__905__PAS_LX' ,
                    'EDID_sample_rate_Hz'   => 500 , 
                    'EDID_start_time_ms'    => -10 , 
                    'EDID_end_time_ms'      => 100 , 
                    'crash_acc_data'        => 'Acc_PAS_LX_value' ,
                    'eval_tolerance_abs'    => $tcpar_abs_tolerance_dv ,                     
                },
        '906' => { 
                    'EDID_data_type'        => 'acceleration' , 
                    'EDID_abbr'             => 'Acc__906__ECU_LowZ' ,
                    'EDID_sample_rate_Hz'   => 50 , 
                    'EDID_start_time_ms'    => -1500 , 
                    'EDID_end_time_ms'      => 200 , 
                    'crash_acc_data'        => 'Acc_ECU_LowZ_value' ,
                    'eval_tolerance_abs'    => $tcpar_abs_tolerance_dv ,                     
                },
        '907' => { 
                    'EDID_data_type'        => 'acceleration' , 
                    'EDID_abbr'             => 'Acc__907__ECU_HG_Y' ,
                    'EDID_sample_rate_Hz'   => 500 , 
                    'EDID_start_time_ms'    => -10 , 
                    'EDID_end_time_ms'      => 150 , 
                    'crash_acc_data'        => 'Acc_HG_Y_value' ,
                    'eval_tolerance_abs'    => $tcpar_abs_tolerance_dv ,                     
                },
        '908' => { 
                    'EDID_data_type'        => 'acceleration' , 
                    'EDID_abbr'             => 'Acc__908__ECU_HG_X' ,
                    'EDID_sample_rate_Hz'   => 500 , 
                    'EDID_start_time_ms'    => -10 , 
                    'EDID_end_time_ms'      => 100 , 
                    'crash_acc_data'        => 'Acc_HG_X_value' ,
                    'eval_tolerance_abs'    => $tcpar_abs_tolerance_dv ,                     
                },

    
    };

    foreach my $edid_no ( sort {$a <=> $b } keys %$all_EDID ) {
        next unless $all_EDID->{ $edid_no }{ 'isUsed' };

        S_w2rep( " Evaluating data of EDID $edid_no\n", "blue" );

        unless ( $all_EDID->{ $edid_no }{ 'EDID_available' } ) {
            S_w2rep( " Could not evaluate EDID $edid_no - no EDR data avalable\n", "red" );
            S_set_verdict( VERDICT_FAIL );
            next;
        }

#         my $EDID_data_type = $additional_EDID_info->{ $edid_no }{'EDID_data_type'};

        my $EDID_eval_data = { 
            'EDID_nbr'              => $edid_no ,
            'EDID_abbr'             => $additional_EDID_info->{ $edid_no }{'EDID_abbr'} ,
            'EDID_start_time_ms'    => $additional_EDID_info->{ $edid_no }{'EDID_start_time_ms'} ,
            'EDID_end_time_ms'      => $additional_EDID_info->{ $edid_no }{'EDID_end_time_ms'} ,
            'EDID_data_type'        => $additional_EDID_info->{ $edid_no }{'EDID_data_type'} ,
            'eval_tolerance_abs'    => $additional_EDID_info->{ $edid_no }{'eval_tolerance_abs'},
            'EDID_sample_rate_Hz'   => $additional_EDID_info->{ $edid_no }{'EDID_sample_rate_Hz'} ,
            'EDID_samples_rec'      => $all_EDID->{ $edid_no }{ 'PHYS_SAMPLES' } ,
            'EDID_nbr_of_samples'   => $all_EDID->{ $edid_no }{ 'NBR_OF_SAMPLES' } ,
#             'crash_acc_data'        => ... ,
#             'crash_acc2_data'       => ... ,
#             'crash_pressure_data'   => ... ,
#             'crash_rollrate_data'   => ... ,
            'crash_times'           => $All_crash_data->{ 'time' } ,
            'time_T0_ms'            => $time_T0_ms,
        };

        
        #
        # Rollrate / Rollangle
        #
        if( defined $additional_EDID_info->{ $edid_no }{'crash_rollrate_data'} ) {
            my $crash_data_label  = $additional_EDID_info->{ $edid_no }{'crash_rollrate_data'};        
            $EDID_eval_data->{ 'crash_rollrate_data' } = $All_crash_data->{ $crash_data_label };
    
            eval_roll_ringbuffer ( $EDID_eval_data );
            next;
        }       
        
        #
        # Acceleration
        #
        if( defined $additional_EDID_info->{ $edid_no }{'crash_acc_data'} ) {
            my $crash_data_label  = $additional_EDID_info->{ $edid_no }{'crash_acc_data'};        
            $EDID_eval_data->{ 'crash_acc_data' } = $All_crash_data->{ $crash_data_label };
    
            if( $additional_EDID_info->{ $edid_no }{'crash_acc2_data'} ) {
                my $crash_data2_label = $additional_EDID_info->{ $edid_no }{'crash_acc2_data'};
                $EDID_eval_data->{ 'crash_acc2_data' } = $All_crash_data->{ $crash_data2_label };    
            }

            eval_velocity_ringbuffer ( $EDID_eval_data );
            next;
        }       
        
        #
        # Pressure
        #
        if( defined $additional_EDID_info->{ $edid_no }{'crash_pressure_data'} ) {
            my $crash_data_label  = $additional_EDID_info->{ $edid_no }{'crash_pressure_data'};        
            $EDID_eval_data->{ 'crash_pressure_data' } = $All_crash_data->{ $crash_data_label };
    
            eval_pressure_ringbuffer( $EDID_eval_data );
            next;
        }

    }    


    return 1;
}

#******************************************************************************************************
#*                                       TEST CASE FINALIZATION                                       *
#******************************************************************************************************
sub TC_finalization {
    POW_off();
    S_wait_ms('TIMER_ECU_OFF');

    return 1;
}

###-----------------------------------------------------------------------------
sub EDR_CD_convertResponse {
###-----------------------------------------------------------------------------
    GEN_print_caller();

    my $EDIDdata_aref = shift;
    my $EDID          = shift;

    return { 
            'PHYS_SAMPLES'                  => [],
            'RAW_SAMPLES'                   => [],
            'DATA_NOT_AVALABLE_ELEMENTS'    => [],
            'INVALID_DATA_ELEMENTS'         => [],
    #         'HEADER_BYTES' => \@Splice_Header ,
            'BYTES_PER_SAMPLE'              => 1 ,
            'NBR_OF_SAMPLES'                => 1 ,
        } if $main::opt_offline;

    unless ( defined $EDID ) {
        S_set_error( "EDID parameter is not defined", 110 );    #error!
        return;
    }
    unless ( defined $EDIDdata_aref ) {
        S_set_error( "value parameter is not defined", 110 );    #error!
        return;
    }

    unless ( ref $EDIDdata_aref eq "ARRAY" ) {
        S_set_error( "value parameter is not a hash ref", 110 );    #error!
        return;
    }

    my @all_my_EDIDs_with_Header_4bytes = qw( 21 22 23 24 25 27 31 32 38 39 );      # temp solution

    foreach my $EDID_with_Header( @all_my_EDIDs_with_Header_4bytes ) 
    {
        next unless $EDID eq $EDID_with_Header;
        S_w2log( 4, " EDR_CD_convertResponse : 4 bytes Header of EDID $EDID must be removed \n" );
        my @Splice_Header = splice @$EDIDdata_aref, 0 , 4 ;
        S_w2log( 4, " EDR_CD_convertResponse : Header of EDID $EDID : " .  join ( ' ' , @Splice_Header ) . " \n" );
    }

    return unless my $BytesperSample_from_Mapping_EDR = EDR_fetchEDIDBytesPerDataSample( $EDID );
    
    return unless my $NbrOfSamples_from_Mapping_EDR = EDR_fetchEDIDDataSamples( $EDID );
    
    my $nbr_of_bytes = scalar @$EDIDdata_aref;    
    unless( $NbrOfSamples_from_Mapping_EDR * $BytesperSample_from_Mapping_EDR == $nbr_of_bytes )  {
        S_w2log( 1, " EDR_CD_convertResponse : (EDID $EDID) mismatch in nbr of elements ($nbr_of_bytes) (must be $BytesperSample_from_Mapping_EDR x $NbrOfSamples_from_Mapping_EDR ) \n" , "red" );
        return;
    }
    
    my $EDID_samples_raw_values = EDR_CD_getSamplesFromResponse( $EDIDdata_aref, $NbrOfSamples_from_Mapping_EDR , $BytesperSample_from_Mapping_EDR );

    S_w2log( 5, "SAMPLES FROM ARRAY: ". join( " " , @$EDID_samples_raw_values) ." \n" );
    
    my $elt_cntr = 0;
    my @data_not_available = ();
    my @invalid_data = ();
    foreach my $data_element( @$EDID_samples_raw_values ) {
        $elt_cntr++;
        
        my $sample_hex = sprintf( "%X" , $data_element );
        #
        # if there is no character different from 'F' its an invalid data element in the ringbuffer ( only FF... are there)
        # 
        # [^F] defines a class of character without 'F'
        #
        unless( $sample_hex =~ /[^F]/i ) {
            S_w2log( 1, " EDR_CD_convertResponse : [$elt_cntr] 'Data not available' element in ringbuffer ( $sample_hex (hex) / $data_element (dec) ) \n" , "red" );
            push ( @data_not_available , $elt_cntr );
        }
        
        if(     $BytesperSample_from_Mapping_EDR == 1 and hex($sample_hex) == 0xFE 
             or $BytesperSample_from_Mapping_EDR == 2 and hex($sample_hex) == 0xFFFE
             or $BytesperSample_from_Mapping_EDR == 3 and hex($sample_hex) == 0xFFFFFE
             or $BytesperSample_from_Mapping_EDR == 4 and hex($sample_hex) == 0xFFFFFFFE
            ) 
        {
            S_w2log( 1, " EDR_CD_convertResponse : [$elt_cntr] 'Invalid Data' element in ringbuffer ( $sample_hex (hex) / $data_element (dec) ) \n" , "red" );
            push ( @invalid_data , $elt_cntr );
        }
                
    }        

    my $EDID_samples_physical = EDR_CD_convertArrayByFactor_dec( $EDID_samples_raw_values, $EDID );
#     my $EDID_samples_physical = EDR_CD_convertArrayByFactor( $EDID_samples_raw_values, $EDID );

    S_w2log( 5, "AFTER CONVERSION: ". join( " " , @$EDID_samples_physical) ." \n" );

    my $EDID_data = { 
        'PHYS_SAMPLES' => $EDID_samples_physical,
        'RAW_SAMPLES' => $EDID_samples_raw_values,
        'DATA_NOT_AVALABLE_ELEMENTS' => \@data_not_available,
        'INVALID_DATA_ELEMENTS' => \@data_not_available,
#         'HEADER_BYTES' => \@Splice_Header ,
        'BYTES_PER_SAMPLE' => $BytesperSample_from_Mapping_EDR ,
        'NBR_OF_SAMPLES' => $NbrOfSamples_from_Mapping_EDR ,
    };

    return $EDID_data;
}

###-----------------------------------------------------------------------------
sub eval_roll_ringbuffer { 
###-----------------------------------------------------------------------------

    my $params = shift;

#         eval_roll_ringbuffer (
#             'EDID_nbr'              => 27 ,
#             'EDID_abbr'             => 'Roll_angle__27__ECU_X' ,
#             'EDID_nbr_of_samples'   => 61 ,
#             'EDID_sample_rate_Hz'   => 10 ,
#             'EDID_samples_rec'      => \@Roll_angle__27__ECU_X ,
#             'crash_rollrate_data'   => \@{$All_crash_data->{ 'Roll_rate_X_value' }} ,
#             'crash_times'           => \@{$All_crash_data->{ 'time' }} ,
#             'time_T0_ms_ms'         => $time_T0,
#             'EDID_start_time_ms'    => -1000 ,
#             'EDID_end_time_ms'      => 5000 ,
#             'EDID_data_type'        => 'crash_rollrate_data' ,
#             'eval_tolerance_abs'    => $tcpar_abs_tolerance_roll_angle ,
#         );

    my $EDID_data_type          = $params->{'EDID_data_type'}; 
    my $eval_tolerance_abs      = $params->{'eval_tolerance_abs'}; 
    my $EDID_nbr                = $params->{'EDID_nbr'}; 
    my $EDID_abbr               = $params->{'EDID_abbr'}; 
    my $EDID_nbr_of_samples_exp = $params->{'EDID_nbr_of_samples'}; 
    my $EDID_sample_rate_Hz     = $params->{'EDID_sample_rate_Hz'};     
    my $EDID_samples_rec_aref   = $params->{'EDID_samples_rec'};        
    my $EDID_start_time_ms      = $params->{'EDID_start_time_ms'}; 
    my $EDID_end_time_ms        = $params->{'EDID_end_time_ms'};   
    my $crash_rollrate_data     = $params->{'crash_rollrate_data'};     
    my $crash_all_times_aref    = $params->{'crash_times'};      
    my $crash_time_T0_ms        = $params->{'time_T0_ms'};                
    
    my @EVAL_Rollangle_crash_data = ();
    my @EVAL_Rollangle_crash_times = ();
    my @MIN_Rollangle_crash_data = ();
    my @MAX_Rollangle_crash_data = ();

    my $EDID_sample_time_ms;
    my @eval_EDR_sample_on_crash_timebase_ms = ();
    
    my @Calc_Rollangle_samples = ();
    my @EDR_Rollangle_samples = ();

    my @used_crash_times = ();
    my @used_crash_rollrate_values = ();
    
    my $EDID_descr = EDR_fetchEDIDLabel($EDID_nbr); 

    if( defined $EDID_sample_rate_Hz ) {
        $EDID_sample_time_ms = ( 1 / $EDID_sample_rate_Hz ) * 1000;
        S_w2log( 3 , " Calculated sample time --> $EDID_sample_time_ms (ms) (based on given sample rate $EDID_sample_rate_Hz Hz )\n" );
    }
    
    my $eval_start_time_ms = $crash_time_T0_ms + $EDID_start_time_ms;
    S_w2log( 3 , " Evaluation start at $eval_start_time_ms (ms) ( --> T0 $crash_time_T0_ms (ms) + $EDID_start_time_ms (ms) )\n" );
    
    my $eval_end_time_ms = $crash_time_T0_ms + $EDID_end_time_ms + 1;
    S_w2log( 3 , " Evaluation end at $eval_end_time_ms (ms) ( --> T0 $crash_time_T0_ms ms + $EDID_end_time_ms ms +  1 ms )\n" );

    my $factor_Rollangle_EDR = $EDID_sample_time_ms * 0.001 if defined $EDID_sample_time_ms;
 
    S_w2rep( " - - - - - - - - - - - - - - - - - - - - - - - - - - -\n" );
    S_w2rep( "  ===> Evaluating EDID $EDID_nbr\n" , "indigo" );
    S_w2rep( "  ===> $EDID_descr\n" , "indigo" );
    S_w2rep( "  ===> $EDID_nbr_of_samples_exp samples \n" , "indigo" );
    S_w2rep( "  ===> $EDID_start_time_ms ms start time ( $eval_start_time_ms ms in crash data)\n" , "indigo" );
    S_w2rep( "  ===> $EDID_end_time_ms ms end time ( $eval_end_time_ms ms in crash data)\n" , "indigo" );
    S_w2rep( "  ===> $EDID_sample_rate_Hz Hz sample rate ($EDID_sample_time_ms ms) \n" , "indigo" ) if defined $EDID_sample_time_ms;
    S_w2rep( " - - - - - - - - - - - - - - - - - - - - - - - - - - -\n" );
    
    #
    # Evaluate correct nbr of EDR samples
    #
    my $nbr_of_EDR_samples = scalar @$EDID_samples_rec_aref;
    EVAL_evaluate_value( "EDID $EDID_nbr - Nbr of EDR samples" , $nbr_of_EDR_samples , "==" , $EDID_nbr_of_samples_exp );
    unless( $nbr_of_EDR_samples ) {
        S_w2rep( " - - - No further evaluation required - - - \n" , 'red' );
        return 1;
    }

    unless( ref $crash_all_times_aref eq 'ARRAY' ) {
        S_set_error( "UNEXPECTED ERROR : given parameter 'crash_times' isnt a ARRAY ref as expected - following a dump is printed" );
        S_w2rep( "BEGIN of DUMP\n".Dumper( $crash_all_times_aref )."\nEND_OF_DUMP\n" );
        return;
    }

    @used_crash_times = @$crash_all_times_aref;
    @used_crash_rollrate_values = @$crash_rollrate_data;
    
    
    #
    # filling crash data when missing at beginning of evaluation range
    #
    if( $eval_start_time_ms < 0 ) {
        S_w2log( 3 , " Evaluation start at $eval_start_time_ms (ms) is less than 0 --> partly no crash data available -> must be filled with dummy values\n" );
        S_w2log( 5 , " Crash time have ".scalar @used_crash_times ." samples before filling\n" );
        S_w2log( 5 , " Crash data have ".scalar @used_crash_rollrate_values ." samples before filling\n" );
        S_w2log( 5 , " Crash times must be filled backwards until $eval_start_time_ms ms \n" );
        
        my $first_available_crash_time = $used_crash_times[0];
        my $new_dummy_sample_time_ms = $first_available_crash_time;    # take the first timestamp
        while( $new_dummy_sample_time_ms >= $eval_start_time_ms )  {
            $new_dummy_sample_time_ms -= $tcpar_crash_sample_time_ms;     # reduce the times (becoming negative)
            unshift( @used_crash_times , $new_dummy_sample_time_ms );
            unshift( @used_crash_rollrate_values , $Acc_data_dummy_value );
#             S_w2log( 5, "add new crash acc sample : [$new_dummy_sample_time_ms ms] $Acc_data_dummy_value\n" );     
        }        
        S_w2log( 5 , " Crash time have ".scalar @used_crash_times ." samples after filling\n" );
        S_w2log( 5 , " Crash data have ".scalar @used_crash_rollrate_values ." samples after filling\n" );
    }
    
    #
    # filling crash data when missing at end of evaluation range
    #
    my $last_crash_time_ms = $used_crash_times[ $#used_crash_times ];
    if( $eval_end_time_ms > $last_crash_time_ms ) {
        S_w2log( 3 , " Evaluation end at $eval_end_time_ms (ms) is bigger than latest injected crash time ($last_crash_time_ms ms) --> partly no crash data available -> must be filled with dummy values\n" );
        S_w2log( 5 , " Crash time have ".scalar @used_crash_times ." samples before filling\n" );
        S_w2log( 5 , " Crash data have ".scalar @used_crash_rollrate_values ." samples before filling\n" );
        S_w2log( 5 , " Crash times must be filled forward until $eval_end_time_ms ms \n" );
        
        my $new_dummy_sample_time_ms = $last_crash_time_ms;    # take the first timestamp
        while( $new_dummy_sample_time_ms <= $eval_end_time_ms )  {
            $new_dummy_sample_time_ms += $tcpar_crash_sample_time_ms;     # reduce the times (becoming negative)
            push( @used_crash_times , $new_dummy_sample_time_ms );
            push( @used_crash_rollrate_values , $Rollrate_data_dummy_value );
#             S_w2log( 5, "add new crash acc sample : [$new_dummy_sample_time_ms ms] $Acc_data_dummy_value\n" );     
        }        
        S_w2log( 5 , " Crash time have ".scalar @used_crash_times ." samples after filling\n" );
        S_w2log( 5 , " Crash data have ".scalar @used_crash_rollrate_values ." samples after filling\n" );
    }
    
    #
    # obtaining relevant crash data for EDR sample evaluation (in timing of EDR samples)
    #    
    
    my $next_EDR_sample_time_ms = $eval_start_time_ms;    
    my $crash_sample_nbr            = 0;
    my $EDR_sample_nr               = 0;
    my $EDR_Rollangle_calculation          = 0;

    my $Crash_Rollangle_calculation        = 0;
    my $max_Rollangle_crash_value_deg      = 0;
    my $max_Rollangle_crash_sample_time_ms = 0;

    my $max_Rollangle_from_T0_crash_sample_time_ms = 0;
    my $max_Rollangle_res_from_T0_crash_sample_time_ms = 0;

    #
    #  MAIN LOOP COLLECTING AND EVALUATING ALL SAMPLES -------------------------  
    #
    foreach my $crash_sample_ms ( @used_crash_times ) {
        $crash_sample_nbr++;        

#         S_w2log( 3, " Sample time $crash_sample_ms ms\n" ) if $eval_start_time_ms < 0;

        #
        # waiting when eval period is starting/ending
        #
        next if $crash_sample_ms < $eval_start_time_ms;   
        last if $crash_sample_ms > $eval_end_time_ms;
        
        #
        # calculating Rollangle of given crash acceleration data
        #
        my $crash_rollrate_data_value       = $used_crash_rollrate_values[$crash_sample_nbr-1];
        $Crash_Rollangle_calculation       += $crash_rollrate_data_value;
        my $crash_Rollangle_data_value_deg  = $Crash_Rollangle_calculation * $factor_Rollangle_crash_inj;        
       
        push( @EVAL_Rollangle_crash_data, $crash_Rollangle_data_value_deg ); 
#         push( @EVAL_Rollangle_crash_times, abs $crash_sample_ms - abs $eval_start_time_ms );
        push( @EVAL_Rollangle_crash_times, $crash_sample_ms );
#         push( @EVAL_Rollangle_crash_times, $crash_sample_ms - $crash_time_T0_ms );
#         S_w2rep( " crash_sample_ms $crash_sample_ms - $eval_start_time_ms eval_start_time_ms = ".$crash_sample_ms - $eval_start_time_ms."\n" );

        #
        # comparing & storing maximum of crash Rollangle
        #
        if( abs $max_Rollangle_crash_value_deg < abs $crash_Rollangle_data_value_deg ) {
            $max_Rollangle_crash_value_deg = $crash_Rollangle_data_value_deg;
            $max_Rollangle_crash_sample_time_ms = $crash_sample_ms;
            $max_Rollangle_from_T0_crash_sample_time_ms = $crash_sample_ms - $crash_time_T0_ms;
        }

        #
        # next when Rollangle maximum value ; no more actions required
        #
        next if $EDID_data_type =~ /Rollangle maximum/i ;  # from here no more required for max dv calculation

        #
        # waiting until next sample time
        #
        next if $crash_sample_ms < $next_EDR_sample_time_ms;   

        #
        # collecting sample times of EDR entries
        #
        push( @eval_EDR_sample_on_crash_timebase_ms, $next_EDR_sample_time_ms );
        $EDR_sample_nr++;

        my $min_rollangle = sprintf ( "%.2f" , $crash_Rollangle_data_value_deg - $eval_tolerance_abs ); 
        my $max_rollangle = sprintf ( "%.2f" , $crash_Rollangle_data_value_deg + $eval_tolerance_abs );
        push( @MIN_Rollangle_crash_data, $min_rollangle );
        push( @MAX_Rollangle_crash_data, $max_rollangle );
        
        #
        # here Rollrate data evaluated via Rollangle calculation
        #
        if( $EDID_data_type =~ /Rollangle/i ) 
        {
            my $EDR_Rollangle_value = sprintf ( "%.2f" , $EDID_samples_rec_aref->[$EDR_sample_nr-1] );
            EVAL_evaluate_interval ( $EDID_abbr." Rollangle [$EDR_sample_nr/$nbr_of_EDR_samples] at $crash_sample_ms ms" , $min_rollangle , $max_rollangle , $EDR_Rollangle_value );
            push( @EDR_Rollangle_samples , $EDR_Rollangle_value);
        }
            
        #
        # here Rollrate data evaluated via Rollangle calculation
        #
        if( $EDID_data_type =~ /Rollrate/i ) 
        {
            my $EDR_rollrate_value = $EDID_samples_rec_aref->[$EDR_sample_nr-1];
            
            unless( defined $EDR_rollrate_value ) {
                S_w2log( 1, $EDID_abbr." : no EDR value for sample nbr $EDR_sample_nr\n", "red" );
                S_set_verdict(VERDICT_INCONC) unless $main::opt_offline;
                last;
            }
    
            $EDR_Rollangle_calculation += $EDR_rollrate_value;
            my $EDR_Rollangle_value = sprintf ( "%.2f" , $EDR_Rollangle_calculation * $factor_Rollangle_EDR );
            EVAL_evaluate_interval ( $EDID_abbr." Rollangle [$EDR_sample_nr/$nbr_of_EDR_samples] at $crash_sample_ms ms" , $min_rollangle , $max_rollangle , $EDR_Rollangle_value );
            push( @Calc_Rollangle_samples , $EDR_Rollangle_value);
        }
            
        $next_EDR_sample_time_ms += $EDID_sample_time_ms;     # calculate time for next 2ms sample    
        last if $EDR_sample_nr == $EDID_nbr_of_samples_exp;    # from here no more evaluation -> jump out
    
    } # end of foreach loop over all crash samples
    #---------------------------------------------------------------------------

    #
    #  creating & storing graph of injected crash data (expectation) 
    #
    S_w2rep( " - - > Graph of injected crash Rollrate data [deg/sec] (converted to NHTSA system)\n" , 'indigo' );
    my $Rollrate_data_hash = {
        'time'             => \@used_crash_times,
        $EDID_abbr.'_sensor__deg/sec__NHTSA' => \@used_crash_rollrate_values,
    };

    my $report_path = $main::REPORT_PATH."/";

    my $png_data_trace_file_name = $EDID_abbr.'_sensor_RR_'.time().'.png';
    my $unv_data_trace_file_name = $EDID_abbr.'_sensor_RR_'.time().'.txt.unv';

    S_create_graph( 
                    $Rollrate_data_hash, 
                    $report_path.$png_data_trace_file_name, 
                    $EDID_abbr."_crash_Rollrate_data (T0 at $crash_time_T0_ms ms) (converted to NHTSA system)",    # time scale start with start of simulation 
                    'white' 
                    );
    S_add_pic2html( 
                    "./".$png_data_trace_file_name, 
                    '', 
                    "./".$unv_data_trace_file_name, 
                    'TYPE="text/unv"' 
                    );
                    
    EVAL_importUNV( $report_path.$unv_data_trace_file_name );
#

    #
    #  creating & storing graph of injected crash data (Rollangle) (expectation) 
    #
    S_w2rep( " - - > Graph of calculated Rollangle out of injected Rollrate crash data [degree] (converted to NHTSA system)\n" , 'indigo' );
    my $Acc_Rollangle_data_hash = {
        'time'             => \@EVAL_Rollangle_crash_times,
        $EDID_abbr.'_sensor__degree__NHTSA' => \@EVAL_Rollangle_crash_data,
    };

    my $report_path = $main::REPORT_PATH."/";

    my $png_Rollangle_data_trace_file_name = $EDID_abbr.'_sensor_RA_'.time().'.png';
    my $unv_Rollangle_data_trace_file_name = $EDID_abbr.'_sensor_RA_'.time().'.txt.unv';

    S_create_graph( 
                    $Acc_Rollangle_data_hash, 
                    $report_path.$png_Rollangle_data_trace_file_name, 
                    $EDID_abbr."_Rollangle_crash_data (evaluation period $EDID_start_time_ms .. $EDID_end_time_ms with $EDID_sample_rate_Hz Hz)", 
                    'white' , 
#                     'interpolate_points'
                    );                    
    S_add_pic2html( 
                    "./".$png_Rollangle_data_trace_file_name, '', 
                    "./".$unv_Rollangle_data_trace_file_name, 'TYPE="text/unv"' 
                    );
                    
    EVAL_importUNV( $report_path.$unv_Rollangle_data_trace_file_name );



    #
    # ROLLANGLE EDID 27
    #
    if( $EDID_data_type =~ /Rollangle/i )  {
        #
        #  creating & storing graph of EDR storage data (measured) 
        #
        S_w2rep( " - - > Graph of stored EDR data samples [degree]\n" , 'indigo' );
        my $Acc_data_hash = {
            'time'             => \@eval_EDR_sample_on_crash_timebase_ms,
            $EDID_abbr.'_EDR__degree__NHTSA' => $EDID_samples_rec_aref,
        };
    
        my $report_path = $main::REPORT_PATH."/";
    
        my $png_EDR_data_trace_file_name = $EDID_abbr.'_EDR_'.time().'.png';
        my $unv_EDR_data_trace_file_name = $EDID_abbr.'_EDR_'.time().'.txt.unv';
    
        S_create_graph( 
                        $Acc_data_hash, 
                        $report_path.$png_EDR_data_trace_file_name, 
                        $EDID_abbr."_EDR_data (evaluation period $EDID_start_time_ms .. $EDID_end_time_ms with $EDID_sample_rate_Hz Hz)", 
                        'white' , 
#                         'interpolate_points' 
                        );                        
        S_add_pic2html( 
                        "./".$png_EDR_data_trace_file_name, '', 
                        "./".$unv_EDR_data_trace_file_name, 'TYPE="text/unv"' 
                        );
                        
        EVAL_importUNV( $report_path.$unv_EDR_data_trace_file_name );
    
        #
        #  creating & storing graph of EDR sample evaluation 
        #
        S_w2rep( " - - > Graph of Rollangle of EDR data samples with MIN/MAX expectation of calculated Rollangle of crash data [degree]\n" , 'indigo' );
        my $Rollangle_rec_hash = {
            'time'                                         => \@eval_EDR_sample_on_crash_timebase_ms,
            $EDID_abbr.'_Rollangle_rec_EDR__degree__NHTSA' => \@EDR_Rollangle_samples,
            $EDID_abbr.'_Rollangle_exp_MIN__degree__NHTSA' => \@MIN_Rollangle_crash_data,
            $EDID_abbr.'_Rollangle_exp_MAX__degree__NHTSA' => \@MAX_Rollangle_crash_data,
        };
    
        my $png_sample_Rollangle_eval_file_name = $EDID_abbr.'_EVAL_'.time().'.png';
        my $unv_sample_Rollangle_eval_file_name = $EDID_abbr.'_EVAL_'.time().'.txt.unv';
    
        S_create_graph(
                        $Rollangle_rec_hash, 
                        $report_path.$png_sample_Rollangle_eval_file_name,
                        "EDID $EDID_nbr : $EDID_descr Rollangle (evaluation period $EDID_start_time_ms .. $EDID_end_time_ms with $EDID_sample_rate_Hz Hz)", 
                        'white', 
                        'interpolate_points'
                        );                        
        S_add_pic2html( 
                        "./".$png_sample_Rollangle_eval_file_name , '', 
                        "./".$unv_sample_Rollangle_eval_file_name, 'TYPE="text/unv"' 
                        );
                        
        EVAL_importUNV( $report_path.$unv_sample_Rollangle_eval_file_name );
    }

    #
    # ROLLRATE EDID 888
    #
    if( $EDID_data_type =~ /Rollrate/i )  {
        #
        #  creating & storing graph of EDR storage data (measured) 
        #
        S_w2rep( " - - > Graph of stored EDR data samples [deg/sec]\n" , 'indigo' );
        my $Acc_data_hash = {
            'time'             => \@eval_EDR_sample_on_crash_timebase_ms,
            $EDID_abbr.'_EDR__deg/sec__NHTSA' => $EDID_samples_rec_aref,
        };
    
        my $report_path = $main::REPORT_PATH."/";
    
        my $png_EDR_data_trace_file_name = $EDID_abbr.'_EDR_'.time().'.png';
        my $unv_EDR_data_trace_file_name = $EDID_abbr.'_EDR_'.time().'.txt.unv';
    
        S_create_graph( 
                        $Acc_data_hash, 
                        $report_path.$png_EDR_data_trace_file_name, 
                        $EDID_abbr."_EDR_data (evaluation period $EDID_start_time_ms .. $EDID_end_time_ms with $EDID_sample_rate_Hz Hz)", 
                        'white' , 
#                         'interpolate_points' 
                        );                        
        S_add_pic2html( 
                        "./".$png_EDR_data_trace_file_name, '', 
                        "./".$unv_EDR_data_trace_file_name, 'TYPE="text/unv"' 
                        );
                        
        EVAL_importUNV( $report_path.$unv_EDR_data_trace_file_name );
    
        #
        #  creating & storing graph of EDR sample evaluation 
        #
        S_w2rep( " - - > Graph of calculated Rollangle of EDR data samples with MIN/MAX expectation from calculated Rollangle of crash data [degree]\n" , 'indigo' );
        my $Rollangle_rec_hash = {
            'time'                                          => \@eval_EDR_sample_on_crash_timebase_ms,
            $EDID_abbr.'_Rollangle_calc_EDR__degree__NHTSA' => \@Calc_Rollangle_samples,
            $EDID_abbr.'_Rollangle_exp_MIN__degree__NHTSA'  => \@MIN_Rollangle_crash_data,
            $EDID_abbr.'_Rollangle_exp_MAX__degree__NHTSA'  => \@MAX_Rollangle_crash_data,
        };
    
        my $png_sample_Rollangle_eval_file_name = $EDID_abbr.'_EVAL_'.time().'.png';
        my $unv_sample_Rollangle_eval_file_name = $EDID_abbr.'_EVAL_'.time().'.txt.unv';
    
        S_create_graph(
                        $Rollangle_rec_hash, 
                        $report_path.$png_sample_Rollangle_eval_file_name,
                        "EDID $EDID_nbr : $EDID_descr Rollangle (evaluation period $EDID_start_time_ms .. $EDID_end_time_ms with $EDID_sample_rate_Hz Hz)", 
                        'white', 
                        'interpolate_points'
                        );                        
        S_add_pic2html( 
                        "./".$png_sample_Rollangle_eval_file_name , '', 
                        "./".$unv_sample_Rollangle_eval_file_name, 'TYPE="text/unv"' 
                        );
                        
        EVAL_importUNV( $report_path.$unv_sample_Rollangle_eval_file_name );
    }

    return 1;
}



###-----------------------------------------------------------------------------
sub eval_velocity_ringbuffer { 
###-----------------------------------------------------------------------------

    my $params = shift;

#         eval_velocity_ringbuffer (
#             'EDID_nbr'              => 788 ,
#             'EDID_abbr'             => 'Acc__788__VDS_LowX' ,
#             'EDID_nbr_of_samples'   => 46 ,
#             'EDID_sample_rate_Hz'   => 500 ,
#             'EDID_samples_rec'      => \@Acc__788__VDS_LowX_rec ,
#             'crash_acc_data'        => \@{$All_crash_data->{ 'Acc_VDS_LowX_value' }} ,
#             'crash_times'           => \@{$All_crash_data->{ 'time' }} ,
#             'time_T0_ms_ms'            => $time_T0,
#             'EDID_start_time_ms'    => -10 ,
#             'EDID_end_time_ms'      => 80 ,
#             'EDID_data_type'        => 'acceleration' ,
#             'eval_tolerance_abs'    => $tcpar_abs_tolerance_dv ,
#         );

    my $EDID_data_type          = $params->{'EDID_data_type'}; 
    my $eval_tolerance_abs      = $params->{'eval_tolerance_abs'}; 
    my $EDID_nbr                = $params->{'EDID_nbr'}; 
    my $EDID_abbr               = $params->{'EDID_abbr'}; 
    my $EDID_nbr_of_samples_exp = $params->{'EDID_nbr_of_samples'}; 
    my $EDID_sample_rate_Hz     = $params->{'EDID_sample_rate_Hz'};     
    my $EDID_samples_rec_aref   = $params->{'EDID_samples_rec'};        
    my $EDID_start_time_ms      = $params->{'EDID_start_time_ms'}; 
    my $EDID_end_time_ms        = $params->{'EDID_end_time_ms'};   
    my $crash_acc_data_aref     = $params->{'crash_acc_data'};     
    my $crash_acc2_data_aref    = $params->{'crash_acc2_data'};     
    my $crash_all_times_aref    = $params->{'crash_times'};      
    my $crash_time_T0_ms        = $params->{'time_T0_ms'};                
    
    my @EVAL_dv_crash_data = ();
    my @EVAL_dv_crash_times = ();
    my @MIN_dv_crash_data = ();
    my @MAX_dv_crash_data = ();

    my $EDID_sample_time_ms;
    my @eval_EDR_sample_on_crash_timebase_ms = ();
    
    my @Calc_dv_samples = ();
    my @EDR_dv_samples = ();

    my @used_crash_times = ();
    my @used_crash_acc_values = ();
    my @used_crash_acc2_values = ();
    
    my $EDID_descr = EDR_fetchEDIDLabel($EDID_nbr); 

    if( defined $EDID_sample_rate_Hz ) {
        $EDID_sample_time_ms = ( 1 / $EDID_sample_rate_Hz ) * 1000;
        S_w2log( 3 , " Calculated sample time --> $EDID_sample_time_ms (ms) (based on given sample rate $EDID_sample_rate_Hz Hz )\n" );
    }
    
    my $eval_start_time_ms = $crash_time_T0_ms + $EDID_start_time_ms;
    S_w2log( 3 , " Evaluation start at $eval_start_time_ms (ms) ( --> T0 $crash_time_T0_ms (ms) + $EDID_start_time_ms (ms) )\n" );
    
    my $eval_end_time_ms = $crash_time_T0_ms + $EDID_end_time_ms + 1;
    S_w2log( 3 , " Evaluation end at $eval_end_time_ms (ms) ( --> T0 $crash_time_T0_ms ms + $EDID_end_time_ms ms +  1 ms )\n" );

    my $factor_dv_crash_inj_EDR = 9.81 * $EDID_sample_time_ms * 0.001 * 3.6 if defined $EDID_sample_time_ms;
 
    S_w2rep( " - - - - - - - - - - - - - - - - - - - - - - - - - - -\n" );
    S_w2rep( "  ===> Evaluating EDID $EDID_nbr\n" , "indigo" );
    S_w2rep( "  ===> $EDID_descr\n" , "indigo" );
    S_w2rep( "  ===> $EDID_nbr_of_samples_exp samples \n" , "indigo" );
    S_w2rep( "  ===> $EDID_start_time_ms ms start time ( $eval_start_time_ms ms in crash data)\n" , "indigo" );
    S_w2rep( "  ===> $EDID_end_time_ms ms end time ( $eval_end_time_ms ms in crash data)\n" , "indigo" );
    S_w2rep( "  ===> $EDID_sample_rate_Hz Hz sample rate ($EDID_sample_time_ms ms) \n" , "indigo" ) if defined $EDID_sample_time_ms;
    S_w2rep( " - - - - - - - - - - - - - - - - - - - - - - - - - - -\n" );
    
    #
    # Evaluate correct nbr of EDR samples
    #
    my $nbr_of_EDR_samples = scalar @$EDID_samples_rec_aref;
    EVAL_evaluate_value( "EDID $EDID_nbr - Nbr of EDR samples" , $nbr_of_EDR_samples , "==" , $EDID_nbr_of_samples_exp );
    unless( $nbr_of_EDR_samples ) {
        S_w2rep( " - - - No further evaluation required - - - \n" , 'red' );
        return 1;
    }

    unless( ref $crash_all_times_aref eq 'ARRAY' ) {
        S_set_error( "UNEXPECTED ERROR : given parameter 'crash_times' isnt a ARRAY ref as expected - following a dump is printed" );
        S_w2rep( "BEGIN of DUMP\n".Dumper( $crash_all_times_aref )."\nEND_OF_DUMP\n" );
        return;
    }

    @used_crash_times       = @$crash_all_times_aref;
    @used_crash_acc_values  = @$crash_acc_data_aref;
    @used_crash_acc2_values = @$crash_acc2_data_aref if defined @$crash_acc2_data_aref;
    
    
    #
    # filling crash data when missing at beginning of evaluation range
    #
    if( $eval_start_time_ms < 0 ) {
        S_w2log( 3 , " Evaluation start at $eval_start_time_ms (ms) is less than 0 --> partly no crash data available -> must be filled with dummy values\n" );
        S_w2log( 5 , " Crash time have ".scalar @used_crash_times ." samples before filling\n" );
        S_w2log( 5 , " Crash data have ".scalar @used_crash_acc_values ." samples before filling\n" );
        S_w2log( 5 , " Crash data2 have ".scalar @used_crash_acc2_values ." samples before filling\n" ) if defined @$crash_acc2_data_aref;
        S_w2log( 5 , " Crash times must be filled backwards until $eval_start_time_ms ms \n" );
        
        my $first_available_crash_time = $used_crash_times[0];
        my $new_dummy_sample_time_ms = $first_available_crash_time;    # take the first timestamp
        while( $new_dummy_sample_time_ms >= $eval_start_time_ms )  {
            $new_dummy_sample_time_ms -= $tcpar_crash_sample_time_ms;     # reduce the times (becoming negative)
            unshift( @used_crash_times , $new_dummy_sample_time_ms );
            unshift( @used_crash_acc_values , $Acc_data_dummy_value );
            unshift( @used_crash_acc2_values , $Acc_data2_dummy_value )if defined @$crash_acc2_data_aref;
#             S_w2log( 5, "add new crash acc sample : [$new_dummy_sample_time_ms ms] $Acc_data_dummy_value\n" );     
        }        
        S_w2log( 5 , " Crash time have ".scalar @used_crash_times ." samples after filling\n" );
        S_w2log( 5 , " Crash data have ".scalar @used_crash_acc_values ." samples after filling\n" );
        S_w2log( 5 , " Crash data2 have ".scalar @used_crash_acc2_values ." samples after filling\n" ) if defined @$crash_acc2_data_aref;
    }

    #
    # filling crash data when missing at end of evaluation range
    #
    my $last_crash_time_ms = $used_crash_times[ $#used_crash_times ];
    if( $eval_end_time_ms > $last_crash_time_ms ) {
        S_w2log( 3 , " Evaluation end at $eval_end_time_ms (ms) is bigger than latest injected crash time ($last_crash_time_ms ms) --> partly no crash data available -> must be filled with dummy values\n" );
        S_w2log( 5 , " Crash time have ".scalar @used_crash_times ." samples before filling\n" );
        S_w2log( 5 , " Crash data have ".scalar @used_crash_acc_values ." samples before filling\n" );
        S_w2log( 5 , " Crash data2 have ".scalar @used_crash_acc2_values ." samples before filling\n" ) if defined @$crash_acc2_data_aref;
        S_w2log( 5 , " Crash times must be filled backwards until $eval_start_time_ms ms \n" );
        
        my $new_dummy_sample_time_ms = $last_crash_time_ms;    # take the first timestamp
        while( $new_dummy_sample_time_ms <= $eval_end_time_ms )  {
            $new_dummy_sample_time_ms += $tcpar_crash_sample_time_ms;     # reduce the times (becoming negative)
            push( @used_crash_times , $new_dummy_sample_time_ms );
            push( @used_crash_acc_values , $Acc_data_dummy_value );
            push( @used_crash_acc2_values , $Acc_data2_dummy_value )if defined @$crash_acc2_data_aref;
#             S_w2log( 5, "add new crash acc sample : [$new_dummy_sample_time_ms ms] $Acc_data_dummy_value\n" );     
        }        
        S_w2log( 5 , " Crash time have ".scalar @used_crash_times ." samples after filling\n" );
        S_w2log( 5 , " Crash data have ".scalar @used_crash_acc_values ." samples after filling\n" );
        S_w2log( 5 , " Crash data2 have ".scalar @used_crash_acc2_values ." samples after filling\n" ) if defined @$crash_acc2_data_aref;
    }
    

    #
    # obtaining relevant crash data for EDR sample evaluation (in timing of EDR samples)
    #    
    
    my $next_EDR_sample_time_ms = $eval_start_time_ms;    
    my $crash_sample_nbr            = 0;
    my $EDR_sample_nr               = 0;
    my $EDR_dv_calculation          = 0;

    my $Crash_dv_calculation        = 0;
    my $max_dv_crash_value_kmh      = 0;
    my $max_dv_crash_sample_time_ms = 0;

    my $Crash_dv2_calculation       = 0;
    my $max_dv_res_crash_value_kmh  = 0;
    my $max_dv_res_crash_sample_time_ms = 0;

    my $max_dv_from_T0_crash_sample_time_ms = 0;
    my $max_dv_res_from_T0_crash_sample_time_ms = 0;

    
    #
    #  MAIN LOOP COLLECTING AND EVALUATING ALL SAMPLES -------------------------  
    #
    foreach my $crash_sample_ms ( @used_crash_times ) {
        $crash_sample_nbr++;        

#         S_w2log( 3, " Sample time $crash_sample_ms ms\n" ) if $eval_start_time_ms < 0;

        #
        # waiting when eval period is starting/ending
        #
        next if $crash_sample_ms < $eval_start_time_ms;   
        last if $crash_sample_ms > $eval_end_time_ms;
        
        #
        # calculating delta-v of given crash acceleration data
        #
        my $crash_acc_data_value     = $used_crash_acc_values[$crash_sample_nbr-1];
        $Crash_dv_calculation       += $crash_acc_data_value;
        my $crash_dv_data_value_kmh  = $Crash_dv_calculation * $factor_dv_crash_inj;        

#         S_w2log( 3, " Sample value $crash_acc_data_value \n" ) if $eval_start_time_ms < 0;
       
        push( @EVAL_dv_crash_data, $crash_dv_data_value_kmh ); 
#         push( @EVAL_dv_crash_times, abs $crash_sample_ms - abs $eval_start_time_ms );
        push( @EVAL_dv_crash_times, $crash_sample_ms );

        #
        # comparing & storing maximum of crash delta-v
        #
        if( abs $max_dv_crash_value_kmh < abs $crash_dv_data_value_kmh ) {
            $max_dv_crash_value_kmh = $crash_dv_data_value_kmh;
            $max_dv_crash_sample_time_ms = $crash_sample_ms;
            $max_dv_from_T0_crash_sample_time_ms = $crash_sample_ms - $crash_time_T0_ms;
        }

        #
        # calculating delta-v resultant of given crash acceleration data
        #
        if ( defined $crash_acc2_data_aref ) {
            
            #
            # calculating delta-v of second given crash acceleration data ( Y when X was first or vice versa)
            #
            my $crash_acc2_data_value    = $used_crash_acc2_values[$crash_sample_nbr-1];
            $Crash_dv2_calculation      += $crash_acc2_data_value;
            my $crash_dv2_data_value_kmh = $Crash_dv_calculation * $factor_dv_crash_inj;

            #
            # vector addition of X and Y velocity signals
            #
            my $crash_dv_res_data_value_kmh = sqrt(  
                                                      $crash_dv_data_value_kmh**2 
                                                    + $crash_dv2_data_value_kmh**2 
                                                    );
            #
            # comparing & storing maximum of crash delta-v resultant
            #
            if( abs $max_dv_res_crash_value_kmh < abs $crash_dv_res_data_value_kmh ) {
                $max_dv_res_crash_value_kmh = $crash_dv_res_data_value_kmh;
                $max_dv_res_crash_sample_time_ms = $crash_sample_ms;
                $max_dv_res_from_T0_crash_sample_time_ms =  $crash_sample_ms - $crash_time_T0_ms;
            }
        }
                    
        #
        # next when delta-v maximum value ; no more actions required
        #
        next if $EDID_data_type =~ /delta-v maximum/i ;  # from here no more required for max dv calculation

        #
        # waiting until next sample time
        #
        next if $crash_sample_ms < $next_EDR_sample_time_ms;   

        #
        # collecting sample times of EDR entries
        #
        push( @eval_EDR_sample_on_crash_timebase_ms, $next_EDR_sample_time_ms );
        $EDR_sample_nr++;

        my $min_dv = sprintf ( "%.2f" , $crash_dv_data_value_kmh - $eval_tolerance_abs ); 
        my $max_dv = sprintf ( "%.2f" , $crash_dv_data_value_kmh + $eval_tolerance_abs );
        push( @MIN_dv_crash_data, $min_dv );
        push( @MAX_dv_crash_data, $max_dv );
        
        #
        # here Acceleration data evaluated via delta-v calculation
        #
        if( $EDID_data_type =~ /delta-v/i ) 
        {
            my $EDR_dv_value = sprintf ( "%.2f" , $EDID_samples_rec_aref->[$EDR_sample_nr-1] );
            EVAL_evaluate_interval ( $EDID_abbr." delta-v [$EDR_sample_nr/$nbr_of_EDR_samples] at $crash_sample_ms ms" , $min_dv , $max_dv , $EDR_dv_value );
            push( @EDR_dv_samples , $EDR_dv_value);
        }
            
        #
        # here Acceleration data evaluated via delta-v calculation
        #
        if( $EDID_data_type =~ /acceleration/i ) 
        {
            my $EDR_acc_value = $EDID_samples_rec_aref->[$EDR_sample_nr-1];
            
            unless( defined $EDR_acc_value ) {
                S_w2log( 1, $EDID_abbr." : no EDR value for sample nbr $EDR_sample_nr\n", "red" );
                S_set_verdict(VERDICT_INCONC) unless $main::opt_offline;
                last;
            }
    
            $EDR_dv_calculation += $EDR_acc_value;
            my $EDR_dv_value = sprintf ( "%.2f" , $EDR_dv_calculation * $factor_dv_crash_inj_EDR );
            EVAL_evaluate_interval ( $EDID_abbr." delta-v [$EDR_sample_nr/$nbr_of_EDR_samples] at $crash_sample_ms ms" , $min_dv , $max_dv , $EDR_dv_value );
            push( @Calc_dv_samples , $EDR_dv_value);
        }
            
        $next_EDR_sample_time_ms += $EDID_sample_time_ms;     # calculate time for next 2ms sample    
        last if $EDR_sample_nr == $EDID_nbr_of_samples_exp;    # from here no more evaluation -> jump out
    
    } # end of foreach loop over all crash samples


    #
    #  creating & storing graph of injected crash data (expectation) 
    #
    S_w2rep( " - - > Graph of injected crash data [g] (converted to NHTSA system)\n" , 'indigo' );
    my $Acc_data_hash = {
        'time'                         => \@used_crash_times,
        $EDID_abbr.'_sensor__g__NHTSA' => \@used_crash_acc_values,
    };

    my $report_path = $main::REPORT_PATH."/";

    my $png_data_trace_file_name = $EDID_abbr.'_sensor_'.time().'.png';
    my $unv_data_trace_file_name = $EDID_abbr.'_sensor_'.time().'.txt.unv';

    S_create_graph( 
                    $Acc_data_hash, 
                    $report_path.$png_data_trace_file_name, 
                    $EDID_abbr."_crash_data (T0 at $crash_time_T0_ms ms)",    # time scale start with start of simulation 
                    'white' 
                    );
    S_add_pic2html( 
                    "./".$png_data_trace_file_name, 
                    '', 
                    "./".$unv_data_trace_file_name, 
                    'TYPE="text/unv"' 
                    );
                    
    EVAL_importUNV( $report_path.$unv_data_trace_file_name );
#

    #
    #  creating & storing graph of injected crash data (delta-v) (expectation) 
    #
    S_w2rep( " - - > Graph of calculated delta-v of injected crash data [km/h] (converted to NHTSA system)\n" , 'indigo' );
    my $Acc_dv_data_hash = {
        'time'             => \@EVAL_dv_crash_times,
        $EDID_abbr.'_sensor_dv__km/h__NHTSA' => \@EVAL_dv_crash_data,
    };

    my $report_path = $main::REPORT_PATH."/";

    my $png_dv_data_trace_file_name = $EDID_abbr.'_sensor_dv_'.time().'.png';
    my $unv_dv_data_trace_file_name = $EDID_abbr.'_sensor_dv_'.time().'.txt.unv';

    S_create_graph( 
                    $Acc_dv_data_hash, 
                    $report_path.$png_dv_data_trace_file_name, 
                    $EDID_abbr."_dv_crash_data (evaluation period $EDID_start_time_ms .. $EDID_end_time_ms with $EDID_sample_rate_Hz Hz)", 
                    'white' , 
#                     'interpolate_points'
                    );                    
    S_add_pic2html( 
                    "./".$png_dv_data_trace_file_name, '', 
                    "./".$unv_dv_data_trace_file_name, 'TYPE="text/unv"' 
                    );
                    
    EVAL_importUNV( $report_path.$unv_dv_data_trace_file_name );


    #
    # EDID 33 + 34
    #
    if( $EDID_data_type =~ /delta-v maximum value/i ) {
        my $EDR_max_dv_value_kmh = $EDID_samples_rec_aref->[0];
        S_w2rep( "Maximum delta-v value in crash data -> $max_dv_crash_value_kmh km/h [at $max_dv_crash_sample_time_ms ms] \n" , "blue" );     
        EVAL_evaluate_value ( 
                                $EDID_abbr." delta-v maximum value" , 
                                $EDR_max_dv_value_kmh , 
                                '==' , 
                                $max_dv_crash_value_kmh , 
                                $eval_tolerance_abs  , 
                                'absolute' 
                            );
        return 1;
    }
    
    #
    # EDID 35 + 36
    #
    if( $EDID_data_type =~ /delta-v maximum time/i ) {
        my $EDR_max_dv_time_ms = $EDID_samples_rec_aref->[0];
        S_w2rep( "Maximum delta-v time from T0 : $max_dv_from_T0_crash_sample_time_ms ms ( $max_dv_crash_value_kmh km/h at $max_dv_crash_sample_time_ms ms crash time)\n" , "blue" );     
        EVAL_evaluate_value ( 
                                $EDID_abbr." delta-v maximum time" , 
                                $EDR_max_dv_time_ms , 
                                '==' , 
                                $max_dv_from_T0_crash_sample_time_ms , 
                                $tcpar_abs_tolerance_dv_time  , 
                                'absolute' 
                            );
        return 1;
    }
    
    #
    # EDID 39
    #
    if( $EDID_data_type =~ /resultant delta-v maximum value/i ) {
        my $EDR_max_dv_res_value_kmh = $EDID_samples_rec_aref->[0];
        S_w2rep( "Resultant maximum delta-v value in crash data -> $max_dv_res_crash_value_kmh km/h [at $max_dv_res_crash_sample_time_ms ms] \n" , "blue" );     
        EVAL_evaluate_value ( 
                                $EDID_abbr." resultant delta-v maximum value" , 
                                $EDR_max_dv_res_value_kmh , 
                                '==' , 
                                $max_dv_res_crash_value_kmh , 
                                $eval_tolerance_abs  , 
                                'absolute' 
                            );
        return 1;
    }
    
    #
    # EDID 37
    #
    if( $EDID_data_type =~ /resultant delta-v maximum time/i ) {
        my $EDR_max_dv_res_time_ms = $EDID_samples_rec_aref->[0];
        S_w2rep( "Resultant maximum delta-v time from T0 : $max_dv_res_from_T0_crash_sample_time_ms ms ( $max_dv_res_crash_value_kmh km/h at $max_dv_res_crash_sample_time_ms ms crash time)\n" , "blue" );     
        EVAL_evaluate_value ( 
                                $EDID_abbr." resultant delta-v maximum time" , 
                                $EDR_max_dv_res_time_ms , 
                                '==' , 
                                $max_dv_res_from_T0_crash_sample_time_ms , 
                                $tcpar_abs_tolerance_dv_time  , 
                                'absolute' 
                            );
        return 1;
    }
    

    if( $EDID_data_type =~ /acceleration/i )  {
        #
        #  creating & storing graph of EDR storage data (measured) 
        #
        S_w2rep( " - - > Graph of stored EDR data samples [g]\n" , 'indigo' );
        my $Acc_data_hash = {
            'time'                      => \@eval_EDR_sample_on_crash_timebase_ms,
            $EDID_abbr.'_EDR__g__NHTSA' => $EDID_samples_rec_aref,
        };
    
        my $report_path = $main::REPORT_PATH."/";
    
        my $png_EDR_data_trace_file_name = $EDID_abbr.'_EDR_'.time().'.png';
        my $unv_EDR_data_trace_file_name = $EDID_abbr.'_EDR_'.time().'.txt.unv';
    
        S_create_graph( 
                        $Acc_data_hash, 
                        $report_path.$png_EDR_data_trace_file_name, 
                        $EDID_abbr."_EDR_data (evaluation period $EDID_start_time_ms .. $EDID_end_time_ms with $EDID_sample_rate_Hz Hz)", 
                        'white' , 
#                         'interpolate_points' 
                        );                        
        S_add_pic2html( 
                        "./".$png_EDR_data_trace_file_name, '', 
                        "./".$unv_EDR_data_trace_file_name, 'TYPE="text/unv"' 
                        );
                        
        EVAL_importUNV( $report_path.$unv_EDR_data_trace_file_name );
    
        #
        #  creating & storing graph of EDR sample evaluation 
        #
        S_w2rep( " - - > Graph of calculated delta-v of EDR data samples with MIN/MAX expectation from delta-v of crash data [km/h]\n" , 'indigo' );
        my $Acc_dv_rec_hash = {
            'time'                => \@eval_EDR_sample_on_crash_timebase_ms,
            $EDID_abbr.'_dv_calc_EDR__km/h__NHTSA' => \@Calc_dv_samples,
            $EDID_abbr.'_dv_exp_MIN__km/h__NHTSA'  => \@MIN_dv_crash_data,
            $EDID_abbr.'_dv_exp_MAX__km/h__NHTSA'  => \@MAX_dv_crash_data,
        };
    
        my $png_sample_dv_eval_file_name = $EDID_abbr.'_EVAL_'.time().'.png';
        my $unv_sample_dv_eval_file_name = $EDID_abbr.'_EVAL_'.time().'.txt.unv';
    
        S_create_graph(
                        $Acc_dv_rec_hash, 
                        $report_path.$png_sample_dv_eval_file_name,
                        "EDID $EDID_nbr : $EDID_descr delta-v (evaluation period $EDID_start_time_ms .. $EDID_end_time_ms with $EDID_sample_rate_Hz Hz)", 
                        'white', 
                        'interpolate_points'
                        );                        
        S_add_pic2html( 
                        "./".$png_sample_dv_eval_file_name , '', 
                        "./".$unv_sample_dv_eval_file_name, 'TYPE="text/unv"' 
                        );
                        
        EVAL_importUNV( $report_path.$unv_sample_dv_eval_file_name );
    }

    #
    # EDID 31 + 32
    #
    if( $EDID_data_type =~ /delta-v/i )  {
        #
        #  creating & storing graph of EDR sample evaluation 
        #
        S_w2rep( " - - > Graph of EDR delta-v samples with MIN/MAX expectation from delta-v of crash data [km/h]\n" , 'indigo' );
        my $Acc_dv_rec_hash = {
            'time'                                => \@eval_EDR_sample_on_crash_timebase_ms,
            $EDID_abbr.'_dv_rec_EDR__km/h__NHTSA' => \@EDR_dv_samples,
            $EDID_abbr.'_dv_exp_MIN__km/h__NHTSA' => \@MIN_dv_crash_data,
            $EDID_abbr.'_dv_exp_MAX__km/h__NHTSA' => \@MAX_dv_crash_data,
        };
    
        my $png_sample_dv_eval_file_name = $EDID_abbr.'_EVAL_'.time().'.png';
        my $unv_sample_dv_eval_file_name = $EDID_abbr.'_EVAL_'.time().'.txt.unv';
    
        S_create_graph(
                        $Acc_dv_rec_hash, 
                        $report_path.$png_sample_dv_eval_file_name,
                        "EDID $EDID_nbr : $EDID_descr delta-v (evaluation period $EDID_start_time_ms .. $EDID_end_time_ms with $EDID_sample_rate_Hz Hz)", 
                        'white', 
                        'interpolate_points'
                        );
        S_add_pic2html( 
                        "./".$png_sample_dv_eval_file_name , '', 
                        "./".$unv_sample_dv_eval_file_name, 'TYPE="text/unv"' 
                        );
                        
        EVAL_importUNV( $report_path.$unv_sample_dv_eval_file_name );
    }

    return 1;
}

###-----------------------------------------------------------------------------
sub eval_pressure_ringbuffer { 
###-----------------------------------------------------------------------------

    my $params = shift;

#         eval_pressure_ringbuffer (
#             'EDID_nbr'              => 788 ,
#             'EDID_abbr'             => 'Press__788__VDS_LowX' ,
#             'EDID_nbr_of_samples'   => 46 ,
#             'EDID_sample_rate_Hz'   => 500 ,
#             'EDID_samples_rec'      => \@Press__788__VDS_LowX_rec ,
#             'crash_pressure_data'   => \@{$All_crash_data->{ 'Press_...' }} ,
#             'crash_times'           => \@{$All_crash_data->{ 'time' }} ,
#             'time_T0_ms'            => $time_T0,
#             'EDID_start_time_ms'    => -10 ,
#             'EDID_end_time_ms'      => 80 ,
#             'EDID_data_type'        => 'pressure' ,
#             'eval_tolerance_abs'    => $tcpar_abs_tolerance_dv ,
#         );

    my $EDID_data_type          = $params->{'EDID_data_type'}; 
    my $eval_tolerance_abs      = $params->{'eval_tolerance_abs'}; 
    my $EDID_nbr                = $params->{'EDID_nbr'}; 
    my $EDID_abbr               = $params->{'EDID_abbr'}; 
    my $EDID_nbr_of_samples_exp = $params->{'EDID_nbr_of_samples'}; 
    my $EDID_sample_rate_Hz     = $params->{'EDID_sample_rate_Hz'};     
    my $EDID_samples_rec_aref   = $params->{'EDID_samples_rec'};        
    my $EDID_start_time_ms      = $params->{'EDID_start_time_ms'}; 
    my $EDID_end_time_ms        = $params->{'EDID_end_time_ms'};   
    my $crash_press_data_aref   = $params->{'crash_pressure_data'};     
    my $crash_all_times_aref    = $params->{'crash_times'};      
    my $crash_time_T0_ms        = $params->{'time_T0_ms'};                
    
    my @EVAL_pressure_crash_data = ();
    my @EVAL_pressure_crash_times = ();
    my @MIN_pressure_crash_data = ();
    my @MAX_pressure_crash_data = ();

    my $EDID_sample_time_ms;
    my @eval_EDR_sample_on_crash_timebase_ms = ();
    
    my @Calc_pressure_samples = ();
    my @EDR_pressure_samples = ();

    my @used_crash_times = ();
    my @used_crash_press_values = ();

    my $EDID_descr = EDR_fetchEDIDLabel($EDID_nbr); 

    if( defined $EDID_sample_rate_Hz ) {
        $EDID_sample_time_ms = ( 1 / $EDID_sample_rate_Hz ) * 1000;
        S_w2log( 3 , " Calculated sample time --> $EDID_sample_time_ms (ms) (based on given sample rate $EDID_sample_rate_Hz Hz )\n" );
    }
    
    my $eval_start_time_ms = $crash_time_T0_ms + $EDID_start_time_ms;
    S_w2log( 3 , " Evaluation start at $eval_start_time_ms (ms) ( --> T0 $crash_time_T0_ms (ms) + $EDID_start_time_ms (ms) )\n" );
    
    my $eval_end_time_ms = $crash_time_T0_ms + $EDID_end_time_ms + 1;
    S_w2log( 3 , " Evaluation end at $eval_end_time_ms (ms) ( --> T0 $crash_time_T0_ms ms + $EDID_end_time_ms ms +  1 ms )\n" );

    my $factor_pressure_crash_inj_EDR = 9.81 * $EDID_sample_time_ms * 0.001 * 3.6 if defined $EDID_sample_time_ms;
 
    S_w2rep( " - - - - - - - - - - - - - - - - - - - - - - - - - - -\n" );
    S_w2rep( "  ===> Evaluating EDID $EDID_nbr\n" , "indigo" );
    S_w2rep( "  ===> $EDID_descr\n" , "indigo" );
    S_w2rep( "  ===> $EDID_nbr_of_samples_exp samples \n" , "indigo" );
    S_w2rep( "  ===> $EDID_start_time_ms ms start time ( $eval_start_time_ms ms in crash data)\n" , "indigo" );
    S_w2rep( "  ===> $EDID_end_time_ms ms end time ( $eval_end_time_ms ms in crash data)\n" , "indigo" );
    S_w2rep( "  ===> $EDID_sample_rate_Hz Hz sample rate ($EDID_sample_time_ms ms) \n" , "indigo" ) if defined $EDID_sample_rate_Hz;
    S_w2rep( " - - - - - - - - - - - - - - - - - - - - - - - - - - -\n" );
    
    #
    # Evaluate correct nbr of EDR samples
    #
    my $nbr_of_EDR_samples = scalar @$EDID_samples_rec_aref;
    EVAL_evaluate_value( "EDID $EDID_nbr - Nbr of EDR samples" , $nbr_of_EDR_samples , "==" , $EDID_nbr_of_samples_exp );
    unless( $nbr_of_EDR_samples ) {
        S_w2rep( " - - - No further evaluation required - - - \n" , 'red' );
        return 1;
    }

    unless( ref $crash_all_times_aref eq 'ARRAY' ) {
        S_set_error( "UNEXPECTED ERROR : given parameter 'crash_times' isnt a ARRAY ref as expected - following a dump is printed" );
        S_w2rep( "BEGIN of DUMP\n".Dumper( $crash_all_times_aref )."\nEND_OF_DUMP\n" );
        return;
    }

    @used_crash_times = @$crash_all_times_aref;
    @used_crash_press_values = @$crash_press_data_aref;
    
    #
    # filling crash data when missing at beginning of evaluation range
    #
    if( $eval_start_time_ms < 0 ) {
        S_w2log( 3 , " Evaluation start at $eval_start_time_ms (ms) is less than 0 --> partly no crash data available -> must be filled with dummy values\n" );
        S_w2log( 5 , " Crash time have ".scalar @used_crash_times ." samples before filling\n" );
        S_w2log( 5 , " Crash data have ".scalar @used_crash_press_values ." samples before filling\n" );
        S_w2log( 5 , " Crash times must be filled backwards until $eval_start_time_ms ms \n" );
        
        my $first_available_crash_time = $used_crash_times[0];
        my $new_dummy_sample_time_ms = $first_available_crash_time;    # take the first timestamp
        while( $new_dummy_sample_time_ms >= $eval_start_time_ms )  {
            $new_dummy_sample_time_ms -= $tcpar_crash_sample_time_ms;     # reduce the times (becoming negative)
            unshift( @used_crash_times , $new_dummy_sample_time_ms );
            unshift( @used_crash_press_values , $Press_data_dummy_value );
        }        
        S_w2log( 5 , " Crash time have ".scalar @used_crash_times ." samples after filling\n" );
        S_w2log( 5 , " Crash data have ".scalar @used_crash_press_values ." samples after filling\n" );
    }

    #
    # filling crash data when missing at end of evaluation range
    #
    my $last_crash_time_ms = $used_crash_times[ $#used_crash_times ];
    if( $eval_end_time_ms > $last_crash_time_ms ) {
        S_w2log( 3 , " Evaluation end at $eval_end_time_ms (ms) is bigger than latest injected crash time ($last_crash_time_ms ms) --> partly no crash data available -> must be filled with dummy values\n" );
        S_w2log( 5 , " Crash time have ".scalar @used_crash_times ." samples before filling\n" );
        S_w2log( 5 , " Crash data have ".scalar @used_crash_press_values ." samples before filling\n" );
        S_w2log( 5 , " Crash times must be filled backwards until $eval_start_time_ms ms \n" );
        
        my $new_dummy_sample_time_ms = $last_crash_time_ms;    # take the first timestamp
        while( $new_dummy_sample_time_ms <= $eval_end_time_ms )  {
            $new_dummy_sample_time_ms += $tcpar_crash_sample_time_ms;     # reduce the times (becoming negative)
            push( @used_crash_times , $new_dummy_sample_time_ms );
            push( @used_crash_press_values , $Press_data_dummy_value );
#             S_w2log( 5, "add new crash acc sample : [$new_dummy_sample_time_ms ms] $Acc_data_dummy_value\n" );     
        }        
        S_w2log( 5 , " Crash time have ".scalar @used_crash_times ." samples after filling\n" );
        S_w2log( 5 , " Crash data have ".scalar @used_crash_press_values ." samples after filling\n" );
    }
    
    
    #
    # obtaining relevant crash data for EDR sample evaluation (in timing of EDR samples)
    #    
    
    my $next_EDR_sample_time_ms = $eval_start_time_ms;    
    my $crash_sample_nbr            = 0;
    my $EDR_sample_nr               = 0;
    my $EDR_pressure_calculation    = 0;

    #
    #  MAIN LOOP COLLECTING AND EVALUATING ALL SAMPLES -------------------------  
    #
    foreach my $crash_sample_ms ( @used_crash_times ) {
        $crash_sample_nbr++;        

#         S_w2log( 3, " Sample time $crash_sample_ms ms\n" ) if $eval_start_time_ms < 0;

        #
        # waiting when eval period is starting/ending
        #
        next if $crash_sample_ms < $eval_start_time_ms;   
        last if $crash_sample_ms > $eval_end_time_ms;


        my $crash_pressure_data_value   = $used_crash_press_values[$crash_sample_nbr-1];
        push( @EVAL_pressure_crash_data, $crash_pressure_data_value ); 
#         push( @EVAL_pressure_crash_times, abs $crash_sample_ms - abs $eval_start_time_ms );
        push( @EVAL_pressure_crash_times, $crash_sample_ms );

        #
        # waiting until next sample time
        #
        next if $crash_sample_ms < $next_EDR_sample_time_ms;   


        #
        # collecting sample times of EDR entries
        #
        push( @eval_EDR_sample_on_crash_timebase_ms, $next_EDR_sample_time_ms );
        $EDR_sample_nr++;

        my $min_pressure = sprintf ( "%.2f" , $crash_pressure_data_value - $eval_tolerance_abs ); 
        my $max_pressure = sprintf ( "%.2f" , $crash_pressure_data_value + $eval_tolerance_abs );
        push( @MIN_pressure_crash_data, $min_pressure );
        push( @MAX_pressure_crash_data, $max_pressure );
        
        #
        # here Pressure data evaluated 
        #
        if( $EDID_data_type =~ /pressure/i ) 
        {
            my $EDR_pressure_value = sprintf ( "%.2f" , $EDID_samples_rec_aref->[$EDR_sample_nr-1] );
            EVAL_evaluate_interval ( $EDID_abbr." delta-v [$EDR_sample_nr/$nbr_of_EDR_samples] at $crash_sample_ms ms" , $min_pressure , $max_pressure , $EDR_pressure_value );
            push( @EDR_pressure_samples , $EDR_pressure_value);
        }
            
        $next_EDR_sample_time_ms += $EDID_sample_time_ms;     # calculate time for next 2ms sample    
        last if $EDR_sample_nr == $EDID_nbr_of_samples_exp;    # from here no more evaluation -> jump out
    
    } # end of foreach loop over all crash samples


    #
    #  creating & storing graph of injected crash data (expectation) 
    #
    S_w2rep( " - - > Graph of injected crash pressure data [promille]\n" , 'indigo' );
    my $Press_data_hash = {
        'time'             => \@used_crash_times,
        $EDID_abbr.'_sensor__promille' => \@used_crash_press_values,
    };

    my $report_path = $main::REPORT_PATH."/";

    my $png_data_trace_file_name = $EDID_abbr.'_sensor_crash_'.time().'.png';
    my $unv_data_trace_file_name = $EDID_abbr.'_sensor_crash_'.time().'.txt.unv';

    S_create_graph( 
                    $Press_data_hash, 
                    $report_path.$png_data_trace_file_name, 
                    $EDID_abbr."_crash_data (T0 at $crash_time_T0_ms ms)",    # time scale start with start of simulation 
                    'white' 
                    );
    S_add_pic2html( 
                    "./".$png_data_trace_file_name, 
                    '', 
                    "./".$unv_data_trace_file_name, 
                    'TYPE="text/unv"' 
                    );
                    
    EVAL_importUNV( $report_path.$unv_data_trace_file_name );
 


    #
    #  creating & storing graph of injected crash pressure data (expectation) 
    #
    S_w2rep( " - - > Graph of injected crash pressure data [promille]\n" , 'indigo' );
    my $Pressure_data_hash = {
        'time'                         => \@EVAL_pressure_crash_times,
        $EDID_abbr.'_sensor__promille' => \@EVAL_pressure_crash_data,
    };

    my $report_path = $main::REPORT_PATH."/";

    my $png_pressure_data_trace_file_name = $EDID_abbr.'_sensor_short_'.time().'.png';
    my $unv_pressure_data_trace_file_name = $EDID_abbr.'_sensor_short_'.time().'.txt.unv';

    S_create_graph( 
                    $Pressure_data_hash, 
                    $report_path.$png_pressure_data_trace_file_name, 
                    $EDID_abbr."_pressure_crash_data (evaluation period $EDID_start_time_ms .. $EDID_end_time_ms with $EDID_sample_rate_Hz Hz)", 
                    'white' , 
#                     'interpolate_points'
                    );                    
    S_add_pic2html( 
                    "./".$png_pressure_data_trace_file_name, '', 
                    "./".$unv_pressure_data_trace_file_name, 'TYPE="text/unv"' 
                    );
                    
    EVAL_importUNV( $report_path.$unv_pressure_data_trace_file_name );

    #
    #  creating & storing graph of EDR storage data (measured) 
    #
    S_w2rep( " - - > Graph of stored EDR pressure data samples [promille]\n" , 'indigo' );
    my $Acc_data_hash = {
        'time'                      => \@eval_EDR_sample_on_crash_timebase_ms,
        $EDID_abbr.'_EDR__promille' => $EDID_samples_rec_aref,
    };

    my $report_path = $main::REPORT_PATH."/";

    my $png_EDR_data_trace_file_name = $EDID_abbr.'_EDR_'.time().'.png';
    my $unv_EDR_data_trace_file_name = $EDID_abbr.'_EDR_'.time().'.txt.unv';

    S_create_graph( 
                    $Acc_data_hash, 
                    $report_path.$png_EDR_data_trace_file_name, 
                    $EDID_abbr."_EDR_data (evaluation period $EDID_start_time_ms .. $EDID_end_time_ms with $EDID_sample_rate_Hz Hz)", 
                    'white' , 
#                         'interpolate_points' 
                    );                        
    S_add_pic2html( 
                    "./".$png_EDR_data_trace_file_name, '', 
                    "./".$unv_EDR_data_trace_file_name, 'TYPE="text/unv"' 
                    );
                    
    EVAL_importUNV( $report_path.$unv_EDR_data_trace_file_name );


    #
    #  creating & storing graph of EDR sample evaluation 
    #
    S_w2rep( " - - > Graph of EDR data samples with MIN/MAX expectation from pressure of crash data [promille]\n" , 'indigo' );
    my $Acc_pressure_rec_hash = {
        'time'                                   => \@eval_EDR_sample_on_crash_timebase_ms,
        $EDID_abbr.'_pressure_rec_EDR__promille' => $EDID_samples_rec_aref,
        $EDID_abbr.'_pressure_exp_MIN__promille' => \@MIN_pressure_crash_data,
        $EDID_abbr.'_pressure_exp_MAX__promille' => \@MAX_pressure_crash_data,
    };

    my $png_sample_pressure_eval_file_name = $EDID_abbr.'_EVAL_'.time().'.png';
    my $unv_sample_pressure_eval_file_name = $EDID_abbr.'_EVAL_'.time().'.txt.unv';

    S_create_graph(
                    $Acc_pressure_rec_hash, 
                    $report_path.$png_sample_pressure_eval_file_name,
                    "EDID $EDID_nbr : $EDID_descr pressure (evaluation period $EDID_start_time_ms .. $EDID_end_time_ms with $EDID_sample_rate_Hz Hz)", 
                    'white', 
#                     'interpolate_points'
                    );                        
    S_add_pic2html( 
                    "./".$png_sample_pressure_eval_file_name , '', 
                    "./".$unv_sample_pressure_eval_file_name, 'TYPE="text/unv"' 
                    );
                    
    EVAL_importUNV( $report_path.$unv_sample_pressure_eval_file_name );

    return 1;
}

1;

__END__
