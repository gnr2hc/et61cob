#### TEST CASE MODULE
package TC_EDID_Ignition;
#-> package name has to match file name ! case sensitive !

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
use INCLUDES_Project;
###-------------------------------
our $VERSION = q$Revision: 1.8 $;
our $HEADER = q$Header: EDID/TC_EDID_Ignition.pm 1.8 2014/02/20 19:28:39ICT ver6cob develop  $;
##################################

my $addpath;

#### INCLUDE ENGINE MODULES ####
use LIFT_general;   # this is always required
use LIFT_evaluation;
use LIFT_PD;
use LIFT_CD;
use POSIX;
##################################

our $PURPOSE = "to evaluate the EDID value reported in the EDR for Ignition cycle, Event Counter, Operating Time";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

#-> update documentation that somebody else can use the test without asking you
#-> delete parameter section if no paramteres are used
#-> note that POD documentation needs entirely empty lines before and after keywords (e.g. =head1, =cut ...) 

=head1 TESTCASE MODULE

TC_EDID_Ignition  $Revision: 1.8 $

=head1 PURPOSE

to evaluate the EDID value reported in the EDR for Ignition cycle, Event Counter, Operating Time

=head1 TESTCASE DESCRIPTION

[initialisation]
StandardPrepNoFault


[stimulation & measurement]
1. Note Down the value of variable for Ignition_Cycle, OperatingTime through PD

2. Inject <CrashFile>

3. Read EDID_Ignition_Cycle, EDID_Ignition_Cycle_Download, EDID_OperatingTime , EDID_EventCounter through CD in EDR1

4. Reset ECU.

5. Read EDID_Ignition_Cycle, EDID_Ignition_Cycle_Download, EDID_OperatingTime , EDID_EventCounter through CD in EDR1

6. Note the value of variable Ignition_Cycle, OperatingTime, through PD and Inject <CrashFile>

7. Read EDID_Ignition_Cycle, EDID_Ignition_Cycle_Download, EDID_OperatingTime , EDID_EventCounter through CD in EDR2


[evaluation]
1.

2.

3. Ignition cycle crash/download, Operating time reported in EDIDs is same as that read in step 1. Event counter is 1

4.

5. Ignition cycle crash, Operating time and event counter reported in EDIDs is same as that observed in step 2. Ignition cycle download is one excess of the value read in step 2

6.

7. Ignition cycle crash/download, Operating time reported in EDIDs is same as that read in step 6. Event counter is 2


[finalisation]
Clear crash recorder


=head1 PARAMETER

=head2 PARAMETER NAMES

    none

=head2 PARAMETER EXAMPLES

    none

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#-> define variables here which sall be used across subroutines
#-> test case parameters shall start with tcpar_
my ($value_PonCounter1,$value_PonTime1,$value_EventCounter1,$EDIDdata_aref1,	
	$value_PonCounter2,$value_PonTime2,$value_EventCounter2,$EDIDdata_aref2,
	$value_PonCounter3,$value_PonTime3,$value_EventCounter3,$EDIDdata_aref3,    
    $EDID_IgnitionCycleCrash, 
    $EDID_IgnitionCycleDownload, 
	$EDID_OperatingTime, 
 	$EDID_EventCounter,
	$var_IgnitionCycle,
	$var_OperatingTime,
    $projectpar_crashfile,$Ignition1,$Ignition2,$Ignition3,
	$EventCounter1,$EventCounter2,$EventCounter3,
    $IgnitionDownload1,$IgnitionDownload2,$IgnitionDownload3,
    $OperatingTime1,$OperatingTime2,$OperatingTime3
    );

sub TC_set_parameters {
	
  	$projectpar_crashfile = S_read_project_parameter ( 'CrashFile' );    
	
  	$EDID_IgnitionCycleCrash = EDR_fetchEDIDbyLabel('IgnitionCycleCrash');
  	$EDID_IgnitionCycleDownload = EDR_fetchEDIDbyLabel('IgnitionCycleDownload');
  	$EDID_OperatingTime = EDR_fetchEDIDbyLabel('OperatingTime');
  	$EDID_EventCounter = EDR_fetchEDIDbyLabel('EventCounter');

  	$var_IgnitionCycle = 'V_POnCounter_U32E';
  	$var_OperatingTime  = 'V_PoOnTime_U32R';

	return 1;
}


#### INITIALIZE TC #####
sub TC_initialization {

	PD_ClearCrashRecorder();
	GEN_StandardPrepNoFault();
    
  	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {
 
   	S_w2rep("Step1:  Note Down the value of variable Ignition_Cycle, OperatingTime through PD", 'blue');	
   	$value_PonCounter1 = PD_ReadMemoryByName("$var_IgnitionCycle");  	
   	$value_PonTime1 = PD_ReadMemoryByName("$var_OperatingTime");
   
	S_w2rep("Step2: Inject Crash: $projectpar_crashfile", 'blue');
	EDR_InjectCrash ($projectpar_crashfile, 10000);
   
	S_w2rep("Step3: Read EDID_Ignition_Cycle, EDID_Ignition_Cycle_Download, EDID_OperatingTime, EDID_EventCounter through CD in EDR1", 'blue'); 
	$EDIDdata_aref1 = EDR_CD_ReadEDR(0x01); 	
	my $EDIDstruct1 = CD_parseEDID($EDIDdata_aref1, 'generic'); 
	  	   
   	$Ignition1 = CD_getEDIDdata($EDIDstruct1,$EDID_IgnitionCycleCrash, 'generic'); 
   	$IgnitionDownload1 = CD_getEDIDdata($EDIDstruct1,$EDID_IgnitionCycleDownload, 'generic');
   	$EventCounter1 = CD_getEDIDdata($EDIDstruct1,$EDID_EventCounter, 'generic');
   	$OperatingTime1 = CD_getEDIDdata($EDIDstruct1,$EDID_OperatingTime, 'generic');
 
	S_w2rep("Step4:  Reset ECU", 'blue');    
	GEN_Power_on_Reset();
	
	S_w2rep("Step5: Read EDID_Ignition_Cycle, EDID_Ignition_Cycle_Download, EDID_OperatingTime, EDID_EventCounter through CD in EDR1 after ECU Reset", 'blue');
   	$EDIDdata_aref2 = EDR_CD_ReadEDR(0x01); 	
	my $EDIDstruct2 = CD_parseEDID($EDIDdata_aref2, 'generic'); 
	  	   
   	$Ignition2 = CD_getEDIDdata($EDIDstruct2,$EDID_IgnitionCycleCrash, 'generic'); 
   	$IgnitionDownload2 = CD_getEDIDdata($EDIDstruct2,$EDID_IgnitionCycleDownload, 'generic');
   	$EventCounter2 = CD_getEDIDdata($EDIDstruct2,$EDID_EventCounter, 'generic');
   	$OperatingTime2 = CD_getEDIDdata($EDIDstruct2,$EDID_OperatingTime, 'generic');

	S_w2rep("Step6:  Note Down the value of variable OperatingTime , ignition_Cycle and Inject crash", 'blue');     
   	$value_PonCounter2 = PD_ReadMemoryByName("$var_IgnitionCycle");  	
   	$value_PonTime2 = PD_ReadMemoryByName("$var_OperatingTime");
   	
   	EDR_InjectCrash ($projectpar_crashfile, 10000);
      
	S_w2rep("Step7: Read EDID_Ignition_Cycle, EDID_Ignition_Cycle_Download, EDID_VIN, EDID_OperatingTime, EDID_EventCounter through CD in EDR2", 'blue');
	$EDIDdata_aref3 = EDR_CD_ReadEDR(0x01); 	
	my $EDIDstruct3 = CD_parseEDID($EDIDdata_aref3, 'generic'); 
	  	   
   	$Ignition3 = CD_getEDIDdata($EDIDstruct3,$EDID_IgnitionCycleCrash, 'generic'); 
   	$IgnitionDownload3 = CD_getEDIDdata($EDIDstruct3,$EDID_IgnitionCycleDownload, 'generic');
   	$EventCounter3 = CD_getEDIDdata($EDIDstruct3,$EDID_EventCounter, 'generic');
   	$OperatingTime3 = CD_getEDIDdata($EDIDstruct3,$EDID_OperatingTime, 'generic');

 	return 1;
}



#### EVALUATE TC #####
sub TC_evaluation {
	
	S_w2rep("Step3 evaluation: Ignition cycle crash/download, Operating time reported in EDIDs is same as that read in step 1. Event counter is 1","blue");	
	EVAL_evaluate_value ("Ignition Cycle Crash", S_aref2hex($Ignition1), '==', S_aref2hex($value_PonCounter1));
	EVAL_evaluate_value ("Ignition Cycle Download", S_aref2hex($IgnitionDownload1), '==', S_aref2hex($value_PonCounter1));
	my $operatime1_observed = floor (S_0x2dec(S_aref2hex($value_PonTime1))/60); #convert to min
	EVAL_evaluate_value ("Operating Time", S_aref2hex($OperatingTime1), '==', $operatime1_observed, 10); #10 % tolerance
	EVAL_evaluate_value ("Event Counter", S_aref2hex($EventCounter1), '==', 1); #first event
	
	S_w2rep("Step5 evaluation: Ignition cycle crash, Operating time and event counter reported in EDIDs is same as that observed in step 2. Ignition cycle download is one excess of the value read in step 2","blue");	
	EVAL_evaluate_value ("Ignition Cycle Crash", S_aref2hex($Ignition2), '==', S_aref2hex($value_PonCounter1));
	my $IgnitionCycleAfterReset = S_aref2hex($IgnitionDownload2) + 1;
	EVAL_evaluate_value ("Ignition Cycle Download", $IgnitionCycleAfterReset, '==', S_aref2hex($value_PonCounter1));
	EVAL_evaluate_value ("Operating Time", S_aref2hex($OperatingTime2), '==', $operatime1_observed, 10); #10 % tolerance
	EVAL_evaluate_value ("Event Counter", S_aref2hex($EventCounter2), '==', 1); #first event
	
	S_w2rep("Step7 evaluation: Ignition cycle crash/download, Operating time reported in EDIDs is same as that read in step 6. Event counter is 2","blue");	
	EVAL_evaluate_value ("Ignition Cycle Crash", S_aref2hex($Ignition3), '==', S_aref2hex($value_PonCounter2));
	EVAL_evaluate_value ("Ignition Cycle Download", S_aref2hex($IgnitionDownload3), '==', S_aref2hex($value_PonCounter2));
	my $operatime2_observed = floor (S_0x2dec(S_aref2hex($value_PonTime2))/60); #convert to min
	EVAL_evaluate_value ("Operating Time", S_aref2hex($OperatingTime3), '==', $operatime2_observed, 10); #10 % tolerance
	EVAL_evaluate_value ("Event Counter", S_aref2hex($EventCounter3), '==', 2); #second event
    	
	return 1;
}


#### TC FINALIZATION #####
sub TC_finalization {

	PD_ClearCrashRecorder();
	return 1;
}


1;

__END__
