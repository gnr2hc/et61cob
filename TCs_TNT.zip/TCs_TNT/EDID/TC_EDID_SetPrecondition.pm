#### TEST CASE MODULE
package TC_EDID_SetPrecondition;
#-> package name has to match file name ! case sensitive !

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
###-------------------------------
our $VERSION = q$Revision: 1.18 $;
our $HEADER = q$Header: EDID/TC_EDID_SetPrecondition.pm 1.18 2018/01/19 00:14:25ICT Okrusch Thomas (CC-PS/EPS2) (OUT2SI) develop  $;
##################################

#### INCLUDE ENGINE MODULES ####
use LIFT_general;   # this is always required
use LIFT_evaluation;
use LIFT_labcar;
use LIFT_PD;
use INCLUDES_Project;
##################################

our $PURPOSE = "To Set the Precondition before crash";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

#-> update documentation that somebody else can use the test without asking you
#-> delete parameter section if no paramteres are used
#-> note that POD documentation needs entirely empty lines before and after keywords (e.g. =head1, =cut ...) 

=head1 TESTCASE MODULE

TC_EDID_SetPreconditions  $Revision: 1.18 $

default state is faultfree ECU powered ON

=head1 PURPOSE

to set the preconditions before crash.(ex: env data, EDP data)

=head1 TESTCASE DESCRIPTION
    
[initialisation]
    StandardPrepNoFault

[stimulation & measurement]
	1. Set ECU voltage to <ECUVoltage> 
	2. Set the values of devices/CAN signals as mentioned in the LIFT Default parameter Section.
	3. Inject <CrashFile> and read the EDR data

[evaluation]
	3. check if crash data is stored in EDR

[finalisation]
     Reset all the Device states    

=head1 PARAMETERS
		
=head2 PARAMETER NAMES
  # Switch States
		BeltLockFrontDriver 
		BeltLockFrontPassenger
		SeatTrackPositionSwitchDriver
		SeatTrackPositionSwitchPassenger
		PassengerAirbagDeactivationSwitch 
		BeltLock2ndRowDriver  
		BeltLock2ndRowCenter  
		BeltLock2ndRowPassenger  
		BeltLock3rdRowDriver  
		BeltLock3rdRowCenter 
		BeltLock3rdRowPassenger  

	# CAN signals
		VehicleSpeed
		AcceleratorPedal
		EngineRPM
		SteeringInput
		ServiceBrakeActivation
		ABSstatus
		StabilityControl
		VIN
		OccupantSizeDriver
		OccupantSizeFrontPassenger 
		OccupantPositionDriver
		OccupantPositionFrontPassenger  

	# Event Timing CAN signals
		AccidentDateYear
		AccidentDateMonth
		AccidentDateDay
		AccidentDateHour
		AccidentDateMinute
		AccidentDateSecond
		VehicleMileage

	'purpose' => 'To validate Data Elements recorded in EDR'
	'ECUVoltage' => Voltage to be set before injecting crash
	'CrashFile' => crash file to be injected, this present in project parameter.

=head2 PARAMETER EXAMPLES

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my ($tcpar_ECUVoltage,		    
	$tcpar_crashfile,
	@devices,
	@COMSignals,
    $response_aref,
    %deviceName,
    %deviceType, 
    %deviceState, 
    %COMSignal_State,
    %COMSignal_Value,    
	$matchedkeys_aref,
	$SearchHashRef
	);

sub TC_set_parameters {
	
	$tcpar_ECUVoltage = GEN_Read_mandatory_testcase_parameter('ECUVoltage');
    $tcpar_crashfile = S_read_project_parameter ( 'CrashFile' );    
    	unless( defined $tcpar_crashfile) {
	    S_set_error ("Missing mandatory parameter $tcpar_crashfile \n",110);
	}
	
	our $PURPOSE = "To set the preconditions before a $tcpar_crashfile crash";	
	
	@devices = ('BeltLockFrontDriver',  
        		 'BeltLockFrontPassenger', 
       		 	 'SeatTrackPositionSwitchDriver',  
           		 'SeatTrackPositionSwitchPassenger',   
        		 'PassengerAirbagDeactivationSwitch',   
        		 'BeltLock2ndRowDriver',  
        		 'BeltLock2ndRowCenter',   
        		 'BeltLock2ndRowPassenger', 
        		 'BeltLock3rdRowDriver',  
        		 'BeltLock3rdRowCenter', 
        		 'BeltLock3rdRowPassenger');

    S_w2rep("Reading Test case parameters related to devices", "purple"); 	    
    #Read Each of the Device TestCase parameter 
    foreach my $device(@devices){           
		$deviceState{$device} = S_read_testcase_parameter($device);  
		S_w2rep("$device state : $deviceState{$device}", "purple");  
    }  
                                       
    @COMSignals = ('VehicleSpeed',  
            'AcceleratorPedal', 
            'EngineRPM',  
            'SteeringInput',   
            'ServiceBrakeActivation',
            'ABSstatus',
            'StabilityControl',
            #'OccupantSizeDriver',
            #'OccupantSizeFrontPassenger',
            #'OccupantPositionDriver',
            #'OccupantPositionFrontPassenger',
            #'VIN',
            'AccidentDateYear',
            'AccidentDateMonth',
            'AccidentDateDay',
            'AccidentDateHour',
            'AccidentDateMinute',
            'AccidentDateSecond',
            'VehicleMileage',
	); 
	
	S_w2rep("Reading Test case parameters related to CAN signals", "purple");
	foreach my $COM_signal(@COMSignals){
		$COMSignal_State{$COM_signal} = S_read_testcase_parameter("$COM_signal");  
		S_w2rep("$COM_signal state : $COMSignal_State{$COM_signal}", "purple");  		
	} 

	$main::ProjectDefaults->{'TEMP'}{'Respone_aref'} = '';	#CLEAR temp data initially
    
	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {
	
	PD_ClearCrashRecorder();
	GEN_StandardPrepNoFault();
    
	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {
	
 	S_w2rep("Step1: Set ECU voltage to $tcpar_ECUVoltage", 'blue');	
	LC_SetVoltage($tcpar_ECUVoltage);

	S_w2rep("Step2: Set the values of devices and CAN signals, as mentioned in the LIFT Default parameter Section.", 'blue');	
	# executing in loop for all devices 
	foreach my $device(@devices) {  		
	    S_w2rep("Device: $device","purple");    
	    my $foundDevice = DEVICE_fetchDevicebyLabel($device);
	        
	    if (defined $foundDevice){
	    	S_w2rep("Set Device $foundDevice to state $deviceState{$device}","brown");
	    	DEVICE_setDeviceState($foundDevice,$deviceState{$device});
	    }
	    else{
	    	S_set_error("Device corresponding to label $device is not found in device mapping file and state is not set. Is it not supported for this project?", 0); #warning!
	    }           
	}   
   	
	# executing in loop for all CAN signals              
	foreach my $COM_signal(@COMSignals) { 
		S_w2rep("COM signal: $COM_signal", "purple");
		
		if (defined $COMSignal_State{$COM_signal}){
			my $foundSignal = COM_fetchSignalbyLabel($COM_signal);

			if (defined $foundSignal){
				S_w2rep("Set signal $foundSignal to state $COMSignal_State{$COM_signal}","brown");
				my $physicalValue = COM_setSignalState ($foundSignal,$COMSignal_State{$COM_signal});
				$main::ProjectDefaults->{'TEMP'}{$COM_signal}{'RandomInRangeValue'} = $physicalValue if($COMSignal_State{$COM_signal} eq 'RandomInRangeValue'); #store temporarily - to be accessed in ValidateEDID.pm file
			}
			else{
				S_set_error("Signal corresponding to label $COM_signal is not found in CAN/FR mapping file and state is not set. Is it not supported for this project?", 0); #warning!
			}
		}
		else{
			S_w2rep("State of $COM_signal signal is not set for this case. Reasons may be: \n 1. This is not required for this case\n 2. This is required for this case but is not defined in the TC par file","brown");
		}	
	}
			
  	S_w2rep("Wait 6 sec to ensure update COM signals are sent on the bus");  
  	S_wait_ms ( '6000' ); 
  	
  	S_w2rep("Step3: Inject Crash", 'blue');
  	EDR_InjectCrash ($tcpar_crashfile, 10000);

   	$response_aref = EDR_CD_ReadEDR(1); #read 1st EDR entry (most recent)
  	$main::ProjectDefaults->{'TEMP'}{'Respone_aref'} = $response_aref;	#to be accessed in ValidateEDID.pm file

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {
		
    EDR_CD_EVAL_checkStorageStatus($response_aref,'Stored');	#Check EDR Storage Status
    	
	return 1;
}

#### TC FINALIZATION #####
sub TC_finalization {

	S_w2rep("Set back ECU voltage to normal voltage", 'blue');	
	LC_SetVoltage(13.5);
	
	S_w2rep("Reset all device states","purple");
	foreach my $device(@devices) {  		          		    
	    my $foundDevice = DEVICE_fetchDevicebyLabel ($device);

	    if (defined $foundDevice){
	    	S_w2rep("reset Device state $deviceState{$device} for $foundDevice","brown");
	    	DEVICE_resetDeviceState($foundDevice,$deviceState{$device});  
	    }
	    else{
	    	S_w2rep("Device corresponding to label $device is not found in device mapping file. State is not set"); 
	    }     
	}
	
	S_w2rep("Start sending all stopped COM signals","purple");
	foreach my $COM_signal(@COMSignals) { 
		if ($COMSignal_State{$COM_signal} eq 'SignalNotAvailable'){
			my $foundSignal = COM_fetchSignalbyLabel($COM_signal);
			if (defined $foundSignal){
		    	S_w2rep("Start sending signal $COM_signal again","brown");
				COM_setSignalState ($foundSignal,'SignalAvailable');
		    }
		    else{
		    	S_set_error("Signal corresponding to label $COM_signal is not found in CAN/FR mapping file and state is not set. No action taken", 0); #warning!
		    }
	    }
	}
	
	return 1;

}

1;

__END__
