EDR4AD platform test cases
testcases are Moved to TCs_Project of Project E4A_Platform