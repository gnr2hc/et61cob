#### TEST CASE MODULE
package TC_EDR_Functional_OverWritingNonInflatableDeploymentCrash;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------
our $VERSION = q$Revision: 1.5 $;
our $HEADER = q$Header: EDR/TC_EDR_Functional_OverWritingNonInflatableDeploymentCrash.pm 1.5 2013/11/28 13:58:34ICT ver6cob develop  $;
################################## 

#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general; 
use LIFT_evaluation;
use LIFT_PD;
use INCLUDES_Project;
##################################

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_Functional_OverWritingNonInflatableDeploymentCrash  $Revision: 1.5 $

requires MLC,PD,CANoe,POWER and evaluation (setup already done in IC)

default state is faultfree ECU powered ON

=head1 PURPOSE

To validate the Overwrite Strategy for InflatableDeployment Crash

=head1 TESTCASE DESCRIPTION 

    [initialisation]
    StandardPreparation

    [stimulation & measurement]
    1. Inject <Type> NonInflatableDeployment crashes (where the number of injected crashes are equal to the number of crash telegrams available in EEPROM)
	2. Read all Crash Telegrams through PD and CD
	3. Inject a <DifferentType1> InflatableDeployment crash
	4. Read all Crash Telegrams through PD and CD
	5. Inject a <DifferentType2> NonInflatableDeployment crash
	6. Read all Crash Telegrams through PD and CD
	7. Inject a <DifferentType3> NoDeployment crash
	8. Read all Crash Telegrams through PD and CD

    [evaluation]
	1.
	2.  Crashes are stored in all telegrams
	3.
	4.  If project has the configuration such that Inflatable crashes can overwrite NonInflatable crashes then,
		Oldest NonInflatable crash is overwritten by the crash created in step 3
		else, 
		No crash telegram is overwritten. All telegrams have the same content as in step 2
	5.
	6.  If project has the configuration such that NonInflatable crashes can overwrite other NonInflatable crashes then,
		Oldest NonInflatable crash is overwritten by the crash created in step 5
		else, 
		No crash telegram is overwritten. All telegrams have the same content as in step 4
	7.
	8.  No crash telegram is overwritten. All telegrams have the same content as in step 6

    [finalisation]
	Clear Crash Telegram and Fault memory
    ECU off

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

    purpose                  --> Purpose of the test case
    Type				  	 --> Type of NonInflatableDeployment crash to be injected in all CTs
    DifferentType1			 --> Type of InflatableDeployment crash to be injected
    DifferentType2			 --> Type of next NonInflatableDeployment crash to be injected
    DifferentType3			 --> Type of NoDeployment crash to be injected
  	

=head2 PARAMETER EXAMPLES
	[TC_EDR_Functional_OverWritingNonInflatableDeploymentCrash.Front]
	DifferentType1 = 'SideDriver'
	DifferentType2 = 'Rear'
	DifferentType3 = 'Front'
	# From here on: applicable Lift Default Parameters
	purpose	 = 'to validate the Overwrite Strategy for InflatableDeployment Crash'
	Type =  'Front'

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#Hashes to read the parameters from .par file  
my (%defaultpar_hash,
	%TCpar_hash);


#List of parameters in .par file
my @defaultpar_list 			= ('purpose',
					   			   'Type');
my @TCpar_list 					= ('DifferentType1',
								   'DifferentType2',
								   'DifferentType3');	   

				                  
#other TC specific constants/parameters from other files


#variables used in the test case
my ($UniqueCrashNumber,
    $NumberOfCrashTelegrams,
    $Inflatable_Overwrites_NonInflatable,
    $NonInflatable_Overwrites_NonInflatable);
my $CrashInjectionStatus;
my (@UniqueCrashNumber_Initial,
	@EDRresponse_aref_Empty,   
	@EDRresponse_aref_Initial,
	@UniqueCrashNumber_AfterInflatable,   
	@EDRresponse_aref_AfterInflatable,
	@UniqueCrashNumber_AfterNonInflatable,   
	@EDRresponse_aref_AfterNonInflatable,
	@UniqueCrashNumber_AfterNoDeployment,   
	@EDRresponse_aref_AfterNoDeployment);
    
our $PURPOSE;


sub TC_set_parameters {
	
	#read each default parameter from the .par file
	foreach my $defaultpar(@defaultpar_list){
		$defaultpar_hash{$defaultpar} =  GEN_Read_mandatory_testcase_parameter($defaultpar);
	}
	
	#read each test case parameter from the .par file
	foreach my $TCpar(@TCpar_list){
		$TCpar_hash{$TCpar} =  GEN_Read_mandatory_testcase_parameter($TCpar);
	}
	
	$PURPOSE = "$defaultpar_hash{'purpose'}";	
	
	#read other TC specific constants/parameters from other files
	$UniqueCrashNumber = 'S_Header_XXE.A_UniqueCrashNbr_U16X';
	$NumberOfCrashTelegrams = EDR_fetchNumberOfCrashTelegrams();
	$Inflatable_Overwrites_NonInflatable = EDR_fetchOverwriteStrategyBehaviour('Inflatable_Overwrites_NonInflatable');
	$NonInflatable_Overwrites_NonInflatable = EDR_fetchOverwriteStrategyBehaviour('NonInflatable_Overwrites_NonInflatable');
    
	return 1;

}

#### INITIALIZE TC #####
sub TC_initialization {

    S_w2rep('StandardPreparation', 'blue'); 
    PD_ClearCrashRecorder();
    GEN_StandardPrepNoFault();
    
    #check that all CTs are empty
    foreach my $CT(1..$NumberOfCrashTelegrams){
    	S_w2rep("precondition: check that EDR$CT is empty", 'orange');
    	$EDRresponse_aref_Empty[$CT] = EDR_CD_ReadEDR($CT);
    	EDR_CD_EVAL_checkStorageStatus ($EDRresponse_aref_Empty[$CT],'NotStored');
    }
        
  	return 1;
}


### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {
	
	my $index;
	  
    S_w2rep("Step1: Inject $defaultpar_hash{'Type'} NonInflatableDeployment crashes (where the number of injected crashes are equal to the number of crash telegrams available in EEPROM)", 'blue');
    foreach(1..$NumberOfCrashTelegrams){
    	$CrashInjectionStatus = EDR_InjectCrash("$defaultpar_hash{'Type'}NonInflatableDeployment" , 5000);
    }
    
    unless (defined $CrashInjectionStatus and $CrashInjectionStatus == 1){
    	S_set_error("Crash is not injected successfully. Not proceeding!", 0);
    	$PURPOSE = "Crash not injected successfully";
		return 0;
    }
    	   	
   	S_w2rep("Step2: Read CrashRecorder through PD and CD", 'blue'); 
   	foreach my $CT(1..$NumberOfCrashTelegrams){
   		#read Unique crash num in header - PD
   		S_w2rep("step2: read Unique crash number in header using PD - for EDR$CT", 'orange');
   		if(defined $UniqueCrashNumber and length $UniqueCrashNumber){
   			$index = $CT-1;
    		$UniqueCrashNumber_Initial[$CT] = PD_ReadMemoryByName( "$UniqueCrashNumber($index)" ); #for each CT	
    	}
    	#read stored EDR data through CD
    	S_w2rep("step2: read stored EDR data through CD - for EDR$CT", 'orange');
    	$EDRresponse_aref_Initial[$CT] = EDR_CD_ReadEDR($CT); 
    }
 
	S_w2rep("Step3: Inject a $TCpar_hash{'DifferentType1'} InflatableDeployment crash", 'blue');
    EDR_InjectCrash("$TCpar_hash{'DifferentType1'}InflatableDeployment" , 5000);
    
    S_w2rep("Step4: Read all Crash Telegrams through PD and CD", 'blue'); 
   	foreach my $CT(1..$NumberOfCrashTelegrams){
   		#read Unique crash num in header - PD
   		S_w2rep("step4: read Unique crash number in header using PD - for EDR$CT", 'orange');
   		if(defined $UniqueCrashNumber and length $UniqueCrashNumber){
   			$index = $CT-1;
    		$UniqueCrashNumber_AfterInflatable[$CT] = PD_ReadMemoryByName( "$UniqueCrashNumber($index)" ); #for each CT
    	}
    	#read stored EDR data through CD
    	S_w2rep("step4: read stored EDR data through CD - for EDR$CT", 'orange');
    	$EDRresponse_aref_AfterInflatable[$CT] = EDR_CD_ReadEDR($CT); 
    }
    
    
    S_w2rep("Step5: Inject a $TCpar_hash{'DifferentType2'} NonInflatableDeployment crash", 'blue');
    EDR_InjectCrash("$TCpar_hash{'DifferentType2'}NonInflatableDeployment" , 5000);
    
    S_w2rep("Step6: Read all Crash Telegrams through PD and CD", 'blue'); 
   	foreach my $CT(1..$NumberOfCrashTelegrams){
   		#read Unique crash num in header - PD
   		S_w2rep("step6: read Unique crash number in header using PD - for EDR$CT", 'orange');
   		if(defined $UniqueCrashNumber and length $UniqueCrashNumber){
   			$index = $CT-1;
    		$UniqueCrashNumber_AfterNonInflatable[$CT] = PD_ReadMemoryByName( "$UniqueCrashNumber($index)" ); #for each CT
    	}
    	#read stored EDR data through CD
    	S_w2rep("step6: read stored EDR data through CD - for EDR$CT", 'orange');
    	$EDRresponse_aref_AfterNonInflatable[$CT] = EDR_CD_ReadEDR($CT); 
    }
    
    S_w2rep("Step7: Inject a $TCpar_hash{'DifferentType3'} NoDeployment crash", 'blue');
    EDR_InjectCrash("$TCpar_hash{'DifferentType3'}NoDeployment" , 5000);
    
    S_w2rep("Step8: Read all Crash Telegrams through PD and CD", 'blue'); 
   	foreach my $CT(1..$NumberOfCrashTelegrams){
   		#read Unique crash num in header - PD
   		S_w2rep("step6: read Unique crash number in header using PD - for EDR$CT", 'orange');
   		if(defined $UniqueCrashNumber and length $UniqueCrashNumber){
   			$index = $CT-1;
    		$UniqueCrashNumber_AfterNoDeployment[$CT] = PD_ReadMemoryByName( "$UniqueCrashNumber($index)" ); #for each CT
    	}
    	#read stored EDR data through CD
    	S_w2rep("step8: read stored EDR data through CD - for EDR$CT", 'orange');
    	$EDRresponse_aref_AfterNoDeployment[$CT] = EDR_CD_ReadEDR($CT); 
    }
	return 1;
	
}


#### EVALUATE TC #####
sub TC_evaluation {
	
	my ($temp_aref1,$temp_aref2);
	#fetch the length of checksum and signature EDIDs and remove these bytes from the response (to compare the EDR entries without these data elements)
	my $checksumLength = EDR_fetchEDIDDataLength (1022); #EDID1022 - checksum
	my $signatureLength = EDR_fetchEDIDDataLength (1023); #EDID1022 - signature
	my $removableBytesNumber = $checksumLength + $signatureLength + 4; #(2 bytes for checksum EDID byte 03 FE + 2 bytes for signature EDID byte 03 FF)
	
	S_w2rep("Step2: Crashes are stored in all telegrams", 'blue'); 
	#foreach my $CT(1..$NumberOfCrashTelegrams){
	#	EDR_CD_EVAL_checkStorageStatus ($EDRresponse_aref_Initial[$CT],'Stored');
	#}	
		
	S_w2rep("Step4: If project has the configuration such that Inflatable crashes can overwrite NonInflatable crashes then, Oldest NonInflatable crash is overwritten by the crash created in step 3 else, No crash telegram is overwritten. All telegrams have the same content as in step 2", 'blue');				
	if($Inflatable_Overwrites_NonInflatable eq 'yes'){
		foreach my $CT(1..$NumberOfCrashTelegrams){ #only oldest CT should be overwritten, other CTs should be unchanged
			#PD check
			S_w2rep("step4: only oldest CT should be overwritten, other CTs should be unchanged - check EDR$CT using PD", 'orange');
			if($CT == '1'){
				#oldest CT for PD is 1st CT which is overwritten
				GEN_EVAL_CompareNumArrays ($UniqueCrashNumber_Initial[$CT], $UniqueCrashNumber_AfterInflatable[$CT], 'NotEqual'); 
			} 
			else{
				#other CTs are not overwritten
				GEN_EVAL_CompareNumArrays ($UniqueCrashNumber_Initial[$CT], $UniqueCrashNumber_AfterInflatable[$CT], 'Equal'); 
			}   		
			#CD check			
			S_w2rep("step4: only oldest CT should be overwritten, other CTs should be unchanged - check EDR$CT using CD", 'orange');
			if($CT < $NumberOfCrashTelegrams){	
				$temp_aref1 = $EDRresponse_aref_Initial[$CT];
				my $index = $CT + 1;
				$temp_aref2 = $EDRresponse_aref_AfterInflatable[$index];					
				if(defined @$temp_aref1[0] and defined @$temp_aref2[0]){
					foreach (1..5){ 	#remove the positive response bytes and header (since this may change after each crash)
						shift(@$temp_aref1); 
						shift(@$temp_aref2); 
					}
					
					#remove the checksum and signature bytes (since this may change after each crash)
					my $offset = scalar (@$temp_aref1) - $removableBytesNumber;
					splice @$temp_aref1, $offset ;
					splice @$temp_aref2, $offset ;	
				}
				GEN_EVAL_CompareNumArrays ($temp_aref1, $temp_aref2, 'Equal');
			}
			elsif($CT == $NumberOfCrashTelegrams){
				$temp_aref1 = $EDRresponse_aref_Initial[$CT];
				$temp_aref2 = $EDRresponse_aref_AfterInflatable[$CT];
				if(defined @$temp_aref1[0] and defined @$temp_aref2[0]){
					foreach (1..5){ 	#remove the positive response bytes and header (since this may change after each crash)
						shift(@$temp_aref1); 
						shift(@$temp_aref2); 
					}
					
					#remove the checksum and signature bytes (since this may change after each crash)
					my $offset = scalar (@$temp_aref1) - $removableBytesNumber;
					splice @$temp_aref1, $offset ;
					splice @$temp_aref2, $offset ;	
				}
				GEN_EVAL_CompareNumArrays ($EDRresponse_aref_Initial[$CT], $EDRresponse_aref_AfterInflatable[$CT], 'NotEqual'); 
			}
		}
		
		S_w2rep("Check that $TCpar_hash{'DifferentType1'} InflatableDeployment crash is stored in the most recent EDR entry", 'red');
		my ($response_aref,$EDIDstruct);
		$response_aref = $EDRresponse_aref_AfterInflatable[1]; #latest EDR entry
		my @hex_resp=(@$response_aref);
    	foreach (@hex_resp){$_ = "0x".sprintf("%02X",$_);
        print FIL $_;}       
   		$EDIDstruct = CD_parseEDID(\@hex_resp );
   		S_w2rep("Verdict is set to INCONC as this should be verified manually", 'red');
		S_set_verdict ( 'VERDICT_INCONC' );
		
	}
	elsif($Inflatable_Overwrites_NonInflatable eq 'no'){
		foreach my $CT(1..$NumberOfCrashTelegrams){
			#PD check
			S_w2rep("step4: CTs should be unchanged - check EDR$CT using PD", 'orange');
			GEN_EVAL_CompareNumArrays ($UniqueCrashNumber_Initial[$CT], $UniqueCrashNumber_AfterInflatable[$CT], 'Equal');    		
			#CD check	
			$temp_aref1 = $EDRresponse_aref_Initial[$CT];
			$temp_aref2 = $EDRresponse_aref_AfterInflatable[$CT];		
			if(defined @$temp_aref1[0] and defined @$temp_aref2[0]){
					foreach (1..5){ 	#remove the positive response bytes and header (since this may change after each crash)
						shift(@$temp_aref1); 
						shift(@$temp_aref2); 
					}
					
					#remove the checksum and signature bytes (since this may change after each crash)
					my $offset = scalar (@$temp_aref1) - $removableBytesNumber;
					splice @$temp_aref1, $offset ;
					splice @$temp_aref2, $offset ;	
				}
			S_w2rep("step4: CTs should be unchanged - check EDR$CT using CD", 'orange');
			GEN_EVAL_CompareNumArrays ($temp_aref1, $temp_aref2, 'Equal');
		}
	}
	
	S_w2rep("Step6: If project has the configuration such that NonInflatable crashes can overwrite other NonInflatable crashes then, Oldest NonInflatable crash is overwritten by the crash created in step 5 else, No crash telegram is overwritten. All telegrams have the same content as in step 4", 'blue');				
	if($NonInflatable_Overwrites_NonInflatable eq 'yes'){
		foreach my $CT(1..$NumberOfCrashTelegrams){ #only oldest CT should be overwritten, other CTs should be unchanged
			#PD check
			S_w2rep("step6: only oldest CT should be overwritten, other CTs should be unchanged - check EDR$CT using PD", 'orange');
			if($CT == '1'){
				#oldest CT for PD is 1st CT which is overwritten
				GEN_EVAL_CompareNumArrays ($UniqueCrashNumber_AfterInflatable[$CT], $UniqueCrashNumber_AfterNonInflatable[$CT], 'NotEqual'); 
			} 
			else{
				#other CTs are not overwritten
				GEN_EVAL_CompareNumArrays ($UniqueCrashNumber_AfterInflatable[$CT], $UniqueCrashNumber_AfterNonInflatable[$CT], 'Equal'); 
			}   		
			#CD check			
			S_w2rep("step6: only oldest CT should be overwritten, other CTs should be unchanged - check EDR$CT using CD", 'orange');
			if($CT < $NumberOfCrashTelegrams){	
				$temp_aref1 = $EDRresponse_aref_AfterInflatable[$CT];
				my $index = $CT + 1;
				$temp_aref2 = $EDRresponse_aref_AfterNonInflatable[$index];					
				if(defined @$temp_aref1[0] and defined @$temp_aref2[0]){
					foreach (1..5){ 	#remove the positive response bytes and header (since this may change after each crash)
						shift(@$temp_aref1); 
						shift(@$temp_aref2); 
					}
					
					#remove the checksum and signature bytes (since this may change after each crash)
					my $offset = scalar (@$temp_aref1) - $removableBytesNumber;
					splice @$temp_aref1, $offset ;
					splice @$temp_aref2, $offset ;	
				}
				GEN_EVAL_CompareNumArrays ($temp_aref1, $temp_aref2, 'Equal');
			}
			elsif($CT == $NumberOfCrashTelegrams){
				$temp_aref1 = $EDRresponse_aref_AfterInflatable[$CT];
				$temp_aref2 = $EDRresponse_aref_AfterNonInflatable[$CT];
				if(defined @$temp_aref1[0] and defined @$temp_aref2[0]){
					foreach (1..5){ 	#remove the positive response bytes and header (since this may change after each crash)
						shift(@$temp_aref1); 
						shift(@$temp_aref2); 
					}
					
					#remove the checksum and signature bytes (since this may change after each crash)
					my $offset = scalar (@$temp_aref1) - $removableBytesNumber;
					splice @$temp_aref1, $offset ;
					splice @$temp_aref2, $offset ;	
				}
				GEN_EVAL_CompareNumArrays ($EDRresponse_aref_AfterInflatable[$CT], $EDRresponse_aref_AfterNonInflatable[$CT], 'NotEqual'); 
			}
		}
		
		S_w2rep("Check that $TCpar_hash{'DifferentType1'} InflatableDeployment crash is stored in the most recent EDR entry", 'red');
		my ($response_aref,$EDIDstruct);
		$response_aref = $EDRresponse_aref_AfterNonInflatable[1]; #latest EDR entry
		my @hex_resp=(@$response_aref);
    	foreach (@hex_resp){$_ = "0x".sprintf("%02X",$_);
        print FIL $_;}       
   		$EDIDstruct = CD_parseEDID(\@hex_resp );
   		S_w2rep("Verdict is set to INCONC as this should be verified manually", 'red');
		S_set_verdict ( 'VERDICT_INCONC' );
		
	}
	elsif($NonInflatable_Overwrites_NonInflatable eq 'no'){
		foreach my $CT(1..$NumberOfCrashTelegrams){
			#PD check
			S_w2rep("step6: CTs should be unchanged - check EDR$CT using PD", 'orange');
			GEN_EVAL_CompareNumArrays ($UniqueCrashNumber_AfterInflatable[$CT], $UniqueCrashNumber_AfterNonInflatable[$CT], 'Equal');    		
			#CD check	
			$temp_aref1 = $EDRresponse_aref_AfterInflatable[$CT];
			$temp_aref2 = $EDRresponse_aref_AfterNonInflatable[$CT];		
			if(defined @$temp_aref1[0] and defined @$temp_aref2[0]){
				foreach (1..5){ 	#remove the positive response bytes and header (since this may change after each crash)
					shift(@$temp_aref1); 
					shift(@$temp_aref2); 
				}
				
				#remove the checksum and signature bytes (since this may change after each crash)
				my $offset = scalar (@$temp_aref1) - $removableBytesNumber;
				splice @$temp_aref1, $offset ;
				splice @$temp_aref2, $offset ;	
			}
			S_w2rep("step6: CTs should be unchanged - check EDR$CT using CD", 'orange');
			GEN_EVAL_CompareNumArrays ($temp_aref1, $temp_aref2, 'Equal');
		}
	}
	
	S_w2rep("Step8: No crash telegram is overwritten. All telegrams have the same content as in step 6", 'blue');				
	foreach my $CT(1..$NumberOfCrashTelegrams){
		S_w2rep("step8: CTs should be unchanged - check EDR$CT using PD", 'orange');
		GEN_EVAL_CompareNumArrays ($UniqueCrashNumber_AfterNonInflatable[$CT], $UniqueCrashNumber_AfterNoDeployment[$CT], 'Equal');
		#CD check	
		$temp_aref1 = $EDRresponse_aref_AfterNonInflatable[$CT];
		$temp_aref2 = $EDRresponse_aref_AfterNoDeployment[$CT];
		if(defined @$temp_aref1[0] and defined @$temp_aref2[0]){
			foreach (1..5){ 	#remove the positive response bytes and header (since this may change after each crash)
				shift(@$temp_aref1); 
				shift(@$temp_aref2); 
			}
			
			#remove the checksum and signature bytes (since this may change after each crash)
			my $offset = scalar (@$temp_aref1) - $removableBytesNumber;
			splice @$temp_aref1, $offset ;
			splice @$temp_aref2, $offset ;	
		}
		S_w2rep("step8: CTs should be unchanged - check EDR$CT using CD", 'orange');
		GEN_EVAL_CompareNumArrays ($temp_aref1, $temp_aref2, 'Equal');
	}

	
	return 1;
}
	
    

#### TC FINALIZATION #####
#-- set system to original state --##
sub TC_finalization {
            
    GEN_Finalization  ();
    
	return 1;
}

#*******************************Summary Section*****************************************
	foreach my $count(1..6){
		$UniqueCrashNumber_Initial[$count] = [0,1];
	}
	foreach my $count(1..6){
		$UniqueCrashNumber_AfterInflatable[$count] = [0,2];
	}
	foreach my $count(1..6){
		$UniqueCrashNumber_AfterNonInflatable[$count] = [3,3];
	}
	foreach my $count(1..6){
		$UniqueCrashNumber_AfterNoDeployment[$count] = [4,4];
	}


my $titles_aref = ['EDR Entry','Initial(NonInflatable)', 'AfterNoDeployment', 'AfterNonInflatable', 'AfterInflatable'];
my $content_EDR1_aref = [1, "@{$UniqueCrashNumber_Initial[1]}",  "@{$UniqueCrashNumber_AfterInflatable[1]}", "@{$UniqueCrashNumber_AfterNonInflatable[1]}", "@{$UniqueCrashNumber_AfterNoDeployment[1]}" ];
my $content_EDR2_aref = [2, "@{$UniqueCrashNumber_Initial[2]}",  "@{$UniqueCrashNumber_AfterInflatable[2]}", "@{$UniqueCrashNumber_AfterNonInflatable[2]}", "@{$UniqueCrashNumber_AfterNoDeployment[2]}" ];
my $content_EDR3_aref = [3, "@{$UniqueCrashNumber_Initial[3]}",  "@{$UniqueCrashNumber_AfterInflatable[3]}", "@{$UniqueCrashNumber_AfterNonInflatable[3]}", "@{$UniqueCrashNumber_AfterNoDeployment[3]}" ];
my $content_EDR4_aref = [4, "@{$UniqueCrashNumber_Initial[4]}",  "@{$UniqueCrashNumber_AfterInflatable[4]}", "@{$UniqueCrashNumber_AfterNonInflatable[4]}", "@{$UniqueCrashNumber_AfterNoDeployment[4]}" ];
my $content_EDR5_aref = [5, "@{$UniqueCrashNumber_Initial[5]}",  "@{$UniqueCrashNumber_AfterInflatable[5]}", "@{$UniqueCrashNumber_AfterNonInflatable[5]}", "@{$UniqueCrashNumber_AfterNoDeployment[5]}" ];
my $content_EDR6_aref = [6, "@{$UniqueCrashNumber_Initial[6]}",  "@{$UniqueCrashNumber_AfterInflatable[6]}", "@{$UniqueCrashNumber_AfterNonInflatable[6]}", "@{$UniqueCrashNumber_AfterNoDeployment[6]}" ];

GEN_printTestStep("-----------------------Summary of Overwrite Strategy Test for Inflatable Crashes-----------------------");
GEN_printComment("PD: Unique Crash Number");
GEN_printTableToReport ($titles_aref,[$content_EDR1_aref, $content_EDR2_aref, $content_EDR3_aref, $content_EDR4_aref, $content_EDR5_aref, $content_EDR6_aref]);


1;


__END__