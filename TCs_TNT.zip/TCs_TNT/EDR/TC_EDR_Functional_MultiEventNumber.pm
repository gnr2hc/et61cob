#### TEST CASE MODULE
package TC_EDR_Functional_MultiEventNumber;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------
our $VERSION = q$Revision: 1.6 $;
our $HEADER = q$Header: EDR/TC_EDR_Functional_MultiEventNumber.pm 1.6 2013/10/28 15:50:35ICT ver6cob develop  $;
################################## 

#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general; 
use LIFT_evaluation;
use LIFT_PD;
use INCLUDES_Project;
##################################

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_Functional_MultiEventNumber  $Revision: 1.6 $

requires MLC,PD,CANoe,POWER and evaluation (setup already done in IC)

default state is faultfree ECU powered ON

=head1 PURPOSE

to validate the data element  Multi Event number recorded in EDR

=head1 TESTCASE DESCRIPTION 

    [initialisation]
    StandardPreparation

    [stimulation & measurement]
    1. Inject a Front NoDeployment Crash
	2. Read MultiEventNumber, time values of 1st stored event through CD
	3. Reset the ECU
	4. Inject <crash>
	5. Read MultiEventNumber, time value of 2nd stored event through CD
	6. For 2 event crash, read MultiEventNumber, time values of 3rd stored event through CD
	7. For 3 event crash, read MultiEventNumber, time values of 4th stored event through CD

    [evaluation]
    1.
	2. MultiEventNumber = 1
	5. MultiEventNumber = 1
	6. MultiEventNumber = <Multi_Event_Number3>
	7. MultiEventNumber = <Multi_Event_Number4>

    [finalisation]
    Clear Crash Telegram and Fault memory
    ECU off

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

    purpose                  --> Purpose of the test case
    crash		  	 		 --> label of crash to be injected
    Multi_Event_Number3		 --> Value of MultiEvent Number for 3rd event
    Multi_Event_Number4		 --> Value of MultiEvent Number for 4th event
  	

=head2 PARAMETER EXAMPLES

    [TC_EDR_Functional_MultiEventNumber.TwoInflatableDeploymentEventsWithin5sec]
	Multi_Event_Number = '2'
	# From here on: applicable Lift Default Parameters
	purpose = 'to validate the data element  Multi Event number recorded in EDR'
	crash = 'TwoInflatableDeploymentEventsWithin5sec'
	Multi_Event_Number3 = '2'

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#Hashes to read the parameters from .par file  
my (%defaultpar_hash,
	%TCpar_hash);


#List of parameters in .par file
my @defaultpar_list 			= ('purpose',
					   			   'crash');
my @TCpar_list 					= ('Multi_Event_Number3',
								   'Time_previous_to_current_3',
								   'Time_initial_to_current_3',
								   'TotalNumberOfEventsStored');	   

				                  
#other TC specific constants/parameters from other files



#variables used in the test case
my ($NumberOfCrashTelegrams);
my $CrashInjectionStatus;	
my ($EDR_CD_response1_aref, 
	$EDR_CD_response2_aref,
	$EDR_CD_response3_aref,
	$EDR_CD_response4_aref,
	$EDR_CD_response5_aref,
	$EDR_CD_response_emptyEDR_aref );
	
my ($MultiEventNumber_EDR1,
	$Time_previous_to_current_EDR1, 
	$Time_initial_to_current_EDR1, 
	$MultiEventNumber_EDR2,
	$Time_previous_to_current_EDR2, 
	$Time_initial_to_current_EDR2, 
	$MultiEventNumber_EDR3,
	$Time_previous_to_current_EDR3, 
	$Time_initial_to_current_EDR3, 
	$MultiEventNumber_EDR4,
	$Time_previous_to_current_EDR4, 
	$Time_initial_to_current_EDR4);



sub TC_set_parameters {
		
	#read each default parameter from the .par file
	foreach my $defaultpar(@defaultpar_list){
		$defaultpar_hash{$defaultpar} =  GEN_Read_mandatory_testcase_parameter($defaultpar);
	}
	
	#read each test case parameter from the .par file
	foreach my $TCpar(@TCpar_list){
		$TCpar_hash{$TCpar} =  GEN_Read_mandatory_testcase_parameter($TCpar);
	}
	
	our $PURPOSE = "$defaultpar_hash{'purpose'}";	
	
	#read other TC specific constants/parameters from other files
	$TCpar_hash{'Multi_Event_Number4'} =  GEN_Read_optional_testcase_parameter('Multi_Event_Number4');
	$TCpar_hash{'Time_previous_to_current_4'} =  GEN_Read_optional_testcase_parameter('Time_previous_to_current_4');
	$TCpar_hash{'Time_initial_to_current_4'} =  GEN_Read_optional_testcase_parameter('Time_initial_to_current_4');
	
	$NumberOfCrashTelegrams = EDR_fetchNumberOfCrashTelegrams();
    
	return 1;

}

#### INITIALIZE TC #####
sub TC_initialization {

    S_w2rep('StandardPreparation', 'blue'); 
    PD_ClearCrashRecorder();
    GEN_StandardPrepNoFault();
        
  	return 1;
}


### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {
       
    S_w2rep("Step1: Inject a Front NoDeployment Crash", 'blue');
    $CrashInjectionStatus = EDR_InjectCrash('FrontNoDeployment' , 10000);    
    
    unless (defined $CrashInjectionStatus and $CrashInjectionStatus == 1){
    	S_set_error("Crash is not injected successfully. Not proceeding!", 0);
		return 0;
    }
    
    S_w2rep("Step2:  Read MultiEventNumber values in EDR1 through CD", 'blue');
    $EDR_CD_response1_aref = EDR_CD_ReadEDR (1); 
    $MultiEventNumber_EDR1 = ReadMultiEventNumber ($EDR_CD_response1_aref);
    $Time_previous_to_current_EDR1 = ReadTimeBetweenEvents($EDR_CD_response1_aref, 'Time_previous_to_current');
	$Time_initial_to_current_EDR1 = ReadTimeBetweenEvents($EDR_CD_response1_aref, 'Time_initial_to_current');
    
    S_w2rep("Step3: Reset the ECU", 'blue');
    GEN_Power_on_Reset ();
    
    S_w2rep("Step4: Inject crash", 'blue');
    $CrashInjectionStatus = InjectCrash ();
          
    
	if(defined $CrashInjectionStatus and $CrashInjectionStatus == 1){
	    if($TCpar_hash{'TotalNumberOfEventsStored'} == 2){
	    	S_w2rep("Step5:  Read MultiEventNumber, time between events of 2nd stored event through CD", 'blue');
	    	$EDR_CD_response2_aref = EDR_CD_ReadEDR (1);   #2nd stored event is reported in EDR1 request(latest entry)
	    	$MultiEventNumber_EDR2 = ReadMultiEventNumber ($EDR_CD_response2_aref);	
	    	$Time_previous_to_current_EDR2 = ReadTimeBetweenEvents($EDR_CD_response2_aref, 'Time_previous_to_current');
	    	$Time_initial_to_current_EDR2 = ReadTimeBetweenEvents($EDR_CD_response2_aref, 'Time_initial_to_current');
	    	
	    	$EDR_CD_response_emptyEDR_aref = EDR_CD_ReadEDR (3);   #read the next EDR too, to check that its empty
	    }   	    
	    elsif(($TCpar_hash{'TotalNumberOfEventsStored'} == 3) && ($NumberOfCrashTelegrams > 2)){
	    	S_w2rep("Step5:  Read MultiEventNumber, time between events of 2nd stored event through CD", 'blue');
	    	$EDR_CD_response2_aref = EDR_CD_ReadEDR (2);   #2nd stored event is reported in EDR2 request (not latest entry)
	    	$MultiEventNumber_EDR2 = ReadMultiEventNumber ($EDR_CD_response2_aref);
	    	$Time_previous_to_current_EDR2 = ReadTimeBetweenEvents($EDR_CD_response2_aref, 'Time_previous_to_current');
	    	$Time_initial_to_current_EDR2 = ReadTimeBetweenEvents($EDR_CD_response2_aref, 'Time_initial_to_current');
	    
	    	S_w2rep("Step6:  For 2 event crash, read MultiEventNumber, time between events of 3rd stored event through CD", 'blue');
	    	$EDR_CD_response3_aref = EDR_CD_ReadEDR (1);  #3rd stored event is reported in EDR1 request (latest entry)
	    	$MultiEventNumber_EDR3 = ReadMultiEventNumber ($EDR_CD_response3_aref);
	    	$Time_previous_to_current_EDR3 = ReadTimeBetweenEvents($EDR_CD_response3_aref, 'Time_previous_to_current');
	    	$Time_initial_to_current_EDR3 = ReadTimeBetweenEvents($EDR_CD_response3_aref, 'Time_initial_to_current');
	    	
	    	$EDR_CD_response_emptyEDR_aref = EDR_CD_ReadEDR (4);   #read the next EDR too, to check that its empty
	    }	    
	    elsif(($TCpar_hash{'TotalNumberOfEventsStored'} == 4) && ($NumberOfCrashTelegrams > 3)){
	    	S_w2rep("Step5:  Read MultiEventNumber, time between events of 2nd stored event through CD", 'blue');
	    	$EDR_CD_response2_aref = EDR_CD_ReadEDR (3);  
	    	$MultiEventNumber_EDR2 = ReadMultiEventNumber ($EDR_CD_response2_aref);
	    	$Time_previous_to_current_EDR2 = ReadTimeBetweenEvents($EDR_CD_response2_aref, 'Time_previous_to_current');
	    	$Time_initial_to_current_EDR2 = ReadTimeBetweenEvents($EDR_CD_response2_aref, 'Time_initial_to_current');
	    
	    	S_w2rep("Step6:  For 2 event crash, read MultiEventNumber, time between events of 3rd stored event through CD", 'blue');
	    	$EDR_CD_response3_aref = EDR_CD_ReadEDR (2); 
	    	$MultiEventNumber_EDR3 = ReadMultiEventNumber ($EDR_CD_response3_aref);
	    	$Time_previous_to_current_EDR3 = ReadTimeBetweenEvents($EDR_CD_response3_aref, 'Time_previous_to_current');
	    	$Time_initial_to_current_EDR3 = ReadTimeBetweenEvents($EDR_CD_response3_aref, 'Time_initial_to_current');
	    		
	    	S_w2rep("Step7:  For 3 event crash, read MultiEventNumber,time between events of 4th stored event through CD", 'blue');
	    	$EDR_CD_response4_aref = EDR_CD_ReadEDR (1);  #latest entry
	    	$MultiEventNumber_EDR4 = ReadMultiEventNumber ($EDR_CD_response4_aref); 	
	    	$Time_previous_to_current_EDR4 = ReadTimeBetweenEvents($EDR_CD_response4_aref, 'Time_previous_to_current');
	    	$Time_initial_to_current_EDR4 = ReadTimeBetweenEvents($EDR_CD_response4_aref, 'Time_initial_to_current');  
	    	
	    	$EDR_CD_response_emptyEDR_aref = EDR_CD_ReadEDR (5);   #read the next EDR too, to check that its empty 	
	    } 
	} 
 
  	return 1;
}


#### EVALUATE TC #####
sub TC_evaluation {
	
	S_w2rep("Step2: MultiEventNumber = 1, Time between events = 0xFFFF", 'blue');
	S_w2rep("MultiEventNumber, time between events of 1st stored event", 'orange');
	EVAL_evaluate_value ( "Multi Event number: FirstEvent", '0x1', '==', $MultiEventNumber_EDR1  );
	EVAL_evaluate_value ( "Time from previous to current event: for First stored Event", '0xFFFF', '==', $Time_previous_to_current_EDR1  );
	EVAL_evaluate_value ( "Time from initial to current event: for First stored Event", '0xFFFF', '==', $Time_initial_to_current_EDR1  );

	S_w2rep("Step5: MultiEventNumber = 1, Time between events = 0xFFFF", 'blue');
	S_w2rep("MultiEventNumber, time between events of 2nd stored event", 'orange');
	EVAL_evaluate_value ( "Multi Event number 2nd event", '0x1', '==', $MultiEventNumber_EDR2  );
	EVAL_evaluate_value ( "Time from previous to current event: for 2nd stored event", '0xFFFF', '==', $Time_previous_to_current_EDR2  );
	EVAL_evaluate_value ( "Time from initial to current event: for 2nd stored event", '0xFFFF', '==', $Time_initial_to_current_EDR2  );
	
	if(($TCpar_hash{'TotalNumberOfEventsStored'} >2) && ($NumberOfCrashTelegrams > 2)){
		S_w2rep("Step6: MultiEventNumber = $TCpar_hash{'Multi_Event_Number3'}", 'blue');
		S_w2rep("For 2 event crash, MultiEventNumber, time between events of 3rd stored event", 'orange');			
		S_w2rep("Expected: $TCpar_hash{'Multi_Event_Number3'}\n Observed: $MultiEventNumber_EDR3");
		if($TCpar_hash{'Multi_Event_Number3'} eq 'NotStored'){
			#checked in last step if the EDR is not stored
		}
		else{
			EVAL_evaluate_value ( "Multi Event number EDR3", $TCpar_hash{'Multi_Event_Number3'}, '==', $MultiEventNumber_EDR3  );
			if($TCpar_hash{'Time_previous_to_current_3'} eq 'as per crash file'){
				S_w2rep("Observed Time between previous event to current event is $Time_previous_to_current_EDR3");
				S_w2rep("Observed Time between initial event to current event is $Time_initial_to_current_EDR3");
				S_set_verdict ( 'VERDICT_INCONC' );
				S_set_error("This step needs to be verified manually. So verdict is set to INCONC!", 0);			
			}
			else{
				EVAL_evaluate_value ( "Time from previous to current event: for 3rd stored event", $TCpar_hash{'Time_previous_to_current_3'}, '==', $Time_previous_to_current_EDR3  );
				EVAL_evaluate_value ( "Time from initial to current event: for 3rd stored event", $TCpar_hash{'Time_initial_to_current_3'}, '==', $Time_initial_to_current_EDR3  );
			}
		}				
	}
		
	if(($TCpar_hash{'TotalNumberOfEventsStored'} > 3) && ($NumberOfCrashTelegrams >3)){
		S_w2rep("Step7: MultiEventNumber = $TCpar_hash{'Multi_Event_Number4'}", 'blue');
		S_w2rep("For 3 event crash, MultiEventNumber, time between events of 4th stored event", 'orange');	
		S_w2rep("Expected: $TCpar_hash{'Multi_Event_Number4'}\n Observed: $MultiEventNumber_EDR4");
		if($TCpar_hash{'Multi_Event_Number4'} eq 'NotStored'){
			#checked in last step if the EDR is not stored
		}
		else{
			EVAL_evaluate_value ( "Multi Event number EDR4", $TCpar_hash{'Multi_Event_Number4'}, '==', $MultiEventNumber_EDR4  );
			if($TCpar_hash{'Time_previous_to_current_4'} eq 'as per crash file'){				
				S_w2rep("Observed Time between previous event to current event is $Time_previous_to_current_EDR4");
				S_w2rep("Observed Time between initial event to current event is $Time_initial_to_current_EDR4");
				S_set_verdict ( 'VERDICT_INCONC' );
				S_set_error("This step needs to be verified manually. So verdict is set to INCONC!", 0);
				
			}
			else{
				EVAL_evaluate_value ( "Time from previous to current event: 4th stored event", $TCpar_hash{'Time_previous_to_current_4'}, '==', $Time_previous_to_current_EDR4  );
				EVAL_evaluate_value ( "Time from initial to current event: 4th stored event", $TCpar_hash{'Time_initial_to_current_4'}, '==', $Time_initial_to_current_EDR4  );
			}
		}
	}
	
	S_w2rep("Step END: check the total number of crashes stored. (Check that no crash is stored in the next EDR)", 'blue');
	EDR_CD_EVAL_checkStorageStatus ($EDR_CD_response_emptyEDR_aref,'NotStored');

    return 1;
}

#### TC FINALIZATION #####
#-- set system to original state --##
sub TC_finalization {

    GEN_Finalization  ();
    
return 1;
}

sub InjectCrash {
	
	if($defaultpar_hash{'crash'} eq 'TwoEventsGreaterThan5sec'){
    	EDR_InjectCrash('FrontNonInflatableDeployment'); 
    	S_wait_ms ( '6000' );
    	return EDR_InjectCrash('SideDriverInflatableDeployment'); 
    }
    elsif($defaultpar_hash{'crash'} eq 'ThreeEventsGreaterThan5sec'){
    	EDR_InjectCrash('FrontNonInflatableDeployment'); 
    	S_wait_ms ( '6000' );
    	EDR_InjectCrash('SideDriverInflatableDeployment');
    	S_wait_ms ( '6000' );
    	return EDR_InjectCrash('FrontInflatableDeployment' , 10000);
    	
    }
    elsif($defaultpar_hash{'crash'} eq 'TwoEventsWithin5sec_NextEventAfter5sec'){
    	EDR_InjectCrash('FrontInflatable_SidePassengerNoDeployment_Multiple');
    	S_wait_ms ( '6000' );
    	return EDR_InjectCrash('SideDriverInflatableDeployment' , 10000);
    }
    else{
    	return EDR_InjectCrash($defaultpar_hash{'crash'} , 10000); 
    }
    
}

sub ReadMultiEventNumber {
	
	my $response_aref = shift;
	my $MultiEventNumber;
	my $EDIDdata_aref;

	my $EDID_MEnumber = EDR_fetchEDIDbyLabel('MultiEventNumber');
	$EDIDdata_aref = EDR_CD_getEDIDdata ($response_aref, $EDID_MEnumber); #EDID corresponds to data element 'Multi Event number'
	unless (defined $EDIDdata_aref and defined @$EDIDdata_aref[0]){
		S_set_error("No data is available for EDID$EDID_MEnumber (MultiEventNumber)", '102');
		return undef;
	}
	return S_aref2hex($EDIDdata_aref);
			
}

sub ReadTimeBetweenEvents {
	
	my $response_aref = shift;
	my $timelabel = shift;
	my $EDIDdata_aref;
	
	my $EDID_time = EDR_fetchEDIDbyLabel($timelabel);
	$EDIDdata_aref = EDR_CD_getEDIDdata ($response_aref, $EDID_time); #EDID corresponds to data element time btw events
	unless (defined $EDIDdata_aref and defined @$EDIDdata_aref[0]){
		S_set_error("No data is available for EDID$EDID_time (Time Between Events)", '102');
		return undef;
	}
	return S_aref2hex($EDIDdata_aref);
			
}


1;


__END__