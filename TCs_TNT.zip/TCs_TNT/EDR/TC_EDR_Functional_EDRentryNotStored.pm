#### TEST CASE MODULE
package TC_EDR_Functional_EDRentryNotStored;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------
our $VERSION = q$Revision: 1.3 $;
our $HEADER = q$Header: EDR/TC_EDR_Functional_EDRentryNotStored.pm 1.3 2013/08/14 11:54:38ICT ver6cob develop  $;
################################## 

#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general; 
use LIFT_evaluation;
use LIFT_PD;
use INCLUDES_Project;
##################################

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_Functional_EDRentryNotStored  $Revision: 1.3 $

requires MLC,PD,CANoe,POWER and evaluation (setup already done in IC)

default state is faultfree ECU powered ON

=head1 PURPOSE

To check that an EDR entry must not be stored in case of release of restraint devices for diagnostic purposes or end-of-life vehicle disposal ignition 

=head1 TESTCASE DESCRIPTION 

    [initialisation]
    StandardPreparation

    [stimulation & measurement]
    1. Create <condition>
	2. Read EDR1 through CD
	3. Read EDR2 through CD

    [evaluation]
    2. No Crash Stored in the EDR1
	3. No Crash Stored in the EDR2

    [finalisation]
    Clear Crash Telegram and Fault memory
    ECU off

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

    purpose                  --> Purpose of the test case
    condition			  	 --> condition to be created - 'DiagnosticFiring' or 'DisposalSessionFiring' i.e. release of restraint devices for diagnosis purposes or end of life disposal ignition
  	

=head2 PARAMETER EXAMPLES

    [TC_EDR_Functional_EDRentryNotStored.DiagnosticFiring]
	# From here on: applicable Lift Default Parameters
	purpose = 'to check that an EDR entry is not stored in case of  release of restraint devices for diagnosis purposes or in case of end of life disposal ignition'
	condition = 'DiagnosticFiring'
	

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#Hashes to read the parameters from .par file  
my (%defaultpar_hash,
	%TCpar_hash);


#List of parameters in .par file
my @defaultpar_list 			= ('purpose',
								   'condition');
my @TCpar_list 					= ();	   

				                  
#other TC specific constants/parameters from other files


#variables used in the test case
my ($EDR1_CD_response_aref, $EDR2_CD_response_aref);
my $result; #successfully created condition (1) else (0)
our $PURPOSE;

sub TC_set_parameters {
		
	#read each default parameter from the .par file
	foreach my $defaultpar(@defaultpar_list){
		$defaultpar_hash{$defaultpar} =  GEN_Read_mandatory_testcase_parameter($defaultpar);
	}
	
	#read each test case parameter from the .par file
	foreach my $TCpar(@TCpar_list){
		$TCpar_hash{$TCpar} =  GEN_Read_mandatory_testcase_parameter($TCpar);
	}
	
	#purpose statement
	$PURPOSE = "$defaultpar_hash{'purpose'}";	
	
	#read other TC specific constants/parameters from other files
    
	return 1;

}

#### INITIALIZE TC #####
sub TC_initialization {

    S_w2rep('StandardPreparation', 'blue'); 
    PD_ClearCrashRecorder();
    GEN_StandardPrepNoFault();
        
  	return 1;
}


### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {
    
    S_w2rep("Step1:  Create condition - $defaultpar_hash{'condition'}", 'blue');
    if($defaultpar_hash{'condition'} eq 'DiagnosticFiring'){
    	$result = EDR_DiagnosticFiring ();
    }
    elsif($defaultpar_hash{'condition'} eq 'DisposalSessionFiring'){
    	$result = EDR_DisposalSessionFiring ();
    }
    
    unless (defined $result and $result == 1){
    	S_set_error("Condition is not created successfully. Not proceeding!", 0);
    	$PURPOSE = "Condition is not created successfully";
		return 0;
    } 
    
 	S_w2rep("Step2:  Read EDR1 through CD", 'blue');
	$EDR1_CD_response_aref = EDR_CD_ReadEDR (1); 
	
	S_w2rep("Step3:  Read EDR2 through CD", 'blue');
	$EDR2_CD_response_aref = EDR_CD_ReadEDR (2);   	
        
  	return 1;
}


#### EVALUATE TC #####
sub TC_evaluation {
	
	S_w2rep("Step2: No Crash Stored in the EDR1", 'blue');
	EDR_CD_EVAL_checkStorageStatus ($EDR1_CD_response_aref,'NotStored');

	S_w2rep("Step3: No Crash Stored in the EDR2", 'blue');
	EDR_CD_EVAL_checkStorageStatus ($EDR2_CD_response_aref,'NotStored');
    
    return 1;
}

#### TC FINALIZATION #####
#-- set system to original state --##
sub TC_finalization {

    GEN_Finalization  ();
    
return 1;
}


1;


__END__