#### TEST CASE MODULE
package TC_EDR_Functional_EPP_InvalidFunctionalArea;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------
our $VERSION = q$Revision: 1.3 $;
our $HEADER = q$Header: EDR/TC_EDR_Functional_EPP_InvalidFunctionalArea.pm 1.3 2013/08/14 11:55:23ICT ver6cob develop  $;
################################## 

#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general; 
use LIFT_evaluation;
use LIFT_PD;
use INCLUDES_Project;
##################################

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_Functional_EPP_InvalidFunctionalArea  $Revision: 1.3 $

requires MLC,PD,CANoe,POWER and evaluation (setup already done in IC)

default state is faultfree ECU powered ON

=head1 PURPOSE

to check that a non deployment event is stored for an EPP crash, where the release condition was met in the algorithm, but where a release decision was not taken due to an invalid functional area

=head1 TESTCASE DESCRIPTION 

    [initialisation]
    StandardPreparation

    [stimulation & measurement]
    1. Inject an EPP crash, where the release condition was met in the algorithm, but where a release decision was not taken due to an invalid functional area 
	2. Read the crash type of the stored crash using PD

    [evaluation]
    1. 
	2. A non deployment event is stored

    [finalisation]
    Clear Crash Telegram and Fault memory
    ECU off

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

    purpose                  --> Purpose of the test case
  	

=head2 PARAMETER EXAMPLES

    [TC_EDR_Functional_EPP_InvalidFunctionalArea.InvalidFunctionalArea]
	# From here on: applicable Lift Default Parameters
	purpose = 'to check that a non deployment event is stored for an EPP crash, where the release condition was met in the algorithm, but where a release decision was not taken due to an invalid functional area'

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#Hashes to read the parameters from .par file  
my (%defaultpar_hash,
	%TCpar_hash);


#List of parameters in .par file
my @defaultpar_list 			= ('purpose');
my @TCpar_list 					= ();	   

				                  
#other TC specific constants/parameters from other files



#variables used in the test case
my ($RecordValidity_GEN_EDR1,$CrashType_EDR1);
my $CrashInjectionStatus;
our $PURPOSE;

sub TC_set_parameters {
		
	#read each default parameter from the .par file
	foreach my $defaultpar(@defaultpar_list){
		$defaultpar_hash{$defaultpar} =  GEN_Read_mandatory_testcase_parameter($defaultpar);
	}
	
	#read each test case parameter from the .par file
	foreach my $TCpar(@TCpar_list){
		$TCpar_hash{$TCpar} =  GEN_Read_mandatory_testcase_parameter($TCpar);
	}
	
	$PURPOSE = "$defaultpar_hash{'purpose'}";	
	
	#read other TC specific constants/parameters from other files

    
	return 1;

}

#### INITIALIZE TC #####
sub TC_initialization {

    S_w2rep('StandardPreparation', 'blue'); 
    PD_ClearCrashRecorder();
    GEN_StandardPrepNoFault();
        
  	return 1;
}


### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {
    
    my $label;
    
    S_w2rep("Step1: Inject an EPP crash, where the release condition was met in the algorithm, but where a release decision was not taken due to an invalid functional area", 'blue');
    $CrashInjectionStatus = EDR_InjectCrash('EPPInvalidFuntionalArea', 5000); 
    
    unless (defined $CrashInjectionStatus and $CrashInjectionStatus == 1){
    	S_set_error("Crash is not injected successfully. Not proceeding!", 0);
    	$PURPOSE = "Crash not injected successfully";
		return 0;
    }    
    
    S_w2rep("Step2:  Read the crash type of the stored crash using PD", 'blue');
	#Crash type
    $CrashType_EDR1 = S_aref2hex (PD_ReadMemoryByName( 'S_Header_XXE.A_CrashType_U8X(0)' ));   
    #Record validity
    $RecordValidity_GEN_EDR1 = S_aref2hex (PD_ReadMemoryByName( 'A_Edr_XSE(0).S_GEN_XXX.V_RecordValidity_U8X' )); 
    
  	return 1;
}


#### EVALUATE TC #####
sub TC_evaluation {
	
	S_w2rep("Step2a: A non deployment event is stored", 'blue');
	if(defined $CrashType_EDR1){
		S_w2rep("Crash Type\n",'orange');
		S_w2rep("Expected: 0x5A\n Observed: $CrashType_EDR1\n", 'blue'); 
		EVAL_evaluate_value ( "Crash type EDR1", '0x5A', '==', $CrashType_EDR1  );
	}
	
	if(defined $RecordValidity_GEN_EDR1){
		S_w2rep("Record Validity - GEN\n",'orange');
		S_w2rep("Expected: 0x5A\n Observed: $RecordValidity_GEN_EDR1\n", 'blue');
		EVAL_evaluate_value ( "Record Validity EDR1", '0x5A', '==', $RecordValidity_GEN_EDR1  );
	}
	
    return 1;
}

#### TC FINALIZATION #####
#-- set system to original state --##
sub TC_finalization {

    GEN_Finalization  ();
    
return 1;
}


1;


__END__