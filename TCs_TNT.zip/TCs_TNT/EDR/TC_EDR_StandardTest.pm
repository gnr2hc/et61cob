#### TEST CASE MODULE
package TC_EDR_StandardTest;
#-> package name has to match file name ! case sensitive !

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
###-------------------------------
our $VERSION = q$Revision: 1.7 $;
our $HEADER = q$Header: EDR/TC_EDR_StandardTest.pm 1.7 2014/09/16 23:09:52ICT Okrusch Thomas (CC-PS/EPS2) (OUT2SI) develop  $;
##################################

#### INCLUDE ENGINE MODULES ####
use LIFT_general;   # this is always required
use LIFT_evaluation;
use LIFT_PD;
use LIFT_CREIS;
use LIFT_POWER;
use INCLUDES_Project;
use Devel::Size qw(total_size);
##################################

our $PURPOSE = "Standard Crash Injection test ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

#-> update documentation that somebody else can use the test without asking you
#-> delete parameter section if no paramteres are used
#-> note that POD documentation needs entirely empty lines before and after keywords (e.g. =head1, =cut ...) 

=head1 TESTCASE MODULE

TC_EDR_StandardTest  $Revision: 1.7 $

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:
    
    <list used parameters>

link to TS_CP: doors://si-airbag-doors.de.bosch.com:36664/?version=2&prodID=0&urn=urn:telelogic::1-0000000000000000-M-00046783

    [initialisation]
#     1. read next crash from MDS-Result-File (read environment states + velocities)
#     2. set environment states + velocities
#     3. erase EDR
#     4. erase FltMem
#     5. write bytes to ECU (optional)
#     6. Soft reset
#     7. read FltMem
#     8. read labels (optional)
     

    [stimulation & measurement]
#     1. read current environment (optional)
#     2. prepare crash
#     3. wait for particular time (IniEnd or given time) & inject crash
#     3. check if EDR is written
#     4. read + store EEPROM (optional)
#     5. read labels (optional)

    [evaluation]
#     1. evaluate labels
#     2. evaluate Environment settings
#     3. evaluate Firing times
#     4. evaluate FltMem before crash
#     5. evaluate FltMem after crash
    

    [finalisation]
    <list test steps>

=head1 PARAMETER

=head2 PARAMETER NAMES

#     LIST   'dummy_list'      --> <explain what this variable is good for>
#     SCALAR 'dummy_scalar'    --> <explain what this variable is good for>
#     HASH   'dummy_hash'      --> <explain what this variable is good for>

=head2 PARAMETER EXAMPLES

#     [TC_template.dummy]
#     dummy_list     = @('value1','value2')
#     dummy_scalar   = 'scalar'
#     dummy_hash     = %('key1' => 'value1','key2' => 'value2')

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#-> define variables here which sall be used across subroutines
#-> test case parameters shall start with tcpar_
my ( 
    $tcpar_CrashName, 
    $tcpar_IterationNumber, 
#     $tcpar_isSetEnvironment, 
    $tcpar_CrashNumber,
    
    $all_EDR_data,
    
    $CrashSettings, 
    $CrashDescription,
    $fltmemBeforeInjection, 
    $fltmemAfterInjection,
    
    );


sub TC_set_parameters {
    
   my ( $valid_flag , $return_value );    

   ( $valid_flag , $return_value ) = S_read_public_variable ( "CRASH_INDEX" );
    if( $valid_flag ) {
        $tcpar_CrashNumber = $return_value + 1;
        S_set_public_variable ( "CRASH_INDEX" , $tcpar_CrashNumber );      # max crash index = 145
    }
    else {
        $tcpar_CrashNumber = 1;
        S_set_public_variable ( "CRASH_INDEX" , 1 );
    }

    $tcpar_CrashNumber = 7;

    $tcpar_IterationNumber  = 1;
#     $tcpar_isSetEnvironment = "no";
    
    	
#     $tcpar_CrashNumber = S_read_testcase_parameter( 'CrashNumber' );
#     unless( defined $tcpar_CrashNumber ) {
#         S_w2rep(" -->  Missing mandatory parameter CrashNumber \n");
#         return 0;
#     }
#     
#     $tcpar_CrashName = S_read_testcase_parameter( 'CrashName' );
#     unless( defined $tcpar_CrashName ) {
#     	S_w2rep(" -->  Missing mandatory parameter CrashName \n");
#         return 0;
#     }
#     
#    $tcpar_IterationNumber = S_read_testcase_parameter( 'IterationNumber' );
#    unless( defined $tcpar_IterationNumber ) {
#         S_w2rep(" -->  Missing optional parameter IterationNumber : consider default as 0 \n");
#         $tcpar_IterationNumber = 0;
#    }    
#    
#    $tcpar_isSetEnvironment = S_read_testcase_parameter( 'IsSetEnvironment' );
#    unless( defined $tcpar_isSetEnvironment ) {
#         S_w2rep(" -->  Missing optional parameter isSetEnvironment : consider default as 'no'\n");
#         $tcpar_isSetEnvironment = 'no';
#    }    

   return 1;
}


#### INITIALIZE TC #####
sub TC_initialization {

    # power ON the ECU
    POW_on();
   
    # wait till the constant time : TIMER_ECU_READY
    S_wait_ms('TIMER_ECU_READY');
    PD_wait_INI_end();
   
    # 1. read next crash from MDS-Result-File (read environment states + velocities)
    $CrashSettings = CREIS_GetCrashSettingsFromMDS($tcpar_CrashNumber, $tcpar_IterationNumber);
    if( defined $CrashSettings->{ 'CrashName' } ) {
        $tcpar_CrashName = $CrashSettings->{ 'CrashName' };
    } else {    
        S_w2rep( "Could not get CrashName from CrashSettings of MDS\n" , "red" );
        return unless $main::opt_offline;
        $tcpar_CrashName = "NO_NAME_IN_DEBUG_MODE";
    }   
     
    S_w2rep( "CRASH index : $tcpar_CrashNumber \n" , "blue" );
    S_add2eval_collection ( 'CRASH_IDX' , $tcpar_CrashNumber );
    S_w2rep( "CRASH name : $tcpar_CrashName \n" , "blue" );
    S_add2eval_collection ( 'CRASH_NAME' , $tcpar_CrashName );

    if( defined $CrashSettings->{ 'Description' } ) {
        $CrashDescription = $CrashSettings->{ 'Description' };
        S_w2rep( "CRASH description : $CrashDescription \n" , "blue" );
        S_add2eval_collection ( 'CRASH_DESCRIPTION' , $CrashDescription );
    }    

    if( defined $CrashSettings->{ 'Sensors' } ) {
        my $CrashSensors = $CrashSettings->{ 'Sensors' };
        if( ref $CrashSensors eq 'HASH' ) {
            foreach my $sensor ( sort keys %$CrashSensors ) {
                S_w2rep( "CRASH sensors : $sensor \n" , "blue" );
                S_add2eval_collection ( 'CRASH_SENSORS' , $sensor );
            }    
        }
    }    

    # S_w2rep(" size of CREIS settings: " . total_size($CrashSettings)/(1024*1024) . " MB \n "); 
    

    
    # 2. set environment states + velocities
# 	if($tcpar_isSetEnvironment =~ /yes/i)
# 	{
# 	   CREIS_SetEnvironmentForCrash($CrashSettings);
# 	   PD_CalculateChecksum( 'PROG_VAR_TBL', 'ASIC_CONF_TBL', 'PAR_SEC_TBL');
# 	   PD_ECUreset();
# 	}
	     
    # 3. erase EDR
    # "check if EDR is erased" will be done by this function call itself. The PD module will wait till ECU status is free (not busy) 
    PD_ClearCrashRecorder();
 
    # 4. erase FltMem
    PD_ClearFaultMemory();
 
    # 5. reset and wait for iniend to make sure that all init fault are available
    PD_ECUreset();
    S_wait_ms('TIMER_ECU_READY');
    PD_wait_INI_end();
    
    # 6. read faultmemory
    
    return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {
	    
    # power OFF the ECU
    POW_off();
    S_wait_ms('TIMER_ECU_OFF');
    
    # 1. read current environment (optional)
    	
	# 2. prepare crash
	CREIS_PrepareCrash($CrashSettings);

    # power ON the ECU
    POW_on();
    	 
    # 3. wait for particular time (IniEnd or given time) & inject crash
    # wait till the wait ini bit is set in ECU, to indicate that ECU is initialized
    PD_wait_INI_end();
 
    # 4. read faultMem before injection
    $fltmemBeforeInjection = PD_GetExtendedFaultInformation();
    
	# 5. Inject the crash
    S_w2rep( "Inject Crash '$tcpar_CrashName'\n" , 'blue' );
	CREIS_InjectCrash();
	
	# 6. check if EDR is written or finite wait time
	S_wait_ms(30000);
	
	# 7. read + store EEPROM (optional)


    read_EDR();

#     my $date_time = S_get_date_extension();
#     my $EEPROM_fn = "./reports/TC_CRASH_NBR__".$tcpar_CrashNumber."__EEPROM_".$date_time.".hex";
#     S_w2rep( "PD_DumpEEPROM( $EEPROM_fn )\n" , 'blue' );
#     PD_DumpEEPROM( $EEPROM_fn );
# 
#     my $FLASH_fn = "./reports/TC_CRASH_NBR__".$tcpar_CrashNumber."__FLASH_".$date_time.".hex";
#     S_w2rep( "PD_DumpFLASH( $FLASH_fn )\n" , 'blue' );
#     PD_DumpFLASH( $FLASH_fn );
	 
	# 8. read faultMem after injection
    $fltmemAfterInjection = PD_GetExtendedFaultInformation();

    # 9. read labels (optional)
	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {
    # 1. evaluate labels (optional)
    # 2. evaluate Environment settings (optional)

	# 3. evaluate Firing times
	# CREIS_EvaluateCrash($CrashSettings);
	
	#PD_DumpDeviceConfiguration();
	
    S_w2rep(" check if system is fault free before crash injection \n");
    # 4. evaluate FltMem before crash
    PD_evaluate_faults( $fltmemBeforeInjection, []);	
    
    S_w2rep(" check if system is fault free after crash injection \n");
     
    # 5. evaluate FltMem before crash
    PD_evaluate_faults( $fltmemAfterInjection, [], ['FltFrontCrashDetected', 'FltSideCrashPasDetected', 
                                                    'FltRearCrashDetected', 'FltSideCrashDrDetected',
                                                    'FltEppCrashDetected', 'FltROllOverCrashDetected']);       
        
	return 1;
}


#### TC FINALIZATION #####
sub TC_finalization {

	#-> either use this
	#    S_w2rep("no actions required\n");
	#-> or writes test steps

#    PD_ClearFaultMemory();
#    PD_ClearCrashRecorder();
    PD_ECUreset();
    
#     POW_off();
#     S_wait_ms('TIMER_ECU_OFF'); 
    	
    undef $tcpar_CrashName;
    undef $tcpar_IterationNumber;
#     undef $tcpar_isSetEnvironment;
    undef $tcpar_CrashNumber;

	undef $all_EDR_data;
    undef $CrashSettings;
    undef $fltmemBeforeInjection;
    undef $fltmemAfterInjection;	

	return 1;
}


sub read_EDR {
    
    S_w2rep( " -> read_EDR() .. \n" , 'blue' );

    my ( 
        $NumberOfCrashTelegrams,
        $Nbr_of_stored_records, 
        );

    unless( $NumberOfCrashTelegrams = EDR_fetchNumberOfCrashTelegrams() ) {
        S_w2rep( "ERROR - Could not get EDR_fetchNumberOfCrashTelegrams" , 'red' ); return;
    }

    foreach my $EDR_type (  qw( Generic OEM )  )         # can be read from 'Generic' and/or 'OEM' 
    {
        $Nbr_of_stored_records = 0;
            
        S_w2rep(" -> Read all EDR crash records ($NumberOfCrashTelegrams) \n", 'blue');
        foreach my $EDRcount ( 1 .. $NumberOfCrashTelegrams )
        {
        	S_w2rep( "----------------------------------------------------------\n", 'blue' );
        	S_w2rep( " Read EDR Nbr $EDRcount\n", 'blue' );
        	S_w2rep( "----------------------------------------------------------\n", 'blue' );
        	my $response = EDR_CD_ReadEDR ($EDRcount , $EDR_type );
            unless( $response ) { S_w2rep( "ERROR while reading $EDR_type EDR record nbr $EDRcount" ); S_user_action( "Es geht nicht" ); return }
            
            $all_EDR_data->{ 'Records' }{ $EDRcount }{$EDR_type}{ 'ResponseRaw' } = $response; 
            
            my $storage_status = EDR_CD_getStorageStatus( $response );
            unless( defined $storage_status ) { S_w2rep( "ERROR while EDR_CD_EDRStorageStatus of $EDRcount" ); return }            
            $all_EDR_data->{ 'Records' }{ $EDRcount }{$EDR_type}{ 'StorageStatus' } = $storage_status;
            S_w2rep( " EDR record [$EDRcount] Storage Status -> $storage_status \n" , 'blue' );

            next unless $storage_status == 1;      # 1 -> 'Stored'
            
            $Nbr_of_stored_records++;
            my $eval_col_label = "EDR_CT".$Nbr_of_stored_records;

#                             'EDR_CT_NBR',
#                             'EDR_CT_TYPES',
#                             'EDR_CT1',
#                             'EDR_CT2',
#                             'EDR_CT3',
#                             'EDR_CT4',
#                             'EDR_CT5',
#                             'EDR_CT6',

            
            my $EDID_struct = EDR_CD_parseEDID(  $response , $EDR_type );
            unless( defined $EDID_struct ) { S_w2rep( "EDR_CD_parseEDID was not successful \n", "red" ); return }
            
            foreach my $EDID_nbr (  sort {$a <=> $b } keys %$EDID_struct ) 
            {
                last if $EDID_nbr > 999;
                my $EDID_label = EDR_fetchEDIDLabel( $EDID_nbr );
            	S_w2rep( "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - \n", 'blue' );
                S_w2rep( " Converting EDID [$EDID_nbr] -> $EDID_label \n" , 'blue' );
            	S_w2rep( "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - \n", 'blue' );
                my $raw_EDID_data_aref = EDR_CD_getEDIDdata( $response, $EDID_nbr , $EDR_type , $EDID_struct );
                unless( defined $raw_EDID_data_aref ) { S_w2rep( "ERROR while EDR_CD_getEDIDdata( .. , $EDID_nbr , $EDR_type , .. )\n" , 'red' ); next }
                $all_EDR_data->{ 'Records' }{ $EDRcount }{$EDR_type}{ 'All_EDIDs' }{ $EDID_nbr }{ 'RawValues' } = $raw_EDID_data_aref;
                
                my $EDID_data = EDR_CD_convertResponse ( $raw_EDID_data_aref , $EDID_nbr );
                unless( defined $EDID_data ) { S_w2rep( "ERROR while EDR_CD_convertResponse ( ..  , $EDID_nbr )\n" , 'red' ); next }

                my $nbr_of_samples = $EDID_data->{'NBR_OF_SAMPLES'};

                my $data_NA_aref = $EDID_data->{'DATA_NOT_AVALABLE_ELEMENTS'};
                if( scalar @$data_NA_aref and $nbr_of_samples == 1 ) {
                    $all_EDR_data->{ 'Records' }{ $EDRcount }{$EDR_type}{ 'All_EDIDs' }{ $EDID_nbr }{ 'NotApplicable' } = $data_NA_aref;
                    S_w2rep( " EDID [$EDID_nbr] -> $EDID_label = @$data_NA_aref (N/A) \n" , 'orange' );
                    next;
                }

                my $phys_values_aref = $EDID_data->{'PHYS_SAMPLES'};
                if( scalar @$phys_values_aref ) {
                    $all_EDR_data->{ 'Records' }{ $EDRcount }{$EDR_type}{ 'All_EDIDs' }{ $EDID_nbr }{ 'PhysValues' } = $phys_values_aref;
                    S_w2rep( " EDID [$EDID_nbr] -> $EDID_label = @$phys_values_aref \n" , 'blue' );
                    S_add2eval_collection ( 'EDR_CT_TYPES' , $$phys_values_aref[0] ) if( $EDID_nbr == 1 ); # EventType
                    S_add2eval_collection ( $eval_col_label , $EDID_label." = ".$$phys_values_aref[0] ) if( $nbr_of_samples == 1 ); # 
                }
            }             
            
        }        
        
    }
    
    if( $Nbr_of_stored_records ) {
        S_add2eval_collection ( 'EDR_CT_NBR' , $Nbr_of_stored_records );
    
    }

    
    return 1;
}


###-----------------------------------------------------------------------------
sub EDR_CD_convertResponse {
###-----------------------------------------------------------------------------
    GEN_print_caller();

    my $EDIDdata_aref = shift;
    my $EDID          = shift;

    return { 
            'PHYS_SAMPLES'                  => [],
            'RAW_SAMPLES'                   => [],
            'DATA_NOT_AVALABLE_ELEMENTS'    => [],
            'INVALID_DATA_ELEMENTS'         => [],
    #         'HEADER_BYTES' => \@Splice_Header ,
            'BYTES_PER_SAMPLE'              => 1 ,
            'NBR_OF_SAMPLES'                => 1 ,
        } if $main::opt_offline;

    unless ( defined $EDID ) {
        S_set_error( "EDID parameter is not defined", 110 );    #error!
        return;
    }
    unless ( defined $EDIDdata_aref ) {
        S_set_error( "value parameter is not defined", 110 );    #error!
        return;
    }

    unless ( ref $EDIDdata_aref eq "ARRAY" ) {
        S_set_error( "value parameter is not a hash ref", 110 );    #error!
        return;
    }

    my @all_my_EDIDs_with_Header_4bytes = qw( 21 22 23 24 25 27 31 32 38 39 );      # temp solution

    foreach my $EDID_with_Header( @all_my_EDIDs_with_Header_4bytes ) 
    {
        next unless $EDID eq $EDID_with_Header;
        S_w2log( 4, " EDR_CD_convertResponse : 4 bytes Header of EDID $EDID must be removed \n" );
        my @Splice_Header = splice @$EDIDdata_aref, 0 , 4 ;
        S_w2log( 4, " EDR_CD_convertResponse : Header of EDID $EDID : " .  join ( ' ' , @Splice_Header ) . " \n" );
    }

    return unless my $BytesperSample_from_Mapping_EDR = EDR_fetchEDIDBytesPerDataSample( $EDID );
    
    return unless my $NbrOfSamples_from_Mapping_EDR = EDR_fetchEDIDDataSamples( $EDID );
    
    my $nbr_of_bytes = scalar @$EDIDdata_aref;    
    unless( $NbrOfSamples_from_Mapping_EDR * $BytesperSample_from_Mapping_EDR == $nbr_of_bytes )  {
        S_w2log( 1, " EDR_CD_convertResponse : (EDID $EDID) mismatch in nbr of elements ($nbr_of_bytes) (must be $BytesperSample_from_Mapping_EDR x $NbrOfSamples_from_Mapping_EDR ) \n" , "red" );
        return;
    }
    
    my $EDID_samples_raw_values = EDR_CD_getSamplesFromResponse( $EDIDdata_aref, $NbrOfSamples_from_Mapping_EDR , $BytesperSample_from_Mapping_EDR );

    S_w2log( 5, "SAMPLES FROM ARRAY: ". join( " " , @$EDID_samples_raw_values) ." \n" );
    
    my $elt_cntr = 0;
    my @data_not_available = ();
    my @invalid_data = ();
    foreach my $data_element( @$EDID_samples_raw_values ) {
        $elt_cntr++;
        
        my $sample_hex = sprintf( "%X" , $data_element );
        #
        # if there is no character different from 'F' its an invalid data element in the ringbuffer ( only FF... are there)
        # 
        # [^F] defines a class of character without 'F'
        #
        if(     $BytesperSample_from_Mapping_EDR == 1 and hex($sample_hex) == 0xFF 
             or $BytesperSample_from_Mapping_EDR == 2 and hex($sample_hex) == 0xFFFF
             or $BytesperSample_from_Mapping_EDR == 3 and hex($sample_hex) == 0xFFFFFF
             or $BytesperSample_from_Mapping_EDR == 4 and hex($sample_hex) == 0xFFFFFFFF
            ) 
        {
            S_w2log( 1, " EDR_CD_convertResponse : [$elt_cntr] 'Data not available' element ( $sample_hex (hex) / $data_element (dec) ) \n" , "red" );
            push ( @data_not_available , $sample_hex );
            next;
        }
        
        if(     $BytesperSample_from_Mapping_EDR == 1 and hex($sample_hex) == 0xFE 
             or $BytesperSample_from_Mapping_EDR == 2 and hex($sample_hex) == 0xFFFE
             or $BytesperSample_from_Mapping_EDR == 3 and hex($sample_hex) == 0xFFFFFE
             or $BytesperSample_from_Mapping_EDR == 4 and hex($sample_hex) == 0xFFFFFFFE
            ) 
        {
            S_w2log( 1, " EDR_CD_convertResponse : [$elt_cntr] 'Invalid Data' element ( $sample_hex (hex) / $data_element (dec) ) \n" , "red" );
            push ( @invalid_data , $elt_cntr );
        }
                
    }        

    my $EDID_samples_physical = EDR_CD_convertArrayByFactor_dec( $EDID_samples_raw_values, $EDID );
#     my $EDID_samples_physical = EDR_CD_convertArrayByFactor( $EDID_samples_raw_values, $EDID );

    S_w2log( 5, "AFTER CONVERSION: ". join( " " , @$EDID_samples_physical) ." \n" );

    my $EDID_data = { 
        'PHYS_SAMPLES' => $EDID_samples_physical,
        'RAW_SAMPLES' => $EDID_samples_raw_values,
        'DATA_NOT_AVALABLE_ELEMENTS' => \@data_not_available,
        'INVALID_DATA_ELEMENTS' => \@data_not_available,
#         'HEADER_BYTES' => \@Splice_Header ,
        'BYTES_PER_SAMPLE' => $BytesperSample_from_Mapping_EDR ,
        'NBR_OF_SAMPLES' => $NbrOfSamples_from_Mapping_EDR ,
    };

    return $EDID_data;
}

1;

__END__
