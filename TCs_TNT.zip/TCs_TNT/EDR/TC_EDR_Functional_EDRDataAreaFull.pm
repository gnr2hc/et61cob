#### TEST CASE MODULE
package TC_EDR_Functional_EDRDataAreaFull;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------
our $VERSION = q$Revision: 1.4 $;
our $HEADER = q$Header: EDR/TC_EDR_Functional_EDRDataAreaFull.pm 1.4 2013/11/28 13:58:33ICT ver6cob develop  $;
################################## 

#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general; 
use LIFT_evaluation;
use LIFT_PD; 
use INCLUDES_Project;

##################################

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_Functional_EDRDataAreaFull  $Revision: 1.4 $

requires MLC,PD,CANoe,POWER and evaluation (setup already done in IC)

default state is faultfree ECU powered ON

=head1 PURPOSE

to check EDR data area full fault and erasure of crash telegram

=head1 TESTCASE DESCRIPTION 

    [initialisation]
    StandardPreparation

    [stimulation & measurement]
    1. Inject <crash>, <count> times
	2. Check Crash Recorder for FltEdrDataAreaFull fault
	3. Inject one more Crash
	4. Check Crash Recorder for FltEdrDataAreaFull fault
	5. In <Disable_Erasure_of_EDR_data> EEPROM variable write value A5A5 and reset ECU
	6. Erase CrashRecorder 
	7. In <Disable_Erasure_of_EDR_data> EEPROM variable write previous value and reset ECU
	8. Erase CrashRecorder. Reset The ECU

    [evaluation]
    1.-
	2. FltEdrDataAreaFull not qualified.
	3.
	4. FltEdrDataAreaFull qualified for Inflatable and NonInflatabel deployment crashes.
	5. 
	6. CrashRecorder should not be Erased.
	7. 
	8. CrashRecorder Should be Erased.
	FltEdrDataAreaFull should be Erased.
	After Reset Fault Should not requalify

    [finalisation]
    Clear Crash Telegram and Fault memory
    ECU off

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

    purpose                  --> Purpose of the test case
    crash				  	 --> Type/name of crash
    count					 --> Number of crashes to be injected in step 1. e.g. 4
  	

=head2 PARAMETER EXAMPLES

    [TC_EDR_Functional_EDRDataAreaFull.SideInflatableDeployment]
	# From here on: applicable Lift Default Parameters
	purpose = 'to check EDR data area full fault and erasure of crash telegram'
	crash = 'SideInflatableDeployment'
	Disable_Erasure_of_EDR_data = 'E_EDRDevFuncState_SXR'
	count = '4'
	

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#Hashes to read the parameters from .par file  
my (%defaultpar_hash,
	%TCpar_hash);


#List of parameters in .par file
my @defaultpar_list 			= ('purpose',
								   'crash',
								   'count',
								   'Disable_Erasure_of_EDR_data');
my @TCpar_list 					= ();	   

				                  
#other TC specific constants/parameters from other files



#variables used in the test case
my ($flt_mem_struct_step2,
	$flt_mem_struct_step4,
	$flt_mem_struct_afterErasure,
	$flt_mem_struct_afterReset);
my $EdrDataAreaFullFault;
my ($EraseCDResponse_ErasureDisabled, $EraseCDResponse_ErasureEnabled);
my ($EDR_CD_response_ErasureDisabled_aref, $EDR_CD_response_ErasureEnabled_aref);
my $CrashInjectionStatus;
my $CrashInjectionStatus2;
our $PURPOSE;

sub TC_set_parameters {
		
	#read each default parameter from the .par file
	foreach my $defaultpar(@defaultpar_list){
		$defaultpar_hash{$defaultpar} =  GEN_Read_mandatory_testcase_parameter($defaultpar);
	}
	
	#read each test case parameter from the .par file
	foreach my $TCpar(@TCpar_list){
		$TCpar_hash{$TCpar} =  GEN_Read_mandatory_testcase_parameter($TCpar);
	}
	
	$PURPOSE = "$defaultpar_hash{'purpose'}";	
	
	#read other TC specific constants/parameters from other files
	$EdrDataAreaFullFault = "FltEdrDataAreaFull";
    
	return 1;

}

#### INITIALIZE TC #####
sub TC_initialization {

    S_w2rep('StandardPreparation', 'blue'); 
    PD_ClearCrashRecorder();
    GEN_StandardPrepNoFault();
        
  	return 1;
}


### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {
    
    my $crashcount = $defaultpar_hash{'count'};
    S_w2rep("Step1: Inject crash $crashcount times", 'blue');
    foreach(1..$crashcount){
    	$CrashInjectionStatus = EDR_InjectCrash($defaultpar_hash{'crash'}, 5000);  
    }
    
    unless (defined $CrashInjectionStatus and $CrashInjectionStatus == 1){
    	S_set_error("Crash is not injected successfully. Not proceeding!", 0);
    	$PURPOSE = "Crash not injected successfully";
		return 0;
    }
    
	S_w2rep("Step2:  Check Crash Recorder for FltEdrDataAreaFull fault", 'blue');
	$flt_mem_struct_step2 = PD_ReadFaultMemory();
	    
	S_w2rep("Step3:  Inject one more Crash", 'blue');
	$CrashInjectionStatus2 = EDR_InjectCrash($defaultpar_hash{'crash'}, 5000); 
	    
	unless (defined $CrashInjectionStatus2 and $CrashInjectionStatus2 == 1){
    	S_set_error("Second crash is not injected successfully. Not proceeding!", 0);
		return 0;
    }
	        
    S_w2rep("Step4:  Check Crash Recorder for FltEdrDataAreaFull fault", 'blue');
    $flt_mem_struct_step4 = PD_ReadFaultMemory();
    
    S_w2rep("Step5:  In Disable_Erasure_of_EDR_data EEPROM variable write value A5A5 and reset ECU", 'blue');
    my $value_aref = PD_ReadMemoryByName( $defaultpar_hash{'Disable_Erasure_of_EDR_data'} );
	#if(defined $value_aref and scalar(@$value_aref) != 1){ #no error in reading
		PD_WriteMemoryByName( $defaultpar_hash{'Disable_Erasure_of_EDR_data'}, [0xA5,0xA5] );
		GEN_Power_on_Reset ();
	#}
	
	S_w2rep("Step6:  Erase CrashRecorder", 'blue');
	$EraseCDResponse_ErasureDisabled = PD_ClearCrashRecorder();	
	$EDR_CD_response_ErasureDisabled_aref = EDR_CD_ReadEDR (1); 
	
	S_w2rep("Step7:  In Disable_Erasure_of_EDR_data EEPROM variable write previous value and reset ECU", 'blue');
	#if(defined $value_aref and scalar(@$value_aref) != 1){ #no error in reading
		PD_WriteMemoryByName( $defaultpar_hash{'Disable_Erasure_of_EDR_data'}, $value_aref );
		GEN_Power_on_Reset ();
	#}
	
	S_w2rep("Step8a:  Erase CrashRecorder", 'blue');
	$EraseCDResponse_ErasureEnabled = PD_ClearCrashRecorder();	
	S_wait_ms(5000, 'wait till EDR has been erased');
	S_w2rep("Read the CrashRecorder to check if erased/not erased", 'orange');
	$EDR_CD_response_ErasureEnabled_aref = EDR_CD_ReadEDR (1); 
	
	S_w2rep("Step8b:  FltEdrDataAreaFull fault after erasure", 'blue');
    $flt_mem_struct_afterErasure = PD_ReadFaultMemory();
      
    S_w2rep("Step8c:  FltEdrDataAreaFull fault after reset", 'blue');
    GEN_Power_on_Reset ();
    $flt_mem_struct_afterReset = PD_ReadFaultMemory();
        
  	return 1;
}


#### EVALUATE TC #####
sub TC_evaluation {
    
    unless(defined $EdrDataAreaFullFault and length $EdrDataAreaFullFault){
    	S_set_error("Error: EdrDataAreaFullFault name is not defined or is empty", 0);
    	return 0;
    }
	
	S_w2rep("Step2: FltEdrDataAreaFull not qualified", 'blue');
	my $status = PD_get_fault_status( $flt_mem_struct_step2, $EdrDataAreaFullFault );
	EVAL_evaluate_value ( "Fault status", '0', '==', $status  ); #fault is not present

	S_w2rep("Step4 and 8: FltEdrDataAreaFull qualified for Inflatable and NonInflatable deployment crashes", 'blue');
	if($defaultpar_hash{'crash'} =~ m/NoDeployment/){
		S_w2rep("FltEdrDataAreaFull is not qualified for NoDeployment crashes", 'blue');
		S_w2rep("Step 4: FltEdrDataAreaFull is not qualified", 'orange');
		$status = PD_get_fault_status( $flt_mem_struct_step4, $EdrDataAreaFullFault );
		EVAL_evaluate_value ( "Fault status after 5 crashes", '0', '==', $status  ); #fault is not present
		
		S_w2rep("Step 8b: FltEdrDataAreaFull is not qualified after erasure of CT", 'orange');
		$status = PD_get_fault_status( $flt_mem_struct_afterErasure, $EdrDataAreaFullFault );
		EVAL_evaluate_value ( "Fault status after 5 crashes and erasure", '0', '==', $status  ); #fault is not present
		
		S_w2rep("Step 8c: FltEdrDataAreaFull is not qualified after erasure of CT and reset", 'orange');
		$status = PD_get_fault_status( $flt_mem_struct_afterReset, $EdrDataAreaFullFault );
		EVAL_evaluate_value ( "Fault status after 5 crashes, erasure and reset", '0', '==', $status  ); #fault is not present
	}
	else{
		S_w2rep("Step 4: FltEdrDataAreaFull is qualified", 'orange');
		EVAL_check_fault_status($flt_mem_struct_step4, $EdrDataAreaFullFault, 0x1F); #fault is qualified
		
		S_w2rep("Step 8b: FltEdrDataAreaFull is erased after erasure of crash telegram", 'orange');
		my $statusAfterErasure = PD_get_fault_status( $flt_mem_struct_afterErasure, $EdrDataAreaFullFault );
		EVAL_evaluate_value ( "Fault status after CT erasure", $statusAfterErasure, '==', '0' ); #fault is not present
		
		S_w2rep("Step 8c: FltEdrDataAreaFull is erased after erasure of crash telegram and hard reset", 'orange');
		my $statusAfterErasureAndReset = PD_get_fault_status( $flt_mem_struct_afterReset, $EdrDataAreaFullFault );
		EVAL_evaluate_value ( "Fault status after CT erasure and reset", $statusAfterErasureAndReset, '==', '0'  ); #fault is not present
	}		
	
	S_w2rep("Step6: CrashRecorder should not be Erased", 'blue');
	EVAL_evaluate_value ( "erasure status", '0', '==', $EraseCDResponse_ErasureDisabled  ); #erase not successful
	EDR_CD_EVAL_checkStorageStatus($EDR_CD_response_ErasureDisabled_aref, 'Stored');					

	S_w2rep("Step8: CrashRecorder Should be Erased", 'blue');
	EVAL_evaluate_value ( "erasure status", '0', '!=', $EraseCDResponse_ErasureEnabled  ); #erase successful
	EDR_CD_EVAL_checkStorageStatus ($EDR_CD_response_ErasureEnabled_aref,'NotStored');
    
    return 1;
}

#### TC FINALIZATION #####
#-- set system to original state --##
sub TC_finalization {

    GEN_Finalization  ();
    
	return 1;
}


1;


__END__