#### TEST CASE MODULE
package TC_EDR_Functional_MissingDevice;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------
our $VERSION = q$Revision: 1.2 $;
our $HEADER = q$Header: EDR/TC_EDR_Functional_MissingDevice.pm 1.2 2013/05/10 20:28:00ICT ver6cob develop  $;
################################## 

#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general; 
use LIFT_evaluation;

use FuncLib_GEN_TNT;
use INCLUDES_project;
do "INCLUDES_project.pm";

##################################

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_Functional_MissingDevice  $Revision: 1.2 $

requires MLC,PD,CANoe,POWER and evaluation (setup already done in IC)

default state is faultfree ECU powered ON

=head1 PURPOSE

to check that device configuration is taken into account while reporting

=head1 TESTCASE DESCRIPTION 

    [initialisation]
    StandardPreparation

    [stimulation & measurement]
    1. Deconfigure some squibs and switches and also stop monitoring these devices (i.e. remove both Program and Monitor bit) and then Program the ECU.
	2. Inject a Front Inflatable deployment crash
	3. Read EDR1 through CD
	4. Read EDR Entry through CD OEM specific Service and Generic Data Service.

    [evaluation]
    1.-
	2. 
	3. EDIDs related to the not monitored squibs and switches are not reported.
	4. Both in Generic data and OEM specific data, EDIDs from 1000 to 1023 are Reported.

    [finalisation]
    Clear Crash Telegram and Fault memory
    ECU off

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

    purpose                  --> Purpose of the test case
  	

=head2 PARAMETER EXAMPLES

    [TC_EDR_Functional_MissingDevice.DeviceConfiguration]
	# From here on: applicable Lift Default Parameters
	purpose = 'to check that device configuration is taken into account while reporting'

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#Hashes to read the parameters from .par file  
my (%defaultpar_hash,
	%TCpar_hash);


#List of parameters in .par file
my @defaultpar_list 			= ('purpose');
my @TCpar_list 					= ();	   

				                  
#other TC specific constants/parameters from other files



#variables used in the test case
my ($EDR1_CD_response_aref, 
	$EDR1_OEM_CD_response_aref,
	$EDR1_Generic_CD_response_aref);
my $CrashInjectionStatus;
our $PURPOSE;

sub TC_set_parameters {
		
	#read each default parameter from the .par file
	foreach my $defaultpar(@defaultpar_list){
		$defaultpar_hash{$defaultpar} =  GEN_Read_mandatory_testcase_parameter($defaultpar);
	}
	
	#read each test case parameter from the .par file
	foreach my $TCpar(@TCpar_list){
		$TCpar_hash{$TCpar} =  GEN_Read_mandatory_testcase_parameter($TCpar);
	}
	
	$PURPOSE = "$defaultpar_hash{'purpose'}";	
	
	#read other TC specific constants/parameters from other files	
    
	return 1;

}

#### INITIALIZE TC #####
sub TC_initialization {

    S_w2rep('StandardPreparation', 'blue'); 
    EDR_StandardPreparation();
        
  	return 1;
}


### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {
    
    S_w2rep("Step1: Deconfigure some squibs and switches and also stop monitoring these devices (i.e. remove both Program and Monitor bit) and then Program the ECU.", 'blue');
    my $status = EDR_DeconfigureDevices();
    
    my $current_verdict = S_get_current_verdict ( ); #check verdict to see if there were any errors in the previous step!
    
    unless ($current_verdict eq 'VERDICT_PASS'){ #verdict should be VERDICT_PASS to proceed further
    	S_set_error("Changing the device configuration is not successful. Not proceeding!", 0);
    	$PURPOSE = "Changing the device configuration is not successful";
		return 0;
    } 
    
    S_w2rep("Step2:  Inject a Front Inflatable deployment crash", 'blue');
    $CrashInjectionStatus = EDR_InjectCrash('FrontInflatableDeployment' , 5000);   
    
    unless (defined $CrashInjectionStatus and $CrashInjectionStatus == 1){
    	S_set_error("Crash is not injected successfully. Not proceeding!", 0);
    	$PURPOSE = "Crash not injected successfully";
		return 0;
    }  
    
    S_w2rep("Step3:  Read EDR1 through CD", 'blue'); 
    $EDR1_CD_response_aref = EDR_CD_ReadEDR (1); 

	S_w2rep("Step4:  Read EDR Entry through CD OEM specific Service and Generic Data Service", 'blue'); 
    S_w2rep("Read OEM entry", 'orange'); 
    $EDR1_OEM_CD_response_aref = EDR_CD_ReadEDR_OEM (1); 
    S_w2rep("Read Generic EDR entry", 'orange'); 
    $EDR1_Generic_CD_response_aref = EDR_CD_ReadEDR_Generic (1); 
    
  	return 1;
}


#### EVALUATE TC #####
sub TC_evaluation {
	
	S_w2rep("Step3: EDIDs related to the not monitored squibs and switches are not reported", 'blue');				
	if($EDR1_CD_response_aref){ #check if array ref is not empty
		EDR_CD_CheckEDIDs_DeconfiguredDevices ($EDR1_CD_response_aref);
	}
	
	S_w2rep("Step4: Both in Generic data and OEM specific data, EDIDs from 1000 to 1023 are Reported", 'blue');				
	if($EDR1_OEM_CD_response_aref){ #check if array ref is not empty
		EDR_CD_CheckEDIDs_1000To1023 ($EDR1_OEM_CD_response_aref);
	}
	if($EDR1_Generic_CD_response_aref){ #check if array ref is not empty
		EDR_CD_CheckEDIDs_1000To1023 ($EDR1_Generic_CD_response_aref);
	}
    
    return 1;
}

#### TC FINALIZATION #####
#-- set system to original state --##
sub TC_finalization {
	
	EDR_ConfigureDevices();
    EDR_Finalization  ();
    
return 1;
}


1;


__END__