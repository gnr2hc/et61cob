#### TEST CASE MODULE
package TC_EDR_Functional_OverWritingInflatableDeploymentCrash;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------
our $VERSION = q$Revision: 1.5 $;
our $HEADER = q$Header: EDR/TC_EDR_Functional_OverWritingInflatableDeploymentCrash.pm 1.5 2013/11/28 13:58:33ICT ver6cob develop  $;
################################## 

#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general; 
use LIFT_evaluation;
use LIFT_PD;
use INCLUDES_Project;
##################################

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_Functional_OverWritingInflatableDeploymentCrash  $Revision: 1.5 $

requires MLC,PD,CANoe,POWER and evaluation (setup already done in IC)

default state is faultfree ECU powered ON

=head1 PURPOSE

To validate the Overwrite Strategy for InflatableDeployment Crash

=head1 TESTCASE DESCRIPTION 

    [initialisation]
    StandardPreparation

    [stimulation & measurement]
    1. Inject <Type> InflatableDeployment crashes (where the number of injected crashes are equal to the number of crash telegrams available in EEPROM)
	2. Read all Crash Telegrams through PD and CD
	3. Inject a <DifferentType1> InflatableDeployment crash
	4. Read all Crash Telegrams through PD and CD
	5. Inject a <DifferentType2> NonInflatableDeployment crash
	6. Read all Crash Telegrams through PD and CD
	7. Inject a <DifferentType3> NoDeployment crash
	8. Read all Crash Telegrams through PD and CD

    [evaluation]
	1.
	2. Crashes are stored in all telegrams
	3.
	4. No crash telegram is overwritten. All telegrams have the same content as in step 2
	5.
	6. No crash telegram is overwritten. All telegrams have the same content as in step 2
	7.
	8. No crash telegram is overwritten. All telegrams have the same content as in step 2

    [finalisation]
	Clear Crash Telegram and Fault memory
    ECU off

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

    purpose                  --> Purpose of the test case
    Type				  	 --> Type of InflatableDeployment crash to be injected in all CTs
    DifferentType1			 --> Type of next InflatableDeployment crash to be injected (different from previous type)
    DifferentType2			 --> Type of NonInflatableDeployment crash to be injected
    DifferentType3			 --> Type of NoDeployment crash to be injected
  	

=head2 PARAMETER EXAMPLES
	[TC_EDR_Functional_OverWritingInflatableDeploymentCrash.Front]
	DifferentType1 = 'SideDriver'
	DifferentType2 = 'Rear'
	DifferentType3 = 'Front'
	# From here on: applicable Lift Default Parameters
	purpose	 = 'to validate the Overwrite Strategy for InflatableDeployment Crash'
	Type =  'Front'

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#Hashes to read the parameters from .par file  
my (%defaultpar_hash,
	%TCpar_hash);


#List of parameters in .par file
my @defaultpar_list 			= ('purpose',
					   			   'Type');
my @TCpar_list 					= ('DifferentType1',
								   'DifferentType2',
								   'DifferentType3');	   

				                  
#other TC specific constants/parameters from other files


#variables used in the test case
my ($UniqueCrashNumber,
    $NumberOfCrashTelegrams);
my $CrashInjectionStatus;
my (@UniqueCrashNumber_Initial,
	@EDRresponse_aref_Empty,   
	@EDRresponse_aref_Initial,
	@UniqueCrashNumber_AfterInflatable,   
	@EDRresponse_aref_AfterInflatable,
	@UniqueCrashNumber_AfterNonInflatable,   
	@EDRresponse_aref_AfterNonInflatable,
	@UniqueCrashNumber_AfterNoDeployment,   
	@EDRresponse_aref_AfterNoDeployment);
 our $PURPOSE;   



sub TC_set_parameters {
	
	#read each default parameter from the .par file
	foreach my $defaultpar(@defaultpar_list){
		$defaultpar_hash{$defaultpar} =  GEN_Read_mandatory_testcase_parameter($defaultpar);
	}
	
	#read each test case parameter from the .par file
	foreach my $TCpar(@TCpar_list){
		$TCpar_hash{$TCpar} =  GEN_Read_mandatory_testcase_parameter($TCpar);
	}
	
	$PURPOSE = "$defaultpar_hash{'purpose'}";	
	
	#read other TC specific constants/parameters from other files
	$UniqueCrashNumber = 'S_Header_XXE.A_UniqueCrashNbr_U16X';
	$NumberOfCrashTelegrams = EDR_fetchNumberOfCrashTelegrams();
    
	return 1;

}

#### INITIALIZE TC #####
sub TC_initialization {

    GEN_printTestStep('StandardPreparation', 'blue'); 
    PD_ClearCrashRecorder();
    GEN_StandardPrepNoFault();
    
    #check that all CTs are empty
    foreach my $CT(1..$NumberOfCrashTelegrams){
    	GEN_printComment("precondition: check that EDR$CT is empty", 'orange');  	
    	$EDRresponse_aref_Empty[$CT] = EDR_CD_ReadEDR($CT);  	
    	EDR_CD_EVAL_checkStorageStatus ($EDRresponse_aref_Empty[$CT],'NotStored');
    }
        
  	return 1;
}


### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {
	
	my $index;
	  
    GEN_printTestStep("Step1: Inject $defaultpar_hash{'Type'} InflatableDeployment crashes (where the number of injected crashes are equal to the number of crash telegrams available in EEPROM)", 'blue');
    foreach(1..$NumberOfCrashTelegrams){
    	$CrashInjectionStatus = EDR_InjectCrash("$defaultpar_hash{'Type'}InflatableDeployment" , 5000);
    }
    
    unless (defined $CrashInjectionStatus and $CrashInjectionStatus == 1){
    	S_set_error("Crash is not injected successfully. Not proceeding!", 0);
    	$PURPOSE = "Crash not injected successfully";
		return 0;
    }
    	   	
   	GEN_printTestStep("Step2: Read CrashRecorder through PD and CD", 'blue'); 
   	foreach my $CT(1..$NumberOfCrashTelegrams){
   		#read Unique crash num in header - PD
   		GEN_printComment("step2: read Unique crash number in header using PD - for EDR$CT", 'orange');
   		if(defined $UniqueCrashNumber and length $UniqueCrashNumber){
   			$index = $CT-1;
    		$UniqueCrashNumber_Initial[$CT] = PD_ReadMemoryByName( "$UniqueCrashNumber($index)" ); #for each CT	
    	}
    	#read stored EDR data through CD
    	GEN_printComment("step2: read stored EDR data through CD - for EDR$CT", 'orange');
    	$EDRresponse_aref_Initial[$CT] = EDR_CD_ReadEDR($CT); 
    }
 
	GEN_printTestStep("Step3: Inject a $TCpar_hash{'DifferentType1'} InflatableDeployment crash", 'blue');
    $CrashInjectionStatus = EDR_InjectCrash("$TCpar_hash{'DifferentType1'}InflatableDeployment" , 5000);
    
	if(defined $CrashInjectionStatus and $CrashInjectionStatus == 1){
	    GEN_printTestStep("Step4: Read all Crash Telegrams through PD and CD", 'blue'); 
	   	foreach my $CT(1..$NumberOfCrashTelegrams){
	   		#read Unique crash num in header - PD
	   		GEN_printComment("step4: read Unique crash number in header using PD - for EDR$CT", 'orange');
	   		if(defined $UniqueCrashNumber and length $UniqueCrashNumber){
	   			$index = $CT-1;
	    		$UniqueCrashNumber_AfterInflatable[$CT] = PD_ReadMemoryByName( "$UniqueCrashNumber($index)" ); #for each CT
	    	}
	    	#read stored EDR data through CD
	    	GEN_printComment("step4: read stored EDR data through CD - for EDR$CT", 'orange');
	    	$EDRresponse_aref_AfterInflatable[$CT] = EDR_CD_ReadEDR($CT); 
	    }
	}
    
    
    GEN_printTestStep("Step5: Inject a $TCpar_hash{'DifferentType2'} NonInflatableDeployment crash", 'blue');
    $CrashInjectionStatus = EDR_InjectCrash("$TCpar_hash{'DifferentType2'}NonInflatableDeployment" , 5000);
    
	if(defined $CrashInjectionStatus and $CrashInjectionStatus == 1){
	    GEN_printTestStep("Step6: Read all Crash Telegrams through PD and CD", 'blue'); 
	   	foreach my $CT(1..$NumberOfCrashTelegrams){
	   		#read Unique crash num in header - PD
	   		GEN_printComment("step6: read Unique crash number in header using PD - for EDR$CT", 'orange');
	   		if(defined $UniqueCrashNumber and length $UniqueCrashNumber){
	   			$index = $CT-1;
	    		$UniqueCrashNumber_AfterNonInflatable[$CT] = PD_ReadMemoryByName( "$UniqueCrashNumber($index)" ); #for each CT
	    	}
	    	#read stored EDR data through CD
	    	GEN_printComment("step6: read stored EDR data through CD - for EDR$CT", 'orange');
	    	$EDRresponse_aref_AfterNonInflatable[$CT] = EDR_CD_ReadEDR($CT); 
	    }
	}
    
    GEN_printTestStep("Step7: Inject a $TCpar_hash{'DifferentType3'} NoDeployment crash", 'blue');
    $CrashInjectionStatus = EDR_InjectCrash("$TCpar_hash{'DifferentType3'}NoDeployment" , 5000);
    
	if(defined $CrashInjectionStatus and $CrashInjectionStatus == 1){
	    GEN_printTestStep("Step8: Read all Crash Telegrams through PD and CD", 'blue'); 
	   	foreach my $CT(1..$NumberOfCrashTelegrams){
	   		#read Unique crash num in header - PD
	   		GEN_printComment("step8: read Unique crash number in header using PD - for EDR$CT", 'orange');
	   		if(defined $UniqueCrashNumber and length $UniqueCrashNumber){
	   			$index = $CT-1;
	    		$UniqueCrashNumber_AfterNoDeployment[$CT] = PD_ReadMemoryByName( "$UniqueCrashNumber($index)" ); #for each CT
	    	}
	    	#read stored EDR data through CD
	    	GEN_printComment("step8: read stored EDR data through CD - for EDR$CT", 'orange');
	    	$EDRresponse_aref_AfterNoDeployment[$CT] = EDR_CD_ReadEDR($CT); 
	    }
	}
	return 1;
	
}


#### EVALUATE TC #####
sub TC_evaluation {
	
	my ($temp_aref1,$temp_aref2);
	
	#fetch the length of checksum and signature EDIDs and remove these bytes from the response (to compare the EDR entries without these data elements)
	my $checksumLength = EDR_fetchEDIDDataLength (1022); #EDID1022 - checksum
	my $signatureLength = EDR_fetchEDIDDataLength (1023); #EDID1022 - signature
	my $removableBytesNumber = $checksumLength + $signatureLength + 4; #(2 bytes for checksum EDID byte 03 FE + 2 bytes for signature EDID byte 03 FF)
	
	GEN_printTestStep("Step2: Crashes are stored in all telegrams", 'blue'); 
	#foreach my $CT(1..$NumberOfCrashTelegrams){
	#	EDR_CD_EVAL_checkStorageStatus ($EDRresponse_aref_Initial[$CT],'Stored');
	#}	
		
	GEN_printTestStep("Step4: No crash telegram is overwritten. All telegrams have the same content as in step 2", 'blue');				
	foreach my $CT(1..$NumberOfCrashTelegrams){
		#PD check
		GEN_printComment("step4: Checking that no crash is overwritten using PD - EDR$CT", 'orange');
		GEN_EVAL_CompareNumArrays ($UniqueCrashNumber_Initial[$CT], $UniqueCrashNumber_AfterInflatable[$CT], 'Equal');    		
		#CD check	
		$temp_aref1 = $EDRresponse_aref_Initial[$CT];
		$temp_aref2 = $EDRresponse_aref_AfterInflatable[$CT];		
		
		#remove the positive response bytes and header (since this may change after each crash)
		if(defined @$temp_aref1[0] and defined @$temp_aref2[0]){
			foreach (1..5){ 	
				shift(@$temp_aref1); 
				shift(@$temp_aref2); 
			}
			
			#remove the checksum and signature bytes (since this may change after each crash)
			my $offset = scalar (@$temp_aref1) - $removableBytesNumber;
			splice @$temp_aref1, $offset ;
			splice @$temp_aref2, $offset ;	
		}

		GEN_printComment("step4: Checking that no crash is overwritten using CD - read EDR$CT", 'orange');
		GEN_printComment("Compare EDR response for EDR$CT before and after injecting an inflatable crash. Both should be same");
		GEN_EVAL_CompareNumArrays ($temp_aref1, $temp_aref2,'Equal');
		
	}
	
	GEN_printTestStep("Step6: No crash telegram is overwritten. All telegrams have the same content as in step 2", 'blue');				
	foreach my $CT(1..$NumberOfCrashTelegrams){
		GEN_printComment("step6: Checking that no crash is overwritten using PD- EDR$CT", 'orange');
		GEN_EVAL_CompareNumArrays ($UniqueCrashNumber_Initial[$CT], $UniqueCrashNumber_AfterNonInflatable[$CT], 'Equal'); 		
		#CD check	
		$temp_aref1 = $EDRresponse_aref_Initial[$CT];
		$temp_aref2 = $EDRresponse_aref_AfterNonInflatable[$CT];
		
		#remove the positive response bytes and header (since this may change after each crash)
		if(defined @$temp_aref1[0] and defined @$temp_aref2[0]){
			foreach (1..5){ 	
				shift(@$temp_aref1); 
				shift(@$temp_aref2); 
			}	
			
			#remove the checksum and signature bytes (since this may change after each crash)
			my $offset = scalar (@$temp_aref1) - $removableBytesNumber;
			splice @$temp_aref1, $offset ;
			splice @$temp_aref2, $offset ;
		}

		GEN_printComment("step6: Checking that no crash is overwritten using CD - EDR$CT", 'orange');
		GEN_printComment("Compare EDR response for EDR$CT before and after injecting a non inflatable crash. Both should be same");
		GEN_EVAL_CompareNumArrays ($temp_aref1, $temp_aref2,'Equal');
	}
	
	GEN_printTestStep("Step8: No crash telegram is overwritten. All telegrams have the same content as in step 2", 'blue');				
	foreach my $CT(1..$NumberOfCrashTelegrams){
		GEN_printComment("step8: Checking that no crash is overwritten using PD - EDR$CT", 'orange');
		GEN_EVAL_CompareNumArrays ($UniqueCrashNumber_Initial[$CT], $UniqueCrashNumber_AfterNoDeployment[$CT],'Equal');
		#CD check	
		$temp_aref1 = $EDRresponse_aref_Initial[$CT];
		$temp_aref2 = $EDRresponse_aref_AfterNoDeployment[$CT];
		
		#remove the positive response bytes and header (since this may change after each crash)
		if(defined @$temp_aref1[0] and defined @$temp_aref2[0]){
			foreach (1..5){ 	
				shift(@$temp_aref1); 
				shift(@$temp_aref2); 
			}
			
			#remove the checksum and signature bytes (since this may change after each crash)
			my $offset= scalar (@$temp_aref1) - $removableBytesNumber;
			splice @$temp_aref1, $offset ;
			splice @$temp_aref2, $offset ;	
		}

		GEN_printComment("step8: Checking that no crash is overwritten using CD - EDR$CT", 'orange');
		GEN_printComment("Compare EDR response for EDR$CT before and after injecting a no deployment crash. Both should be same");
		GEN_EVAL_CompareNumArrays ($temp_aref1, $temp_aref2,'Equal');
	}
	
	
	
	return 1;

}

#### TC FINALIZATION #####
#-- set system to original state --##
sub TC_finalization {
            
    GEN_Finalization  ();
    
return 1;
}

#*******************************Summary Section*****************************************
foreach my $count(1..6){
		$UniqueCrashNumber_Initial[$count] = [0,1];
	}
	foreach my $count(1..6){
		$UniqueCrashNumber_AfterInflatable[$count] = [0,2];
	}
	foreach my $count(1..6){
		$UniqueCrashNumber_AfterNonInflatable[$count] = [3,3];
	}
	foreach my $count(1..6){
		$UniqueCrashNumber_AfterNoDeployment[$count] = [4,4];
	}

my $titles_aref = ['EDR Entry','Initial(Inflatable)', 'AfterInflatable', 'AfterNonInflatable', 'AfterNoDeployment'];
my $content_EDR1_aref = [1, "@{$UniqueCrashNumber_Initial[1]}", "@{$UniqueCrashNumber_AfterInflatable[1]}", "@{$UniqueCrashNumber_AfterNonInflatable[1]}", "@{$UniqueCrashNumber_AfterNoDeployment[1]}"];
my $content_EDR2_aref = [2, "@{$UniqueCrashNumber_Initial[2]}", "@{$UniqueCrashNumber_AfterInflatable[2]}", "@{$UniqueCrashNumber_AfterNonInflatable[2]}", "@{$UniqueCrashNumber_AfterNoDeployment[2]}"];
my $content_EDR3_aref = [3, "@{$UniqueCrashNumber_Initial[3]}", "@{$UniqueCrashNumber_AfterInflatable[3]}", "@{$UniqueCrashNumber_AfterNonInflatable[3]}", "@{$UniqueCrashNumber_AfterNoDeployment[3]}"];
my $content_EDR4_aref = [4, "@{$UniqueCrashNumber_Initial[4]}", "@{$UniqueCrashNumber_AfterInflatable[4]}", "@{$UniqueCrashNumber_AfterNonInflatable[4]}", "@{$UniqueCrashNumber_AfterNoDeployment[4]}"];
my $content_EDR5_aref = [5, "@{$UniqueCrashNumber_Initial[5]}", "@{$UniqueCrashNumber_AfterInflatable[5]}", "@{$UniqueCrashNumber_AfterNonInflatable[5]}", "@{$UniqueCrashNumber_AfterNoDeployment[5]}"];
my $content_EDR6_aref = [6, "@{$UniqueCrashNumber_Initial[6]}", "@{$UniqueCrashNumber_AfterInflatable[6]}", "@{$UniqueCrashNumber_AfterNonInflatable[6]}", "@{$UniqueCrashNumber_AfterNoDeployment[6]}"];

GEN_printTestStep("-----------------------Summary of Overwrite Strategy Test for Inflatable Crashes-----------------------");
GEN_printComment("PD: Unique Crash Number");
GEN_printTableToReport ($titles_aref,[$content_EDR1_aref, $content_EDR2_aref, $content_EDR3_aref, $content_EDR4_aref, $content_EDR5_aref, $content_EDR6_aref], 'yes');


1;


__END__