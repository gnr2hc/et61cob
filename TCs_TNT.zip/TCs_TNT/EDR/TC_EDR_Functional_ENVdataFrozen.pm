#### TEST CASE MODULE
package TC_EDR_Functional_ENVdataFrozen;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------
our $VERSION = q$Revision: 1.5 $;
our $HEADER = q$Header: EDR/TC_EDR_Functional_ENVdataFrozen.pm 1.5 2013/10/28 15:50:34ICT ver6cob develop  $;
################################## 

#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general; 
use LIFT_evaluation;
use LIFT_PD;
use INCLUDES_Project;
##################################

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_Functional_ENVdataFrozen  $Revision: 1.5 $

requires MLC,PD,CANoe,POWER and evaluation (setup already done in IC)

default state is faultfree ECU powered ON

=head1 PURPOSE

to validate the data elements belonging to Environmental data are frozen at start of event

=head1 TESTCASE DESCRIPTION 

    [initialisation]
    StandardPreparation

    [stimulation & measurement]
    1. a) Set Switch to state1
    b) Send CANSignal with value value1

	2. Inject any  Crash of Type NoDeployment/NonInflatable/Inflatable
	At the time of crash, immediately Change Switch to state2 and CANSignal to value2

	3. Read the EDIDs corresponding to Switch state and CANSignal using CD

    [evaluation]
    1
	2.
	3. Reported EDIDs should have the following data:
	state1_expected and 
	value1_expected

    [finalisation]
    Clear Crash Telegram and Fault memory
    ECU off

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

    purpose                  --> Purpose of the test case
    Switch					 --> name of the switch
	CANSignal				 --> label of the CAN signal
	state1					 --> state of switch to be set before crash
	state2					 --> state of switch to be set before crash
	value1					 --> value of CAN signal to be set before crash
	value2					 --> value of CAN signal to be set before crash
	state1_expected			 --> expected value to be reported in EDID corresponding to Switch
	value1_expected			 --> expected value to be reported in EDID corresponding to CANSignal
  	

=head2 PARAMETER EXAMPLES

    

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#Hashes to read the parameters from .par file  
my (%defaultpar_hash,
	%TCpar_hash);


#List of parameters in .par file
my @defaultpar_list 			= ('purpose',
					   			   'Switch',
					   			   'CANSignal');
my @TCpar_list 					= ('state1',
								   'state2',
								   'value1',
								   'value2');	   

				                  
#other TC specific constants/parameters from other files



#variables used in the test case
my $EDR_CD_response_aref;
my $NumberOfCrashTelegrams;
my $CrashInjectionStatus;
my $signalName;
my $switchName;
my ($EventType_EDR1, $EventType_EDR2);
our $PURPOSE;
my $switchData;
my $CANsignalData;

sub TC_set_parameters {
		
	#read each default parameter from the .par file
	foreach my $defaultpar(@defaultpar_list){
		$defaultpar_hash{$defaultpar} =  GEN_Read_mandatory_testcase_parameter($defaultpar);
	}
	
	#read each test case parameter from the .par file
	foreach my $TCpar(@TCpar_list){
		$TCpar_hash{$TCpar} =  GEN_Read_mandatory_testcase_parameter($TCpar);
	}
	$TCpar_hash{'state1_expected'} =  GEN_Read_mandatory_testcase_parameter('state1_expected','byref');
	$TCpar_hash{'value1_expected'} =  GEN_Read_mandatory_testcase_parameter('value1_expected','byref');
	
	$PURPOSE = "$defaultpar_hash{'purpose'}";	
	
	#read other TC specific constants/parameters from other files
    $NumberOfCrashTelegrams = EDR_fetchNumberOfCrashTelegrams ();
    $switchName = DEVICE_fetchDevicebyLabel ($defaultpar_hash{'Switch'});
    $signalName = COM_fetchSignalbyLabel ($defaultpar_hash{'CANSignal'});
    
	return 1;

}

#### INITIALIZE TC #####
sub TC_initialization {

    S_w2rep('StandardPreparation', 'blue'); 
    PD_ClearCrashRecorder();
    GEN_StandardPrepNoFault();
        
  	return 1;
}


### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {
    
    my $label;
    my $EDID_switch;
    my $EDID_CANsignal;
    
    S_w2rep("Step1a: Set Switch to state1", 'blue');
    my $status1 = DEVICE_setDeviceState($switchName,$TCpar_hash{'state1'});
    
    my $current_verdict = S_get_current_verdict ( ); #check verdict to see if there were any errors in the previous step!
    
    unless ($current_verdict eq 'VERDICT_PASS' or $current_verdict eq 'VERDICT_NONE'){ #verdict should be VERDICT_PASS (or NONE in offline mode) to proceed further
    	S_set_error("Switch State is not set successfully. Not proceeding!", 0);
    	$PURPOSE = "Switch State is not set successfully";
		return 0;
    }
    
    S_w2rep("Step1b: Send CANSignal with value value1", 'blue');
    my $status2 = COM_setSignalState($signalName,$TCpar_hash{'value1'});
    
    $current_verdict = S_get_current_verdict ( ); #check verdict to see if there were any errors in the previous step!
    
    unless ($current_verdict eq 'VERDICT_PASS' or $current_verdict eq 'VERDICT_NONE'){ #verdict should be VERDICT_PASS (or NONE in offline mode) to proceed further
    	S_set_error("CAN signal value is not set successfully. Not proceeding!", 0);
    	$PURPOSE = "CAN signal value is not set successfully";
		return 0;
    }
    
    S_w2rep("Step1c: Wait for 7 seconds", 'blue');
    S_wait_ms( '7000' );
    
    S_w2rep("Step2: Inject any crash. At the time of crash, immediately Change Switch to state2 and CANSignal to value2", 'blue');
    $CrashInjectionStatus = EDR_InjectCrash('FrontInflatableDeployment');
    DEVICE_setDeviceState($switchName,$TCpar_hash{'state2'});
    COM_setSignalState($signalName,$TCpar_hash{'value2'});
    
    unless (defined $CrashInjectionStatus and $CrashInjectionStatus == 1){
    	S_set_error("Crash is not injected successfully. Not proceeding!", 0);
    	$PURPOSE = "Crash not injected successfully";
		return 0;
    } 
    
    S_wait_ms( '10000' );
       
    S_w2rep("Step3: Read the EDIDs corresponding to Switch state and CANSignal using CD", 'blue');
    $EDR_CD_response_aref = EDR_CD_ReadEDR (1); 
       
    $EDID_switch = EDR_fetchEDIDbyLabel($defaultpar_hash{'Switch'});  
    $EDID_CANsignal = EDR_fetchEDIDbyLabel($defaultpar_hash{'CANSignal'});
    
	$switchData = EDR_CD_getEDIDdata ($EDR_CD_response_aref,$EDID_switch);
	$CANsignalData = EDR_CD_getEDIDdata ($EDR_CD_response_aref,$EDID_CANsignal); 
	
	    
  	return 1;
}


#### EVALUATE TC #####
sub TC_evaluation {
    
    S_w2rep("Step3: Reported EDIDs should have the following data: state1_expected and value1_expected", 'blue');
    GEN_EVAL_CompareNumArrays ($TCpar_hash{'state1_expected'},$switchData);
    GEN_EVAL_CompareNumArrays ($TCpar_hash{'value1_expected'},$CANsignalData);
	
    
    return 1;
}

#### TC FINALIZATION #####
#-- set system to original state --##
sub TC_finalization {

    GEN_Finalization  ();
    
return 1;
}


1;


__END__