#### TEST CASE MODULE
package TC_EDR_Functional_ParallelCrash_SingleCT;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------
our $VERSION = q$Revision: 1.5 $;
our $HEADER = q$Header: EDR/TC_EDR_Functional_ParallelCrash_SingleCT.pm 1.5 2013/10/28 15:50:31ICT ver6cob develop  $;
################################## 

#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general; 
use LIFT_evaluation;
use LIFT_PD;
use INCLUDES_Project;
##################################

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_Functional_ParallelCrash_SingleCT  $Revision: 1.5 $

requires MLC,PD,CANoe,POWER and evaluation (setup already done in IC)

default state is faultfree ECU powered ON

=head1 PURPOSE

to check that all incidents belonging to a parallel event are captured in the same Crash telegram

=head1 TESTCASE DESCRIPTION 

    [initialisation]
    StandardPreparation

    [stimulation & measurement]
    1. Inject a ParallelEvent crash
	2. Read All Crash Recorder Through CD

    [evaluation]
    1.-
	2. Only EDR1 has detected a Crash all other Crash Recorders are empty. Read Event Type.
	For parallel event containing a Rollover event this data corresponds to the respective crash in each crash telegram
	For parallel events (without Rollover event), the data is stored in a single EDR and corresponds to the first inflatable crash event (If there are no inflatable events, the data corresponding to the first non-inflatable event is stored. If there are no Non inflatable events, the data corresponding to the first NoDeployment event is stored)

    [finalisation]
    Clear Crash Telegram and Fault memory
    ECU off

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

    purpose                  --> Purpose of the test case
    crash				  	 --> Type/name of crash
  	

=head2 PARAMETER EXAMPLES

    [TC_EDR_Functional_ParallelCrash_SingleCT.FrontInflatable_SideDriverInflatable_Parallel]
	# From here on: applicable Lift Default Parameters
	purpose = 'to check that all incidents belonging to a parallel event are captured in the same Crash telegram'
	crash = 'FrontInflatable_SideDriverInflatable_Parallel'

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#Hashes to read the parameters from .par file  
my (%defaultpar_hash,
	%TCpar_hash);


#List of parameters in .par file
my @defaultpar_list 			= ('purpose',
					   			   'crash');
my @TCpar_list 					= ('EventType_EDR1');	   

				                  
#other TC specific constants/parameters from other files



#variables used in the test case
my @EDR_CD_response_aref;
my $NumberOfCrashTelegrams;
my $CrashInjectionStatus;
my ($EventType_EDR1, $EventType_EDR2);
our $PURPOSE;

sub TC_set_parameters {
		
	#read each default parameter from the .par file
	foreach my $defaultpar(@defaultpar_list){
		$defaultpar_hash{$defaultpar} =  GEN_Read_mandatory_testcase_parameter($defaultpar);
	}
	
	#read each test case parameter from the .par file
	foreach my $TCpar(@TCpar_list){
		$TCpar_hash{$TCpar} =  GEN_Read_mandatory_testcase_parameter($TCpar);
	}
	$TCpar_hash{'EventType_EDR2'} =  GEN_Read_optional_testcase_parameter('EventType_EDR2');
	
	$PURPOSE = "$defaultpar_hash{'purpose'}";	
	
	#read other TC specific constants/parameters from other files
    $NumberOfCrashTelegrams = EDR_fetchNumberOfCrashTelegrams();
    
	return 1;

}

#### INITIALIZE TC #####
sub TC_initialization {

    S_w2rep('StandardPreparation', 'blue'); 
    PD_ClearCrashRecorder();
    GEN_StandardPrepNoFault();
        
  	return 1;
}


### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {
    
    my $label;
    
    S_w2rep("Step1: Inject a ParallelEvent crash", 'blue');
    $CrashInjectionStatus = EDR_InjectCrash($defaultpar_hash{'crash'} , 10000);   
    
    unless (defined $CrashInjectionStatus and $CrashInjectionStatus == 1){
    	S_set_error("Crash is not injected successfully. Not proceeding!", 0);
    	$PURPOSE = "Crash not injected successfully";
		return 0;
    } 
       
    S_w2rep("Step2a: Read All Crash Recorders Through CD", 'blue');
    #read all EDRs
    foreach my $EDRcount(1..$NumberOfCrashTelegrams){
    	S_w2rep("Read EDR$EDRcount ", 'orange');
    	$EDR_CD_response_aref[$EDRcount-1] = EDR_CD_ReadEDR ($EDRcount); 
    }
       
    S_w2rep("Step2b: Read EventType values through CD", 'blue');	
    my $EDID_EventType = EDR_fetchEDIDbyLabel('EventType');
	if($defaultpar_hash{'crash'} =~ m/Rollover/i){
		$EventType_EDR1 = EDR_CD_getEDIDdata ($EDR_CD_response_aref[1],$EDID_EventType);
		$EventType_EDR2 = EDR_CD_getEDIDdata ($EDR_CD_response_aref[0],$EDID_EventType); #most recent entry
	}
	else{
		$EventType_EDR1 = EDR_CD_getEDIDdata ($EDR_CD_response_aref[0],$EDID_EventType); #most recent entry
	}
	    
  	return 1;
}


#### EVALUATE TC #####
sub TC_evaluation {
    
    if($defaultpar_hash{'crash'} =~ m/Rollover/i){#if this crash contains a rollover event
    	S_w2rep("Step2a: CD: First Crash Event is stored in CrashRecorder1 and second crash in CrashRecorder2", 'blue');
		S_w2rep("Check if EDR1 and EDR2 are not empty", 'orange');
    	EDR_CD_EVAL_checkStorageStatus($EDR_CD_response_aref[0], 'Stored');	
    	EDR_CD_EVAL_checkStorageStatus($EDR_CD_response_aref[1], 'Stored');	
    	
    	#remaining EDRs should be empty!
		foreach my $EDRcount(3..$NumberOfCrashTelegrams){
			if($EDR_CD_response_aref[$EDRcount-1]){ #check if array ref is not empty
				S_w2rep("Check if EDR$EDRcount is empty", 'orange');
				EDR_CD_EVAL_checkStorageStatus ($EDR_CD_response_aref[$EDRcount-1],'NotStored');
			}
		}
		
		S_w2rep("Step2b: check the Event Type", 'blue');
		if(defined $EventType_EDR1){
			S_w2rep("Event Type\n",'orange');
			S_w2rep("Expected: $TCpar_hash{'EventType_EDR1'} and $TCpar_hash{'EventType_EDR2'} \n Observed: @$EventType_EDR1[0] and @$EventType_EDR2[0]\n", 'blue'); 
			EVAL_evaluate_value ( "Event type EDR1", $TCpar_hash{'EventType_EDR1'}, '==', @$EventType_EDR1[0] );
			EVAL_evaluate_value ( "Event type EDR2", $TCpar_hash{'EventType_EDR2'}, '==', @$EventType_EDR2[0] );
		}
    }
    else{
    	S_w2rep("Step2a: CD: First Crash Event is stored in CrashRecorder1 and CrashRecorder2 is empty", 'blue');
		S_w2rep("Check if EDR1 is not empty", 'orange');
		EDR_CD_EVAL_checkStorageStatus($EDR_CD_response_aref[0], 'Stored');	
		#remaining EDRs should be empty!
		foreach my $EDRcount(2..$NumberOfCrashTelegrams){
			if($EDR_CD_response_aref[$EDRcount-1]){ #check if array ref is not empty
				S_w2rep("Check if EDR$EDRcount is empty", 'orange');
				EDR_CD_EVAL_checkStorageStatus ($EDR_CD_response_aref[$EDRcount-1],'NotStored');
			}
		}
		
		S_w2rep("Step2b: check the Event Type", 'blue');
		if(defined $EventType_EDR1){
			S_w2rep("Event Type\n",'orange');
			S_w2rep("Expected: $TCpar_hash{'EventType_EDR1'} \n Observed: @$EventType_EDR1[0]\n", 'blue'); 
			EVAL_evaluate_value ( "Event type EDR1", $TCpar_hash{'EventType_EDR1'}, '==', @$EventType_EDR1[0] );
		}
    }
	
	
    
    return 1;
}

#### TC FINALIZATION #####
#-- set system to original state --##
sub TC_finalization {

    GEN_Finalization  ();
    
return 1;
}


1;


__END__