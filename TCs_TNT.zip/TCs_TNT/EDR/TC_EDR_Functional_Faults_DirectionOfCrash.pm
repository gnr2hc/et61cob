#### TEST CASE MODULE
package TC_EDR_Functional_Faults_DirectionOfCrash;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------
our $VERSION = q$Revision: 1.7 $;
our $HEADER = q$Header: EDR/TC_EDR_Functional_Faults_DirectionOfCrash.pm 1.7 2014/02/20 19:07:17ICT ver6cob develop  $;
################################## 

#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general; 
use LIFT_evaluation;
use LIFT_PD;
use LIFT_CD;
use INCLUDES_Project;
##################################

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_Functional_Faults_DirectionOfCrash  $Revision: 1.7 $

requires MLC,PD,CANoe,POWER and evaluation (setup already done in IC)

default state is faultfree ECU powered ON

=head1 PURPOSE

check for faults based on crash direction in case of deployment events

=head1 TESTCASE DESCRIPTION 

    [initialisation]
    StandardPreparation

    [stimulation & measurement]
    1. Inject a crash
	2. Read fault Recorder through CD. 19 02 FF
	3. Switch OFF and switch ON the ECU and read the fault recorder through CD

    [evaluation]
    1.
	2. <fault> is in qualified state
	3. <fault> is in dequalified state (not active)

    [finalisation]
    Clear Crash Telegram and Fault memory
    ECU off

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

    purpose                  --> Purpose of the test case
    crash				  	 --> Type/name of crash
  	

=head2 PARAMETER EXAMPLES

    [TC_EDR_Functional_Faults_DirectionOfCrash.SideDriverInflatableDeployment]
	fault = 'FltSideCrashDrDetected'
	# From here on: applicable Lift Default Parameters
	purpose = 'check for faults based on crash direction in case of deployment events'
	crash = 'SideDriverInflatableDeployment'
	

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#Hashes to read the parameters from .par file  
my (%defaultpar_hash,
	%TCpar_hash);


#List of parameters in .par file
my @defaultpar_list 			= ('purpose',
								   'crash');
my @TCpar_list 					= ('fault');	   

				                  
#other TC specific constants/parameters from other files


#variables used in the test case
my $DTC_struct_beforeReset;
my $DTC_struct_afterReset;
my $CrashInjectionStatus;
our $PURPOSE;

sub TC_set_parameters {
		
	#read each default parameter from the .par file
	foreach my $defaultpar(@defaultpar_list){
		$defaultpar_hash{$defaultpar} =  GEN_Read_mandatory_testcase_parameter($defaultpar);
	}
	
	#read each test case parameter from the .par file
	foreach my $TCpar(@TCpar_list){
		$TCpar_hash{$TCpar} =  GEN_Read_mandatory_testcase_parameter($TCpar);
	}
	
	#purpose statement
	$PURPOSE = "$defaultpar_hash{'purpose'}";	
	
	#read other TC specific constants/parameters from other files
    
	return 1;

}

#### INITIALIZE TC #####
sub TC_initialization {

    S_w2rep('StandardPreparation', 'blue'); 
    PD_ClearCrashRecorder();
    GEN_StandardPrepNoFault();
        
  	return 1;
}


### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {
    
    S_w2rep("Step1: Inject a crash", 'blue');
    $CrashInjectionStatus = EDR_InjectCrash($defaultpar_hash{'crash'} , 10000);  
    	
    unless (defined $CrashInjectionStatus and $CrashInjectionStatus == 1){
    	S_set_error("Condition is not created successfully. Not proceeding!", 0);
    	$PURPOSE = "Crash not injected successfully";
		return 0;
    }
    		
 	S_w2rep("Step2:  Read fault Recorder through CD. 19 02 service", 'blue');
	S_wait_ms ( '2000' );
	PD_ReadFaultMemory();
	S_wait_ms ( '2000' );
	$DTC_struct_beforeReset = CD_read_DTC('0x02','0x08');
	
	S_w2rep("Step3:  Switch OFF and switch ON the ECU and read the fault recorder through CD", 'blue');
	GEN_Power_on_Reset();	
	PD_ReadFaultMemory();
	S_wait_ms ( '2000' );
	$DTC_struct_afterReset = CD_read_DTC('0x02','0x08');
	 	     
  	return 1;
}


#### EVALUATE TC #####
sub TC_evaluation {
		
	S_w2rep("Step2: fault is in qualified state", 'blue');
	CD_check_fault_status( $DTC_struct_beforeReset, $TCpar_hash{'fault'}, '0bxxxx1xx1' );
	
	S_w2rep("Step3: fault is in dequalified state (not active)", 'blue');
	CD_check_fault_status( $DTC_struct_afterReset, $TCpar_hash{'fault'}, '0bxxxx1xx0' );
	    
    return 1;
}

#### TC FINALIZATION #####
#-- set system to original state --##
sub TC_finalization {

    GEN_Finalization  ();
    
return 1;
}


1;


__END__