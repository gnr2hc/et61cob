#### TEST CASE MODULE
package TC_EDR_Functional_InhibitCrashRecording;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------
our $VERSION = q$Revision: 1.5 $;
our $HEADER = q$Header: EDR/TC_EDR_Functional_InhibitCrashRecording.pm 1.5 2013/10/28 15:50:33ICT ver6cob develop  $;
################################## 

#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general; 
use LIFT_evaluation;
use LIFT_PD;
use INCLUDES_Project;
use GENERIC_DCOM;
##################################

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_Functional_InhibitCrashRecording  $Revision: 1.5 $

requires MLC,PD,CANoe,POWER and evaluation (setup already done in IC)

default state is faultfree ECU powered ON

=head1 PURPOSE

To Validate the Inhibit Crash Recording feature

=head1 TESTCASE DESCRIPTION 

    [initialisation]
    StandardPreparation

    [stimulation & measurement]
    1. Set status of InhibitCrashRecording feature 
	2. ResetECU. Wait for few seconds.
	3. Creat any SingleEvent Crash
	4. Read EDR1 through CD
	5. Creat any SingleEvent Crash
	6. Read EDR1 through CD

    [evaluation]
    4. CrashRecorder1 <StoreStatus>. 
	5. -
	6. CrashRecorder2 <StoreStatus>. 

    [finalisation]
    remove the InhibitCrashRecording feature
    Clear Crash Telegram and Fault memory
    ECU off

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

    purpose                  --> Purpose of the test case
    InhibitCrashRecording	 --> feature is Active/NotActive
  	

=head2 PARAMETER EXAMPLES

    [TC_EDR_Functional_InhibitCrashRecording.NotActive]
	StoreStatus = 'CrashStored'
	# From here on: applicable Lift Default Parameters
	purpose = 'To Validate When Inhibit Crash Recording is Set Crash Should not be Recorded'
	InhibitCrashRecording = 'NotActive'

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#Hashes to read the parameters from .par file  
my (%defaultpar_hash,
	%TCpar_hash);


#List of parameters in .par file
my @defaultpar_list 			= ('purpose',
					   			   'InhibitCrashRecording');
my @TCpar_list 					= ('StoreStatus');	   

				                  
#other TC specific constants/parameters from other files



#variables used in the test case
my ($EDR_CD_response1_aref, $EDR_CD_response2_aref);
my $CrashInjectionStatus;
my $CrashInjectionStatus2;
our $PURPOSE;

sub TC_set_parameters {
		
	#read each default parameter from the .par file
	foreach my $defaultpar(@defaultpar_list){
		$defaultpar_hash{$defaultpar} =  GEN_Read_mandatory_testcase_parameter($defaultpar);
	}
	
	#read each test case parameter from the .par file
	foreach my $TCpar(@TCpar_list){
		$TCpar_hash{$TCpar} =  GEN_Read_mandatory_testcase_parameter($TCpar);
	}
	
	$PURPOSE = "$defaultpar_hash{'purpose'}";	
	
	#read other TC specific constants/parameters from other files

    
	return 1;

}

#### INITIALIZE TC #####
sub TC_initialization {

    S_w2rep('StandardPreparation', 'blue'); 
    PD_ClearCrashRecorder();
    GEN_StandardPrepNoFault();
        
  	return 1;
}


### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {
    
    my $EDRentry = 1; #check for 1st EDR entry
    
    S_w2rep("Step1: Set status of InhibitCrashRecording feature", 'blue');
    my $inhibitstatus = EDR_setInhibitRecordingStatus ($defaultpar_hash{'InhibitCrashRecording'});
	
	my $current_verdict = S_get_current_verdict ( ); #check verdict to see if there were any errors in the previous step!
    
    unless ($current_verdict eq 'VERDICT_PASS' or $current_verdict eq 'VERDICT_NONE'){ #verdict should be VERDICT_PASS (or NONE in offline mode) to proceed further
    	S_set_error("Status is not set successfully. Not proceeding!", 0);
    	$PURPOSE = "Status is not set successfully";
		return 0;
    }
    
    S_w2rep("Step2: ResetECU. Wait for few seconds", 'blue');
    GEN_Power_on_Reset ();

    S_w2rep("Step3: Creat any SingleEvent Crash", 'blue');
    $CrashInjectionStatus = EDR_InjectCrash('FrontNoDeployment' , 10000);  
    
    unless (defined $CrashInjectionStatus and $CrashInjectionStatus == 1){
    	S_set_error("Crash is not injected successfully. Not proceeding!", 0);
    	$PURPOSE = "Crash not injected successfully";
		return 0;
    }
    
	my %hash_ref;
	$hash_ref{'EDRentry'} = $EDRentry;
    S_w2rep("Step4: Read EDR1 through CD", 'blue');
    if($defaultpar_hash{'InhibitCrashRecording'} eq 'Active'){			
		GDCOM_request_general ("REQ_RoutineControl_EDRCalculateSignature_StartRoutine", "NR_conditionsNotCorrect" ,\%hash_ref);
		GDCOM_request_general ("REQ_RoutineControl_EDRCalculateCRC_StartRoutine", "NR_conditionsNotCorrect",\%hash_ref);		
		GDCOM_request_general ("REQ_ReadDatabyID_FA13_GenericEDREntry", "NR_conditionsNotCorrect");
	}
	else{
		$EDR_CD_response1_aref = EDR_CD_ReadEDR ($EDRentry); 
	}
    
    S_w2rep("Step5: Creat any SingleEvent Crash", 'blue');
    $CrashInjectionStatus2 = EDR_InjectCrash('FrontInflatableDeployment' , 10000); 
    
    unless (defined $CrashInjectionStatus2 and $CrashInjectionStatus2 == 1){
    	S_set_error("Second crash is not injected successfully. Not proceeding!", 0);
		return;
    }   
    
    S_w2rep("Step6: Read EDR1 through CD", 'blue');
	if($defaultpar_hash{'InhibitCrashRecording'} eq 'Active'){
		GDCOM_request_general ("REQ_RoutineControl_EDRCalculateSignature_StartRoutine", "NR_conditionsNotCorrect" ,\%hash_ref);
		GDCOM_request_general ("REQ_RoutineControl_EDRCalculateCRC_StartRoutine", "NR_conditionsNotCorrect" ,\%hash_ref);		
		GDCOM_request_general ("REQ_ReadDatabyID_FA13_GenericEDREntry", "NR_conditionsNotCorrect");
	}
	else{
		$EDR_CD_response2_aref = EDR_CD_ReadEDR ($EDRentry); 
	}

  	return 1;
}


#### EVALUATE TC #####
sub TC_evaluation {
    
	S_w2rep("Step4: CrashRecorder1 StoreStatus", 'blue');
	if($TCpar_hash{'StoreStatus'} eq 'NRC22'){
		S_w2rep("This step is evaluated in stimulation and measurement step 4", 'orange');
	}
	elsif($TCpar_hash{'StoreStatus'} eq 'CrashStored'){
		S_w2rep("check that EDR1 is not empty", 'orange');
		EDR_CD_EVAL_checkStorageStatus($EDR_CD_response1_aref, 'Stored');				
	}
	
	unless (defined $CrashInjectionStatus2 and $CrashInjectionStatus2 == 1){
    	S_set_error("Second crash is not injected successfully. Not proceeding!", 0);
		return 0;
    }
	
	S_w2rep("Step6: CrashRecorder2 StoreStatus", 'blue');
	if($TCpar_hash{'StoreStatus'} eq 'NRC22'){
		S_w2rep("This step is evaluated in stimulation and measurement step 6", 'orange');
	}
	elsif($TCpar_hash{'StoreStatus'} eq 'CrashStored'){
		S_w2rep("check that EDR2 is not empty", 'orange');
		EDR_CD_EVAL_checkStorageStatus($EDR_CD_response2_aref, 'Stored');				
	}

    return 1;
}

#### TC FINALIZATION #####
#-- set system to original state --##
sub TC_finalization {
    
    EDR_setInhibitRecordingStatus ('NotActive');        
    GEN_Finalization  ();
    
return 1;
}




1;


__END__