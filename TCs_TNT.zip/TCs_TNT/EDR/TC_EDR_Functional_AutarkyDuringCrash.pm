#### TEST CASE MODULE
package TC_EDR_Functional_AutarkyDuringCrash;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
###-------------------------------
our $VERSION = q$Revision: 1.4 $;
our $HEADER = q$Header: EDR/TC_EDR_Functional_AutarkyDuringCrash.pm 1.4 2013/08/14 11:54:32ICT ver6cob develop  $;
################################## 

#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general; 
use LIFT_evaluation;
use LIFT_PD;
use LIFT_POWER; 
use INCLUDES_Project;
##################################

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_Functional_AutarkyDuringCrash  $Revision: 1.4 $

requires MLC,PD,CANoe,POWER and evaluation (setup already done in IC)

default state is faultfree ECU powered ON

=head1 PURPOSE

to check the recording of data during autarky

=head1 TESTCASE DESCRIPTION 

    [initialisation]
    StandardPreparation

    [stimulation & measurement]
    1. Inject a <crash> and immediately switch off the ECU
	2. Switch ON the ECU and read the EDR using CD

    [evaluation]
    1.-
	2. 2. 
	a. Crash is stored. 
	EDID for 'Complete file recorded' data element shows that data is recorded incompletely (0x00). 
	If crash is stored completely, then this data element has value 0xA5 (completed successfully) 

	b. EDID 1 to EDID 500 and EDID 1000 to EDID 1024
	are reported with valid data and non default data

    [finalisation]
    Clear Crash Telegram and Fault memory
    ECU off

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

    purpose                  --> Purpose of the test case
    crash				  	 --> Type/name of crash
  	

=head2 PARAMETER EXAMPLES

    [TC_EDR_Functional_AutarkyDuringCrash.FrontInflatableDeployment]
	# From here on: applicable Lift Default Parameters
	purpose = 'to check the recording of data during autarky'
	crash = 'FrontInflatableDeployment'

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#Hashes to read the parameters from .par file  
my (%defaultpar_hash,
	%TCpar_hash);


#List of parameters in .par file
my @defaultpar_list 			= ('purpose',
					   			   'crash');
my @TCpar_list 					= ();	   

				                  
#other TC specific constants/parameters from other files



#variables used in the test case
my ($EDR_CD_response_aref);
my ($CrashValidity_EDR1);
my ($RecordValidity_GEN_EDR1);
my $CrashInjectionStatus;
our $PURPOSE;

sub TC_set_parameters {
	
	#read each default parameter from the .par file
	foreach my $defaultpar(@defaultpar_list){
		$defaultpar_hash{$defaultpar} =  GEN_Read_mandatory_testcase_parameter($defaultpar);
	}
	
	#read each test case parameter from the .par file
	foreach my $TCpar(@TCpar_list){
		$TCpar_hash{$TCpar} =  GEN_Read_mandatory_testcase_parameter($TCpar);
	}
	
	$PURPOSE = "$defaultpar_hash{'purpose'}";	
	
	#read other TC specific constants/parameters from other files

    
	return 1;

}

#### INITIALIZE TC #####
sub TC_initialization {

    S_w2rep('StandardPreparation', 'blue'); 
    PD_ClearCrashRecorder();
    GEN_StandardPrepNoFault();
        
  	return 1;
}


### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {
    
    my $label;
    
    S_w2rep("Step1: Inject a crash and immediately switch off the ECU", 'blue');
    POW_off();
    S_wait_ms(50);    
	$CrashInjectionStatus = EDR_InjectCrash($defaultpar_hash{'crash'});  
    S_wait_ms('TIMER_ECU_OFF');   
	POW_on();
    S_wait_ms( 'TIMER_ECU_READY' );
    
    unless (defined $CrashInjectionStatus and $CrashInjectionStatus == 1){
    	S_set_error("Crash is not injected successfully. Not proceeding!", 0);
    	$PURPOSE = "Crash not injected successfully";
		return 0;
    }
    	
    S_w2rep("Step2:  Switch ON the ECU and read EDR through CD", 'blue');  
    $EDR_CD_response_aref = EDR_CD_ReadEDR (1); #read EDR1
	
  	return 1;
}


#### EVALUATE TC #####
sub TC_evaluation {			
	
	S_w2rep("Step2a: Crash is stored. EDID for 'Complete file recorded' data element shows that data is recorded incompletely (0x00). If crash is stored completely, then this data element has value 0xA5 (completed successfully) ", 'blue');
	EDR_CD_EVAL_checkStorageStatus($EDR_CD_response_aref, 'Stored_CompleteFileNotRecorded');
	
	S_w2rep("Step2b: EDID 1 to EDID 500 and EDID 1000 to EDID 1024 are reported with valid data and non default data", 'blue');
	S_set_verdict ( 'VERDICT_INCONC' );
	S_set_error("This step needs to be verified manually. So verdict is set to INCONC!",0);
	S_set_error("Look at the EDR response and check EDIDs 1 to 500 and EDID 1000 to EDID 1024. It should have valid non default data!", 0);	
	
    return 1;
}

#### TC FINALIZATION #####
#-- set system to original state --##
sub TC_finalization {

    GEN_Finalization  ();
    
return 1;
}


1;


__END__