#### TEST CASE MODULE
package TC_EDR_Functional_DefaultValueOfErasedCrashTelegram;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------
our $VERSION = q$Revision: 1.4 $;
our $HEADER = q$Header: EDR/TC_EDR_Functional_DefaultValueOfErasedCrashTelegram.pm 1.4 2013/11/28 13:58:34ICT ver6cob develop  $;
################################## 


#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general; 
use LIFT_evaluation;
use LIFT_PD;
use INCLUDES_Project;
##################################

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_Functional_DefaultValueOfErasedCrashTelegram  $Revision: 1.4 $

requires MLC,PD,CANoe,POWER and evaluation (setup already done in IC)

default state is faultfree ECU powered ON

=head1 PURPOSE

To Validate For Default values stored in different conditions

=head1 TESTCASE DESCRIPTION 

    [initialisation]
    StandardPreparation

    [stimulation & measurement]
    1. Initialize NVM. ResetECU and read Header section in NVM
	2. Read EDR1 through CD
	3. Inject crash
	4. EraseCrashRecorder
	5. Read EDR1 through CD
	6. Read Header section in NVM

    [evaluation]
    1. Header section variables have default value 0x00
	2. CrashTelegram has default Values 0xFF
	3. -
	5. CrashTelegram has Default Values 0xFF
	6. Header section variables have default value 0x00

    [finalisation]
    Clear Crash Telegram and Fault memory
    ECU off

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

    purpose                  --> Purpose of the test case
    crash				  	 --> Type/name of crash
  	

=head2 PARAMETER EXAMPLES

    [TC_EDR_Functional_DefaultValueOfErasedCrashTelegram.FrontNoDeployment]
	# From here on: applicable Lift Default Parameters
	purpose = 'To Validate For Default values stored in different conditions'
	crash = 'FrontNoDeployment'

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#Hashes to read the parameters from .par file  
my (%defaultpar_hash,
	%TCpar_hash);


#List of parameters in .par file
my @defaultpar_list 			= ('purpose',
					   			   'crash');
my @TCpar_list 					= ();	   

				                  
#other TC specific constants/parameters from other files
my $EEPROM_path;


#variables used in the test case
my ($EDRheader_NVM_val_aref1, $EDRheader_NVM_val_aref2);
my ($EDR_CD_response1_aref, $EDR_CD_response2_aref);
my $CrashInjectionStatus;
my $EERPOM_dump;
#my $NumberOfCrashTelegrams;
our $PURPOSE;

my $header_LockedStatus_default;
my $header_CrashType_default;
my $header_CrashValid_default;
my $header_MultiEventNum_default;
my $header_UniqueCrashNum_default;
my $header_LockedStatus_AfterErase;
my $header_CrashType_AfterErase;
my $header_CrashValid_AfterErase;
my $header_MultiEventNum_AfterErase;
my $header_UniqueCrashNum_AfterErase;

sub TC_set_parameters {
	
	#read each default parameter from the .par file
	foreach my $defaultpar(@defaultpar_list){
		$defaultpar_hash{$defaultpar} =  GEN_Read_mandatory_testcase_parameter($defaultpar);
	}
	
	#read each test case parameter from the .par file
	foreach my $TCpar(@TCpar_list){
		$TCpar_hash{$TCpar} =  GEN_Read_mandatory_testcase_parameter($TCpar);
	}
	
	$PURPOSE = "$defaultpar_hash{'purpose'}";	
	
	unless (defined $LIFT_config::EEPROM_file){ #check if EEPROM path is declared in CFG
    	S_set_error("EEPROM path is not found in CFG file. Not proceeding!", 0);
    	$PURPOSE = "EEPROM path is not found in CFG file";
		return 0;
    }
	
	#read other TC specific constants/parameters from other files	
    #$NumberOfCrashTelegrams = EDR_fetchNumberOfCrashTelegrams();
    
	return 1;

}

#### INITIALIZE TC #####
sub TC_initialization {

    S_w2rep('StandardPreparation', 'blue'); 
    PD_ClearCrashRecorder();
    GEN_StandardPrepNoFault();
    
    S_w2rep("Dump EEPROM and re-initialize at the end of test case", 'blue');
	$EERPOM_dump = "$main::REPORT_PATH/_snapshot_/EDR_EEPROM_dump.hex";
    PD_DumpEEPROM( $EERPOM_dump );
        
  	return 1;
}


### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {
    
    my $EDRentry = 1; #check for 1st EDR entry
    
    S_w2rep("Step1: Initialize NVM. ResetECU and read Header section in NVM", 'blue');
    PD_InitEEPROM( $LIFT_config::EEPROM_file );
    GEN_printComment("reset ECU");	
    GEN_Power_on_Reset();
    S_wait_ms(6000, "wait after reset");
	
	my $current_verdict = S_get_current_verdict ( ); #check verdict to see if there were any errors in the previous step!
    
    unless ($current_verdict eq 'VERDICT_PASS' or $current_verdict eq 'VERDICT_NONE'){ #verdict should be VERDICT_PASS to proceed further
    	S_set_error("EEPROM is not initialized successfully. Not proceeding!", 0);
    	$PURPOSE = "EEPROM is not initialized successfully";
		return 0;
    }
    
    $header_LockedStatus_default = PD_ReadMemoryByName( "S_Header_XXE.A_CrashEntryLocked_XEX(0)" );
    $header_CrashType_default = PD_ReadMemoryByName( "S_Header_XXE.A_CrashType_U8X(0)" );
    $header_CrashValid_default = PD_ReadMemoryByName( "S_Header_XXE.A_CrashValid_U8X(0)" );
    $header_MultiEventNum_default = PD_ReadMemoryByName( "S_Header_XXE.A_MultiEventNumber_U16X(0)" );
    $header_UniqueCrashNum_default = PD_ReadMemoryByName( "S_Header_XXE.A_UniqueCrashNbr_U16X(0)" );
                
    S_w2rep("Step2: Read EDR1 through CD", 'blue');
    $EDR_CD_response1_aref = EDR_CD_ReadEDR ($EDRentry); 
    
    S_w2rep("Step3: Inject crash", 'blue');
    GEN_printComment("Re-initialize EEPROM to bring the system back to normal state and then inject crash (so that crash will be detected)");	
    PD_InitEEPROM( $EERPOM_dump );
    GEN_Power_on_Reset();
    S_wait_ms(6000, "wait after reset");
    $CrashInjectionStatus = EDR_InjectCrash($defaultpar_hash{'crash'}, 5000);  
    
    unless (defined $CrashInjectionStatus and $CrashInjectionStatus == 1){
    	S_set_error("Crash is not injected successfully. Not proceeding!", 0);
    	$PURPOSE = "Crash not injected successfully";
		return 0;
    }  
	
	if(defined $CrashInjectionStatus and $CrashInjectionStatus == 1){ 
		S_w2rep("Step4: EraseCrashRecorder", 'blue');
		PD_ClearCrashRecorder();
		S_wait_ms ( '5000', "wait after erasure" );
	    
	    S_w2rep("Step5: Read EDR1 through CD", 'blue');
	    $EDR_CD_response2_aref = EDR_CD_ReadEDR ($EDRentry); 
	    
	    S_w2rep("Step6: Read Header section in NVM", 'blue');
		$header_LockedStatus_AfterErase = PD_ReadMemoryByName( "S_Header_XXE.A_CrashEntryLocked_XEX(0)" );
	    $header_CrashType_AfterErase = PD_ReadMemoryByName( "S_Header_XXE.A_CrashType_U8X(0)" );
	    $header_CrashValid_AfterErase = PD_ReadMemoryByName( "S_Header_XXE.A_CrashValid_U8X(0)" );
	    $header_MultiEventNum_AfterErase = PD_ReadMemoryByName( "S_Header_XXE.A_MultiEventNumber_U16X(0)" );
	    $header_UniqueCrashNum_AfterErase = PD_ReadMemoryByName( "S_Header_XXE.A_UniqueCrashNbr_U16X(0)" );
	}
	
  	return 1;
}


#### EVALUATE TC #####
sub TC_evaluation {
	
	S_w2rep("Step1: Header section variables have default value 0x00 or 0xFF", 'blue');
	EVAL_evaluate_value ("Header: Locked status", S_aref2hex($header_LockedStatus_default), '==', 0x00);
	EVAL_evaluate_value ("Header: Crash Type", S_aref2hex($header_CrashType_default), '==', 0x00);
	EVAL_evaluate_value ("Header: Crash Validity", S_aref2hex($header_CrashValid_default), '==', 0x00);
	EVAL_evaluate_value ("Header: Multi Event Number", S_aref2hex($header_MultiEventNum_default), '==', 0x00);
	EVAL_evaluate_value ("Header: Unique Crash Number", S_aref2hex($header_UniqueCrashNum_default), '==', 0x00);
	
	S_w2rep("Step2: response has default value 0x00", 'blue');
	EDR_CD_EVAL_checkStorageStatus ($EDR_CD_response1_aref,'NotStored');
	
	unless (defined $CrashInjectionStatus and $CrashInjectionStatus == 1){
    	S_set_error("Crash is not injected successfully. Not proceeding!", 0);
		return 0;
    }
	
	S_w2rep("Step5: response has default value 0x00", 'blue');	
	EDR_CD_EVAL_checkStorageStatus ($EDR_CD_response2_aref,'NotStored');
		
	S_w2rep("Step6: Header section variables have default value 0x00 or 0xFF", 'blue');	
	EVAL_evaluate_value ("Header: Locked status", S_aref2hex($header_LockedStatus_AfterErase), '==', 0x00);
	EVAL_evaluate_value ("Header: Crash Type", S_aref2hex($header_CrashType_AfterErase), '==', 0x00);
	EVAL_evaluate_value ("Header: Crash Validity", S_aref2hex($header_CrashValid_AfterErase), '==', 0x00);
	EVAL_evaluate_value ("Header: Multi Event Number", S_aref2hex($header_MultiEventNum_AfterErase), '==', 0x00);
	EVAL_evaluate_value ("Header: Unique Crash Number", S_aref2hex($header_UniqueCrashNum_AfterErase), '==', 0x00);
	 
    return 1;
}

#### TC FINALIZATION #####
#-- set system to original state --##
sub TC_finalization {

    
	return 1;
}


1;


__END__