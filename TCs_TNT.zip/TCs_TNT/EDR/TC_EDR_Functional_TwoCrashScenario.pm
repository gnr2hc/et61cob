#### TEST CASE MODULE
package TC_EDR_Functional_TwoCrashScenario;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------
our $VERSION = q$Revision: 1.6 $;
our $HEADER = q$Header: EDR/TC_EDR_Functional_TwoCrashScenario.pm 1.6 2013/10/28 15:50:33ICT ver6cob develop  $;
################################## 

#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general; 
use LIFT_evaluation;
use LIFT_PD;
use INCLUDES_Project;
##################################

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_Functional_TwoCrashScenario  $Revision: 1.6 $

requires MLC,PD,CANoe,POWER and evaluation (setup already done in IC)

default state is faultfree ECU powered ON

=head1 PURPOSE

to validate the TwoCrashScenario - storage of two non overlapping events

=head1 TESTCASE DESCRIPTION 

    [initialisation]
    StandardPreparation

    [stimulation & measurement]
    1. Create a multi event <Crash>. (Both events are not overlapping)    
	2. Read Crash Telegrams EDR1 and EDR2

    [evaluation]
    2. Two Crashes are stored in the Crash recorder.
	First Crash Event is stored in CrashRecorder1 and Second Crash Event is stored in CrashRecorder2
	Make sure that Crash data is written completely, by reading the 'Header section' of Crash telegram.
	Read the Event Type using CD to confirm that the correct crash is stored in each record

    [finalisation]
    Clear Crash Telegram and Fault memory
    ECU off

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

    purpose                  --> Purpose of the test case
    crash				  	 --> Type/name of crash
  	

=head2 PARAMETER EXAMPLES

    [TC_EDR_Functional_TwoCrashScenario.FrontInflatableSideDriverInflatable]
	# From here on: applicable Lift Default Parameters
	purpose = 'to validate the TwoCrashScenario - storage of two non overlapping events'
	crash = 'FrontInflatableSideDriverInflatable'

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#Hashes to read the parameters from .par file  
my (%defaultpar_hash,
	%TCpar_hash);


#List of parameters in .par file
my @defaultpar_list 			= ('purpose',
					   			   'crash');
my @TCpar_list 					= ('EventType_EDR1',
								   'EventType_EDR2');	   

				                  
#other TC specific constants/parameters from other files



#variables used in the test case
my @EDR_CD_response_aref;
my ($EventType_EDR1,$EventType_EDR2);
my $CrashInjectionStatus;
my $NumberOfCrashTelegrams;
our $PURPOSE;

sub TC_set_parameters {
		
	#read each default parameter from the .par file
	foreach my $defaultpar(@defaultpar_list){
		$defaultpar_hash{$defaultpar} =  GEN_Read_mandatory_testcase_parameter($defaultpar);
	}
	
	#read each test case parameter from the .par file
	foreach my $TCpar(@TCpar_list){
		$TCpar_hash{$TCpar} =  GEN_Read_mandatory_testcase_parameter($TCpar);
	}
	
	$PURPOSE = "$defaultpar_hash{'purpose'}";	
	
	#read other TC specific constants/parameters from other files
    $NumberOfCrashTelegrams = EDR_fetchNumberOfCrashTelegrams();
    
	return 1;

}

#### INITIALIZE TC #####
sub TC_initialization {

    S_w2rep('StandardPreparation', 'blue'); 
    PD_ClearCrashRecorder();
    GEN_StandardPrepNoFault();
        
  	return 1;
}


### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {
    
    my $label;
    
    S_w2rep("Step1: Create a multi event crash. (Both events are not overlapping)", 'blue');
    $CrashInjectionStatus = EDR_InjectCrash($defaultpar_hash{'crash'} , 10000); 
    
    unless (defined $CrashInjectionStatus and $CrashInjectionStatus == 1){
    	S_set_error("Crash is not injected successfully. Not proceeding!", 0);
    	$PURPOSE = "Crash not injected successfully";
		return 0;
    }   
    
    S_w2rep("Step2:  Read Crash Telegrams EDR1, EDR2 and EDR3", 'blue');
    foreach my $EDRcount(1..$NumberOfCrashTelegrams){
    	S_w2rep("Read EDR$EDRcount ", 'orange');
    	$EDR_CD_response_aref[$EDRcount-1] = EDR_CD_ReadEDR ($EDRcount); 
    }
       
    S_w2rep("Step2b: Read EventType values through CD", 'blue');	
	my $EDID_EventType = EDR_fetchEDIDbyLabel('EventType');
	$EventType_EDR1 = EDR_CD_getEDIDdata ($EDR_CD_response_aref[1], $EDID_EventType);
	$EventType_EDR2 = EDR_CD_getEDIDdata ($EDR_CD_response_aref[0], $EDID_EventType); #most recent entry
  	
  	return 1;
}


#### EVALUATE TC #####
sub TC_evaluation {
	
	S_w2rep("Step2a: First Crash Event is stored in CrashRecorder1 and second crash in CrashRecorder2", 'blue');
	S_w2rep("Check if EDR1 and EDR2 are not empty", 'orange');
    EDR_CD_EVAL_checkStorageStatus($EDR_CD_response_aref[0], 'Stored');	
    EDR_CD_EVAL_checkStorageStatus($EDR_CD_response_aref[1], 'Stored');	
    	
    #remaining EDRs should be empty!
	foreach my $EDRcount(3..$NumberOfCrashTelegrams){
		if($EDR_CD_response_aref[$EDRcount-1]){ #check if array ref is not empty
			S_w2rep("Check if EDR$EDRcount is empty", 'orange');
			EDR_CD_EVAL_checkStorageStatus ($EDR_CD_response_aref[$EDRcount-1],'NotStored');
		}
	}
		
	S_w2rep("Step2b: check the Event Type", 'blue');
	if(defined $EventType_EDR1){
		S_w2rep("Event Type\n",'orange');
		S_w2rep("Expected: $TCpar_hash{'EventType_EDR1'} and $TCpar_hash{'EventType_EDR2'} \n Observed: @$EventType_EDR1[0] and @$EventType_EDR2[0]\n", 'blue'); 
		EVAL_evaluate_value ( "Event type EDR1", $TCpar_hash{'EventType_EDR1'}, '==', @$EventType_EDR1[0] );
		EVAL_evaluate_value ( "Event type EDR2", $TCpar_hash{'EventType_EDR2'}, '==', @$EventType_EDR2[0] );
	}
    
    return 1;
}

#### TC FINALIZATION #####
#-- set system to original state --##
sub TC_finalization {

    GEN_Finalization  ();
    
return 1;
}


1;


__END__