#### TEST CASE MODULE
package TC_EDR_Functional_HeaderBytes;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------
our $VERSION = q$Revision: 1.5 $;
our $HEADER = q$Header: EDR/TC_EDR_Functional_HeaderBytes.pm 1.5 2013/10/28 15:50:30ICT ver6cob develop  $;
################################## 

#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general; 
use LIFT_evaluation;
use LIFT_POWER; 
use LIFT_PD;
use INCLUDES_Project;
##################################

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_Functional_HeaderBytes  $Revision: 1.5 $

requires MLC,PD,CANoe,POWER and evaluation (setup already done in IC)

default state is faultfree ECU powered ON

=head1 PURPOSE

To validate Header bytes reported in the EDR service

=head1 TESTCASE DESCRIPTION 

    [initialisation]
    StandardPreparation

    [stimulation & measurement]
    1. Inject any Inflatable Crash.
	2. Read header bytes in EDR1 through CD.
	3. Inject any NonInflatable Crash and at the time of storage, switch Off the ECU. i.e create such a condition complete crash should not be stored
	4. Read header bytes in EDR2 through CD.
	5. Reset ECU and inject any Inflatable Crash.
	6. Read header bytes in EDR3 through CD.
	7. Inject any Inflatable Crash.
	8. Read header bytes in EDR4 through CD.
	9. Inject any Inflatable Crash.
	10. Read header bytes in EDR5 through CD.
	11. Inject 10 NoDeployment Crashes.
	12. Read header bytes in EDR6 through CD.	
	

    [evaluation]
    1.
	2. 00 01
	3.
	4. 80 02
	5.
	6. 00 03
	7.
	8. 00 04
	9.
	10. 00 05
	11.
	12. 00 0F

    [finalisation]
    Clear Crash Telegram and Fault memory
    ECU off

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

    purpose                  --> Purpose of the test case
  	

=head2 PARAMETER EXAMPLES

    [TC_EDR_Functional_HeaderBytes.HeaderBytes]
	# From here on: applicable Lift Default Parameters
	purpose = 'To validate Header bytes reported in the EDR service'

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#Hashes to read the parameters from .par file  
my (%defaultpar_hash,
	%TCpar_hash);


#List of parameters in .par file
my @defaultpar_list 			= ('purpose');
my @TCpar_list 					= ();	   

				                  
#other TC specific constants/parameters from other files



#variables used in the test case
my ($EDR1_CD_response_aref, 
	$EDR2_CD_response_aref,
	$EDR3_CD_response_aref,
	$EDR4_CD_response_aref,
	$EDR5_CD_response_aref,
	$EDR6_CD_response_aref); 
my ($EDR1_Header_aref,
	$EDR2_Header_aref,
	$EDR3_Header_aref,
	$EDR4_Header_aref,
	$EDR5_Header_aref,
	$EDR6_Header_aref);
my $NumberOfCrashTelegrams;	
my $CrashInjectionStatus;
our $PURPOSE;

sub TC_set_parameters {
		
	#read each default parameter from the .par file
	foreach my $defaultpar(@defaultpar_list){
		$defaultpar_hash{$defaultpar} =  GEN_Read_mandatory_testcase_parameter($defaultpar);
	}
	
	#read each test case parameter from the .par file
	foreach my $TCpar(@TCpar_list){
		$TCpar_hash{$TCpar} =  GEN_Read_mandatory_testcase_parameter($TCpar);
	}
	
	$PURPOSE = "$defaultpar_hash{'purpose'}";	
	
	#read other TC specific constants/parameters from other files	
    $NumberOfCrashTelegrams = EDR_fetchNumberOfCrashTelegrams ();
	
    
	return 1;

}

#### INITIALIZE TC #####
sub TC_initialization {

    S_w2rep('StandardPreparation', 'blue'); 
    PD_ClearCrashRecorder();
    GEN_StandardPrepNoFault();
        
  	return 1;
}


### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {
    
    S_w2rep("Step1:  Inject any Inflatable Crash", 'blue');
    $CrashInjectionStatus = EDR_InjectCrash('FrontInflatableDeployment' , 10000); 
    
    unless (defined $CrashInjectionStatus and $CrashInjectionStatus == 1){
    	S_set_error("Crash is not injected successfully. Not proceeding!", 0);
    	$PURPOSE = "Crash not injected successfully";
		return 0;
    }    
    
	S_w2rep("Step2:  Read header bytes in EDR1 through CD", 'blue'); 
	$EDR1_CD_response_aref = EDR_CD_ReadEDR (1); 
	if($EDR1_CD_response_aref){ #if aref is not empty
	    $EDR1_Header_aref = EDR_CD_readHeader ($EDR1_CD_response_aref); 
	}    
	
	S_w2rep("Step3: Inject any NonInflatable Crash and at the time of storage, switch Off the ECU. i.e create such a condition complete crash should not be stored", 'blue');
	POW_off();
    S_wait_ms(50);    
	$CrashInjectionStatus = EDR_InjectCrash('FrontNonInflatableDeployment');  
	S_wait_ms('TIMER_ECU_OFF');   
	POW_on();
    S_wait_ms( 'TIMER_ECU_READY' );
	    
	unless (defined $CrashInjectionStatus and $CrashInjectionStatus == 1){
    	S_set_error("Crash is not injected successfully. Not proceeding!", 0);
		return 0;
    }   
 
    S_w2rep("Step4:  Read header bytes in EDR2 through CD", 'blue'); 
    $EDR2_CD_response_aref = EDR_CD_ReadEDR (2); 
    if($EDR2_CD_response_aref){
    	$EDR2_Header_aref = EDR_CD_readHeader ($EDR2_CD_response_aref);
    }
		        
    if($NumberOfCrashTelegrams > 2){
    	S_w2rep("Step5:  Reset ECU and inject any Inflatable Crash", 'blue');
    	GEN_Power_on_Reset ();
		$CrashInjectionStatus = EDR_InjectCrash('SideDriverInflatableDeployment' , 10000); 
		
		unless (defined $CrashInjectionStatus and $CrashInjectionStatus == 1){
    		S_set_error("Crash is not injected successfully. Not proceeding!", 0);
			return 0;
    	}
    	    
    	S_w2rep("Step6:  Read header bytes in EDR3 through CD", 'blue'); 
    	$EDR3_CD_response_aref = EDR_CD_ReadEDR (3); 
    	if($EDR3_CD_response_aref){
    		$EDR3_Header_aref = EDR_CD_readHeader ($EDR3_CD_response_aref);
    	} 
	}
		    
		    
    if($NumberOfCrashTelegrams > 3){
    	S_w2rep("Step7:  Inject any Inflatable Crash", 'blue');
    	$CrashInjectionStatus = EDR_InjectCrash('FrontInflatableDeployment' , 10000); 
    	
    	unless (defined $CrashInjectionStatus and $CrashInjectionStatus == 1){
    		S_set_error("Crash is not injected successfully. Not proceeding!", 0);
			return 0;
    	}    
    
    	S_w2rep("Step8:  Read header bytes in EDR4 through CD", 'blue'); 
    	$EDR4_CD_response_aref = EDR_CD_ReadEDR (4); 
    	if($EDR4_CD_response_aref){
    		$EDR4_Header_aref = EDR_CD_readHeader ($EDR4_CD_response_aref); 
    	}
    }
		    
    if($NumberOfCrashTelegrams > 4){
    	S_w2rep("Step9:  Inject any Inflatable Crash", 'blue');
    	$CrashInjectionStatus = EDR_InjectCrash('SideDriverInflatableDeployment' , 10000);  
    	
    	unless (defined $CrashInjectionStatus and $CrashInjectionStatus == 1){
    		S_set_error("Crash is not injected successfully. Not proceeding!", 0);
			return 0;
    	}   
    
        S_w2rep("Step10:  Read header bytes in EDR5 through CD", 'blue'); 
	    $EDR5_CD_response_aref = EDR_CD_ReadEDR (5); 
	    if($EDR5_CD_response_aref){
	    	$EDR5_Header_aref = EDR_CD_readHeader ($EDR5_CD_response_aref); 
	    }
	}
		    
		    
    if($NumberOfCrashTelegrams > 5){
    	S_w2rep("Step11:  Inject 10 NoDeployment Crashes", 'blue');
    	foreach(1..10){
    		$CrashInjectionStatus = EDR_InjectCrash('FrontNoDeployment' , 10000);
    	}   
    	
    	unless (defined $CrashInjectionStatus and $CrashInjectionStatus == 1){
    		S_set_error("Crash is not injected successfully. Not proceeding!", 0);
			return 0;
    	}    
    
    	S_w2rep("Step12:  Read header bytes in EDR6 through CD", 'blue'); 
    	$EDR6_CD_response_aref = EDR_CD_ReadEDR (6); 
    	if($EDR6_CD_response_aref){
    		$EDR6_Header_aref = EDR_CD_readHeader ($EDR6_CD_response_aref); 
    	}
	}
    
  	return 1;
}


#### EVALUATE TC #####
sub TC_evaluation {
	
	S_w2rep("Step2: Header bytes: 00 01", 'blue');				
	if($EDR1_Header_aref){ #check if array ref is not empty
		GEN_EVAL_CompareNumArrays($EDR1_Header_aref, [0x00,0x01], 'Equal' );
	}
	
    S_w2rep("Step4: Header bytes: 80 02", 'blue');				
	if($EDR2_Header_aref){ 
		GEN_EVAL_CompareNumArrays($EDR2_Header_aref, [0x80,0x02], 'Equal' );
	}
	
	if($NumberOfCrashTelegrams > 2){
		S_w2rep("Step6: Header bytes: 00 03", 'blue');				
		if($EDR3_Header_aref){ 
			GEN_EVAL_CompareNumArrays($EDR3_Header_aref, [0x00,0x03],'Equal' );
			
		}
	}
	
	if($NumberOfCrashTelegrams > 3){
		S_w2rep("Step8: Header bytes: 00 04", 'blue');				
		if($EDR4_Header_aref){ 
			GEN_EVAL_CompareNumArrays($EDR4_Header_aref, [0x00,0x04],'Equal' );
		}
	}
	
	if($NumberOfCrashTelegrams > 4){
		S_w2rep("Step10: Header bytes: 00 05", 'blue');				
		if($EDR5_Header_aref){ 
			GEN_EVAL_CompareNumArrays($EDR5_Header_aref, [0x00,0x05],'Equal' );
		}
	}
	
	if($NumberOfCrashTelegrams > 5){
		S_w2rep("Step12: Header bytes: 00 06", 'blue');				
		if($EDR6_Header_aref){ 
			GEN_EVAL_CompareNumArrays($EDR6_Header_aref, [0x00,0x0F],'Equal' );
		}
	}
	
    return 1;
}

#### TC FINALIZATION #####
#-- set system to original state --##
sub TC_finalization {
	
    GEN_Finalization  ();
    
return 1;
}


1;


__END__