# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_PCP_Switches;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_ISS
#TS version in DOORS: 5.3
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use LIFT_can_access;
use FuncLib_TNT_GEN;
use FuncLib_SYC_INTERFACE;
##################################

our $PURPOSE = "check the trigger dependency on the switch states";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PCP_Switches

=head1 PURPOSE

check the trigger dependency on the switch states

=head1 TESTCASE DESCRIPTION

This script is based on 

I<B<Initialisation>>

1. switch ECU on
2. read fault recorder
3. switch ECU off

I<B<Stimulation and Measurement>>

1.  set velocity
2.  set switch states
3.  switch ECU on
4.  check CAN-messages
5.  set switch states
6.  check CAN-messages
7.  switch ECU off

I<B<Evaluation>>

1. evaluate CAN-messages
2. evaluate CAN-messages

I<B<Finalisation>>

1. switch ECU on
2. clear fault memory
3. switch ECU off

=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES



=head2 PARAMETER EXAMPLES
[TC_PCP_Switches.open_belt_lock_for_PCP]   #ID: TS_ISS_446
    purpose		         = 'check the configuration open_belt_lock_for_PCP'
    Ubat                 = 13.5
    switch_state1        = %('BLFD' => 'PositionA', 'BLFP' => 'PositionA', 'BLRD' => 'PositionA', 'BLRP' => 'PositionA', 'BLRC' => 'PositionA')
    switch_state2        = %('BLFD' => 'PositionA', 'BLFP' => 'PositionA', 'BLRD' => 'PositionA', 'BLRP' => 'PositionA', 'BLRC' => 'PositionA')
	Velocity_message     =  'VSD_ESPReferenceVelocity' 
	AEB_Expected_message = 'BMI_AEB_Expected'
	MSB_FD_message       = 'Airbag_MSB_FD'
    MSB_FP_message       = 'Airbag_MSB_FP'
    MSB_RD_message       = 'Airbag_MSB_RD'
    MSB_RP_message       = 'Airbag_MSB_RP'
    MSB_RC_message       = 'Airbag_MSB_RC'
	Velocity             = 35
	BMI_AEB_Expected     = 1
	Airbag_MSB_FD = @('0','0')
	Airbag_MSB_FP = @('0','0')
	Airbag_MSB_RD = @('0','0')
	Airbag_MSB_RP = @('0','0')
	Airbag_MSB_RC = @('0','0')

=cut

#PARAMETERS
################ Parameters from .par file ###################
my ( $tcpar_Ubat_V, $tcpar_velocity_message, $tcpar_velocity );
my ( $tcpar_switch_state1,        $tcpar_switch_state2 );
my ( $tcpar_aeb_expected_message, $tcpar_aeb_expected );
my ( $tcpar_MSB_FD_message,       $tcpar_MSB_FP_message, $tcpar_MSB_RD_message, $tcpar_MSB_RP_message, $tcpar_MSB_RC_message );
my ( $tcpar_MSB_FD_values,        $tcpar_MSB_FP_values, $tcpar_MSB_RD_values, $tcpar_MSB_RP_values, $tcpar_MSB_RC_values );

################ global parameter declaration ###################
#add any global variables here
my @temperatures;
my ($CAN_trace_file);

###############################################################

sub TC_set_parameters {

	$tcpar_Ubat_V           = GEN_Read_mandatory_testcase_parameter('Ubat');
	$tcpar_switch_state1    = GEN_Read_mandatory_testcase_parameter( 'switch_state1', 'byref' );
	$tcpar_switch_state2    = GEN_Read_mandatory_testcase_parameter( 'switch_state2', 'byref' );
	$tcpar_velocity_message = GEN_Read_mandatory_testcase_parameter('Velocity_message');
	$tcpar_velocity         = GEN_Read_mandatory_testcase_parameter('Velocity');

	$tcpar_aeb_expected_message = GEN_Read_mandatory_testcase_parameter('AEB_Expected_message');
	$tcpar_aeb_expected         = GEN_Read_mandatory_testcase_parameter('BMI_AEB_Expected');

	$tcpar_MSB_FD_message = GEN_Read_mandatory_testcase_parameter('MSB_FD_message');
	$tcpar_MSB_FD_values  = GEN_Read_mandatory_testcase_parameter( 'Airbag_MSB_FD', 'byref' );
	$tcpar_MSB_FP_message = GEN_Read_mandatory_testcase_parameter('MSB_FP_message');
	$tcpar_MSB_FP_values  = GEN_Read_mandatory_testcase_parameter( 'Airbag_MSB_FP', 'byref' );
	$tcpar_MSB_RD_message = GEN_Read_mandatory_testcase_parameter('MSB_RD_message');
	$tcpar_MSB_RD_values  = GEN_Read_mandatory_testcase_parameter( 'Airbag_MSB_RD', 'byref' );
	$tcpar_MSB_RP_message = GEN_Read_mandatory_testcase_parameter('MSB_RP_message');
	$tcpar_MSB_RP_values  = GEN_Read_mandatory_testcase_parameter( 'Airbag_MSB_RP', 'byref' );
	$tcpar_MSB_RC_message = GEN_Read_mandatory_testcase_parameter('MSB_RC_message');
	$tcpar_MSB_RC_values  = GEN_Read_mandatory_testcase_parameter( 'Airbag_MSB_RC', 'byref' );

	return 1;
}

sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PD_ClearFaultMemory();
	S_wait_ms('TIMER_ECU_READY');

	PD_GetExtendedFaultInformation();

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	push( @temperatures, TEMP_get_temperature() );

	return 1;
}

sub TC_stimulation_and_measurement {

	my ( $result, $state_value, $state_unit );

	S_teststep( "Set velocity", 'AUTO_NBR' );
	CA_write_can_signal( $tcpar_velocity_message, $tcpar_velocity );

	S_teststep( "Set switches to required position for test", 'AUTO_NBR' );
	foreach my $switch ( keys %{$tcpar_switch_state1} ) {
		S_teststep_2nd_level( "Set switch '$switch' to position '" . $tcpar_switch_state1->{$switch} . "'", 'AUTO_NBR' );
		( $result, $state_value, $state_unit ) = SYC_SWITCH_get_state( $switch, $tcpar_switch_state1->{$switch} );
		if ( $state_unit =~ /R/i ) {
			LC_SetResistance( $switch, $state_value );
		}
		elsif ( $state_unit =~ /I/i ) {
			LC_SetCurrent( $switch, $state_value );
		}
	}

	S_teststep( "Set $tcpar_aeb_expected_message to value $tcpar_aeb_expected", 'AUTO_NBR' );
	CA_write_can_signal( $tcpar_aeb_expected_message, $tcpar_aeb_expected );

	S_teststep( "Start CAN trace", 'AUTO_NBR' );
	CA_trace_start();

	S_teststep( "Switch ECU on", 'AUTO_NBR' );
	LC_ECU_On($tcpar_Ubat_V);
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Set switches to required position for test", 'AUTO_NBR' );
	foreach my $switch ( keys %{$tcpar_switch_state2} ) {
		S_teststep_2nd_level( "Set switch '$switch' to position '" . $tcpar_switch_state2->{$switch} . "'", 'AUTO_NBR' );
		( $result, $state_value, $state_unit ) = SYC_SWITCH_get_state( $switch, $tcpar_switch_state2->{$switch} );
		if ( $state_unit =~ /R/i ) {
			LC_SetResistance( $switch, $state_value );
		}
		elsif ( $state_unit =~ /I/i ) {
			LC_SetCurrent( $switch, $state_value );
		}
	}
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Switch ECU off", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep( "Stop CAN trace", 'AUTO_NBR' );
	CA_trace_stop();

	S_teststep( "Store CAN trace for evaluation", 'AUTO_NBR', 'evaluation' );
	$CAN_trace_file = CA_trace_store();

	return 1;
}

sub TC_evaluation {

	my ( $expected_pattern, $detected_pattern, $verdict );
	my $data_href = CA_trace_get_dataref( $CAN_trace_file, [ $tcpar_MSB_FD_message, $tcpar_MSB_FP_message, $tcpar_MSB_RD_message, $tcpar_MSB_RP_message, $tcpar_MSB_RC_message ] );

	$expected_pattern = join( ':', @$tcpar_MSB_FD_values );
	( $expected_pattern, $detected_pattern, $verdict ) = EVAL_evaluate_digital_pattern_over_time( $data_href, $tcpar_MSB_FD_message, $expected_pattern );
	S_teststep_expected( "MSB FD expected signal pattern: $expected_pattern", 'evaluation' );
	S_teststep_detected( "MSB FD detected signal pattern: $detected_pattern", 'evaluation' );

	$expected_pattern = join( ':', @$tcpar_MSB_FP_values );
	( $expected_pattern, $detected_pattern, $verdict ) = EVAL_evaluate_digital_pattern_over_time( $data_href, $tcpar_MSB_FP_message, $expected_pattern );
	S_teststep_expected( "MSB FP expected signal pattern: $expected_pattern", 'evaluation' );
	S_teststep_detected( "MSB FP detected signal pattern: $detected_pattern", 'evaluation' );

	$expected_pattern = join( ':', @$tcpar_MSB_RD_values );
	( $expected_pattern, $detected_pattern, $verdict ) = EVAL_evaluate_digital_pattern_over_time( $data_href, $tcpar_MSB_RD_message, $expected_pattern );
	S_teststep_expected( "MSB RD expected signal pattern: $expected_pattern", 'evaluation' );
	S_teststep_detected( "MSB RD detected signal pattern: $detected_pattern", 'evaluation' );

	$expected_pattern = join( ':', @$tcpar_MSB_RP_values );
	( $expected_pattern, $detected_pattern, $verdict ) = EVAL_evaluate_digital_pattern_over_time( $data_href, $tcpar_MSB_RP_message, $expected_pattern );
	S_teststep_expected( "MSB RP expected signal pattern: $expected_pattern", 'evaluation' );
	S_teststep_detected( "MSB RP detected signal pattern: $detected_pattern", 'evaluation' );

	$expected_pattern = join( ':', @$tcpar_MSB_RC_values );
	( $expected_pattern, $detected_pattern, $verdict ) = EVAL_evaluate_digital_pattern_over_time( $data_href, $tcpar_MSB_RC_message, $expected_pattern );
	S_teststep_expected( "MSB RC expected signal pattern: $expected_pattern", 'evaluation' );
	S_teststep_detected( "MSB RC detected signal pattern: $detected_pattern", 'evaluation' );

	return 1;
}

sub TC_finalization {

	CA_simulation_start();

	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	PD_ClearFaultMemory();

	LC_ECU_Off();

	S_teststep_detected(" TEMP : $temperatures[0] ");

	return 1;
}

1;
