# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_PCP_Release;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_ISS
#TS version in DOORS: 5.3
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use LIFT_can_access;
use FuncLib_TNT_GEN;
use FuncLib_SYC_INTERFACE;
##################################

our $PURPOSE = "check the trigger dependency on the release conditions";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PCP_Release

=head1 PURPOSE

check the trigger dependency on the release conditions

=head1 TESTCASE DESCRIPTION

This script is based on 

I<B<Initialisation>>

1. Switch ECU on
2. Read fault recorder
3. Switch ECU off

I<B<Stimulation and Measurement>>

1. set velocity1
2. set switch states
3. set message values
4. Switch ECU on
5. check CAN-messages
6. set AEBExpected2
7. check CAN-messages
8. Switch ECU off

I<B<Evaluation>>

1. Evaluate CAN-messages
2. Evaluate CAN-messages

I<B<Finalisation>>

1. Switch ECU on
2. Clear fault memory
3. Switch ECU off

=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES



=head2 PARAMETER EXAMPLES
[TC_PCP_Release.Release_AEBState]   #ID: TS_ISS_400
    purpose		             = 'check the release Release_AEBState'
    Ubat                     = 13.5
    switch_state             = %('BLFD' => 'PositionB', 'BLFP' => 'PositionB', 'BLRD' => 'PositionB', 'BLRP' => 'PositionB', 'BLRC' => 'PositionB')
	Velocity_message         =  'VSD_ESPReferenceVelocity' 
	AEB_Expected_message     = 'BMI_AEB_Expected'
	AEB_State_message        = 'BMI_AEB_State'
	VDC_Intervention_message = 'VDC_Intervention'
	VDC_AccX_message         = 'VDC_AccLongitudinal'
	VDC_AccY_message         = 'VDC_AccLateral'
	VDC_YawRate_message      = 'VDC_YawRate'
	MSB_FD_message           = 'Airbag_MSB_FD'
    MSB_FP_message           = 'Airbag_MSB_FP'
    MSB_RD_message           = 'Airbag_MSB_RD'
    MSB_RP_message           = 'Airbag_MSB_RP'
    MSB_RC_message           = 'Airbag_MSB_RC'
	Velocity                 = 35
	AebExpected1             = 1
	AebExpected2             = 0
	AebState                 = 1
	VdcIntervention          = 0
	AccX                     = 91
	AccY                     = 85
	YawRate                  = 42
	Airbag_MSB_FD            = @('0','0')
    Airbag_MSB_FP            = @('0','0')
    Airbag_MSB_RD            = @('0','0')
    Airbag_MSB_RP            = @('0','0')
    Airbag_MSB_RC            = @('0','0')

=cut

#PARAMETERS
################ Parameters from .par file ###################
my ( $tcpar_Ubat_V,                   $tcpar_switch_state,     $tcpar_velocity_message, $tcpar_velocity );
my ( $tcpar_aeb_expected_message,     $tcpar_aeb_expected1,    $tcpar_aeb_expected2,    $tcpar_aeb_state_message, $tcpar_aeb_state );
my ( $tcpar_vdc_intervention_message, $tcpar_vdc_intervention, $tcpar_vdc_accx_message, $tcpar_vdc_accx, $tcpar_vdc_accy_message, $tcpar_vdc_accy, $tcpar_vdc_yawrate_message, $tcpar_vdc_yawrate );
my ( $tcpar_MSB_FD_message, $tcpar_MSB_FP_message, $tcpar_MSB_RD_message, $tcpar_MSB_RP_message, $tcpar_MSB_RC_message );
my ( $tcpar_MSB_FD_values,  $tcpar_MSB_FP_values,  $tcpar_MSB_RD_values,  $tcpar_MSB_RP_values,  $tcpar_MSB_RC_values );

################ global parameter declaration ###################
#add any global variables here
my @temperatures;
my ($CAN_trace_file);
my ( $tcpar_vdc_accx_CAN, $tcpar_vdc_accy_CAN, $tcpar_vdc_yawrate_CAN, $unit );
my ( $tcpar_vdc_accx_LSB, $tcpar_vdc_accy_LSB, $tcpar_vdc_yawrate_LSB, $type, $value_aref );
my $acc_factor      = 0.1;      # = m/s� in g
my $acc_resolution  = 0.002;    # g/LSB
my $rate_resolution = 0.1;      # �/s/LSB

###############################################################

sub TC_set_parameters {

	$tcpar_Ubat_V           = GEN_Read_mandatory_testcase_parameter('Ubat');
	$tcpar_switch_state     = GEN_Read_mandatory_testcase_parameter( 'switch_state', 'byref' );
	$tcpar_velocity_message = GEN_Read_mandatory_testcase_parameter('Velocity_message');
	$tcpar_velocity         = GEN_Read_mandatory_testcase_parameter('Velocity');

	$tcpar_aeb_expected_message     = GEN_Read_mandatory_testcase_parameter('AEB_Expected_message');
	$tcpar_aeb_expected1            = GEN_Read_mandatory_testcase_parameter('AebExpected1');
	$tcpar_aeb_expected2            = GEN_Read_mandatory_testcase_parameter('AebExpected2');
	$tcpar_aeb_state_message        = GEN_Read_mandatory_testcase_parameter('AEB_State_message');
	$tcpar_aeb_state                = GEN_Read_mandatory_testcase_parameter('AebState');
	$tcpar_vdc_intervention_message = GEN_Read_mandatory_testcase_parameter('VDC_Intervention_message');
	$tcpar_vdc_intervention         = GEN_Read_mandatory_testcase_parameter('VdcIntervention');
	$tcpar_vdc_accx_message         = GEN_Read_mandatory_testcase_parameter('VDC_AccX_message');
	$tcpar_vdc_accx                 = GEN_Read_mandatory_testcase_parameter('AccX');
	$tcpar_vdc_accy_message         = GEN_Read_mandatory_testcase_parameter('VDC_AccY_message');
	$tcpar_vdc_accy                 = GEN_Read_mandatory_testcase_parameter('AccY');
	$tcpar_vdc_yawrate_message      = GEN_Read_mandatory_testcase_parameter('VDC_YawRate_message');
	$tcpar_vdc_yawrate              = GEN_Read_mandatory_testcase_parameter('YawRate');

	$tcpar_MSB_FD_message = GEN_Read_mandatory_testcase_parameter('MSB_FD_message');
	$tcpar_MSB_FD_values  = GEN_Read_mandatory_testcase_parameter( 'Airbag_MSB_FD', 'byref' );
	$tcpar_MSB_FP_message = GEN_Read_mandatory_testcase_parameter('MSB_FP_message');
	$tcpar_MSB_FP_values  = GEN_Read_mandatory_testcase_parameter( 'Airbag_MSB_FP', 'byref' );
	$tcpar_MSB_RD_message = GEN_Read_mandatory_testcase_parameter('MSB_RD_message');
	$tcpar_MSB_RD_values  = GEN_Read_mandatory_testcase_parameter( 'Airbag_MSB_RD', 'byref' );
	$tcpar_MSB_RP_message = GEN_Read_mandatory_testcase_parameter('MSB_RP_message');
	$tcpar_MSB_RP_values  = GEN_Read_mandatory_testcase_parameter( 'Airbag_MSB_RP', 'byref' );
	$tcpar_MSB_RC_message = GEN_Read_mandatory_testcase_parameter('MSB_RC_message');
	$tcpar_MSB_RC_values  = GEN_Read_mandatory_testcase_parameter( 'Airbag_MSB_RC', 'byref' );

	return 1;
}

sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PD_ClearFaultMemory();
	S_wait_ms('TIMER_ECU_READY');

	PD_GetExtendedFaultInformation();

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	push( @temperatures, TEMP_get_temperature() );

	return 1;
}

sub TC_stimulation_and_measurement {

	my ( $result, $state_value, $state_unit );

	S_teststep( "Set velocity", 'AUTO_NBR' );
	CA_write_can_signal( $tcpar_velocity_message, $tcpar_velocity );

	S_teststep( "Set switches to required position for test", 'AUTO_NBR' );
	foreach my $switch ( keys %{$tcpar_switch_state} ) {
		S_teststep_2nd_level( "Set switch '$switch' to position '" . $tcpar_switch_state->{$switch} . "'", 'AUTO_NBR' );
		( $result, $state_value, $state_unit ) = SYC_SWITCH_get_state( $switch, $tcpar_switch_state->{$switch} );
		if ( $state_unit =~ /R/i ) {
			LC_SetResistance( $switch, $state_value );
		}
		elsif ( $state_unit =~ /I/i ) {
			LC_SetCurrent( $switch, $state_value );
		}
	}

	S_teststep( "Set CAN messages to required value", 'AUTO_NBR' );
	S_teststep_2nd_level( "set $tcpar_aeb_expected_message with value $tcpar_aeb_expected1", 'AUTO_NBR' );
	CA_write_can_signal( $tcpar_aeb_expected_message, $tcpar_aeb_expected1 );
	S_teststep_2nd_level( "set $tcpar_aeb_state_message with value $tcpar_aeb_state", 'AUTO_NBR' );
	CA_write_can_signal( $tcpar_aeb_state_message, $tcpar_aeb_state );
	S_teststep_2nd_level( "set $tcpar_vdc_intervention_message with value $tcpar_vdc_intervention", 'AUTO_NBR' );
	CA_write_can_signal( $tcpar_vdc_intervention_message, $tcpar_vdc_intervention );
	S_teststep_2nd_level( "set $tcpar_vdc_accx_message with value $tcpar_vdc_accx", 'AUTO_NBR' );
	CA_write_can_signal( $tcpar_vdc_accx_message, $tcpar_vdc_accx, 'Hex' );
	S_teststep_2nd_level( "set $tcpar_vdc_accy_message with value $tcpar_vdc_accy", 'AUTO_NBR' );
	CA_write_can_signal( $tcpar_vdc_accy_message, $tcpar_vdc_accy, 'Hex' );
	S_teststep_2nd_level( "set $tcpar_vdc_yawrate_message with value $tcpar_vdc_yawrate", 'AUTO_NBR' );
	CA_write_can_signal( $tcpar_vdc_yawrate_message, $tcpar_vdc_yawrate, 'Hex' );

	S_teststep( "Start CAN trace", 'AUTO_NBR' );
	CA_trace_start();

	S_teststep( "Switch ECU on", 'AUTO_NBR' );
	LC_ECU_On($tcpar_Ubat_V);
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "set $tcpar_aeb_expected_message with value $tcpar_aeb_expected2", 'AUTO_NBR' );
	CA_write_can_signal( $tcpar_aeb_expected_message, $tcpar_aeb_expected2 );
	S_wait_ms('TIMER_ECU_READY');

	( $tcpar_vdc_accx_CAN,    $unit ) = CA_read_can_signal($tcpar_vdc_accx_message);
	( $tcpar_vdc_accy_CAN,    $unit ) = CA_read_can_signal($tcpar_vdc_accy_message);
	( $tcpar_vdc_yawrate_CAN, $unit ) = CA_read_can_signal($tcpar_vdc_yawrate_message);

	$value_aref            = PD_ReadMemoryByName('rb_cia_ISSESPAccX_s16');
	$type                  = PD_get_type_from_name('rb_cia_ISSESPAccX_s16');
	$tcpar_vdc_accx_LSB    = S_aref2dec( $value_aref, $type );
	$value_aref            = PD_ReadMemoryByName('rb_cia_ISSESPAccY_s16');
	$type                  = PD_get_type_from_name('rb_cia_ISSESPAccY_s16');
	$tcpar_vdc_accy_LSB    = S_aref2dec( $value_aref, $type );
	$value_aref            = PD_ReadMemoryByName('rb_cia_ISSESPYawRate_s16');
	$type                  = PD_get_type_from_name('rb_cia_ISSESPYawRate_s16');
	$tcpar_vdc_yawrate_LSB = S_aref2dec( $value_aref, $type );

	S_teststep( "Switch ECU off", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep( "Stop CAN trace", 'AUTO_NBR' );
	CA_trace_stop();

	S_teststep( "Store CAN trace for evaluation", 'AUTO_NBR', 'evaluation' );
	$CAN_trace_file = CA_trace_store();

	return 1;
}

sub TC_evaluation {

	my ( $expected_pattern, $detected_pattern, $verdict );
	my ($calculation);
	my $data_href = CA_trace_get_dataref( $CAN_trace_file, [ $tcpar_MSB_FD_message, $tcpar_MSB_FP_message, $tcpar_MSB_RD_message, $tcpar_MSB_RP_message, $tcpar_MSB_RC_message ] );

	S_teststep_expected("ACC X CAN value: $tcpar_vdc_accx_CAN");
	$calculation = ( $tcpar_vdc_accx_CAN * $acc_factor ) / $acc_resolution;
	S_teststep_expected("ACC X LSB value: $calculation");
	S_teststep_detected("ACC X LSB value: $tcpar_vdc_accx_LSB");
	EVAL_evaluate_value( "ACC X", $tcpar_vdc_accx_LSB, '==', $calculation, 5, 'absolute' );

	S_teststep_expected("ACC Y CAN value: $tcpar_vdc_accy_CAN");
	$calculation = ( $tcpar_vdc_accy_CAN * $acc_factor ) / $acc_resolution;
	S_teststep_expected("ACC Y LSB value: $calculation");
	S_teststep_detected("ACC Y LSB value: $tcpar_vdc_accy_LSB");
	EVAL_evaluate_value( "ACC Y", $tcpar_vdc_accy_LSB, '==', $calculation, 5, 'absolute' );

	S_teststep_expected("RATE CAN value: $tcpar_vdc_yawrate_CAN");
	$calculation = $tcpar_vdc_yawrate_CAN / $rate_resolution;
	S_teststep_expected("RATE LSB value: $calculation");
	S_teststep_detected("RATE LSB value: $tcpar_vdc_yawrate_LSB");
	EVAL_evaluate_value( "RATE", $tcpar_vdc_yawrate_LSB, '==', $calculation, 2, 'absolute' );

	# EVAL_evaluateAndPlotDataWithLimits( $data_href, 'PCP Release - MSB xx messages', [ $tcpar_MSB_FD_message, $tcpar_MSB_FP_message, $tcpar_MSB_RD_message, $tcpar_MSB_RP_message, $tcpar_MSB_RC_message ] );

	# check timing of detected pattern

	$expected_pattern = join( ':', @$tcpar_MSB_FD_values );
	( $expected_pattern, $detected_pattern, $verdict ) = EVAL_evaluate_digital_pattern_over_time( $data_href, $tcpar_MSB_FD_message, $expected_pattern );
	S_teststep_expected( "MSB FD expected signal pattern: $expected_pattern", 'evaluation' );
	S_teststep_detected( "MSB FD detected signal pattern: $detected_pattern", 'evaluation' );

	#	my ( $values_aref, $times_aref ) = EVAL_get_values_and_times_over_time( $data_href, $tcpar_MSB_FD_message );
	#	my $detected_values = join( ':', @$values_aref );
	#	my $detected_times  = join( ':', @$times_aref );
	#	S_teststep_detected("MSB FD detected values: $detected_values");
	#	S_teststep_detected("MSB FD detected times : $detected_times ");

	$expected_pattern = join( ':', @$tcpar_MSB_FP_values );
	( $expected_pattern, $detected_pattern, $verdict ) = EVAL_evaluate_digital_pattern_over_time( $data_href, $tcpar_MSB_FP_message, $expected_pattern );
	S_teststep_expected( "MSB FP expected signal pattern: $expected_pattern", 'evaluation' );
	S_teststep_detected( "MSB FP detected signal pattern: $detected_pattern", 'evaluation' );

	$expected_pattern = join( ':', @$tcpar_MSB_RD_values );
	( $expected_pattern, $detected_pattern, $verdict ) = EVAL_evaluate_digital_pattern_over_time( $data_href, $tcpar_MSB_RD_message, $expected_pattern );
	S_teststep_expected( "MSB RD expected signal pattern: $expected_pattern", 'evaluation' );
	S_teststep_detected( "MSB RD detected signal pattern: $detected_pattern", 'evaluation' );

	$expected_pattern = join( ':', @$tcpar_MSB_RP_values );
	( $expected_pattern, $detected_pattern, $verdict ) = EVAL_evaluate_digital_pattern_over_time( $data_href, $tcpar_MSB_RP_message, $expected_pattern );
	S_teststep_expected( "MSB RP expected signal pattern: $expected_pattern", 'evaluation' );
	S_teststep_detected( "MSB RP detected signal pattern: $detected_pattern", 'evaluation' );

	$expected_pattern = join( ':', @$tcpar_MSB_RC_values );
	( $expected_pattern, $detected_pattern, $verdict ) = EVAL_evaluate_digital_pattern_over_time( $data_href, $tcpar_MSB_RC_message, $expected_pattern );
	S_teststep_expected( "MSB RC expected signal pattern: $expected_pattern", 'evaluation' );
	S_teststep_detected( "MSB RC detected signal pattern: $detected_pattern", 'evaluation' );

	return 1;
}

sub TC_finalization {

	CA_simulation_start();

	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	PD_ClearFaultMemory();
	LC_ECU_Off();

	S_teststep_detected(" TEMP : $temperatures[0] ");

	return 1;
}

1;
