#### TEST CASE MODULE
package TC_SPI_WriteSignal;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
###-------------------------------
our $VERSION = q$Revision: 1.1 $;
our $HEADER = q$Header: SPI/TC_SPI_WriteSignal.pm 1.1 2016/08/18 18:31:47ICT Vadiraja Vasudendra Rajendra (RBEI/ESA-PP3) (RVD7KOR) develop  $;
################################## 


#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general;
use LIFT_spi_access;
use LIFT_spi_instruction_set;
use LIFT_evaluation;
use File::Basename;
use Data::Dumper;
use INCLUDES_Project;
use LIFT_PD;
use LIFT_manitoo;
##################################
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_SPI_Development  $Revision: 1.1 $


=head1 PURPOSE

develop SPI database for signal based testing

=head1 TESTCASE DESCRIPTION 

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

=head2 PARAMETER EXAMPLES

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_spi_node;
my $tcpar_trace_path;
my $tcpar_start_time;
my $tcpar_end_time;
my $tcpar_cmd_seq_eval;

################ global parameter declaration ###################
#add any global variables here
#my ();

our $PURPOSE;
our $TC_name = "TC_SPI_Development";

my $measurement_label = 'CommandSequenceMeasurement';
my ($measdata_href, $flt_mem_struct);
#-------------------------------------------------------------------------------
sub TC_set_parameters {
#-------------------------------------------------------------------------------

    return 1;
}

#-------------------------------------------------------------------------------
sub TC_initialization {
#-------------------------------------------------------------------------------
    S_w2log( 1, "No initialization required, test case is evaluation only" );

    S_wait_ms(400);
        

    PD_ECUlogin();
    $flt_mem_struct = PD_ReadFaultMemory(1);

    PD_ClearFaultMemory();
    S_wait_ms(9000);
    $flt_mem_struct = PD_ReadFaultMemory(1);

    MANITOO_FET_power_off( 0 , 1 );
    
    S_wait_ms('TIMER_ECU_OFF');
    return 1;
}

#-------------------------------------------------------------------------------
sub TC_stimulation_and_measurement {
#-------------------------------------------------------------------------------
                         
#    SPI_load_signal_manipulation('Node'=>'Cobra_M',
#                                 'Command' => 'PROG_SAFETY',
#                                 'Signal'=>'SID PRE',
#                                 'SignalDataValues' => [1],
#                                 );

  
                                 
    # SD bit manipulation
    SPI_load_signal_manipulation('Node'=>'SMI7xx',
                                 'SMI7_Module' => 'SMI710_2_Roll',
                                 'SMI7_Page' => 4,
                                 'Command' => 'MODULE_COMMAND__READ_Adr',
                                 'Signal'=>'CRC/TF',
                                 'SignalDataValues' => [7]
                                 );
    
#    SPI_load_signal_manipulation('Node'=>'Cobra_M', 'Command' => 'PROG_SAFETY__[WRITE REG]', 'Signal'=>'MON SPI', 'SignalDataValues' => [0, 0, 2, 2, 2, 1]);
#    SPI_load_signal_manipulation('Node'=>'Cobra_M', 'Command' => 'PROG_SAFETY__[WRITE REG]', 'Signal'=>'MON SPI', 'SignalDataSamples' =>{0 => 1, 50 => 3, 60 => 2, 65 => 1});
 MANITOO_FET_power_on( 0 , 1 );
  #S_wait_ms(5000);
    SPI_start_manipulation();
    # S_wait_ms(2000);
    
     S_wait_ms(7000);
    SPI_stop_manipulation();
    $flt_mem_struct = PD_ReadFaultMemory(1);
    return 1;
}

#-------------------------------------------------------------------------------
sub TC_evaluation {
#-------------------------------------------------------------------------------

    S_teststep("Get detected sequence from trace", 'AUTO_NBR');
    
    return 1;
}

#-------------------------------------------------------------------------------
sub TC_finalization {
#-------------------------------------------------------------------------------
    S_w2log( 1, "No finalization required, test case is evaluation only" );                        

    return 1;
}

1;