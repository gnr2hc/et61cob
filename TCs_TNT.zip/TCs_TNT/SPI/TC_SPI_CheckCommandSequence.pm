#### TEST CASE MODULE
package TC_SPI_CheckCommandSequence;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
###-------------------------------
our $VERSION = q$Revision: 1.5 $;
our $HEADER = q$Header: SPI/TC_SPI_CheckCommandSequence.pm 1.5 2016/09/16 14:07:01ICT Vadiraja Vasudendra Rajendra (RBEI/ESA-PP3) (RVD7KOR) develop  $;
################################## 


#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general;
use LIFT_spi_access;
use LIFT_evaluation;
use File::Basename;
use Data::Dumper;
use INCLUDES_Project;

##################################
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SPI_CheckCommandSequence

=head1 PURPOSE

To Evaluate sequence of SPI commands using the SPI trace from SPI_Maid Tool.

=head1 TESTCASE DESCRIPTION

I<B<Initialisation>>

No initialisation required, test case is evaluation only.

I<B<Stimulation and Measurement>>

1. Load SPI measurement from file.

    SPI_trace_load_file( 'MeasurementLabel' => 'Measurement_SMI7', # unique measurement label
                         'FileName' => 'C:\\AB12\\AB12_SPI_Record_B50_TestZip\\150331_151550.dat',     # complete measurement file path and name
                       );
2. Get trace dataref in hash format.
    $measdata_href = SPI_trace_get_dataref( 'MeasurementLabel' => 'Measurement_SMI7',
                                            'SPI_Node' => $tcpar_SPI_NODE,
                                            'StartTime_ms' => 2315,
                                            'EndTime_ms' => 2317 );

    $measdata_href looks like this : 
    
    $measdata_href = {
                         '2316.133325' => {
                          'MODULE COMMAND__Write::MOSI::Data' => '147',
                          'MODULE COMMAND__Write::MOSI::Page' => '147',
                          'MODULE COMMAND__Write::MISO::Page' => '0',
                          'MODULE COMMAND__Write::MOSI::Adr' => '5',
                          'MODULE COMMAND__Write::MISO::MIDSMI710_1' => 'Valid',
                          'MODULE COMMAND__Write::MISO::Data' => '862'
                         },
                         '2316.138125' => {
                          'MODULE COMMAND__Read Data::MOSI::Adr' => '5',
                          'MODULE COMMAND__Read Data::MISO::MIDSMI710_1' => 'Valid',
                          'MODULE COMMAND__Read Data::MISO::Page' => '0',
                          'MODULE COMMAND__Read Data::MOSI::Page' => '0',
                          'MODULE COMMAND__Read Data::MISO::Data' => '147',
                          'MODULE COMMAND__Read Data::MOSI::Data' => '0'
                         },
                     }
I<B<Evaluation>>

1. Evaluate sequence from trace
    ($verdict, $detectedSequence_aref) = SPI_EVAL_check_command_sequence(    
                                            'MeasurementData_href' => 'Measurement_SMI7', 
                                            'CommandList' => [  'MODULE COMMAND__Write', 'MODULE COMMAND__Read Data',],
                                             # expected command sequence
                                       );

I<B<Finalisation>>

No finalization required, test case is evaluation only


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

    LIST 'SPI_CMD_SEQ' => expected command sequence
    SCALAR 'SPI_NODE' => Node name 
    SCALAR 'TRACE_FILE_PATH' => complete trace file path including the name( .dat file )
    SCALAR 'START_TIME_ms' => start time in milli seconds
    SCALAR 'END_TIME_ms' =>  end time in milli seconds 


=head2 PARAMETER EXAMPLES

    SPI_CMD_SEQ = @('READ_LF_ACC2__DATA__SMI700_2', 'READ_LF_ACC1__CURRENT_DATA__SMI700_2', 'READ_HF_ACC2__CURRENT_DATA__SMI700_2')
    SPI_NODE = 'SMI7xx'
    TRACE_FILE_PATH =  'C:\\AB12\\AB12_SPI_Record_B50_TestZip\\150331_151550.dat'
    START_TIME_ms = 0
    END_TIME_ms= 700

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_SPI_CMD_SEQ;
my $tcpar_SPI_NODE;
my $tcpar_TRACE_FILE_PATH;
my $tcpar_START_TIME_ms;
my $tcpar_END_TIME_ms;
my $tcpar_Start_Command;
my $tcpar_offset_Time_ms;
################ global parameter declaration ###################
#add any global variables here

our $PURPOSE;
our $TC_name = "TC_SPI_Development";

my $measurement_label = 'CommandSequenceMeasurement';
my $measdata_href;
#-------------------------------------------------------------------------------
sub TC_set_parameters {
#-------------------------------------------------------------------------------
    $tcpar_SPI_CMD_SEQ = GEN_Read_mandatory_testcase_parameter('SPI_CMD_SEQ', 'byref');
    
    $tcpar_SPI_NODE = GEN_Read_mandatory_testcase_parameter('SPI_NODE');
    $tcpar_TRACE_FILE_PATH = GEN_Read_mandatory_testcase_parameter('TRACE_FILE_PATH');
    $tcpar_START_TIME_ms = GEN_Read_optional_testcase_parameter('START_TIME_ms');
    $tcpar_END_TIME_ms = GEN_Read_optional_testcase_parameter('END_TIME_ms');
    $tcpar_Start_Command = GEN_Read_optional_testcase_parameter('StartCommand');
    $tcpar_offset_Time_ms = GEN_Read_optional_testcase_parameter('TimeOffsetStartCommand_ms');

    return 1;
}

#-------------------------------------------------------------------------------
sub TC_initialization {
#-------------------------------------------------------------------------------
    S_w2log( 1, "No initialization required, test case is evaluation only" );                      

    return 1;
}

#-------------------------------------------------------------------------------
sub TC_stimulation_and_measurement {
#-------------------------------------------------------------------------------

    S_teststep("Get trace dataref for given time range ( $tcpar_START_TIME_ms to $tcpar_END_TIME_ms ) for node $tcpar_SPI_NODE", 'AUTO_NBR');
    
    S_teststep_2nd_level("Load SPI measurement from file $tcpar_TRACE_FILE_PATH", 'AUTO_NBR');
    
    my $actualMeasurementLabel = SPI_trace_load_file('MeasurementLabel' => $measurement_label, # unique measurement label
                        'FileName' => $tcpar_TRACE_FILE_PATH, # complete measurement file path and name
                        );
                        
    S_teststep_2nd_level("Get trace dataref in hash format", 'AUTO_NBR');
    $measdata_href = SPI_trace_get_dataref( 'MeasurementLabel' => $actualMeasurementLabel,
                                            'SPI_Node' => $tcpar_SPI_NODE,
                                            'StartTime_ms' => $tcpar_START_TIME_ms,
                                            'EndTime_ms' => $tcpar_END_TIME_ms  );     
    S_dump2pmFile( "VariableToDump" => $measdata_href );
    return unless(defined $measdata_href);            

    return 1;
}

#-------------------------------------------------------------------------------
sub TC_evaluation {
#-------------------------------------------------------------------------------

    S_teststep("Get detected sequence from trace", 'AUTO_NBR');
    my ($verdict, $detectedSequence_aref) = SPI_EVAL_check_command_sequence('MeasurementData_href' => $measdata_href, 
                                                             'CommandList' => $tcpar_SPI_CMD_SEQ,);
                                                             
    return unless(defined $verdict);
                                                         
    my $commandIndex = 0;
    foreach my $expectedCommand (@{$tcpar_SPI_CMD_SEQ})
    {
        my $detectedCommand = $detectedSequence_aref -> [$commandIndex];
        if(not defined $detectedCommand)
        {
            $detectedCommand = 'No_matching_command_found';
        }
        my $commandNumber = $commandIndex+1;
        S_teststep("Check command $commandNumber in given sequence ", 'AUTO_NBR', "Command_$expectedCommand\_$commandNumber");
        S_teststep_expected("$expectedCommand", "Command_$expectedCommand\_$commandNumber"); #evaluation 1
        S_teststep_detected("$detectedCommand", "Command_$expectedCommand\_$commandNumber");        
        $commandIndex++;
    }
    
    return 1;
}

#-------------------------------------------------------------------------------
sub TC_finalization {
#-------------------------------------------------------------------------------
    S_w2log( 1, "No finalization required, test case is evaluation only" );                        

    return 1;
}

1;