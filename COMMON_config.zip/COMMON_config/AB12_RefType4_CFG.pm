# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

package LIFT_config;

### Project Specific Config for LIFT_exec_engine

use Sys::Hostname;
use File::Basename;
use File::Spec;

our ( $left_logo, $right_logo, $LIFT_ProjectDescription, $LIFT_host, $LIFT_exec_path, $LIFT_PRJCFG_path, $LIFT_COMMON_config_path );
our ( $SAD_file, $SAD_fpath, $LIFT_TC_path, @LIFT_TC_paths, $LIFT_TC_DOCS_path, $LIFT_PARA_path, $LIFT_LOG_path, $LIFT_RES_path, $SYC_export_pm_file );

our ( $LIFT_TC_INIT_path, $LIFT_TC_INIT_CAMPAIGN, $LIFT_TC_END_path, $LIFT_TC_END_CAMPAIGN, $LIFT_ProjectDefaults, $LIFT_Testbench );
$LIFT_ProjectDescription = "AB12.1 Core Asset - RT4";

$LIFT_host               = hostname();                                     ### LIFT host
$LIFT_exec_path          = dirname($0);                                    ### LIFT exec path = path from called LIFT_exec_engine
$LIFT_PRJCFG_path        = dirname(__FILE__);                              ### COMMON Project Config PATH - useful for commen mappings             
$LIFT_LOG_path           = "$LIFT_PRJCFG_path/../../reports/";             ### LOGS PATH
$LIFT_LOG_path           = File::Spec->rel2abs("$LIFT_LOG_path");          ### just to clean ab to long path names
$LIFT_RES_path           = "$LIFT_PRJCFG_path/../../reports/";             ### RESULTS PATH
$LIFT_RES_path           = File::Spec->rel2abs("$LIFT_RES_path");          ### just to clean ab to long path names
$LIFT_PARA_path          = "$LIFT_PRJCFG_path/../";                        ### TESTCASE PARAMETERS
$LIFT_TC_path            = "$LIFT_PRJCFG_path/../../Platform/";            ### TESTCASE MODULES
$LIFT_TC_DOCS_path       = "$LIFT_TC_path/Documentation/html/";            ### TESTCASE DOCUMENTATION
$left_logo               = '.\htmldata\images\logo_left.png';              ### TODO : to be set correctly
$right_logo              = '.\htmldata\images\logo_right.png';             ### TODO : to be set correctly
$LIFT_TC_INIT_path       = "$LIFT_PRJCFG_path/IC";
$LIFT_TC_INIT_CAMPAIGN   = "IC_AB12_CA.DEFAULT";                           ### Init campaign to be executed / can be even set via cmd line option -IC xxxx

# @LIFT_TC_paths           = ( "$LIFT_PRJCFG_path/../TCs_CustLib/", "$LIFT_PRJCFG_path/../../Platform/" );    ### TESTCASE MODULES
$LIFT_TC_END_path        = "$LIFT_PRJCFG_path/IC";                  ### End campaign path
# $LIFT_TC_END_CAMPAIGN    = "EC_CI";                                 ### End campaign to be executed

### 
$SAD_fpath = "$LIFT_PRJCFG_path/../../results/";
###

#additional setting for SAD file
#our $SAD_file = "$LIFT_PRJCFG_path/SW/"; # variable $SAD_file will be replaced with sad file present in the folder SW
# If both $SAD_file and $SAD_fpath is configured then sad file configured in $SAD_file will be considered.
# If both $SAD_file and $SAD_fpath is configured but sad file does not exist then $SAD_fpath is considered.

# RT4 - M03.18.2
$SYC_export_pm_file = "$LIFT_PRJCFG_path/SysTestExport_AB12_RefType4_SYC_M03_18_2.pm";
$SYC_variant_name   = "AB12_RefType4_SYC_General_Rev_1_36";

#### PROJECT Defaults
require "$LIFT_PRJCFG_path/Mappings/AB12_RefType4_ProjectConst_Main.pm";     # contains package LIFT_PROJECT
require "$LIFT_PRJCFG_path/Mappings/AB12_RefType4_ProjectConst_TSG4.pm";     # use Device mapping file
require "$LIFT_PRJCFG_path/Mappings/AB12_RefType4_ProjectConst_QuaTe.pm";    # contains package LIFT_PROJECT
require "$LIFT_PRJCFG_path/Mappings/AB12_RefType4_ProjectConst_CREIS.pm";    # CREIS defaults AB12_ProjectConst_SPI
$LIFT_ProjectDefaults = $LIFT_PROJECT::Defaults;                             # initial assignment of  $LIFT_ProjectDefaults

### Testbench configuration
require "$LIFT_PRJCFG_path/LIFT_Testbenches.pm";
$LIFT_Testbench = $LIFT_Testbenches::Testbench->{$LIFT_host};

unless ( $LIFT_Simulator = $LIFT_Testbench->{'Devices'}{'LabCar'}{'Serial_Number'} ) {
	$LIFT_Simulator = 'None_LIFT_LC';
}
if ( -f "$LIFT_PRJCFG_path/Mappings/Mapping_DEVICE_RefType4.pm" ) {
	require "$LIFT_PRJCFG_path/Mappings/Mapping_DEVICE_RefType4.pm";
	$LIFT_DeviceMapping = $LIFT_PROJECT::Defaults->{'Mapping_DEVICE'};
}



   if ( -f "$LIFT_PRJCFG_path/Mappings/Mapping_PSI5_settings_RT4_PAS6e_PPS3e.pm" ) {   ### Manitoo PAS Mapping configuration for SW M3.18 onwords
    require "$LIFT_PRJCFG_path/Mappings/Mapping_PSI5_settings_RT4_PAS6e_PPS3e.pm";     ### -> extends $LIFT_ProjectDefaults
   }
 
if ( -f "$LIFT_PRJCFG_path/Mappings/Mapping_SPI_network.pm" ) {        
    require "$LIFT_PRJCFG_path/Mappings/Mapping_SPI_network.pm";       
}

if ( defined $ENV{'DISPOSAL_FLAG'} and $ENV{'DISPOSAL_FLAG'} eq 'TRUE' ) {
	if ( -f "$LIFT_PRJCFG_path/Mappings/ACEA_Mapping_DIAG.pm" ) {               ### Diag Mapping for DISPOSAL configuration
	    require "$LIFT_PRJCFG_path/Mappings/ACEA_Mapping_DIAG.pm";              ### -> extends $LIFT_ProjectDefaults
	}
}
else {
	if ( -f "$LIFT_PRJCFG_path/Mappings/Mapping_DIAG.pm" ) {               ### Diag Mapping configuration
	    require "$LIFT_PRJCFG_path/Mappings/Mapping_DIAG.pm";              ### -> extends $LIFT_ProjectDefaults
	}
}

if ( -f "$LIFT_PRJCFG_path/Mappings/Mapping_CustomerData.pm" ) {               ### Mapping Customer data required Test Area dem 
    require "$LIFT_PRJCFG_path/Mappings/Mapping_CustomerData.pm";              ### 
}

if ( -f "$LIFT_PRJCFG_path/Mappings/AB12_RefType4_CAN_mapping.pm" ) {    ### CAN mapping
    require "$LIFT_PRJCFG_path/Mappings/AB12_RefType4_CAN_mapping.pm";    ### -> extends $LIFT_ProjectDefaults
}

if ( -f "$LIFT_PRJCFG_path/Mappings/NET_Access_mapping.pm" ) {    ### Netaccess mapping
    require "$LIFT_PRJCFG_path/Mappings/NET_Access_mapping.pm";    ### -> extends $LIFT_ProjectDefaults
}
if ( -f "$LIFT_PRJCFG_path/Mappings/Mapping_Fault.pm" ) {
	require "$LIFT_PRJCFG_path/Mappings/Mapping_Fault.pm";
	$LIFT_FaultMapping = $LIFT_PROJECT::Defaults->{'Mapping_Fault'};
}

if ( -f "$LIFT_PRJCFG_path/Mappings/Mapping_FAULT_extension.pm" ) {
	require "$LIFT_PRJCFG_path/Mappings/Mapping_FAULT_extension.pm";
	$LIFT_FaultMapping = $LIFT_PROJECT::Defaults->{'Mapping_Fault'};
}
##############################################################################
if ( -f "$LIFT_PRJCFG_path/Mappings/Mapping_DEVICE_RefType4.pm" ) {
	require "$LIFT_PRJCFG_path/Mappings/Mapping_DEVICE_RefType4.pm";
	$LIFT_DeviceMapping = $LIFT_PROJECT::Defaults->{'Mapping_DEVICE'};
}

### EDR mapping
# This file is generated by SCIP -> it must be replaced for every SW checkpoint!
our $EDR_variant_name = 'EdrRefType4';
if ( -f "$LIFT_PRJCFG_path/Mappings/Mapping_EDR_Core_Asset_AB12_RefTyp4.pm" ) {
    require "$LIFT_PRJCFG_path/Mappings/Mapping_EDR_Core_Asset_AB12_RefTyp4.pm";
}
# Mapping contains variant specific settings to be done by the user
if ( -f "$LIFT_PRJCFG_path/Mappings/Mapping_EDR_UserSettings_RefType4.pm" ) {
    require "$LIFT_PRJCFG_path/Mappings/Mapping_EDR_UserSettings_RefType4.pm";
}


1;
