package LIFT_EXEC_OPTIONS;

$EXEC_OPTIONS = {

	'EDR' => {
		'OfflineReportValidation' => 1, #some validation test cases will behave differently if this option is set
		'CreisOfflineEvalReporting' => 1,
	},

};