package LIFT_Testbenches;

use File::Basename;
use Cwd 'abs_path';
my $PRJCFG_path = abs_path( dirname(__FILE__) );    #   absolute path like C:\working_somewhere\...\lift_project_config\

our $Testbench;
$Testbench={

    'BIE1-C-00000' => {    # MANITOO TESTBENCH AB12.1 RT4  () in Bie office )
        ### ----------- Device Configuration Section -----------
        'Devices' => {

            'PDLayer' => {    # example values given here
                'BusType'             => 'CANFD',    # bus type, possible values are 'CAN', 'FlexRay' ,  'CANFD'
                'Channel_Nbr_0-based' => 1,        # Vector hardware channel number (0-based)
                'Hw_Serial_Nbr'       => 2892,    # Vector hardware serial number
            },

            'Manitoo' => {
                'Connection_Type'    => 'USB',
                'FET_HW_Type'        => 'FET_3_Ports',
                'FET_PortsSelection' => 1,
                'Description'        => "only for Manitoo testing ",
            },
            'PeriBox' => {
                'Description'       => "Peribox Manitoo RefType4 Testbench",
                'Test_Bench_Number' => 'BIE1-C-00000',
            },
            'CD' => {
                'CANchannel' => 1,
                'CANHWSerialNo' => 2892,
            },
            'CANoe' => {
                'Hostname'      => 'BIE1-C-00000',
                'Online_Config' => $PRJCFG_path . '\..\CANoe_simulation\AB12_Bussimulation\AB12_CoreAssets_Bussimulation_CANFD.cfg',
                'Log_File'      => $PRJCFG_path . '\..\CANoe_simulation\AB12_Bussimulation\LogFiles\CANOE.asc',
                'ILUsed'        => 'Yes',                                                                                                                        # Option : 'Yes' if Interaction layer used , otherwise 'No'
            },
			'Renesas_Flash_Tool' => {
				'ECU_type'          => 'D3A',                              #  ECU_type can be R1L, R1L1MB, D4 or D3 or D3A
				'FlashTool_Sl_Num'  => '6CS090263C',                       #  written on flashtool
				'Project_Workspace' => $PRJCFG_path . '\Tools\Renesas',    # Renesas project workspace
			},

        },    ## End of ~~~ Device Configuration Section ~~~
       
        ### ----------- Function Configuration Section -----------
        'Functions' => {

            'Labcar' => {    # see documentaton of LIFT_labcar for possible devices
                'line'       => 'PeriBox_NoPower',
                'power_Ubat' => 'Manitoo',
            },
            
            'PSI5_Access' => {
                'simulate' => 'Manitoo',
            },
            
            ### --- Function Area : CAN_Access
            'CAN_Access' => {
                'basic'     => 'CANoe',               # function groups: read, write, trace, simulation
                'stimulate' => 'CANoe',               # function groups: Stimulate signals , call CAPL
            },
            
            'ProdDiag' => {
                'generation' => 'AB12',
                'basic'      => 'PDLayer',
            },

            'CD' => 'CAN',                            #either 'CAN' (for CD via CANoe module) or 'ODIS' (for CD via ODIS tool)
              
              
        'SPI_Manipulation' => {
        	
              'Labcar' => {    # see documentaton of LIFT_labcar for possible devices
                'line'       => 'PeriBox_NoPower',
                'power_Ubat' => 'Manitoo',
            },
            
            'PSI5_Access' => {
                'simulate' => 'Manitoo',
            },
            
            'SPI_Access' => {
                'trace'      => 'Manitoo',
                'manipulate' => 'Manitoo',
            },
            
            ### --- Function Area : CAN_Access
            'CAN_Access' => {
                'basic'     => 'CANoe',               # function groups: read, write, trace, simulation
                'stimulate' => 'CANoe',               # function groups: Stimulate signals , call CAPL
            },
            
            'ProdDiag' => {
                'generation' => 'AB12',
                'basic'      => 'PDLayer',
            },

            'CD' => 'CAN',                            #either 'CAN' (for CD via CANoe module) or 'ODIS' (for CD via ODIS tool) 
              
              },   
        
			'FLASH_ONLY' => {
				'Labcar' => {                     # see documentaton of LIFT_labcar for possible devices
					'line'       => 'PeriBox_NoPower',    # possible devices: TSG4, MLC, PeriBox
					'power_Ubat' => 'Manitoo',              # possible devices: TSG4, MLC, TOE1, TOELLNER, NIDAQ, IDX,
				},
				
			 'ProdDiag' => {
                'generation' => 'AB12',
                'basic'      => 'PDLayer',
            },
			
			},
        },    ## End of ~~~ Function Configuration Section ~~~
    },        ## End of BIE1-C-00000
    
  ######################################################################################################################  
  ######################################################################################################################
  
    
    ### ----------- LIFT control host -----------
	'BIEZ00HL' => {    # LIFT PC host name  -  Core Asset EDR setup   (good example for TSG4+LCT with crash setup)
	### ----------- Device Configuration Section -----------
		'Devices' => {
			'TSG4' => {
				'Hostname'          => 'BIEZ00HL',
				'Test_Bench_Number' => 20,                                #     only for logging purpose
				'Description'       => "Core Asset EDR setup L2B-R1.4",
				'CANHWSerialNo'     => 3685,                              # 573, 2890            # 2890 -> VN1640
				'CANchannel'        => 2,                                 # 2890 -> 3  ,        # VN1640 CH4        slot 2 on VN89xx Box, because FR channel does not count
				'POWER'             => {
					'Ubat' => "internal",                                 #  POWER Devices:: LabCar,TOE1 or IDX
					'UF'   => "internal",                                 #  POWER Devices:: LabCar,TOE1 or IDX
				},
			},

			'PDLayer' => {                                                # example values given here
				'BusType'             => 'CANFD',                         # bus type, possible values are 'CAN', 'FlexRay'
				'Channel_Nbr_0-based' => 3,                               # Vector hardware channel number (0-based)
				'Hw_Serial_Nbr'       => 3685,                            # Vector hardware serial number                573 ->   VN89xx Box
			},

			'CD' => {
				'CANHWSerialNo' => 3685,
				'CANchannel'    => 3,                                     # f�r 573
			},
			
			'QuaTe' => {
				'Controllers' => 2,                                       #RT4, RT3.2: 2 - RT3: 3             #   number of controllers connected
			},
			
			'CANoe' => {
				'Hostname'      => 'BIEZ00HL',
				'Online_Config' => $PRJCFG_path . '\..\CANoe_simulation\AB12_Bussimulation\AB12_CoreAssets_Bussimulation_CANFD.cfg',
				'Log_File'      => $PRJCFG_path . '\..\CANoe_simulation\AB12_Bussimulation\LogFiles\CANOE.asc',
				'ILUsed'        => 'Yes',
			},
			
			'Renesas_Flash_Tool' => {
				'ECU_type'          => 'D3A',                                                  #  ECU_type can be R1L, R1L1MB, D4 or D3 or D3A
				'FlashTool_Sl_Num'  => '7CS106857C',                                           #  written on tool
				'Project_Workspace' => $PRJCFG_path . '\Tools\Renesas',    # Renesas project workspace
			},
		}, ## End of ~~~ Device Configuration Section ~~~
		
		
		   ### ----------- Function Configuration Section -----------
		'Functions' => {
			'Labcar' => {                                                                      # see documentaton of LIFT_labcar for possible devices
				'line'                  => 'TSG4',
				'extended'              => 'TSG4',
				'disposal'              => 'TSG4',
				'power_Ubat'            => 'TSG4',
				'measure_connector'     => 'TSG4',
				'measure_trace_digital' => 'LCT',
			},

			'ProdDiag' => {
				'generation' => 'AB12',                                                        # Airbag generation, possible values: currently 'AB12' only
				'basic'      => 'PDLayer',                                                     # Device for function group 'basic' (all functions): device currently only 'PDLayer'
			},

			'CD' => 'CAN',                                                                     # was formerly 'Diagnosis', see documentaton of LIFT_CD for possible devices

			'CAN_Access' => {
				'basic'     => 'CANoe',
				'stimulate' => 'CANoe',                                                        # function groups: read, write, trace, simulation
			},

			'Crash_simulation' => {
				'crash_database' => 'MDSRESULT',                                               # possible devices: MDSRESULT
				'crash_sensors'  => 'QuaTe',                                                   # possible devices: QuaTe, IDEFIX
			},

			'CREIS' => {                                                                       
				'Labcar' => {
					'line'                  => 'TSG4',
					'extended'              => 'TSG4',
					'disposal'              => 'TSG4',
					'power_Ubat'            => 'TSG4',
					'measure_connector'     => 'TSG4',
					'measure_trace_digital' => 'LCT',
				},

				#				'PD' => 'PD',
				
				'ProdDiag' => {
					'generation' => 'AB12',                                                    # Airbag generation, possible values: currently 'AB12' only
					'basic'      => 'PDLayer',                                                 # Device for function group 'basic' (all functions): device currently only 'PDLayer'
				},
				
				'CD'         => 'CAN',
				
				'CAN_Access' => {
					'basic'     => 'CANoe',
					'stimulate' => 'CANoe',
				},

				#'NET_Access' => {
				#'basic'     => 'CANoe',    # function groups: read, write, trace, simulation
				#'stimulate' => 'CANoeCtrl',    # function groups: Stimulate signals ,CAPL
				# },
				
				'Crash_simulation' => {
					'crash_database' => 'MDSRESULT',    # possible devices: MDSRESULT
					'crash_sensors'  => 'QuaTe',        # possible devices: QuaTe, IDEFIX
					'trigger'        => 'QuaTe',        # possible devices: QuaTe, IDEFIX, can_access
				},
			},
			'FLASH_ONLY' => {
				
				'Labcar' => {                           # see documentaton of LIFT_labcar for possible devices
					'line'       => 'TSG4',             # possible devices: TSG4, MLC, PeriBox
					'power_Ubat' => 'TSG4',             # possible devices: TSG4, MLC, TOE1, TOELLNER, NIDAQ, IDX,
				},
				'ProdDiag' => {
					'generation' => 'AB12',             # Airbag generation, possible values: currently 'AB12' only
					'basic'      => 'PDLayer',          # Device for function group 'basic' (all functions): device currently only 'PDLayer'
				},
			},
		},## End of ~~~ Function Configuration Section ~~~
	},    ## End of ~~ BIEZ00HL ~~

  ######################################################################################################################  
  ######################################################################################################################

    ### ----------- LIFT control host -----------
    'BMH1084235' => {    #   Core Asset SW test bench: TSG4 with crash setup)
        ### ----------- Device Configuration Section -----------
        'Devices' => {
            'TSG4' => {
                'Hostname'          => 'BMH1084235',
                'Test_Bench_Number' => "TS 026 (TestSetup 026)",    # test bench number / name
                'Description'       => "AB12 CA SW RBT RT4",        # test bench description
                'CANHWSerialNo'     => 23686,                       # VN1640A
                'CANchannel'        => 3,                           # used CAN channel for TSG4 control
            },

            'PDLayer' => {                                          # example values given here,
                'BusType'             => 'CANFD',                   # bus type, possible values are 'CAN', 'FlexRay'
                'Channel_Nbr_0-based' => 2,                         # Vector hardware channel number (0-based)
                'Hw_Serial_Nbr'       => 23686,                     # Vector hardware serial number
            },

            'CD' => {
                'CANHWSerialNo' => 23686,
                'CANchannel' => 2,
            },
            
			'QuaTe' => {
                'Controllers' => 2,    # number of controllers connected
            }, 
            
            'CANoe' => {
                'Hostname'      => 'BMH1084235',
                'Online_Config' => $PRJCFG_path . '\..\CANoe_simulation\AB12_Bussimulation\AB12_CoreAssets_Bussimulation_CANFD.cfg',
                'Log_File'      => $PRJCFG_path . '\..\CANoe_simulation\AB12_Bussimulation\LogFiles\CANOE.asc',
				
            },
            
            'Renesas_Flash_Tool' => {
                'ECU_type'         => 'D3A',          #  ECU_type can be R1L, R1L1MB, D4 or D3
                #'FlashTool_Sl_Num' => '8DS125209C',    #  written on flashtool     from original testbench file
                'FlashTool_Sl_Num' => '8DS125224C',    #  written on flashtool
				'Project_Workspace' => $PRJCFG_path . '\Tools\Renesas',    # Renesas project workspace
                'FlashTool_exe_path' => 'C:\Program Files (x86)\Renesas Electronics\Programming Tools\Renesas Flash Programmer V2.05\RFP.exe',
            },			
        },    ## end of ~~~ Device Configuration Section ~~~
        
        
        ### ----------- Function Configuration Section -----------
        'Functions' => {
            ### ----------- Default Functions -----------
            'Labcar' => {
                'line'       => 'TSG4',
                'extended'   => 'TSG4',
                'disposal'   => 'TSG4',
                'power_Ubat' => 'TSG4',
                'power_UF'   => 'TSG4',
              # 'measure_connector'     => 'TSG4',
              # 'measure_trace_digital' => 'LCT',
            },

            'ProdDiag' => {
                'generation' => 'AB12',
                'basic'      => 'PDLayer',
            },

            'CD' => 'CAN',

            'CAN_Access' => {
                'basic'     => 'CANoe',
                'stimulate' => 'CANoe',
            },
			
			'Crash_simulation' => {
                'crash_database' => 'MDSRESULT',
                'crash_sensors'  => 'QuaTe',
            },
            
            'CREIS' => {                                                                       # test type for switching ON and OFF ECU
				'Labcar' => {
					'line'                  => 'TSG4',
					'extended'              => 'TSG4',
					'disposal'              => 'TSG4',
					'power_Ubat'            => 'TSG4',
					'measure_connector'     => 'TSG4',
					'measure_trace_digital' => 'LCT',
				},

				#				'PD' => 'PD',
				
				'ProdDiag' => {
					'generation' => 'AB12',                                                    # Airbag generation, possible values: currently 'AB12' only
					'basic'      => 'PDLayer',                                                 # Device for function group 'basic' (all functions): device currently only 'PDLayer'
				},
				
				'CD'         => 'CAN',
				
				'CAN_Access' => {
					'basic'     => 'CANoe',
					'stimulate' => 'CANoe',
				},

				#'NET_Access' => {
				#'basic'     => 'CANoe',    # function groups: read, write, trace, simulation
				#'stimulate' => 'CANoeCtrl',    # function groups: Stimulate signals ,CAPL
				#},
				
				'Crash_simulation' => {
					'crash_database' => 'MDSRESULT',    # possible devices: MDSRESULT
					'crash_sensors'  => 'QuaTe',        # possible devices: QuaTe, IDEFIX
					'trigger'        => 'QuaTe',        # possible devices: QuaTe, IDEFIX, can_access
				},
			},

            ## end of ~~~ Default Functions ~~~
            
			'FLASH_ONLY' => {
				
				'Labcar' => {                                              # see documentaton of LIFT_labcar for possible devices
					'line'       => 'TSG4',                                # possible devices: TSG4, MLC, PeriBox
					'power_Ubat' => 'TSG4',                                # possible devices: TSG4, MLC, TOE1, TOELLNER, NIDAQ, IDX,
				},
				
        		'ProdDiag' => {
        			'generation' => 'AB12',                                    # Airbag generation, possible values: currently 'AB12' only
        			'basic'      => 'PDLayer',                                 # Device for function group 'basic' (all functions): device currently only 'PDLayer'
        		},
			},
            
        },    ## End of ~~~ Function Configuration Section ~~~
    }, #####  End of BMH1084235 ######
	
	### ----------- LIFT control host -----------
	
	'BMH1117456' => {    #   test tower for normal/MANITOO execution and test development
        ### ----------- Device Configuration Section -----------
        'Devices' => {
            'TSG4' => {
                'Hostname'          => 'BMH1117456',
                'Test_Bench_Number' => "TS 020 (TestSetup 020)",    # test bench number / name
                'Description'       => "AB12 CA SW RBT RT4",        # test bench description
                'CANHWSerialNo'     => 29845,                       # VN1640A
                'CANchannel'        => 2,                           # used CAN channel for TSG4 control
			#####Toellner power supply		
			'POWER'=>
 				{
 					'Ubat' => "TSG4",
 					'UF' => "TSG4",
					#'device' => "TOE1"
				}, 
			},

            'PDLayer' => {                                          # example values given here,
                'BusType'             => 'CANFD',                   # bus type, possible values are 'CAN', 'FlexRay'
                'Channel_Nbr_0-based' => 0,                         # Vector hardware channel number (0-based)
                'Hw_Serial_Nbr'       => 29845,                     # Vector hardware serial number
            },
                'PD' => {
#                	'Hostname'      => 'SI-Z0OUS',
#                	'CANHWSerialNo' => '957',                                      # VN8912A  device
#                	'CANchannel'    => 3,                                          # to be checked with PsDiag
					'AB12' => 1,
				},
            'Manitoo' => {
                'Connection_Type'    => 'COM11',
                'FET_HW_Type'        => 'FET_3_Ports',
                'FET_PortsSelection' => 1,
            },

            'CD' => {
                'Hostname'      => 'BMH1117456',
                'CANHWSerialNo' => 29845,

                #               'AB12'          => 1,
                'CANchannel' => 1,
            },
		#####Toellner power supply	
			# 'TOE1' =>
            # {
            # 'connect' => 'GPIB:2',
            # },

            'CANoe' => {
                'Hostname'      => 'BMH1117456',
                 'Online_Config' => $PRJCFG_path . '\..\CANoe_simulation\AB12_Bussimulation\AB12_CoreAssets_Bussimulation_CANFD.cfg',
                'Log_File'      => $PRJCFG_path . '\..\CANoe_simulation\AB12_Bussimulation\LogFiles\CANOE.asc',
				'ILUsed' => 'Yes',
			}, 
			'Renesas_Flash_Tool' => {
                'ECU_type'         => 'D3A',          #  ECU_type can be R1L, R1L1MB, D4 or D3
                                                      #  RenesasR1xTypeB = "R1L"
                                                      #  RenesasR1x10623 = "R1L"
                                                      #  RenesasR1xTypeC = "R1L1MB"
                                                      #  RenesasR1x10643 = "R1L1MB"
                                                      #  RenesasP1xD3    = "D3"
                                                      #  RenesasP1xD4    = "D4"
                                                      #  user can also use their own configuration by giving it as ECU type string in this format 'rwsProj;needsCleanHex;extendCodeFlash'
                                                      #  e.g.: geely;1;1 where geely has to be a folder below config/Tools/Renesas with same structure like R1L1MB_ecuFlash
                'FlashTool_Sl_Num' => '8DS125209C',    #  written on flashtool
				'Project_Workspace' => $PRJCFG_path . '\Tools\Renesas',    # Renesas project workspace
                'FlashTool_exe_path' => 'C:\Program Files (x86)\Renesas Electronics\Programming Tools\Renesas Flash Programmer V2.05\RFP.exe',
			},
        },    ## end of ~~~ Device Configuration Section ~~~
        ### ----------- Function Configuration Section -----------
        'Functions' => {
            ### ----------- Default Functions -----------
            'Labcar' => {
                'line'       => 'TSG4',
                'extended'   => 'TSG4',
                'disposal'   => 'TSG4',
                'power_Ubat' => 'TSG4',  #####Toellner power supply	- change the name from TOE1 to TSG4 or viceversa
                'power_UF'   => 'TSG4',  #####Toellner power supply	- change the name from TOE1 to TSG4 or viceversa

                'measure_connector'     => 'TSG4',
                'measure_trace_digital' => 'LCT',
                              # 'measure_trace_analog'  => 'TRC',
                #               'measure_once'          => 'DMM1',
            },
			
			'NET_Access' => {
                #
				'basic' =>  'CANoe', # function groups: read, write, trace, simulation
                #					# 'stimulate' => 'CANoeCtrl', 
				} ,
			'PERIPHERIE'=>{
 				'device' => 'TSG4',
 			},
			
            'ProdDiag' => {
                'generation' => 'AB12',
                'basic'      => 'PDLayer',
            },

            'CD' => 'CAN',    # was formerly 'Diagnosis', see documentaton of LIFT_CD for possible devices

            'CAN_Access' => {
                'basic'     => 'CANoe',
                'stimulate' => 'CANoe',
            },
			'SPI_Access' => {
				'trace'      => 'Manitoo',    # function groups: trace, manipulate
				'manipulate' => 'Manitoo',       #Manitoo
				#'logicanalyzer' => 'LA_AcuteTravelLogic',
			},

            'PSI5_Access' => {
                'simulate' => 'Manitoo',    #Device used to simulate
            },
            
			'FLASH_ONLY' => {
                'Labcar' => {    # see documentaton of LIFT_labcar for possible devices
                    'line'       => 'TSG4',    # possible devices: TSG4, MLC, PeriBox
                    'power_Ubat' => 'TSG4',              # possible devices: TSG4, MLC, TOE1, TOELLNER, NIDAQ, IDX,
                },

        		'ProdDiag' => {
        			'generation' => 'AB12',                                    # Airbag generation, possible values: currently 'AB12' only
        			'basic'      => 'PDLayer',                                 # Device for function group 'basic' (all functions): device currently only 'PDLayer'
        		},

            },
			
        },## End of ~~~ Function Configuration Section ~~~
    },	#####  End of BMH1117456 ######

};
