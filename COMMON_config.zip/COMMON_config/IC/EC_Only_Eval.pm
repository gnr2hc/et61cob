#### TEST CASE MODULE
package EC_Only_Eval;

#### DONT MODIFY THIS SECTION ####
use strict;
###-------------------------------
my $VERSION = q$Revision: 1.1 $;
my $HEADER = q$Header: config/EC_Only_Eval.pm 1.1 2015/07/21 15:54:29CEST Baeuerle Katharina (CC-PS/EPS2) (ZIK1ABT) develop  $;
##################################

#### INCLUDE ENGINE MODULES ####
use LIFT_general;

################################

## testcase parameters

## other local vars

our $PURPOSE = "LIFT END CAMPAIGN for ONLY EVALUATION test lists";

##################################
####  TESTCASE STARTS HERE    ####
##################################



sub TC_set_parameters {

    return 1;
}



#### INITIALIZE TC #####
sub TC_initialization {

    S_w2rep(" *** Starting End Campaign ***\n") ;

    S_w2rep(" EC -> set vercict PASS as default\n");
    S_set_verdict( VERDICT_PASS );

    my $link = '\\\\'.$LIFT_config::LIFT_host."/$main::REPORT_PATH"."_result.html";
    $link =~ s/\:/\$/g;
    my $mailtext = "Test finshed with $main::CAMPAIGN_STATUS\n\nTest result link : $link\n\nthis is a generated message, please do not reply.";

    if (@LIFT_config::mailto){
        S_send_mail('','test finished',$mailtext,@LIFT_config::mailto);
    }
    return 1;
}


### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {
	
	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	return 1;
}


#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	return 1;
}


1;