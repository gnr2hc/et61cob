#     ___       _ _      ____                            _
#    |_ _|_ __ (_) |_   / ___|__ _ _ __ ___  _ __   __ _(_) __ _ _ __
#     | || '_ \| | __| | |   / _` | '_ ` _ \| '_ \ / _` | |/ _` | '_ \
#     | || | | | | |_  | |__| (_| | | | | | | |_) | (_| | | (_| | | | |
#    |___|_| |_|_|\__|  \____\__,_|_| |_| |_| .__/ \__,_|_|\__, |_| |_|
#                                           |_|            |___/

package IC_AB12_CA;

#### DONT MODIFY THIS SECTION ####
use strict;

#### INCLUDE STANDARD PERL LIBS ####
use File::Basename;

###-------------------------------
my $VERSION = q$Revision: 1.7 $;
my $HEADER  = q$Header: config/IC_AB12_CA.pm 1.7 2019/06/28 09:34:05IST Phan Khanh Duy (RBVH/EPS21) (PDA1HC) develop  $;
##################################

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_evaluation;
use LIFT_equipment;
use LIFT_labcar;
use LIFT_ECU_SW_Flash;
use GENERIC_DCOM;
use LIFT_PD;
require LIFT_PD2ProdDiag;
import LIFT_PD2ProdDiag;
use LIFT_ProdDiag;
use LIFT_TEMPERATURE;
use LIFT_FaultMemory;
use LIFT_can_access;
use FuncLib_SYC_INTERFACE;
##################################

## testcase parameters
my $tcpar_Testbench_type;
my $tcpar_Flag_SW_Flash;
my $tcpar_SW_Labels_reading_aref;
my $tcpar_Set_Device_Configuration_href;
my $tcpar_Init_EDR;
my $tcpar_Check_faultfree_system;
my $tcpar_Record_CAN_trace;
my $tcpar_Init_GDCOM;

## other local vars

our $PURPOSE = "LIFT INIT CAMPAIGN for AB12 CA SW Test";

##################################
####  TESTCASE STARTS HERE    ####
##################################

sub TC_set_parameters {

	$tcpar_Testbench_type = S_read_optional_testcase_parameter( 'Testbench_type', "byref", 'DEFAULT' );
	$tcpar_Flag_SW_Flash  = S_read_optional_testcase_parameter( 'Flag_SW_Flash',  'byref', 0 );
	$tcpar_SW_Labels_reading_aref        = S_read_optional_testcase_parameter('SW_Labels_reading');
	$tcpar_Set_Device_Configuration_href = S_read_optional_testcase_parameter('Set_Device_Configuration');
	$tcpar_Init_EDR                      = S_read_optional_testcase_parameter( 'Init_EDR', 'byref', 'yes' );
	$tcpar_Check_faultfree_system        = S_read_optional_testcase_parameter( 'Check_faultfree_system', 'byref', 0 );
	$tcpar_Record_CAN_trace              = S_read_optional_testcase_parameter( 'Record_CAN_trace', 'byref', 1 );
	$tcpar_Init_GDCOM                    = S_read_optional_testcase_parameter( 'Init_GDCOM', 'byref', 1 );

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	S_w2rep(" *** Starting Init Campaign ***\n");

	if ($tcpar_Flag_SW_Flash) {
		S_teststep( " IC -> Initialize test bench equipment - only for flashing", 'AUTO_NBR' );
		EQUIP_init_testbench('FLASH_ONLY');

		my $SW2flash = $LIFT_config::SAD_file;
		unless ($SW2flash) { S_set_error("could not get SAD file from LIFT_config"); return }
		$SW2flash =~ s/\.sad$/.hex/i;
		$SW2flash =~ s/\//\\/g;

		my $SW_file_name = basename($SW2flash);

		S_teststep( " IC -> Flash SW $SW_file_name ... ", 'AUTO_NBR' );
		my $flash_result = ECU_SW_AutoFlash($SW2flash);
	}

	if ( $tcpar_Testbench_type eq 'DEFAULT' ) {
		S_teststep( " IC -> Initialize test bench equipment (DEFAULT settings used from testbench settings)", 'AUTO_NBR' );
		EQUIP_init_testbench();
	}
	else {
		S_teststep( " IC -> Initialize test bench equipment - $tcpar_Testbench_type", 'AUTO_NBR' );
		EQUIP_init_testbench($tcpar_Testbench_type);
	}

	if ($tcpar_Record_CAN_trace) {

		# RBS is initialized // BUT separation control of RBS and trace
		S_teststep( " IC -> CAN simulation start", 'AUTO_NBR' );
		CA_simulation_start();

		S_teststep( " IC -> CAN trace start", 'AUTO_NBR' );
		CA_trace_start();
	}

	if ($tcpar_Init_GDCOM) {
		S_teststep( " IC -> Initialize GDCOM", 'AUTO_NBR' );
		GDCOM_init();
	}

	S_teststep( " IC -> get Project Info in order to resolve SW Version from tetsbench Initialization (from PRD_Init)", 'AUTO_NBR' );
	my $prj_info_href = S_get_project_info();
	if ( defined $prj_info_href->{'ECU_SW_VERSION'} ) {
		my $SWversion = $prj_info_href->{'ECU_SW_VERSION'};
		S_teststep_detected("IC -> current ECU SW Version : $SWversion");
	}

	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {
		
	my $ECU_mode = _check_ECU_mode();    # set FAIL in case of IDLE mode
	S_teststep( "Read FCM 'Bosch' (directly after SW Flash)", 'AUTO_NBR' );
	LIFT_FaultMemory->read_fault_memory('Bosch');

	_Set_Device_Configuration($tcpar_Set_Device_Configuration_href) if ( defined $tcpar_Set_Device_Configuration_href );

	_EDR_initialization() if ( $tcpar_Init_EDR eq 'yes' and $ECU_mode ne 'Idle' );

	S_teststep( "PRD_Clear_Fault_Memory", 'AUTO_NBR' );
	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Reset ECU", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	_SW_Labels_reading($tcpar_SW_Labels_reading_aref) if ( defined $tcpar_SW_Labels_reading_aref );

	S_teststep( "Read all FCM types (after Clear FCM and ECU Reset)", 'AUTO_NBR' );

	S_teststep_2nd_level( "Read FCM 'Bosch'", 'AUTO_NBR', 'read_Bosch_after_quali' );
	my $FCM_Bosch_after_reset_obj = LIFT_FaultMemory->read_fault_memory('Bosch');
	$FCM_Bosch_after_reset_obj->evaluate_faults( {}, 'read_Bosch_after_quali' ) if $tcpar_Check_faultfree_system;

	S_teststep_2nd_level( "Read FCM 'Disturbance'", 'AUTO_NBR' );
	LIFT_FaultMemory->read_fault_memory('Disturbance');

	S_teststep_2nd_level( "Read FCM 'Plant'", 'AUTO_NBR' );
	LIFT_FaultMemory->read_fault_memory('Plant');

	S_teststep_2nd_level( "Read FCM 'Primary'", 'AUTO_NBR' );
	LIFT_FaultMemory->read_fault_memory('Primary');

	_check_ECU_mode();    # set FAIL in case of IDLE mode

	if ($tcpar_Record_CAN_trace) {
		S_teststep( "Power OFF ECU", 'AUTO_NBR' );
		LC_ECU_Off();
		S_wait_ms('TIMER_ECU_OFF');

		S_teststep( " IC -> CAN trace stop", 'AUTO_NBR' );
		CA_trace_stop();

		S_teststep( " IC -> CAN trace store (stops the measurement)", 'AUTO_NBR' );
		my $CAN_trace_file_name_to_store = $main::REPORT_PATH . "/" . "CAN_trace_IC.asc";
		my $stored_CAN_trace_file        = CA_trace_store($CAN_trace_file_name_to_store);
		S_teststep_detected("Stored CAN trace : $stored_CAN_trace_file");

		S_teststep( " IC -> Ensure running CAN(FD) RBS", 'AUTO_NBR' );
		CA_simulation_start();

		LC_ECU_On('U_BATT_DEFAULT');
		S_wait_ms('TIMER_ECU_READY');
	}

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	S_w2rep(" IC -> set verdict PASS to finish init campaign\n");
	S_set_verdict(VERDICT_PASS);

	return 1;
}

##### TC FINALIZATION #####
#sub TC_finalization {
#
#    return 1;
#}

#############################################################################################
sub _check_ECU_mode {

	my $ECU_mode = 'not set';

	S_teststep( "Read PRD_Get_ECU_Properties", 'AUTO_NBR' );
	my $ecuProperties_after_Flash_href = PRD_Get_ECU_Properties();
	foreach my $EcuProp_key ( keys %{$ecuProperties_after_Flash_href} ) {
		foreach my $EcuSubProp_key ( keys %{ $ecuProperties_after_Flash_href->{$EcuProp_key} } ) {
			my $EcuSubProp_value = $ecuProperties_after_Flash_href->{$EcuProp_key}{$EcuSubProp_key};
			S_w2rep( " $EcuProp_key -> $EcuSubProp_key = $EcuSubProp_value \n", 'blue' );
			if ( $EcuSubProp_key eq 'ECU_mode' ) { $ECU_mode = $EcuSubProp_value }
		}
	}

	S_teststep_expected("ECU mode shall be NORMAL DRIVING");
	S_teststep_detected("ECU mode : $ECU_mode");
	if ( $ECU_mode eq 'NormalDriving' ) {
		S_set_verdict(VERDICT_PASS);
	}
	elsif ( $ECU_mode eq 'Idle' ) {
		S_set_verdict(VERDICT_FAIL);
	}
	else {
		S_set_warning("UNEXPECTED ECU mode : $ECU_mode \n");
	}

	return $ECU_mode;
}

#############################################################################################
sub _SW_Labels_reading {

	my $software_Labels_reading_aref = shift;

	foreach my $software_label ( @{$software_Labels_reading_aref} ) {
		S_teststep( "Reading SW Label '$software_label'", 'AUTO_NBR' );
		my $memory_content_str = S_aref2hex( PRD_Read_Memory($software_label) );
		S_teststep_detected("Memory '$software_label' : '$memory_content_str'");
	}

	return 1;
}

##############################################################################################
sub _Set_Device_Configuration {
	my $device_config_href = shift;

	my $devices_modes_href = {};

	foreach my $device ( keys %$device_config_href ) {
		my @actions = split( /\|/, $device_config_href->{$device} );
		foreach my $action (@actions) {
			S_w2rep(" Device '$device' : Prepare '$action' \n");
			push( @{ $devices_modes_href->{$device} }, $action );
		}
	}

	my @devices = keys( %{$devices_modes_href} );

	S_teststep( "Call PRD_Set_Device_Configuration for devices : " . join( '->', @devices ), 'AUTO_NBR' );
	unless ( PRD_Set_Device_Configuration( $devices_modes_href, { 'resetType' => 'HARD', 'wait_time_after_reset_ms' => 5000 } ) ) {
		S_set_error("Problem while initializing Device Configurations");
		return;
	}

	return 1;
}

##############################################################################################
sub _EDR_initialization {

	return 1 if ($main::opt_offline);

	# --- EDR Initialization start ---
	S_teststep( "EDR Initialization", 'AUTO_NBR' );

	S_teststep_2nd_level( "Read 'rb_dcbm_FirstStartUpIndication_u16' ", 'AUTO_NBR' );
	my $edr_initialization_value = S_aref2hex( PRD_Read_Memory('rb_dcbm_FirstStartUpIndication_u16') );

	unless ( defined $edr_initialization_value ) {
		S_w2rep(" EDR Initialization: Could not read 'rb_dcbm_FirstStartUpIndication_u16' - do nothing \n");
		return 1;
	}

	S_teststep_detected(" 'rb_dcbm_FirstStartUpIndication_u16' = $edr_initialization_value");

	# clear EDR when initialized
	if ( $edr_initialization_value eq '0x5555' )    # 0x5555 = EDR is initialized --> ADAPT IF REQUIRED
	{
		S_w2rep("EDR is already initialized ( rb_dcbm_FirstStartUpIndication_u16 = 0x5555) - just erase it now\n");

		S_teststep_2nd_level( "PRD_Clear_EDR", 'AUTO_NBR' );
		PRD_Clear_EDR();
		S_wait_ms(2000);
		S_w2rep("EDR initialization finished\n");
		return 1;
	}

	S_teststep_2nd_level( "Reset ECU", 'AUTO_NBR' );
	LC_ECU_Reset(1);                                # make sure that power on counter is >= 2

	S_teststep_2nd_level( "Set a plant mode (mode 6 / 20hex / 32 dec (Airbag deployment shall be prohibited in the algorithm) ) to enable EDR initialization", 'AUTO_NBR' );

	#    PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [0b00000001] ) || return;
	PRD_Write_Memory( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [0b00100000] ) || return;
	S_wait_ms(200);

	S_teststep_2nd_level( "Reset ECU in order to activate PLant mode and trigger EDR initialzation procedure", 'AUTO_NBR' );
	LC_ECU_Reset(1);

	# Wait for EDR initialization to be completed
	my $maxWaitTime_ms          = 60000;                                         # 60 sec, 1 minute --> ADAPT IF REQUIRED
	my $intervalWaitTime_ms     = 1000;
	my $maxWaitTimeIteration    = $maxWaitTime_ms / $intervalWaitTime_ms + 1;    # 1 loop: 2000ms wait time
	my $edr_expected_init_value = '0x5555';

	my $edrInitialized   = 0;
	my $totalWaitTime_ms = 0;
	S_teststep_2nd_level( "Read cyclic 'rb_dcbm_FirstStartUpIndication_u16'", 'AUTO_NBR' );
	foreach my $waitTimeIteration ( 1 .. $maxWaitTimeIteration ) {
		$edr_initialization_value = S_aref2hex( PRD_Read_Memory('rb_dcbm_FirstStartUpIndication_u16') );
		S_teststep_detected(" (Loop $waitTimeIteration / $maxWaitTimeIteration) 'rb_dcbm_FirstStartUpIndication_u16' = $edr_initialization_value");
		if ( $edr_initialization_value eq $edr_expected_init_value )             # 0x5555 = EDR is initialized --> ADAPT IF REQUIRED
		{
			$edrInitialized = 1;
			S_teststep_expected(" 'rb_dcbm_FirstStartUpIndication_u16' must be $edr_expected_init_value ");
			S_w2rep("EDR initialized successfully after ECU reset + $totalWaitTime_ms ms");
			last;
		}

		S_wait_ms($intervalWaitTime_ms);
		$totalWaitTime_ms += $intervalWaitTime_ms;
	}

	S_teststep_2nd_level( "Reset plant mode", 'AUTO_NBR' );
	PRD_Write_Memory( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [0b00000000] ) || return;
	S_wait_ms(200);

	S_teststep_2nd_level( "Reset ECU", 'AUTO_NBR' );
	LC_ECU_Reset(1);

	unless ($edrInitialized) {
		S_set_verdict(VERDICT_FAIL);
		S_w2rep("EDR initialization could not be completed within max wait time of 60000 ms (1 minute).\n"
			  . "Measure the required initialization time with PSDiag fast diagnosis and adapt max wait time if required.\n"
			  . "Procedure for measurement:\n"
			  . "- Turn on ECU and check that Power on Counter is >= 2\n"
			  . "- Set plant mode\n"
			  . "- Check value of variable 'rb_dcbm_FirstStartUpIndication_u16' with fast diagnosis and get time when it goes to 0x5555.\n"
			  . "(Note: 0x5555 is the value for EDR initialized in CA - this value is configurable in SPS and might be different in your project!)" );
		return;
	}

	S_teststep_2nd_level( "Just wait some extra time (5sec) before clearing EDR Crash Recorder", 'AUTO_NBR' );
	S_wait_ms(5000);

	S_teststep_2nd_level( "Clear EDR Crash Recorder", 'AUTO_NBR' );
	PRD_Clear_EDR();
	S_wait_ms(2000);

	return 1;
}

1;
