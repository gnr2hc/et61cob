#### TEST CASE MODULE
package IC_Only_Eval;

#### DONT MODIFY THIS SECTION ####
use strict;
###-------------------------------
my $VERSION = q$Revision: 1.2 $;
my $HEADER = q$Header: config/IC_Only_Eval.pm 1.2 2018/05/16 17:46:29CEST Baeuerle Katharina (CC-PS/EPS2) (ZIK1ABT) develop  $;
##################################

#### HERE SELECTION OF MODULES ####
use LIFT_general;
use FuncLib_SYC_INTERFACE;
use Data::Dumper;
##################################

our $PURPOSE = "LIFT INIT CAMPAIGN for ONLY EVALUATION test lists";

##################################
####  TESTCASE STARTS HERE    ####
##################################



sub TC_set_parameters {

    return 1;
}



#### INITIALIZE TC #####
sub TC_initialization {

    S_w2rep(" *** Starting Init Campaign ***\n");

    S_w2rep(" *** General Initialization & Configuration of Test System *** \n");
    S_w2rep("---------------------------------------------------------------\n");

    S_w2rep( " IC -> write LIFT configuration to logfile \n" );
    S_w2rep( " LIFT Test System uses following versions of useful function libraries:\n" );
    S_w2rep( "   < $main::HEADER >\n" );
    S_w2rep( "   < $LIFT_evaluation::HEADER >\n" ) if defined $LIFT_evaluation::HEADER;
    S_w2rep( "   < $LIFT_general::HEADER >\n" ) if defined $LIFT_general::HEADER;

    S_log_testbenchconfig();

    my $link = '\\\\'.$LIFT_config::LIFT_host."/$main::REPORT_PATH"."_result.html";
    $link =~ s/\:/\$/g;
    my $mailtext = "test result link : $link\n\nthis is a generated message, please do not reply.";
    if (@LIFT_config::mailto){
        S_send_mail('',"test started",$mailtext,@LIFT_config::mailto);
    }

    S_teststep("Initialize SYC interface", 'AUTO_NBR');
    SYC_Init();

    S_w2rep(" IC -> set verdict PASS to finish init campaign\n");
    S_set_verdict( VERDICT_PASS );

    return 1;
}


### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

    return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

    return 1;
}


#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {


    return 1;
}


1;