###################  Configuration for LA_AcuteTravelLogic in Core Asset projects ##################

package LIFT_PROJECT;

use File::Basename;  # needed for dirname

$Defaults->{'LA_AcuteTravelLogic'} = {
    # Only the used channels, including the trigger channel need to be listed
    # GND Pin not to be listed, but GND connection to any of the 4 GND pins has to exist in HW setup
    # Names can be chosen, assigned integer numbers have to be zero-based
	
    'pinNames' => {    # [REQUIRED] list of pin names
        'MOSI_SPI_1'      => 0,	# L21
        'MISO_ASIC_SPI_1' => 1,	# L22
        'MISO_CPU_SPI_1'  => 2,	#
        'SCK_SPI_1'       => 3,	# L14

        'Control_Mux' 	  => 4,	# L24
						  
        'CS_COBRA_M'  	  => 5,	# L20 CS0
        'CS_COBRA_S'  	  => 6,	# L19 CS1
        'CS_SMA_M'    	  => 7,	# L18 CS2
        'CS_SMI'      	  => 8,	# L17 CS3	
        'CS_SMA_P'    	  => 9,	# L16 CS4
        'SCON_MON'    	  => 26,# L11 CS5

		'TrigAct_TrigCtrlUnit_0_2'		 => 10,	# B8P1
		'ManipuEnable_TrigCtrlUnit_0_2'  => 11,	# B8P2
		'ReadFIFO_TrigCtrlUnit_0_2'		 => 12, 	# B8P3
                                         
		'TrigAct_TrigCtrlUnit_1_3'		 => 13,	# B8P4
		'ManipuEnable_TrigCtrlUnit_1_3'  => 14,	# B8P5
		'ReadFIFO_TrigCtrlUnit_1_3'		 => 15,	# B8P6
                                        
		'StartManipulation'				 => 16,	# B8P7
		'WriteFIFO_TrigCtrlUnit_0_1'	 => 17,	# B8P8 check writing time PS to PL			                              
	                                      
		'TrigAct_PreTrigUnit_0_1'		 => 18,	# B9P1 
		'Enable_PreTrigUnit_0_SyncTrig'	 => 19,	# B9P2 also used as trigger to read FIFO in sync mode! (for crash injection)
		'Enable_PreTrigUnit_1'			 => 20,	# B9P3
                                         
		'ExtTrig_TrigCtrlUnit_0_1_2_3'	 => 21,	# B8P4 trigger to read FIFO in external mode
	                                      
		'SMI_BusAdr01_Page_0'			 => 22,	# B9P5 active pages of SMI sensor with BusAdr01
		'SMI_BusAdr01_Page_1'			 => 23,	# B9P6
		'SMI_BusAdr01_Page_2'			 => 24,	# B9P7
		'SMI_BusAdr01_Page_4'			 => 25,	# B9P8
		
    },
#	'triggerEdge'    => 'dontcare',         # [REQUIRED]
    'triggerEdge'    => 'rising',			# [REQUIRED]
                                            # text: 'falling'|'rising'|'low'|'high'|'change'|'dontcare'
                                            # (dontcare = immediate trigger)											
    'triggerPinName' => 'Control_Mux',      # [REQUIRED, if triggerEdge not equal to 'dontcare' otherwise OPTIONAL]
											
    #'hwMode'        => 'HW_200M_32CH_TR',  # [OPTIONAL]
                                            # (default: 'HW_200M_32CH_TR' = 200 MHz, transitional mode, 32 ch)
											
                                            #POSSIBLE MODES
                                            #'HW_4G_36CH'
                                            #'HW_4G_18CH'
                                            #'HW_4G_9CH'
                                            #'HW_4G_4CH'
                                            #'HW_2G_36CH'
                                            #'HW_1600M_4CH'
                                            #'HW_800M_9CH'
                                            #'HW_400M_18CH'
                                            #'HW_200M_36CH'
                                            #'HW_200M_18CH'
                                            #'HW_200M_12CH'
                                            #'HW_200M_9CH'
                                            #'HW_200M_6CH'
                                            #'HW_200M_4CH'
                                            #'HW_200M_2CH'
                                            #'HW_200M_1CH'
                                            #'HW_200M_32CH_TR'
                                            #'HW_200M_8CH_TR'

	'fileNameTemplate' => dirname($main::opt_conf) . '/../../COMMON_config/Tools/TravelLogic/AB12_ManiToo_LIFT_Interface_Template.law', # [OPTIONAL]
	# 'postTriggerSize_pct' => '<int>', # [OPTIONAL] default: 90%
	# 'numSamples_perCh' => '<int>',    # [OPTIONAL] default: max. available memory
};

1;
