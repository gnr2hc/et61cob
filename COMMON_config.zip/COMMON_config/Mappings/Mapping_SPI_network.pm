package LIFT_PROJECT;

# Mapping describing the SPI network
# Used for: SPI trace decoding, SPI manipulation
# TODO:  - add all SPI Nodes available in the network (ASICs, internal sensors)
# 	-> information on configured devices can be found in SYC chapters:
# 5.2 (System Asics)
# 5.3 (Internal Airbag Sensors)

use File::Basename;    # needed for dirname

our @ISA = qw(Exporter);

our @EXPORT = qw(
  $Defaults
);

$Defaults->{'Mapping_SPI'} = {

    'CG904_M' => {

        #'Offset' => '0',
        'CS_Polarity'      => 'true',
        'DecodingFile'     => dirname(__FILE__) . '/../../../Platform/CommonData/SPI_decoder_files/system_ASIC/CG90x_Cobra.spi',
        'CS_Enabled'       => 'true',
        'CS_Pin'           => '0',
        'MSB_LSB'          => 'MSB',
        'DeviceType'       => 'CG90x_Cobra',
        'Frame_Length_Bit' => '32',
        'CLK_Mode'         => 'true',
        'SPI'              => '1'
    },

    'CG904_S' => {

        #'Offset' => '0',
        'CS_Polarity'      => 'true',
        'DecodingFile'     => dirname(__FILE__) . '/../../../Platform/CommonData/SPI_decoder_files/system_ASIC/CG90x_Cobra.spi',
        'CS_Enabled'       => 'true',
        'CS_Pin'           => '1',
        'MSB_LSB'          => 'MSB',
        'DeviceType'       => 'CG90x_Cobra',
        'Frame_Length_Bit' => '32',
        'CLK_Mode'         => 'true',
        'SPI'              => '1'
    },

    'SMA760' => {

        #'Offset' => '0',
        'CS_Polarity'      => 'true',
        'DecodingFile'     => dirname(__FILE__) . '/../../../Platform/CommonData/SPI_decoder_files/sensors_SMA/SMA7xx.spi',
        'CS_Enabled'       => 'true',
        'CS_Pin'           => '2',
        'MSB_LSB'          => 'MSB',
        'DeviceType'       => 'SMA760',
        'Frame_Length_Bit' => '32',
        'CLK_Mode'         => 'true',
        'SPI'              => '1'
    },

    'SMA720' => {

        #'Offset' => '0',
        'CS_Polarity'      => 'true',
        'DecodingFile'     => dirname(__FILE__) . '/../../../Platform/CommonData/SPI_decoder_files/sensors_SMA/SMA7xx.spi',
        'CS_Enabled'       => 'true',
        'CS_Pin'           => '4',
        'MSB_LSB'          => 'MSB',
        'DeviceType'       => 'SMA720',
        'Frame_Length_Bit' => '32',
        'CLK_Mode'         => 'true',
        'SPI'              => '1'
    },
    'SMI' => {

        'CS_Polarity' => 'true',
        'DecodingFile'     => dirname(__FILE__) . '/../../../Platform/CommonData/SPI_decoder_files/sensors_SMI/SMI8_6D_C7.spi',
        'CS_Enabled'       => 'true',
        'CS_Pin'           => '3',
        'MSB_LSB'          => 'MSB',
        'DeviceType'       => 'SMI8_6D_C7',
        'Frame_Length_Bit' => '32',
        'CLK_Mode'         => 'true',
        'SPI'              => '1',
        'SMI7_Modules'     => {
#            'YawSensor'       => 0,
#            'YawPlausiSensor' => 1,
#            'PitchSensor'     => 2,
#            'RollSensor'      => 3,
        },
    },

};
$Defaults->{'SPILC_FunctionMapping'} = {

    #  CMD  ->
    #  SIG  ->
    #  VAL  ->
    #  MOSI -> 1 (MOSI flag , to be set when signal is MOSI signal)
    #  MISO -> 1 (MISO flag , default 1)
    #
    squibs => {
        ls_short2gnd => { 1 => { 'CMD' => 'FLM_READ_RES_CH<ASIC_CHANNEL>', 'SIG' => 'flt', 'VAL' => 8 }, },
        hs_short2gnd => { 1 => { 'CMD' => 'FLM_READ_RES_CH<ASIC_CHANNEL>', 'SIG' => 'flt', 'VAL' => 10 }, },
        ls_short2bat => { 1 => { 'CMD' => 'FLM_READ_RES_CH<ASIC_CHANNEL>', 'SIG' => 'flt', 'VAL' => 9 }, },

        hs_short2bat => { 1 => { 'CMD' => 'FLM_READ_RES_CH<ASIC_CHANNEL>', 'SIG' => 'flt', 'VAL' => 11 }, },

        sqref_too_low => { 1 => { 'CMD' => 'FLM_READ_RES_CH<ASIC_CHANNEL>', 'SIG' => 'flt', 'VAL' => 2 }, },

        sqref_too_high => { 1 => { 'CMD' => 'FLM_READ_RES_CH<ASIC_CHANNEL>', 'SIG' => 'flt', 'VAL' => 3 }, },

        hs_volt_too_high => { 1 => { 'CMD' => 'FLM_READ_RES_CH<ASIC_CHANNEL>', 'SIG' => 'flt', 'VAL' => 4 }, },

        ls_volt_too_high => { 1 => { 'CMD' => 'FLM_READ_RES_CH<ASIC_CHANNEL>', 'SIG' => 'flt', 'VAL' => 5 }, },

        res_value_too_high => { 1 => { 'CMD' => 'FLM_READ_RES_CH<ASIC_CHANNEL>', 'SIG' => 'flt', 'VAL' => 6 }, },

        volt_ls_gt_hs => { 1 => { 'CMD' => 'FLM_READ_RES_CH<ASIC_CHANNEL>', 'SIG' => 'flt',       'VAL' => 7 }, },
        res_value_raw => { 1 => { 'CMD' => 'FLM_READ_RES_CH<ASIC_CHANNEL>', 'SIG' => 'res_value', 'VAL' => '<resistor_value_raw>' }, },

        #        res_value_ohms => {                                                        #  calculation method to be investigated / later
        #            1 => { 'SIG' => 'res_value', 'VALUE_PHYS' => '<resistor_value_ohms' },
        #        },

        validity_flag => { 1 => { 'CMD' => 'FLM_READ_RES_CH<ASIC_CHANNEL>', 'SIG' => 'vd', 'VAL' => '<Validity_flag>' }, },

        fire_cnt_high_level => { 1 => { 'CMD' => 'FLM_READ_FIRE_CNT_CH<ASIC_CHANNEL>', 'SIG' => 'fire_counter_hl', 'VAL' => '<FIRE_COUNTER_HL_VAL>' }, },

        fire_cnt_low_level => { 1 => { 'CMD' => 'FLM_READ_FIRE_CNT_CH<ASIC_CHANNEL>', 'SIG' => 'fire_counter_ll', 'VAL' => '<FIRE_COUNTER_LL_VAL>' }, },

        openline => { 1 => { 'CMD' => 'FLM_READ_RES_CH<ASIC_CHANNEL>', 'SIG' => 'res_value', 'VAL' => 2047 }, },
    },

    pases => {
        ls_short2gnd => { 1 => { 'CMD' => 'PSI_READ_SC', 'SIG' => 'sg<ASIC_CHANNEL>', 'VAL' => 1 }, },
        hs_short2gnd => { 1 => { 'CMD' => 'PSI_READ_SC', 'SIG' => 'sg<ASIC_CHANNEL>', 'VAL' => 1 }, },
        ls_short2bat => { 1 => { 'CMD' => 'PSI_READ_SC', 'SIG' => 'sb<ASIC_CHANNEL>', 'VAL' => 1 }, },
        hs_short2bat => { 1 => { 'CMD' => 'PSI_READ_SC', 'SIG' => 'sb<ASIC_CHANNEL>', 'VAL' => 1 }, },
        vzl_flag     => { 1 => { 'CMD' => 'PSI_READ_SC', 'SIG' => 'vzl',              'VAL' => '<VZL_FLAG_VAL>' } },

        # PSI_READ_DATA <ASIC_CH_TS>
        #
        # ASIC_CH_TS : b4 b3 b2 b1 b0
        #              => CHANNEL  b4 b3 b2 (6 channels) / 000 CH1 ... 101 CH6
        #              => TIMESLOT b1 b0    (4 timeslots) / 00 -> TS1 ... 11 -> TS4
        #
        #  PSI5 Mapping required !!!
        #
        #  vas , vu , vs , psi_data
        vas      => { 1 => { 'CMD' => 'PSI_READ_DATA<ASIC_CHANNEL_TS>', 'SIG' => 'vas',      'VAL' => '<vzl_flag>' } },
        psi_data => { 1 => { 'CMD' => 'PSI_READ_DATA<ASIC_CHANNEL_TS>', 'SIG' => 'psi_data', 'VAL' => '<psi_data>' } },
        openline => { 1 => { 'CMD' => 'PSI_READ_DATA<ASIC_CHANNEL_TS>', 'SIG' => 'psi_data', 'VAL' => 496 } },

        timeslots => {
            UFSD  => 2,
            UFSP  => 2,
            PASFD => 1,
            PASFP => 1,
            PASMD => 2,
            PASMP => 2,
            PPSFD => 3,
            PPSFP => 3
        },

    },

    switches => {
        hs_short2gnd => { 1 => { 'CMD' => 'AINO_READ_AUTO_CH<ASIC_CHANNEL>', 'SIG' => 'adc_data', 'VAL' => 0 }, },
        ls_short2gnd => { 1 => { 'CMD' => 'AINO_READ_AUTO_CH<ASIC_CHANNEL>', 'SIG' => 'adc_data', 'VAL' => 0 }, },
        ls_short2bat => { 1 => { 'CMD' => 'AINO_READ_AUTO_CH<ASIC_CHANNEL>', 'SIG' => 's2b',      'VAL' => 1 }, },
        hs_short2bat => { 1 => { 'CMD' => 'AINO_READ_AUTO_CH<ASIC_CHANNEL>', 'SIG' => 's2b',      'VAL' => 1 }, },
        openline     => { 1 => { 'CMD' => 'AINO_READ_AUTO_CH<ASIC_CHANNEL>', 'SIG' => 'adc_data', 'VAL' => 1023 }, },
        adc_data     => { 1 => { 'CMD' => 'AINO_READ_AUTO_CH<ASIC_CHANNEL>', 'SIG' => 'adc_data', 'VAL' => '<ADC_RESULT_VAL>' }, },

    },
};
1;
