package LIFT_PROJECT;

#$VERSION = q$Revision: 1.12 $;
#$HEADER = q$Header: config/Mappings/AB12_RefType4_ProjectConst_Main.pm 1.12 2020/02/28 12:43:37IST Nguyen Van Truc (RBVH/EPS24) (GNR2HC) develop  $;

our $Defaults;
$Defaults = {

    'MKS_FILE_REVISIONS' => {    #used by MKS_checkFilesRevisions

        'DEFAULT' => {           #label/name of test
            'EXACT' => {         #working revisions should match exactly with below revisions
                'AB12_RefType4_ProjectConst_CREIS.pm' => '1.10',
                'LIFT_crash_simulation.pm'            => '1.38.1.9',
                'LIFT_TSG4.pm'                        => '1.93.2.1',
                'FuncLib_TNT_crash_simulation.pm'     => '1.20',
            },

            'ATLEAST' => {       #working revision should be greater than or equal to below revisions
            },
            'AddOns' => {
                'CREIS' => 'CREIS_V2_0',
                'EDR'   => 'EDR_V7_0',
            }
        },

        #further labels can be added here (separate hash for each test)

    },
    'VEHICLE' => {
        'U_BATT_DEFAULT'                      => 13.5,
        'U_BATT_LINEFAULT'                    => 13.5,
        'KL15_Zyklus_voltage'                 => 9.05,
        'U_BATT_UNDERVOLTAGE'                 => 6.2,
        'U_BATT_OVERVOLTAGE'                  => 19.8,
        'ISO_FAULTMEMORY'                     => 1,
        'SWITCH_EVALUATION_VOLTAGE_RANGE_MAX' => 19.5,    #V #swm
        'SWITCH_EVALUATION_VOLTAGE_RANGE_MIN' => 6.5,     #V #swm
        'SWITCH_EVALUATION_VOLTAGE_RANGE_MID' => 13.0,    #V #swm
		'HighVoltage'                         => 19.50,
		'LowVoltage'                          => 9.00,
		'ITM_Init_Time_ms'                    => 5000,
	},
	'TIMER' => {
		'TIMER_ECU_READY'               => 10000,
		'TIMER_ECU_READY_WITHINITDELAY' => 10000,         #wait time after power on, when ITM init delay is enabled
		'TIMER_DIAGNOSIS'               => 1500,
		'TIMER_ECU_OFF'                 => 10000,
		'TIMER_SIX_SEC'                 => 6000,          #swm
		'TIMER_TWO_SEC'                 => 2000,
		'SWITCH_STATE_CHANGE_TIME'      => 500,           # ms #check this #swm
		'ITMinitdelay'                  => 4000,          #swm
		'TIMER_ECU_FAULT_QUALIFICATION' => 10000,         # wait time for fault qualification
		'TIMER_CLEAR_CRASH_RECORDER'    => 15000,
		'TIMER_SECURITY_DELAY_ON_BOOT'  => 15000,
	},

    #These constants are used to enable ITM init delay feature #not yet implemented
    'ITM' => {
        'ITM_initdelay_variable'     => 'S_PDMProgVarTbl1_XXE.V_ProdMode_U16X',    #prod mode variable to enable ITM init delay feature
        'ITM_initdelay_mask'         => '0x0080',                                  #value to be written to prod mode variable to enable ITM init delay feature
        'ITMexecutedstatus_variable' => 'rb_itm_TestFinished_u64 ',                #rb_itm_InitialTestFinished_e = 0,
    },

    'CRC_AREA' => {
        'PROG_VAR_TBL'  => '1',
        'ASIC_CONF_TBL' => '4',
        'PAR_SEC_TBL'   => '',
    },

	'SADCONFIG' => { 'CAN_Type' => 'BOSCH_CAN_03', },
	'DISPOSAL'  => {
		'RoutineStatusRecord'   => '12',
		'SW_Path'               => 'D:\MKS\Projects\TurboLIFT\Projects\AB12_RT_4\config\SW\M03.16_RT4\AB1210_B0_0014_BB031600_Cat2.hex',
		'ECU_Serial_Number'     => '8DS125230C',
		'ECU_Type'              => 'D3A',
		'WL_Status_Read_Method' => 'PD',
		'WL_Signal_Name'        => 'rb_wimi_SysWIStatus_aen(0)',
	},

	'WARNING_LAMPS' => { 'WL_1_3_Name' => 'DISP', },

	'ProdDiag' => {
		'ProjectName' => 'BOSCH',    # project name, possible values are 'TakeFromPSDiag' or
		                                      # a CANType from PSDiag_CAN_Parameter.txt, e.g. 'BOSCH_CAN_03' or 'FORD_CAN_05' or
		                                      # 'BOSCH'  - for CANFD (Customer name).
	},

	'PRODUCTION_DIAGNOSIS' => {
	   'INIEND_TIMEOUT' => 10,
	   'INIEND_LABEL'   => 'rb_itm_EndOfItmTimestamp_u32',
	 },
	'ECU_HW_INFO' => {
		'9C78C3C4#ECC1B5DD7145' => {
			'TT_No'        => '0 285 B06 015-01',
			'HW_version'   => 'AB12.1 AP2400.01 RT4',
			'HW_serial_no' => 'H01-011',
		},
		'947045BD#54673C716939' => {
			'TT_No'        => '0 285 B06 015-01',
			'HW_version'   => 'AB12.1 AB2400.01 RT4',
			'HW_serial_no' => 'H01-003',
		},
		'DECBC8D1#80C1B5DC7145' => {
			'TT_No'        => '0 285 B06 015-01',
			'HW_version'   => 'AB12.1 AB2400.01 RT4',
			'HW_serial_no' => 'H01-014',
		},
		'26AF6312#ABBAEDDAACDC' => {
			'TT_No'        => '0 285 B06 015-01',
			'HW_version'   => 'AB12.1 AP2400.01 RT4',
			'HW_serial_no' => 'H01-007',
		},
		'36DDA3BA#ABBAEDDAACDC' => {
			'TT_No'        => '0 285 B06 015-01',
			'HW_version'   => 'AB12.1 AP2400.01 RT4 A0',
			'HW_serial_no' => 'H01-015',
		},
		'E014F9C6#7145B5DCC4C3' => {
			'TT_No'        => '0 285 B06 015-01',
			'HW_version'   => 'AB12.1 AP2400.01 RT4 A0',
			'HW_serial_no' => 'H02-044',
		},
		'764CF466#A66B3C716939' => {
			'TT_No'        => '0 285 B06 015-01',
			'HW_version'   => 'AB12.1 AP2400.01 RT4 A0',
			'HW_serial_no' => 'H02-026',
		},
		'85543302#9C743C706939' => {
			'TT_No'        => '0 285 B07 334-01',
			'HW_version'   => 'AB12.1 AP2400.01 RT4 B0 quick1',
			'HW_serial_no' => 'H08-009',
		},
		'2AFD7EC8#7C743C706939' => {
			'TT_No'        => '0 285 B07 334-01',
			'HW_version'   => 'AB12.1 AP2400.01 RT4 B0 quick1',
			'HW_serial_no' => 'H08-010',
		},
		'6F22163D#2AA3E9E97538' => {
			'TT_No'        => '0 285 B07 334-01',
			'HW_version'   => 'AB12.1 AP2400.01 RT4 B0 quick1',
			'HW_serial_no' => 'H08-011 - modified for creis',
		},
		'DC57834E#2AA3E9E97538' => {
			'TT_No'        => '0 285 B07 334-01',
			'HW_version'   => 'AB12.1 AP2400.01 RT4 B0 quick1',
			'HW_serial_no' => 'H08-012 - modified for creis',
		},
		'53469D37#FC8A13106946' => {
			'TT_No'        => '0 285 B07 333-01',
			'HW_version'   => 'AB12.1 AP2400.01 RT4 B0 quick2',
			'HW_serial_no' => 'H09-008',
		},
		'DC7F3D24#048913116946' => {
			'TT_No'        => '0 285 B07 333-01',
			'HW_version'   => 'AB12.1 AP2400.01 RT4 B0 quick2',
			'HW_serial_no' => 'H09-009',
		},
		'599211B2#008713116946' => {
			'TT_No'        => '0 285 B07 333-01',
			'HW_version'   => 'AB12.1 AP2400.01 RT4 B0 quick2',
			'HW_serial_no' => 'H09-033 - modified for sleep',
		},
		'FFFFFFFF#10AB54329876' => {
			'TT_No'        => '0 285 B0x xxx',
			'HW_version'   => 'AB12.1 AP2400.01 RT4',
			'HW_serial_no' => '4-A0-xxx',
		},
	},

    #asic names are carried over from AB10, needs to be updated when actual names are known
    'IXS_MAPPING' => {

        #'CS0'  => 'CG904M', #temp
        'CS1' => 'CG904M',    #Monitor SystemAsic
        'CS2' => 'CG904M',    #SystemAsic1
        'CS3' => 'CG904M',    #SystemAsic2
                              #'CS4'  => 'CF190',
        'CS5' => 'SMI7x0',
        'CS6' => 'SMA660',

        #'CS7'  => 'SMA660',
        #'CS8'  => 'CS8',
        #'CS9'  => 'CS9',
        #'CS10' => 'CS10',
        #'CS11' => 'CS11',
        #'CS12' => 'EEFiBy',
        #'CS13' => 'EENeBy',
        #'CS15' => 'LoData',
    },

    'ASICS' => {
        'MasterSystemASIC'               => 'CG904M',
        'SlaveSystemASIC'                => 'CG904M',
        'AdditionalPAS_IFASIC'           => '',
        'MainAccelerationSensor'         => 'SMA760',
        'PlausibilityAccelerationSensor' => 'SMA720',
        'RolloverSensor'                 => 'SMI860',
        'ABPlusSensor'                   => 'SMG810',
        'ABPlusSensorsforActiveSafety'   => '',
    },

    # external device names are carried over from AB10, needs to be updated when actual names are known
    # check and update for AB12
    'DEVICE_CONFIG' => {

        # Squibs
        'AB1FD'  => 'AB1FD',
        'AB1FP'  => 'AB1FP',
        'AB2FD'  => 'AB2FD',
        'AB2FP'  => 'AB2FP',
        'AB3FP'  => 'AB3FP',
        'ALLFD'  => 'ALLFD',
        'ALLFP'  => 'ALLFP',
        'ASC1FD' => 'ASC1FD',
        'BATD'   => 'BATD',
        'BT1FD'  => 'BT1FD',
        'BT1FP'  => 'BT1FP',
        'BT1RC'  => 'BT1RC',
        'BT1RD'  => 'BT1RD',
        'BT1RP'  => 'BT1RP',
        'BT2FD'  => 'BT2FD',
        'BT2FP'  => 'BT2FP',
        'BT2RC'  => 'BT2RC',
        'BT2RD'  => 'BT2RD',
        'BT2RP'  => 'BT2RP',
        'HOODD'  => 'HOODD',
        'HOODP'  => 'HOODP',
        'IC1FD'  => 'IC1FD',
        'IC1FP'  => 'IC1FP',
        'IC1RD'  => 'IC1RD',
        'IC1RP'  => 'IC1RP',
        'KA1FD'  => 'KA1FD',
        'KA1FP'  => 'KA1FP',
        'PPAB1'  => 'PPAB1',
        'SA1FD'  => 'SA1FD',
        'SA1FP'  => 'SA1FP',
        'SA1RD'  => 'SA1RD',
        'SA1RP'  => 'SA1RP',

        #  PAS
        'UFSD'  => 'UfsD',
        'UFSP'  => 'UfsP',
        'PASFD' => 'PasFD',
        'PASFP' => 'PasFP',
        'PASMD' => 'PasMD',
        'PASMP' => 'PasMP',
        'PPSFD' => 'PpsFD',
        'PPSFP' => 'PpsFP',
        'PTSD'  => 'PtsD',
        'PTSP'  => 'PtsP',
        'PCSC'  => 'PcsC',
        'PASRC' => 'PasRC',

        # Warning lamps
        'AWL'  => 'AOutSysWarningIndicator',
        'PADL' => 'AOutPassAirbagOffIndicator',
        'PAEL' => 'AOutPassAirbagOnIndicator',
        'CRO1' => 'AOutCrashOutput1',
        'CRO2' => 'AOutCrashOutput2',

        # Switches
        'BLFC'  => 'BLFC',
        'BLFD'  => 'BLFD',
        'BLFP'  => 'BLFP',
        'BLR2C' => 'BLR2C',
        'BLR2D' => 'BLR2D',
        'BLR2P' => 'BLR2P',
        'BLR3C' => 'BLR3C',
        'BLR3D' => 'BLR3D',
        'BLR3P' => 'BLR3P',
        'BLRC'  => 'BLRC',
        'BLRD'  => 'BLRD',
        'BLRP'  => 'BLRP',
        'OPSFP' => 'OPSFP',
        'OPSRC' => 'OPSRC',
        'OPSRD' => 'OPSRD',
        'OPSRP' => 'OPSRP',
        'PADS1' => 'PADS1',
        'PADS2' => 'PADS2',
        'SPSFD' => 'SPSFD',
        'SPSFP' => 'SPSFP',

        # Customer dummy device
        'ACL' => 'Additional Communication Line',

        # ASICs
        'SystemAsic1'            => 'SystemAsic1',
        'SystemAsic2'            => 'SystemAsic2',
        'CentralSensorMain'      => 'CentralSensorMain',
        'CentralSensorPlausi'    => 'CentralSensorPlausi',
        'CentralSensorYaw'       => 'CentralSensorYaw',
        'CentralSensorYawPlausi' => 'CentralSensorYawPlausi',
        'CentralSensorRoll'      => 'CentralSensorRoll',
        'CentralSensorPitch'     => 'CentralSensorPitch',

        # Special Behaviour Bits
        'SpecBehItmDebugDelay'      => 'SpecBehItmDebugDelay',
        'IsRightHandDriver'         => 'IsRightHandDriver',
        'DisableAlgoPep'            => 'DisableAlgoPep',
        'DisableAlgoRollover'       => 'DisableAlgoRollover',
        'DisableAlgoStaticRollover' => 'DisableAlgoStaticRollover',
        'IsISODisposalSupported'    => 'IsISODisposalSupported',

        #Section Activators
        'Dummy' => 'Dummy',
    },

    'CUSTOMER_DIAGNOSIS' => {

		####################-------------------CD SECTION--------------------#########################

		#Functional address
		'RequestID_functional'     => '0x6ec',    #as hex string
		'ResponseID_functional'    => '0x4fc',    #as hex string
		'FlowControlID_functional' => '0x6ec',
		'Timeout_functional'       => 10000,      #in milliseconds,CD function will convert it to second
		'P3_mintime_functional'    => 100,
		###################################################

		#Physical address
		'RequestID_physical'     => '0x6DC',      #as hex string
		'ResponseID_physical'    => '0x4FC',      #as hex string
		'FlowControlID_physical' => '0x6DC',
		'Timeout_physical'       => 10000,
		'P3_mintime_physical'    => 100,

		#Disposal address
		####################################################
		'RequestID_disposal'     => '0x7F1',      #as hex string
		'ResponseID_disposal'    => '0x7F9',      #as hex string
		'FlowControlID_disposal' => '0x715',
		'Timeout_disposal'       => 10000,
		'P3_mintime_disposal'    => 100,

		#General
		####################################################
		'RequestID_CD'           => '0x6DC',                                               #as hex string
		'ResponseID_CD'          => '0x4FC',                                               #as hex string
		'FlowControlID_CD'       => '0x6DC',
		'Timeout_CD'             => 10000,
		'P3_mintime_CD'          => 10000,
		'FlowControl'            => [ 0x30, 0x00, 0x01 ],
		'clearDTC'               => [ 0x14, 0xff, 0xff, 0xff ],                            # Bytes as array ref
		'DTC_SAM'                => '0b10011001',                                          # DTC Status availability Mask
		'SAM'                    => 1,
		'SJW'                    => 3,
		'Tseg1'                  => 0xc,
		'Tseg2'                  => 3,
		'Baudrate'               => 500000,
		'DLCmode'                => 0,                                                     # 0 for 8 byte, 1 for dynamic DLC
		'DTCdefaultstate'        => 0x08,                                                  # read current fault
		'DTCbytes'               => 3,                                                     # bytes per DTC
		'ExtID'                  => 0,                                                     # 1 for Extended Identifier, 0 for Standard
		'ExtAddressing'          => 0,                                                     # 1 for Extended Addressing, 0 for Normal
		'EcuAddr'                => 0x01,                                                  # ECU id for Extended Addressing.
		'TargetAddr'             => 0x55,                                                  # Target address for Extended Addressing.
		'CAN_TesterPresent_Req'  => [ 0x02, 0x3E, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00 ],    # do not add DLC in the request
		'CAN_TesterPresent_Time' => 4000,                                                  # cyclic TP cycle time is milli sec
		'DISABLE'                => 0,                                                     # optional, to disable all CD features (similar to debug mode)
		'DTCdefaultsubfunction'  => '02',

		####################-------------------PROD SECTION--------------------#########################

		#For Valid PD ID
		'RequestID_PD'     => '0x650',                                                     #as hex string
		'ResponseID_PD'    => '0x651',                                                     #as hex string
		'FlowControlID_PD' => '0x650',
		'Timeout_PD'       => 10000,
		'P3_mintime_PD'    => 4000,

		####################################################
		#for Fast Diagnosis - multiple response frames
		'ResponseID1_FD_PD' => '0x651',                                                    #as hex string
		'ResponseID2_FD_PD' => '0x652',                                                    #as hex string
		'ResponseID3_FD_PD' => '0x653',                                                    #as hex string
		'ResponseID4_FD_PD' => '0x654',                                                    #as hex string

		####################################################
		#1mS wait time
		'RequestID_PD_Notimeout'     => '0x650',                                           #as hex string
		'ResponseID_PD_Notimeout'    => '0x651',                                           #as hex string
		'FlowControlID_PD_Notimeout' => '0x650',
		'Timeout_PD_Notimeout'       => 1,
		'P3_mintime_PD_Notimeout'    => 400,

		####################################################
		#For Valid PD Invalid
		'RequestID_Invalid'     => '0x500',                                                #as hex string
		'ResponseID_Invalid'    => '0x501',                                                #as hex string
		'FlowControlID_Invalid' => '0x500',
		'Timeout_Invalid'       => 5000,
		'P3_mintime_Invalid'    => 400,

	},

########################################################################################################################
    # here you can define global optional faults for every test, for example if you have always variant coding info in EEPROM
    # 'TEMP_OPTIONAL_FAULTS' -> fault is ignored completely
    # 'TEMP_DISTRUB_FAULTS'  -> fault is ignored if only disturb bit is set
    # 'TEMP_DISTRUB_FAULTS'  => [ 'ALL' ] will ignore all faults where only disturb bit is set
    # e.g. 'TEMP_OPTIONAL_FAULTS' => [ 'FltVdsPitchRateSensorMonitoring' , 'FltVdsYawRateSensorMonitoring' ],
########################################################################################################################

	'TEMP_OPTIONAL_FAULTS' => ['rb_coa_VehSpdRxMsgTimeout_flt'],

    'TEMP_DISTRUB_FAULTS' => [],

    'EVALUATION_FILE' => {
        'USED'          => 1,
        'DELIMITER'     => ';',         ### useful are: chr(9) is TAB or ';'
        'EMPTY_CHAR'    => ' - - - ',
        'SIGNAL_MARKER' => 'SIG: ',     ### marker to identify the label of the checked signal
        'EXPECT_MARKER' => 'EXP: ',     ### marker to identify the 'MUST' / 'SOLL'
        'DETECT_MARKER' => 'FND: ',     ### marker to identify the 'REAL' / 'IST'
        'JUST_VERDICTS' => {
            'VERDICT_FAIL'   => 1,
            'VERDICT_INCONC' => 1,
            'VERDICT_NONE'   => 1,
            'VERDICT_PASS'   => 1,
        },

        'COLUMN_ORDER' => [ 'NBR', 'DATE_TIME', 'TC_ID', 'Stimulation', 'EXP', 'DET', 'MISMATCH', 'VERDICT' ],

        #'COLUMN_ORDER' => [ 'NBR', 'DATE_TIME', 'TC_ID', 'RuntimeMeasurement - MIN', 'RuntimeMeasurement - AVG', 'RuntimeMeasurement - MAX', 'RuntimeMeasurement - PND', 'TaskDrop2ms', 'TaskDrop5ms', 'TaskDrop10ms', 'RB_FAULTS', 'VERDICT' ],
    },

    'CANoeCtrl' => {
        'OutputSignals' => {
            'BMI_AEB_Expected' => {
                'Index'        => 0,
                'CycleTime'    => 20,
                #'DefaultValue' => 0,
            },
            'IDF_01_Time_to_Impact' => {
                'Index'        => 1,
                'CycleTime'    => 20,
                #'DefaultValue' => 0,
            },
            'BMI_AEB_State' => {
                'Index'        => 2,
                'CycleTime'    => 20,
                #'DefaultValue' => 0,
            },
            'BMI_BeltJerk' => {
                'Index'        => 3,
                'CycleTime'    => 20,
                #'DefaultValue' => 0,
            },
            'EXT_MSB_BeltJerk_ExtReq' => {
                'Index'        => 4,
                'CycleTime'    => 20,
                #'DefaultValue' => 0,
            },
            'DRV_BrakePedalPosition' => {
                'Index'        => 5,
                'CycleTime'    => 20,
                #'DefaultValue' => 0,
            },
            'VDC_MCPressure' => {
                'Index'        => 6,
                'CycleTime'    => 20,
                #'DefaultValue' => 0,
            },
            'IDF_01_Closing_Velocity' => {
                'Index'        => 7,
                'CycleTime'    => 20,
                #'DefaultValue' => 0,
            },
            'VDC_AccLongitudinal' => {
                'Index'        => 8,
                'CycleTime'    => 20,
                #'DefaultValue' => 0,
            },
            'VDC_AccLateral' => {
                'Index'        => 9,
                'CycleTime'    => 20,
                #'DefaultValue' => 0,
            },
            'VDC_Intervention' => {
                'Index'        => 10,
                'CycleTime'    => 20,
                #'DefaultValue' => 0,
            },
            'VDC_YawRate' => {
                'Index'        => 11,
                'CycleTime'    => 20,
                #'DefaultValue' => 0,
            },
            'EXT_MSB_FullTensing_ExtReq' => {
                'Index'        => 12,
                'CycleTime'    => 20,
                #'DefaultValue' => 0,
            },
            'DRV_AccPedalPosition' => {
                'Index'        => 13,
                'CycleTime'    => 20,
                #'DefaultValue' => 0,
            },
            'IDF_01_AEB_Flag' => {
                'Index'        => 14,
                'CycleTime'    => 20,
                #'DefaultValue' => 0,
            },
            'EXT_MSB_PartTensing_ExtReq' => {
                'Index'        => 15,
                'CycleTime'    => 20,
                #'DefaultValue' => 0,
            },
            'IDF_01_Object_Class' => {
                'Index'        => 16,
                'CycleTime'    => 20,
                #'DefaultValue' => 0,
            },
            'IDF_01_TTI_TimeStamp' => {
                'Index'        => 17,
                'CycleTime'    => 20,
                #'DefaultValue' => 0,
            },
            'VSD_ESPReferenceVelocity' => {
                'Index'        => 18,
                'CycleTime'    => 20,
                #'DefaultValue' => 0,
            },
        },
    },
};
$Defaults->{'CSM'} = {
    'LocalWorkingArea_Path' => 'C:\temp\CSM_Local_Working_Area',
    'StorageArea_Path'      => 'C:\TurboLIFT\_StorageArea_CSM_development',
    'disable_CSM'           => 0,
};
1;
