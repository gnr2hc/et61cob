package LIFT_PROJECT;

# use constant SPI_SENSOR_HG_X_CHANNEL => 0b010;
our @ISA = qw(Exporter);

our @EXPORT = qw(
   $Defaults
);
$Defaults->{'MANITOO_TEMP'}{'SERVICES'} = {
    #
    #  SERVICES
    #
    'power_ON'  => {
       'CMD_sequence' => {
            1.1 => { cmd => '80 - 00 01 00 01',  descr => 'Power-ON' },
        },
    },
    'power_OFF'  => {
       'CMD_sequence' => {
            1.1 => { cmd => '80 - 00 01 00 00',  descr => 'Power-OFF' },
        },
    },
    'init'  => { # Init #ok
       'CMD_sequence' => {
            # get version
            1.1 => { cmd => '10', descr => 'Get Version' },
            # complete Reset of PS & PL
            2.1 => { cmd => '22', descr => 'Reset PS & PL' },
            # config_rti_trigger
            3.1 => { cmd => '51 - 00 00 00 01',  descr => 'Set CS for Cobra_M' },
            3.2 => { cmd => '52 - FF C0 00 00',  descr => 'Set SPI Mask for WD command' },
            3.3 => { cmd => '53 - 01 00 00 00',  descr => 'Set SPI Pattern for WD command' },
            # config_spi_smi7
            4.1 => { cmd => '71 - 00 10 00 08',  descr => 'Set CS for SMI7' },
            },
    },
    'start_manipulation'  => {  # Start manipulation  ok
        'CMD_sequence' => {
            1.0 => { cmd => 'FA 00 00 00 01', descr => 'debug via Extension port' },		#########################
			1.1 => { cmd => '20', descr => 'Copy data to PL' },
            1.2 => { cmd => '21 - 00 00 00 01', descr => 'Start manipulation' },

        },
    },
	'stop_manipulation'  => { # Stop manipulation ok
       'CMD_sequence' => {
            1.1 => { cmd => '21 - 00 00 00 00',  descr => 'Stop manipulation' },
            1.2 => { cmd => '23', descr => 'Partial Reset PS & PL' },
        },
    },
    'copy_data_to_PL'  => {
        'CMD_sequence' => {
            1.0 => { cmd => '20', descr => 'Copy data to PL' },
        },
    },
    
};

$Defaults->{'MANITOO_TEMP'}{'TESTCASES'} = {
#************************************************* RD_DEVICE_ID CRC,Data load,S bit check**************************************************************

#***************************************************************************************
    'Invalid_RD_DEVICE_ID_DataLoad_SMA760M_3x'  =>  { # check for the Invalid CRC Read Device ID RD_DEVICE_ID
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1 
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    # make Instruction bits as 1
            1.3 => { cmd => '33 - 00 - 21 00 00 00', descr => 'module_0: Set Frame Pattern'} , # Read Device ID RD_DEVICE_ID Instruction bits# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_DEVICE_ID_DataLoad_SMA760P_3x'  =>  { # check for the Invalid CRC Read Device ID RD_DEVICE_ID
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    # make Instruction bits as 1
            1.3 => { cmd => '33 - 00 - 21 00 00 00', descr => 'module_0: Set Frame Pattern'} , # Read Device ID RD_DEVICE_ID Instruction bits# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#**************************************************************************************
    'Invalid_RD_DEVICE_ID_CRC_SMA760M_3x'  =>  { # RD_MODE check for the Invalid Read voltage Mode
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #0 bits As there is no Instruction
            1.3 => { cmd => '33 - 00 - 21 00 00 00', descr => 'module_0: Set Frame Pattern'} , # Read voltage Mode RD_MODE
		    # Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_DEVICE_ID_CRC_SMA760P_3x'  =>  { # RD_MODE check for the Invalid Read voltage Mode
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #0 bits As there is no Instruction
            1.3 => { cmd => '33 - 00 - 21 00 00 00', descr => 'module_0: Set Frame Pattern'} , # Read voltage Mode RD_MODE
		    # Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_DEVICE_ID_SBit_SMA760M_3x'  =>  { # RD_MODE check for the Invalid Read voltage Mode
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #0 bits As there is no Instruction
            1.3 => { cmd => '33 - 00 - 21 00 00 00', descr => 'module_0: Set Frame Pattern'} , # Read voltage Mode RD_MODE
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 00', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_DEVICE_ID_SBit_SMA760P_3x'  =>  { # RD_MODE check for the Invalid Read voltage Mode
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #0 bits As there is no Instruction
            1.3 => { cmd => '33 - 00 - 21 00 00 00', descr => 'module_0: Set Frame Pattern'} , # Read voltage Mode RD_MODE
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 00', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_DEVICE_ID_DataLoad_SMA760M_2x'  =>  { # check for the Invalid CRC Read Device ID RD_DEVICE_ID
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    # make Instruction bits as 1
            1.3 => { cmd => '33 - 00 - 21 00 00 00', descr => 'module_0: Set Frame Pattern'} , # Read Device ID RD_DEVICE_ID Instruction bits# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_DEVICE_ID_DataLoad_SMA760P_2x'  =>  { # check for the Invalid CRC Read Device ID RD_DEVICE_ID
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    # make Instruction bits as 1
            1.3 => { cmd => '33 - 00 - 21 00 00 00', descr => 'module_0: Set Frame Pattern'} , # Read Device ID RD_DEVICE_ID Instruction bits# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#**************************************************************************************
    'Invalid_RD_DEVICE_ID_CRC_SMA760M_2x'  =>  { # RD_MODE check for the Invalid Read voltage Mode
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #0 bits As there is no Instruction
            1.3 => { cmd => '33 - 00 - 21 00 00 00', descr => 'module_0: Set Frame Pattern'} , # Read voltage Mode RD_MODE
		    # Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_DEVICE_ID_CRC_SMA760P_2x'  =>  { # RD_MODE check for the Invalid Read voltage Mode
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #0 bits As there is no Instruction
            1.3 => { cmd => '33 - 00 - 21 00 00 00', descr => 'module_0: Set Frame Pattern'} , # Read voltage Mode RD_MODE
		    # Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_DEVICE_ID_SBit_SMA760M_2x'  =>  { # RD_MODE check for the Invalid Read voltage Mode
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #0 bits As there is no Instruction
            1.3 => { cmd => '33 - 00 - 21 00 00 00', descr => 'module_0: Set Frame Pattern'} , # Read voltage Mode RD_MODE
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_DEVICE_ID_SBit_SMA760P_2x'  =>  { # RD_MODE check for the Invalid Read voltage Mode
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #0 bits As there is no Instruction
            1.3 => { cmd => '33 - 00 - 21 00 00 00', descr => 'module_0: Set Frame Pattern'} , # Read voltage Mode RD_MODE
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#************************************************* RD_REVISION_ID CRC,Data load,S bit check**************************************************************
#**************************************************************************************
    'Invalid_RD_REV_ID_CRC_SMA760M_3x'  =>  { # RD_MODE check for the Invalid Read voltage Mode
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #0 bits As there is no Instruction
            1.3 => { cmd => '33 - 00 - 22 00 00 00', descr => 'module_0: Set Frame Pattern'} , # Read voltage Mode RD_MODE
		    # Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_REV_ID_CRC_SMA760P_3x'  =>  { # RD_MODE check for the Invalid Read voltage Mode
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #0 bits As there is no Instruction
            1.3 => { cmd => '33 - 00 - 22 00 00 00', descr => 'module_0: Set Frame Pattern'} , # Read voltage Mode RD_MODE
		    # Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_REV_ID_Sbit_SMA760M_3x'  =>  { # RD_MODE check for the Invalid Read voltage Mode
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #0 bits As there is no Instruction
            1.3 => { cmd => '33 - 00 - 22 00 00 00', descr => 'module_0: Set Frame Pattern'} , # Read voltage Mode RD_MODE
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 00', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_REV_ID_Sbit_SMA760P_3x'  =>  { # RD_MODE check for the Invalid Read voltage Mode
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #0 bits As there is no Instruction
            1.3 => { cmd => '33 - 00 - 22 00 00 00', descr => 'module_0: Set Frame Pattern'} , # Read voltage Mode RD_MODE
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 00', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },	
#**************************************************************************************
    'Invalid_RD_REV_ID_CRC_SMA760M_2x'  =>  { # RD_MODE check for the Invalid Read voltage Mode
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #0 bits As there is no Instruction
            1.3 => { cmd => '33 - 00 - 22 00 00 00', descr => 'module_0: Set Frame Pattern'} , # Read voltage Mode RD_MODE
		    # Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_REV_ID_CRC_SMA760P_2x'  =>  { # RD_MODE check for the Invalid Read voltage Mode
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #0 bits As there is no Instruction
            1.3 => { cmd => '33 - 00 - 22 00 00 00', descr => 'module_0: Set Frame Pattern'} , # Read voltage Mode RD_MODE
		    # Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_REV_ID_Sbit_SMA760M_2x'  =>  { # RD_MODE check for the Invalid Read voltage Mode
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #0 bits As there is no Instruction
            1.3 => { cmd => '33 - 00 - 22 00 00 00', descr => 'module_0: Set Frame Pattern'} , # Read voltage Mode RD_MODE
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_REV_ID_Sbit_SMA760P_2x'  =>  { # RD_MODE check for the Invalid Read voltage Mode
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #0 bits As there is no Instruction
            1.3 => { cmd => '33 - 00 - 22 00 00 00', descr => 'module_0: Set Frame Pattern'} , # Read voltage Mode RD_MODE
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },		

#************************************************* RD_SERIAL CRC,Data load,S bit check**************************************************************
#***************************************************************************************
    'Invalid_RDserialNo_1_CRC_Check_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1   
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 00 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 06 40', descr => 'module_0: Write FIFO data' },
        },  
    },      
#***************************************************************************************
    'Invalid_RDserialNo_1_CRC_Check_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 00 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
   'Invalid_RD_SERIALNo_2_CRC_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 01 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_SERIALNo_2_CRC_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 01 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
   'Invalid_RD_SERIALNo_3_CRC_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 02 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_SERIALNo_3_CRC_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 02 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_SERIALNo_1_Sbit_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - F0 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 00 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 00', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_SERIALNo_1_Sbit_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - F0 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 00 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 00', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_SERIALNo_2_Sbit_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - F0 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 01 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 00', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_SERIALNo_2_Sbit_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - F0 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 01 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 00', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_SERIALNo_3_Sbit_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - F0 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 02 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 00', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_SERIALNo_3_Sbit_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - F0 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 02 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 00', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },	


#***************************************************************************************
    'Invalid_RD_SERIALNo_1_CRC_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 00 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_SERIALNo_1_CRC_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 00 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
   'Invalid_RD_SERIALNo_2_CRC_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 01 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_SERIALNo_2_CRC_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 01 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
   'Invalid_RD_SERIALNo_3_CRC_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 02 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_SERIALNo_3_CRC_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 02 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_SERIALNo_1_Sbit_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - F0 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 00 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_SERIALNo_1_Sbit_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - F0 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 00 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_SERIALNo_2_Sbit_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - F0 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 01 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_SERIALNo_2_Sbit_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - F0 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 01 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_SERIALNo_3_Sbit_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - F0 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 02 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_SERIALNo_3_Sbit_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - F0 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 02 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#*****************************************************RD_Clock_Counter CRC, Dataload, S bit check***************************************

#***************************************************************************************
    'Invalid_RDClkCntr_CRC_INIT_SMA760M_80ms'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 40 01 5F 90', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RDClkCntr_CRC_INIT_SMA760P_80ms'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 40 01 38 80', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_RDClkCntr_CRC_INIT_SMA760M_40ms'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 40 00 75 30', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RDClkCntr_CRC_INIT_SMA760P_40ms'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 40 00 75 30', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_RDClkCntr_DataLoad_INIT_SMA760M_80ms'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 40 01 38 80', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RDClkCntr_DataLoad_INIT_SMA760P_80ms'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 40 01 38 80', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_RDClkCntr_DataLoad_INIT_SMA760M_40ms'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 40 00 75 30', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RDClkCntr_DataLoad_INIT_SMA760P_40ms'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 40 00 75 30', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },

	#***************************************************************************************
    'Invalid_RDClkCntr_Sbit_INIT_SMA760M_80ms'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 40 01 38 80', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RDClkCntr_Sbit_INIT_SMA760P_80ms'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 40 01 38 80', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_RDClkCntr_Sbit_INIT_SMA760M_40ms'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 40 01 9C 40', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RDClkCntr_Sbit_INIT_SMA760P_40ms'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 40 01 9C 40', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_CONFIG1_CRC_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 34 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************RD_Config1 CRC, Dataload, S bit check**************************************************************

#***************************************************************************************
    'Invalid_RD_CONFIG1_CRC_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 34 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_CONFIG1_DataLoad_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 34 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_CONFIG1_DataLoad_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 34 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_CONFIG1_Sbit_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 34 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 00', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_CONFIG1_Sbit_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 34 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 00', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },

#***************************************************************************************
    'Invalid_RD_CONFIG1_CRC_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 34 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_CONFIG1_CRC_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 34 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_CONFIG1_DataLoad_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 34 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_CONFIG1_DataLoad_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 34 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_CONFIG1_Sbit_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 34 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_CONFIG1_Sbit_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 34 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#************************************************************RD_Monitor_II CRC, Dataload, S bit check**************************************
#***************************************************************************************
    'Invalid_RD_MON2_CRC_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 33 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			#Configure Pre-Trigger
			# 2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            # 2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            # 2.3 => { cmd => '63 - 00 - 2C 80 3D F0', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			# 2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			# 2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
            #Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_MON2_CRC_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 33 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
            
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },

#***************************************************************************************
    'Invalid_RD_MON2_DataLoad_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 33 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            #Configure Pre-Trigger
			# 2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            # 2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            # 2.3 => { cmd => '63 - 00 - 2C 80 31 9C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			# 2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			# 2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
            #Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },

	#***************************************************************************************
    'Invalid_RD_MON2_DataLoad_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 33 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            #Configure Pre-Trigger
			# 2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            # 2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            # 2.3 => { cmd => '63 - 00 - 2C 80 31 9C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			# 2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			# 2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
            #Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_MON2_Sbit_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 33 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            #Configure Pre-Trigger
			# 2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            # 2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            # 2.3 => { cmd => '63 - 00 - 2C 80 31 9C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			# 2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			# 2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
            #Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 00', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },

#***************************************************************************************
    'Invalid_RD_MON2_Sbit_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 33 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            #Configure Pre-Trigger
			# 2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            # 2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            # 2.3 => { cmd => '63 - 00 - 2C 80 31 9C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			# 2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			# 2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
            #Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 00', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },

#***************************************************************************************
    'Invalid_RD_MON2_CRC_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 33 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			#Configure Pre-Trigger
			# 2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            # 2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            # 2.3 => { cmd => '63 - 00 - 2C 80 3D F0', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			# 2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			# 2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
            #Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_MON2_CRC_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 33 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },

#***************************************************************************************
    'Invalid_RD_MON2_DataLoad_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 33 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            #Configure Pre-Trigger
			# 2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            # 2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            # 2.3 => { cmd => '63 - 00 - 2C 80 31 9C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			# 2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			# 2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
            #Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_MON2_DataLoad_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 33 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            #Configure Pre-Trigger
			# 2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            # 2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            # 2.3 => { cmd => '63 - 00 - 2C 80 31 9C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			# 2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			# 2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
            #Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_MON2_Sbit_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 33 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            #Configure Pre-Trigger
			# 2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            # 2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            # 2.3 => { cmd => '63 - 00 - 2C 80 31 9C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			# 2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			# 2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
            #Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },

#***************************************************************************************
    'Invalid_RD_MON2_Sbit_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 33 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            #Configure Pre-Trigger
			# 2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            # 2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            # 2.3 => { cmd => '63 - 00 - 2C 80 31 9C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			# 2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			# 2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
            #Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_MON2_EOP_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 33 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 38 80 00 3C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 00 00 10', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 10', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_RD_MON2_EOP_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 33 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 38 80 00 3C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 00 00 10', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 10', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_MON2_EOP_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 33 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 38 80 00 3C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 00 00 10', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 10', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_RD_MON2_EOP_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 33 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 38 80 00 3C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 00 00 10', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 10', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_RD_MON2_CRC_SMA760M_EOP_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 33 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 38 80 00 3C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },		
#***************************************************************************************
    'Invalid_RD_MON2_CRC_SMA760P_EOP_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 33 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 38 80 00 3C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_RD_MON1_CRC_SMA760M_EOP_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 32 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 38 80 00 3C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },		
#***************************************************************************************
    'Invalid_RD_MON1_CRC_SMA760P_EOP_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 32 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 38 80 00 3C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },	

#***************************************************************************************
    'Invalid_RD_MON2_Sbit_SMA760M_EOP_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 33 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 38 80 00 3C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 00', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },		
#***************************************************************************************
    'Invalid_RD_MON2_Sbit_SMA760P_EOP_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 33 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 38 80 00 3C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 00', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_RD_MON1_Sbit_SMA760M_EOP_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 32 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 38 80 00 3C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 00', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },		
#***************************************************************************************
    'Invalid_RD_MON1_Sbit_SMA760P_EOP_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 32 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 38 80 00 3C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 00', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_MON2_Sbit_SMA760M_EOP_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 33 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 38 80 00 3C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },		
#***************************************************************************************
    'Invalid_RD_MON2_Sbit_SMA760P_EOP_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 33 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 38 80 00 3C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_RD_MON1_Sbit_SMA760M_EOP_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 32 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 38 80 00 3C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },		
#***************************************************************************************
    'Invalid_RD_MON1_Sbit_SMA760P_EOP_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 32 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 38 80 00 3C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
	#***************************************************************************************
    'Invalid_RD_MON2_CRC_SMA760M_EOP_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 33 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 38 80 00 3C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },		
#***************************************************************************************
    'Invalid_RD_MON2_CRC_SMA760P_EOP_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 33 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 38 80 00 3C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_RD_MON1_CRC_SMA760M_EOP_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 32 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 38 80 00 3C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },		
#***************************************************************************************
    'Invalid_RD_MON1_CRC_SMA760P_EOP_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 32 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 38 80 00 3C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_ITE_OFF_CH1_Avg_check_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 80 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 00', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 06 40', descr => 'module_0: Write FIFO data' },
        },
    },

	
	
#**********************************RD_Clock_Counter TFF,TST,PF, TF, EOP check********************
#***************************************************************************************
    'Invalid_RD_CLK_TFF_SMA760M'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - 00 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 80 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 80 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },

#***************************************************************************************
    'Invalid_RD_CLK_TFF_SMA760P'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - 00 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 80 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 80 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },	
	
#***************************************************************************************
    'Invalid_RD_CLK_TST_SMA760M'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - 80 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 40 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 40 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },

#***************************************************************************************
    'Invalid_RD_CLK_TST_SMA760P'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - 80 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 40 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 40 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_RD_CLK_TF_SMA760M'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - F0 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 08 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 08 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },

#***************************************************************************************
    'Invalid_RD_CLK_TF_SMA760P'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - F0 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 08 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 08 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_CLK_PF_SMA760M'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - F8 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 04 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 04 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },

#***************************************************************************************
    'Invalid_RD_CLK_PF_SMA760P'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - F8 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 04 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 04 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_RD_CLK_EOP_SMA760M'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - C0 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 20 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 20 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },

#***************************************************************************************
    'Invalid_RD_CLK_EOP_SMA760P'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - C0 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 20 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 20 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_RD_CLK_GSbit_SMA760M'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 00 00 08', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 08', descr => 'module_0: Write FIFO data' },
        },
    },

#***************************************************************************************
    'Invalid_RD_CLK_GSbit_SMA760P'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 00 00 08', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 08', descr => 'module_0: Write FIFO data' },
        },
    },	
	
	
#***************************************************************************************
    'Invalid_RD_CLK_Sbit_SMA760M'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },

#***************************************************************************************
    'Invalid_RD_CLK_Sbit_SMA760P'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },	
	
#***************************************************************************************
    'Invalid_RD_CLK_Dataload_SMA760M'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },

#***************************************************************************************
    'Invalid_RD_CLK_Dataload_SMA760P'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },

#*********************************RD_Offset_Cancellation CRC, Dataload, S bit Check*********************************************	

#***************************************************************************************
    'Invalid_RD_OffCan_enable_CRC_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 3D F0', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_OffCan_enable_CRC_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			# Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 0D E4', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_OffCan_enable_DataLoad_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 3D F0', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
          	#Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_OffCan_enable_DataLoad_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 0D E4', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           	#Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_OffCan_enable_Sbit_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 3D F0', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           	#Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 00', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_OffCan_enable_Sbit_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 3D F0', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },

#***************************************************************************************
    'Invalid_RD_OffCan_enable_CRC_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 3D F0', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_OffCan_enable_CRC_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 0D E4', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_OffCan_enable_DataLoad_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 3D F0', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           	#configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_OffCan_enable_DataLoad_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 0D E4', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
          	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_OffCan_enable_Sbit_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 3D F0', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_OffCan_enable_Sbit_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 0D E4', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },

#***************************************************************************************
    'Invalid_RD_OffCan_disable_CRC_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 31 9C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_OffCan_disable_CRC_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			# Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 01 88', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_OffCan_disable_DataLoad_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 31 9C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_OffCan_disable_DataLoad_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 01 88', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           	#Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_OffCan_disable_Sbit_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 31 9C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           	#Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 00', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_OffCan_disable_Sbit_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 01 88', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },

#***************************************************************************************
    'Invalid_RD_OffCan_disable_CRC_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 31 9C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_OffCan_disable_CRC_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 01 88', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_OffCan_disable_DataLoad_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 31 9C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           	#configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_OffCan_disable_DataLoad_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 01 88', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
          	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_OffCan_disable_Sbit_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 31 9C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_OffCan_disable_Sbit_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 01 88', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_SensorData_CH1_Avg_SMA760M_Chk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 80 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			 # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 31 9C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 00 7D 00', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 05 20', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 FF 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_SensorData_CH2_Avg_SMA760M_Chk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - C4 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			 # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 31 9C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 00 7D 00', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 05 20', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 FF 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_SensorData_CH1_Avg_SMA760P_Chk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 80 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			 # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 01 88', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 00 7D 00', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 05 20', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 FF 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_SensorData_CH2_Avg_SMA760P_Chk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - C4 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			 # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 01 88', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 00 7D 00', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 05 20', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 07 FF C0', descr => 'module_0: Write FIFO data' },
        },
    },

#***************************************************************************************
    'Invalid_RD_SensorData_CH1_Peak_SMA760M_Chk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 80 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			 # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 31 9C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 00 7D 00', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 14', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 07 FF C0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_SensorData_CH2_Peak_SMA760M_Chk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - C4 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			 # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 31 9C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 00 7D 00', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 14', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 07 FF C0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_SensorData_CH1_Peak_SMA760P_Chk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 80 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			 # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 01 88', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 00 7D 00', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 14', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 07 FF C0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_SensorData_CH2_Peak_SMA760P_Chk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - C4 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			 # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 01 88', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 00 7D 00', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 14', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 07 FF C0', descr => 'module_0: Write FIFO data' },
        },
    },
#*************************************Slow offset cancellation*******************
#***************************************************************************************
    'Invalid_RD_slow_OffCan_enable_CRC_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 39 D4', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_slow_OffCan_enable_CRC_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			# Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 01 D0', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_slow_OffCan_enable_DataLoad_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 39 D4', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
          	#Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_slow_OffCan_enable_DataLoad_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 01 D0', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           	#Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_slow_OffCan_enable_Sbit_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 39 D4', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           	#Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_slow_OffCan_enable_Sbit_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 01 D0', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },

#***************************************************************************************
    'Invalid_RD_slow_OffCan_enable_CRC_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 39 D4', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_slow_OffCan_enable_CRC_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 01 D0', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_slow_OffCan_enable_DataLoad_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 39 D4', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           	#configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_slow_OffCan_enable_DataLoad_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 01 D0', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
          	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_slow_OffCan_enable_Sbit_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 39 D4', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_slow_OffCan_enable_Sbit_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 01 D0', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
           	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },

	
#*********************************RD_Test_Mode BITE1 Dataload, CRC, Sbit check**********************************

#***************************************************************************************
    'Invalid_RD_TestMode_BITE1_CRC_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			# Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 B0', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_TestMode_BITE1_CRC_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 B0', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_TestMode_BITE1_CRC_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 B0', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_TestMode_BITE1_CRC_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			# Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 B0', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		    # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_TestMode_BITE1_DataLoad_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			# Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 B0', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		    # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_TestMode_BITE1_DataLoad_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			# Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 B0', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		    # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_TestMode_BITE1_DataLoad_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			# Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 B0', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		    # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_TestMode_BITE1_DataLoad_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 B0', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_TestMode_BITE1_Sbit_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 B0', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		    # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_TestMode_BITE1_Sbit_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			# Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 B0', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		    # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_TestMode_BITE1_Sbit_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 B0', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_TestMode_BITE1_Sbit_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 B0', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#*********************************RD_Test_Mode BITE2 Dataload, CRC, Sbit check**********************************
#***************************************************************************************
    'Invalid_RD_TestMode_BITE2_CRC_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			# Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 01 4C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_TestMode_BITE2_CRC_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 01 4C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_TestMode_BITE2_CRC_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 01 4C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_TestMode_BITE2_CRC_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			# Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 01 4C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		    # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_TestMode_BITE2_DataLoad_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			# Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 01 4C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		    # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_TestMode_BITE2_DataLoad_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			# Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 01 4C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		    # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_TestMode_BITE2_DataLoad_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			# Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 01 4C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		    # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_TestMode_BITE2_DataLoad_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 01 4C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_TestMode_BITE2_Sbit_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 01 4C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		    # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_TestMode_BITE2_Sbit_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			# Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 01 4C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		    # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_TestMode_BITE2_Sbit_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 01 4C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_TestMode_BITE2_Sbit_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 01 4C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },

#*********************************RD_Test_Mode BITEOff Dataload, CRC, Sbit check**********************************
#***************************************************************************************
    'Invalid_RD_TestMode_BITEOff_CRC_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			# Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 00', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_TestMode_BITEOff_CRC_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 00', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_TestMode_BITEOff_CRC_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 00', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_TestMode_BITEOff_CRC_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			# Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 00', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		    # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_TestMode_BITEOff_DataLoad_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			# Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 00', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		    # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_TestMode_BITEOff_DataLoad_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			# Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 00', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		    # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_TestMode_BITEOff_DataLoad_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			# Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 00', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		    # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_TestMode_BITEOff_DataLoad_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 00', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_TestMode_BITEOff_Sbit_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 00', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		    # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_TestMode_BITEOff_Sbit_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			# Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 00', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		    # Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_TestMode_BITEOff_Sbit_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 00', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_TestMode_BITEOff_Sbit_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 00', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 0F 42 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			#2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#******************************************Evaluation of BITE**********************************************************************	
#***************************************************************************************
    'Invalid_BITE_OFF_CH1_SMA760M_Avg'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 80 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			 # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 00', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 00 7D 00', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 05 20', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 FF 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_BITE_OFF_CH2_SMA760M_Avg'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - C4 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			 # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 00', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 00 7D 00', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 05 20', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 FF 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_BITE_OFF_CH1_SMA760P_Avg'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 80 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			 # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 00', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 00 7D 00', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 05 20', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 FF 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_BITE_OFF_CH2_SMA760P_Avg'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - C4 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			 # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 00', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 00 7D 00', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 05 20', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 FF 00', descr => 'module_0: Write FIFO data' },
        },
    },

#***************************************************************************************
    'Invalid_BITE_OFF_CH1_SMA760M_Peak'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 80 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			 # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 00', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 00 7D 00', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 14', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 05 5F 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_BITE_OFF_CH2_SMA760M_Peak'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - C4 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			 # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 00', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 00 7D 00', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 14', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 05 5F 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_BITE_OFF_CH1_SMA760P_Peak'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 80 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			 # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 00', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 00 7D 00', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 14', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 07 5F C0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_BITE_OFF_CH2_SMA760P_Peak'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - C4 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			 # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 00', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 00 7D 00', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 14', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 05 5F 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_BITE1_CH1_SMA760M_Avg'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 80 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			 # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 B0', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 00 7D 00', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 05 20', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 FF 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_BITE1_CH2_SMA760M_Avg'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - C4 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			 # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 B0', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 00 7D 00', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 05 20', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 FF 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_BITE1_CH1_SMA760P_Avg'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 80 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			 # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 B0', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 00 7D 00', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 05 20', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 07 FF C0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_BITE1_CH2_SMA760P_Avg'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - C4 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			 # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 B0', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 00 7D 00', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 05 20', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 07 FF C0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_BITE1_CH1_SMA760M_Peak'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 80 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			 # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 B0', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 00 7D 00', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 14', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 FF 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_BITE1_CH2_SMA760M_Peak'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - C4 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			 # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 B0', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 00 7D 00', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 14', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 FF 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_BITE1_CH1_SMA760P_Peak'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 80 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			 # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 B0', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 00 7D 00', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 14', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 FF 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_BITE1_CH2_SMA760P_Peak'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - C4 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			 # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 00 B0', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 00 7D 00', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 14', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 FF 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_BITE2_CH1_SMA760M_Avg'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 80 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			 # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 01 4C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 00 7D 00', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 05 20', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 FF 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_BITE2_CH2_SMA760M_Avg'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - C4 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			 # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 01 4C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 00 7D 00', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 05 20', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 FF 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_BITE2_CH1_SMA760P_Avg'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 80 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			 # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 01 4C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 00 7D 00', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 05 20', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 07 FF C0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_BITE2_CH2_SMA760P_Avg'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - C4 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			 # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 01 4C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 00 7D 00', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 05 20', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 07 FF C0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_BITE2_CH1_SMA760M_Peak'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 80 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			 # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 01 4C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 00 7D 00', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 14', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 FF 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_BITE2_CH2_SMA760M_Peak'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - C4 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			 # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 01 4C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 00 7D 00', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 14', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 FF 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_BITE2_CH1_SMA760P_Peak'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 80 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			 # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 01 4C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 00 7D 00', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 14', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 FF 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_BITE2_CH2_SMA760P_Peak'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - C4 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			 # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 31 80 01 4C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 00 7D 00', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 14', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 FF 00', descr => 'module_0: Write FIFO data' },
        },
    },
#******************************************RD_SENSOR_DATA**************************************
#***************************************************************************************
    'Invalid_RD_SensorDataCh1_CRC_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 80 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			 # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 31 9C', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 00 7D 00', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 40', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 02 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_SensorDataCh1_CRC_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 80 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
			 # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF FF FF FF', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 2C 80 01 88', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 00 7D 00', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 05 20', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 00 FF 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_SensorDataCh1_CRC_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 80 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_SensorDataCh1_CRC_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 80 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },

#********************************RD_RAW_OFFSET CRC, Dataload, Sbit Check****************************
#***************************************************************************************
    'Invalid_RD_RAWOffsetCH1_Dataload_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 27 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_RAWOffsetCH2_Dataload_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 28 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },

#***************************************************************************************
    'Invalid_RD_RAWOffsetCH1_CRC_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 27 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_RAWOffsetCH2_CRC_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 28 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_RAWOffsetCH1_CRC_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 27 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_RAWOffsetCH2_CRC_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 28 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_RAWOffsetCH1_CRC_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 27 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_RAWOffsetCH2_CRC_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 28 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_RAWOffsetCH1_SMA760M_Sbit_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 27 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_RAWOffsetCH2_SMA760M_Sbit_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 28 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_RAWOffsetCH1_SMA760P_Sbit_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 27 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_RAWOffsetCH2_SMA760P_Sbit_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 28 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_RAWOffsetCH1_CRC_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 27 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_RAWOffsetCH2_CRC_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 28 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_RAWOffsetCH1_CRC_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 27 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_RAWOffsetCH2_CRC_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 28 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_RAWOffsetCH1_SMA760M_Sbit_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 27 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_RAWOffsetCH2_SMA760M_Sbit_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 28 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_RAWOffsetCH1_SMA760P_Sbit_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 27 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_RAWOffsetCH2_SMA760P_Sbit_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 28 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#********************************RD_OFFSET_REG CRC, Dataload, Sbit Check****************************

#***************************************************************************************
    'Invalid_RD_OFFSET_REG_CH1_Dataload_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 29 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_OFFSET_REG_CH2_Dataload_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2A 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_OFFSET_REG_CH1_CRC_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 29 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_OFFSET_REG_CH2_CRC_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2A 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_OFFSET_REG_CH1_CRC_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 29 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_OFFSET_REG_CH2_CRC_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2A 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },

#***************************************************************************************
    'Invalid_RD_OFFSET_REG_CH1_SMA760M_Sbit_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 29 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_OFFSET_REG_CH2_SMA760M_Sbit_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2A 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_OFFSET_REG_CH1_SMA760P_Sbit_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 29 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_OFFSET_REG_CH2_SMA760P_Sbit_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2A 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_RD_OFFSET_REG_CH1_CRC_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 29 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_OFFSET_REG_CH2_CRC_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2A 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_OFFSET_REG_CH1_CRC_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 29 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_OFFSET_REG_CH2_CRC_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2A 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },

#***************************************************************************************
    'Invalid_RD_OFFSET_REG_CH1_SMA760M_Sbit_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 29 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_OFFSET_REG_CH2_SMA760M_Sbit_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2A 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_OFFSET_REG_CH1_SMA760P_Sbit_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 29 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_OFFSET_REG_CH2_SMA760P_Sbit_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2A 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },		
	

#********************************RD_BITE CRC, Dataload, Sbit Check****************************
#***************************************************************************************
    'Invalid_RD_BITE_CH1_CRC_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_BITE_CH2_CRC_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0E 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_BITE_CH1_CRC_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_BITE_CH2_CRC_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0E 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_RD_BITE_CH1_SMA760M_Sbit_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 00', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_BITE_CH2_SMA760M_Sbit_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0E 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 00', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_BITE_CH1_SMA760P_Sbit_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 00', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_BITE_CH2_SMA760P_Sbit_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0E 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 00', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_RD_BITE_CH1_CRC_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_BITE_CH2_CRC_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0E 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_BITE_CH1_CRC_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_BITE_CH2_CRC_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0E 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_RD_BITE_CH1_SMA760M_Sbit_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_BITE_CH2_SMA760M_Sbit_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0E 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_BITE_CH1_SMA760P_Sbit_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_BITE_CH2_SMA760P_Sbit_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0E 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },		
	
#***********************************BITE CALCULATION****************************************************************
#***************************************************************************************
    'Invalid_RD_BITE_CH1_POS_SMA760M_0LSB_Avgchk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F F0 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },		
#***************************************************************************************
    'Invalid_RD_BITE_CH1_POS_SMA760M_100LSB_Avgchk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F F0 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 06 40 00', descr => 'module_0: Write FIFO data' },
        },
    },		
#***************************************************************************************
    'Invalid_RD_BITE_CH1_NEG_SMA760M_0LSBAvgchk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 0F F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },			
#***************************************************************************************
    'Invalid_RD_BITE_CH1_NEG_SMA760M_Neg100LSB_Avgchk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 0F F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 09 C0', descr => 'module_0: Write FIFO data' },
        },
    },	
	
#***************************************************************************************
    'Invalid_RD_BITE_CH2_POS_SMA760M_0LSB_Avgchk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0E 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F F0 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },		
#***************************************************************************************
    'Invalid_RD_BITE_CH2_POS_SMA760M_100LSB_Avgchk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0E 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 40', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F F0 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 06 40 00', descr => 'module_0: Write FIFO data' },
        },
    },	
	
#***************************************************************************************
    'Invalid_RD_BITE_CH2_NEG_SMA760M_0LSB_Avgchk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0E 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 0F F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_RD_BITE_CH2_NEG_SMA760M_Neg100LSB_Avgchk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0E 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 0F F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 09 C0', descr => 'module_0: Write FIFO data' },
        },
    },	

#***************************************************************************************
    'Invalid_RD_BITE_CH1_POS_SMA760P_0LSB_Avgchk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F F0 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },		
#***************************************************************************************
    'Invalid_RD_BITE_CH1_POS_SMA760P_100LSB_Avgchk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 40', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F F0 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 06 40 00', descr => 'module_0: Write FIFO data' },
        },
    },		
#***************************************************************************************
    'Invalid_RD_BITE_CH1_NEG_SMA760P_0LSBAvgchk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 40', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 0F F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },			
#***************************************************************************************
    'Invalid_RD_BITE_CH1_NEG_SMA760P_Neg100LSB_Avgchk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 0F F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 09 C0', descr => 'module_0: Write FIFO data' },
        },
    },	
	
#***************************************************************************************
    'Invalid_RD_BITE_CH2_POS_SMA760P_0LSB_Avgchk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0E 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F F0 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },		
#***************************************************************************************
    'Invalid_RD_BITE_CH2_POS_SMA760P_100LSB_Avgchk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0E 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F F0 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 06 40 00', descr => 'module_0: Write FIFO data' },
        },
    },	
	
#***************************************************************************************
    'Invalid_RD_BITE_CH2_NEG_SMA760P_0LSB_Avgchk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0E 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 0F F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_RD_BITE_CH2_NEG_SMA760P_Neg100LSB_Avgchk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0E 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 0F F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 09 C0', descr => 'module_0: Write FIFO data' },
        },
    },		
#***************************************************************************************
    'Invalid_RD_BITE_CH1_POS_SMA760M_0LSB_Peakchk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F F0 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },		
	
#***************************************************************************************
    'Invalid_RD_BITE_CH1_POS_SMA760M_100LSB_Peakchk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F F0 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 06 40 00', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_RD_BITE_CH1_NEG_SMA760M_0LSB_Peakchk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 0F F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_RD_BITE_CH1_NEG_SMA760M_Neg100LSB_Peakchk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 0F F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 09 C0', descr => 'module_0: Write FIFO data' },
        },
    },
	
#***************************************************************************************
    'Invalid_RD_BITE_CH2_POS_SMA760M_0LSB_Peakchk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0E 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F F0 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_RD_BITE_CH2_POS_SMA760M_100LSB_Peakchk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0E 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F F0 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 06 40 00', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_RD_BITE_CH2_NEG_SMA760M_0LSB_Avgchk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0E 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 0F F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_BITE_CH2_NEG_SMA760M_0LSB_Peakchk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0E 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F F0 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },		
#***************************************************************************************
    'Invalid_RD_BITE_CH2_NEG_SMA760M_Neg100LSB_Peakchk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0E 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 0F F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 09 C0', descr => 'module_0: Write FIFO data' },
        },
    },	

#***************************************************************************************
    'Invalid_RD_BITE_CH1_POS_SMA760P_0LSB_Peakchk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F F0 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },		
#***************************************************************************************
    'Invalid_RD_BITE_CH1_POS_SMA760P_100LSB_Peakchk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F F0 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 06 40 00', descr => 'module_0: Write FIFO data' },
        },
    },		
#***************************************************************************************
    'Invalid_RD_BITE_CH1_NEG_SMA760P_0LSBPeakchk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 0F F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },			
#***************************************************************************************
    'Invalid_RD_BITE_CH1_NEG_SMA760P_Neg100LSB_Peakchk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 0F F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 09 C0', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_RD_BITE_CH2_POS_SMA760P_0LSB_Peakchk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0E 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F F0 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },		
#***************************************************************************************
    'Invalid_RD_BITE_CH2_POS_SMA760P_100LSB_Peakchk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0E 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F F0 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 06 40 00', descr => 'module_0: Write FIFO data' },
        },
    },	
	
#***************************************************************************************
    'Invalid_RD_BITE_CH2_NEG_SMA760P_0LSB_Peakchk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0E 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 0F F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_RD_BITE_CH2_NEG_SMA760P_Neg100LSB_Peakchk'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 0E 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 0F F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 09 C0', descr => 'module_0: Write FIFO data' },
        },
    },	
#********************************RD_Monitor_II CRC, Dataload, Sbit Check****************************
#***************************************************************************************
    'Invalid_MonData2_TFF_SMA760M'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - 00 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 33 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 80 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 80 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_MonData2_TFF_SMA760P'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - 00 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 33 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 80 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 80 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_MonData2_TST_SMA760M'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - 80 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 33 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 40 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 40 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_MonData2_TST_SMA760P'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - 80 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 33 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 40 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 40 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_MonData2_TF_SMA760M'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - F0 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 33 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 08 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 08 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_MonData2_TF_SMA760P'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - F0 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 33 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 08 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 08 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },	
	#***************************************************************************************
    'Invalid_MonData2_PF_SMA760M'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - F8 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 33 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 04 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 04 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_MonData2_PF_SMA760P'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - F8 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 33 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 04 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 04 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
	#***************************************************************************************
    'Invalid_MonData2_GS_SMA760M'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 33 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 08', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 08', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_MonData2_GS_SMA760P'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 33 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 08', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 08', descr => 'module_0: Write FIFO data' },
        },
    },
#**************************************SID *************************	
#***************************************************************************************
    'Invalid_RD_SensorDataCh1_SID_SMA760M'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 80 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF C0 00 00', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 23 80 00 20', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 00 01 30', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 01 F0 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 01 F0 00 00', descr => 'module_0: Write FIFO data' },
        },
    },	

#***************************************************************************************
    'Invalid_RD_SensorDataCh1_SID_SMA760P'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 80 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF C0 00 00', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 23 80 00 00', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 00 01 40', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 01 F0 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 F0 00 00', descr => 'module_0: Write FIFO data' },
        },
    },

#***************************************************************************************
    'Invalid_RD_SensorDataCh2_SID_SMA760M'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - C4 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 04', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF C0 00 00', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 23 80 00 20', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 00 01 30', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 01 F0 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 01 F0 00 00', descr => 'module_0: Write FIFO data' },
        },
    },	

#***************************************************************************************
    'Invalid_RD_SensorDataCh2_SID_SMA760P'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - C4 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
            # Configure Pre-Trigger
			2.1 => { cmd => '61 - 00 - 00 10 00 10', descr => 'pretrigger_0: Set SPI1 CS for SMA600'}, #CS
            2.2 => { cmd => '62 - 00 - FF C0 00 00', descr => 'pretrigger_0: Set Frame Mask'} ,    # make Instruction bits as 1
            2.3 => { cmd => '63 - 00 - 23 80 00 00', descr => 'pretrigger_0: Set Frame Pattern'} , # Read Sensor Data channel 1 bits
			2.4 => { cmd => '64 - 00 - 00 00 01 30', descr => 'pretrigger_0: Pre-Trigger active for 1s' }, # Pre-Trigger time
			2.5 => { cmd => '65 - 00 - 00 00 00 01', descr => 'module_0: Trigger only by pre trigger 1' }, # Trigger condition
		   	# Configure FIFOs for SA1
            3.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            3.2 => { cmd => '42 - 00 - 01 - 00 F0 00 00', descr => 'module_0: Write FIFO ctrl' },
            3.3 => { cmd => '43 - 00 - 01 - 00 F0 00 00', descr => 'module_0: Write FIFO data' },
        },
    },		
#**************************************Fault information *************************
	
#***************************************************************************************
    'Invalid_Group1_fault_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 34 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_Group1_fault_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 34 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_Group1_fault_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 34 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_Group1_fault_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 34 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },	
	
#***************************************************************************************
    'Invalid_Group2_fault_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_Group2_fault_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },	
	
#***************************************************************************************
    'Invalid_Group2_fault_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_Group2_fault_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2C 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },		
#***************************************************************************************
    'Invalid_Group3_fault_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_Group3_fault_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_Group3_fault_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_Group3_fault_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 31 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },	
	
#***************************************************************************************
    'Invalid_Group4_fault_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2A 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_Group4_fault_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 29 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_Group4_fault_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2A 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_Group4_fault_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 29 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },		
	
#***************************************************************************************
    'Invalid_Cyclic_fault_SMA760M_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - C4 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 00', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 08', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 08', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_Cyclic_fault_SMA760P_3x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 40 01 38 80', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 08', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 08', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_Cyclic_fault_SMA760M_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_Cyclic_fault_SMA760P_2x'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2D 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO data' },
        },
    },		
	
#*****************************STORE INITIAL VALUE***************
#***************************************************************************************
    'Invalid_RD_RAWOffsetCH1_Dataload_SMA760M_0LSB'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 27 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_RD_RAWOffsetCH1_Dataload_SMA760M_3200LSB'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 27 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 03 20 00', descr => 'module_0: Write FIFO data' },
        },
    },		
#***************************************************************************************
    'Invalid_RD_RAWOffsetCH1_Dataload_SMA760M_Neg3200LSB'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 27 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 0C E0 00', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_RD_RAWOffsetCH2_Dataload_SMA760M_0LSB'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 28 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },	
	
#***************************************************************************************
    'Invalid_RD_RAWOffsetCH2_Dataload_SMA760M_3200LSB'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 28 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 03 20 00', descr => 'module_0: Write FIFO data' },
        },
    },	
		
#***************************************************************************************
    'Invalid_RD_RAWOffsetCH2_Dataload_SMA760M_Neg3200LSB'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 28 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			
             # Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 0C E0 00', descr => 'module_0: Write FIFO data' },
        },
    },		
#***************************************************************************************
    'Invalid_RD_RAWOffsetCH1_Dataload_SMA760P_0LSB'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 27 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },		
#***************************************************************************************
    'Invalid_RD_RAWOffsetCH1_Dataload_SMA760P_960LSB'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 27 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 F0 00', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_RD_RAWOffsetCH1_Dataload_SMA760P_Neg960LSB'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 27 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 0F 10 00', descr => 'module_0: Write FIFO data' },
        },
    },		
#***************************************************************************************
    'Invalid_RD_RAWOffsetCH2_Dataload_SMA760P_0LSB'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 28 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },		
#***************************************************************************************
    'Invalid_RD_RAWOffsetCH2_Dataload_SMA760P_960LSB'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 28 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 F0 00', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_RD_RAWOffsetCH2_Dataload_SMA760P_Neg960LSB'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 28 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 0F 10 00', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_RD_OFFSET_REG_CH1_Dataload_SMA760M_0LSB'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 29 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_RD_OFFSET_REG_CH1_Dataload_SMA760M_3200LSB'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 29 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 C8 00', descr => 'module_0: Write FIFO data' },
        },
    },		
#***************************************************************************************
    'Invalid_RD_OFFSET_REG_CH1_Dataload_SMA760M_Neg3200LSB'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 29 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 0F 38 00', descr => 'module_0: Write FIFO data' },
        },
    },		
	
#***************************************************************************************
    'Invalid_RD_OFFSET_REG_CH2_Dataload_SMA760M_0LSB'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2A 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_RD_OFFSET_REG_CH2_Dataload_SMA760M_3200LSB'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2A 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 C8 00', descr => 'module_0: Write FIFO data' },
        },
    },		
#***************************************************************************************
    'Invalid_RD_OFFSET_REG_CH2_Dataload_SMA760M_Neg3200LSB'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2A 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 0F 38 00', descr => 'module_0: Write FIFO data' },
        },
    },		
#***************************************************************************************
    'Invalid_RD_OFFSET_REG_CH1_Dataload_SMA760P_0LSB'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 29 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_RD_OFFSET_REG_CH1_Dataload_SMA760P_960LSB'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 29 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 3C 00', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_RD_OFFSET_REG_CH1_Dataload_SMA760P_Neg960LSB'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 29 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 0F C4 00', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_RD_OFFSET_REG_CH2_Dataload_SMA760P_0LSB'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2A 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },		
#***************************************************************************************
    'Invalid_RD_OFFSET_REG_CH1_Dataload_SMA760P_3840LSB'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2A 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 F0 00', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_RD_OFFSET_REG_CH1_Dataload_SMA760P_Neg3840LSB'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 2A 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 01', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 0F 10 00', descr => 'module_0: Write FIFO data' },
        },
    },	
#***********************************VoltageMode****************************************
#***************************************************************************************
    'Invalid_ReadVgMode_CRC_3x_SMA760M'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 20 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_ReadVgMode_CRC_3x_SMA760P'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 20 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_ReadVgMode_DataLoad_3x_SMA760M'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 20 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },		

#***************************************************************************************
    'Invalid_ReadVgMode_DataLoad_3x_SMA760P'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 20 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 03', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },

#***************************************************************************************
    'Invalid_ReadVgMode_Sbit_3x_SMA760M'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 20 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 00', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },		

#***************************************************************************************
    'Invalid_ReadVgMode_Sbit_3x_SMA760P'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 20 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 00', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },

#***************************************************************************************
    'Invalid_ReadVgMode_CRC_2x_SMA760M'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 20 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
#***************************************************************************************
    'Invalid_ReadVgMode_CRC_2x_SMA760P'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 20 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 00 00 07', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },	
#***************************************************************************************
    'Invalid_ReadVgMode_DataLoad_2x_SMA760M'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 20 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },		

#***************************************************************************************
    'Invalid_ReadVgMode_DataLoad_2x_SMA760P'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FF C0 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 20 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 00 0F FF F0', descr => 'module_0: Write FIFO data' },
        },
    },

#***************************************************************************************
    'Invalid_ReadVgMode_Sbit_2x_SMA760M'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 04', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 20 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },		

#***************************************************************************************
    'Invalid_ReadVgMode_Sbit_2x_SMA760P'  =>  { # check the Invalid RD_SERIAL_NO INIT Fault
#***************************************************************************************
        'CMD_sequence' => {
            # Configure SPI trigger for SA1
            1.1 => { cmd => '31 - 00 - 00 10 00 10', descr => 'module_0: Set SPI1 CS for SMA760'}, #CS
            1.2 => { cmd => '32 - 00 - FC 00 00 00', descr => 'module_0: Set Frame Mask'} ,    #10 bits for instruction
            1.3 => { cmd => '33 - 00 - 20 00 00 00', descr => 'module_0: Set Frame Pattern'} , #RD_SEN_DataCH1_SID
			# Configure FIFOs for SA1
            2.1 => { cmd => '41 - 00 - 01 - 10 00 00 02', descr => 'module_0: Write FIFO mode and time' },
            2.2 => { cmd => '42 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO ctrl' },
            2.3 => { cmd => '43 - 00 - 01 - 02 00 00 00', descr => 'module_0: Write FIFO data' },
        },
    },
};
#***************************************************************************************
$Defaults->{'TC_MANITOO_MAP'} = {
#***************************************************************************************
######################### SMA660 Variables #####################################################
                'AsicIdMismatch_fltStatus_U8'  => 'Dem_AllEventsStatusByte(574)_U8', ## 703,rb_syc_AsicIdMismatch_flt,0x0xF00049  AsicIdMismatch
				'GP1_SMA760M_U8'               => 'Dem_AllEventsStatusByte(44)_U8',  ## 44,rb_csem_InitGroup1Sma660Main_flt,0x0xF00049  InitGroup1Sma660Main
				'GP1_SMA760P_U8'               => 'Dem_AllEventsStatusByte(45)_U8',  ## 45,rb_csem_InitGroup1Sma660Plausi_flt,0x0xF00049  InitGroup1Sma660Plausi
				'GP2_SMA760M_U8'               => 'Dem_AllEventsStatusByte(46)_U8',  ## 46,rb_csem_InitGroup2Sma660Main_flt,0x0xF00049  InitGroup2Sma660Main
				'GP2_SMA760P_U8'               => 'Dem_AllEventsStatusByte(47)_U8',  ## 47,rb_csem_InitGroup2Sma660Plausi_flt,0x0xF00049  InitGroup2Sma660Plausi
				'GP3_SMA760M_U8'               => 'Dem_AllEventsStatusByte(48)_U8',  ## 48,rb_csem_InitGroup3Sma660Main_flt,0x0xF00049  InitGroup3Sma660Main
				'GP3_SMA760P_U8'               => 'Dem_AllEventsStatusByte(49)_U8',  ## 49,rb_csem_InitGroup3Sma660Plausi_flt,0x0xF00049  InitGroup3Sma660Plausi
				'GP4_SMA760M_U8'               => 'Dem_AllEventsStatusByte(50)_U8',  ## 50,rb_csem_InitGroup4Sma660Main_flt,0x0xF00049  InitGroup4Sma660Main
				'GP4_SMA760P_U8'               => 'Dem_AllEventsStatusByte(51)_U8',  ## 51,rb_csem_InitGroup4Sma660Plausi_flt,0x0xF00049  InitGroup4Sma660Plausi
				'CyclRTMon_SMA760M_U8'         => 'Dem_AllEventsStatusByte(41)_U8',  ## 41,rb_csem_CyclRTMonSma660Main_flt,0x0xF00049  CyclRTMonSma660Main
				'CyclRTMon_SMA760P_U8'         => 'Dem_AllEventsStatusByte(42)_U8',  ## 42,rb_csem_CyclRTMonSma660Plausi_flt,0x0xF00049  CyclRTMonSma660Plausi
######################### SMB470 Variables #####################################################			
				'Group1_fltStatus_U8' => 'Dem_AllEventsStatusByte(139)_U8', ## 139,rb_csem_InitGroup1Smb470_flt,A00000  InitGroup1Smb470
				'Group2_fltStatus_U8' => 'Dem_AllEventsStatusByte(143)_U8', ## 143,rb_csem_InitGroup2Smb470_flt,A00000  InitGroup2Smb470 ##
				'Group3_fltStatus_U8' => 'Dem_AllEventsStatusByte(147)_U8', ## 147,rb_csem_InitGroup3Smb470_flt,A00000  InitGroup3Smb470 ##



# SMI7xx_YawSensor    
##              RawData
                'YawRateLfChl_RawData_U16'   		=> 'rb_cs7c_RtComRxPayload_au16(7)_U16',                                            
                'AccXLgChl_RawData_U16'   			=> 'rb_cs7c_RtComRxPayload_au16(0)_U16',  # ACC2_LF
                'AccYLgChl_RawData_U16'   			=> 'rb_cs7c_RtComRxPayload_au16(2)_U16',  # ACC1_LF
                'AccXHgMonChl_RawData_U16'   	    => 'rb_cs7c_RtComRxPayload_au16(1)_U16',
                'YawRateLfChl_RawData_U8'   		=> 'rb_cs7c_RtComRxPayload_au16(7)_U8',                                            
                'AccXLgChl_RawData_U8'   			=> 'rb_cs7c_RtComRxPayload_au16(0)_U8',
                'AccYLgChl_RawData_U8'   			=> 'rb_cs7c_RtComRxPayload_au16(2)_U8',
                'AccXHgMonChl_RawData_U8'   	    => 'rb_cs7c_RtComRxPayload_au16(1)_U8',
##              NhtsaData
                'YawRateLfChl_NhtsaData_S16'        => 'rb_csem_SensorDataRT_st.ChannelValue_as16(11)_S16', 
                'AccXLgChl_NhtsaData_S16'   		=> 'rb_csem_SensorDataRT_st.ChannelValue_as16(4)_S16',
                'AccYLgChl_NhtsaData_S16'   		=> 'rb_csem_SensorDataRT_st.ChannelValue_as16(6)_S16',
                'AccXHgMonChl_NhtsaData_S16'   	    => 'rb_csem_SensorDataRT_st.ChannelValue_as16(5)_S16',
##              check API to Customer
                'YawRateLfChl_ChlState_U8'          => 'rb_cs7m_ChlState_aen(7)_U8',
                'AccXLgChl_State_U8'                => 'rb_cs7m_ChlState_aen(0)_U8',
                'AccYLgChl_State_U8'                => 'rb_cs7m_ChlState_aen(2)_U8',               
                'AccXHgMonChl_State_U8'             => 'rb_cs7m_ChlState_aen(1)_U8',               
##               MonPermInit_YawSensor
                'MonPermInitYawSensor_fltStatus_U8' => 'Dem_AllEventsStatusByte(67)_U8',
##               MonPermBG_YawSensor
                'MonPermBGYawSensor_fltStatus_U8'   => 'Dem_AllEventsStatusByte(63)_U8',
##               MonTemp_YawRate_Channel
                'MonTempYawRateLfChl_fltStatus_U8'  => 'Dem_AllEventsStatusByte(80)_U8',
                'MonTempAccXLgChl_fltStatus_U8'     => 'Dem_AllEventsStatusByte(73)_U8',
                'MonTempAccYLgChl_fltStatus_U8'     => 'Dem_AllEventsStatusByte(75)_U8',
                'MonTempAccXHgMonChl_fltStatus_U8'  => 'Dem_AllEventsStatusByte(72)_U8',
##               MonPerm_YawRate_Channel
                'MonPermYawRateLfChl_fltStatus_U8'  => 'Dem_AllEventsStatusByte(70)_U8',
                'MonPermAccXLgChl_fltStatus_U8'     => 'Dem_AllEventsStatusByte(55)_U8',
                'MonPermAccYLgChl_fltStatus_U8'     => 'Dem_AllEventsStatusByte(57)_U8',
                'MonPermAccXHgMonChl_fltStatus_U8'  => 'Dem_AllEventsStatusByte(54)_U8',
#                check Temp1
                'YawSensor_Temp1_S16'                 => 'rb_cs7c_StatusData_ast(0).Temperature1_s16_S16',
               
#             
# SMI7xx_RollSensor
##              RawData
				'RollRateLfChl_RawData_U16'     	=> 'rb_cs7c_RtComRxPayload_au16(6)_U16',
				'AccZLgChl_RawData_U16'   			=> 'rb_cs7c_RtComRxPayload_au16(5)_U16',
				'RollRateLfChl_RawData_U8'   		=> 'rb_cs7c_RtComRxPayload_au16(6)_U8',
				'AccZLgChl_RawData_U8'   			=> 'rb_cs7c_RtComRxPayload_au16(5)_U8',
##              NhtsaData
				'RollRateLfChl_NhtsaData_S16'       => 'rb_csem_SensorDataRT_st.ChannelValue_as16(10)_S16',
				'AccZLgChl_NhtsaData_S16'           => 'rb_csem_SensorDataRT_st.ChannelValue_as16(9)_S16',
##              check API to Customer
                'RollRateLfChl_State_U8'            => 'rb_cs7m_ChlState_aen(6)_U8',
                'AccZLgChl_State_U8'                => 'rb_cs7m_ChlState_aen(5)_U8',               
##              MonPermInit_RollSensor 
                'MonPermInitRollSensor_fltStatus_U8'  => 'Dem_AllEventsStatusByte(65)_U8',
##              MonPermBG_RollSensor
                'MonPermBGRollSensor_fltStatus_U8'    => 'Dem_AllEventsStatusByte(61)_U8',
##              MonTemp_RollRate_Channel  
                'MonTempRollRateLfChl_fltStatus_U8'   => 'Dem_AllEventsStatusByte(79)_U8',
                'MonTempAccZLgChl_fltStatus_U8'       => 'Dem_AllEventsStatusByte(77)_U8',
##              MonPerm_RollRate_Channel  
                'MonPermRollRateLfChl_fltStatus_U8'   => 'Dem_AllEventsStatusByte(69)_U8',
                'MonPermAccZLgChl_fltStatus_U8'       => 'Dem_AllEventsStatusByte(59)_U8',
#               check Temp1
               'RollSensor_Temp1_S16'                 => 'rb_cs7c_StatusData_ast(2).Temperature1_s16_S16',   
#                
# SMI7 and SMA660
#               check API to Algo
				'AlgoDataValid_b32.0'   	=> 'rb_csem_SensorDataRT_st.DataValid_b32_U8',
				'AlgoDataValid_b32.1'   	=> 'rb_csem_SensorDataRT_st.DataValid_b32.1_U8',
#               check Data Overload
                'InertDataOverload_b32.0'   => 'rb_csem_SensorDataRT_st.InertDataOverload_b32_U8',
                'InertDataOverload_b32.1'   => 'rb_csem_SensorDataRT_st.InertDataOverload_b32.1_U8',

# SWM				
				'adcData_BLRC_U16'                 	=> 'rb_swma_AsicChannelData_ast(2).Value10Bit_u16_U16',   
				'shortLineFltStatus_BLRC_U8'		=> 'Dem_AllEventsStatusByte(666)_U8',
				'undefinedFltStatus_BLRC_U8'		=> 'Dem_AllEventsStatusByte(682)_U8',
				'openlineFltStatus_BLRC_U8'			=> 'Dem_AllEventsStatusByte(633)_U8',
				'switchPosition_BLRC'				=> 'rb_swm_SwitchInfo_ast(6).PositionFiltered_en_U8',
				'switchStatus_BLRC'					=> 'rb_swm_SwitchInfo_ast(6).StatusFiltered_en_U8',
				
				'adcData_SPSFP_U16'                 => 'rb_swma_AsicChannelData_ast(6).Value10Bit_u16_U16',   
				'shortLineFltStatus_SPSFP_U8'		=> 'Dem_AllEventsStatusByte(626)_U8',
				'undefinedFltStatus_SPSFP_U8'		=> 'Dem_AllEventsStatusByte(641)_U8',
				'openlineFltStatus_SPSFP_U8'		=> 'Dem_AllEventsStatusByte(595)_U8',
				'switchPosition_SPSFP'				=> 'rb_swm_SwitchInfo_ast(8).PositionFiltered_en_U8',
				'switchStatus_SPSFP'				=> 'rb_swm_SwitchInfo_ast(8).StatusFiltered_en_U8',
				
				'adcData_AB1FD_U16'                 => 'rb_sqmm_ResistanceValue_au16(4)_U16',   
				'shortLineFltStatus_AB1FD_U8'		=> 'Dem_AllEventsStatusByte(465)_U8',
                
                # SMI7 and SMA660
#               check API to Algo
				'AlgoDataValid_U32'            => 'rb_csem_SensorDataRT_st.DataValid_b32',
# SMI7                                              #---LB---***HB***
#			    'All_AlgoData_Valid'	       => '330--?----xxxx?--xxxxxxxxxxxxxxxxx',
				'All_AlgoData_Valid'	       => '3301101111000001100000000000000000',
#               'AccYLg_AlgoData_NotValid'     => '330-101111000001100000000000000000', AccYLg    - ACC1_LF    flt_int=2ms  
                'AccYLgChl_AlgoData_NotValid'     => '3300101111000001100000000000000000',
#               'AccXHgMon_AlgoData_NotValid'     => '3301-01111000001100000000000000000', AccXHgMon - ACC2_HF    flt_int=0ms
                'AccXHgMonChl_AlgoData_NotValid'  => '3301001111000001100000000000000000',
#       	    'AccXLg_AlgoData_NotValid'     => '33011?1111000001100000000000000000', **AccXLg    - ACC2_LF    flt_int=18ms ACC2
#
				'AccXLgChl_AlgoData_NotValid'     => '3301101111000001100000000000000000',
#				'YawRateLf_AlgoData_NotValid'  => '33011011110000?1100000000000000000', **YawRateLf  - RATE_LF   flt_int=18ms
                'YawRateLfChl_AlgoData_NotValid'  => '3301101111000001100000000000000000',
#				'RollRateLf_AlgoData_NotValid' => '3301101111.00000-10.0000000000000000', RollRateLf - RATE_LF   flt_int=2ms
				'RollRateLfChl_AlgoData_NotValid' => '3301101111000000100000000000000000',
#               'AccZLg_AlgoData_NotValid'     => '3301101111000001-00000000000000000', AccZLg     - ACC2_LF   flt_int=2ms
                'AccZLgChl_AlgoData_NotValid'     => '3301101111000001000000000000000000',
#                                                                                      ** - disabled for Algo
#              check API to Customer
               'YawRateLfChl_State_U8'      => 'rb_cs7m_ChlState_aen(7)',                              
               'AccXLgChl_State_U8'         => 'rb_cs7m_ChlState_aen(0)',
               'AccYLgChl_State_U8'         => 'rb_cs7m_ChlState_aen(2)',               
               'AccXHgMonChl_State_U8'      => 'rb_cs7m_ChlState_aen(1)',               
               'RollRateLfChl_State_U8'     => 'rb_cs7m_ChlState_aen(6)',               
               'AccZLgChl_State_U8'         => 'rb_cs7m_ChlState_aen(5)',               
#               AsicDeviceId
                'YawSensor_AsicDeviceId_U16'    => 'rb_syca_AsicDeviceId_au16(4)',
                'RollSensor_AsicDeviceId_U16'   => 'rb_syca_AsicDeviceId_au16(6)',
#               AsicRevisionId
                'YawSensor_AsicRevisionId_U16'  => 'rb_syca_AsicRevisionId_au16(4)',
                'RollSensor_AsicRevisionId_U16' => 'rb_syca_AsicRevisionId_au16(6)',
#               AsicSerialNr
                'YawSensor_AsicSerialNr0_U16'   => 'rb_cs7m_AsicIdData_ast(0).AsicSerialNr_au16(0)',
                'YawSensor_AsicSerialNr1_U16'   => 'rb_cs7m_AsicIdData_ast(0).AsicSerialNr_au16(1)',
                'YawSensor_AsicSerialNr2_U16'   => 'rb_cs7m_AsicIdData_ast(0).AsicSerialNr_au16(2)',
                'RollSensor_AsicSerialNr0_U16'  => 'rb_cs7m_AsicIdData_ast(2).AsicSerialNr_au16(0)',
                'RollSensor_AsicSerialNr1_U16'  => 'rb_cs7m_AsicIdData_ast(2).AsicSerialNr_au16(1)',
                'RollSensor_AsicSerialNr2_U16'  => 'rb_cs7m_AsicIdData_ast(2).AsicSerialNr_au16(2)',
#                SmiSerialNr
                'YawSensor_SmiSerialNr0_U16'    => 'rb_cs7m_AsicIdData_ast(0).SmiSerialNr_au16(0)',
                'YawSensor_SmiSerialNr1_U16'    => 'rb_cs7m_AsicIdData_ast(0).SmiSerialNr_au16(1)',
                'YawSensor_SmiSerialNr2_U16'    => 'rb_cs7m_AsicIdData_ast(0).SmiSerialNr_au16(2)',
                'RollSensor_SmiSerialNr0_U16'   => 'rb_cs7m_AsicIdData_ast(2).SmiSerialNr_au16(0)',
                'RollSensor_SmiSerialNr1_U16'   => 'rb_cs7m_AsicIdData_ast(2).SmiSerialNr_au16(1)',
                'RollSensor_SmiSerialNr2_U16'   => 'rb_cs7m_AsicIdData_ast(2).SmiSerialNr_au16(2)',
#               check Temp1
                'YawSensor_Temp1_U16'   => 'rb_cs7c_TemperatureData_au16(0)',                              
                'RollSensor_Temp1_U16'  => 'rb_cs7c_TemperatureData_au16(2)',
				
				'switchPosition_BLRC'	=> 'rb_swm_SwitchInfo_ast(6).PositionFiltered_en',
				'switchStatus_BLRC'		=> 'rb_swm_SwitchInfo_ast(6).StatusFiltered_en',
				
				'switchPosition_SPSFP'	=> 'rb_swm_SwitchInfo_ast(8).PositionFiltered_en',
				'switchStatus_SPSFP'		=> 'rb_swm_SwitchInfo_ast(8).StatusFiltered_en',
    };

#***************************************************************************************
$Defaults->{'MNT_CONST_MAP'} = {
#***************************************************************************************
# SMI7 and SMA660
#               check API to Algo
				'AlgoDataValid_U32'            => 'rb_csem_SensorDataRT_st.DataValid_b32',
# SMI7                                              #---LB---***HB***
#			    'All_AlgoData_Valid'	       => '330--?----xxxx?--xxxxxxxxxxxxxxxxx',
				'All_AlgoData_Valid'	       => '3301101111000001100000000000000000',
#               'AccYLg_AlgoData_NotValid'     => '330-101111000001100000000000000000', AccYLg    - ACC1_LF    flt_int=2ms
                'AccYLgChl_AlgoData_NotValid'     => '3300101111000001100000000000000000',
#               'AccXHgMon_AlgoData_NotValid'     => '3301-01111000001100000000000000000', AccXHgMon - ACC2_HF    flt_int=0ms
                'AccXHgMonChl_AlgoData_NotValid'  => '3301001111000001100000000000000000',
#       	    'AccXLg_AlgoData_NotValid'     => '33011?1111000001100000000000000000', **AccXLg    - ACC2_LF    flt_int=18ms ACC2
#
				'AccXLgChl_AlgoData_NotValid'     => '3301101111000001100000000000000000',
#				'YawRateLf_AlgoData_NotValid'  => '33011011110000?1100000000000000000', **YawRateLf  - RATE_LF   flt_int=18ms
                'YawRateLfChl_AlgoData_NotValid'  => '3301101111000001100000000000000000',
#				'RollRateLf_AlgoData_NotValid' => '3301101111.00000-10.0000000000000000', RollRateLf - RATE_LF   flt_int=2ms
				'RollRateLfChl_AlgoData_NotValid' => '3301101111000000100000000000000000',
#               'AccZLg_AlgoData_NotValid'     => '3301101111000001-00000000000000000', AccZLg     - ACC2_LF   flt_int=2ms
                'AccZLgChl_AlgoData_NotValid'     => '3301101111000001000000000000000000',
#                                                                                      ** - disabled for Algo
#              check API to Customer
               'YawRateLfChl_State_U8'      => 'rb_cs7m_ChlState_aen(7)',
               'AccXLgChl_State_U8'         => 'rb_cs7m_ChlState_aen(0)',
               'AccYLgChl_State_U8'         => 'rb_cs7m_ChlState_aen(2)',
               'AccXHgMonChl_State_U8'      => 'rb_cs7m_ChlState_aen(1)',
               'RollRateLfChl_State_U8'     => 'rb_cs7m_ChlState_aen(6)',
               'AccZLgChl_State_U8'         => 'rb_cs7m_ChlState_aen(5)',
#               AsicDeviceId
                'YawSensor_AsicDeviceId_U16'    => 'rb_syca_AsicDeviceId_au16(4)',
                'RollSensor_AsicDeviceId_U16'   => 'rb_syca_AsicDeviceId_au16(6)',
#               AsicRevisionId
                'YawSensor_AsicRevisionId_U16'  => 'rb_syca_AsicRevisionId_au16(4)',
                'RollSensor_AsicRevisionId_U16' => 'rb_syca_AsicRevisionId_au16(6)',
#               AsicSerialNr
                'YawSensor_AsicSerialNr0_U16'   => 'rb_cs7m_AsicIdData_ast(0).AsicSerialNr_au16(0)',
                'YawSensor_AsicSerialNr1_U16'   => 'rb_cs7m_AsicIdData_ast(0).AsicSerialNr_au16(1)',
                'YawSensor_AsicSerialNr2_U16'   => 'rb_cs7m_AsicIdData_ast(0).AsicSerialNr_au16(2)',
                'RollSensor_AsicSerialNr0_U16'  => 'rb_cs7m_AsicIdData_ast(2).AsicSerialNr_au16(0)',
                'RollSensor_AsicSerialNr1_U16'  => 'rb_cs7m_AsicIdData_ast(2).AsicSerialNr_au16(1)',
                'RollSensor_AsicSerialNr2_U16'  => 'rb_cs7m_AsicIdData_ast(2).AsicSerialNr_au16(2)',
#                SmiSerialNr
                'YawSensor_SmiSerialNr0_U16'    => 'rb_cs7m_AsicIdData_ast(0).SmiSerialNr_au16(0)',
                'YawSensor_SmiSerialNr1_U16'    => 'rb_cs7m_AsicIdData_ast(0).SmiSerialNr_au16(1)',
                'YawSensor_SmiSerialNr2_U16'    => 'rb_cs7m_AsicIdData_ast(0).SmiSerialNr_au16(2)',
                'RollSensor_SmiSerialNr0_U16'   => 'rb_cs7m_AsicIdData_ast(2).SmiSerialNr_au16(0)',
                'RollSensor_SmiSerialNr1_U16'   => 'rb_cs7m_AsicIdData_ast(2).SmiSerialNr_au16(1)',
                'RollSensor_SmiSerialNr2_U16'   => 'rb_cs7m_AsicIdData_ast(2).SmiSerialNr_au16(2)',
#               check Temp1
                'YawSensor_Temp1_U16'   => 'rb_cs7c_TemperatureData_au16(0)',
                'RollSensor_Temp1_U16'  => 'rb_cs7c_TemperatureData_au16(2)',

				'switchPosition_BLRC'	=> 'rb_swm_SwitchInfo_ast(6).PositionFiltered_en',
				'switchStatus_BLRC'		=> 'rb_swm_SwitchInfo_ast(6).StatusFiltered_en',

				'switchPosition_SPSFP'	=> 'rb_swm_SwitchInfo_ast(8).PositionFiltered_en',
				'switchStatus_SPSFP'		=> 'rb_swm_SwitchInfo_ast(8).StatusFiltered_en',
    };

#***************************************************************************************
$Defaults->{'TC_MANITOO_MAP'} = {
#***************************************************************************************
    #
    #  SMA660 SECTION

				'rb_syc_AsicIdMismatch_flt'					=> '0xF00049', # 703,rb_syc_AsicIdMismatch_flt,0xF00049  AsicIdMismatch
				'rb_csem_InitGroup1SmaMain_flt'			=> '0xF00049', # 44,rb_csem_InitGroup1Sma660Main_flt,0xF00049  InitGroup1Sma660Main
				'rb_csem_InitGroup1SmaPlausi_flt'		=> '0xF00049', # 45,rb_csem_InitGroup1Sma660Plausi_flt,0xF00049  InitGroup1Sma660Plausi
				'rb_csem_InitGroup2SmaMain_flt'			=> '0xF00049', # 46,rb_csem_InitGroup2Sma660Main_flt,0xF00049  InitGroup2Sma660Main
				'rb_csem_InitGroup2SmaPlausi_flt'		=> '0xF00049', # 47,rb_csem_InitGroup2Sma660Plausi_flt,0xF00049  InitGroup2Sma660Plausi
				'rb_csem_InitGroup3SmaMain_flt'		    => '0xF00049', # 48,rb_csem_InitGroup3Sma660Main_flt,0xF00049  InitGroup3Sma660Main
				'rb_csem_InitGroup3SmaPlausi_flt'		=> '0xF00049', # 49,rb_csem_InitGroup3Sma660Plausi_flt,0xF00049  InitGroup3Sma660Plausi
				'rb_csem_InitGroup4SmaMain_flt'			=> '0xF00049', # 50,rb_csem_InitGroup4Sma660Main_flt,0x0xF00049  InitGroup4Sma660Main
				'rb_csem_InitGroup4SmaPlausi_flt'		=> '0xF00049', # 51,rb_csem_InitGroup4Sma660Plausi_flt,0x0xF00049  InitGroup4Sma660Plausi
				'rb_csem_CyclRTMonSmaMain_flt'			=> '0xF00049',
				'rb_csem_CyclRTMonSmaPlausi_flt'			=> '0xF00049',
				'rb_spi_SpiRcvMsgCrcWrong_flt'			    => '0xF00049',
    #
    #  SMA660 SECTION
    #

    #
    #  SMB470 SECTION

				# 'rb_syc_AsicIdMismatch_flt'					=> 'A00000',
				# 'rb_csem_InitGroup1Smb470_flt'				=> 'A00000',
				# 'rb_csem_InitGroup2Smb470_flt'				=> 'A00000',
				# 'rb_csem_InitGroup3Smb470_flt'				=> 'A00000',
    #
    #  SMB470 SECTION
    #
};
# Definitions for module TC_CSEM_SMI7
# ------------------------------------
#-1*****************************************************************************
#!!!!Achtung: little endian ====> Ausgabe in LIFT auch little endian!!!!!!
#'AlgoDataValid_b32' => 'rb_csem_SensorDataRT_st.DataValid_b32',
#-1 Byte_1
#-enum;rb_sycc_CentralSensorChannels_ten;rb_sycc_MainAccM45_e;0;   Bit_0
#-enum;rb_sycc_CentralSensorChannels_ten;rb_sycc_MainAccP45_e;1;
#-enum;rb_sycc_CentralSensorChannels_ten;rb_sycc_PlausiAccM45_e;2;
#-enum;rb_sycc_CentralSensorChannels_ten;rb_sycc_PlausiAccP45_e;3;

#?enum;rb_sycc_CentralSensorChannels_ten;rb_sycc_AccXLg_e;4;  => nicht g�ltig f�r Algo?
#-enum;rb_sycc_CentralSensorChannels_ten;rb_sycc_AccXHgMon_e;5;
#-enum;rb_sycc_CentralSensorChannels_ten;rb_sycc_AccYLg_e;6;
#enum;rb_sycc_CentralSensorChannels_ten;rb_sycc_AccYHgMon_e;7;    Bit_7
#'AlgoDataValid_b32'.1 => 'rb_csem_SensorDataRT_st.DataValid_b32',
#    Byte_2
#enum;rb_sycc_CentralSensorChannels_ten;rb_sycc_AccYLgPlausi_e;8; Bit_0
#-enum;rb_sycc_CentralSensorChannels_ten;rb_sycc_AccZLg_e;9;
#-enum;rb_sycc_CentralSensorChannels_ten;rb_sycc_RollRateLf_e;10;
#?enum;rb_sycc_CentralSensorChannels_ten;rb_sycc_YawRateLf_e;11; => nicht g�ltig f�r Algo?
#enum;rb_sycc_CentralSensorChannels_ten;rb_sycc_YawRateLfPlausi_e;12;
#enum;rb_sycc_CentralSensorChannels_ten;rb_sycc_PitchRateLf_e;13; Bit_5

#enum;rb_sycc_CentralSensorChannels_ten;rb_sycc_CentralSensorChannelsMax_e;14;

#-1 API to Algo invalid
#rb_csem_SensorDataRT_st.DataValid_b32,FEDFABD4,PDI for sensor channel data which contains the data for each sensor channel itself and some.Flags if sensor channel data is valid,,,,,,,,,
#rb_csem_SensorDataRT_st.DataValid_b32.1,FEDFABD5,PDI for sensor channel data which contains the data for each sensor channel itself and some.Flags if sensor channel data is valid,,,,,,,,,
#rb_csem_SensorDataRT_st.DataValid_b32.2,FEDFABD6,PDI for sensor channel data which contains the data for each sensor channel itself and some.Flags if sensor channel data is valid,,,,,,,,,
#rb_csem_SensorDataRT_st.DataValid_b32.3,FEDFABD7,PDI for sensor channel data which contains the data for each sensor channel itself and some.Flags if sensor channel data is valid,,,,,,,,,

#-1
#rb_csem_SensorDataRT_st.InertDataOverload_b32,FEDFABD8,PDI for sensor channel data which contains the data for each sensor channel itself and some.Flags if sensor channel data is in mechanical overload for the inertial sensors only (e.g.,,,,,,,,,
#rb_csem_SensorDataRT_st.InertDataOverload_b32.1,FEDFABD9,PDI for sensor channel data which contains the data for each sensor channel itself and some.Flags if sensor channel data is in mechanical overload for the inertial sensors only (e.g.,,,,,,,,,
#rb_csem_SensorDataRT_st.InertDataOverload_b32.2,FEDFABDA,PDI for sensor channel data which contains the data for each sensor channel itself and some.Flags if sensor channel data is in mechanical overload for the inertial sensors only (e.g.,,,,,,,,,
#rb_csem_SensorDataRT_st.InertDataOverload_b32.3,FEDFABDB,PDI for sensor channel data which contains the data for each sensor channel itself and some.Flags if sensor channel data is in mechanical overload for the inertial sensors only (e.g.,,,,,,,,,

#define RB_siam_CsXchannelMask_cu16				((uint16)(((uint16)1u) << RB_siam_CsXchannelLoc_cu8))
#define RB_siam_CsYchannelMask_cu16				((uint16)(((uint16)1u) << RB_siam_CsYchannelLoc_cu8))
#define RB_siam_CsXrdchannelMask_cu16			((uint16)(((uint16)1u) << RB_siam_CsXrdchannelLoc_cu8))
#define RB_siam_CsYrdchannelMask_cu16			((uint16)(((uint16)1u) << RB_siam_CsYrdchannelLoc_cu8))
#define RB_siam_CsHighgXMonchannelMask_cu16		((uint16)(((uint16)1u) << RB_siam_CsHighgXMonchannelLoc_cu8))
#define RB_siam_CsLowgXchannelMask_cu16   		((uint16)(((uint16)1u) << RB_siam_CsLowgXchannelLoc_cu8))
#define RB_siam_CsLowgYchannelMask_cu16   		((uint16)(((uint16)1u) << RB_siam_CsLowgYchannelLoc_cu8))
#define RB_siam_CsLowgZchannelMask_cu16   		((uint16)(((uint16)1u) << RB_siam_CsLowgZchannelLoc_cu8))
#define RB_siam_CsRollchannelMask_cu16    		((uint16)(((uint16)1u) << RB_siam_CsRollchannelLoc_cu8))
#define RB_siam_CsYawchannelMask_cu16     		((uint16)(((uint16)1u) << RB_siam_CsYawchannelLoc_cu8))
#define RB_siam_CsPitchchannelMask_cu16   		((uint16)(((uint16)1u) << RB_siam_CsPitchchannelLoc_cu8))

#rb_csem_SensorDataRT_st.ChannelValue_as16(0),FEDFABB8,PDI for sensor channel data which contains the data for each sensor channel itself and some.Pre-processed sensor channel data,,,,,,,,,
#rb_csem_SensorDataRT_st.ChannelValue_as16(0).1,FEDFABB9,PDI for sensor channel data which contains the data for each sensor channel itself and some.Pre-processed sensor channel data,,,,,,,,,
#rb_csem_SensorDataRT_st.ChannelValue_as16(1),FEDFABBA,PDI for sensor channel data which contains the data for each sensor channel itself and some.Pre-processed sensor channel data,,,,,,,,,
#rb_csem_SensorDataRT_st.ChannelValue_as16(1).1,FEDFABBB,PDI for sensor channel data which contains the data for each sensor channel itself and some.Pre-processed sensor channel data,,,,,,,,,
#rb_csem_SensorDataRT_st.ChannelValue_as16(10),FEDFABCC,PDI for sensor channel data which contains the data for each sensor channel itself and some.Pre-processed sensor channel data,,,,,,,,,
#rb_csem_SensorDataRT_st.ChannelValue_as16(10).1,FEDFABCD,PDI for sensor channel data which contains the data for each sensor channel itself and some.Pre-processed sensor channel data,,,,,,,,,
#rb_csem_SensorDataRT_st.ChannelValue_as16(11),FEDFABCE,PDI for sensor channel data which contains the data for each sensor channel itself and some.Pre-processed sensor channel data,,,,,,,,,
#rb_csem_SensorDataRT_st.ChannelValue_as16(11).1,FEDFABCF,PDI for sensor channel data which contains the data for each sensor channel itself and some.Pre-processed sensor channel data,,,,,,,,,
#rb_csem_SensorDataRT_st.ChannelValue_as16(12),FEDFABD0,PDI for sensor channel data which contains the data for each sensor channel itself and some.Pre-processed sensor channel data,,,,,,,,,
#rb_csem_SensorDataRT_st.ChannelValue_as16(12).1,FEDFABD1,PDI for sensor channel data which contains the data for each sensor channel itself and some.Pre-processed sensor channel data,,,,,,,,,
#rb_csem_SensorDataRT_st.ChannelValue_as16(13),FEDFABD2,PDI for sensor channel data which contains the data for each sensor channel itself and some.Pre-processed sensor channel data,,,,,,,,,
#rb_csem_SensorDataRT_st.ChannelValue_as16(13).1,FEDFABD3,PDI for sensor channel data which contains the data for each sensor channel itself and some.Pre-processed sensor channel data,,,,,,,,,
#rb_csem_SensorDataRT_st.ChannelValue_as16(2),FEDFABBC,PDI for sensor channel data which contains the data for each sensor channel itself and some.Pre-processed sensor channel data,,,,,,,,,
#rb_csem_SensorDataRT_st.ChannelValue_as16(2).1,FEDFABBD,PDI for sensor channel data which contains the data for each sensor channel itself and some.Pre-processed sensor channel data,,,,,,,,,
#rb_csem_SensorDataRT_st.ChannelValue_as16(3),FEDFABBE,PDI for sensor channel data which contains the data for each sensor channel itself and some.Pre-processed sensor channel data,,,,,,,,,
#rb_csem_SensorDataRT_st.ChannelValue_as16(3).1,FEDFABBF,PDI for sensor channel data which contains the data for each sensor channel itself and some.Pre-processed sensor channel data,,,,,,,,,
#rb_csem_SensorDataRT_st.ChannelValue_as16(4),FEDFABC0,PDI for sensor channel data which contains the data for each sensor channel itself and some.Pre-processed sensor channel data,,,,,,,,,
#rb_csem_SensorDataRT_st.ChannelValue_as16(4).1,FEDFABC1,PDI for sensor channel data which contains the data for each sensor channel itself and some.Pre-processed sensor channel data,,,,,,,,,
#rb_csem_SensorDataRT_st.ChannelValue_as16(5),FEDFABC2,PDI for sensor channel data which contains the data for each sensor channel itself and some.Pre-processed sensor channel data,,,,,,,,,
#rb_csem_SensorDataRT_st.ChannelValue_as16(5).1,FEDFABC3,PDI for sensor channel data which contains the data for each sensor channel itself and some.Pre-processed sensor channel data,,,,,,,,,
#rb_csem_SensorDataRT_st.ChannelValue_as16(6),FEDFABC4,PDI for sensor channel data which contains the data for each sensor channel itself and some.Pre-processed sensor channel data,,,,,,,,,
#rb_csem_SensorDataRT_st.ChannelValue_as16(6).1,FEDFABC5,PDI for sensor channel data which contains the data for each sensor channel itself and some.Pre-processed sensor channel data,,,,,,,,,
#rb_csem_SensorDataRT_st.ChannelValue_as16(7),FEDFABC6,PDI for sensor channel data which contains the data for each sensor channel itself and some.Pre-processed sensor channel data,,,,,,,,,
#rb_csem_SensorDataRT_st.ChannelValue_as16(7).1,FEDFABC7,PDI for sensor channel data which contains the data for each sensor channel itself and some.Pre-processed sensor channel data,,,,,,,,,
#rb_csem_SensorDataRT_st.ChannelValue_as16(8),FEDFABC8,PDI for sensor channel data which contains the data for each sensor channel itself and some.Pre-processed sensor channel data,,,,,,,,,
#rb_csem_SensorDataRT_st.ChannelValue_as16(8).1,FEDFABC9,PDI for sensor channel data which contains the data for each sensor channel itself and some.Pre-processed sensor channel data,,,,,,,,,
#rb_csem_SensorDataRT_st.ChannelValue_as16(9),FEDFABCA,PDI for sensor channel data which contains the data for each sensor channel itself and some.Pre-processed sensor channel data,,,,,,,,,
#rb_csem_SensorDataRT_st.ChannelValue_as16(9).1,FEDFABCB,PDI for sensor channel data which contains the data for each sensor channel itself and some.Pre-processed sensor channel data,,,,,,,,,
#-1*****************************************************************************

#-2*****************************************************************************
#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_AccXLg_e;          0;
#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_AccXHgMon_e;       1;
#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_AccYLg_e;          2;
#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_AccYHgMon_e;       3;
#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_AccYLgPlausi_e;    4;
#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_AccZLg_e;          5;
#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_RollRateLf_e;      6;
#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_YawRateLf_e;       7;
#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_YawRateLfPlausi_e; 8;
#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_PitchRateLf_e;     9;

#-2 API to Customer invalid
#rb_cs7m_ChlState_aen(0),FEDFAB24,Current state of each SMI7 channel
#rb_cs7m_ChlState_aen(1),FEDFAB25,Current state of each SMI7 channel
#rb_cs7m_ChlState_aen(2),FEDFAB26,Current state of each SMI7 channel
#rb_cs7m_ChlState_aen(3),FEDFAB27,Current state of each SMI7 channel
#rb_cs7m_ChlState_aen(4),FEDFAB28,Current state of each SMI7 channel
#rb_cs7m_ChlState_aen(5),FEDFAB29,Current state of each SMI7 channel
#rb_cs7m_ChlState_aen(6),FEDFAB2A,Current state of each SMI7 channel
#rb_cs7m_ChlState_aen(7),FEDFAB2B,Current state of each SMI7 channel
#rb_cs7m_ChlState_aen(8),FEDFAB2C,Current state of each SMI7 channel
#rb_cs7m_ChlState_aen(9),FEDFAB2D,Current state of each SMI7 channel

#enum;rb_csem_ChannelState_ten;rb_csem_ChlInitInProgress_e;          0;Channel initialization in progress
#enum;rb_csem_ChannelState_ten;rb_csem_ChlNotConfigured_e;           1;Channel not configured
#enum;rb_csem_ChannelState_ten;rb_csem_ChlOk_e;                      2;Channel OK
#enum;rb_csem_ChannelState_ten;rb_csem_ChlTemporaryError_e;          3;Channel temporary error (out of spec)
#enum;rb_csem_ChannelState_ten;rb_csem_ChlPermErrorDueSensorErr_e;   4;Channel permanent error (sensor perm flt)
#enum;rb_csem_ChannelState_ten;rb_csem_ChlPermErrorCyclThisPOC_e;    5;Channel permanent error (cyclic this POC)
#enum;rb_csem_ChannelState_ten;rb_csem_ChlPermErrorCyclPrevPOC_e;    6;Channel permanent error (cyclic prev POC)
#enum;rb_csem_ChannelState_ten;rb_csem_ChlPermErrorDueExtReq_e;      7;Channel permanent error (external request  e.g. ASI)
#enum;rb_csem_ChannelState_ten;rb_csem_ChlNotSupported_e;            8;Channel is not supported
#-2*****************************************************************************

#-3*****************************************************************************
#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_AccXLg_e;0;
#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_AccXHgMon_e;1;
#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_AccYLg_e;2;
#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_AccYHgMon_e;3;
#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_AccYLgPlausi_e;4;
#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_AccZLg_e;5;
#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_RollRateLf_e;6;
#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_YawRateLf_e;7;
#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_YawRateLfPlausi_e;8;
#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_PitchRateLf_e;9;

#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_YawSensorStatusClusFlags_e;10;
#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_YawPlausiSensorStatusClusFlags_e;11;
#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_RollSensorStatusClusFlags_e;12;
#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_PitchSensorStatusClusFlags_e;13;

#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_YawSensorStatusHwScon_e;14;
#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_YawPlausiSensorStatusHwScon_e;15;
#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_RollSensorStatusHwScon_e;16;
#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_PitchSensorStatusHwScon_e;17;

#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_YawSensorIntErrCnt01_e;18;
#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_YawSensorIntErrCnt23_e;19;
#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_YawSensorIntErrCnt45_e;20;
#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_YawSensorIntErrCnt67_e;21;

#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_YawPlausiSensorIntErrCnt01_e;22;
#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_YawPlausiSensorIntErrCnt23_e;23;
#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_YawPlausiSensorIntErrCnt45_e;24;
#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_YawPlausiSensorIntErrCnt67_e;25;

#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_RollSensorIntErrCnt01_e;26;
#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_RollSensorIntErrCnt23_e;27;
#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_RollSensorIntErrCnt45_e;28;
#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_RollSensorIntErrCnt67_e;29;

#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_PitchSensorIntErrCnt01_e;30;
#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_PitchSensorIntErrCnt23_e;31;
#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_PitchSensorIntErrCnt45_e;32;
#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_PitchSensorIntErrCnt67_e;33;

#enum;rb_cs7c_AllPossibleRtCmdsTxReasons_ten;rb_cs7c_MaxPossibleRtCmdsTxReasons_e;34;

#/*! rb_cs7c_RtComRxPayload_au16:    Payload of the real-time communications */
#volatile uint16 rb_cs7c_RtComRxPayload_au16[rb_cs7c_MaxPossibleRtCmdsTxReasons_e];

#/*! rb_cs7c_RtComRxFaults_ab8:    Rx faults of the real-time communications */
#volatile uint8 rb_cs7c_RtComRxFaults_ab8[rb_cs7c_MaxPossibleRtCmdsTxReasons_e]; /*
#-3*****************************************************************************

#-4*****************************************************************************
#enum;rb_scm_SafetyChannelSettings_tst;rb_sycc_Smi7SensorYaw_e;0;
#enum;rb_scm_SafetyChannelSettings_tst;rb_sycc_Smi7SensorYawPlausi_e;1;
#enum;rb_scm_SafetyChannelSettings_tst;rb_sycc_Smi7SensorRoll_e;2;
#enum;rb_scm_SafetyChannelSettings_tst;rb_sycc_Smi7SensorPitch_e;3;
#enum;rb_scm_SafetyChannelSettings_tst;rb_sycc_Smi7SensorMax_e;4;

#rb_cs7c_TemperatureData_au16(0)
#rb_cs7c_TemperatureData_au16(0).1
#rb_cs7c_TemperatureData_au16(1)
#rb_cs7c_TemperatureData_au16(1).1
#rb_cs7c_TemperatureData_au16(2)
#rb_cs7c_TemperatureData_au16(2).1
#rb_cs7c_TemperatureData_au16(3),
#rb_cs7c_TemperatureData_au16(3).1
#-4*****************************************************************************

#-5*****************************************************************************
#rb_syca_AsicDeviceId_au16(4),FEDFD24C,4.0 ASIC Device ID read from ASIC via SPI (some AB12 devices use only the lower 8 bit).,,,,,,,,,
#rb_syca_AsicDeviceId_au16(4).1,FEDFD24D,4.1 ASIC Device ID read from ASIC via SPI (some AB12 devices use only the lower 8 bit).,,,,,,,,,
#-rb_syca_AsicDeviceId_au16(5),FEDFD24E,5.0 ASIC Device ID read from ASIC via SPI (some AB12 devices use only the lower 8 bit).,,,,,,,,,
#-rb_syca_AsicDeviceId_au16(5).1,FEDFD24F,5.1 ASIC Device ID read from ASIC via SPI (some AB12 devices use only the lower 8 bit).,,,,,,,,,
#rb_syca_AsicDeviceId_au16(6),FEDFD250,6.0 ASIC Device ID read from ASIC via SPI (some AB12 devices use only the lower 8 bit).,,,,,,,,,
#rb_syca_AsicDeviceId_au16(6).1,FEDFD251,6.1 ASIC Device ID read from ASIC via SPI (some AB12 devices use only the lower 8 bit).,,,,,,,,,
#-rb_syca_AsicDeviceId_au16(7),FEDFD252,7.0 ASIC Device ID read from ASIC via SPI (some AB12 devices use only the lower 8 bit).,,,,,,,,,
#-rb_syca_AsicDeviceId_au16(7).1,FEDFD253,7.1 ASIC Device ID read from ASIC via SPI (some AB12 devices use only the lower 8 bit).,,,,,,,,,

#rb_syca_AsicRevisionId_au16(4),FEDFD25C,4.0 ASIC Revision ID read from ASIC via SPI (some AB12 devices use only the lower 8 bit).,,,,,,,,,
#rb_syca_AsicRevisionId_au16(4).1,FEDFD25D,4.1 ASIC Revision ID read from ASIC via SPI (some AB12 devices use only the lower 8 bit).,,,,,,,,,
#-rb_syca_AsicRevisionId_au16(5),FEDFD25E,5.0 ASIC Revision ID read from ASIC via SPI (some AB12 devices use only the lower 8 bit).,,,,,,,,,
#-rb_syca_AsicRevisionId_au16(5).1,FEDFD25F,5.1 ASIC Revision ID read from ASIC via SPI (some AB12 devices use only the lower 8 bit).,,,,,,,,,
#rb_syca_AsicRevisionId_au16(6),FEDFD260,6.0 ASIC Revision ID read from ASIC via SPI (some AB12 devices use only the lower 8 bit).,,,,,,,,,
#rb_syca_AsicRevisionId_au16(6).1,FEDFD261,6.1 ASIC Revision ID read from ASIC via SPI (some AB12 devices use only the lower 8 bit).,,,,,,,,,
#-rb_syca_AsicRevisionId_au16(7),FEDFD262,7.0 ASIC Revision ID read from ASIC via SPI (some AB12 devices use only the lower 8 bit).,,,,,,,,,
#-rb_syca_AsicRevisionId_au16(7).1,FEDFD263,7.1 ASIC Revision ID read from ASIC via SPI (some AB12 devices use only the lower 8 bit).,,,,,,,,,

#-5*****************************************************************************
#Yaw
#rb_cs7m_AsicIdData_ast(0).AsicSerialNr_au16(0),FEDFA962,Smi7 Identification data for each sensor.ASIC serial numbers 3x16 bits,,,,,,,,,
#rb_cs7m_AsicIdData_ast(0).AsicSerialNr_au16(0).1,FEDFA963,Smi7 Identification data for each sensor.ASIC serial numbers 3x16 bits,,,,,,,,,
#rb_cs7m_AsicIdData_ast(0).AsicSerialNr_au16(1),FEDFA964,Smi7 Identification data for each sensor.ASIC serial numbers 3x16 bits,,,,,,,,,
#rb_cs7m_AsicIdData_ast(0).AsicSerialNr_au16(1).1,FEDFA965,Smi7 Identification data for each sensor.ASIC serial numbers 3x16 bits,,,,,,,,,
#rb_cs7m_AsicIdData_ast(0).AsicSerialNr_au16(2),FEDFA966,Smi7 Identification data for each sensor.ASIC serial numbers 3x16 bits,,,,,,,,,
#rb_cs7m_AsicIdData_ast(0).AsicSerialNr_au16(2).1,FEDFA967,Smi7 Identification data for each sensor.ASIC serial numbers 3x16 bits,,,,,,,,,
#rb_cs7m_AsicIdData_ast(0).SmiSerialNr_au16(0),FEDFA95C,Smi7 Identification data for each sensor.SMI serial numbers 3x16 bits,,,,,,,,,
#rb_cs7m_AsicIdData_ast(0).SmiSerialNr_au16(0).1,FEDFA95D,Smi7 Identification data for each sensor.SMI serial numbers 3x16 bits,,,,,,,,,
#rb_cs7m_AsicIdData_ast(0).SmiSerialNr_au16(1),FEDFA95E,Smi7 Identification data for each sensor.SMI serial numbers 3x16 bits,,,,,,,,,
#rb_cs7m_AsicIdData_ast(0).SmiSerialNr_au16(1).1,FkEDFA95F,Smi7 Identification data for each sensor.SMI serial numbers 3x16 bits,,,,,,,,,
#rb_cs7m_AsicIdData_ast(0).SmiSerialNr_au16(2),FEDFA960,Smi7 Identification data for each sensor.SMI serial numbers 3x16 bits,,,,,,,,,
#rb_cs7m_AsicIdData_ast(0).SmiSerialNr_au16(2).1,FEDFA961,Smi7 Identification data for each sensor.SMI serial numbers 3x16 bits,,,,,,,,,
#Roll
#rb_cs7m_AsicIdData_ast(2).AsicSerialNr_au16(0),FEDFA97A,Smi7 Identification data for each sensor.ASIC serial numbers 3x16 bits,,,,,,,,,
#rb_cs7m_AsicIdData_ast(2).AsicSerialNr_au16(0).1,FEDFA97B,Smi7 Identification data for each sensor.ASIC serial numbers 3x16 bits,,,,,,,,,
#rb_cs7m_AsicIdData_ast(2).AsicSerialNr_au16(1),FEDFA97C,Smi7 Identification data for each sensor.ASIC serial numbers 3x16 bits,,,,,,,,,
#rb_cs7m_AsicIdData_ast(2).AsicSerialNr_au16(1).1,FEDFA97D,Smi7 Identification data for each sensor.ASIC serial numbers 3x16 bits,,,,,,,,,
#rb_cs7m_AsicIdData_ast(2).AsicSerialNr_au16(2),FEDFA97E,Smi7 Identification data for each sensor.ASIC serial numbers 3x16 bits,,,,,,,,,
#rb_cs7m_AsicIdData_ast(2).AsicSerialNr_au16(2).1,FEDFA97F,Smi7 Identification data for each sensor.ASIC serial numbers 3x16 bits,,,,,,,,,
#rb_cs7m_AsicIdData_ast(2).SmiSerialNr_au16(0),FEDFA974,Smi7 Identification data for each sensor.SMI serial numbers 3x16 bits,,,,,,,,,
#rb_cs7m_AsicIdData_ast(2).SmiSerialNr_au16(0).1,FEDFA975,Smi7 Identification data for each sensor.SMI serial numbers 3x16 bits,,,,,,,,,
#rb_cs7m_AsicIdData_ast(2).SmiSerialNr_au16(1),FEDFA976,Smi7 Identification data for each sensor.SMI serial numbers 3x16 bits,,,,,,,,,
#rb_cs7m_AsicIdData_ast(2).SmiSerialNr_au16(1).1,FEDFA977,Smi7 Identification data for each sensor.SMI serial numbers 3x16 bits,,,,,,,,,
#rb_cs7m_AsicIdData_ast(2).SmiSerialNr_au16(2),FEDFA978,Smi7 Identification data for each sensor.SMI serial numbers 3x16 bits,,,,,,,,,
#rb_cs7m_AsicIdData_ast(2).SmiSerialNr_au16(2).1,FEDFA979,Smi7 Identification data for each sensor.SMI serial numbers 3x16 bits,,,,,,,,,

1;
