package LIFT_PROJECT;

$Defaults->{'Mapping_FAULT_extension'} = {
 'PRIORITY1_FAULTS' => [ 'rb_pom_VerOpenLine_flt','rb_pom_PowerPlausiSystemAsic1_flt','rb_pom_InadvertentReset_flt','rb_pom_VerVignCoupling_flt','rb_pom_VerLow_flt','rb_pom_VerHigh_flt','rb_pom_ESRhigh_flt','rb_pom_ErCapacityOutOfRange_flt','rb_pom_ErCapacitorMissing_flt','rb_pom_VerTestLevelChargeUp_flt','rb_pom_VerFinalLevelChargeUp_flt','rb_pom_OverTemperatureSystemAsic1_flt','rb_pom_OverTemperatureSystemAsic2_flt','rb_pom_VST50VltgSystemAsic1_flt','rb_pom_VST50VltgSystemAsic2_flt','rb_pom_VltgsNokSystemAsic1_flt','rb_pom_VltgsNokSystemAsic2_flt','rb_pom_HighTemperatureAsic1_flt','rb_pom_HighTemperatureAsic2_flt','rb_wdm_InitTestFail_flt','rb_wdm_DisAlpRemainsDisabled_flt','rb_wdm_WrongInitValWdStatus_flt','rb_wdm_Wd2WrongCheckword_flt','rb_wdm_Wd3WrongCheckword_flt','rb_wdm_WDFaultMasterWD1_flt','rb_wdm_WDFaultMasterWD2_flt','rb_wdm_WDFaultMasterWD3_flt','rb_wdm_WDFaultSlave1_flt','rb_wdm_WDFltCntOverflow_flt','rb_csem_InitGroup1Sma660Main_flt','rb_csem_InitGroup1Sma660Plausi_flt','rb_csem_InitGroup2Sma660Main_flt','rb_csem_InitGroup2Sma660Plausi_flt','rb_csem_InitGroup3Sma660Main_flt','rb_csem_InitGroup3Sma660Plausi_flt','rb_csem_InitGroup4Sma660Main_flt','rb_csem_InitGroup4Sma660Plausi_flt','rb_csem_CyclRTMonSma660Main_flt','rb_csem_CyclRTMonSma660Plausi_flt'],
'PRIORITY2_FAULTS' => [ 'rb_sqm_SqrefTooHigh_flt','rb_sqm_SqrefTooLow_flt','rb_sqm_VHx_flt','rb_acc_AlgoVerifySensorId_flt','rb_acc_ParameterLayoutIDInvalid_flt','rb_acc_ParaIDConsistenceCheck_flt'],
'PRIORITY3_FAULTS' => [ 'rb_sqm_SquibResistanceOpenKA1FD_flt','rb_sqm_SquibResistanceOpenAB2FD_flt','rb_sqm_SquibResistanceOpenAB1FP_flt','rb_sqm_SquibResistanceOpenAB2FP_flt','rb_sqm_SquibResistanceOpenALLFD_flt','rb_sqm_SquibResistanceOpenALLFP_flt','rb_swm_OpenLineBLFP_flt','rb_sqm_SquibResistanceOpenBT1FD_flt','rb_sqm_SquibResistanceOpenBT1FP_flt','rb_sqm_SquibResistanceOpenBATD_flt','rb_sqm_SquibResistanceOpenASC1FD_flt','rb_sqm_SquibResistanceOpenAB3FP_flt','rb_sqm_SquibResistanceOpenBT1RD_flt','rb_sqm_SquibResistanceOpenBT1RP_flt','rb_sqm_SquibResistanceOpenBT2FD_flt','rb_sqm_SquibResistanceOpenBT2FP_flt','rb_sqm_SquibResistanceOpenIC1FP_flt','rb_sqm_SquibResistanceOpenIC1FD_flt','rb_sqm_SquibResistanceOpenKA1FP_flt','rb_sqm_SquibResistanceOpenSA1RD_flt','rb_sqm_SquibResistanceOpenSA1FD_flt','rb_sqm_SquibResistanceOpenSA1FP_flt','rb_sqm_SquibResistanceOpenHOODD_flt','rb_swm_OpenLinePADS1_flt','rb_sqm_SquibResistanceOpenHOODP_flt'],

	#--------------------------- POM -------------------------------

	'rb_pom_PowerPlausiSystemAsic1_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::POM_STATUS::c3',
		'SpiSignalError' => 0,
	},

	'rb_pom_PowerPlausiSystemAsic2_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_S::POM_STATUS::c4',
		'SpiSignalError' => 0,
	},

	'rb_pom_InadvertentReset_flt' => {    #TODO: fault not qualified
		'DeviceType'       => 'SPI',
		'Condition'        => 'SPI_Manipulation',
		'SpiSignal'        => 'CG904_M::POM_READ_AUTO_VER::ver',
		'SpiSignalError'   => 380,
		'SpiSignal_1'      => 'CG904_S::POM_READ_AUTO_VER::ver',
		'SpiSignalError_1' => 380,
	},

	'rb_pom_VerVignCoupling_flt' => {     #TODO: fault not qualified
		'DeviceType'       => 'SPI',
		'Condition'        => 'SPI_Manipulation',
		'SpiSignal'        => 'CG904_M::POM_READ_AUTO_VER::ver',
		'SpiSignalError'   => 250,
		'SpiSignal_1'      => 'CG904_S::POM_READ_AUTO_VER::ver',
		'SpiSignalError_1' => 250,

		#		'SpiSignal_2'      => 'Cobra_M::POM_READ_AUTO_VBAT_MON2::vbat_mon2',
		#		'SpiSignalError_2' => 250,
	},

	'rb_pom_VerOpenLine_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::POM_READ_AUTO_VER::ver',
		'SpiSignalError' => 0,
		'FaultType'      => 'init_NoClearNoReset',
	},

	'rb_pom_VerLow_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::POM_READ_AUTO_VER::ver',
		'SpiSignalError' => 500,
		'FaultType'      => 'cyclic_SPI',
	},

	'rb_pom_VerHigh_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::POM_READ_AUTO_VER::ver',
		'SpiSignalError' => 800,
		'FaultType'      => 'cyclic',
	},
	'rb_pom_VbatLow_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::POM_READ_AUTO_VER::ver',
		'SpiSignalError' => 0,
		'FaultType'      => 'cyclic',
	},
	'rb_pom_VbatHigh_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::POM_READ_AUTO_VER::ver',
		'SpiSignalError' => 0,
		'FaultType'      => 'cyclic_SPI',
	},

	'rb_pom_ESRhigh_flt' => {
		'DeviceType'       => 'SPI',
		'Condition'        => 'SPI_Manipulation',
		'SpiSignal'        => 'CG904_M::POM_READ_BIST::et0_et1_et2',
		'SpiSignalError'   => '0b1xxxxxx11xxxxxxx',
		'SpiSignal_1'      => 'CG904_S::POM_READ_BIST::et0_et1_et2',
		'SpiSignalError_1' => '0b1xxxxxx11xxxxxxx',
		'FaultType'        => 'init_NoClearNoReset',
	},

	'rb_pom_ErCapacityOutOfRange_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::POM_READ_BIST::delta_ver',
		'SpiSignalError' => 5,
		'FaultType'      => 'init_NoClearNoReset',
	},
	'rb_pom_BatteryESRHigh_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::POM_CYCL_CAP::res',    #cyclic fault
		'SpiSignalError' => 1,
		'FaultType'      => 'init',
	},

	# 'rb_pom_ErCapacitorMissing_flt' => {
	# 'DeviceType'     => 'SPI',
	# 'Condition'      => 'SPI_Manipulation',
	# 'SpiSignal'      => 'CG904_M::POM_CYCL_CAP::res',    #cyclic fault
	# 'SpiSignalError' => 1,
	# 'CyclicDequalificationtime'=>'0-10000', #in ms
	# 'FaultType'					=>'cyclic_SPI',
	# },

	'rb_pom_ErCapacitorMissing_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::POM_READ_BIST::vel',    #init fault
		'SpiSignalError' => 0,
	},

	# 'rb_pom_Autarky_flt' => {
	# 'DeviceType'     => 'SPI',
	# 'Condition'      => 'SPI_Manipulation',
	# 'SpiSignal'      => 'CG904_M::POM_CYCL_CAP::aky',    #case 1
	# 'SpiSignalError' => 1,
	# },

	'rb_pom_Autarky_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::POM_STATUS::vin',    #case 2
		'SpiSignalError' => 1,
	},

	'rb_pom_VerTestLevelChargeUp_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::POM_STATUS::vet',
		'SpiSignalError' => 0,
	},

	'rb_pom_VerFinalLevelChargeUp_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::POM_STATUS::vel',
		'SpiSignalError' => 1,
	},

	'rb_pom_OverTemperatureSystemAsic1_flt' => {
		'DeviceType'                => 'SPI',
		'Condition'                 => 'SPI_Manipulation',
		'SpiSignal'                 => 'CG904_M::POM_STATUS::ot',
		'SpiSignalError'            => 1,
		'CyclicDequalificationtime' => '0-10',                      #in ms
		'FaultType'                 => 'cyclic_SPI',
	},

	'rb_pom_OverTemperatureSystemAsic2_flt' => {
		'DeviceType'                => 'SPI',
		'Condition'                 => 'SPI_Manipulation',
		'SpiSignal'                 => 'CG904_S::POM_STATUS::ot',
		'SpiSignalError'            => 1,
		'CyclicDequalificationtime' => '0-10',                      #in ms
		'FaultType'                 => 'cyclic_SPI',
	},

	'rb_pom_VST50VltgSystemAsic1_flt' => {
		'DeviceType'                => 'SPI',
		'Condition'                 => 'SPI_Manipulation',
		'SpiSignal'                 => 'CG904_M::POM_STATUS::v50',
		'SpiSignalError'            => 1,
		'CyclicDequalificationtime' => '0-10',                       #in ms
		'FaultType'                 => 'cyclic_SPI',
	},

	'rb_pom_VST50VltgSystemAsic2_flt' => {
		'DeviceType'                => 'SPI',
		'Condition'                 => 'SPI_Manipulation',
		'SpiSignal'                 => 'CG904_S::POM_STATUS::v50',
		'SpiSignalError'            => 1,
		'CyclicDequalificationtime' => '0-10',                       #in ms
		'FaultType'                 => 'cyclic_SPI',
	},

	'rb_pom_VltgsNokSystemAsic1_flt' => {
		'DeviceType'                => 'SPI',
		'Condition'                 => 'SPI_Manipulation',
		'SpiSignal'                 => 'CG904_M::POM_STATUS::nok',
		'SpiSignalError'            => 1,
		'CyclicDequalificationtime' => '0-10',                       #in ms
		'FaultType'                 => 'cyclic_SPI',
	},

	'rb_pom_VltgsNokSystemAsic2_flt' => {
		'DeviceType'                => 'SPI',
		'Condition'                 => 'SPI_Manipulation',
		'SpiSignal'                 => 'CG904_S::POM_STATUS::nok',
		'SpiSignalError'            => 1,
		'CyclicDequalificationtime' => '0-10',                       #in ms
		'FaultType'                 => 'cyclic_SPI',
	},

	'rb_pom_HighTemperatureAsic1_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::POM_READ_AUTO_TEMPERATURE::temperature',
		'SpiSignalError' => 0,
		'FaultType'      => 'cyclic_SPI',
	},

	'rb_pom_HighTemperatureAsic2_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_S::POM_READ_AUTO_TEMPERATURE::temperature',
		'SpiSignalError' => 0,
		'FaultType'      => 'cyclic_SPI',
	},

	#--------------------------- WDM -------------------------------

	'rb_wdm_InitTestFail_flt' => {    #TODO: check
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::WD_STATUS::o1',
		'SpiSignalError' => 0,
		'FaultType'      => 'init',

	},

	'rb_wdm_DisAlpRemainsDisabled_flt' => {    #TODO: check
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::DISABLE_STATUS::ALP',
		'SpiSignalError' => 1,
		'FaultType'      => 'init',
	},

	'rb_wdm_WrongInitValWdStatus_flt' => {     #TODO: check
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::WD_STATUS::cr',
		'SpiSignalError' => 0,
		'FaultType'      => 'init',
	},

	'rb_wdm_Wd2WrongCheckword_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::WD2_TRIGGER::wd2_checkword',
		'SpiSignalError' => 1,
		'FaultType'      => 'cyclic_SPI_SingleQuali',
	},

	'rb_wdm_Wd3WrongCheckword_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::WD3_TRIGGER::wd3_checkword',
		'SpiSignalError' => 1,
		'FaultType'      => 'cyclic_SPI_SingleQuali',
	},

	'rb_wdm_WDFaultMasterWD1_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::WD_STATUS::u1',
		'SpiSignalError' => 1,
		'FaultType'      => 'cyclic_SPI',
	},

	'rb_wdm_WDFaultMasterWD2_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::WD_STATUS::u2',
		'SpiSignalError' => 1,
		'FaultType'      => 'cyclic_SPI',
	},

	'rb_wdm_WDFaultMasterWD3_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::WD_STATUS::r3',
		'SpiSignalError' => 1,
		'FaultType'      => 'cyclic_SPI',
	},

	'rb_wdm_WDFaultSlave1_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_S::WD_STATUS::o1',
		'SpiSignalError' => 1,
		'FaultType'      => 'cyclic_SPI',
	},

	'rb_wdm_WDFltCntOverflow_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::WD_STATUS::faultcnt',
		'SpiSignalError' => 3,
	},

	#--------------------------- SMA760-SMA720 -------------------------------

	'rb_csem_InitGroup1SmaMain_flt' => {
		'Device'         => 'SMA760',
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMA760::RD_CONFIG_1::CRC',
		'SpiSignalError' => 7,
		'FaultType'      => 'init_permanent',
	},

	'rb_csem_InitGroup1SmaPlausi_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMA720::RD_CONFIG_1::CRC',
		'SpiSignalError' => 7,
		'FaultType'      => 'init_permanent',
	},

	'rb_csem_InitGroup2SmaMain_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMA760::RD_MONITOR_II_DATA::FOC_BUSY_CH1',
		'SpiSignalError' => 1,
		'FaultType'      => 'init_permanent',
	},

	'rb_csem_InitGroup2SmaPlausi_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMA720::RD_MONITOR_II_DATA::FOC_BUSY_CH1',
		'SpiSignalError' => 1,
		'FaultType'      => 'init_permanent',
	},

	'rb_csem_InitGroup3SmaMain_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMA760::RD_TEST_MODE::CH1_BITE',
		'SpiSignalError' => 3,
		'FaultType'      => 'init_permanent',
	},

	'rb_csem_InitGroup3SmaPlausi_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMA720::RD_TEST_MODE::CH1_BITE',
		'SpiSignalError' => 3,
		'FaultType'      => 'init_permanent',
	},

	'rb_csem_InitGroup4SmaMain_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMA760::RD_BITE_CH1::Positive BITE OTP CH1',
		'SpiSignalError' => 255,
		'FaultType'      => 'init_permanent',
	},

	'rb_csem_InitGroup4SmaPlausi_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMA720::RD_BITE_CH1::Positive BITE OTP CH1',
		'SpiSignalError' => 255,
		'FaultType'      => 'init_permanent',
	},

	'rb_csem_CyclRTMonSmaMain_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMA760::RD_SENSOR_DATA_CH1::SID',
		'SpiSignalError' => 31,
		'FaultType'      => 'cyclic_SPI_SingleQuali',
	},

	'rb_csem_CyclRTMonSmaPlausi_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMA720::RD_CAPTURED_DATA_CH2::SID',
		'SpiSignalError' => 31,
		'FaultType'      => 'cyclic_SPI_SingleQuali',
	},

	#---------------------Algo------------------------------------------------------
	'rb_simc_SignalMonCtrlMain_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMA760::RD_SENSOR_DATA_CH1::Data_CH1',
		'SpiSignalError' => 31,
		'FaultType'      => 'cyclic_SPI',
	},
	'rb_simp_SignalMonPesPasFD_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::PSI_READ_DATA13::psi_data',
		'SpiSignalError' => 31,
		'FaultType'      => 'cyclic_SPI',
	},
	'rb_simp_SignalMonPesUfsD_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::PSI_READ_DATA2::psi_data',
		'SpiSignalError' => 20,
		'FaultType'      => 'cyclic_SPI_SingleQuali',
	},

	#---------------------------------------------------------------------------------------------
	#---------------------------------SMI8-----------------------------------------------------------
	'rb_csem_MonPermInitInertialSensor2_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMI8xx::PitchRateLfChl::CRC',
		'SpiSignalError' => 7,
		'FaultType'      => 'init_permanent',
	},

	#------------------------------------------------------SWM----------------------------------------#
	'rb_swm_SdlHwSwPlausibility_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::DISABLE_STATUS::SIDS',
		'SpiSignalError' => 0,
		'FaultType'      => 'cyclic_SPI',
	},

	#---------------------------------------------------PSEM----------------------------------------------#
	'rb_psem_InternalCommUFSD_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::PSI_READ_DATA::S',
		'SpiSignalError' => 0,
		'FaultType'      => 'cyclic_SPI_permanent',
	},
	'rb_psem_InternalCommUFSP_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::PSI_READ_DATA::S',
		'SpiSignalError' => 0,
		'FaultType'      => 'cyclic_SPI_permanent',
	},
	'rb_psem_InternalCommPASFD_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::PSI_READ_DATA::S',
		'SpiSignalError' => 0,
		'FaultType'      => 'cyclic_SPI_permanent',
	},
	'rb_psem_InternalCommPASFP_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::PSI_READ_DATA::S',
		'SpiSignalError' => 0,
		'FaultType'      => 'cyclic_SPI_permanent',
	},
	'rb_psem_InternalCommPASMD_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::PSI_READ_DATA::S',
		'SpiSignalError' => 0,
		'FaultType'      => 'cyclic_SPI_permanent',
	},
	'rb_psem_InternalCommPASMP_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::PSI_READ_DATA::S',
		'SpiSignalError' => 0,
		'FaultType'      => 'cyclic_SPI_permanent',
	},
	'rb_psem_InternalCommPPSFD_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::PSI_READ_DATA::S',
		'SpiSignalError' => 0,
		'FaultType'      => 'cyclic_SPI_permanent',
	},
	'rb_psem_InternalCommPPSFP_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::PSI_READ_DATA::S',
		'SpiSignalError' => 0,
		'FaultType'      => 'cyclic_SPI_permanent',
	},

	'rb_psem_InternalCommPCSC_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_S::PSI_READ_DATA::S',
		'SpiSignalError' => 0,
		'FaultType'      => 'cyclic_SPI_permanent',
	},
	'rb_psem_InternalCommPTSD_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_S::PSI_READ_DATA::S',
		'SpiSignalError' => 0,
		'FaultType'      => 'cyclic_SPI_permanent',
	},
	'rb_psem_InternalCommPTSP_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_S::PSI_READ_DATA::S',
		'SpiSignalError' => 0,
		'FaultType'      => 'cyclic_SPI_permanent',
	},
	'rb_psem_InternalCommPASRC_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_S::PSI_READ_DATA::S',
		'SpiSignalError' => 0,
		'FaultType'      => 'cyclic_SPI_permanent',
	},

	#-------------------------------------------------------------------------------------------------#
	'rb_bsd_SysAsicAmuInitTest_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::AINO_START_BIST::CRC',
		'SpiSignalError' => 'invert',
		'FaultType'      => 'init',
	},
	'rb_bsd_SysAsicRegisterProgMon_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::PROG_SAFETY::sl',
		'SpiSignalError' => 1,
		'FaultType'      => 'init_NoClearNoReset',
	},
	'rb_sqm_AmuShortTestGnd_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::FLM_READ_SHORT1::cn',
		'SpiSignalError' => 0,
		'FaultType'      => 'init',
	},
	'rb_sqm_AmuShortTestBat_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::FLM_READ_SHORT2::cn',
		'SpiSignalError' => 0,
		'FaultType'      => 'init',
	},
	'rb_sqm_SqrefTooHigh_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::FLM_READ_RES::flt',
		'SpiSignalError' => 3,
		'FaultType'      => 'cyclic_SPI',
	},
	'rb_sqm_SqrefTooLow_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::FLM_READ_RES::flt',
		'SpiSignalError' => 2,
		'FaultType'      => 'cyclic_SPI',
	},
	'rb_svr_SVRTestFailedSVR1_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::FLM_READ_SVR::| adc_data: 0x',
		'SpiSignalError' => 0,
		'FaultType'      => 'init',
	},
	'rb_spi_SpiRcvMsgCrcWrong_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::POM_STATUS::CRC',
		'SpiSignalError' => 3,
		'FaultType'      => 'cyclic_SPI_permanent',
	},
	'rb_scm_SCONPlausibility_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_S::DISABLE_STATUS::DIS_AHP',
		'SpiSignalError' => 1,
		'FaultType'      => 'init_NoClearNoReset',
	},
	'rb_scm_DisableLines_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::DISABLE_STATUS::DIS_AHP',
		'SpiSignalError' => 1,
		'FaultType'      => 'init_NoClearNoReset',
	},
	'rb_sqm_VHx_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::FLM_READ_VH::adc_data',
		'SpiSignalError' => 0,
		'FaultType'      => 'cyclic_SPI',
	},
	'rb_simp_SignalMonPesPtsD_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_S::PSI_READ_DATA_CH1_TS3::psi_data',
		'SpiSignalError' => 100,
		'Duration_us'	 => '200000',
		'FaultType'      => 'cyclic_SPI_permanent',
	},	
	#---------------------------------------SMI8--------------------------------------------
	'rb_csem_MonPermBGInertialSensor1_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMI::InertialSensor1::SD',
		'SpiSignalError' => 1,
		'Duration_us'	 => '1500000',
		'FaultType'      => 'cyclic_SPI_permanent',
	},
	'rb_csem_MonPermBGInertialSensor2_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMI::InertialSensor2::SD',
		'SpiSignalError' => 1,
		'Duration_us'	 => '1500000',
		'FaultType'      => 'cyclic_SPI_permanent',
	},
	'rb_csem_MonPermInitInertialSensor1_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMI::InitInertialSensor1::CRC',
		'SpiSignalError' => '7',
		'Frame_Cycles'	 => '3',
		'FaultType'      => 'init_off_SPI_permanent',
	},
	'rb_csem_MonPermInitInertialSensor2_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMI::InitInertialSensor2::CRC',
		'SpiSignalError' => '7',
		'Frame_Cycles'	 => '3',
		'FaultType'      => 'init_off_SPI_permanent',
	},
	'rb_csem_MonPermAccXHgMonChl_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMI::AccXHgMonChl::CN',
		'SpiSignalError' => 1,
		'Duration_us'	 => '10200000',
		'FaultType'      => 'cyclic_SPI_permanent',
	},
	'rb_csem_MonTempAccXHgMonChl_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMI::AccXHgMonChl::CN',
		'SpiSignalError' => 1,
		'Duration_us'	 => '9500000',
		'FaultType'      => 'cyclic_SPI',
	},
	'rb_csem_MonPermRollRateLfChl_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMI::RollRateLfChl::CN',
		'SpiSignalError' => 1,
		'Duration_us'	 => '10200000',
		'FaultType'      => 'cyclic_SPI_permanent',
	},
	'rb_csem_MonTempRollRateLfChl_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMI::RollRateLfChl::CN',
		'SpiSignalError' => 1,
		'Duration_us'	 => '9500000',
		'FaultType'      => 'cyclic_SPI',
	},
	'rb_csem_MonPermAccZLgChl_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMI::AccZLgChl::CN',
		'SpiSignalError' => 1,
		'Duration_us'	 => '10200000',
		'FaultType'      => 'cyclic_SPI_permanent',
	},
	'rb_csem_MonTempAccZLgChl_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMI::AccZLgChl::CN',
		'SpiSignalError' => 1,
		'Duration_us'	 => '9500000',
		'FaultType'      => 'cyclic_SPI',
	},
	'rb_csem_MonPermAccYLgChl_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMI::AccYLgChl::CN',
		'SpiSignalError' => 1,
		'Duration_us'	 => '10200000',
		'FaultType'      => 'cyclic_SPI_permanent',
	},
	'rb_csem_MonTempAccYLgChl_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMI::AccYLgChl::CN',
		'SpiSignalError' => 1,
		'Duration_us'	 => '9500000',
		'FaultType'      => 'cyclic_SPI',
	},
	'rb_csem_MonPermYawRateLfChl_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMI::YawRateLfChl::CN',
		'SpiSignalError' => 1,
		'Duration_us'	 => '10200000',
		'FaultType'      => 'cyclic_SPI_permanent',
	},
	'rb_csem_MonTempYawRateLfChl_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMI::YawRateLfChl::CN',
		'SpiSignalError' => 1,
		'Duration_us'	 => '9500000',
		'FaultType'      => 'cyclic_SPI',
	},
	'rb_csem_MonPermPitchRateLfChl_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMI::PitchRateLfChl::CN',
		'SpiSignalError' => 1,
		'Duration_us'	 => '10200000',
		'FaultType'      => 'cyclic_SPI_permanent',
	},
	'rb_csem_MonTempPitchRateLfChl_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMI::PitchRateLfChl::CN',
		'SpiSignalError' => 1,
		'Duration_us'	 => '9500000',
		'FaultType'      => 'cyclic_SPI',
	},
	'rb_csem_MonPermAccYHgMonChl_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMI::AccYHgMonChl::CN',
		'SpiSignalError' => 1,
		'Duration_us'	 => '10200000',
		'FaultType'      => 'cyclic_SPI_permanent',
	},
	'rb_csem_MonTempAccYHgMonChl_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMI::AccYHgMonChl::CN',
		'SpiSignalError' => 1,
		'Duration_us'	 => '9500000',
		'FaultType'      => 'cyclic_SPI',
	},
	'rb_csem_MonPermAccXLgChl_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMI::AccXLgChl::CN',
		'SpiSignalError' => 1,
		'Duration_us'	 => '10200000',
		'FaultType'      => 'cyclic_SPI_permanent',
	},
	'rb_csem_MonTempAccXLgChl_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMI::AccXLgChl::CN',
		'SpiSignalError' => 1,
		'Duration_us'	 => '9500000',
		'FaultType'      => 'cyclic_SPI',
	},	
};

1;
