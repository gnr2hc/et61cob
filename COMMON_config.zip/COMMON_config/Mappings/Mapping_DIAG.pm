#### This file is generated from SPR export by the Diag mapping generator tool #### 

package LIFT_PROJECT; 

######################################################### 
my $VERSION = q$Revision: 1.13 $;
my $HEADER = q$Header: config/Mappings/Mapping_DIAG.pm 1.13 2020/06/15 15:58:05IST Biswas Abhishek (RBEI/ESA-PP2) (ABW5KOR) develop  $;
########################################################## 

$Defaults->{"Mapping_DIAG"} = {


############# PRJ_SUPPORTED_SERVICES ##################

'PRJ_SUPPORTED_SERVICES' => {
	'SecurityAccess' => 'En',
	'DiagnosticSessionControl' => '10',
	'ECUReset' => '11',
	'ClearDiagnosticInformation' => '14',
	'ReadDTCInformation' => '19',
	'ReadDataByIdentifier' => '22',
	'CommunicationControl' => '28',
	'WriteDataByIdentifier' => '2E',
	'IOControl' => '2F',
	'RoutineControl' => '31',
	'TesterPresent' => '3E',
	'ControlDTCSetting' => '85',
},
#---------------------------------------------------------#


############# DIAG SERVICES ##################

'DIAG_SERVICES' => {

	'SecurityAccess' => {
					'Service_ID' => 'En',
					'Supported_SubFuns' => {
								'RequestSeed_0x01' => '01', 
								'RequestSeed_0x02' => '03', 
								'RequestSeed_Deployment_Level48' => '5F', 
								'RequestSeed_EDR' => 'te rt he ap pr op ri at es ub fu nc ti on fo rR eq ue st Se ed :2 7X', 
								'SendKey_0x01' => '02', 
								'SendKey_0x02' => '04', 
								'SendKey_Deployment_Level48' => '60', 
								'SendKey_EDR' => 'te rt he ap pr op ri at es ub fu nc ti on fo rS en dK ey :2 7Y', 
					},
					'NEG_Responses' => {
					},
	},
#----------------------------------------------------------------------------------#
	'DiagnosticSessionControl' => {
					'Service_ID' => '10',
					'Supported_SubFuns' => {
								'DefaultSession' => '01', 
								'DefaultSession_ForDisposal' => '01', 
								'ExtendedSession' => '03', 
								'SafetySession' => '04', 
					},
					'NEG_Responses' => {
								'NR_subFunctionNotSupported' => { 'Response' =>  '7F 10 12' , 'Mode' =>  'strict' , 'Desc' =>  'subFunctionNotSupported' , 'AddrModes' => [ 'physical' ]},
								'NR_incorrectMessageLengthOrInvalidFormat' => { 'Response' =>  '7F 10 13' , 'Mode' =>  'strict' , 'Desc' =>  'incorrectMessageLengthOrInvalidFormat' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_busyRepeatRequest' => { 'Response' =>  '7F 10 21' , 'Mode' =>  'strict' , 'Desc' =>  'busyRepeatRequest' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_conditionsNotCorrect' => { 'Response' =>  '7F 10 22' , 'Mode' =>  'strict' , 'Desc' =>  'conditionsNotCorrect' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestCorrectlyReceived_ResponsePending' => { 'Response' =>  '7F 10 78' , 'Mode' =>  'strict' , 'Desc' =>  'requestCorrectlyReceived_ResponsePending' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_subFunctionNotSupportedInActiveSession' => { 'Response' =>  '7F 10 7E' , 'Mode' =>  'strict' , 'Desc' =>  'subFunctionNotSupportedInActiveSession' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_serviceNotSupportedInActiveSession' => { 'Response' =>  '7F 10 7F' , 'Mode' =>  'strict' , 'Desc' =>  'serviceNotSupportedInActiveSession' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_vehicleSpeedTooHigh' => { 'Response' =>  '7F 10 88' , 'Mode' =>  'strict' , 'Desc' =>  'vehicleSpeedTooHigh' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_voltageTooHigh' => { 'Response' =>  '7F 10 92' , 'Mode' =>  'strict' , 'Desc' =>  'voltageTooHigh' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_voltageTooLow' => { 'Response' =>  '7F 10 93' , 'Mode' =>  'strict' , 'Desc' =>  'voltageTooLow' , 'AddrModes' => [ 'physical', 'functional' ]},
					},
	},
#----------------------------------------------------------------------------------#
	'ECUReset' => {
					'Service_ID' => '11',
					'Supported_SubFuns' => {
								'HARD' => '01', 
								'HardReset_ForDisposal' => '01', 
								'SOFT' => '03', 
								'SystemSupplierHardReset' => '60', 
								'SystemSupplierSoftReset' => '63', 
					},
					'NEG_Responses' => {
								'NR_subFunctionNotSupported' => { 'Response' =>  '7F 11 12' , 'Mode' =>  'strict' , 'Desc' =>  'subFunctionNotSupported' , 'AddrModes' => [ 'physical' ]},
								'NR_incorrectMessageLengthOrInvalidFormat' => { 'Response' =>  '7F 11 13' , 'Mode' =>  'strict' , 'Desc' =>  'incorrectMessageLengthOrInvalidFormat' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_busyRepeatRequest' => { 'Response' =>  '7F 11 21' , 'Mode' =>  'strict' , 'Desc' =>  'busyRepeatRequest' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_conditionsNotCorrect' => { 'Response' =>  '7F 11 22' , 'Mode' =>  'strict' , 'Desc' =>  'conditionsNotCorrect' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestOutOfRange' => { 'Response' =>  '7F 11 31' , 'Mode' =>  'strict' , 'Desc' =>  'requestOutOfRange' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_securityAccessDenied' => { 'Response' =>  '7F 11 33' , 'Mode' =>  'strict' , 'Desc' =>  'securityAccessDenied' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestCorrectlyReceived_ResponsePending' => { 'Response' =>  '7F 11 78' , 'Mode' =>  'strict' , 'Desc' =>  'requestCorrectlyReceived_ResponsePending' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_subFunctionNotSupportedInActiveSession' => { 'Response' =>  '7F 11 7E' , 'Mode' =>  'strict' , 'Desc' =>  'subFunctionNotSupportedInActiveSession' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_serviceNotSupportedInActiveSession' => { 'Response' =>  '7F 11 7F' , 'Mode' =>  'strict' , 'Desc' =>  'serviceNotSupportedInActiveSession' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_vehicleSpeedTooHigh' => { 'Response' =>  '7F 11 88' , 'Mode' =>  'strict' , 'Desc' =>  'vehicleSpeedTooHigh' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_voltageTooHigh' => { 'Response' =>  '7F 11 92' , 'Mode' =>  'strict' , 'Desc' =>  'voltageTooHigh' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_voltageTooLow' => { 'Response' =>  '7F 11 93' , 'Mode' =>  'strict' , 'Desc' =>  'voltageTooLow' , 'AddrModes' => [ 'physical', 'functional' ]},
					},
	},
#----------------------------------------------------------------------------------#
	'ClearDiagnosticInformation' => {
					'Service_ID' => '14',
					'Supported_SubFuns' => {
								'ClearAllDTC' => 'FF FF FF', 
					},
					'NEG_Responses' => {
								'NR_serviceNotSupported' => { 'Response' =>  '7F 14 11' , 'Mode' =>  'strict' , 'Desc' =>  'serviceNotSupported' , 'AddrModes' => [ 'physical' ]},
								'NR_incorrectMessageLengthOrInvalidFormat' => { 'Response' =>  '7F 14 13' , 'Mode' =>  'strict' , 'Desc' =>  'incorrectMessageLengthOrInvalidFormat' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_busyRepeatRequest' => { 'Response' =>  '7F 14 21' , 'Mode' =>  'strict' , 'Desc' =>  'busyRepeatRequest' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_conditionsNotCorrect' => { 'Response' =>  '7F 14 22' , 'Mode' =>  'strict' , 'Desc' =>  'conditionsNotCorrect' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestOutOfRange' => { 'Response' =>  '7F 14 31' , 'Mode' =>  'strict' , 'Desc' =>  'requestOutOfRange' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_generalProgrammingFailure' => { 'Response' =>  '7F 14 72' , 'Mode' =>  'strict' , 'Desc' =>  'generalProgrammingFailure' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestCorrectlyReceived_ResponsePending' => { 'Response' =>  '7F 14 78' , 'Mode' =>  'strict' , 'Desc' =>  'requestCorrectlyReceived_ResponsePending' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_serviceNotSupportedInActiveSession' => { 'Response' =>  '7F 14 7F' , 'Mode' =>  'strict' , 'Desc' =>  'serviceNotSupportedInActiveSession' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_vehicleSpeedTooHigh' => { 'Response' =>  '7F 14 88' , 'Mode' =>  'strict' , 'Desc' =>  'vehicleSpeedTooHigh' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_voltageTooHigh' => { 'Response' =>  '7F 14 92' , 'Mode' =>  'strict' , 'Desc' =>  'voltageTooHigh' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_voltageTooLow' => { 'Response' =>  '7F 14 93' , 'Mode' =>  'strict' , 'Desc' =>  'voltageTooLow' , 'AddrModes' => [ 'physical', 'functional' ]},
					},
	},
#----------------------------------------------------------------------------------#
	'ReadDTCInformation' => {
					'Service_ID' => '19',
					'Supported_SubFuns' => {
								'ReportDtcSnapshotRecordByDtcNumber' => '04', 
								'ReportDtcsByStatusMask' => '02', 
								'ReportNumberOfDtcByStatusMask' => '01', 
								'ReportSupportedDtcs' => '0A', 
								'RepotDtcExtDataRecordByDtcNumber' => '06', 
					},
					'NEG_Responses' => {
								'NR_serviceNotSupported' => { 'Response' =>  '7F 19 11' , 'Mode' =>  'strict' , 'Desc' =>  'serviceNotSupported' , 'AddrModes' => [ 'physical' ]},
								'NR_subFunctionNotSupported' => { 'Response' =>  '7F 19 12' , 'Mode' =>  'strict' , 'Desc' =>  'subFunctionNotSupported' , 'AddrModes' => [ 'physical' ]},
								'NR_incorrectMessageLengthOrInvalidFormat' => { 'Response' =>  '7F 19 13' , 'Mode' =>  'strict' , 'Desc' =>  'incorrectMessageLengthOrInvalidFormat' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_busyRepeatRequest' => { 'Response' =>  '7F 19 21' , 'Mode' =>  'strict' , 'Desc' =>  'busyRepeatRequest' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_conditionsNotCorrect' => { 'Response' =>  '7F 19 22' , 'Mode' =>  'strict' , 'Desc' =>  'conditionsNotCorrect' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestOutOfRange' => { 'Response' =>  '7F 19 31' , 'Mode' =>  'strict' , 'Desc' =>  'requestOutOfRange' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestCorrectlyReceived_ResponsePending' => { 'Response' =>  '7F 19 78' , 'Mode' =>  'strict' , 'Desc' =>  'requestCorrectlyReceived_ResponsePending' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_subFunctionNotSupportedInActiveSession' => { 'Response' =>  '7F 19 7E' , 'Mode' =>  'strict' , 'Desc' =>  'subFunctionNotSupportedInActiveSession' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_serviceNotSupportedInActiveSession' => { 'Response' =>  '7F 19 7F' , 'Mode' =>  'strict' , 'Desc' =>  'serviceNotSupportedInActiveSession' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_vehicleSpeedTooHigh' => { 'Response' =>  '7F 19 88' , 'Mode' =>  'strict' , 'Desc' =>  'vehicleSpeedTooHigh' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_voltageTooHigh' => { 'Response' =>  '7F 19 92' , 'Mode' =>  'strict' , 'Desc' =>  'voltageTooHigh' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_voltageTooLow' => { 'Response' =>  '7F 19 93' , 'Mode' =>  'strict' , 'Desc' =>  'voltageTooLow' , 'AddrModes' => [ 'physical', 'functional' ]},
					},
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier' => {
					'Service_ID' => '22',
					'Supported_SubFuns' => {
								'ActDiagSession' => 'F1 86', 
								'AddressInformation' => 'FA 12', 
								'AddressInformationOfPCU' => 'FA 02', 
								'CnEDRdata01' => 'FA 13', 
								'CnEDRdata02' => 'FA 14', 
								'CnEDRdata03' => 'FA 15', 
								'DeploymentLoopTable' => 'FA 06', 
								'DeploymentMethodVersion' => 'FA 01', 
								'DismantlerInfo' => 'FA 07', 
								'EDREntry01' => 'FA 13', 
								'EDREntry02' => 'FA 14', 
								'EDREntry03' => 'FA 15', 
								'EDREntry04' => 'FA 16', 
								'EDREntry05' => 'FA 17', 
								'EDREntry06' => 'FA 18', 
								'EDRIdentification' => 'FA 11', 
								'NumberOfEDRDevices' => 'FA 10', 
								'NumberOfPCU' => 'FA 00', 
								'OEMEDREntry01' => '10 13', 
								'OEMEDREntry02' => '10 14', 
								'OEMEDREntry03' => '10 15', 
								'OEMEDREntry04' => '10 16', 
								'OEMEDREntry05' => '10 17', 
								'OEMEDREntry06' => '10 18', 
								'OEMSpecificAddressInformation' => '10 12', 
								'OEMSpecificEDREntry01' => '10 13', 
								'OEMSpecificEDREntry02' => '10 14', 
								'OEMSpecificEDREntry03' => '10 15', 
								'OEMSpecificEDREntry04' => '10 16', 
								'OEMSpecificEDREntry05' => '10 17', 
								'OEMSpecificEDREntry06' => '10 18', 
								'OEMSpecificEDRIdentification' => '10 11', 
								'OEMSpecificNumberOfEDRDevices' => '10 10', 
								'OEMspecificAddressInformation' => '10 12', 
								'OEMspecificEDRIdentification' => '10 11', 
								'ReadBatteryVoltage' => 'D1 12', 
								'ReadCrash' => 'FA 10', 
								'ReadEnergyReserve' => '5B 02', 
								'ReadSenSerNrPasFD' => '50 03', 
								'ReadSenSerNrPasFP' => '50 04', 
								'ReadSenSerNrUfsD' => '50 00', 
								'ReadSenSerNrUfsp' => '50 01', 
								'ReadSquibResAB1FD' => '30 00', 
								'ReadSquibResAB2FD' => '30 01', 
								'ReadSquibStsAB1FD' => '31 00', 
								'ReadSquibStsAB2FD' => '31 01', 
								'ReadSwitchMesBLFD' => '40 00', 
								'ReadSwitchMesBLFP' => '40 01', 
								'ReadSwitchMesBLR2D' => '40 03', 
								'ReadSwitchMesSPSFD' => '40 09', 
								'ReadSwitchStsBLFD' => '41 00', 
								'ReadSwitchStsBLFP' => '41 01', 
								'ReadSwitchStsBLR2D' => '41 03', 
								'ReadSwitchStsSPSFD' => '41 09', 
								'ReadVIN' => 'F1 90', 
								'ReadWriteEOL' => '60 01', 
								'ReadWriteGenData' => '20 00', 
								'SupplierEDREntry01' => '11 13', 
								'SupplierEDREntry02' => '11 14', 
								'SupplierEDREntry03' => '11 15', 
					},
					'NEG_Responses' => {
								'NR_incorrectMessageLengthOrInvalidFormat' => { 'Response' =>  '7F 22 13' , 'Mode' =>  'strict' , 'Desc' =>  'incorrectMessageLengthOrInvalidFormat' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_responseTooLong' => { 'Response' =>  '7F 22 14' , 'Mode' =>  'strict' , 'Desc' =>  'responseTooLong' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_busyRepeatRequest' => { 'Response' =>  '7F 22 21' , 'Mode' =>  'strict' , 'Desc' =>  'busyRepeatRequest' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_conditionsNotCorrect' => { 'Response' =>  '7F 22 22' , 'Mode' =>  'strict' , 'Desc' =>  'conditionsNotCorrect' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestOutOfRange' => { 'Response' =>  '7F 22 31' , 'Mode' =>  'strict' , 'Desc' =>  'requestOutOfRange' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_securityAccessDenied' => { 'Response' =>  '7F 22 33' , 'Mode' =>  'strict' , 'Desc' =>  'securityAccessDenied' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestCorrectlyReceived_ResponsePending' => { 'Response' =>  '7F 22 78' , 'Mode' =>  'strict' , 'Desc' =>  'requestCorrectlyReceived_ResponsePending' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_serviceNotSupportedInActiveSession' => { 'Response' =>  '7F 22 7F' , 'Mode' =>  'strict' , 'Desc' =>  'serviceNotSupportedInActiveSession' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_vehicleSpeedTooHigh' => { 'Response' =>  '7F 22 88' , 'Mode' =>  'strict' , 'Desc' =>  'vehicleSpeedTooHigh' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_voltageTooHigh' => { 'Response' =>  '7F 22 92' , 'Mode' =>  'strict' , 'Desc' =>  'voltageTooHigh' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_voltageTooLow' => { 'Response' =>  '7F 22 93' , 'Mode' =>  'strict' , 'Desc' =>  'voltageTooLow' , 'AddrModes' => [ 'physical', 'functional' ]},
					},
	},
#----------------------------------------------------------------------------------#
	'CommunicationControl' => {
					'Service_ID' => '28',
					'Supported_SubFuns' => {
								'EnableRxAndDisableTx' => '01', 
								'EnableRxAndTx' => '00', 
					},
					'NEG_Responses' => {
								'NR_serviceNotSupported' => { 'Response' =>  '7F 28 11' , 'Mode' =>  'strict' , 'Desc' =>  'serviceNotSupported' , 'AddrModes' => [ 'physical' ]},
								'NR_subFunctionNotSupported' => { 'Response' =>  '7F 28 12' , 'Mode' =>  'strict' , 'Desc' =>  'subFunctionNotSupported' , 'AddrModes' => [ 'physical' ]},
								'NR_incorrectMessageLengthOrInvalidFormat' => { 'Response' =>  '7F 28 13' , 'Mode' =>  'strict' , 'Desc' =>  'incorrectMessageLengthOrInvalidFormat' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_busyRepeatRequest' => { 'Response' =>  '7F 28 21' , 'Mode' =>  'strict' , 'Desc' =>  'busyRepeatRequest' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_conditionsNotCorrect' => { 'Response' =>  '7F 28 22' , 'Mode' =>  'strict' , 'Desc' =>  'conditionsNotCorrect' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestOutOfRange' => { 'Response' =>  '7F 28 31' , 'Mode' =>  'strict' , 'Desc' =>  'requestOutOfRange' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestCorrectlyReceived_ResponsePending' => { 'Response' =>  '7F 28 78' , 'Mode' =>  'strict' , 'Desc' =>  'requestCorrectlyReceived_ResponsePending' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_subFunctionNotSupportedInActiveSession' => { 'Response' =>  '7F 28 7E' , 'Mode' =>  'strict' , 'Desc' =>  'subFunctionNotSupportedInActiveSession' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_serviceNotSupportedInActiveSession' => { 'Response' =>  '7F 28 7F' , 'Mode' =>  'strict' , 'Desc' =>  'serviceNotSupportedInActiveSession' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_vehicleSpeedTooHigh' => { 'Response' =>  '7F 28 88' , 'Mode' =>  'strict' , 'Desc' =>  'vehicleSpeedTooHigh' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_voltageTooHigh' => { 'Response' =>  '7F 28 92' , 'Mode' =>  'strict' , 'Desc' =>  'voltageTooHigh' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_voltageTooLow' => { 'Response' =>  '7F 28 93' , 'Mode' =>  'strict' , 'Desc' =>  'voltageTooLow' , 'AddrModes' => [ 'physical', 'functional' ]},
					},
	},
#----------------------------------------------------------------------------------#
	'WriteDataByIdentifier' => {
					'Service_ID' => '2E',
					'Supported_SubFuns' => {
								'DismantlerInfo' => 'FA 07', 
								'ReadWriteEOL' => '60 01', 
								'ReadWriteGenData' => '20 00', 
					},
					'NEG_Responses' => {
								'NR_incorrectMessageLengthOrInvalidFormat' => { 'Response' =>  '7F 2E 13' , 'Mode' =>  'strict' , 'Desc' =>  'incorrectMessageLengthOrInvalidFormat' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_busyRepeatRequest' => { 'Response' =>  '7F 2E 21' , 'Mode' =>  'strict' , 'Desc' =>  'busyRepeatRequest' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_conditionsNotCorrect' => { 'Response' =>  '7F 2E 22' , 'Mode' =>  'strict' , 'Desc' =>  'conditionsNotCorrect' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestOutOfRange' => { 'Response' =>  '7F 2E 31' , 'Mode' =>  'strict' , 'Desc' =>  'requestOutOfRange' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_securityAccessDenied' => { 'Response' =>  '7F 2E 33' , 'Mode' =>  'strict' , 'Desc' =>  'securityAccessDenied' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_generalProgrammingFailure' => { 'Response' =>  '7F 2E 72' , 'Mode' =>  'strict' , 'Desc' =>  'generalProgrammingFailure' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestCorrectlyReceived_ResponsePending' => { 'Response' =>  '7F 2E 78' , 'Mode' =>  'strict' , 'Desc' =>  'requestCorrectlyReceived_ResponsePending' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_serviceNotSupportedInActiveSession' => { 'Response' =>  '7F 2E 7F' , 'Mode' =>  'strict' , 'Desc' =>  'serviceNotSupportedInActiveSession' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_vehicleSpeedTooHigh' => { 'Response' =>  '7F 2E 88' , 'Mode' =>  'strict' , 'Desc' =>  'vehicleSpeedTooHigh' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_voltageTooHigh' => { 'Response' =>  '7F 2E 92' , 'Mode' =>  'strict' , 'Desc' =>  'voltageTooHigh' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_voltageTooLow' => { 'Response' =>  '7F 2E 93' , 'Mode' =>  'strict' , 'Desc' =>  'voltageTooLow' , 'AddrModes' => [ 'physical', 'functional' ]},
					},
	},
#----------------------------------------------------------------------------------#
	'IOControl' => {
					'Service_ID' => '2F',
					'Supported_SubFuns' => {
								'FuncFreezeCurState_InputOutputControl' => '2F 00 02', 
								'FuncResetToDef_InputOutputControl' => '2F 00 01', 
								'FuncShrtTermAdj_InputOutputControl' => '2F 00 03', 
								'RetCtrlToECU_InputOutputControl' => '2F 00 00', 
					},
					'NEG_Responses' => {
								'NR_serviceNotSupported' => { 'Response' =>  '7F 2F 11' , 'Mode' =>  'strict' , 'Desc' =>  'serviceNotSupported' , 'AddrModes' => [ 'physical' ]},
								'NR_subFunctionNotSupported' => { 'Response' =>  '7F 2F 12' , 'Mode' =>  'strict' , 'Desc' =>  'subFunctionNotSupported' , 'AddrModes' => [ 'physical' ]},
								'NR_incorrectMessageLengthOrInvalidFormat' => { 'Response' =>  '7F 2F 13' , 'Mode' =>  'strict' , 'Desc' =>  'incorrectMessageLengthOrInvalidFormat' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_busyRepeatRequest' => { 'Response' =>  '7F 2F 21' , 'Mode' =>  'strict' , 'Desc' =>  'busyRepeatRequest' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_conditionsNotCorrect' => { 'Response' =>  '7F 2F 22' , 'Mode' =>  'strict' , 'Desc' =>  'conditionsNotCorrect' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestOutOfRange' => { 'Response' =>  '7F 2F 31' , 'Mode' =>  'strict' , 'Desc' =>  'requestOutOfRange' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_securityAccessDenied' => { 'Response' =>  '7F 2F 33' , 'Mode' =>  'strict' , 'Desc' =>  'securityAccessDenied' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestCorrectlyReceived_ResponsePending' => { 'Response' =>  '7F 2F 78' , 'Mode' =>  'strict' , 'Desc' =>  'requestCorrectlyReceived_ResponsePending' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_serviceNotSupportedInActiveSession' => { 'Response' =>  '7F 2F 7F' , 'Mode' =>  'strict' , 'Desc' =>  'serviceNotSupportedInActiveSession' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_vehicleSpeedTooHigh' => { 'Response' =>  '7F 2F 88' , 'Mode' =>  'strict' , 'Desc' =>  'vehicleSpeedTooHigh' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_voltageTooHigh' => { 'Response' =>  '7F 2F 92' , 'Mode' =>  'strict' , 'Desc' =>  'voltageTooHigh' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_voltageTooLow' => { 'Response' =>  '7F 2F 93' , 'Mode' =>  'strict' , 'Desc' =>  'voltageTooLow' , 'AddrModes' => [ 'physical', 'functional' ]},
					},
	},
#----------------------------------------------------------------------------------#
	'RoutineControl' => {
					'Service_ID' => '31',
					'Supported_SubFuns' => {
								'RequestResults_CalculateSignatureOrCRC' => '03 E2 10', 
								'RequestRoutineResult_AKLV37' => '03 E2 10', 
								'RequestRoutineResult_VDSCalibration' => '03 60 00', 
								'RequestRoutineResults_DeployLoopRoutineID' => '03 E2 01', 
								'RequestRoutineResults_ExecuteSPL' => '03 E2 00', 
								'StartRoutine_CalculateSignatureOrCRC' => '01 E2 10', 
								'StartRoutine_DeployLoopRoutineID' => '01 E2 01', 
								'StartRoutine_ExecuteSPL' => '01 E2 00', 
								'StopRoutine_AKLV37' => '02 E2 10', 
								'StopRoutine_CalculateSignatureOrCRC' => '02 E2 10', 
								'StopRoutine_DeployLoopRoutineID' => '02 E2 01', 
								'StopRoutine_ExecuteSPL' => '02 E2 00', 
								'StopRoutine_VDSCalibration' => '02 60 00', 
								'startRoutine_AKLV37' => '01 E2 10', 
								'startRoutine_VDSCalibration' => '01 60 00', 
					},
					'NEG_Responses' => {
								'NR_subFunctionNotSupported' => { 'Response' =>  '7F 31 12' , 'Mode' =>  'strict' , 'Desc' =>  'subFunctionNotSupported' , 'AddrModes' => [ 'physical' ]},
								'NR_incorrectMessageLengthOrInvalidFormat' => { 'Response' =>  '7F 31 13' , 'Mode' =>  'strict' , 'Desc' =>  'incorrectMessageLengthOrInvalidFormat' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_busyRepeatRequest' => { 'Response' =>  '7F 31 21' , 'Mode' =>  'strict' , 'Desc' =>  'busyRepeatRequest' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_conditionsNotCorrect' => { 'Response' =>  '7F 31 22' , 'Mode' =>  'strict' , 'Desc' =>  'conditionsNotCorrect' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestSequenceError' => { 'Response' =>  '7F 31 24' , 'Mode' =>  'strict' , 'Desc' =>  'requestSequenceError' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestOutOfRange' => { 'Response' =>  '7F 31 31' , 'Mode' =>  'strict' , 'Desc' =>  'requestOutOfRange' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_securityAccessDenied' => { 'Response' =>  '7F 31 33' , 'Mode' =>  'strict' , 'Desc' =>  'securityAccessDenied' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_generalProgrammingFailure' => { 'Response' =>  '7F 31 72' , 'Mode' =>  'strict' , 'Desc' =>  'generalProgrammingFailure' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestCorrectlyReceived_ResponsePending' => { 'Response' =>  '7F 31 78' , 'Mode' =>  'strict' , 'Desc' =>  'requestCorrectlyReceived_ResponsePending' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_subFunctionNotSupportedInActiveSession' => { 'Response' =>  '7F 31 7E' , 'Mode' =>  'strict' , 'Desc' =>  'subFunctionNotSupportedInActiveSession' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_serviceNotSupportedInActiveSession' => { 'Response' =>  '7F 31 7F' , 'Mode' =>  'strict' , 'Desc' =>  'serviceNotSupportedInActiveSession' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_vehicleSpeedTooHigh' => { 'Response' =>  '7F 31 88' , 'Mode' =>  'strict' , 'Desc' =>  'vehicleSpeedTooHigh' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_voltageTooHigh' => { 'Response' =>  '7F 31 92' , 'Mode' =>  'strict' , 'Desc' =>  'voltageTooHigh' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_voltageTooLow' => { 'Response' =>  '7F 31 93' , 'Mode' =>  'strict' , 'Desc' =>  'voltageTooLow' , 'AddrModes' => [ 'physical', 'functional' ]},
					},
	},
#----------------------------------------------------------------------------------#
	'TesterPresent' => {
					'Service_ID' => '3E',
					'Supported_SubFuns' => {
								'zeroSubfunction' => '00', 
								'zeroSubfunction_ForDisposal' => '00', 
					},
					'NEG_Responses' => {
								'NR_subFunctionNotSupported' => { 'Response' =>  '7F 3E 12' , 'Mode' =>  'strict' , 'Desc' =>  'subFunctionNotSupported' , 'AddrModes' => [ 'physical' ]},
								'NR_incorrectMessageLengthOrInvalidFormat' => { 'Response' =>  '7F 3E 13' , 'Mode' =>  'strict' , 'Desc' =>  'incorrectMessageLengthOrInvalidFormat' , 'AddrModes' => [ 'physical', 'functional' ]},
					},
	},
#----------------------------------------------------------------------------------#
	'ControlDTCSetting' => {
					'Service_ID' => '85',
					'Supported_SubFuns' => {
								'DisableDTCSetting' => '02', 
								'EnableDTCSetting' => '01', 
					},
					'NEG_Responses' => {
								'NR_serviceNotSupported' => { 'Response' =>  '7F 85 11' , 'Mode' =>  'strict' , 'Desc' =>  'serviceNotSupported' , 'AddrModes' => [ 'physical' ]},
								'NR_subFunctionNotSupported' => { 'Response' =>  '7F 85 12' , 'Mode' =>  'strict' , 'Desc' =>  'subFunctionNotSupported' , 'AddrModes' => [ 'physical' ]},
								'NR_incorrectMessageLengthOrInvalidFormat' => { 'Response' =>  '7F 85 13' , 'Mode' =>  'strict' , 'Desc' =>  'incorrectMessageLengthOrInvalidFormat' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_busyRepeatRequest' => { 'Response' =>  '7F 85 21' , 'Mode' =>  'strict' , 'Desc' =>  'busyRepeatRequest' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_conditionsNotCorrect' => { 'Response' =>  '7F 85 22' , 'Mode' =>  'strict' , 'Desc' =>  'conditionsNotCorrect' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestOutOfRange' => { 'Response' =>  '7F 85 31' , 'Mode' =>  'strict' , 'Desc' =>  'requestOutOfRange' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestCorrectlyReceived_ResponsePending' => { 'Response' =>  '7F 85 78' , 'Mode' =>  'strict' , 'Desc' =>  'requestCorrectlyReceived_ResponsePending' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_subFunctionNotSupportedInActiveSession' => { 'Response' =>  '7F 85 7E' , 'Mode' =>  'strict' , 'Desc' =>  'subFunctionNotSupportedInActiveSession' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_serviceNotSupportedInActiveSession' => { 'Response' =>  '7F 85 7F' , 'Mode' =>  'strict' , 'Desc' =>  'serviceNotSupportedInActiveSession' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_vehicleSpeedTooHigh' => { 'Response' =>  '7F 85 88' , 'Mode' =>  'strict' , 'Desc' =>  'vehicleSpeedTooHigh' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_voltageTooHigh' => { 'Response' =>  '7F 85 92' , 'Mode' =>  'strict' , 'Desc' =>  'voltageTooHigh' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_voltageTooLow' => { 'Response' =>  '7F 85 93' , 'Mode' =>  'strict' , 'Desc' =>  'voltageTooLow' , 'AddrModes' => [ 'physical', 'functional' ]},
					},
	},
#----------------------------------------------------------------------------------#

},
##### END OF DIAG_SERVICES Section #######


######### Request Response Section ########

'Requests_Responses' => {

	'ClearDiagnosticInformation_ClearAllDTC' => {
					'Requests' => {
						'REQ_ClearDiagnosticInformation_ClearAllDTC' => {'Request' => '14 FF FF FF', },
					},
					'POS_Responses' => {
						'PR_ClearDiagnosticInformation_ClearAllDTC' => {'DataLength' => '', 'Desc' => 'ClearDiagnosticInformation_ClearAllDTC', 'DoorsIDs' => ['SPS_ConfigTable327'], 'Mode' => 'relax', 'Response' => '54', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'n/a',
	},
#----------------------------------------------------------------------------------#
	'ClearDiagnosticInformation_ClearRequestedDTC' => {
					'Requests' => {
						'REQ_ClearDiagnosticInformation_ClearRequestedDTC' => {'Request' => '14 XX XX XX No te :X XX XX Xi st he DT Ct ob ec le ar ed', },
					},
					'POS_Responses' => {
						'PR_ClearDiagnosticInformation_ClearRequestedDTC' => {'DataLength' => '', 'Desc' => 'ClearDiagnosticInformation_ClearRequestedDTC', 'DoorsIDs' => ['SPS_ConfigTable325'], 'Mode' => 'relax', 'Response' => '54', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'n/a',
	},
#----------------------------------------------------------------------------------#
	'CommunicationControl_EnableRxAndDisableTx' => {
					'Requests' => {
						'REQ_CommunicationControl_EnableRxAndDisableTx' => {'Request' => '28 01 CommunicationType', },
					},
					'POS_Responses' => {
						'PR_CommunicationControl_EnableRxAndDisableTx' => {'DataLength' => '', 'Desc' => 'CommunicationControl_EnableRxAndDisableTx', 'DoorsIDs' => ['SPS_ConfigTable256'], 'Mode' => 'relax', 'Response' => '68 01', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['IdleModeCheck', 'VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'n/a',
	},
#----------------------------------------------------------------------------------#
	'CommunicationControl_EnableRxAndTx' => {
					'Requests' => {
						'REQ_CommunicationControl_EnableRxAndTx' => {'Request' => '28 00 CommunicationType', },
					},
					'POS_Responses' => {
						'PR_CommunicationControl_EnableRxAndTx' => {'DataLength' => '', 'Desc' => 'CommunicationControl_EnableRxAndTx', 'DoorsIDs' => ['SPS_ConfigTable257'], 'Mode' => 'relax', 'Response' => '68 00', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['IdleModeCheck', 'VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'n/a',
	},
#----------------------------------------------------------------------------------#
	'ControlDTCSetting_DisableDTCSetting' => {
					'Requests' => {
						'REQ_ControlDTCSetting_DisableDTCSetting' => {'Request' => '85 02', },
					},
					'POS_Responses' => {
						'PR_ControlDTCSetting_DisableDTCSetting' => {'DataLength' => '', 'Desc' => 'ControlDTCSetting_DisableDTCSetting', 'DoorsIDs' => ['SPS_ConfigTable259'], 'Mode' => 'relax', 'Response' => 'C5 02', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['n/a'],
					'additional_parameter' => 'n/a',
	},
#----------------------------------------------------------------------------------#
	'ControlDTCSetting_EnableDTCSetting' => {
					'Requests' => {
						'REQ_ControlDTCSetting_EnableDTCSetting' => {'Request' => '85 01', },
					},
					'POS_Responses' => {
						'PR_ControlDTCSetting_EnableDTCSetting' => {'DataLength' => '', 'Desc' => 'ControlDTCSetting_EnableDTCSetting', 'DoorsIDs' => ['SPS_ConfigTable258'], 'Mode' => 'relax', 'Response' => 'C5 01', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['n/a'],
					'additional_parameter' => 'n/a',
	},
#----------------------------------------------------------------------------------#
	'DiagnosticSessionControl_DefaultSession' => {
					'Requests' => {
						'REQ_DiagnosticSessionControl_DefaultSession' => {'Request' => '10 01', },
					},
					'POS_Responses' => {
						'PR_DiagnosticSessionControl_DefaultSession' => {'DataLength' => '', 'Desc' => 'DiagnosticSessionControl_DefaultSession', 'DoorsIDs' => ['SPS_ConfigTable218'], 'Mode' => 'relax', 'Response' => '50 01', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['n/a'],
					'additional_parameter' => 'n/a',
	},
#----------------------------------------------------------------------------------#
	'DiagnosticSessionControl_DefaultSession_ForDisposal' => {
					'Requests' => {
						'REQ_DiagnosticSessionControl_DefaultSession_ForDisposal' => {'Request' => '10 01', },
					},
					'POS_Responses' => {
						'PR_DiagnosticSessionControl_DefaultSession_ForDisposal' => {'DataLength' => '', 'Desc' => 'DiagnosticSessionControl_DefaultSession_ForDisposal', 'DoorsIDs' => ['SPS_ConfigTable124'], 'Mode' => 'relax', 'Response' => '50 01', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'SafetySession'],
					'allowed_in_addressingmodes' => ['disposal'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'n/a',
	},
#----------------------------------------------------------------------------------#
	'DiagnosticSessionControl_ExtendedSession' => {
					'Requests' => {
						'REQ_DiagnosticSessionControl_ExtendedSession' => {'Request' => '10 03', },
					},
					'POS_Responses' => {
						'PR_DiagnosticSessionControl_ExtendedSession' => {'DataLength' => '', 'Desc' => 'DiagnosticSessionControl_ExtendedSession', 'DoorsIDs' => ['SPS_ConfigTable219'], 'Mode' => 'relax', 'Response' => '50 03', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['n/a'],
					'additional_parameter' => 'n/a',
	},
#----------------------------------------------------------------------------------#
	'DiagnosticSessionControl_SafetySession' => {
					'Requests' => {
						'REQ_DiagnosticSessionControl_SafetySession' => {'Request' => '10 04', },
					},
					'POS_Responses' => {
						'PR_DiagnosticSessionControl_SafetySession' => {'DataLength' => '', 'Desc' => 'DiagnosticSessionControl_SafetySession', 'DoorsIDs' => ['SPS_ConfigTable125'], 'Mode' => 'relax', 'Response' => '50 04', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['IdleModeCheck', 'VehicleSpeedTooHighCheck', 'InitTestNotCompletedCheck', 'ProductionModeActiveCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'SafetySession'],
					'allowed_in_addressingmodes' => ['disposal'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'n/a',
	},
#----------------------------------------------------------------------------------#
	'ECUReset_HARD' => {
					'Requests' => {
						'REQ_ECUReset_HARD' => {'Request' => '11 01', },
					},
					'POS_Responses' => {
						'PR_ECUReset_HARD' => {'DataLength' => '', 'Desc' => 'ECUReset_HARD', 'DoorsIDs' => ['SPS_ConfigTable246'], 'Mode' => 'relax', 'Response' => '51 01', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['n/a'],
					'additional_parameter' => 'rb_der_NormalHardReset_e',
	},
#----------------------------------------------------------------------------------#
	'ECUReset_HardReset_ForDisposal' => {
					'Requests' => {
						'REQ_ECUReset_HardReset_ForDisposal' => {'Request' => '11 01', },
					},
					'POS_Responses' => {
						'PR_ECUReset_HardReset_ForDisposal' => {'DataLength' => '', 'Desc' => 'ECUReset_HardReset_ForDisposal', 'DoorsIDs' => ['SPS_ConfigTable129'], 'Mode' => 'relax', 'Response' => '51 01', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['SafetySession'],
					'allowed_in_addressingmodes' => ['disposal'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'rb_der_NormalHardReset_e ',
	},
#----------------------------------------------------------------------------------#
	'ECUReset_SOFT' => {
					'Requests' => {
						'REQ_ECUReset_SOFT' => {'Request' => '11 03', },
					},
					'POS_Responses' => {
						'PR_ECUReset_SOFT' => {'DataLength' => '', 'Desc' => 'ECUReset_SOFT', 'DoorsIDs' => ['SPS_ConfigTable244'], 'Mode' => 'relax', 'Response' => '51 03', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['n/a'],
					'additional_parameter' => 'rb_der_NormalSoftReset_e',
	},
#----------------------------------------------------------------------------------#
	'ECUReset_SystemSupplierHardReset' => {
					'Requests' => {
						'REQ_ECUReset_SystemSupplierHardReset' => {'Request' => '11 60', },
					},
					'POS_Responses' => {
						'PR_ECUReset_SystemSupplierHardReset' => {'DataLength' => '', 'Desc' => 'ECUReset_SystemSupplierHardReset', 'DoorsIDs' => ['SPS_ConfigTable243'], 'Mode' => 'relax', 'Response' => '51 60', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['n/a'],
					'additional_parameter' => 'rb_der_FastHardReset_e',
	},
#----------------------------------------------------------------------------------#
	'ECUReset_SystemSupplierSoftReset' => {
					'Requests' => {
						'REQ_ECUReset_SystemSupplierSoftReset' => {'Request' => '11 63', },
					},
					'POS_Responses' => {
						'PR_ECUReset_SystemSupplierSoftReset' => {'DataLength' => '', 'Desc' => 'ECUReset_SystemSupplierSoftReset', 'DoorsIDs' => ['SPS_ConfigTable242'], 'Mode' => 'relax', 'Response' => '51 63', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['n/a'],
					'additional_parameter' => 'rb_der_FastSoftReset_e',
	},
#----------------------------------------------------------------------------------#
	'IOControl_FuncFreezeCurState_InputOutputControl' => {
					'Requests' => {
						'REQ_IOControl_FuncFreezeCurState_InputOutputControl' => {'Request' => '2F 2F 00 02', },
					},
					'POS_Responses' => {
						'PR_IOControl_FuncFreezeCurState_InputOutputControl' => {'DataLength' => '', 'Desc' => 'IOControl_FuncFreezeCurState_InputOutputControl', 'DoorsIDs' => ['SPS_ConfigTable310'], 'Mode' => 'relax', 'Response' => '6F 2F 00 02', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['Level1'],
					'additional_parameter' => '0x0101,',
	},
#----------------------------------------------------------------------------------#
	'IOControl_FuncResetToDef_InputOutputControl' => {
					'Requests' => {
						'REQ_IOControl_FuncResetToDef_InputOutputControl' => {'Request' => '2F 2F 00 01', },
					},
					'POS_Responses' => {
						'PR_IOControl_FuncResetToDef_InputOutputControl' => {'DataLength' => '', 'Desc' => 'IOControl_FuncResetToDef_InputOutputControl', 'DoorsIDs' => ['SPS_ConfigTable309'], 'Mode' => 'relax', 'Response' => '6F 2F 00 01', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['AlgoIsActiveOrCrashStorageInProgressCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['Level1'],
					'additional_parameter' => '0x0101,',
	},
#----------------------------------------------------------------------------------#
	'IOControl_FuncShrtTermAdj_InputOutputControl' => {
					'Requests' => {
						'REQ_IOControl_FuncShrtTermAdj_InputOutputControl' => {'Request' => '2F 2F 00 03', },
					},
					'POS_Responses' => {
						'PR_IOControl_FuncShrtTermAdj_InputOutputControl' => {'DataLength' => '', 'Desc' => 'IOControl_FuncShrtTermAdj_InputOutputControl', 'DoorsIDs' => ['SPS_ConfigTable311'], 'Mode' => 'relax', 'Response' => '6F 2F 00 03', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['AlgoIsActiveOrCrashStorageInProgressCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['Level1'],
					'additional_parameter' => '0x0101,',
	},
#----------------------------------------------------------------------------------#
	'IOControl_RetCtrlToECU_InputOutputControl' => {
					'Requests' => {
						'REQ_IOControl_RetCtrlToECU_InputOutputControl' => {'Request' => '2F 2F 00 00', },
					},
					'POS_Responses' => {
						'PR_IOControl_RetCtrlToECU_InputOutputControl' => {'DataLength' => '', 'Desc' => 'IOControl_RetCtrlToECU_InputOutputControl', 'DoorsIDs' => ['SPS_ConfigTable307'], 'Mode' => 'relax', 'Response' => '6F 2F 00 00', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['AlgoIsActiveOrCrashStorageInProgressCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['Level1'],
					'additional_parameter' => '0x0101',
	},
#----------------------------------------------------------------------------------#
	'ReadDTCInformation_ReportDtcSnapshotRecordByDtcNumber' => {
					'Requests' => {
						'REQ_ReadDTCInformation_ReportDtcSnapshotRecordByDtcNumber' => {'Request' => '19 04 DTC DTCSnapshotRecordNumber', },
					},
					'POS_Responses' => {
						'PR_ReadDTCInformation_ReportDtcSnapshotRecordByDtcNumber' => {'DataLength' => '', 'Desc' => 'ReadDTCInformation_ReportDtcSnapshotRecordByDtcNumber', 'DoorsIDs' => ['SPS_ConfigTable248'], 'Mode' => 'relax', 'Response' => '59 04', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['n/a'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['n/a'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'n/a',
	},
#----------------------------------------------------------------------------------#
	'ReadDTCInformation_ReportDtcsByStatusMask' => {
					'Requests' => {
						'REQ_ReadDTCInformation_ReportDtcsByStatusMask' => {'Request' => '19 02 StatusMask', },
					},
					'POS_Responses' => {
						'PR_ReadDTCInformation_ReportDtcsByStatusMask' => {'DataLength' => '', 'Desc' => 'ReadDTCInformation_ReportDtcsByStatusMask', 'DoorsIDs' => ['SPS_ConfigTable250'], 'Mode' => 'relax', 'Response' => '59 02', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['n/a'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['n/a'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'n/a',
	},
#----------------------------------------------------------------------------------#
	'ReadDTCInformation_ReportNumberOfDtcByStatusMask' => {
					'Requests' => {
						'REQ_ReadDTCInformation_ReportNumberOfDtcByStatusMask' => {'Request' => '19 01 StatusMask', },
					},
					'POS_Responses' => {
						'PR_ReadDTCInformation_ReportNumberOfDtcByStatusMask' => {'DataLength' => '', 'Desc' => 'ReadDTCInformation_ReportNumberOfDtcByStatusMask', 'DoorsIDs' => ['SPS_ConfigTable251'], 'Mode' => 'relax', 'Response' => '59 01', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['n/a'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['n/a'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'n/a',
	},
#----------------------------------------------------------------------------------#
	'ReadDTCInformation_ReportSupportedDtcs' => {
					'Requests' => {
						'REQ_ReadDTCInformation_ReportSupportedDtcs' => {'Request' => '19 0A', },
					},
					'POS_Responses' => {
						'PR_ReadDTCInformation_ReportSupportedDtcs' => {'DataLength' => '', 'Desc' => 'ReadDTCInformation_ReportSupportedDtcs', 'DoorsIDs' => ['SPS_ConfigTable249'], 'Mode' => 'relax', 'Response' => '59 0A', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['n/a'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['n/a'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'n/a',
	},
#----------------------------------------------------------------------------------#
	'ReadDTCInformation_RepotDtcExtDataRecordByDtcNumber' => {
					'Requests' => {
						'REQ_ReadDTCInformation_RepotDtcExtDataRecordByDtcNumber' => {'Request' => '19 06 DTC DTCExtendedDataRecordNumber', },
					},
					'POS_Responses' => {
						'PR_ReadDTCInformation_RepotDtcExtDataRecordByDtcNumber' => {'DataLength' => '', 'Desc' => 'ReadDTCInformation_RepotDtcExtDataRecordByDtcNumber', 'DoorsIDs' => ['SPS_ConfigTable247'], 'Mode' => 'relax', 'Response' => '59 06', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['n/a'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['n/a'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'n/a',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_ActDiagSession' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_ActDiagSession' => {'Request' => '22 F1 86', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_ActDiagSession' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_ActDiagSession', 'DoorsIDs' => ['SPS_ConfigTable286'], 'Mode' => 'relax', 'Response' => '62 F1 86', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => '0x0000,',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_AddressInformation' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_AddressInformation' => {'Request' => '22 FA 12', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_AddressInformation' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_AddressInformation', 'DoorsIDs' => ['SPS_ConfigTable165'], 'Mode' => 'relax', 'Response' => '62 FA 12', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['Choose precondition(s) (multi selection)'],
					'allowed_in_sessions' => ['DefaultSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'none',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_AddressInformationOfPCU' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_AddressInformationOfPCU' => {'Request' => '22 FA 02', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_AddressInformationOfPCU' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_AddressInformationOfPCU', 'DoorsIDs' => ['SPS_ConfigTable136'], 'Mode' => 'relax', 'Response' => '62 FA 02', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['IdleModeCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'SafetySession'],
					'allowed_in_addressingmodes' => ['disposal'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'rb_drdi_DIDFA02_e',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_CnEDRdata01' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_CnEDRdata01' => {'Request' => '22 FA 13', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_CnEDRdata01' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_CnEDRdata01', 'DoorsIDs' => ['SPS_ConfigTable298'], 'Mode' => 'relax', 'Response' => '62 FA 13', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['AlgoIsActiveOrCrashStorageInProgressCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'rb_drdi_DIDReadCrashData_e,',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_CnEDRdata02' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_CnEDRdata02' => {'Request' => '22 FA 14', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_CnEDRdata02' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_CnEDRdata02', 'DoorsIDs' => ['SPS_ConfigTable297'], 'Mode' => 'relax', 'Response' => '62 FA 14', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['AlgoIsActiveOrCrashStorageInProgressCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'rb_drdi_DIDReadCrashData_e,',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_CnEDRdata03' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_CnEDRdata03' => {'Request' => '22 FA 15', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_CnEDRdata03' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_CnEDRdata03', 'DoorsIDs' => ['SPS_ConfigTable296'], 'Mode' => 'relax', 'Response' => '62 FA 15', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['AlgoIsActiveOrCrashStorageInProgressCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'rb_drdi_DIDReadCrashData_e,',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_DeploymentLoopTable' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_DeploymentLoopTable' => {'Request' => '22 FA 06', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_DeploymentLoopTable' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_DeploymentLoopTable', 'DoorsIDs' => ['SPS_ConfigTable137'], 'Mode' => 'relax', 'Response' => '62 FA 06', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'SafetySession'],
					'allowed_in_addressingmodes' => ['disposal'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'rb_drdi_DIDFA06_e',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_DeploymentMethodVersion' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_DeploymentMethodVersion' => {'Request' => '22 FA 01', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_DeploymentMethodVersion' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_DeploymentMethodVersion', 'DoorsIDs' => ['SPS_ConfigTable135'], 'Mode' => 'relax', 'Response' => '62 FA 01', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['IdleModeCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'SafetySession'],
					'allowed_in_addressingmodes' => ['disposal'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => '0x0000',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_DismantlerInfo' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_DismantlerInfo' => {'Request' => '22 FA 07', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_DismantlerInfo' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_DismantlerInfo', 'DoorsIDs' => ['SPS_ConfigTable138'], 'Mode' => 'relax', 'Response' => '62 FA 07', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['IdleModeCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'SafetySession'],
					'allowed_in_addressingmodes' => ['disposal'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => '0x0000',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_EDREntry01' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_EDREntry01' => {'Request' => '22 FA 13', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_EDREntry01' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_EDREntry01', 'DoorsIDs' => ['SPS_ConfigTable166'], 'Mode' => 'relax', 'Response' => '62 FA 13', },
					},
					'protocol' => 'Choose protocol',
					'preconditions_prohibiting_execution' => ['AlgoIsActiveOrCrashStorageInProgressCheck', 'AKLV37CrashDataReadValiditycheck'],
					'allowed_in_sessions' => ['Choosesession(s)(multiselection)', 'DefaultSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'none',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_EDREntry02' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_EDREntry02' => {'Request' => '22 FA 14', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_EDREntry02' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_EDREntry02', 'DoorsIDs' => ['SPS_ConfigTable167'], 'Mode' => 'relax', 'Response' => '62 FA 14', },
					},
					'protocol' => 'Choose protocol',
					'preconditions_prohibiting_execution' => ['AlgoIsActiveOrCrashStorageInProgressCheck', 'AKLV37CrashDataReadValiditycheck'],
					'allowed_in_sessions' => ['Choosesession(s)(multiselection)', 'DefaultSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'none',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_EDREntry03' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_EDREntry03' => {'Request' => '22 FA 15', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_EDREntry03' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_EDREntry03', 'DoorsIDs' => ['SPS_ConfigTable168'], 'Mode' => 'relax', 'Response' => '62 FA 15', },
					},
					'protocol' => 'Choose protocol',
					'preconditions_prohibiting_execution' => ['AlgoIsActiveOrCrashStorageInProgressCheck', 'AKLV37CrashDataReadValiditycheck'],
					'allowed_in_sessions' => ['Choosesession(s)(multiselection)', 'DefaultSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'none',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_EDREntry04' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_EDREntry04' => {'Request' => '22 FA 16', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_EDREntry04' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_EDREntry04', 'DoorsIDs' => ['SPS_ConfigTable169'], 'Mode' => 'relax', 'Response' => '62 FA 16', },
					},
					'protocol' => 'Choose protocol',
					'preconditions_prohibiting_execution' => ['AlgoIsActiveOrCrashStorageInProgressCheck', 'AKLV37CrashDataReadValiditycheck'],
					'allowed_in_sessions' => ['Choosesession(s)(multiselection)', 'DefaultSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'none',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_EDREntry05' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_EDREntry05' => {'Request' => '22 FA 17', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_EDREntry05' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_EDREntry05', 'DoorsIDs' => ['SPS_ConfigTable170'], 'Mode' => 'relax', 'Response' => '62 FA 17', },
					},
					'protocol' => 'Choose protocol',
					'preconditions_prohibiting_execution' => ['AlgoIsActiveOrCrashStorageInProgressCheck', 'AKLV37CrashDataReadValiditycheck'],
					'allowed_in_sessions' => ['Choosesession(s)(multiselection)', 'DefaultSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'none',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_EDREntry06' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_EDREntry06' => {'Request' => '22 FA 18', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_EDREntry06' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_EDREntry06', 'DoorsIDs' => ['SPS_ConfigTable171'], 'Mode' => 'relax', 'Response' => '62 FA 18', },
					},
					'protocol' => 'Choose protocol',
					'preconditions_prohibiting_execution' => ['AlgoIsActiveOrCrashStorageInProgressCheck', 'AKLV37CrashDataReadValiditycheck'],
					'allowed_in_sessions' => ['Choosesession(s)(multiselection)', 'DefaultSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'none',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_EDRIdentification' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_EDRIdentification' => {'Request' => '22 FA 11', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_EDRIdentification' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_EDRIdentification', 'DoorsIDs' => ['SPS_ConfigTable164'], 'Mode' => 'relax', 'Response' => '62 FA 11', },
					},
					'protocol' => 'Choose protocol',
					'preconditions_prohibiting_execution' => ['Choose precondition(s) (multi selection)'],
					'allowed_in_sessions' => ['Choosesession(s)(multiselection)'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'none',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_NumberOfEDRDevices' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_NumberOfEDRDevices' => {'Request' => '22 FA 10', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_NumberOfEDRDevices' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_NumberOfEDRDevices', 'DoorsIDs' => ['SPS_ConfigTable163'], 'Mode' => 'relax', 'Response' => '62 FA 10', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['Choose precondition(s) (multi selection)'],
					'allowed_in_sessions' => ['DefaultSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'none',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_NumberOfPCU' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_NumberOfPCU' => {'Request' => '22 FA 00', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_NumberOfPCU' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_NumberOfPCU', 'DoorsIDs' => ['SPS_ConfigTable134'], 'Mode' => 'relax', 'Response' => '62 FA 00', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['IdleModeCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'SafetySession'],
					'allowed_in_addressingmodes' => ['disposal'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => '0x0000',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_OEMEDREntry01' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_OEMEDREntry01' => {'Request' => '22 10 13', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_OEMEDREntry01' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_OEMEDREntry01', 'DoorsIDs' => ['SPS_ConfigTable294'], 'Mode' => 'relax', 'Response' => '62 10 13', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['AlgoIsActiveOrCrashStorageInProgressCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'rb_drdi_DIDReadCrashData_e,',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_OEMEDREntry02' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_OEMEDREntry02' => {'Request' => '22 10 14', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_OEMEDREntry02' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_OEMEDREntry02', 'DoorsIDs' => ['SPS_ConfigTable302'], 'Mode' => 'relax', 'Response' => '62 10 14', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['AlgoIsActiveOrCrashStorageInProgressCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'rb_drdi_DIDReadCrashData_e,',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_OEMEDREntry03' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_OEMEDREntry03' => {'Request' => '22 10 15', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_OEMEDREntry03' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_OEMEDREntry03', 'DoorsIDs' => ['SPS_ConfigTable303'], 'Mode' => 'relax', 'Response' => '62 10 15', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['AlgoIsActiveOrCrashStorageInProgressCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'rb_drdi_DIDReadCrashData_e,',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_OEMEDREntry04' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_OEMEDREntry04' => {'Request' => '22 10 16', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_OEMEDREntry04' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_OEMEDREntry04', 'DoorsIDs' => ['SPS_ConfigTable301'], 'Mode' => 'relax', 'Response' => '62 10 16', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['AlgoIsActiveOrCrashStorageInProgressCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'rb_drdi_DIDReadCrashData_e,',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_OEMEDREntry05' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_OEMEDREntry05' => {'Request' => '22 10 17', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_OEMEDREntry05' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_OEMEDREntry05', 'DoorsIDs' => ['SPS_ConfigTable300'], 'Mode' => 'relax', 'Response' => '62 10 17', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['AlgoIsActiveOrCrashStorageInProgressCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'rb_drdi_DIDReadCrashData_e,',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_OEMEDREntry06' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_OEMEDREntry06' => {'Request' => '22 10 18', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_OEMEDREntry06' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_OEMEDREntry06', 'DoorsIDs' => ['SPS_ConfigTable299'], 'Mode' => 'relax', 'Response' => '62 10 18', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['AlgoIsActiveOrCrashStorageInProgressCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'rb_drdi_DIDReadCrashData_e,',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_OEMSpecificAddressInformation' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_OEMSpecificAddressInformation' => {'Request' => '22 10 12', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_OEMSpecificAddressInformation' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_OEMSpecificAddressInformation', 'DoorsIDs' => ['SPS_ConfigTable184'], 'Mode' => 'relax', 'Response' => '62 10 12', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['Choose precondition(s) (multi selection)'],
					'allowed_in_sessions' => ['Choosesession(s)(multiselection)'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'none',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_OEMSpecificEDREntry01' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_OEMSpecificEDREntry01' => {'Request' => '22 10 13', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_OEMSpecificEDREntry01' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_OEMSpecificEDREntry01', 'DoorsIDs' => ['SPS_ConfigTable185'], 'Mode' => 'relax', 'Response' => '62 10 13', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['AlgoIsActiveOrCrashStorageInProgressCheck', 'AKLV37CrashDataReadValiditycheck'],
					'allowed_in_sessions' => ['Choosesession(s)(multiselection)'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['Choosesecuritylevel'],
					'additional_parameter' => 'none',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_OEMSpecificEDREntry02' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_OEMSpecificEDREntry02' => {'Request' => '22 10 14', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_OEMSpecificEDREntry02' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_OEMSpecificEDREntry02', 'DoorsIDs' => ['SPS_ConfigTable186'], 'Mode' => 'relax', 'Response' => '62 10 14', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['AlgoIsActiveOrCrashStorageInProgressCheck', 'AKLV37CrashDataReadValiditycheck'],
					'allowed_in_sessions' => ['Choosesession(s)(multiselection)'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['Choosesecuritylevel'],
					'additional_parameter' => 'none',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_OEMSpecificEDREntry03' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_OEMSpecificEDREntry03' => {'Request' => '22 10 15', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_OEMSpecificEDREntry03' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_OEMSpecificEDREntry03', 'DoorsIDs' => ['SPS_ConfigTable187'], 'Mode' => 'relax', 'Response' => '62 10 15', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['AlgoIsActiveOrCrashStorageInProgressCheck', 'AKLV37CrashDataReadValiditycheck'],
					'allowed_in_sessions' => ['Choosesession(s)(multiselection)'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['Choosesecuritylevel'],
					'additional_parameter' => 'none',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_OEMSpecificEDREntry04' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_OEMSpecificEDREntry04' => {'Request' => '22 10 16', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_OEMSpecificEDREntry04' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_OEMSpecificEDREntry04', 'DoorsIDs' => ['SPS_ConfigTable188'], 'Mode' => 'relax', 'Response' => '62 10 16', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['AlgoIsActiveOrCrashStorageInProgressCheck', 'AKLV37CrashDataReadValiditycheck'],
					'allowed_in_sessions' => ['Choosesession(s)(multiselection)'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['Choosesecuritylevel'],
					'additional_parameter' => 'none',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_OEMSpecificEDREntry05' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_OEMSpecificEDREntry05' => {'Request' => '22 10 17', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_OEMSpecificEDREntry05' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_OEMSpecificEDREntry05', 'DoorsIDs' => ['SPS_ConfigTable189'], 'Mode' => 'relax', 'Response' => '62 10 17', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['AlgoIsActiveOrCrashStorageInProgressCheck', 'AKLV37CrashDataReadValiditycheck'],
					'allowed_in_sessions' => ['Choosesession(s)(multiselection)'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['Choosesecuritylevel'],
					'additional_parameter' => 'none',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_OEMSpecificEDREntry06' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_OEMSpecificEDREntry06' => {'Request' => '22 10 18', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_OEMSpecificEDREntry06' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_OEMSpecificEDREntry06', 'DoorsIDs' => ['SPS_ConfigTable190'], 'Mode' => 'relax', 'Response' => '62 10 18', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['AlgoIsActiveOrCrashStorageInProgressCheck', 'AKLV37CrashDataReadValiditycheck'],
					'allowed_in_sessions' => ['Choosesession(s)(multiselection)'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['Choosesecuritylevel'],
					'additional_parameter' => 'none',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_OEMSpecificEDRIdentification' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_OEMSpecificEDRIdentification' => {'Request' => '22 10 11', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_OEMSpecificEDRIdentification' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_OEMSpecificEDRIdentification', 'DoorsIDs' => ['SPS_ConfigTable183'], 'Mode' => 'relax', 'Response' => '62 10 11', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['Choose precondition(s) (multi selection)'],
					'allowed_in_sessions' => ['Choosesession(s)(multiselection)'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'none',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_OEMSpecificNumberOfEDRDevices' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_OEMSpecificNumberOfEDRDevices' => {'Request' => '22 10 10', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_OEMSpecificNumberOfEDRDevices' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_OEMSpecificNumberOfEDRDevices', 'DoorsIDs' => ['SPS_ConfigTable182'], 'Mode' => 'relax', 'Response' => '62 10 10', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['Choose precondition(s) (multi selection)'],
					'allowed_in_sessions' => ['Choosesession(s)(multiselection)'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'none',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_OEMspecificAddressInformation' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_OEMspecificAddressInformation' => {'Request' => '22 10 12', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_OEMspecificAddressInformation' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_OEMspecificAddressInformation', 'DoorsIDs' => ['SPS_ConfigTable292'], 'Mode' => 'relax', 'Response' => '62 10 12', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'rb_drdi_DIDReadCrashData_e',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_OEMspecificEDRIdentification' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_OEMspecificEDRIdentification' => {'Request' => '22 10 11', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_OEMspecificEDRIdentification' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_OEMspecificEDRIdentification', 'DoorsIDs' => ['SPS_ConfigTable265'], 'Mode' => 'relax', 'Response' => '62 10 11', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => '(uint16)0x0000u',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_ReadBatteryVoltage' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_ReadBatteryVoltage' => {'Request' => '22 D1 12', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_ReadBatteryVoltage' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_ReadBatteryVoltage', 'DoorsIDs' => ['SPS_ConfigTable287'], 'Mode' => 'relax', 'Response' => '62 D1 12', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'RB_drdi_VBATvoltage_cu8',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_ReadCrash' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_ReadCrash' => {'Request' => '22 FA 10', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_ReadCrash' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_ReadCrash', 'DoorsIDs' => ['SPS_ConfigTable290'], 'Mode' => 'relax', 'Response' => '62 FA 10', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession', 'SafetySession'],
					'allowed_in_addressingmodes' => ['disposal'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => '0x0000',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_ReadEnergyReserve' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_ReadEnergyReserve' => {'Request' => '22 5B 02', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_ReadEnergyReserve' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_ReadEnergyReserve', 'DoorsIDs' => ['SPS_ConfigTable284'], 'Mode' => 'relax', 'Response' => '62 5B 02', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'RB_drdi_VERvoltage_cu8',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_ReadSenSerNrPasFD' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_ReadSenSerNrPasFD' => {'Request' => '22 50 03', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_ReadSenSerNrPasFD' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_ReadSenSerNrPasFD', 'DoorsIDs' => ['SPS_ConfigTable282'], 'Mode' => 'relax', 'Response' => '62 50 03', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'RB_drdi_SensorType(rb_sycp_PasFD_e)',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_ReadSenSerNrPasFP' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_ReadSenSerNrPasFP' => {'Request' => '22 50 04', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_ReadSenSerNrPasFP' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_ReadSenSerNrPasFP', 'DoorsIDs' => ['SPS_ConfigTable283'], 'Mode' => 'relax', 'Response' => '62 50 04', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'RB_drdi_SensorType(rb_sycp_PasFP_e)',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_ReadSenSerNrUfsD' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_ReadSenSerNrUfsD' => {'Request' => '22 50 00', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_ReadSenSerNrUfsD' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_ReadSenSerNrUfsD', 'DoorsIDs' => ['SPS_ConfigTable278'], 'Mode' => 'relax', 'Response' => '62 50 00', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'RB_drdi_SensorType(rb_sycp_UfsD_e)',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_ReadSenSerNrUfsp' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_ReadSenSerNrUfsp' => {'Request' => '22 50 01', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_ReadSenSerNrUfsp' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_ReadSenSerNrUfsp', 'DoorsIDs' => ['SPS_ConfigTable277'], 'Mode' => 'relax', 'Response' => '62 50 01', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'RB_drdi_SensorType(rb_sycp_UfsP_e)',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_ReadSquibResAB1FD' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_ReadSquibResAB1FD' => {'Request' => '22 30 00', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_ReadSquibResAB1FD' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_ReadSquibResAB1FD', 'DoorsIDs' => ['SPS_ConfigTable267'], 'Mode' => 'relax', 'Response' => '62 30 00', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'RB_drdi_SquibType(rb_sycf_AB1FD_e)',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_ReadSquibResAB2FD' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_ReadSquibResAB2FD' => {'Request' => '22 30 01', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_ReadSquibResAB2FD' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_ReadSquibResAB2FD', 'DoorsIDs' => ['SPS_ConfigTable268'], 'Mode' => 'relax', 'Response' => '62 30 01', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'RB_drdi_SquibType(rb_sycf_AB2FD_e)',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_ReadSquibStsAB1FD' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_ReadSquibStsAB1FD' => {'Request' => '22 31 00', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_ReadSquibStsAB1FD' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_ReadSquibStsAB1FD', 'DoorsIDs' => ['SPS_ConfigTable269'], 'Mode' => 'relax', 'Response' => '62 31 00', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'RB_drdi_SquibType(rb_sycf_AB1FD_e)',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_ReadSquibStsAB2FD' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_ReadSquibStsAB2FD' => {'Request' => '22 31 01', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_ReadSquibStsAB2FD' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_ReadSquibStsAB2FD', 'DoorsIDs' => ['SPS_ConfigTable270'], 'Mode' => 'relax', 'Response' => '62 31 01', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'RB_drdi_SquibType(rb_sycf_AB2FD_e)',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_ReadSwitchMesBLFD' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_ReadSwitchMesBLFD' => {'Request' => '22 40 00', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_ReadSwitchMesBLFD' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_ReadSwitchMesBLFD', 'DoorsIDs' => ['SPS_ConfigTable272'], 'Mode' => 'relax', 'Response' => '62 40 00', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'RB_drdi_SwitchType(rb_drdi_SwitchFunctionalityBeltLock_e, rb_sycs_SwitchBLFD_e)',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_ReadSwitchMesBLFP' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_ReadSwitchMesBLFP' => {'Request' => '22 40 01', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_ReadSwitchMesBLFP' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_ReadSwitchMesBLFP', 'DoorsIDs' => ['SPS_ConfigTable273'], 'Mode' => 'relax', 'Response' => '62 40 01', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'RB_drdi_SwitchType(rb_drdi_SwitchFunctionalityBeltLock_e, rb_sycs_SwitchBLFP_e)',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_ReadSwitchMesBLR2D' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_ReadSwitchMesBLR2D' => {'Request' => '22 40 03', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_ReadSwitchMesBLR2D' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_ReadSwitchMesBLR2D', 'DoorsIDs' => ['SPS_ConfigTable274'], 'Mode' => 'relax', 'Response' => '62 40 03', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'RB_drdi_SwitchType(rb_drdi_SwitchFunctionalityBeltLock_e, rb_sycs_SwitchBLR2D_e)',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_ReadSwitchMesSPSFD' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_ReadSwitchMesSPSFD' => {'Request' => '22 40 09', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_ReadSwitchMesSPSFD' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_ReadSwitchMesSPSFD', 'DoorsIDs' => ['SPS_ConfigTable275'], 'Mode' => 'relax', 'Response' => '62 40 09', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'RB_drdi_SwitchType(rb_drdi_SwitchFunctionalitySeatPosition_e, rb_sycs_SwitchSPSFD_e)',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_ReadSwitchStsBLFD' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_ReadSwitchStsBLFD' => {'Request' => '22 41 00', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_ReadSwitchStsBLFD' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_ReadSwitchStsBLFD', 'DoorsIDs' => ['SPS_ConfigTable276'], 'Mode' => 'relax', 'Response' => '62 41 00', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'RB_drdi_SwitchType(rb_drdi_SwitchFunctionalityBeltLock_e, rb_sycs_SwitchBLFD_e)',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_ReadSwitchStsBLFP' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_ReadSwitchStsBLFP' => {'Request' => '22 41 01', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_ReadSwitchStsBLFP' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_ReadSwitchStsBLFP', 'DoorsIDs' => ['SPS_ConfigTable281'], 'Mode' => 'relax', 'Response' => '62 41 01', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'RB_drdi_SwitchType(rb_drdi_SwitchFunctionalityBeltLock_e, rb_sycs_SwitchBLFP_e)',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_ReadSwitchStsBLR2D' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_ReadSwitchStsBLR2D' => {'Request' => '22 41 03', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_ReadSwitchStsBLR2D' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_ReadSwitchStsBLR2D', 'DoorsIDs' => ['SPS_ConfigTable280'], 'Mode' => 'relax', 'Response' => '62 41 03', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession', '---'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'RB_drdi_SwitchType(rb_drdi_SwitchFunctionalityBeltLock_e, rb_sycs_SwitchBLR2D_e)',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_ReadSwitchStsSPSFD' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_ReadSwitchStsSPSFD' => {'Request' => '22 41 09', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_ReadSwitchStsSPSFD' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_ReadSwitchStsSPSFD', 'DoorsIDs' => ['SPS_ConfigTable279'], 'Mode' => 'relax', 'Response' => '62 41 09', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'RB_drdi_SwitchType(rb_drdi_SwitchFunctionalitySeatPosition_e, rb_sycs_SwitchSPSFD_e)',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_ReadVIN' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_ReadVIN' => {'Request' => '22 F1 90', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_ReadVIN' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_ReadVIN', 'DoorsIDs' => ['SPS_ConfigTable288'], 'Mode' => 'relax', 'Response' => '62 F1 90', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession', 'SafetySession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => '0x0000,',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_ReadWriteEOL' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_ReadWriteEOL' => {'Request' => '22 60 01', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_ReadWriteEOL' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_ReadWriteEOL', 'DoorsIDs' => ['SPS_ConfigTable285'], 'Mode' => 'relax', 'Response' => '62 60 01', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => '0x0000',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_ReadWriteGenData' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_ReadWriteGenData' => {'Request' => '22 20 00', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_ReadWriteGenData' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_ReadWriteGenData', 'DoorsIDs' => ['SPS_ConfigTable266'], 'Mode' => 'relax', 'Response' => '62 20 00', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'rb_drdi_DID2000_e',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_SupplierEDREntry01' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_SupplierEDREntry01' => {'Request' => '22 11 13', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_SupplierEDREntry01' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_SupplierEDREntry01', 'DoorsIDs' => ['SPS_ConfigTable320'], 'Mode' => 'relax', 'Response' => '62 11 13', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['AlgoIsActiveOrCrashStorageInProgressCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'rb_drdi_DIDReadCrashData_e,',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_SupplierEDREntry02' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_SupplierEDREntry02' => {'Request' => '22 11 14', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_SupplierEDREntry02' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_SupplierEDREntry02', 'DoorsIDs' => ['SPS_ConfigTable321'], 'Mode' => 'relax', 'Response' => '62 11 14', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['AlgoIsActiveOrCrashStorageInProgressCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'rb_drdi_DIDReadCrashData_e,',
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_SupplierEDREntry03' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_SupplierEDREntry03' => {'Request' => '22 11 15', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_SupplierEDREntry03' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_SupplierEDREntry03', 'DoorsIDs' => ['SPS_ConfigTable322'], 'Mode' => 'relax', 'Response' => '62 11 15', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['AlgoIsActiveOrCrashStorageInProgressCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'rb_drdi_DIDReadCrashData_e,',
	},
#----------------------------------------------------------------------------------#
	'RoutineControl_RequestResults_CalculateSignatureOrCRC' => {
					'Requests' => {
						'REQ_RoutineControl_RequestResults_CalculateSignatureOrCRC' => {'Request' => '31 03 E2 10', },
					},
					'POS_Responses' => {
						'PR_RoutineControl_RequestResults_CalculateSignatureOrCRC' => {'DataLength' => '', 'Desc' => 'RoutineControl_RequestResults_CalculateSignatureOrCRC', 'DoorsIDs' => ['SPS_ConfigTable177'], 'Mode' => 'relax', 'Response' => '71 03 E2 10', },
					},
					'protocol' => 'Choose protocol',
					'preconditions_prohibiting_execution' => ['AlgoIsActiveOrCrashStorageInProgressCheck'],
					'allowed_in_sessions' => ['Choosesession(s)(multiselection)'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => '[ControlOptionLength = 0],[ControlOptionValidation = rb_drc_E210RecordValidation],[InfoAndStatusLength  = 3],[RoutineValidation = ]',
	},
#----------------------------------------------------------------------------------#
	'RoutineControl_RequestRoutineResult_AKLV37' => {
					'Requests' => {
						'REQ_RoutineControl_RequestRoutineResult_AKLV37' => {'Request' => '31 03 E2 10', },
					},
					'POS_Responses' => {
						'PR_RoutineControl_RequestRoutineResult_AKLV37' => {'DataLength' => '', 'Desc' => 'RoutineControl_RequestRoutineResult_AKLV37', 'DoorsIDs' => ['SPS_ConfigTable317'], 'Mode' => 'relax', 'Response' => '71 03 E2 10', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['AlgoIsActiveOrCrashStorageInProgressCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => '0x00,',
	},
#----------------------------------------------------------------------------------#
	'RoutineControl_RequestRoutineResult_VDSCalibration' => {
					'Requests' => {
						'REQ_RoutineControl_RequestRoutineResult_VDSCalibration' => {'Request' => '31 03 60 00', },
					},
					'POS_Responses' => {
						'PR_RoutineControl_RequestRoutineResult_VDSCalibration' => {'DataLength' => '', 'Desc' => 'RoutineControl_RequestRoutineResult_VDSCalibration', 'DoorsIDs' => ['SPS_ConfigTable314'], 'Mode' => 'relax', 'Response' => '71 03 60 00', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => '0x00',
	},
#----------------------------------------------------------------------------------#
	'RoutineControl_RequestRoutineResults_DeployLoopRoutineID' => {
					'Requests' => {
						'REQ_RoutineControl_RequestRoutineResults_DeployLoopRoutineID' => {'Request' => '31 03 E2 01', },
					},
					'POS_Responses' => {
						'PR_RoutineControl_RequestRoutineResults_DeployLoopRoutineID' => {'DataLength' => '', 'Desc' => 'RoutineControl_RequestRoutineResults_DeployLoopRoutineID', 'DoorsIDs' => ['SPS_ConfigTable154'], 'Mode' => 'relax', 'Response' => '71 03 E2 01', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['SafetySession'],
					'allowed_in_addressingmodes' => ['disposal'],
					'allowed_in_securitylevels' => ['Level48'],
					'additional_parameter' => '[ControlOptionLength = 1],[ControlOptionValidation = rb_dmim_E201RecordValidation],[InfoAndStatusLength  = 3]',
	},
#----------------------------------------------------------------------------------#
	'RoutineControl_RequestRoutineResults_ExecuteSPL' => {
					'Requests' => {
						'REQ_RoutineControl_RequestRoutineResults_ExecuteSPL' => {'Request' => '31 03 E2 00', },
					},
					'POS_Responses' => {
						'PR_RoutineControl_RequestRoutineResults_ExecuteSPL' => {'DataLength' => '', 'Desc' => 'RoutineControl_RequestRoutineResults_ExecuteSPL', 'DoorsIDs' => ['SPS_ConfigTable153'], 'Mode' => 'relax', 'Response' => '71 03 E2 00', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['SafetySession'],
					'allowed_in_addressingmodes' => ['disposal'],
					'allowed_in_securitylevels' => ['Level48'],
					'additional_parameter' => '[ControlOptionLength = 0],[ControlOptionValidation = rb_dmim_E200RecordValidation],[InfoAndStatusLength  = 2]',
	},
#----------------------------------------------------------------------------------#
	'RoutineControl_StartRoutine_CalculateSignatureOrCRC' => {
					'Requests' => {
						'REQ_RoutineControl_StartRoutine_CalculateSignatureOrCRC' => {'Request' => '31 01 E2 10 RoutineControlOption', },
					},
					'POS_Responses' => {
						'PR_RoutineControl_StartRoutine_CalculateSignatureOrCRC' => {'DataLength' => '', 'Desc' => 'RoutineControl_StartRoutine_CalculateSignatureOrCRC', 'DoorsIDs' => ['SPS_ConfigTable175'], 'Mode' => 'relax', 'Response' => '71 01 E2 10', },
					},
					'protocol' => 'Choose protocol',
					'preconditions_prohibiting_execution' => ['AlgoIsActiveOrCrashStorageInProgressCheck'],
					'allowed_in_sessions' => ['Choosesession(s)(multiselection)'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => '[ControlOptionLength = 2],[ControlOptionValidation = rb_drc_E210RecordValidation],[InfoAndStatusLength  = 3]',
	},
#----------------------------------------------------------------------------------#
	'RoutineControl_StartRoutine_DeployLoopRoutineID' => {
					'Requests' => {
						'REQ_RoutineControl_StartRoutine_DeployLoopRoutineID' => {'Request' => '31 01 E2 01 RoutineControlOption', },
					},
					'POS_Responses' => {
						'PR_RoutineControl_StartRoutine_DeployLoopRoutineID' => {'DataLength' => '', 'Desc' => 'RoutineControl_StartRoutine_DeployLoopRoutineID', 'DoorsIDs' => ['SPS_ConfigTable152'], 'Mode' => 'relax', 'Response' => '71 01 E2 01', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['SafetySession'],
					'allowed_in_addressingmodes' => ['disposal'],
					'allowed_in_securitylevels' => ['Level48'],
					'additional_parameter' => '[ControlOptionLength = 1],[ControlOptionValidation = rb_dmim_E201RecordValidation],[InfoAndStatusLength  = 3]',
	},
#----------------------------------------------------------------------------------#
	'RoutineControl_StartRoutine_ExecuteSPL' => {
					'Requests' => {
						'REQ_RoutineControl_StartRoutine_ExecuteSPL' => {'Request' => '31 01 E2 00 RoutineControlOption', },
					},
					'POS_Responses' => {
						'PR_RoutineControl_StartRoutine_ExecuteSPL' => {'DataLength' => '', 'Desc' => 'RoutineControl_StartRoutine_ExecuteSPL', 'DoorsIDs' => ['SPS_ConfigTable151'], 'Mode' => 'relax', 'Response' => '71 01 E2 00', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['SafetySession'],
					'allowed_in_addressingmodes' => ['disposal'],
					'allowed_in_securitylevels' => ['Level48'],
					'additional_parameter' => '[ControlOptionLength = 1],[ControlOptionValidation = rb_dmim_E200RecordValidation],[InfoAndStatusLength  = 2]',
	},
#----------------------------------------------------------------------------------#
	'RoutineControl_StopRoutine_AKLV37' => {
					'Requests' => {
						'REQ_RoutineControl_StopRoutine_AKLV37' => {'Request' => '31 02 E2 10 RoutineControlOption', },
					},
					'POS_Responses' => {
						'PR_RoutineControl_StopRoutine_AKLV37' => {'DataLength' => '', 'Desc' => 'RoutineControl_StopRoutine_AKLV37', 'DoorsIDs' => ['SPS_ConfigTable316'], 'Mode' => 'relax', 'Response' => '71 02 E2 10', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['AlgoIsActiveOrCrashStorageInProgressCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => '0x00,',
	},
#----------------------------------------------------------------------------------#
	'RoutineControl_StopRoutine_CalculateSignatureOrCRC' => {
					'Requests' => {
						'REQ_RoutineControl_StopRoutine_CalculateSignatureOrCRC' => {'Request' => '31 02 E2 10 RoutineControlOption', },
					},
					'POS_Responses' => {
						'PR_RoutineControl_StopRoutine_CalculateSignatureOrCRC' => {'DataLength' => '', 'Desc' => 'RoutineControl_StopRoutine_CalculateSignatureOrCRC', 'DoorsIDs' => ['SPS_ConfigTable176'], 'Mode' => 'relax', 'Response' => '71 02 E2 10', },
					},
					'protocol' => 'Choose protocol',
					'preconditions_prohibiting_execution' => ['AlgoIsActiveOrCrashStorageInProgressCheck'],
					'allowed_in_sessions' => ['Choosesession(s)(multiselection)'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => '[ControlOptionLength = 2],[ControlOptionValidation = rb_drc_E210RecordValidation],[InfoAndStatusLength  = 3]',
	},
#----------------------------------------------------------------------------------#
	'RoutineControl_StopRoutine_DeployLoopRoutineID' => {
					'Requests' => {
						'REQ_RoutineControl_StopRoutine_DeployLoopRoutineID' => {'Request' => '31 02 E2 01 RoutineControlOption', },
					},
					'POS_Responses' => {
						'PR_RoutineControl_StopRoutine_DeployLoopRoutineID' => {'DataLength' => '', 'Desc' => 'RoutineControl_StopRoutine_DeployLoopRoutineID', 'DoorsIDs' => ['SPS_ConfigTable318'], 'Mode' => 'relax', 'Response' => '71 02 E2 01', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['SafetySession'],
					'allowed_in_addressingmodes' => ['disposal'],
					'allowed_in_securitylevels' => ['Level48'],
					'additional_parameter' => 'n/a',
	},
#----------------------------------------------------------------------------------#
	'RoutineControl_StopRoutine_ExecuteSPL' => {
					'Requests' => {
						'REQ_RoutineControl_StopRoutine_ExecuteSPL' => {'Request' => '31 02 E2 00 RoutineControlOption', },
					},
					'POS_Responses' => {
						'PR_RoutineControl_StopRoutine_ExecuteSPL' => {'DataLength' => '', 'Desc' => 'RoutineControl_StopRoutine_ExecuteSPL', 'DoorsIDs' => ['SPS_ConfigTable319'], 'Mode' => 'relax', 'Response' => '71 02 E2 00', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['SafetySession'],
					'allowed_in_addressingmodes' => ['disposal'],
					'allowed_in_securitylevels' => ['Level48'],
					'additional_parameter' => 'n/a',
	},
#----------------------------------------------------------------------------------#
	'RoutineControl_StopRoutine_VDSCalibration' => {
					'Requests' => {
						'REQ_RoutineControl_StopRoutine_VDSCalibration' => {'Request' => '31 02 60 00 RoutineControlOption', },
					},
					'POS_Responses' => {
						'PR_RoutineControl_StopRoutine_VDSCalibration' => {'DataLength' => '', 'Desc' => 'RoutineControl_StopRoutine_VDSCalibration', 'DoorsIDs' => ['SPS_ConfigTable313'], 'Mode' => 'relax', 'Response' => '71 02 60 00', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => '0x00',
	},
#----------------------------------------------------------------------------------#
	'RoutineControl_startRoutine_AKLV37' => {
					'Requests' => {
						'REQ_RoutineControl_startRoutine_AKLV37' => {'Request' => '31 01 E2 10 RoutineControlOption', },
					},
					'POS_Responses' => {
						'PR_RoutineControl_startRoutine_AKLV37' => {'DataLength' => '', 'Desc' => 'RoutineControl_startRoutine_AKLV37', 'DoorsIDs' => ['SPS_ConfigTable315'], 'Mode' => 'relax', 'Response' => '71 01 E2 10', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['AlgoIsActiveOrCrashStorageInProgressCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => '0x00,',
	},
#----------------------------------------------------------------------------------#
	'RoutineControl_startRoutine_VDSCalibration' => {
					'Requests' => {
						'REQ_RoutineControl_startRoutine_VDSCalibration' => {'Request' => '31 01 60 00 RoutineControlOption', },
					},
					'POS_Responses' => {
						'PR_RoutineControl_startRoutine_VDSCalibration' => {'DataLength' => '', 'Desc' => 'RoutineControl_startRoutine_VDSCalibration', 'DoorsIDs' => ['SPS_ConfigTable312'], 'Mode' => 'relax', 'Response' => '71 01 60 00', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => '0x00',
	},
#----------------------------------------------------------------------------------#
	'SecurityAccess_RequestSeed_0x01' => {
					'Requests' => {
						'REQ_SecurityAccess_RequestSeed_0x01' => {'Request' => '27 01', },
					},
					'POS_Responses' => {
						'PR_SecurityAccess_RequestSeed_0x01' => {'DataLength' => '', 'Desc' => 'SecurityAccess_RequestSeed_0x01', 'DoorsIDs' => ['SPS_ConfigTable255'], 'Mode' => 'relax', 'Response' => '67 01', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['n/a'],
					'additional_parameter' => 'n/a',
	},
#----------------------------------------------------------------------------------#
	'SecurityAccess_RequestSeed_0x02' => {
					'Requests' => {
						'REQ_SecurityAccess_RequestSeed_0x02' => {'Request' => '27 03', },
					},
					'POS_Responses' => {
						'PR_SecurityAccess_RequestSeed_0x02' => {'DataLength' => '', 'Desc' => 'SecurityAccess_RequestSeed_0x02', 'DoorsIDs' => ['SPS_ConfigTable253'], 'Mode' => 'relax', 'Response' => '67 03', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['n/a'],
					'additional_parameter' => 'n/a',
	},
#----------------------------------------------------------------------------------#
	'SecurityAccess_RequestSeed_Deployment_Level48' => {
					'Requests' => {
						'REQ_SecurityAccess_RequestSeed_Deployment_Level48' => {'Request' => '27 5F', },
					},
					'POS_Responses' => {
						'PR_SecurityAccess_RequestSeed_Deployment_Level48' => {'DataLength' => '', 'Desc' => 'SecurityAccess_RequestSeed_Deployment_Level48', 'DoorsIDs' => ['SPS_ConfigTable142'], 'Mode' => 'relax', 'Response' => '67 5F', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['SafetySession'],
					'allowed_in_addressingmodes' => ['disposal'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'n/a',
	},
#----------------------------------------------------------------------------------#
	'SecurityAccess_RequestSeed_EDR' => {
					'Requests' => {
						'REQ_SecurityAccess_RequestSeed_EDR' => {'Request' => 'En te rt he ap pr op ri at es ub fu nc ti on fo rR eq ue st Se ed :2 7X', },
					},
					'POS_Responses' => {
						'PR_SecurityAccess_RequestSeed_EDR' => {'DataLength' => '', 'Desc' => 'SecurityAccess_RequestSeed_EDR', 'DoorsIDs' => ['SPS_ConfigTable194'], 'Mode' => 'relax', 'Response' => '4E te rt he ap pr op ri at es ub fu nc ti on fo rR eq ue st Se ed :2 7X', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['Choose precondition(s) (multi selection)'],
					'allowed_in_sessions' => ['Choosesession(s)(multiselection)'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['n/a'],
					'additional_parameter' => 'n/a',
	},
#----------------------------------------------------------------------------------#
	'SecurityAccess_SendKey_0x01' => {
					'Requests' => {
						'REQ_SecurityAccess_SendKey_0x01' => {'Request' => '27 02 Key', },
					},
					'POS_Responses' => {
						'PR_SecurityAccess_SendKey_0x01' => {'DataLength' => '', 'Desc' => 'SecurityAccess_SendKey_0x01', 'DoorsIDs' => ['SPS_ConfigTable254'], 'Mode' => 'relax', 'Response' => '67 02', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['n/a'],
					'additional_parameter' => 'n/a',
	},
#----------------------------------------------------------------------------------#
	'SecurityAccess_SendKey_0x02' => {
					'Requests' => {
						'REQ_SecurityAccess_SendKey_0x02' => {'Request' => '27 04 Key', },
					},
					'POS_Responses' => {
						'PR_SecurityAccess_SendKey_0x02' => {'DataLength' => '', 'Desc' => 'SecurityAccess_SendKey_0x02', 'DoorsIDs' => ['SPS_ConfigTable252'], 'Mode' => 'relax', 'Response' => '67 04', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['n/a'],
					'additional_parameter' => 'n/a',
	},
#----------------------------------------------------------------------------------#
	'SecurityAccess_SendKey_Deployment_Level48' => {
					'Requests' => {
						'REQ_SecurityAccess_SendKey_Deployment_Level48' => {'Request' => '27 60', },
					},
					'POS_Responses' => {
						'PR_SecurityAccess_SendKey_Deployment_Level48' => {'DataLength' => '', 'Desc' => 'SecurityAccess_SendKey_Deployment_Level48', 'DoorsIDs' => ['SPS_ConfigTable143'], 'Mode' => 'relax', 'Response' => '67 60', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['SafetySession'],
					'allowed_in_addressingmodes' => ['disposal'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'n/a',
	},
#----------------------------------------------------------------------------------#
	'SecurityAccess_SendKey_EDR' => {
					'Requests' => {
						'REQ_SecurityAccess_SendKey_EDR' => {'Request' => 'En te rt he ap pr op ri at es ub fu nc ti on fo rS en dK ey :2 7Y', },
					},
					'POS_Responses' => {
						'PR_SecurityAccess_SendKey_EDR' => {'DataLength' => '', 'Desc' => 'SecurityAccess_SendKey_EDR', 'DoorsIDs' => ['SPS_ConfigTable195'], 'Mode' => 'relax', 'Response' => '4E te rt he ap pr op ri at es ub fu nc ti on fo rS en dK ey :2 7Y', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['Choose precondition(s) (multi selection)'],
					'allowed_in_sessions' => ['Choosesession(s)(multiselection)'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['n/a'],
					'additional_parameter' => 'n/a',
	},
#----------------------------------------------------------------------------------#
	'TesterPresent_zeroSubfunction' => {
					'Requests' => {
						'REQ_TesterPresent_zeroSubfunction' => {'Request' => '3E 00', },
					},
					'POS_Responses' => {
						'PR_TesterPresent_zeroSubfunction' => {'DataLength' => '', 'Desc' => 'TesterPresent_zeroSubfunction', 'DoorsIDs' => ['SPS_ConfigTable217'], 'Mode' => 'relax', 'Response' => '7E 00', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['n/a'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'n/a',
	},
#----------------------------------------------------------------------------------#
	'TesterPresent_zeroSubfunction_ForDisposal' => {
					'Requests' => {
						'REQ_TesterPresent_zeroSubfunction_ForDisposal' => {'Request' => '3E 00', },
					},
					'POS_Responses' => {
						'PR_TesterPresent_zeroSubfunction_ForDisposal' => {'DataLength' => '', 'Desc' => 'TesterPresent_zeroSubfunction_ForDisposal', 'DoorsIDs' => ['SPS_ConfigTable158'], 'Mode' => 'relax', 'Response' => '7E 00', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['n/a'],
					'allowed_in_sessions' => ['DefaultSession', 'SafetySession'],
					'allowed_in_addressingmodes' => ['disposal'],
					'allowed_in_securitylevels' => ['n/a'],
					'additional_parameter' => 'n/a',
	},
#----------------------------------------------------------------------------------#
	'WriteDataByIdentifier_DismantlerInfo' => {
					'Requests' => {
						'REQ_WriteDataByIdentifier_DismantlerInfo' => {'Request' => '2E FA 07 Data', },
					},
					'POS_Responses' => {
						'PR_WriteDataByIdentifier_DismantlerInfo' => {'DataLength' => '', 'Desc' => 'WriteDataByIdentifier_DismantlerInfo', 'DoorsIDs' => ['SPS_ConfigTable147'], 'Mode' => 'relax', 'Response' => '6E FA 07', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['IdleModeCheck', 'AutarkieModeCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'SafetySession'],
					'allowed_in_addressingmodes' => ['disposal'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => 'n/a',
	},
#----------------------------------------------------------------------------------#
	'WriteDataByIdentifier_ReadWriteEOL' => {
					'Requests' => {
						'REQ_WriteDataByIdentifier_ReadWriteEOL' => {'Request' => '2E 60 01 Data', },
					},
					'POS_Responses' => {
						'PR_WriteDataByIdentifier_ReadWriteEOL' => {'DataLength' => '', 'Desc' => 'WriteDataByIdentifier_ReadWriteEOL', 'DoorsIDs' => ['SPS_ConfigTable306'], 'Mode' => 'relax', 'Response' => '6E 60 01', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['AutarkieModeCheck', 'InitTestNotCompletedCheck'],
					'allowed_in_sessions' => ['ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['Level1'],
					'additional_parameter' => '0x00',
	},
#----------------------------------------------------------------------------------#
	'WriteDataByIdentifier_ReadWriteGenData' => {
					'Requests' => {
						'REQ_WriteDataByIdentifier_ReadWriteGenData' => {'Request' => '2E 20 00 Data', },
					},
					'POS_Responses' => {
						'PR_WriteDataByIdentifier_ReadWriteGenData' => {'DataLength' => '', 'Desc' => 'WriteDataByIdentifier_ReadWriteGenData', 'DoorsIDs' => ['SPS_ConfigTable305'], 'Mode' => 'relax', 'Response' => '6E 20 00', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['AutarkieModeCheck'],
					'allowed_in_sessions' => ['ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
					'additional_parameter' => '0x00',
	},
#----------------------------------------------------------------------------------#

},
##### END OF Request Response Section #######



############# GlobalNRC ##################

'GlobalNRC' => {
	'10' => 'generalReject',
	'11' => 'serviceNotSupported',
	'12' => 'subFunctionNotSupported',
	'13' => 'incorrectMessageLengthOrInvalidFormat',
	'14' => 'responseTooLong',
	'21' => 'busyRepeatRequest',
	'22' => 'conditionsNotCorrect',
	'24' => 'requestSequenceError',
	'25' => 'noResponseFromSubnetComponent',
	'26' => 'failurePreventsExecutionOfRequestedAction',
	'31' => 'requestOutOfRange',
	'33' => 'securityAccessDenied',
	'35' => 'invalidKey',
	'36' => 'exceedNumberOfAttempts',
	'37' => 'requiredTimeDelayNotExpired',
	'70' => 'uploadDownloadNotAccepted',
	'71' => 'transferDataSuspended',
	'72' => 'generalProgrammingFailure',
	'73' => 'wrongBlockSequenceCounter',
	'78' => 'requestCorrectlyReceived_ResponsePending',
	'7E' => 'subFunctionNotSupportedInActiveSession',
	'7F' => 'serviceNotSupportedInActiveSession',
	'81' => 'rpmTooHigh',
	'82' => 'rpmTooLow',
	'83' => 'engineIsRunning',
	'84' => 'engineIsNotRunning',
	'85' => 'engineRunTimeTooLow',
	'86' => 'temperatureTooHigh',
	'87' => 'temperatureTooLow',
	'88' => 'vehicleSpeedTooHigh',
	'89' => 'vehicleSpeedTooLow',
	'8A' => 'throttle_PedalTooHigh',
	'8B' => 'throttle_PedalTooLow',
	'8C' => 'transmissionRangeNotInNeutral',
	'8D' => 'transmissionRangeNotInGear',
	'8F' => 'brakeSwitchNotClosed',
	'90' => 'shifterLeverNotInPark',
	'91' => 'torqueConverterClutchLocked',
	'92' => 'voltageTooHigh',
	'93' => 'voltageTooLow',
},
#---------------------------------------------------------#

};    #end of Mapping_DIAG
1;