package LIFT_PROJECT;

$Defaults->{"Mapping_DIAG"} = {

	#Mapping server for PROD service only
	#----------------------------------------------------------------

	"PRJ_SUPPORTED_SERVICES" => {

		# Prod Diag
		"SecurityAccess"            => "00",
		"Read_Cell"                 => "01",
		"Write_Cell"                => "02",
		"Update_DataFlashSections"  => "03",    # not there in SRS
		"Clear_Fault_Memory"        => "04",
		"Freeze_Fault_Memory"       => "05",
		"Check_EDR_Empty"           => "06",    # not there in SRS
		"Read_EDR"                  => "07",
		"Clear_EDR"                 => "08",
		"ECU_Status"                => "09",
		"Read_Fault_Memory"         => "10",
		"Verify_Data_ByCRC"         => "11",    # not there in SRS
		"Reset"                     => "12",
		"Fault_Memory_Manipulation" => "13",
		"Read_NVM_Cells"            => '14',
		"Write_NVM_Cells"           => '15',
		"AI0_Test_Pattern"          => "16",
		"Read_System_ASIC_Serial_number "=> "17",
		"Enable_Safety_Path"        => '18',

		#"Fire_All_Devices"          => '19', # why commented? Ask Deepu
		"Fast_Diagnostics_CAN"     => "90",
		"Fast_Diagnostics_Flexray" => "91",
		"Fast_Diagnostics_CANFD"   => "92",
		"SMI7XY_Verification"      => "0D",
		"SMI8_SMA7_Verification"   => "0E",
		"Request_Download"         => "34",
		"Transfer_Data "           => "36",
		"Transfer_Exit"            => "37",
	},

	#----------------------------------------------------------------

	"DIAG_SERVICES" => {

		#----------------------------------------------------------------------------------------
		#************************** Production Diagnosis services *******************************
		#----------------------------------------------------------------------------------------
		"SecurityAccess" => {
			"Service_ID"        => "00",
			"Supported_SubFuns" => {
				"SecurityAccess__SeedLevel1" => "A1",
				"SecurityAccess__KeyLevel1"  => "A2",
				"SecurityAccess__SeedLevel2" => "A3",
				"SecurityAccess__KeyLevel2"  => "A4",
			},
			"NEG_Responses" => {
				"NR_IncorectKey"                           => { "Response" => "7F 00 35 B8", "Mode" => "strict", "Desc" => "Seed Key Level 1 :IncorectKey",                            "DataLength" => "4" },
				"NR_requestOutOfRange"                     => { "Response" => "7F 00 31 B4", "Mode" => "strict", "Desc" => "SecurityAccess: RequestOutOfRange",                        "DataLength" => "4" },
				"NR_securityAccessDenied"                  => { "Response" => "7F 00 33 B6", "Mode" => "strict", "Desc" => "SecurityAccess: securityAccessDenied",                     "DataLength" => "4" },
				"NR_incorrectMessageLengthOrInvalidFormat" => { "Response" => "7F 00 13 96", "Mode" => "strict", "Desc" => "SecurityAccess: NR_incorrectMessageLengthOrInvalidFormat", "DataLength" => "4" },
				"NR_requestSequenceError"                  => { "Response" => "7F 00 24 A7", "Mode" => "strict", "Desc" => "SecurityAccess: requestSequenceError",                     "DataLength" => "4" },

			},
		},

		#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		"Read_Cell" => {
			"Service_ID"        => "01",
			"Supported_SubFuns" => {},
			"NEG_Responses"     => {
				"NR_requestOutOfRange"                     => { "Response" => "7F 01 31 B5 ", "Mode" => "strict", "Desc" => "Read_Cell :RequestOutOfRange",                     "DataLength" => "4" },
				"NR_securityAccessDenied"                  => { "Response" => "7F 01 33 B7",  "Mode" => "strict", "Desc" => "Read_Cell securityAccessDenied",                   "DataLength" => "4" },
				"NR_incorrectMessageLengthOrInvalidFormat" => { "Response" => "7F 01 13 97",  "Mode" => "strict", "Desc" => "Read_Cell :incorrectMessageLengthOrInvalidFormat", "DataLength" => "4" },
				"NR_conditionsNotCorrect"                  => { "Response" => "7F 01 22 A6 ", "Mode" => "strict", "Desc" => "Read_Cell :conditionsNotCorrect",                  "DataLength" => "4" },
			},
		},

		#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		"Write_Cell" => {
			"Service_ID"        => "02",
			"Supported_SubFuns" => {},
			"NEG_Responses"     => {
				"NR_requestOutOfRange"                     => { "Response" => "7F 02 31 B6 ", "Mode" => "strict", "Desc" => "Write_Cell :RequestOutOfRange",                     "DataLength" => "4" },
				"NR_securityAccessDenied"                  => { "Response" => "7F 02 33 B8",  "Mode" => "strict", "Desc" => "Write_Cell: securityAccessDenied",                  "DataLength" => "4" },
				"NR_incorrectMessageLengthOrInvalidFormat" => { "Response" => "7F 02 13 98",  "Mode" => "strict", "Desc" => "Write_Cell::incorrectMessageLengthOrInvalidFormat", "DataLength" => "4" },
				"NR_conditionsNotCorrect"                  => { "Response" => "7F 02 22 A7 ", "Mode" => "strict", "Desc" => "Write_Cell :conditionsNotCorrect",                  "DataLength" => "4" },
			},
		},

		#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		"Update_DataFlashSections" => {
			"Service_ID"        => "03",
			"Supported_SubFuns" => {},
			"NEG_Responses"     => {
				"NR_requestOutOfRange"                     => { "Response" => "7F 03 31 B7 ", "Mode" => "strict", "Desc" => "Update_DataFlashSections :RequestOutOfRange",                     "DataLength" => "4" },
				"NR_conditionsNotCorrect"                  => { "Response" => "7F 03 22 A8 ", "Mode" => "strict", "Desc" => "Update_DataFlashSections :conditionsNotCorrect",                  "DataLength" => "4" },
				"NR_securityAccessDenied"                  => { "Response" => "7F 03 33 B9",  "Mode" => "strict", "Desc" => "Update_DataFlashSections: securityAccessDenied",                  "DataLength" => "4" },
				"NR_incorrectMessageLengthOrInvalidFormat" => { "Response" => "7F 03 13 99",  "Mode" => "strict", "Desc" => "Update_DataFlashSections::incorrectMessageLengthOrInvalidFormat", "DataLength" => "4" },
			},
		},

		#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		"Clear_Fault_Memory" => {
			"Service_ID"        => "04",
			"Supported_SubFuns" => {},
			"NEG_Responses"     => {
				"NR_requestOutOfRange"                     => { "Response" => "7F 04 31 B8 ", "Mode" => "strict", "Desc" => "Clear_Fault_Memory :RequestOutOfRange",                     "DataLength" => "4" },
				"NR_conditionsNotCorrect"                  => { "Response" => "7F 04 22 A9 ", "Mode" => "strict", "Desc" => "Clear_Fault_Memory :conditionsNotCorrect",                  "DataLength" => "4" },
				"NR_securityAccessDenied"                  => { "Response" => "7F 04 33 BA",  "Mode" => "strict", "Desc" => "Clear_Fault_Memory: securityAccessDenied",                  "DataLength" => "4" },
				"NR_incorrectMessageLengthOrInvalidFormat" => { "Response" => "7F 04 13 9A",  "Mode" => "strict", "Desc" => "Clear_Fault_Memory::incorrectMessageLengthOrInvalidFormat", "DataLength" => "4" },
			},
		},

		#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		"Freeze_Fault_Memory" => {
			"Service_ID"        => "05",
			"Supported_SubFuns" => {},
			"NEG_Responses"     => {
				"NR_requestOutOfRange"                     => { "Response" => "7F 05 31 B9 ", "Mode" => "strict", "Desc" => "Freeze_Fault_Memory :RequestOutOfRange",                     "DataLength" => "4" },
				"NR_conditionsNotCorrect"                  => { "Response" => "7F 05 22 AA ", "Mode" => "strict", "Desc" => "Freeze_Fault_Memory :conditionsNotCorrect",                  "DataLength" => "4" },
				"NR_securityAccessDenied"                  => { "Response" => "7F 05 33 BB",  "Mode" => "strict", "Desc" => "Freeze_Fault_Memory: securityAccessDenied",                  "DataLength" => "4" },
				"NR_incorrectMessageLengthOrInvalidFormat" => { "Response" => "7F 05 13 9B",  "Mode" => "strict", "Desc" => "Freeze_Fault_Memory::incorrectMessageLengthOrInvalidFormat", "DataLength" => "4" },
			},
		},

		#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		"Read_EDR" => {
			"Service_ID"        => "07",
			"Supported_SubFuns" => {},
			"NEG_Responses"     => {
				"NR_requestOutOfRange"                     => { "Response" => "7F 07 31 BB", "Mode" => "strict", "Desc" => "Read_EDR :RequestOutOfRange",    "DataLength" => "4" },
				"NR_conditionsNotCorrect"                  => { "Response" => "7F 07 22 AC", "Mode" => "strict", "Desc" => "Read_EDR :conditionsNotCorrect", "DataLength" => "4" },
				"NR_securityAccessDenied"                  => { "Response" => "7F 07 33 BD", "Mode" => "strict", "Desc" => "Read_EDR securityAccessDenied",  "DataLength" => "4" },
				"NR_incorrectMessageLengthOrInvalidFormat" => { "Response" => "7F 07 13 9D", "Mode" => "strict", "Desc" => "Read_EDR incorrect length",      "DataLength" => "4" },
				"NR_crashRecorderEmpty"                    => { "Response" => "7F 07 55 DF", "Mode" => "strict", "Desc" => "Read_EDR crash record empty",    "DataLength" => "4" },
			},
		},

		#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		"Clear_EDR" => {
			"Service_ID"        => "08",
			"Supported_SubFuns" => {},
			"NEG_Responses"     => {
				"NR_requestOutOfRange"                     => { "Response" => "7F 08 31 BC ", "Mode" => "strict", "Desc" => "Clear_EDR :RequestOutOfRange",    "DataLength" => "4" },
				"NR_conditionsNotCorrect"                  => { "Response" => "7F 08 22 AD ", "Mode" => "strict", "Desc" => "Clear_EDR :conditionsNotCorrect", "DataLength" => "4" },
				"NR_securityAccessDenied"                  => { "Response" => "7F 08 33 BE",  "Mode" => "strict", "Desc" => "Clear_EDR securityAccessDenied",  "DataLength" => "4" },
				"NR_incorrectMessageLengthOrInvalidFormat" => { "Response" => "7F 08 13 9E",  "Mode" => "strict", "Desc" => "Clear_EDR incorrect length",      "DataLength" => "4" },
			},
		},

		#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		"ECU_Status" => {
			"Service_ID"        => "09",
			"Supported_SubFuns" => {},
			"NEG_Responses"     => {
				"NR_requestOutOfRange"                     => { "Response" => "7F 09 31 BD ", "Mode" => "strict", "Desc" => "ECU_Status :RequestOutOfRange",                     "DataLength" => "4" },
				"NR_securityAccessDenied"                  => { "Response" => "7F 09 33 BF",  "Mode" => "strict", "Desc" => "ECU_Status: securityAccessDenied",                  "DataLength" => "4" },
				"NR_incorrectMessageLengthOrInvalidFormat" => { "Response" => "7F 09 13 9F",  "Mode" => "strict", "Desc" => "ECU_Status::incorrectMessageLengthOrInvalidFormat", "DataLength" => "4" },
				"NR_conditionsNotCorrect"                  => { "Response" => "7F 09 22 AE ", "Mode" => "strict", "Desc" => "ECU_Status :conditionsNotCorrect",                  "DataLength" => "4" },
			},
		},

		#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		"SMI7XY_Verification" => {
			"Service_ID"        => "0D",
			"Supported_SubFuns" => {},
			"NEG_Responses"     => {
				"NR_requestOutOfRange"                     => { "Response" => "7F 0D 00 31 C2", "Mode" => "strict", "Desc" => "SMI7XY_Verification :RequestOutOfRange",                     "DataLength" => "5" },
				"NR_conditionsNotCorrect"                  => { "Response" => "7F 0D 00 22 B3", "Mode" => "strict", "Desc" => "SMI7XY_Verification :conditionsNotCorrect",                  "DataLength" => "5" },
				"NR_securityAccessDenied"                  => { "Response" => "7F 0D 00 33 C4", "Mode" => "strict", "Desc" => "SMI7XY_Verification: securityAccessDenied",                  "DataLength" => "5" },
				"NR_incorrectMessageLengthOrInvalidFormat" => { "Response" => "7F 0D 00 13 A4", "Mode" => "strict", "Desc" => "SMI7XY_Verification::incorrectMessageLengthOrInvalidFormat", "DataLength" => "5" },
				"NR_serviceNotSupported"                   => { "Response" => "7F 0D 00 11 A2", "Mode" => "strict", "Desc" => "SMI7XY_Verification :conditionsNotCorrect",                  "DataLength" => "5" },
			},
		},

		"SMI8_SMA7_Verification" => {
			"Service_ID"        => "0E",
			"Supported_SubFuns" => {},
			"NEG_Responses"     => {
				"NR_requestOutOfRange"                     => { "Response" => "7F 0E 31 C2", "Mode" => "strict", "Desc" => "SMI8_SMA7_Verification :RequestOutOfRange",                     "DataLength" => "4" },
				"NR_conditionsNotCorrect"                  => { "Response" => "7F 0E 22 B3", "Mode" => "strict", "Desc" => "SMI8_SMA7_Verification :conditionsNotCorrect",                  "DataLength" => "4" },
				"NR_securityAccessDenied"                  => { "Response" => "7F 0E 33 C3", "Mode" => "strict", "Desc" => "SMI8_SMA7_Verification : securityAccessDenied",                  "DataLength" => "4" },
				"NR_incorrectMessageLengthOrInvalidFormat" => { "Response" => "7F 0E 13 A4", "Mode" => "strict", "Desc" => "SMI8_SMA7_Verification :incorrectMessageLengthOrInvalidFormat", "DataLength" => "4" },
				"NR_serviceNotSupported"                   => { "Response" => "7F 0E 11 A2", "Mode" => "strict", "Desc" => "SMI8_SMA7_Verification :conditionsNotCorrect",                  "DataLength" => "4" },
		    	"NR_requestSequenceError"                  => { "Response" => "7F 0E 24 B5", "Mode" => "strict", "Desc" => "SMI8_SMA7_Verification requestSequenceErro",                   "DataLength" => "4" },
				"NR_responsePending"                       => { "Response" => "7F 0E 78 09", "Mode" => "strict", "Desc" => "SMI8_SMA7_Verification requestSequenceErro",                   "DataLength" => "4" },
			},
		},

		#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		"Read_Fault_Memory" => {
			"Service_ID"        => "10",
			"Supported_SubFuns" => {
				"Read_Fault_Memory__Plant"              => {"01"},
				"Read_Fault_Memory__Primary"            => {"02"},
				"Read_Fault_Memory__History"            => {"03"},
				"Read_Fault_Memory__Bosch"              => {"04"},
				"Read_Fault_Memory__Distrubance"        => {"05"},
				"Read_Fault_Memory__InvalidSubFunction" => {"06"},
			},
			"NEG_Responses" => {
				"NR_requestOutOfRange"                     => { "Response" => "7F 10 31 C4", "Mode" => "strict", "Desc" => "Read_Fault_Memory: RequestOutOfRange",                     "DataLength" => "4" },
				"NR_conditionsNotCorrect"                  => { "Response" => "7F 10 22 B5", "Mode" => "strict", "Desc" => "Read_Fault_Memory :conditionsNotCorrect",                  "DataLength" => "4" },
				"NR_securityAccessDenied"                  => { "Response" => "7F 10 33 C6", "Mode" => "strict", "Desc" => "Read_Fault_Memory: securityAccessDenied",                  "DataLength" => "4" },
				"NR_incorrectMessageLengthOrInvalidFormat" => { "Response" => "7F 10 13 A6", "Mode" => "strict", "Desc" => "Read_Fault_Memory::incorrectMessageLengthOrInvalidFormat", "DataLength" => "4" },
			},
		},

		#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		"Verify_Data_ByCRC" => {
			"Service_ID"        => "11",
			"Supported_SubFuns" => {},
			"NEG_Responses"     => {
				"NR_requestOutOfRange"                     => { "Response" => "7F 11 31 C5 ", "Mode" => "strict", "Desc" => "Verify_Data_ByCRC :RequestOutOfRange",                     "DataLength" => "4" },
				"NR_conditionsNotCorrect"                  => { "Response" => "7F 11 22 B6",  "Mode" => "strict", "Desc" => "Verify_Data_ByCRC :conditionsNotCorrect",                  "DataLength" => "4" },
				"NR_securityAccessDenied"                  => { "Response" => "7F 11 33 C7",  "Mode" => "strict", "Desc" => "Verify_Data_ByCRC: securityAccessDenied",                  "DataLength" => "4" },
				"NR_incorrectMessageLengthOrInvalidFormat" => { "Response" => "7F 11 13 A7",  "Mode" => "strict", "Desc" => "Verify_Data_ByCRC::incorrectMessageLengthOrInvalidFormat", "DataLength" => "4" },
			},
		},

		#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		"Reset" => {
			"Service_ID"        => "12",
			"Supported_SubFuns" => {},
			"NEG_Responses"     => {
				"NR_requestOutOfRange"                     => { "Response" => "7F 12 31 C6 ", "Mode" => "strict", "Desc" => "Reset :RequestOutOfRange",                     "DataLength" => "4" },
				"NR_conditionsNotCorrect"                  => { "Response" => "7F 12 22 B7",  "Mode" => "strict", "Desc" => "Reset :conditionsNotCorrect",                  "DataLength" => "4" },
				"NR_securityAccessDenied"                  => { "Response" => "7F 12 33 C8",  "Mode" => "strict", "Desc" => "Reset: securityAccessDenied",                  "DataLength" => "4" },
				"NR_incorrectMessageLengthOrInvalidFormat" => { "Response" => "7F 12 13 A8",  "Mode" => "strict", "Desc" => "Reset::incorrectMessageLengthOrInvalidFormat", "DataLength" => "4" },
			},
		},

		#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		"Fault_Memory_Manipulation" => {
			"Service_ID"        => "13",
			"Supported_SubFuns" => {},
			"NEG_Responses"     => {
				"NR_requestOutOfRange"                     => { "Response" => "7F 13 31 C7 ", "Mode" => "strict", "Desc" => "Fault_Memory_Manipulation :RequestOutOfRange",                     "DataLength" => "4" },
				"NR_conditionsNotCorrect"                  => { "Response" => "7F 13 22 B8",  "Mode" => "strict", "Desc" => "Fault_Memory_Manipulation :conditionsNotCorrect",                  "DataLength" => "4" },
				"NR_securityAccessDenied"                  => { "Response" => "7F 13 33 C9",  "Mode" => "strict", "Desc" => "Fault_Memory_Manipulation: securityAccessDenied",                  "DataLength" => "4" },
				"NR_incorrectMessageLengthOrInvalidFormat" => { "Response" => "7F 13 13 A9",  "Mode" => "strict", "Desc" => "Fault_Memory_Manipulation::incorrectMessageLengthOrInvalidFormat", "DataLength" => "4" },
			},
		},

		#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		"Read_NVM_Cells" => {
			"Service_ID"        => "14",
			"Supported_SubFuns" => {},
			"NEG_Responses"     => {
				"NR_requestOutOfRange"                     => { "Response" => "7F 14 31 C8", "Mode" => "strict", "Desc" => "Read_NVM_Cells :RequestOutOfRange",                     "DataLength" => "4" },
				"NR_conditionsNotCorrect"                  => { "Response" => "7F 14 22 B9", "Mode" => "strict", "Desc" => "Read_NVM_Cells :conditionsNotCorrect",                  "DataLength" => "4" },
				"NR_securityAccessDenied"                  => { "Response" => "7F 14 33 CA", "Mode" => "strict", "Desc" => "Read_NVM_Cells: securityAccessDenied",                  "DataLength" => "4" },
				"NR_incorrectMessageLengthOrInvalidFormat" => { "Response" => "7F 14 13 AA", "Mode" => "strict", "Desc" => "Read_NVM_Cells::incorrectMessageLengthOrInvalidFormat", "DataLength" => "4" },
			},
		},

		#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		"Write_NVM_Cells" => {
			"Service_ID"        => "15",
			"Supported_SubFuns" => {},
			"NEG_Responses"     => {
				"NR_requestOutOfRange"                     => { "Response" => "7F 15 31 C9", "Mode" => "strict", "Desc" => "Write_NVM_Cells :RequestOutOfRange",                     "DataLength" => "4" },
				"NR_conditionsNotCorrect"                  => { "Response" => "7F 15 22 BA", "Mode" => "strict", "Desc" => "Write_NVM_Cells :conditionsNotCorrect",                  "DataLength" => "4" },
				"NR_securityAccessDenied"                  => { "Response" => "7F 15 33 CB", "Mode" => "strict", "Desc" => "Write_NVM_Cells: securityAccessDenied",                  "DataLength" => "4" },
				"NR_incorrectMessageLengthOrInvalidFormat" => { "Response" => "7F 15 13 AB", "Mode" => "strict", "Desc" => "Write_NVM_Cells::incorrectMessageLengthOrInvalidFormat", "DataLength" => "4" },
			},
		},

	#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		"Read_System_ASIC_Serial_number" => {
			"Service_ID"        => "17",
			"Supported_SubFuns" => {},
			"NEG_Responses"     => {
				"NR_conditionsNotCorrect"                  => { "Response" => "7F 17 22 BC", "Mode" => "strict", "Desc" => "Read_System_ASIC_Serial_number :conditionsNotCorrect",        "DataLength" => "4" },
				"NR_incorrectMessageLengthOrInvalidFormat" => { "Response" => "7F 17 13 AD", "Mode" => "strict", "Desc" => "Read_System_ASIC_Serial_number::incorrectMessageLengthOrInvalidFormat", "DataLength" => "4" },
				"NR_securityAccessDenied"                  => { "Response" => "7F 17 33 CD", "Mode" => "strict", "Desc" => "Read_System_ASIC_Serial_number securityAccessDenied",          "DataLength" => "4" },
			},
		},
		#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		"Enable_Safety_Path" => {
			"Service_ID"        => "18",
			"Supported_SubFuns" => {},
			"NEG_Responses"     => {
				"NR_requestOutOfRange"                     => { "Response" => "7F 18 31 CC", "Mode" => "strict", "Desc" => "Enable_Safety_Path :RequestOutOfRange",                     "DataLength" => "4" },
				"NR_conditionsNotCorrect"                  => { "Response" => "7F 18 22 BD", "Mode" => "strict", "Desc" => "Enable_Safety_Path :conditionsNotCorrect",                  "DataLength" => "4" },
				"NR_securityAccessDenied"                  => { "Response" => "7F 18 33 CE", "Mode" => "strict", "Desc" => "Enable_Safety_Path: securityAccessDenied",                  "DataLength" => "4" },
				"NR_incorrectMessageLengthOrInvalidFormat" => { "Response" => "7F 18 13 AE", "Mode" => "strict", "Desc" => "Enable_Safety_Path::incorrectMessageLengthOrInvalidFormat", "DataLength" => "4" },
			},
		},

		#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		"Fire_All_Devices" => {
			"Service_ID"        => "19",
			"Supported_SubFuns" => {},
			"NEG_Responses"     => {
				"NR_requestOutOfRange"                     => { "Response" => "7F 19 31 CD", "Mode" => "strict", "Desc" => "Fire_All_Devices :RequestOutOfRange",                     "DataLength" => "4" },
				"NR_conditionsNotCorrect"                  => { "Response" => "7F 19 22 BE", "Mode" => "strict", "Desc" => "Fire_All_Devices :conditionsNotCorrect",                  "DataLength" => "4" },
				"NR_securityAccessDenied"                  => { "Response" => "7F 19 33 CF", "Mode" => "strict", "Desc" => "Fire_All_Devices: securityAccessDenied",                  "DataLength" => "4" },
				"NR_incorrectMessageLengthOrInvalidFormat" => { "Response" => "7F 19 13 AF", "Mode" => "strict", "Desc" => "Fire_All_Devices::incorrectMessageLengthOrInvalidFormat", "DataLength" => "4" },
			},
		},

		#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		"Fast_Diagnostics_CAN" => {
			"Service_ID"        => "90",
			"Supported_SubFuns" => {},
			"NEG_Responses"     => {
				"NR_requestOutOfRange"                     => { "Response" => "7F 90 31 44", "Mode" => "strict", "Desc" => "Fast_Diagnostics_CAN :RequestOutOfRange",                     "DataLength" => "4" },
				"NR_conditionsNotCorrect"                  => { "Response" => "7F 90 22 35", "Mode" => "strict", "Desc" => "Fast_Diagnostics_CAN :conditionsNotCorrect",                  "DataLength" => "4" },
				"NR_securityAccessDenied"                  => { "Response" => "7F 90 33 46", "Mode" => "strict", "Desc" => "Fast_Diagnostics_CAN: securityAccessDenied",                  "DataLength" => "4" },
				"NR_incorrectMessageLengthOrInvalidFormat" => { "Response" => "7F 90 13 26", "Mode" => "strict", "Desc" => "Fast_Diagnostics_CAN::incorrectMessageLengthOrInvalidFormat", "DataLength" => "4" },
			},
		},
		
		"Fast_Diagnostics_CANFD" => {
			"Service_ID"        => "92",
			"Supported_SubFuns" => {},
			"NEG_Responses"     => {
				"NR_requestOutOfRange"                     => { "Response" => "7F 92 31 46", "Mode" => "strict", "Desc" => "Fast_Diagnostics_CAN :RequestOutOfRange",                     "DataLength" => "4" },
				"NR_conditionsNotCorrect"                  => { "Response" => "7F 92 22 37", "Mode" => "strict", "Desc" => "Fast_Diagnostics_CAN :conditionsNotCorrect",                  "DataLength" => "4" },
				"NR_securityAccessDenied"                  => { "Response" => "7F 92 33 48", "Mode" => "strict", "Desc" => "Fast_Diagnostics_CAN: securityAccessDenied",                  "DataLength" => "4" },
				"NR_incorrectMessageLengthOrInvalidFormat" => { "Response" => "7F 92 13 28", "Mode" => "strict", "Desc" => "Fast_Diagnostics_CAN::incorrectMessageLengthOrInvalidFormat", "DataLength" => "4" },
			},
		},
		

		#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		"Fast_Diagnostics_Flexray" => {
			"Service_ID"        => "91",
			"Supported_SubFuns" => {},
			"NEG_Responses"     => {
				"NR_requestOutOfRange"                     => { "Response" => "7F 91 31 45", "Mode" => "strict", "Desc" => "Fast_Diagnostics_Flexray :RequestOutOfRange",                     "DataLength" => "4" },
				"NR_conditionsNotCorrect"                  => { "Response" => "7F 91 22 36", "Mode" => "strict", "Desc" => "Fast_Diagnostics_Flexray :conditionsNotCorrect",                  "DataLength" => "4" },
				"NR_securityAccessDenied"                  => { "Response" => "7F 91 33 47", "Mode" => "strict", "Desc" => "Fast_Diagnostics_Flexray: securityAccessDenied",                  "DataLength" => "4" },
				"NR_incorrectMessageLengthOrInvalidFormat" => { "Response" => "7F 91 13 27", "Mode" => "strict", "Desc" => "Fast_Diagnostics_Flexray::incorrectMessageLengthOrInvalidFormat", "DataLength" => "4" },
			},
		},

		#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		"Request_Download" => {
			"Service_ID"        => "34",
			"Supported_SubFuns" => {},
			"NEG_Responses"     => {
				"NR_requestOutOfRange"    => { "Response" => "7F 34 31 E8 ", "Mode" => "strict", "Desc" => "Request_Download :RequestOutOfRange",      "DataLength" => "4" },
				"NR_conditionsNotCorrect" => { "Response" => "7F 34 22 D9",  "Mode" => "strict", "Desc" => "Request_Download :conditionsNotCorrect",   "DataLength" => "4" },
				"NR_requestSequenceError" => { "Response" => "7F 34 24 DB",  "Mode" => "strict", "Desc" => "Request_Download requestSequenceError",    "DataLength" => "4" },
				"NR_securityAccessDenied" => { "Response" => "7F 34 33 EA",  "Mode" => "strict", "Desc" => "Request_Download: securityAccessDenied",   "DataLength" => "4" },
				"NR_serviceNotSupported"  => { "Response" => "7F 34 11 C8",  "Mode" => "strict", "Desc" => "Request_Download: NR_serviceNotSupported", "DataLength" => "4" },
			},
		},

		#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		"Transfer_Data" => {
			"Service_ID"        => "36",
			"Supported_SubFuns" => {},
			"NEG_Responses"     => {
				"NR_requestOutOfRange"    => { "Response" => "7F 36 31 EA ", "Mode" => "strict", "Desc" => "Transfer_Data :RequestOutOfRange",      "DataLength" => "4" },
				"NR_conditionsNotCorrect" => { "Response" => "7F 36 22 DB",  "Mode" => "strict", "Desc" => "Transfer_Data :conditionsNotCorrect",   "DataLength" => "4" },
				"NR_requestSequenceError" => { "Response" => "7F 36 24 DD",  "Mode" => "strict", "Desc" => "Transfer_Data requestSequenceError",    "DataLength" => "4" },
				"NR_securityAccessDenied" => { "Response" => "7F 36 33 EC",  "Mode" => "strict", "Desc" => "Transfer_Data: securityAccessDenied",   "DataLength" => "4" },
				"NR_serviceNotSupported"  => { "Response" => "7F 36 11 CA",  "Mode" => "strict", "Desc" => "Transfer_Data: NR_serviceNotSupported", "DataLength" => "4" },
			},
		},

		#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		"Transfer_Exit" => {
			"Service_ID"        => "37",
			"Supported_SubFuns" => {},
			"NEG_Responses"     => {
				"NR_requestOutOfRange"    => { "Response" => "7F 37 31 EB ", "Mode" => "strict", "Desc" => "Transfer_Exit :RequestOutOfRange",      "DataLength" => "4" },
				"NR_conditionsNotCorrect" => { "Response" => "7F 37 22 DC",  "Mode" => "strict", "Desc" => "Transfer_Exit :conditionsNotCorrect",   "DataLength" => "4" },
				"NR_requestSequenceError" => { "Response" => "7F 37 24 DE",  "Mode" => "strict", "Desc" => "Transfer_Exit requestSequenceError",    "DataLength" => "4" },
				"NR_securityAccessDenied" => { "Response" => "7F 37 33 ED",  "Mode" => "strict", "Desc" => "Transfer_Exit: securityAccessDenied",   "DataLength" => "4" },
				"NR_serviceNotSupported"  => { "Response" => "7F 37 11 CB",  "Mode" => "strict", "Desc" => "Transfer_Exit: NR_serviceNotSupported", "DataLength" => "4" },
			},
		},

		#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

	},    #end of DIAG_SERVICES

	#------------------------------------------------------ Requests_Responses Starts here--------------------------------------------------------------------------

	"Requests_Responses" => {

		#----------------------------------------------------------------------------------------
		#************************** Production Diagnosis request response *******************************
		#----------------------------------------------------------------------------------------

		"SecurityAccess" => {
			"Requests" => {
				"REQ_SecurityAccess__SeedLevel1" => { "Request" => "00 A1" },
				"REQ_SecurityAccess__KeyLevel1"  => { "Request" => "00 A2 Key" },
				"REQ_SecurityAccess__SeedLevel2" => { "Request" => "00 A3" },
				"REQ_SecurityAccess__KeyLevel2"  => { "Request" => "00 A4 Key" },
			},
			"POS_Responses" => {
				"PR_SecurityAccess__SeedLevel1" => { "Response" => "40 A1", "Mode" => "relax", "Desc" => "Positive Response for the Security Seed Request Level 1 ", "DoorsIDs" => [] },
				"PR_SecurityAccess__KeyLevel1"  => { "Response" => "40 A2", "Mode" => "relax", "Desc" => "Positive Response for the Security Key Request Level 1 ",  "DoorsIDs" => [] },

				#byte 10 to 17 should be filled for each checkpoint (SW release)
				#byte no:  02 03 04 05 06 07 08 09 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 53 54
				"PR_SecurityAccess__KeyLevel1AllBytes" => {
					"Response" => "40 A2 0C 81 0B 41 42 12 42 00 00 00 00 00 00 00 00 00 00 00 20 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00",
					"Mode"     => "relax",
					"Desc"     => "Positive Response for the Security Key Request Level 1 ",
					"DoorsIDs" => []
				},
				"PR_SecurityAccess__SeedLevel2" => { "Response" => "40 A3", "Mode" => "relax", "Desc" => "Positive Response for the Security Seed Request Level 2 ", "DoorsIDs" => [] },
				"PR_SecurityAccess__KeyLevel2"  => { "Response" => "40 A4", "Mode" => "relax", "Desc" => "Positive Response for the Security Key Request Level 2",   "DoorsIDs" => [] },
			},
		},

		#**************************************************************************************************************************************************************************************
		"Read_Cell" => {
			"Requests"      => { "REQ_Read_Cell" => { "Request"  => "01 NumberOfCells StartAddress" }, },
			"POS_Responses" => { "PR_Read_Cell"  => { "Response" => "41", "Mode" => "relax", "Desc" => "Positive Response for the Read_Cell Request", "DoorsIDs" => [] }, },
		},

		#**************************************************************************************************************************************************************************************
		"Write_Cell" => {
			"Requests"      => { "REQ_Write_Cell" => { "Request"  => "02 StartAddress CellContentValue" }, },
			"POS_Responses" => { "PR_Write_Cell"  => { "Response" => "42 44", "Mode" => "strict", "Desc" => "Positive Response for the Write_Cell Request", "DoorsIDs" => [] }, },
		},

		#**************************************************************************************************************************************************************************************
		"Update_DataFlashSections" => {
			"Requests"      => { "REQ_Update_DataFlashSections" => { "Request"  => "02  Flash_Section" }, },
			"POS_Responses" => { "PR_Update_DataFlashSections"  => { "Response" => "43 45", "Mode" => "strict", "Desc" => "Positive Response for theUpdate_DataFlashSections", "DoorsIDs" => [] }, },
		},

		#**************************************************************************************************************************************************************************************
		"Clear_Fault_Memory" => {
			"Requests"      => { "REQ_Clear_Fault_Memory" => { "Request"  => "04 Mode" }, },
			"POS_Responses" => { "PR_Clear_Fault_Memory"  => { "Response" => "44 46", "Mode" => "strict", "Desc" => "Positive Response for the Clear_Fault_Memory Request", "DoorsIDs" => [] }, },
		},

		#**************************************************************************************************************************************************************************************
		"Freeze_Fault_Memory" => {
			"Requests"      => { "REQ_Freeze_Fault_Memory" => { "Request"  => "05" }, },
			"POS_Responses" => { "PR_Freeze_Fault_Memory"  => { "Response" => "45 47", "Mode" => "strict", "Desc" => "Positive Response for the Freeze_Fault_Memory Request", "DoorsIDs" => [] }, },
		},

		#**************************************************************************************************************************************************************************************
		"Read_Fault_Memory" => {
			"Requests" => {
				"REQ_Read_Fault_Memory__Plant"              => { "Request" => "10 00" },
				"REQ_Read_Fault_Memory__Primary"            => { "Request" => "10 01" },
				"REQ_Read_Fault_Memory__History"            => { "Request" => "10 02" },
				"REQ_Read_Fault_Memory__Bosch"              => { "Request" => "10 03" },
				"REQ_Read_Fault_Memory__Distrubance"        => { "Request" => "10 04" },
				"REQ_Read_Fault_Memory__InvalidSubFunction" => { "Request" => "10 subfunction" },
			},
			"POS_Responses" => {
				"PR_Read_Fault_Memory__Plant"       => { "Response" => "50 00", "Mode" => "relax", "Desc" => "Positive Response for the Read Fault Memory Plant ",       "DoorsIDs" => [] },
				"PR_Read_Fault_Memory__Primary"     => { "Response" => "50 01", "Mode" => "relax", "Desc" => "Positive Response for the Read Fault Memory Primary ",     "DoorsIDs" => [] },
				"PR_Read_Fault_Memory__History"     => { "Response" => "50 02", "Mode" => "relax", "Desc" => "Positive Response for the Read Fault Memory History ",     "DoorsIDs" => [] },
				"PR_Read_Fault_Memory__Bosch"       => { "Response" => "50 03", "Mode" => "relax", "Desc" => "Positive Response for the Read Fault Memory Bosch ",       "DoorsIDs" => [] },
				"PR_Read_Fault_Memory__Distrubance" => { "Response" => "50 04", "Mode" => "relax", "Desc" => "Positive Response for the Read Fault Memory Distrubance ", "DoorsIDs" => [] },
			},
		},

		#**************************************************************************************************************************************************************************************
		"Read_EDR" => {
			"Requests"      => { "REQ_Read_EDR" => { "Request"  => "07 DID" }, },
			"POS_Responses" => { "PR_Read_EDR"  => { "Response" => "47 DID", "Mode" => "relax", "Desc" => "Positive Response for the Read_EDR Request", "DoorsIDs" => [] }, },
		},

		#**************************************************************************************************************************************************************************************
		"Clear_EDR" => {
			"Requests"      => { "REQ_Clear_EDR" => { "Request"  => "08 00" }, },
			"POS_Responses" => { "PR_Clear_EDR"  => { "Response" => "48 00 4B", "Mode" => "strict", "Desc" => "Positive Response for the Clear_EDR Request", "DoorsIDs" => [] }, },
		},

		#**************************************************************************************************************************************************************************************
		"ECU_Status" => {
			"Requests"      => { "REQ_ECU_Status" => { "Request"  => "09" }, },
			"POS_Responses" => { "PR_ECU_Status"  => { "Response" => "49 ", "Mode" => "relax", "Desc" => "Positive Response for the ECU Status ", "DoorsIDs" => [] }, },
		},
	#**************************************************************************************************************************************************************************************
		"Read_System_ASIC_Serial_number" => {
			"Requests"      => { "REQ_Read_System_ASIC_Serial_number" => { "Request"  => "17" }, },
			"POS_Responses" => { "PR_Read_System_ASIC_Serial_number"  => { "Response" => "57", "Mode" => "relax", "Desc" => "Positive Response for the ECU Status ", "DoorsIDs" => [] }, },
		},
		#**************************************************************************************************************************************************************************************
		"SMI7XY_Verification" => {
			"Requests"      => { "REQ_SMI7XY_Verification" => { "Request"  => "0D SamplingDetails NumberOfSamples" }, },
			"POS_Responses" => { "PR_SMI7XY_Verification"  => { "Response" => "4D SMI700_1 SMI700_2 SMI710_1 SMI710_2 Samples", "Mode" => "relax", "Desc" => "Positive Response for the SMI7XY_Verification Request", "DoorsIDs" => [] }, },
		},
		
		#**************************************************************************************************************************************************************************************
		"SMI8_SMA7_Verification" => {
			"Requests"      => { "REQ_SMI8_SMA7_Verification" => { "Request"  => "0E ControlType SamplingDetails NumberOfSamples" }, },
			"POS_Responses" => { "PR_SMI8_SMA7_Verification"  => { "Response" => "4E ControlType", "Mode" => "relax", "Desc" => "Positive Response for the SMI7XY_Verification Request", "DoorsIDs" => [] }, },
		},

		#**************************************************************************************************************************************************************************************
		"Fast_Diagnostics_CAN" => {
			"Requests"      => { "REQ_Fast_Diagnostics_CAN" => { "Request" => "90 Options NumberOfCells RAM_Address" }, },
			"POS_Responses" => {
				"PR_Fast_Diagnostics_CAN"         => { "Response" => "",    "Mode" => "optional relax", "Desc" => "Positive Response for the  Fast Diagnostics using CAN", "DoorsIDs" => [] },
				"PR_Fast_Diagnostics_CAN_StartUp" => { "Response" => "D0 ", "Mode" => "relax",          "Desc" => "Positive Response for the  Fast Diagnostics using CAN", "DoorsIDs" => [] },
			},
		},

		#**************************************************************************************************************************************************************************************
		"Fast_Diagnostics_CANFD" => {
			"Requests"      => { "REQ_Fast_Diagnostics_CANFD" => { "Request" => "92 Options NumberOfCells RAM_Address" }, },
			"POS_Responses" => {
				"PR_Fast_Diagnostics_CANFD"         => { "Response" => "",    "Mode" => "optional relax", "Desc" => "Positive Response for the  Fast Diagnostics using CANFD", "DoorsIDs" => [] },
				"PR_Fast_Diagnostics_CANFD_StartUp" => { "Response" => "D2 ", "Mode" => "relax",          "Desc" => "Positive Response for the  Fast Diagnostics using CANFD", "DoorsIDs" => [] },
			},
		},

		#**************************************************************************************************************************************************************************************
		"Fast_Diagnostics_Flexray" => {
			"Requests"      => { "REQ_Fast_Diagnostics_Flexray" => { "Request"  => "91 No_CellRead FD_StartupRAM_Address" }, },
			"POS_Responses" => { "PR_Fast_Diagnostics_Flexray"  => { "Response" => "D1 ", "Mode" => "relax", "Desc" => "Positive Response for the  Fast Diagnostics using Flexray", "DoorsIDs" => [] }, },
		},

		#**************************************************************************************************************************************************************************************
		"Verify_Data_ByCRC" => {
			"Requests"      => { "REQ_Verify_Data_ByCRC" => { "Request"  => "11" }, },
			"POS_Responses" => { "PR_Verify_Data_ByCRC"  => { "Response" => "51", "Mode" => "relax", "Desc" => "Positive Response for the Verify_Data_ByCRC  Request", "DoorsIDs" => [] }, },
		},

		#**************************************************************************************************************************************************************************************
		"Reset" => {
			"Requests"      => { "REQ_Reset" => { "Request"  => "12 ResetType" }, },
			"POS_Responses" => { "PR_Reset"  => { "Response" => "52", "Mode" => "relax", "Desc" => "Positive Response for the Reset Request", "DoorsIDs" => [] }, },
		},

		#**************************************************************************************************************************************************************************************
		"Fault_Memory_Manipulation" => {
			"Requests"      => { "REQ_Fault_Memory_Manipulation" => { "Request"  => "13 EventID Request_Type" }, },
			"POS_Responses" => { "PR_Fault_Memory_Manipulation"  => { "Response" => "53 55", "Mode" => "strict", "Desc" => "Positive Response for the Fault_Memory_Manipulation Request", "DoorsIDs" => [] }, },
		},

		#**************************************************************************************************************************************************************************************
		"Read_NVM_Cells" => {

			#NVMBlockDetails: Byte 5 to 8
			#5: NVMIndication nibble + NVMBlockID high nibble
			#6: NVMBlockID mid nibble + NVMBlockID low nibble
			#7: NVMSubBlockID nibble + Offset high nibble
			#8: Offset mid nibble + Offset low nibble

			"Requests"      => { "REQ_Read_NVM_Cells" => { "Request"  => "14 NumberOfCells NVMBlockDetails" }, },
			"POS_Responses" => { "PR_Read_NVM_Cells"  => { "Response" => "54", "Mode" => "relax", "Desc" => "Positive Response for the Read_NVM_Cells Request", "DoorsIDs" => [] }, },
		},

		#**************************************************************************************************************************************************************************************
		"Write_NVM_Cells" => {

			#NVMBlockDetails: Byte 5 to 8
			#5: NVMIndication nibble + NVMBlockID high nibble
			#6: NVMBlockID mid nibble + NVMBlockID low nibble
			#7: NVMSubBlockID nibble + Offset high nibble
			#8: Offset mid nibble + Offset low nibble

			"Requests"      => { "REQ_Write_NVM_Cells" => { "Request"  => "15 NumberOfCells NVMBlockDetails CellContentValue" }, },
			"POS_Responses" => { "PR_Write_NVM_Cells"  => { "Response" => "55 57", "Mode" => "strict", "Desc" => "Positive Response for the Write_NVM_Cells Request", "DoorsIDs" => [] }, },
		},

		#**************************************************************************************************************************************************************************************
		"Enable_Safety_Path" => {
			"Requests"      => { "REQ_Enable_Safety_Path" => { "Request"  => "18 Key" }, },
			"POS_Responses" => { "PR_Enable_Safety_Path"  => { "Response" => "58 5A", "Mode" => "strict", "Desc" => "Positive Response for the Enable_Safety_Path Request", "DoorsIDs" => [] }, },
		},

		#**************************************************************************************************************************************************************************************
		"Fire_All_Devices" => {
			"Requests"      => { "REQ_Fire_All_Devices" => { "Request"  => "19" }, },
			"POS_Responses" => { "PR_Fire_All_Devices"  => { "Response" => "59", "Mode" => "relax", "Desc" => "Positive Response for the Fire_All_Devices Request", "DoorsIDs" => [] }, },
		},

		#**************************************************************************************************************************************************************************************
		"Request_Download" => {
			"Requests"      => { "REQ_Request_Download" => { "Request"  => "34 DataFormatIdentifier AddressAndLengthFormatIdentifier MemoryAddress DownloadDataSize" }, },
			"POS_Responses" => { "PR_Request_Download"  => { "Response" => "74 00 00 68", "Mode" => "relax", "Desc" => "Positive Response for the Request_Download Request", "DoorsIDs" => [] }, },
		},

		#**************************************************************************************************************************************************************************************
		"Transfer_Data" => {
			"Requests"      => { "REQ_Transfer_Data" => { "Request"  => "36 BlockSequenceCounter DataBytes" }, },
			"POS_Responses" => { "PR_Transfer_Data"  => { "Response" => "76", "Mode" => "relax", "Desc" => "Positive Response for the Transfer Data", "DoorsIDs" => [] }, },
		},

		#**************************************************************************************************************************************************************************************
		"Transfer_Exit" => {
			"Requests"      => { "REQ_Transfer_Exit" => { "Request"  => "37" }, },
			"POS_Responses" => { "PR_Transfer_Exit"  => { "Response" => "77 79", "Mode" => "relax", "Desc" => "Positive Response for the Transfer_Exit Request", "DoorsIDs" => [] }, },
		},

		#**************************************************************************************************************************************************************************************
		"NotSupported_Service" => {
			"Requests"      => { "REQ_Read_Cell" => { "Request"  => "req" }, },
			"POS_Responses" => { "PR_Read_Cell"  => { "Response" => "41", "Mode" => "relax", "Desc" => "Positive Response for the Read_Cell Request", "DoorsIDs" => [] }, },
		},

		#**************************************************************************************************************************************************************************************

	},
	"label_value_mapping" => {

		#-------------------------------------------------------------------------------------
	},    # end of label_value_mapping

	#----------------------------------------------------------------

	"Response_Phys2Hex" => {

	},    # end of Response_Phys2Hex

};    # end of DIAG mapping
1;
