package LIFT_PROJECT;

our $Defaults;
$Defaults = {

    'VEHICLE' => {
        'U_BATT_DEFAULT'                      => 13.5,
        'U_BATT_LINEFAULT'                    => 13.5,
        'KL15_Zyklus_voltage'                 => 9.05,
        'U_BATT_UNDERVOLTAGE'                 => 6.2,
        'U_BATT_OVERVOLTAGE'                  => 19.8,
        'ISO_FAULTMEMORY'                     => 1,
        'SWITCH_EVALUATION_VOLTAGE_RANGE_MAX' => 19.5,    #V #swm
        'SWITCH_EVALUATION_VOLTAGE_RANGE_MIN' => 6.5,     #V #swm
        'SWITCH_EVALUATION_VOLTAGE_RANGE_MID' => 13.0,    #V #swm
        'ITM_Init_Time_ms'                    => 5008,    # (Value from RT3 only)  FaultList Test -> https://connect.bosch.com/wikis/home?lang=de-de#!/wiki/Wad0c302c3442_4748_8eef_7d10157fb564/page/ITM%20Initialization%20Time

    },
    'TIMER' => {
        'TIMER_ECU_READY'               => 6000,
        'TIMER_ECU_READY_WITHINITDELAY' => 10000,         #wait time after power on, when ITM init delay is enabled
        'TIMER_DIAGNOSIS'               => 1500,
        'TIMER_ECU_OFF'                 => 6000,
        'TIMER_SIX_SEC'                 => 6000,          #swm
        'SWITCH_STATE_CHANGE_TIME'      => 500,           # ms #check this #swm
        'ITMinitdelay'                  => 4000,          #swm
        'TIMER_ECU_FAULT_QUALIFICATION' => 10000,         # wait time for fault qualification
    },

    'ProdDiag' => {
        'ProjectName' => 'BOSCH',    # project name, possible values are 'TakeFromPSDiag' or
                                            # a CANType from PSDiag_CAN_Parameter.txt, e.g. 'BOSCH_CAN_03' or 'FORD_CAN_05' or
                                            # a FlexrayType from TBD (this is not yet supported by PDLayer.dll)
    },

	'CUSTOMER_DIAGNOSIS' => {

		####################-------------------CD SECTION--------------------#########################

		#Functional address
		'RequestID_functional'     => '0x6ec',    #as hex string
		'ResponseID_functional'    => '0x4fc',    #as hex string
		'FlowControlID_functional' => '0x6ec',
		'Timeout_functional'       => 10000,      #in milliseconds,CD function will convert it to second
		'P3_mintime_functional'    => 100,
		###################################################

		#Physical address
		'RequestID_physical'     => '0x6DC',      #as hex string
		'ResponseID_physical'    => '0x4FC',      #as hex string
		'FlowControlID_physical' => '0x6DC',
		'Timeout_physical'       => 10000,
		'P3_mintime_physical'    => 100,

		#Disposal address
		####################################################
		'RequestID_disposal'     => '0x7F1',      #as hex string
		'ResponseID_disposal'    => '0x7F9',      #as hex string
		'FlowControlID_disposal' => '0x715',
		'Timeout_disposal'       => 10000,
		'P3_mintime_disposal'    => 100,

		#General
		####################################################
		'RequestID_CD'           => '0x6DC',                                               #as hex string
		'ResponseID_CD'          => '0x4FC',                                               #as hex string
		'FlowControlID_CD'       => '0x6DC',
		'Timeout_CD'             => 10000,
		'P3_mintime_CD'          => 10000,
		'FlowControl'            => [ 0x30, 0x00, 0x01 ],
		'clearDTC'               => [ 0x14, 0xff, 0xff, 0xff ],                            # Bytes as array ref
		'DTC_SAM'                => '0b10011001',                                          # DTC Status availability Mask
		'SAM'                    => 1,
		'SJW'                    => 3,
		'Tseg1'                  => 0xc,
		'Tseg2'                  => 3,
		'Baudrate'               => 500000,
		'DLCmode'                => 0,                                                     # 0 for 8 byte, 1 for dynamic DLC
		'DTCdefaultstate'        => 0x08,                                                  # read current fault
		'DTCbytes'               => 3,                                                     # bytes per DTC
		'ExtID'                  => 0,                                                     # 1 for Extended Identifier, 0 for Standard
		'ExtAddressing'          => 0,                                                     # 1 for Extended Addressing, 0 for Normal
		'EcuAddr'                => 0x01,                                                  # ECU id for Extended Addressing.
		'TargetAddr'             => 0x55,                                                  # Target address for Extended Addressing.
		'CAN_TesterPresent_Req'  => [ 0x02, 0x3E, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00 ],    # do not add DLC in the request
		'CAN_TesterPresent_Time' => 4000,                                                  # cyclic TP cycle time is milli sec
		'DISABLE'                => 0,                                                     # optional, to disable all CD features (similar to debug mode)
		'DTCdefaultsubfunction'  => '02',

		####################-------------------PROD SECTION--------------------#########################

		#For Valid PD ID
		'RequestID_PD'     => '0x650',                                                     #as hex string
		'ResponseID_PD'    => '0x651',                                                     #as hex string
		'FlowControlID_PD' => '0x650',
		'Timeout_PD'       => 10000,
		'P3_mintime_PD'    => 4000,

		####################################################
		#for Fast Diagnosis - multiple response frames
		'ResponseID1_FD_PD' => '0x651',                                                    #as hex string
		'ResponseID2_FD_PD' => '0x652',                                                    #as hex string
		'ResponseID3_FD_PD' => '0x653',                                                    #as hex string
		'ResponseID4_FD_PD' => '0x654',                                                    #as hex string

		####################################################
		#1mS wait time
		'RequestID_PD_Notimeout'     => '0x650',                                           #as hex string
		'ResponseID_PD_Notimeout'    => '0x651',                                           #as hex string
		'FlowControlID_PD_Notimeout' => '0x650',
		'Timeout_PD_Notimeout'       => 1,
		'P3_mintime_PD_Notimeout'    => 400,

		####################################################
		#For Valid PD Invalid
		'RequestID_Invalid'     => '0x500',                                                #as hex string
		'ResponseID_Invalid'    => '0x501',                                                #as hex string
		'FlowControlID_Invalid' => '0x500',
		'Timeout_Invalid'       => 5000,
		'P3_mintime_Invalid'    => 400,

	},
########################################################################################################################
    # here you can define global optional faults for every test, for example if you have always variant coding info in EEPROM
    # 'TEMP_OPTIONAL_FAULTS' -> fault is ignored completely
    # 'TEMP_DISTRUB_FAULTS'  -> fault is ignored if only disturb bit is set
    # 'TEMP_DISTRUB_FAULTS'  => [ 'ALL' ] will ignore all faults where only disturb bit is set
    # e.g. 'TEMP_OPTIONAL_FAULTS' => [ 'FltVdsPitchRateSensorMonitoring' , 'FltVdsYawRateSensorMonitoring' ],
########################################################################################################################
	'ECU_HW_INFO' => {

		# Fingerprint is KEY
		'5CD13142#92763C716939' => {    # hostname : BIE1-C-00001   // RT4 (BAT)
			'TT_No'        => '0 285 B06 015-01',
			'HW_version'   => 'AB12.1 AP2400.01 RT4',
			'HW_serial_no' => 'H01-014',
		},
		'DC95DF65#2AA3E9E97538' => {    # hostname : BIEZ00HL     // RT4 (TA Team TSG4)
			'TT_No'        => '0 285 B09 728 - 01',
			'HW_version'   => 'AB12.1 AP2400.01 RT4',
			'HW_serial_no' => 'H11-027 - modified for crash injection',
		},
		'7036A6D2#06B10C2D68DD' => {                                       # hostname : BIE1-C-00000   // RT4 (TA Team Peribox + Manitoo)
			'TT_No'        => '0 285 B09 728 - 01',
			'HW_version'   => 'AB12.1 AP2400.01 RT4',
			'HW_serial_no' => 'H11-061 - modified for SPI manipulation',
		},
		'736149E0#6844A8A6B729' => {                                       # hostname : BIE1-C-00003   // RT3.2 (BAT)
			'TT_No'        => '0 285 B06 117 - 01',
			'HW_version'   => 'AB12 AP2303 RT3 V02',
			'HW_serial_no' => 'FFFFFFFFFFFFFFFFFFF',
		},
	},


    'TEMP_OPTIONAL_FAULTS' => [ 
#        'rb_coa_VehSpdRxMsgTimeout_flt', 
#        'rb_acc_AlgoVerifySensorId_flt', 
    ],

    'EVALUATION_FILE' => {
        'USED'          => 1,
        'DELIMITER'     => ';',         ### useful are: chr(9) is TAB or ';'
        'EMPTY_CHAR'    => ' - - - ',
        'SIGNAL_MARKER' => 'SIG: ',     ### marker to identify the label of the checked signal
        'EXPECT_MARKER' => 'EXP: ',     ### marker to identify the 'MUST' / 'SOLL'
        'DETECT_MARKER' => 'FND: ',     ### marker to identify the 'REAL' / 'IST'
        'JUST_VERDICTS' => {
            'VERDICT_FAIL'   => 1,
            'VERDICT_INCONC' => 1,
            'VERDICT_NONE'   => 1,
            'VERDICT_PASS'   => 1,
        },

        'COLUMN_ORDER' => [ 'NBR', 'DATE_TIME', 'TC_ID', 'Stimulation', 'EXP', 'DET', 'MISMATCH', 'VERDICT' ],

    },
};

$Defaults->{'CSM'} = {
    'LocalWorkingArea_Path' => 'C:\temp\CSM_Local_Working_Area',
    'StorageArea_Path'      => 'C:\TurboLIFT\_StorageArea_CSM_development',
    'disable_CSM'           => 0,
};
1;
