### file generated with 
### input dbc files:
### => C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc
package LIFT_PROJECT;

$Defaults->{"Mapping_NET_Access_CANFD"} = {
'MSGS_OR_PDUS_OR_FRAMES'  => {
      'CANFD1::EXT_PCP_MSG' => { 
                                'ID'                => 120, 
                                'DLC'               => 2, 
                                'SENDER'            => 'Other_ECU', 
                                'CYCLE'             => 20, 
                                'CANOE_ENABLE'      => 'E_C1EXT_PCP_MSG_Enable', 
                                'CANOE_DLC'         => 'E_C1EXT_PCP_MSG_Dlc', 
                                'CANOE_CYCLETIME'   => 'E_C1EXT_PCP_MSG_CycleTime', 
                                'CANOE_VALIDCRC'    => 'E_C1EXT_PCP_MSG_ValidCRC', 
                                'CANOE_VALIDCNT'    => 'E_C1EXT_PCP_MSG_ValidCnt', 
                            },

      'CANFD1::BMI_EMN_MSG' => { 
                                'ID'                => 121, 
                                'DLC'               => 2, 
                                'SENDER'            => 'Other_ECU', 
                                'CYCLE'             => 20, 
                                'CANOE_ENABLE'      => 'E_C1BMI_EMN_MSG_Enable', 
                                'CANOE_DLC'         => 'E_C1BMI_EMN_MSG_Dlc', 
                                'CANOE_CYCLETIME'   => 'E_C1BMI_EMN_MSG_CycleTime', 
                                'CANOE_VALIDCRC'    => 'E_C1BMI_EMN_MSG_ValidCRC', 
                                'CANOE_VALIDCNT'    => 'E_C1BMI_EMN_MSG_ValidCnt', 
                            },

      'CANFD1::ISS_Sync' => { 
                                'ID'                => 128, 
                                'DLC'               => 6, 
                                'SENDER'            => 'MRR', 
                                'CYCLE'             => 20, 
                                'CANOE_ENABLE'      => 'E_C1ISS_Sync_Enable', 
                                'CANOE_DLC'         => 'E_C1ISS_Sync_Dlc', 
                                'CANOE_CYCLETIME'   => 'E_C1ISS_Sync_CycleTime', 
                                'CANOE_VALIDCRC'    => 'E_C1ISS_Sync_ValidCRC', 
                                'CANOE_VALIDCNT'    => 'E_C1ISS_Sync_ValidCnt', 
                            },

      'CANFD1::IDF_01' => { 
                                'ID'                => 129, 
                                'DLC'               => 8, 
                                'SENDER'            => 'MRR', 
                                'CYCLE'             => 20, 
                                'CANOE_ENABLE'      => 'E_C1IDF_01_Enable', 
                                'CANOE_DLC'         => 'E_C1IDF_01_Dlc', 
                                'CANOE_CYCLETIME'   => 'E_C1IDF_01_CycleTime', 
                                'CANOE_VALIDCRC'    => 'E_C1IDF_01_ValidCRC', 
                                'CANOE_VALIDCNT'    => 'E_C1IDF_01_ValidCnt', 
                            },

      'CANFD1::VDC_01' => { 
                                'ID'                => 131, 
                                'DLC'               => 6, 
                                'SENDER'            => 'Other_ECU', 
                                'CYCLE'             => 20, 
                                'CANOE_ENABLE'      => 'E_C1VDC_01_Enable', 
                                'CANOE_DLC'         => 'E_C1VDC_01_Dlc', 
                                'CANOE_CYCLETIME'   => 'E_C1VDC_01_CycleTime', 
                                'CANOE_VALIDCRC'    => 'E_C1VDC_01_ValidCRC', 
                                'CANOE_VALIDCNT'    => 'E_C1VDC_01_ValidCnt', 
                            },

      'CANFD1::DRV_01' => { 
                                'ID'                => 132, 
                                'DLC'               => 3, 
                                'SENDER'            => 'Other_ECU', 
                                'CYCLE'             => 20, 
                                'CANOE_ENABLE'      => 'E_C1DRV_01_Enable', 
                                'CANOE_DLC'         => 'E_C1DRV_01_Dlc', 
                                'CANOE_CYCLETIME'   => 'E_C1DRV_01_CycleTime', 
                                'CANOE_VALIDCRC'    => 'E_C1DRV_01_ValidCRC', 
                                'CANOE_VALIDCNT'    => 'E_C1DRV_01_ValidCnt', 
                            },

      'CANFD1::MSB_FD' => { 
                                'ID'                => 134, 
                                'DLC'               => 1, 
                                'SENDER'            => 'Other_ECU', 
                                'CYCLE'             => 20, 
                                'CANOE_ENABLE'      => 'E_C1MSB_FD_Enable', 
                                'CANOE_DLC'         => 'E_C1MSB_FD_Dlc', 
                                'CANOE_CYCLETIME'   => 'E_C1MSB_FD_CycleTime', 
                                'CANOE_VALIDCRC'    => 'E_C1MSB_FD_ValidCRC', 
                                'CANOE_VALIDCNT'    => 'E_C1MSB_FD_ValidCnt', 
                            },

      'CANFD1::MSB_FP' => { 
                                'ID'                => 135, 
                                'DLC'               => 1, 
                                'SENDER'            => 'Other_ECU', 
                                'CYCLE'             => 20, 
                                'CANOE_ENABLE'      => 'E_C1MSB_FP_Enable', 
                                'CANOE_DLC'         => 'E_C1MSB_FP_Dlc', 
                                'CANOE_CYCLETIME'   => 'E_C1MSB_FP_CycleTime', 
                                'CANOE_VALIDCRC'    => 'E_C1MSB_FP_ValidCRC', 
                                'CANOE_VALIDCNT'    => 'E_C1MSB_FP_ValidCnt', 
                            },

      'CANFD1::MSB_RD' => { 
                                'ID'                => 136, 
                                'DLC'               => 1, 
                                'SENDER'            => 'Other_ECU', 
                                'CYCLE'             => 20, 
                                'CANOE_ENABLE'      => 'E_C1MSB_RD_Enable', 
                                'CANOE_DLC'         => 'E_C1MSB_RD_Dlc', 
                                'CANOE_CYCLETIME'   => 'E_C1MSB_RD_CycleTime', 
                                'CANOE_VALIDCRC'    => 'E_C1MSB_RD_ValidCRC', 
                                'CANOE_VALIDCNT'    => 'E_C1MSB_RD_ValidCnt', 
                            },

      'CANFD1::MSB_RC' => { 
                                'ID'                => 137, 
                                'DLC'               => 1, 
                                'SENDER'            => 'Other_ECU', 
                                'CYCLE'             => 20, 
                                'CANOE_ENABLE'      => 'E_C1MSB_RC_Enable', 
                                'CANOE_DLC'         => 'E_C1MSB_RC_Dlc', 
                                'CANOE_CYCLETIME'   => 'E_C1MSB_RC_CycleTime', 
                                'CANOE_VALIDCRC'    => 'E_C1MSB_RC_ValidCRC', 
                                'CANOE_VALIDCNT'    => 'E_C1MSB_RC_ValidCnt', 
                            },

      'CANFD1::MSB_RP' => { 
                                'ID'                => 144, 
                                'DLC'               => 1, 
                                'SENDER'            => 'Other_ECU', 
                                'CYCLE'             => 20, 
                                'CANOE_ENABLE'      => 'E_C1MSB_RP_Enable', 
                                'CANOE_DLC'         => 'E_C1MSB_RP_Dlc', 
                                'CANOE_CYCLETIME'   => 'E_C1MSB_RP_CycleTime', 
                                'CANOE_VALIDCRC'    => 'E_C1MSB_RP_ValidCRC', 
                                'CANOE_VALIDCNT'    => 'E_C1MSB_RP_ValidCnt', 
                            },

      'CANFD1::GGCC' => { 
                                'ID'                => 256, 
                                'DLC'               => 8, 
                                'SENDER'            => 'Other_ECU', 
                                'CYCLE'             => 400, 
                                'CANOE_ENABLE'      => 'E_C1GGCC_Enable', 
                                'CANOE_DLC'         => 'E_C1GGCC_Dlc', 
                                'CANOE_CYCLETIME'   => 'E_C1GGCC_CycleTime', 
                                'CANOE_VALIDCRC'    => 'E_C1GGCC_ValidCRC', 
                                'CANOE_VALIDCNT'    => 'E_C1GGCC_ValidCnt', 
                            },

      'CANFD1::Veh_Speed_dashboard' => { 
                                'ID'                => 512, 
                                'DLC'               => 4, 
                                'SENDER'            => 'Other_ECU', 
                                'CYCLE'             => 20, 
                                'CANOE_ENABLE'      => 'E_C1Veh_Speed_dashboard_Enable', 
                                'CANOE_DLC'         => 'E_C1Veh_Speed_dashboard_Dlc', 
                                'CANOE_CYCLETIME'   => 'E_C1Veh_Speed_dashboa1_CycleTime', 
                                'CANOE_VALIDCRC'    => 'E_C1Veh_Speed_dashboard_ValidCRC', 
                                'CANOE_VALIDCNT'    => 'E_C1Veh_Speed_dashboard_ValidCnt', 
                            },

      'CANFD1::EdrData_01' => { 
                                'ID'                => 768, 
                                'DLC'               => 8, 
                                'SENDER'            => 'Other_ECU', 
                                'CYCLE'             => 100, 
                                'CANOE_ENABLE'      => 'E_C1EdrData_01_Enable', 
                                'CANOE_DLC'         => 'E_C1EdrData_01_Dlc', 
                                'CANOE_CYCLETIME'   => 'E_C1EdrData_01_CycleTime', 
                                'CANOE_VALIDCRC'    => 'E_C1EdrData_01_ValidCRC', 
                                'CANOE_VALIDCNT'    => 'E_C1EdrData_01_ValidCnt', 
                            },

      'CANFD1::EdrData_02' => { 
                                'ID'                => 769, 
                                'DLC'               => 8, 
                                'SENDER'            => 'Other_ECU', 
                                'CYCLE'             => 100, 
                                'CANOE_ENABLE'      => 'E_C1EdrData_02_Enable', 
                                'CANOE_DLC'         => 'E_C1EdrData_02_Dlc', 
                                'CANOE_CYCLETIME'   => 'E_C1EdrData_02_CycleTime', 
                                'CANOE_VALIDCRC'    => 'E_C1EdrData_02_ValidCRC', 
                                'CANOE_VALIDCNT'    => 'E_C1EdrData_02_ValidCnt', 
                            },

      'CANFD1::EdrData_03' => { 
                                'ID'                => 770, 
                                'DLC'               => 4, 
                                'SENDER'            => 'Other_ECU', 
                                'CYCLE'             => 100, 
                                'CANOE_ENABLE'      => 'E_C1EdrData_03_Enable', 
                                'CANOE_DLC'         => 'E_C1EdrData_03_Dlc', 
                                'CANOE_CYCLETIME'   => 'E_C1EdrData_03_CycleTime', 
                                'CANOE_VALIDCRC'    => 'E_C1EdrData_03_ValidCRC', 
                                'CANOE_VALIDCNT'    => 'E_C1EdrData_03_ValidCnt', 
                            },

      'CANFD1::EdrData_04' => { 
                                'ID'                => 771, 
                                'DLC'               => 5, 
                                'SENDER'            => 'Other_ECU', 
                                'CYCLE'             => 100, 
                                'CANOE_ENABLE'      => 'E_C1EdrData_04_Enable', 
                                'CANOE_DLC'         => 'E_C1EdrData_04_Dlc', 
                                'CANOE_CYCLETIME'   => 'E_C1EdrData_04_CycleTime', 
                                'CANOE_VALIDCRC'    => 'E_C1EdrData_04_ValidCRC', 
                                'CANOE_VALIDCNT'    => 'E_C1EdrData_04_ValidCnt', 
                            },

      'CANFD1::Airbag01' => { 
                                'ID'                => 1024, 
                                'DLC'               => 8, 
                                'SENDER'            => 'AB_ECU', 
                                'CYCLE'             => 20, 
                                'CANOE_ENABLE'      => 'E_C1Airbag01_Enable', 
                                'CANOE_DLC'         => 'E_C1Airbag01_Dlc', 
                                'CANOE_CYCLETIME'   => 'E_C1Airbag01_CycleTime', 
                                'CANOE_VALIDCRC'    => 'E_C1Airbag01_ValidCRC', 
                                'CANOE_VALIDCNT'    => 'E_C1Airbag01_ValidCnt', 
                            },

      'CANFD1::Airbag_MSB' => { 
                                'ID'                => 1026, 
                                'DLC'               => 3, 
                                'SENDER'            => 'AB_ECU', 
                                'CYCLE'             => 20, 
                                'CANOE_ENABLE'      => 'E_C1Airbag_MSB_Enable', 
                                'CANOE_DLC'         => 'E_C1Airbag_MSB_Dlc', 
                                'CANOE_CYCLETIME'   => 'E_C1Airbag_MSB_CycleTime', 
                                'CANOE_VALIDCRC'    => 'E_C1Airbag_MSB_ValidCRC', 
                                'CANOE_VALIDCNT'    => 'E_C1Airbag_MSB_ValidCnt', 
                            },

      'CANFD1::CustDiag_Physical_Response' => { 
                                'ID'                => 1276, 
                                'DLC'               => 8, 
                                'SENDER'            => 'AB_ECU', 
                                'CYCLE'             => 10, 
                                'CANOE_ENABLE'      => 'E_C1CustDiag_Physical_Re2_Enable', 
                                'CANOE_DLC'         => 'E_C1CustDiag_Physical_Respo3_Dlc', 
                                'CANOE_CYCLETIME'   => 'E_C1CustDiag_Physical4_CycleTime', 
                                'CANOE_VALIDCRC'    => 'E_C1CustDiag_Physical_5_ValidCRC', 
                                'CANOE_VALIDCNT'    => 'E_C1CustDiag_Physical_6_ValidCnt', 
                            },

      'CANFD1::FLM_env_data' => { 
                                'ID'                => 1280, 
                                'DLC'               => 3, 
                                'SENDER'            => 'Other_ECU', 
                                'CYCLE'             => 1000, 
                                'CANOE_ENABLE'      => 'E_C1FLM_env_data_Enable', 
                                'CANOE_DLC'         => 'E_C1FLM_env_data_Dlc', 
                                'CANOE_CYCLETIME'   => 'E_C1FLM_env_data_CycleTime', 
                                'CANOE_VALIDCRC'    => 'E_C1FLM_env_data_ValidCRC', 
                                'CANOE_VALIDCNT'    => 'E_C1FLM_env_data_ValidCnt', 
                            },

      'CANFD1::Temperature' => { 
                                'ID'                => 1296, 
                                'DLC'               => 8, 
                                'SENDER'            => 'Other_ECU', 
                                'CYCLE'             => 200, 
                                'CANOE_ENABLE'      => 'E_C1Temperature_Enable', 
                                'CANOE_DLC'         => 'E_C1Temperature_Dlc', 
                                'CANOE_CYCLETIME'   => 'E_C1Temperature_CycleTime', 
                                'CANOE_VALIDCRC'    => 'E_C1Temperature_ValidCRC', 
                                'CANOE_VALIDCNT'    => 'E_C1Temperature_ValidCnt', 
                            },

      'CANFD1::Sensordata' => { 
                                'ID'                => 1536, 
                                'DLC'               => 8, 
                                'SENDER'            => 'AB_ECU', 
                                'CYCLE'             => 10, 
                                'CANOE_ENABLE'      => 'E_C1Sensordata_Enable', 
                                'CANOE_DLC'         => 'E_C1Sensordata_Dlc', 
                                'CANOE_CYCLETIME'   => 'E_C1Sensordata_CycleTime', 
                                'CANOE_VALIDCRC'    => 'E_C1Sensordata_ValidCRC', 
                                'CANOE_VALIDCNT'    => 'E_C1Sensordata_ValidCnt', 
                            },

      'CANFD1::ProDiag_Request' => { 
                                'ID'                => 1616, 
                                'DLC'               => 8, 
                                'SENDER'            => 'Tester', 
                                'CYCLE'             => 10, 
                                'CANOE_ENABLE'      => 'E_C1ProDiag_Request_Enable', 
                                'CANOE_DLC'         => 'E_C1ProDiag_Request_Dlc', 
                                'CANOE_CYCLETIME'   => 'E_C1ProDiag_Request_CycleTime', 
                                'CANOE_VALIDCRC'    => 'E_C1ProDiag_Request_ValidCRC', 
                                'CANOE_VALIDCNT'    => 'E_C1ProDiag_Request_ValidCnt', 
                            },

      'CANFD1::ProDiag_Response1' => { 
                                'ID'                => 1617, 
                                'DLC'               => 8, 
                                'SENDER'            => 'AB_ECU', 
                                'CYCLE'             => 10, 
                                'CANOE_ENABLE'      => 'E_C1ProDiag_Response1_Enable', 
                                'CANOE_DLC'         => 'E_C1ProDiag_Response1_Dlc', 
                                'CANOE_CYCLETIME'   => 'E_C1ProDiag_Response1_CycleTime', 
                                'CANOE_VALIDCRC'    => 'E_C1ProDiag_Response1_ValidCRC', 
                                'CANOE_VALIDCNT'    => 'E_C1ProDiag_Response1_ValidCnt', 
                            },

      'CANFD1::ProDiag_Response2' => { 
                                'ID'                => 1618, 
                                'DLC'               => 8, 
                                'SENDER'            => 'AB_ECU', 
                                'CYCLE'             => 10, 
                                'CANOE_ENABLE'      => 'E_C1ProDiag_Response2_Enable', 
                                'CANOE_DLC'         => 'E_C1ProDiag_Response2_Dlc', 
                                'CANOE_CYCLETIME'   => 'E_C1ProDiag_Response2_CycleTime', 
                                'CANOE_VALIDCRC'    => 'E_C1ProDiag_Response2_ValidCRC', 
                                'CANOE_VALIDCNT'    => 'E_C1ProDiag_Response2_ValidCnt', 
                            },

      'CANFD1::ProDiag_Response3' => { 
                                'ID'                => 1619, 
                                'DLC'               => 8, 
                                'SENDER'            => 'AB_ECU', 
                                'CYCLE'             => 10, 
                                'CANOE_ENABLE'      => 'E_C1ProDiag_Response3_Enable', 
                                'CANOE_DLC'         => 'E_C1ProDiag_Response3_Dlc', 
                                'CANOE_CYCLETIME'   => 'E_C1ProDiag_Response3_CycleTime', 
                                'CANOE_VALIDCRC'    => 'E_C1ProDiag_Response3_ValidCRC', 
                                'CANOE_VALIDCNT'    => 'E_C1ProDiag_Response3_ValidCnt', 
                            },

      'CANFD1::ProDiag_Response4' => { 
                                'ID'                => 1620, 
                                'DLC'               => 8, 
                                'SENDER'            => 'AB_ECU', 
                                'CYCLE'             => 10, 
                                'CANOE_ENABLE'      => 'E_C1ProDiag_Response4_Enable', 
                                'CANOE_DLC'         => 'E_C1ProDiag_Response4_Dlc', 
                                'CANOE_CYCLETIME'   => 'E_C1ProDiag_Response4_CycleTime', 
                                'CANOE_VALIDCRC'    => 'E_C1ProDiag_Response4_ValidCRC', 
                                'CANOE_VALIDCNT'    => 'E_C1ProDiag_Response4_ValidCnt', 
                            },

      'CANFD1::PrdFastDiagRespViaCANFD1' => { 
                                'ID'                => 1621, 
                                'DLC'               => 1, 
                                'SENDER'            => 'AB_ECU', 
                                'CYCLE'             => 10, 
                                'CANOE_ENABLE'      => 'E_C1PrdFastDiagRespViaCA7_Enable', 
                                'CANOE_DLC'         => 'E_C1PrdFastDiagRespViaCANFD1_Dlc', 
                                'CANOE_CYCLETIME'   => 'E_C1PrdFastDiagRespVi8_CycleTime', 
                                'CANOE_VALIDCRC'    => 'E_C1PrdFastDiagRespVia9_ValidCRC', 
                                'CANOE_VALIDCNT'    => 'E_C1PrdFastDiagRespVi10_ValidCnt', 
                            },

      'CANFD1::PrdFastDiagRespViaCANFD2' => { 
                                'ID'                => 1622, 
                                'DLC'               => 1, 
                                'SENDER'            => 'AB_ECU', 
                                'CYCLE'             => 10, 
                                'CANOE_ENABLE'      => 'E_C1PrdFastDiagRespViaC11_Enable', 
                                'CANOE_DLC'         => 'E_C1PrdFastDiagRespViaCANFD2_Dlc', 
                                'CANOE_CYCLETIME'   => 'E_C1PrdFastDiagRespV12_CycleTime', 
                                'CANOE_VALIDCRC'    => 'E_C1PrdFastDiagRespVi13_ValidCRC', 
                                'CANOE_VALIDCNT'    => 'E_C1PrdFastDiagRespVi14_ValidCnt', 
                            },

      'CANFD1::CustDiag_Physical_Request' => { 
                                'ID'                => 1756, 
                                'DLC'               => 8, 
                                'SENDER'            => 'Tester', 
                                'CYCLE'             => 10, 
                                'CANOE_ENABLE'      => 'E_C1CustDiag_Physical_R15_Enable', 
                                'CANOE_DLC'         => 'E_C1CustDiag_Physical_Requ16_Dlc', 
                                'CANOE_CYCLETIME'   => 'E_C1CustDiag_Physica17_CycleTime', 
                                'CANOE_VALIDCRC'    => 'E_C1CustDiag_Physical18_ValidCRC', 
                                'CANOE_VALIDCNT'    => 'E_C1CustDiag_Physical19_ValidCnt', 
                            },

      'CANFD1::CustDiag_Functional_Request' => { 
                                'ID'                => 1772, 
                                'DLC'               => 8, 
                                'SENDER'            => 'Tester', 
                                'CYCLE'             => 200, 
                                'CANOE_ENABLE'      => 'E_C1CustDiag_Functional20_Enable', 
                                'CANOE_DLC'         => 'E_C1CustDiag_Functional_Re21_Dlc', 
                                'CANOE_CYCLETIME'   => 'E_C1CustDiag_Functio22_CycleTime', 
                                'CANOE_VALIDCRC'    => 'E_C1CustDiag_Function23_ValidCRC', 
                                'CANOE_VALIDCNT'    => 'E_C1CustDiag_Function24_ValidCnt', 
                            },

      'CANFD1::CANFDTestRx01' => { 
                                'ID'                => 1809, 
                                'DLC'               => 64, 
                                'SENDER'            => 'Vector__XXX', 
                                'CYCLE'             => 100, 
                                'CANOE_ENABLE'      => 'E_C1CANFDTestRx01_Enable', 
                                'CANOE_DLC'         => 'E_C1CANFDTestRx01_Dlc', 
                                'CANOE_CYCLETIME'   => 'E_C1CANFDTestRx01_CycleTime', 
                                'CANOE_VALIDCRC'    => 'E_C1CANFDTestRx01_ValidCRC', 
                                'CANOE_VALIDCNT'    => 'E_C1CANFDTestRx01_ValidCnt', 
                            },

      'CANFD1::CANFDTestTx01' => { 
                                'ID'                => 1810, 
                                'DLC'               => 64, 
                                'SENDER'            => 'AB_ECU', 
                                'CYCLE'             => 100, 
                                'CANOE_ENABLE'      => 'E_C1CANFDTestTx01_Enable', 
                                'CANOE_DLC'         => 'E_C1CANFDTestTx01_Dlc', 
                                'CANOE_CYCLETIME'   => 'E_C1CANFDTestTx01_CycleTime', 
                                'CANOE_VALIDCRC'    => 'E_C1CANFDTestTx01_ValidCRC', 
                                'CANOE_VALIDCNT'    => 'E_C1CANFDTestTx01_ValidCnt', 
                            },

      'CANFD1::VDS_Sensordata' => { 
                                'ID'                => 1811, 
                                'DLC'               => 16, 
                                'SENDER'            => 'AB_ECU', 
                                'CYCLE'             => 10, 
                                'CANOE_ENABLE'      => 'E_C1VDS_Sensordata_Enable', 
                                'CANOE_DLC'         => 'E_C1VDS_Sensordata_Dlc', 
                                'CANOE_CYCLETIME'   => 'E_C1VDS_Sensordata_CycleTime', 
                                'CANOE_VALIDCRC'    => 'E_C1VDS_Sensordata_ValidCRC', 
                                'CANOE_VALIDCNT'    => 'E_C1VDS_Sensordata_ValidCnt', 
                            },

      'CANFD1::IsoDisp_Physical_Request' => { 
                                'ID'                => 2033, 
                                'DLC'               => 8, 
                                'SENDER'            => 'Tester', 
                                'CYCLE'             => 10, 
                                'CANOE_ENABLE'      => 'E_C1IsoDisp_Physical_Re25_Enable', 
                                'CANOE_DLC'         => 'E_C1IsoDisp_Physical_Request_Dlc', 
                                'CANOE_CYCLETIME'   => 'E_C1IsoDisp_Physical26_CycleTime', 
                                'CANOE_VALIDCRC'    => 'E_C1IsoDisp_Physical_27_ValidCRC', 
                                'CANOE_VALIDCNT'    => 'E_C1IsoDisp_Physical_28_ValidCnt', 
                            },

      'CANFD1::IsoDisp_Physical_Response' => { 
                                'ID'                => 2041, 
                                'DLC'               => 8, 
                                'SENDER'            => 'AB_ECU', 
                                'CYCLE'             => 10, 
                                'CANOE_ENABLE'      => 'E_C1IsoDisp_Physical_Re29_Enable', 
                                'CANOE_DLC'         => 'E_C1IsoDisp_Physical_Respo30_Dlc', 
                                'CANOE_CYCLETIME'   => 'E_C1IsoDisp_Physical31_CycleTime', 
                                'CANOE_VALIDCRC'    => 'E_C1IsoDisp_Physical_32_ValidCRC', 
                                'CANOE_VALIDCNT'    => 'E_C1IsoDisp_Physical_33_ValidCnt', 
                            },

      'CANFD1::VECTOR__INDEPENDENT_SIG_MSG' => { 
                                'ID'                => 3221225472, 
                                'DLC'               => 0, 
                                'SENDER'            => 'Vector__XXX', 
                                'CYCLE'             => 10, 
                                'CANOE_ENABLE'      => 'E_C1VECTOR__INDEPENDENT34_Enable', 
                                'CANOE_DLC'         => 'E_C1VECTOR__INDEPENDENT_SI35_Dlc', 
                                'CANOE_CYCLETIME'   => 'E_C1VECTOR__INDEPEND36_CycleTime', 
                                'CANOE_VALIDCRC'    => 'E_C1VECTOR__INDEPENDE37_ValidCRC', 
                                'CANOE_VALIDCNT'    => 'E_C1VECTOR__INDEPENDE38_ValidCnt', 
                            },

      },
## --- Signal List (msg by msg , IDs ascending) of System under Test node 

############################################# 

# -------------------------------------------------------------------------------------- 

# ----------- CANFD MESSAGE: CANFD1::EXT_PCP_MSG ID: 120 (0x78), DB File name :C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc ------------- 

# -------------------------------------------------------------------------------------- 

  'CANFD1::EXT_PCP_MSG::EXT_MSB_BeltJerk_ExtReq'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID120EXT_MSB_BeltJerk_ExtReq', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  5, 
           'LENGTH'        =>  1, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::EXT_PCP_MSG::EXT_MSB_FullTensing_ExtReq'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID120EXT_MSB_FullTensing_E39', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  7, 
           'LENGTH'        =>  1, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::EXT_PCP_MSG::EXT_MSB_PartialTensing_ExtReq'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID120EXT_MSB_PartialTensin40', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  6, 
           'LENGTH'        =>  1, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::EXT_PCP_MSG::EXT_PCP_AEB_Enable'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID120EXT_PCP_AEB_Enable', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  8, 
           'LENGTH'        =>  1, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  1,
           },

  'CANFD1::EXT_PCP_MSG::EXT_PCP_BSR_Enable'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID120EXT_PCP_BSR_Enable', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  9, 
           'LENGTH'        =>  1, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  1,
           },

  'CANFD1::EXT_PCP_MSG::EXT_PCP_EBEnable'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID120EXT_PCP_EBEnable', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  11, 
           'LENGTH'        =>  1, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  1,
           },

  'CANFD1::EXT_PCP_MSG::EXT_PCP_Enable'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID120EXT_PCP_Enable', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  12, 
           'LENGTH'        =>  1, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  1,
           },

  'CANFD1::EXT_PCP_MSG::EXT_PCP_PCWEnable'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID120EXT_PCP_PCWEnable', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  13, 
           'LENGTH'        =>  1, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  1,
           },

  'CANFD1::EXT_PCP_MSG::EXT_PCP_SBEnable'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID120EXT_PCP_SBEnable', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  10, 
           'LENGTH'        =>  1, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  1,
           },

# -------------------------------------------------------------------------------------- 

# ----------- CANFD MESSAGE: CANFD1::BMI_EMN_MSG ID: 121 (0x79), DB File name :C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc ------------- 

# -------------------------------------------------------------------------------------- 

  'CANFD1::BMI_EMN_MSG::BMI_AEB_Expected'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID121BMI_AEB_Expected', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  6, 
           'LENGTH'        =>  1, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::BMI_EMN_MSG::BMI_AEB_State'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID121BMI_AEB_State', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  4, 
           'LENGTH'        =>  2, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::BMI_EMN_MSG::BMI_BeltJerk'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID121BMI_BeltJerk', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  7, 
           'LENGTH'        =>  1, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

# -------------------------------------------------------------------------------------- 

# ----------- CANFD MESSAGE: CANFD1::ISS_Sync ID: 128 (0x80), DB File name :C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc ------------- 

# -------------------------------------------------------------------------------------- 

  'CANFD1::ISS_Sync::ISS_Sync_CRC'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID128ISS_Sync_CRC', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  0, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'INTEL', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::ISS_Sync::ISS_Sync_PDU_Type'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID128ISS_Sync_PDU_Type', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  8, 
           'LENGTH'        =>  4, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'INTEL', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::ISS_Sync::ISS_Sync_SeqID'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID128ISS_Sync_SeqID', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  12, 
           'LENGTH'        =>  4, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'INTEL', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::ISS_Sync::ISS_Sync_Sync_TimeStamp'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID128ISS_Sync_Sync_TimeStamp', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  16, 
           'LENGTH'        =>  32, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  10.000000, 
           'FORMAT'        => 'INTEL', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => 'Unit_�s', 
           'INITVALUE_RAW' =>  0,
           },

# -------------------------------------------------------------------------------------- 

# ----------- CANFD MESSAGE: CANFD1::IDF_01 ID: 129 (0x81), DB File name :C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc ------------- 

# -------------------------------------------------------------------------------------- 

  'CANFD1::IDF_01::IDF_01_AEB_Flag'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID129IDF_01_AEB_Flag', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  58, 
           'LENGTH'        =>  2, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'INTEL', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::IDF_01::IDF_01_Closing_Velocity'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID129IDF_01_Closing_Velocity', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  24, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  0.167000, 
           'FORMAT'        => 'INTEL', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => 'Unit_m/s', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::IDF_01::IDF_01_Object_Class'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID129IDF_01_Object_Class', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  12, 
           'LENGTH'        =>  3, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'INTEL', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::IDF_01::IDF_01_TTI_TimeStamp'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID129IDF_01_TTI_TimeStamp', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  32, 
           'LENGTH'        =>  26, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  0.001000, 
           'FORMAT'        => 'INTEL', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => 'Unit_s', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::IDF_01::IDF_01_Time_to_Impact'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID129IDF_01_Time_to_Impact', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  16, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  0.004000, 
           'FORMAT'        => 'INTEL', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => 'Unit_s', 
           'INITVALUE_RAW' =>  0,
           },

# -------------------------------------------------------------------------------------- 

# ----------- CANFD MESSAGE: CANFD1::VDC_01 ID: 131 (0x83), DB File name :C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc ------------- 

# -------------------------------------------------------------------------------------- 

  'CANFD1::VDC_01::VDC_AccLateral'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID131VDC_AccLateral', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  1, 
           'LENGTH'        =>  10, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  0.047852, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => 'mps2', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::VDC_01::VDC_AccLateralStatus'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID131VDC_AccLateralStatus', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  7, 
           'LENGTH'        =>  1, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::VDC_01::VDC_AccLongitudinal'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID131VDC_AccLongitudinal', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  23, 
           'LENGTH'        =>  10, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  0.047852, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'SIGNED', 
           'UNIT'          => 'mps2', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::VDC_01::VDC_AccLongitudinalStatus'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID131VDC_AccLongitudinalSt41', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  6, 
           'LENGTH'        =>  1, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::VDC_01::VDC_Intervention'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID131VDC_Intervention', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  4, 
           'LENGTH'        =>  1, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::VDC_01::VDC_MCPressure'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID131VDC_MCPressure', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  35, 
           'LENGTH'        =>  12, 
           'OFFSET'        =>  46626.160000, 
           'FACTOR'        =>  23.960000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'SIGNED', 
           'UNIT'          => 'kPa', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::VDC_01::VDC_MCPressureStatus'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID131VDC_MCPressureStatus', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  3, 
           'LENGTH'        =>  1, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::VDC_01::VDC_YawRate'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID131VDC_YawRate', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  29, 
           'LENGTH'        =>  10, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  0.244141, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'SIGNED', 
           'UNIT'          => '�/s', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::VDC_01::VDC_YawRateStatus'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID131VDC_YawRateStatus', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  2, 
           'LENGTH'        =>  1, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

# -------------------------------------------------------------------------------------- 

# ----------- CANFD MESSAGE: CANFD1::DRV_01 ID: 132 (0x84), DB File name :C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc ------------- 

# -------------------------------------------------------------------------------------- 

  'CANFD1::DRV_01::DRV_AccPedalPosition'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID132DRV_AccPedalPosition', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  8, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  0.392157, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '%', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::DRV_01::DRV_AccPedalPositionStatus'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID132DRV_AccPedalPositionS42', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  4, 
           'LENGTH'        =>  1, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  1,
           },

  'CANFD1::DRV_01::DRV_BrakePedalPosition'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID132DRV_BrakePedalPosition', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  0, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  0.392157, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '%', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::DRV_01::DRV_BrakePedalPositionStatus'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID132DRV_BrakePedalPositio43', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  3, 
           'LENGTH'        =>  1, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  1,
           },

# -------------------------------------------------------------------------------------- 

# ----------- CANFD MESSAGE: CANFD1::MSB_FD ID: 134 (0x86), DB File name :C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc ------------- 

# -------------------------------------------------------------------------------------- 

  'CANFD1::MSB_FD::MSB_FD_Status'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID134MSB_FD_Status', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  7, 
           'LENGTH'        =>  1, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

# -------------------------------------------------------------------------------------- 

# ----------- CANFD MESSAGE: CANFD1::MSB_FP ID: 135 (0x87), DB File name :C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc ------------- 

# -------------------------------------------------------------------------------------- 

  'CANFD1::MSB_FP::MSB_FP_Status'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID135MSB_FP_Status', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  7, 
           'LENGTH'        =>  1, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

# -------------------------------------------------------------------------------------- 

# ----------- CANFD MESSAGE: CANFD1::MSB_RD ID: 136 (0x88), DB File name :C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc ------------- 

# -------------------------------------------------------------------------------------- 

  'CANFD1::MSB_RD::MSB_RD_Status'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID136MSB_RD_Status', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  7, 
           'LENGTH'        =>  1, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

# -------------------------------------------------------------------------------------- 

# ----------- CANFD MESSAGE: CANFD1::MSB_RC ID: 137 (0x89), DB File name :C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc ------------- 

# -------------------------------------------------------------------------------------- 

  'CANFD1::MSB_RC::Status_MSB_RC'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID137Status_MSB_RC', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  7, 
           'LENGTH'        =>  1, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

# -------------------------------------------------------------------------------------- 

# ----------- CANFD MESSAGE: CANFD1::MSB_RP ID: 144 (0x90), DB File name :C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc ------------- 

# -------------------------------------------------------------------------------------- 

  'CANFD1::MSB_RP::MSB_RP_Status'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID144MSB_RP_Status', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  7, 
           'LENGTH'        =>  1, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

# -------------------------------------------------------------------------------------- 

# ----------- CANFD MESSAGE: CANFD1::GGCC ID: 256 (0x100), DB File name :C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc ------------- 

# -------------------------------------------------------------------------------------- 

  'CANFD1::GGCC::GGCC_Id'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID256GGCC_Id', 
           'MULTIPLEX'     =>  { 'MASTER' => 'CANFD1::GGCC::GGCC_Id' }, 
           'STARTBIT'      =>  7, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::GGCC::GGCC_VinHigh'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID256GGCC_VinHigh', 
           'MULTIPLEX'     =>  { 'MASTER' => 'CANFD1::GGCC::GGCC_Id' , 'CODE' => 0 }, 
           'STARTBIT'      =>  15, 
           'LENGTH'        =>  56, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::GGCC::GGCC_VinLow'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID256GGCC_VinLow', 
           'MULTIPLEX'     =>  { 'MASTER' => 'CANFD1::GGCC::GGCC_Id' , 'CODE' => 2 }, 
           'STARTBIT'      =>  15, 
           'LENGTH'        =>  24, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::GGCC::GGCC_VinMid'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID256GGCC_VinMid', 
           'MULTIPLEX'     =>  { 'MASTER' => 'CANFD1::GGCC::GGCC_Id' , 'CODE' => 1 }, 
           'STARTBIT'      =>  15, 
           'LENGTH'        =>  56, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

# -------------------------------------------------------------------------------------- 

# ----------- CANFD MESSAGE: CANFD1::Veh_Speed_dashboard ID: 512 (0x200), DB File name :C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc ------------- 

# -------------------------------------------------------------------------------------- 

  'CANFD1::Veh_Speed_dashboard::VSD_ESPReferenceVelocity'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID512VSD_ESPReferenceVeloc44', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  10, 
           'LENGTH'        =>  11, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  0.125000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => 'kph', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::Veh_Speed_dashboard::VSD_ESPReferenceVelocityStatus'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID512VSD_ESPReferenceVeloc45', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  27, 
           'LENGTH'        =>  1, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::Veh_Speed_dashboard::VSD_VehDrivingDirection'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID512VSD_VehDrivingDirection', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  29, 
           'LENGTH'        =>  2, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

# -------------------------------------------------------------------------------------- 

# ----------- CANFD MESSAGE: CANFD1::EdrData_01 ID: 768 (0x300), DB File name :C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc ------------- 

# -------------------------------------------------------------------------------------- 

  'CANFD1::EdrData_01::Edr_ABSActivity'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID768Edr_ABSActivity', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  7, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::EdrData_01::Edr_AcceleratorPedal'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID768Edr_AcceleratorPedal', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  15, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::EdrData_01::Edr_EngineRpm'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID768Edr_EngineRpm', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  23, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  64.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => 'rpm', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::EdrData_01::Edr_GearPosition'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID768Edr_GearPosition', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  63, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::EdrData_01::Edr_ServiceBrakeActivation'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID768Edr_ServiceBrakeActiv46', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  31, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::EdrData_01::Edr_StabilityControl'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID768Edr_StabilityControl', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  39, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::EdrData_01::Edr_SteeringInput'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID768Edr_SteeringInput', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  47, 
           'LENGTH'        =>  16, 
           'OFFSET'        =>  -819.100000, 
           'FACTOR'        =>  0.100000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => 'deg', 
           'INITVALUE_RAW' =>  8191,
           },

# -------------------------------------------------------------------------------------- 

# ----------- CANFD MESSAGE: CANFD1::EdrData_02 ID: 769 (0x301), DB File name :C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc ------------- 

# -------------------------------------------------------------------------------------- 

  'CANFD1::EdrData_02::Edr_AccidentDay'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID769Edr_AccidentDay', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  21, 
           'LENGTH'        =>  6, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  1,
           },

  'CANFD1::EdrData_02::Edr_AccidentHour'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID769Edr_AccidentHour', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  28, 
           'LENGTH'        =>  5, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::EdrData_02::Edr_AccidentMilliSecond'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID769Edr_AccidentMilliSecond', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  55, 
           'LENGTH'        =>  10, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::EdrData_02::Edr_AccidentMinute'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID769Edr_AccidentMinute', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  37, 
           'LENGTH'        =>  6, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  1,
           },

  'CANFD1::EdrData_02::Edr_AccidentMonth'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID769Edr_AccidentMonth', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  11, 
           'LENGTH'        =>  4, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::EdrData_02::Edr_AccidentSecond'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID769Edr_AccidentSecond', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  45, 
           'LENGTH'        =>  6, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::EdrData_02::Edr_AccidentYear'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID769Edr_AccidentYear', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  7, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

# -------------------------------------------------------------------------------------- 

# ----------- CANFD MESSAGE: CANFD1::EdrData_03 ID: 770 (0x302), DB File name :C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc ------------- 

# -------------------------------------------------------------------------------------- 

  'CANFD1::EdrData_03::Edr_AEBStatus'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID770Edr_AEBStatus', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  7, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::EdrData_03::Edr_AdaptiveCruiseControl'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID770Edr_AdaptiveCruiseCon47', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  14, 
           'LENGTH'        =>  4, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::EdrData_03::Edr_CCSStatus'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID770Edr_CCSStatus', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  10, 
           'LENGTH'        =>  3, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::EdrData_03::Edr_PressureMonLampStatus'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID770Edr_PressureMonLampSt48', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  15, 
           'LENGTH'        =>  1, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::EdrData_03::Edr_ThrottlePedalPosition'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID770Edr_ThrottlePedalPosi49', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  31, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::EdrData_03::Edr_TractionCtlSysStatus'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID770Edr_TractionCtlSysSta50', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  20, 
           'LENGTH'        =>  2, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::EdrData_03::Edr_TurnSglSwStatus'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID770Edr_TurnSglSwStatus', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  18, 
           'LENGTH'        =>  3, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

# -------------------------------------------------------------------------------------- 

# ----------- CANFD MESSAGE: CANFD1::EdrData_04 ID: 771 (0x303), DB File name :C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc ------------- 

# -------------------------------------------------------------------------------------- 

  'CANFD1::EdrData_04::Edr_BrakePedalPosition'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID771Edr_BrakePedalPosition', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  7, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::EdrData_04::Edr_BrakingSystemWarningStatus'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID771Edr_BrakingSystemWarn51', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  11, 
           'LENGTH'        =>  2, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::EdrData_04::Edr_EngineRPM_V2'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID771Edr_EngineRPM_V2', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  23, 
           'LENGTH'        =>  16, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::EdrData_04::Edr_ParkingSystemStatus'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID771Edr_ParkingSystemStatus', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  9, 
           'LENGTH'        =>  2, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

# -------------------------------------------------------------------------------------- 

# ----------- CANFD MESSAGE: CANFD1::Airbag01 ID: 1024 (0x400), DB File name :C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc ------------- 

# -------------------------------------------------------------------------------------- 

  'CANFD1::Airbag01::Airbag01_BeltLockFrontDriver'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1024Airbag01_BeltLockFro52', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  1, 
           'LENGTH'        =>  2, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::Airbag01::Airbag01_BeltLockFrontPassenger'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1024Airbag01_BeltLockFro53', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  15, 
           'LENGTH'        =>  2, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::Airbag01::Airbag01_RollingCounter'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1024Airbag01_RollingCoun54', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  7, 
           'LENGTH'        =>  6, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::Airbag01::Airbag01_TestUint8NSignal'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1024Airbag01_TestUint8NS55', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  16, 
           'LENGTH'        =>  48, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'INTEL', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  11223344556,
           },

# -------------------------------------------------------------------------------------- 

# ----------- CANFD MESSAGE: CANFD1::Airbag_MSB ID: 1026 (0x402), DB File name :C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc ------------- 

# -------------------------------------------------------------------------------------- 

  'CANFD1::Airbag_MSB::Airbag_MSB_FD'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1026Airbag_MSB_FD', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  7, 
           'LENGTH'        =>  3, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::Airbag_MSB::Airbag_MSB_FP'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1026Airbag_MSB_FP', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  4, 
           'LENGTH'        =>  3, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::Airbag_MSB::Airbag_MSB_RC'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1026Airbag_MSB_RC', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  12, 
           'LENGTH'        =>  3, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::Airbag_MSB::Airbag_MSB_RD'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1026Airbag_MSB_RD', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  15, 
           'LENGTH'        =>  3, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::Airbag_MSB::Airbag_MSB_RP'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1026Airbag_MSB_RP', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  23, 
           'LENGTH'        =>  3, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

# -------------------------------------------------------------------------------------- 

# ----------- CANFD MESSAGE: CANFD1::CustDiag_Physical_Response ID: 1276 (0x4fc), DB File name :C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc ------------- 

# -------------------------------------------------------------------------------------- 

  'CANFD1::CustDiag_Physical_Response::CustDiag_Physical_ResponseByte1'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1276CustDiag_Physical_Re56', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  7, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::CustDiag_Physical_Response::CustDiag_Physical_ResponseByte2'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1276CustDiag_Physical_Re57', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  15, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::CustDiag_Physical_Response::CustDiag_Physical_ResponseByte3'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1276CustDiag_Physical_Re58', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  23, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::CustDiag_Physical_Response::CustDiag_Physical_ResponseByte4'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1276CustDiag_Physical_Re59', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  31, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::CustDiag_Physical_Response::CustDiag_Physical_ResponseByte5'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1276CustDiag_Physical_Re60', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  39, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::CustDiag_Physical_Response::CustDiag_Physical_ResponseByte6'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1276CustDiag_Physical_Re61', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  47, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::CustDiag_Physical_Response::CustDiag_Physical_ResponseByte7'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1276CustDiag_Physical_Re62', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  55, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::CustDiag_Physical_Response::CustDiag_Physical_ResponseByte8'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1276CustDiag_Physical_Re63', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  63, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

# -------------------------------------------------------------------------------------- 

# ----------- CANFD MESSAGE: CANFD1::FLM_env_data ID: 1280 (0x500), DB File name :C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc ------------- 

# -------------------------------------------------------------------------------------- 

  'CANFD1::FLM_env_data::FLM_EnvData_Mileage'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1280FLM_EnvData_Mileage', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  7, 
           'LENGTH'        =>  20, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => 'kilometer', 
           'INITVALUE_RAW' =>  0,
           },

# -------------------------------------------------------------------------------------- 

# ----------- CANFD MESSAGE: CANFD1::Temperature ID: 1296 (0x510), DB File name :C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc ------------- 

# -------------------------------------------------------------------------------------- 

  'CANFD1::Temperature::Ext_TestUint8NSignal'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1296Ext_TestUint8NSignal', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  23, 
           'LENGTH'        =>  40, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'SIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::Temperature::Ext_temperature'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1296Ext_temperature', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  7, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  -50.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'SIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  50,
           },

  'CANFD1::Temperature::TemperatureStatus'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1296TemperatureStatus', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  15, 
           'LENGTH'        =>  1, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

# -------------------------------------------------------------------------------------- 

# ----------- CANFD MESSAGE: CANFD1::Sensordata ID: 1536 (0x600), DB File name :C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc ------------- 

# -------------------------------------------------------------------------------------- 

  'CANFD1::Sensordata::SensorData1'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1536SensorData1', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  7, 
           'LENGTH'        =>  16, 
           'OFFSET'        =>  -32767.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'SIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  32767,
           },

  'CANFD1::Sensordata::SensorStatus1no'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1536SensorStatus1no', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  23, 
           'LENGTH'        =>  2, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

# -------------------------------------------------------------------------------------- 

# ----------- CANFD MESSAGE: CANFD1::ProDiag_Request ID: 1616 (0x650), DB File name :C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc ------------- 

# -------------------------------------------------------------------------------------- 

  'CANFD1::ProDiag_Request::ProDiag_RequestByte1'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1616ProDiag_RequestByte1', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  7, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::ProDiag_Request::ProDiag_RequestByte2'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1616ProDiag_RequestByte2', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  15, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::ProDiag_Request::ProDiag_RequestByte3'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1616ProDiag_RequestByte3', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  23, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::ProDiag_Request::ProDiag_RequestByte4'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1616ProDiag_RequestByte4', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  31, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::ProDiag_Request::ProDiag_RequestByte5'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1616ProDiag_RequestByte5', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  39, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::ProDiag_Request::ProDiag_RequestByte6'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1616ProDiag_RequestByte6', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  47, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::ProDiag_Request::ProDiag_RequestByte7'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1616ProDiag_RequestByte7', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  55, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::ProDiag_Request::ProDiag_RequestByte8'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1616ProDiag_RequestByte8', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  63, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

# -------------------------------------------------------------------------------------- 

# ----------- CANFD MESSAGE: CANFD1::ProDiag_Response1 ID: 1617 (0x651), DB File name :C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc ------------- 

# -------------------------------------------------------------------------------------- 

  'CANFD1::ProDiag_Response1::ProDiag_Response1Byte1'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1617ProDiag_Response1Byte1', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  7, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::ProDiag_Response1::ProDiag_Response1Byte2'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1617ProDiag_Response1Byte2', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  15, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::ProDiag_Response1::ProDiag_Response1Byte3'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1617ProDiag_Response1Byte3', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  23, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::ProDiag_Response1::ProDiag_Response1Byte4'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1617ProDiag_Response1Byte4', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  31, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::ProDiag_Response1::ProDiag_Response1Byte5'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1617ProDiag_Response1Byte5', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  39, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::ProDiag_Response1::ProDiag_Response1Byte6'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1617ProDiag_Response1Byte6', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  47, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::ProDiag_Response1::ProDiag_Response1Byte7'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1617ProDiag_Response1Byte7', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  55, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::ProDiag_Response1::ProDiag_Response1Byte8'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1617ProDiag_Response1Byte8', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  63, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

# -------------------------------------------------------------------------------------- 

# ----------- CANFD MESSAGE: CANFD1::ProDiag_Response2 ID: 1618 (0x652), DB File name :C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc ------------- 

# -------------------------------------------------------------------------------------- 

  'CANFD1::ProDiag_Response2::ProDiag_Response2Byte1'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1618ProDiag_Response2Byte1', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  7, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::ProDiag_Response2::ProDiag_Response2Byte2'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1618ProDiag_Response2Byte2', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  15, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::ProDiag_Response2::ProDiag_Response2Byte3'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1618ProDiag_Response2Byte3', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  23, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::ProDiag_Response2::ProDiag_Response2Byte4'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1618ProDiag_Response2Byte4', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  31, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::ProDiag_Response2::ProDiag_Response2Byte5'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1618ProDiag_Response2Byte5', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  39, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::ProDiag_Response2::ProDiag_Response2Byte6'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1618ProDiag_Response2Byte6', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  47, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::ProDiag_Response2::ProDiag_Response2Byte7'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1618ProDiag_Response2Byte7', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  55, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::ProDiag_Response2::ProDiag_Response2Byte8'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1618ProDiag_Response2Byte8', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  63, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

# -------------------------------------------------------------------------------------- 

# ----------- CANFD MESSAGE: CANFD1::ProDiag_Response3 ID: 1619 (0x653), DB File name :C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc ------------- 

# -------------------------------------------------------------------------------------- 

  'CANFD1::ProDiag_Response3::ProDiag_Response3Byte1'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1619ProDiag_Response3Byte1', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  7, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::ProDiag_Response3::ProDiag_Response3Byte2'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1619ProDiag_Response3Byte2', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  15, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::ProDiag_Response3::ProDiag_Response3Byte3'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1619ProDiag_Response3Byte3', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  23, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::ProDiag_Response3::ProDiag_Response3Byte4'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1619ProDiag_Response3Byte4', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  31, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::ProDiag_Response3::ProDiag_Response3Byte5'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1619ProDiag_Response3Byte5', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  39, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::ProDiag_Response3::ProDiag_Response3Byte6'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1619ProDiag_Response3Byte6', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  47, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::ProDiag_Response3::ProDiag_Response3Byte7'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1619ProDiag_Response3Byte7', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  55, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::ProDiag_Response3::ProDiag_Response3Byte8'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1619ProDiag_Response3Byte8', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  63, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

# -------------------------------------------------------------------------------------- 

# ----------- CANFD MESSAGE: CANFD1::ProDiag_Response4 ID: 1620 (0x654), DB File name :C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc ------------- 

# -------------------------------------------------------------------------------------- 

  'CANFD1::ProDiag_Response4::ProDiag_Response4Byte1'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1620ProDiag_Response4Byte1', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  7, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::ProDiag_Response4::ProDiag_Response4Byte2'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1620ProDiag_Response4Byte2', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  15, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::ProDiag_Response4::ProDiag_Response4Byte3'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1620ProDiag_Response4Byte3', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  23, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::ProDiag_Response4::ProDiag_Response4Byte4'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1620ProDiag_Response4Byte4', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  31, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::ProDiag_Response4::ProDiag_Response4Byte5'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1620ProDiag_Response4Byte5', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  39, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::ProDiag_Response4::ProDiag_Response4Byte6'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1620ProDiag_Response4Byte6', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  47, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::ProDiag_Response4::ProDiag_Response4Byte7'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1620ProDiag_Response4Byte7', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  55, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::ProDiag_Response4::ProDiag_Response4Byte8'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1620ProDiag_Response4Byte8', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  63, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

# -------------------------------------------------------------------------------------- 

# ----------- CANFD MESSAGE: CANFD1::PrdFastDiagRespViaCANFD1 ID: 1621 (0x655), DB File name :C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc ------------- 

# -------------------------------------------------------------------------------------- 

  'CANFD1::PrdFastDiagRespViaCANFD1::PrdFastDiagRespViaCANFD1Byte1'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1621PrdFastDiagRespViaCA64', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  0, 
           'LENGTH'        =>  512, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'INTEL', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

# -------------------------------------------------------------------------------------- 

# ----------- CANFD MESSAGE: CANFD1::PrdFastDiagRespViaCANFD2 ID: 1622 (0x656), DB File name :C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc ------------- 

# -------------------------------------------------------------------------------------- 

  'CANFD1::PrdFastDiagRespViaCANFD2::PrdFastDiagRespViaCANFD2Byte1'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1622PrdFastDiagRespViaCA65', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  0, 
           'LENGTH'        =>  512, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'INTEL', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

# -------------------------------------------------------------------------------------- 

# ----------- CANFD MESSAGE: CANFD1::CustDiag_Physical_Request ID: 1756 (0x6dc), DB File name :C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc ------------- 

# -------------------------------------------------------------------------------------- 

  'CANFD1::CustDiag_Physical_Request::CustDiag_Physical_RequestByte1'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1756CustDiag_Physical_Re66', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  7, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::CustDiag_Physical_Request::CustDiag_Physical_RequestByte2'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1756CustDiag_Physical_Re67', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  15, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::CustDiag_Physical_Request::CustDiag_Physical_RequestByte3'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1756CustDiag_Physical_Re68', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  23, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::CustDiag_Physical_Request::CustDiag_Physical_RequestByte4'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1756CustDiag_Physical_Re69', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  31, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::CustDiag_Physical_Request::CustDiag_Physical_RequestByte5'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1756CustDiag_Physical_Re70', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  39, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::CustDiag_Physical_Request::CustDiag_Physical_RequestByte6'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1756CustDiag_Physical_Re71', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  47, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::CustDiag_Physical_Request::CustDiag_Physical_RequestByte7'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1756CustDiag_Physical_Re72', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  55, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::CustDiag_Physical_Request::CustDiag_Physical_RequestByte8'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1756CustDiag_Physical_Re73', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  63, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

# -------------------------------------------------------------------------------------- 

# ----------- CANFD MESSAGE: CANFD1::CustDiag_Functional_Request ID: 1772 (0x6ec), DB File name :C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc ------------- 

# -------------------------------------------------------------------------------------- 

  'CANFD1::CustDiag_Functional_Request::CustDiag_Functional_RequestByte1'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1772CustDiag_Functional_74', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  7, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::CustDiag_Functional_Request::CustDiag_Functional_RequestByte2'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1772CustDiag_Functional_75', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  15, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::CustDiag_Functional_Request::CustDiag_Functional_RequestByte3'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1772CustDiag_Functional_76', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  23, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::CustDiag_Functional_Request::CustDiag_Functional_RequestByte4'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1772CustDiag_Functional_77', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  31, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::CustDiag_Functional_Request::CustDiag_Functional_RequestByte5'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1772CustDiag_Functional_78', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  39, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::CustDiag_Functional_Request::CustDiag_Functional_RequestByte6'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1772CustDiag_Functional_79', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  47, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::CustDiag_Functional_Request::CustDiag_Functional_RequestByte7'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1772CustDiag_Functional_80', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  55, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::CustDiag_Functional_Request::CustDiag_Functional_RequestByte8'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1772CustDiag_Functional_81', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  63, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

# -------------------------------------------------------------------------------------- 

# ----------- CANFD MESSAGE: CANFD1::CANFDTestRx01 ID: 1809 (0x711), DB File name :C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc ------------- 

# -------------------------------------------------------------------------------------- 

  'CANFD1::CANFDTestRx01::CanFDRxSignal01'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1809CanFDRxSignal01', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  0, 
           'LENGTH'        =>  512, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'INTEL', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

# -------------------------------------------------------------------------------------- 

# ----------- CANFD MESSAGE: CANFD1::CANFDTestTx01 ID: 1810 (0x712), DB File name :C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc ------------- 

# -------------------------------------------------------------------------------------- 

  'CANFD1::CANFDTestTx01::CANFDTxSignal01'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1810CANFDTxSignal01', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  0, 
           'LENGTH'        =>  480, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'INTEL', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::CANFDTestTx01::CANFDTxSignal02'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1810CANFDTxSignal02', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  480, 
           'LENGTH'        =>  32, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  0.001000, 
           'FORMAT'        => 'INTEL', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

# -------------------------------------------------------------------------------------- 

# ----------- CANFD MESSAGE: CANFD1::VDS_Sensordata ID: 1811 (0x713), DB File name :C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc ------------- 

# -------------------------------------------------------------------------------------- 

  'CANFD1::VDS_Sensordata::VDS_CANFDHeaveSignalData'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1811VDS_CANFDHeaveSignal82', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  0, 
           'LENGTH'        =>  16, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  0.000200, 
           'FORMAT'        => 'INTEL', 
           'TYPE'          => 'SIGNED', 
           'UNIT'          => 'g', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::VDS_Sensordata::VDS_CANFDHeaveSignalStatus'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1811VDS_CANFDHeaveSignal83', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  112, 
           'LENGTH'        =>  2, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'INTEL', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::VDS_Sensordata::VDS_CANFDLateralSignalData'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1811VDS_CANFDLateralSign84', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  16, 
           'LENGTH'        =>  16, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  0.000200, 
           'FORMAT'        => 'INTEL', 
           'TYPE'          => 'SIGNED', 
           'UNIT'          => 'g', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::VDS_Sensordata::VDS_CANFDLateralSignalStatus'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1811VDS_CANFDLateralSign85', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  114, 
           'LENGTH'        =>  2, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'INTEL', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::VDS_Sensordata::VDS_CANFDLinearSignalData'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1811VDS_CANFDLinearSigna86', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  32, 
           'LENGTH'        =>  16, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  0.000200, 
           'FORMAT'        => 'INTEL', 
           'TYPE'          => 'SIGNED', 
           'UNIT'          => 'g', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::VDS_Sensordata::VDS_CANFDLinearSignalStatus'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1811VDS_CANFDLinearSigna87', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  116, 
           'LENGTH'        =>  2, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'INTEL', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::VDS_Sensordata::VDS_CANFDPitchSignalData'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1811VDS_CANFDPitchSignal88', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  48, 
           'LENGTH'        =>  16, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  0.010000, 
           'FORMAT'        => 'INTEL', 
           'TYPE'          => 'SIGNED', 
           'UNIT'          => '�/s', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::VDS_Sensordata::VDS_CANFDPitchSignalStatus'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1811VDS_CANFDPitchSignal89', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  118, 
           'LENGTH'        =>  2, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'INTEL', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::VDS_Sensordata::VDS_CANFDRollSignalData'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1811VDS_CANFDRollSignalD90', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  64, 
           'LENGTH'        =>  16, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  0.010000, 
           'FORMAT'        => 'INTEL', 
           'TYPE'          => 'SIGNED', 
           'UNIT'          => '�/s', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::VDS_Sensordata::VDS_CANFDRollSignalStatus'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1811VDS_CANFDRollSignalS91', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  120, 
           'LENGTH'        =>  2, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'INTEL', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::VDS_Sensordata::VDS_CANFDTemperatureSignalData'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1811VDS_CANFDTemperature92', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  96, 
           'LENGTH'        =>  16, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  0.005000, 
           'FORMAT'        => 'INTEL', 
           'TYPE'          => 'SIGNED', 
           'UNIT'          => '�C', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::VDS_Sensordata::VDS_CANFDYawSignalData'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1811VDS_CANFDYawSignalData', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  80, 
           'LENGTH'        =>  16, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  0.010000, 
           'FORMAT'        => 'INTEL', 
           'TYPE'          => 'SIGNED', 
           'UNIT'          => '�/s', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::VDS_Sensordata::VDS_CANFDYawSignalStatus'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID1811VDS_CANFDYawSignalSt93', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  122, 
           'LENGTH'        =>  2, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'INTEL', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

# -------------------------------------------------------------------------------------- 

# ----------- CANFD MESSAGE: CANFD1::IsoDisp_Physical_Request ID: 2033 (0x7f1), DB File name :C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc ------------- 

# -------------------------------------------------------------------------------------- 

  'CANFD1::IsoDisp_Physical_Request::IsoDisp_Physical_RequestByte1'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID2033IsoDisp_Physical_Req94', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  7, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::IsoDisp_Physical_Request::IsoDisp_Physical_RequestByte2'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID2033IsoDisp_Physical_Req95', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  15, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::IsoDisp_Physical_Request::IsoDisp_Physical_RequestByte3'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID2033IsoDisp_Physical_Req96', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  23, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::IsoDisp_Physical_Request::IsoDisp_Physical_RequestByte4'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID2033IsoDisp_Physical_Req97', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  31, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::IsoDisp_Physical_Request::IsoDisp_Physical_RequestByte5'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID2033IsoDisp_Physical_Req98', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  39, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::IsoDisp_Physical_Request::IsoDisp_Physical_RequestByte6'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID2033IsoDisp_Physical_Req99', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  47, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::IsoDisp_Physical_Request::IsoDisp_Physical_RequestByte7'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID2033IsoDisp_Physical_Re100', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  55, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::IsoDisp_Physical_Request::IsoDisp_Physical_RequestByte8'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID2033IsoDisp_Physical_Re101', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  63, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

# -------------------------------------------------------------------------------------- 

# ----------- CANFD MESSAGE: CANFD1::IsoDisp_Physical_Response ID: 2041 (0x7f9), DB File name :C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc ------------- 

# -------------------------------------------------------------------------------------- 

  'CANFD1::IsoDisp_Physical_Response::IsoDisp_Physical_ResponseByte1'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID2041IsoDisp_Physical_Re102', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  7, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::IsoDisp_Physical_Response::IsoDisp_Physical_ResponseByte2'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID2041IsoDisp_Physical_Re103', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  15, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::IsoDisp_Physical_Response::IsoDisp_Physical_ResponseByte3'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID2041IsoDisp_Physical_Re104', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  23, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::IsoDisp_Physical_Response::IsoDisp_Physical_ResponseByte4'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID2041IsoDisp_Physical_Re105', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  31, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::IsoDisp_Physical_Response::IsoDisp_Physical_ResponseByte5'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID2041IsoDisp_Physical_Re106', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  39, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::IsoDisp_Physical_Response::IsoDisp_Physical_ResponseByte6'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID2041IsoDisp_Physical_Re107', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  47, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::IsoDisp_Physical_Response::IsoDisp_Physical_ResponseByte7'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID2041IsoDisp_Physical_Re108', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  55, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::IsoDisp_Physical_Response::IsoDisp_Physical_ResponseByte8'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID2041IsoDisp_Physical_Re109', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  63, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

# -------------------------------------------------------------------------------------- 

# ----------- CANFD MESSAGE: CANFD1::VECTOR__INDEPENDENT_SIG_MSG ID: 3221225472 (0xc0000000), DB File name :C:/sandboxes/TurboLIFT_Testarea_development_RT4/KUN7KOR/tools_TurboLIFT/Custlib/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_CanDatabase.dbc ------------- 

# -------------------------------------------------------------------------------------- 

  'CANFD1::VECTOR__INDEPENDENT_SIG_MSG::EDR_SCSStatus'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID3221225472EDR_SCSStatus', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  0, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'MOTOROLA', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::VECTOR__INDEPENDENT_SIG_MSG::IDF_01_BZ'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID3221225472IDF_01_BZ', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  0, 
           'LENGTH'        =>  4, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'INTEL', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

  'CANFD1::VECTOR__INDEPENDENT_SIG_MSG::IDF_01_CRC'  => { 
           'CANOE_WR_SIGNAL'  => 'E_C1ID3221225472IDF_01_CRC', 
           'MULTIPLEX'     =>  undef, 
           'STARTBIT'      =>  0, 
           'LENGTH'        =>  8, 
           'OFFSET'        =>  0.000000, 
           'FACTOR'        =>  1.000000, 
           'FORMAT'        => 'INTEL', 
           'TYPE'          => 'UNSIGNED', 
           'UNIT'          => '', 
           'INITVALUE_RAW' =>  0,
           },

};
# end of CANFD mapping

1;
