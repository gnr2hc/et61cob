package LIFT_PROJECT;

##########################################################
$VERSION = q$Revision: 1.2 $;
$HEADER  = q$Header: config/Mapping_PSI5_settings_RT4_PAS6e_PPS3e.pm 1.2 2020/03/06 17:17:32IST Withohn Sabine (CC-PS/EPS2) (WII2SI) develop  $;
##########################################################

our @ISA = qw(Exporter);

our @EXPORT = qw(
  $Defaults
);

#      _     ___ _   _ _____ ____
#     | |   |_ _| \ | | ____/ ___|
#     | |    | ||  \| |  _| \___ \
#     | |___ | || |\  | |___ ___) |
#     |_____|___|_| \_|_____|____/
#
$Defaults->{'PSI5_LINES'} = {

    # INDEX / KEY => PSI5 LINE NUMBER
    # 1: UFSD - UFS6e - 125kB
    1 => { 'USE_DEFAULTS' => 'PSI5_LINES_DEFAULTS', },

    # 2: UFSP - UFS6e - 125kB
    2 => { 'USE_DEFAULTS' => 'PSI5_LINES_DEFAULTS', },

    # 3: PASFD - PAS6e - 189kB
    3 => {
        'USE_DEFAULTS'    => 'PSI5_LINES_DEFAULTS',
        'Timeslot_ts1_us' => 49,
        'Timeslot_ts2_us' => 150,
        'Timeslot_ts3_us' => 261,
        'Timeslot_ts4_us' => 385,
        'baudrate_kbps'   => 189,
    },

    # 4: PASFP - PAS6e - 189kB
    4 => {
        'USE_DEFAULTS'    => 'PSI5_LINES_DEFAULTS',
        'Timeslot_ts1_us' => 49,
        'Timeslot_ts2_us' => 150,
        'Timeslot_ts3_us' => 261,
        'Timeslot_ts4_us' => 385,
        'baudrate_kbps'   => 189,
    },

    # 5: PPSFD - PPS3e - 189kB
    5 => {
        'USE_DEFAULTS'    => 'PSI5_LINES_DEFAULTS',
        'Timeslot_ts1_us' => 49,
        'Timeslot_ts2_us' => 150,
        'Timeslot_ts3_us' => 261,
        'Timeslot_ts4_us' => 385,
        'baudrate_kbps'   => 189,
    },

    # 6: PPSFP - PPS3e - 189kB
    6 => {
        'USE_DEFAULTS'    => 'PSI5_LINES_DEFAULTS',
        'Timeslot_ts1_us' => 49,
        'Timeslot_ts2_us' => 150,
        'Timeslot_ts3_us' => 261,
        'Timeslot_ts4_us' => 385,
        'baudrate_kbps'   => 189,
    },

    # 7: PTSD - PTS1 - 125kB
    7 => { 'USE_DEFAULTS' => 'PSI5_LINES_DEFAULTS', },

    # 8: PTSP - PTS1 - 125kB
    8 => { 'USE_DEFAULTS' => 'PSI5_LINES_DEFAULTS', },

    # 9: PCSC - UFS6e - 125kB
    9 => { 'USE_DEFAULTS' => 'PSI5_LINES_DEFAULTS', },

    # 9: PASMD - PAS6e - 189kB
    10 => {
        'USE_DEFAULTS'    => 'PSI5_LINES_DEFAULTS',
        'Timeslot_ts1_us' => 49,
        'Timeslot_ts2_us' => 150,
        'Timeslot_ts3_us' => 261,
        'Timeslot_ts4_us' => 385,
        'baudrate_kbps'   => 189,
    },

    # 10: PASMP - PAS6e - 189kB
    11 => {
        'USE_DEFAULTS'    => 'PSI5_LINES_DEFAULTS',
        'Timeslot_ts1_us' => 49,
        'Timeslot_ts2_us' => 150,
        'Timeslot_ts3_us' => 261,
        'Timeslot_ts4_us' => 385,
        'baudrate_kbps'   => 189,
    },

};

#      ____  _____ _   _ ____   ___  ____  ____    ____  ____   ___      _ _____ ____ _____
#     / ___|| ____| \ | / ___| / _ \|  _ \/ ___|  |  _ \|  _ \ / _ \    | | ____/ ___|_   _|
#     \___ \|  _| |  \| \___ \| | | | |_) \___ \  | |_) | |_) | | | |_  | |  _|| |     | |
#      ___) | |___| |\  |___) | |_| |  _ < ___) | |  __/|  _ <| |_| | |_| | |__| |___  | |
#     |____/|_____|_| \_|____/ \___/|_| \_\____/  |_|   |_| \_\\___/ \___/|_____\____| |_|
#
$Defaults->{'PSI5_SENSORS_PROJECT'} = {
    'UFSD' => {
        'LINE' => 1,
        'TYPE' => 'UFS6e',

        #         'INIT1_DATA' => {},

        #         'INIT2_DATA1-14'           => '0x42042114A270C5',    #  Byte 1 .. 7   ( data  1 .. 14 )
        #         'INIT2_MANUFACTURING_DATE' => '0x3789',              #  Byte 8 + 9    ( data 15 .. 18 )
        #         'INIT2_LOT_LINE_NUMBERr'   => '0x00',                #  Byte 10
        #         'INIT2_SERIES_NUMBER'      => '0x9876543210AB',      #  Byte 11 .. 16
        'INIT2_DATA' => {
            PROTOCOL_REVISION      => 4,                                # Data 1
            NUMBER_OF_DATA_BLOCKS  => 32,                               # Data 2 and 3
            MANUFACTURER           => 'BOSCH_ASCII',                    # Data 4 and 5
            PAS6e_GENERATION_BIT   => 'PAS6e',                          # Data 6
            SENSOR_TYPE            => 'ACCELERATION_SENSOR',            # Data 7
            ACCELERATION_AXIS      => 'ACCELERATION_AXIS_ALPHA',        # Data 8
            ACCELERATION_RANGE     => '480g_RANGE',                     # Data 9
            SENSOR_CODE            => 'PAS6e_426Hz_6us_SAMPLE_TIME',    # Data 10
            HOUSING_CODE           => '0x27',                           # Data 10 and Data 11
            SENSOR_CODE_CUSTOMER   => '0x0C5',                          # Data 12, 13, 14
            SGB_MANUFACTURING_DATE => '31-12-2016',                     # Data 15, 16, 17, 18
            LOT_NUMBER             => '0x0',                            # Data 19
            LINE_NUMBER            => '0x0',                            # Data 20
            SERIES_NUMBER          => '0x9876543210AB',                 # Data 21 .. 32
        },
        'INIT3_DATA' => {
            'INIT3_MESSAGE' => 'SENSOR_OK',
        },

        'CYCLIC_MESSAGES' => {
            'ALL'                  => '0x000',
            'NUMBER_OF_USED_BYTES' => 10,
        },

        'USER_MESSAGES' => {
            'ALL'                  => '0x000',
            'NUMBER_OF_USED_BYTES' => 4,
        },

        'TIMESLOT' => 'Timeslot_ts2_us',

    },

    'UFSP' => {
        'LINE' => 2,
        'TYPE' => 'UFS6e',

        #         'INIT1_DATA' => {},

        #         'INIT2_DATA1-14'           => '0x42042114A270C5',    #  Byte 1 .. 7   ( data  1 .. 14 )
        #         'INIT2_MANUFACTURING_DATE' => '0x3789',              #  Byte 8 + 9    ( data 15 .. 18 )
        #         'INIT2_LOT_LINE_NUMBER'    => '0x00',                #  Byte 10
        #         'INIT2_SERIES_NUMBER'      => '0x9876543210AB',      #  Byte 11 .. 16
        'INIT2_DATA' => {
            PROTOCOL_REVISION      => 4,                                # Data 1
            NUMBER_OF_DATA_BLOCKS  => 32,                               # Data 2 and 3
            MANUFACTURER           => 'BOSCH_ASCII',                    # Data 4 and 5
            PAS6e_GENERATION_BIT   => 'PAS6e',                          # Data 6
            SENSOR_TYPE            => 'ACCELERATION_SENSOR',            # Data 7
            ACCELERATION_AXIS      => 'ACCELERATION_AXIS_ALPHA',        # Data 8
            ACCELERATION_RANGE     => '480g_RANGE',                     # Data 9
            SENSOR_CODE            => 'PAS6e_426Hz_6us_SAMPLE_TIME',    # Data 10
            HOUSING_CODE           => '0x27',                           # Data 10 and Data 11
            SENSOR_CODE_CUSTOMER   => '0x0C5',                          # Data 12, 13, 14
            SGB_MANUFACTURING_DATE => '31-12-2016',                     # Data 15, 16, 17, 18
            LOT_NUMBER             => '0x0',                            # Data 19
            LINE_NUMBER            => '0x0',                            # Data 20
            SERIES_NUMBER          => '0x9876543210AB',                 # Data 21 .. 32
        },
        'INIT3_DATA' => {
            'INIT3_MESSAGE' => 'SENSOR_OK',
        },

        'CYCLIC_MESSAGES' => {
            'ALL'                  => '0x000',
            'NUMBER_OF_USED_BYTES' => 10,
        },

        'USER_MESSAGES' => {
            'ALL'                  => '0x000',
            'NUMBER_OF_USED_BYTES' => 4,
        },

        'TIMESLOT' => 'Timeslot_ts2_us',

    },

    'PASFD' => {
        'LINE' => 3,
        'TYPE' => 'PAS6e',

        #         'INIT1_DATA' => {},

        #         'INIT2_DATA1-14'           => '0x42042114800000',    #  old: 420420148341CA',    #  Byte 1 .. 7   ( data  1 .. 14 )
        #         'INIT2_MANUFACTURING_DATE' => '0x3789',              #  Byte 8 + 9    ( data 15 .. 18 )
        #         'INIT2_LOT_LINE_NUMBER'    => '0x00',                #  Byte 10
        #         'INIT2_SERIES_NUMBER'      => '0x9876543210AB',      #  Byte 11 .. 16
        'INIT2_DATA' => {
            PROTOCOL_REVISION      => 4,                                # Data 1
            NUMBER_OF_DATA_BLOCKS  => 32,                               # Data 2 and 3
            MANUFACTURER           => 'BOSCH_ASCII',                    # Data 4 and 5
            PAS6e_GENERATION_BIT   => 'PAS6e',                          # Data 6
            SENSOR_TYPE            => 'ACCELERATION_SENSOR',            # Data 7
            ACCELERATION_AXIS      => 'ACCELERATION_AXIS_ALPHA',        # Data 8
            ACCELERATION_RANGE     => '120g_RANGE',                     # Data 9
            SENSOR_CODE            => 'PAS6e_426Hz_6us_SAMPLE_TIME',    # Data 10
            HOUSING_CODE           => '0x00',                           # Data 10 and Data 11
            SENSOR_CODE_CUSTOMER   => '0x000',                          # Data 12, 13, 14
            SGB_MANUFACTURING_DATE => '31-12-2016',                     # Data 15, 16, 17, 18
            LOT_NUMBER             => '0x0',                            # Data 19
            LINE_NUMBER            => '0x0',                            # Data 20
            SERIES_NUMBER          => '0x9876543210AB',                 # Data 21 .. 32
        },
        'INIT3_DATA' => {
            'INIT3_MESSAGE' => 'SENSOR_OK',
        },

        'CYCLIC_MESSAGES' => {
            'ALL'                  => '0x000',
            'NUMBER_OF_USED_BYTES' => 10,
        },

        'USER_MESSAGES' => {
            'ALL'                  => '0x000',
            'NUMBER_OF_USED_BYTES' => 4,
        },

        'TIMESLOT' => 'Timeslot_ts1_us',
    },

    'PASFP' => {
        'LINE' => 4,
        'TYPE' => 'PAS6e',

        #         'INIT1_DATA' => {},

        #         'INIT2_DATA1-14'           => '0x42042114800000',    #  old: 420420148341CA',    #  Byte 1 .. 7   ( data  1 .. 14 )
        #         'INIT2_MANUFACTURING_DATE' => '0x3789',              #  Byte 8 + 9    ( data 15 .. 18 )
        #         'INIT2_LOT_LINE_NUMBER'    => '0x00',                #  Byte 10
        #         'INIT2_SERIES_NUMBER'      => '0x9876543210AB',      #  Byte 11 .. 16
        'INIT2_DATA' => {
            PROTOCOL_REVISION      => 4,                                # Data 1
            NUMBER_OF_DATA_BLOCKS  => 32,                               # Data 2 and 3
            MANUFACTURER           => 'BOSCH_ASCII',                    # Data 4 and 5
            PAS6e_GENERATION_BIT   => 'PAS6e',                          # Data 6
            SENSOR_TYPE            => 'ACCELERATION_SENSOR',            # Data 7
            ACCELERATION_AXIS      => 'ACCELERATION_AXIS_ALPHA',        # Data 8
            ACCELERATION_RANGE     => '120g_RANGE',                     # Data 9
            SENSOR_CODE            => 'PAS6e_426Hz_6us_SAMPLE_TIME',    # Data 10
            HOUSING_CODE           => '0x00',                           # Data 10 and Data 11
            SENSOR_CODE_CUSTOMER   => '0x000',                          # Data 12, 13, 14
            SGB_MANUFACTURING_DATE => '31-12-2016',                     # Data 15, 16, 17, 18
            LOT_NUMBER             => '0x0',                            # Data 19
            LINE_NUMBER            => '0x0',                            # Data 20
            SERIES_NUMBER          => '0x9876543210AB',                 # Data 21 .. 32
        },
        'INIT3_DATA' => {
            'INIT3_MESSAGE' => 'SENSOR_OK',
        },

        'CYCLIC_MESSAGES' => {
            'ALL'                  => '0x000',
            'NUMBER_OF_USED_BYTES' => 10,
        },

        'USER_MESSAGES' => {
            'ALL'                  => '0x000',
            'NUMBER_OF_USED_BYTES' => 4,
        },

        'TIMESLOT' => 'Timeslot_ts1_us',
    },

    'PPSFD' => {
        'LINE' => 5,
        'TYPE' => 'PPS3e',

        #         'INIT1_DATA' => {},

        #         'INIT2_DATA1-14'           => '0x4204288CB00000',    #  Byte 1 .. 7   ( data  1 .. 14 )
        #         'INIT2_MANUFACTURING_DATE' => '0x3789',              #  Byte 8 + 9    ( data 15 .. 18 )
        #         'INIT2_LOT_LINE_NUMBER'    => '0x00',                #  Byte 10
        #         'INIT2_SERIES_NUMBER'      => '0x9876543210AB',      #  Byte 11 .. 16
        'INIT2_DATA' => {
            PROTOCOL_REVISION             => 4,                                # Data 1
            NUMBER_OF_DATA_BLOCKS         => 32,                               # Data 2 and 3
            MANUFACTURER                  => 'BOSCH_ASCII',                    # Data 4 and 5
            FILTER_TYPE_AND_SAMPLING_MODE => 'FIR_FAST',                       # Data 6
            PRESSURE_SENSOR_TYPE          => 'PN_SENSOR',                      # Data 7
            SENSOR_MODE                   => 'PRESSURE_-15%_to_+23.4%',        # Data 8
            PSI5_MODE                     => 'P10P_500_4H_PN_SLOT4_PARITY',    # Data 9
            BOSCH_SENSOR_CODE             => '0x00',                           # Data 10 and 11
            SENSOR_CODE_CUSTOMER          => '0x000',                          # Data 12, 13, 14
            SGB_MANUFACTURING_DATE        => '31-12-2016',                     # Data 15, 15, 17, 18
            LINE_NUMBER                   => '0x0',                            # Data 19
            LOT_NUMBER                    => '0x0',                            # Data 20
            SERIES_NUMBER                 => '0x9876543210AB',                 # Data 21 .. 32
        },
        'INIT3_DATA' => {
            'INIT3_MESSAGE'           => 'SENSOR_OK',
            'ABSOLUTE_PRESSURE_VALUE' => 10,
        },

        'CYCLIC_MESSAGES' => {
            'ALL'                     => '0x000',
            'NUMBER_OF_USED_BYTES'    => 10,
            'ABSOLUTE_PRESSURE_VALUE' => 10,
        },

        'USER_MESSAGES' => {
            'ALL'                  => '0x000',
            'NUMBER_OF_USED_BYTES' => 10,
        },

        'TIMESLOT' => 'Timeslot_ts4_us',
    },

    'PPSFP' => {
        'LINE' => 6,
        'TYPE' => 'PPS3e',

        #         'INIT1_DATA' => {},

        #         'INIT2_DATA1-14'           => '0x4204288CB00000',    #  Byte 1 .. 7   ( data  1 .. 14 )
        #         'INIT2_MANUFACTURING_DATE' => '0x3789',              #  Byte 8 + 9    ( data 15 .. 18 )
        #         'INIT2_LOT_LINE_NUMBER'    => '0x00',                #  Byte 10
        #         'INIT2_SERIES_NUMBER'      => '0x9876543210AB',      #  Byte 11 .. 16
        'INIT2_DATA' => {
            PROTOCOL_REVISION             => 4,                                # Data 1
            NUMBER_OF_DATA_BLOCKS         => 32,                               # Data 2 and 3
            MANUFACTURER                  => 'BOSCH_ASCII',                    # Data 4 and 5
            FILTER_TYPE_AND_SAMPLING_MODE => 'FIR_FAST',                       # Data 6
            PRESSURE_SENSOR_TYPE          => 'PN_SENSOR',                      # Data 7
            SENSOR_MODE                   => 'PRESSURE_-15%_to_+23.4%',        # Data 8
            PSI5_MODE                     => 'P10P_500_4H_PN_SLOT4_PARITY',    # Data 9
            BOSCH_SENSOR_CODE             => '0x00',                           # Data 10 and 11
            SENSOR_CODE_CUSTOMER          => '0x000',                          # Data 12, 13, 14
            SGB_MANUFACTURING_DATE        => '31-12-2016',                     # Data 15, 15, 17, 18
            LINE_NUMBER                   => '0x0',                            # Data 19
            LOT_NUMBER                    => '0x0',                            # Data 20
            SERIES_NUMBER                 => '0x9876543210AB',                 # Data 21 .. 32
        },
        'INIT3_DATA' => {
            'INIT3_MESSAGE'           => 'SENSOR_OK',
            'ABSOLUTE_PRESSURE_VALUE' => 10,
        },

        'CYCLIC_MESSAGES' => {
            'ALL'                     => '0x000',
            'NUMBER_OF_USED_BYTES'    => 10,
            'ABSOLUTE_PRESSURE_VALUE' => 10,
        },

        'USER_MESSAGES' => {
            'ALL'                  => '0x000',
            'NUMBER_OF_USED_BYTES' => 10,
        },

        'TIMESLOT' => 'Timeslot_ts4_us',
    },

    'PTSD' => {
        'LINE' => 7,
        'TYPE' => 'PTS1',

        #         'INIT1_DATA' => {},

        #         'INIT2_DATA1-14'           => '0x4204208874928A   4204208870228A',    #  Byte 1 .. 7   ( data  1 .. 14 )
        #         'INIT2_MANUFACTURING_DATE' => '0x3789',                               #  Byte 8 + 9    ( data 15 .. 18 )
        #         'INIT2_LOT_LINE_NUMBER'    => '0x00',                                 #  Byte 10
        #         'INIT2_SERIES_NUMBER'      => '0x9876543210AB',                       #  Byte 11 .. 16
        'INIT2_DATA' => {
            PROTOCOL_REVISION             => 4,                          # Data 1
            NUMBER_OF_DATA_BLOCKS         => 32,                         # Data 2 and 3
            MANUFACTURER                  => 'BOSCH_ASCII',              # Data 4 and 5
            SENSOR_TYPE                   => 'PRESSURE_SENSOR',          # Data 6 and Data 7
            TRANSMISSION_MODE             => 'PTS1_ABS_PRESSURE_OFF',    # Data 8
            SENSOR_TYPE_PSI_CONFIGURATION => '0x7',                      # Data 9
            ELECTRONIC_HOUSE_CODING       => '0x49',                     # Data 10 and Data 11
            MANUFACTURER_SERIES_CODE      => '0x28A',                    # Data 12, 13, 14
            SGB_MANUFACTURING_DATE        => '31-12-2016',               # Data 15, 16, 17, 18
            LOT_NUMBER                    => '0x0',                      # Data 19
            LINE_NUMBER                   => '0x0',                      # Data 20
            SERIES_NUMBER                 => '0x9876543210AB',           # Data 21 .. 32
        },
        'INIT3_DATA' => {
            'INIT3_MESSAGE'           => 'SENSOR_OK',
            'ABSOLUTE_PRESSURE_VALUE' => 10,
        },

        'CYCLIC_MESSAGES' => {
            'ALL'                     => '0x000',
            'NUMBER_OF_USED_BYTES'    => 10,
            'ABSOLUTE_PRESSURE_VALUE' => 10,
        },

        'USER_MESSAGES' => {
            'ALL'                  => '0x000',
            'NUMBER_OF_USED_BYTES' => 10,
        },

        'TIMESLOT' => 'Timeslot_ts3_us',
    },

    'PTSP' => {
        'LINE' => 8,
        'TYPE' => 'PTS1',

        #         'INIT1_DATA' => {},

        #         'INIT2_DATA1-14'           => '0x4204208874928A',    #  Byte 1 .. 7   ( data  1 .. 14 )
        #         'INIT2_MANUFACTURING_DATE' => '0x3789',              #  Byte 8 + 9    ( data 15 .. 18 )
        #         'INIT2_LOT_LINE_NUMBER'    => '0x00',                #  Byte 10
        #         'INIT2_SERIES_NUMBER'      => '0x9876543210AB',      #  Byte 11 .. 16
        'INIT2_DATA' => {
            PROTOCOL_REVISION             => 4,                          # Data 1
            NUMBER_OF_DATA_BLOCKS         => 32,                         # Data 2 and 3
            MANUFACTURER                  => 'BOSCH_ASCII',              # Data 4 and 5
            SENSOR_TYPE                   => 'PRESSURE_SENSOR',          # Data 6 and Data 7
            TRANSMISSION_MODE             => 'PTS1_ABS_PRESSURE_OFF',    # Data 8
            SENSOR_TYPE_PSI_CONFIGURATION => '0x7',                      # Data 9
            ELECTRONIC_HOUSE_CODING       => '0x49',                     # Data 10 and Data 11
            MANUFACTURER_SERIES_CODE      => '0x28A',                    # Data 12, 13, 14
            SGB_MANUFACTURING_DATE        => '31-12-2016',               # Data 15, 16, 17, 18
            LOT_NUMBER                    => '0x0',                      # Data 19
            LINE_NUMBER                   => '0x0',                      # Data 20
            SERIES_NUMBER                 => '0x9876543210AB',           # Data 21 .. 32
        },
        'INIT3_DATA' => {
            'INIT3_MESSAGE'           => 'SENSOR_OK',
            'ABSOLUTE_PRESSURE_VALUE' => 10,
        },

        'CYCLIC_MESSAGES' => {
            'ALL'                     => '0x000',
            'NUMBER_OF_USED_BYTES'    => 10,
            'ABSOLUTE_PRESSURE_VALUE' => 10,
        },

        'USER_MESSAGES' => {
            'ALL'                  => '0x000',
            'NUMBER_OF_USED_BYTES' => 10,
        },

        'TIMESLOT' => 'Timeslot_ts3_us',
    },

    'PCSC' => {
        'LINE' => 9,
        'TYPE' => 'UFS6e',

        #         'INIT1_DATA' => {},

        #         'INIT2_DATA1-14'           => '0x42042114A270C5',    #  Byte 1 .. 7   ( data  1 .. 14 )
        #         'INIT2_MANUFACTURING_DATE' => '0x3789',              #  Byte 8 + 9    ( data 15 .. 18 )
        #         'INIT2_LOT_LINE_NUMBER'    => '0x00',                #  Byte 10
        #         'INIT2_SERIES_NUMBER'      => '0x9876543210AB',      #  Byte 11 .. 16
        'INIT2_DATA' => {
            PROTOCOL_REVISION      => 4,                                # Data 1
            NUMBER_OF_DATA_BLOCKS  => 32,                               # Data 2 and 3
            MANUFACTURER           => 'BOSCH_ASCII',                    # Data 4 and 5
            PAS6e_GENERATION_BIT   => 'PAS6e',                          # Data 6
            SENSOR_TYPE            => 'ACCELERATION_SENSOR',            # Data 7
            ACCELERATION_AXIS      => 'ACCELERATION_AXIS_ALPHA',        # Data 8
            ACCELERATION_RANGE     => '480g_RANGE',                     # Data 9
            SENSOR_CODE            => 'PAS6e_426Hz_6us_SAMPLE_TIME',    # Data 10
            HOUSING_CODE           => '0x27',                           # Data 10 and Data 11
            SENSOR_CODE_CUSTOMER   => '0x0C5',                          # Data 12, 13, 14
            SGB_MANUFACTURING_DATE => '31-12-2016',                     # Data 15, 16, 17, 18
            LOT_NUMBER             => '0x0',                            # Data 19
            LINE_NUMBER            => '0x0',                            # Data 20
            SERIES_NUMBER          => '0x9876543210AB',                 # Data 21 .. 32
        },
        'INIT3_DATA' => {
            'INIT3_MESSAGE' => 'SENSOR_OK',
        },

        'CYCLIC_MESSAGES' => {
            'ALL'                  => '0x000',
            'NUMBER_OF_USED_BYTES' => 10,
        },

        'USER_MESSAGES' => {
            'ALL'                  => '0x000',
            'NUMBER_OF_USED_BYTES' => 4,
        },

        'TIMESLOT' => 'Timeslot_ts2_us',

    },

    'PASMP' => {
        'LINE' => 10,
        'TYPE' => 'PAS6e',

        #         'INIT1_DATA' => {},

        #         'INIT2_DATA1-14'           => '0x42042114800000',    #  old: 420420148341CA',    #  Byte 1 .. 7   ( data  1 .. 14 )
        #         'INIT2_MANUFACTURING_DATE' => '0x3789',              #  Byte 8 + 9    ( data 15 .. 18 )
        #         'INIT2_LOT_LINE_NUMBER'    => '0x00',                #  Byte 10
        #         'INIT2_SERIES_NUMBER'      => '0x9876543210AB',      #  Byte 11 .. 16
        'INIT2_DATA' => {
            PROTOCOL_REVISION      => 4,                                # Data 1
            NUMBER_OF_DATA_BLOCKS  => 32,                               # Data 2 and 3
            MANUFACTURER           => 'BOSCH_ASCII',                    # Data 4 and 5
            PAS6e_GENERATION_BIT   => 'PAS6e',                          # Data 6
            SENSOR_TYPE            => 'ACCELERATION_SENSOR',            # Data 7
            ACCELERATION_AXIS      => 'ACCELERATION_AXIS_ALPHA',        # Data 8
            ACCELERATION_RANGE     => '120g_RANGE',                     # Data 9
            SENSOR_CODE            => 'PAS6e_426Hz_6us_SAMPLE_TIME',    # Data 10
            HOUSING_CODE           => '0x00',                           # Data 10 and Data 11
            SENSOR_CODE_CUSTOMER   => '0x000',                          # Data 12, 13, 14
            SGB_MANUFACTURING_DATE => '31-12-2016',                     # Data 15, 16, 17, 18
            LOT_NUMBER             => '0x0',                            # Data 19
            LINE_NUMBER            => '0x0',                            # Data 20
            SERIES_NUMBER          => '0x9876543210AB',                 # Data 21 .. 32
        },
        'INIT3_DATA' => {
            'INIT3_MESSAGE' => 'SENSOR_OK',
        },

        'CYCLIC_MESSAGES' => {
            'ALL'                  => '0x000',
            'NUMBER_OF_USED_BYTES' => 10,
        },

        'USER_MESSAGES' => {
            'ALL'                  => '0x000',
            'NUMBER_OF_USED_BYTES' => 4,
        },

        'TIMESLOT' => 'Timeslot_ts2_us',

    },
    'PASMD' => {
        'LINE' => 11,
        'TYPE' => 'PAS6e',

        #         'INIT1_DATA' => {},

        #         'INIT2_DATA1-14'           => '0x42042114800000',    #  old: 420420148341CA',    #  Byte 1 .. 7   ( data  1 .. 14 )
        #         'INIT2_MANUFACTURING_DATE' => '0x3789',              #  Byte 8 + 9    ( data 15 .. 18 )
        #         'INIT2_LOT_LINE_NUMBER'    => '0x00',                #  Byte 10
        #         'INIT2_SERIES_NUMBER'      => '0x9876543210AB',      #  Byte 11 .. 16
        'INIT2_DATA' => {
            PROTOCOL_REVISION      => 4,                                # Data 1
            NUMBER_OF_DATA_BLOCKS  => 32,                               # Data 2 and 3
            MANUFACTURER           => 'BOSCH_ASCII',                    # Data 4 and 5
            PAS6e_GENERATION_BIT   => 'PAS6e',                          # Data 6
            SENSOR_TYPE            => 'ACCELERATION_SENSOR',            # Data 7
            ACCELERATION_AXIS      => 'ACCELERATION_AXIS_ALPHA',        # Data 8
            ACCELERATION_RANGE     => '120g_RANGE',                     # Data 9
            SENSOR_CODE            => 'PAS6e_426Hz_6us_SAMPLE_TIME',    # Data 10
            HOUSING_CODE           => '0x00',                           # Data 10 and Data 11
            SENSOR_CODE_CUSTOMER   => '0x000',                          # Data 12, 13, 14
            SGB_MANUFACTURING_DATE => '31-12-2016',                     # Data 15, 16, 17, 18
            LOT_NUMBER             => '0x0',                            # Data 19
            LINE_NUMBER            => '0x0',                            # Data 20
            SERIES_NUMBER          => '0x9876543210AB',                 # Data 21 .. 32
        },
        'INIT3_DATA' => {
            'INIT3_MESSAGE' => 'SENSOR_OK',
        },

        'CYCLIC_MESSAGES' => {
            'ALL'                  => '0x000',
            'NUMBER_OF_USED_BYTES' => 10,
        },

        'USER_MESSAGES' => {
            'ALL'                  => '0x000',
            'NUMBER_OF_USED_BYTES' => 4,
        },

        'TIMESLOT' => 'Timeslot_ts2_us',

    },

};

#      ____  _____ _   _ ____   ___  ____  ____    _______   ______  _____ ____
#     / ___|| ____| \ | / ___| / _ \|  _ \/ ___|  |_   _\ \ / /  _ \| ____/ ___|
#     \___ \|  _| |  \| \___ \| | | | |_) \___ \    | |  \ V /| |_) |  _| \___ \
#      ___) | |___| |\  |___) | |_| |  _ < ___) |   | |   | | |  __/| |___ ___) |
#     |____/|_____|_| \_|____/ \___/|_| \_\____/    |_|   |_| |_|   |_____|____/
#
$Defaults->{'PSI5_SENSORS_TYPES'} = {

    # UFS6e with 125kB
    'UFS6e' => {

        'QUIESCENT_CURR_MA' => 4,
        'TRANSMIT_CURR_MA'  => 26,
        'INIT1_TIME_MS'     => 60.5,
        'INIT2_TIME_MS'     => 128,
        'INIT3_TIME_MS'     => 8,
    },

    # PAS6e with 189kB
    'PAS6e' => {
        'QUIESCENT_CURR_MA' => 4,
        'TRANSMIT_CURR_MA'  => 26,
        'INIT1_TIME_MS'     => 60.5,
        'INIT2_TIME_MS'     => 128,
        'INIT3_TIME_MS'     => 8,
    },

    # PPS3e with 189kB
    'PPS3e' => {
        'QUIESCENT_CURR_MA' => 4,
        'TRANSMIT_CURR_MA'  => 26,
        'INIT1_TIME_MS'     => 60.5,
        'INIT2_TIME_MS'     => 128,
        'INIT3_TIME_MS'     => 8,
    },

    # PTS1 with 125kB
    'PTS1' => {
        'QUIESCENT_CURR_MA' => 4,
        'TRANSMIT_CURR_MA'  => 26,
        'INIT1_TIME_MS'     => 60.5,
        'INIT2_TIME_MS'     => 128,
        'INIT3_TIME_MS'     => 8,
    },

};

#      _     ___ _   _ _____ ____    ____  _____ _____ _   _   _ _   _____ ____
#     | |   |_ _| \ | | ____/ ___|  |  _ \| ____|  ___/ \ | | | | | |_   _/ ___|
#     | |    | ||  \| |  _| \___ \  | | | |  _| | |_ / _ \| | | | |   | | \___ \
#     | |___ | || |\  | |___ ___) | | |_| | |___|  _/ ___ \ |_| | |___| |  ___) |
#     |_____|___|_| \_|_____|____/  |____/|_____|_|/_/   \_\___/|_____|_| |____/
#
$Defaults->{'PSI5_LINES_DEFAULTS'} = {
    'Auto_restart_time_us' => 507,
    'Auto_restart_int'     => 0,
    'Parity_bit_ts1_int'   => 1,
    'Parity_bit_ts2_int'   => 1,
    'Parity_bit_ts3_int'   => 1,
    'Parity_bit_ts4_int'   => 1,
    'Reboot_counter_int'   => 1,
    'Timeslot_ts1_us'      => 48,
    'Timeslot_ts2_us'      => 192,
    'Timeslot_ts3_us'      => 348,
    'baudrate_kbps'        => 125,
};

