package LIFT_PROJECT;

$Defaults -> {'PSEM_Coreassetconfig'} = {
'Sensor_Details' =>{

#This has talks about which fault are possible for INIT2 in your project
	'Fault_Behaviour' => {
		'PROTOCOL_REVISION'      => 'YES',                                # Data 1
		'MANUFACTURER'           => 'YES',                    # Data 4 and 5
		'PAS6e_GENERATION_BIT'   => 'YES',                          # Data 6
		'SENSOR_TYPE'            => 'YES',            # Data 7
		'SENSOR_CODE'            => 'YES',    # Data 10
		'HOUSING_CODE'           => 'NO',		   # Data 10 and Data 11
		'LINE_NUMBER'       => 'NO',
		'LOT_NUMBER'    => 'NO',
		'SGB_MANUFACTURING_DATE' => 'YES',
		'SENSOR_CODE_CUSTOMER' => 'NO',		
		'ACCELERATION_AXIS' => 'YES',
		'FILTER_TYPE_AND_SAMPLING_MODE' => 'YES',
		'ACCELERATION_RANGE' => 'YES',
		'PRESSURE_SENSOR_TYPE' => 'YES',
		'SENSOR_MODE' => 'YES',
		'PSI5_MODE' => 'YES',
		'TRANSMISSION_MODE' => 'YES',
		'SENSOR_TYPE_PSI_CONFIGURATION' => 'YES',
		'ELECTRONIC_HOUSE_CODING' => 'YES',
		'MANUFACTURER_SERIES_CODE' => 'YES',
		'BOSCH_SENSOR_CODE' => 'YES',
	},
	'Mode' =>{
		'AK-LV29' => 'Yes',
		'Bosch' => 'No',
	},
	'ASIC_details' =>{
		'Reboot_max_counter' => '0x0A',
		'number_Asic' => '2', # The number of asics configured for CA
		'ASIC_Name' => 'CG904',
	},
	'Max_Sensorfamily_Type_Supported' => '0x0A',
	
# Example:
	# 'SnesorName' => {
		# 'Sensor_Family' => 'PAS6f',
		
	# }

	# 'SensorFamilyName' =>{
		# 'MfgCode' => '',
		# 'ProtocolRev' => '',
		# 'SensorGen' => '',
		# 'Filter' => '',
		# 'Sample' => '',
	# }
#For a given software sensor details of which family it belongs to and etc...	
#Single test case for each family and each sensor. will cover valid1, valid2, invalid1, invalid2, invalid3
	'PASFD' => {
		'Sensor_Family' => 'PAS6e',	
		'ASIC_Connected' => 'Master',
		'Timeslot' => '1',
			'Channel_no' => '2',	
			'Line' => '4',
			},
	'PASFP' => {
		'Sensor_Family' => 'PAS6e',
		'ASIC_Connected' => 'Master',	
			'Channel_no' => '3',
			'Timeslot' => '4',
			'Line' => '3',
	},
	'PASMD' => {
		'Sensor_Family' => 'PAS6e',	
		'ASIC_Connected' => 'Master',
		'Timeslot' => '4',
		'Channel_no' => '4',
		'Line' => '3',
	},
	'PASMP' => {
		'Sensor_Family' => 'PAS6e',		
		'ASIC_Connected' => 'Master',
		'Channel_no' => '5',
		'Timeslot' => '4',
		'Line' => '4',
	},
	'PASRC' => {
		'Sensor_Family' => 'UFS6e',
		'ASIC_Connected' => 'Slave',
		'Channel_no' => '8',
		'Timeslot' => '3',
		'Line' => '6',
	},
	'UFSD' => {
		'Sensor_Family' => 'UFS6e',	
		'ASIC_Connected' => 'Master',
		'Channel_no' => '0',
		'Timeslot' => '2',
		'Line' => '1',
	},
	'UFSP' => {
		'Sensor_Family' => 'UFS6e',	
		'ASIC_Connected' => 'Master',
		'Channel_no' => '1',
		'Timeslot' => '2',
		'Line' => '2',
	},
	'PCSC' => {
		'Sensor_Family' => 'UFS6e',	
		'ASIC_Connected' => 'Slave',
		'Channel_no' => '11',
		'Timeslot' => '2',
        'Line' => '3',		
	},
	'PPSFD' => {
		'Sensor_Family' => 'PPS3e',	
		'ASIC_Connected' => 'Master',
		'Channel_no' => '6',
		'Timeslot' => '4',
		'Line' => '3',
	},
	'PPSFP' => {
		'Sensor_Family' => 'PPS3e',
		'ASIC_Connected' => 'Master',
		'Channel_no' => '7',
		'Timeslot' => '4',
		'Line' => '4',
	},
	'PTSD' => {
		'Sensor_Family' => 'PTS1',		
		'ASIC_Connected' => 'Slave',
		'Channel_no' => '9',
		'Timeslot' => '3',
		'Line' => '1',
	},
	'PTSP' => {
		'Sensor_Family' => 'PTS1',		
		'ASIC_Connected' => 'Slave',
		'Timeslot' => '3',
		'Channel_no' => '10',
		'Line' => '2',
	},

#sensor family detials
	'PAS6f' =>{
		'ProtocolRev' => ['0110','0100'],
		'Filter' => ['0xxx','1xxx' ], #either the 1st or 2nd value is supported
		'Sample' => ['x0xx','x1xx'], #either the 1st or 2nd value is supported
		'errorcode' => ['0x213','0x214','0x215','0x216','0x217','0x218','0x219','0x21A','0x21B','0x21C','0x21E'],
		'UnexpectedMessages' => ['0x20F','0x20E','0x20D','0x20C','0x20B','0x20A','0x209','0x208','0x207','0x206','0x205','0x204','0x203','0x202','0x201','0x200'],
	},
	'PAS6fXY' =>{
		'ProtocolRev' => ['0110','0100'],
		'Filter' => ['0xxx','1xxx' ], #either the 1st or 2nd value is supported
		'Sample' => ['x0xx','x1xx'], #either the 1st or 2nd value is supported
		'errorcode' => 'None',
		'UnexpectedMessages' => ['0x20F','0x20E','0x20D','0x20C','0x20B','0x20A','0x209','0x208','0x207','0x206','0x205','0x204','0x203','0x202','0x201','0x200'],
	},	
	'PAS6s' =>{
		'ProtocolRev' => ['0110','0100'], 
		'Filter' => ['0xxx','1xxx' ], #either the 1st or 2nd value is supported
		'Sample' => ['x0xx','x1xx'], #either the 1st or 2nd value is supported
		'errorcode' => ['0x213','0x214','0x215','0x216','0x217','0x218','0x219','0x21A','0x21B','0x21C','0x21E'],
		'UnexpectedMessages' => ['0x20F','0x20E','0x20D','0x20C','0x20B','0x20A','0x209','0x208','0x207','0x206','0x205','0x204','0x203','0x202','0x201','0x200'],
	},
	'PAS6sXY' =>{
		'ProtocolRev' => ['0110','0100'],
		'Filter' => ['0xxx','1xxx' ], #either the 1st or 2nd value is supported
		'Sample' => ['x0xx','x1xx'], #either the 1st or 2nd value is supported
		'errorcode' => 'None',
		'UnexpectedMessages' => ['0x20F','0x20E','0x20D','0x20C','0x20B','0x20A','0x209','0x208','0x207','0x206','0x205','0x204','0x203','0x202','0x201','0x200'],
	},
	'PAS5R' =>{
		'ProtocolRev' => ['0100'],
		'Filter' => 'None',
		'Sample' => 'None', 
		'errorcode' => ['0x213','0x214','0x215','0x216','0x217','0x218','0x219','0x21A','0x21B','0x21C','0x21E'],
		'UnexpectedMessages' => ['0x20F','0x20E','0x20D','0x20C','0x20B','0x20A','0x209','0x208','0x207','0x206','0x205','0x204','0x203','0x202','0x201','0x200'],
	},
	'PAS5XY' =>{
		'ProtocolRev' => ['0100'],
		'Filter' => 'None',
		'Sample' => 'None', 
		'errorcode' => ['0x213','0x214','0x215','0x216','0x217','0x218','0x219','0x21A','0x21B','0x21C','0x21E'],
		'UnexpectedMessages' => ['0x20F','0x20E','0x20D','0x20C','0x20B','0x20A','0x209','0x208','0x207','0x206','0x205','0x204','0x203','0x202','0x201','0x200'],
	},
	'PAS6' =>{
		'ProtocolRev' => ['0100'],
		'Filter' => 'None',
		'Sample' => 'None', 
		'errorcode' => ['0x213','0x214','0x215','0x216','0x217','0x218','0x219','0x21A','0x21B','0x21C','0x21E'],
		'UnexpectedMessages' => ['0x20F','0x20E','0x20D','0x20C','0x20B','0x20A','0x209','0x208','0x207','0x206','0x205','0x204','0x203','0x202','0x201','0x200'],
	},
	'PAS6e' =>{
		'ProtocolRev' => ['0100'],
		'Filter' => 'None',
		'Sample' => 'None', 
		'errorcode' => ['0x213','0x214','0x215','0x216','0x217','0x218','0x219','0x21A','0x21B','0x21C','0x21E'],
		'UnexpectedMessages' => ['0x20F','0x20E','0x20D','0x20C','0x20B','0x20A','0x209','0x208','0x207','0x206','0x205','0x204','0x203','0x202','0x201','0x200'],
	},
	'PAS5D' =>{
		'ProtocolRev' => ['0100'],
		'Filter' => 'None',
		'Sample' => 'None',  
		'errorcode' => 'None',
		'UnexpectedMessages' => ['0x20F','0x20E','0x20D','0x20C','0x20B','0x20A','0x209','0x208','0x207','0x206','0x205','0x204','0x203','0x202','0x201','0x200'],
	},
	'PAS5eD' =>{
		'ProtocolRev' => ['0100'],
		'Filter' => 'None',
		'Sample' => 'None', 
		'errorcode' => ['0x213','0x214','0x215','0x216','0x217','0x218','0x219','0x21A','0x21B','0x21C','0x21E'],
		'UnexpectedMessages' => ['0x20F','0x20E','0x20D','0x20C','0x20B','0x20A','0x209','0x208','0x207','0x206','0x205','0x204','0x203','0x202','0x201','0x200'],
	},
	'UFS6f' =>{
		'ProtocolRev' => ['0110','0100'], 
		'Filter' => ['0xxx', '1xxx' ], #either the 1st or 2nd value is supported
		'Sample' => ['x0xx', 'x1xx'], #either the 1st or 2nd value is supported
		'errorcode' => ['0x213','0x214','0x215','0x216','0x217','0x218','0x219','0x21A','0x21B','0x21C','0x21E'],
		'UnexpectedMessages' => ['0x20F','0x20E','0x20D','0x20C','0x20B','0x20A','0x209','0x208','0x207','0x206','0x205','0x204','0x203','0x202','0x201','0x200'],
	},
	'UFS6s' =>{
		'ProtocolRev' => ['0110','0100'],
		'Filter' => ['0xxx','1xxx' ], #either the 1st or 2nd value is supported
		'Sample' => ['x0xx','x1xx'], #either the 1st or 2nd value is supported
		'errorcode' =>['0x213','0x214','0x215','0x216','0x217','0x218','0x219','0x21A','0x21B','0x21C','0x21E'],
		'UnexpectedMessages' => ['0x20F','0x20E','0x20D','0x20C','0x20B','0x20A','0x209','0x208','0x207','0x206','0x205','0x204','0x203','0x202','0x201','0x200'],
	},
	'UFS3R' =>{
		'MfgCode' => '0001 0000',
		'ProtocolRev' => ['0100'],
		'Filter' => 'None',
		'Sample' => 'None', 
		'errorcode' => ['0x213','0x214','0x215','0x216','0x217','0x218','0x219','0x21A','0x21B','0x21C','0x21E'],
		'UnexpectedMessages' => ['0x20F','0x20E','0x20D','0x20C','0x20B','0x20A','0x209','0x208','0x207','0x206','0x205','0x204','0x203','0x202','0x201','0x200'],
	},
	'UFS6' =>{
		'ProtocolRev' => ['0100'],
		'Filter' => 'None',
		'Sample' => 'None',  
		'errorcode' => ['0x213','0x214','0x215','0x216','0x217','0x218','0x219','0x21A','0x21B','0x21C','0x21E'],
		'UnexpectedMessages' => ['0x20F','0x20E','0x20D','0x20C','0x20B','0x20A','0x209','0x208','0x207','0x206','0x205','0x204','0x203','0x202','0x201','0x200'],
	},
	'UFS6e' =>{
		'ProtocolRev' => ['0100'],
		'Filter' => 'None',
		'Sample' => 'None', 
		'errorcode' => ['0x213','0x214','0x215','0x216','0x217','0x218','0x219','0x21A','0x21B','0x21C','0x21E'],
		'UnexpectedMessages' => ['0x20F','0x20E','0x20D','0x20C','0x20B','0x20A','0x209','0x208','0x207','0x206','0x205','0x204','0x203','0x202','0x201','0x200'],
	},
	'PPS2' =>{
		'ProtocolRev' => ['0100'],
		'Filter' => 'None',
		'Sample' => 'None', 
		'errorcode'=> ['0x200','0x201','0x202','0x203','0x204','0x205','0x206','0x207','0x208','0x209','0x20A','0x20B','0x20C','0x20D','0x20E','0x20F','0x210','0x211','0x212','0x213','0x214','0x215','0x216','0x217','0x218','0x219','0x21A','0x21B','0x21C','0x21D','0x21E','0x21F'], #hex values from 200 to 21F are the error codes
		'SensorType' => 'Pressure',
		'AbsolutePressure_ValidStartRange_AK-LV' => '6',
		'AbsolutePressure_ValidEndRange_AK-LV' => '3399',
		'AbsolutePressure_ValidStartRange_Bosch' => '6',
		'AbsolutePressure_ValidEndRange_Bosch'=> '3399',
	},
	'PPS3' =>{
		'ProtocolRev' => ['0100','0110'],
		'Filter' => 'None',
		'Sample' => 'None', 
		'errorcode'=> ['0x200','0x201','0x202','0x203','0x204','0x205','0x206','0x207','0x208','0x209','0x20A','0x20B','0x20C','0x20D','0x20E','0x20F','0x210','0x211','0x212','0x213','0x214','0x215','0x216','0x217','0x218','0x219','0x21A','0x21B','0x21C','0x21D','0x21E','0x21F'], #hex values from 200 to 21F are the error codes
		'UnexpectedMessages' => ['0x3FF','0x380','0x37F','0x300','0x2FF','0x280','0x27F','0x200','0x1FF','0x180','0x17F','0x100','0x0FF','0x080','0x07F','0x000'],
		'SensorType' => 'Pressure',
		'AbsolutePressure_ValidStartRange_AK-LV' => '6',
		'AbsolutePressure_ValidEndRange_AK-LV' => '3399',
		'AbsolutePressure_ValidStartRange_Bosch' => '6',
		'AbsolutePressure_ValidEndRange_Bosch' => '3399',
	},
	'PTS1' =>{
		'ProtocolRev' => ['0100','0110'],
		'Filter' => 'None',
		'Sample' => 'None', 
		'errorcode'=> ['0x200','0x201','0x202','0x203','0x204','0x205','0x206','0x207','0x208','0x209','0x20A','0x20B','0x20C','0x20D','0x20E','0x20F','0x210','0x211','0x212','0x213','0x214','0x215','0x216','0x217','0x218','0x219','0x21A','0x21B','0x21C','0x21D','0x21E','0x21F'], #hex values from 200 to 21F are the error codes
		'UnexpectedMessages' => ['0x3FF','0x380','0x37F','0x300','0x2FF','0x280','0x27F','0x200','0x1FF','0x180','0x17F','0x100','0x0FF','0x080','0x07F','0x000'],
		'SensorType' => 'Pressure',
		'AbsolutePressure_ValidStartRange_AK-LV'=> '6',
		'AbsolutePressure_ValidEndRange_AK-LV'=>'3399',
		'AbsolutePressure_ValidStartRange_Bosch' => '6',
		'AbsolutePressure_ValidEndRange_Bosch' =>'3399',
	},	
	'PPS3e' =>{
		'ProtocolRev' => ['0100','0110'],
		'Filter' => 'None',
		'Sample' => 'None', 
		'SensorType' => 'Pressure',
		# 'errorcode'=> ['0x200' ,'0x21F'],
		'errorcode'=> ['0x200','0x201','0x202','0x203','0x204','0x205','0x206','0x207','0x208','0x209','0x20A','0x20B','0x20C','0x20D','0x20E','0x20F','0x210','0x211','0x212','0x213','0x214','0x215','0x216','0x217','0x218','0x219','0x21A','0x21B','0x21C','0x21D','0x21E','0x21F'], #hex values from 200 to 21F are the error codes
		'AbsolutePressure_ValidStartRange_AK-LV' => '6',
		'AbsolutePressure_ValidEndRange_AK-LV' => '3399',
		'AbsolutePressure_ValidStartRange_Bosch' => '6',
		'AbsolutePressure_ValidEndRange_Bosch' =>'3399',
		'UnexpectedMessages' => ['0x3FF','0x380','0x37F','0x300','0x2FF','0x280','0x27F','0x200','0x1FF','0x180','0x17F','0x100','0x0FF','0x080','0x07F','0x000'],
},
	'PTS1e' =>{
		'ProtocolRev' => ['0100','0110'],
		'Filter' => 'None',
		'Sample' => 'None', 
		'errorcode'=> ['0x200','0x201','0x202','0x203','0x204','0x205','0x206','0x207','0x208','0x209','0x20A','0x20B','0x20C','0x20D','0x20E','0x20F','0x210','0x211','0x212','0x213','0x214','0x215','0x216','0x217','0x218','0x219','0x21A','0x21B','0x21C','0x21D','0x21E','0x21F'], #hex values from 200 to 21F are the error codes
		'SensorType' => 'Pressure',
		'AbsolutePressure_ValidStartRange_AK-LV' => '6',
		'AbsolutePressure_ValidEndRange_AK-LV' => '3399',
		'AbsolutePressure_ValidStartRange_Bosch' => '6',
		'AbsolutePressure_ValidEndRange_Bosch' => '3399',
		'UnexpectedMessages' => ['0x3FF','0x380','0x37F','0x300','0x2FF','0x280','0x27F','0x200','0x1FF','0x180','0x17F','0x100','0x0FF','0x080','0x07F','0x000'],
	},
},

#Below section is only to get the possible values for each section.
#if there is a change in PSI TurboLift functions, this hash to be relooked into
#########################################################
#######################################################
####################################################
#####PLEASE DO NOT MODIFY THIS SECTION#####################
########################################
########################################

'SENSOR_TYPES_PAS5_UFS3_UFS3R_PAS5R' => {
    PROTOCOL_REVISION      => 0,     # NIBBLE 1
    NUMBER_OF_DATA_BLOCKS  => 1,     # NIBBLE 2 and 3
    MANUFACTURER           => 3,     # NIBBLE 4 and 5
    SENSOR_BUS_MODE        => 5,     # NIBBLE 6
    SENSOR_TYPE            => 6,     # NIBBLE 7
    SATELLITE_SENSING_AXIS => 7,     # NIBBLE 8
    ACCELERATION_RANGE     => 8,     # NIBBLE 9
    SENSOR_CODE            => 9,     # STARTING 2 BITS( '00'00 ) OF NIBBLE 10
    HOUSING_CODE           => 10,    # TRAILING 2 BITS( 00'00' ) OF NIBBLE 10 AND COMPLETE NIBBLE 11
    SENSOR_CODE_CUSTOMER   => 11,    # NIBBLES 12, 13 AND 14
    SGB_MANUFACTURING_DATE => 14,    # NIBBLES 15, 16, 17 AND 18
    LOT_NUMBER             => 18,    # NIBBLE 19
    LINE_NUMBER            => 19,    # NIBBLE 20
    SERIES_NUMBER          => 20,    # NIBBLE 21 TO 31
},

'SENSOR_TYPES_PAS6_PAS6e_UFS6_UFS6e' => {
    PROTOCOL_REVISION      => 0,
    NUMBER_OF_DATA_BLOCKS  => 1,
    MANUFACTURER           => 3,
    PAS6e_GENERATION_BIT   => 5,
    SENSOR_TYPE            => 6,
    ACCELERATION_AXIS      => 7,
    ACCELERATION_RANGE     => 8,
    SENSOR_CODE            => 9,
    HOUSING_CODE           => 10,
    SENSOR_CODE_CUSTOMER   => 11,
    SGB_MANUFACTURING_DATE => 14,
    LOT_NUMBER             => 18,
    LINE_NUMBER            => 19,
    SERIES_NUMBER          => 20,
},

'SENSOR_TYPES_PPS3' => {
    PROTOCOL_REVISION             => 0,     # NIBBLE 1
    NUMBER_OF_DATA_BLOCKS         => 1,     # NIBBLE 2 AND 3
    MANUFACTURER                  => 3,     # NIBBLES 4 AND 5
    SENSOR_TYPE                   => 5,     # NIBBLE 6 AND 7  -> VALUE '0X08' FOR PRESSURE SENSOR
    TRANSMISSION_MODE             => 7,     # NIBBLE 8
    SENSOR_TYPE_PSI_CONFIGURATION => 8,     # NIBBLE 9 -> RANGE '0X0' -'0XF'
    ELECTRONIC_HOUSE_CODING       => 9,     # NIBBLE 10 AND 11 -> RANGE '0X0' - '0XFF'
    MANUFACTURER_SERIES_CODE      => 11,    # NIBBLE 12, 13 AND 14 -> RANGE '0X0' - '0XFFF'
    SGB_MANUFACTURING_DATE        => 14,    # NIBBLES 15, 16, 17 AND 18
    LOT_NUMBER                    => 18,    # NIBBLE 19 -> RANGE '0X0' - '0XF'
    LINE_NUMBER                   => 19,    # NIBBLE 20 -> RANGE '0X0' - '0XF'
    SERIES_NUMBER                 => 20     #NIBBLE 21 to 31
},

'SENSOR_TYPES_PPS3e_PTS1e' => {
    PROTOCOL_REVISION             => 0,     # NIBBLE 1
    NUMBER_OF_DATA_BLOCKS         => 1,     # NIBBLE 2 AND 3
    MANUFACTURER                  => 3,     # NIBBLES 4 AND 5
    FILTER_TYPE_AND_SAMPLING_MODE => 5,     # NIBBLE 6 filter type and sampling mode
    PRESSURE_SENSOR_TYPE          => 6,     # NIBBLE 7
    SENSOR_MODE                   => 7,     # NIBBLE 8
    PSI5_MODE                     => 8,     # NIBBLE 9 -> RANGE '0X0' -'0XF'
    BOSCH_SENSOR_CODE             => 9,     # NIBBLE 10 AND 11 -> RANGE '0X0' - '0XFF'
    SENSOR_CODE_CUSTOMER          => 11,    # NIBBLE 12, 13 AND 14 -> RANGE '0X0' - '0XFFF'
    SGB_MANUFACTURING_DATE        => 14,    # NIBBLES 15, 16, 17 AND 18
    LOT_NUMBER                    => 18,    # NIBBLE 19 -> RANGE '0X0' - '0XF'
    LINE_NUMBER                   => 19,    # NIBBLE 20 -> RANGE '0X0' - '0XF'
    SERIES_NUMBER                 => 20     #NIBBLE 21 to 31
},

'SENSOR_TYPES_PPS2' => {
    PROTOCOL_REVISION             => 0,     # NIBBLE 1
    NUMBER_OF_DATA_BLOCKS         => 1,     # NIBBLE 2 AND 3
    MANUFACTURER                  => 3,     # NIBBLES 4 AND 5
    SENSOR_TYPE                   => 5,     # NIBBLE 6 AND 7  -> VALUE '0X08' FOR PRESSURE SENSOR
    TRANSMISSION_MODE             => 7,     # NIBBLE 8
    SENSOR_TYPE_PSI_CONFIGURATION => 8,     # NIBBLE 9 -> RANGE '0X0' -'0XF'
    BOSCH_SENSOR_CODE             => 9,     # NIBBLE 10 AND 11 -> RANGE '0X0' - '0XFF'
    SENSOR_CODE_CUSTOMER          => 11,    # NIBBLE 12, 13 AND 14 -> RANGE '0X0' - '0XFFF'
    SGB_MANUFACTURING_DATE        => 14,    # NIBBLES 15, 16, 17 AND 18
    LOT_NUMBER                    => 18,    # NIBBLE 19 -> RANGE '0X0' - '0XF'
    LINE_NUMBER                   => 19,    # NIBBLE 20 -> RANGE '0X0' - '0XF'
    SERIES_NUMBER                 => 20     # NIBBLE 21 to 31
},

'MANUFACTURER' => {
    BOSCH                     => '0x10',
    BOSCH_ASCII               => '0x42',
    AUTOLIV                   => '0x40',
    AUTOLIV_ASCII             => '0x41',
    CONTINENTAL               => '0x0',
    CONTINENTAL_ASCII         => '0x43',
    ANALOG_DEVICES_ASCII      => '0x44',
    ELMOS_ASCII               => '0x45',
    FREESCALE_ASCII           => '0x45',
    TRW_ASCII                 => '0x54',
    NO_SPECIFIED_MANUFACTURER => '0x00'
},

'SENSOR_TYPE' => {
    ACCELERATION_SENSOR => '0x1',    # length is 1 nible ( nbr 7 )
    PRESSURE_SENSOR     => '0x',    # length is 1 byte  ( nible nbr 6 + 7 )
},

'PRESSURE_SENSOR_TYPE' => {
    PN_SENSOR        => '0x',       # length 1 nibble
    P0_T_SENSOR      => '0x9',       # length 1 nibble
    PN_COARSE_SENSOR => '0xC',       # length 1 nibble
    P_LOW_SENSOR     => '0x5',       # length 1 nibble
    P_HIGH_SENSOR    => '0x6',       # length 1 nibble
    T_SENSOR         => '0x7',       # length 1 nibble
},

'SENSOR_BUS_MODE' => {    # POSSIBLE CONFIGURATIONS
    BUS3_TIMESLOT1 => '0x5',
    BUS3_TIMESLOT2 => '0x6',
    BUS3_TIMESLOT3 => '0x7',
    BUS4_TIMESLOT1 => '0xC',
    BUS4_TIMESLOT2 => '0xD',
    BUS4_TIMESLOT3 => '0xE',
    BUS4_TIMESLOT4 => '0xF'
},

'PAS6e_GENERATION_BIT' => {
    PAS6  => '0X0',
    PAS6e => '0X1',
},

'SATELLITE_SENSING_AXIS' => {
    SENSING_AXIS_X => '0x0',
    SENSING_AXIS_Y => '0x4',
},

# SENSOR TYPES SUPPORTED PAS5, PAS5R, UFS3, UFS3R, PAS5XY, UFS6, UFS6e, PAS6, PAS6e
'ACCELERATION_RANGE' => {
    '120g_RANGE' => '0x',
    '240g_RANGE' => '0x9',
    '480g_RANGE' => '0xA',
},

'SENSOR_MODE' => {
    'PRESSURE_-5%_to_+15%'    => '0x4',
    'PRESSURE_RESERVED'       => '0x5',
    'PRESSURE_-15%_to_+23.4%' => '0x6',
    'PRESSURE_-15%_to_+100%'  => '0x7',
    'NONE_-5%_to_+15%'        => '0x0',
    'NONE_RESERVED'           => '0x1',
    'NONE_-15%_to_+23.4%'     => '0x2',
    'NONE_-15%_to_+100%'      => '0x3',

},

'SENSOR_CODE' => {

    # PAS5, PAS5R, UFS3, UFS3R
    PAS5x_UFS3x_SMA_AXIS_X_FILTER_213Hz => '2',
    PAS5x_UFS3x_SMA_AXIS_X_FILTER_426Hz => '0',
    PAS5x_UFS3x_SMA_AXIS_Y_FILTER_213Hz => '3',
    PAS5x_UFS3x_SMA_AXIS_Y_FILTER_426Hz => '1',

    # PAS6, UFS6
    PAS6_UFS6_SMA_AXIS_X_FILTER_200Hz => '2',
    PAS6_UFS6_SMA_AXIS_X_FILTER_400Hz => '0',
    PAS6_UFS6_SMA_AXIS_Y_FILTER_200Hz => '3',
    PAS6_UFS6_SMA_AXIS_Y_FILTER_400Hz => '1',

    # PAS6e, UFS6e
    PAS6e_426Hz_6us_SAMPLE_TIME  => '0',
    PAS6e_426Hz_FAST_SAMPLE_TIME => '1',
    PAS6e_213Hz_6us_SAMPLE_TIME  => '2',
    PAS6e_213Hz_FAST_SAMPLE_TIME => '3',
},

'ACCELERATION_AXIS' => {
    ACCELERATION_AXIS_ALPHA => '0x4',
    ACCELERATION_AXIS_BETA  => '0x0',
    ACCELERATION_AXIS_GAMMA => '0x'
},

'FILTER_TYPE_AND_SAMPLING_MODE' => {
    IIR_FAST         => '0x0',
    IIR_6_US_COMMON  => '0x2',
    IIR_49_US_COMMON => '0x4',
    FIR_FAST         => '0x',
    FIR_6_US_COMMON  => '0x5',
    FIR_49_US_COMMON => '0x6',
},

'TRANSMISSION_MODE' => {
    PTS1_ABS_PRESSURE_ON                  => '0x0',
    PTS1_ABS_PRESSURE_OFF                 => '0x',
    PPS3_ABS_PRESSURE_ON                  => '0x0',
    PPS3_ABS_PRESSURE_OFF                 => '0x',
    PPS2_ABS_PRESSURE_ON_AND_PARITY_MODE  => '0x0',
    PPS2_ABS_PRESSURE_ON_AND_CRC_MODE     => '0x4',
    PPS2_ABS_PRESSURE_OFF_AND_PARITY_MODE => '0x',
    PPS2_ABS_PRESSURE_OFF_AND_CRC_MODE    => '0xC',

},

'PSI5_MODE' => {
    A10P_250_1L_PARITY                                              => '0x0',
    P10P_500_3L_PN_SLOT1_PARITY                                     => '0x5',
    P10P_500_3L_PN_SLOT2_PARITY                                     => '0x6',
    P10P_500_3L_PN_SLOT3_PARITY                                     => '0x7',
    P10P_500_3L_PN_COARSE_SLOT1__PN_SLOT3_PARITY                    => '0x2',
    P10P_500_3L_PO_T_SLOT2__PN_SLOT3_PARITY                         => '0x3',
    P10P_500_3L_PN_COARSE_SLOT1__PO_T_SLOT2__PN_SLOT3_PARITY        => '0x4',
    P10P_500_4H_PN_SLOT1_PARITY                                     => '0x',
    P10P_500_4H_PN_SLOT2_PARITY                                     => '0x9',
    P10P_500_4H_PN_SLOT3_PARITY                                     => '0xA',
    P10P_500_4H_PN_SLOT4_PARITY                                     => '0xB',
    P10P_500_4H_PN_COARSE_SLOT1__PN_SLOT4_PARITY                    => '0xC',
    P10P_500_4H_PO_T_SLOT3__PN_SLOT4_PARITY                         => '0xD',
    P10P_500_4H_PN_COARSE_SLOT1__PO_T_SLOT3__PN_SLOT4_PARITY        => '0xE',
    P10P_500_4H_PO_T_SLOT1__PN_SLOT2_PARITY                         => '0xF',
    P16CRC_500_2L_PO_T_SLOT1__PN_SLOT1_CRC                          => '0x15',
    P16CRC_500_2L_PO_T_SLOT2__PN_SLOT2_CRC                          => '0x16',
    P16CRC_500_3H_PO_T_SLOT1__PN_SLOT1_CRC                          => '0x18',
    P16CRC_500_3H_PO_T_SLOT2__PN_SLOT2_CRC                          => '0x19',
    P16CRC_500_3H_PO_T_SLOT3__PN_SLOT3_CRC                          => '0x1A',
    P10P_500_3L_PADC_LOW_SLOT1__PADC_HIGH_SLOT2___TADC_SLOT3_PARITY => '0x14',
},
                          
},
