package LIFT_Testbenches;

our $Testbench;
$Testbench = {
	'BMH1007302'=>
 	{
		'Devices'=>
 		{
			'NIDAQ'=>
 			{
 				'Device_ID' =>"M6251",	#  Devices can be :: M6251
 				'Channel_Name' =>['AO0'],# channel number(s) used for communication, Channel names can be: AO0  and AO1
			},
			'TSG4'=>
 			{
 				'Hostname' =>"BMH1007302",
 				'CANHWSerialNo' =>434,	#   written on CAN device e.g. "007129-047080" -> 47080
 				'Test_Bench_Number' =>"VTT 117",#   only for logging purpose
 				'CANchannel' =>2,
 				'Description' =>"sVTT Test PC",	#   only for logging purpose 
			},
			'TOE1'=>
 			{
 				'connect' =>"GPIB:2",
			},
			'LabCar'=>
 			{
 				'Hostname' =>"BMH1007302",
 				'CANHWSerialNo' =>434,	#   written on CAN device e.g. "007129-047080" -> 47080
 				'Test_Bench_Number' =>42,	#   only for logging purpose
 				'CANchannel' =>2,
 				'Description' =>"sVTT Test PC",	#   only for logging purpose 
			},
			'CANoe'=>
 			{
 				'Log_File' =>'D:\Sandbox\TurboLIFT\Projects\VW_PQ26\config\Tools\CANoe\CANOE.asc',
 				'Hostname' =>"BMH1007302",
 				'Online_Config' =>'D:\Sandbox\TurboLIFT\Projects\VW_PQ26\config\Tools\CANoe\CANoe_PQ26.cfg',
			},
			'DTM5080'=>
 			{
 				'connect' =>"COM6",
			},
			'GPIB'=>
 			{
 				'Hostname' =>"BMH1007302",
			},
			'DSO1'=>
 			{
 				'connect' =>"IP:10.47.105.233",
			},
			'QuaTe'=>
 			{
 				'Controllers' =>2,	#   number of controllers connected
			},
			'VOETSCH'=>
 			{
 				'connect' =>"COM6",
			},
			'PD'=>
 			{
 				'Hostname' =>"BMH1007302",
 				'CANHWSerialNo' =>434,	#   written on CAN device e.g. "007129-047080" -> 47080
 				'CANchannel' =>1,
			},
			'IDX'=>
 			{
 				'config' =>"default.cfg",
			},
		},
		'Functions'=>
 		{
			'TEMPERATURE'=>
 			{
 				'device' =>"VOETSCH",
			},
			'POWER'=>
 			{
 				'device' =>"NIDAQ",	#  POWER Devices:: LabCar,TOE1 or IDX
			},
			'CAN_Access'=>
 			{
 				'trace' =>['CANoe'],
 				'read' =>['CANoe'],
 				'write' =>['CANoe'],
			},
			'PERIPHERIE'=>
 			{
 				'device' =>"LabCar",	#  PERIPHERI Devices:: LabCar or PeriBox
			},
			'Diagnosis'=> 'CAN',
		},
	},
};

1;
