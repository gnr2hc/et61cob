# *****************************************************************************************************
#                                                                                                       
#  Copyright (c) 2012  Robert Bosch GmBH                                                                
#                      Germany                                                                          
#                      All rights reserved                                                              
#                                                                                                       
#******************************************************************************************************
#    $Source: sVTT/sVTT_Utility_GUI.pl $
#    $Revision: 1.4 $
#    $Author: Archana Gopalakrishna (RBEI/ECF1) (GOA2BMH) $
#    $State: develop $
#    $Date: 2014/11/25 19:16:23ICT $
#******************************************************************************************************

#################################################################################
# this tool is under MKS version management
my $VERSION = q$Revision: 1.4 $;
my $HEADER  = q$Header: sVTT/sVTT_Utility_GUI.pl 1.4 2014/11/25 19:16:23ICT Archana Gopalakrishna (RBEI/ECF1) (GOA2BMH) develop  $;
#################################################################################

my $addpath;
BEGIN
{
    
    use Config;
    use File::Spec;
    use File::Basename;

    # find the LIFT engine path (LIFT_engine_path = ./../)
    my $LIFT_exec_path = File::Spec->rel2abs(dirname(dirname(__FILE__))) . "/Engine";    
    
    # add directories to search path for perl modules    
    $addpath = "$LIFT_exec_path/modules";
    print "addpath is $addpath\n";
    unshift (@INC, $addpath);
    print "@INC";
}

use strict;
use warnings;
use File::Basename;
use Tk;
use Tk::Table;
use Tk::ROText;
use Tk::BrowseEntry;
use Tk::FileSelect;
use Tk::DirSelect;
use feature qw(switch);
use Readonly;
use Math::BigInt qw(bgcd);
use Time::Localtime;

use LIFT_sVTT_Curves;

Readonly my $SVTT_FAILED => -1000; # failed checking condition
Readonly my $SCALAR_FACTOR => 10**6; # allow time samples until 0.000001s / 1us

open ( LOG,">SVTT_Utility_GUI_LOG.txt" ) or die "Couldn't open SVTT_Utility_GUI_LOG.txt : $@";

my ($curve_name,$curve_window, $ss_conv_window);
my $default_curve_values = ();
my $stoc_values = ();
my $stoc_variant = 1;
my $curve_param_names = [];
my $stochastic_cbox = 'NOT_CHECKED';
my $curve_comments = ();
my ($u_min, $u_max,$curve_folder_path); #global variable for reading project default values and curve file path
my $gui_multiple_window_opening = 0;
my $curve_name_user = undef;

my $mainwindow = MainWindow->new; # Main Window
#Size of main window display
$mainwindow->geometry("700x250");
$mainwindow->resizable(0,0);

my $Headframe = $mainwindow -> Frame()->pack(-padx=>8,-pady=>8); #Frame contains the file path
my $curve_folder_frame = $mainwindow -> Frame()->pack(-padx=>8,-pady=>8); #Frame contains the file path
my $Voltage_frame = $mainwindow -> Frame()->pack(-padx=>8,-pady=>8); #Frame contains the Umax and Umin values
my $curveframe = $mainwindow -> Frame()->pack(-padx=>8,-pady=>8); #Frame contains the curve name
my $frm = $mainwindow -> Frame->pack();
my $noteframe = $mainwindow -> Frame()->pack(); #Frame contains the curve name

$Headframe->Label(-text => 'sVTT Curve Utility',-font=>"Verdana 12 bold italic underline")->pack(-side=>"left",-padx => 200);
$Headframe -> Button( "-text" => "Help", "-borderwidth"=> 3, "-command" => sub{ Help();})->pack (-side=>"right");
######################### file frame ###########################
$curve_folder_frame->Label(-text => 'Curves folder path ')->pack(-side=>"left");
$curve_folder_frame -> Entry("-width" => 70,"-textvariable" => \$curve_folder_path,)->pack (-side=>"left");
my $browse_flag =0;
$curve_folder_path = 'C:';
$curve_folder_frame -> Button( "-text" => "Browse Folder", "-borderwidth"=> 3,
                              "-command" => sub
                                {
                                    my $dir = $curve_folder_frame->chooseDirectory(-initialdir => '~', -title => 'Choose a folder');
                                    $curve_folder_path = $dir;
                                },
                            )->pack (-side=>'right',-padx=>'05');

$Voltage_frame->Label(-text => 'Umax (V) ')->pack(-side=>"left");
$Voltage_frame -> Entry("-width" => 25,"-textvariable" => \$u_max,)->pack (-side=>"left");

$Voltage_frame->Label(-text => 'Umin (V) ')->pack(-side=>"left");
$Voltage_frame -> Entry("-width" => 25,"-textvariable" => \$u_min,)->pack (-side=>"left");

$curveframe->Label(-text=>"Select the curve to Generate")->pack(-side => "top")->pack(-side=>"left");

my $curve_select = $curveframe->BrowseEntry("-textvariable"=> \$curve_name,"-state" => "readonly",) ->pack(-side=>"left");

my $curve_list = $curve_select->Subwidget('slistbox')->Subwidget('scrolled')->pack();

my @content;
tie @content,'Tk::Listbox', $curve_list;
@content = qw/   LV124_e_01
                 LV124_e_02
                 LV124_e_03
                 LV124_e_04
                 LV124_e_05
                 LV124_e_07
                 LV124_e_08
                 LV124_e_09
                 LV124_e_11
                 LV124_e_12
             /;

$frm -> Button(-text => "Enter","-borderwidth"=>3,
                -command => sub{
                                 if($curve_folder_path eq 'C:')
                                 {
                                        W2log("WARNING :: Change folder path \n");
                                        $mainwindow->messageBox(
                                                                    '-icon'    => "warning", #qw/error info question warning/
                                                                    '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                                                                    '-title'   => 'Folder path',
                                                                    '-message' => "Change folder path other than 'C:'"
                                                                );
                                        return;
                                 }
                                 elsif($curve_folder_path eq '')
                                 {
                                        W2log("ERROR :: No folder path given \n");
                                        $mainwindow->messageBox(
                                                                    '-icon'    => "error", #qw/error info question warning/
                                                                    '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                                                                    '-title'   => 'Folder path',
                                                                    '-message' => "No folder path given"
                                                                );
                                        return;
                                 }

                                if ((defined $u_max) && (defined $u_min) && (defined $curve_name))
                                {
                                    if($u_min > $u_max)
                                    {
                                        W2log("ERROR :: U_Min > U_max \n");
                                        $mainwindow->messageBox(
                                                                    '-icon'    => "error", #qw/error info question warning/
                                                                    '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                                                                    '-title'   => 'Voltage',
                                                                    '-message' => "U_Min ($u_min) > U_max ($u_max)"
                                                                );
                                        return;
                                    }
                                    $curve_window = $mainwindow -> Toplevel();
                                    $curve_window->geometry("700x500");
                                    $curve_window->resizable(0,0);
                                    $curve_window -> Label(-text=>"Parameters of $curve_name",-font=>"Verdana 12 bold italic") -> pack(-padx=>8,-pady=>8);
                                    my $curve_frame_top = $curve_window -> Frame()->pack(-padx=>8,-pady=>8); #Frame contains the curve name in top window 
                                    $curve_name_user = $curve_name;
                                    $curve_frame_top->Label(-text => 'Curve Name')->pack(-side => "top")->pack(-side=>"left");
                                    $curve_frame_top -> Entry("-width" => 25,"-textvariable" => \$curve_name_user,)->pack (-side=>"right");

                                    given($curve_name)
                                    {
                                        when ( "LV124_e_01")
                                        {
                                            W2log("INFO:: Creation of curve LV124_e_01 \n");
                                        $curve_param_names = ['Vmax:0','Vmin:0','Holding_time_in_Vmin:0','tr:1','tf:1', 't1:1','number_of_cycles:0','sampling_time:0']; #correct params
                                        $default_curve_values = [17, 13.5, 5, 0.009, 0.009, 3600, 1, 0.2]; #time in seconds
                                        # @$curve_param_names = keys(%{$$curve_spec_hash{$curve_name}});
                                        # @$default_curve_values = values (%{$$curve_spec_hash{$curve_name}});
                                            $stoc_values = ['','','','','','','',''];
                                            $curve_comments = ['in V','in V', 'in V','in s', 'in s', 'in s','number of times the cycle should repeate','should be <0.2'];
                                            Create_table($curve_param_names, $default_curve_values, $curve_comments);
                                        }
                                        when ( "LV124_e_02")
                                        {
                                            W2log("INFO:: Creation of curve LV124_e_02 \n");
                                            $curve_param_names = ['Vmin:0','U1:0','Vmax:0','tr:1', 'tf:1', 't1:1','t2:1', 't3:1', 'number_of_cycles:0','sampling_time:0'];#correct params
                                            $default_curve_values = [16, 17, 18, 0.001, 0.001, 0.4, 0.6, 2, 3, 0.0002]; #time in seconds
                                            # $stoc_values = ['','','','','','','','','',''];
                                            $curve_comments = ['in V','in V', 'in V', 'in s', 'in s', 'in s', 'in s', 'in s', 'number of times the cycle should repeate','should be <0.0002'];
                                            Create_table($curve_param_names, $default_curve_values,$curve_comments);
                                        }
                                        when("LV124_e_03")
                                        {
                                            W2log("INFO:: Creation of curve LV124_e_03 \n");
                                            $curve_param_names = ['Vmax:0','Vmin:0', 'tr:1', 'tf:1', 't1:1','t2:1', 'number_of_cycles:0','sampling_time:0'];#correct params
                                            $default_curve_values = [10.8, 9, 0.0018, 0.0018, 0.5, 1, 3, 0.0002]; #time in seconds
                                            # $stoc_values = ['','','','','','','',''];
                                            $curve_comments = ['in V','in V','in s', 'in s', 'in s', 'in s', 'number of times the cycle should repeate','should be <0.0002'];
                                            Create_table($curve_param_names, $default_curve_values,$curve_comments);
                                        }
                                        when( "LV124_e_04")
                                        {
                                            W2log("INFO:: Creation of curve LV124_e_04 \n");
                                            $curve_param_names = ['Vmin:0','Vmax:0', 't1:1', 'tr:1', 'tf:1', 'number_of_cycles:0', 'sampling_time:0'];#correct params
                                            $default_curve_values = [10.8, 26, 60, 0.009, 0.009, 1, 0.0002]; #time in seconds
                                            $stoc_values = ['','','','','','',''];
                                            $curve_comments = ['in V','in V','in s', 'in s', 'in s', 'number of times the cycle should repeate','should be <0.0002'];
                                            Create_table($curve_param_names, $default_curve_values, $curve_comments);
                                        }
                                        when( "LV124_e_05")
                                        { 
                                            W2log("INFO:: Creation of curve LV124_e_05 \n");
                                            $curve_param_names = ['u_min:0', 'u_max:0', 'tr:1', 't1:1', 'tf:1', 'Break_between_cycles:0', 'iteration:0', 'sampling_time:0'];#correct params
                                            $default_curve_values = [13.5, 27, 0.001, 0.3, 0.03, 60, 10, 0.0002]; #time in seconds
                                            $stoc_values = ['','','','','','','',''];
                                            $curve_comments = ['in V','in V','in s', 'in s', 'in s', 'in s', 'number of times the cycle should repeate','should be <0.0002'];
                                            Create_table($curve_param_names, $default_curve_values, $curve_comments);
                                        }
                                        when( "LV124_e_07")
                                        {
                                            W2log("INFO:: Creation of curve LV124_e_07 \n");
                                            $curve_param_names = ['Start_voltage:0','Rate_of_Voltage_Change:0', 'U1:0', 't1:1', 'Min_Voltage:0', 'U2:0', 't2:1','Final_Voltage:0', 'number_of_cycles:0','sampling_time:0'];#correct params
                                            $default_curve_values = [16,0.5,6,60,0,6, 60,16, 1, 0.002]; #time in seconds
                                            $stoc_values = ['','','','','','','','','',''];
                                            $curve_comments = ['in V','in V','in V', 'in s', 'in V', 'in V', 'in s', 'in V','number of times the cycle should repeate','should be <0.002'];
                                            Create_table($curve_param_names, $default_curve_values, $curve_comments);
                                        }
                                        when( "LV124_e_08")
                                        {
                                            W2log("INFO:: Creation of curve LV124_e_08 \n");
                                            $curve_param_names = ['Start_voltage:0','Voltage_drop:0', 'V1:0', 't1:1', 'min_voltage:0', 't2:1','Final_Voltage:0', 'tr:1', 'number_of_cycles:0','sampling_time:0'];#correct params
                                            $default_curve_values = [16,0.5,6,60,0,60,16,0.4,1,0.002]; #time in seconds
                                            $stoc_values = ['','','','','','','','','',''];
                                            $curve_comments = ['in V','in V','in V', 'in s', 'in V', 'in s', 'in V', 'in s', 'number of times the cycle should repeate','should be <0.002'];
                                            Create_table($curve_param_names, $default_curve_values, $curve_comments);
                                        }
                                        when( "LV124_e_09")
                                        {
                                            W2log("INFO:: Creation of curve LV124_e_09 \n");
                                            $curve_param_names = ['Vmax:0','Vth:0', 'delta_V1:0', 'delta_V2:0', 't2:1', 'tr:1', 'tf:1', 'number_of_cycles:0', 't1:1','sampling_time:0'];#correct params
                                            $default_curve_values = [8,6,0.5,0.2,11,0.009,0.009,1,5,0.0002]; #time in seconds
                                            $stoc_values = ['','','','','','','','','',''];
                                            $curve_comments = ['in V','in V','in V', 'in V', 'in s', 'in s', 'in s', 'number of times the cycle should repeate', 'in S', 'should be <0.0002'];
                                            Create_table($curve_param_names, $default_curve_values, $curve_comments);
                                        }
                                        when( "LV124_e_11")
                                        {
                                            W2log("INFO:: Creation of curve LV124_e_11 \n");
                                            $curve_param_names = ['Vb:0', 'Vt:0', 'Vs:0', 'Va:0', 'Vr:0', 't50:1', 'tf:1', 't4:1', 't5:1', 't6:1', 't7:1', 't8:1', 'tr:1', 'freq:0', 'break_between_two_cycles:0', 'number_of_cycles:0', 'sampling_time:0'];#correct params
                                            $default_curve_values = [11, 4.5, 4.5, 6.5, 2, 0, 0.00099, 0, 0, 0.019, 0.05, 10, 0.1, 2, 2, 10, 0.0002];
                                            $stoc_values = ['','','','','','','','','','','','','','','','',''];
                                            $curve_comments = ['in V','in V','in V', 'in V', 'in V', 'in s', 'in s', 'in s', 'in s', 'in s', 'in s', 'in s', 'in S', 'in Hz', 'in s', 'number of times the cycle should repeate','should be <0.0002'];
                                            Create_table($curve_param_names, $default_curve_values, $curve_comments);
                                        }
                                        when( "LV124_e_12")
                                        {
                                            W2log("INFO:: Creation of curve LV124_e_12 \n");
                                            $curve_param_names = ['Vmin:0', 'Vmax:0', 't1:1', 'tr:1', 'tf:1', 'number_of_cycles:0', 'delta_V:0','sampling_time:0'];#correct params
                                            $default_curve_values = [11.8, 15, 2, 0.301, 0.301, 10, 0, 0.0002];
                                            $stoc_values = ['','','','','','','',''];
                                            $curve_comments = ['in V','in V', 'in s', 'in s', 'in s', 'number of times the cycle should repeate', 'in V', 'should be <0.0002'];
                                            Create_table($curve_param_names, $default_curve_values, $curve_comments);
                                        }
                                    }
                                }
                                else
                                {
                                    unless (defined $u_max)
                                    {
                                        W2log("ERROR :: No U_max given \n");
                                        $mainwindow->messageBox(
                                                                    '-icon'    => "error", #qw/error info question warning/
                                                                    '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                                                                    '-title'   => 'Voltage',
                                                                    '-message' => "!Enter u_max!"
                                                                );
                                    }
                                    unless(defined $u_min)
                                    {
                                        W2log("ERROR :: No U_max given \n");
                                        $mainwindow->messageBox(
                                                                    '-icon'    => "error", #qw/error info question warning/
                                                                    '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                                                                    '-title'   => 'Voltage',
                                                                    '-message' => "!Enter u_min!"
                                                                );
                                    }

                                    if($u_min > $u_max)
                                    {
                                        W2log("ERROR :: U_Min > U_max \n");
                                        $mainwindow->messageBox(
                                                                    '-icon'    => "error", #qw/error info question warning/
                                                                    '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                                                                    '-title'   => 'Voltage',
                                                                    '-message' => "U_Min ($u_min) > U_max ($u_max)"
                                                                );
                                    }

                                    unless (defined $curve_name)
                                    {
                                        W2log("ERROR :: Curve is not selected \n");
                                        $mainwindow->messageBox(
                                                                    '-icon'    => "error", #qw/error info question warning/
                                                                    '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                                                                    '-title'   => 'Curve selection',
                                                                    '-message' => "!Select the curve!"
                                                                );
                                    }
                                }
                                }) ->pack(-side => "left");

$frm -> Button(-text => "Converter","-borderwidth"=>3,-command => sub{
                                    $ss_conv_window = $mainwindow -> Toplevel();
                                    $ss_conv_window->geometry("500x150");
                                    $ss_conv_window->resizable(0,0);
                                    $ss_conv_window -> Label(-text=>"SAT to SVTC Conversion",-font=>"Verdana 12 bold italic") -> pack(-padx=>8,-pady=>8);
                                    my $file_frame_top = $ss_conv_window -> Frame()->pack(-padx=>8,-pady=>8); #Frame contains the curve name in top window 
                                    my $but_frame_top = $ss_conv_window -> Frame()->pack(-padx=>8,-pady=>8); #Frame contains the curve name in top window 
                                    my $file_browse;
                                    my $qv = 'NOT_CHECKED';
                                    my $qv_cbox = $file_frame_top->Checkbutton(-text => 'SAT folder - Converts all SAT files to SVTC files', -variable => \$qv, -onvalue => 'CHECKED', -offvalue => 'NOT_CHECKED')->pack(-anchor => 'w',);
                                    $file_frame_top->Label(-text => 'Path')->pack(-side => "top")->pack(-side=>"left");
                                    $file_frame_top -> Entry("-width" => 50, "-textvariable" => \$file_browse)->pack (-side=>"left");
                                    $file_frame_top -> Button( "-text" => "Browse", "-borderwidth"=> 3,
                                                               "-command" => sub {
                                                                                    if($qv eq 'CHECKED')
                                                                                    {
                                                                                           $file_browse = '';
                                                                                           my $dir = $file_frame_top->chooseDirectory(-initialdir => '~', -title => 'Choose a folder');
                                                                                            $file_browse = $dir;
                                                                                    }
                                                                                    if($qv eq 'NOT_CHECKED')
                                                                                    {
                                                                                        $file_browse = '';
                                                                                        my $file_dialog = $file_frame_top->FileSelect(-directory => 'D:/');
                                                                                        $file_browse = $file_dialog->Show();
                                                                                    }
                                                                                 }
                                                            )->pack (-side=>'left',-padx=>'05');

                                    $but_frame_top -> Button("-text" => "Convert Curve","-borderwidth"=>3,
                                                             "-command" => sub{

                                                                                 if($qv eq 'CHECKED')
                                                                                 {
                                                                                    unless(defined $file_browse)
                                                                                    {
                                                                                       W2log("ERROR :: Choose SAT files located folder to convert SAT to SVTC \n");
                                                                                       $ss_conv_window->messageBox(
                                                                                                    '-icon'    => "error",#qw/error info question warning/
                                                                                                    '-type'    => "OK",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                                                                                                    '-title'   => 'SAT file folder',
                                                                                                    '-message' => "Choose SAT files located folder!!")->pack(-side => 'left');
                                                                                     }

                                                                                    opendir(DIR, $file_browse);
                                                                                    my @filenames = grep({/\.sat$/} readdir(DIR));

                                                                                    foreach my $filename(@filenames)
                                                                                    {
                                                                                        $filename = $file_browse."\\$filename";
                                                                                        SAT_to_SVTC($filename);
                                                                                    }
                                                                                    W2log("INFO :: SVTC Curve files Created at $curve_folder_path \n");
                                                                                    $ss_conv_window->messageBox(
                                                                                                    '-icon'    => "info",#qw/error info question warning/
                                                                                                    '-type'    => "OK",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                                                                                                    '-message' => "Converted SAT to SVTC files")->pack(-side => 'left');
                                                                                 }
                                                                                 else
                                                                                 {
                                                                                    unless(defined $file_browse)
                                                                                    {
                                                                                        W2log("ERROR :: SAT File path is not given to convert to SVTC \n");
                                                                                        $ss_conv_window->messageBox(
                                                                                                                '-icon'    => "error",#qw/error info question warning/
                                                                                                                '-type'    => "OK",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                                                                                                                '-title'   => 'SAT file',
                                                                                                                '-message' => "Enter SAT file path!!")->pack(-side => 'left');
                                                                                    }
                                                                                }
                                                                                SAT_to_SVTC($file_browse);
                                                                                W2log("INFO :: Converted '$file_browse' to  SVTC file \n");
                                                                                $ss_conv_window->messageBox(
                                                                                                    '-icon'    => "info",#qw/error info question warning/
                                                                                                    '-type'    => "OK",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                                                                                                    '-message' => "Converted '$file_browse' to  SVTC file")->pack(-side => 'left');
                                                                              }
                                                            ) ->pack(-side => "left");

                                    $but_frame_top -> Button(-text => "Exit","-borderwidth"=>3,-command => sub{ destroy $ss_conv_window;}) -> pack(-side => "right");
}) -> pack(-side => "left");

$frm -> Button(-text => "Exit","-borderwidth"=>3,-command => sub{ destroy $mainwindow;}) -> pack(-side => "left");

$noteframe -> Label(-text=>"Features::",-font=>"Verdana 10 bold italic") -> pack();
$noteframe -> Label(-text=>"1. Creation of LV124 Curves with stochastic \n 2. SAT to SVTC file Coversion",-font=>"Verdana 10") -> pack();

sub Create_table
{
    #create table frame to display --> @cnames    
    my $tableFrame = $curve_window->Frame(-borderwidth => 2, -relief => 'raised')->pack;

    my $stochastic = 'NOT_CHECKED';

    my @cnames = ('Parameters','Min Val','Max Val','Units');

    my (@stocrow, @rowname);

    foreach my $param(@$curve_param_names)
    {
        if($param =~ /:1$/)
        {
            push(@stocrow,$param);
        }
        my @split_row = split(/:[01]$/,$param);
        push(@rowname, $split_row[0]);
    }

    push(@rowname, 'Number of stochastic variants');
    my $rows = scalar (@rowname);
    my $cols = $#cnames; #column size of the table 

    # allocate a table to the frame
    my $table = $tableFrame->Table(-columns => $cols+1, -rows => $rows+2, -relief => 'raised')->pack( -expand => 'yes', -fill => 'both');

   # column headings
    foreach my $c (0..$cols)
    {
        my $tmp = $table->Label(-text => $cnames[$c], -relief => 'raised');
        $table->put( 0, $c, $tmp );
    }

    foreach my $r ( 1 .. $rows )
    {
        my $tmp;
            foreach my $c ( 0 .. $cols )
            {
                if($c == 0)
                {
                    $tmp = $table->Label(-width => 25,-text => $rowname[$r-1], -padx => 2, -background => 'white',-relief => 'groove');
                    $tmp->bind('text', [ $table ]);
                    $table->put( $r, $c, $tmp );
                }
                if($c == 1)
                {
                    $tmp = $table->Entry("-width" => 15,"-textvariable" => \$$default_curve_values[$r-1],-state => 'normal')->pack (-side=>"left");
                    $tmp->bind('text', [ $table ]);
                    $table->put( $r, $c, $tmp );
                }
                if($c == 2)
                {
                    $tmp = $table->Entry("-width" => 15,"-textvariable" => \$$stoc_values[$r-1],-state => 'disabled')->pack (-side=>"left");
                    $tmp->bind('text', [ $table ]);
                    $table->put( $r, $c, $tmp );
                }
                if($c == 3)
                {
                    $tmp = $table->Entry("-width" => 35,"-textvariable" => \$$curve_comments[$r-1],'-state' => 'disabled')->pack (-side=>"left");
                    $tmp->bind('text', [ $table ]);
                    $table->put( $r, $c, $tmp );
                }
                if($r == $rows && $c == 1)
                {
                    $tmp = $table->Entry("-width" => 15,"-textvariable" => \$stoc_variant,-state => 'disabled')->pack (-side=>"left");
                    $tmp->bind('text', [ $table ]);
                    $table->put( $r, $c, $tmp );
                }
            }
    }

    $stochastic_cbox = $tableFrame->Checkbutton(-text => 'Stochastic (Random)', -variable => \$stochastic, -onvalue => 'CHECKED', -offvalue => 'NOT_CHECKED',
                                                   -command => sub {
                                                        my $curvename_temp = $curve_name;
                                                        if($stochastic eq 'CHECKED')
                                                        {
                                                            W2log("INFO :: Stochastic feature for $curvename_temp is selected \n");
                                                            foreach my $r ( 1 .. $rows )
                                                            {
                                                                if(grep({/$rowname[$r-1]/} @stocrow))
                                                                {
                                                                    my $tmp = $table->Entry("-width" => 15,"-textvariable" => \$$stoc_values[$r-1],-state => 'normal')->pack (-side=>"left");
                                                                       $tmp->bind('text', [ $table ]);
                                                                       $table->put( $r, 2, $tmp );
                                                                }
                                                                if ($r == $rows)
                                                                {
                                                                    my $stoc_tmp = $table->Entry("-width" => 5,"-textvariable" => \$stoc_variant,-state => 'normal')->pack (-side=>"left");
                                                                       $stoc_tmp->bind('text', [ $table ]);
                                                                       $table->put($rows, 1, $stoc_tmp );
                                                                }
                                                            }
                                                            $curve_name_user = $curve_name_user.'_stochastic';
                                                        }
                                                        if($stochastic eq 'NOT_CHECKED')
                                                        {
                                                            foreach my $r ( 1 .. $rows )
                                                            {
                                                                if(grep({/$rowname[$r-1]/} @stocrow))
                                                                {
                                                                    my $tmp = $table->Entry("-width" => 15,"-textvariable" => '',-state => 'disabled')->pack (-side=>"left");
                                                                       $tmp->bind('text', [ $table ]);
                                                                       $table->put( $r, 2, $tmp );
                                                                }
                                                                if ($r == $rows)
                                                                {
                                                                  my $stoc_tmp = $table->Entry("-width" => 5,"-textvariable" => \$stoc_variant,-state => 'disabled')->pack (-side=>"left");
                                                                     $stoc_tmp->bind('text', [ $table ]);
                                                                     $table->put( $rows, 1, $stoc_tmp );
                                                                }
                                                            }

                                                             my $stoc_tmp = $table->Entry("-width" => 5,"-textvariable" => \$stoc_variant ,-state => 'disabled')->pack (-side=>"left");
                                                                $stoc_tmp->bind('text', [ $table ]);
                                                                $table->put($rows, 1, $stoc_tmp );

                                                            $curve_name_user = $curvename_temp;
                                                        }
                                                    }
    )->pack(-anchor => 'w');

    my $create_frame = $curve_window -> Frame->pack();
    $create_frame -> Button(-text => "Create Curve","-borderwidth"=>3,
                       -command => sub{
                                        my $length = scalar(@$curve_param_names);
                                        my $Curve_params_input_argument = {};
                                        $Curve_params_input_argument->{'Curve_name'} = $curve_name;
                                        for(my $i = 0; $i < ($length); $i ++)
                                        {
                                            my $temp = $$curve_param_names[$i];
                                            $temp =~s/\:[01]//;
                                            $Curve_params_input_argument->{$temp} = $$default_curve_values[$i];	
                                        }
                                        my $func = \&$curve_name;#address reference of the function
                                        my $status = $func->($Curve_params_input_argument, $u_min , $u_max, $curve_folder_path);#call the function 

                                        if ($status eq '0')
                                        {
                                            W2log("ERROR :: $curve_name not created \n");
                                            $mainwindow->messageBox(
                                                                      '-icon'    => "error",#qw/error info question warning/
                                                                      '-type'    => "OK",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                                                                      '-title'   => 'Curve creation',
                                                                      '-message' => "$curve_name not created"
                                                                    );
                                             $stoc_variant = 1;
                                        }
                                        else
                                        {
                                           if($stochastic eq 'NOT_CHECKED')
                                           {
                                                W2log("INFO :: $curve_name created successfully\n");
                                                $mainwindow->messageBox(
                                                                      '-icon'    => "info",#qw/error info question warning/
                                                                      '-type'    => "OK",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                                                                      '-title'   => 'Curve creation',
                                                                      '-message' => "$curve_name created successfully"
                                                                    );

                                                my $type_button = $mainwindow->messageBox(
                                                        '-icon'    => "question",#qw/error info question warning/
                                                        '-type'    => "YesNo",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                                                        '-title'   => 'Stochastic nature',
                                                        '-message' => "Do you want to generate stochastic curves for $curve_name?"
                                                        );
                                                if($type_button eq 'Yes')
                                                {
                                                    $stoc_variant = 1;
                                                }
                                                else
                                                {
                                                    $stoc_variant = 1;
                                                    destroy $curve_window;
                                                }
                                          }
                                          else
                                          {
                                            W2log("INFO :: $curve_name created successfully\n");
                                                $mainwindow->messageBox(
                                                                      '-icon'    => "info",#qw/error info question warning/
                                                                      '-type'    => "OK",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                                                                      '-title'   => 'Curve creation',
                                                                      '-message' => "stochastic curves for $curve_name created successfully"
                                                                    );

                                                my $type_button = $mainwindow->messageBox(
                                                        '-icon'    => "question",#qw/error info question warning/
                                                        '-type'    => "YesNo",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                                                        '-title'   => 'Curve creation',
                                                        '-message' => "DO you want to generate non-stochastic curve for $curve_name?"
                                                        );
                                                if($type_button eq 'Yes')
                                                {
                                                    $stoc_variant = 1;
                                                }
                                                else
                                                {
                                                    $stoc_variant = 1;
                                                    destroy $curve_window;
                                                }
                                            }
                                        }
                                       }) -> pack(-side => "left");

    $create_frame -> Button(-text => "Exit","-borderwidth"=>3,-command => sub{ W2log("INFO :: Closed $curve_name Window\n"); destroy $curve_window;}) -> pack(-side => "right");
return 1;
}

MainLoop;

=head2 SAT_to_SVTC

    Reads the SAT file and converts into SVTC file.

=cut

sub SAT_to_SVTC
{
        my $file_browse = shift;

       #Start Conversion of SAT to SVTC
         my $filename = basename( $file_browse,  ".sat");

        my ($samples_curve,$iteration_curve,$arbitrary_time,$arbitrary_voltage,$current_curve) = SAT_parser($file_browse);
        my $time_curve= Resample_Voltage ($arbitrary_voltage, $arbitrary_time);
         $time_curve = sprintf("%.6f", $time_curve);
         my $counter = 0; my $index = 0;
        # save the contents from .sat file to .svtc

        my $sVTTCurve_svtc_file_path = $curve_folder_path;
        $sVTTCurve_svtc_file_path .="\\$filename\.svtc";

        open my $SATFH,'<',"$file_browse" || die 'Failed to read file ' . $file_browse;
        open my $SVTCFH,'>',"$sVTTCurve_svtc_file_path" || die 'Failed to read file ' . $sVTTCurve_svtc_file_path;
        while(my $line = <$SATFH>)
        {
            chomp($line);
            if($line !~/^\s*$/x) # checking for an empty line
            {
                #Matching 'Dateiname :'
                if($line =~ /^Dateiname\s*:\s*/i)    # change to Curve Name & use the filename from filepath 
                {
                    my ($name) = fileparse $file_browse;
                    ($name) = substr($name,0,index($name,'.'));
                    $line = "Curve Name : $name";
                }
                #Matching 'Punkte :'
                elsif($line =~ /^Punkte\s*:\s*/ix)    # change to Samples & append length of voltage array
                {
                    $line = "Samples : " . scalar(@$arbitrary_voltage) ;# append length of voltage array
                }
                #Matching 'Wiederholungen :'
                elsif($line =~ s/Wiederholungen/Iteration/ix)# change to iteration
                {
                    $line = $line . "\n" . "Time[s] : " . $time_curve;
                }
                #Matching 'Strombegrenzung :'
                elsif($line =~ /^Strombegrenzung/ix)# ignore current value for nidaq
                {
                    next;    # ignore this line
                }
                #Matching 'U[V]'
                elsif($line =~ /^(U\[V\])/ix)
                {
                    $line = $1;        # use only U[V]
                }
                else
                {
                    #Matching other than 'U[V]'
                    unless(($line=~ /U\[V\]\s+t\[s\]/x) )
                    {
                        my $time = $time_curve*(10**6);
                        my $loop =  $$arbitrary_time[$index] / $time;
                        while($loop)
                        {
                            print $SVTCFH $$arbitrary_voltage[$counter++] . "\n";    # copy contents from voltage value to svtc file
                            $loop--;
                        }
                        $index++;
                    }
                    next; # skip printing the line & move to the next content
                }
            }
            print $SVTCFH $line . "\n";    # copy contents from sat file to svtc file
        }
        close($SATFH);
        close($SVTCFH);
         #End Conversion of SAT to SVTC

    return;
}

=head2 Help

    Provides the information on usage of SVTT Utility Tool.

=cut

sub Help
{
    my @help_info = ( "Steps to be followed in creation of LV124 Curves",
                      "------------------------------------------------",
                      "1. Double click of sVTT_Utility_GUI.pl file pops-up a GUI window.",
                      "    a. Log file creates with a name 'SVTT_Utility_GUI_LOG.txt'",
                      "2. Browse the folder path where curves to be generated (Ex:: D:/Sandbox/Tools/SVTT_Curves).",
                      "3. Provide max and min voltage values in respective text boxes.",
                      "4. Select the curve from drop down list and click on enter.",
                      "5. After click of enter, pops-up the window for selected curve",
                      "6. After creation of curve(s), close the window with 'Exit' button.",
                      "",
                      "Below are the actions to be done in popped-up curve window",
                      "-----------------------------------------------------------",
                      "i. Enter the curve name at allocated text box",
                      "ii. Enter the curve generation related parameter values in the table",
                      "iii. For Stochastic nature, check the respective box and enter required parameters in provided fields.",
                      "iv. By click on 'Create Curve' button, generates the curve.",
                      "v. Close the window with 'Exit' button.",
                      "","",
                      "Steps to be followed in conversion of SAT to SVTC",
                      "-------------------------------------------------",
                      "1. Double click of sVTT_Utility_GUI.pl file pops-up a GUI window.",
                      "2. Browse the folder path where curves to be generated (Ex:: D:/Sandbox/Tools/SVTT_Curves)",
                      "3. Click on 'Convertor' button, pop-ups a window.",
                      "",
                      "Below are the actions to be done in popped-up curve window",
                      "-----------------------------------------------------------",
                      "i. Multiple SAT files converts to SVTC files by clicking check box 'SAT folder'",
                      "ii. Browse the file/folder path by click on 'Browse' button",
                      "iii. Click on 'Convert Curve' button, converted curve file(s) is/are available in the path selected in point 2",
                      "iv. Close the window with 'Exit' button.",
    );

    my $help_window = $mainwindow -> Toplevel();
    $help_window->geometry("700x550");
    $help_window->resizable(0,0);
    $help_window -> Label(-text=>"Usage of SVTT Utility Tool",-font=>"Verdana 12 bold italic underline") -> pack(-padx=>8,-pady=>8);
    my $help_frame = $help_window -> Frame()->pack(-padx=>8,-pady=>8); #Frame contains the curve name in top window 
    my  $tx= $help_frame->Scrolled("ROText", -height => 260, -width => 150, -scrollbars => 'se',)->pack();
    $tx->insert("insert", "$_\n") foreach(@help_info);

    return;
}

=head2 SAT_parser 

    Subroutine Name  :: SAT_parser
    Description      :: Reads sat file and returns the content of file.
    Syntax           :: SAT_parser (sat_file_path);
    Input Arguments  :: Mandatory
                              sat_file_path - Absolute path of SAT file
                              sat_curvename - Curve name which sat file to be parsed(Only for documentation purpose)
    Return Value(s)  :: OnFailure - ['-1000', '-1000', '-1000', '-1000','-1000'] 
                        OnSuccess - sat_samples - Samples available in sat file
                                    sat_current - Current value in sat file
                                    sat_iteration - Iteration value available in sat file
                                    \@sat_arbitrary_voltage - Array reference of voltage values
                                    \@sat_arbitrary_time - Array reference of time values
    Example          :: (10, 1, 1, [10.00], [3.00]) = SAT_parser ('D:\Sandbox\TurboLIFT\Projects\VW_PQ26\config\Tools\sVTT_Curves\NiDaq_Testing2.sat');

=cut

sub SAT_parser
{
    my $sat_file_path = shift;

    my($sat_name, $sat_samples, $sat_iteration, $sat_current);
    my (@sat_arbitrary_voltage, @sat_arbitrary_time) = ();
    my $counter=0;

    open my $SATFH,'<',"$sat_file_path" || die 'Failed to read file ' . $sat_file_path;

    while(my $line = <$SATFH>)
        {
            chomp($line);
            if($line !~/^\s*$/x) # checking for an empty line
            {
                if($line =~ /^Dateiname\s*:\s+(.+)/x)
                {
                    $sat_name = $1;
                }
                elsif($line =~ /^Punkte\s*:\s+(.+)/x)
                {
                    $sat_samples = $1;
                }
                elsif($line =~ /^Strombegrenzung\s*:\s+(.+)/x)
                {
                    $sat_current = $1;
                }
                elsif($line =~ /^Wiederholungen\s*:\s+(.+)/x)
                {
                    $sat_iteration = $1;
                }
                else
                {
                    unless(($line=~ /U\[V\]\s+t\[s\]/x) || ($counter == $sat_samples))
                    {
                            my @arbit_vals = split(/\s+/,$line);
                            push(@sat_arbitrary_voltage,$arbit_vals[0]);
                            push(@sat_arbitrary_time,$arbit_vals[1]);
                            $counter++;
                    }
                }
            }
        }

        close($SATFH);

        if($counter < $sat_samples)
        {
            W2log("INFO :: arbitrary values are less than punkte($sat_samples) in sat file, considered count of arbitrary values:: $counter \n");
            $sat_samples = $counter;
        }

        unless(defined $sat_name)
        {
          W2log("ERROR :: SAT file format is not correct \n");
          return ($SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED);
        }

        unless(defined $sat_samples)
        {
           W2log("ERROR :: SAT file format is not correct \n");
           return ($SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED);
        }

        unless(defined $sat_iteration)
        {
           W2log("ERROR :: SAT file format is not correct \n");
           return ($SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED);
        }

        my $temp = scalar(@sat_arbitrary_time);
        if( $temp == 0)
        {
           W2log("ERROR :: SAT file format is not correct \n");
           return ($SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED);
        }

        $temp = scalar(@sat_arbitrary_voltage);
        if($temp == 0)
        {
           W2log("ERROR :: SAT file format is not correct \n");
           return ($SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED,$SVTT_FAILED);
        }

        return($sat_samples,$sat_iteration,\@sat_arbitrary_time,\@sat_arbitrary_voltage,$sat_current);
}

=head2 Resample_Voltage

    Subroutine Name  :: Resample_Voltage
    Description      :: This function finds the hcf of time value & modifies the voltage samples based on hcf of time.
    Syntax           :: $time_hcf = Resample_Voltage($ecu_voltage_aref, $time_aref);
    Input Arguments  :: Mandatory - $ecu_voltage_aref : reference to array of voltage values
                        Mandatory - $time_aref : reference to array of time values
    Return Value(s)  :: hcf of time value
    Example          :: $time_hcf = &Resample_Voltage($ecu_voltage_aref, $time_aref);

=cut

sub Resample_Voltage
{
    my $ecu_voltage_aref = shift;
    my $time_aref = shift;

    my $time_hcf=undef;
    my @voltage_value = ();

    # get the hcf of time value from time array
    foreach my $data (@$time_aref) { $data = $data * $SCALAR_FACTOR; }
    $time_hcf = bgcd(@$time_aref);
    $time_hcf = $time_hcf->numify();

    # propogate the voltage array based on hcf of time value
    my $index = 0;
    foreach my $time(@$time_aref)
    {
        my $loop = $time / $time_hcf;
        while($loop)
        {
            push (@voltage_value, $$ecu_voltage_aref[$index]);
            $loop--;
        }
        $index++;
    }
    foreach(0..scalar(@$ecu_voltage_aref)) {pop(@$ecu_voltage_aref);}  # remove existing contents of voltage array

    push(@$ecu_voltage_aref, @voltage_value); # update new contents to voltage array

    return($time_hcf/$SCALAR_FACTOR);
}

sub W2log{
     my $text = shift;
     my $timestamp = localtime(time);

     print "$timestamp $text";
     print LOG "$timestamp $text";

     return;
}

1;
__END__

=head1 AUTHORS

 Archana Gopalakrishna, E<lt> Archana.Gopalakrishna@in.bosch.com E<gt>

=head1 NOTES

=head1 User Manual

=head1 SEE ALSO

=cut