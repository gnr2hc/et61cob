#### TEST CASE MODULE
package TC_sVTT_Executecurve;
#-> package name has to match file name ! case sensitive !

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
###-------------------------------
our $VERSION = q$Revision: 1.5 $;
our $HEADER = q$Header: sVTT/TC_sVTT_Executecurve.pm 1.5 2015/06/19 19:57:52ICT Archana Gopalakrishna (RBEI/ECF1) (GOA2BMH) develop  $;
##################################

use File::Basename;
#### INCLUDE ENGINE MODULES ####
use LIFT_general;   # this is always required
use LIFT_sVTT;
use LIFT_PD;
use LIFT_DSO1;
use LIFT_sVTT_Curves;
##################################

our $PURPOSE = "sVTT Testing";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

#-> update documentation that somebody else can use the test without asking you
#-> delete parameter section if no parameters are used
#-> note that POD documentation needs entirely empty lines before and after keywords (e.g. =head1, =cut ...) 

=head1 TESTCASE MODULE

TC_template  $Revision: 1.5 $

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:
    
    <list used parameters>

link to TS_CP: 

    [initialisation]     
	<list test steps>
	
    [stimulation & measurement]
    1. Preform pre-diagnosis action(optional)
    2. Reset of svtt execution (optional)
    3. Execution of Curve
    3. Reset of svtt execution (optional)
    4. Preform post-diagnosis action(optional)
    5. Reset of svtt execution (optional)

    [evaluation]
    1. evaluate of labels
    2. evaluate FltMem before crash
    3. evaluate FltMem after crash
 
    [finalisation]
    <list test steps>

=head1 PARAMETER

=head2 PARAMETER NAMES

    Curve_name
    ECU_labels
    FLT_mand
	FLT_opt
	Check_Labels

=head2 PARAMETER EXAMPLES

    [TC_sVTT_StandardTest.Audi_LV124_E02]
    Curve_name = 'AUDI_lv124_e_02_transient_over_voltage_endurance'
    ECU_labels = @('label1','label2')
    FLT_mand = @('fault1','fault2')
	FLT_opt = @('opt_fault1' , 'opt_fault2')
	Check_Labels = @ ('label1|operator1|expectedvalue1,'label2|operator2|expectedvalue2')

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#-> define variables here which all be used across subroutines
#-> test case parameters shall start with tcpar_
#my ($tcpar_Vmin, $tcpar_U1, $tcpar_Vmax, $tcpar_tr, $tcpar_tf, $tcpar_t1, $tcpar_t2, $tcpar_t3, $tcpar_number_of_cycles);
my ($tcpar_purpose, $tcpar_Curve_file, $tcpar_ECU_labels, $tcpar_FLT_mand, $tcpar_FLT_opt, $tcpar_ChkLabel,$tcpar_curve_params,$tcpar_online_curve_snapshot);
my $curve_file;
my ($curve_filename,$DSO_initialised );
my $DSO_settings;
my ($dso, $error, $string, $value, $DeviceID, $status);

sub TC_set_parameters
{
    $tcpar_purpose = S_read_testcase_parameter( 'purpose' );#scalar   
    unless( defined $tcpar_purpose )
    {
    	S_w2rep(" -->  Missing optional parameter purpose \n");
    } 
    
    $tcpar_Curve_file = S_read_testcase_parameter( 'curve_file' );#scalar   
    unless( defined $tcpar_Curve_file )
    {
    	S_w2rep(" -->  Missing optional parameter curve_file \n");
    } 
       
    $tcpar_curve_params = S_read_testcase_parameter( 'curve_params', 'byref' ); #hash entry
    unless( defined $tcpar_curve_params )
    {
    	S_w2rep(" -->  Missing optional parameter curve_params \n");
    }

    $tcpar_ECU_labels = S_read_testcase_parameter( 'ECU_labels', 'byref' ); #array
    unless( defined $tcpar_ECU_labels )
    {
    	S_w2rep(" -->  Missing optional parameter ECU_labels \n");
    }
    
    $tcpar_FLT_mand = S_read_testcase_parameter( 'FLT_mand','byref' ); #array
    unless( defined $tcpar_FLT_mand )
    {
        S_w2rep(" -->  Missing optional parameter FLT_mand \n");
    }    
   
    $tcpar_FLT_opt = S_read_testcase_parameter( 'FLT_opt','byref' ); #array
    unless( defined $tcpar_FLT_opt )
    {
        S_w2rep(" -->  Missing optional parameter FLT_opt\n");
    }    

    $tcpar_ChkLabel = S_read_testcase_parameter( 'Check_Labels','byref' ); #array
    unless( defined $tcpar_ChkLabel )
    {
        S_w2rep(" -->  Missing optional parameter Check_Labels\n");
    } 

    $tcpar_online_curve_snapshot = S_read_testcase_parameter( 'online_curve_snapshot','byref' ); #array
    unless( defined $tcpar_online_curve_snapshot )
    {
        S_w2rep(" -->  Missing optional parameter online_curve_snapshot\n");
    } 

	return 1;
}


#### INITIALIZE TC #####
sub TC_initialization 
{
     if ((defined $tcpar_Curve_file) && (defined $tcpar_curve_params))
     {
     	 S_w2rep(" -->  Both curve_file and curve_params are defined. Testcase doesnot know what to do.\n");
     	 return 0;
     }

     if ((!defined $tcpar_Curve_file) && (!defined $tcpar_curve_params))
     {
     	 S_w2rep(" -->  Either parameter curve_file or curve_params to be defined.\n");
     	 return 0;
     }
          
	 $curve_file = $tcpar_Curve_file if (defined $tcpar_Curve_file) ;
	 
	 if (defined $tcpar_curve_params) 
     {
	     my $curve_name = $tcpar_curve_params->{'CURVE_NAME'};
	     my $func = \&$curve_name;
	     
	     ($curve_file, $DSO_settings) = $func ->($tcpar_curve_params);	
     }
       	       
	 return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement
{
	if ($tcpar_online_curve_snapshot eq "yes")
	{
	    DSO1_connect();
		DSO1_setVdiv('C1',$DSO_settings->{"Volt"});
		DSO1_setTdiv($DSO_settings->{"Time"});
		$DSO_initialised = 1;
	}	
    ##### Clear fault memory after CANoe was started by IC, in order to make ECU fault free before curve
	SVTT_ClearFaultMemory('AO0');
	S_wait_ms( 5 * 1000 );
	##### After Clear fault memory, reset ECU, in order to see any power on faults (during init phase)
	SVTT_Reset();
	
	S_wait_ms( 5 * 1000 );
    #####pre diagnosis
	$curve_filename = basename $curve_file;
	SVTT_PerformDiagnosis($curve_filename, 'AO0','pre', $tcpar_ECU_labels, $tcpar_ChkLabel);
	SVTT_Reset();
    S_wait_ms( 5 * 1000 );
	
	#####Execute curve
	SVTT_ExecuteCurve($curve_filename);

	#####Post diagnosis
	SVTT_Reset();
	S_wait_ms( 5 * 1000 );
    SVTT_PerformDiagnosis($curve_filename, 'AO0','post', $tcpar_ECU_labels, $tcpar_ChkLabel);
	SVTT_Reset();
	S_wait_ms( 5 * 1000 );

	if ($DSO_initialised == 1)
	{		
		my $snapshot_filename = $curve_filename;
		$snapshot_filename =~ s/.svtc$//i;
		my $snapshot_filepath = dirname $curve_file;

		$snapshot_filepath = File::Spec->rel2abs(dirname($snapshot_filepath));
		$snapshot_filepath = $snapshot_filepath."\\sVTT_Curves\\".$snapshot_filename;
		DSO1_saveScreen($snapshot_filepath);
		S_add_pic2html ( "./sVTT_Curves/$snapshot_filename.png",'width=600');
		DSO1_disconnect( );
    }
	
	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation 
{
	SVTT_Evaluation($curve_filename, $tcpar_FLT_mand, $tcpar_FLT_opt);

	return 1;
}


#### TC FINALIZATION #####
sub TC_finalization 
{    
	return 1;
}

1;