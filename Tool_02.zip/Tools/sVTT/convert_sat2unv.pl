# Small tool to convert sat files to unv format, so the files can be viewed with uniview.
# Chose a folder -> All .sat files in the folder will be converted into .txt.unv files
#
use strict;
use File::Find;
use Tk;

my $mw = tkinit();
my $folderName = $mw->chooseDirectory(-title => 'Choose a folder with sat files');


find(\&convertFile, ($folderName) );

print "READY.\n";


sub convertFile{
	my ($headerLine);

	my $fileName = $File::Find::name;

	return unless( $fileName =~ /\.sat$/i );

	print "Converting $fileName ...\n";
	
	my $outName = $fileName;
	$outName =~ s/\.\w+$/.txt.unv/;
	
	open( IN, '<', $fileName) or die "cannot open input file $fileName : $!";
	my @lines = <IN>;
	close IN;
	
	$headerLine = shift @lines; # Dateiname
	$headerLine = shift @lines; # Punkte
	$headerLine = shift @lines; # Strombegrenzung
	$headerLine = shift @lines; # Wiederholungen
	$headerLine = shift @lines; # <empty>
	$headerLine = shift @lines; # signals[unit]
	my $signal = 'none';
	my $unit = 'none';
	if( $headerLine =~ /^(\w+)\[(\w+)\]\s+(\w+)\[(\w+)\]/ ){
		$signal = $1;
		$unit = $2;
	}
	
	my $outputString = "TIME;$signal\n";
	$outputString .= "s;$unit\n";
	
	my $value;
	my $time = 0;
	foreach my $line (@lines){
		if( $line =~ /^(\S+)\s+(\S+)\s*$/ ){
			$value = $1;
			$outputString .= "$time;$value\n";
			$time += $2;
		}
	}

	$outputString .= "$time;$value\n";

	open( OUT, ">$outName"  ) or die $!;
	print OUT $outputString;
	close OUT;

}

