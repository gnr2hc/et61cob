package LIFT_config;

### Project Specific Config for LIFT_exec_engine

use Sys::Hostname;
use File::Basename;
our (@mailto, $left_logo, $right_logo, $LIFT_ProjectDescription,$LIFT_host, $LIFT_exec_path, $LIFT_PRJCFG_path, $SAD_file, $LIFT_TC_path, $LIFT_TC_DOCS_path, $LIFT_PARA_path);
#@mailto=('Frank.Boehm@de.bosch.com');

# relative path related to campaign report ($LIFT_LOG_path), better for moving reports
$left_logo='.\logos\logo_left.png';
$right_logo='.\logos\logo_right.png';
$LIFT_ProjectDescription = "VW PQ26 project";

### LIFT host
$LIFT_host = hostname();

### LIFT exec path = path from called LIFT_exec_engine
$LIFT_exec_path = dirname( $0 );
### Project Configuration PATH = from called Project Configuration
$LIFT_PRJCFG_path = dirname( $main::opt_conf );

### TESTCASES settings, change path if you use different folder.
$LIFT_TC_path   = "$LIFT_PRJCFG_path/../TCs/";
### TESTCASE DOCUMENTATION
$LIFT_TC_DOCS_path = "$LIFT_TC_path/Documentation/html/";
### TESTCASE PARAMETERS
$LIFT_PARA_path              = "$LIFT_PRJCFG_path/../TC_par";

our ($LIFT_LOG_path,$LIFT_RES_path,$LIFT_TC_INIT_path,$LIFT_TC_INIT_CAMPAIGN,$LIFT_TC_END_path,$LIFT_TC_END_CAMPAIGN,$LIFT_ProjectDefaults,$LIFT_Testbench,$LIFT_Simulator);

### LOGS and RESULTS PATH
$LIFT_LOG_path = "$LIFT_PRJCFG_path/../reports/";
$LIFT_RES_path = "$LIFT_PRJCFG_path/../reports/";

### INIT CAMPAIGN
$LIFT_TC_INIT_path = "$LIFT_PRJCFG_path";
$LIFT_TC_INIT_CAMPAIGN = "IC_sVTT.sVTT";            # Init campaign to be executed

### END CAMPAIGN
$LIFT_TC_END_path = "$LIFT_PRJCFG_path";
$LIFT_TC_END_CAMPAIGN = "EC_sVTT";            # End campaign to be executed


### PROJECT Defaults
require "$LIFT_PRJCFG_path/sVTT_ProjectConst.pm";        # contains package LIFT_PROJECT
$LIFT_ProjectDefaults = $LIFT_PROJECT::Defaults;

### Testbench configuration
if ( -f 'D:\Sandbox\TurboLIFT\Projects\VW_PQ26\config\LIFT_Testbenches.pm' ) {
    require 'D:\Sandbox\TurboLIFT\Projects\VW_PQ26\config\LIFT_Testbenches.pm';
    #$LIFT_Testbench = $LIFT_Testbenches::Testbench->{$LIFT_host}; # to use if run on several testbenches
    $LIFT_Testbench = $LIFT_Testbenches::Testbench->{'BMH1007302'}; # to use if runs on single testbench
}
unless( $LIFT_Simulator = $LIFT_Testbench->{'Devices'}{'LabCar'}{'Serial_Number'} ) {
    $LIFT_Simulator = 'None_LIFT_LC';
}

#just to remove the warnings
$LIFT_PROJECT::Defaults=$LIFT_PROJECT::Defaults;
$LIFT_Testbenches::Testbench=$LIFT_Testbenches::Testbench;
$main::opt_conf=$main::opt_conf;

### SAD mapping - mandatory required!!
require "$LIFT_PRJCFG_path/Mapping_SAD.pm";
$LIFT_SADMapping = $LIFT_PROJECT::Defaults->{'Mapping_SAD'};

### replace path with SAD file for ECU SW
$SAD_file = 'D:\Sandbox\TurboLIFT\Projects\VW_PQ26\config\SW\Results\vw1003_BB65887_c02_Cat3_20130729.sad';

### sVTT Curve Library Path
our $sVTTCurve_file_path = 'D:\Sandbox\TurboLIFT\Projects\VW_PQ26\config\Tools\sVTT_Curves';

1;