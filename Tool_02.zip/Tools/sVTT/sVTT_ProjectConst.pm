package LIFT_PROJECT;


#$VERSION = q$Revision: 1.6 $;
#$HEADER = q$Header: sVTT/sVTT_ProjectConst.pm 1.6 2015/02/20 14:36:27ICT Archana Gopalakrishna (RBEI/ECF1) (GOA2BMH) develop  $;

our $Defaults;
$Defaults = {
'VTT' => {
        #Hardware Devices Required to perform an action 
            'Devices' => ['power', 'temperature', 'diagnosis'],
        #This section is used for controlling the diagnosis action before and after execution of each curve
            'Sequence_Control' => {
                                    'U_Diag' => 10,  # in volt; negative numbers mean: voltage of last Point of previous curve used for Diag
                                    't_Diag'  => 10,  # in seconds (new parameter which indicates time after curve start when can the diagnosis be performed during curve)
                                    'Diag_wait' => 2,  # in seconds, time to wait after curve output (U=U_diag) before trying diagnosis
                                   'Reset_time' => 5,  # in seconds
                                  },
            'Curve_Controls' => {
                                    'U_min' => 0,  # in volt , lower voltage limit
                                    'U_max' => 30,  # in volt , upper voltage limit 
                                },
        },

'VEHICLE'           => {
                        'NormalVoltage'                   => 13.8, 
                        'KL15_Zyklus_voltage'              => 9.05,                       
                        'LowVoltage'              => 5.5,  
                        'HighVoltage'               => 19.75, 
                        'ProgVarTable_CRCsection'          => 1,
                       },

                      
########################################################################################################################
# here you define the MLC configuration
# section => {device name => label}
########################################################################################################################
'MLC' => {
          'CAN' => {
            'CAN1_Name' => 'Highspeed_CAN_1',
            'CAN2_Name' => 'Highspeed_CAN_2',
          },
          
          'FREELY_USABLE_SWITCHES'  => {
            'FS1_Name' => 'SSSL_1a',
            'FS2_Name' => 'SSSL_1b',
            'FS3_Name' => 'SSSL_1c',
            'FS4_Name' => 'SSSL_2a',
            'FS5_Name' => 'SSSL_2b',
            'FS6_Name' => 'SSSL_2c',
            
            'SSSL_1a_STATE_CA' => '290_Ohm',
            'SSSL_1a_STATE_CB' => '680_Ohm',
            'SSSL_1a_STATE_NC' => 'OFF',
            'SSSL_1b_STATE_CA' => '1400_Ohm',
            'SSSL_1b_STATE_CB' => '3980_Ohm',
            'SSSL_1b_STATE_NC' => 'OFF',
            'SSSL_1c_STATE_CA' => '6200_Ohm',
            'SSSL_1c_STATE_CB' => 'NA',
            'SSSL_1c_STATE_NC' => 'OFF',

            'SSSL_2a_STATE_CA' => '140_Ohm',
            'SSSL_2a_STATE_CB' => '240_Ohm',
            'SSSL_2a_STATE_NC' => 'OFF',
            'SSSL_2b_STATE_CA' => '420_Ohm',
            'SSSL_2b_STATE_CB' => '1440_Ohm',
            'SSSL_2b_STATE_NC' => 'OFF',
            'SSSL_2c_STATE_CA' => '2500_Ohm',
            'SSSL_2c_STATE_CB' => 'NA',
            'SSSL_2c_STATE_NC' => 'OFF',
          },
          
          'General' => {
            'MaxVoltage' => '20',
          },
          'PAS' => {
            'PAS1_Name' => 'PAS1',
            'PAS2_Name' => 'PAS2',
            'PAS3_Name' => 'PAS3',
            'PAS4_Name' => 'PAS4',
            'PAS5_Name' => 'PAS5',
            'PAS6_Name' => 'PAS6',
          },
          'POWER_SUPPLY_LINES' => {
            'PSL1_Name' => 'CLAMP_15',
          },
          'SQUIBS' => {
            'SQ1_Name' => 'AB1FD',
            'SQ2_Name' => 'AB1FP',
            'SQ3_Name' => 'HA1FP',
            'SQ4_Name' => 'HA1FD',
            'SQ5_Name' => 'SA1FD',
            'SQ6_Name' => 'SA1FP',
            'SQ7_Name' => 'BT1FD',
            'SQ8_Name' => 'BT1FP',
            'SQ9_Name' => 'BATDHV',
            'SQ10_Name' => 'BATD12V',
          },
          'SWITCHES' => {
            'SW8_Name' => 'BL2RP',
                       
            'SW4_Name' => 'BLFD',
            'SW4_Name' => 'BLFDVW',
            'SW5_Name' => 'BLFP',
            'SW5_Name' => 'BLFPVW',
            'SW7_Name' => 'HWPATH',
            'SW6_Name' => 'SSSL1',
          # 'SW8_Name' => 'SBR',
            'SW9_Name' => 'BL2RD',
            'SW10_Name' => 'BL2RC',
            'BLFD_CLOSED' => 'UNBUCKLED',
            'BLFD_OPEN' => 'BUCKLED',
            'BLFP_CLOSED' => 'UNBUCKLED',
            'BLFP_OPEN' => 'BUCKLED',
            'BL2RC_CLOSED' => 'BUCKLED',
            'BL2RC_OPEN' => 'UNBUCKLED',
            'BL2RD_CLOSED' => 'BUCKLED',
            'BL2RD_OPEN' => 'UNBUCKLED',
            'BL2RP_CLOSED' => 'BUCKLED',
            'BL2RP_OPEN' => 'UNBUCKLED',
            'SBR_CLOSED' => 'UNOCCUPIED',
            'SBR_OPEN' => 'OCCUPIED',
            'HWPATH_OPEN' => 'DEACTIVATED',
			'HWPATH_CLOSED' => 'ACTIVATED',
			'SSSL1_OPEN' => 'ACTIVATED',
			'SSSL1_CLOSED' => 'DEACTIVATED',
#           'SSSL_CLOSED' => 'DEACTIVATED',
#           'SSSL_OPEN' => 'ACTIVATED',
            
          }, 
          'WARNING_LAMPS' => {
            'WL5_Name' =>'BAOffA',
            'WL3_Name' =>'Crash Output',
            'WL4_Name' =>'BAOnA'
          },
},


'CRC_AREA' => {
                'PROG_VAR_TBL'  => '1',
                'ASIC_CONF_TBL' => '4',
},

########################################################################################################################
# here you can define global optional faults for every test, for example if you have always variant coding info in EEPROM
# 'TEMP_OPTIONAL_FAULTS' -> fault is ignored completely
# 'TEMP_DISTRUB_FAULTS' -> fault is ignored if only disturb bit is set
# 'TEMP_DISTRUB_FAULTS' => [ 'ALL' ] will ignore all faults where only disturb bit is set
#e.g. 'TEMP_OPTIONAL_FAULTS' => [ 'FltVdsPitchRateSensorMonitoring' , 'FltVdsYawRateSensorMonitoring' ], 
########################################################################################################################
'TEMP_OPTIONAL_FAULTS' => ['FltConfiguration','FltBAOnAConfiguration','FltBAOffAConfiguration'],

#'TEMP_DISTRUB_FAULTS' => [ 
#    'FltSwitchPSPOSShortLine','FltSwitchPADSShortLine','FltSwitchDSPOSShortLine','FltSwitchBL2RRShortLine',
#    'FltSwitchBL2RMShortLine','FltSwitchBL2RLShortLine','FltSwitchBLFRShortLine','FltSwitchBLFLShortLine',
#    'FltSwitchIsofix1ShortLine','FltSwitchIsofix2ShortLine','FltSwitchBLMLShortLine','FltSwitchBLMRShortLine',
#    'FltSwitchPSPOSShort2Bat','FltSwitchPADSShort2Bat','FltSwitchDSPOSShort2Bat','FltSwitchBL2RRShort2Bat',
#    'FltSwitchBL2RMShort2Bat','FltSwitchBL2RLShort2Bat','FltSwitchBLFRShort2Bat','FltSwitchBLFLShort2Bat',
#    'FltSwitchIsofix1Short2Bat','FltSwitchIsofix2Short2Bat','FltSwitchBLMLShort2Bat','FltSwitchBLMRShort2Bat',
# ],

#'TEMP_DISTRUB_FAULTS' => [ 'ALL' ], 


'EVALUATION_FILE'  =>
                    {
                   'USED'          => 1,
                   'DELIMITER'     => chr(9),             ### useful are: chr(9) is TAB or ';'
                   'EMPTY_CHAR'    => ' - - - ',
                   'SIGNAL_MARKER' => 'SIG: ',             ### marker to identify the label of the checked signal
                   'EXPECT_MARKER' => 'EXP: ',             ### marker to identify the 'MUST' / 'SOLL'
                   'DETECT_MARKER' => 'FND: ',             ### marker to identify the 'REAL' / 'IST'
                   'JUST_VERDICTS' =>
                                   {
                                    'VERDICT_FAIL'   => 1,
                                    'VERDICT_INCONC' => 1,
                                    'VERDICT_NONE'   => 1,
                                    'VERDICT_PASS'   => 1,
                                    },
                   'COLUMN_ORDER'  =>
                                   [
                                   'NBR' ,
                                   'DATE_TIME' ,
                                   'TC_ID' ,
                                   'TEMPERATURE',
                                   'VERDICT' ,
                                   'PRE_MAND_PASS' ,
                                   'PRE_MAND_FAIL' ,
                                   'PRE_OPT_PASS' ,
                                   'PRE_OPT_FAIL' ,
                                   'POST_MAND_PASS' ,
                                   'POST_MAND_FAIL' ,
                                   'POST_OPT_PASS' ,
                                   'POST_OPT_FAIL' ,
                                    ],
                    },


'DEVICE_CONFIG' => {

               'AB1FD' => 'AB1FD',
               'AB1FP' => 'AB1FP',
               'HA1FP' => 'HA1FP',
               'HA1FD' => 'HA1FD',
               'SA1FD' => 'SA1FD',
               'SA1FP' => 'SA1FP',
               'BT1FD'=> 'BT1FD',
               'BT1FP' => 'BT1FP',
               'BATDHV' => 'BATDHV',
               'BATD12V' => 'BATD12V',
               
               # Switches            
   
                'BL2RP'=>'Belt Lock Rear Passenger uC controlled',
                'BLFD'=>'Belt Lock Front Driver',
                'BLFDVW'=>'Belt Lock Front Driver VW',
                'BLFP'=>'Belt Lock Front Passenger',
                'BLFPVW'=>'Belt Lock Front Passenger VW',
                'BL2RD'=>'Belt Lock Rear Driver uC controlled',
                'BL2RC'=>'Belt Lock Rear Center uC controlled',
                
                'SBR'=>'Seat Belt Reminder uC controlled',
                'SSSL1'=>'Passenger Deactivation SW Line read by uC',
                'HWPATH'=>'Passenger Deactivation switch HW line',
				'BAOffA'=>'BAOffA',
				'BAOnA'=>'BAOnA',
              
                #special behaviour bits
                
                'SBRInSeries'=>'SBR in series to BLFP',
               	'AttentionBlinking'=>'Activate BAOxA of Attention Blinking feature',
                },
};

1;
