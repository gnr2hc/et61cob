#### TEST CASE MODULE
package TC_sVTT_StandardTest;
#-> package name has to match file name ! case sensitive !

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
###-------------------------------
our $VERSION = q$Revision: 1.3 $;
our $HEADER = q$Header: sVTT/TC_sVTT_StandardTest.pm 1.3 2014/08/26 14:34:31ICT VGR3KOR develop  $;
##################################

#### INCLUDE ENGINE MODULES ####
use LIFT_general;   # this is always required
use LIFT_sVTT;
use LIFT_PD;

##################################

our $PURPOSE = "Basic sVTT Curve execution";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

#-> update documentation that somebody else can use the test without asking you
#-> delete parameter section if no parameters are used
#-> note that POD documentation needs entirely empty lines before and after keywords (e.g. =head1, =cut ...) 

=head1 TESTCASE MODULE

TC_template  $Revision: 1.3 $

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:
    
    <list used parameters>

link to TS_CP: 

    [initialisation]     
	<list test steps>
	
    [stimulation & measurement]
    1. Preform pre-diagnosis action(optional)
    2. Reset of svtt execution (optional)
    3. Execution of Curve
    3. Reset of svtt execution (optional)
    4. Preform post-diagnosis action(optional)
    5. Reset of svtt execution (optional)

    [evaluation]
    1. evaluate of labels
    2. evaluate FltMem before crash
    3. evaluate FltMem after crash
 
    [finalisation]
    <list test steps>

=head1 PARAMETER

=head2 PARAMETER NAMES

    Curve_name
    ECU_labels
    FLT_mand
	FLT_opt
	Check_Labels

=head2 PARAMETER EXAMPLES

    [TC_sVTT_StandardTest.Audi_LV124_E02]
    Curve_name = 'AUDI_lv124_e_02_transient_over_voltage_endurance'
    ECU_labels = @('label1','label2')
    FLT_mand = @('fault1','fault2')
	FLT_opt = @('opt_fault1' , 'opt_fault2')
	Check_Labels = @ ('label1|operator1|expectedvalue1,'label2|operator2|expectedvalue2')

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#-> define variables here which all be used across subroutines
#-> test case parameters shall start with tcpar_
my ($tcpar_Curve_Name, $tcpar_ECU_labels, $tcpar_FLT_mand, $tcpar_FLT_opt, $tcpar_ChkLabel);

sub TC_set_parameters {
    	
    $tcpar_Curve_Name = S_read_testcase_parameter( 'Curve_name' );
    unless( defined $tcpar_Curve_Name ) {
        S_w2rep(" -->  Missing mandatory parameter Curve_name \n");
    }
    
    $tcpar_ECU_labels = S_read_testcase_parameter( 'ECU_labels', 'byref' );
    unless( defined $tcpar_ECU_labels ) {
    	S_w2rep(" -->  Missing mandatory parameter ECU_labels \n");
    }
    
   $tcpar_FLT_mand = S_read_testcase_parameter( 'FLT_mand','byref' );
   unless( defined $tcpar_FLT_mand ) {
        S_w2rep(" -->  Missing optional parameter FLT_mand \n");
   }    
   
   $tcpar_FLT_opt = S_read_testcase_parameter( 'FLT_opt','byref' );
   unless( defined $tcpar_FLT_opt ) {
        S_w2rep(" -->  Missing optional parameter FLT_opt\n");
    }    

   $tcpar_ChkLabel = S_read_testcase_parameter( 'Check_Labels','byref' );
   unless( defined $tcpar_ChkLabel ) {
        S_w2rep(" -->  Missing optional parameter Check_Labels\n");
    } 

	return 1;
}


#### INITIALIZE TC #####
sub TC_initialization 
{
   return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement 
{

    # pre diagnosis
	SVTT_PerformDiagnosis($tcpar_Curve_Name, 'AO0','pre', $tcpar_ECU_labels, $tcpar_ChkLabel);
	SVTT_Reset();
	#Execute curve
	SVTT_ExecuteCurve($tcpar_Curve_Name);
	#Post diagnosis
	SVTT_Reset();
    SVTT_PerformDiagnosis($tcpar_Curve_Name, 'AO0','post', $tcpar_ECU_labels, $tcpar_ChkLabel);
	SVTT_Reset();

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation 
{
	SVTT_Evaluation($tcpar_Curve_Name, $tcpar_FLT_mand, $tcpar_FLT_opt);

	return 1;
}


#### TC FINALIZATION #####
sub TC_finalization 
{
	return 1;
}

1;