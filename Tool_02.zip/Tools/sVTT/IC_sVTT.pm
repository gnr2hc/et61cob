#### TEST CASE MODULE
package IC_sVTT;

#### DONT MODIFY THIS SECTION ####
use strict;
###-------------------------------
my $VERSION = q$Revision: 1.5 $;
my $HEADER = q$Header: sVTT/IC_sVTT.pm 1.5 2015/06/22 15:31:51ICT Archana Gopalakrishna (RBEI/ECF1) (GOA2BMH) develop  $;

#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general;
use FuncLib_sVTT;
use LIFT_PD;
use LIFT_CD;
use LIFT_POWER;
use LIFT_MLC;
use LIFT_equipment;
use LIFT_CANoe;
use LIFT_can_access;

##################################

## testcase parameters

## other local vars

our $PURPOSE = "LIFT INIT CAMPAIGN for sVTT in MQB_A0";

my $tcpar_CANoe_flag;

##################################
####  TESTCASE STARTS HERE    ####
##################################

sub TC_set_parameters {
    $tcpar_CANoe_flag = S_read_testcase_parameter('CANOE_flag');
	 
	unless( defined $tcpar_CANoe_flag)
    {
        S_w2rep(" -->  Missing mandatory parameter CANOE_flag \n");
        return 0;
    }

    return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

    S_w2rep(" *** Starting Init Campaign ***\n");

    S_w2rep(" *** General Initialization & Configuration of Test System *** \n");
    S_w2rep("---------------------------------------------------------------\n");

    S_w2rep( " IC -> write LIFT configuration to logfile \n" );
    S_w2rep( " LIFT Test System uses following versions of useful function libraries:\n" );
    S_w2rep( "   < $main::HEADER >\n" )  if defined $main::HEADER;
    S_w2rep( "   < $LIFT_general::HEADER >\n" ) if defined $LIFT_general::HEADER;
    S_w2rep( "   < $LIFT_POWER::HEADER >\n" ) if defined $LIFT_POWER::HEADER;
    S_w2rep( "   < $LIFT_sVTT::HEADER >\n" ) if defined $LIFT_sVTT::HEADER;
    S_w2rep( "   < $LIFT_PD::HEADER >\n" ) if defined $LIFT_PD::HEADER;
    S_w2rep( "   < $LIFT_MLC::HEADER >\n" ) if defined $LIFT_MLC::HEADER;
	
    S_log_testbenchconfig();

    #------------------------------------------------
    # initialize OLE
    #------------------------------------------------
    S_w2rep( " IC -> Initialize test bench equipment \n" );

	if ($tcpar_CANoe_flag)
    {
        ### better to initialize CANoe after MLC to avoid CAN HW conflicts
        ### for CANoe initialisation
         S_w2rep("Initilaizing CANoe\n");
       #CAN_init();
       #CAN_start_measurement();
        
		 EQUIP_main_init();      
		 CA_trace_configure();  
		 CA_trace_start();
		 CA_read_configure();
		 CA_write_configure();
    }

	SVTT_init();

    S_w2rep(" IC -> set verdict PASS to finish init campaign\n");
    S_set_verdict( VERDICT_PASS );
	
    return 1;
}


### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {	
	
	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {
   return 1;
}


#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {
    return 1;
}

1;
