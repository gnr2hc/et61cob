#### TEST CASE MODULE
package EC_sVTT;

#### DONT MODIFY THIS SECTION ####
use strict;
###-------------------------------
my $VERSION = q$Revision: 1.3 $;
my $HEADER = q$Header: sVTT/EC_sVTT.pm 1.3 2015/06/22 15:32:13ICT Archana Gopalakrishna (RBEI/ECF1) (GOA2BMH) develop  $;
##################################

#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general;
use LIFT_evaluation;
use LIFT_PD;
use FuncLib_sVTT;


##################################

## testcase parameters

## other local vars

our $PURPOSE = "LIFT END CAMPAIGN for template project";

=head 

sorry, no description available

=cut

##################################
####  TESTCASE STARTS HERE    ####
##################################

my ($tcpar_diag,$tcpar_quate);

sub TC_set_parameters {

    ###-----------------------------------------------------------------------
    ### Reading Testcase Parameter from Testcase Parameter File
    ###-----------------------------------------------------------------------

    return 1;
}



#### INITIALIZE TC #####
sub TC_initialization {

    S_w2rep(" *** Starting End Campaign ***\n") ;

    S_w2rep( " EC -> cleaning up test bench equipment \n" );

	SVTT_exit();

    S_w2rep(" EC -> set vercict PASS to finish exit campaign\n");
    S_set_verdict( VERDICT_PASS );

    return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {
return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {
return 1;
}


#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {
return 1;
}


1;