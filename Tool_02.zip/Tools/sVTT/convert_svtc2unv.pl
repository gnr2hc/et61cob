# Small tool to convert svtc files to unv format, so the files can be viewed with uniview.
# Chose a folder -> All .svtc files in the folder will be converted into .txt.unv files
#
use strict;
use File::Find;
use Tk;

my $mw = tkinit();
#my $folderName = 'C:\Users\phc2si\Documents\perl_test\svtc';
my $folderName = $mw->chooseDirectory(-title => 'Choose a folder with svtc files');


find(\&convertFile, ($folderName) );

print "READY.\n";


sub convertFile{
	my ($headerLine);

	my $fileName = $File::Find::name;

	return unless( $fileName =~ /\.svtc$/i );

	print "Converting $fileName ...\n";
	
	my $outName = $fileName;
	$outName =~ s/\.\w+$/.txt.unv/;
	
	open( IN, '<', $fileName) or die "cannot open input file $fileName : $!";
	my @lines = <IN>;
	close IN;
	
	$headerLine = shift @lines; # curve name
	$headerLine = shift @lines; # samples
	$headerLine = shift @lines; # iteration
	$headerLine = shift @lines; # time
	my $deltaTime = 0;
	if( $headerLine =~ /:\s*(\d+\.\d+)/ ){
		$deltaTime = $1;
	}
	$headerLine = shift @lines; # empty
	$headerLine = shift @lines; # signal[unit]
	my $signal = 'none';
	my $unit = 'none';
	if( $headerLine =~ /^(\w+)\[(\w+)\]/ ){
		$signal = $1;
		$unit = $2;
	}
	
	my $outputString = "TIME;$signal\n";
	$outputString .= "s;$unit\n";
	
	my $time = 0;
	foreach my $line (@lines){
		if( $line =~ /^(.+)$/ ){
			$outputString .= "$time;$1\n";
			$time += $deltaTime;
		}
	}
			
	open( OUT, ">$outName"  ) or die $!;
	print OUT $outputString;
	close OUT;

}

