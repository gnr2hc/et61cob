# *****************************************************************************************************
#                                                                                                      
#  Copyright (c) 2014  Robert Bosch GmBH                                                               
#                      Germany                                                                         
#                      All rights reserved                                                             
#                                                                                                      
#******************************************************************************************************
#    $Revision: 1.8 $
#    $Author: Weissflog Peter (CC-PS/EPS2) (WGP2SI) $
#    $Date: 2016/10/28 18:25:30ICT $
#******************************************************************************************************

# :::::::::::::::::::::::::::::::::::::::::::::::: #
# :::::::::::::::::::::::::::::::::::::::::::::::: #
# :::                                          ::: #
# ::: this file is only used for documentation ::: #
# :::                                          ::: #
# :::::::::::::::::::::::::::::::::::::::::::::::: #
# :::::::::::::::::::::::::::::::::::::::::::::::: #

=for html
<font color="Maroon" size = "8">Stochastic Voltage Temperature Test (sVTT)</font>

=head2 Introduction of sVTT

=for html
<font color="blue">
Stochastic Voltage Temperature Test is performed to check general ECU behavior (hardware and software) under environment temperature and power supply variations
</font>

=head3 TurboLiFT description

=for html
<font color="blue">
A general introduction on TurboLiFT can be found @ <a href="../../../Engine/Documentation/html/Documentation/LIFT_description.html" target="blank1">TurboLiFT_Description</a>
</font>

=head3 Testbench Setup and description

=for html
<font color="blue">
The below picture shows the testbench setup of sVTT.<br/><br/>
NIDAQ+Servowatt/Toellner is the power supply.<br/><br/>
Known amplifiers: Servowatt or TOE7621_32.<br/><br/>
Known NIDAQ-Cards: PCIe-6251 or USB-6361 (BNC).<br/><br/>
MLC/TSG4/Peribox is the periphery device.<br/><br/>
Servowatt or TOE7621_32 amplifier amplifies the output voltage of NIDAQ connected to MLC.<br/><br/>
CANoe is used to log the trace <font color="red">if required.</font><br/><br/>
PC containing TurboLiFT project for testing.<br/><br/>
Temperature chamber/Oven to set/read temperature.<br/><br/>
<IMG SRC='..\..\pics\sVTT\Testbench_setup.png' alt="sVTT Testbench Setup Image" border="1" />
<br/><br/><font color="black"><B> NIDAQ Driver Installation</B><br/><br/></font>
1. Install NIDAQ driver either from NI website <br />&nbsp;&nbsp;&nbsp;&nbsp;<font color="green">http://www.ni.com/download/ni-daqmx-9.6/3423/en/ </font><br />or below path (N Drive)<br />
&nbsp;&nbsp;&nbsp;&nbsp;<font color="green">\\siz1130\aerse$\Projekte\Testing\05_Programs\5.17_Commercial_SW_and_Drivers\NI\NIDAQ960F0\NIDAQ960f0.exe</font><br />
2. After installation of niDaq-driver, rename the default generic device name to <I>"NI-DAQmx"</I> or old still allowed <I>"M6251_1"</I> by opening NI Measurement & Automation (MAX).
<br/><br/><font color="black"><B> Over Voltage Protection for NIDAQ </B><br/><br/></font>
1.	Servowatt HW-factor = -5.0 *OR* TOE7621_32 HW-factor = 3.2 is handled in NIDAQ low level module, configured by entry in <font color="green"> $Testbench->{'Devices' => 'NIDAQ' => 'Amplifier' => "Servowatt" *OR* "TOE7621_32"} </font>.<br />
2.  Due to the risk of specifying wrong amplifier, a S_user_action was added in function 'NIDAQ_init', to let the user confirm once per TurboLIFT test-run, that the correct amplifier was configured in Testbench.<br />
3.	Further limitation of curve voltage values is defined in Project constants file <font color="green"> $Defaults->{'VTT'}->{'Curve_Controls'} </font>
</font><font color="red">
<br/><br/><B>NIDAQ CAN BE USED IN CONJUNCTION WITH SERVOWATT or TOE7621_32 AMPLIFIER</B>
</font>

=head3 High level Architecture

=for html
<font color="blue">
The below picture shows the architecture of sVTT.<br/><br/>
The module LIFT_sVTT has all the necessary elementary APIs to perform Voltage Temperature Test which shall be called in Testcase.<br/><br/>
<B><font color="green"> Note:: All modules description are available @ <a href="../../../Engine/Documentation/index.html" target="blank2">TurboLiFT_Modules_Description</a></B>
</font></font><br/><br/>
<IMG SRC='..\..\pics\sVTT\Architecture.png' alt="sVTT High level Architecture Image" border="1" />

=head4 LIFT Modules Table

=for html
<font color = "#333300">
<table border = 1>
<tr> <th>Module Name</th>         <th>DLL</th>        <th>Tool</th>                </tr>
<tr> <td>LIFT_sVTT.pm</td>        <td></td>           <td></td>                    </tr>
<tr> <td>LIFT_PD.pm</td>          <td>PD</td>         <td></td>                    </tr>
<tr> <td>LIFT_NIDAQ.pm</td>       <td>NIDAQ</td>      <td></td>                    </tr>
<tr> <td>LIFT_TOE1.pm</td>        <td></td>           <td></td>                    </tr>
<tr> <td>LIFT_POWER.pm</td>       <td></td>           <td></td>                    </tr>
<tr> <td>LIFT_Temperature.pm</td> <td></td>           <td></td>                    </tr>
<tr> <td>LIFT_VOETSCH.pm</td>     <td></td>           <td></td>                    </tr>
<tr> <td>DTM5080.pm</td>          <td></td>           <td></td>                    </tr>
<tr> <td>LIFT_sVTT_Curves.pm</td> <td></td>           <td>SVTT_Utility_GUI.pl</td> </tr>
</table></font>

=head4 LIFT Project Configuration files Table

=for html
<font color = "red">All Configuration files mentioned in below table varies for different projects.</font>
<font color = "Green">Example considers VW_PQ26 project.</font><br/><br/>
<font color = "#333300">
<table border = 1>
<tr> <th>Configuration files</th>     <th>Folder Location</th> <th>Description</th>  </tr>
<tr> <td>VW_PQ26_ProjectConst.pm</td> <td>Config</td>         <td>Project constant parameters are available here</td>  </tr>
<tr> <td>VW_PQ26_CFG.pm</td>          <td>Config</td>         <td>Project Specific Configuration details are available here</td>  </tr>
<tr> <td>LIFT_Testbenches.pm</td>     <td>Config</td>         <td>Testbench specific parameters are available here</td>  </tr>
<tr> <td>IC_VW_PQ26.pm</td>           <td>Config</td>         <td>Init Campaign file of Project</td>  </tr>
<tr> <td>IC_VW_PQ26.par</td>          <td>Config</td>         <td>Init Campaign related parameter file of Project</td>  </tr>
<tr> <td>EC_VW_PQ26.pm</td>           <td>Config</td>         <td>End Campaign file of Project</td>  </tr>
</table></font>                                              
<br/>
<B><font color="green"> Note:: All configuration files, testlist, testcases and Testcase Parameter sample files are provided in below sections for reference.</font></B>

=head3 sVTT TurboLiFT folder structure

=for html
<font color = "blue">The TurboLIFT folder structure consists of six folders (Refer below diagram).</font><br/><br/>
<font color = "green">
1. config    ::</font> <font color = "blue"> Contains configuration files, Campaign file and Tools related folder (CANoe, sVTT_Curves). </font><br/>
<font color = "red">Note :: Currently sVTT_Curves folder can be maintained any location <I>(Preferred location :: As mentioned in below picture)</I> as project is not created. </font>
<font color = "green"><br /><br />
2. Engine    ::</font> <font color = "blue"> Contains exec_engine & related modules. </font><br /><br />
<font color = "green">
3. reports   ::</font> <font color = "blue"> Contains the testrun reports. </font><br /><br />
<font color = "green">
4. TC_par    ::</font> <font color = "blue"> Contains testcase(s) related parameter(s) file(s). </font><br /><br />
<font color = "green">
5. TCs       ::</font> <font color = "blue"> Contains project related testcases (.pm). </font><br /><br />
<font color = "green">
6. Testlists ::</font> <font color = "blue"> Contains testlist file(s). </font><br /><br />
<IMG SRC='..\..\pics\sVTT\Folder_Structure.png' alt="sVTT Folder Structure Image" border="1" />

=head2 sVTT Curves

=head3 Features

=for html
<font color = "blue">
1. Creation of LV124 Curves <br />
2. SAT to SVTC file Conversion<br />
<font color="green"><B>Note::</B> Help document is provided in GUI</font><br />
</font>

=head3 Curve Availability Table

=for html
<font color = "#333300"  size = "4">
<table border = 1>
<tr> <th>Curve Name</th> <th>Generator</th>           <th>Comment</th> </tr>
<tr> <td>LV124 E01</td>  <td>LIFT_sVTT_Curves.pm/sVTT_Utility_GUI.pl</td> <td></td> </tr>
<tr> <td>LV124 E02</td>  <td>LIFT_sVTT_Curves.pm/sVTT_Utility_GUI.pl</td> <td></td> </tr>
<tr> <td>LV124 E03</td>  <td>LIFT_sVTT_Curves.pm/sVTT_Utility_GUI.pl</td> <td></td> </tr>
<tr> <td>LV124 E04</td>  <td>LIFT_sVTT_Curves.pm/sVTT_Utility_GUI.pl</td> <td></td> </tr>
<tr> <td>LV124 E05</td>  <td>LIFT_sVTT_Curves.pm/sVTT_Utility_GUI.pl</td> <td></td> </tr>
<tr> <td>LV124 E06</td>  <td>Done by HW group</td>    <td></td> </tr>
<tr> <td>LV124 E07</td>  <td>LIFT_sVTT_Curves.pm/sVTT_Utility_GUI.pl</td> <td></td> </tr>
<tr> <td>LV124 E08</td>  <td>LIFT_sVTT_Curves.pm/sVTT_Utility_GUI.pl</td> <td></td> </tr>
<tr> <td>LV124 E09</td>  <td>LIFT_sVTT_Curves.pm/sVTT_Utility_GUI.pl</td> <td></td> </tr>
<tr> <td>LV124 E10</td>  <td>TC_LV124_E_10.pm</td>    <td>TSG4 Hardware: Microcut feature available for all function modules,<br/>except bus PAS, i.e. only for first 2 of 8 PASes on each PAS module</td> </tr>
<tr> <td>LV124 E11</td>  <td>LIFT_sVTT_Curves.pm/sVTT_Utility_GUI.pl</td> <td></td> </tr>
<tr> <td>LV124 E12</td>  <td>LIFT_sVTT_Curves.pm/sVTT_Utility_GUI.pl</td> <td></td> </tr>
<tr> <td>LV124 E13</td>  <td>TC_LV124_E_13.pm</td>    <td>TSG4 Hardware: Microcut feature available for all function modules,<br/>except bus PAS, i.e. only for first 2 of 8 PASes on each PAS module</td> </tr>
<tr> <td>LV124 E14</td>  <td>Manual Testing</td>    <td>Manual Test Connector interruption<br/>Not done with NIDAQ</td> </tr>
<tr> <td>LV124 E15</td>  <td>LIFT_sVTT_Curves.pm/sVTT_Utility_GUI.pl</td> <td></td> </tr>
<tr> <td>LV124 E16</td>  <td> Done by TSG4 HW</td>    <td>TSG4 Hardware solution available<br/>Not done with NIDAQ</td> </tr>
<tr> <td>LV124 E17</td>  <td> Short Circuit Robustness Test (CSR)</td>    <td>done by system tester in RBEI as a service for HW group in Dz<br/>Not done with NIDAQ</td> </tr>
<tr> <td>LV124 E18</td>  <td>  </td>    <td>MLBevo : Not required by customer (negotiated)<br/>MQB - Not decided</td> </tr>
<tr> <td>LV124 E19</td>  <td>  </td>    <td>Current measurement required<br/>Not done with NIDAQ</td> </tr>
<tr> <td>LV124 E20</td>  <td>  </td>    <td>500V test voltage required<br/>Not done with NIDAQ</td> </tr>
<tr> <td>LV124 E21</td>  <td>Done by HW group</td>    <td> </td> </tr>
<tr> <td>LV124 E22</td>  <td>  </td>    <td>MLBevo : Not required by customer (negotiated)<br/>MQB - Not decided</td> </tr>
</table></font>

=head3 Curve File formats

=for html
<font color = "blue">
The below table shows different curve formats which are supported in TurboLiFT.</font><br /><br />
<IMG SRC='..\..\pics\sVTT\CurveFormats.png' alt="sVTT Curve Library File Formats Image" border="1" />

=head3 Curve Creation and Execution Usecases

=for html
<font color = "#333300">
<table border = 1>
    <tr>
         <th>Usecase</th>
         <th>Description</th>
    </tr>
    <tr>
         <td> Curve will be created and run without randomness </td>
         <td> Curves are created in Testcase by calling APIs from LIFT_sVTT_Curves.pm .<br/>Read curve parameters from parameter file and create.</td>
    </tr>     
    <tr>
         <td> Curve will be created with Randomness </td>
         <td> Curves are created in Testcase by calling APIs from LIFT_sVTT_Curves.pm. <br/>Randomness is achieved with additional 'randomness' parameter .<br/>Read curve parameters from parameter file and create. <br /> Repeat the test multiple times in testlist to achieve more randomness.</td>
    </tr>     
    <tr>
         <td> Curve not created in testcase (curve file exists either standard or random) </td>
         <td> Required that usecase 1 or 2 have run once before. <br /> This usecase is used mainly for analysis. </td>
    </tr>     
</table>
<br /><font color="brown">For sample testcases, parameter and testlist files with different usecases refer to section<B><I> Test Execution </I></B></font>
</font>

=head2 Comparison between TurboLiFT and Testprog

=head3 Testprog VTC to TurboLiFT Configuration files

=for html
<font color = "blue">
The below diagram shows the transformation of testprog VTC file to TurboLiFT Configuration.<br /><br />
1. <B>TB</B> represents that VTC parameters are transformed to LIFT_testbenches.pm file, as these are very specific to testbench setup.<br /><br />
2. <B>PjC</B> represents that VTC parameters are transformed to sVTT_projectConst.pm file, as these are very specific to project.<br /><br />
3. <B>Testcase</B> represents that selected curves & ECU Labels are handled as testcase parameters.<br /><br />
</font>
<IMG SRC='..\..\pics\sVTT\VTC_to_Config.png' alt="sVTT Testprog VTC to TurboLiFT Configuration Image" border="1" />

=head3 Project Constant

=for html
<font color = "blue">For sample Project Constant of sVTT, refer</font>
<a href="../../../sVTT/sVTT_ProjectConst.pm" type="text/pm">Sample sVTT ProjectConst</a>

=head3 Testbench Configuration

=for html
<font color = "blue">For sample Testbench of sVTT, refer</font>
<a href="../../../sVTT/LIFT_Testbenches.pm" type="text/pm">Sample sVTT Testbench</a>

=head3 Configuration (CFG) file

=for html
<font color = "blue">
Contains the configuration related information such as paths of SAD file, SAT file, reports folder and so on.<br /><br />
For sample Configuration file of sVTT, refer</font>
<a href="../../../sVTT/sVTT_CFG.pm" type="text/pm">Sample sVTT CFG</a>

=head2 Test Execution

=head3 Pre-execution steps

=for html
<font color = "blue">
1. Create the Testcase parameters and testlist files based on Usecase .<br /><br />
2. Project related configuration settings(project constants, test bench and configuration file) should be done.
</font>

=head3 Testcase execution

=for html
<font color = "blue">
The below diagram shows the execution flow of testcase to perform voltage temperature test.<br /><br />
1. Reads the curve information from curve library<br /><br />
&nbsp;&nbsp;&nbsp;&nbsp;a. Both sat and svtc files are supported for NIDAQ.<br /><br />
&nbsp;&nbsp;&nbsp;&nbsp;b. Only sat files are supported for Toellner.<br /><br />
2. Perform the Pre-Diagnosis action<br /><br />
3. Execute the arbitrary voltage curve on ECU<br /><br />
4. Perform the Post-Diagnosis action<br /><br />
5. Evaluates mandatory/optional faults of pre and post dianosis and ECU Label checking<br /><br />
<font color = "green"> These sequence of steps will be performed for all testcases in project</font><br /><br />
<IMG SRC='..\..\pics\sVTT\Testcase_Execution.png' alt="sVTT Testcase_Execution Image" border="1" /><br /><br />
For Sample Testcase refer <a href="../../../sVTT/TC_sVTT_Executecurve.pm" type="text/pm">Sample sVTT Testcase</a><br /><br />
</font>

=head4 Doors Interface

=for html
<font color = "blue">The parameters and testlist are generated from DOORS<br /><br />
For Sample Par and Testlist files refer below links<br /><br /></font>
<a href="../../../sVTT/TC_sVTT_Executecurve.par" type="text/par">sVTT Sample parameter file </a><br /><br />
<a href="../../../sVTT/sVTT_TL.txt" type="text/pm">sVTT Sample Testlist </a><br /><br />

=head4 Init Campaign

=for html
<font color = "blue">
This is FIRST step in testing.<br /><br />
Here the function called is SVTT_init<br /><br />
This Initiates PD, performs BB check, connects power device, temperature device and set the state of verdict to PASS on success.<br /><br />
For Sample IC and IC_PAR refer below links<br /><br /></font>
<a href="../../../sVTT/IC_sVTT.pm" type="text/pm">sVTT Sample INIT Campaign</a><br /><br />
<a href="../../../sVTT/IC_sVTT.par" type="text/par">sVTT Sample INIT Campaign parameter file</a><br /><br />

=head4 End Campaign

=for html
<font color = "blue">
This is LAST step in testing.<br /><br />
Here the function called is SVTT_exit<br /><br />
This closes PD, disconnects power device, temperature device and set the state of verdict to PASS on success.<br /><br />
For Sample EC refer </font>
<a href="../../../sVTT/EC_sVTT.pm" type="text/pm">sVTT Sample END Campaign</a><br /><br />

=head3 Test flow

=for html
<font color = "blue">The High level view on testflow of sVTT testing in a project is given in below diagram</font><br /><br />
<IMG SRC='..\..\pics\sVTT\TestFlow.png' alt="sVTT TestFlow Image" border="1" />

=head2 Result Evaluation 

=for html
<font color = "blue">This section gives an overview on the Evaluation report of testcases executed.</font>

=head3 Report structure in Testprog

=for html
<font color = "blue">
The below diagram shows the analysis tool used in Testprog for result evaluation.<br /><br />
</font>
<IMG SRC='..\..\pics\sVTT\AnalysisTool.png' alt="Analysis Tool Image" border="1" /><br/><br />

=head3 Report structure in TurboLiFT

=for html
<font color = "blue">
The below tables shows the result evaluation in TurboLiFT.<br /><br />
</font>
<IMG SRC='..\..\pics\sVTT\Result_Table.png' alt="Result Table Image" border="1" /><br/><br />
<font color = "blue">
The below picture shows the Evaluation table format for different usecases.<br /><br />
Generic Evaluation Table : This table shows which column will be available in evaluation table for what input parameter.<br /><br />
All the other tables show different usecases.<br /><br />
</font>
<IMG SRC='..\..\pics\sVTT\Evalaution_Tables.png' alt="Result Table Image" border="1" /><br/><br />

=head3 Comparison between Testprog and TurboLiFT reports

=for html
<font color = "blue">
In Testprog, Analysis Tool is used to evaluate the result of complete testing.<br /><br />
In TurboLiFT, each testcase is executed and respective report is generated which helps in re-execution of the failed testcases.<br /><br />
Each curve execution is a testcase.<br /><br />
The evaluation of result is performed in testcase evaluation phase, as each testcase executes a single curve. No separate tool is used to perform evaluation.<br /><br />
The verdict is set to <B>NONE</B> in offline mode.<br /><br />
The verdict is set to <font color = "green"><B>PASS</B></font> if no other faults except all mandatory faults are logged into fault memory of ECU and a finite temperature is read from chamber.<br /><br />
The verdict is set to <font color = "red"><B>FAIL</B></font> in all other cases.<br /><br />
The verdict is set to <font color = "purple"><B>INCONC</B></font> if any unexpected hardware error.<br /><br />
</font>

=head2 Notes

=for html
<font color = "blue">
To make all links work appropriately, need to synchronize the <font color = "green">"\\TurboLIFT\Tools\Engine\modules"</font> and run <font color = "red">"create_LIFT_docu.bat"</font> in <font color = "green">"\\TurboLIFT\Tools\Engine\Documentation" </font>folder<br/><br/>
</font>