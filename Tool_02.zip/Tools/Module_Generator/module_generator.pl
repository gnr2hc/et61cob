=head1 NAME

module_generator.pl - generate a TurboLIFT module skeleton from a text file containing the package name and the function prototypes

=head1 SYNOPSIS

module_generator.pl

=head1 VERSION

$Revision: 1.2 $

=head1 DESCRIPTION

module_generator.pl asks for an input text file. The first line of this file must be:

package <package>

The other lines must contain the function prototypes in the form:

<return values> = <function name>( <arguments> );

For examples see the file example.txt

module_generator.pl will generate a TurboLIFT module file <package>.pm with skeletons for function code and POD. 

=cut

use strict;
use Tk;

# open file dialog
my $mw = tkinit();
my $types_aref = [ ['Text files', '.txt'],
              ['All Files',   '*'],];
my $inputFile = $mw->getOpenFile(
        -filetypes => $types_aref,
    );

# read input file and get all lines of the file
open( IN, '<', $inputFile) or die "cannot open input file $inputFile : $!";
my @lines = <IN>;
close IN;

# read first line and extract package name
my $firstLine = shift @lines;
my $package;
if( $firstLine =~ /package\s+(\w+)/ ) {
    $package = $1;
}
else{
    print("ERROR: First line of input file ($inputFile) does not contain 'package ' followed by a package name.\n");
    print("Press <RETURN> to exit.\n");
    <STDIN>;
    exit;
}

my ($bodyString, @functions, @prototypes);
# loop over the rest of the lines
foreach my $line (@lines){
    my ($returnValues, $functionWithArgs, $function, $arguments);
    # check prototype format of the line
    if( $line =~ /^([^=]+)=([^=]+)/ ){
        # everything before the = is return values
        $returnValues = $1;
        # everything after the = is function name with arguments
        $functionWithArgs = $2;
        # remove leading and trailing whitespace from $returnValues
        $returnValues =~ s/^\s+//g;
        $returnValues =~ s/\s+$//g;
    }
    else{
        # assume the whole line is function name with arguments if there is no =
        $functionWithArgs = $line;
    }

    # remove line feed, semicolon, leading and trailing whitespace from $functionWithArgs
    chomp $functionWithArgs;
    $functionWithArgs =~ s/;//g;
    $functionWithArgs =~ s/^\s+//g;
    $functionWithArgs =~ s/\s+$//g;
    
    # get function name and arguments
    if( $functionWithArgs =~ /^\s*(\w+)\s*\((.*)\)/ ) {
        $function = $1;
        $arguments = $2;
    }
    
    # take next line if no function name is defined
    next if not defined $function;
    
    # remember function names and prototypes for header skeleton
    push(@functions, $function);
    push(@prototypes, $line);

    # Generate the skeleton for each function; text will be added to $bodyString
    AddFunctionSkeleton($function, $line, $functionWithArgs, $arguments, $returnValues);
}

$bodyString .= "1;\n";


# Generate the skeleton for the module header (using $package, @functions, @prototypes)
my $headerString = GetModuleHeaderSkeleton();

# write output file
my $outputFile = "$package.pm";
open( OUT, ">$outputFile"  ) or die $!;
print OUT "$headerString\n";
print OUT "$bodyString\n";
close OUT;

# final printout for the user
my $functionCount = @functions;
print("Created skeleton code for $functionCount functions in output file $outputFile.\n");
print("Press <RETURN> to exit.\n");
<STDIN>;



# Generate the skeleton for one function
sub AddFunctionSkeleton{
    my $function = shift;
    my $prototype = shift;
    my $functionWithArgs = shift;
    my $arguments = shift;
    my $returnValues = shift;
    
    # get individual arguments
    $arguments =~ s/\[//g;
    $arguments =~ s/\]//g;
    my @arguments = split(/,/, $arguments);

    # generate arguments in POD
    my $podArgumentString;
    $podArgumentString = "B<Arguments:>\n\n=over\n\n" if @arguments;
    foreach my $argument ( @arguments ) {
        $argument =~ s/\s//g;
        $podArgumentString .= "=item $argument\n\n";
    }
    $podArgumentString .= "=back\n\n" if @arguments;

    # generate arguments in code
    my $codeArgumentString;
    $codeArgumentString = "    my \@args = \@_;\n" if @arguments;
    $codeArgumentString .= "    S_checkFunctionArguments( '$functionWithArgs', \@args ) or return;\n" if @arguments;
    foreach my $argument ( @arguments ) {
        $argument =~ s/\s//g;
        $codeArgumentString .= "    my $argument = shift \@args;\n";
    }    

    # get individual return values
    my @returnValues;
    if( $returnValues =~ /\((.+)\)/ ){
        @returnValues = split(/,/, $1);
    }
    else{
        @returnValues = ($returnValues) if defined $returnValues;
    }

    # generate return values in POD
    my $podReturnValueString;
    $podReturnValueString =  "B<Return Values:>\n\n=over\n\n" if @returnValues;
    foreach my $returnValue ( @returnValues ) {
        $returnValue =~ s/\s//g;
        $podReturnValueString .= "=item $returnValue\n\n";
    }
    $podReturnValueString .= "=back\n\n" if @returnValues;

    # generate return values in code
    my $codeReturnValueString;
    $codeReturnValueString = "    my $returnValues;\n\n" if @returnValues;
    $codeReturnValueString .= "    return $returnValues;" if @returnValues;

    # generate skeleton for function
    my $skel = <<"END_SKEL";
=head2 $function

    $prototype

$podArgumentString
$podReturnValueString
B<Examples:>

B<Notes:> 

=cut

sub $function {
$codeArgumentString
$codeReturnValueString
}

END_SKEL

    # add function skeleton to $bodyString
    $bodyString .= $skel;
}


# Generate the skeleton for the module header
sub GetModuleHeaderSkeleton{

    # create beginning of header
    my $header = <<'END_HEADER1';
# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmbH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#    $Source: Module_Generator/module_generator.pl $
#    $Revision: 1.2 $
#    $Author: Prosch Christian (CC-PS/EPS2) (PHC2SI) $
#    $State: develop $
#    $Date: 2017/05/11 21:30:26ICT $
#******************************************************************************************************

END_HEADER1


    # add package name
    $header .= "package $package;\n\n";

    $header .= <<'END_HEADER2';
use strict;
use warnings;
use LIFT_general;

require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
END_HEADER2


    # add list of exported functions
    foreach my $function ( @functions ) {
        $header .= "    $function\n";
    }

    $header .= <<'END_HEADER3';
);

our ( $VERSION, $HEADER );
$VERSION = q$Revision: 1.2 $;
$HEADER  = q$Header: Module_Generator/module_generator.pl 1.2 2017/05/11 21:30:26ICT Prosch Christian (CC-PS/EPS2) (PHC2SI) develop  $;

=head1 NAME

END_HEADER3


    $header .= "$package \$Revision: 1.2 $\n\n";
    $header .= "=head1 SYNOPSIS\n\n";
    $header .= "    use $package\n\n";
    # add list of prototype for synopsis
    foreach my $prototype ( @prototypes ) {
        $header .= "    $prototype";
    }
    $header .= "\n=head1 DESCRIPTION\n\n";
    $header .= "\n=head1 FUNCTIONS\n\n";
    
    return $header;
}
