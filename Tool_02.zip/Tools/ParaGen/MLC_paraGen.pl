#!C:\Perl\bin\Perl.exe -w

#################################################################################
# this tool is under version management
my $VERSION = q$Revision: 2.4 $;
my $HEADER  = q$Header: ParaGen/MLC_paraGen.pl 2.4 2010/02/26 15:56:12ICT Boehm Frank (DC/PAR) (BM7ZSI) develop  $;
#################################################################################


my $addpath;
BEGIN
{
    my $LIFT_exec_path='./../Engine';

    # add directories to search path for perl modules    
    unshift @INC, "$LIFT_exec_path/modules";

}


use strict;
use warnings;
use Getopt::Long;
use Tk;

my $out_file_shortRT = 'RB_shortLineRT.par';
my $out_file_shortINI = 'RB_shortLineINI.par';
my $out_file_openRT = 'RB_openLineRT.par';
my @SQlines;
my @SWlines;
my @PASlines;
my $INfile;

my $SQquali  = "'SQUIB_FAULT_QUALI_TIME'";
my $SQdequali= "'SQUIB_FAULT_DEQUALI_TIME'";
my $SQqualijitter= "'SQUIB_QUALI_JITTER'";
my $SQdequalijitter= "'SQUIB_DEQUALI_JITTER'";
my $SQshort_quali  = "'SQUIB_SHORT_QUALI_TIME'";
my $SQshort_dequali= "'SQUIB_SHORT_DEQUALI_TIME'";
my $SQqualiINI  = "'SQUIB_INI_QUALI_TIME'";
my $SQdequaliINI = "'SQUIB_INI_DEQUALI_TIME'";

my $SWquali  = "'SWITCH_FAULT_QUALI_TIME'";
my $SWdequali= "'SWITCH_FAULT_DEQUALI_TIME'";
my $SWqualijitter= "'SWITCH_QUALI_JITTER'";
my $SWdequalijitter= "'SWITCH_DEQUALI_JITTER'";
my $SWqualiINI  = "'SWITCH_INI_QUALI_TIME'";
my $SWdequaliINI = "'SWITCH_INI_DEQUALI_TIME'";

my $PASquali  = "'PAS_FAULT_QUALI_TIME'";
my $PASdequali= "'PAS_FAULT_DEQUALI_TIME'";
my $PASqualijitter= "'PAS_QUALI_JITTER'";
my $PASdequalijitter= "'PAS_DEQUALI_JITTER'";
my $PASqualiINI  = "'PAS_INI_QUALI_TIME'";
my $PASdequaliINI = "'PAS_INI_DEQUALI_TIME'";

=head1 usage

create parameter files for RB_shortLineRT, RB_shortLineINI, RB_openLineRT based on MLC_HW.ini or project defaults file


 CLI: MLC_paraGen.pl --file [file]
 e.g. MLC_paraGen.pl --file C:\MKS\LIFT\LIFT_FORD_C307_project\Project_defaults\FO1000_ProjectDefaults.pm


=head1 AUTHOR

Frank B�hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=cut


#$INfile = 'C:\MKS\LIFT\LIFT_FORD_C307_project\Project_defaults\FO1000_ProjectDefaults.pm';




my ( $main, $ValueFrame, $ButtonFrame, $ValueEntry, $display_txt);


################################
# create those nice TK widgets #
################################

# create main window 'main'
$main = MainWindow -> new();

# define minimum size of window 'main'
$main -> minsize( 400, 300 );

# create title in window 'main'
$main -> title ( "create MLC parameter file $VERSION" );

# create label in window 'main'
$main -> Label( "-text" => "create MLC parameter file based on MLC_HW.ini or project defaults file",
                "-font" => "{MS Sans Serif} 10 bold",
         )
      -> pack( "-pady" => 10 );

# create frame 'ValueFrame' in window 'main'
$ValueFrame = $main -> Frame() -> pack( "-pady" => 5 );

# create frame 'ButtonFrame' in window 'main'
$ButtonFrame = $main -> Frame() -> pack( "-pady" => 5 );

# create label in window 'ValueWindow'
$ValueFrame -> Label( "-text" => "file: ", )
            -> pack( "-side" => 'left', );

# create entry 'ValueEntry' in 'ValueFrame'
$ValueEntry = $ValueFrame -> Entry(
            "-width" => 50,
            "-textvariable" => \$INfile, #reference to $prj_id
            );
$ValueEntry -> pack( "-side" => 'left', );

          # create 'browse file' button
          $ValueFrame -> Button
            (
            "-text" => "Browse file",
            "-command" => sub
              {
                      # browse for file
                      $INfile = $main -> getOpenFile
                        (
                        "-filetypes"  =>
                          [
                          ["par files", '.ini'],
                          ["par files", '.pm'],
                          ["All files", '.*']
                          ],
                        "-title"      => "choose one of the files to scan (*.pm, *.ini)",
                        );
                      # if a file was chosen
                      if ( $INfile )
                        {
                        #extract directory
                        print "\n $INfile was chosen\n";
                        $display_txt="$INfile was chosen";
                        }
                      else
                        {
                          print "no filename!\n";
                          # prompt user
                          $main->messageBox(
                              '-icon'    => "error",#qw/error info question warning/
                              '-type'    => "OK",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                              '-title'   => 'Attention',
                              '-message' => "!Please select file first!"
                          );


                       }
              },
            )
              -> pack ("-padx" => 5,);


# create 'exit' button
$ButtonFrame -> Button
  (
  "-text" => "E X I T",
  "-command" => sub
    {exit}
  )
-> pack ("-side" => 'left',"-ipadx" => 20,"-ipady" => 20,"-pady" => 30,"-padx" => 50);


# create 'create' button
$ButtonFrame -> Button
  (
  "-text" => "CREATE",
  "-command" => sub
    { # execute when button is pressed  
        if ($INfile) { # create project if scan_file was given
        create_params();
        $INfile = ""; # set scan_file to undefined

        }
        else{
        # prompt user if scan_file is undefined
            $main->messageBox(
                '-icon'    => "error", #qw/error info question warning/
                '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
                '-message' => "!Please select file first!"
            );
        }
    }
  )
-> pack ("-side" => 'right',"-ipadx" => 20,"-ipady" => 20,"-pady" => 30,"-padx" => 50);

# create label in window 'main'
$main -> Label( "-textvariable" => \$display_txt, #reference to $display_txt
                "-font" => "{MS Sans Serif} 10 bold",
         )
      -> pack( "-pady" => 10 );






#++++++++++++++++++++++++++++++++++++++++++++++
########################## MAIN ###############
# the MainLoop is used by perlTK, when it is called all widgets are created and the
# connected actions are done (e.g. when you press a button)


# run with CLI
GetOptions('file=s' => \$INfile );
if ($INfile){ # source file
    print("running with CLI\n");
    create_params();
}
else{
  # if no options, run TK GUI
  print("running with TK\n");
  MainLoop();
}


#-------------------- MAIN end ---------------#
#++++++++++++++++++++++++++++++++++++++++++++++






sub create_params{
@SQlines = ();
@SWlines = ();
@PASlines = ();

# check for blanks !

if ($INfile =~ /\.pm$/){
    my $key;
    print "loading Project defaults\n";
    require "$INfile";        # contains package LIFT_PROJECT
    foreach $key ( keys %{$LIFT_PROJECT::Defaults->{"MLC"}{'SQUIBS'}} ){
        push(@SQlines,$LIFT_PROJECT::Defaults->{"MLC"}{'SQUIBS'}{$key});
    }
    foreach $key ( keys %{$LIFT_PROJECT::Defaults->{"MLC"}{'SWITCHES'}} ){
        if ($key =~ /_Name$/){
            push(@SWlines,$LIFT_PROJECT::Defaults->{"MLC"}{'SWITCHES'}{$key});
        }
    }
    foreach $key ( keys %{$LIFT_PROJECT::Defaults->{"MLC"}{'PAS'}} ){
        push(@PASlines,$LIFT_PROJECT::Defaults->{"MLC"}{'PAS'}{$key});
    }
    
}
elsif($INfile =~ /\.ini$/){
    my $line;
    print "loading HW ini\n";
    open ( IN,"<$INfile" ) or die "Couldn't open $_ : $@";

    while($line = <IN>){ 
        #scan for line labels
        if ($line =~ /^\s*SW\d+_Name\s*=\s*(\w+)/) {
            push(@SWlines,$1);
        }
        elsif($line =~ /^\s*SQ\d+_Name\s*=\s*(\w+)/) {
            push(@SQlines,$1);
        }
        elsif($line =~ /^\s*PAS\d+_Name\s*=\s*(\w+)/) {
            push(@PASlines,$1);
        }
    }
    
}
else {die"unknown file format $INfile\n";}


#@SQlines = qw( BT1RD BT1RP BT1RC WB1D WB1P HEADD AB1FD HEADP KABD KABP WB2D WB2P SARD SARP BLFD BLFP AB2FD AB1FP AB2FP BT1FD BT1FP SABD SABP BATDIS );
#@SWlines = qw( BLRR PADS BLFL PSPOS BLRL BLRM DSPOS BLFR );

@SQlines = sort @SQlines;
@SWlines = sort @SWlines;
@PASlines = sort @PASlines;
print" SQ @SQlines \n";
print" SW @SWlines \n";
print"PAS @PASlines \n";



open (FILE,">para.txt") or warn "could not write $out_file_shortRT: $@\n";

print FILE"add to projects default section and change values if required:\n\n";
print FILE"'VEHICLE'           => {\n";
print FILE"                        'U_BATT_LINEFAULT'                 => 13.8,\n"; 
print FILE"                        'U_BATT_DEFAULT'                   => 13.8,\n"; 
print FILE"                        'ISO_FAULTMEMORY'                  => 0,\n";    
print FILE"                        },\n";
print FILE"'TIMER'             => {\n";
print FILE"                        'TIMER_ECU_READY                  => 2000,\n";
print FILE"                        'TIMER_ECU_OFF                    => 3000,\n";
print FILE"                        $SQquali          => 1000,\n";
print FILE"                        $SQdequali        => 2500,\n";
print FILE"                        $SQqualijitter              => 500,\n";
print FILE"                        $SQdequalijitter              => 500,\n";
print FILE"                        $SQshort_quali          => 1000,\n";
print FILE"                        $SQshort_dequali        => 2500, \n";
print FILE"                        $SQqualiINI            => 0, \n";
print FILE"                        $SQdequaliINI          => 0, \n";
print FILE"                        $SWquali         => 700, \n";
print FILE"                        $SWdequali       => 1700, \n";
print FILE"                        $SWqualijitter             => 500,\n";
print FILE"                        $SWdequalijitter             => 500,\n";
print FILE"                        $SWqualiINI           => 0, \n";
print FILE"                        $SWdequaliINI         => 0, \n";
print FILE"                        $PASquali         => 150, \n";
print FILE"                        $PASdequali       => 4000,\n";
print FILE"                        $PASqualijitter             => 30,\n";
print FILE"                        $PASdequalijitter             => 30,\n";
print FILE"                        $PASqualiINI           => 0,\n";
print FILE"                        $PASdequaliINI         => 0,\n";
print FILE"                       },\n";





close(FILE);

generate_shortRT();
generate_shortINI();
generate_openRT();

 $display_txt="done";
}

=head1 comments

 you might have to adjust the quali time for single switches
 workaround to simulate switches with free usable switches has to be implemented manually
 switches on same multiplexer will qualify all faults for short2Vbat this has to be modified manually 

=cut



###########################################
###########################################
############### SUBROUTINES ###############
###########################################
###########################################

sub generate_shortRT{
my $line;
my ($line1,$line2,$l1,$l2);

    open (FILE,">$out_file_shortRT") or warn "could not write $out_file_shortRT: $@\n";

    print FILE "\n### SQUIBS ###\n\n";

    foreach $line(@SQlines){

        print FILE "[RB_shortLineRT.".$line."p_GND]\n";
        print FILE "core_asset_ID   = 'missing'\n";
        print FILE "purpose         = 'check fault quali for SQ short $line to GND'\n";
        print FILE "lines           = @('$line+','GND')\n";
        print FILE "qualitime       = $SQquali\n";
        print FILE "dequalitime     = $SQdequali\n";
        print FILE "qualijitter     = $SQqualijitter\n";
        print FILE "dequalijitter   = $SQdequalijitter\n";
        print FILE "FLTmand         = @('Flt".$line."TerminalShort2Gnd')\n";
        print FILE "FLTopt          = @('Flt".$line."ResistanceShort')\n";
        print FILE "\n";

        print FILE "[RB_shortLineRT.".$line."p_VBAT]\n";
        print FILE "core_asset_ID   = 'missing'\n";
        print FILE "purpose         = 'check fault quali for SQ short $line to VBAT'\n";
        print FILE "lines           = @('$line+','VBAT')\n";
        print FILE "qualitime       = $SQquali\n";
        print FILE "dequalitime     = $SQdequali\n";
        print FILE "qualijitter     = $SQqualijitter\n";
        print FILE "dequalijitter   = $SQdequalijitter\n";
        print FILE "FLTmand         = @('Flt".$line."TerminalShort2Bat')\n";
        print FILE "FLTopt          = @('Flt".$line."ResistanceOpen')\n";
        print FILE "\n";

        print FILE "[RB_shortLineRT.".$line."m_GND]\n";
        print FILE "core_asset_ID   = 'missing'\n";
        print FILE "purpose         = 'check fault quali for SQ short $line to GND'\n";
        print FILE "lines           = @('$line-','GND')\n";
        print FILE "qualitime       = $SQquali\n";
        print FILE "dequalitime     = $SQdequali\n";
        print FILE "qualijitter     = $SQqualijitter\n";
        print FILE "dequalijitter   = $SQdequalijitter\n";
        print FILE "FLTmand         = @('Flt".$line."TerminalShort2Gnd')\n";
        print FILE "FLTopt          = @('Flt".$line."ResistanceShort')\n";
        print FILE "\n";

        print FILE "[RB_shortLineRT.".$line."m_VBAT]\n";
        print FILE "core_asset_ID   = 'missing'\n";
        print FILE "purpose         = 'check fault quali for SQ short $line to VBAT'\n";
        print FILE "lines           = @('$line-','VBAT')\n";
        print FILE "qualitime       = $SQquali\n";
        print FILE "dequalitime     = $SQdequali\n";
        print FILE "qualijitter     = $SQqualijitter\n";
        print FILE "dequalijitter   = $SQdequalijitter\n";
        print FILE "FLTmand         = @('Flt".$line."TerminalShort2Bat')\n";
        print FILE "FLTopt          = @('Flt".$line."ResistanceOpen')\n";
        print FILE "\n";

        print FILE "[RB_shortLineRT.".$line."]\n";
        print FILE "core_asset_ID   = 'SRTP_FLS_380'\n";
        print FILE "purpose         = 'check fault quali for SQ short $line+ to $line-'\n";
        print FILE "lines           = @('".$line."+','".$line."-')\n";
        print FILE "qualitime       = $SQshort_quali\n";
        print FILE "dequalitime     = $SQshort_dequali\n";
        print FILE "qualijitter     = $SQqualijitter\n";
        print FILE "dequalijitter   = $SQdequalijitter\n";
        print FILE "FLTmand         = @('Flt".$line."ResistanceShort')\n";
        print FILE "\n";

    }

    print FILE "\n### SWITCHES ###\n\n";

    foreach $line(@SWlines){

        print FILE "[RB_shortLineRT.".$line."p_VBAT]\n";
        print FILE "core_asset_ID   = 'SRTP_SWM_13'\n";
        print FILE "purpose         = 'check fault quali for SW short $line+ to VBAT'\n";
        print FILE "lines           = @('$line+','VBAT')\n";
        print FILE "qualitime       = $SWquali\n";
        print FILE "dequalitime     = $SWdequali\n";
        print FILE "qualijitter     = $SWqualijitter\n";
        print FILE "dequalijitter   = $SWdequalijitter\n";
        print FILE "FLTmand         = @('FltSwitch".$line."Short2Bat')\n";
        print FILE "\n";

        print FILE "[RB_shortLineRT.".$line."p_GND]\n";
        print FILE "core_asset_ID   = 'SRTP_SWM_14'\n";
        print FILE "purpose         = 'check fault quali for SW short $line+ to GND'\n";
        print FILE "lines           = @('$line+','GND')\n";
        print FILE "qualitime       = $SWquali\n";
        print FILE "dequalitime     = $SWdequali\n";
        print FILE "qualijitter     = $SWqualijitter\n";
        print FILE "dequalijitter   = $SWdequalijitter\n";
        print FILE "FLTmand         = @('FltSwitch".$line."ShortLine')\n";
        print FILE "\n";

        # SW short $line+ to $line- is similar to SW short $line+ to GND
    }

    print FILE "\n### PERIPHERAL SENSORS ###\n\n";

    foreach $line(@PASlines){

        print FILE "[RB_shortLineRT.".$line."p_VBAT]\n";
        print FILE "core_asset_ID   = 'tbd'\n";
        print FILE "purpose         = 'check fault quali for PAS short $line+ to VBAT'\n";
        print FILE "lines           = @('$line+','VBAT')\n";
        print FILE "qualitime       = $PASquali\n";
        print FILE "dequalitime     = $PASdequali\n";
        print FILE "qualijitter     = $PASqualijitter\n";
        print FILE "dequalijitter   = $PASdequalijitter\n";
        print FILE "FLTmand         = @('FltPas".$line."Short2Bat')\n";
        print FILE "\n";

        print FILE "[RB_shortLineRT.".$line."p_GND]\n";
        print FILE "core_asset_ID   = 'tbd'\n";
        print FILE "purpose         = 'check fault quali for PAS short $line+ to GND'\n";
        print FILE "lines           = @('$line+','GND')\n";
        print FILE "qualitime       = $PASquali\n";
        print FILE "dequalitime     = $PASdequali\n";
        print FILE "qualijitter     = $PASqualijitter\n";
        print FILE "dequalijitter   = $PASdequalijitter\n";
        print FILE "FLTmand         = @('FltPas".$line."Short2Gnd')\n";
        print FILE "\n";

    }
   
    close (FILE);

    print "\n$out_file_shortRT done\n";

}



sub generate_shortINI{
my $line;
my ($line1,$line2,$l1,$l2);

    open (FILE,">$out_file_shortINI") or warn "could not write $out_file_shortINI: $@\n";

    print FILE "\n### SQUIBS ###\n\n";

    foreach $line(@SQlines){

        print FILE "[RB_shortLineINI.".$line."p_GND]\n";
        print FILE "core_asset_ID   = 'SRTP_FLS_10'\n";
        print FILE "purpose         = 'check fault quali for SQ short $line to GND'\n";
        print FILE "lines           = @('$line+','GND')\n";
        print FILE "qualitime       = $SQquali\n";
        print FILE "dequalitime     = $SQdequali\n";
        print FILE "qualijitter     = $SQqualijitter\n";
        print FILE "dequalijitter   = $SQdequalijitter\n";
        print FILE "FLTmand         = @('Flt".$line."TerminalShort2Gnd')\n";
        print FILE "FLTopt          = @('Flt".$line."ResistanceShort')\n";
        print FILE "\n";

        print FILE "[RB_shortLineINI.".$line."p_VBAT]\n";
        print FILE "core_asset_ID   = 'SRTP_FLS_9'\n";
        print FILE "purpose         = 'check fault quali for SQ short $line to VBAT'\n";
        print FILE "lines           = @('$line+','VBAT')\n";
        print FILE "qualitime       = $SQquali\n";
        print FILE "dequalitime     = $SQdequali\n";
        print FILE "qualijitter     = $SQqualijitter\n";
        print FILE "dequalijitter   = $SQdequalijitter\n";
        print FILE "FLTmand         = @('Flt".$line."TerminalShort2Bat')\n";
        print FILE "FLTopt          = @('Flt".$line."ResistanceOpen')\n";
        print FILE "\n";

        print FILE "[RB_shortLineINI.".$line."m_GND]\n";
        print FILE "core_asset_ID   = 'SRTP_FLS_12'\n";
        print FILE "purpose         = 'check fault quali for SQ short $line to GND'\n";
        print FILE "lines           = @('$line-','GND')\n";
        print FILE "qualitime       = $SQquali\n";
        print FILE "dequalitime     = $SQdequali\n";
        print FILE "qualijitter     = $SQqualijitter\n";
        print FILE "dequalijitter   = $SQdequalijitter\n";
        print FILE "FLTmand         = @('Flt".$line."TerminalShort2Gnd')\n";
        print FILE "FLTopt          = @('Flt".$line."ResistanceShort')\n";
        print FILE "\n";

        print FILE "[RB_shortLineINI.".$line."m_VBAT]\n";
        print FILE "core_asset_ID   = 'SRTP_FLS_11'\n";
        print FILE "purpose         = 'check fault quali for SQ short $line to VBAT'\n";
        print FILE "lines           = @('$line-','VBAT')\n";
        print FILE "qualitime       = $SQquali\n";
        print FILE "dequalitime     = $SQdequali\n";
        print FILE "qualijitter     = $SQqualijitter\n";
        print FILE "dequalijitter   = $SQdequalijitter\n";
        print FILE "FLTmand         = @('Flt".$line."TerminalShort2Bat')\n";
        print FILE "FLTopt          = @('Flt".$line."ResistanceOpen')\n";
        print FILE "\n";

        print FILE "[RB_shortLineINI.".$line."]\n";
        print FILE "core_asset_ID   = 'SRTP_FLS_20'\n";
        print FILE "purpose         = 'check fault quali for SQ short $line+ to $line-'\n";
        print FILE "lines           = @('".$line."+','".$line."-')\n";
        print FILE "qualitime       = $SQquali\n";
        print FILE "dequalitime     = $SQdequali\n";
        print FILE "qualijitter     = $SQqualijitter\n";
        print FILE "dequalijitter   = $SQdequalijitter\n";
        print FILE "FLTmand         = @('Flt".$line."ResistanceShort')\n";
        print FILE "\n";

    }

    for($l1=0;$l1<scalar(@SQlines);$l1++){
        for($l2=$l1+1;$l2<scalar(@SQlines);$l2++){
            $line1=$SQlines[$l1];
            $line2=$SQlines[$l2];
            
            print FILE "[RB_shortLineINI.".$line1."p_".$line2."p]\n";
            print FILE "core_asset_ID   = 'SRTP_FLS_2'\n";
            print FILE "purpose         = 'check fault quali for SQ short $line1+ to $line2+'\n";
            print FILE "lines           = @('$line1+','$line2+')\n";
            print FILE "qualitime       = $SQqualiINI\n";
            print FILE "dequalitime     = $SQdequaliINI\n";
            print FILE "qualijitter     = $SQqualijitter\n";
            print FILE "dequalijitter   = $SQdequalijitter\n";
            print FILE "nodequali_flag  = 1\n";
            print FILE "FLTmand         = @('Flt".$line1."CrossCoupled','Flt".$line2."CrossCoupled')\n";
            print FILE "\n";
            
            print FILE "[RB_shortLineINI.".$line1."m_".$line2."m]\n";
            print FILE "core_asset_ID   = 'SRTP_FLS_124'\n";
            print FILE "purpose         = 'check fault quali for SQ short $line1- to $line2-'\n";
            print FILE "lines           = @('$line1-','$line2-')\n";
            print FILE "qualitime       = $SQqualiINI\n";
            print FILE "dequalitime     = $SQdequaliINI\n";
            print FILE "qualijitter     = $SQqualijitter\n";
            print FILE "dequalijitter   = $SQdequalijitter\n";
            print FILE "nodequali_flag  = 1\n";
            print FILE "FLTmand         = @('Flt".$line1."CrossCoupled','Flt".$line2."CrossCoupled')\n";
            print FILE "\n";

            print FILE "[RB_shortLineINI.".$line1."p_".$line2."m]\n";
            print FILE "core_asset_ID   = 'SRTP_FLS_122'\n";
            print FILE "purpose         = 'check fault quali for SQ short $line1+ to $line2-'\n";
            print FILE "lines           = @('$line1+','$line2-')\n";
            print FILE "qualitime       = $SQqualiINI\n";
            print FILE "dequalitime     = $SQdequaliINI\n";
            print FILE "qualijitter     = $SQqualijitter\n";
            print FILE "dequalijitter   = $SQdequalijitter\n";
            print FILE "nodequali_flag  = 1\n";
            print FILE "FLTmand         = @('Flt".$line1."CrossCoupled','Flt".$line2."CrossCoupled')\n";
            print FILE "\n";

            print FILE "[RB_shortLineINI.".$line1."m_".$line2."p]\n";
            print FILE "core_asset_ID   = 'SRTP_FLS_123'\n";
            print FILE "purpose         = 'check fault quali for SQ short $line1- to $line2+'\n";
            print FILE "lines           = @('$line1-','$line2+')\n";
            print FILE "qualitime       = $SQqualiINI\n";
            print FILE "dequalitime     = $SQdequaliINI\n";
            print FILE "qualijitter     = $SQqualijitter\n";
            print FILE "dequalijitter   = $SQdequalijitter\n";
            print FILE "nodequali_flag  = 1\n";
            print FILE "FLTmand         = @('Flt".$line1."CrossCoupled','Flt".$line2."CrossCoupled')\n";
            print FILE "\n";
        }
    }


    print FILE "\n### SWITCHES ###\n\n";

    foreach $line(@SWlines){

        print FILE "[RB_shortLineINI.".$line."p_VBAT]\n";
        print FILE "core_asset_ID   = 'SRTP_SWM_13,SRTP_SWM_262'\n";
        print FILE "purpose         = 'check fault quali for SW short $line+ to VBAT'\n";
        print FILE "lines           = @('$line+','VBAT')\n";
        print FILE "qualitime       = $SWqualiINI\n";
        print FILE "dequalitime     = $SWdequaliINI\n";
        print FILE "qualijitter     = $SWqualijitter\n";
        print FILE "dequalijitter   = $SWdequalijitter\n";
        print FILE "nodequali_flag  = 1\n";
        print FILE "FLTmand         = @('FltSwitch".$line."Short2Bat')\n";
        print FILE "\n";

        print FILE "[RB_shortLineINI.".$line."p_GND]\n";
        print FILE "core_asset_ID   = 'SRTP_SWM_14'\n";
        print FILE "purpose         = 'check fault quali for SW short $line+ to GND'\n";
        print FILE "lines           = @('$line+','GND')\n";
        print FILE "qualitime       = $SWquali\n";
        print FILE "dequalitime     = $SWdequali\n";
        print FILE "qualijitter     = $SWqualijitter\n";
        print FILE "dequalijitter   = $SWdequalijitter\n";
        print FILE "FLTmand         = @('FltSwitch".$line."ShortLine')\n";
        print FILE "\n";

        # SW short $line+ to $line- is similar to SW short $line+ to GND
    }

    for($l1=0;$l1<scalar(@SWlines);$l1++){
        for($l2=$l1+1;$l2<scalar(@SWlines);$l2++){
            $line1=$SWlines[$l1];
            $line2=$SWlines[$l2];

            print FILE "[RB_shortLineINI.".$line1."_".$line2."]\n";
            print FILE "core_asset_ID   = 'SRTP_SWM_16'\n";
            print FILE "purpose         = 'check fault quali for SW short $line1+ to $line2+'\n";
            print FILE "lines           = @('$line1+','$line2+')\n";
            print FILE "qualitime       = $SWqualiINI\n";
            print FILE "dequalitime     = $SWdequaliINI\n";
            print FILE "nodequali_flag  = 1\n";
            print FILE "qualijitter     = $SWqualijitter\n";
            print FILE "dequalijitter   = $SWdequalijitter\n";
            print FILE "FLTmand         = @('FltSwitch".$line1."CrossCoupled','FltSwitch".$line2."CrossCoupled')\n";
            print FILE "\n";

        }
    }

    print FILE "\n### PERIPHERAL SENSORS ###\n\n";

    foreach $line(@PASlines){

        print FILE "[RB_shortLineINI.".$line."p_VBAT]\n";
        print FILE "core_asset_ID   = 'tbd'\n";
        print FILE "purpose         = 'check fault quali for PAS short $line+ to VBAT'\n";
        print FILE "lines           = @('$line+','VBAT')\n";
        print FILE "qualitime       = $PASqualiINI\n";
        print FILE "dequalitime     = $PASdequali\n";
        print FILE "qualijitter     = $PASqualijitter\n";
        print FILE "dequalijitter   = $PASdequalijitter\n";
        print FILE "FLTmand         = @('FltPas".$line."Short2Bat')\n";
        print FILE "\n";

        print FILE "[RB_shortLineINI.".$line."p_GND]\n";
        print FILE "core_asset_ID   = 'tbd'\n";
        print FILE "purpose         = 'check fault quali for PAS short $line+ to GND'\n";
        print FILE "lines           = @('$line+','GND')\n";
        print FILE "qualitime       = $PASqualiINI\n";
        print FILE "dequalitime     = $PASdequali\n";
        print FILE "qualijitter     = $PASqualijitter\n";
        print FILE "dequalijitter   = $PASdequalijitter\n";
        print FILE "FLTmand         = @('FltPas".$line."Short2Gnd')\n";
        print FILE "\n";

    }

    for($l1=0;$l1<scalar(@PASlines);$l1++){
        for($l2=$l1+1;$l2<scalar(@PASlines);$l2++){
            $line1=$PASlines[$l1];
            $line2=$PASlines[$l2];

            print FILE "[RB_shortLineINI.".$line1."_".$line2."]\n";
            print FILE "core_asset_ID   = 'tbd'\n";
            print FILE "purpose         = 'check fault quali for PAS short $line1+ to $line2+'\n";
            print FILE "lines           = @('$line1+','$line2+')\n";
            print FILE "qualitime       = $PASqualiINI\n";
            print FILE "dequalitime     = $PASdequaliINI\n";
            print FILE "nodequali_flag  = 1\n";
            print FILE "qualijitter     = $PASqualijitter\n";
            print FILE "dequalijitter   = $PASdequalijitter\n";
            print FILE "FLTmand         = @('FltPas".$line1."CrossCoupling','FltPas".$line2."CrossCoupling')\n";
            print FILE "\n";

        }
    }
    
    close (FILE);

    print "\n$out_file_shortINI done\n";

}



sub generate_openRT{
my $line;

    open (FILE,">$out_file_openRT") or warn "could not write $out_file_openRT: $@\n";

    print FILE "\n### SQUIBS ###\n\n";



    foreach $line(@SQlines){

        print FILE "[RB_openLineRT.".$line."]\n";
        print FILE "core_asset_ID   = 'SRTP_FLS_381'\n";
        print FILE "purpose         = 'check fault quali for SQ open $line'\n";
        print FILE "line            = '$line'\n";
        print FILE "qualitime       = $SQquali\n";
        print FILE "dequalitime     = $SQdequali\n";
        print FILE "qualijitter     = $SQqualijitter\n";
        print FILE "dequalijitter   = $SQdequalijitter\n";
        print FILE "FLTmand         = @('Flt".$line."ResistanceOpen')\n";
        print FILE "\n";


    }

    print FILE "\n### SWITCHES ###\n\n";

    foreach $line(@SWlines){

        print FILE "[RB_openLineRT.".$line."]\n";
        print FILE "core_asset_ID   = 'SRTP_SWM_15'\n";
        print FILE "purpose         = 'check fault quali for SW open $line'\n";
        print FILE "line            = '$line'\n";
        print FILE "qualitime       = $SWquali\n";
        print FILE "dequalitime     = $SWdequali\n";
        print FILE "qualijitter     = $SWqualijitter\n";
        print FILE "dequalijitter   = $SWdequalijitter\n";
        print FILE "FLTmand         = @('FltSwitch".$line."OpenLine')\n";
        print FILE "\n";

    }

    print FILE "\n### PERIPHERAL SENSORS ###\n\n";

    foreach $line(@PASlines){

        print FILE "[RB_openLineRT.".$line."]\n";
        print FILE "core_asset_ID   = 'tbd'\n";
        print FILE "purpose         = 'check fault quali for PAS open $line'\n";
        print FILE "line            = '$line'\n";
        print FILE "qualitime       = $PASquali\n";
        print FILE "dequalitime     = $PASdequaliINI\n";
        print FILE "qualijitter     = $PASqualijitter\n";
        print FILE "dequalijitter   = $PASdequalijitter\n";
        print FILE "nodequali_flag  = 1\n";
        print FILE "FLTmand         = @('FltPas".$line."OpenLine')\n";
        print FILE "\n";

    }
    
    close (FILE);

    print "\n$out_file_openRT done\n";

}


# end of program
