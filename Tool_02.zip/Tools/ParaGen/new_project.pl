# *****************************************************************************************************
#                                                                                                       
#  Copyright (c) 2012  Robert Bosch GmBH                                                                
#                      Germany                                                                          
#                      All rights reserved                                                              
#                                                                                                       
#******************************************************************************************************
#    $Source: ParaGen/new_project.pl $
#    $Revision: 1.6 $
#    $Author: Reddivari Devendra Kumar (RBEI/ESA-PP) (dvn2kor) $
#    $State: develop $
#    $Date: 2014/07/02 22:25:07ICT $
#******************************************************************************************************

use strict;
use warnings;
use File::Basename;

############## ROOT PROJECT ##############################################
# TODO Enter the MKS path one level below the actual created project
my $rootproject= 'G:\MKS\Projects\TurboLIFT\Projects\VW_Audi_Platform\VW_Audi_Platform.pj';  

##################### NEW PROJECT NAME ####################################
# TODO name of project to be created
my $projectname = "MQB_A0";   

########################### CUSTLIB PROJECT ############################
my $custlib_projectname = 'VW_Audi';   #TODO

########################### LOCAL SANDBOX PATHS ########################
#TODO change the local sandbox path
my $turbolift_sandbox_path = 'D:\MKS\TurboLIFT';   

my $template_path = $turbolift_sandbox_path.'\Template';
my $projects_path = $turbolift_sandbox_path. '\Projects\VW_Audi_Platform';   #TODO

# just for testing: comment later
my $rootfolder = dirname($rootproject);

# just for later use ...
my $SAD= 'K:\DfsDE\DIV\CS\DE_CS$\Prj\PS\Line\Software\AB-Software\Audi_VW\1041\E-Up\vw1002_BB00000_c07_Cat2_20120426\Results\vw1002_BB00000_c07_Cat2_20120426.sad';
my $MLC_file='MLC.ini';
my $diag_file='diag.ini';


# create folders in sandbox


my ($cmd, $result, @file, $line);

#head1 just commented to avoid accidental usage !!!

# create subproject
$cmd="si createsubproject -P $rootproject $rootfolder\\$projectname\\$projectname.pj";
MKS_command($cmd);


## share engine + TCs
$cmd='si sharesubproject --sharedProject=G:\MKS\Projects\TurboLIFT\System\Engine\Engine.pj -P '."$rootfolder\\$projectname\\$projectname.pj $rootfolder\\$projectname".'\Engine\Engine.pj';
MKS_command($cmd);

#share the custlib TC_FunctionLib project to the created project (\Engine\modules\TC_FunctionLib\TC_FunctionLib.pj)
$cmd="si sharesubproject --sharedProject=G:\\MKS\\Projects\\TurboLIFT\\Projects\\CustLib\\$custlib_projectname\\TC_FunctionLib\\TC_FunctionLib.pj -P $rootfolder\\$projectname\\$projectname.pj $rootfolder\\$projectname" . '\Engine\modules\TC_FunctionLib\TC_CustLib\TC_FunctionLib.pj';
MKS_command($cmd);

#share the custlib TCs_CustLib project to the created project (TCs\TCs_CustLib\TCs_CustLib.pj)
$cmd="si sharesubproject --sharedProject=G:\\MKS\\Projects\\TurboLIFT\\Projects\\CustLib\\$custlib_projectname\\TCs_CustLib\\TCs_CustLib.pj -P $rootfolder\\$projectname\\$projectname.pj $rootfolder\\$projectname" . '\TCs\TCs_CustLib\TCs_CustLib.pj';
MKS_command($cmd);

#share the TCs TCs_TNT project to the created project (\TCs\TCs_TNT\TCs_TNT.pj)
$cmd='si sharesubproject --sharedProject=G:\MKS\Projects\TurboLIFT\System\TCs\TCs_TNT\TCs_TNT.pj -P '."$rootfolder\\$projectname\\$projectname.pj $rootfolder\\$projectname".'\TCs\TCs_TNT\TCs_TNT.pj';
MKS_command($cmd);

## create sandbox
$cmd='si createsandbox -P '."$rootfolder\\$projectname\\$projectname.pj"." -Y $projects_path\\"."$projectname";
MKS_command($cmd);

# copy files with DOS command xcopy from Template project

$result = system( "xcopy $template_path\\config\\*.p* $projects_path\\$projectname\\config\\ /Y/R" );    
$result = system( "xcopy $template_path\\reports $projects_path\\$projectname\\reports\\ /Y/R/E" );    
$result = system( "xcopy $template_path\\config\\SW $projects_path\\$projectname\\config\\SW\\ /Y/R/E" );    
$result = system( "xcopy $template_path\\Testlists $projects_path\\$projectname\\Testlists\\ /Y/R/E" );    
$result = system( "xcopy $template_path\\TC_par $projects_path\\$projectname\\TC_par\\ /Y/R/E" );    
$result = system( "xcopy $template_path\\TCs\\TCs_Project\\readme_project.txt $projects_path\\$projectname\\TCs\\TCs_Project\\ /Y/R" );    
$result = system( "xcopy $template_path\\Engine\\modules\\TC_FunctionLib\\readme_project.txt $projects_path\\$projectname\\Engine\\modules\\TC_FunctionLib\\ /Y/R" );    



# copy run_empty.bat file and replace config name
print "\nrewriting run_empty.bat --> ";
open (IN, "<$template_path\\run_empty.bat");
	@file=<IN>;
close(IN);
foreach $line (@file){
	$line =~ s/default_CFG/\Q$projectname\E_CFG/;
}
open (OUT, ">$projects_path\\$projectname\\run_empty.bat");
	print OUT @file;
close(OUT);
print "done ! ";

# rename and modify config files
rename ("$projects_path\\$projectname\\config\\default_ProjectConst.pm","$projects_path\\$projectname\\config\\$projectname"."_ProjectConst.pm");

print "\nrewriting default_CFG.pm --> ";
open (IN, "<$projects_path\\$projectname\\config\\default_CFG.pm") or warn "could not open";
	@file=<IN>;
close(IN);
foreach $line (@file){
	$line =~ s/IC_default/IC_$projectname/;
	$line =~ s/EC_default/EC_$projectname/;
	$line =~ s/default_ProjectConst/\Q$projectname\E_ProjectConst/;
}
open (OUT, ">$projects_path\\$projectname\\config\\$projectname"."_CFG.pm");
	print OUT @file;
close(OUT);
print "done ! ";

print "\nrewriting IC_default.pm --> ";
open (IN, "<$projects_path\\$projectname\\config\\IC_default.pm");
	@file=<IN>;
close(IN);
foreach $line (@file){
	$line =~ s/IC_default/IC_$projectname/;
}
open (OUT, ">$projects_path\\$projectname\\config\\IC_$projectname.pm");
	print OUT @file;
close(OUT);
print "done ! ";

print "\nrewriting IC_default.par --> ";
open (IN, "<$projects_path\\$projectname\\config\\IC_default.par") or die "cannot open $projects_path\\$projectname\\config\\IC_default.par";
	@file=<IN>;
close(IN);
foreach $line (@file){
	$line =~ s/IC_default/IC_$projectname/;
}
open (OUT, ">$projects_path\\$projectname\\config\\IC_$projectname.par");
	print OUT @file;
close(OUT);
print "done ! ";

print "\nrewriting EC_default.pm --> ";
open (IN, "<$projects_path\\$projectname\\config\\EC_default.pm");
	@file=<IN>;
close(IN);
foreach $line (@file){
	$line =~ s/EC_default/EC_$projectname/;
}
open (OUT, ">$projects_path\\$projectname\\config\\EC_$projectname.pm");
	print OUT @file;
close(OUT);
print "done ! ";

unlink ("$projects_path\\$projectname\\config\\IC_default.pm","$projects_path\\$projectname\\config\\IC_default.par",
"$projects_path\\$projectname\\config\\EC_default.pm","$projects_path\\$projectname\\config\\default_CFG.pm");


## add files to sandbox
$cmd='si add --description="initial" -S '."$projects_path\\$projectname\\$projectname.pj"." $projects_path\\$projectname\\TCs\\TCs_Project\\readme_project.txt";
MKS_command($cmd);
$cmd='si add --description="initial" -S '."$projects_path\\$projectname\\$projectname.pj"." $projects_path\\$projectname\\Engine\\modules\\TC_FunctionLib\\readme_project.txt";
MKS_command($cmd);
$cmd='si add --description="initial" -S '."$projects_path\\$projectname\\$projectname.pj"." $projects_path\\$projectname\\Testlists\\empty.txt";
MKS_command($cmd);
$cmd='si add --description="initial" -S '."$projects_path\\$projectname\\$projectname.pj"." $projects_path\\$projectname\\run_empty.bat";
MKS_command($cmd);
$cmd='si add --description="initial" -S '."$projects_path\\$projectname\\$projectname.pj"." $projects_path\\$projectname\\TC_par\\readme.txt";
MKS_command($cmd);
$cmd='si add --description="initial" -S '."$projects_path\\$projectname\\$projectname.pj"." $projects_path\\$projectname\\reports\\readme.txt";
MKS_command($cmd);
$cmd='si add --description="initial" -S '."$projects_path\\$projectname\\$projectname.pj"." $projects_path\\$projectname\\config\\SW\\put_sw_files_here.txt";
MKS_command($cmd);

print"please add files in $projects_path\\$projectname\\config manually to MKS project\n";
print"and configure engine to checkpoint version\n";


system('pause');

###################
### subroutines ###
###################

sub MKS_command{
    my $cmd = shift;
    my @ret;
    
    print "executing <$cmd>\n";
    @ret = `$cmd`;
    print "ret < @ret >\n";
    
    return @ret;

}