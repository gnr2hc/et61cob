#!/usr/bin/perl
# *****************************************************************************************************
#                                                                                                       
#  Copyright (c) 2012  Robert Bosch GmBH                                                                
#                      Germany                                                                          
#                      All rights reserved                                                              
#                                                                                                       
#******************************************************************************************************
#    $Source: ParaGen/EDID_Mining_Reporter.pl $
#    $Revision: 1.1 $
#    $Author: VGR3KOR $
#    $State: develop $
#    $Date: 2012/08/30 18:12:02ICT $
#******************************************************************************************************

use strict;
use Tk;
use Win32::OLE;
use Win32::OLE::Const 'Microsoft Excel';
use Data::Dumper;

my %Excel_Col_info=();# Contains the Column names of EDID No, Data ele and Data Lenght
my ($scan_file,$sheetname); # Contains the excel file name and excel sheet name

###############################Start Tk Window################################

#Create Main window
my $mainwindow = new MainWindow;

#Size of main window display
$mainwindow->geometry("700x200");

###################Start Create frame in main window############################
my $Headframe = $mainwindow -> Frame()->pack(-padx=>10,-pady=>10); #Frame contains the heading lable
my $Fileframe = $mainwindow -> Frame()->pack(-padx=>8,-pady=>8); #Frame contains the excel book path components
my $Sheetframe = $mainwindow -> Frame()->pack(-padx=>8,-pady=>8); #Frame contains the excel sheet components
my $Dataframe = $mainwindow -> Frame()->pack(-padx=>8,-pady=>8); #Frame contains the excel column components
my $Buttonframe = $mainwindow -> Frame()->pack(-padx=>10,-pady=>10); #Frame contains the buttons
###################End Create frame in main window##############################

$Headframe->Label(-text => 'EDID Mining Reporter Information',-font=>"Verdana 12 bold italic underline")->pack();

####################Start --- Reading file name from the path ##################
$Fileframe->Label(-text => 'Excel Book path ')->pack(-side=>"left");
$Fileframe -> Entry("-width" => 50,"-textvariable" => \$scan_file,)->pack (-side=>"left");

$Fileframe -> Button
            ( "-text" => "Browse file",
			  "-command" => sub
				{
				  # browse for file
				  $scan_file = $mainwindow -> getOpenFile
					(
					"-filetypes"  =>
					  [
					  ["excel files 2003", '.xls'],
					  ["excel files 2007", '.xlsx'],
					  ["All files", '.*']
					  ],
					"-title"      => "choose one of the files to scan (*.xls)",
					);
				},
            )->pack (-side=>'left');
#################End --- Reading file name from the path #######################

#################Start --- Reading Sheet Name###################################
$Sheetframe->Label(-text => 'Excel Sheet Name ')->pack (-side=>"left");
$Sheetframe -> Entry("-width" => 30, "-textvariable" => \$sheetname,)->pack (-side=>"left");
#################End --- Reading Sheet Name###################################
			
#################Start --- Reading EDID No column Name##########################
$Dataframe->Label(-text => 'EDID No Column Name')->pack (-side=>"left");
$Dataframe -> Entry("-width" => 10,"-textvariable" => \$Excel_Col_info{'EDIDNo'},)->pack (-side=>"left");
#################End --- Reading EDID No column Name##########################

#################Start --- Reading Data Element column Name##########################
$Dataframe->Label(-text => 'Data Element Column Name')->pack (-side=>"left");
$Dataframe -> Entry("-width" => 10,"-textvariable" => \$Excel_Col_info{'DataElement'},)->pack (-side=>"left");
#################End --- Reading Data Element column Name##########################
		
#################Start --- Reading Data length column Name##########################
$Dataframe->Label(-text => 'Data length Column Name')->pack (-side=>"left");
$Dataframe -> Entry("-width" => 10,"-textvariable" => \$Excel_Col_info{'NoofBytes'},)->pack (-side=>"left");
#################End --- Reading Data length column Name##########################

#################Start --- reset button function #####################################
$Buttonframe -> Button
  (
  "-text" => "Reset",
  "-command" => sub
    { # execute when button is pressed  
        $scan_file = ""; # set scan_file to undefined
		$sheetname = "";
		$Excel_Col_info{'NoofBytes'}='';
		$Excel_Col_info{'DataElement'}='';
		$Excel_Col_info{'EDIDNo'}='';
    }
  )
->pack (-side=>"left");
#################End --- reset button function #####################################
print $Excel_Col_info{'DataElement'};
#################Start --- submit button function #####################################
$Buttonframe -> Button
  (
  "-text" => "Submit",
  "-command" => sub { # execute when button is pressed  
        if (defined($scan_file))
		 { # create project if scan_file was given
			&Read_EDID_Excel_Info($scan_file,$sheetname,\%Excel_Col_info);
			$scan_file = ""; # set scan_file to undefined
			exit(0);
		}
        else {
        # prompt user if scan_file is undefined
            $mainwindow->messageBox(
                '-icon'    => "error", #qw/error info question warning/
                '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
                '-message' => "!No file was selected, select an excel file!"
            );
        }
    }
  )
->pack (-side=>"left");
############End --- submit button function #####################################

############Start --- exit button function #####################################
$Buttonframe -> Button
  (
  "-text" => "Close",
  "-command" => sub
    { exit(0);}
  )->pack (-side=>"left");

##############End --- exit button function #####################################
 
&MainLoop;

###############################End Tk Window####################################

###################Start --- Reading the Excel file Information to Hash#########

################################################################################
#	Function name :: Read_EDID_Excel_Info
#
#	Read_EDID_Excel_Info($scan_file,$sheetname,\%Excel_Col_info)
#
#	Ex: Read_EDID_Excel_Info(testexcel.xls,sheet1,\%Excel_Col_info = { edidno => 'A', datalele => 'B', datalen =>'D'}))
#
#	Description:: This function reads the excel sheet which contains the information of the EDID mining record details.
#	Reads the EDID number, data element and data length of the data element to a hash.
################################################################################

sub Read_EDID_Excel_Info
{
	#Local Variables
	my (@filename_array) =(); # Holds the DataLength and EDID Number
	my ($EDID_Info_hash,$EDID_DataElement, $EDID_No, $EDID_Data_Length)=0;
	my ($row, $Excel, $filepath, $excelsheetname) = 0;
	my (@error_messages,%EDID_ExcelData);

	$filepath = shift; #Contains filename from the passed arguments
	$excelsheetname = shift; #Contains sheet name from the passed arguments
	$EDID_Info_hash = shift; #Contains column details from the passed arguments
	
	#Checking Whether given input is an excel file or not
	@filename_array = split(/[\/]/,$filepath); 
	
	unless($filename_array[$#filename_array] =~ /\.xl(s|sx)$/)
	{
		print "Given file is not the excel file -- $filepath \n";
		exit(0);
	}
	
	#Checking whether excel sheet name is given or not
	unless(defined($excelsheetname)) {
		print "Excel sheet name is not given\n";
		exit(0);
	}
	
	#Checking whether EDID number column name is given or not
	unless(defined($$EDID_Info_hash{'EDIDNo'})) {
		print "EDID number column name is not given\n";
		exit(0);
	}
	
	#Checking whether Data element column name is given or not
	unless(defined($$EDID_Info_hash{'DataElement'})) {
		print "Data element column name is not given\n";
		exit(0);
	}
	
	#Checking whether Data length column name is given or not
	unless(defined($$EDID_Info_hash{'NoofBytes'})) {
		print "Data length column name is not given\n";
		exit(0);
	}
	#Opens a New Excel application or returns the reference of activated excel application
	$Excel = Win32::OLE->GetActiveObject('Excel.Application') ||
		   Win32::OLE->new('Excel.Application');
	$Excel->{'Visible'} = 1;        #0 is hidden, 1 is visible
	$Excel->{DisplayAlerts}=1;  #0 is hide alerts

	# Open File and Worksheet
	my $Book = $Excel->Workbooks->Open($filepath) || die "Unable to open the workbook Book1.xls -- $!"; # open Excel file
	my $Sheet = $Book->Worksheets($excelsheetname);
	
	# Refresh Data (ActiveWorkbook.RefreshAll)
	$Book->RefreshAll();

	# Find Last Filled Column and Row
	my $LastRow = $Sheet->UsedRange->Rows->{'Count'};
	my $LastCol = $Sheet->UsedRange->Columns->{'Count'};
   	#Checking whether the sheet contains the info or not
	if($LastRow == "1" and $LastCol == "1")
	{
		print "No data to be read in Excel worksheet\n";
		exit(0);
	}
	
	#Reads the EDID Number, Data and DataLenght(in Bytes) from excel and
	#Writes the value into the hash. Data as key; number and length as value.
	for($row = 9; $row <=$LastRow; $row++)
	{
		$EDID_No = $Sheet->Cells($row,$$EDID_Info_hash{'EDIDNo'})->{'Value'};
		if($EDID_No eq '')
		{
			push(@error_messages, "No EDID number to read in Row No -- $row<br/>");
			next;
		}
		
		$EDID_DataElement = $Sheet->Cells($row,$$EDID_Info_hash{'DataElement'})->{'Value'};
		$EDID_DataElement =~ s/\n/ /g;
		$EDID_DataElement =~ s/ +/ /g;
		unless(defined($EDID_DataElement))
		{
			push(@error_messages, "No EDID data to read for EDID No -- $EDID_No <br/>");
			$EDID_DataElement = undef;
		}
	
		$EDID_Data_Length = $Sheet->Cells($row,$$EDID_Info_hash{'NoofBytes'})->{'Value'};
		unless(defined($EDID_Data_Length))
		{
			push(@error_messages, "No EDID data length to read for EDID No -- $EDID_No<br/>");
			$EDID_Data_Length = 0;
		}
		$EDID_ExcelData{$EDID_No} = [$EDID_DataElement, $EDID_Data_Length];
	}
	
	#Checking for information in EDID_ExcelData hash
	unless(keys %EDID_ExcelData)
	{
		print "No data read from the excel worksheet. Excel sheet is empty\n";
		exit(0);
	}
	
	#Closure of Excel application
	$Book->Close();
	$Excel->Quit();
	
	$Data::Dumper::Varname = "CrashInfo";
	open(FIL, ">excel_info_hash.pm");
	print FIL 'package ExcelInfo;',"\n\n";
	print FIL Dumper(\%EDID_ExcelData);
	close(FIL);
}
###################End --- Reading the Excel file Information to Hash#######


=head1 USAGE


This GUI reads the excel file which contains the information of the crash file,
such as EDID Number, Data element and Data lenght of the data element and generates the hash.
						
						
The multi space and new line in the data element which read from excel sheet replaced with single space.
						
						
Input(s):
---------
 Excel Book path :: Excel file name should select by click "Browse file" button
 Excel Sheet Name :: Sheet name should be given. Sheet name is case sensitive (Ex:Sheet1)
 EDID No Column Name :: Column name in which EDID number is present. Column Name should be in Capital letter (Ex: A). Only Alphabets are allowed.
 Data Element Column Name :: Column name in which Data Element is present. Column Name should be in Capital letter (Ex: A). Only Alphabets are allowed. 
 Data length Column Name :: Column name in which Data length is present. Column Name should be in Capital letter (Ex: A). Only Alphabets are allowed.
						
						
Error Message(s):
-----------------
Dialogue box appears with a error message when a file is not selected in the GUI.
						
						
Example:
--------
HashReference = {
                'EDID_No' => [
                          'Data element',
                          'Data length'
						],
						.
						.
						.
						.
						.
						.
                'EDID_No' => [
                          'Data element',
                          'Data length'
                        ]
              };
						
						
Example:
--------
$CrashInfo1 = {
                '54' => [
                          'Frontal air bag, 2nd stage disposal, driver',
                          '1'
						],
						.
						.
						.
						.
						.
						.
                '52' => [
                          'Frontal air bag, time to 2nd stage deployment, driver',
                          '2'
                        ]
              };
						

Note::No default values are given.

=head1 AUTHOR

G V Sriram, E<lt>VeerabhadraSriram.Grandhi@in.bosch.comE<gt>

=cut
