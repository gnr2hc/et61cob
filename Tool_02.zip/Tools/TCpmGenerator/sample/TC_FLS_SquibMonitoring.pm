#### TEST CASE MODULE
package TC_FLS_SquibMonitoring;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER = q$Header: TCpmGenerator/sample/TC_FLS_SquibMonitoring.pm 1.1 2013/07/31 00:03:35ICT Reddivari Devendra Kumar (RBEI/ESA-PP) (dvn2kor) develop  $;

#### INCLUDE MODULES ####

use LIFT_general;
use FuncLib_GEN_TNT;
use INCLUDES_Project; #necessary
do "INCLUDES_Project.pm"; #necessary

##################################

our $PURPOSE = "<summarize what this test is good for>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_FLS_SquibMonitoring

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Create <condition>

2. Create <fault> on <squib>

3. Wait for <qualitime> and read the fault recorder

4. Remove <fault> on <squib>

5. Wait for <dequalitime> and read the fault recorder


I<B<Evaluation>>

3. expected faults: <FLTmand_createFault>

5. expected faults: <FLTmand_removeFault>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'squib' => 
	SCALAR 'condition' => 
	SCALAR 'fault' => 
	SCALAR 'qualitime' => 
	SCALAR 'dequalitime' => 
	HASH 'FLTmand_createFault' => 
	HASH 'FLTmand_removeFault' => 


=head2 PARAMETER EXAMPLES

	purpose	= 'to check the squib monitoring requirements under normal condition - HighSide Short2Bat fault'
	
	squib = '<Test Heading>'
	condition = 'normal' #normal condition
	fault = 'Short2Bat_highSide'
	qualitime = '6000' #ms
	dequalitime = '6000' #ms
	
	FLTmand_createFault = %('fls_Short2Bat_FAULT' => '0bxxxxx111')
	FLTmand_removeFault = %('fls_Short2Bat_FAULT' => '0bxxxxx110')

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $defaultpar_purpose;
my $defaultpar_squib;
my $defaultpar_condition;
my $defaultpar_fault;
my $defaultpar_qualitime;
my $defaultpar_dequalitime;
my $defaultpar_FLTmand_createFault;
my $defaultpar_FLTmand_removeFault;

################ global parameter declaration ###################
#add any global variables here


###############################################################

sub TC_set_parameters {

	$defaultpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	$defaultpar_squib =  GEN_Read_mandatory_testcase_parameter( 'squib' );
	$defaultpar_condition =  GEN_Read_mandatory_testcase_parameter( 'condition' );
	$defaultpar_fault =  GEN_Read_mandatory_testcase_parameter( 'fault' );
	$defaultpar_qualitime =  GEN_Read_mandatory_testcase_parameter( 'qualitime' );
	$defaultpar_dequalitime =  GEN_Read_mandatory_testcase_parameter( 'dequalitime' );
	$defaultpar_FLTmand_createFault =  GEN_Read_mandatory_testcase_parameter( 'FLTmand_createFault' );
	$defaultpar_FLTmand_removeFault =  GEN_Read_mandatory_testcase_parameter( 'FLTmand_removeFault' );

	return 1;
}

sub TC_initialization {

	S_w2rep("StandardPrepNoFault",'blue');

	return 1;
}

sub TC_stimulation_and_measurement {

	S_w2rep("Step 1. Create <condition>",'blue');

	S_w2rep("Step 2. Create <fault> on <squib>",'blue');

	S_w2rep("Step 3. Wait for <qualitime> and read the fault recorder",'blue');

	S_w2rep("Step 4. Remove <fault> on <squib>",'blue');

	S_w2rep("Step 5. Wait for <dequalitime> and read the fault recorder",'blue');

	return 1;
}

sub TC_evaluation {

	S_w2rep("Step 3. expected faults: <FLTmand_createFault>",'blue');

	S_w2rep("Step 5. expected faults: <FLTmand_removeFault>",'blue');

	return 1;
}

sub TC_finalization {

	return 1;
}


1;
