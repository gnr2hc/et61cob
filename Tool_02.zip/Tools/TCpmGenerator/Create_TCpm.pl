#!perl -w

#****************************************************************************************************
#                                                                           						*
# Copyright (c) 2013 Robert Bosch GmbH, Germany                             						*
#               All rights reserved                                         						*
#                                                                           						*
#****************************************************************************************************
# $Author: ver6cob $                         						*
# $Revision : 1.0 $        																			*
#                     																				*
#****************************************************************************************************

use strict;
use warnings;
use Tk;
use Tk::Frame;
use Win32::File;
use File::Copy;
use File::Basename;
use Win32::OLE;
use Win32::OLE::Const;
use File::Find;
use File::Path;
use Getopt::Long;
use File::Glob ':glob';
use Cwd; 
use Tk::LabFrame;
use File::Copy qw(copy);
my $LOOKUP_table;

sub Creatre_About_Window(){
	my $mw = MainWindow->new("-background" => "#888888");
	$mw->minsize(100,25);
	$mw->title("Help");

	#Making a text area
	my $txt = $mw -> Scrolled('Text',-width => 100,-scrollbars=>'e') -> pack ();

	$txt->delete('1.0','end');
		$txt->insert('end','
#	
#
#	DESCRIPTION:                               
#	This tool will generate a skeleton TC pm file from an exported Test Specification             
#
#	FOLLOW THESE STEPS:
#	1. Export TS to excel sheet: TS->File->Export->Microsoft Office->Excel..
#	2. Select this file and click GENERATE                                
#  
#	REMARKS:                                    
#	1. Perl Version 5.12 32 bit(installed using Peacy package) is required
#	2. Perl TK is to be installed                
#                                       
	'
	);

}
my ($main,$end_frame,$path_frame_xls,$path_frame_template,$entry);
my ($Designation_path,$ExcelFile_Name_Path,$templateFile_Name_Path,@File_Select_Arr,$status,);
my ($EDID_Start_Byte_From_Panel,$input_excel_File_Name,$input_template_File_Name,$EDR_Service_IDs,$Diag_Request_ID_From_Panel,$Diag_Response_ID_From_Panel);
my  @EDR_Services_DID_Array ;
my $DID_Value;
# Default Designation Path
$Designation_path='C:';
my  $TK_ERROR_INDICATION_FLAG_i=0;
my $project_name ="";
$main = MainWindow->new("-background" => "DodgerBlue1");

# Size to the TK window 
$main->minsize(450,100);

$main->title("TC pm file Generator");
# Get the current path 
my $pwd = cwd();
#print "$pwd","\n";
my @path_structure;
@path_structure =split(/\//,$pwd); 
# Remove the last Folder 
#pop(@path_structure);
# Add the string with \\ to get the complete path
my $File_With_Path=join("\\",@path_structure);
print "File_With_Path =$File_With_Path","\n";
$pwd =~ s/\//\\/g;
$pwd =~ s/\//\\/;

#Remove the files if is already present in the canoe folder
  

#Declare that there is a menu
my $mbar = $main -> Menu();
$main -> configure(-menu => $mbar);

#The Main Buttons
my $file = $mbar -> cascade(-label=>"File", -underline=>0, -tearoff => 0);
my $help = $mbar -> cascade(-label =>"Help", -underline=>0, -tearoff => 0);


## File Menu ##
$file -> command(-label =>"Exit", -underline => 1,
        -command => sub { exit } );
 
#******************************************************************************************** 
$help -> command(-label =>"ReadMe",  -command=>sub {Creatre_About_Window()});

$main->Label(
    -text=>'TC pm file Generator',
    -font=>'{Segoe UI light} 20',
    -background => 'DodgerBlue1',
    -foreground => 'white',
    -height=>'001')->pack(-side=>'top',-pady=>'003');




 my $labeled_frame1   = $main->Frame(-borderwidth => 2, 
                                 -relief => 'groove',
                                 -background => "DodgerBlue1",
                                 )->pack(-side => "top",-padx=>'150',-anchor=>'nw');


#my $shot = $main->Photo(-file => "$File_With_Path\\logo\\AUDI.gif");
#$main->Label(-image => $shot)->pack(-side => 'top');
 $main->Label(
            -text=>'Select the excel file (exported from the TS)',
            -font=>'{Segoe UI light} 11 ',
            -background => "DodgerBlue1",
            -foreground => "white",
             )->pack(-side=>'top',-pady=>'02',-side=>'top');

$path_frame_xls = $main->Frame("-background" => "DodgerBlue1")->pack(-pady=>'1',-padx=>'05', -anchor=>'nw' );
$path_frame_template = $main->Frame("-background" => "DodgerBlue1")->pack(-pady=>'1',-padx=>'05', -anchor=>'nw' );

$path_frame_xls->Label(
        -text=>'Load File',
        -background => "DodgerBlue1",
         -foreground => "white",
        -font=>'{Segoe UI light} 11 ')->pack(-side=>'left');
        
$status= ' Not Started';
$entry = $path_frame_xls->Entry(
        -width=>'50',
        -textvariable=>\$ExcelFile_Name_Path,
        -background => "grey",
        -foreground  => "black",
        )->pack(-side=>'left',
                -pady=>'0');

                $path_frame_xls->Button(
                        -text=>"Browse",
                        -width=>'7',
                        -relief => 'groove',
                        -background => "orange",
                        -foreground  => "white",
                         -font=>'{Segoe UI light} 12',
                        -command=>sub
                        {
                            $ExcelFile_Name_Path = $main->getOpenFile(
                                        -filetypes=>[
                                            ["xls xlsx files", ['.xlsx', '.xls'] ],
											["xls xlsx files", ['.xlsx', '.xls'] ],
                                       ],
                                        -title=>"Choose the xls file ",
                        );
                
                            if($ExcelFile_Name_Path)
                            {
                               @File_Select_Arr=split(/\[/, $ExcelFile_Name_Path);
                               $input_excel_File_Name=$File_Select_Arr[-1];
                               print "Excel File Name =$input_excel_File_Name";
                               $Designation_path = dirname($ExcelFile_Name_Path); 
                               $Designation_path=$Designation_path."/";
                             
                            }
                                                    
                        }
        )->pack(-side => "right",-padx=>'05',-pady=>'03');


$end_frame = $main->Frame("-background" => "DodgerBlue1")->pack(-ipadx=>'10', -padx=>'2');
$end_frame->Button(
        -text=>'Exit',
        -width=>'8',
        -font=>'{Segoe UI light} 12 ',
         -background => "orange",
         -foreground => "white",
          -relief => 'groove',
        -command=>[$main=>'destroy']
        )->pack(-pady=> 10,  -side=>'right');


$end_frame->Button(
        -text=>'Generate',
        -width=>'8',
        -font=>'{Segoe UI light} 12 ',
		-background => "orange",
        -foreground => "white",
        -relief => 'groove',
        -command=>sub {Generate_File()}
        )->pack(-pady=> 10, -padx=> 10,  -side=>'right');   
        
 # create label in window 'main'
 $main -> Label(
        -textvariable => \$status, #reference to display the status
         -font=>'{Segoe UI light} 11',
        -background  => "DodgerBlue1",
        -foreground  => "gray90",
        )-> pack( "-pady" => 6,-side=>'top' );
        
MainLoop;

 
  
sub Generate_File(){   

    #@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    #            Error Handling from the GUI   
    #@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    if(!$input_excel_File_Name){
       	$status= "Select the excel file !!"; 
		$main->update();
		die("excel file $input_excel_File_Name is not found!\n");
    }
	else{
		$status= ' Not Started ';
		$main->update();
			   
		#SheetName of the Exported Decoder sheet
		my %input_data_Sheet = (
								'in_Data1'=>"Tabelle1",
								'in_Data2'=>"sheet1",
								);	
								
		require "Create_TCpm_Lookuptable.pm";
		$LOOKUP_table = $CREATE_TCPM_LOOKUP::TABLE;														
	
		my (@error_messages,@warning_messages);
		my $excel;
		my $input_WorkBook;
		my $input_WorkSheet;
		
		my $xls_TestHeading_column;
		my $xls_TestPreparation_column;
		my $xls_TestSpecification_column;
		my $xls_ExpectedResults_column;
		my $xls_ID_column;

		my @datavaluelines;

		# Open the xls using the WIN OLE package  
		use Win32::OLE qw(in with);
		use Win32::OLE::Const 'Microsoft Excel';
		$Win32::OLE::Warn = 3;

		# get already active Excel application or open new
		$excel = Win32::OLE->GetActiveObject('Excel.Application') || Win32::OLE->new('Excel.Application', 'Quit');  
		#$excel->{DisplayAlerts}=0;
		#$excel->{Visible} =1;

		# open Excel file which comtain  the decoder information 
		$input_WorkBook = $excel->Workbooks->Open("$input_excel_File_Name");
		# select workSheet number 1 (you can also select a workSheet by name)
		
		$input_WorkSheet = $input_WorkBook->Worksheets(1);
		
				
		#^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ Finding the Last Row and Coloumn of the doors Document ^^^^^^^^^^^^^^^^^^^^^^^^
		my $LastRow_input_data = $input_WorkSheet->UsedRange->Find({What=>"*",
		SearchDirection=>xlPrevious,
		SearchOrder=>xlByRows})->{Row};
		print "\nLast Row of input file =",$LastRow_input_data,"\n";
		
		my $LastColoumn_input_data = $input_WorkSheet->UsedRange->Find({What=>"*",
		SearchDirection=>xlPrevious,
		SearchOrder=>xlByColumns})->{Column};
		print "\nLast Coloumn of input file =",$LastColoumn_input_data,"\n";
					
		#^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^Declaration for  the coloumn cells of doors doccuments  ^^^^^^^^^^^^^^^^^^^^^^^^
				
		#^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^Status update in the GUI Window ^^^^^^^^^^^^^^^^^^^^^^^^       
		$status = "Conversion in progress!!!.";
		$main->update();
				
		#^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^Assigning the coloumn attrributes for  the column cells of doors doccuments  ^^^^^^^^^^^^^^^^^^^^^^^^
		my $Header_Filter_Row =1;
		my $column =1;
		my $column_Read;
		foreach $column(1..$LastColoumn_input_data){
			$column_Read=""; # clear the old data 
			# Read the bit byte cell value from xls File 
			$column_Read =$input_WorkSheet->Cells($Header_Filter_Row,$column)->{'Value'};
			
			if($column_Read =~ m/Test Heading/i){
				$xls_TestHeading_column = $column;
			}
			elsif($column_Read =~ m/Test Preparation/i){
				$xls_TestPreparation_column = $column;
			}
			elsif($column_Read =~ m/Test Specification/i){
				$xls_TestSpecification_column = $column;
			}
			elsif($column_Read =~ m/Expected Result/i){
				$xls_ExpectedResults_column = $column;
			}
			elsif($column_Read =~ m/ID/i){
				$xls_ID_column = $column;
			}
		}	
		#++++++++++++++++++++++++++++++++++++++++++++++++++++++

		# check if all expected columns are present in excel sheet
		unless (defined $xls_TestHeading_column){
			push(@error_messages,  "'Test Heading' column is missing. Please make sure the headings of each column are imported from the TS\n");
		}
		unless (defined $xls_TestPreparation_column){
			push(@error_messages,  "'Test Preparation' column is missing. Please make sure the headings of each column are imported from the TS\n");
		}
		unless (defined $xls_TestSpecification_column){
			push(@error_messages,  "'Data Length (Byte)' column is missing. Please make sure the headings of each column are imported from the TS\n");
		}
		unless (defined $xls_ExpectedResults_column){
			push(@error_messages,  "'Test Specification' column is missing. Please make sure the headings of each column are imported from the TS\n");
		}
		unless (defined $xls_ID_column){
			push(@error_messages,  "'ID' column is missing. Please make sure the headings of each column are imported from the TS\n");
		}		
		#++++++++++++++++++++++++++++++++++++++++++++++++++++++
		
		
		#++++++++++++++++++++++++++++create the EDID list HASH+++++++++++++++++++++++++++++++++++++++				
		my ($xls_TestHeading_read,
			$xls_TestPreparation_read, 
			$xls_TestSpecification_read,
			$xls_ExpectedResults_read,
			$xls_TCName_read,
			$xls_DefaultParameters_read,
			$xls_TCParameters_read,
			$xls_ParameterDescription_read,
			$xls_ID_read,
			
			$xls_LIFT_TCdefinition_row,
			$xls_LIFT_DefaultParameters_row,
			$xls_LIFT_TCParameters_row,
			$xls_LIFT_TCName_row,
			
			$TCname,
		);
		
		open (ERRORLOG,">ErrorLog.txt") || die("ErrorLog.txt could not be created!\n");  
							
		foreach my $row(2..$LastRow_input_data){
			my (@keys,@values);
			my $count = 0;
			
			$xls_TestHeading_read  =$input_WorkSheet->Cells($row,$xls_TestHeading_column)->{'Value'} if defined $xls_TestHeading_column;
																										
			if (defined $xls_TestHeading_read and $xls_TestHeading_read =~ m/Test Case Definition/i){   
				$xls_LIFT_TCdefinition_row = $row;
				$xls_LIFT_TCName_row = $row+1;
				$xls_LIFT_DefaultParameters_row = $row+2;
				$xls_LIFT_TCParameters_row = $row+3;
				
				$xls_ID_read =$input_WorkSheet->Cells($xls_LIFT_TCdefinition_row,$xls_ID_column)->{'Value'} if defined $xls_ID_column;
				$xls_TestHeading_read =$input_WorkSheet->Cells($xls_LIFT_TCName_row,$xls_TestHeading_column)->{'Value'} if defined $xls_TestHeading_column;
				unless($xls_TestHeading_read =~ m/LIFT Test Case Name/){
					$xls_LIFT_TCName_row++;
					$xls_TestHeading_read =$input_WorkSheet->Cells($xls_LIFT_TCName_row,$xls_TestHeading_column)->{'Value'} if defined $xls_TestHeading_column;
					unless($xls_TestHeading_read =~ m/LIFT Test Case Name/){
						$xls_LIFT_TCName_row++;
						$xls_TestHeading_read =$input_WorkSheet->Cells($xls_LIFT_TCName_row,$xls_TestHeading_column)->{'Value'} if defined $xls_TestHeading_column;
					}
				}
				$xls_TCName_read =$input_WorkSheet->Cells($xls_LIFT_TCName_row,$xls_TestPreparation_column)->{'Value'} if (defined $xls_TestPreparation_column and $xls_TestHeading_read =~ m/LIFT Test Case Name/i);
				
				unless(defined $xls_TCName_read){
					push(@error_messages,  "LIFT Test Case Name corresponding to definition in ID $xls_ID_read is missing\n");
				}
				
				if(defined $xls_TCName_read){
					if($xls_TCName_read =~ /\./){
						print $xls_TCName_read;
						my @names = split(/\./, $xls_TCName_read);
						print $names[0];
						print $names[1];
						$xls_TCName_read = $names[0];
					}
					chomp($xls_TCName_read);
					print $xls_TCName_read;
					
					$TCname = $xls_TCName_read; # chomp($xls_TCName_read);
					print $TCname;
					                      	
					$xls_TestPreparation_read =$input_WorkSheet->Cells($xls_LIFT_TCdefinition_row,$xls_TestPreparation_column)->{'Value'} if defined $xls_TestPreparation_column;
					$xls_TestSpecification_read =$input_WorkSheet->Cells($xls_LIFT_TCdefinition_row,$xls_TestSpecification_column)->{'Value'} if defined $xls_TestSpecification_column;
					$xls_ExpectedResults_read =$input_WorkSheet->Cells($xls_LIFT_TCdefinition_row,$xls_ExpectedResults_column)->{'Value'} if defined $xls_ExpectedResults_column;
					
					$xls_TestHeading_read =$input_WorkSheet->Cells($xls_LIFT_DefaultParameters_row,$xls_TestHeading_column)->{'Value'} if defined $xls_TestHeading_column;
					unless($xls_TestHeading_read =~ m/LIFT Default Parameters/){
						$xls_LIFT_DefaultParameters_row++;
						$xls_TestHeading_read =$input_WorkSheet->Cells($xls_LIFT_DefaultParameters_row,$xls_TestHeading_column)->{'Value'} if defined $xls_TestHeading_column;
						unless($xls_TestHeading_read =~ m/LIFT Default Parameters/){
							$xls_LIFT_DefaultParameters_row++;
							$xls_TestHeading_read =$input_WorkSheet->Cells($xls_LIFT_DefaultParameters_row,$xls_TestHeading_column)->{'Value'} if defined $xls_TestHeading_column;
						}
					}				
					$xls_DefaultParameters_read =$input_WorkSheet->Cells($xls_LIFT_DefaultParameters_row,$xls_TestPreparation_column)->{'Value'} if defined $xls_TestPreparation_column;
					
					unless(defined $xls_DefaultParameters_read){
						push(@error_messages,  "LIFT Default Parameters corresponding to definition in ID $xls_ID_read is missing\n");
					}
						
					$xls_ParameterDescription_read = $input_WorkSheet->Cells($xls_LIFT_DefaultParameters_row,$xls_TestSpecification_column)->{'Value'} if defined $xls_TestSpecification_column;
					
					$xls_TestHeading_read =$input_WorkSheet->Cells($xls_LIFT_TCParameters_row,$xls_TestHeading_column)->{'Value'} if defined $xls_TestHeading_column;
					unless($xls_TestHeading_read =~ m/LIFT Test Case Parameters/){
						$xls_LIFT_TCParameters_row++;
						$xls_TestHeading_read =$input_WorkSheet->Cells($xls_LIFT_TCParameters_row,$xls_TestHeading_column)->{'Value'} if defined $xls_TestHeading_column;
						unless($xls_TestHeading_read =~ m/LIFT Test Case Parameters/){
							$xls_LIFT_TCParameters_row++;
							$xls_TestHeading_read =$input_WorkSheet->Cells($xls_LIFT_TCParameters_row,$xls_TestHeading_column)->{'Value'} if defined $xls_TestHeading_column;
						}
					}
					$xls_LIFT_TCParameters_row++;
					$xls_TCParameters_read = $input_WorkSheet->Cells($xls_LIFT_TCParameters_row,$xls_TestPreparation_column)->{'Value'} if defined $xls_TestPreparation_column;				
					
					my @TestPreparation;
					my @TestSpecification;
					my @ExpectedResult;
					my @DefaultParameters;
					my @TCParameters;
					my @parname;
					my @defaultParameterLabels;
					my @TCParameterLabels;
					my @allParameters;
					my $partype;
					
					@TestPreparation = split('\n', $xls_TestPreparation_read);
					chomp(@TestPreparation);

					@TestSpecification = split('\n', $xls_TestSpecification_read);
					chomp(@TestSpecification);

					@ExpectedResult = split('\n', $xls_ExpectedResults_read);
					chomp(@ExpectedResult);
					
					@DefaultParameters = split('\n', $xls_DefaultParameters_read);
					chomp(@DefaultParameters);
					
					@TCParameters = split('\n', $xls_TCParameters_read);
					chomp(@TCParameters);
					
					open (TCFILE,">$TCname".".pm") || die("$TCname".".pm could not be created!\n");  

					print TCFILE "#### TEST CASE MODULE\n";
					print TCFILE "package $TCname;\n\n";
					print TCFILE "#### DONT MODIFY THIS SECTION ####\n";
					print TCFILE "use strict;\n";
					print TCFILE "use warnings;\n\n";
					print TCFILE "###-------------------------------###\n";
					print TCFILE 'our $VERSION = q$Revision: 1.11 $;';
					print TCFILE "\n";
					print TCFILE 'our $HEADER = q$Header: TCpmGenerator/Create_TCpm.pl 1.11 2014/06/18 16:51:03ICT ver6cob develop  $;';
					print TCFILE "\n\n";
					print TCFILE "#----------------------- TEST SPECIFICATION ------------------------------\n";
					print TCFILE "#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)\n";
					print TCFILE "#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)\n";
					print TCFILE "#-------------------------------------------------------------------------\n";
					print TCFILE "\n";
					print TCFILE "#### INCLUDE ENGINE MODULES ####\n\n";
					print TCFILE "use LIFT_general;\n";
					print TCFILE "use INCLUDES_Project; #necessary\n";
					print TCFILE "#include further modules here";
					print TCFILE "\n\n";
					print TCFILE "##################################\n\n";
					print TCFILE 'our $PURPOSE = "<summarize what this test is good for>";';
					print TCFILE "\n\n";
					print TCFILE "#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n\n";	
					print TCFILE "=head1 TESTCASE MODULE\n\n";
					print TCFILE "$TCname\n\n";
					print TCFILE "=head1 PURPOSE\n\n";
					print TCFILE "<explain what this test is good for>\n\n";
					print TCFILE "=head1 TESTCASE DESCRIPTION\n\n";
					print TCFILE "\nI<B<Initialisation>>\n\n";
					foreach my $line (@TestPreparation){
						printLineWithNewLine($line);						
					}
					print TCFILE "\nI<B<Stimulation and Measurement>>\n\n";
					foreach my $line (@TestSpecification){
						printLineWithNewLine($line);
					}
					print TCFILE "\nI<B<Evaluation>>\n\n";
					foreach my $line (@ExpectedResult){
						printLineWithNewLine($line);
					}
					print TCFILE "\nI<B<Finalisation>>\n\n";
					print TCFILE "Reset/Remove the test condition created in test case\n\n\n";
					
					print TCFILE "=head1 PARAMETER DESCRIPTION\n\n";
					print TCFILE "\n=head2 PARAMETER NAMES\n\n";					
					foreach my $line (@TCParameters){
						my ($parname, $partype) = checkParameter ($line);
						push(@TCParameterLabels,$parname);
						push(@allParameters, $parname);
						printParaDocuLine($partype,$parname);
					}
					foreach my $line (@DefaultParameters){
						my ($parname, $partype) = checkParameter ($line);
						unless (grep $_ eq $parname, @TCParameterLabels){ #check if this default parameter is not present in test case parameters
							push(@defaultParameterLabels,$parname);
							push(@allParameters, $parname);
							printParaDocuLine($partype,$parname);
						}
					}
					
					print TCFILE "\n\n=head2 PARAMETER EXAMPLES\n\n";
					foreach my $line (@DefaultParameters){
						my ($parname, $partype) = checkParameter ($line);
						printLine("\t".$line) if (grep $_ eq $parname, @defaultParameterLabels); #print only if this parameter is not also a test case parameter
					}
					foreach my $line (@TCParameters){
						printLine("\t".$line);
					}
					print TCFILE "\n=cut\n\n";
					
					print TCFILE "\n\n#PARAMETERS\n";
					print TCFILE "################ Parameters from .par file ###################\n";
					foreach my $line (@defaultParameterLabels){												
						printDefaultParameter($line);
					}
					foreach my $line (@TCParameterLabels){						
						printTCParameter($line);
					}
					print TCFILE "\n################ global parameter declaration ###################\n";
					print TCFILE "#add any global variables here\n";
					print TCFILE "\n\n###############################################################\n\n";
					
					print TCFILE "sub TC_set_parameters {\n\n";
					foreach my $line (@defaultParameterLabels){						
						printReadDefaultParameter($line);					
					}
					foreach my $line (@TCParameterLabels){
						printReadTCParameter($line);					
					}
					print TCFILE "\n\treturn 1;\n";
					print TCFILE "}\n\n";
					
					print TCFILE "sub TC_initialization {\n\n";
					foreach my $line (@TestPreparation){
						#if line contains a parameter <par> replace it with the variable $tcpar_par (if par is a valid parameter)
						$line =~ s/\<(.*?)\>/\'\$tcpar_$1\'/g; # if (grep $_ eq $1, @allParameters);
						printTestStep($line);						
					}
					print TCFILE "\treturn 1;\n";
					print TCFILE "}\n\n";
					
					print TCFILE "sub TC_stimulation_and_measurement {\n\n";
					foreach my $line (@TestSpecification){
						#if line contains a parameter <par> replace it with the variable $tcpar_par (if par is a valid parameter)
						$line =~ s/\<(.*?)\>/\'\$tcpar_$1\'/g; # if (grep $_ eq $1, @allParameters);
						printTestStep($line);	
					}
					print TCFILE "\treturn 1;\n";
					print TCFILE "}\n\n";
					
					print TCFILE "sub TC_evaluation {\n\n";
					foreach my $line (@ExpectedResult){
						#if line contains a parameter <par> replace it with the variable $tcpar_par (if par is a valid parameter)
						$line =~ s/\<(.*?)\>/\'\$tcpar_$1\'/g; # if (grep $_ eq $1, @allParameters);
						printTestStep($line, 'eval');	
					}
					print TCFILE "\treturn 1;\n";
					print TCFILE "}\n\n";
					
					print TCFILE "sub TC_finalization {\n\n";
					print TCFILE "\treturn 1;\n";
					print TCFILE "}\n\n";
					
					print TCFILE "\n1;\n";
					close TCFILE;
				}				     
			}				                   
		}
		
		$input_WorkBook->Close(); 
		
		my $errorcount = 0;
		print ERRORLOG "!!!!!!!!!!!!!!!!!!!!!!!!ERRORS!!!!!!!!!!!!!!!!!!!!!!!!\n\n";
		if(defined $error_messages[0]){
			foreach my $error (@error_messages){
				$errorcount++;
				print ERRORLOG "$errorcount. $error";
			}
		}
		else{
			print ERRORLOG "No Errors! :-)";
		}
		
		my $warningcount = 0;
		print ERRORLOG "\n\n!!!!!!!!!!!!!!!!!!!!!!!!WARNINGS!!!!!!!!!!!!!!!!!!!!!!\n\n";
		if(defined $warning_messages[0]){
			foreach my $warning (@warning_messages){
				$warningcount++;
				print ERRORLOG "$warningcount. $warning";
			}
		}
		else{
			print ERRORLOG "No Warnings! :-)";
		}	
				  
		##################  Save File is completed ###############################       
	}	
    
    
    close ERRORLOG;
    
    $status= "Completed Press Exit! \nHave a look at ErrorLog.txt file for Errors and Warnings";
    $main->update(); # sub 

}

sub printTestStep{
	my $line = shift;
	my $mode = shift;
	
	chomp($line);
	if($line ne '' and $line ne '\n'){
		if($line =~ /^\d/){
			if (defined $mode and $mode eq 'eval'){
				print TCFILE "\tGEN_printTestStep(\"Evaluation for Step $line\");\n";
			}
			else{
				print TCFILE "\tGEN_printTestStep(\"Step $line\");\n";
			}		
		}
		else{
			print TCFILE "\tGEN_printTestStep(\"$line\");\n";
		}
		
		#use look up table to print the function name and arguments too!!
		if($line =~ m/\[(.*?)\]/i){ #e.g. [ readDataByIdentifier:: ActiveSession ]
			my $functionkeyword = $1;
			my $parameterkeyword = $functionkeyword;
			$functionkeyword =~ s/^\s*(.*?)\s*\:\:\s*(.*?)\s*$/$1/i; #get function keyword i.e. readDataByIdentifier
			$parameterkeyword =~ s/^\s*(.*?)\s*\:\:\s*(.*?)\s*$/$2/i; #get parameter keyword i.e. ActiveSession
			#print TCFILE "$functionkeyword $parameterkeyword" ; #debugging
			
			my $functionName = $LOOKUP_table->{'KEYWORD'}{$functionkeyword}{'FunctionName'};
			my $parName;
			if ($parameterkeyword =~ m/\$tcpar_/i){
				$parName = $parameterkeyword;
			}
			else{
				$parName = $LOOKUP_table->{'KEYWORD'}{$functionkeyword}{$parameterkeyword};
			}				
			print TCFILE "\t$functionName ( $parName );\n" if (defined $functionName and $functionName ne '');
		}
		
		print TCFILE "\n";						
	}	
}

sub printLine{
	my $line = shift;
	
	chomp($line);
	if($line ne '' and $line ne '\n'){
		print TCFILE "$line\n";
	}
}

sub printLineWithNewLine{
	my $line = shift;
	
	chomp($line);
	if($line ne '' and $line ne '\n'){
		print TCFILE "$line\n\n";
	}
}

sub printParaDocuLine{
	my $type = shift;
	my $name = shift;	
	
	chomp($name);
	chomp($type);
	if(defined $name and defined $type and $name !~ /#/){
		print TCFILE "\t$type '$name' => \n";
	}
}

sub printDefaultParameter{
	my $line = shift;
	
	if($line ne '' and $line ne '\n' and $line !~ /#/){		
		$line = 'my $'."tcpar_$line;";
		print TCFILE "$line\n";
	}	
}

sub printReadDefaultParameter{
	my $line = shift;
	
	if($line ne '' and $line ne '\n' and $line !~ /#/){
		$line = "\t".'$'."tcpar_$line =  GEN_Read_mandatory_testcase_parameter( '$line' );";
		print TCFILE "$line\n";
	}	
}

sub printTCParameter{
	my $line = shift;
	
	if($line ne '' and $line ne '\n' and $line !~ /#/){		
		$line = 'my $'."tcpar_$line;";
		print TCFILE "$line\n";
	}	
}

sub printReadTCParameter{
	my $line = shift;
	
	if($line ne '' and $line ne '\n' and $line !~ /#/){
		$line = "\t".'$'."tcpar_$line =  GEN_Read_mandatory_testcase_parameter( '$line' );";
		print TCFILE "$line\n";
	}	
}

sub checkParameter{
	my $line = shift;
	
	my $partype;
	if($line =~ /\%/){
		$partype = 'HASH';
	}
	elsif($line =~ /\@/){
		$partype = 'LIST';
	}
	else{
		$partype = 'SCALAR';
	}
	my @parname = split('=', $line);
	$parname[0] =~ s/^\s*(.*?)\s*$/$1/;
	
	if($parname[0] ne '' and $parname[0] ne '\n'){
		return $parname[0], $partype;
	}	
}

# create
__END__
