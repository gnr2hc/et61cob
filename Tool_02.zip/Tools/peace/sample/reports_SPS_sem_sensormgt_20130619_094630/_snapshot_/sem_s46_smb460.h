/* EasyCASE V6.5 01.01.2008 00:00:00 */
/* EasyCASE O
If=vertical
LevelNumbers=no
LineNumbers=no
Colors=16777215,0,12582912,12632256,0,0,0,16711680,8388736,0,33023,32768,0,0,0,0,0,32768,12632256,255,65280,255,255,16711935
ScreenFont=Courier New,,80,4,-11,0,400,0,0,0,0,0,0,3,2,1,49,96,96
PrinterFont=Courier New,,80,4,-66,0,400,0,0,0,0,0,0,3,2,1,49,600,600
LastLevelId= */
/* EasyCASE (
   sem_s46_smb460.h */
#ifndef Y_sem_s46_smb460H
#define Y_sem_s46_smb460H
/* EasyCASE - */
/*#ACD# M(Bosch Copyright) */
/* ************************************************************************** */
/*                                                                            */
/*  Copyright (c) 2008 Robert Bosch GmbH, Germany                             */
/*                All rights reserved                                         */
/*                                                                            */
/* ************************************************************************** */
/*#end ACD#*/
/*#ACD# M(sem_s46_smb460 Header Author) Author*/
/*  $Source: sem_s46_smb460.h                                                    */
/*  $Revision: 1.1 $                                                          */
/*  $Author: Reddivari Devendra Kumar (RBEI/ESA-PP) (dvn2kor) $                                                        */
/*#end ACD#*/
/* ************************************************************************** *
 *  Description:
 * Specific Module for SMB460 series dual channel central acceleration sensor.
 * 
 * The SMB460 features two perpendicular, in plane measurement axis with a
 * measurement range of 96g each. The communication with the SMB460 is done via
 * the SPI.
 * 
 * This module contains the sensor specific initialisation and background
 * monitoring tasks.
 *
 *
 *  Reference to Documentation:  sem_s46_smb460_SDS.HTML
 */
/* ********************** Framecode-Generator V2.0 ************************** */
/* EasyCASE (
   History */
/* ****************************** History *********************************** */
/*#ACD# M(sem_s46_smb460 Header) History*/
/*  $Log: peace/sample/reports_SPS_sem_sensormgt_20130619_094630/_snapshot_/sem_s46_smb460.h  $ */
/*  Revision 1.1 2013/07/31 00:03:31ICT Reddivari Devendra Kumar (RBEI/ESA-PP) (dvn2kor)  */
/*  Initial revision */
/*  Member added to project g:/MKS/Projects/TurboLIFT/Tools/Tools.pj */
/*  Revision 1.1 2013/06/19 06:19:03MESZ Vernon Hawes (RBEI/ESA1) (ver6cob)  */
/*  Initial revision */
/*  Member added to project g:/MKS/Projects/TurboLIFT/Projects/AB12/AB12.pj */
/*  Revision 5.5 2011/04/18 21:02:14IST Kuenzel Fritz-Holger (DGS-EC/ESS6) (HKU2SI)  */
/*  comment for fault reaction and fault description reworked */
/*  --- Added comments ---  HKU2SI [2011/06/20 14:27:16Z] */
/*  Delta review done by EPS3-Frueh. */
/*  --- Added comments ---  HKU2SI [2011/06/20 14:27:16Z] */
/*  State changed: develop -> reviewed by HKU2SI */
/*   */
/*  --- Added comments ---  HKU2SI [2011/08/25 06:51:57Z] */
/*  State changed: reviewed -> release by HKU2SI */
/*  Revision 5.4 2011/02/25 10:07:16CET HKU2SI  */
/*  sem_s20_smb200 */
/*  --- Added comments ---  HKU2SI [2011/02/25 09:08:32Z] */
/*  FLTREACTION introduced */
/*  --- Added comments ---  HKU2SI [2011/02/25 14:08:48Z] */
/*  release again, because only faultreaction as comment was introduced */
/*  --- Added comments ---  HKU2SI [2011/02/25 14:08:48Z] */
/*  State changed: develop -> release by HKU2SI */
/*  Revision 5.3 2011/01/21 11:05:34CET HKU2SI  */
/*  CRQ_179 new plausibility function implemented */
/*  --- Added comments ---  HKU2SI [2011/01/21 10:57:53Z] */
/*  State changed: develop -> ready_for_review by HKU2SI */
/*   */
/*  --- Added comments ---  HKU2SI [2011/02/04 13:04:17Z] */
/*  State changed: ready_for_review -> reviewed by HKU2SI */
/*   */
/*  --- Added comments ---  HKU2SI [2011/02/04 13:04:23Z] */
/*  State changed: reviewed -> tested by HKU2SI */
/*   */
/*  --- Added comments ---  HKU2SI [2011/02/04 13:04:30Z] */
/*  State changed: tested -> release by HKU2SI */
/*  Revision 5.2 2011/01/04 14:23:23CET bhs6kor  */
/*  updated after review */
/*  --- Added comments ---  bhs6kor [2011/01/06 09:03:31Z] */
/*  State changed: develop -> ready_for_review by bhs6kor */
/*  Revision 5.1 2010/08/05 13:34:30IST fru1si  */
/*  - Removed DCU from AB10lib sensor management. */
/*  - Adapted UML model for cust specific sensor modules (dependencies to lib APIs, separate header for struct definitions). */
/*  - Re-ran code generator with latest templates. */
/*  - No functional change --> previous state is taken over. */
/*  --- Added comments ---  fru1si [2010/08/05 08:11:44Z] */
/*  State changed: develop -> release by fru1si */
/*  Revision 4.2 2010/04/28 12:16:26CEST str3kor  */
/*  Ptedt00050326:Introduced Instance mechanism(new stusture introduced to support more then one SMB460 Sensor),removed LI SwitchOn command */
/*  --- Added comments ---  str3kor [2010/04/28 10:21:18Z] */
/*  State changed: develop -> ready_for_review by str3kor */
/*   */
/*  --- Added comments ---  HKU2SI [2010/05/21 05:55:03Z] */
/*  State changed: ready_for_review -> reviewed by HKU2SI */
/*   */
/*  --- Added comments ---  HKU2SI [2010/05/21 05:55:10Z] */
/*  State changed: reviewed -> tested by HKU2SI */
/*  Revision 4.1 2009/09/29 18:45:57IST hku2si  */
/*  module generated with AMEOS AB10 from main path */
/*  --- Added comments ---  HKU2SI [2009/10/02 13:06:32Z] */
/*  State changed: develop -> release by HKU2SI */
/*  Revision 4.0 2009/08/27 12:08:30CEST hku2si  */
/*  new ASI (algo sensor interface) located to main branch */
/*  Revision 2.14.1.1 2009/03/11 12:12:42CET hku2si  */
/*  new sensor interface introduced (sem_std_sensortypedefs.h) */
/*  Revision 2.14 2008/12/18 17:00:53CET fru1si  */
/*  Re-ran code generator after Hydra update ("#pragma arm" issue) */
/*  --- Added comments ---  fru1si [2008/12/18 16:03:19Z] */
/*  Member revision set by fru1si */
/*  --- Added comments ---  fru1si [2008/12/18 16:04:29Z] */
/*  State changed: develop -> release by fru1si */
/*  Revision 2.13 2006/11/17 10:52:45CET ngk2si  */
/*  Updated BITE test threshold according to HW Module Documentation (DASS) v.2.1 */
/*  --- Added comments ---  ngk2si [2006/11/17 09:57:07Z] */
/*  Delta review with A.Jansen, no findings. */
/*  --- Added comments ---  ngk2si [2006/11/17 09:57:07Z] */
/*  State changed: develop -> reviewed by ngk2si */
/*   */
/*  --- Added comments ---  ngk2si [2006/11/17 15:20:40Z] */
/*  Executed all SW-test with now findings.  */
/*  Release state not possible as BITE HW thresholds are still preliminary. */
/*  --- Added comments ---  ngk2si [2006/11/17 15:20:40Z] */
/*  State changed: reviewed -> tested by ngk2si */
/*   */
/*  --- Added comments ---  ngk2si [2007/04/04 11:56:58Z] */
/*  BITE Test thresholds have been confirmed by EHW-Schuetze, */
/*  so module is set to release. */
/*  --- Added comments ---  ngk2si [2007/04/04 11:56:59Z] */
/*  State changed: tested -> release by ngk2si */
/*  Revision 2.12 2006/07/27 16:58:27CEST ngk2si  */
/*  Background monitoring in steady state split into three states (for BG runtime reduction) */
/*  --- Added comments ---  ngk2si [2006/07/31 11:47:01Z] */
/*  Delta Review with J.Widmaier, no findings */
/*  --- Added comments ---  ngk2si [2006/07/31 11:47:01Z] */
/*  State changed: develop -> reviewed by ngk2si */
/*  Revision 2.11 2006/05/27 16:19:58CEST ngk2si  */
/*  Updated after cs_centralsensors code review */
/*  --- Added comments ---  ngk2si [2006/05/29 14:52:49Z] */
/*  Delta review to 2.10 with J. Widmaier */
/*  --- Added comments ---  ngk2si [2006/05/29 14:52:49Z] */
/*  State changed: develop -> reviewed by ngk2si */
/*  Revision 2.10 2006/05/20 15:08:36CEST ngk2si  */
/*  - fixed (small) bug in internal monitoring supervision found during unit test */
/*  - Redesigned interpolation mode programming */
/*  Revision 2.9 2006/05/16 13:53:42CEST ngk2si  */
/*  - new SPI API names */
/*  - regenerated with updated CodeGen */
/*  - new StepUpIni Return type */
/*  - improved commenting */
/*  Revision 2.8 2006/05/05 17:18:43CEST ngk2si  */
/*  Updated with findings from SMB460 code review */
/*  --- Added comments ---  ngk2si [2006/05/05 15:19:01Z] */
/*  State changed: develop -> reviewed by ngk2si */
/*  Revision 2.7 2006/04/07 16:38:22CEST ngk2si  */
/*  Regenerated with new template */
/*  Revision 2.6 2006/04/03 12:59:54CEST ngk2si  */
/*  - Regenerated with updated templates */
/*  - now always the first SMB460 is used for the SCON-Test */
/*  - Made waiting for SCON-Test a individual state */
/*  Revision 2.5 2006/03/10 15:47:16CET ngk2si  */
/*  Regenerated with updated template */
/*  Revision 2.4 2006/03/01 18:20:16CET ngk2si  */
/*  Updated for B-Sample-Version of SMB460 */
/*  Revision 2.3 2006/02/07 18:11:04CET ngk2si  */
/*  Restructured data interfaces */
/*  Misra updated */
/*  Revision 0.7.1.8 2005/12/28 13:11:19CET ngk2si  */
/*  Corrected naming of enums */
/*  Revision 0.7.1.7 2005/12/01 17:29:52CET ngk2si  */
/*  Corrected Initilisation-Sequence-Bug (Offset Cancellation). */
/*  Revision 0.7.1.6 2005/11/11 10:32:38CET ngk2si  */
/*  Added handling for not configured sensors */
/*  Revision 0.7.1.5 2005/10/24 17:46:56CEST ngk2si  */
/*  Improved commenting and removed danger of race condition with RT-SPI-Bit checks */
/*  Revision 0.7.1.4 2005/10/21 18:28:26CEST ngk2si  */
/*  Modifed Central-Sensor Internal PDI to use only one struct (less externs) */
/*  Revision 0.7.1.3 2005/10/19 17:29:49CEST ngk2si  */
/*  Moved RTErrorFlagEvaluation to CS module */
/*  Revision 0.7.1.2 2005/10/13 16:06:44CEST ngk2si  */
/*  C_Sample general rework */
/*  Revision 0.7.1.1 2005/10/10 16:33:14CEST ngk2si  */
/*  Backported from version 2.2 due to Sample delay */
/*  New architecture but supports A-Si */
/*  Revision 0.7 2005/05/02 16:21:44CEST ngk2si  */
/*  Added check of Sensor-EEPROM CRC Monitoring Bit */
/*  Revision 0.6 2005/04/07 14:59:37CEST ngk2si  */
/*  Improved configuration of SafetyID */
/*  Revision 0.5 2005/03/23 17:39:12CET ngk2si  */
/*  Major restructuring after SystemArchitectureRound 23.03.05, changed handling of single channel init faults */
/*  Revision 0.4 2005/03/21 12:04:04CET ngk2si  */
/*  Made several parameters unsigned */
/*  Revision 0.3 2005/03/18 16:19:15CET ngk2si  */
/*  First version that initialises the central sensor */
/*  Revision 0.2 2005/03/16 14:01:03CET ngk2si  */
/*  Architecture updated: separated smb460 specific stuff from global centralsensors-module */
/*#end ACD#*/
/* ************************************************************************** */
/* EasyCASE ) */
/* EasyCASE (
   Includes */
/* PRQA S 1-9999 suppress_foreign_warnings_sem_s46_smb460_h */
/* EasyCASE (
   Standard includes (utils + own header) */
#include "utl_options.p"
#include "utl_tb_typesbase.h"
/* EasyCASE ) */
/* EasyCASE (
   Direct includes for package SEM_SensorMgt */
#include "sem_smr_sensormanager.h" 
#include "sem_std_sensortypedefs.h" 
/* EasyCASE ) */
/* PRQA L:suppress_foreign_warnings_sem_s46_smb460_h */
/* EasyCASE ) */
/* EasyCASE (
   #Define Constants */
/*#ACD# M(Constants sem_s46_smb460)  Definitions*/
/* EasyCASE ( 921
   sensor specific thresholds */
#define C_SMB460DeviceID_U8X                    0x46u   /* expected Device ID of this Asic */

#define C_SMB460AverageExp_U8X                     4u   /* number of realtime measurements used for an averaged signal,
* specified in 2^x fashion (4 => 16 samples) */

#define C_SMB460OffsetThreshold_U16X            0x0Au   /* threshold for offset cancellation check (2g) */
#define C_SMB460OffsetDelay_U16X                150u    /* delay till fast offset cancellation can be evaluated (ms) */

#define C_SMB460BiteDelay_U16X                  150u    /* delay till Bite can be evaluated (ms) */
#define C_SMB460BiteMinThreshold_S16X           50      /* minimum threshold for the BITE Test */
#define C_SMB460BiteMaxThreshold_S16X           150     /* maximum threshold for the BITE Test */
/* EasyCASE ) */
/* EasyCASE ( 916
   SPI Commands for SMB460 */
/* read commands */
#define C_SMB460SPIReadChannel1_U16X            0x8000u  /* Read sensor Channel 1 */
#define C_SMB460SPIReadChannel2_U16X            0xC000u  /* Read sensor Channel 2 */

#define C_SMB460SPIReadDeviceID_U16X            0x0000u  /* Read Device ID */
#define C_SMB460SPIReadMonitorData1_U16X        0x2200u  /* Read Monitor Data 1 */
#define C_SMB460SPIReadMonitorData2_U16X        0x2400u  /* Read Monitor Data 2 */

/* commands for inital tests / programming */
#define C_SMB460SPIOffsetCancellationON_U16X    0x7805u  /* switch on offset cancellation for both channels */
#define C_SMB460SPIOffsetCancellationOFF_U16X   0x7800u  /* switch off offset cancellation for both channels */
#define C_SMB460SPIReadOffsetCancellation_U16X  0x7A00u  /* Read Offset cancellation status */

#define C_SMB460OffsetCancellationFast_U8X      0x0Fu    /* fast offset cancellation on both cannels active */
#define C_SMB460OffsetCancellationSlow_U8X      0x0Au    /* slow offset cancellation on both cannels active */
#define C_SMB460OffsetCancellationOff_U8X       0x00u    /* offset cancellation off */

#define C_SMB460SPIDemandBite1_U16X             0x3809u  /* Selftest: Channel 1: pos Channel 2: neg */
#define C_SMB460SPIDemandBite2_U16X             0x3806u  /* Selftest: Channel 1: neg Channel 2: pos */
#define C_SMB460SPIDemandBiteOFF_U16X           0x3800u  /* Selftest: both Channels off  */

#define C_SMB460SPIDemandInterpolation_U16X     0x6A01u  /* switch on linear interpolation */

#define C_SMB460SPIProgSafetyID_U16X            0x5A00u  /* program safety-ID */
#define C_SMB460SPIReadSafetyID_U16X            0x3600u  /* read safety-ID */

#define C_SMB460SPIEOPCommand_U16X              0x0C00u  /* End of programming */
/* EasyCASE - */
/* SPI-Communication Masks */
#define M_SMB460SPIMoni2StatusAfterEOP_U16X     0x0000u  /* 0 = sensor is in normal state */
#define M_SMB460SPIMoni2CheckAfterEOP_U16X      0x00FEu  /* all Monitor2-Register-Bits besides LSB must be checked */
#define M_SMB460SPIMoni2Interpolation_U16X      0x0001u  /* LSB on Monitor2-Regster indicates interpolation mode */
#define M_SMB460SPISlowOffsetCalcActive_U16X    0x100Au  /* slow offset cancellation active on both channels */
/* EasyCASE ) */
/* EasyCASE ( 920
   Masks */
/* Masks for Internal Monitoring SPI-Messages
 *    The SMB460 has two internal monitoring registers (8bit each), that indicate
 *    the sensor errors or stati detected by the monitoring logic inside the asic.
 *    The bits are combined into one U16 and have the following meaning:
 *
 *    Moni 1 (will set the NRO-Spi-Bit):
 *       xxxx xxxx xxxx xxx1: offset cancellation of channel 1 out of range
 *       xxxx xxxx xxxx xx1x: offset cancellation of channel 2 out of range
 *       xxxx xxxx xxxx x1xx: Offset counter in wrong mode channel 1 (fast instead of slow)
 *       xxxx xxxx xxxx 1xxx: Offset counter in wrong mode channel 2 (fast instead of slow)
 *       xxxx xxxx xxx1 xxxx: No ECLK.
 *       xxxx xxxx xx1x xxxx: extended mode for production tests (fault grade Coverage mode)
 *       xxxx xxxx x1xx xxxx: EEPROM check error, CRC Error.
 *       xxxx xxxx 1xxx xxxx: SPI-interface error check.
 *
 *   Moni 2 (do no set the NRO-SPI-Bit):
 *       xxxx xxx1 xxxx xxxx: status of linear interpolation mode (0 = on, 1 = off)
 *       xxxx xx1x xxxx xxxx: no Safety-ID programming occurred in this power on cycle.
 *       xxxx x1xx xxxx xxxx: not used.
 *       xxxx 1xxx xxxx xxxx: No Fast or slow offset cancellation triggered for channel 1
 *       xxx1 xxxx xxxx xxxx: No Fast or slow offset cancellation triggered for channel 2
 *       xx1x xxxx xxxx xxxx: No selftest function of channel 1 triggered
 *       x1xx xxxx xxxx xxxx: No selftest function of channel 2 triggered
 *       1xxx xxxx xxxx xxxx: No EOP-lock-command received
 */
#define M_SMB460MoniOffsetOutOfRange_U16X       0x0003u
#define M_SMB460MoniOffsetWrongMode_U16X        0x000Cu
#define M_SMB460MoniNoECLK_U16X                 0x0010u
#define M_SMB460MoniExtModeOrCRCError_U16X      0x0060u
#define M_SMB460MoniSpiError_U16X               0x0080u
#define M_SMB460Moni2Interpolation_U16X         0x0100u
   /* the remaining bits of Moni 2 are not monitored */

/* Mapping for the 6 bits detailed fault info stored withing the CSMonitoring Fault:
 *       xx xxx1: Offset cancellation out of range (channel 1 or 2)
 *       xx xx1x: offset cancellation in wrong mode (fast vs slow, channel 1 or 2)
 *       xx x1xx: No ECKL
 *       xx 1xxx: sensor in extended production mode or EEPROM / CRC error
 *       x1 xxxx: SPI interface error
 *       1x xxxx: Interpolation in wrong mode (on vs off)
 */
#define M_SMB460MoniFaultOffsetOutOfRange_U8X   0x01u
#define M_SMB460MoniFaultOffsetWrongMode_U8X    0x02u
#define M_SMB460MoniFaultNoECLK_U8X             0x04u
#define M_SMB460MoniFaultExtModeOrCRCError_U8X  0x08u
#define M_SMB460MoniFaultSpiError_U8X           0x10u
#define M_SMB460MoniFaultInterpolation_U8X      0x20u
/* EasyCASE ) */
/*! FLTREACTION FltCsAsicXYProgramming: E_DisableAlgoFrontRear */
/*! FLTREACTION FltCsAsicXYInternalMonitoring: E_DisableAlgoFrontRear */
/* EasyCASE - */
/*! FLTREACTION FltCsChannel1BITE: E_DisableAlgoFrontRear */
/*! FLTREACTION FltCsChannel1OffsetCancellation: E_DisableAlgoFrontRear */
/*! FLTREACTION FltCsChannel1Communication: E_DisableAlgoFrontRear */
/*! FLTREACTION FltCsChannel1Plausibility: E_DisableAlgoFrontRear */
/*! FLTREACTION FltCsChannel2BITE: E_DisableAlgoFrontRear */
/*! FLTREACTION FltCsChannel2OffsetCancellation: E_DisableAlgoFrontRear */
/*! FLTREACTION FltCsChannel2Communication: E_DisableAlgoFrontRear */
/*! FLTREACTION FltCsChannel2Plausibility: E_DisableAlgoFrontRear */
/* EasyCASE - */
/*! FLTDESC FltCsAsicXYProgramming: XY Sensor: Programming failed */
/* EasyCASE - */
/*! FLTDESC FltCsAsicXYInternalMonitoring: XY Sensor: Internal monitoring error */
/* EasyCASE - */
/*! FLTDESC FltCsChannel1BITE: XY Sensor Ch 1: selftest failed */
/*! FLTDESC FltCsChannel1OffsetCancellation: XY Sensor Ch 1: offset cancellation failed */
/*! FLTDESC FltCsChannel1Communication: communication error (SPI) */
/*! FLTDESC FltCsChannel1Plausibility: XY Sensor Ch 1: sensor signal plausibility error */
/* EasyCASE - */
/*! FLTDESC FltCsChannel2BITE: XY Sensor Ch 2: selftest failed */
/*! FLTDESC FltCsChannel2OffsetCancellation: XY Sensor Ch 2: offset cancellation failed */
/*! FLTDESC FltCsChannel2Communication: XY Sensor Ch 2: communication error (SPI) */
/*! FLTDESC FltCsChannel2Plausibility: XY Sensor Ch 2: sensor signal plausibility error */
/* EasyCASE - */
/*#end ACD#*/
/* EasyCASE ) */
/* EasyCASE (
   ENUM and struct Definitions */
/*#ACD# M(Enums sem_s46_smb460)  Enums*/
/*#end ACD#*/
/*#ACD# M(Enums sem_s46_smb460 leadout)  Enums*/
/* EasyCASE ( 914
   enum te_SMB460Status */
/* EasyCASE < */
/* This enum encodes the states for a smb460 sensor */
typedef enum
{
  E_SMB460NotConfigured,                     /* sensor is not configured */
  E_SMB460SensorDisabled,                    /* sensor disabled because of a fault */
  E_SMB460InitCalcRawOffset,                 /* calculate the raw offset */
  E_SMB460InitEvalRawOffset,                 /* evaluate the raw offset */
  E_SMB460InitStartFastOffsetCancellation,   /* start fast offset cancellation */
  E_SMB460InitWaitForOffsetCancellation,     /* wait for fast offset cancellation */
  E_SMB460InitEvalOffsetCancellation,        /* evaluate result of fast offset cancellation */
  E_SMB460InitStartBite1,                    /* start build in self test */
  E_SMB460InitWaitForBite1,                  /* wait for bite 1 settling time */
  E_SMB460InitSwitchBite2,                   /* switch to bite 2 test */
  E_SMB460InitWaitForBite2,                  /* wait for bite 2 settling time */
  E_SMB460InitEvalBite,                      /* evaluate result of bite test */
  E_SMB460InitWaitSconTest,                  /* wait for end of SCON-Threshold test */
  E_SMB460InitCheckTestModeOff,              /* check if Testmode is off */
  E_SMB460InitProgramSensor,                 /* program the sensor */
  E_SMB460InitEvaluateErrorsAndEOP,          /* evaluate the initalisation error and send EOP */
  E_SMB460SteadyState1,                      /* sensor is in steady state 1 (fetch internal monitoring) */
  E_SMB460SteadyState2,                      /* sensor is in steady state 2 (eval internal monitoring) */
  E_SMB460SteadyState3                       /* sensor is in steady state 3 (communication check) */
} te_SMB460Status;
/* EasyCASE > */
/* EasyCASE ) */
/* EasyCASE ( 928
   struct ts_SMB460Data */
/* EasyCASE < */
typedef struct {  /*! DEF STRUCT ts_SMB460Data */
te_Boolean E_IsInterMoniFltQual_SXX; /*!ENUM te_Boolean E_IsInterMoniFltQual_SXX:Indicates whether internal monitoring fault is qualified or not? */
U8 V_LIRepetitCntr_U8X;              /*! V_LIRepetitCntr_U8X:No.of times Linear interpolation status read */
} ts_SMB460Data;  /*! END DEF*/
/* EasyCASE > */
/* EasyCASE ) */
/*#end ACD#*/
/* EasyCASE ) */
/* EasyCASE (
   Public API Declarations */
/* EasyCASE ) */
/* EasyCASE (
   Package protected API Declarations */
#ifdef Y_INC_FROM_PKG_SEM_SensorMgt
/* EasyCASE (
   S46_Init */
/******************************************************************************
 * Description:
 *    Initialises the handling for one SMB460. This includes:
 *    - checking if the sensor type is correct, that means if this module
 *      really accesses a SMB460
 *    - extracting configuration data and adding it to the management tables in
 *      centralsensors module
 *    - setting the initial sensor/channel states
 *    - initiating the realtime reading by the sensor-manager
 * 
 * Arguments:
 *    - v_asic_u8r: the asic-number of this sensor as specified in PDM
 *    - v_channelNo_u8r: the number of the first channel of this sensor, this
 *      index is e.g. used in the protected data interface.
 *    - e_configured_xxr: is the sensor configured in PDM or not
 * 
 * Return:
 *    the number of channels this sensor has, for a smb460 this is two.
 * 
 * Scheduling:
 *    called once in 10ms background after cfg-data is availible.
 * 
 * Usage guide: -
 * 
 * Remarks:
 * The below Permanent Faults are checked for stored state using Central sensor
 * API's
 *   - FltCs[ASIC]Programming
 *   - FltCs[ASIC]InternalMonitoring
 *   - Flt[CsChannel]OffsetCancellation
 *   - Flt[CsChannel]BITE
 *   - Flt[CsChannel]Plausibility.
 * If the sensor is not configured (e_configured_xxr = false) then this API
 * clears all non-permanent faults related to this sensor. The permanent faults
 * are not cleared.
 ******************************************************************************/
U8 S46_Init(U8 v_asic_u8r, U8 v_channelNo_u8r, te_Boolean e_configured_xxr );
/* EasyCASE ) */
/* EasyCASE (
   S46_BackgroundMonitoring10ms */
/******************************************************************************
 * Description:
 *    Controls the background monitoring for this sensor, depending on sensor
 *    state that is initialisation or continous cyclic monitoring.
 * 
 * Arguments:
 *    - v_asic_u8r: the sensor for which to do the monitoring
 * 
 * Return: -
 * 
 * Scheduling:
 *    10ms
 * 
 * Usage guide:
 *    Called by centralsensors-module once for each smb460 in each 10ms
 *    background cycle.
 * 
 * Remarks: -
 ******************************************************************************/
void S46_BackgroundMonitoring10ms(U8 v_asic_u8r );
/* EasyCASE ) */
#endif
/* EasyCASE ) */
#endif
/* EasyCASE ) */
