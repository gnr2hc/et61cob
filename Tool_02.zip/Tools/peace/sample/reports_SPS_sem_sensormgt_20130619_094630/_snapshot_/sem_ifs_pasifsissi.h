/* EasyCASE V6.5 01.01.2008 00:00:00 */
/* EasyCASE O
If=vertical
LevelNumbers=no
LineNumbers=no
Colors=16777215,0,12582912,12632256,0,0,0,16711680,8388736,0,33023,32768,0,0,0,0,0,32768,12632256,255,65280,255,255,16711935
ScreenFont=Courier New,,80,4,-11,0,400,0,0,0,0,0,0,3,2,1,49,96,96
PrinterFont=Courier New,,80,4,-66,0,400,0,0,0,0,0,0,3,2,1,49,600,600
LastLevelId= */
/* EasyCASE (
   sem_ifs_pasifsissi.h */
#ifndef Y_sem_ifs_pasifsissiH
#define Y_sem_ifs_pasifsissiH
/* EasyCASE - */
/*#ACD# M(Bosch Copyright) */
/* ************************************************************************** */
/*                                                                            */
/*  Copyright (c) 2008 Robert Bosch GmbH, Germany                             */
/*                All rights reserved                                         */
/*                                                                            */
/* ************************************************************************** */
/*#end ACD#*/
/*#ACD# M(sem_ifs_pasifsissi Header Author) Author*/
/*  $Source: sem_ifs_pasifsissi.h                                                    */
/*  $Revision: 1.1 $                                                          */
/*  $Author: Reddivari Devendra Kumar (RBEI/ESA-PP) (dvn2kor) $                                                        */
/*#end ACD#*/
/* ************************************************************************** *
 *  Description:
 * Specific module for controlling the PES interface inside AB10 system ASIC
 * (SISSI) and the Companion ASIC.
 * 
 * Main tasks:
 * - initial programming
 * - control & monitoring of PES power supply
 * 
 * Remarks:
 * In the past there was a special module for the PES interface inside of the
 * Companion ASIC. During the development it was seen, that there is not too
 * much difference between the SISSI PES interface and the Companion PES
 * interface to justify an own module. Therefore the two modules where combined
 * during the development of the SISSI-SISSI combination.
 *
 *
 *  Reference to Documentation:  sem_ifs_pasifsissi_SDS.HTML
 */
/* ********************** Framecode-Generator V2.0 ************************** */
/* EasyCASE (
   History */
/* ****************************** History *********************************** */
/*#ACD# M(sem_ifs_pasifsissi Header) History*/
/*  $Log: peace/sample/reports_SPS_sem_sensormgt_20130619_094630/_snapshot_/sem_ifs_pasifsissi.h  $ */
/*  Revision 1.1 2013/07/31 00:03:30ICT Reddivari Devendra Kumar (RBEI/ESA-PP) (dvn2kor)  */
/*  Initial revision */
/*  Member added to project g:/MKS/Projects/TurboLIFT/Tools/Tools.pj */
/*  Revision 1.1 2013/06/19 06:18:54MESZ Vernon Hawes (RBEI/ESA1) (ver6cob)  */
/*  Initial revision */
/*  Member added to project g:/MKS/Projects/TurboLIFT/Projects/AB12/AB12.pj */
/*  Revision 5.4 2011/08/25 13:52:18IST Frueh Manuel (CC-PS/EPS3) (fru1si)  */
/*  Added struct comment for Diagsym. */
/*  Only comment added, no change in hex-file. */
/*  --> previous state taken over */
/*  --- Added comments ---  fru1si [2011/08/25 08:22:23Z] */
/*  State changed: develop -> release by fru1si */
/*  Revision 5.3 2011/07/27 14:57:51CEST siu1kor  */
/*  create_code done */
/*  --- Added comments ---  hkr2kor [2011/07/27 13:44:56Z] */
/*  State changed: develop -> reviewed by hkr2kor */
/*   */
/*  --- Added comments ---  SIU1KOR [2011/07/28 11:57:54Z] */
/*  State changed: reviewed -> release by SIU1KOR */
/*  Revision 5.2 2011/07/27 16:08:48IST siu1kor  */
/*  Updated with review findings for the task Ptedt00075630 */
/*  Revision 5.1 2010/08/05 13:34:27IST fru1si  */
/*  - Removed DCU from AB10lib sensor management. */
/*  - Adapted UML model for cust specific sensor modules (dependencies to lib APIs, separate header for struct definitions). */
/*  - Re-ran code generator with latest templates. */
/*  - No functional change --> previous state is taken over. */
/*  --- Added comments ---  fru1si [2010/08/05 08:09:19Z] */
/*  State changed: develop -> release by fru1si */
/*  Revision 4.1 2009/10/02 12:46:02CEST fru1si  */
/*  Corrected review findings (see Ptedt00038969). */
/*  Revision 4.0 2009/09/25 13:26:05CEST fru1si  */
/*  Introduced new ASI interface */
/*  Revision 3.1 2008/12/18 17:00:27CET fru1si  */
/*  Re-ran code generator after Hydra update ("#pragma arm" issue) */
/*  --- Added comments ---  fru1si [2008/12/18 16:03:05Z] */
/*  Member revision set by fru1si */
/*  --- Added comments ---  fru1si [2008/12/18 16:04:08Z] */
/*  State changed: develop -> release by fru1si */
/*  Revision 3.0 2008/11/10 09:21:47CET hkr2kor  */
/*  Merged the implementation on the dev branches back to the main path.  */
/*  - New Algo SW Interface */
/*  - Sissi-Sissi Coupling */
/*  --- Added comments ---  fru1si [2008/12/18 10:43:21Z] */
/*  Member revision set by fru1si */
/*  --- Added comments ---  fru1si [2008/12/18 10:43:29Z] */
/*  Take over state from merged revision. */
/*  --- Added comments ---  fru1si [2008/12/18 10:43:29Z] */
/*  State changed: develop -> release by fru1si */
/*  Revision 2.1.1.6 2008/08/27 15:06:23IST wjd2si  */
/*  - Added return value (te_Complete) to IFS_Init. IFS_Init needs now to be called multiple time. This was  */
/*    done due to runtime problems */
/*  - Removed one no longer needed constant (M_SissiCRCMode_U16X) */
/*  - Added constants for the number of lines of different ASICs */
/*  --- Added comments ---  wjd2si [2008/09/02 08:01:30Z] */
/*  Reviewed by Hemanth Nayak */
/*  Tested by ESW3-Widmaier */
/*  --- Added comments ---  wjd2si [2008/09/02 08:01:31Z] */
/*  State changed: develop -> tested by wjd2si */
/*   */
/*  --- Added comments ---  wjd2si [2008/09/05 06:31:50Z] */
/*  Release granted by ESW3-Breu on 05.09.2008 */
/*  --- Added comments ---  wjd2si [2008/09/05 06:31:50Z] */
/*  State changed: tested -> release by wjd2si */
/*  Revision 2.1.1.5 2008/08/26 09:09:29CEST wjd2si  */
/*  Update of comments after architecture change. They were already reviewed in the PSAS review => inherit release state */
/*  --- Added comments ---  wjd2si [2008/08/26 07:09:36Z] */
/*  State changed: develop -> release by wjd2si */
/*  Revision 2.1.1.4 2008/04/11 15:24:01CEST wjd2si  */
/*  Reran create_code after update of tooling. No changes to the code, only comments -> take over old state */
/*  --- Added comments ---  wjd2si [2008/04/11 13:24:06Z] */
/*  State changed: develop -> reviewed by wjd2si */
/*   */
/*  --- Added comments ---  wjd2si [2008/04/15 06:36:02Z] */
/*  Test finished by ESW3-Widmaier on 14.04.2008 */
/*  --- Added comments ---  wjd2si [2008/04/15 06:36:02Z] */
/*  State changed: reviewed -> tested by wjd2si */
/*   */
/*  --- Added comments ---  wjd2si [2008/04/16 14:43:51Z] */
/*  Release granted by ESW3-Breu on 16.04.2008 */
/*  --- Added comments ---  wjd2si [2008/04/16 14:43:52Z] */
/*  State changed: tested -> release by wjd2si */
/*  Revision 2.1.1.3 2008/03/14 11:16:17CET wjd2si  */
/*  - Correction and expansion of comments  */
/*  - Corrected maximum number of samples from 8 to 12 */
/*  Revision 2.1.1.2 2008/02/28 08:06:54CET wjd2si  */
/*  Major rework to adapt to new APIs of PDM and RPM */
/*  Removed QAC warnings and errors */
/*  Revision 2.1.1.1 2008/02/01 15:52:00CET wjd2si  */
/*  First updated version for Sissi-Sissi coupling and the integration of the Companion ASIC */
/*  Revision 2.1 2006/12/12 18:07:30CET ngk2si  */
/*  - Added Support for CG108/9 (VW System Asic) */
/*  - Module now triggers a SEM configuration fault if more than 4 PAS are allocated to Sissi Lines */
/*  --- Added comments ---  ngk2si [2006/12/13 09:13:52Z] */
/*  Delta review to version 2.1 with ESW3-Widmaier, no findings. */
/*  --- Added comments ---  ngk2si [2006/12/13 09:13:52Z] */
/*  State changed: develop -> reviewed by ngk2si */
/*   */
/*  --- Added comments ---  ngk2si [2006/12/13 09:41:01Z] */
/*  All Tests passed. */
/*  --- Added comments ---  ngk2si [2006/12/13 09:41:01Z] */
/*  State changed: reviewed -> release by ngk2si */
/*  Revision 2.0 2006/09/25 16:16:59CEST ngk2si  */
/*  And now really 2.0 is choosen as revision number */
/*  --- Added comments ---  ngk2si [2006/09/25 14:17:34Z] */
/*  no differences to 1.2 */
/*  --- Added comments ---  ngk2si [2006/09/25 14:17:34Z] */
/*  State changed: develop -> reviewed by ngk2si */
/*   */
/*  --- Added comments ---  ngk2si [2006/09/26 15:39:19Z] */
/*  Tested with SDTR 2.2.1.1 */
/*  --- Added comments ---  ngk2si [2006/09/26 15:39:19Z] */
/*  State changed: reviewed -> release by ngk2si */
/*  Revision 1.3 2006/09/25 16:16:26CEST ngk2si  */
/*  Duplicate revision to change version number to 2.x (similar to other modules) */
/*  Revision 1.2 2006/09/22 16:06:14CEST kio1si  */
/*  Reran Codegen */
/*  Revision 1.1 2006/06/08 13:04:18CEST ngk2si  */
/*  Fixed comment typos. */
/*  Revision 1.0 2006/06/01 19:14:13CEST ngk2si  */
/*  -merged back to main branch */
/*  - corrected several parameter names */
/*  Revision 0.5.1.6 2006/05/27 16:17:06CEST ngk2si  */
/*  New PAS-initialisation structure, now this module calls the pas-specific init. */
/*  Revision 0.5.1.5 2006/05/15 11:20:19CEST ngk2si  */
/*  modified PAS-IF initialisation after adding companion asic module */
/*  Revision 0.5.1.4 2006/04/20 17:20:00CEST ngk2si  */
/*  Fixed programming of interpolation mode */
/*  Revision 0.5.1.3 2006/04/07 16:38:21CEST ngk2si  */
/*  Regenerated with new template */
/*  Revision 0.5.1.2 2006/04/03 12:58:46CEST ngk2si  */
/*  Regenerated with updated templates */
/*  Revision 0.5.1.1 2006/03/08 11:53:31CET ngk2si  */
/*  Prototype for c-sample siissi, Interpolation mode still missing */
/*  Revision 0.5 2006/02/07 18:10:34CET ngk2si  */
/*  Restructured data interfaces */
/*  Misra updated */
/*  Revision 0.4 2006/01/02 15:16:12CET ngk2si  */
/*  Changed architecture of sensor data interface */
/*  Revision 0.3 2005/12/28 13:11:14CET ngk2si  */
/*  Corrected naming of enums */
/*  Revision 0.2 2005/11/29 16:05:40CET ngk2si  */
/*  added functional code */
/*#end ACD#*/
/* ************************************************************************** */
/* EasyCASE ) */
/* EasyCASE (
   Includes */
/* PRQA S 1-9999 suppress_foreign_warnings_sem_ifs_pasifsissi_h */
/* EasyCASE (
   Standard includes (utils + own header) */
#include "utl_options.p"
#include "utl_tb_typesbase.h"
/* EasyCASE ) */
/* EasyCASE (
   Direct includes for package SEM_SensorMgt */
#include "sem_smr_sensormanager.h" 
#include "sem_std_sensortypedefs.h" 
/* EasyCASE ) */
/* PRQA L:suppress_foreign_warnings_sem_ifs_pasifsissi_h */
/* EasyCASE ) */
/* EasyCASE (
   #Define Constants */
/*#ACD# M(Constants sem_ifs_pasifsissi)  Definitions*/
/* EasyCASE - */
/* A system asic with 6 lines (CG143) uses at most 12 samples 
 *
 * CG101        -> 0 lines
 * CG102/CG108  -> 2 lines
 * CG103/CG109  -> 4 lines
 * CG143        -> 6 lines
 */
#define C_SissiMaxPasSamples_U8X                12u 
/*!DEF ARRAYLEN C_SissiMaxPasSamples_U8X 12 */

/* SPI-Command-Bits */
/* Read commands */
#define C_SissiReadPasCommand_U16X              0x8000u
#define C_SissiPasOldValue_U8X                  1u
#define C_SissiPasNewValue_U8X                  0u

/* PAS-power supply commands */
#define C_SissiReadSupply_U16X                  0x1000u
#define C_SissiSwitchSupply_U16X                0x10C0u   /* same command, but bit 6 and 7 are 1 */

/* Specifies in which bits in the prog-pas-command the safety-ID is encoded (bit 5..7) */
#define C_SissiProgPasSafetyIDLocation_U8X      5u

/* Bit masks for the number of sissi lines */
#define M_SissiTwoLines_U16X                    0x0003u
#define M_SissiFourLines_U16X                   0x000Fu
#define M_SissiSixLines_U16X                    0x003Fu

/* Number of lines per ASIC */
#define C_IFSNoLinesCG102108_U8X        2u
#define C_IFSNoLinesCG103109_U8X        4u
#define C_IFSNoLinesCG143_U8X           6u
/* EasyCASE - */
/*#end ACD#*/
/* EasyCASE ) */
/* EasyCASE (
   ENUM and struct Definitions */
/*#ACD# M(Enums sem_ifs_pasifsissi)  Enums*/
/*#end ACD#*/
/*#ACD# M(Enums sem_ifs_pasifsissi leadout)  Enums*/
/* EasyCASE C */
/* struct to temporarily store the pas-setup data for the initialisation */
typedef struct
   {                                                /*! DEF STRUCT ts_PESifSissiSetupData */
   tp_SensorSpecificFunction P_PESSpecificRTFp_XFX; /*! tp_SensorSpecificFunction P_PESSpecificRTFp_XFX: Real-time eval function pointer */
   U16                       V_ReadCommand_U16X;    /*! V_ReadCommand_U16X: MibSPI read command */
   U8                        V_SensorIndex_U8X;     /*! V_SensorIndex_U8X: Sensor index in SMR table */
   U8                        V_ChannelIndex_U8X;    /*! V_ChannelIndex_U8X: Channel index in SMR table */
   } ts_PESifSissiSetupData;                        /*! END DEF */
/* EasyCASE E */
/*#end ACD#*/
/* EasyCASE ) */
/* EasyCASE (
   Public API Declarations */
/* EasyCASE ) */
/* EasyCASE (
   Package protected API Declarations */
#ifdef Y_INC_FROM_PKG_SEM_SensorMgt
/* EasyCASE (
   IFS_Init */
/******************************************************************************
 * Description:
 *    Performs the initialization for all SISSI and companion PES-IFs as well
 *    as the SW setup for all PES connected to them. This includes:
 *    - programming of the interpolation and CRC mode
 *    - PES-IF register programming for every connected PES
 *    - calling the PES type specific init methods (via
 *      PES_CallSensorSpecificInit)
 *    - setup the PES read commands for the sensor manager (via
 *      SMR_AddSensorChannel)
 * 
 * Arguments: -
 * 
 * Return:
 *    E_InComplete: initialization has not finished yet
 *    E_Complete  : initialization has finished
 * 
 * Scheduling:
 *    Called by pes_peripheralsensors at the very first 10ms background.
 * 
 * Usage guide:
 *    Call the function from peripheral sensors module in the early init, until
 *    the function returns E_Complete.
 * 
 * Remarks:
 *    Setting up the PES read commands is rather complicated, as with each read
 *    command the NEXT buffer to be read has to be indicated.
 *    Example - reading of two PAS4:
 * 
 *    buffers to read:     commands sent:
 *    ----------------     --------------
 *    buffer 1 old value:  read buffer (next: 1 new)
 *    buffer 1 new value:  read buffer (next: 2 old)
 *    buffer 2 old value:  read buffer (next: 2 new)
 *    buffer 2 new value:  read buffer (next: 1 old)
 * 
 *    That means, the read commands are "rotated" by one. This "feature" makes
 *    this function rather complicated, especially as it is also necessary to
 *    handle a flexible order of buffers and even unused buffers. Therefore
 *    this whole sequence is first build up in RAM, then rotated and then
 *    written into the structures in sensor management.
 ******************************************************************************/
te_Complete IFS_Init( void );
/* EasyCASE ) */
/* EasyCASE (
   IFS_MakeLineMeasurement */
/******************************************************************************
 * Description:
 *    Fetches the PES line status of all SISSI and companion PES-IF lines. The
 *    result is stored by setting the corresponding bits in
 *    S_PesLineData_XXR.F_MeasuredStatus_U16X.
 * 
 * Arguments: -
 * 
 * Return: -
 * 
 * Scheduling:
 *    Called from pes_peripheralsensors at the beginning of its 10ms cyclic
 *    monitoring.
 * 
 * Usage guide: -
 * 
 * Remarks: Loops over all present CG102, CG103, CG108, CG109 and CG143 ASICs.
 ******************************************************************************/
void IFS_MakeLineMeasurement( void );
/* EasyCASE ) */
/* EasyCASE (
   IFS_MakeLineSwitching */
/******************************************************************************
 * Description:
 *    Performs the line switching for all SISSI and companion ASIC PES lines by
 *    sending the corresponding "supply SPI" command. Requested lines are taken
 *    from variable S_PesLineData_XXR.F_RequestedStatus_U16X.
 * 
 * Arguments: -
 * 
 * Return: -
 * 
 * Scheduling:
 *    Called from pes_peripheralsensors at the very end of its 10ms cyclic
 *    monitoring.
 * 
 * Usage guide: -
 * 
 * Remarks: Loops over all present CG102, CG103, CG108, CG109 and CG143 ASICs.
 ******************************************************************************/
void IFS_MakeLineSwitching( void );
/* EasyCASE ) */
#endif
/* EasyCASE ) */
#endif
/* EasyCASE ) */
