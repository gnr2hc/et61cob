/* EasyCASE V6.5 01.01.2008 00:00:00 */
/* EasyCASE O
If=vertical
LevelNumbers=no
LineNumbers=no
Colors=16777215,0,12582912,12632256,0,0,0,16711680,8388736,0,33023,32768,0,0,0,0,0,32768,12632256,255,65280,255,255,16711935
ScreenFont=Courier New,,80,4,-11,0,400,0,0,0,0,0,0,3,2,1,49,96,96
PrinterFont=Courier New,,80,4,-66,0,400,0,0,0,0,0,0,3,2,1,49,600,600
LastLevelId= */
/* EasyCASE (
   sem_pa5_pas5.h */
#ifndef Y_sem_pa5_pas5H
#define Y_sem_pa5_pas5H
/* EasyCASE - */
/*#ACD# M(Bosch Copyright) */
/* ************************************************************************** */
/*                                                                            */
/*  Copyright (c) 2008 Robert Bosch GmbH, Germany                             */
/*                All rights reserved                                         */
/*                                                                            */
/* ************************************************************************** */
/*#end ACD#*/
/*#ACD# M(sem_pa5_pas5 Header Author) Author*/
/*  $Source: sem_pa5_pas5.h                                                    */
/*  $Revision: 1.1 $                                                          */
/*  $Author: Reddivari Devendra Kumar (RBEI/ESA-PP) (dvn2kor) $                                                        */
/*#end ACD#*/
/* ************************************************************************** *
 *  Description:
 * This module contains the specific implementation for
 * - the PAS5 peripheral acceleration sensor (also used as UFS3 upfront sensor),
 * - the enhanced PAS5R (UFS3R) sensor
 * - the 2-channel PAS5xy sensor
 * - the PAS6 peripheral acceleration sensor
 * 
 * It mainly features:
 * - real-time data evaluation
 * - background monitoring
 * 
 * The PAS5(R) has an electrical measurement range of 120 g (the mechanically
 * possible range is higher). A constant acceleration of 1g leads to a received
 * signal of 4LSB inside the ECU. The maximum transmitted signal of 480LSB
 * therefore corresponds to an acceleration of 120g.
 * The UFS3(R) has an electrical measurement range of 480g. In that case an
 * acceleration of 1g results in an output signal of 1LSB. 480LSB therefore
 * corresponds to 480g.
 * The PAS6 has an electrical measurement range of 120g, 240g or 480g, means
 * 4LSB/g, 2LSB/g or 1LSB/g. The range 120g is only used as PAS. The range 240g
 * can be used as PAS or UFS. The range 480g is only used as UFS.
 * 
 *
 *
 *  Reference to Documentation:  sem_pa5_pas5_SDS.HTML
 */
/* ********************** Framecode-Generator V2.0 ************************** */
/* EasyCASE (
   History */
/* ****************************** History *********************************** */
/*#ACD# M(sem_pa5_pas5 Header) History*/
/*  $Log: peace/sample/reports_SPS_sem_sensormgt_20130619_094630/_snapshot_/sem_pa5_pas5.h  $ */
/*  Revision 1.1 2013/07/31 00:03:31ICT Reddivari Devendra Kumar (RBEI/ESA-PP) (dvn2kor)  */
/*  Initial revision */
/*  Member added to project g:/MKS/Projects/TurboLIFT/Tools/Tools.pj */
/*  Revision 1.1 2013/06/19 06:18:58MESZ Vernon Hawes (RBEI/ESA1) (ver6cob)  */
/*  Initial revision */
/*  Member added to project g:/MKS/Projects/TurboLIFT/Projects/AB12/AB12.pj */
/*  Revision 5.1 2010/08/05 13:34:26IST Frueh Manuel (CC-PS/EPS3) (fru1si)  */
/*  - Removed DCU from AB10lib sensor management. */
/*  - Adapted UML model for cust specific sensor modules (dependencies to lib APIs, separate header for struct definitions). */
/*  - Re-ran code generator with latest templates. */
/*  - No functional change --> previous state is taken over. */
/*  --- Added comments ---  fru1si [2010/08/05 08:10:49Z] */
/*  State changed: develop -> release by fru1si */
/*  Revision 4.6 2010/01/25 12:57:48CET fru1si  */
/*  - Added check of SPI bits TST and NRO/EOP during steady state */
/*  - Fixed handling of additional fault info */
/*  Revision 4.5 2009/12/07 17:55:40CET jnr1si  */
/*  reran code generator to update module description */
/*  no functional change */
/*  Revision 4.4 2009/11/24 14:08:06CET jnr1si  */
/*  Added constants for the new manaufacturer code used by PAS6 */
/*  part of implementation of PAS6 sensor support */
/*  deliver:Ptedt00032829 */
/*  --- Added comments ---  jnr1si [2009/12/07 16:05:46Z] */
/*  review:Ptedt00042862 */
/*  --- Added comments ---  jnr1si [2009/12/07 16:05:46Z] */
/*  State changed: develop -> tested by jnr1si */
/*  Revision 4.3 2009/11/10 16:39:36CET jnr1si  */
/*  Changed constants for the adapted manufacturer check */
/*  preperation for implementation of PAS6 sensor support */
/*  first step for Ptedt00032829 */
/*  Revision 4.2 2009/10/26 12:35:07CET hkr2kor  */
/*  C_PAS5DCINIT1Timeout_U16X is increased by 60 ms -  */
/*  this is provided to confirm no S2G existed when DC init failure is detected. */
/*  Fix for Ptedt00028280 */
/*  --- Added comments ---  hkr2kor [2009/10/27 08:21:27Z] */
/*  State changed: develop -> ready_for_review by hkr2kor */
/*   */
/*  --- Added comments ---  gnp2kor [2009/11/06 08:40:34Z] */
/*  REVIEWED AND BASELINED-Ptedt00026909_26913_28280_01 */
/*  --- Added comments ---  gnp2kor [2009/11/06 08:40:35Z] */
/*  State changed: ready_for_review -> release by gnp2kor */
/*  Revision 4.1 2009/09/28 20:15:46IST fru1si  */
/*  Fixed typo in struct definition: B_SensingAxix_U4X --> B_SensingAxis_U4X */
/*  --- Added comments ---  fru1si [2009/10/02 14:45:47Z] */
/*  State changed: develop -> reviewed by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2009/10/02 16:36:54Z] */
/*  State changed: reviewed -> tested by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2009/10/02 16:37:02Z] */
/*  State changed: tested -> release by fru1si */
/*  Revision 4.0 2009/09/25 13:26:21CEST fru1si  */
/*  Introduced new ASI interface */
/*  Revision 3.3 2009/08/17 18:03:31IST str3kor  */
/*  Ptedt00032031:Removed B-Sample PAS5XY sensor specific macros and constants.PAS5XY C-Sample changes mapped */
/*  PAS5 sensor specfication(i.e Same as PAS5 ,PAS5Xy also 2 pages in intialization phase 2)  */
/*  --- Added comments ---  str3kor [2009/08/17 12:33:40Z] */
/*  State changed: develop -> ready_for_review by str3kor */
/*  Revision 3.2 2009/04/07 16:14:06IST fru1si  */
/*  Current thresholds adapted according to latest information from EHW3-Schntze. */
/*  Revision 3.1 2008/12/18 17:00:26CET fru1si  */
/*  Re-ran code generator after Hydra update ("#pragma arm" issue) */
/*  --- Added comments ---  fru1si [2008/12/18 16:03:04Z] */
/*  Member revision set by fru1si */
/*  --- Added comments ---  fru1si [2008/12/18 16:04:07Z] */
/*  State changed: develop -> release by fru1si */
/*  Revision 3.0 2008/11/11 12:38:23CET fru1si  */
/*  Merged new functionality from side branch back to trunk: */
/*  - new Algo-SW sensor data interface */
/*  - option constants moved to sem_pes_peripheralsensors */
/*  - PAS5XY support added */
/*  --- Added comments ---  fru1si [2008/11/11 15:59:16Z] */
/*  State changed: develop -> release by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2008/11/11 16:00:59Z] */
/*  State inherited from merged revision. */
/*  --- Added comments ---  fru1si [2008/12/18 10:48:27Z] */
/*  Member revision set by fru1si */
/*  Revision 1.13.1.5 2008/10/29 19:26:23IST juv2kor  */
/*  Two new fields added in ts_Pas5StatusCode to support PASxy Channel2 data */
/*  C_PAS5StatusMessageLength_U8X changed from 16 to 18. New constants to manage Page3 data */
/*  --- Added comments ---  juv2kor [2008/10/29 13:56:33Z] */
/*  State changed: develop -> ready_for_review by juv2kor */
/*  Revision 1.13.1.4 2008/07/31 19:55:58IST hkr2kor  */
/*  Init timeouts are extended by 100 ms for daisy chain sensors. */
/*  --- Added comments ---  hkr2kor [2008/09/24 11:36:30Z] */
/*  State changed: develop -> ready_for_review by hkr2kor */
/*   */
/*  --- Added comments ---  hek3kor [2008/10/23 13:45:10Z] */
/*  REVIEWED AND BASELINED - Ptedt00008564, Ptedt00016033, Ptedt00016235 */
/*  --- Added comments ---  hek3kor [2008/10/23 13:45:11Z] */
/*  State changed: ready_for_review -> reviewed by hek3kor */
/*   */
/*  --- Added comments ---  hek3kor [2008/10/23 13:45:17Z] */
/*  State changed: reviewed -> release by hek3kor */
/*  Revision 1.13.1.3 2008/07/17 17:49:46IST wjd2si  */
/*  Changes after review by ESW3-Frueh on 17.07.08: */
/*  - Parameters of PA5_Init violated the naming rules */
/*  --- Added comments ---  wjd2si [2008/07/17 12:22:25Z] */
/*  State changed: develop -> reviewed by wjd2si */
/*  Revision 1.13.1.2 2008/07/11 10:39:19CEST wjd2si  */
/*  Comment adaption after changes in architecture */
/*  Revision 1.13.1.1 2008/05/29 08:59:02CEST wjd2si  */
/*  Adapted the module to the new interface between Algo and SW. The mean value calculation of the sensor  */
/*  values was shifted from Algo to SEM: */
/*  - Removed B sample support */
/*  - Removed the PAS5 specific option settings. The option settings are now defined centralized in  */
/*    sem_pes_peripheralsensors.h */
/*  - Introduced three new functions (PA5_EvaluateFirstSampleFIQ, PA5_EvaluateSecondSampleFIQ, */
/*    PA5_EvaluateSingleSampleFIQ) which replace the function PA5_EvaluateSensorDataFIQ. This was  */
/*    done to handle the mean value calculation of the sensor values. */
/*  - Added new parameter to PA5_Init to be able to hand over two RT evaluation functions. One for the  */
/*    first and one for the second sample. */
/*  Revision 1.13 2008/05/21 10:09:59CEST fru1si  */
/*  Minor changes to option masks after delta review with ESW3-Widmaier */
/*  --- Added comments ---  fru1si [2008/05/21 08:10:13Z] */
/*  State changed: develop -> reviewed by fru1si */
/*  Revision 1.12 2008/05/20 09:58:05CEST fru1si  */
/*  Rework completed after review with ESW3-Widmaier */
/*  Revision 1.11 2008/04/29 17:51:52CEST fru1si  */
/*  Added support for PAS5R/UFS3R */
/*  --- Added comments ---  fru1si [2008/04/30 10:10:38Z] */
/*  State changed: develop -> ready_for_review by fru1si */
/*  Revision 1.10 2008/02/11 17:36:54CET wjd2si  */
/*  Corrected idiot bugs */
/*  --- Added comments ---  wjd2si [2008/02/18 07:17:09Z] */
/*  Unit design test finished by ESW3-Widmaier on 18.02.2008 without findings */
/*  --- Added comments ---  wjd2si [2008/02/18 07:17:09Z] */
/*  State changed: develop -> tested by wjd2si */
/*  Revision 1.8 2008/01/08 17:45:00CET ngk2si  */
/*  Minor bugfix regarding naming of bitfields. */
/*  --- Added comments ---  ngk2si [2008/01/10 11:16:21Z] */
/*  Delta review with ESW3-Widmaier, no findings. */
/*  --- Added comments ---  ngk2si [2008/01/10 11:16:22Z] */
/*  State changed: develop -> reviewed by ngk2si */
/*   */
/*  --- Added comments ---  ngk2si [2008/01/18 16:10:29Z] */
/*  Unit tests done by ESW3-Kurihara */
/*  --- Added comments ---  ngk2si [2008/01/18 16:10:29Z] */
/*  State changed: reviewed -> release by ngk2si */
/*  Revision 1.7 2008/01/07 16:04:27CET ngk2si  */
/*  - Ptedt00009290: Adapted sensor data bitfields for NEC controllers (big => little endian) */
/*  - added compiler switches to TI specific pragmas (also for NEC) */
/*  - fixed several QAC findings (and added msg. suppression for existing deviations). */
/*  Revision 1.6 2007/06/15 14:00:36CEST wjd2si  */
/*  Added new definiton of additional fault information for the sensor defect fault (and the description) */
/*  --- Added comments ---  wjd2si [2007/06/15 14:45:32Z] */
/*  Delta review to revision 1.5 by ESW3-Angstmann on 15.07.2007 without */
/*  findings */
/*  --- Added comments ---  wjd2si [2007/06/15 14:45:32Z] */
/*  State changed: develop -> reviewed by wjd2si */
/*   */
/*  --- Added comments ---  wjd2si [2007/06/25 09:02:05Z] */
/*  UDT performed by ESW3-Widmaier without findings. Release granted by */
/*  ESW3-Thiel on 25.06.07 */
/*  --- Added comments ---  wjd2si [2007/06/25 09:02:05Z] */
/*  State changed: reviewed -> release by wjd2si */
/*  Revision 1.5 2007/05/14 11:42:34CEST wjd2si  */
/*  Added INIT1 timeout constant */
/*  Revision 1.4 2006/12/04 14:27:07CET ngk2si  */
/*  Fixes CQ ees100005472 */
/*  Updated programmable current Threshold according to new HW Spec 1.9 valid for System Asic CA and  */
/*  Companion Asic BA sample. */
/*  --- Added comments ---  ngk2si [2006/12/04 14:29:52Z] */
/*  Delta review with ESW3-Widmaier, no findings */
/*  --- Added comments ---  ngk2si [2006/12/04 14:29:53Z] */
/*  State changed: develop -> reviewed by ngk2si */
/*   */
/*  --- Added comments ---  ngk2si [2006/12/04 16:38:10Z] */
/*  All delta-tests passed (see SDT 1.2.1.2) */
/*  --- Added comments ---  ngk2si [2006/12/04 16:38:10Z] */
/*  State changed: reviewed -> tested by ngk2si */
/*   */
/*  --- Added comments ---  wjd2si [2007/03/26 11:41:48Z] */
/*  All UDT where a real sensor is needed where rerun with a C sample PAS5 */
/*  sensor by ESW3-Widmaier on 26.03.07 without findings. */
/*  --- Added comments ---  wjd2si [2007/03/26 11:41:49Z] */
/*  State changed: tested -> release by wjd2si */
/*  Revision 1.3 2006/11/20 17:49:00CET ngk2si  */
/*  Added support for C-Sample: Change PAS-Init-Protocol revision (4 instead of 2). */
/*  --- Added comments ---  ngk2si [2006/11/20 17:20:26Z] */
/*  Delta review with AE-OS/ESW3 Widmaier, no findings. */
/*  --- Added comments ---  ngk2si [2006/11/20 17:20:26Z] */
/*  State changed: develop -> reviewed by ngk2si */
/*  Revision 1.2 2006/10/18 18:09:47CEST ngk2si  */
/*  - Realised code-review findings */
/*  - Plausibility check now uses only one sample (newvalue) */
/*  --- Added comments ---  ngk2si [2006/10/19 09:16:02Z] */
/*  reviewed on 16.10.06 */
/*  --- Added comments ---  ngk2si [2006/10/19 09:16:03Z] */
/*  State changed: develop -> reviewed by ngk2si */
/*  Revision 1.1 2006/10/02 15:22:22CEST ngk2si  */
/*  Improved some descriptions (no code-change) */
/*  Revision 1.0 2006/09/29 17:23:28CEST ngk2si  */
/*  Implemented Status data check for B-Sample */
/*  Revision 0.14 2006/08/31 15:29:58CEST ngk2si  */
/*  1st update for B-Samples of PAS5, primarily updated data structures. */
/*  PAS-Init data is not yet checked! */
/*  Revision 0.13 2006/08/28 16:14:14CEST wjd2si  */
/*  Changed parameter, which defines the amount of bytes necessary to store sensor specific data from  */
/*  U8 to U16 to be able to reserve more then 255 Bytes RAM for sensormanagement */
/*  Revision 0.12 2006/08/15 10:06:09CEST wjd2si  */
/*  Added direct include of sem_pes_peripheralsensors to be able to define te_PesBgStates as parameter for */
/*  the BG monitoring function */
/*  Revision 0.11 2006/07/21 10:41:27CEST ngk2si  */
/*  Added struct describing the content of the inital status data (Ford request) */
/*  This struct is now also used for the initial status data decoding. */
/*  Revision 0.10 2006/07/14 09:13:07CEST ngk2si  */
/*  Updaten PAS-Specific data format */
/*  Revision 0.9 2006/05/27 17:09:34CEST ngk2si  */
/*  Changed Pas-Init procedure */
/*  Revision 0.8 2006/05/20 15:01:14CEST ngk2si  */
/*  Regnerated with new codegen */
/*  Revision 0.7 2006/04/21 11:29:39CEST ngk2si  */
/*  Updated API descriptions after Architecture update */
/*  Revision 0.6 2006/04/03 12:57:24CEST ngk2si  */
/*  - Regenerated with new templates */
/*  - updated pas-specific parameters */
/*  Revision 0.5 2006/03/10 15:45:39CET ngk2si  */
/*  Major rework for c-sample, now init-message is received and checked. */
/*  Revision 0.4 2006/02/21 11:08:18CET ngk2si  */
/*  Changed API-names according to new coding rules (FIQ...) */
/*  Revision 0.3 2005/12/28 13:11:15CET ngk2si  */
/*  Corrected naming of enums */
/*  Revision 0.2 2005/12/12 18:01:46CET ngk2si  */
/*  First "working" revision. Only prototype with lots of code commented out! */
/*#end ACD#*/
/* ************************************************************************** */
/* EasyCASE ) */
/* EasyCASE (
   Includes */
/* PRQA S 1-9999 suppress_foreign_warnings_sem_pa5_pas5_h */
/* EasyCASE (
   Standard includes (utils + own header) */
#include "utl_options.p"
#include "utl_tb_typesbase.h"
/* EasyCASE ) */
/* EasyCASE (
   Direct Includes */
#ifdef Y_Option_sem_pes_peripheralsensors
#include "sem_pes_peripheralsensors.h" 
#endif
/* EasyCASE ) */
/* EasyCASE (
   Direct includes for package SEM_SensorMgt */
#include "sem_smr_sensormanager.h" 
#include "sem_std_sensortypedefs.h" 
/* EasyCASE ) */
/* PRQA L:suppress_foreign_warnings_sem_pa5_pas5_h */
/* EasyCASE ) */
/* EasyCASE (
   #Define Constants */
/*#ACD# M(Constants sem_pa5_pas5)  Definitions*/
/* EasyCASE - */
/* HW specific constants */

#define C_PAS5INIT1Timeout_U16X                98u  /* Maximum PAS INIT1 phase startup time (65ms nominal + 50%) */
#define C_PAS5StartupTimeout_U16X             305u  /* Maximum PAS5 startup time (203ms nominal + 50% safety margin) */
        /* Note: 203ms is the slower timing used for the bus mode, other modes would be done within 138,2ms). */

/* Maximum PAS Daisy Chain INIT1 phase startup time (~160 ms start up time + 65ms nominal + 50%) */
/* Start up time includes 60 ms which takes care of internal S2G filtering time - see PLH SDS and Ptedt00028280 */
/* This addition is only applicable for INIT1 timeout, since DCInitFailed fault is detected in INIT1 state only */
#define C_PAS5DCINIT1Timeout_U16X               258u
/* Maximum PAS5 Daisy Chain startup time (~100 ms start up time + 203ms nominal + 50% safety margin) */
#define C_PAS5DCStartupTimeout_U16X             405u

#define C_PAS5StatusMessageLength_U8X          16u  /* PAS5 sends 16 bytes of status data */
#define C_PAS5SerialNumberLength_U8X            6u  /* PAS5 has a 6 byte serial number */

#define C_PAS5PasIfSettings_U8X              0x03u  /* => 000X XXXY: X = current threshold, Y = 8/10bit */
        /* Current setting: 0001 (15mA) + 10 bit, see HW-Spec "Software relevant features for SISSI PAS-IF, v1.9 */
#define C_PAS5RPasIfSettings_U8X             0x09u  /* => 000X XXXY: X = current threshold, Y = 8/10bit */
        /* Current setting: 0100 (18mA) + 10 bit, see HW-Spec "Software relevant features for SISSI PAS-IF, v1.9 */

/* Thresholds for plausibility check */
#define C_PAS5SignalPlausiThreshold_U16X       60u  /* Signal threshold used for a sensor plausibility fault (LSB) */
#define C_PAS5SignalPlausiTimeThreshold_U16X  100u  /* Samples used for a sensor plausibility fault
                                                     * (100 samples * 10ms => 1s) */
/* EasyCASE - */
/* Constants for the PAS init data  - see PAS5 spec */

/* Global status data constants */
#define C_PAS5FirstPageComplete_U32X        0x0000FFFFu   /* 16 messages from first page received */
#define C_Pas5StatusMessagesComplete_U32X   0xFFFFFFFFu   /* All 32 messages received */
#define C_PAS5IndexSecondPage_U8X           16u           /* Each page has 16 entries */

/* Data 1+2: Protocol information part A (always constant) */
#define C_PAS5SdProtocolCSampleA_U8X        0x42u /* Protocol-Revision 4, length 2 */
/* Data 3  : Protocol informatino part B */
#define C_PAS5SdProtocolCSampleB_U8X        0x00u /* length information part B */

/* Data 4+5: Manufacturer information */
/* Bit wise according to PSI5 spec 1.3 */
#define C_PAS5ManuBoschBIT_U8X              0x10u
#define C_PAS5ManuVdoBIT_U8X                0x20u
#define C_PAS5ManuAutolivBIT_U8X            0x40u
#define C_PAS5ManuTemicBIT_U8X              0x80u
/* ASCII coded according to PSI5 spec 1.4 for PAS6 support */
#define C_PAS5ManuBoschASCII_U8X            0x42u
#define C_PAS5ManuAutolivASCII_U8X          0x41u
#define C_PAS5ManuTemicASCII_U8X            0x43u
#define C_PAS5ManuTrwASCII_U8X              0x54u

/* Data 6: Bus mode for PAS5(R)/ sensor acceleration type for PAS5XY */
#define C_PAS5SensorTypePas5xy_U8X          0x00u /* This constant is fixed only for PAS5XY sensor */              

/* Data 7 (fixed): Acceleration sensor: 0001 */
#define C_PAS5SensorType_U8X                0x01u

/* Data 8: Sensing axis  */

/* Data 9: Measurement range => UFS or PAS or PAS5XY*/
#define C_PAS5Range120g_U8X                  0x08u    /* also named 100g */
#define C_PAS5Range240g_U8X                  0x09u    
#define C_PAS5Range480g_U8X                  0x0Au    /* also named 400g */
/* Remaining range of 960g are not realized */

/* Data 10: Sensor filter frequency and SMB axis */
/* EasyCASE - */
/* Additional fault information masks for sensor defect fault
 *
 * Meaning of the bits (6 bit additional fault information)
 * pu dddd
 *
 * d = Additional fault information which the sensor sends together with the "Sensor defect" message
 *     Therefore these bits cannot be used for other purposes.
 * u = Sensor sends "Sensor ready but unlocked" message
 * p = Error occurred during daisy chain programming
 */

#define M_PAS5ReadyUnlocked_U8X               0x10u
#define M_PAS5ReadyOnlyBit1Locked_U8X         0x10u
#define M_PAS5DaisyChainProgrammingError_U8X  0x20u
/* EasyCASE - */
/*#end ACD#*/
/* EasyCASE ) */
/* EasyCASE (
   ENUM and struct Definitions */
/*#ACD# M(Enums sem_pa5_pas5)  Enums*/
/*#end ACD#*/
/*#ACD# M(Enums sem_pa5_pas5 leadout)  Enums*/
/* EasyCASE C */
/* Structure for part 1 of the PAS5 init data.
 * Due to different endianess in TI and NEC controllers, the bitfield
 * definitions must be made uC specific (see AB10_60J20_017).
 */
typedef struct
   {
   #if defined ab10andromeda
   U32 B_ProtocolA_U8X     : 8;   /* Data 1..2  : Protocol revision and length part A */
   U32 B_ProtocolB_U4X     : 4;   /* Data 3     : Protocol revision and length part B */
   U32 B_ManufacturerA_U4X : 4;   /* Data 4     : Manufacturer part A */
   U32 B_ManufacturerB_U4X : 4;   /* Data 5     : Manufacturer part B */
   U32 B_ModeOrType_U4X    : 4;   /* Data 6     : Mode (async, bus, ...) and sending current for PAS5(R) / PAS5xy sensor type */
   U32 B_Type_U4X          : 4;   /* Data 7     : Sensor type (fixed to acceleration sensor) */
   U32 B_SensingAxis_U4X   : 4;   /* Data 8     : Sensing axis (alpha, beta or gamma) */
   #elif defined ab10nec
   U32 B_ProtocolA_U8X     : 8;   /* Data 1..2  : Protocol revision and length part A */
   U32 B_ManufacturerA_U4X : 4;   /* Data 4     : Manufacturer part A */
   U32 B_ProtocolB_U4X     : 4;   /* Data 3     : Protocol revision and length part B */
   U32 B_ModeOrType_U4X    : 4;   /* Data 6     : Mode (async, bus, ...) and sending current for PAS5(R) / PAS5xy sensor type */
   U32 B_ManufacturerB_U4X : 4;   /* Data 5     : Manufacturer part B */
   U32 B_SensingAxis_U4X   : 4;   /* Data 8     : Sensing axis (alpha, beta or gamma) */
   U32 B_Type_U4X          : 4;   /* Data 7     : Sensor type (fixed to acceleration sensor) */
   #else
      #error unsupported uC type!
   #endif
   } ts_Pas5StatusPart1;
/* EasyCASE E */
/* EasyCASE C */
/* Structure for part 2 of the PAS5 init data. */
typedef struct
   {
   #if defined ab10andromeda
   U32 B_Range_U4X         :  4;   /* Data 9     : Sensor range (120..480g) */
   U32 B_Filter_U1X        :  1;   /* Data 10    : Filter (200 or 400Hz) */
   U32 B_SMBDir_U1X        :  1;   /* Data 10    : SMB axis */
   U32 B_SGBCodeA_U2X      :  2;   /* Data 10    : SGB housing code part A */
   U32 B_SGBCodeB_U4X      :  4;   /* Data 11    : SGB housing code part B */
   U32 B_CustomerCodeA_U4X :  4;   /* Data 12    : Sensor code customer part A */
   U32 B_CustomerCodeB_U8X :  8;   /* Data 13..14: Sensor code customer part B */
   U32                     :  2;   /* Data 15    : 2 bits padding */
   U32 B_DateUpper_U6X     :  6;   /* Data 15..16: SGB manufacturing data (Bit 8..13) */
   #elif defined ab10nec
   U32 B_SGBCodeA_U2X      :  2;   /* Data 10    : SGB housing code part A */
   U32 B_SMBDir_U1X        :  1;   /* Data 10    : SMB axis */
   U32 B_Filter_U1X        :  1;   /* Data 10    : Filter (200 or 400Hz) */
   U32 B_Range_U4X         :  4;   /* Data 9     : Sensor range (120..480g) */
   U32 B_CustomerCodeA_U4X :  4;   /* Data 12    : Sensor code customer part A */
   U32 B_SGBCodeB_U4X      :  4;   /* Data 11    : SGB housing code part B */
   U32 B_CustomerCodeB_U8X :  8;   /* Data 13..14: Sensor code customer part B */
   U32 B_DateUpper_U6X     :  6;   /* Data 15..16: SGB manufacturing data (Bit 8..13) */
   U32                     :  2;   /* Data 15    : 2 bits padding */
   #else
      #error unsupported uC type!
   #endif
   } ts_Pas5StatusPart2;
/* EasyCASE E */
/* EasyCASE C */
/* Complete structure for the pas-init data */
typedef struct
   {
   ts_Pas5StatusPart1 S_Part1_XXX;   /* Data 1..8  : First word of status data */
   ts_Pas5StatusPart2 S_Part2_XXX;   /* Data 9..16 : Second word of status data */
   U8 V_DateLower_U8X;               /* Data 17..18: SGB manufacturing data (Bit 0..7) */
   U8 V_LotLineNo_U8X;               /* Data 19..20: SGB Lot and line number */
   U8 A_SerialNumber_U8X[C_PAS5SerialNumberLength_U8X]; /* Sensor serial number */
   } ts_Pas5StatusCode;
/* EasyCASE E */
/* EasyCASE C */
/* Contains the data needed for a single PAS5
 * Attention: this struct must be word-aligned (size % 4 = 0) */
typedef struct
   {
   U8      A_SensorStatusCodeINTW_U8X[C_PAS5StatusMessageLength_U8X]; /* PAS5 status message */
   S16     V_FirstSampleValueINTW_S16X;                               /* First received sample value */
   U16     V_Dummy_U16X;                                              /* To have the whole structure word aligned */
   } ts_Pas5SpecificData;
/* EasyCASE E */
#define C_PAS5SpecificRamSize_U16X      sizeof(ts_Pas5SpecificData)
/* EasyCASE - */
/*#end ACD#*/
/* EasyCASE ) */
/* EasyCASE (
   Public API Declarations */
/* EasyCASE ) */
/* EasyCASE (
   Package protected API Declarations */
#ifdef Y_INC_FROM_PKG_SEM_SensorMgt
/* EasyCASE (
   PA5_Init */
/******************************************************************************
 * Description:
 *    Initializes the handling for a PAS5 sensor by
 *    - allocating RAM for this sensor
 *    - writing PAS5 specific settings into call by reference parameters
 *    - setting BG monitoring function to call for this sensor
 *    - setting up specific values in peripheral sensors data tables
 *    - setting the sensor's initial state
 * 
 * Arguments:
 *    - v_sensor_u8r               : index of current sensor
 *    - p_pesIfSettings_u8r        : pointer to settings for PES-IF
 *    - p_pas5FirstSampleFIQFp_xfr : pointer to FIQ evaluation function for the
 *      first sample of the PAS5
 *    - p_pas5SecondSampleFIQFp_xfr: pointer to FIQ evalution function for the
 *      second sample of the PAS5
 *      Note: Parameters two, three and four are call by reference!
 * 
 * Return: -
 * 
 * Scheduling:
 *    Called once in 10ms background after configuration data is available.
 * 
 * Usage guide: -
 * 
 * Remarks: -
 ******************************************************************************/
void PA5_Init(U8 v_sensor_u8r, U8 * p_pesIfSettings_u8r, tp_SensorSpecificFunction * p_pas5FirstSampleFIQFp_xfr, tp_SensorSpecificFunction * p_pas5SecondSampleFIQFp_xfr );
/* EasyCASE ) */
/* EasyCASE (
   PA5_EvaluateSingleSampleFIQ */
/******************************************************************************
 * Description:
 *    Function is called during the real-time interrupt if the PAS5 is a 2kHz
 *    sensor (e.g. synchronous) for the received sensor value.
 *    It performs the real-time checks (data in range, etc.) and writes valid
 *    results into the sensor data PDI.
 * 
 * Arguments:
 *    - v_rawData_u16r: raw sensor data received from the sensor
 *    - v_sensor_u8r  : index of the sensor
 *    - v_channel_u8r : index of the channel (not used)
 * 
 * Return: -
 * 
 * Scheduling:
 *    Real-time
 * 
 * Usage guide:
 *    This function is called via function pointer by the sensor manager and
 *    evaluates one sensor sample. For that to work the pointer to this
 *    function and its parameters are stored inside the sensor manager during
 *    initialization (see SMR_AddSensorChannel).
 * 
 * Remarks:
 *    As this function is called during real-time for each PAS5, it obviously
 *    has to be highly runtime optimized.
 ******************************************************************************/
void PA5_EvaluateSingleSampleFIQ(U16 v_rawData_u16r, U8 v_sensor_u8r, U8 v_channel_u8r );
/* EasyCASE ) */
/* EasyCASE (
   PA5_EvaluateFirstSampleFIQ */
/******************************************************************************
 * Description:
 *    Function is called during the real-time interrupt for the first received
 *    sensor value of a PAS5 (for old value).
 *    It performs the real-time checks (data in range, etc.) and keeps the
 *    sensor value for the mean value calculation by
 *    PA5_EvaluateSecondSampleFIQ.
 * 
 * 
 * Arguments:
 *    - v_rawData_u16r: raw sensor data received from the sensor via SPI
 *    - v_sensor_u8r  : index of the sensor
 *    - v_channel_u8r : index of the channel (not used)
 * 
 * Return: -
 * 
 * Scheduling:
 *    Real-time
 * 
 * Usage guide:
 *    This function is called via function pointer by the sensor manager and
 *    evaluates one sensor channel. For that to work the pointer to this
 *    function and its parameters are stored inside the sensor manager during
 *    initialization (see SMR_AddSensorChannel).
 * 
 * Remarks:
 *    As this function might be called twice for every PAS5, it obviously has
 *    to be highly runtime optimized.
 ******************************************************************************/
void PA5_EvaluateFirstSampleFIQ(U16 v_rawData_u16r, U8 v_sensor_u8r, U8 v_channel_u8r );
/* EasyCASE ) */
/* EasyCASE (
   PA5_EvaluateSecondSampleFIQ */
/******************************************************************************
 * Description:
 *    Function is called during the real-time interrupt for the second received
 *    sensor value of a PAS5 (for new value).
 *    It performs the real-time checks (data in range, etc.), does the mean
 *    value calculation and writes valid results into the sensor data PDI.
 * 
 * Arguments:
 *    - v_rawData_u16r: raw sensor data received from the sensor
 *    - v_sensor_u8r  : index of the sensor
 *    - v_channel_u8r : index of the channel (not used)
 * 
 * Return: -
 * 
 * Scheduling:
 *    Real-time
 * 
 * Usage guide:
 *    This function is called via function pointer by the sensor manager and
 *    evaluates one sensor sample. For that to work the pointer to this
 *    function and its parameters are stored inside the sensor manager during
 *    initialization (see SMR_AddSensorChannel).
 * 
 * Remarks:
 *    As this function is called during real-time for each PAS5, it obviously
 *    has to be highly runtime optimized.
 ******************************************************************************/
void PA5_EvaluateSecondSampleFIQ(U16 v_rawData_u16r, U8 v_sensor_u8r, U8 v_channel_u8r );
/* EasyCASE ) */
/* EasyCASE (
   PA5_BackGroundMonitoring10ms */
/******************************************************************************
 * Description:
 *    Performs the background monitoring specific for PAS5 sensors.
 * 
 * Arguments:
 *    - v_sensor_u8r : index of current sensor in the data table in the
 *      sem_pes_peripheralsensors module
 *    - e_BGstate_xxr: current BG monitoring state
 * Return: -
 * 
 * Scheduling:
 *    Called once for each PAS5 in each 10ms background cycle.
 * 
 * Usage guide:
 *    Called by sem_pes_peripheralsensors module via function pointer.
 * 
 * Remarks: -
 ******************************************************************************/
void PA5_BackGroundMonitoring10ms(U8 v_sensor_u8r, te_PesBgStates e_BGstate_xxr );
/* EasyCASE ) */
#endif
/* EasyCASE ) */
#endif
/* EasyCASE ) */
