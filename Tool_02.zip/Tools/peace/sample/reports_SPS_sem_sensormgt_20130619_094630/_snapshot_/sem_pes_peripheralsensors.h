/* EasyCASE V6.5 01.01.2008 00:00:00 */
/* EasyCASE O
If=vertical
LevelNumbers=no
LineNumbers=no
Colors=16777215,0,12582912,12632256,0,0,0,16711680,8388736,0,33023,32768,0,0,0,0,0,32768,12632256,255,65280,255,255,16711935
ScreenFont=Courier New,,80,4,-11,0,400,0,0,0,0,0,0,3,2,1,49,96,96
PrinterFont=Courier New,,80,4,-66,0,400,0,0,0,0,0,0,3,2,1,49,600,600
LastLevelId= */
/* EasyCASE (
   sem_pes_peripheralsensors.h */
#ifndef Y_sem_pes_peripheralsensorsH
#define Y_sem_pes_peripheralsensorsH
/* EasyCASE - */
/*#ACD# M(Bosch Copyright) */
/* ************************************************************************** */
/*                                                                            */
/*  Copyright (c) 13/05/2008 Robert Bosch GmbH, Germany                             */
/*                All rights reserved                                         */
/*                                                                            */
/* ************************************************************************** */
/*#end ACD#*/
/*#ACD# M(sem_pes_peripheralsensors Header Author) Author*/
/*  $Source: sem_pes_peripheralsensors.h
 *  $Revision: 1.1 $
 *  $Author: Reddivari Devendra Kumar (RBEI/ESA-PP) (dvn2kor) $
 */
/*#end ACD#*/
/* ************************************************************************** *
 *  Description:
 * This module manages the common handling of all peripheral sensors.
 * 
 * It features:
 * - the data interface for peripheral sensors to the rest of the system
 * - the logical functionality for the handling of peripheral sensors and PES
 *   lines
 * - all power related stuff (switching lines, shortage detection...)
 * - functions to enable/disable peripheral sensors
 * - common background monitoring functions (e.g. the handling of communication
 *   errors)
 * - functions to gather information about the connected sensors
 * 
 * Sensor specific implementations are located inside specific modules, e.g.
 * sem_pa4_pas4. Each sensor's special features are handled there:
 * - sensor real-time data processing
 * - sensor initialization
 * - specific background monitoring
 * 
 * PES interface specific implementations are located inside specific modules,
 * e.g. sem_ifs_pasifsissi. Each ASIC's special features are handled there:
 * - control of initial programming
 * - physical control of the chips via SPI
 * 
 * The sensor specific real-time data processing is called directly by the
 * sensor manager, therefore there is no real-time part in this module.
 * 
 * Projects without any peripheral sensors do not use this module.
 *
 *
 *  Reference to Documentation:  sem_pes_peripheralsensors_SDS.HTML
 */
/* ********************** Framecode-Generator V2.0 ************************** */
/* EasyCASE (
   History */
/* ****************************** History *********************************** */
/*#ACD# M(sem_pes_peripheralsensors Header) History*/
/*  $Log: peace/sample/reports_SPS_sem_sensormgt_20130619_094630/_snapshot_/sem_pes_peripheralsensors.h  $ */
/*  Revision 1.1 2013/07/31 00:03:31ICT Reddivari Devendra Kumar (RBEI/ESA-PP) (dvn2kor)  */
/*  Initial revision */
/*  Member added to project g:/MKS/Projects/TurboLIFT/Tools/Tools.pj */
/*  Revision 1.1 2013/06/19 06:18:59MESZ Vernon Hawes (RBEI/ESA1) (ver6cob)  */
/*  Initial revision */
/*  Member added to project g:/MKS/Projects/TurboLIFT/Projects/AB12/AB12.pj */
/*  Revision 5.13 2012/10/08 15:23:33IST Frueh Manuel (CC-PS/EPS3) (fru1si)  */
/*  Added constants for PESPlausi fault mask. */
/*  --- Added comments ---  fru1si [2012/10/08 09:56:18Z] */
/*  No functional change in the module. Reviewed via walkthrough by ESA2-Bibhuti without findings on 2012/10/8. */
/*  --- Added comments ---  fru1si [2012/10/08 09:56:18Z] */
/*  State changed: develop -> release by fru1si */
/*  Revision 5.12 2012/08/29 10:09:15MESZ fru1si  */
/*  Added FLTDESC and FLTREACTION comments for line faults. */
/*  Only comments added, no functional change --> previous state is taken over. */
/*  --- Added comments ---  fru1si [2012/08/29 08:09:24Z] */
/*  State changed: develop -> release by fru1si */
/*  Revision 5.11 2012/07/03 11:32:46MESZ hkr2kor  */
/*  Renamed plausi fault masks detected by algo.  */
/*  As the fault masks are not relevant or distinguishable by algo, a single fault mask is used. */
/*  --- Added comments ---  hkr2kor [2012/07/05 08:27:52Z] */
/*  State changed: develop -> ready_for_review by hkr2kor */
/*   */
/*  --- Added comments ---  hkr2kor [2012/07/05 08:27:59Z] */
/*  Delta review done by EPS3-Frueh, no findings. */
/*  --- Added comments ---  hkr2kor [2012/07/05 08:27:59Z] */
/*  State changed: ready_for_review -> reviewed by hkr2kor */
/*   */
/*  --- Added comments ---  hkr2kor [2012/07/06 10:34:49Z] */
/*  deliver:Ptedt00115042 */
/*  --- Added comments ---  hkr2kor [2012/07/06 14:53:15Z] */
/*  State changed: reviewed -> release by hkr2kor */
/*  Revision 5.10 2012/06/01 15:40:12MESZ hkr2kor  */
/*  Added API for algo, for the algo sensor watchdog feature. */
/*  Added the PES plausibility fault masks. */
/*  --- Added comments ---  hkr2kor [2012/06/01 13:48:29Z] */
/*  State changed: develop -> ready_for_review by hkr2kor */
/*   */
/*  --- Added comments ---  hkr2kor [2012/06/04 12:57:20Z] */
/*  review:Ptedt00110844 */
/*  --- Added comments ---  hkr2kor [2012/06/04 12:57:20Z] */
/*  State changed: ready_for_review -> reviewed by hkr2kor */
/*   */
/*  --- Added comments ---  hkr2kor [2012/06/06 14:18:32Z] */
/*  State changed: reviewed -> release by hkr2kor */
/*  Revision 5.9 2011/09/29 13:20:30MESZ fru1si  */
/*  Moved local function to check for stored permanent fault to a new API. */
/*  --- Added comments ---  fru1si [2011/09/29 11:24:26Z] */
/*  review:Ptedt00085070 */
/*  --- Added comments ---  fru1si [2011/09/29 11:24:43Z] */
/*  State changed: develop -> reviewed by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2011/09/29 12:43:22Z] */
/*  State changed: reviewed -> tested by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2011/09/29 13:45:29Z] */
/*  State changed: tested -> release by fru1si */
/*  Revision 5.8 2011/03/23 16:32:55CET fru1si  */
/*  Added fault reaction. */
/*  Only comments added. No functional change. */
/*  Release state taken over. */
/*  --- Added comments ---  fru1si [2011/03/23 15:33:04Z] */
/*  State changed: develop -> release by fru1si */
/*  Revision 5.7 2011/02/14 12:40:10CET bhs6kor  */
/*  removed API */
/*  --- Added comments ---  bhs6kor [2011/02/18 08:46:52Z] */
/*  State changed: develop -> reviewed by bhs6kor */
/*   */
/*  --- Added comments ---  rdd3kor [2011/02/18 13:37:08Z] */
/*  REVIEWED AND BASELINED */
/*  --- Added comments ---  rdd3kor [2011/02/18 13:37:09Z] */
/*  State changed: reviewed -> release by rdd3kor */
/*  Revision 5.6 2011/02/07 13:52:53IST bhs6kor  */
/*  added new API PES_CheckChannelFault */
/*  Revision 5.5 2010/11/25 20:01:01IST fru1si  */
/*  Corrected typo in API description. */
/*  --- Added comments ---  fru1si [2010/11/25 14:32:16Z] */
/*  review:Ptedt00062972 */
/*  --- Added comments ---  fru1si [2010/11/25 14:32:16Z] */
/*  State changed: develop -> reviewed by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2010/11/26 13:19:16Z] */
/*  State changed: reviewed -> tested by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2010/11/26 14:26:53Z] */
/*  State changed: tested -> release by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2010/11/26 14:46:23Z] */
/*  deliver:Ptedt00059236 */
/*  Revision 5.3 2010/11/02 12:30:28CET fru1si  */
/*  Minor layout change to the module description due to new code generator. */
/*  No change of content. Previous state is taken over. */
/*  Revision 5.2 2010/10/26 11:52:08CEST fru1si  */
/*  Removed obsolete constants to set up CG107/CF190. */
/*  Moved all fault descriptions to a single location. */
/*  Revision 5.1 2010/08/05 10:04:26CEST fru1si  */
/*  - Removed DCU from AB10lib sensor management. */
/*  - Adapted UML model for cust specific sensor modules (dependencies to lib APIs, separate header for struct definitions). */
/*  - Re-ran code generator with latest templates. */
/*  - No functional change --> previous state is taken over. */
/*  --- Added comments ---  fru1si [2010/08/05 08:10:49Z] */
/*  State changed: develop -> release by fru1si */
/*  Revision 4.10 2010/03/31 09:53:59CEST fru1si  */
/*  Re-ran code generator. State taken over from previous revision. */
/*  Revision 4.9 2010/03/31 09:49:14CEST fru1si  */
/*  Corrected Diagsym comment for F_UsedPESLines_U16X. */
/*  Revision 4.8 2010/02/23 16:21:38CET fru1si  */
/*  Added two APIs again which were wrongfully removed: */
/*   - PES_GetPasTypeALL */
/*   - PES_ReadPESStatusALL */
/*  Revision 4.7 2010/01/25 12:57:48CET fru1si  */
/*  - Added check of SPI bits TST and NRO/EOP during steady state */
/*  - Fixed handling of additional fault info */
/*  Revision 4.6 2009/12/17 11:58:26CET jnr1si  */
/*  New API PES_HandleVSyncLowMsgFIQ() */
/*  Revision 4.5 2009/12/07 17:54:19CET jnr1si  */
/*  Moved ER check in case of a "Vsync low" message from BG to realtime. */
/*  Updated API description */
/*  fix:Ptedt00041598 */
/*  --- Added comments ---  jnr1si [2009/12/08 15:48:38Z] */
/*  review:Ptedt00043377 */
/*  --- Added comments ---  jnr1si [2009/12/08 15:48:38Z] */
/*  State changed: develop -> reviewed by jnr1si */
/*  Revision 4.4 2009/11/24 10:50:39CET FKS2SI  */
/*  Support of 32 PES channels instead of 16 PES channels, see CQ for details. */
/*  fix:Ptedt00040995 DCU - AB10 Ext.Line  Rebootverhalten im Fehlerfall */
/*                                 sowie Verhalten bei fehlerhafter Ausstattung fehlerhaft */
/*  --- Added comments ---  FKS2SI [2009/11/26 15:42:36Z] */
/*  Delta review done by ESW3-Thiel, no findings. */
/*  --- Added comments ---  FKS2SI [2009/11/26 15:42:36Z] */
/*  State changed: develop -> reviewed by FKS2SI */
/*   */
/*  --- Added comments ---  FKS2SI [2009/11/26 15:45:56Z] */
/*  Release activities done for the changes from revision 4.3 to 4.4. */
/*  But previous revision is in tested state only, */
/*  so this revision changes to tested too only. */
/*  --- Added comments ---  FKS2SI [2009/11/26 15:45:56Z] */
/*  State changed: reviewed -> tested by FKS2SI */
/*  Revision 4.3 2009/10/12 13:34:56CEST fru1si  */
/*  Introduced new optional interface sem_csf_custsensorfaulthandler. This can be used */
/*  to implement additional fault handling actions when a line fault is qualified by the platform. */
/*  --- Added comments ---  fru1si [2009/10/14 13:24:33Z] */
/*  State changed: develop -> tested by fru1si */
/*  Revision 4.2 2009/10/02 12:46:04CEST fru1si  */
/*  Corrected review findings (see Ptedt00038969). */
/*  --- Added comments ---  fru1si [2009/10/02 14:45:47Z] */
/*  State changed: develop -> reviewed by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2009/10/02 16:36:53Z] */
/*  State changed: reviewed -> tested by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2009/10/02 16:37:01Z] */
/*  State changed: tested -> release by fru1si */
/*  Revision 4.1 2009/09/29 17:21:05CEST fru1si  */
/*  Re-ran code generator after UML model update. */
/*  Revision 4.0 2009/09/25 13:26:04CEST fru1si  */
/*  Introduced new ASI interface */
/*  Revision 3.12 2009/08/28 12:31:46CEST fru1si  */
/*  Fixed handling of "Vsync low" messages when ER is low. */
/*  Also reran code generator. */
/*  fix:Ptedt00027988 */
/*   */
/*  Revision 3.11 2009/08/28 11:35:42CEST fru1si  */
/*  Fixed handling of "Vsync low" messages when ER is low. */
/*  fix:Ptedt00027988 */
/*  Revision 3.9 2009/08/17 14:49:18CEST str3kor  */
/*  Ptedt00032031:Added sensing axis(betta and alpha) and filter mode(213/426 Hz) constants for PAS5XY C-Sample Specification */
/*  --- Added comments ---  str3kor [2009/08/17 12:49:39Z] */
/*  READY FOR REVIEW -Ptedt00032031_01 */
/*  --- Added comments ---  str3kor [2009/08/17 12:49:40Z] */
/*  State changed: develop -> ready_for_review by str3kor */
/*  Revision 3.8 2009/07/29 20:56:47IST hkr2kor  */
/*  Changed option test strategy as per SCR 08_056 : Ptedt00017006 */
/*  Removed another unused constant */
/*  --- Added comments ---  hkr2kor [2009/07/29 15:30:04Z] */
/*  State changed: develop -> ready_for_review by hkr2kor */
/*   */
/*  --- Added comments ---  hkr2kor [2009/07/30 15:19:07Z] */
/*  Reviewed delta changes from 3.7 */
/*  --- Added comments ---  hkr2kor [2009/07/30 15:19:08Z] */
/*  State changed: ready_for_review -> reviewed by hkr2kor */
/*  Revision 3.7 2009/06/18 20:53:56IST fru1si  */
/*  Added handling of DCU sensors. */
/*  Revision 3.6 2009/05/14 12:25:44CEST fru1si  */
/*  Corrected findings after review with ESW3-Jonkmann. */
/*  See also Ptedt00029742. */
/*  Adapted local variables to U32 according to design rules. */
/*  Also fixed typos in comments. */
/*  Revision 3.5 2009/04/07 15:45:14CEST jnr1si  */
/*  moved constants for the configuration of PSI lines from sem_ifp_pasifsaphir.h to this file, because they are also used by the new CF190 modul */
/*  Revision 3.4 2009/03/16 12:05:42CET jnr1si  */
/*  Added new init state for the initialization of the new pas-interface ASIC CF190 */
/*   */
/*  -> TE: Ptedt00020485 */
/*  Revision 3.3 2009/01/30 11:35:22CET fru1si  */
/*  Added Diagsym comments for additional fault info bit masks. */
/*  Only comments changed so release status from previous revision is taken over. */
/*  --- Added comments ---  fru1si [2009/01/30 10:36:40Z] */
/*  State changed: develop -> release by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2009/01/30 10:36:46Z] */
/*  Member revision set by fru1si */
/*  Revision 3.2 2009/01/23 09:42:03CET gge2si  */
/*  Add MASKS for additional fault information (MASKS PasExtCommFlt) */
/*  --- Added comments ---  gge2si [2009/01/23 08:42:20Z] */
/*  Member revision set by gge2si */
/*  Revision 3.1 2008/12/18 17:00:24CET fru1si  */
/*  Re-ran code generator after Hydra update ("#pragma arm" issue) */
/*  --- Added comments ---  fru1si [2008/12/18 16:03:03Z] */
/*  Member revision set by fru1si */
/*  --- Added comments ---  fru1si [2008/12/18 16:04:06Z] */
/*  State changed: develop -> release by fru1si */
/*  Revision 3.0 2008/12/18 06:24:37CET hkr2kor  */
/*  Merged the developments on the branches to the main path. */
/*  - New Algo SW Interface updates */
/*  - Daisy chain sensor configuration supported */
/*  - Updated handling when reboot limits are limited */
/*  - PAS5XY sensors supported */
/*  - Companion ASIC IF module dropped. */
/*  --- Added comments ---  fru1si [2008/12/18 10:49:33Z] */
/*  Member revision set by fru1si */
/*  --- Added comments ---  fru1si [2008/12/18 10:49:51Z] */
/*  Take over state from merged revision. */
/*  --- Added comments ---  fru1si [2008/12/18 10:49:53Z] */
/*  State changed: develop -> release by fru1si */
/*  Revision 2.42.1.3.1.4 2008/10/20 18:30:24IST hkr2kor  */
/*  To avoid huge runtime issues, the sync settings and data rate settings are fetched once in PES. */
/*  This is a intermediate solution for now. Here, its just a rerun of code-gen. */
/*  --- Added comments ---  hek3kor [2008/10/23 13:54:24Z] */
/*  REVIEWED AND BASELINED - Ptedt00008564, Ptedt00016033, Ptedt00016235 */
/*  --- Added comments ---  hek3kor [2008/10/23 13:54:26Z] */
/*  State changed: develop -> reviewed by hek3kor */
/*   */
/*  --- Added comments ---  hek3kor [2008/10/23 13:54:31Z] */
/*  State changed: reviewed -> release by hek3kor */
/*   */
/*  --- Added comments ---  hkr2kor [2008/11/24 15:12:08Z] */
/*  Member revision set by hkr2kor on variant CG107_Saphir */
/*  Revision 2.42.1.3.1.3 2008/10/10 15:59:08IST hkr2kor  */
/*  - Switch ON of a bus sensor line could give Manchester error or Parity error. */
/*     This is ignored while doing option tests until a defined threshold is reached -  */
/*     counter introduced for this purpose. */
/*  - Unused V_PasTimer_U16X removed */
/*  - Cosmetic changes in API descriptions */
/*  Revision 2.42.1.3.1.2 2008/09/10 16:55:05IST hkr2kor  */
/*  Companion ASIC init state enum removal taken from the original branch */
/*  Revision 2.42.1.3.1.1 2008/07/31 19:49:26IST hkr2kor  */
/*  10 ms BG function gets an input parameter to avoid integration error - Ptedt00016033 */
/*  Revision 2.42.1.3 2008/07/24 15:52:07IST wjd2si  */
/*  Changes after review by Hemanth Nayak (RBEI/EAE1) / Manuel Frnh (CC-OS/ESW3): */
/*  - Added constant for expected SPI bits */
/*  - Changed prefix for masks from C_ to M_ */
/*  Revision 2.42.1.2 2008/06/13 15:28:02CEST wjd2si  */
/*  - Added constant for indent of absolute pressure options for PPS */
/*  Revision 2.42.1.1 2008/05/28 16:39:15CEST wjd2si  */
/*  Adapted the module to the new interface between Algo and SW. The mean value calculation of the sensor  */
/*  values was shifted from Algo to SEM: */
/*  - Unified the option constants for all the different sensor types. They are now located in this file */
/*  - The array holding the old and the new value was removed (A_SensorValue_S16X) and a new array */
/*    with half the size and a different name was introduced for the mean values (A_MeanValue_S16X). The */
/*    name change was done to avoid using incompatible versions of files between Algo and SEM. */
/*  - Introduced a new function PES_CallPasSpecificInit which handles the initialization of the sensor */
/*    types which are supported by the platform (at the moment: PAS4, PAS5(R), PPS1 and PPS2)  */
/*  Revision 2.42 2008/05/14 15:40:22CEST hkr2kor  */
/*  Inserted a separate state for the saphir in the pes init2 state machine. */
/*  Revision 2.41 2008/04/30 12:39:27IST fru1si  */
/*  Merged with branch 2.38.1.1 */
/*  Revision 2.39 2008/03/05 10:17:57CET hkr2kor  */
/*  PES BG monitoring split into 3 parts, to be executed within same 10 ms slice, to  */
/*  distribute the high runtime load in different 10 ms BG process. */
/*   */
/*  Requires the SMR_BackGroundMonitoring2 which calls this function to be  */
/*  called thrice in every 10 ms (one in each 10 ms process). */
/*  --- Added comments ---  wjd2si [2008/03/10 07:29:20Z] */
/*  Delta review to revision 2.38 without finding done by ESW3-Widmaier on 10.03.2008 */
/*  --- Added comments ---  wjd2si [2008/03/10 07:29:21Z] */
/*  State changed: develop -> reviewed by wjd2si */
/*  Revision 2.38 2008/02/26 17:08:36CET hkr2kor  */
/*  Sync Pulse voltage monitoring constants added in the branch, brought back to main path. */
/*  --- Added comments ---  wjd2si [2008/02/28 07:10:19Z] */
/*  Set to release after delta review without findings by ESW3-Widmaier on 28.02.2008. */
/*  No changes to existing code. Only two new constants/masks where added. */
/*  --- Added comments ---  wjd2si [2008/02/28 07:10:19Z] */
/*  State changed: develop -> release by wjd2si */
/*  Revision 2.37 2008/02/12 15:08:45CET wjd2si  */
/*  Corrected diagsym comments of structure ts_PesInternalData */
/*  Attention:  */
/*  ====== */
/*   - Needs at least revision 1.39 of diagsym subproject */
/*   - Needs definition of enumeration te_SpiDeviceList in spi_spi_spidriverpar.p */
/*  --- Added comments ---  wjd2si [2008/02/12 14:18:19Z] */
/*  Set to release after delta review by ESW3-Kendlbacher without findings on 12.02.2008. */
/*  There are no changes at the code, only diagsym warnings. So it has no  */
/*  influence on the SAS, SDS, SDT and RTRT. */
/*  --- Added comments ---  wjd2si [2008/02/12 14:18:20Z] */
/*  State changed: develop -> release by wjd2si */
/*  Revision 2.36 2008/01/24 08:18:10CET wjd2si  */
/*  Added comment about additional fault information of internal communication fault. */
/*  --- Added comments ---  wjd2si [2008/01/24 07:18:34Z] */
/*  Delta-Review to last revision by ESW3-SchSfer on 24.01.2008 */
/*  --- Added comments ---  wjd2si [2008/01/24 07:18:35Z] */
/*  State changed: develop -> reviewed by wjd2si */
/*   */
/*  --- Added comments ---  wjd2si [2008/01/24 11:45:35Z] */
/*  Release granted by ESW3-Thiel on 24.01.2008 */
/*  --- Added comments ---  wjd2si [2008/01/24 11:45:36Z] */
/*  State changed: reviewed -> release by wjd2si */
/*  Revision 2.35 2008/01/18 17:07:25CET ngk2si  */
/*  Implemented Algo-SW-CR AB10_35B_03_02_001_rcr001_CentralPAS_SAC_SPR_SW_Algo.doc: */
/*     Added PAS-Locations for centrally mounted peripheral sensors. */
/*  --- Added comments ---  ngk2si [2008/01/18 16:08:09Z] */
/*  Delta review with EPM2-Bentele-Calvoer, no findings. */
/*  --- Added comments ---  ngk2si [2008/01/18 16:08:10Z] */
/*  State changed: develop -> reviewed by ngk2si */
/*  Revision 2.34 2007/10/25 11:11:32CEST wjd2si  */
/*  Reran create_code after changes of code generator. Only white space after comma of enumerations are */
/*  removed. No impact on code -> inherit state of 2.33 */
/*  --- Added comments ---  wjd2si [2007/10/25 09:11:50Z] */
/*  State changed: develop -> release by wjd2si */
/*  Revision 2.33 2007/06/15 13:55:42CEST wjd2si  */
/*  Added new definition for the message "Sensor ok, but unlocked" which is sent by the PAS5 */
/*  --- Added comments ---  wjd2si [2007/06/15 14:44:45Z] */
/*  Delta review to revision 2.32 by ESW3-Angstmann on 15.07.2007 without */
/*  findings */
/*  --- Added comments ---  wjd2si [2007/06/15 14:44:45Z] */
/*  State changed: develop -> reviewed by wjd2si */
/*  Revision 2.32 2007/05/14 11:43:59CEST wjd2si  */
/*  Added array for the INIT1 timeout handling */
/*  Revision 2.31 2007/04/11 10:59:43CEST wjd2si  */
/*  Added enumeration values for pedestrian protection sensors */
/*  Revision 2.30 2007/03/23 13:55:10CET wjd2si  */
/*  Changed comment about sensor defective fault information. No changes at code functionality level. */
/*  --- Added comments ---  wjd2si [2007/03/23 12:55:46Z] */
/*  As no changes to code are possible set to release after review by ESW3-Angstmann without findings on 23.03.07 */
/* EasyCASE - */
/*  --- Added comments ---  wjd2si [2007/03/23 12:55:47Z] */
/*  State changed: develop -> release by wjd2si */
/*  Revision 2.29 2007/01/30 15:39:32CET wjd2si  */
/*  - Introduced new initialization state in te_PASIFInitialisationStateList to be able to skip the test of the  */
/*    sensor initialization, if the sensors should not be turned on during initialization */
/*  - Introduced new states (te_PesInit2State) to be able to split the API PES_Init2 into several states.  */
/*    Therefore also a return value (te_Boolean) was introduced to signal to the sensormanager when to  */
/*    call the API again or when to continue with the rest of the initialisation. */
/*  Revision 2.28 2006/11/18 14:21:34CET wjd2si  */
/*  Removed no longer needed constants */
/*  --- Added comments ---  wjd2si [2006/11/18 13:21:59Z] */
/*  Delta-Review by AE-OS/ESW3-Angstmann and -Widmaier */
/*  --- Added comments ---  wjd2si [2006/11/18 13:21:59Z] */
/*  State changed: develop -> reviewed by wjd2si */
/*   */
/*  --- Added comments ---  wjd2si [2006/11/21 08:07:33Z] */
/*  Set to release after UDT was finished on 21.11.06 executed by ESW3-Widmaier */
/* EasyCASE - */
/*  --- Added comments ---  wjd2si [2006/11/21 08:07:34Z] */
/*  State changed: reviewed -> release by wjd2si */
/*  Revision 2.27 2006/11/10 09:15:57CET wjd2si  */
/*  Added new additional fault description mask for INIT1 timeout. INIT1 timeout was mapped to buffer empty */
/*  in the past, which was quite confusing. */
/*  Revision 2.26 2006/10/27 18:36:40CEST ngk2si  */
/* EasyCASE - */
/*  - Reformated Comments */
/*  - removed one unneccessary mask */
/*  Revision 2.25 2006/10/18 18:07:08CEST ngk2si  */
/*  PES_AllocateSensorSpecificRam ensures now that the sensor specific RAM is always word aligned. */
/*  Revision 2.24 2006/08/28 16:15:09CEST wjd2si  */
/*  Changed parameter of PES_AllocateSensorSpecificRam from U8 to U16 to be able to reserve more  */
/*  then 255 Byte or RAM in total */
/*  Revision 2.23 2006/08/21 11:30:14CEST wjd2si  */
/*  - Changed definition of message constants from unsigned to signed */
/*  - Removed definition of te_LineMonitoringConfigurationList (it is not used) */
/* EasyCASE - */
/*  - Moved definition of enumeration te_PesDesiredPowerState from c-file to h-file due to QAC finding */
/*  Revision 2.22 2006/08/15 12:15:29CEST wjd2si  */
/*  - Moved structure ts_PesInternalData into the generated part (so structure is now modled in the architecture) */
/*  - Changed definition of fault flag constant so it now matches the split counters (A_PasRTFaultFlagsINTW_U16X */
/* EasyCASE - */
/*    -> A_PasRTDefectFltINTW_U8X, A_PasRTExtCommFltINTW_U8X and A_PasRTIntCommFltINTW_U8X */
/*  - Included enumeration te_PesBgStates */
/*  - Changed BG monitoring function pointer prototyp (now includes te_PesBgStates as parameter) */
/*  - Changed name of PES_ReadPeripheralSensorStatusALL to PES_ReadPESStatusALL, because length */
/*    violated the coding rules. */
/*  - Introduced four new package protected helper functions for the sensor type specific units:  */
/*    PES_CheckRTDefectFaults, PES_CheckRTInternalCommFaults, PES_CheckRTExternalCommFaults  */
/*    and PES_SetInitialStatus */
/*  Revision 2.21 2006/07/26 09:38:13CEST kio1si  */
/*  Reran codegen. */
/*  Revision 2.20 2006/07/25 16:08:34CEST wjd2si  */
/*  Corrected wrong diagsym comment for F_OptionTestFailedINTW_U16X */
/*  Revision 2.19 2006/07/21 12:35:07CEST wjd2si  */
/*  Introduced option test for not configured devices: */
/*  - Counter for executed option tests for each sensor added to ts_PesInternalData */
/*  - Flag register to mark detected option test failure for up to 16 sensors */
/*  - Constant for unlimited option tests */
/*  Revision 2.18 2006/07/14 09:13:09CEST ngk2si  */
/*  Updaten PAS-Specific data format */
/*  Revision 2.17 2006/06/17 10:57:05CEST ngk2si  */
/*  - function pointers for PAS-BG monitoring are now initialised to a "do_nothing" function in init */
/*   (just to be sure that nothing can go wrong) */
/*  - fixed initialisation timeout, now uses a constant */
/*  - added API to access PAS-Status-Data (e.g. for Diagnosis)  */
/*  Revision 2.16 2006/06/12 11:05:39CEST kio1si  */
/*  PDM prameter file name change */
/*  Revision 2.15 2006/05/27 16:18:46CEST ngk2si  */
/*  - New PAS-Initialisation structure */
/* EasyCASE - */
/*  - PAS-specific BG-monitoring is now called via function pointer */
/*  Revision 2.14 2006/05/12 17:28:28CEST ngk2si  */
/*  Fixed ; in companion asic hook, regenerated with updated codegen */
/*  Revision 2.13 2006/04/21 11:29:41CEST ngk2si  */
/*  Updated API descriptions after Architecture update */
/*  Revision 2.12 2006/04/07 16:38:21CEST ngk2si  */
/*  Regenerated with new template */
/*  Revision 2.11 2006/04/03 12:58:13CEST ngk2si  */
/*  Regenerated with new templates */
/* EasyCASE - */
/*  Revision 2.10 2006/03/10 15:47:14CET ngk2si  */
/*  Regenerated with updated template */
/* EasyCASE - */
/*  Revision 2.9 2006/02/28 17:14:14CET ngk2si  */
/*  Updated parameter access (now with macro in sensormgtpar.p). */
/* EasyCASE - */
/*  Revision 2.8 2006/02/21 11:08:12CET ngk2si  */
/*  Changed API-names according to new coding rules (FIQ...) */
/*  Revision 2.7 2006/02/07 18:10:35CET ngk2si  */
/*  Restructured data interfaces */
/*  Misra updated */
/*  Revision 2.6 2006/01/02 15:16:15CET ngk2si  */
/* EasyCASE - */
/*  Changed architecture of sensor data interface */
/*  Revision 2.5 2005/12/29 15:30:41CET ngk2si  */
/*  Changed handling of timeouts to a single global timer */
/*  Revision 2.4 2005/12/28 15:55:19CET ngk2si  */
/*  Improved Pas-Init-Fault handling */
/*  Revision 2.3 2005/12/28 13:11:16CET ngk2si  */
/*  Corrected naming of enums */
/*  Revision 2.2 2005/11/29 16:08:13CET ngk2si  */
/* EasyCASE - */
/*  Architecture changes: support of Specific-PAS-IF modules */
/*  Revision 2.1 2005/10/25 18:26:56CEST ngk2si  */
/*  RT-Runtime optimization: centralised handling of no ini-data passing */
/*  Revision 2.0 2005/10/13 16:05:29CEST ngk2si  */
/*  C_Sample general rework */
/*  Revision 0.32 2005/06/01 14:03:35CEST ngk2si  */
/*  Corrected Review Findings, moved temporary API IsSensingDirectionInverted to TemporaryFunctions */
/*  Revision 0.31 2005/04/21 11:11:01CEST kcl2si  */
/*  update due to codegen update for event listeners */
/* EasyCASE - */
/*  Revision 0.30 2005/04/21 10:54:12CEST ngk2si  */
/*  Added Interface returning PAS-Location for Algo */
/* EasyCASE - */
/*  Revision 0.29 2005/03/23 17:38:19CET ngk2si  */
/*  Changes because of move of PAS-IF programming to Init2 function */
/*  Revision 0.28 2005/03/21 12:04:01CET ngk2si  */
/*  Made several parameters unsigned */
/* EasyCASE - */
/*  Revision 0.27 2005/03/16 14:00:10CET ngk2si  */
/*  Corrected parameter names according to coding rules */
/*  Revision 0.26 2005/03/09 11:49:02CET ngk2si  */
/*  Corrections after first peripheralsensor tests */
/* EasyCASE - */
/*  Revision 0.25 2005/03/02 13:50:55CET ngk2si  */
/*  RTRTed Version, used for 1st unit test */
/*  Revision 0.24 2005/02/23 11:13:10CET ngk2si  */
/*  Added Diagsym comments */
/* EasyCASE - */
/*  Revision 0.23 2005/02/22 19:37:56CET ngk2si  */
/*  Rework after changes to sensor data interface */
/*  Revision 0.22 2005/02/18 22:39:03CET fsa2si  */
/*  Architecture and Code Gen Update */
/*  Revision 0.21 2005/02/18 16:10:36CET ngk2si  */
/*  temporary version for code-gen-change */
/*  Revision 0.20 2005/02/14 19:28:39CET ngk2si  */
/*  Corrected naming of PDI-variables containing the sensor data */
/* EasyCASE - */
/*  Revision 0.19 2005/02/10 17:26:02CET ngk2si  */
/*  Added timeout for pas-initialisation + detailed error code for external communication errors. */
/*  Revision 0.18 2005/02/04 18:03:51CET ngk2si  */
/* EasyCASE - */
/*  Removed API PES_BeginPeripheralSensorsStartup */
/*  Revision 0.17 2005/02/04 15:03:47CET ngk2si  */
/*  Reworked after SAS review */
/*  Revision 0.16 2005/02/03 14:07:43CET ngk2si  */
/*  Version for SDS review */
/*  Revision 0.15 2005/01/21 19:30:25CET ngk2si  */
/*  Changed Configuration Data Handling */
/*  Revision 0.14 2005/01/14 17:08:17CET ngk2si  */
/*  several architecture updates, adapted API-descriptions to new template */
/*  Revision 0.13 2004/12/30 17:21:25CET ngk2si  */
/*  End of year 2004 Edition */
/*  Revision 0.12 2004/12/21 18:02:57CET ngk2si  */
/*  Christmas Version */
/*  Revision 0.11 2004/12/10 14:53:33CET ngk2si  */
/*  - New Checkin because of changes in the build-script */
/*  - Severall new functionality */
/*  Revision 0.10 2004/12/01 17:58:44CET ngk2si  */
/*  architecture adaptations, new code_gen script (runtime tooling) */
/*#end ACD#*/
/* ************************************************************************** */
/* EasyCASE ) */
/* EasyCASE (
   Includes */
/* PRQA S 1-9999 suppress_foreign_warnings_sem_pes_peripheralsensors_h */
/* EasyCASE (
   Standard includes (utils + own header) */
#include "utl_options.p"
#include "utl_tb_typesbase.h"
/* EasyCASE ) */
/* EasyCASE (
   Direct Includes */
#include "pdm_syssettingspar.p" 
/* EasyCASE ) */
/* EasyCASE (
   Direct includes for package SEM_SensorMgt */
#include "sem_smr_sensormanager.h" 
#include "sem_std_sensortypedefs.h" 
/* EasyCASE ) */
/* PRQA L:suppress_foreign_warnings_sem_pes_peripheralsensors_h */
/* EasyCASE ) */
/* EasyCASE (
   #Define Constants */
/*#ACD# M(Constants sem_pes_peripheralsensors)  Definitions*/
/* EasyCASE ( 23477
   Global settings */
/* Specifies how often initial PES line checks are made (used in case of an error) */
#define C_PESInitLineCheckAttempts_U8X          4u

/* Definition for an invalid sensor value */
#define C_PESInvalidData_S16X                   0x7FFF

/* Definition of expected value for check of offending SPI bits. This is the
 * same for all sensor types. Therefore it is defined here centrally. */
#define C_PESExpSPIBits_U8X                     0u

/* Maximum allowed comm errors - manchester or parity errors during sensor option test */
#define C_OptionTestCommFltThd_U8X              3u

/* ER voltage threshold for "Vsync low" handling (V * 100) */
#define C_ERThresholdVsyncLow_U16X              ((U16)1300u)   /* 13V */
/* EasyCASE ) */
/* EasyCASE ( 23464
   PSI5 codes & ranges / SPI bit definitions */
/* PSI5 error codes */
#define C_PSIManchesterErrorMsg_S16X            0x01FC
#define C_PSIParityErrorMsg_S16X                0x01F8
#define C_PSISyncPulseVoltageTooLowMsg_S16X     0x01F6
#define C_PSISensorDefectiveMsg_S16X            0x01F4
#define C_PSIBufferEmptyMsg_S16X                0x01F0
#define C_PSISensorBusyMsg_S16X                 0x01E8
#define C_PSISensorOkMsg_S16X                   0x01E7
#define C_PSISensorUnlockedMsg_S16X             0x01E6
#define C_PSIOnlyBit1LockedMsg_S16X             0x01E5
#define C_PSIBidiCommCodeErrorMsg_S16X          0x01E2
#define C_PSIBidiCommCodeOkMsg_S16X             0x01E1

/* PSI5 ID and status data ranges */
#define C_PSIMaxStatusDatum_S16X                -481
#define C_PSIMinStatusDatum_S16X                -496
#define C_PSIMaxIdentCode_S16X                  -497
#define C_PSIMinIdentCode_S16X                  -512
#define C_PSIStatusDataOffset_S16X              496
#define C_PSIIdentCodeOffset_S16X               512
/* EasyCASE - */
/* Constant to shift the safety ID enum values to match read SPI command */
#define C_PESSafetyIDReadCommandLocation_U8X    2u

/* Masks for real-time evaluated SPI bits */
#define M_PESSafetyID_U8X                       0x1Cu /* Only safety ID */
#define M_PESSPIStatusBitsAndSID_U8X            0x7Cu /* TST + NRO (EOP) + safety ID */
/* EasyCASE ) */
/* EasyCASE ( 23466
   Peripheral sensor detailed fault information */
/* Internal communication fault flags (A_PasRTIntCommFltINTW_U8X)
 *
 * v0wxyyyz
 *
 * w - This bit marks if the SPI bit TST was set in a sensor data frame (only after PES init is done).
 * x - This bit marks if the SPI bit NRO was set in a sensor data frame (only after PES init is done).
 * y - A bit is set where a difference between the received and the expected safety ID (3 bits long)
 * is detected (0 expected, received 1 or vice versa). The expected safety ID is programmed in algo EEPROM
 * and set as expected during initialization in this array: S_PesIntData_XXR.A_ExpSPIBits_U8X (000yyy00).
 *
 * z - "Sync pulse voltage too low" message 0x01F6 received. Set by the PSI5-S PES interface in the
 * SAPHIR and CF190 ASICs. Actual system state has to be confirmed to make sure that data is consistent.
 * 
 * v - If the "Sync pulse voltage too low" message is received, the Ver is checked. If it is too low
 * for a proper sync pulse this flag is set which is only evaluated internally. It is not part of the 
 * additional fault info.
 *
 * 0 - Not used / reserved for future use.
 */

/* Mask for realtime evaluated "Sync pulse voltage too low" message 0x01F6, only for SAPHIR synchronous mode */
                                                               /*! DEF MASKS PasIntCommFlt */
#define M_PESSyncPulseVoltageTooLow_U8X                 0x01u  /*! 00: Sync pulse voltage too low */
                                                               /*! 01: Safety ID bit 0 corrupt */
                                                               /*! 02: Safety ID bit 1 corrupt */
                                                               /*! 03: Safety ID bit 2 corrupt */
                                                               /*! 04: NRO (EOP) bit is set */
                                                               /*! 05: TST bit is set */
                                                               /*! END DEF */
#define M_PESVerLow_U8X                                 0x80u  /* Not part of additional fault info (also used for ext comm faults) */
/* EasyCASE - */
/* External communication fault flags (A_PasRTExtCommFltINTW_U8X)*/
                                                              /*! DEF MASKS PasExtCommFlt */
#define M_PESExternalCommBufferEmpty_U8X                0x01u /*! 00: Receive buffer empty */
#define M_PESExternalCommParityError_U8X                0x02u /*! 01: Parity error */
#define M_PESExternalCommManchesterError_U8X            0x04u /*! 02: Manchester error */
#define M_PESExternalCommUnexpectedDataError_U8X        0x08u /*! 03: Invalid data */
#define M_PESExternalCommInitTimeOut_U8X                0x10u /*! 04: Stuck in Init1 */
                                                              /*! END DEF */
/* EasyCASE - */
/* Init or type fault flags (set via xxx_checkIniComplete() functions of sensor modules)*/
                                              /*! DEF MASKS PasInitOrTypeFlt */
#define M_PESInitFaultTimeout_U8X       0x01u /*! 00: Init timeout occurred */
#define M_PESInitFaultTransmission_U8X  0x02u /*! 01: Init data incomplete */
#define M_PESInitFaultType_U8X          0x04u /*! 02: Wrong sensor type, e.g. supplier */
#define M_PESInitFaultSubtype_U8X       0x08u /*! 03: Wrong sensor subtype, e.g. range/axis */
#define M_PESInitFaultProject_U8X       0x10u /*! 04: Customer specific check failed */
#define M_PESInitFaultSpecific_U8X      0x20u /*! 05: Sensor specific check failed */
                                              /*! END DEF */
/* EasyCASE - */
/* Additional fault info regarding plausibility fault */
/* Bits 0 and 1 are unused to maintain consistency with the CS channel plausi fault */
                                    		/*! DEF MASKS PESPlausiFault */
#define M_PESPlausiAlgoFront_U8X 	0x04u	/*! 02: Front algo sensor WD fault */
#define M_PESPlausiAlgoRear_U8X 	0x08u	/*! 03: Rear algo sensor WD fault */
#define M_PESPlausiAlgo_U8X 		0x10u	/*! 04: Generic algo sensor WD fault */
#define M_PESPlausiCSABS_U8X 		0x20u	/*! 05: CSABS algo sensor WD fault */
                                  	  		/*! END DEF */
/* EasyCASE - */
/* Sensor defect fault flags (A_PESRTDefectFltINTW_U8X)
 *
 * xyzzzzzz
 *
 * x - Flags reception of "Sensor Defect" error message in RT.
 *
 * y - Flags reception of additional fault information in RT.
 *
 * z - These 6 bits contain the actual fault information transmitted by the sensor.
 *     The default value is 0x3F if a sensor does not support this feature (e.g. PAS4, PPS1).
 *     As this is very sensor specific a generic fault description cannot be given.
 */
#define M_PESDefectError_U8X                            0x80u
#define M_PESFltInfoRcvd_U8X                            0x40u
/* EasyCASE ) */
/* EasyCASE ( 23510
   Peripheral sensor FLTDESC / FLTREACTION */
/*! FLTDESC MACRO Flt<Z_PasMacro>Option: <Z_PasMacro> option fault (unexpected device) */
/*! FLTDESC MASKS PasInitOrTypeFlt MACRO Flt<Z_PasMacro>InitOrType: <Z_PasMacro> wrong sensor connected or initialization failed */
/*! FLTDESC MASKS PESPlausiFault MACRO Flt<Z_PasMacro>Plausibility: <Z_PasMacro> signal plausibility error */
/*! FLTDESC MACRO Flt<Z_PasMacro>Defect: <Z_PasMacro> sensor defective */
/*! FLTDESC MASKS PasExtCommFlt MACRO Flt<Z_PasMacro>ExternalCommunication: <Z_PasMacro> communication error on PES line */
/*! FLTDESC MASKS PasIntCommFlt MACRO Flt<Z_PasMacro>InternalCommunication: <Z_PasMacro> internal communication error */
/*! FLTDESC MACRO Flt<Z_PesLineLogicalMacro>CrossCoupling: <Z_PesLineLogicalMacro> X-coupling */
/*! FLTDESC MACRO Flt<Z_PesLineLogicalMacro>Short2Bat: <Z_PesLineLogicalMacro> short circuit to battery */
/*! FLTDESC MACRO Flt<Z_PesLineLogicalMacro>Short2Gnd: <Z_PesLineLogicalMacro> short circuit to ground */
/* EasyCASE - */
/*! FLTREACTION MACRO Flt<Z_PasMacro>Option: E_NoDisable */
/*! FLTREACTION MACRO Flt<Z_PasMacro>InitOrType: E_NoDisable */
/*! FLTREACTION MACRO Flt<Z_PasMacro>Plausibility: E_NoDisable */
/*! FLTREACTION MACRO Flt<Z_PasMacro>Defect: E_NoDisable */
/*! FLTREACTION MACRO Flt<Z_PasMacro>ExternalCommunication: E_NoDisable */
/*! FLTREACTION MACRO Flt<Z_PasMacro>InternalCommunication: E_NoDisable */
/*! FLTREACTION MACRO Flt<Z_PesLineLogicalMacro>CrossCoupling: E_NoDisable */
/*! FLTREACTION MACRO Flt<Z_PesLineLogicalMacro>Short2Bat: E_NoDisable */
/*! FLTREACTION MACRO Flt<Z_PesLineLogicalMacro>Short2Gnd: E_NoDisable */
/* EasyCASE ) */
/* EasyCASE < */
/***********************************************************************************************/
/* The following definitions of enum te_PesBgStates and tp_PasSpecificBgFunction have to be    */
/* done here. There is no manual edit section after the generated enumerations and before      */
/* the structure definitions. tp_PesSpecificBgFunction needs enum te_PesBgStates and is needed */
/* by structure ts_PesInternalData. So it was decided to put them here.                        */
/***********************************************************************************************/

/* The peripheral sensors BG monitoring during 10ms BG is split into
 * different states which are defined by this enumeration.
 */
typedef enum
{
   E_PesBgState1,
   E_PesBgState2,
   E_PesBgState3
} te_PesBgStates;

/*! DEF ENUM te_PesBgStates */
/*! E_PesBgState1: First BG monitoring state */
/*! E_PesBgState2: Second BG monitoring state */
/*! E_PesBgState3: Third BG monitoring state */
/*! END DEF */
/* EasyCASE > */
/* EasyCASE - */
/* Type definition for the function pointers pointing to the pas specific BG evaluation function.
 * Parameters are: U8 v_sensor_u8r
 */
typedef void (*tp_PesSpecificBgFunction) (U8, te_PesBgStates);
/* EasyCASE - */
/*#end ACD#*/
/* EasyCASE ) */
/* EasyCASE (
   ENUM and struct Definitions */
/*#ACD# M(Enums sem_pes_peripheralsensors)  Enums*/
/*#end ACD#*/
/* EasyCASE (
   struct ts_PesLineData */
/* EasyCASE C */
/*
 * Contains data corresponding to the PES lines (e.g. line states)
 */
typedef struct
{
  U16 F_MeasuredStatus_U16X      ; /* Measured logical status of the PES lines (bit=1: ON, 0:OFF) */   
  U16 F_ExpectedStatus_U16X      ; /* Expected logical status of the PES lines (bit=1: ON, 0:OFF) */   
  U16 F_RequestedStatus_U16X     ; /* Requested logical status of the PES lines (bit=1: ON, 0:OFF) */   
  U16 F_UsedPESLines_U16X        ; /* PES lines which are used (a PES is connected to it) */ 
} ts_PesLineData;
/* EasyCASE E */
/* EasyCASE ) */
/* EasyCASE - */
/* EasyCASE (
   struct ts_PesSensorData */
/* EasyCASE C */
/*
 * Protected Data Interface for peripheral sensor data.
 */
typedef struct
{
  U32 F_DataValid_U32X           ; /* Indicates if sensor data is valid (=1), access via macro Z_IsPESDataValid(sensorchannel). */   
  S16 A_MeanValue_S16X [E_MaxPeripheralSensors] ; /* Contains the preprocessed peripheral sensor data. One element exists for every sensor. 
                                                For 4kHz sensors the real mean value will be stored here. For 2kHz sensors only the 
                                                received value will be stored. Resolution [g/bit] depends on sensor type.  */ 
} ts_PesSensorData;
/* EasyCASE E */
/* EasyCASE ) */
/* EasyCASE - */
/* EasyCASE (
   struct ts_PesInternalData */
/* EasyCASE C */
/*
 * This struct is used to store data internal for peripheral sensors.
 */
typedef struct
{
  void* A_SensorSpecificData_XPX [E_MaxPeripheralSensors] ; /* Sensor specific RAM                      */   
  U32 A_StatusMsgRvdINTW_U32X [E_MaxPeripheralSensors] ; /* Flags indicating received status messages */   
  S16 A_PlausiCounter_S16X [E_MaxPeripheralSensors] ; /* Number of signals above plausi-threshold */   
  U8 A_PESRTDefectFltINTW_U8X [E_MaxPeripheralSensors] ; /* Sensor defect fault flags                */   
  U8 A_PESRTExtCommFltINTW_U8X [E_MaxPeripheralSensors] ; /* External communication fault flags       */   
  U8 A_PESRTIntCommFltINTW_U8X [E_MaxPeripheralSensors] ; /* Internal communication fault flags       */   
  U16 A_PESInitOneTimeout_U16X [E_MaxPeripheralSensors] ; /* Timeout for INIT1 phase                  */   
  U16 A_PESInitTimeout_U16X [E_MaxPeripheralSensors] ; /* Timeout of PES initialization            */   
  U8 A_MessageIndexINTW_U8X [E_MaxPeripheralSensors] ; /* Index of status message received last    */   
  U8 A_ExpSPIBits_U8X [E_MaxPeripheralSensors] ; /* Expected SPI bits (TST, NRO & safety ID) */   
  U8 V_CheckedSPIBits_U8X        ; /* Specific bits of an SPI frame which should be monitored */   
  U8 A_NumberOfSamples_U8X [E_MaxPeripheralSensors] ; /* Number of samples for this PES (1 or 2)  */   
  U8 A_RebootCounter_U8X [E_MaxPeripheralSensors] ; /* Number of reboots                        */   
  U8 A_OptionTestCounter_U8X [E_MaxPeripheralSensors] ; /* Number of performed option tests         */   
  te_SensorStateList A_SensorStateINTW_XEX [E_MaxPeripheralSensors] ; /* Sensor state (OK, Init, Defect, ...)     */   
  te_SpiDeviceList A_SPIDevice_XEX [E_MaxPeripheralSensors] ; /* Chipselect this sensor is connected to   */   
  tp_PesSpecificBgFunction A_PESSpecificBgFP_XFX [E_MaxPeripheralSensors] ; /* Function pointer to PES specific BG monitoring function */   
  U8 A_OptnTestComFltCntINTW_U8X [E_MaxPeripheralSensors] ; /* Number of Manchester or parity errors during option test */   
  U32 F_OptionTestFailedINTW_U32X ; /* Flags which indicate a failed option test */ 
} ts_PesInternalData;
/* EasyCASE E */
/* EasyCASE ) */
/* EasyCASE - */
/*#ACD# M(Enums sem_pes_peripheralsensors leadout)  Enums*/
/* EasyCASE ( 23474
   Diagsym comments for generated structs */
/*! DEF STRUCT ts_PesLineData */
   /*! F_MeasuredStatus_U16X  : Measured logical status of the PES lines (bit=1: ON, 0:OFF) */
   /*! F_ExpectedStatus_U16X  : Expected logical status of the PES lines (bit=1: ON, 0:OFF) */
   /*! F_RequestedStatus_U16X : Requested logical status of the PES lines (bit=1: ON, 0:OFF) */
   /*! F_UsedPESLines_U16X    : PES lines which are used (a PES is connected) */
/*! END DEF */
/* EasyCASE - */
/*! DEF STRUCT ts_PesSensorData */
   /*! F_DataValid_U32X                               : Bit set => channel OK */
   /*! ARRAY A_MeanValue_S16X[E_MaxPeripheralSensors] : Sensor value */
/*! END DEF */
/* EasyCASE - */
/*! DEF STRUCT ts_PesInternalData */
   /*!ARRAY A_SensorSpecificData_XPX[E_MaxPeripheralSensors]: Sensor specific RAM */
   /*!ARRAY A_StatusMsgRvdINTW_U32X[E_MaxPeripheralSensors]: Flags indicating received status messages */
   /*!ARRAY A_PlausiCounter_S16X[E_MaxPeripheralSensors]: Number of signals above plausi-threshold */
   /*!ARRAY A_PESRTDefectFltINTW_U8X[E_MaxPeripheralSensors]: Sensor defect fault flags */
   /*!ARRAY A_PESRTExtCommFltINTW_U8X[E_MaxPeripheralSensors]: External communication fault flags */
   /*!ARRAY A_PESRTIntCommFltINTW_U8X[E_MaxPeripheralSensors]: Internal communication fault flags */
   /*!ARRAY A_PESInitOneTimeout_U16X[E_MaxPeripheralSensors]: Timeout for INIT1 phase */
   /*!ARRAY A_PESInitTimeout_U16X[E_MaxPeripheralSensors]: Timeout of PES initialization */
   /*!ARRAY A_MessageIndexINTW_U8X[E_MaxPeripheralSensors]: Index of status message received last */
   /*!ARRAY A_ExpSPIBits_U8X[E_MaxPeripheralSensors]: Expected SPI bits (TST, NRO & safety ID) */
   /*! V_CheckedSPIBits_U8X: Specific bits of an SPI frame which should be monitored */
   /*!ARRAY A_NumberOfSamples_U8X[E_MaxPeripheralSensors]: Number of samples for this PES (1 or 2) */
   /*!ARRAY A_RebootCounter_U8X[E_MaxPeripheralSensors]: Number of reboots */
   /*!ARRAY A_OptionTestCounter_U8X[E_MaxPeripheralSensors]: Number of performed option tests */
   /*!ARRAY ENUM te_SensorStateList A_SensorStateINTW_XEX[E_MaxPeripheralSensors]: Sensor state (OK, Init, Defect, ... */
   /*!ARRAY ENUM te_SpiDeviceList A_SPIDevice_XEX[E_MaxPeripheralSensors]: Chipselect this sensor is connected to */
   /*!ARRAY A_PESSpecificBgFP_XFX[E_MaxPeripheralSensors]: Function pointer to PES specific BG monitoring function */
   /*!ARRAY A_OptnTestComFltCntINTW_U8X [E_MaxPeripheralSensors]: Number of Manchester or parity errors during option test */
   /*! F_OptionTestFailedINTW_U32X: Flags which indicate a failed option test */
/*! END DEF */
/* EasyCASE ) */
/* EasyCASE ( 23461
   enum te_PASIFInitialisationStateList */
/* EasyCASE < */
/* Enum With the different initialization states of the PES-IF */
 typedef enum
 {                         /*! DEF ENUM te_PASIFInitialisationStateList */
  E_PasIfShortToBatCheck,      /*! E_PasIfShortToBatCheck   : Checking short to BAT on PES lines */
  E_PasIfCrossCouplingTest,    /*! E_PasIfCrossCouplingTest : Checking cross-coupling on PES lines  */
  E_PasIfWaitForERTest,        /*! E_PasIfWaitForERTest     : Waiting for end of energy reserve test */
  E_PasIfEvalERCondition,      /*! E_PasIfEvalERCondition   : Check initial requested power condition */
  E_PasStartup,                /*! E_PasStartup             : Initialization of PES-IF done => starting PES */
  E_PasStartupCompleted        /*! E_PasStartupCompleted    : Final state => init of all PES done */
 } te_PASIFInitialisationStateList;  /*! END DEF */
/* EasyCASE > */
/* EasyCASE ) */
/* EasyCASE ( 23476
   enum te_PesDesiredPowerState */
/* EasyCASE < */
/*
 * Specifies the desired power state of all sensors. This is influenced
 * by PES_PowerPeripheralSensors and evaluated by pes_ControlAllPasPowering.
 */
typedef enum
{
   E_PesNoChange,
   E_PesPowerOn,
   E_PesPowerOff
} te_PesDesiredPowerState;
/*! DEF ENUM te_PesDesiredPowerState                        */
   /*! E_NoChange: Power state of sensors should not change */
   /*! E_PowerOn: Switch on all sensors                     */
   /*! E_PowerOff: Switch off all sensors                   */
/*! END DEF */
/* EasyCASE > */
/* EasyCASE ) */
/* EasyCASE ( 23481
   enum te_PesInit2State */
/* EasyCASE < */
/*
 * The initialisation 2 API is split into several states to keep runtime load in
 * a rational range
 */
typedef enum
{
   E_PesInitSissi,
   E_PesInitSaphir,
   E_PesInitCf190,
   E_PesInitCG974,
   E_PesInitFinish,
   E_PesInitDone
} te_PesInit2State;
/*! DEF ENUM te_PesInit2State                          */
   /*! E_PesInitSissi: Initialise Sissi PES-IF         */
   /*! E_PesInitSaphir: Initialise Saphir PES-IF       */
   /*! E_PesInitCf190: Initialise CF190 (Ramses 2)     */
   /*! E_PesInitCG974: Initialise CG974 PES-IF         */
   /*! E_PesInitFinish: Perform finishing steps        */
   /*! E_PesInitDone: Initialization has finished      */
/*! END DEF */
/* EasyCASE > */
/* EasyCASE ) */
/*#end ACD#*/
/* EasyCASE ) */
/* EasyCASE (
   Protected Data Interfaces (description) */
/* EasyCASE (
   PDI: ts_PesLineData S_PesLineData_XXR */
/*
 * Contains the RAM data related to PES lines.
 */
/* Declaration of ts_PesLineData S_PesLineData_XXR can be found in realising c file */
/* EasyCASE ) */
/* EasyCASE (
   PDI: ts_PesInternalData S_PesIntData_XXR */
/*
 * Contains the RAM data for peripheral sensors.
 */
/* Declaration of ts_PesInternalData S_PesIntData_XXR can be found in realising c file */
/* EasyCASE ) */
/* EasyCASE (
   PDI: ts_PesSensorData S_PesSensorDataINTW_XXR */
/*
 * Contains the RT sensor values and validity flags.
 */
/* Declaration of ts_PesSensorData S_PesSensorDataINTW_XXR can be found in realising c file */
/* EasyCASE ) */
/* EasyCASE ) */
/* EasyCASE (
   Public API Declarations */
/* EasyCASE (
   PES_PowerPeripheralSensors */
/******************************************************************************
 * Description:
 *    Switches power for all peripheral sensors. This is e.g. useful to disable
 *    them in case of low energy.
 * 
 * Arguments:
 *    e_powerOn_xxr: E_True to switch on power, E_False to switch off
 * 
 * Return: -
 * 
 * Scheduling:
 *    Event-driven
 * 
 * Usage guide:
 *   Before powering the PES from ITM make sure that:
 *     1) PES cross coupling test is over.
 *     2) Initial energy reserve test is not running.
 * 
 * Remarks:
 *    The exact state transitions depend on the current sensor state (see chart
 *    in the design section of this module's SDS for details).
 ******************************************************************************/
void PES_PowerPeripheralSensors(te_Boolean e_powerOn_xxr );
/* EasyCASE ) */
/* EasyCASE (
   PES_DisablePeripheralSensor */
/******************************************************************************
 * Description:
 *    Disables a single peripheral sensor until next PON (sets the state to
 *    E_SMRSensorDead).
 * 
 * Arguments:
 *    e_sensor_xxr: peripheral sensor to disable
 * 
 * Return: -
 * 
 * Scheduling:
 *    Event-driven
 * 
 * Usage guide:
 *    This API is called for two reasons:
 *      - from other modules to disable a sensor (e.g. algo might disable a
 *        sensor that faced a crash).
 *      - internally in this module to deactivate a sensor that was classified
 *        as defective.
 * 
 * Remarks:
 *    This API will only set the logical state immediately, de-powering is done
 *    in the PES background monitoring.
 *    There is no corresponding "enable"-API, but each disabled sensor will be
 *    restarted in the next POC.
 ******************************************************************************/
void PES_DisablePeripheralSensor(te_PeripheralSensorList e_sensor_xxr );
/* EasyCASE ) */
/* EasyCASE (
   PES_GetPasTypeALL */
/******************************************************************************
 * Description:
 *    Returns information about the type of the specified peripheral sensor.
 *    This includes the measurement range (e.g. PAS4_100g, PAS4_200g, etc.).
 * 
 * Arguments:
 *    e_sensor_xxr: the sensor for which type information is needed.
 * 
 * Return:
 *    PES type enum value (specified in PDM p-file).
 * 
 * Scheduling:
 *    Event-driven
 * 
 * Usage guide: -
 * 
 * Remarks: -
 ******************************************************************************/
te_PASTypeList PES_GetPasTypeALL(te_PeripheralSensorList e_sensor_xxr );
/* EasyCASE ) */
/* EasyCASE (
   PES_ReadPESStatusALL */
/******************************************************************************
 * Description:
 *    Reads the (filtered) state of the specified peripheral sensor.
 * 
 * Arguments:
 *    e_sensor_xxr: sensor for which the state is queried
 * 
 * Return:
 *    Current sensor state
 * 
 * Scheduling:
 *    Event-driven
 * 
 * Usage guide: -
 * 
 * Remarks:
 *    The sensor state is part of the protected data interface S_PesIntData_XXR.
 ******************************************************************************/
te_SensorStateList PES_ReadPESStatusALL(te_PeripheralSensorList e_sensor_xxr );
/* EasyCASE ) */
/* EasyCASE (
   PES_AccessPesInitData */
/******************************************************************************
 * Description:
 *    Provides access to the init/status data sent by the specified peripheral
 *    sensor. This data contains for example the sensor type or the serial
 *    number. This data can be used for diagnosis services.
 *    Obviously the status data will only be accessible after initialisation of
 *    a sensor is complete.
 * 
 * Arguments:
 *    e_sensor_xxr: sensor for which the sensor data is requested
 * 
 * Return:
 *    A void pointer to the init/status data, or NULL pointer if e_sensor_xxr
 *    is out of range.
 * 
 * Scheduling:
 *    Event-driven
 * 
 * Usage guide:
 *    ATTENTION: The void pointer references the original data, not a copy, SO
 *    DO NOT MODIFY IT!
 * 
 *    A void pointer is used, as the data format/amount of data depends on the
 *    sensor type. To use it first check the sensor type (PES_GetPasTypeALL) to
 *    determine what amount of status data exists (e.g. for a PAS4 8bytes are
 *    transmitted, for a PAS5 16bytes).
 * 
 *    The best way to access the data depends on the format the status data is
 *    needed in (e.g. as U64 or byte-wise). For example for a byte-wise access
 *    you could do the following:
 * 
 *       const U8* p_dummy_u8r;
 *       p_dummy_u8r = (U8*) PES_AccessPesInitData(sensor);
 *       v_firstByte_u8r = *p_dummy_u8r;
 *       ...
 * 
 * Remarks: -
 ******************************************************************************/
const void* PES_AccessPesInitData(te_PeripheralSensorList e_sensor_xxr );
/* EasyCASE ) */
/* EasyCASE (
   PES_ReportSignalPlausiFault */
/******************************************************************************
 * Description:
 *    This API shall be used by the algo to report the signal plausibility
 *    fault detected by the algo sensor watchdog component, for peripheral
 *    sensors. The following actions are performed
 *    - Qualify the Flt[PES]Plausibility fault
 *    - Disable the sensor logically
 *    - Clear the sensor output and mark data as invalid
 * 
 * Arguments:
 *    - e_sensor_xxr: affected sensor for which the plausi fault is detected
 *    - v_detailedFaultInfo_u8r: detailed fault info to be stored in fault
 *      memory
 * 
 * Return:
 *    none
 * 
 * Scheduling:
 *    Event driven, called by algo in a 10 ms BG function
 * 
 * Usage guide:
 *    none
 * 
 * Remarks:
 *    none
 ******************************************************************************/
void PES_ReportSignalPlausiFault(te_PeripheralSensorList e_sensor_xxr, U8 v_detailedFaultInfo_u8r );
/* EasyCASE ) */
/* EasyCASE (
   Macro: Z_IsPESDataValid  */
/******************************************************************************
 * Description:
 *    Checks if the data of the selected sensor sample in the peripheral
 *    sensors data interface is valid or not.
 * 
 * Arguments:
 *    sensorchannel: peripheral sensor channel for which the 'valid'
 *    information is requested
 * 
 * Return:
 *    - E_True : in the latest transmission valid data was received from the
 *      sensor
 *    - E_False: invalid data received or sensor not in steady state
 * 
 * Scheduling: - (Macro)
 * 
 * Usage guide:
 *    Use whenever using the peripheral sensor data interface, e.g.:
 *    if (Z_IsPESDataValid(sample) == E_True) { ... }
 * 
 * Remarks:
 *    Access to the PDI S_PesSensorDataINTW_XXR is necessary, so don't forget
 *    to include that in the architecture.
 ******************************************************************************/
#define Z_IsPESDataValid(x) ( (te_Boolean) Z_BitIsSet(S_PesSensorDataINTW_XXR.F_DataValid_U32X, Z_GetBitMask(x) ))
/* EasyCASE ) */
/* EasyCASE ) */
/* EasyCASE (
   Package protected API Declarations */
#ifdef Y_INC_FROM_PKG_SEM_SensorMgt
/* EasyCASE (
   PES_ClearSensorDataOutputFIQ */
/******************************************************************************
 * Description:
 *    Clears the peripheral sensor data output by setting the value to 0 and by
 *    clearing the data valid flags for all sensors.
 * 
 * Arguments: -
 * 
 * Return: -
 * 
 * Scheduling:
 *    Real-time
 * 
 * Usage guide:
 *    Called by the smr_sensormanager module at the end of real-time sensor
 *    data evaluation. This is done only during initialization as long as the
 *    ITM has not yet allowed the passing of sensor data to the system.
 * 
 * Remarks: -
 ******************************************************************************/
void PES_ClearSensorDataOutputFIQ( void );
/* EasyCASE ) */
/* EasyCASE (
   PES_Init1 */
/******************************************************************************
 * Description:
 *    Initializes the peripheral sensor management to safe default values.
 * 
 * Arguments: -
 * 
 * Return: -
 * 
 * Scheduling:
 *    Event-driven
 * 
 * Usage guide:
 *    Called directly at startup (before configuration data is available).
 * 
 * Remarks: -
 ******************************************************************************/
void PES_Init1( void );
/* EasyCASE ) */
/* EasyCASE (
   PES_Init2 */
/******************************************************************************
 * Description:
 *    Initializes the peripheral sensor management with data from the EEPROM
 *    configuration. This is done by calling the init routines of the different
 *    PES-IF modules.
 * 
 * Arguments: -
 * 
 * Return:
 *    - E_False: Initialization is not finished yet. PES_Init2 has to be called
 *      again.
 *    - E_True : Initialization has finished. Do no longer call PES_Init2 in
 *      this POC.
 * 
 * Scheduling:
 *    Called once in 10ms background, in the first cycle after configuration
 *    data is available.
 * 
 * Usage guide:
 *    Called by sensor manager.
 * 
 * Remarks:
 *    Just to make it clear: this method initializes the software modules, not
 *    the sensors!
 *    Call this API until E_True is returned and then stop calling it.
 ******************************************************************************/
te_Boolean PES_Init2( void );
/* EasyCASE ) */
/* EasyCASE (
   PES_BackGroundMonitoring10ms */
/******************************************************************************
 * Description:
 *    Controls the 10ms background monitoring functions for peripheral sensors.
 *    This function does the logical handling of the background monitoring. The
 *    direct hardware interaction is handled in the sensor or PES-IF specific
 *    modules.
 * 
 * Arguments:
 *    e_bgexecpart_xxr: BG execution part 1 or 2 or 3
 * 
 * Return: -
 * 
 * Scheduling:
 *    10ms background - this function is split into 3 parts to distribute the
 *    high runtime load, hence there should be 3 function calls in every 10ms
 *    BG.
 * 
 * Usage guide:
 *    Called by sensor manager (which has to be called thrice from BG loops).
 * 
 * Remarks:
 *    Typical tasks triggered by this function are:
 *      - PES line related monitoring (e.g. shortage detection).
 *      - PES monitoring (e.g. evaluation of "SensorDefective" messages).
 * 
 *    This function is called by the sem_sensormanager module after
 *    configuration data is available (and after PES_Init1 and PES_Init2 have
 *    been called, so there is no need to take care of that).
 ******************************************************************************/
void PES_BackGroundMonitoring10ms(te_SEMBGExecutionPart e_bgexecpart_xxr );
/* EasyCASE ) */
/* EasyCASE (
   PES_SetPeripheralSensorState */
/******************************************************************************
 * Description:
 *    Sets the (filtered) state of the specified peripheral sensor. This API
 *    will also take care of any other necessary actions (switching on/off
 *    power, starting timeouts, etc.)
 * 
 * Arguments:
 *    v_sensor_u8r: index of sensor for which to set the state
 *    e_state_xxr : new state to set
 * 
 * Return: -
 * 
 * Scheduling:
 *    Event-driven
 * 
 * Usage guide:
 *    Called by the sensor specific modules (or locally).
 * 
 * Remarks:
 *    This API can only be called from background, as some operations it
 *    performs (e.g. FaultClear) are not allowed inside an interrupt function.
 *    If a PES specific module needs to set the state in real-time (e.g. as
 *    reaction to init messages) it has to set it directly via the PDI
 *    S_PesIntData_XXR (and then also trigger any additional actions, if
 *    needed).
 ******************************************************************************/
void PES_SetPeripheralSensorState(U8 v_sensor_u8r, te_SensorStateList e_state_xxr );
/* EasyCASE ) */
/* EasyCASE (
   PES_AllocateSensorSpecificRam */
/******************************************************************************
 * Description:
 *    Allocates RAM space to be used by sensor specific modules to store their
 *    individual data.
 * 
 * Arguments:
 *    v_bytes_u16r: the amount of memory needed (in bytes)
 *    If this value is not divisible by 4 it will be rounded up. This is
 *    necessary to ensure that each sensor's RAM space is word aligned.
 * 
 * Return:
 *    A void pointer to the start address of the memory allocated for the
 *    caller. C_NULLPT_XXX if not enough memory is available.
 *    THIS HAS TO BE CHECKED!
 * 
 * Scheduling:
 *    Event-driven during initialization.
 * 
 * Usage guide:
 *    To be called by peripheral sensor specific modules during initialization.
 * 
 * Remarks:
 *    Pay attention to the return value because it will be C_NULLPT_XXX if not
 *    enough memory is available (e.g. because of a configuration error). This
 *    will also set a sensor management configuration error
 *    (FltSEMConfiguration).
 * 
 ******************************************************************************/
void* PES_AllocateSensorSpecificRam(U16 v_bytes_u16r );
/* EasyCASE ) */
/* EasyCASE (
   PES_CheckRTDefectFaults */
/******************************************************************************
 * Description:
 *    This function is a standard implementation of the check of the sensor
 *    defective fault flags, which are set during the sensor type specific
 *    real-time evaluation.
 * 
 *    For each sensor an 8 bit flag bar is reserved in array
 *    A_PESRTDefectFltINTW_U8X. The highest bit (bit 7) is the indication, if a
 *    defect fault should be stepped up. Bit 6 marks if the additional fault
 *    information was already received. The lower 6 bits are copied directly to
 *    the additional fault information. As soon as the fault is filtered the
 *    sensor is set to dead state and switched off for the POC. If the highest
 *    bit is not set the fault will be stepped down.
 * 
 * 
 * Arguments:
 *    v_sensor_u8r: sensor which should be checked
 * 
 * Return:  -
 * 
 * Scheduling:
 *    Every 30 ms called by sensor type specific BG function.
 * 
 * Usage guide:
 *    This API can be used as standard test of the RT fault flags by the sensor
 *    type specific units during their BG monitoring. When the "SensorDefect"
 *    fault should be stepped up, the highest bit of A_PESRTDfectFltINTW_U8X
 *    has to be set. As soon as the additional fault info is available bit 6
 *    must be set and the information has to be stored in the lower 6 bits of
 *    that array entry. Sensors which don't have any additional fault info must
 *    never set bit 6 so the default value is always used. The default value is
 *    0x3F.
 * 
 * Remarks:
 *    It was decided to have this function as a helper function in
 *    sem_pes_peripheralsensors, because of the requirement to reboot the
 *    Siemens pSat4.1 sensor as soon as "sensor defective" messages are
 *    received during the initialization of the sensor. This can be done, if
 *    this function is duplicated in the pSat module and changed there. The
 *    other sensor type specific modules can use this API as standard method to
 *    check the sensor defect flags.
 * 
 *    The old function pes_CheckRealtimeFaults was split into three different
 *    APIs, so that the runtime consumption can be distributed into 3 10ms
 *    cycles.
 * 
 *    In contrast to the other two helper functions -
 *    PES_CheckRTInternalCommFaults and PES_CheckRTExternalCommFaults - this
 *    function does not automatically step up the fault, if the array entry in
 *    A_PESRTDefectFltINTW_U8X is not equal to zero. Bit 7 is the indicator, if
 *    the fault should be stepped up or down. Bit 6 flags if the additional
 *    fault info was already received. All the other bits are only additional
 *    information and do not contribute to the fault mechanism.
 * 
 * This function also handles door slam conditions in the following way: if a
 * sensor defect is flagged during one of the sensor's initialization sates the
 * sensor is rebooted up to two times to see if it is just a temporary error
 * (e.g. caused by a door slam) or a permanent problem. In the latter case the
 * fault is stepped up immediately without prior filtering. If the additional
 * fault info is not available (not received yet or not supported by sensor)
 * the default value is 0x3F.
 ******************************************************************************/
void PES_CheckRTDefectFaults(U8 v_sensor_u8r );
/* EasyCASE ) */
/* EasyCASE (
   PES_CheckRTInternalCommFaults */
/******************************************************************************
 * Description:
 *    This function is a standard implementation of the check of the internal
 *    communication fault flags which are set during the sensor type specific
 *    real-time evaluation.
 * 
 *    For each sensor an 8 bit flag bar is reserved in array
 *    A_PESRTIntCommFltINTW_U8X. If one of the bits is set the internal
 *    communication fault is stepped up. As soon as the fault is filtered, the
 *    sensor is set to dead state and switched off for the rest of the PON
 *    cycle. If no fault flag is set, the fault will be stepped down.
 * 
 * 
 * Arguments:
 *    v_sensor_u8r: sensor which should be checked
 * 
 * Return: -
 * 
 * Scheduling:
 *    Every 30 ms called by sensor type specific BG function.
 * 
 * Usage guide:
 *    This API can be used as standard test of the RT fault flags by the sensor
 *    type specific units during their BG monitoring.
 * 
 * Remarks:
 *    The old function pes_CheckRealtimeFaults was split into three different
 *    APIs, so that the runtime consumption can be distributed into 3 10ms
 *    cycles.
 * 
 *    For synchronous sensors a sync pulse is provided by the interface ASIC
 *    (SAPHIR/CF190). The sync pulse voltage (Vsync) is provided externally and
 *    monitored by the interface-ASIC. When it isn't sufficient to guarantee a
 *    proper shape of the sync pulse, the interface ASIC sends a special error
 *    code as the sensor response. Then a bit is set by the sensor modules in
 *    the A_PESRTIntCommFltINTW_U8X array. At the same time the ER voltage is
 *    checked against a certain threshold because there is a direct dependency
 *    between Ver and Vsync. If the ER is too low a second bit in the same
 *    array is set. In this API, both bits are evaluated. If the ER was above
 *    the threshold the internal communication fault is stepped up. If the ER
 *    is too low, it is expected that Vsync is insufficient. In this case the
 *    fault is not stepped up.
 * 
 * This function also checks the 3 bit safety ID of each data transmission.
 * Addtionally the TST and NRO (EOP) bits are checked as soon as sensor data is
 * passed to the algorithm (sensor manager state == E_SMRSteadyState). Any bit
 * which does not match the expected value is shown in the additional fault
 * information.
 ******************************************************************************/
void PES_CheckRTInternalCommFaults(U8 v_sensor_u8r );
/* EasyCASE ) */
/* EasyCASE (
   PES_CheckRTExternalCommFaults */
/******************************************************************************
 * Description:
 *    This function is a standard implementation of the check of the external
 *    communication fault flags, which are set during the sensor type specific
 *    real-time evaluation.
 * 
 *    For each sensor an 8 bit flag bar is reserved in array
 *    A_PESRTExtCommFltINTW_U8X. If one of the bits is set the module internal
 *    fault counter is incremented. When the internal counter reaches the
 *    threshold, the external communication fault is stepped up, and the sensor
 *    is set to error state, switched off and rebooted later. If no fault flag
 *    is set and the sensor is in OK state, the internal fault counter is
 *    decremented. When it reaches the threshold, the fault will be stepped
 *    down.
 * 
 * 
 * Arguments:
 *    v_sensor_u8r: sensor which should be checked
 * 
 * Return:  -
 * 
 * Scheduling:
 *    Every 30 ms called by sensor type specific BG function.
 * 
 * Usage guide:
 *    This API can be used as standard test of the RT fault flags by the sensor
 *    type specific units during their BG monitoring.
 * 
 * Remarks:
 *    The old function pes_CheckRealtimeFaults was split into three different
 *    APIs, so that the runtime consumption can be distributed into 3 10ms
 *    cycles.
 *    Earlier, the external communication fault was stepped up or down after
 *    each evaluation. The module internal filtering was introduced, so that
 *    projects could have longer fault qualification times.
 ******************************************************************************/
void PES_CheckRTExternalCommFaults(U8 v_sensor_u8r );
/* EasyCASE ) */
/* EasyCASE (
   PES_SetInitialState */
/******************************************************************************
 * Description:
 *    This function is a helper function for the sensor type specific
 *    initialization of a sensor.
 * 
 *    At the end of the normal initialization of a sensor (e.g. PA4_Init) this
 *    API can be called to calculate and set the correct sensor state. The
 *    following criteria are used:
 *    - is the sensor configured to be connected to a sensor line
 *      (A_SemCfgDataPESToLine_XEX != E_NotConnected)?
 *    - is the sensor monitored?
 *    - is the sensor configured?
 * 
 *    In case a sensor is configured to be not connected to a sensor line and
 *    the monitoring or configured bit is set, the global sensor configuration
 *    error is set (FltSEMConfiguration). This forces the sensor management
 *    into idle mode.
 * 
 * Arguments:
 *    v_sensor_u8r: sensor for which the initial state should be set
 * 
 * Return:   -
 * 
 * Scheduling:
 *    Called by the sensor type specific init functions (e.g. PA4_Init)
 * 
 * Usage guide:   -
 * 
 * Remarks:   -
 ******************************************************************************/
void PES_SetInitialState(U8 v_sensor_u8r );
/* EasyCASE ) */
/* EasyCASE (
   PES_CallSensorSpecificInit */
/******************************************************************************
 * Description:
 *     Dispatching method to call the peripheral sensor specific initialization
 *     methods. The initialization functions of the sensor types supported by
 *     the platform are called from this function. For sensor types not
 *     supported by the platform (e.g. project specific ones) the function
 *     CSE_CallPasSpecificInit is called. Depending on the return value of that
 *     function, a configuration fault is qualified or not.
 * 
 * Arguments:
 *    - v_sensor_u8r              : index of current sensor
 *    - p_pesIfSettings_u8r       : pointer to settings for PES-IF
 *    - p_pesFirstSampleFIQFp_xfr : pointer to the FIQ evaluation function for
 *      the first of two samples (4kHz) of the PES
 *    - p_pesSecondSampleFIQFp_xfr: pointer to the FIQ evaluation function for
 *      the second of two samples (4kHz) or for the only sample (2kHz) of the
 *      PES
 * 
 *    Note: Parameters two, three and four are call by reference and only
 *    return values to the caller.
 * 
 * Return: -
 * 
 * Scheduling:
 *     Called once for each PES in an early 10ms background cycle.
 * 
 * Usage guide: -
 * 
 * Remarks:
 *     The function CSE_CustSensorSpecificInit has to implement initialization
 *     calls for sensor types which are not supported by the platform. It also
 *     has to take care of unknown sensor types.
 * 
 *     Availability of configuration data need not be checked, as the sensor
 *     configuration is loaded during system init and this function is called
 *     after that from background.
 * 
 *     Every PES type supported by the platform gets one case entry.
 * 
 *     In case of a 2kHz PES the function called by this one (e.g. BRS_Init)
 *     has to return the function pointer in the return parameter
 *     p_pesSecondSampleFIQFp_xpr and SMR_NoOperationFIQ for return parameter
 *     p_pesFirstSampleFIQFp_xpr.
 ******************************************************************************/
void PES_CallSensorSpecificInit(U8 v_sensor_u8r, U8 * p_pesIfSettings_u8r, tp_SensorSpecificFunction * p_pesFirstSampleFIQFp_xfr, tp_SensorSpecificFunction * p_pesSecondSampleFIQFp_xfr );
/* EasyCASE ) */
/* EasyCASE (
   PES_HandleVSyncLowMsgFIQ */
/******************************************************************************
 * Description:
 *    Set the fault bit for the "VSync Low" fault in the bit field for the
 *    internal communication fault. Additionally it checks if the ER voltage
 *    (VER) is above 13V. If not, the highest bit in the bit field is set as
 *    well to suppress the fault handling in PES_CheckRTInternalCommFaults (see
 *    description for reason)
 * 
 * Arguments:
 *    v_sensor_u8r: sensor for which the "VSync Low" msg was received
 * 
 * Return:
 *    -
 * 
 * Scheduling:
 *    Event driven in RT, when the error code "VSync Low" (0x1F6) is received
 * 
 * Usage guide:
 *    To be used in the sensor data evaluation of the PES modules which support
 *    synchronous sensors.
 * 
 * Remarks:
 *    The ER voltage (VER) check was moved from BG to RT due to the defect
 *    Ptedt00041598 where a disturbed internal communication fault was
 *    detected. This was probably caused by the time gap of up to 30ms between
 *    the detection of the error code "VSync Low" in RT and the evaluation and
 *    check of VER in BG. During this time VER was probably loaded from below
 *    13V above this threshold and the fault was stepped up although the
 *    message was expected.
 ******************************************************************************/
void PES_HandleVSyncLowMsgFIQ(U8 v_sensor_u8r );
/* EasyCASE ) */
/* EasyCASE (
   PES_HandleExtCommMsgFIQ */
/******************************************************************************
 * Description:
 *    The API checks if the ER voltage (VER) is above 13V. If not, the highest
 *    bit in the bit field for communication faults is set as well to suppress
 *    the fault handling in PES_CheckRTExternalCommFaults (see description for
 *    reason).
 * 
 * Arguments:
 *    v_sensor_u8r: sensor for which an external communication fault was
 *    detected
 * 
 * Return: -
 * 
 * Scheduling:
 *    Event-driven in RT, when on of the external comm error codes is received
 *    (empty buffer, parity, Manchester coding, invalid data)
 * 
 * Usage guide:
 *    To be used in the sensor data evaluation of sensor specific modules.
 * 
 * Remarks: -
 ******************************************************************************/
void PES_HandleExtCommMsgFIQ(U8 v_sensor_u8r );
/* EasyCASE ) */
/* EasyCASE (
   PES_IsPermanentFltPresent */
/******************************************************************************
 * Description:
 *    This function checks if any peripheral sensor channel related permanent
 *    faults are stored in fault memory.
 * 
 * Arguments:
 *    v_sensor_u8r : peripheral sensor being checked
 * 
 * Return:
 *    - E_True : a permanent fault is stored in fault memory
 *    - E_False: no permanent fault present for this sensor
 * 
 * Scheduling:
 *    Called in BG from sensor specific modules and PES module.
 * 
 * Usage guide:
 *    Call this function to check if peripheral sensor related faults are
 *    stored in fault memory. This is required within all sensor specific
 *    modules to keep a sensor in state "E_SMRSensorInitializationDone" if a
 *    permanent fault is already present in fault memory.
 * 
 * Remarks:
 *    The following faults are classified as permanent:
 * 
 *    - Flt[PES]Plausibility
 *    - Flt[PES]Defect
 * 
 ******************************************************************************/
te_Boolean PES_IsPermanentFltPresent(U8 v_sensor_u8r );
/* EasyCASE ) */
#endif
/* EasyCASE ) */
#endif
/* EasyCASE ) */
