#ifndef Y_sem_s25_smb250H
#define Y_sem_s25_smb250H
#include "utl_options.p"
#include "utl_tb_typesbase.h"
#include "sem_smr_sensormanager.h" 
#include "sem_std_sensortypedefs.h" 
#define C_SMB250SPIReadChannel_U16X             0x8000u  
#define C_SMB250SPIReadDeviceID_U16X            0x0000u  
#define C_SMB250SPIReadRevisionID_U16X          0x0600u  
#define C_SMB250SPIOffsetCancellationON_U16X    0x7801u  
#define C_SMB250SPIOffsetCancellationOFF_U16X   0x7800u  
#define C_SMB250SPIReadOffsetCancellation_U16X  0x7A00u  
#define C_SMB250SPIDemandBite1_U16X             0x3801u  
#define C_SMB250SPIDemandBite2_U16X             0x3802u  
#define C_SMB250SPIDemandBiteOFF_U16X           0x3800u  
#define C_SMB250SPIEOPCommand_U16X              0x0C00u  
#define M_SMB250OffsetStatusAfterEOP_U16X   0x1002u  
#define M_SMB250OffsetCancellationFast_U8X  0x03u    
#define M_SMB250OffsetCancellationOff_U8X   0x00u    
#define C_SMB250DeviceID_U8X                    0x10u   
#define C_SMB250OffsetDelay_U16X                150u    
#define C_SMB250OffsetTreshold_U16X             0x0Au   
#define C_SMB250BiteDelay_U16X                   50u    
#define C_SMB250BiteOffDelay_U16X                10u    
#define C_SMB250BiteMinThreshold_S16X            120    
#define C_SMB250BiteMaxThreshold_S16X            389    
typedef enum
{
  E_SMB250NotConfigured,                     
  E_SMB250SensorDisabled,                    
  E_SMB250InitCalcRawOffset,                 
  E_SMB250InitEvalRawOffset,                 
  E_SMB250InitStartFastOffsetCancellation,   
  E_SMB250InitWaitForOffsetCancellation,     
  E_SMB250InitEvalOffsetCancellation,        
  E_SMB250InitStartBite1,                    
  E_SMB250InitWaitForBite1,                  
  E_SMB250InitSwitchBite2,                   
  E_SMB250InitWaitForBite2,                  
  E_SMB250InitEvalBite,                      
  E_SMB250InitCheckTestModeOff,              
  E_SMB250InitEvaluateErrorsAndEOP,          
  E_SMB250SteadyState1,                      
  E_SMB250SteadyState2,                      
  E_SMB250SteadyState3                       
} te_SMB250Status;
#ifdef Y_INC_FROM_PKG_SEM_SensorMgt
U8 S25_Init(U8 v_asic_u8r, U8 v_channelNo_u8r, te_Boolean e_configured_xxr );
void S25_BackgroundMonitoring10ms(U8 v_asic_u8r );
#endif
#endif
