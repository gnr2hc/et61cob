#ifndef Y_sem_if9_pasifcg974H
#define Y_sem_if9_pasifcg974H
#include "utl_options.p"
#include "utl_tb_typesbase.h"
#include "sem_smr_sensormanager.h" 
#include "sem_std_sensortypedefs.h" 
#define C_Cg974MaxPasLines_U8X          3u
#define C_Cg974MaxPasSamples_U8X        6u 
#define C_Cg974ReadPasCommand_U16X      0x8000u
#define C_Cg974PasOldValue_U8X          0x1000u
#define C_Cg974PasNewValue_U8X          0x0000u
#define C_Cg974ChannelReadLocation_U8X  13u
#define C_Cg974ProgInterface_U16X       0x5E00u
#define M_CG974ProtocolInfo_U8X         0x01u 
#define C_Cg974VerifyPrograming_U16X    0x7E00u
#define C_Cg974EndOfProgramming_U16X    0x0C00u
#define M_Cg974VerifyProgMask_U8X       0x07u   
#define C_Cg974EopExpectedValue_U16X    0x0000u 
#define M_Cg974EopCheckMask_U16X        0xF000u 
#define C_Cg974SwitchSupply_U16X        0x3200u
#define C_Cg974SwitchAout_U16X          0x3005u 
#define C_Cg974VoltageThreshold_U16X    155u  
#define C_Cg974ProgRepetition_U8X       3u
#define M_Cg974AllLinePos_U16X     (U16)((U16)((1u << (C_Cg974MaxPasLines_U8X * (U8)E_MaxCg974Asics)) - 1u) << (U8) A_SemCfgDataFirstLineOnAsic_XEX[E_MaxSystemAsics])
#define Z_Cg974DevLinePos(AsicNo)  (U16)(M_Cg974PasLinesMask_U8X << (U8) A_SemCfgDataFirstLineOnAsic_XEX[E_MaxSystemAsics + (AsicNo)])
#define C_CG974ProgrammingFailed_U8X            0x01u   
#define C_CG974InterpolationRequired_U8X        0x02u   
#ifdef Y_INC_FROM_PKG_SEM_SensorMgt
te_Complete IF9_Init( void );
void IF9_MakeLineMeasurement( void );
void IF9_MakeLineSwitching( void );
void IF9_CyclicLineSampling2ms( void );
te_AsicList IF9_GetFirstCg974InAsicList( void );
#endif
#endif
