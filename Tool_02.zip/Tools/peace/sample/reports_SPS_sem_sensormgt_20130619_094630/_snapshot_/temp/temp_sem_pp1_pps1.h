#ifndef Y_sem_pp1_pps1H
#define Y_sem_pp1_pps1H
#include "utl_options.p"
#include "utl_tb_typesbase.h"
#ifdef Y_Option_sem_pes_peripheralsensors
#include "sem_pes_peripheralsensors.h" 
#endif
#include "sem_smr_sensormanager.h" 
#include "sem_std_sensortypedefs.h" 
#define C_PPS1INIT1Timeout_U16X             176u         
#define C_PPS1StartupTimeout_U16X           525u     
#define C_PPS1StatusMessageLength_U8X         8u     
#define C_PPS1SerialNumberLength_U8X          4u     
#define C_PPS1StatusMessagesComplete_U32X 0x0000FFFFu     
#define C_PPS1PasIfSettings_U8X            0x15u     
#define C_PPS1StatusDataProtocol_U8X        0x30u    
#define C_PPS1StatusDataManufact_U8X        0x01u    
#define C_PPS1StatusDataType_U8X            0x08u    
#define C_PPS1SignalPlausiThreshold_U16X     32u     
#define C_PSIPPS1pressureID1_S16X            0x01E6 
#define C_PSIPPS1pressureID2_S16X            0x01E7 
#define C_PSIPPS1outOfRange_S16X             0x01EC 
#define C_PPS1AbsPressureReceived_U8X        0x01u
#define C_PPS1RelPressureReceived_U8X        0x02u
#define C_PPS1AbsDefaultValue_U8X               0xFFu   
#define C_PPS1AbsMinimumThresh_U8X              0x37u   
#define C_PPS1AbsMaximumThresh_U8X              0x73u   
#define C_PPS1AbsDeltaThresh_U8X                0x06u   
#define M_PPS1MinimumAbsPressureFlt_U8X         0x01u
#define M_PPS1MaximumAbsPressureFlt_U8X         0x02u
#define M_PPS1DeltaAbsPressureFlt_U8X           0x04u
#define M_PPS1NoRelativePressureRcvd_U8X        0x01u   
#define M_PPS1NoAbsIDRcvd_U8X                   0x02u   
#define M_PPS1PresOutRangeError_U8X             0x04u   
typedef enum
{
   E_NoPPS1Configured, 
   E_AbsMinMaxUpdated, 
   E_NoAbsMinMaxUpdate
} te_PPS1MinMaxUpdate;
typedef enum
{
   E_NoAbsIDReceived,
   E_AbsID1Received,
   E_AbsFirstNibbleReceived,
   E_AbsID2Received
} te_PPS1AbsReception;
typedef struct
   {
   #if defined ab10andromeda
   U32 B_Protocol_U8X     : 8;  
   U32 B_Manufacturer_U3X : 3;  
   U32 B_Type_U5X         : 5;  
   U32 B_AbsPresMode_U4X  : 4;  
   U32                    : 4;  
   U32 B_CustomerCode_U8X : 8;  
   #elif defined ab10nec
   U32 B_Protocol_U8X     : 8;  
   U32 B_Type_U5X         : 5;  
   U32 B_Manufacturer_U3X : 3;  
   U32                    : 4;  
   U32 B_AbsPresMode_U4X  : 4;  
   U32 B_CustomerCode_U8X : 8;     
   #else 
      #error unsupported uC type!
   #endif
   } ts_Pps1StatusPart1;
typedef struct
   {
   ts_Pps1StatusPart1 S_Part1_XXX;
   U8 A_SerialNumber_U8X[C_PPS1SerialNumberLength_U8X];  
   } ts_Pps1StatusCode;
typedef struct
   {
   U8                      A_SensorStatusCodeINTW_U8X[C_PPS1StatusMessageLength_U8X];  
   U8                      V_AbsolutePressureINTW_U8X;                                 
   U8                      V_TempAbsPressureINTW_U8X;                                  
   te_PPS1AbsReception     E_PPS1LastReceivedAbsINTW_XXX;                              
   U8                      V_PressureReceiveFlagsINTW_U8X;                             
   U8                      V_MissingAbsCounter_U8X;                                    
   U8                      V_PPS1Dummy_U8X;                                            
   S16                     V_FirstSampleValueINTW_S16X;                                
   } ts_Pps1SpecificData;
#define C_PPS1SpecificRamSize_U16X sizeof(ts_Pps1SpecificData)
#ifdef Y_INC_FROM_PKG_SEM_SensorMgt
void PP1_Init(U8 v_sensor_u8r, U8 * p_pesIfSettings_u8r, tp_SensorSpecificFunction * p_pps1FirstSampleFIQFp_xfr, tp_SensorSpecificFunction * p_pps1SecondSampleFIQFp_xfr );
void PP1_EvaluateFirstSampleFIQ(U16 v_rawData_u16r, U8 v_sensor_u8r, U8 v_channel_u8r );
void PP1_EvaluateSecondSampleFIQ(U16 v_rawData_u16r, U8 v_sensor_u8r, U8 v_channel_u8r );
void PP1_BackGroundMonitoring10ms(U8 v_sensor_u8r, te_PesBgStates e_BGstate_xxr );
void PP1_BackGroundMonitoring100ms( void );
#endif
#endif
