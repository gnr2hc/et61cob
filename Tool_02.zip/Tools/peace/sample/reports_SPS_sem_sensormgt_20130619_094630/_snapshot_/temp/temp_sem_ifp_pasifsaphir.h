#ifndef Y_sem_ifp_pasifsaphirH
#define Y_sem_ifp_pasifsaphirH
#include "utl_options.p"
#include "utl_tb_typesbase.h"
#include "sem_smr_sensormanager.h" 
#include "sem_std_sensortypedefs.h" 
#define C_SaphirMaxPESSamples_U8X              16u
#define C_SaphirMaxPESLines_U8X                4u
#define M_SaphirFourLines_U16X                 0x000Fu
#define C_SaphirNumberOfPSIReceiveReg_U8X      16u
#define C_SaphirTestModePSICons_U16X               0x3810u
#define C_SaphirTestModeOff_U16X                           0x3800u
#define C_SaphirTestPSICons_U16X                           0xDC00u
#define C_SaphirReadPESCommand_U16X            0x8000u
#define C_SaphirSelectPESCommand_U16X          0xC200u
#define C_SaphirReadSupply_U16X                0x1000u
#define C_SaphirSwitchSupply_U16X              0x10C0u
#define M_SaphirLinePos_U16X                   (0x000Fu << E_PasLineSissi1)
#define C_SaphirSyncMask_U16X                  0xF400u
#define C_SaphirSyncGen_U16X                   0xF200u
#define C_SaphirProgSyncMode_U8X               0x00u
#define C_Shift2LinePosReadCmd_U8X             1u
#define C_Shift2DataRegPos_U8X                 3u
#define C_Shift2LinePos_U8X                    5u
typedef struct
   {
   tp_SensorSpecificFunction P_PESSpecificFIQFp_XFX;
   U16                       V_ReadCommand_U16X;
   U8                        V_SensorIndex_U8X;
   U8                        V_ChannelIndex_U8X;
   } ts_PasIfSaphirSetupData;
typedef enum
{
   E_PASLineReg1,
   E_PASLineReg2,
   E_PASLineReg3,
   E_PASLineReg4,
   E_MaxPASLineRegs
}te_PASLineRegs;
typedef enum
{
   E_IFPInitStaticData,
   E_IFPInitSMR,
   E_IFPCalculatePASLineSettings,
   E_IFPProgramPASLines,
   E_IFPInitSID,
   E_IFPInitSyncMode,
   E_IFPSignalPathMonTest,
   E_IFPInitCheckNextSaphir,
   E_IFPInitFinished
}te_IFPInitStates;
typedef enum
{
   E_IFPTestWait,
   E_IFPTestOngoing,
   E_IFPTestFinished
}te_IFPSignalPathMonTestState;
void IFP_InitSignalPathMonTestFIQ( void );
#ifdef Y_INC_FROM_PKG_SEM_SensorMgt
te_Complete IFP_Init( void );
void IFP_MakeLineMeasurement( void );
void IFP_MakeLineSwitching( void );
#endif
#endif
