#ifndef Y_sem_ifs_pasifsissiH
#define Y_sem_ifs_pasifsissiH
#include "utl_options.p"
#include "utl_tb_typesbase.h"
#include "sem_smr_sensormanager.h" 
#include "sem_std_sensortypedefs.h" 
#define C_SissiMaxPasSamples_U8X                12u 
#define C_SissiReadPasCommand_U16X              0x8000u
#define C_SissiPasOldValue_U8X                  1u
#define C_SissiPasNewValue_U8X                  0u
#define C_SissiReadSupply_U16X                  0x1000u
#define C_SissiSwitchSupply_U16X                0x10C0u   
#define C_SissiProgPasSafetyIDLocation_U8X      5u
#define M_SissiTwoLines_U16X                    0x0003u
#define M_SissiFourLines_U16X                   0x000Fu
#define M_SissiSixLines_U16X                    0x003Fu
#define C_IFSNoLinesCG102108_U8X        2u
#define C_IFSNoLinesCG103109_U8X        4u
#define C_IFSNoLinesCG143_U8X           6u
typedef struct
   {                                                
   tp_SensorSpecificFunction P_PESSpecificRTFp_XFX; 
   U16                       V_ReadCommand_U16X;    
   U8                        V_SensorIndex_U8X;     
   U8                        V_ChannelIndex_U8X;    
   } ts_PESifSissiSetupData;                        
#ifdef Y_INC_FROM_PKG_SEM_SensorMgt
te_Complete IFS_Init( void );
void IFS_MakeLineMeasurement( void );
void IFS_MakeLineSwitching( void );
#endif
#endif
