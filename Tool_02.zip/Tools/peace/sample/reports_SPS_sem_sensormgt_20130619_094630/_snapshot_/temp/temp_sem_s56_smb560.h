#ifndef Y_sem_s56_smb560H
#define Y_sem_s56_smb560H
#include "utl_options.p"
#include "utl_tb_typesbase.h"
#include "sem_smr_sensormanager.h" 
#include "sem_std_sensortypedefs.h" 
 /* control error test cases */
#undef Y_SMA560ErrorTestCases        
#ifdef Y_SMA560ErrorTestCases
#include "eem_eem_eeprommgr.h"
#endif
       /* !!! debug information ony for test purposes */
#undef Y_SMB560DbgInfo              
           /* !!! do not react on SMA560 faults */ 
#undef Y_SMB560EMC                  
 /* OFF  for normal mode */
 /* OFF  for normal mode */
#define C_SMA560DeviceID_U8X                     0x56u  
#define C_SMA560BitePosMinThreshold_S16X         59     
#define C_SMA560BitePosMaxThreshold_S16X         181    
#define C_SMA560BiteNegMinThreshold_S16X        -181    
#define C_SMA560BiteNegMaxThreshold_S16X        -59     
#define C_SMA560OffsetValueMin_S16X             -10     
#define C_SMA560OffsetValueMax_S16X              10     
#define C_SMA560ResetDelay_U8X                   20u    
#define C_SMA560Delay10ms_U16X                   10u    
#define C_SMA560Delay20ms_U16X                   20u    
#define C_SMA560Delay30ms_U16X                   30u    
#define C_SMA560Delay1_U32X                      15000u 
#define C_SMA560OutOfRng496LSB_S16X               496   
#define C_SMA560ClockCntPercent_U16X             5242
#define C_SMA560SPIReadIniOfsChA8Bits_U16X      0x5100u  
#define C_SMA560SPIReadIniOfsChA4Bits_U16X      0x5200u  
#define C_SMA560SPIReadIniOfsChB8Bits_U16X      0x5400u  
#define C_SMA560SPIReadIniOfsChB4Bits_U16X      0x5700u  
#define C_SMA560SPIReadChannel1_U16X            0x8000u  
#define C_SMA560SPIReadChannel2_U16X            0xE000u  
#define C_SMA560SPIReadDeviceID_U16X            0x0100u  
#define C_SMA560SPIReadMonitorData1_U16X        0x2300u  
#define C_SMA560SPIReadMonitorData2_U16X        0x2500u  
#define C_SMA560SPISelect96GRange_U16X          0x5d00u  
#define C_SMA560SPIReadAccelRange_U16X          0x0b00u  
#define C_SMA560SPIAccel96gRange_U16X           0x0000u  
#define C_SMA560SPIOffsetCancellationON_U16X    0x7905u  
#define C_SMA560SPIOffsetCancellationOFF_U16X   0x7900u  
#define C_SMA560SPIReadOffsetCancellation_U16X  0x7A00u  
#define C_SMA560OffsetCancellationFast_U8X      0x0Fu    
#define C_SMA560OffsetCancellationSlow_U8X      0x0Au    
#define C_SMA560OffsetCancellationOff_U8X       0x00u    
#define C_SMA560SPIDemandBite1_U16X             0x3809u  
#define C_SMA560SPIDemandBite2_U16X             0x3806u  
#define C_SMA560SPIDemandBiteOFF_U16X           0x3800u  
#define C_SMA560SPIDemandInterpolationOn_U16X   0x6b01u  
#define C_SMA560SPIProgSafetyID_U16X            0x5b00u  
#define C_SMA560SPIReadSafetyID_U16X            0x3700u  
#define C_SMA560SPIReadClockCount_U16X          0x0400u  
#define C_SMA560SPIEOPCommand_U16X              0x0d00u  
#define M_SMA560TFFMisoResponse_U16X            0x8000u  
#define M_SMA560SPIMoni2Interpolation_U16X      0x0001u  
#define M_SMA560MISOResponseLower8Bits_U16X     0x00ffu  
#define M_SMA560MISOChkMaskLower4Bits_U16X      0x000fu  
#define M_SMA560MISOResponseLower4Bits_U16X     0x000fu  
#define M_SMA560MISOResponseSOCActive_U16X      0x100Au  
#define M_SMA560MoniOC1_U16X                  0x0001u    
#define M_SMA560MoniOC2_U16X                  0x0002u    
#define M_SMA560MoniOCC1_U16X                 0x0004u    
#define M_SMA560MoniOCC2_U16X                 0x0008u    
#define M_SMA560MoniNoEclk_U16X               0x0010u    
#define M_SMA560MoniEMprod_U16X               0x0020u    
#define M_SMA560MoniNoEOP_U16X                0x8000u    
#define M_SMA560MoniCRC_U16X                  0x0040u    
#define M_SMA560MoniLI_U16X                   0x0100u    
#define M_SMA560MoniFaultGrp1_U8X              0x01u  
#define M_SMA560MoniFaultGrp2_U8X              0x02u  
#define M_SMA560MoniFaultGrp3_U8X              0x04u  
#define M_SMA560MoniFaultGrp4_U8X              0x08u  
#define M_SMA560MoniFaultGrp5_U8X              0x10u  
#define M_SMA560MoniFaultGrp6_U8X              0x20u  
#define M_SMA560FOCoff_U16X                    0x000fu 
#define M_SMA560LowNibble_U16X                 0x000fu 
#define M_SMA560LowByte_U16X                   0x00ffu 
#define M_SMA560Lower2Bits_U16X                0x0003u 
#define M_SMA560Lower3Bits_U16X                0x0007u 
#define M_SMA560StepupIniFlt_U8X               0x01u 
#define C_SMA560Shift8_U8X                    0x08u   
#define C_SMA560Shift4_U8X                    0x04u   
#define C_SMA560RTDataErrRetries_U8X          3u      
#define C_SMA560MaxOfsOrBITEErrCnt_U8X        19u     
#define C_SMA560NoOfChannels_U8X              2u      
#define C_SMA560MaxLIRepetit_U8X              3u      
#define C_SMA560ClkCntrRepetit_U8X            4u      
#define C_SMA560Div4_S8X                      4       
#ifdef Y_SMB560DbgInfo
#define C_SMA560RngBufSize_U8X                5       
#endif
#ifdef Y_SMA560ErrorTestCases
#define M_SMA560_DbgCtrlA1_U16X         0x0001 
#define M_SMA560_DbgCtrlA2_U16X         0x0002 
#define M_SMA560_DbgCtrlA3_U16X         0x0004 
#define M_SMA560_DbgCtrlA4_U16X         0x0008 
#define M_SMA560_DbgCtrlA5_U16X         0x0010 
#define M_SMA560_DbgCtrlA6_U16X         0x0020 
#define M_SMA560_DbgCtrlB1_U16X         0x0040 
#define M_SMA560_DbgCtrlB2_U16X         0x0080 
#define M_SMA560_DbgCtrlB3_U16X         0x0100 
#define M_SMA560_DbgCtrlB4_U16X         0x0200 
#define M_SMA560_DbgCtrlB5_U16X         0x0400 
#define M_SMA560_DbgCtrlB6_U16X         0x0800 
#define M_SMA560_DbgCtrlB7_U16X         0x1000 
#define M_SMA560_DbgCtrlB8_U16X         0x2000    
#define M_SMA560_DbgCtrlB9_U16X         0x4000 
#define M_SMA560_DbgCtrlB10_U16X        0x8000 
#define M_SMA560_DbgCtrlC1_U16X         0x00010000 
#define M_SMA560_DbgCtrlC2_U16X         0x00020000 
#define M_SMA560_DbgCtrlD1_U16X         0x00040000 
#define M_SMA560_DbgCtrlE1_U16X         0x00080000 
#define M_SMA560_DbgCtrlE2_U16X         0x00100000 
#define M_SMA560_DbgCtrlE3_U16X         0x00200000 
#define M_SMA560_DbgCtrlF1_U16X         0x00400000 
#define M_SMA560_DbgCtrlF2_U16X         0x00800000 
#define M_SMA500_DbgCtrlF3_U16X         0x01000000 
#define M_SMA500_DbgCtrlF4_U16X         0x02000000 
#endif
#define M_SMA560IntrlPrgm0_U8X 0x01u 
#define M_SMA560IntrlPrgm1_U8X 0x02u 
#define M_SMA560IntrlPrgm2_U8X 0x04u 
#define M_SMA560IntrlPrgm3_U8X 0x08u 
#define M_SMA560IntrlPrgm4_U8X 0x10u 
#define M_SMA560IntrlPrgm5_U8X 0x20u 
#define M_SMA560OfsChA_U8X   0x01u 
#define M_SMA560BITE1ChA_U8X 0x02u 
#define M_SMA560BITE2ChA_U8X 0x04u 
#define M_SMA560OfsChB_U8X   0x08u 
#define M_SMA560BITE1ChB_U8X 0x10u 
#define M_SMA560BITE2ChB_U8X 0x20u 
#define M_SMA560ReinitFOC_U8X        0x01u 
#define M_SMA560OfsChAafterBITE_U8X  0x02u 
#define M_SMA560OfsChBafterBITE_U8X  0x04u 
#define M_SMA560OfsChABITE1or2_U8X   0x08u 
#define M_SMA560OfsChBBITE1or2_U8X   0x10u 
typedef enum                                 
{
  E_SMA560NotConfigured,                     
  E_SMA560SensorDisabled,                    
  E_SMA560InitPart1,                         
  E_SMA560InitPart2,                         
  E_SMA560InitPart3,                         
  E_SMA560InitPart4,                         
  E_SMA560InitPart5,                         
  E_SMA560InitEOPAndEvaluation,              
  E_SMA560SteadyState1,                      
  E_SMA560SteadyState2,                      
  E_SMA560SteadyState3                       
} te_SMA560Status;                           
typedef enum
{                                            
  E_SMA560InitGRangePart1,                   
  E_SMA560CheckAccelRange                     
} te_SMA560InitPart1;                        
typedef enum
{                                 
  E_CheckIfFOCisOFF,              
  E_SMA560ReadInitialOfs,         
  E_SMA560DoAveragingAndEval      
} te_SMA560InitPart2;             
typedef enum
{                                            
  E_SMA560ReinitFOC,                         
  E_SMA560WaitCheckIfFOCisOff,               
  E_SMA560BuildAverageAfterFOC,              
  E_SMA560InitStartBite1,                    
  E_SMA560InitWaitForBite1,                  
  E_SMA560InitStartBite2                     
} te_SMA560InitPart3;                        
typedef enum
{                                            
  E_SMA560InitWaitForBite2,                  
  E_SMA560StoreBITE2,                        
  E_SMA560TestIfBiteOff,                     
  E_SMA560SOfsAfterBITE,                     
  E_SMA560InitEvalOfsAfterBITE,              
  E_SMA560InitEvalBite                       
} te_SMA560InitPart4;                        
typedef enum
{                                    
  E_SMA560SensorUsedForSCON,          
  E_SMA560InitWaitSconTest,          
  E_SMA560ProgramSID,                
  E_SMA560ChkLinearInterpolation,    
  E_SMA560EnableLinearInterpolation  
} te_SMA560InitPart5;                
typedef struct {     
U32 V_DelayTimer_U32X;                              
U16 V_PrevClockCount_U16X;                          
S16 V_IniOfsRegValueChA_S16X;                       
S16 V_IniOfsRegValueChB_S16X;                       
S16 V_ChannelBiteOfsChA_S16X;                       
S16 V_ChannelBiteOfsChB_S16X;                       
te_SMA560InitPart1 E_InitPart1_SXX;                 
te_SMA560InitPart2 E_InitPart2_SXX;                 
te_SMA560InitPart3 E_InitPart3_SXX;                 
te_SMA560InitPart4 E_InitPart4_SXX;                 
te_SMA560InitPart5 E_InitPart5_SXX;                 
te_Boolean E_IsInterMoniFltQual_SXX;                
U8 V_IntrlMoniFltActiv_U8X;                         
U8 V_ClkCntrRepetit_U8X;                            
U8 V_Counter_U8X;                                   
U8 F_InitTestPassed_U8X;                            
U8 V_OfsBITECntr_U8X;                               
U8 V_StatusInfo_U8X;                                
U8 A_NoOfWrongDataINTW_U8X[C_SMA560NoOfChannels_U8X]; 
#ifdef Y_SMB560DbgInfo
U8 V_CntrNoTFFset_U8X;                              
U8 V_CntrSWReset_U8X;                               
U8 V_AsicNr_U8X;                                    
U8 V_AsicNrCnv_U8X;                                 
U16 V_Devicedata_U16X;                              
U16 V_TFFResponse_U16X;                             
U16 V_GRange_U16X;                                  
U16 V_ClockCount_U16X;                              
U16 V_MonitorData12_U16X;                           
U16 V_SOCStatus_U16X;                               
U8 V_StatusInfo1_U8X;                               
S16 V_CancelFOCValueChA_S16X;                       
S16 V_CancelFOCValueChB_S16X;                       
U8  V_Channel_U8R;                                  
U8  V_ChIdxForInst_U8R;                             
U16 V_PrevMainCtrlState_U16X;                       
U32 V_TimeDiff_U32X;                                
U32 V_CurrentTime_U32X;                             
U8  V_TimeDiffms_U8X;                               
S16 V_ClockCountDiff_S16R;                          
S16 V_ClkCntTrgtValue_S16R;                         
S16 V_MinClkCntTrgtValue_S16R;                      
S16 V_MaxClkCntTrgtValue_S16R;                      
U16 V_RawClockCount_U16R;                           
#endif
#ifdef Y_SMA560ErrorTestCases                       
te_EEMgrOperStatus E_EEMSuccess1_SXX;
U8  V_EERead1_U8X;                                  
U32 V_DbgFaultControl_U32X;                         
U32 V_RTCounter_U32X;                               
#endif
} ts_SMA560Data;  
typedef enum                              
{
E_SMA560IntrnlMoniFlt000000,/*! E_SMA560IntrnlMoniFlt000000: not used */
E_SMA560IntrnlMoniFlt000001,/*! E_SMA560IntrnlMoniFlt000001: B8 group1, OC1, OC2, OCC1, OCC2 */
E_SMA560IntrnlMoniFlt000010,/*! E_SMA560IntrnlMoniFlt000010: B8 group2, CLK, LI */
E_SMA560IntrnlMoniFlt000011,/*! E_SMA560IntrnlMoniFlt000011: B8 group1,2 */
E_SMA560IntrnlMoniFlt000100,/*! E_SMA560IntrnlMoniFlt000100: B8 group3, EMprod */
E_SMA560IntrnlMoniFlt000101,/*! E_SMA560IntrnlMoniFlt000101: B8 group1,3 */
E_SMA560IntrnlMoniFlt000110,/*! E_SMA560IntrnlMoniFlt000110: B8 group2,3 */
E_SMA560IntrnlMoniFlt000111,/*! E_SMA560IntrnlMoniFlt000111: B8 group1,2,3 */
E_SMA560IntrnlMoniFlt001000,/*! E_SMA560IntrnlMoniFlt001000: B8 group4 SID NoOff12 NoTe112 NoEOP */
E_SMA560IntrnlMoniFlt001001,/*! E_SMA560IntrnlMoniFlt001001: B8 group1,4 */
E_SMA560IntrnlMoniFlt001010,/*! E_SMA560IntrnlMoniFlt001010: B8 group1,2 */
E_SMA560IntrnlMoniFlt001011,/*! E_SMA560IntrnlMoniFlt001011: B8 group1,2,4 */
E_SMA560IntrnlMoniFlt001100,/*! E_SMA560IntrnlMoniFlt001100: B8 group3,4 */
E_SMA560IntrnlMoniFlt001101,/*! E_SMA560IntrnlMoniFlt001101: B8 group1,3,4 */
E_SMA560IntrnlMoniFlt001110,/*! E_SMA560IntrnlMoniFlt001110: B8 group2,3,4 */
E_SMA560IntrnlMoniFlt001111,/*! E_SMA560IntrnlMoniFlt001111: B8 group1,2,3,4 */
E_SMA560IntrnlMoniFlt010000,/*! E_SMA560IntrnlMoniFlt010000: B8 group5 CRC, SPIEC */
E_SMA560IntrnlMoniFlt010001,/*! E_SMA560IntrnlMoniFlt010001: B8 group1,5 */
E_SMA560IntrnlMoniFlt010010,/*! E_SMA560IntrnlMoniFlt010010: B8 group2,5 */
E_SMA560IntrnlMoniFlt010011,/*! E_SMA560IntrnlMoniFlt010011: B8 group1,2,5 */
E_SMA560IntrnlMoniFlt010100,/*! E_SMA560IntrnlMoniFlt010100: B8 group3,5 */
E_SMA560IntrnlMoniFlt010101,/*! E_SMA560IntrnlMoniFlt010101: B8 group1,3,5 */
E_SMA560IntrnlMoniFlt010110,/*! E_SMA560IntrnlMoniFlt010110: B8 group2,4,5 */
E_SMA560IntrnlMoniFlt010111,/*! E_SMA560IntrnlMoniFlt010111: B8 group1,2,3,5 */
E_SMA560IntrnlMoniFlt011000,/*! E_SMA560IntrnlMoniFlt011000: B8 group4,5 */
E_SMA560IntrnlMoniFlt011001,/*! E_SMA560IntrnlMoniFlt011001: B8 group1,4,5 */
E_SMA560IntrnlMoniFlt011010,/*! E_SMA560IntrnlMoniFlt011010: B8 group2,4,5 */
E_SMA560IntrnlMoniFlt011011,/*! E_SMA560IntrnlMoniFlt011011: B8 group1,2,4,5 */
E_SMA560IntrnlMoniFlt011100,/*! E_SMA560IntrnlMoniFlt011100: B8 group3,4,5 */
E_SMA560IntrnlMoniFlt011101,/*! E_SMA560IntrnlMoniFlt011101: B8 group1,3,4,5 */
E_SMA560IntrnlMoniFlt011110,/*! E_SMA560IntrnlMoniFlt011110: B8 group2,3,4,5 */
E_SMA560IntrnlMoniFlt011111,/*! E_SMA560IntrnlMoniFlt011111: B8 group1,2,3,4,5 */
E_SMA560IntrnlMoniFlt100000,/*! E_SMA560IntrnlMoniFlt100000: not used */
E_SMA560IntrnlMoniFlt100001,/*! E_SMA560IntrnlMoniFlt100001: B1 ASICD does not match */
E_SMA560IntrnlMoniFlt100010,/*! E_SMA560IntrnlMoniFlt100010: B2 TFF wrong after SW reset */
E_SMA560IntrnlMoniFlt100011,/*! E_SMA560IntrnlMoniFlt100011: B2 sensor data is 496LSB after SW reset */
E_SMA560IntrnlMoniFlt100100,/*! E_SMA560IntrnlMoniFlt100100: B3 g range is not 96g after SW reset */
E_SMA560IntrnlMoniFlt100101,/*! E_SMA560IntrnlMoniFlt100101: B4 FOC is not automatically switched off */
E_SMA560IntrnlMoniFlt100110,/*! E_SMA560IntrnlMoniFlt100110: B5 FOC is not switched off (reinit. FOC) */
E_SMA560IntrnlMoniFlt100111,/*! E_SMA560IntrnlMoniFlt100111: B6 wrong clock count, init. phase */
E_SMA560IntrnlMoniFlt101000,/*! E_SMA560IntrnlMoniFlt101000: B7 monitor data1 or data2 bit set */
E_SMA560IntrnlMoniFlt101001,/*! E_SMA560IntrnlMoniFlt101001: B7 NRO is not 0 directly after EOP */
E_SMA560IntrnlMoniFlt101010,/*! E_SMA560IntrnlMoniFlt101010: B7 monitor data1,2 NRO unequal 0 after EOP */
E_SMA560IntrnlMoniFlt101011,/*! E_SMA560IntrnlMoniFlt101011: B9 clock count out of range, steady state */
E_SMA560IntrnlMoniFlt101100,/*! E_SMA560IntrnlMoniFlt101100: B10 g-range selection invalid */
E_SMA560IntrnlMoniFlt101101,/*! E_SMA560IntrnlMoniFlt101101: not used */
E_SMA560IntrnlMoniFlt101110,/*! E_SMA560IntrnlMoniFlt101110: not used */
E_SMA560IntrnlMoniFlt101111,/*! E_SMA560IntrnlMoniFlt101111: not used */
E_SMA560IntrnlMoniFlt110000,/*! E_SMA560IntrnlMoniFlt110000: not used */
E_SMA560IntrnlMoniFlt110001,/*! E_SMA560IntrnlMoniFlt110001: not used */
E_SMA560IntrnlMoniFlt110010,/*! E_SMA560IntrnlMoniFlt110010: not used */
E_SMA560IntrnlMoniFlt110011,/*! E_SMA560IntrnlMoniFlt110011: not used */
E_SMA560IntrnlMoniFlt110100,/*! E_SMA560IntrnlMoniFlt110100: not used */
E_SMA560IntrnlMoniFlt110101,/*! E_SMA560IntrnlMoniFlt110101: not used */
E_SMA560IntrnlMoniFlt110110,/*! E_SMA560IntrnlMoniFlt110110: not used */
E_SMA560IntrnlMoniFlt110111,/*! E_SMA560IntrnlMoniFlt110111: not used */
E_SMA560IntrnlMoniFlt111000,/*! E_SMA560IntrnlMoniFlt111000: not used */
E_SMA560IntrnlMoniFlt111001,/*! E_SMA560IntrnlMoniFlt111001: not used */
E_SMA560IntrnlMoniFlt111010,/*! E_SMA560IntrnlMoniFlt111010: not used */
E_SMA560IntrnlMoniFlt111011,/*! E_SMA560IntrnlMoniFlt111011: not used */
E_SMA560IntrnlMoniFlt111100,/*! E_SMA560IntrnlMoniFlt111100: not used */
E_SMA560IntrnlMoniFlt111101,/*! E_SMA560IntrnlMoniFlt111101: not used */
E_SMA560IntrnlMoniFlt111110,/*! E_SMA560IntrnlMoniFlt111110: not used */
E_SMA560IntrnlMoniFlt111111 /*! E_SMA560IntrnlMoniFlt111111: not used */
} te_SMA560IntrnlMoniFault;   
#ifdef Y_INC_FROM_PKG_SEM_SensorMgt
U8 S56_Init(U8 v_asic_u8r, U8 v_channelNo_u8r, te_Boolean e_configured_xxr );
void S56_BackgroundMonitoring10ms(U8 v_asic_u8r );
void S56_EvaluateSensorDataFIQ(U16 v_rawData_u16r, U8 v_sensor_u8r, U8 v_channel_u8r );
#endif
#endif
