#ifndef Y_sem_m2r_rollratemm2rH
#define Y_sem_m2r_rollratemm2rH
#include "utl_options.p"
#include "utl_tb_typesbase.h"
#include "sem_smr_sensormanager.h" 
#include "sem_std_sensortypedefs.h" 
#define C_MM2RDeviceID_U8X                    0x95u   
#define C_MM2RPartIdLengt_U8X                 0x04u   
#define C_MM2R55msLatch_U8X                    110u   
#define C_MM2RResetDelay_U8X                     2u   
#define C_MM2RResetEvaluationDelay_U16X        150u   
#define C_MM2RRawOffsetDelay_U16X              500u   
#define C_MM2ROffsetThreshold_U16X            0x32u   
#define C_MM2ROffsetDelayFirst_U16X            500u   
#define C_MM2ROffsetDelayRetry_U16X            200u   
#define C_MM2RBiteDelay_U16X                  60u     
#define C_MM2RBiteOffDelay_U16X               70u     
#define C_MM2RBiteMinThreshold_S16X           115     
#define C_MM2RBiteMaxThreshold_S16X           460     
#define C_MM2REOPDelay_U16X                   100u    
#define C_MM2RSPIReadSensorData_U16X          0x8000u  
#define C_MM2RSPIReadDeviceID_U16X            0x0000u  
#define C_MM2RSPIReadMonitorData1_U16X        0x3A00u  
#define C_MM2RSPIReadMonitorData2_U16X        0x3C00u  
#define C_MM2RSPIOffsetCancellationON_U16X    0x7801u  
#define C_MM2RSPIOffsetCancellationOFF_U16X   0x7800u  
#define C_MM2RSPIReadOffsetCancellation_U16X  0x7A00u  
#define C_MM2RSPIDemandBitePos_U16X           0x3801u  
#define C_MM2RSPIDemandBiteNeg_U16X           0x3802u  
#define C_MM2RSPIDemandBiteOFF_U16X           0x3800u  
#define C_MM2RSPIReadPartId1_U16X             0x5E00u  
#define C_MM2RSPIReadPartId2_U16X             0x5C00u  
#define C_MM2RSPIReadPartId3_U16X             0x5A00u  
#define C_MM2RSPIReadPartId4_U16X             0x5800u  
#define C_MM2RSPIEOPCommand_U16X              0x0C00u  
#define M_MM2RNROBit_U8X                        0x20u  
#define M_MM2RSafetyID_U8X                      0x0Cu  
#define M_MM2RInitMoni1Expected_U16X          0x1000u  
#define M_MM2RInitMoni1Checked_U16X           0x100Au  
#define M_MM2RCheckedMonibitsInit_U16R        0x01FFu  
#define M_MM2RCheckedMonibitsSteady_U16R      0x05FFu  
#define M_MM2RSPIOffsetCancellationFast_U8X     0x03u  
#define M_MM2RSPIOffsetCancellationSlow_U8X     0x02u  
#define M_MM2RSPIOffsetCancellationOff_U8X      0x00u  
#define M_MM2RSPIOffsetStatusAfterEOP_U16X    0x1002u  
#define M_MM2RSPIPartIDApplication_U8X          0x30u  
#define M_MM2RMoniDrive_U16X            0x0002u
#define M_MM2RMoniPll_U16X              0x0008u
#define M_MM2RMoniRateChannel_U16X      0x0021u
#define M_MM2RMoniDriveChannel_U16X     0x00C4u
#define M_MM2RMoniOffset_U16X           0x0410u
#define M_MM2RMoniParity_U16X           0x0100u
#define M_MM2RMoniFaultDrive_U8X        0x01u
#define M_MM2RMoniFaultPll_U8X          0x02u
#define M_MM2RMoniFaultRateChannel_U8X  0x04u
#define M_MM2RMoniFaultDriveChannel_U8X 0x08u
#define M_MM2RMoniFaultOffset_U8X       0x10u
#define M_MM2RMoniFaultParity_U8X       0x20u
typedef enum
{
  E_MM2RNotConfigured,                     
  E_MM2RSensorDisabled,                    
  E_MM2RInitResetTestStart,                
  E_MM2RInitResetTestDelay,                
  E_MM2RInitResetTestEval,                 
  E_MM2RInitReadPartID ,                   
  E_MM2RInitRawOffsetDelay,                
  E_MM2RInitRawOffsetMeasurement,          
  E_MM2RInitFastOffsetStart,               
  E_MM2RInitFastOffsetDelay,               
  E_MM2RInitFastOffsetEval,                
  E_MM2RInitBite1Start,                    
  E_MM2RInitBite1Delay,                    
  E_MM2RInitBiteSwitch,                    
  E_MM2RInitBite2Delay,                    
  E_MM2RInitBiteEval,                      
  E_MM2RInitBiteSendOff,                   
  E_MM2RInitBiteCheckOff,                  
  E_MM2RInitProgramSensor,                 
  E_MM2RInitCompleteInit,                  
  E_MM2RSteadyState1,                      
  E_MM2RSteadyState2,                      
  E_MM2RSteadyState3                       
} te_MM2RStatus;
#ifdef Y_INC_FROM_PKG_SEM_SensorMgt
U8 M2R_Init(U8 v_asic_u8r, U8 v_channelNo_u8r, te_Boolean e_configured_xxr );
void M2R_BackgroundMonitoring10ms( void );
void M2R_EvaluateSensorDataFIQ(U16 v_rawData_u16r, U8 v_sensor_u8r, U8 v_channel_u8r );
#endif
#endif
