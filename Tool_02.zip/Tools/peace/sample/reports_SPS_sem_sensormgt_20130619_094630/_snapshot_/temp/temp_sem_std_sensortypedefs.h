#ifndef Y_sem_std_sensortypedefsH
#define Y_sem_std_sensortypedefsH
#include "utl_options.p"
#include "utl_tb_typesbase.h"
#ifdef Y_Option_sem_cst_custsensortypedefspar
#include "sem_cst_custsensortypedefspar.p" 
#endif
#include "sem_smr_sensormanager.h" 
#include "sem_std_sensortypedefs.h" 
#define C_PESOptionManuBosch_U16X         0x0001u
#define C_PESOptionManuVDO_U16X           0x0002u
#define C_PESOptionManuAutoliv_U16X       0x0004u
#define C_PESOptionManuTemic_U16X         0x0008u
#define C_PESOptionManuTrw_U16X           0x0009u
#define M_PESOptionManuMask_U16X          0x000Fu
#define C_PESOptionTSlot1_U16X            0x0000u
#define C_PESOptionTSlot2_U16X            0x0010u
#define C_PESOptionTSlot3_U16X            0x0020u
#define C_PESOptionTSlot4_U16X            0x0030u
#define M_PESOptionTSlotMask_U16X         0x0030u
#define C_PESOptionTSlotIndent_U8X        4u
#define C_PESOption125kbps_U16X           0x0000u
#define C_PESOption189kbps_U16X           0x0040u
#define M_PESOptionSpeedMask_U16X         0x0040u
#define C_PESOptionParity_U16X            0x0000u
#define C_PESOptionCRC_U16X               0x0080u
#define M_PESOptionProtMask_U16X          0x0080u
#define C_PESOptionAsync_U16X             0x0000u
#define C_PESOptionSync_U16X              0x0100u
#define C_PESOptionDaisyChain_U16X        0x0200u
#define M_PESOptionSyncMask_U16X          0x0300u
#define C_PESOptionsSyncIndent_U8X        8u
#define C_PESOptionDataRate4kHz_U16X      0x0000u
#define C_PESOptionDataRate2kHz_U16X      0x0400u
#define C_PESOptionInterpolOff_U16X       0x0000u
#define C_PESOptionInterpolOn_U16X        0x0800u
#define C_PESOptionAccBetaAxis_U16X       0x0000u
#define C_PESOptionAccAlphaAxis_U16X      0x2000u
#define C_PESOptionAccGammaAxis_U16X      0x4000u
#define M_PESOptionAccAxisMask_U16X       0x6000u
#define C_PESOptionAccAxisIndent_U8X      13u
#define C_PESOptionPas4CG968_U16X         0x0000u
#define C_PESOptionPas4CG969_U16X         0x1000u
#define C_PESOptionPas520mA_U16X          0x0000u
#define C_PESOptionPas535mA_U16X          0x8000u
#define M_PESOptionPas5CurrentMask_U16X   0x8000u
#define C_PESOptionPas5CurrentIndent_U16X 15u
#define C_PESOptionPas5400Hz_U16X         0x0000u
#define C_PESOptionPas5200Hz_U16X         0x1000u
#define M_PESOptionPas5FilterMask_U16X    0x1000u
#define C_PESOptionPas5FilterIndent_U16X  12u
#define C_PESOptionPreNormal_U16X         0x0000u
#define C_PESOptionPreOnlyAbsPre_U16X     0x1000u
#define C_PESOptionPreOnlyInit_U16X       0x2000u
#define M_PESOptionPreAbsPreMask_U16X     0x3000u
#define C_PESOptionPreAbsPreIndent_U16X   12u
#define M_PSISingleTimeSlot_U8X                0x00u
#define M_PSITwoTimeSlots_U8X                  0x08u
#define M_PSIThreeTimeSlots_U8X                0x10u
#define M_PSIFourTimeSlots_U8X                 0x18u
typedef enum
{
   E_UFS = 0,
   E_PAS = 1,
   E_Variable = 2,
   E_RollRate = 3,
   E_NotSafetyRelevant = 4,
   E_CentralX = 5,
   E_CentralY = 6,
   E_NotAllowed = 7
} te_SensorSafetyIDList;
typedef enum
{
   E_InvalidCsType,
   E_SMB460,
   E_SMB250,
   E_SMB200,
   E_MM2R,
   E_MM2S,
   E_SMB560,
   #ifdef Z_SEMUseCustSpecificSensorTypes
        Z_SEMCustSpecificSensorTypes()
   #endif
} te_CSTypeList;
#endif
