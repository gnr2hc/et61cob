#ifndef Y_sem_s46_smb460H
#define Y_sem_s46_smb460H
#include "utl_options.p"
#include "utl_tb_typesbase.h"
#include "sem_smr_sensormanager.h" 
#include "sem_std_sensortypedefs.h" 
#define C_SMB460DeviceID_U8X                    0x46u   
#define C_SMB460OffsetThreshold_U16X            0x0Au   
#define C_SMB460OffsetDelay_U16X                150u    
#define C_SMB460BiteDelay_U16X                  150u    
#define C_SMB460BiteMinThreshold_S16X           50      
#define C_SMB460BiteMaxThreshold_S16X           150     
#define C_SMB460SPIReadChannel1_U16X            0x8000u  
#define C_SMB460SPIReadChannel2_U16X            0xC000u  
#define C_SMB460SPIReadDeviceID_U16X            0x0000u  
#define C_SMB460SPIReadMonitorData1_U16X        0x2200u  
#define C_SMB460SPIReadMonitorData2_U16X        0x2400u  
#define C_SMB460SPIOffsetCancellationON_U16X    0x7805u  
#define C_SMB460SPIOffsetCancellationOFF_U16X   0x7800u  
#define C_SMB460SPIReadOffsetCancellation_U16X  0x7A00u  
#define C_SMB460OffsetCancellationFast_U8X      0x0Fu    
#define C_SMB460OffsetCancellationSlow_U8X      0x0Au    
#define C_SMB460OffsetCancellationOff_U8X       0x00u    
#define C_SMB460SPIDemandBite1_U16X             0x3809u  
#define C_SMB460SPIDemandBite2_U16X             0x3806u  
#define C_SMB460SPIDemandBiteOFF_U16X           0x3800u  
#define C_SMB460SPIDemandInterpolation_U16X     0x6A01u  
#define C_SMB460SPIProgSafetyID_U16X            0x5A00u  
#define C_SMB460SPIReadSafetyID_U16X            0x3600u  
#define C_SMB460SPIEOPCommand_U16X              0x0C00u  
#define M_SMB460SPIMoni2StatusAfterEOP_U16X     0x0000u  
#define M_SMB460SPIMoni2CheckAfterEOP_U16X      0x00FEu  
#define M_SMB460SPIMoni2Interpolation_U16X      0x0001u  
#define M_SMB460SPISlowOffsetCalcActive_U16X    0x100Au  
#define M_SMB460MoniOffsetOutOfRange_U16X       0x0003u
#define M_SMB460MoniOffsetWrongMode_U16X        0x000Cu
#define M_SMB460MoniNoECLK_U16X                 0x0010u
#define M_SMB460MoniExtModeOrCRCError_U16X      0x0060u
#define M_SMB460MoniSpiError_U16X               0x0080u
#define M_SMB460Moni2Interpolation_U16X         0x0100u
#define M_SMB460MoniFaultOffsetOutOfRange_U8X   0x01u
#define M_SMB460MoniFaultOffsetWrongMode_U8X    0x02u
#define M_SMB460MoniFaultNoECLK_U8X             0x04u
#define M_SMB460MoniFaultExtModeOrCRCError_U8X  0x08u
#define M_SMB460MoniFaultSpiError_U8X           0x10u
#define M_SMB460MoniFaultInterpolation_U8X      0x20u
typedef enum
{
  E_SMB460NotConfigured,                     
  E_SMB460SensorDisabled,                    
  E_SMB460InitCalcRawOffset,                 
  E_SMB460InitEvalRawOffset,                 
  E_SMB460InitStartFastOffsetCancellation,   
  E_SMB460InitWaitForOffsetCancellation,     
  E_SMB460InitEvalOffsetCancellation,        
  E_SMB460InitStartBite1,                    
  E_SMB460InitWaitForBite1,                  
  E_SMB460InitSwitchBite2,                   
  E_SMB460InitWaitForBite2,                  
  E_SMB460InitEvalBite,                      
  E_SMB460InitWaitSconTest,                  
  E_SMB460InitCheckTestModeOff,              
  E_SMB460InitProgramSensor,                 
  E_SMB460InitEvaluateErrorsAndEOP,          
  E_SMB460SteadyState1,                      
  E_SMB460SteadyState2,                      
  E_SMB460SteadyState3                       
} te_SMB460Status;
typedef struct {  
te_Boolean E_IsInterMoniFltQual_SXX; 
U8 V_LIRepetitCntr_U8X;              
} ts_SMB460Data;  
#ifdef Y_INC_FROM_PKG_SEM_SensorMgt
U8 S46_Init(U8 v_asic_u8r, U8 v_channelNo_u8r, te_Boolean e_configured_xxr );
void S46_BackgroundMonitoring10ms(U8 v_asic_u8r );
#endif
#endif
