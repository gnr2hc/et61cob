/* EasyCASE V6.5 01.01.2008 00:00:00 */
/* EasyCASE O
If=vertical
LevelNumbers=no
LineNumbers=no
Colors=16777215,0,12582912,12632256,0,0,0,16711680,8388736,0,33023,32768,0,0,0,0,0,32768,12632256,255,65280,255,255,16711935
ScreenFont=Courier New,,80,4,-11,0,400,0,0,0,0,0,0,3,2,1,49,96,96
PrinterFont=Courier New,,80,4,-66,0,400,0,0,0,0,0,0,3,2,1,49,600,600
LastLevelId= */
/* EasyCASE (
   sem_std_sensortypedefs.h */
#ifndef Y_sem_std_sensortypedefsH
#define Y_sem_std_sensortypedefsH
/* EasyCASE - */
/*#ACD# M(Bosch Copyright) */
/* ************************************************************************** */
/*                                                                            */
/*  Copyright (c) 2009 Robert Bosch GmbH, Germany                             */
/*                All rights reserved                                         */
/*                                                                            */
/* ************************************************************************** */
/*#end ACD#*/
/*#ACD# M(sem_std_sensortypedefs Header Author) Author*/
/*
 *  $Source: peace/sample/reports_SPS_sem_sensormgt_20130619_094630/_snapshot_/sem_std_sensortypedefs.h $
 *  $Revision: 1.1 $
 *  $Author: Reddivari Devendra Kumar (RBEI/ESA-PP) (dvn2kor) $
 */
/*#end ACD#*/
/* ************************************************************************** *
 *  Description:
 * This header file contains all sensor typedefs, enums and constants which are
 * needed to setup the parameters in alg_sysconfeeprom.p:
 * 
 * - safety ID definitions
 * - central sensor type
 * - peripheral sensor data rate and sync settings (as part of sensor options)
 *
 *
 *  Reference to Documentation:  sem_std_sensortypedefs_SDS.HTML
 */
/* ********************** Framecode-Generator V2.0 ************************** */
/* EasyCASE (
   History */
/* ****************************** History *********************************** */
/*#ACD# M(sem_std_sensortypedefs Header) History*/
/*
 *  $Log: peace/sample/reports_SPS_sem_sensormgt_20130619_094630/_snapshot_/sem_std_sensortypedefs.h  $
 *  Revision 1.1 2013/07/31 00:03:31ICT Reddivari Devendra Kumar (RBEI/ESA-PP) (dvn2kor) 
 *  Initial revision
 *  Member added to project g:/MKS/Projects/TurboLIFT/Tools/Tools.pj
 *  Revision 1.1 2013/06/19 06:19:06MESZ Vernon Hawes (RBEI/ESA1) (ver6cob) 
 *  Initial revision
 *  Member added to project g:/MKS/Projects/TurboLIFT/Projects/AB12/AB12.pj
 *  Revision 5.5 2012/03/12 15:31:22IST Bharath Sambamoorthy (RBEI/ESA3) (bhs6kor) 
 *  updated aftere review
 *  --- Added comments ---  bhs6kor [2012/03/16 05:08:07Z]
 *  State changed: develop -> reviewed by bhs6kor
 *  
 *  --- Added comments ---  kps1kor [2012/03/16 13:30:39Z]
 *  State changed: reviewed -> release by kps1kor
 *  Revision 5.4 2012/02/21 11:39:05IST bhs6kor 
 *  added macro for allowing customer specific sensor init.
 *  removed sensor typedef from AMEOS model to user defined section
 *  --- Added comments ---  bhs6kor [2012/02/23 09:25:23Z]
 *  State changed: develop -> ready_for_review by bhs6kor
 *  Revision 5.3 2010/11/25 20:00:18IST fru1si 
 *  Re-generated after description change in AMEOS.
 *  --- Added comments ---  fru1si [2010/11/26 14:39:46Z]
 *  Moved masks for time slot programming from sem_pes_peripheralsensors.h.
 *  --- Added comments ---  fru1si [2010/11/26 14:40:21Z]
 *  Delta-review performed as walkthrough on 2010/11/26 with EPS3-Knnzel without findings.
 *  --- Added comments ---  fru1si [2010/11/26 14:40:21Z]
 *  State changed: develop -> reviewed by fru1si
 *  
 *  --- Added comments ---  fru1si [2010/11/26 14:40:29Z]
 *  State changed: reviewed -> release by fru1si
 *  Revision 5.2 2010/10/26 11:45:39CEST fru1si 
 *  Removed constants to set up DCU channels since DCU was moved to bm1001 cust sensor management.
 *  Revision 5.1 2010/08/05 10:04:28CEST fru1si 
 *  - Removed DCU from AB10lib sensor management.
 *  - Adapted UML model for cust specific sensor modules (dependencies to lib APIs, separate header for struct definitions).
 *  - Re-ran code generator with latest templates.
 *  - No functional change --> previous state is taken over.
 *  --- Added comments ---  fru1si [2010/08/05 08:11:15Z]
 *  State changed: develop -> release by fru1si
 *  Revision 4.4 2010/02/23 13:10:15CET str3kor 
 *  Ptedt00046507:M_PESOptionDcuVerMask_U16X changed to M_PESOptionDcuVerMask_U8X.
 *  --- Added comments ---  hkr2kor [2010/02/24 14:35:30Z]
 *  State changed: develop -> reviewed by hkr2kor
 *  
 *  --- Added comments ---  hkr2kor [2010/02/24 14:35:36Z]
 *  State changed: reviewed -> release by hkr2kor
 *  Revision 4.3 2010/02/15 12:05:11IST hkr2kor 
 *  Ptedt00046507 - DCU Version and Rose check changed. 
 *  Now, the DCU also sends the SBS version in data 11, but it has to be ignored.
 *  Revision 4.2 2009/11/24 19:09:40IST jnr1si 
 *  Added manufacturer option for TRW as part of the PAS6 support
 *  deliver:Ptedt00032829
 *  Revision 4.1 2009/09/28 16:42:39CEST fru1si 
 *  Fixed acceleration axis constants: alpha, beta, gamma.
 *  Added DCU version / RoSe check constants.
 *  --- Added comments ---  fru1si [2009/10/02 14:45:58Z]
 *  State changed: develop -> reviewed by fru1si
 *  
 *  --- Added comments ---  fru1si [2009/10/02 16:36:54Z]
 *  State changed: reviewed -> tested by fru1si
 *  
 *  --- Added comments ---  fru1si [2009/10/02 16:37:02Z]
 *  State changed: tested -> release by fru1si
 *  Revision 4.0 2009/09/25 16:41:23CEST fru1si 
 *  Initial revision
 *  Member added to project g:/MKS/Projects/ab10_lib/sem_sensormgt/sem_sensormgt.pj
 */
/*#end ACD#*/
/* ************************************************************************** */
/* EasyCASE ) */
/* EasyCASE (
   Includes */
/* PRQA S 1-9999 suppress_foreign_warnings_sem_std_sensortypedefs_h */
/* EasyCASE (
   Standard includes (utils + own header) */
#include "utl_options.p"
#include "utl_tb_typesbase.h"
/* EasyCASE ) */
/* EasyCASE (
   Direct Includes */
#ifdef Y_Option_sem_cst_custsensortypedefspar
#include "sem_cst_custsensortypedefspar.p" 
#endif
/* EasyCASE ) */
/* EasyCASE (
   Direct includes for package SEM_SensorMgt */
#include "sem_smr_sensormanager.h" 
#include "sem_std_sensortypedefs.h" 
/* EasyCASE ) */
/* PRQA L:suppress_foreign_warnings_sem_std_sensortypedefs_h */
/* EasyCASE ) */
/* EasyCASE (
   #Define Constants */
/*#ACD# M(Constants sem_std_sensortypedefs)  Definitions*/
/* EasyCASE ( 10
   Sensor options for A_PesOptions_U16X */
/* Sensor option specific settings for setup of A_PesOptions_U16X
 *
 * The sensor options have the following distribution:
 * xxxx gfee dcbb aaaa
 *
 * aaaa ... Manufacturer
 * bb   ... Time slot
 * c    ... Speed (128 / 189 kbps)
 * d    ... Parity / CRC
 * ee   ... Sync mode / daisy chain
 * f    ... Data rate (2kHz / 4kHz)
 * g    ... Interpolation (off / on)
 * x    ... Sensor type specific settings
 */

/* 1. Common options */

/* 1.1 Manufacturer */
#define C_PESOptionManuBosch_U16X         0x0001u
#define C_PESOptionManuVDO_U16X           0x0002u
#define C_PESOptionManuAutoliv_U16X       0x0004u
#define C_PESOptionManuTemic_U16X         0x0008u
#define C_PESOptionManuTrw_U16X           0x0009u
#define M_PESOptionManuMask_U16X          0x000Fu

/* 1.2 Time slot */
#define C_PESOptionTSlot1_U16X            0x0000u
#define C_PESOptionTSlot2_U16X            0x0010u
#define C_PESOptionTSlot3_U16X            0x0020u
#define C_PESOptionTSlot4_U16X            0x0030u
#define M_PESOptionTSlotMask_U16X         0x0030u
#define C_PESOptionTSlotIndent_U8X        4u

/* 1.3 Speed */
#define C_PESOption125kbps_U16X           0x0000u
#define C_PESOption189kbps_U16X           0x0040u
#define M_PESOptionSpeedMask_U16X         0x0040u

/* 1.4 Parity / CRC */
#define C_PESOptionParity_U16X            0x0000u
#define C_PESOptionCRC_U16X               0x0080u
#define M_PESOptionProtMask_U16X          0x0080u

/* 1.5 Sync settings */
#define C_PESOptionAsync_U16X             0x0000u
#define C_PESOptionSync_U16X              0x0100u
#define C_PESOptionDaisyChain_U16X        0x0200u
#define M_PESOptionSyncMask_U16X          0x0300u
#define C_PESOptionsSyncIndent_U8X        8u

/* 1.6 Data rate */
#define C_PESOptionDataRate4kHz_U16X      0x0000u
#define C_PESOptionDataRate2kHz_U16X      0x0400u

/* 1.7 Interpolation */
#define C_PESOptionInterpolOff_U16X       0x0000u
#define C_PESOptionInterpolOn_U16X        0x0800u

/* 2. Sensor type specific options */

/* 2.1 Acceleration sensors */

/* Acceleration axis relative to the housing */
/* Alpha = screwing axis  */
/* Beta  = connector axis */
/* Gamma = resulting axis */
#define C_PESOptionAccBetaAxis_U16X       0x0000u
#define C_PESOptionAccAlphaAxis_U16X      0x2000u
#define C_PESOptionAccGammaAxis_U16X      0x4000u
#define M_PESOptionAccAxisMask_U16X       0x6000u
#define C_PESOptionAccAxisIndent_U8X      13u

/* 2.1.1 PAS4/UFS2 specific options */

/* Variant */
#define C_PESOptionPas4CG968_U16X         0x0000u
#define C_PESOptionPas4CG969_U16X         0x1000u

/* 2.1.2 PAS5/UFS3 specific options */

/* Transmission current */
#define C_PESOptionPas520mA_U16X          0x0000u
#define C_PESOptionPas535mA_U16X          0x8000u
#define M_PESOptionPas5CurrentMask_U16X   0x8000u
#define C_PESOptionPas5CurrentIndent_U16X 15u

#define C_PESOptionPas5400Hz_U16X         0x0000u
#define C_PESOptionPas5200Hz_U16X         0x1000u
#define M_PESOptionPas5FilterMask_U16X    0x1000u
#define C_PESOptionPas5FilterIndent_U16X  12u

/* 2.2 Pressure sensors */

/* Absolute pressure transmission mode */
#define C_PESOptionPreNormal_U16X         0x0000u
#define C_PESOptionPreOnlyAbsPre_U16X     0x1000u
#define C_PESOptionPreOnlyInit_U16X       0x2000u
#define M_PESOptionPreAbsPreMask_U16X     0x3000u
#define C_PESOptionPreAbsPreIndent_U16X   12u
/* EasyCASE ) */
/* EasyCASE ( 14
   PSI setting for sync lines on Saphir and CF190 */
/* Sensor mode for each PSI line (set in SEM p-file: A_SlotsPerPESLine_U8X) */
#define M_PSISingleTimeSlot_U8X                0x00u
#define M_PSITwoTimeSlots_U8X                  0x08u
#define M_PSIThreeTimeSlots_U8X                0x10u
#define M_PSIFourTimeSlots_U8X                 0x18u
/* EasyCASE ) */
/*#end ACD#*/
/* EasyCASE ) */
/* EasyCASE (
   ENUM and struct Definitions */
/*#ACD# M(Enums sem_std_sensortypedefs)  Enums*/
/*#end ACD#*/
/*
 * Enum for the sensor safety-ID.
 * 
 * Values are based on the hardware specification and are equivalent to those
 * used in SPI messages.
 */
typedef enum
{
   E_UFS = 0,
   E_PAS = 1,
   E_Variable = 2,
   E_RollRate = 3,
   E_NotSafetyRelevant = 4,
   E_CentralX = 5,
   E_CentralY = 6,
   E_NotAllowed = 7
} te_SensorSafetyIDList;
/*! DEF ENUM te_SensorSafetyIDList */
   /*! 0 : E_UFS: Safety ID for upfront sensors            */
   /*! 1 : E_PAS: Safety ID for PAS                        */
   /*! 2 : E_Variable: Variable safety ID for special sensors   */
   /*! 3 : E_RollRate: Safety ID for rollover sensor            */
   /*! 4 : E_NotSafetyRelevant: Safety ID for not safety relevant sensor */
   /*! 5 : E_CentralX: Safety ID for the central x channel      */
   /*! 6 : E_CentralY: Safety ID for the central y channel      */
   /*! 7 : E_NotAllowed: This safety ID can not be used           */
/*! END DEF */
/* EasyCASE - */
/*#ACD# M(Enums sem_std_sensortypedefs leadout)  Enums*/
/* EasyCASE - */
/* user defined code to be added here ... */
/* EasyCASE - */
/* EasyCASE < */
typedef enum
{
   E_InvalidCsType,
   E_SMB460,
   E_SMB250,
   E_SMB200,
   E_MM2R,
   E_MM2S,
   E_SMB560,
   #ifdef Z_SEMUseCustSpecificSensorTypes
        Z_SEMCustSpecificSensorTypes()
   #endif
} te_CSTypeList;

/*This compiler switch Z_SEMUseCustSpecificSensorTypes is only 
defined if cust specific sensor types are used (see optionl file sem_cst_custsensortypedefspar.p)*/

/*! DEF ENUM te_CSTypeList */
   /*! E_InvalidCsType: Invalid central sensor type              */
   /*! E_SMB460: SMB460 dual channel central sensor       */
   /*! E_SMB250: SMB250 single channel central sensor     */
   /*! E_SMB200: SMB200 dual channel low-g yz-sensor      */
   /*! E_MM2R: MM2R roll rate sensor                    */
   /*! E_MM2S: MM2S roll rate sensor                    */
   /*! E_SMB560: SMB560 dual channel central sensor, successor of SMB460 */
/*! END DEF */
/* EasyCASE > */
/* EasyCASE - */
/*#end ACD#*/
/* EasyCASE ) */
/* EasyCASE (
   Public API Declarations */
/* EasyCASE ) */
#endif
/* EasyCASE ) */
