/* EasyCASE V6.5 01.01.2008 00:00:00 */
/* EasyCASE O
If=vertical
LevelNumbers=no
LineNumbers=no
Colors=16777215,0,12582912,12632256,0,0,0,16711680,8388736,0,33023,32768,0,0,0,0,0,32768,12632256,255,65280,255,255,16711935
ScreenFont=Courier New,,80,4,-11,0,400,0,0,0,0,0,0,3,2,1,49,96,96
PrinterFont=Courier New,,80,4,-66,0,400,0,0,0,0,0,0,3,2,1,49,600,600
LastLevelId= */
/* EasyCASE (
   sem_pa4_pas4.h */
#ifndef Y_sem_pa4_pas4H
#define Y_sem_pa4_pas4H
/* EasyCASE - */
/*#ACD# M(Bosch Copyright) */
/* ************************************************************************** */
/*                                                                            */
/*  Copyright (c) 2008 Robert Bosch GmbH, Germany                             */
/*                All rights reserved                                         */
/*                                                                            */
/* ************************************************************************** */
/*#end ACD#*/
/*#ACD# M(sem_pa4_pas4 Header Author) Author*/
/*  $Source: sem_pa4_pas4.h                                                    */
/*  $Revision: 1.1 $                                                          */
/*  $Author: Reddivari Devendra Kumar (RBEI/ESA-PP) (dvn2kor) $                                                        */
/*#end ACD#*/
/* ************************************************************************** *
 *  Description:
 * This module contains the specific implementation for the PAS4 peripheral
 * acceleration sensor (also used as UFS2 upfront sensor).
 * 
 * It mainly features:
 * - real-time data evaluation
 * - background monitoring
 * 
 * The PAS4 has a measurement range of 100g or 50g. A constant acceleration of
 * 1g leads to a received signal of 4 or 8LSB inside the ECU. The maximum
 * transmitted signal of 480LSB therefore corresponds to 120g or 60g
 * acceleration.
 * The UFS2 has a measurement range of 400g. 1g then results in 1LSB output
 * signal, 480LSB therefore corresponds to 480g.
 *
 *
 *  Reference to Documentation:  sem_pa4_pas4_SDS.HTML
 */
/* ********************** Framecode-Generator V2.0 ************************** */
/* EasyCASE (
   History */
/* ****************************** History *********************************** */
/*#ACD# M(sem_pa4_pas4 Header) History*/
/*  $Log: peace/sample/reports_SPS_sem_sensormgt_20130619_094630/_snapshot_/sem_pa4_pas4.h  $ */
/*  Revision 1.1 2013/07/31 00:03:31ICT Reddivari Devendra Kumar (RBEI/ESA-PP) (dvn2kor)  */
/*  Initial revision */
/*  Member added to project g:/MKS/Projects/TurboLIFT/Tools/Tools.pj */
/*  Revision 1.1 2013/06/19 06:18:57MESZ Vernon Hawes (RBEI/ESA1) (ver6cob)  */
/*  Initial revision */
/*  Member added to project g:/MKS/Projects/TurboLIFT/Projects/AB12/AB12.pj */
/*  Revision 5.1 2010/08/05 13:34:27IST Frueh Manuel (CC-PS/EPS3) (fru1si)  */
/*  - Removed DCU from AB10lib sensor management. */
/*  - Adapted UML model for cust specific sensor modules (dependencies to lib APIs, separate header for struct definitions). */
/*  - Re-ran code generator with latest templates. */
/*  - No functional change --> previous state is taken over. */
/*  --- Added comments ---  fru1si [2010/08/05 08:10:49Z] */
/*  State changed: develop -> release by fru1si */
/*  Revision 4.2 2010/01/25 12:57:48CET fru1si  */
/*  - Added check of SPI bits TST and NRO/EOP during steady state */
/*  - Fixed handling of additional fault info */
/*  Revision 4.1 2009/09/28 16:45:43CEST fru1si  */
/*  Fixed typo in struct definition: B_SensingAxix_U4X --> B_SensingAxis_U4X */
/*  --- Added comments ---  fru1si [2009/10/02 14:45:47Z] */
/*  State changed: develop -> reviewed by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2009/10/02 16:36:54Z] */
/*  State changed: reviewed -> tested by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2009/10/02 16:37:02Z] */
/*  State changed: tested -> release by fru1si */
/*  Revision 4.0 2009/09/25 13:26:18CEST fru1si  */
/*  Introduced new ASI interface */
/*  Revision 3.1 2008/12/18 17:00:28CET fru1si  */
/*  Re-ran code generator after Hydra update ("#pragma arm" issue) */
/*  --- Added comments ---  fru1si [2008/12/18 16:03:06Z] */
/*  Member revision set by fru1si */
/*  --- Added comments ---  fru1si [2008/12/18 16:04:09Z] */
/*  State changed: develop -> release by fru1si */
/*  Revision 3.0 2008/11/11 12:31:57CET fru1si  */
/*  Merged new functionality from side branch back to trunk: */
/*  - new Algo-SW sensor data interface */
/*  - option constants moved to sem_pes_peripheralsensors */
/*  --- Added comments ---  fru1si [2008/11/11 15:58:57Z] */
/*  State changed: develop -> release by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2008/11/11 16:00:27Z] */
/*  State inherited from merged revision. */
/*  --- Added comments ---  fru1si [2008/12/18 10:48:01Z] */
/*  Member revision set by fru1si */
/*  Revision 2.24.1.1 2008/05/29 09:22:34CEST wjd2si  */
/*  Adapted the module to the new interface between Algo and SW. The mean value calculation of the sensor  */
/*  values was shifted from Algo to SEM: */
/*  - Removed the PAS4 specific option settings. The option settings are now defined centralized in  */
/*    sem_pes_peripheralsensors.h */
/*  - Introduced two new functions (PA4_EvaluateFirstSampleFIQ, PA4_EvaluateSecondSampleFIQ) which  */
/*    replace the function PA4_EvaluateSensorDataFIQ. This was done to handle the mean value  */
/*    calculation of the sensor values. */
/*  - Added new parameter to PA4_Init to be able to hand over two RT evaluation functions. One for the  */
/*    first and one for the second sample. */
/*  Revision 2.24 2008/01/07 16:04:26CET ngk2si  */
/*  - Ptedt00009290: Adapted sensor data bitfields for NEC controllers (big => little endian) */
/*  - added compiler switches to TI specific pragmas (also for NEC) */
/*  - fixed several QAC findings (and added msg. suppression for existing deviations). */
/*  --- Added comments ---  ngk2si [2008/01/10 11:16:41Z] */
/*  Delta review with ESW3-Widmaier, no findings. */
/*  --- Added comments ---  ngk2si [2008/01/10 11:16:41Z] */
/*  State changed: develop -> reviewed by ngk2si */
/*   */
/*  --- Added comments ---  ngk2si [2008/01/18 15:25:18Z] */
/*  Test passed successfully */
/*  --- Added comments ---  ngk2si [2008/01/18 15:25:19Z] */
/*  State changed: reviewed -> release by ngk2si */
/*  Revision 2.23 2007/05/14 11:42:35CEST wjd2si  */
/*  Added INIT1 timeout constant */
/*  --- Added comments ---  wjd2si [2007/05/16 13:42:37Z] */
/*  Unit design test performed by ESW3-Widmaier without findings on 16.5.07 */
/*  --- Added comments ---  wjd2si [2007/05/16 13:42:37Z] */
/*  State changed: develop -> tested by wjd2si */
/*   */
/*  --- Added comments ---  wjd2si [2007/05/18 06:08:52Z] */
/*  Delta review to last revision by ESW3-Angstmann on 16.5.07 without findings */
/*  --- Added comments ---  wjd2si [2007/05/18 06:08:52Z] */
/*  State changed: tested -> release by wjd2si */
/*  Revision 2.22 2006/12/04 14:27:07CET ngk2si  */
/*  Fixes CQ ees100005472 */
/*  Updated programmable current Threshold according to new HW Spec 1.9 valid for System Asic CA and  */
/*  Companion Asic BA sample. */
/*  --- Added comments ---  ngk2si [2006/12/04 14:30:03Z] */
/*  Delta review with ESW3-Widmaier, no findings */
/*  --- Added comments ---  ngk2si [2006/12/04 14:30:03Z] */
/*  State changed: develop -> reviewed by ngk2si */
/*   */
/*  --- Added comments ---  ngk2si [2006/12/04 16:37:39Z] */
/*  All delta-tests passed (see SDT2.4.1.2) */
/*  --- Added comments ---  ngk2si [2006/12/04 16:37:39Z] */
/*  State changed: reviewed -> release by ngk2si */
/*  Revision 2.21 2006/11/10 16:59:12CET ngk2si  */
/*  Merged updates back to main branch */
/*  --- Added comments ---  ngk2si [2006/11/10 16:00:20Z] */
/*  Delta review to 2.36 (incl side branch) with H.Kuenzel, no findings. */
/*  --- Added comments ---  ngk2si [2006/11/10 16:00:20Z] */
/*  State changed: develop -> reviewed by ngk2si */
/*  Revision 2.20.1.3 2006/11/03 15:29:16CET ngk2si  */
/*  Added comment to explain sensor resolution. */
/*  Revision 2.20.1.2 2006/11/02 18:54:32CET ngk2si  */
/*  - Implemented SW-CR AB10_60I_06_012: Updated accoring to new TKU 1.3 */
/*   (support of new Pas4-Asic CG969). */
/*  - Init-Data decoding is now done via a bitfield (similar to PAS5/PPS1). */
/*  Revision 2.20.1.1 2006/10/18 18:10:31CEST ngk2si  */
/*  - Realised PAS5 code-review findings  */
/*  - Plausibility check now uses only one sample (newvalue) */
/*  Revision 2.20 2006/09/21 10:05:00CEST kio1si  */
/*  reran codegen */
/*  Revision 2.19 2006/09/05 14:59:56CEST wjd2si  */
/*  Small corrections due to QAC findings */
/*  Revision 2.18 2006/08/31 16:44:12CEST ngk2si  */
/*  PAS options in p-file are no 16bit wide (necessary for PAS5) */
/*  Revision 2.17 2006/08/28 16:14:14CEST wjd2si  */
/*  Changed parameter, which defines the amount of bytes necessary to store sensor specific data from  */
/*  U8 to U16 to be able to reserve more then 255 Bytes RAM for sensormanagement */
/*  Revision 2.16 2006/08/15 10:06:09CEST wjd2si  */
/*  Added direct include of sem_pes_peripheralsensors to be able to define te_PesBgStates as parameter for */
/*  the BG monitoring function */
/*  Revision 2.15 2006/07/21 10:41:26CEST ngk2si  */
/*  Added struct describing the content of the inital status data (Ford request) */
/*  This struct is now also used for the initial status data decoding. */
/*  Revision 2.14 2006/07/14 09:13:06CEST ngk2si  */
/*  Updaten PAS-Specific data format */
/*  Revision 2.13 2006/06/01 19:15:00CEST ngk2si  */
/*  Corrected parameter names, removed Pas-Ini-Data received twice test */
/*  Revision 2.12 2006/05/27 16:17:34CEST ngk2si  */
/*  New Pas initialisation structure */
/*  Revision 2.11 2006/05/16 13:50:47CEST ngk2si  */
/*  - new SPI API names */
/*  - regenerated with updated CodeGen */
/*  Revision 2.10 2006/04/21 11:29:39CEST ngk2si  */
/*  Updated API descriptions after Architecture update */
/*  Revision 2.9 2006/04/07 16:38:21CEST ngk2si  */
/*  Regenerated with new template */
/*  Revision 2.8 2006/04/03 12:57:21CEST ngk2si  */
/*  - Regenerated with new templates */
/*  - updated pas-specific parameters */
/*  Revision 2.7 2006/03/10 15:44:30CET ngk2si  */
/*  Regenerated with new template */
/*  Revision 2.6 2006/02/21 11:08:17CET ngk2si  */
/*  Changed API-names according to new coding rules (FIQ...) */
/*  Revision 2.5 2006/02/07 18:10:34CET ngk2si  */
/*  Restructured data interfaces */
/*  Misra updated */
/*  Revision 2.4 2005/12/12 18:03:55CET ngk2si  */
/*  Corrected comments */
/*  Revision 2.3 2005/11/29 16:07:17CET ngk2si  */
/*  Runtime optimisations (replaced error counters by flags) */
/*  Revision 2.2 2005/11/16 19:11:53CET ngk2si  */
/*  Modified RT function */
/*  Revision 2.1 2005/10/25 18:26:52CEST ngk2si  */
/*  RT-Runtime optimization: centralised handling of no ini-data passing */
/*  Revision 2.0 2005/10/13 15:58:30CEST ngk2si  */
/*  1st C-Sample revision */
/*  Revision 0.13 2005/06/01 14:26:48CEST ngk2si  */
/*  Corrected Review Findings */
/*  Revision 0.12 2005/04/21 10:56:06CEST ngk2si  */
/*  Changed Current-Threshold after request from HW-Group */
/*  Revision 0.11 2005/03/21 12:04:07CET ngk2si  */
/*  Made several parameters unsigned */
/*  Revision 0.10 2005/03/16 14:00:09CET ngk2si  */
/*  Corrected parameter names according to coding rules */
/*  Revision 0.9 2005/03/09 11:48:59CET ngk2si  */
/*  Corrections after first peripheralsensor tests */
/*  Revision 0.8 2005/03/02 13:50:51CET ngk2si  */
/*  RTRTed Version, used for 1st unit test */
/*  Revision 0.7 2005/02/24 19:40:08CET ngk2si  */
/*  Version used for RTRT-Test 1.1 */
/*  Revision 0.6 2005/02/22 19:37:54CET ngk2si  */
/*  Rework after changes to sensor data interface */
/*  Revision 0.5 2005/02/18 22:39:40CET fsa2si  */
/*  Architecture and Code Gen Update */
/*  Revision 0.4 2005/02/18 16:10:34CET ngk2si  */
/*  temporary version for code-gen-change */
/*  Revision 0.3 2005/02/10 17:25:12CET ngk2si  */
/*  Minor changes, re-checkin to get rid of merger warnings */
/*#end ACD#*/
/* ************************************************************************** */
/* EasyCASE ) */
/* EasyCASE (
   Includes */
/* PRQA S 1-9999 suppress_foreign_warnings_sem_pa4_pas4_h */
/* EasyCASE (
   Standard includes (utils + own header) */
#include "utl_options.p"
#include "utl_tb_typesbase.h"
/* EasyCASE ) */
/* EasyCASE (
   Direct Includes */
#ifdef Y_Option_sem_pes_peripheralsensors
#include "sem_pes_peripheralsensors.h" 
#endif
/* EasyCASE ) */
/* EasyCASE (
   Direct includes for package SEM_SensorMgt */
#include "sem_smr_sensormanager.h" 
#include "sem_std_sensortypedefs.h" 
/* EasyCASE ) */
/* PRQA L:suppress_foreign_warnings_sem_pa4_pas4_h */
/* EasyCASE ) */
/* EasyCASE (
   #Define Constants */
/*#ACD# M(Constants sem_pa4_pas4)  Definitions*/
/* EasyCASE - */
/* HW-specific constants */
#define C_PAS4INIT1Timeout_U16X             176u     /* Maximum PAS INIT1 phase startup time (117ms nominal + 50%) */    
#define C_PAS4StartupTimeout_U16X           525u     /* Maximum PAS startup time (350ms nominal + 50%) */
#define C_PAS4StatusMessageLength_U8X         8u     /* PAS4 sends 8 bytes of status data */
#define C_PAS4SerialNumberLength_U8X          4u     /* PAS4 has 4 bytes serial number */
#define C_PAS4PasIfSettings_U8X            0x07u     /* => 000X XXXY: X = current threshold, Y = 8/10bit */
        /* current setting: 0011 + 10 bit, see HW-Spec "Software relevant features for SISSI PAS-IF, v1.9 */

/* Thresholds for plausibility check */
#define C_PAS4SignalPlausiThreshold_U16X     60u     /* signal threshold for sensor plausibility fault (lsb) */
#define C_PAS4SignalPlausiTimeThreshold_U16X 100u    /* samples used for a sensor plausibility fault
                                                      * (100 samples * 10ms => 1s) */
/* EasyCASE - */
/* Constants for the PAS-Init-Data  - see PAS4 spec */

#define C_Pas4StatusMessagesComplete_U32X  0x0000FFFFu   /* PAS4 sends 16 status messages in total */
 
/* Data 1..3: Protocol Information Part 1 (always constant) */
#define C_PAS4StatusDataProtocol_U8X            0x30u    /* Protocollrevision 1, blocklength 16 */
#define C_PAS4StatusDataManufact_U8X            0x01u    /* Manufactorer RB-AE */

/* Data 4: Sensor Type */
#define C_PAS4StatusDataCG968_U8X               0x01u    /* Normal PAS4 (default) */
#define C_PAS4StatusDataCG969_U8X               0x02u    /* new PAS4 with CG969 (with parity) */
 
/* Data 5: Acceleration Range (compared with PAS-Type) */
#define C_PAS4StatusData50g_U8X                 0x01u 
#define C_PAS4StatusData100g_U8X                0x00u
#define C_PAS4StatusData200g_U8X                0x02u
#define C_PAS4StatusData200gPSB5_U8X            0x03u

/* Data 6: Acceleration Axis */
#define C_PAS4StatusDataXsensitiv_U8X           0x00u
#define C_PAS4StatusDataYsensitiv_U8X           0x01u
#define C_PAS4StatusDataZsensitiv_U8X           0x10u
/* EasyCASE - */
/*#end ACD#*/
/* EasyCASE ) */
/* EasyCASE (
   ENUM and struct Definitions */
/*#ACD# M(Enums sem_pa4_pas4)  Enums*/
/*#end ACD#*/
/*#ACD# M(Enums sem_pa4_pas4 leadout)  Enums*/
/* EasyCASE C */
/* Structure for part 1 of the PAS4 init data.
 * Due to different endianess in TI and NEC controllers, the bitfield 
 * definitions must be made uC specific (see AB10_60J20_017).
 */
typedef struct
   {
   #if defined ab10andromeda
   U32 B_Protocol_U8X     : 8;  /* Data 1..2: Protocol revision and length */
   U32 B_Manufacturer_U3X : 3;  /* Data 3   : Manufacturer */
   U32 B_Type_U5X         : 5;  /* Data 3..4: Sensor type */
   U32 B_Range_U4X        : 4;  /* Data 5   : Accceleration range */
   U32 B_SensingAxis_U4X  : 4;  /* Data 6   : Sensing axis (alpha, beta or gamma) */
   U32 B_CustomerCode_U8X : 8;  /* Data 7..8: Customer specific code */
   #elif defined ab10nec
   U32 B_Protocol_U8X     : 8;  /* Data 1..2: Protocol revision and length */
   U32 B_Type_U5X         : 5;  /* Data 3..4: Sensor type */
   U32 B_Manufacturer_U3X : 3;  /* Data 3   : Manufacturer */
   U32 B_SensingAxis_U4X  : 4;  /* Data 6   : Sensing axis (alpha, beta or gamma) */
   U32 B_Range_U4X        : 4;  /* Data 5   : Accceleration range */
   U32 B_CustomerCode_U8X : 8;  /* Data 7..8: Customer specific code */
   #else 
      #error unsupported uC type!
   #endif
   } ts_Pas4StatusPart1;
/* EasyCASE E */
/* EasyCASE C */
/* structure for the pas-init data */
typedef struct
   {
   ts_Pas4StatusPart1 S_DecodedMsg_XXX;
   U8 A_SerialNumber_U8X[C_PAS4SerialNumberLength_U8X];  /* Sensor serial number */
   } ts_Pas4StatusCode;
/* EasyCASE E */
/* EasyCASE C */
/* Contains the data needed for a single PAS4
 * Attention: this struct must be word-aligned (size % 4 = 0) */
typedef struct
   {
   U8  A_SensorStatusCodeINTW_U8X[C_PAS4StatusMessageLength_U8X]; /* PAS4 status message */
   S16 V_FirstSampleValueINTW_S16X;                               /* First received sample value */
   U16 V_Dummy_U16X;                                              /* To have the whole structure word aligned */
   } ts_Pas4SpecificData;
/* EasyCASE E */
#define C_PAS4SpecificRamSize_U16X sizeof(ts_Pas4SpecificData)
/* EasyCASE - */
/*#end ACD#*/
/* EasyCASE ) */
/* EasyCASE (
   Public API Declarations */
/* EasyCASE ) */
/* EasyCASE (
   Package protected API Declarations */
#ifdef Y_INC_FROM_PKG_SEM_SensorMgt
/* EasyCASE (
   PA4_Init */
/******************************************************************************
 * Description:
 *    Initializes the handling for this PAS4 sensor by
 *    - allocating RAM for this sensor
 *    - writing PAS4 specific settings into call by refercence parameters
 *    - setting BG monitoring function to call for this sensor
 *    - setting up specific values in peripheral sensors data tables
 *    - setting the sensor's initial state
 * 
 * Arguments:
 *    - v_sensor_u8r               : index of current sensor
 *    - p_pesIfSettings_u8r        : pointer to settigs for PES-IF
 *    - p_pas4FirstSampleFIQFp_xfr : pointer to FIQ evaluation function for the
 *      first sample of the PAS4
 *    - p_pas4SecondSampleFIQFp_xfr: pointer to FIQ evalution function for the
 *      second sample of the PAS4
 *      Note: Parameters two, three and four are call by reference!
 * 
 * Return: -
 * 
 * Scheduling:
 *    Called once in 10ms background after configuration data is available.
 * 
 * Usage guide: -
 * 
 * Remarks: -
 ******************************************************************************/
void PA4_Init(U8 v_sensor_u8r, U8 * p_pesIfSettings_u8r, tp_SensorSpecificFunction * p_pas4FirstSampleFIQFp_xfr, tp_SensorSpecificFunction * p_pas4SecondSampleFIQFp_xfr );
/* EasyCASE ) */
/* EasyCASE (
   PA4_EvaluateFirstSampleFIQ */
/******************************************************************************
 * Description:
 *    Function is called during the real-time interrupt for the first received
 *    sensor value of a PAS4 (for old value). It performs the real-time checks
 *    (data in range, etc.) and keeps the sensor value for the mean value
 *    calculation by PA4_EvaluateSecondSampleFIQ.
 * 
 * Arguments:
 *    - v_rawData_u16r: raw sensor data received from the sensor
 *    - v_sensor_u8r  : index of the sensor
 *    - v_channel_u8r : index of the channel (not used)
 * 
 * Return: -
 * 
 * Scheduling:
 *    Real-time
 * 
 * Usage guide:
 *    This function is called via function pointer by the sensor manager and
 *    evaluates one sensor sample. For that to work the pointer to this
 *    function and its parameters are stored inside the sensor manager during
 *    initialization (see SMR_AddSensorChannel).
 * 
 * Remarks:
 *    As this function is called during real-time for each PAS4, it obviously
 *    has to be highly runtime optimized.
 ******************************************************************************/
void PA4_EvaluateFirstSampleFIQ(U16 v_rawData_u16r, U8 v_sensor_u8r, U8 v_channel_u8r );
/* EasyCASE ) */
/* EasyCASE (
   PA4_EvaluateSecondSampleFIQ */
/******************************************************************************
 * Description:
 *    Function is called during the real-time interrupt for the second received
 *    sensor value of a PAS4 (for new value).
 *    It performs the real-time checks (data in range, etc.), does the mean
 *    value calculation and writes valid results into the sensor data PDI.
 * 
 * Arguments:
 *    - v_rawData_u16r: raw sensor data received from the sensor
 *    - v_sensor_u8r  : index of the sensor
 *    - v_channel_u8r : index of the channel (not used)
 * 
 * Return: -
 * 
 * Scheduling:
 *    Real-time
 * 
 * Usage guide:
 *    This function is called via function pointer by the sensor manager and
 *    evaluates one sensor sample. For that to work the pointer to this
 *    function and its parameters are stored inside the sensor manager during
 *    initialization (see SMR_AddSensorChannel).
 * 
 * Remarks:
 *    As this function is called during real-time for each PAS4, it obviously
 *    has to be highly runtime optimized.
 ******************************************************************************/
void PA4_EvaluateSecondSampleFIQ(U16 v_rawData_u16r, U8 v_sensor_u8r, U8 v_channel_u8r );
/* EasyCASE ) */
/* EasyCASE (
   PA4_BackGroundMonitoring10ms */
/******************************************************************************
 * Description:
 *    Performs the background monitoring specific for PAS4 sensors.
 * 
 * Arguments:
 *    - v_sensor_u8r : index of current sensor in the data table in the
 *      sem_pes_peripheralsensors module
 *    - e_BGstate_xxr: current BG monitoring state
 * Return: -
 * 
 * Scheduling:
 *    Called once for each PAS4 in 10ms background.
 * 
 * Usage guide:
 *    Called by sem_pes_peripheralsensors module via function pointer.
 * 
 * Remarks: -
 ******************************************************************************/
void PA4_BackGroundMonitoring10ms(U8 v_sensor_u8r, te_PesBgStates e_BGstate_xxr );
/* EasyCASE ) */
#endif
/* EasyCASE ) */
#endif
/* EasyCASE ) */
