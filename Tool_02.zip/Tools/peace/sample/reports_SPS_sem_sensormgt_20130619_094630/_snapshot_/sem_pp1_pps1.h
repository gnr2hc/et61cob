/* EasyCASE V6.5 01.01.2008 00:00:00 */
/* EasyCASE O
If=vertical
LevelNumbers=no
LineNumbers=no
Colors=16777215,0,12582912,12632256,0,0,0,16711680,8388736,0,33023,32768,0,0,0,0,0,32768,12632256,255,65280,255,255,16711935
ScreenFont=Courier New,,80,4,-11,0,400,0,0,0,0,0,0,3,2,1,49,96,96
PrinterFont=Courier New,,80,4,-66,0,400,0,0,0,0,0,0,3,2,1,49,600,600
LastLevelId= */
/* EasyCASE (
   sem_pp1_pps1.h */
#ifndef Y_sem_pp1_pps1H
#define Y_sem_pp1_pps1H
/* EasyCASE - */
/*#ACD# M(Bosch Copyright) */
/* ************************************************************************** */
/*                                                                            */
/*  Copyright (c) 2008 Robert Bosch GmbH, Germany                             */
/*                All rights reserved                                         */
/*                                                                            */
/* ************************************************************************** */
/*#end ACD#*/
/*#ACD# M(sem_pp1_pps1 Header Author) Author*/
/*  $Source: sem_pp1_pps1.h                                                    */
/*  $Revision: 1.1 $                                                          */
/*  $Author: Reddivari Devendra Kumar (RBEI/ESA-PP) (dvn2kor) $                                                        */
/*#end ACD#*/
/* ************************************************************************** *
 *  Description:
 * This module contains the specific implementation for the PPS1 peripheral
 * pressure sensor.
 * 
 * It mainly features:
 * - real-time data evaluation
 * - background monitoring
 * 
 * The PPS1 is a pressure sensor that transmits two types of pressure data:
 * - relative pressure changes: this is the "real" data that is used for the
 *   crash algorithm. This data is transmitted just like acceleration data for
 *   a PAS. Resolution is 8.4LSB/kPa.
 * - absolute pressure: this is used for sensor testing. This data is
 *   transmitted using a special protocol.
 *
 *
 *  Reference to Documentation:  sem_pp1_pps1_SDS.HTML
 */
/* ********************** Framecode-Generator V2.0 ************************** */
/* EasyCASE (
   History */
/* ****************************** History *********************************** */
/*#ACD# M(sem_pp1_pps1 Header) History*/
/*  $Log: peace/sample/reports_SPS_sem_sensormgt_20130619_094630/_snapshot_/sem_pp1_pps1.h  $ */
/*  Revision 1.1 2013/07/31 00:03:31ICT Reddivari Devendra Kumar (RBEI/ESA-PP) (dvn2kor)  */
/*  Initial revision */
/*  Member added to project g:/MKS/Projects/TurboLIFT/Tools/Tools.pj */
/*  Revision 1.1 2013/06/19 06:19:00MESZ Vernon Hawes (RBEI/ESA1) (ver6cob)  */
/*  Initial revision */
/*  Member added to project g:/MKS/Projects/TurboLIFT/Projects/AB12/AB12.pj */
/*  Revision 5.2 2011/03/23 21:02:56IST Frueh Manuel (CC-PS/EPS3) (fru1si)  */
/*  Added fault reaction. */
/*  Only comments added. No functional change. */
/*  Release state taken over. */
/*  --- Added comments ---  fru1si [2011/03/23 15:33:04Z] */
/*  State changed: develop -> release by fru1si */
/*  Revision 5.1 2010/08/05 10:04:28CEST fru1si  */
/*  - Removed DCU from AB10lib sensor management. */
/*  - Adapted UML model for cust specific sensor modules (dependencies to lib APIs, separate header for struct definitions). */
/*  - Re-ran code generator with latest templates. */
/*  - No functional change --> previous state is taken over. */
/*  --- Added comments ---  fru1si [2010/08/05 08:11:15Z] */
/*  State changed: develop -> release by fru1si */
/*  Revision 4.3 2010/01/25 12:57:48CET fru1si  */
/*  - Added check of SPI bits TST and NRO/EOP during steady state */
/*  - Fixed handling of additional fault info */
/*  Revision 4.2 2009/10/08 11:59:48CEST fru1si  */
/*  No functional changes. */
/*  Renamed some local variables for coding rules conformity. */
/*  Reduced cyclomatic complexity for coding rules conformity. */
/*  Corrected some constant names. */
/*  Revision 4.1 2009/09/28 16:48:34CEST fru1si  */
/*  Re-ran code generator and fixed some typos. */
/*  --- Added comments ---  fru1si [2009/10/02 14:45:47Z] */
/*  State changed: develop -> reviewed by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2009/10/02 16:36:53Z] */
/*  State changed: reviewed -> tested by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2009/10/02 16:37:01Z] */
/*  State changed: tested -> release by fru1si */
/*  Revision 4.0 2009/09/25 13:26:06CEST fru1si  */
/*  Introduced new ASI interface */
/*  Revision 3.2 2009/02/02 13:35:31CET fru1si  */
/*  Added Diagsym mask definition for absolute pressure fault. */
/*  Only comments changed so release status is taken over from previous revision. */
/*  --- Added comments ---  fru1si [2009/02/02 12:35:39Z] */
/*  State changed: develop -> release by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2009/02/02 12:35:42Z] */
/*  Member revision set by fru1si */
/*  Revision 3.1 2008/12/18 17:00:44CET fru1si  */
/*  Re-ran code generator after Hydra update ("#pragma arm" issue) */
/*  --- Added comments ---  fru1si [2008/12/18 16:03:14Z] */
/*  Member revision set by fru1si */
/*  --- Added comments ---  fru1si [2008/12/18 16:04:21Z] */
/*  State changed: develop -> release by fru1si */
/*  Revision 3.0 2008/11/11 12:24:45CET fru1si  */
/*  Merged new functionality from side branch back to trunk: */
/*  - new Algo-SW sensor data interface */
/*  - option constants moved to sem_pes_peripheralsensors */
/*  --- Added comments ---  fru1si [2008/11/11 15:59:28Z] */
/*  State changed: develop -> release by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2008/11/11 16:01:16Z] */
/*  State inherited from merged revision. */
/*  --- Added comments ---  fru1si [2008/12/18 10:50:31Z] */
/*  Member revision set by fru1si */
/*  Revision 1.25.1.1 2008/05/28 16:21:48CEST wjd2si  */
/*  Adapted the module to the new interface between Algo and SW. The mean value calculation of the sensor  */
/*  values was shifted from Algo to SEM: */
/*  - Introduced two new functions (PP1_EvaluateFirstSampleFIQ, PP1_EvaluateSecondSampleFIQ)  */
/*    which replace the function PP1_EvaluateSensorDataFIQ. This was done to handle the mean value  */
/*    calculation of the sensor values. */
/*  - Added new parameter to PP1_Init to be able to hand over two RT evaluation functions. One for the  */
/*    first and one for the second sample. */
/*  - Removed the PPS1 specific option settings. The option settings are now defined centralized in  */
/*    sem_pes_peripheralsensors.h */
/*  Revision 1.25 2008/01/07 16:04:28CET ngk2si  */
/*  - Ptedt00009290: Adapted sensor data bitfields for NEC controllers (big => little endian) */
/*  - added compiler switches to TI specific pragmas (also for NEC) */
/*  - fixed several QAC findings (and added msg. suppression for existing deviations). */
/*  --- Added comments ---  ngk2si [2008/01/10 11:11:58Z] */
/*  Delta review with ESW3-Widmaier, no findings. */
/*  --- Added comments ---  ngk2si [2008/01/10 11:11:58Z] */
/*  State changed: develop -> reviewed by ngk2si */
/*   */
/*  --- Added comments ---  ngk2si [2008/01/18 15:26:12Z] */
/*  Test done by ESW3-Kurihara */
/*  --- Added comments ---  ngk2si [2008/01/18 15:26:12Z] */
/*  State changed: reviewed -> release by ngk2si */
/*  Revision 1.24 2007/05/18 14:30:42CEST wjd2si  */
/*  Added comment */
/*  --- Added comments ---  wjd2si [2007/05/18 12:31:36Z] */
/*  Reviewed by ESW3-Angstmann on 18.5.07 without findings */
/*  --- Added comments ---  wjd2si [2007/05/18 12:31:36Z] */
/*  State changed: develop -> reviewed by wjd2si */
/*   */
/*  --- Added comments ---  wjd2si [2007/05/18 13:20:01Z] */
/*  Unit design test finished by ESW3-Widmaier without findings 18.5.07 */
/*  --- Added comments ---  wjd2si [2007/05/18 13:20:01Z] */
/*  State changed: reviewed -> release by wjd2si */
/*  Revision 1.23 2007/05/14 11:42:36CEST wjd2si  */
/*  Added INIT1 timeout constant */
/*  Revision 1.22 2007/03/23 15:18:19CET wjd2si  */
/*  Added pressure out of range message definition and corresponding fault bit */
/*  --- Added comments ---  wjd2si [2007/03/23 14:34:47Z] */
/*  Delta-Review without findings done by ESW3-Angstmann on 23.03.07 */
/*  --- Added comments ---  wjd2si [2007/03/23 14:34:47Z] */
/*  State changed: develop -> reviewed by wjd2si */
/*   */
/*  --- Added comments ---  wjd2si [2007/03/26 08:38:25Z] */
/*  Test finished on 26.03.2007 without findings by ESW3-Widmaier */
/*  --- Added comments ---  wjd2si [2007/03/26 08:38:26Z] */
/*  State changed: reviewed -> release by wjd2si */
/*  Revision 1.21 2007/03/01 16:24:59CET wjd2si  */
/*  Update after architecture change and create_code call (nothing seems to have changed) */
/*  --- Added comments ---  wjd2si [2007/03/16 09:07:44Z] */
/*  Reviewed by ESW3-Kendlbacher on 15.3.07 without findings. */
/*  --- Added comments ---  wjd2si [2007/03/16 09:07:44Z] */
/*  State changed: develop -> reviewed by wjd2si */
/*  Revision 1.20 2007/02/28 11:27:38CET wjd2si  */
/*  Introduced counter for missing absolute pressure messages in the sensor specific part */
/*  Revision 1.19 2007/02/27 14:34:00CET wjd2si  */
/*  - Changes to handle the new absolute pressure receive algorithm (new temp absolute pressure where */
/*    the received messages are stored temporary before they can be moved to the final absolute pressure */
/*    value, new enumeration item for receive state machine) */
/*  - Optimization of flags for absolute and relative pressure receive test so that the structure keeps the same */
/*    size as before the change of the absolute pressue receive algorithm */
/*  - New default value for absolute pressure after meetings with EPD4-Gunselmann */
/*  Revision 1.18 2007/02/08 14:45:40CET wjd2si  */
/*  Reran create_code - only spaces were included - grrr */
/*  Revision 1.17 2007/02/08 12:13:06CET wjd2si  */
/*  Changed current threshold to 15.5 mA according to requirements from EPD4 (see also document */
/*   Software relevant features for SISSI PAS-IF, v2.0) */
/*  Revision 1.16 2007/01/26 10:36:11CET wjd2si  */
/*  Reran create_code (One empty line was added - is that really necessary ??) */
/*  Revision 1.15 2007/01/18 10:36:52CET wjd2si  */
/*  - Changes for the new receiption algorithm of the absolute pressure value: */
/*    - Introduced enumeration te_PPS1AbsIDReception which determines which absolute pressure ID was */
/*      received last time */
/*    - Changed boolean value E_Abs1stNibbleExpectedINTW_XXX to te_PPS1AbsIDReceiption value  */
/*      E_PPS1LastReceivedAbsIDINTW_XXX */
/*  Revision 1.14 2006/12/13 16:24:39CET wjd2si  */
/*  - Changed minimum and maximum absolute pressure threshold again according to EPD4-Gunselmann */
/*  Revision 1.13 2006/12/12 11:11:31CET wjd2si  */
/*  Corrected comment for PPS1 options */
/*   */
/*  No code change */
/*  Revision 1.12 2006/12/11 17:31:25CET wjd2si  */
/*  - Removed no longer needed masks */
/*  - Renamed newly created enums to match coding guideline */
/*  Revision 1.11 2006/12/11 15:20:32CET wjd2si  */
/*  - Adapted absolute pressure thresholds according EPD4-Gunselmann */
/*  - Expanded structure ts_Pps1SpecificData */
/*  Revision 1.10 2006/12/05 17:29:23CET wjd2si  */
/*  - Corrected Ident Code and Status Data Offset to S16 */
/*  - Introduced constants for absolute pressure sampling and check */
/*  - Expanded struct ts_Pps1SpecificData to contain information about the absolute pressure */
/*  - Introduced API PP1_BackGroundMonitoring100ms for absolute pressure check and also for check, if  */
/*    relative data and absolute data are still received */
/*  Revision 1.9 2006/12/04 14:27:08CET ngk2si  */
/*  Fixes CQ ees100005472 */
/*  Updated programmable current Threshold according to new HW Spec 1.9 valid for System Asic CA and  */
/*  Companion Asic BA sample. */
/*  Revision 1.8 2006/10/18 18:13:34CEST ngk2si  */
/*  - Realised PAS5 code-review findings  */
/*  - Plausibility check now uses only one sample (newvalue) */
/*  - Ini-Data check now uses bitfield */
/*  Revision 1.7 2006/10/02 18:04:04CEST ngk2si  */
/*  Updated descriptions (no code-change). */
/*  Revision 1.6 2006/08/31 16:44:29CEST ngk2si  */
/*  PAS options in p-file are no 16bit wide (necessary for PAS5) */
/*  Revision 1.5 2006/08/28 16:14:13CEST wjd2si  */
/*  Changed parameter, which defines the amount of bytes necessary to store sensor specific data from  */
/*  U8 to U16 to be able to reserve more then 255 Bytes RAM for sensormanagement */
/*  Revision 1.4 2006/08/21 11:35:25CEST wjd2si  */
/*  Changed definition of pressure id messages from unsigned to signed */
/*  Revision 1.3 2006/08/15 10:06:08CEST wjd2si  */
/*  Added direct include of sem_pes_peripheralsensors to be able to define te_PesBgStates as parameter for */
/*  the BG monitoring function */
/*  Revision 1.2 2006/07/21 10:41:28CEST ngk2si  */
/*  Added struct describing the content of the inital status data (Ford request) */
/*  This struct is now also used for the initial status data decoding. */
/*  Revision 1.1 2006/07/14 09:13:11CEST ngk2si  */
/*  Updaten PAS-Specific data format */
/*  Revision 1.0 2006/06/30 17:32:20CEST ngk2si  */
/*  Updated for C-Sample architecture.  */
/*  Basic functions are working, however still some features are missing. */
/*  Revision 0.4 2006/02/21 11:08:14CET ngk2si  */
/*  Changed API-names according to new coding rules (FIQ...) */
/*  Revision 0.3 2005/11/17 17:23:41CET ngk2si  */
/*  Corrected threshold for plausibility check to 32 after input from HW. */
/*  Revision 0.2 2005/11/16 19:12:35CET ngk2si  */
/*  1st working version, missing is absolute pressure transmission and */
/*  status-data evaluation */
/*  Revision 1.35 2005/04/21 11:09:35CEST kcl2si  */
/*  fix for #STACKCALC_FCTPTR# tag */
/*  Revision 1.34 2005/03/31 07:49:29CEST fsa2si  */
/*  fix util includes */
/*  Revision 1.33 2005/02/22 15:22:28CET fsa2si  */
/*  macro double in protected and public section fix */
/*  Revision 1.32 2005/02/18 18:23:23CET fsa2si  */
/*  fixes */
/*  Revision 1.31 2005/02/18 12:38:14CET fsa2si  */
/*  macro fix */
/*  Revision 1.30 2005/02/16 11:50:25CET fsa2si  */
/*  telelogic driven changes */
/*  Revision 1.29 2004/10/29 12:06:56CEST fsa2si  */
/*  generate switches for APIs */
/*  Revision 1.28 2004/10/27 07:36:01CEST fsa2si  */
/*  pfile stereotype supported for direct includes */
/*  stereotype pfile is not generated */
/*  .p is extended instead of .h */
/*  Revision 1.27 2004/10/08 14:30:48CEST kcl2si  */
/*  added comment for stackcalc */
/*  Revision 1.26 2004/09/28 12:50:09CEST fsa2si  */
/*  rework for first complete build */
/*  Revision 1.25 2004/08/16 10:53:07CEST fsa2si  */
/*  recent updates, protected APIS const externals */
/*  Revision 1.24 2004/07/30 11:17:45CEST fsa2si  */
/*  leadout acd enum define section  added */
/*  Revision 1.23 2004/07/28 11:53:26CEST kcl2si  */
/*  corrected datatype for 2nd event */
/*  Revision 1.22 2004/07/28 11:45:12CEST kcl2si  */
/*  changed 2nd parameter for event from U32 to U32R */
/*  Revision 1.21 2004/06/29 10:34:45CEST fsa2si  */
/*  fixes */
/*  Revision 1.20 2004/06/22 16:50:19CEST fsa2si  */
/*  g */
/*  Revision 1.19 2004/06/22 10:53:42CEST fsa2si  */
/*  enum first then structs */
/*  Revision 1.18 2004/06/01 12:37:01CEST fsa2si  */
/*  macrogenerated added */
/*  Revision 1.17 2004/05/05 12:58:22CEST fsa2si  */
/*  aggregation enum and struct fixed */
/*  Revision 1.16 2004/04/29 09:45:08CEST fsa2si  */
/*  some fixes */
/*  Revision 1.15 2004/04/22 12:03:46CEST fsa2si  */
/*  structs also supported */
/*  Revision 1.14 2004/04/20 08:49:15CEST fsa2si  */
/*  enums added */
/*  Revision 1.1 2004/11/02 12:14:17CET fsa2si  */
/*  Initial revision */
/*  Member added to project g:/MKS/Projects/build_tms470.pj */
/*#end ACD#*/
/* ************************************************************************** */
/* EasyCASE ) */
/* EasyCASE (
   Includes */
/* PRQA S 1-9999 suppress_foreign_warnings_sem_pp1_pps1_h */
/* EasyCASE (
   Standard includes (utils + own header) */
#include "utl_options.p"
#include "utl_tb_typesbase.h"
/* EasyCASE ) */
/* EasyCASE (
   Direct Includes */
#ifdef Y_Option_sem_pes_peripheralsensors
#include "sem_pes_peripheralsensors.h" 
#endif
/* EasyCASE ) */
/* EasyCASE (
   Direct includes for package SEM_SensorMgt */
#include "sem_smr_sensormanager.h" 
#include "sem_std_sensortypedefs.h" 
/* EasyCASE ) */
/* PRQA L:suppress_foreign_warnings_sem_pp1_pps1_h */
/* EasyCASE ) */
/* EasyCASE (
   #Define Constants */
/*#ACD# M(Constants sem_pp1_pps1)  Definitions*/
/* EasyCASE - */
#define C_PPS1INIT1Timeout_U16X             176u     /* Maximum PAS INIT1 phase startup time (117ms nominal + 50%) */    
#define C_PPS1StartupTimeout_U16X           525u     /* Maximum PAS startup time (350ms nominal + 50%) */
#define C_PPS1StatusMessageLength_U8X         8u     /* PPS1 sends 8 bytes of status data */
#define C_PPS1SerialNumberLength_U8X          4u     /* PPS1 has 4 bytes serial number */
#define C_PPS1StatusMessagesComplete_U32X 0x0000FFFFu     /* PPS1 sends 16 status messages in total */
#define C_PPS1PasIfSettings_U8X            0x15u     /* => 000X XXXY: X = current threshold, Y = 8/10bit */
   /* current setting: 1010 + 10 bit option, see HW-Spec "Software relevant features for SISSI PAS-IF, v2.0 */  

/* init-status-data-constants - see PPS1 spec */
#define C_PPS1StatusDataProtocol_U8X        0x30u    /* Protocollrevision 1, blocklength 16 */
#define C_PPS1StatusDataManufact_U8X        0x01u    /* Manufacturer RB-AE */
#define C_PPS1StatusDataType_U8X            0x08u    /* Type pressure sensor (PPS1) */

/* Thresholds for plausibility check */
#define C_PPS1SignalPlausiThreshold_U16X     32u     /* signal threshold used for a sensor plausibility fault (lsb) */
#define C_PPS1SignalPlausiTimeThreshold_U16X 100u    /* samples used for a sensor plausibility fault
                                                      * (100 samples * 10ms => 1s) */

/* PSI error codes for absolute pressure transmission and pressure out of range */
#define C_PSIPPS1pressureID1_S16X            0x01E6 /* Absolute pressure identifier 1 */
#define C_PSIPPS1pressureID2_S16X            0x01E7 /* Absolute pressure identifier 2 */
#define C_PSIPPS1outOfRange_S16X             0x01EC /* Pressure out of range */

/* Mask for the receiption of absolute and relative pressure check */
/* IMPORTANT: If additional flags are defined for variable V_PressureReceiveFlagsINTW_U8X, then the switch case
 * logic in local function pp1_DataRcvCheckAndAbsMinMax HAS to be checked, if it is still valid!! */
#define C_PPS1AbsPressureReceived_U8X        0x01u
#define C_PPS1RelPressureReceived_U8X        0x02u
/* EasyCASE - */
/* Constants for absolute pressure handling */
#define C_PPS1AbsDefaultValue_U8X               0xFFu   /* Default value for absolute pressure */
#define C_PPS1AbsMinimumThresh_U8X              0x37u   /* Threshold for absolture pressure minimum check */
#define C_PPS1AbsMaximumThresh_U8X              0x73u   /* Threshold for absolture pressure maximum check */
#define C_PPS1AbsDeltaThresh_U8X                0x06u   /* Threshold for delta of minimum and maximum check */

#define M_PPS1MinimumAbsPressureFlt_U8X         0x01u
#define M_PPS1MaximumAbsPressureFlt_U8X         0x02u
#define M_PPS1DeltaAbsPressureFlt_U8X           0x04u
/* EasyCASE - */
/* Constant for PPS1 specific sensor defective fault handling
 * Sensor specific fault information for the sensor defective fault can be done in the lower 6 bit. */
#define M_PPS1NoRelativePressureRcvd_U8X        0x01u   /* No relative pressure received */
#define M_PPS1NoAbsIDRcvd_U8X                   0x02u   /* No absolute pressure ID received */
#define M_PPS1PresOutRangeError_U8X             0x04u   /* PPS1 sends "Pressure out of range message" */
/* EasyCASE - */
/*#end ACD#*/
/* EasyCASE ) */
/* EasyCASE (
   ENUM and struct Definitions */
/*#ACD# M(Enums sem_pp1_pps1)  Enums*/
/*#end ACD#*/
/*#ACD# M(Enums sem_pp1_pps1 leadout)  Enums*/
/* EasyCASE - */
/* EasyCASE < */
typedef enum
{
   E_NoPPS1Configured, 
   E_AbsMinMaxUpdated, 
   E_NoAbsMinMaxUpdate
} te_PPS1MinMaxUpdate;
/*! DEF ENUM te_PPS1MinMaxUpdate */
/*! E_NoPPS1Configured: No PPS1 configured */
/*! E_AbsMinMaxUpdated: Min and Max value updated */
/*! E_NoAbsMinMaxUpdate: Min and Max value not updated */
/*! END DEF */
/* EasyCASE > */
/* EasyCASE - */
/* EasyCASE < */
typedef enum
{
   E_NoAbsIDReceived,
   E_AbsID1Received,
   E_AbsFirstNibbleReceived,
   E_AbsID2Received
} te_PPS1AbsReception;
/*! DEF ENUM te_PPS1AbsIDReception */
/*! E_NoAbsIDReceived: No absolute pressure ID received */
/*! E_AbsID1Received: Absolute pressure ID1 received */
/*! E_AbsFirstNibbleReceived: First nibble of absolute pressure received */
/*! E_AbsID2Received: Absolute pressure ID2 received */
/*! END DEF */
/* EasyCASE > */
/* EasyCASE C */
/* Structure for part 1 of the PPS1 init data.
 * Due to different endianess in TI and NEC controllers, the bitfield 
 * definitions must be made uC specific (see AB10_60J20_017).
 */
typedef struct
   {
   #if defined ab10andromeda
   U32 B_Protocol_U8X     : 8;  /* Data 1..2: Protocol revision and length */
   U32 B_Manufacturer_U3X : 3;  /* Data 3   : Manufacturer */
   U32 B_Type_U5X         : 5;  /* Data 3..4: Sensor type (fixed to pressure sensor) */
   U32 B_AbsPresMode_U4X  : 4;  /* Data 5   : Transmission mode of absolute pressure */
   U32                    : 4;  /* Data 6   : not used */
   U32 B_CustomerCode_U8X : 8;  /* Data 7..8: Customer specific code */
   #elif defined ab10nec
   U32 B_Protocol_U8X     : 8;  /* Data 1..2: Protocol revision and length */
   U32 B_Type_U5X         : 5;  /* Data 3..4: Sensor type (fixed to pressure sensor) */
   U32 B_Manufacturer_U3X : 3;  /* Data 3   : Manufacturer */
   U32                    : 4;  /* Data 6   : not used */
   U32 B_AbsPresMode_U4X  : 4;  /* Data 5   : Transmission mode of absolute pressure */
   U32 B_CustomerCode_U8X : 8;  /* Data 7..8: Customer specific code */   
   #else 
      #error unsupported uC type!
   #endif
   } ts_Pps1StatusPart1;
/* EasyCASE E */
/* EasyCASE C */
/* Complete structure for the pas-init data */
typedef struct
   {
   ts_Pps1StatusPart1 S_Part1_XXX;
   U8 A_SerialNumber_U8X[C_PPS1SerialNumberLength_U8X];  /* Sensor serial number */
   } ts_Pps1StatusCode;
/* EasyCASE E */
/* EasyCASE C */
/* Contains the data needed for a single PPS1
 * Attention: this struct must be word-aligned (size % 4 = 0) */
 
 /* IMPORTANT: If additional flags are defined for variable V_PressureReceiveFlagsINTW_U8X, then the switch case
 * logic in local function pp1_DataRcvCheckAndAbsMinMax HAS to be checked, if it is still valid!! */
typedef struct
   {
   U8                      A_SensorStatusCodeINTW_U8X[C_PPS1StatusMessageLength_U8X];  /* PPS1 status message */
   U8                      V_AbsolutePressureINTW_U8X;                                 /* Received absolute pressure */
   U8                      V_TempAbsPressureINTW_U8X;                                  /* Temporary absolute pressure */
   te_PPS1AbsReception     E_PPS1LastReceivedAbsINTW_XXX;                              /* Last received abs press msg type */
   U8                      V_PressureReceiveFlagsINTW_U8X;                             /* Flags, if abs or rel pressure was received */
   U8                      V_MissingAbsCounter_U8X;                                    /* Counter for missing absolute pressure messages */
   U8                      V_PPS1Dummy_U8X;                                            /* To have the whole structure word aligned */
   S16                     V_FirstSampleValueINTW_S16X;                                /* First received sample value */
   } ts_Pps1SpecificData;
/* EasyCASE E */
#define C_PPS1SpecificRamSize_U16X sizeof(ts_Pps1SpecificData)
/* EasyCASE - */
/*! DEF MASKS PPS1AbsPressFlt */
/*! 00: Minimum pressure below threshold */
/*! 01: Maximum pressure above threshold */
/*! 02: Difference in pressure too high */
/*! END DEF */
/* EasyCASE - */
/*! FLTDESC MASKS PPS1AbsPressFlt FltPPS1AbsolutePressure: PPS1 absolute pressure fault */
/*! FLTREACTION FltPPS1AbsolutePressure: E_NoDisable */
/* EasyCASE - */
/*#end ACD#*/
/* EasyCASE ) */
/* EasyCASE (
   Public API Declarations */
/* EasyCASE ) */
/* EasyCASE (
   Package protected API Declarations */
#ifdef Y_INC_FROM_PKG_SEM_SensorMgt
/* EasyCASE (
   PP1_Init */
/******************************************************************************
 * Description:
 *    Initializes the handling for a PPS1 sensor by
 *    - allocating RAM for this sensor
 *    - writing PPS1 specific settings into call by reference parameters
 *    - setting BG monitoring function to call for this sensor
 *    - setting up specific values in peripheral sensors data tables
 *    - setting the sensor's initial state
 * 
 * Arguments:
 *    - v_sensor_u8r               : index of current sensor
 *    - p_pesIfSettings_u8r        : pointer to settings for PES-IF
 *    - p_pps1FirstSampleFIQFp_xfr : pointer to FIQ evaluation function for the
 *      first sample of the PPS1
 *    - p_pps1SecondSampleFIQFp_xfr: pointer to FIQ evalution function for the
 *      second sample of the PPS1
 *      Note: Parameters two, three and four are call by reference!
 * 
 * Return: -
 * 
 * Scheduling:
 *    Called once in 10ms background after configuration data is available.
 * 
 * Usage guide: -
 * 
 * Remarks: -
 ******************************************************************************/
void PP1_Init(U8 v_sensor_u8r, U8 * p_pesIfSettings_u8r, tp_SensorSpecificFunction * p_pps1FirstSampleFIQFp_xfr, tp_SensorSpecificFunction * p_pps1SecondSampleFIQFp_xfr );
/* EasyCASE ) */
/* EasyCASE (
   PP1_EvaluateFirstSampleFIQ */
/******************************************************************************
 * Description:
 *    Function is called during the real-time interrupt for the first received
 *    sensor value of a PPS1 (for old value).
 *    It performs the real-time checks (data in range, etc.) and keeps the
 *    sensor value for the mean value calculation by
 *    PP1_EvaluateSecondSampleFIQ.
 * 
 * Arguments:
 *    - v_rawData_u16r: raw sensor data received from the sensor
 *    - v_sensor_u8r  : index of the sensor
 *    - v_channel_u8r : index of the channel (not used)
 * 
 * Return: -
 * 
 * Scheduling:
 *    Real-time
 * 
 * Usage guide:
 *    This function is called via function pointer by the sensor manager and
 *    evaluates one sensor sample. For that to work the pointer to this
 *    function and its parameters are stored inside the sensor manager during
 *    initialization (see SMR_AddSensorChannel).
 * 
 * Remarks:
 *    As this function is called during real-time for each PPS1, it obviously
 *    has to be highly runtime optimized.
 *    Note: While the PPS transmits an absolute pressure value the data valid
 *    flag is set and the output values are set to 0 (requirement by algorithm
 *    group).
 ******************************************************************************/
void PP1_EvaluateFirstSampleFIQ(U16 v_rawData_u16r, U8 v_sensor_u8r, U8 v_channel_u8r );
/* EasyCASE ) */
/* EasyCASE (
   PP1_EvaluateSecondSampleFIQ */
/******************************************************************************
 * Description:
 *    Function is called during the real-time interrupt for the second received
 *    sensor value of a PPS1 (for new value).
 *    It performs the real-time checks (data in range, etc.), does the mean
 *    value calculation and writes valid results into the sensor data PDI.
 * 
 * Arguments:
 *    - v_rawData_u16r: raw sensor data received from the sensor
 *    - v_sensor_u8r  : index of the sensor
 *    - v_channel_u8r : index of the channel (not used)
 * 
 * Return: -
 * 
 * Scheduling:
 *    Real-time
 * 
 * Usage guide:
 *    This function is called via function pointer by the sensor manager and
 *    evaluates one sensor sample. For that to work the pointer to this
 *    function and its parameters are stored inside the sensor manager during
 *    initialization (see SMR_AddSensorChannel).
 * 
 * Remarks:
 *    As this function is called during real-time for each PPS1, it obviously
 *    has to be highly runtime optimized.
 *    Note: While the PPS transmits an absolute pressure value the data valid
 *    flag is set and the output values are set to 0 (requirement by algorithm
 *    group).
 ******************************************************************************/
void PP1_EvaluateSecondSampleFIQ(U16 v_rawData_u16r, U8 v_sensor_u8r, U8 v_channel_u8r );
/* EasyCASE ) */
/* EasyCASE (
   PP1_BackGroundMonitoring10ms */
/******************************************************************************
 * Description:
 *    Performs the background monitoring specific for PPS1 sensors.
 * 
 * Arguments:
 *    - v_sensor_u8r : index of current sensor in the data table in the
 *      sem_pes_peripheralsensors module
 *    - e_BGstate_xxr: current BG monitoring state
 * 
 * Return: -
 * 
 * Scheduling:
 *    Called once for each PPS1 in each 10ms background cycle.
 * 
 * Usage guide:
 *    Called by sem_pes_peripheralsensors module via function pointer.
 * 
 * Remarks: -
 ******************************************************************************/
void PP1_BackGroundMonitoring10ms(U8 v_sensor_u8r, te_PesBgStates e_BGstate_xxr );
/* EasyCASE ) */
/* EasyCASE (
   PP1_BackGroundMonitoring100ms */
/******************************************************************************
 * Description:
 *    The following tasks are handled by the 100ms BG task:
 *    - check if relative pressure is received. If not qualify a "SensorDefect"
 *      fault and set the sensor to dead state. This is only done, if the
 *      sensor is configured and in steady state.
 *    - check if ID messages (and therefore absolute pressure) are received. If
 *      this did not happen 2 seconds in a row, then qualify a "SensorDefect"
 *      fault and set the sensor to dead state. This is only done, if the
 *      sensor is configured and in steady state.
 *    - determination of minimum and maximum absolute pressure value (only
 *      configured PPS1 which are in steady state and have sent an absolute
 *      pressure value during the last 100ms are taken into account).
 *    - comparison of minimum and maximum absolute pressure against thresholds.
 *      If comparison fails, qualify absolute pressure check fault and disable
 *      all PPS1 sensors (sensor dead state).
 *    - comparison of difference between minimum and maximum absolute pressure
 *      against threshold. If comparison fails, qualify absolute pressure check
 *      fault and disable all PPS1 sensors (sensor dead state).
 * 
 * Arguments: -
 * 
 * Return: -
 * 
 * Scheduling:
 *    Called once in the 100ms background cycle only if PPS1 sensors are
 *    included as option in the architecture.
 * 
 * Usage guide: -
 * 
 * Remarks: -
 ******************************************************************************/
void PP1_BackGroundMonitoring100ms( void );
/* EasyCASE ) */
#endif
/* EasyCASE ) */
#endif
/* EasyCASE ) */
