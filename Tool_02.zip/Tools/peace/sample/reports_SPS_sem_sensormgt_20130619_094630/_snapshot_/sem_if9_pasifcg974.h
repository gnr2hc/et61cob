/* EasyCASE V6.5 01.01.2008 00:00:00 */
/* EasyCASE O
If=vertical
LevelNumbers=no
LineNumbers=no
Colors=16777215,0,12582912,12632256,0,0,0,16711680,8388736,0,33023,32768,0,0,0,0,0,32768,12632256,255,65280,255,255,16711935
ScreenFont=Courier New,,80,4,-11,0,400,0,0,0,0,0,0,3,2,1,49,96,96
PrinterFont=Courier New,,80,4,-66,0,400,0,0,0,0,0,0,3,2,1,49,600,600
LastLevelId= */
/* EasyCASE (
   sem_if9_pasifcg974.h */
#ifndef Y_sem_if9_pasifcg974H
#define Y_sem_if9_pasifcg974H
/* EasyCASE - */
/*#ACD# M(Bosch Copyright) */
/* ************************************************************************** */
/*                                                                            */
/*  Copyright (c) 2008 Robert Bosch GmbH, Germany                             */
/*                All rights reserved                                         */
/*                                                                            */
/* ************************************************************************** */
/*#end ACD#*/
/*#ACD# M(sem_if9_pasifcg974 Header Author) Author*/
/*
 *  $Source: peace/sample/reports_SPS_sem_sensormgt_20130619_094630/_snapshot_/sem_if9_pasifcg974.h $
 *  $Revision: 1.1 $
 *  $Author: Reddivari Devendra Kumar (RBEI/ESA-PP) (dvn2kor) $
 */
/*#end ACD#*/
/* ************************************************************************** *
 *  Description:
 * Specific module for the PES-IF ASIC CG974 (also used in AB9).
 * 
 * Main tasks:
 * - initial programming
 * - control & monitoring of PES power supply
 *
 *
 *  Reference to Documentation:  sem_if9_pasifcg974_SDS.HTML
 */
/* ********************** Framecode-Generator V2.0 ************************** */
/* EasyCASE (
   History */
/* ****************************** History *********************************** */
/*#ACD# M(sem_if9_pasifcg974 Header) History*/
/*  $Log: peace/sample/reports_SPS_sem_sensormgt_20130619_094630/_snapshot_/sem_if9_pasifcg974.h  $ */
/*  Revision 1.1 2013/07/31 00:03:30ICT Reddivari Devendra Kumar (RBEI/ESA-PP) (dvn2kor)  */
/*  Initial revision */
/*  Member added to project g:/MKS/Projects/TurboLIFT/Tools/Tools.pj */
/*  Revision 1.1 2013/06/19 06:18:52MESZ Vernon Hawes (RBEI/ESA1) (ver6cob)  */
/*  Initial revision */
/*  Member added to project g:/MKS/Projects/TurboLIFT/Projects/AB12/AB12.pj */
/*  Revision 5.4 2011/07/12 20:51:00IST Frueh Manuel (CC-PS/EPS3) (fru1si)  */
/*  Re-ran create_code. */
/*  --- Added comments ---  fru1si [2011/07/12 15:21:09Z] */
/*  State changed: develop -> release by fru1si */
/*  Revision 5.3 2011/07/12 17:00:06CEST fru1si  */
/*  Moved fault masks and Diagsym definition from c-file to h-file to eliminate Diagsym warning. */
/*  --- Added comments ---  fru1si [2011/07/12 15:00:19Z] */
/*  State changed: develop -> release by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2011/07/12 15:01:01Z] */
/*  Only moved constant and comment from c-file to h-file. No code change. Therefore previous state is taken over. */
/*  Revision 5.2 2011/03/23 16:48:23CET fru1si  */
/*  Added fault reaction. */
/*  Only comments added. No functional change. */
/*  Release state taken over. */
/*  Revision 5.1 2010/08/05 10:04:27CEST fru1si  */
/*  - Removed DCU from AB10lib sensor management. */
/*  - Adapted UML model for cust specific sensor modules (dependencies to lib APIs, separate header for struct definitions). */
/*  - Re-ran code generator with latest templates. */
/*  - No functional change --> previous state is taken over. */
/*  --- Added comments ---  fru1si [2010/08/05 08:07:29Z] */
/*  State changed: develop -> release by fru1si */
/*  Revision 4.2 2010/03/26 15:52:22CET jnr1si  */
/*  Added API to get the first element from te_AsicList which is of type CG974. */
/*  related to defect Ptedt00046388 */
/*  --- Added comments ---  jnr1si [2010/04/08 09:40:07Z] */
/*  review:Ptedt00049020 */
/*  --- Added comments ---  jnr1si [2010/04/08 09:40:08Z] */
/*  State changed: develop -> reviewed by jnr1si */
/*   */
/*  --- Added comments ---  jnr1si [2010/04/19 12:26:48Z] */
/*  State changed: reviewed -> release by jnr1si */
/*  Revision 4.1 2009/10/02 16:29:33CEST fru1si  */
/*  Corrected review findings (see Ptedt00038969). */
/*  --- Added comments ---  fru1si [2009/10/02 14:45:47Z] */
/*  State changed: develop -> reviewed by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2009/10/02 16:36:53Z] */
/*  State changed: reviewed -> tested by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2009/10/02 16:37:02Z] */
/*  State changed: tested -> release by fru1si */
/*  Revision 4.0 2009/09/25 13:26:15CEST fru1si  */
/*  Introduced new ASI interface */
/*  Revision 3.1 2008/12/18 17:00:28CET fru1si  */
/*  Re-ran code generator after Hydra update ("#pragma arm" issue) */
/*  --- Added comments ---  fru1si [2008/12/18 16:03:06Z] */
/*  Member revision set by fru1si */
/*  --- Added comments ---  fru1si [2008/12/18 16:04:08Z] */
/*  State changed: develop -> release by fru1si */
/*  Revision 3.0 2008/11/10 14:17:24CET hkr2kor  */
/*  Merged the implementation on the dev branch back to the main path. */
/*  - New Algo SW Interface */
/*  --- Added comments ---  fru1si [2008/12/18 10:35:39Z] */
/*  Member revision set by fru1si */
/*  --- Added comments ---  fru1si [2008/12/18 10:35:44Z] */
/*  State changed: develop -> release by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2008/12/18 10:35:52Z] */
/*  Take over state from merged revision. */
/*  Revision 0.6.1.4 2008/09/03 21:11:52IST wjd2si  */
/*  IF9_Init was split into several states and has to be called multiple times. Therefore a return value was */
/*  introduced to indicate, if the function has to be called again or not. */
/*  --- Added comments ---  wjd2si [2008/09/03 15:41:59Z] */
/*  State changed: develop -> ready_for_review by wjd2si */
/*   */
/*  --- Added comments ---  wjd2si [2008/09/05 06:30:04Z] */
/*  State changed: ready_for_review -> release by wjd2si */
/*  Revision 0.6.1.3 2008/07/24 12:03:05CEST wjd2si  */
/*  Updated one comments after review by Hemanth Nayak (RBEI/EAE1) */
/*  --- Added comments ---  wjd2si [2008/07/24 10:06:54Z] */
/*  State changed: develop -> reviewed by wjd2si */
/*  Revision 0.6.1.2 2008/07/10 12:14:32CEST wjd2si  */
/*  Corrected two comments. Now ready for review */
/*  Revision 0.6.1.1 2008/05/29 09:42:46CEST wjd2si  */
/*  Adapted the module to the new interface between Algo and SW: */
/*  - The name of the access macro for the first line of an ASIC has changed */
/*  Revision 0.6 2008/05/21 09:55:04CEST jsa2si  */
/*  Minor Changes: value for C_Cg974ProgRepetition_U8X changed. Variable renamed. */
/*  --- Added comments ---  jsa2si [2008/05/21 07:58:27Z] */
/*  Reviewed with J.Widmaier on 21.05.2008. No findings. */
/*  --- Added comments ---  jsa2si [2008/05/21 07:58:28Z] */
/*  State changed: develop -> reviewed by jsa2si */
/*  Revision 0.5 2008/02/27 14:22:33CET jsa2si  */
/*  Reviewed with J.Widmaier on 26.02.08. No findings. */
/*  --- Added comments ---  jsa2si [2008/02/27 13:22:50Z] */
/*  State changed: develop -> reviewed by jsa2si */
/*  Revision 0.3 2007/02/08 14:56:00CET wjd2si  */
/*  Reran create_code. Correction of some architecture comment */
/*  --- Added comments ---  wjd2si [2007/03/02 07:11:58Z] */
/*  State changed: develop -> release by wjd2si */
/*  Revision 0.2 2006/06/17 12:09:00CEST ngk2si  */
/*  first implementation, not properly integrated yet */
/*  Revision 0.1 2006/06/10 16:06:04CEST ngk2si  */
/*  Initial revision */
/*#end ACD#*/
/* ************************************************************************** */
/* EasyCASE ) */
/* EasyCASE (
   Includes */
/* PRQA S 1-9999 suppress_foreign_warnings_sem_if9_pasifcg974_h */
/* EasyCASE (
   Standard includes (utils + own header) */
#include "utl_options.p"
#include "utl_tb_typesbase.h"
/* EasyCASE ) */
/* EasyCASE (
   Direct includes for package SEM_SensorMgt */
#include "sem_smr_sensormanager.h" 
#include "sem_std_sensortypedefs.h" 
/* EasyCASE ) */
/* PRQA L:suppress_foreign_warnings_sem_if9_pasifcg974_h */
/* EasyCASE ) */
/* EasyCASE (
   #Define Constants */
/*#ACD# M(Constants sem_if9_pasifcg974)  Definitions*/
/* EasyCASE - */
/* A CG974 asic has 3 PAS-lines with at most 6 samples (2 samples per line) */
#define C_Cg974MaxPasLines_U8X          3u
#define C_Cg974MaxPasSamples_U8X        6u 

/* SPI-Command-Bits */
/* Read commands */
#define C_Cg974ReadPasCommand_U16X      0x8000u
#define C_Cg974PasOldValue_U8X          0x1000u
#define C_Cg974PasNewValue_U8X          0x0000u
#define C_Cg974ChannelReadLocation_U8X  13u
    /* line to read on CG974 is specified in bits 13..14 */

/* Programming Commands */
#define C_Cg974ProgInterface_U16X       0x5E00u
#define M_CG974ProtocolInfo_U8X         0x01u /* only lowest bit is relevant (8bit or 10bit protocol) */
#define C_Cg974VerifyPrograming_U16X    0x7E00u
#define C_Cg974EndOfProgramming_U16X    0x0C00u
#define M_Cg974VerifyProgMask_U8X       0x07u   /* lower three bits specify programming */
#define C_Cg974EopExpectedValue_U16X    0x0000u /* After EOP TFF, TST and EOP must be 0 */
#define M_Cg974EopCheckMask_U16X        0xF000u /* test the top 4 bit */
#define M_Cg974PasLinesMask_U8X         0x07u   /* Line cluster of a single CG974 inside of ts_PesLineData
                                                   Has to be shifted to corect position                 */

/* PAS-power supply commands */
#define C_Cg974SwitchSupply_U16X        0x3200u
#define C_Cg974SwitchAout_U16X          0x3005u /* AOUT on and first channel selected */


#define C_Cg974VoltageThreshold_U16X    155u  
    /* corresponds to 0.5V on ADC Pin, and 3V on PAS-Line (6:1 voltage divider) */

/* specifies how often programming commands to CG974 are executed */
#define C_Cg974ProgRepetition_U8X       3u
/* EasyCASE - */
/* Bit masks for all lines of all CG974 ASICs in the absolute position
 * (that depends on the number of sissi(companion pas-lines) */
#define M_Cg974AllLinePos_U16X     (U16)((U16)((1u << (C_Cg974MaxPasLines_U8X * (U8)E_MaxCg974Asics)) - 1u) << (U8) A_SemCfgDataFirstLineOnAsic_XEX[E_MaxSystemAsics])

/* Bit masks for all lines of a specified CG974 ASIC in the absolute position */
#define Z_Cg974DevLinePos(AsicNo)  (U16)(M_Cg974PasLinesMask_U8X << (U8) A_SemCfgDataFirstLineOnAsic_XEX[E_MaxSystemAsics + (AsicNo)])
/* EasyCASE - */
/* Fault properties */
                                                        /*! DEF MASKS CG974ProgFlt */
#define C_CG974ProgrammingFailed_U8X            0x01u   /*! 00: Register programming failed */
#define C_CG974InterpolationRequired_U8X        0x02u   /*! 01: Interpolation not supported */
                                                        /*! END DEF */
/* EasyCASE - */
/*! FLTDESC MASKS CG974ProgFlt E_FltCg974Initialisation: CG974 initialization failure */
/*! FLTREACTION E_FltCg974Initialisation: E_NoDisable */
/* EasyCASE - */
/*#end ACD#*/
/* EasyCASE ) */
/* EasyCASE (
   ENUM and struct Definitions */
/*#ACD# M(Enums sem_if9_pasifcg974)  Enums*/
/*#end ACD#*/
/*#ACD# M(Enums sem_if9_pasifcg974 leadout)  Enums*/
/* EasyCASE - */
/*#end ACD#*/
/* EasyCASE ) */
/* EasyCASE (
   Public API Declarations */
/* EasyCASE ) */
/* EasyCASE (
   Package protected API Declarations */
#ifdef Y_INC_FROM_PKG_SEM_SensorMgt
/* EasyCASE (
   IF9_Init */
/******************************************************************************
 * Description:
 *    Performs the initialization for all CG974 PES-IF. This includes e.g.
 *    programming of PES-IF registers.
 * 
 * Arguments: -
 * 
 * Return:
 *    E_InComplete: initialization has not finished yet
 *    E_Complete  : initialization has finished
 * 
 * Scheduling:
 *    Called by pes_peripheralsensor at the very first 10ms background.
 * 
 * Usage guide:
 *    Call the function from peripheral sensors module in the early init until
 *    the function returns E_Complete.
 * 
 * Remarks: -
 ******************************************************************************/
te_Complete IF9_Init( void );
/* EasyCASE ) */
/* EasyCASE (
   IF9_MakeLineMeasurement */
/******************************************************************************
 * Description:
 *    Measures the PES line status of all CG974 PES-IF lines. The result is
 *    stored by setting the corrosponding bits in
 *    S_PesLineData_XXR.F_MeasuredStatus_U16X.
 * 
 * Arguments: -
 * 
 * Return: -
 * 
 * Scheduling:
 *    Called from pes_peripheralsensors at the beginning of its 10ms cyclic
 *    monitoring.
 * 
 * Usage guide: -
 * 
 * Remarks:
 *    As a CG974 can measure only 1 line at a time (by switching an output that
 *    is read via ADC), this function only does a logical evaluation (line is
 *    powered or unpowered) and writes the result for the handling by the
 *    peripheralsensors module.
 *    The actual measurement is done inside the function
 *    IF9_CyclicLineSampling2ms.
 ******************************************************************************/
void IF9_MakeLineMeasurement( void );
/* EasyCASE ) */
/* EasyCASE (
   IF9_MakeLineSwitching */
/******************************************************************************
 * Description:
 *    Performs the line switching for all CG974 PES lines by sending the
 *    "supply SPI" command. Requested values are taken  from variable the
 *    S_PesLineData_XXR.F_RequestedStatus_U16X.
 * 
 * Arguments: -
 * 
 * Return: -
 * 
 * Scheduling:
 *    Called from pes_peripheralsensors at the very end of its 10ms cyclic
 *    monitoring.
 * 
 * Usage guide: -
 * 
 * Remarks: -
 ******************************************************************************/
void IF9_MakeLineSwitching( void );
/* EasyCASE ) */
/* EasyCASE (
   IF9_CyclicLineSampling2ms */
/******************************************************************************
 * Description:
 *    Performs the actual PES-IF line voltage sampling.
 * 
 * Arguments: -
 * 
 * Return: -
 * 
 * Scheduling:
 *    Called in 2ms BG loop.
 * 
 * Usage guide: -
 * 
 * Remarks:
 *    This API is necessary, as for the CG974 only one PES line can be measured
 *    a time (in contrast to SISSI/companion ASIC where all lines are evaluated
 *    simultaneously with internal comparators).
 *    Therefore in each 2ms cycle one line on each CG974 is sampled, then the
 *    measurement output of CG974 is switched to the next line. This ensures
 *    that all lines are measured within the main 10ms PES-IF cyclic monitoring.
 ******************************************************************************/
void IF9_CyclicLineSampling2ms( void );
/* EasyCASE ) */
/* EasyCASE (
   IF9_GetFirstCg974InAsicList */
/******************************************************************************
 * Description:
 *    Returns the first occurrence of a CG974 ASIC in the enum list te_AsicList
 * 
 * Arguments: -
 * 
 * Return:
 *    te_AsicList - first element of te_AsicList which is of type CG974
 * 
 * Scheduling:
 *    eventdriven
 * 
 * Usage guide: -
 * 
 * Remarks: -
 ******************************************************************************/
te_AsicList IF9_GetFirstCg974InAsicList( void );
/* EasyCASE ) */
#endif
/* EasyCASE ) */
#endif
/* EasyCASE ) */
