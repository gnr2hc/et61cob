//***************************************************************
//*   @BlockName ="IDEFix_CSV_Output"
//*   @NumberOfInputs="4"
//*   @NumberOfOutputs="1"
//*   @InputName[0]="MOSI"
//*   @InputName[1]="MISO"
//*   @InputName[2]="CSIndex"
//*   @InputName[3]="NumberBits"
//*   @OutputName[0]="Output"
//*   @NumberOfConfigStrings="1"
//*   @ConfigString[0]="Description: Output FileName|C:\Temp\Idefix_Format_Out.csv"
//*   @End
//***************************************************************
#include "LogicMaidFramework.h"
#include "stdio.h"
#include "string.h"

FILE* datei;

void BlockIni(void)   //This is called before simulation
{
	char string[200];
	strcpy(string, GetConfigString(0));
	datei = fopen(string, "w+");
	if(datei != NULL)
	{
		fprintf(datei,"Time[usec];CSIndex;Burst;NumberBits;MOSI_47_32;MOSI_31_0;MISO_47_32;MISO_31_0;Error;LA_CH2_SPI1;LA_CH1_SPI1;LA_CH0_SPI1\n");
	}
}

void BlockMain(void)  //This is called during simulation several times
{
	double Time;
	unsigned long long MOSI_In;
	unsigned long long MISO_In;
	unsigned int MOSI_31_0;
	unsigned int MOSI_47_32;
	unsigned int MISO_31_0;
	unsigned int MISO_47_32;
	unsigned int CS_In;
	unsigned int NumberBits;

	Time = GetSampleTime();
	Time *= 1000000; // to �s
	MOSI_In = GetInputUInt64(0);
	MISO_In = GetInputUInt64(1);
	CS_In = (int)GetInputUInt64(2);
	NumberBits = (int)GetInputUInt64(3);

	MOSI_31_0 = (int) MOSI_In;
	MOSI_47_32 = (int) (MOSI_In >> 32);

	MISO_31_0 = (int) MISO_In;
	MISO_47_32 = (int) (MISO_In >> 32);

	//Time;CSIndex;Burst;NumberBits;MOSI_47_32;MOSI_31_0;MISO_47_32;MISO_31_0;Error;LA_CH2_SPI1;LA_CH1_SPI1;LA_CH0_SPI1
	fprintf(datei,"%8.0f.0000;0x%02x;0;%d;0x%04x;0x%08x;0x%04x;0x%08x;0;0;0;0\n",
			Time, CS_In, NumberBits, MOSI_47_32, MOSI_31_0, MISO_47_32, MISO_31_0);

	//Output eigentlich unn�tig, aber l�uft sonst nicht ab... SPI Mate Bug?!
//	SetOutputUInt64(0, MOSI_In);
}

void BlockEnd(void)   //This is called after simulation
{
	fclose(datei);
}

