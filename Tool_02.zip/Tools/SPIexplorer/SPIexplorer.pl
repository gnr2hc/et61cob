#!perl -w
#****************************************************************************
#                                                                           *
# Copyright (c) 2011 Robert Bosch GmbH, Germany                             *
#               All rights reserved                                         *
#                                                                           *
#****************************************************************************
#
# $Source   : Tools/SPIexplorer/SPIexplorer.pl $
# $Author   : CC/EPS2 - Wilhelm Petkof 
#		      RBEI/ESA1 - Vernon Hawes$
# $Revision : 1.0 $  
#
# Description:
# SPI decoder for   - files decoded by LIFT
#					- files recorded with Idefix
#					- SPI records with SPImaid
#  
# with auto detection of corresponding file format
#
# Remarks: - Excel-Writer-XLSX module should be installed first
#
#****************************************************************************

use warnings;
use strict;
use Tk;
use Getopt::Std;
use File::Basename;
use Excel::Writer::XLSX; #use Spreadsheet::WriteExcel::Big;

my %comValueIXS;
my %StatusDisplay;
my %self;
my $main;
my $info_frame;
my $file = "dummy";
my $filetype = "dummy";
my $asicname;
my @AB12_SPI_modules;
my @SPI_modules;
my @available_sensors;
my $status;
my $maxRows = 150000; #due to excel limitation

# Create a new Excel file
my $FileName;
my ($workbook,$worksheet_decoded,$worksheet_statistics);

require "Mapping_SPI.pm";
my $Mapping = $Mapping_SPI::Mapping;

#############################################################################
# *********************** main *************************
package main;
	CreateGUI ();

MainLoop;

sub CreateGUI{

	my %opts;   # Command line options
	my $firstLine;
    if ( defined($ARGV[0]) ) {
        getopts('f:', \%opts) or die "Missing command line parameter!";
        $file = $opts{'f'};		
    }     
    open(FILEHANDLE, $file);
    print "$file\n";    
    if ($file =~ m/.csv/) {
	    $firstLine = <FILEHANDLE>; # read first line
    }

	$main = MainWindow->new("-background" => "DodgerBlue1");	
	$main->minsize(300,200);
	$main->title("SPI explorer");

	my $title_frame  = $main->Frame(-borderwidth => 0, 
									-relief => 'flat',-background => "DodgerBlue1",-height=>'2',
									)->pack(-anchor=>'center',-padx=>10,-side => "top");	
										 
	#$title_frame -> Photo('img', 
    #         -file => "spi.bmp");
    #my $c = $title_frame->Label(-image => 'img',
	#					-background => "DodgerBlue1")->pack(-side=>'left');

	$title_frame->Label(
		-text=>'SPI EXPLORER',
		-font=>'{Segoe UI light} 20',
		-background => "DodgerBlue1",
		-foreground    => "white")->pack(-side=>'right',-pady=>8);
			
	

	my $explore_frame  = $main->Frame(-borderwidth => 2, 
                                 -relief => 'raised',
                                 -background => "gray",
								 -height=>'2',
                                 )->pack(-anchor=>'center',
										-pady=> 10,-padx=>10,
										 -side => "top");	
	$explore_frame->Label(
							-text=>'EXPLORE',
							-font=>'{Segoe UI semibold} 10.5',
							-background => "gray",
							-foreground => "DodgerBlue1",)
							#-font=>'{Leelawadee} 11 bold')
							#-height=>'3')
							->pack(-side=>'top');	
												
	
	# and ($RowCnt < $numRow) ) condition check removed due to dynamic update of Rows     
    while (defined(my $line = <FILEHANDLE>)){
    	my $dataMISO;
    	chomp($line);
    	
    	#**************************  decode IDX_SPI CSV ***************************
		# Time[usec];CSIndex;Burst;NumberBits;MOSI_47_32;MOSI_31_0;MISO_47_32;MISO_31_0;Error;LA_CH2_SPI1;LA_CH1_SPI1;LA_CH0_SPI1
		# 2348033;0x00;0;16;0x0000;0x00000100;0x0000;0x0000ffff;0;0;0;0
 		# 2348165;0x02;0;16;0x0000;0x0000f0f0;0x0000;0x0000ffff;0;0;0;0
		# 2348168;0x02;0;16;0x0000;0x00000100;0x0000;0x0000f056;0;0;0;0
		# 2348172;0x04;0;16;0x0000;0x0000f0f0;0x0000;0x0000ffff;0;0;0;0
		
		if (($file =~ m/.csv/) and ($firstLine =~ m/NumberBits/)) {	
        	my ($dummy,$time,$CS,$burst,$bits,$MOSI1);

			if (($file =~ m/.csv/) and ($firstLine =~ m/Burst/)) {	
		    	($time,$CS,$burst,$bits,$MOSI1) = split(/;/,$line);
		    	#$self{info}->SetLabel('Hi');
			}
            else {
            	($time,$CS,$bits,$MOSI1) = split(/;/,$line);
			}
	
			#$bits = hex($bits);
            if ($bits ==16 ){$filetype = "AB10";}
            elsif($bits ==32 ){$filetype = "AB12";}	
           					
			$CS = hex($CS); # convert to dec            
			$asicname = $Mapping->{$filetype}{'IXS_MAPPING'}{"CS$CS"};		

		}
    	#**************************  decode SPIMaid CSV ***************************
		# Time;ASIC;MOSI;MISO;DecMOSI;DecMISO
		# 0.00022384;12;0x0000000;0x0000614; ; 
		# 0.00045616;12;0x0000000;0x0000600; ; 
		# 0.00068784;12;0x0000000;0x0000614; ;
		
		elsif (($file =~ m/.csv/) and ($firstLine =~ m/ASIC/)) {
        	my ($time,$CS, $MOSI, $MISO, $MOSIbits, $MISObits);
			($time, $CS, $MOSI, $MISO) = split(/;/,$line);
			
			$MOSIbits = sprintf( "%032b", hex($MOSI));
			
            if ($MOSIbits ==16 ){$filetype = "AB10";}
            elsif($MOSIbits ==32 ){$filetype = "AB12";}
           					
			$CS = hex($CS); # convert to dec            
			$asicname = $Mapping->{$filetype}{'IXS_MAPPING'}{"CS$CS"};
            
    	}
    	#**************************  decoded by LIFT  ***************************
        #             $1        $2    $3        $4  $5            $6 $7  
        else{
        	$line =~ /(\d+.\d+)\s+(\w+):(\w+):MISO=(0b(\d*)).+:MOSI=(0b(\d*))/;
			$asicname = $2;$dataMISO = $5;
			
			my $cnt = length($dataMISO);
			
			if($cnt==16){$filetype = "AB10";}
			elsif($cnt==32){$filetype = "AB12";}
			
        }
        
        if (defined $asicname and grep $_ eq $asicname, @available_sensors ) {
			#do nothing
		}
		else{
			if(defined $asicname and $asicname ne ''){
				push(@available_sensors, $asicname);
			}
		}           
   } #end while  
   
   foreach my $asicname (@available_sensors){
   		#if($asicname =~ m/SM/){	
				my $sensor_frame  = $explore_frame->Frame(-borderwidth => 1, -relief => 'flat', -background => "gray", -height=>'2', )->pack(-anchor=>'nw',-side => "top");
	
				$sensor_frame->Checkbutton(
					-variable => \$self{$asicname},           
					-text => "$asicname",
					-font=>'{Segoe UI Light} 10',
					-background => "gray",
					-foreground => "DodgerBlue1",
					#-height=>'2')
					)-> pack( -anchor=>'nw',
							#-expand =>1,
							#-padx=>10,
							-side=>'left'
							);
				$self{$asicname} = 1; #set by default
				
				$sensor_frame->Checkbutton(
					-variable => \$self{"$asicname"."_DisplayOnlyChangedSensorData"},           
					-text => "DisplayOnlyChanges",
					-font=>'{Segoe UI Light} 10',
					-background => "gray",
					-foreground => "DodgerBlue1",
					#-height=>'2')
					)-> pack( -anchor=>'ne',
							#-expand =>1,
							#-padx=>10,
							-side=>'right'
							);
				if($asicname =~ m/SM/i){
					$self{"$asicname"."_DisplayOnlyChangedSensorData"} = 1;	 #set by default for sensor ASICs	
				}
				else{
					$self{"$asicname"."_DisplayOnlyChangedSensorData"} = 0;	 #set by default to 0 for others	
				}
				
			#}
			#else{
			#	$explore_frame->Checkbutton(-variable => \$self{$asicname},-text => "$asicname",-font=>'{Segoe UI Light} 10',-background => "orange",-foreground => "DodgerBlue1",)
			#					-> pack( -anchor=>'nw',-expand =>1,-side=>'top');
			#	$self{$asicname} = 1; #set by default				
			#}	
   }
   
   my $SPI_modules = $Mapping->{$filetype}{'modules'};
   @SPI_modules = @$SPI_modules if defined $SPI_modules;
   my $numofmodules = scalar @SPI_modules;
   
   if(scalar @SPI_modules) {		
		my $Mainmodule_frame  = $main->Frame(-borderwidth => 1,-relief => 'raised',-background => "gray",-height=>'1',)
										->pack(-anchor=>'center',-pady=>10,-side => "top");
		$Mainmodule_frame->Label(-text=>'MODULES',-font=>'{Segoe UI semibold} 10.5',-background => "gray",-foreground => "DodgerBlue1",)
								->pack(-side=>'top');								
										
		my $module_frame1  = $Mainmodule_frame->Frame(-borderwidth => 1,-relief => 'flat',-background => "gray",-height=>'1',)
										->pack(-anchor=>'nw',-padx=>10,-side => "left");
		my $module_frame2  = $Mainmodule_frame->Frame(-borderwidth => 1,-relief => 'flat',-background => "gray",-height=>'1',)
										->pack(-anchor=>'ne',-padx=>10,-side => "right");
																				
										
		my $count=0;
		foreach my $module (@SPI_modules){		
			if ($count < ($numofmodules/2)){
				#set all modules
				if($module eq 'ALL'){
				$module_frame1->Checkbutton(-variable => \$self{$module},-text => "ALL",-font=>'{Segoe UI Light} 10',-background => "gray",-foreground => "DodgerBlue1",-command=>\&Setallmodules)
												-> pack( -anchor=>'nw',-expand =>1,-side=>'top');
				}
				else {
				$module_frame1->Checkbutton(-variable => \$self{$module},-text => "$module",-font=>'{Segoe UI Light} 10',-background => "gray",-foreground => "DodgerBlue1",)
												-> pack( -anchor=>'nw',-expand =>1,-side=>'top');
				}
			}
			else{
				$module_frame2->Checkbutton(-variable => \$self{$module},-text => "$module",-font=>'{Segoe UI Light} 10',-background => "gray",-foreground => "DodgerBlue1",)
												-> pack( -anchor=>'nw',-side=>'top');			
			}
			$count++;																	
		}
    }
	$info_frame  = $main->Frame(-borderwidth => 0, 
									-relief => 'flat',-background => "DodgerBlue1",-height=>'2',
									)->pack(-anchor=>'center',-padx=>10,-side => "top");
									
	$info_frame->Checkbutton(
            -variable => \$self{Statistics},           
            -text => "Display Bus Statistics",
            -font=>'{Segoe UI semibold} 10.5',
			-background => "DodgerBlue1",
            -foreground => "orange",
            )
           -> pack( -anchor=>'nw',
					-padx =>20,
					-expand =>1
            );
	$self{Statistics} = 0; #reset by default
        
    my $end_frame = $main->Frame("-background" => "DodgerBlue1")->pack(-pady=>'10', -padx=>'2');
	$end_frame->Button(
                        -text=>"START",
						-font=>'{Segoe UI semibold} 10.5 ',
                        -width=>'10',
                        -height=>'1',
                        -background => "gray",
                        -foreground  => "DodgerBlue1",
                        -command=>\&decodeSPI

        )->pack(-padx=>2, -side=>'left');
        
	$end_frame->Button(
        -text=>'EXIT',
        -width=>'10',
        -height=>'1',
        -font=>'{Segoe UI semibold} 10.5 ',
         -background => "gray",
         -foreground => "DodgerBlue1",
        -command=>[$main=>'destroy']
        )->pack(-padx=>2, -side=>'right'); 	    

	$main -> Label(
			-textvariable => \$status, #reference to display the status
			-font=>'{Segoe UI} 10',
			-background => "DodgerBlue1",
            -foreground  => "white",
			)-> pack( "-pady" => 12 );
		
	$status = "$filetype spi trace";	
		
	$main->Label(
            -textvariable => \$file,
            -background => "DodgerBlue1",
            -foreground => "orange",
            -font=>'{Segoe UI } 8.5 ')->pack(-pady =>10, -padx =>10,-side=>'top');
	}
	
sub Setallmodules{
		
		foreach my $module(@SPI_modules){
			if($self{ALL} == 1){
				$self{$module} = 1;
			}
			elsif($self{ALL} == 0){
				$self{$module} = 0;
			}
		}
}
sub decodeSPI{
	
	my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time());
	my $date = sprintf("%04d%02d%02d", $year+1900, $mon+1, $mday );
	my $time = sprintf("%02d%02d%02d", $hour, $min, $sec);
	my $tcTime = "$date"."_$time";
	
	#------------ excel output---------------#   
    my($inputfilename, $dir, $ext) = fileparse($file);
    $inputfilename =~ m/^(.*?)\.(.*)$/;
    $inputfilename = $1;
    $FileName = "decoded_$inputfilename"."_$tcTime.xlsx";   
    $workbook = Excel::Writer::XLSX->new($FileName);

	# Add a worksheet
	$worksheet_decoded = $workbook->add_worksheet('decoded');
	$worksheet_statistics = $workbook->add_worksheet('statistics');


    $worksheet_decoded->set_column('A:F', 10); 
    $worksheet_decoded->set_column('G:H', 20); 
    $worksheet_decoded->set_column('I:I', 25); 
	$worksheet_decoded->set_column('L:L', 20); 
	$worksheet_decoded->set_column('M:M', 25); 
	
	$worksheet_statistics->set_column('A:A', 20); 
	#------------ excel output---------------#

	#pause;
	my $self = shift;
	my $writtenflag = 0; 
	my $sensor_count = 0;

	$status = "In progress... Please wait!!";
	$main->update();
	
	my $numCol  = 13;
	my $numRow  = 2;
	
	my $col_absTime = 0;
	my $col_relTime = 1;
	my $col_cycTime = 2;
	my $col_comLine = 3;
	my $col_comCnt  = 4;
	my $col_ASIC    = 5;
	my $col_Command = 6;
	my $col_MOSI_Data = 7;
	my $col_MOSI_Value  = 8;
	my $col_MISO_Stat  = 9;
	my $col_MISO_SID  = 10;
	my $col_MISO_Data = 11;
	my $col_MISO_Value  = 12;
	my $col_module   = 13;
    
    #*********************************************************************
	# Excel handling
	#*********************************************************************	
	# Define the format and add it to the worksheet
	my $format_head = $workbook->add_format(
	#center_across => 1,
	bold => 0,
	size => 11,
	border => 1,
	color => 'black',
	bg_color => 'grey',
	border_color => 'black',
	align => 'vcenter',
	font => 'Segoe UI Light',
	#num_format => 1,
	);
    
    $worksheet_decoded->write(0,$col_absTime, "absTime (ms)", $format_head);
    $worksheet_decoded->write(0,$col_relTime, "relTime", $format_head);
    $worksheet_decoded->write(0,$col_comLine, "comLine", $format_head);
    $worksheet_decoded->write(0,$col_comCnt, "comCnt", $format_head);
    $worksheet_decoded->write(0,$col_cycTime, "cycTime", $format_head);
    $worksheet_decoded->write(0,$col_ASIC, "ASIC", $format_head);
    $worksheet_decoded->write(0,$col_module, "module", $format_head);
    $worksheet_decoded->write(0,$col_MOSI_Data, "MOSI_Data", $format_head);
    $worksheet_decoded->write(0,$col_MISO_Stat, "Status", $format_head);
    $worksheet_decoded->write(0,$col_MISO_SID, "SID", $format_head);
    $worksheet_decoded->write(0,$col_MISO_Data, "MISO_Data", $format_head);
    $worksheet_decoded->write(0,$col_MOSI_Value, "MOSI_Value", $format_head);
    $worksheet_decoded->write(0,$col_MISO_Value, "MISO_Value", $format_head);
    $worksheet_decoded->write(0,$col_Command, "Command", $format_head);
    
    $worksheet_decoded->autofilter('A1:N1'); 
    $worksheet_decoded->freeze_panes('I2'); 
    
    $worksheet_statistics->autofilter('A1:L1'); 
    $worksheet_statistics->freeze_panes('C2'); 
    
    #define colors
	my %attr_color_excel;
    $attr_color_excel{light_Yellow} = $workbook->set_custom_color(40,255,255,128);
    $attr_color_excel{light_Green} = $workbook->set_custom_color(41,165,208,91);
    $attr_color_excel{light_Green2} = $workbook->set_custom_color(42,64,219,160);
    $attr_color_excel{light_Blue} = $workbook->set_custom_color(43,117,207,239);
    $attr_color_excel{light_Blue1} = $workbook->set_custom_color(44, 17,152,207);
    $attr_color_excel{light_Turk} = $workbook->set_custom_color(45, 55,183,162);
    $attr_color_excel{light_Oker} = $workbook->set_custom_color(46,239,179,115);
    $attr_color_excel{light_Pink} = $workbook->set_custom_color(47,243,126,206);
    $attr_color_excel{light_Red} = $workbook->set_custom_color(48,243,0,0);
    $attr_color_excel{light_Grey} = $workbook->set_custom_color(49,128,128,128);
    $attr_color_excel{Green} = $workbook->set_custom_color(50,141,182,0);
    $attr_color_excel{Red} = $workbook->set_custom_color(51,227,38,54);   
    $attr_color_excel{White} = $workbook->set_custom_color(52,255,255,255);   
    $attr_color_excel{Blue} = $workbook->set_custom_color(53,21,96,189);
        

# -------------------------------------------------------------------------------------

# Remark: all the CS used in the file have to be assingned to an ASIC!!

    my %comColor = (	
					
        	'PPS2' => {
			            'Block_ID_1' => 'Green',
			            'Block_ID_2' => 'Green',
			            'Block_ID_3' => 'Green',
			            'Block_ID_4' => 'Green',
			            'Block_ID_5' => 'Green',
			            'Block_ID_6' => 'Green',
			            'Block_ID_7' => 'Green',
			            'Block_ID_8' => 'Green',
			            'Block_ID_9' => 'Green',
			            'Block_ID_10' => 'Green',
			            'Block_ID_11' => 'Green',
			            'Block_ID_12' => 'Green',
			            'Block_ID_13' => 'Green',
			            'Block_ID_14' => 'Green',
			            'Block_ID_15' => 'Green',
			            'Block_ID_16' => 'Green',
			            'Status_Data' => 'light_Yellow',
			            'Manchester_Error' => 'light_Red',
			            'Parity_Error' => 'light_Red',
			            'Sensor_Defect' => 'light_Red',
			            'Buffer_Empty' => 'light_Red',
			            'Sensor_Busy' => 'light_Blue',
			            'Sensor_Ready' => 'light_Pink',
			            'Sensor_Ready_unlocked' => 'light_Blue', 
        			},

        	'PAS5R' => {
			            'Block_ID_1' => 'Green',
			            'Block_ID_2' => 'Green',
			            'Block_ID_3' => 'Green',
			            'Block_ID_4' => 'Green',
			            'Block_ID_5' => 'Green',
			            'Block_ID_6' => 'Green',
			            'Block_ID_7' => 'Green',
			            'Block_ID_8' => 'Green',
			            'Block_ID_9' => 'Green',
			            'Block_ID_10' => 'Green',
			            'Block_ID_11' => 'Green',
			            'Block_ID_12' => 'Green',
			            'Block_ID_13' => 'Green',
			            'Block_ID_14' => 'Green',
			            'Block_ID_15' => 'Green',
			            'Block_ID_16' => 'Green',
			            'Status_Data' => 'light_Yellow',
			            'Manchester_Error' => 'light_Red',
			            'Parity_Error' => 'light_Red',
			            'Sensor_Defect' => 'light_Red',
			            'Buffer_Empty' => 'light_Red',
			            'Sensor_Busy' => 'light_Blue',
			            'Sensor_Ready' => 'light_Pink',
			            'Sensor_Ready_unlocked' => 'light_Blue',    
			            'Sensor_Ready_unlocked_1' => 'light_Blue',   
			            'Bidirec_Comm_Error' => 'light_Blue',  
			          	'Bidirec_Comm_OK' => 'light_Blue',
        			},

        	'SMA560' => {
						'PRO_SEL' => 'light_Pink',					
						'SEL_G_RANGE' => 'light_Pink', 			
						'RD_ACCEL_RANGE' => 'light_Turk',			
						'RD_G_RANGE' => 'light_Turk',			
						'RD_OFFSET_CANCEL_I_CHA' => 'light_Green',	
						'RD_OFFSET_CANCEL_II_CHA' => 'light_Green',	
						'RD_OFFSET_CANCEL_I_Channel_A' => 'light_Green',	
						'RD_OFFSET_CANCEL_II_Channel_A' => 'light_Green',	
						'RD_OFFSET_CANCEL_I_CHB' => 'light_Green', 	
						'RD_OFFSET_CANCEL_II_CHB' => 'light_Green',	
						'RD_OFFSET_CANCEL_I_Channel_B' => 'light_Green',	
						'RD_OFFSET_CANCEL_II_Channel_B' => 'light_Green',	
						'RD_DEVICE_ID' => 'Green',  			
						'RD_REVISION_ID'  => 'Green',			
						'RD_MONITOR_I' => 'light_Blue', 		
						'RD_MONITOR_II' => 'light_Blue1', 		
						'RD_MONITOR_I_DATA' => 'light_Blue', 		
						'RD_MONITOR_II_DATA' => 'light_Blue1', 		
						'RD_SENSOR_DATA_I' => 'White',
						'RD_DATA_CHA' => 'White',					
						'RD_SENSOR_DATA_II' => 'light_Grey',		
						'RD_DATA_CHB' => 'light_Grey',		
						'PROG_SID' => 'light_Oker',  				
						'RD_SID' => 'Green',					
						'DE_OFFSET_CANCEL' => 'light_Yellow',  		
						'RD_OFFSET_CANCEL' => 'light_Green',		
						'RD_OFFSET_CANCELLATION' => 'light_Green',		
						'RD_CLK_CNT' => 'light_Green2',				
#						'DE_LINEAR_INTERPOL',		
						'END_OF_PROG' => 'light_Pink',				
						'DE_FOR_TEST' => 'light_Yellow',				
						'PROG_FOR_TEST_0' => 'light_Oker',			
						'PROG_FOR_TEST_1' => 'light_Oker',			
						'PROG_FOR_TEST_2' => 'light_Oker',			
						'PROG_FOR_TEST_3' => 'light_Oker',			
#						'PROG_FOR_TEST_4' => 'light_Oker',			
						'PROG_FOR_TEST_5' => 'light_Oker',			
						'PROG_FOR_TEST_6' => 'light_Oker',			
#						'PROG_FOR_TEST_7' => 'light_Oker',			
#						'PROG_ENH_SAFETY',			
#						'WR_EXT_MODE',				
#						'WR_EXT_TESTMODE1',		
#						'WR_EXT_TESTMODE2',	
        			},

        	'SMA560P' => {
						'PRO_SEL' => 'light_Pink',					
						'SEL_G_RANGE' => 'light_Pink', 			
						'RD_ACCEL_RANGE' => 'light_Turk',			
						'RD_G_RANGE' => 'light_Turk',			
						'RD_OFFSET_CANCEL_I_CHA' => 'light_Green',	
						'RD_OFFSET_CANCEL_II_CHA' => 'light_Green',	
						'RD_OFFSET_CANCEL_I_Channel_A' => 'light_Green',	
						'RD_OFFSET_CANCEL_II_Channel_A' => 'light_Green',	
						'RD_OFFSET_CANCEL_I_CHB' => 'light_Green', 	
						'RD_OFFSET_CANCEL_II_CHB' => 'light_Green',	
						'RD_OFFSET_CANCEL_I_Channel_B' => 'light_Green',	
						'RD_OFFSET_CANCEL_II_Channel_B' => 'light_Green',	
						'RD_DEVICE_ID' => 'Green',  			
						'RD_REVISION_ID'  => 'Green',			
						'RD_MONITOR_I' => 'light_Blue', 		
						'RD_MONITOR_II' => 'light_Blue1', 		
						'RD_MONITOR_I_DATA' => 'light_Blue', 		
						'RD_MONITOR_II_DATA' => 'light_Blue1', 		
						'RD_SENSOR_DATA_I' => 'White',		
						'RD_DATA_CHA' => 'White',					
						'RD_SENSOR_DATA_II' => 'light_Grey',		
						'RD_DATA_CHB' => 'light_Grey',		
						'PROG_SID' => 'light_Oker',  				
						'RD_SID' => 'Green',					
						'DE_OFFSET_CANCEL' => 'light_Yellow',  		
						'RD_OFFSET_CANCEL' => 'light_Green',		
						'RD_OFFSET_CANCELLATION' => 'light_Green',		
						'RD_CLK_CNT' => 'light_Green2',				
#						'DE_LINEAR_INTERPOL',		
						'END_OF_PROG' => 'light_Pink',				
						'DE_FOR_TEST' => 'light_Yellow',				
						'PROG_FOR_TEST_0' => 'light_Oker',			
						'PROG_FOR_TEST_1' => 'light_Oker',			
						'PROG_FOR_TEST_2' => 'light_Oker',			
						'PROG_FOR_TEST_3' => 'light_Oker',			
						'PROG_FOR_TEST_4' => 'light_Oker',			
						'PROG_FOR_TEST_5' => 'light_Oker',			
						'PROG_FOR_TEST_6' => 'light_Oker',			
						'PROG_FOR_TEST_7' => 'light_Oker',			
#						'PROG_ENH_SAFETY',			
#						'WR_EXT_MODE',				
#						'WR_EXT_TESTMODE1',		
#						'WR_EXT_TESTMODE2',	
        			},

        	'SMG100' => {
						'RD_DEVICE_ID' => 'Green',		
						'RD_REVISION_ID' => 'Green',		
						'RD_PART_ID_I' => 'Green',		
						'RD_PART_ID_II' => 'Green',		
						'RD_PART_ID_III' => 'Green',		
						'RD_PART_ID_IV'  => 'Green',
						'RD_PART_ID_V'  => 'Green',
						'RD_PART_ID_VI'  => 'Green',
#						'RD_SID' => 'Green',				
						'RD_SENSOR_DATA' => 'White',		
						'RD_OFFSET_CANCEL' => 'light_Green',	
						'RD_MONITOR_I' => 'light_Blue',		
						'RD_MONITOR_II' => 'light_Blue1',		
#						'RD_MONITOR_III',		
						'DE_OFFSET_CANCEL' => 'light_Yellow',		
						'END_OF_PROG' => 'light_Pink',				
						'DE_FOR_TEST' => 'light_Yellow',		
#						'RD_BITE_CAL_VAL_I',	
#						'RD_BITE_CAL_VAL_II',	
#						'RD_OFFSET_VAL_I',		
#						'RD_OFFSET_VAL_II',	
						'RD_SENSOR_CONFIG' => 'light_Turk',	
						'WR_SOFT_RESET' => 'light_Pink',		
#						'WR_PARITY',			
        			},

        	'SMB200' => {
						'RD_DEVICE_ID' => 'Green',		
						'RD_REVISION_ID' => 'Green',		
						'RD_MONITOR_I' => 'light_Blue',		
						'RD_SENSOR_DATA_I' => 'White',	
						'RD_SENSOR_DATA_II' => 'light_Grey',	
						'DE_OFFSET_CANCEL' => 'light_Yellow',	
						'RD_OFFSET_CANCEL' => 'light_Green',	
						'END_OF_PROG' => 'light_Pink',			
						'DE_FOR_TEST' => 'light_Yellow',			
        			},

			'SMB470' => {                      
						'PRO_SEL' => 'light_Pink',					
						'RD_DEVICE_ID' => 'Green',		
						'RD_REVISION_ID' => 'Green',		
						'RD_MONITOR_I' => 'light_Blue',		
						'RD_MONITOR_II' => 'light_Blue1',		
						'RD_MONITOR_III' => 'light_Blue',		
						'RD_SENSOR_DATA_I' => 'White',	
						'RD_SENSOR_DATA_II' => 'light_Grey',	
						'PROG_SID' => 'light_Oker',			
						'RD_SID' => 'light_Oker',				
						'DE_OFFSET_CANCEL' => 'light_Oker',	
						'RD_OFFSET_CANCEL' => 'light_Oker',	
						'DE_LINEAR_INTERPOL' => 'light_Oker',	
						'END_OF_PROG' => 'light_Pink', 		
						'DE_FOR_TEST' => 'light_Green',			
						'DE_SOFTRESET' => 'light_Pink',		
						'RD_PART_ID_I' => 'Green',		
						'RD_PART_ID_II' => 'Green',		
						'RD_PART_ID_III' => 'Green',		
						'RD_PART_ID_IV' => 'Green',		
						'RD_PART_ID_V' => 'Green',		
						'RD_PART_ID_VI' => 'Green',		
#						'WR_EXT_MODE', 		
#						'WR_EXT_TESTMODE1',	
#						'WR_EXT_TESTMODE2',	
						'PROG_FILT_SETTINGS' => 'light_Pink',	
						'RD_FILT_SETTINGS' => 'light_Pink',	
						'RD_ECLK_CNT' => 'light_Turk',			
						'RD_NOISE_OFFSET' => 'light_Turk',		
						'RD_TEMP' => 'light_Yellow',				
						'RD_SELF_TEST_REF1'  => 'Green',	
						'RD_SELF_TEST_REF2'	 => 'Green',
        			},

        	'CG147' => {
	           			'READ_REV_ID' => 'light_Green',
			            'ENABLE_PROG' => 'light_Oker',
			            'PROG_PSI1_LINE' => 'light_Turk',
			            'PROG_PSI2_LINE' => 'light_Turk',
			            'PROG_PSI3_LINE' => 'light_Turk',
			            'PROG_PSI4_LINE' => 'light_Turk',
			            'PROG_PSYNC_MODE' => 'light_Turk',
			            'PSI_SYNC_MASK' => 'light_Turk',
			            'PROG_PSI_SID' => 'light_Turk',
			            'PSI_SUPPLY' => 'light_Turk',
			            'PROG_AIN1_2' => 'light_Yellow',
			            'PROG_AIN3_4' => 'light_Yellow',
			            'PROG_AIN5_6' => 'light_Yellow',
			            'START_ADC' => 'light_Yellow',
			            'READ_ADC' => 'light_Yellow',
			            'FLM_TEST_SINK' => 'light_Blue1',
			            'FLM_TEST_SRC' => 'light_Blue',
			            'WD2_TRIGGER' => 'Green',
			            'WD3_TRIGGER' => 'light_Pink',
			            'READ_WD_STATUS'  => 'light_Pink',
			            'READ_WD_FC' => 'light_Pink',
			            'END_ENABLE' => 'light_Green',
			            'PROG_UP_THRES' => 'light_Green',
			            'PROG_LOW_THRES' => 'light_Green',
			            'PROG_SDIS_CH' => 'light_Green',
			            'PROG_UFS_THRES' => 'light_Green',
			            'PROG_PAS_THRES' => 'light_Green',
			            'PROG_PRES_THRES' => 'light_Green',
			            'PROG_ROLL_THRES' => 'light_Green',
			            'PROG_Y_THRES' => 'light_Green',
			            'PROG_X_THRES' => 'light_Green',
			            'PROG_DISXY9_12' => 'light_Green',
			            'PROG_SDIS9_12' => 'light_Green',
			            'PROG_DISXY5_8' => 'light_Green',
			            'PROG_SDIS5_8' => 'light_Green',
			            'PROG_DISXY1_4' => 'light_Green',
			            'PROG_SDIS1_4' => 'light_Green',
			            'FLM_LOCK' => 'light_Green',
			            'AOUT_CTRL' => 'light_Grey',
			            'EOP' => 'light_Pink',
        			},
    			);

    # output data
    my ($out_absTime, $out_relTime, $out_cycTime, $out_comLine, $out_comCnt, $out_sensor, $out_Command,$out_module);
    my ($out_MOSI_Data, $out_MISO_Stat, $out_MISO_SID, $out_MISO_Data, $out_MISO_Value, $out_MOSI_Value);

    my ($dataMISO, $dataMOSI);

	my $OutputToGrid = 0;
    my $RowCnt = 1;
    my $last_comLine = 0;
    my $last_absTime = 0;

    my (%sensorOldValue, %statOldValue, %commandCounter, %commandCycTime);

###############################################################################################################

my @decodableASICs;
my @decodableModules;

foreach my $ASIC(@available_sensors){
	if(defined $ASIC and $ASIC ne '' and defined $self{$ASIC} and $self{$ASIC} == 1){
		push (@decodableASICs, $ASIC);
	}
}

foreach my $module(@SPI_modules){
	if(defined $self{$module} and $self{$module} == 1){
		push (@decodableModules, $module);
	}
}


if(!scalar @decodableASICs){
  	$status = "Select ASIC";
  	$main->update();
  	$OutputToGrid = 0;
}
else {
	
    my ($firstLine, $line);
  
    open(FILEHANDLE, $file);
    print "$file\n";

    if ($file =~ m/.csv/) {
	    $firstLine = <FILEHANDLE>; # read first line
	    #print $firstLine;	
    } 
    
    my $frame_length = $Mapping->{$filetype}{'frame_length'};
    my $instruction_length = $Mapping->{$filetype}{'instruction_length'};
    my $data_length = $Mapping->{$filetype}{'data_length'};
    my $alldata_length = $frame_length - $instruction_length;
    
    print ">>>>>>>>FRAME FORMAT<<<<<<<<\n";
    print "frame length is $frame_length\n";
    print "instruction length is $instruction_length\n";
    print "data length is $data_length\n";
    
    # and ($RowCnt < $numRow) ) condition check removed due to dynamic update of Rows    
    while (defined($line = <FILEHANDLE>) and $RowCnt < $maxRows){

    	chomp($line);
    	#**************************  decode IDX_SPI CSV ***************************
		# Time[usec];CSIndex;Burst;NumberBits;MOSI_47_32;MOSI_31_0;MISO_47_32;MISO_31_0;Error;LA_CH2_SPI1;LA_CH1_SPI1;LA_CH0_SPI1
		# 2348033;0x00;0;16;0x0000;0x00000100;0x0000;0x0000ffff;0;0;0;0
 		# 2348165;0x02;0;16;0x0000;0x0000f0f0;0x0000;0x0000ffff;0;0;0;0
		# 2348168;0x02;0;16;0x0000;0x00000100;0x0000;0x0000f056;0;0;0;0
		# 2348172;0x04;0;16;0x0000;0x0000f0f0;0x0000;0x0000ffff;0;0;0;0
		
		if (($file =~ m/.csv/) and ($firstLine =~ m/NumberBits/)) {	
        	my ($dummy,$time,$CS,$burst,$bits,$MOSI1,$MOSI2,$MISO1,$MISO2,$error,$signalname,$Address,$Instruction,$sensorname,$Page,$MOSIbits,$MISObits,$CH2,$CH1,$CH0);

			if (($file =~ m/.csv/) and ($firstLine =~ m/Burst/)) {	
		    	($time,$CS,$burst,$bits,$MOSI1,$MOSI2,$MISO1,$MISO2,$error,$CH2,$CH1,$CH0) = split(/;/,$line);
			}
            else {
            	($time,$CS,$bits,$MOSI1,$MOSI2,$MISO1,$MISO2,$error,$CH2,$CH1,$CH0) = split(/;/,$line);
			}
			
            	if($filetype eq "AB10"){
            		$dummy = sprintf( "%016b" , hex($MOSI1)).sprintf( "%032b" , hex($MOSI2)); # convert to 48 bits
            	}
            	elsif($filetype eq "AB12"){
            		$dummy = sprintf( "%032b" , hex($MOSI1)).sprintf( "%016b" , hex($MOSI2)); # convert to 48 bits
            	}          
           		$dummy =~ /(\d{$bits})$/;   # extract used bits only
            	$MOSIbits = $1;
            
            	if($filetype eq "AB10"){
            		$dummy = sprintf( "%016b" , hex($MISO1)).sprintf( "%032b" , hex($MISO2)); # convert to 48 bits
            	}
            	elsif($filetype eq "AB12"){
            		$dummy = sprintf( "%032b" , hex($MISO1)).sprintf( "%016b" , hex($MISO2)); # convert to 48 bits
            	}            
            	$dummy =~ /(\d{$bits})$/;   # extract used bits only
            	$MISObits = $1;
            
            $CS = hex($CS); # convert to dec
            $time = sprintf( "%010.3f" , $time/1000.0); # convert to msec		
			$sensorname = $Mapping->{$filetype}{'IXS_MAPPING'}{"CS$CS"};		
			my $ExtendedInstruction ='';
			
            if( $sensorname eq "LA") {
            	$line = $time . " " . $sensorname.':data:MISO' . '=' . '0b'.$MISObits . " " . $sensorname.':data:MOSI' . '=' . '0b'.$MOSIbits; 
            }
            
            else {
            		#if($filetype eq "AB10"){
            			$MOSIbits =~ /^(\d{$instruction_length})(\d{$alldata_length})/; #7 and 9 for AB10, 
            			$Instruction = $1;
           				$ExtendedInstruction = $1.$2 if defined $2; 
            		#} 
            		#elsif($filetype eq "AB12"){
            		#	$MOSIbits =~ /^(\d{$instruction_length})(\d{$alldata_length})/; #10(instruction size in bits) and 22(data) for AB12
            		#	$Instruction = $1;
           			#	$ExtendedInstruction = $1.$2; 
            		#}            	
 
                if (defined $Mapping->{$filetype}{$sensorname.'_COMMAND'}{$Instruction}) {
                	$signalname = $sensorname.":".$Mapping->{$filetype}{$sensorname.'_COMMAND'}{$Instruction};
                }
                elsif (defined $Mapping->{$filetype}{$sensorname.'_COMMAND'}{$ExtendedInstruction}) {
                	$signalname = $sensorname.":".$Mapping->{$filetype}{$sensorname.'_COMMAND'}{$ExtendedInstruction};
                }
                else {
                	$signalname = $sensorname.":undef";
                }

            	$line = $time . " " . $signalname .':MISO' . '=' . '0b'.$MISObits . " " . $signalname . ':MOSI' . '=' . '0b'.$MOSIbits;
			}
		}
		
    	#**************************  decode SPIMaid CSV ***************************
		# Time;ASIC;MOSI;MISO;DecMOSI;DecMISO
		# 0.00022384;12;0x0000000;0x0000614; ; 
		# 0.00045616;12;0x0000000;0x0000600; ; 
		# 0.00068784;12;0x0000000;0x0000614; ;
		
		if (($file =~ m/.csv/) and ($firstLine =~ m/ASIC/)) {
        	my ($time,$CS, $MOSI, $MISO, $MOSIbits, $MISObits, $sensorname, $signalname, $Instruction, $ExtendedInstruction, $SensorData);
			($time, $CS, $MOSI, $MISO) = split(/;/,$line);
			
			$MOSIbits = sprintf( "%032b", hex($MOSI));
			$MISObits = sprintf( "%032b", hex($MISO));   		

            $time = sprintf( "%010.3f" , $time*1000.0); # convert to msec
		
			$sensorname = $Mapping->{$filetype}{'IXS_MAPPING'}{"CS" . $CS};

           if (($sensorname eq "PPS2") or ($sensorname eq "PAS5R")) {
            	$Instruction = substr($MISObits, 22, 10);
            	
				$SensorData = abs (uint10($Instruction));
                if ( ($SensorData) <= 480 ) {
                	$Instruction = '0000000000';
                }               
                $ExtendedInstruction = "NotDefined";
           }
           else {
            	#if($filetype eq "AB10"){
            		$MOSIbits =~ /^(\d{$instruction_length})(\d{$alldata_length})/; #7 and 9 for AB10, 
            	#} 
            	#elsif($filetype eq "AB12"){
            	#	$MOSIbits =~ /^(\d{10})(\d{22})/; #10(instruction size in bits) and 22(data) for AB12	
            	#}
            	$Instruction = $1;
            	$ExtendedInstruction = $1.$2;
           }    		

		   	if (defined $Mapping->{$filetype}{$sensorname.'_COMMAND'}{$Instruction}) {
    			$signalname = $sensorname.":".$Mapping->{$filetype}{$sensorname.'_COMMAND'}{$Instruction};
		   	}
		   	elsif (defined $Mapping->{$filetype}{$sensorname.'_COMMAND'}{$ExtendedInstruction}) {
            	$signalname = $sensorname.":".$Mapping->{$filetype}{$sensorname.'_COMMAND'}{$ExtendedInstruction};
		   	}
		   	else {
            	$signalname = $sensorname.":undef";
		   	}

			$line = $time . " " . $signalname .':MISO' . '=' . '0b'. $MISObits . " " . $signalname . ':MOSI' . '=' . '0b'.$MOSIbits;
			print "$line\n";
    	}

    	#**************************  decoded by LIFT  ***************************
        #             $1        $2    $3        $4  $5            $6 $7  
        $line =~ /(\d+.\d+)\s+(\w+):(\w+):MISO=(0b(\d*)).+:MOSI=(0b(\d*))/;

        $out_absTime = $1; $out_sensor = $2; $out_Command = $3; $dataMISO = $5, $dataMOSI = $7;  
        
        unless(defined $dataMOSI){
        	next;
        }

     	
           # count all sensor specific commands
            $commandCounter{$out_sensor}{$out_Command}[0]++;
    
            my $comIndex = $commandCounter{$out_sensor}{$out_Command}[0];
            if ( $comIndex < 10 ) {
                $commandCounter{$out_sensor}{$out_Command}[$comIndex] = $out_absTime;
            }
            else {
                $commandCounter{$out_sensor}{$out_Command}[10] = $out_absTime;
            }

            # get actual sensor specific command counter
            $out_comCnt = $commandCounter{$out_sensor}{$out_Command}[0];

            if ( exists($commandCycTime{$out_sensor}{$out_Command}) ) {
                $out_cycTime = sprintf("%.3f", ($out_absTime - $commandCycTime{$out_sensor}{$out_Command}));
            }
            else {
                $out_cycTime = "";
            }
            
           $out_module = $Mapping->{$filetype}{$out_Command}{'module'};
           
           if(not defined $sensorOldValue{$out_sensor}{$out_Command} and not defined $statOldValue{$out_sensor}){
           		$sensorOldValue{$out_sensor}{$out_Command} = 1;	
 				$statOldValue{$out_sensor} = "000";	
           }

            
 if (defined $out_sensor and grep $_ eq $out_sensor, @decodableASICs){
                   
            if(scalar @decodableModules){
            	if(defined $out_module and grep $_ eq $out_module, @decodableModules){
            		$out_comLine++; 
            		$OutputToGrid = 1;        # activate output to grid
            		if (defined $self{ALL} and $self{ALL} == 1){
            			$status = "All commands will be decoded! Please wait..\n This may take some time!";
	  					$main->update();
            		}           		
            	}
            }
            else{ #if no modules are decodable, decode everything
            	$status = "All commands will be decoded! Please wait..\n This may take some time!";
	  			$main->update();
            	$out_comLine++; 
            	$OutputToGrid = 1;        # activate output to grid
            } 
            
            #*********************************************************************
			# Format Decoding
			#*********************************************************************	   
			my $MOSI_data_start = $Mapping->{$filetype}{"$out_sensor"."_FORMAT"}{'MOSI_data_start'};     
			    
             if(defined $MOSI_data_start) {          	
            	my $MOSI_data_length = $Mapping->{$filetype}{"$out_sensor"."_FORMAT"}{'MOSI_data_length'};
            	my $MISO_data_start = $Mapping->{$filetype}{"$out_sensor"."_FORMAT"}{'MISO_data_start'};
            	my $MISO_data_length = $Mapping->{$filetype}{"$out_sensor"."_FORMAT"}{'MISO_data_length'};
            	my $MISO_SID_start = $Mapping->{$filetype}{"$out_sensor"."_FORMAT"}{'MISO_SID_start'};
            	my $MISO_SID_length = $Mapping->{$filetype}{"$out_sensor"."_FORMAT"}{'MISO_SID_length'};
            	my $MISO_Stat_start = $Mapping->{$filetype}{"$out_sensor"."_FORMAT"}{'MISO_Stat_start'};
            	my $MISO_Stat_length = $Mapping->{$filetype}{"$out_sensor"."_FORMAT"}{'MISO_Stat_length'};
            	
            	$out_MOSI_Data = substr($dataMOSI, $MOSI_data_start, $MOSI_data_length) ; 
            	$out_MISO_Data  = substr($dataMISO, $MISO_data_start, $MISO_data_length); 
                $out_MISO_SID = "-" . substr($dataMISO, $MISO_SID_start, $MISO_SID_length) . "-"; 
                $out_MISO_Stat = "-" . substr($dataMISO, $MISO_Stat_start, $MISO_Stat_length) . "-"; 
				
            }
            #*********************************************************************
			# Any special handling of format
			#*********************************************************************	  
            elsif ($out_sensor eq "CG147") {
	            $out_MOSI_Data = substr($dataMOSI, 8, 8);
                $out_MISO_SID = "-" . substr($dataMISO, 3, 1) . "-" . substr($dataMISO, 4, 4);
                $out_MISO_Stat = substr($dataMISO, 0, 3);

                if (substr($dataMOSI, 0, 8) == "10000000") {	# read PAS data command?
                    $out_MISO_Data  = substr($dataMISO, 6, 10);
                }
                else {
                    $out_MISO_Data = substr($dataMISO, 8, 8);
                }
            }
            elsif ($out_sensor =~ m/PPS2/) {
	            $out_MOSI_Data = "-" . substr($dataMOSI, 8, 8) . "-";
            	$out_MISO_Stat = "";
            	$out_MISO_SID = "";    
            	$out_MISO_Data  = substr($dataMISO, 22, 10);
            }
            elsif ($filetype eq 'AB10') { #if no other special decoding available/needed!!
	            $out_MOSI_Data = substr($dataMOSI, 8, 8); #8 and 8
                $out_MISO_SID = "-" . substr($dataMISO, 3, 3) . "-";
                $out_MISO_Stat = substr($dataMISO, 0, 3);

                if (substr($dataMOSI, 0, 1) == "1") { # read sensor data command?
                    $out_MISO_Data  = substr($dataMISO, 6, 10); #6 and 10
                }
                else {
                    $out_MISO_Data  = substr($dataMISO, 8, 8); #8 and 8
                }
            }
            	
            $out_MISO_Value = "";
			$out_MOSI_Value = "";	

			
#*********************************************************************
# DisplayOnlyChanges
#*********************************************************************			
my $DisplayOnlyChanges = 0;	
if (($self{"$out_sensor"."_DisplayOnlyChangedSensorData"} == 1) and defined $sensorOldValue{$out_sensor}{$out_Command} and ($sensorOldValue{$out_sensor}{$out_Command} eq $dataMISO) ) {
	$OutputToGrid = 0;
	$DisplayOnlyChanges = 1;
}
unless($DisplayOnlyChanges){			
#*********************************************************************
# decoder by SPI mapping
#*********************************************************************			
			
	my ($group,$name,$startbit,$length,$value,$decode);
	my (@decodedPar,@parNames);
	my $datalength = 16;
	my $commandFound = 0;	
	my $commandHash = $Mapping->{$filetype}{$out_Command};
	my %decodedHash;
	
	foreach my $key (sort keys %$commandHash){
		if($key =~ m/parameter/i){
			$group = $Mapping->{$filetype}{$out_Command}{$key}{'group'};
			$name = $Mapping->{$filetype}{$out_Command}{$key}{'name'};
			$startbit = $Mapping->{$filetype}{$out_Command}{$key}{'startbit'};
			$length = $Mapping->{$filetype}{$out_Command}{$key}{'length'};
			
			my $position = $datalength - ($startbit+$length); #position from where bits are to be extracted for this parameter
	
			$value = substr($out_MOSI_Data,$position , $length) if ($group eq 'MOSI');
			$value = substr($out_MISO_Data,$position , $length) if ($group eq 'MISO');
			
			$decode = $Mapping->{$filetype}{$out_Command}{$key}{$value} if defined $value;
	 		if(defined $decode){
	 			$decodedHash{$out_Command}{$group}{$name} = $value."($decode)";
	 		}
	 		elsif(defined $value){
	 			$decodedHash{$out_Command}{$group}{$name} = $value;
	 		}
	 		$commandFound = 1 if defined $value;	
		}
	}

if($commandFound){
	my $tempHash_MOSI = $decodedHash{$out_Command}{'MOSI'};
	my $tempHash_MISO = $decodedHash{$out_Command}{'MISO'};
	if(defined $tempHash_MOSI){
		foreach my $par (sort keys %$tempHash_MOSI){
			my $value = $decodedHash{$out_Command}{'MOSI'}{$par};
			$out_MOSI_Value = "$out_MOSI_Value"."$par:$value; ";
		}
	}
	
	if(defined $tempHash_MISO){
		foreach my $par (sort keys %$tempHash_MISO){
			my $value = $decodedHash{$out_Command}{'MISO'}{$par};
			$out_MISO_Value = "$out_MISO_Value"."$par:$value; ";
		}
	}
	
}

#*********************************************************************
# PPS2 decoder
#*********************************************************************
elsif ($out_sensor eq "PPS2") {       	
            	if ($out_Command eq "Sensor_Data") {
                    $out_MISO_Value = uint10(substr($dataMISO, 22, 10));
            	}
            	elsif ($out_Command =~ m/Block_ID/) {
            	}
           		elsif ($out_Command eq "Status_Data") {
           		}
           		elsif ($out_Command eq "Manchester_Error") {
           		}
           		elsif ($out_Command eq "Parity_Error") {
           		}
           		elsif ($out_Command eq "Sensor_Defect") {
           		}
           		elsif ($out_Command eq "Buffer_Empty") {
           		}
           		elsif ($out_Command eq "Sensor_Busy") {
           		}
           		elsif ($out_Command eq "Sensor_Ready") {
           		}
           		elsif ($out_Command eq "Sensor_Ready_unlocked") {
           		}
                else {
                    #$grid1->SetRowAttr($RowCnt, $attr_color{light_Red});
                }
}

#*********************************************************************
# PAS5R decoder
#*********************************************************************
elsif ($out_sensor eq "PAS5R") {       	
            	if ($out_Command eq "Sensor_Data") {
                    $out_MISO_Value = uint10(substr($dataMISO, 22, 10));
            	}
            	elsif ($out_Command =~ m/Block_ID/) {
            	}
           		elsif ($out_Command eq "Status_Data") {
           		}
           		elsif ($out_Command eq "Manchester_Error") {
           		}
           		elsif ($out_Command eq "Parity_Error") {
           		}
           		elsif ($out_Command eq "Sensor_Defect") {
           		}
           		elsif ($out_Command eq "Buffer_Empty") {
           		}
           		elsif ($out_Command eq "Sensor_Busy") {
           		}
           		elsif ($out_Command eq "Sensor_Ready") {
           		}
           		elsif ($out_Command eq "Sensor_Ready_unlocked") {
           		}
           		elsif ($out_Command eq "Sensor_Ready_unlocked_1") {
           		}
           		elsif ($out_Command eq "Bidirec_Comm_Error") {
           		}
           		elsif ($out_Command eq "Bidirec_Comm_OK") {
           		}
                else {
                    #$grid1->SetRowAttr($RowCnt, $attr_color{light_Red});
                }
}

#*********************************************************************
# SMA560 decoder
#*********************************************************************
elsif ( ($out_sensor eq 'SMA560') or ($out_sensor eq 'SMA560P') ) {       
                if ( ($out_Command eq "RD_SENSOR_DATA_I") or ($out_Command eq "RD_DATA_CHA") or
                	 ($out_Command eq "RD_SENSOR_DATA_II") or ($out_Command eq "RD_DATA_CHB") ) {
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                

                    $out_MISO_SID = int8(substr($dataMISO, 3, 3));    
                    $out_MISO_Value = uint10(substr($dataMISO, 6, 10));

					if ($out_sensor eq 'SMA560') {
						if ( ($self{SMA560_DisplayOnlyChangedSensorData} != 0) and 
						     ($sensorOldValue{$out_sensor}{$out_Command} eq $dataMISO) ) {
								$OutputToGrid = 0;
						}
						                  
					}
					else {
						if ( ($self{SMA560P_DisplayOnlyChangedSensorData} != 0) and 
						     ($sensorOldValue{$out_sensor}{$out_Command} eq $dataMISO) ) {
								$OutputToGrid = 0;
						}                  
					}                   
					$sensorOldValue{$out_sensor}{$out_Command} = $dataMISO;
				}
                elsif ($out_Command eq 'RD_CLK_CNT') {					
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                
                    $out_MISO_Value = int8($out_MISO_Data);
                }
                elsif ( ($out_Command eq 'RD_MONITOR_I') or ($out_Command eq 'RD_MONITOR_I_DATA') or
                	    ($out_Command eq 'RD_MONITOR_II') or ($out_Command eq 'RD_MONITOR_II_DATA')) {
                    if ($out_MISO_Data ne '00000000') {
                        #$grid1->SetCellBackgroundColour($RowCnt, $col_MISO_Data, Wx::Colour->new(@light_Red));
                    }

                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                
                    $out_MISO_Data =~ s/(\d)\B/$1:/g;                      
                }
                elsif ($out_Command eq 'RD_DEVICE_ID') {
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                
                    $out_MISO_Value = sprintf("%#02x", int8($out_MISO_Data));
				}
                elsif ($out_Command eq 'RD_REVISION_ID') {
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                

					my $MISO_MSR1 = substr($dataMISO, 12, 4);					
					my $MISO_SWR2 = substr($dataMISO, 8, 4);					 
                    my $MISO_Val_MSR1 = sprintf("%#x", int8($MISO_MSR1));
                    my $MISO_Val_SWR2 = sprintf("%#x", int8($MISO_SWR2));
 
                	$out_MISO_Data = ($MISO_SWR2 . ":" . $MISO_MSR1);                	
                    $out_MISO_Value  = ($MISO_Val_SWR2 . ":" . $MISO_Val_MSR1);
				}
                elsif ($out_Command eq 'SEL_G_RANGE') {
    				my %gRange = ('0000' => '96g', '0011' => '70g', '1100' => '48g', '1111' => '35g');
 					my $MOSI_S1 = substr($dataMOSI, 12, 4);
 					my $MOSI_S2 = substr($dataMOSI,  8, 4);
 					 
                    $out_MOSI_Data = $MOSI_S2 . ":" . $MOSI_S1;                
                    $out_MOSI_Value = $gRange{$MOSI_S2} . ":" . $gRange{$MOSI_S1};                

                	$out_MISO_Data = "-" . $out_MISO_Data . "-";                
                }
                elsif (($out_Command eq 'RD_ACCEL_RANGE') or ($out_Command eq 'RD_G_RANGE')) {
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                

    				my %gRange = ('0000' => '96g', '0011' => '70g', '1100' => '48g', '1111' => '35g');   				
 					my $MISO_S1 = substr($dataMISO, 12, 4);
 					my $MISO_S2 = substr($dataMISO,  8, 4);

                    $out_MISO_Data = $MISO_S2 . ":" . $MISO_S1;                
                    $out_MISO_Value = $gRange{$MISO_S2} . ":" . $gRange{$MISO_S1};                
                }
                elsif ($out_Command eq 'DE_OFFSET_CANCEL') {
    				my %OffCancStat = ('0' => 'Off', '1' => 'On');
					my $MOSI_OFF1 = substr($dataMOSI, 15, 1);
					my $MOSI_S2 = substr($dataMOSI, 14, 1);
					my $MOSI_OFF3 = substr($dataMOSI, 13, 1);
					my $MOSI_S4 = substr($dataMOSI, 8, 5);

                    $out_MOSI_Data = "-" . $MOSI_S4 . "-" . ":"  . $MOSI_OFF3 . "-" . $MOSI_S2 . "-" . ":"  . $MOSI_OFF1;                
                    $out_MOSI_Value = $OffCancStat{$MOSI_OFF3} . ":" . $OffCancStat{$MOSI_OFF1};                
                	$out_MISO_Data = "-" . $out_MISO_Data . "-";                
                }
                elsif (($out_Command eq 'RD_OFFSET_CANCEL') or ($out_Command eq 'RD_OFFSET_CANCELLATION') ){
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                

    				my %OffCancStat = ('00' => 'Off', '10' => 'Slow', '11' => 'Fast');
					my $MISO_OMD1 = substr($dataMISO, 14, 2);
					my $MISO_OMD2 = substr($dataMISO, 12, 2);
					my $MISO_S3 = substr($dataMISO, 8, 4);

                    $out_MISO_Data = "-" . $MISO_S3 . "-" . $MISO_OMD2 . ":" . $MISO_OMD1;                
                    $out_MISO_Value = $OffCancStat{$MISO_OMD2} . ":" . $OffCancStat{$MISO_OMD1};                
                }
                elsif ( ($out_Command eq 'RD_OFFSET_CANCEL_I_CHA') or ($out_Command eq 'RD_OFFSET_CANCEL_I_Channel_A') or
                		($out_Command eq 'RD_OFFSET_CANCEL_I_CHB') or ($out_Command eq 'RD_OFFSET_CANCEL_I_Channel_B') ) {
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                
                }
                elsif ( ($out_Command eq 'RD_OFFSET_CANCEL_II_CHA') or ($out_Command eq 'RD_OFFSET_CANCEL_II_Channel_A') or
                		($out_Command eq 'RD_OFFSET_CANCEL_II_CHB') or($out_Command eq 'RD_OFFSET_CANCEL_II_Channel_B') ) {
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                

					my $MISO_S1 = substr($dataMISO, 12, 4);
					my $MISO_S2 = substr($dataMISO, 8, 4);
					
                    $out_MISO_Data = "-" . $MISO_S2 . "-" . $MISO_S1;                
				}
                elsif ( $out_Command eq 'DE_FOR_TEST' ) {
       				my %TMD = ('00' => 'Off', '01' => 'PosA', '10' => 'NegA', '11' => 'Test');
					my $MOSI_TMD1 = substr($dataMOSI, 14, 2);
					my $MOSI_TMD2 = substr($dataMOSI, 12, 2);
					my $MOSI_S3 = substr($dataMOSI, 8, 4);

                    $out_MOSI_Data = "-" . $MOSI_S3 . "-" . $MOSI_TMD2 . ":" . $MOSI_TMD1;                
                    $out_MOSI_Value = $TMD{$MOSI_TMD2} . ":" . $TMD{$MOSI_TMD1};                   
                	$out_MISO_Data = "-" . $out_MISO_Data . "-";                
                }
                elsif ($out_Command =~ /PROG_FOR_TEST/) {
                    $out_MOSI_Value = int8($out_MOSI_Data);

                	$out_MISO_Data = "-" . $out_MISO_Data . "-";                
                }
                elsif ($out_Command eq 'PROG_SID') {
					my $MOSI_S1 = substr($dataMOSI, 13, 3);
					my $MOSI_S2 = substr($dataMOSI, 10, 3);
					my $MOSI_S3 = substr($dataMOSI, 8, 2);

                    my $ID_S1 = sprintf("%X", int8($MOSI_S1));
                    my $ID_S2 = sprintf("%X", int8($MOSI_S2));

                    $out_MOSI_Data = "-" . $MOSI_S3 . "-" . $MOSI_S2 . ":" . $MOSI_S1;                
                    $out_MOSI_Value = $ID_S2 . ":" . $ID_S1;
                	$out_MISO_Data = "-" . $out_MISO_Data . "-";                
                }
                elsif ($out_Command eq 'RD_SID') {
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                

					my $MISO_S1 = substr($dataMISO, 13, 3);
					my $MISO_S2 = substr($dataMISO, 10, 3);
					my $MISO_S3 = substr($dataMISO, 8, 2);

                    my $ID_S1 = sprintf("%X", int8($MISO_S1));
                    my $ID_S2 = sprintf("%X", int8($MISO_S2));

                    $out_MISO_Data = "-". $MISO_S3 . "-" . $MISO_S2 . ":" . $MISO_S1;                
                    $out_MISO_Value = $ID_S2 . ":" . $ID_S1;
                }
                elsif ($out_Command eq 'PRO_SEL') {
                    $out_MOSI_Value = sprintf("%#02x", int8($out_MOSI_Data));
                	$out_MISO_Data = "-" . $out_MISO_Data . "-";                
                }
                elsif ($out_Command eq 'END_OF_PROG') {
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                
                	$out_MISO_Data = "-" . $out_MISO_Data . "-";                
                }
                else {
                    #$grid1->SetRowAttr($RowCnt, $attr_color{light_Red});
                }
}
                     
#*********************************************************************
# CG904 decoder
#*********************************************************************
elsif ($out_sensor =~ m/CG904/i) {            	               
            #bitwise decoding for POM module	               
                if ( $out_Command eq 'POM_STATUS' ) {
       				my %vel = ('0' => 'VER ok', '1' => 'VER low');
       				my %v50 = ('0' => 'VST50 ok', '1' => 'VST50 out of band');
       				my %vzl = ('0' => 'VZP ok', '1' => 'VZP low');
       				my %vet = ('0' => 'VER < VER test level', '1' => 'VER > VER test level');
       				my %ot = ('0' => 'temperature ok', '1' => 'temperature too high, VUP switched off');
       				my %erc = ('0' => 'ER_CHARGE not set', '1' => 'VUP_L=1 & VER_TEST=0');
       				my %sl = ('0' => 'normal mode', '1' => 'sleep mode request');
       				my %c1 = ('0' => 'CONF_33_OFF', '1' => 'CONF_33_ON');
       				my %c2 = ('0' => 'CONF_50_OFF', '1' => 'CONF_50_ON');
       				my %c3 = ('0' => 'CONF_CORE_OFF', '1' => 'CONF_CORE_ON');
       				my %c4 = ('0' => 'CONF_VC1_OFF', '1' => 'CONF_VC1_ON');
       				my %c5 = ('0' => 'CONF_VC2_OFF', '1' => 'CONF_VC2_ON');
       				my %c6 = ('0' => 'CONF_VBAT_OFF', '1' => 'CONF_VBAT_ON');

					my $MISO_vel = substr($dataMISO, 27, 1);
					my $MISO_v50 = substr($dataMISO, 26, 1);
					my $MISO_vzl = substr($dataMISO, 25, 1);
					my $MISO_vet = substr($dataMISO, 24, 1);
					my $MISO_c1 = substr($dataMISO, 23, 1);
					my $MISO_c2 = substr($dataMISO, 22, 1);
					my $MISO_c3 = substr($dataMISO, 21, 1);
					my $MISO_c4 = substr($dataMISO, 20, 1);
					my $MISO_c5 = substr($dataMISO, 19, 1);
					my $MISO_c6 = substr($dataMISO, 18, 1);
					my $MISO_ot = substr($dataMISO, 17, 1);
					my $MISO_erc = substr($dataMISO, 16, 1);
					my $MISO_sl = substr($dataMISO, 15, 1);	
					
					$out_MISO_Value = "sl:".$sl{$MISO_sl} . ",erc:" . $erc{$MISO_erc} . ",ot:" .  $ot{$MISO_ot} . ",vet:" . $vet{$MISO_vet} . ",vzl:" .  $vzl{$MISO_vzl} . ",v50:" . $v50{$MISO_v50}. ",vel:" . $vel{$MISO_vel};
                }				           
				elsif ( $out_Command eq 'POM_VER_CURR' ) {
       				my %vlm = ('0' => 'loading up to 11V', '1' => 'loading up to 31V');       				
       				my %dis = ('0' => 'discharge VER off', '1' => 'discharge VER on');				                 
       				
					my $MOSI_vlm = substr($dataMOSI, 26, 1);
					my $MOSI_ver_current = substr($dataMOSI, 23, 3);
					my $MOSI_dis = substr($dataMOSI, 22, 1);
					my $MOSI_Val_ver_current = sprintf("%#x", int8($MOSI_ver_current));

                    #$out_MOSI_Data = $MOSI_dis . ":" . $MOSI_ver_current . ":" . $MOSI_vlm;                                    
                    $out_MOSI_Value = "dis:".$dis{$MOSI_dis} . ",ver_current:" . $MOSI_ver_current . ",vlm:" .  $vlm{$MOSI_vlm};
                	$out_MISO_Data = "-" . $out_MOSI_Data . "-";               
                }						
				elsif ( $out_Command eq 'POM_START_BIST' ) {
       				my %mode = ('00' => 'no BIST', '01' => 'ESR BIST', '10' => 'CAP BIST', '11' => 'CAP + Discharge BIST');       				
       				my %bc = ('0' => 'VER>VER_TEST', '1' => 'VER is too low');	
					my %vel = ('0' => 'VER ok', '1' => 'VER low');					
					my %ta = ('0' => 'BIST not running', '1' => 'BIST running');					
       				
					my $MOSI_i_bist = substr($dataMOSI, 24, 3);
					my $MOSI_t_bist = substr($dataMOSI, 19, 5);
					my $MOSI_mode = substr($dataMOSI, 17, 2);
					
					my $MISO_bc = substr($dataMISO, 27, 1);
					my $MISO_vel = substr($dataMISO, 26, 1);
					my $MISO_ta = substr($dataMISO, 25, 1);
					#my $MOSI_Val_i_bist = sprintf("%#x", int8($MOSI_ver_current));

                    #$out_MOSI_Data = $MOSI_dis . ":" . $MOSI_ver_current . ":" . $MOSI_vlm;                                    
                    $out_MOSI_Value = "mode:".$mode{$MOSI_mode} . ", i_bist:" . $MOSI_i_bist . ", t_bist:" .  $MOSI_t_bist;
                	$out_MISO_Value = "ta:" . $ta{$MISO_ta} . ", vel:". $vel{$MISO_vel} . ", bc:". $bc{$MISO_bc};               
                }
				elsif ( $out_Command eq 'POM_READ_BIST' ) {
       				my %et1 = ('0' => 'VER < ESR_START + 0.75V', '1' => 'VER > ESR_START + 0.75V');   
					my %et2 = ('0' => 'VER < ESR_START + 1.25V', '1' => 'VER > ESR_START + 1.25V');     				
					my %vel = ('0' => 'VER ok', '1' => 'VER low');	
					my %vzl = ('0' => 'VZP ok', '1' => 'VZP low');
					my %ch = ('0' => 'charge current ok', '1' => 'no charge current');
					my %mis = ('0' => 'ER present', '1' => 'ER capacitance is missing');
					my %vet = ('0' => 'VER < VER test level', '1' => 'VER > VER test level');	
					my %ta = ('0' => 'BIST not running', '1' => 'BIST running');					
					
					my $MISO_delta_ver = substr($dataMISO, 21, 7);
					my $MISO_et1 = substr($dataMISO, 20, 1);
					my $MISO_et2 = substr($dataMISO, 19, 1);
					my $MISO_vel = substr($dataMISO, 18, 1);
					my $MISO_vzl = substr($dataMISO, 17, 1);
					my $MISO_ch = substr($dataMISO, 16, 1);
					my $MISO_mis = substr($dataMISO, 15, 1);
					my $MISO_vet = substr($dataMISO, 14, 1);
					my $MISO_ta = substr($dataMISO, 13, 1);
					#my $MOSI_Val_i_bist = sprintf("%#x", int8($MOSI_ver_current));

                    #$out_MOSI_Data = $MOSI_dis . ":" . $MOSI_ver_current . ":" . $MOSI_vlm;                                    
                	$out_MISO_Value = "ta:" . $ta{$MISO_ta} . ", vet:". $vet{$MISO_vet} . ", mis:". $mis{$MISO_mis}. ", ch:". $ch{$MISO_ch}. ", vzl:". $vzl{$MISO_vzl}. ", vel:". $vel{$MISO_vel}. ", et2:". $et2{$MISO_et2}. ", et1:". $et1{$MISO_et1}. ", delta_ver:" .  $MISO_delta_ver;               
                }		
                elsif ( $out_Command eq 'POM_CYCL_CAP' ) {
       				my %on = ('0' => 'cyclic capacitance test off', '1' => 'cyclic capacitance test on');
       				my %res = ('0' => 'result of last cyclic capacitance test-ok', '1' => 'result of last cyclic capacitance test-error');
       				my %bc = ('0' => 'busy charge-VER is ok', '1' => 'busy charge-VER is too low');
       				my %ta = ('0' => 'cyclic capacitance test not active', '1' => 'cyclic capacitance test active');
       				
					my $MOSI_on = substr($dataMOSI, 26, 1);
					
					my $MISO_res = substr($dataMISO, 27, 1);
					my $MISO_bc = substr($dataMISO, 26, 1);
					my $MISO_ta = substr($dataMISO, 25, 1);

                    #$out_MISO_Data = $MISO_ta . ":" . $MISO_bc . ":" . $MISO_res;                                    
                    $out_MISO_Value = "ta:".$ta{$MISO_ta} . ",bc:" . $bc{$MISO_bc} . ",res:" .  $res{$MISO_res};
                	#$out_MOSI_Data = $MOSI_on;  
                	$out_MOSI_Value = "on:".$on{$MOSI_on} ; 
                	
           
                }				
				elsif ( $out_Command =~ m/PROG_AINO_CONF/ ) {
       				#my %current_level = ('0' => 'cyclic capacitance test off', '1' => 'cyclic capacitance test on');
       				my %src = ('0' => 'VAS', '1' => 'VUP');
       				my %ui = ('0' => 'voltage', '1' => 'current');
       				my %mode = ('00' => 'no meas', '01' => 'no source', '10' => 'fix current', '11' => 'fix voltage');
       				
					my $MOSI_current_level = substr($dataMOSI, 23, 4);
					my $MOSI_src = substr($dataMOSI, 22, 1);
					my $MOSI_ui = substr($dataMOSI, 21, 1);
					my $MOSI_mode = substr($dataMOSI, 19, 2);

                    #$out_MOSI_Data = $MISO_ta . ":" . $MISO_bc . ":" . $MISO_res;                                    
                    $out_MOSI_Value = "mode:".$mode{$MOSI_mode} . ", ui:".$ui{$MOSI_ui} . ", src:" .  $src{$MOSI_src}. ", current_level:" . $MOSI_current_level;
                	#$out_MOSI_Data = $MOSI_on;  
                	#$out_MOSI_Value = $on{$MOSI_on} ; 
                	
           
                }				
				elsif ( $out_Command =~ m/PROG_SW_MODE/ ) {
       				#my %current_level = ('0' => 'cyclic capacitance test off', '1' => 'cyclic capacitance test on');
       				my %en = ('0' => 'enable band', '1' => 'disable band');
       				
					my $MOSI_sdis_channel = substr($dataMOSI, 19, 4);
					my $MOSI_count = substr($dataMOSI, 23, 3);
					my $MOSI_en = substr($dataMOSI, 26, 1);

                    #$out_MOSI_Data = $MISO_ta . ":" . $MISO_bc . ":" . $MISO_res;                                    
                    $out_MOSI_Value = "sdis_channel:".$MOSI_sdis_channel . ", count:".$MOSI_count . ", en:" .  $en{$MOSI_en};
                	#$out_MOSI_Data = $MOSI_on;  
                	#$out_MOSI_Value = $on{$MOSI_on} ; 
                	
                 }          							
}
            
#*********************************************************************
# SMG100 decoder
#*********************************************************************
elsif ($out_sensor eq 'SMG100') {       
                if ($out_Command eq 'RD_SENSOR_DATA') {
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                

                    $out_MISO_SID = int8(substr($dataMISO, 3, 3));    
                    $out_MISO_Value = uint10(substr($dataMISO, 6, 10));

					if ( ($self{SMG100_DisplayOnlyChangedSensorData} != 0) and 
						 ($sensorOldValue{$out_sensor}{$out_Command} eq $dataMISO) ) {
						$OutputToGrid = 0;
					}                  
					$sensorOldValue{$out_sensor}{$out_Command} = $dataMISO;					
                }
                elsif ( ($out_Command eq 'RD_MONITOR_I') or
                		($out_Command eq 'RD_MONITOR_II') ) {
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                

                    if ($out_MISO_Data ne '00000000') {
                        #$grid1->SetCellBackgroundColour($RowCnt, $col_MISO_Data, Wx::Colour->new(@light_Red));
                    }

                    $out_MISO_Data =~ s/(\d)\B/$1:/g;                      
                }
                elsif ($out_Command eq 'RD_DEVICE_ID') {
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                
                    $out_MISO_Value = sprintf("%#02x", int8($out_MISO_Data));
				}
                elsif ($out_Command eq 'RD_REVISION_ID') {
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                

					my $MISO_MSR1 = substr($dataMISO, 12, 4);					
					my $MISO_SWR2 = substr($dataMISO, 8, 4);					 
                    my $MISO_Val_MSR1 = sprintf("%#x", int8($MISO_MSR1));
                    my $MISO_Val_SWR2 = sprintf("%#x", int8($MISO_SWR2));
 
                	$out_MISO_Data = ($MISO_SWR2 . ":" . $MISO_MSR1);                	
                    $out_MISO_Value  = ($MISO_Val_SWR2 . ":" . $MISO_Val_MSR1);
				}
                elsif ($out_Command =~ /RD_PART_ID_/) {  
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                
                    $out_MISO_Value = sprintf("%#02x", int8($out_MISO_Data));
                }
                elsif ($out_Command eq 'WR_SOFT_RESET') {
                 	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                
                }
                elsif ($out_Command eq 'RD_SENSOR_CONFIG') {
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                

       				my %SUP = ('0' => '5V', '1' => '3V');
       				my %MEAS = ('0' => '240', '1' => '300');
       				my %SPI = ('0' => 'OP', '1' => 'RB');
					my $MISO_SUP1 = substr($dataMISO, 15, 1);
					my $MISO_MEAS2 = substr($dataMISO, 14, 1);
					my $MISO_FIR_SEL3 = substr($dataMISO, 12, 2);
					my $MISO_SPI4 = substr($dataMISO, 11, 1);
					my $MISO_S5 = substr($dataMISO, 8, 3);

                    $out_MISO_Data = "-" . $MISO_S5 . "-" . $MISO_SPI4 . ":" . $MISO_FIR_SEL3 . ":" . $MISO_MEAS2 . ":" . $MISO_SUP1;
                    $out_MISO_Value = $SPI{$MISO_SPI4} . ":" . $MISO_FIR_SEL3 . ":" . $MEAS{$MISO_MEAS2} . ":" .  $SUP{$MISO_SUP1};            
                }
                elsif ($out_Command eq 'DE_OFFSET_CANCEL') {
    				my %OffCancStat = ('0' => 'Off', '1' => 'On');
					my $MOSI_OFF1 = substr($dataMOSI, 15, 1);
					my $MOSI_S2 = substr($dataMOSI, 8, 7);

                    $out_MOSI_Data = "-" . $MOSI_S2 . "-" . $MOSI_OFF1;                
                    $out_MOSI_Value = $OffCancStat{$MOSI_OFF1}; 
                	$out_MISO_Data = "-" . $out_MISO_Data . "-";                
                }
                elsif ($out_Command eq 'RD_OFFSET_CANCEL') {
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                

    				my %OffCancStat = ('00' => 'Off', '10' => 'Slow', '11' => 'Fast');
					my $MISO_OMD1 = substr($dataMISO, 14, 2);
					my $MISO_S2 = substr($dataMISO, 8, 6);

                    $out_MISO_Data = "-" . $MISO_S2 . "-" . $MISO_OMD1;                
                    $out_MISO_Value = $OffCancStat{$MISO_OMD1};                
                }
                elsif ( $out_Command eq 'DE_FOR_TEST' ) {
       				my %TMD = ('00' => 'Off', '01' => 'PosA', '10' => 'NegA', '11' => 'Test');
					my $MOSI_TMD1 = substr($dataMOSI, 14, 2);
					my $MOSI_S2 = substr($dataMOSI, 8, 6);

                    $out_MOSI_Data = "-" . $MOSI_S2 . "-" . $MOSI_TMD1;                
                    $out_MOSI_Value = $TMD{$MOSI_TMD1};                   
                	$out_MISO_Data = "-" . $out_MISO_Data . "-";                
                }
                elsif ($out_Command eq 'END_OF_PROG') {
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                
                	$out_MISO_Data = "-" . $out_MISO_Data . "-";                
                }
               else {
                    #$grid1->SetRowAttr($RowCnt, $attr_color{light_Red});
               }
}
                        
#*********************************************************************
# SMB200 decoder
#*********************************************************************
elsif ( $out_sensor eq 'SMB200' ) {       
                if ( ($out_Command eq 'RD_SENSOR_DATA_I') or 
                     ($out_Command eq 'RD_SENSOR_DATA_II') ) {
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                

                    $out_MISO_SID = int8(substr($dataMISO, 3, 3));    
                    $out_MISO_Value = uint10(substr($dataMISO, 6, 10));

					if ( ($self{SMB200_DisplayOnlyChangedSensorData} != 0) and 
						 ($sensorOldValue{$out_sensor}{$out_Command} eq $dataMISO) ) {
						$OutputToGrid = 0;
					}                  
					$sensorOldValue{$out_sensor}{$out_Command} = $dataMISO;					
                }
                elsif ($out_Command eq 'RD_MONITOR_I') {
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                

                    if ($out_MISO_Data ne '00000000') {
                        #$grid1->SetCellBackgroundColour($RowCnt, $col_MISO_Data, Wx::Colour->new(@light_Red));
                    }

					my $MISO_S1 = substr($out_MISO_Data, 4, 4);
					my $MISO_S2 = substr($out_MISO_Data, 0, 4);

                    $MISO_S1 =~ s/(\d)\B/$1:/g;                      
                    $out_MISO_Data = $MISO_S2 . "-" . $MISO_S1 ;                      
                }
                elsif ($out_Command eq 'RD_DEVICE_ID') {
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                
                    $out_MISO_Value = sprintf("%#02x", int8($out_MISO_Data));
				}
                elsif ($out_Command eq 'RD_REVISION_ID') {
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                

					my $MISO_MSR1 = substr($dataMISO, 12, 4);					
					my $MISO_SWR2 = substr($dataMISO, 8, 4);
					 
                    my $MISO_Val_MSR1 = sprintf("%#x", int8($MISO_MSR1));
                    my $MISO_Val_SWR2 = sprintf("%#x", int8($MISO_SWR2));
 
                	$out_MISO_Data = ($MISO_SWR2 . ":" . $MISO_MSR1);                	
                    $out_MISO_Value  = ($MISO_Val_SWR2 . ":" . $MISO_Val_MSR1);
				}
                elsif ($out_Command eq 'DE_OFFSET_CANCEL') {
    				my %OffCancStat = ('0' => 'Off', '1' => 'On');
					my $MOSI_OFF1 = substr($dataMOSI, 15, 1);
					my $MOSI_S2 = substr($dataMOSI, 14, 1);
					my $MOSI_OFF3 = substr($dataMOSI, 13, 1);
					my $MOSI_S4 = substr($dataMOSI, 8, 5);

                    $out_MOSI_Data = "-" . $MOSI_S4 . "-" . ":"  . $MOSI_OFF3 . "-" . $MOSI_S2 . "-" . ":"  . $MOSI_OFF1;                
                    $out_MOSI_Value = $OffCancStat{$MOSI_OFF3} . ":" . $OffCancStat{$MOSI_OFF1};                
                	$out_MISO_Data = "-" . $out_MISO_Data . "-";                
                }
                elsif ($out_Command eq 'RD_OFFSET_CANCEL') {
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                

    				my %OffCancStat = ('00' => 'Off', '10' => 'Slow', '11' => 'Fast');
					my $MISO_OMD1 = substr($dataMISO, 14, 2);
					my $MISO_OMD2 = substr($dataMISO, 12, 2);
					my $MISO_S3 = substr($dataMISO, 8, 4);

                    $out_MISO_Data = "-" . $MISO_S3 . "-" . $MISO_OMD2 . ":" . $MISO_OMD1;                
                    $out_MISO_Value = $OffCancStat{$MISO_OMD2} . ":" . $OffCancStat{$MISO_OMD1};                
                }
                elsif ( $out_Command eq 'DE_FOR_TEST' )
                {
       				my %TMD = ('00' => 'Off', '01' => 'PosA', '10' => 'NegA');
					my $MOSI_TMD1 = substr($dataMOSI, 14, 2);
					my $MOSI_TMD2 = substr($dataMOSI, 12, 2);
					my $MOSI_S3 = substr($dataMOSI, 8, 4);

                    $out_MOSI_Data = "-" . $MOSI_S3 . "-" . $MOSI_TMD2 . ":" . $MOSI_TMD1;                
                    $out_MOSI_Value = $TMD{$MOSI_TMD2} . ":" . $TMD{$MOSI_TMD1};                   
                	$out_MISO_Data = "-" . $out_MISO_Data . "-";                
                }
             	elsif ($out_Command eq 'END_OF_PROG') {
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                
                	$out_MISO_Data = "-" . $out_MISO_Data . "-";                
             	}
             	else {
                    #$grid1->SetRowAttr($RowCnt, $attr_color{light_Red});
				}
}
			
#*********************************************************************
# SMB470 decoder
#*********************************************************************
elsif ( $out_sensor eq "SMB470" ) {       
                if ( ($out_Command eq "RD_SENSOR_DATA_I") or
                	 ($out_Command eq "RD_SENSOR_DATA_II") ) {
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                

                    $out_MISO_SID = int8(substr($dataMISO, 3, 3));    
                    $out_MISO_Value = uint10(substr($dataMISO, 6, 10));

					if ( ($self{SMB470_DisplayOnlyChangedSensorData} != 0) and 
						 ($sensorOldValue{$out_sensor}{$out_Command} eq $dataMISO) ) {
						$OutputToGrid = 0;
					}                  
					$sensorOldValue{$out_sensor}{$out_Command} = $dataMISO;					
                }
                elsif ($out_Command eq 'RD_TEMP') {					
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                
                    $out_MISO_Value = uint8($out_MISO_Data);
                }
                elsif ($out_Command eq 'RD_ECLK_CNT') {					
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                
                    $out_MISO_Value = int8($out_MISO_Data);
                }
                elsif ( ($out_Command eq 'RD_MONITOR_I') or
                		($out_Command eq 'RD_MONITOR_II') ) {
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                

                    if ($out_MISO_Data ne '00000000') {
                        #$grid1->SetCellBackgroundColour($RowCnt, $col_MISO_Data, Wx::Colour->new(@light_Red));
                    }
                    $out_MISO_Data =~ s/(\d)\B/$1:/g;                      
                }
                elsif ($out_Command eq 'RD_MONITOR_III') {
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                

                    if ($out_MISO_Data ne '00000000') {
                        #$grid1->SetCellBackgroundColour($RowCnt, $col_MISO_Data, Wx::Colour->new(@light_Red));
                    }

					my $MISO_S1 = substr($dataMISO, 9, 7);
					my $MISO_S2 = substr($dataMISO, 8, 1);

                    $MISO_S1 =~ s/(\d)\B/$1:/g;
                    $out_MISO_Data = $MISO_S2 . "-" . $MISO_S1 ;                      
                }
                elsif ($out_Command eq 'RD_DEVICE_ID') {
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                
                    $out_MISO_Value = sprintf("%#02x", int8($out_MISO_Data));
				}
                elsif ($out_Command eq 'RD_REVISION_ID') {
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                

					my $MISO_MSR1 = substr($dataMISO, 12, 4);					
					my $MISO_SWR2 = substr($dataMISO, 8, 4);					 
                    my $MISO_Val_MSR1 = sprintf("%#x", int8($MISO_MSR1));
                    my $MISO_Val_SWR2 = sprintf("%#x", int8($MISO_SWR2));
 
                	$out_MISO_Data = ($MISO_SWR2 . ":" . $MISO_MSR1);                	
                    $out_MISO_Value  = ($MISO_Val_SWR2 . ":" . $MISO_Val_MSR1);
				}
                elsif ($out_Command =~ /RD_PART_ID_/) {  
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                
                    $out_MISO_Value = sprintf("%#02x", int8($out_MISO_Data));
                }
                elsif ($out_Command eq 'DE_OFFSET_CANCEL') {
    				my %OffCancReq = ('0' => 'Off', '1' => 'On');
					my $MOSI_OC_B1 = substr($dataMOSI, 15, 1);
					my $MOSI_OS_B2 = substr($dataMOSI, 14, 1);
					my $MOSI_OC_A3 = substr($dataMOSI, 13, 1);
					my $MOSI_OS_A4 = substr($dataMOSI, 12, 1);
					my $MOSI_S5    = substr($dataMOSI, 8, 4);

                    $out_MOSI_Data = "-" . $MOSI_S5 . "-"  . $MOSI_OS_A4 . ":" . $MOSI_OC_A3 . ":"  . $MOSI_OS_B2 . ":"  . $MOSI_OC_B1;                
                    $out_MOSI_Value = $OffCancReq{$MOSI_OS_A4} . ":" . $OffCancReq{$MOSI_OC_A3} . ":"  . $OffCancReq{$MOSI_OS_B2} . ":"  . $OffCancReq{$MOSI_OC_B1};
                	$out_MISO_Data = "-" . $out_MISO_Data . "-";                
                }
                elsif ($out_Command eq 'RD_OFFSET_CANCEL') {
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                

    				my %OffCancReq = ('0' => 'Off', '1' => 'On');
    				my %OffCancStat = ('00' => 'Off', '10' => 'Slow', '11' => 'Fast');
					my $MISO_CAL_B1 = substr($dataMISO, 14, 2);
					my $MISO_SUB_B2 = substr($dataMISO, 13, 1);
					my $MISO_CAL_A3 = substr($dataMISO, 11, 2);
					my $MISO_SUB_A4 = substr($dataMISO, 10, 1);
					my $MISO_S5     = substr($dataMISO, 8, 2);

                    $out_MISO_Data = "-" . $MISO_S5 . "-"  . $MISO_SUB_A4 . ":" . $MISO_CAL_A3 . ":"  . $MISO_SUB_B2 . ":"  . $MISO_CAL_B1;                
                    $out_MISO_Value = $OffCancReq{$MISO_SUB_A4} . ":" . $OffCancStat{$MISO_CAL_A3} . ":"  . $OffCancReq{$MISO_SUB_B2} . ":"  . $OffCancStat{$MISO_CAL_B1};               
                }
                elsif ( $out_Command eq 'DE_FOR_TEST' ) {
       				my %TMD1 = ('00' => 'BITEoff', '01' => 'LFposA', '10' => 'LFnegA', '11' => 'HFon');
       				my %TMD2 = (
       					'0000' => '31250', '0001' => '20833', '0010' => '15625', '0011' => '12500',
       					'0100' => '10417', '0101' => '8929',  '0110' => '7813',  '0111' =>  '6944',
       					'1000' =>  '5208', '1001' => '4167',  '1010' => '2976',  '1011' =>  '1736',
       					'1100' =>  '1042', '1101' =>  '694',  '1110' =>  '401',  '1111' =>   '100');
       				my %TMD3 = ('0' => 'Std', '1' => 'Sin');
       				my %BV = ('0' => '2.0V', '1' => '2.3V');

					my $MOSI_TMD1 = substr($dataMOSI, 14, 2);
					my $MOSI_TMD2 = substr($dataMOSI, 10, 4);
					my $MOSI_TMD3 = substr($dataMOSI, 9, 1);
					my $MOSI_BV4 = substr($dataMOSI, 8, 1);

                    $out_MOSI_Data = $MOSI_BV4 . ":" . $MOSI_TMD3 . ":" . $MOSI_TMD2 . ":" . $MOSI_TMD1;                                    
                    $out_MOSI_Value = $BV{$MOSI_BV4} . ":" . $TMD3{$MOSI_TMD3} . ":" .  $TMD2{$MOSI_TMD2} . ":" . $TMD1{$MOSI_TMD1};
                	$out_MISO_Data = "-" . $out_MISO_Data . "-";                
                }
                elsif ($out_Command eq 'PROG_FILT_SETTINGS') {
       				my %ECLK = ('00' => '4mHz', '01' => '2mHz', '10' => '1mHz');
       				my %FLT = ('00' => '5-20kHz', '01' => '6-18kHz', '10' => '1,2-20kHz', '11' => '5-15kHz');

					my $MOSI_FLT1 = substr($dataMOSI, 14, 2);
					my $MOSI_ECLK2 = substr($dataMOSI, 12, 2);
					my $MOSI_FLT3 = substr($dataMOSI, 10, 2);
					my $MOSI_ECLK4 = substr($dataMOSI, 8, 2);

                    $out_MOSI_Data = $MOSI_ECLK4 . ":" . $MOSI_FLT3 . ":" . $MOSI_ECLK2 . ":" . $MOSI_FLT1; 
                    $out_MOSI_Value = $ECLK{$MOSI_ECLK4} . ":" . $FLT{$MOSI_FLT3} . ":" . $ECLK{$MOSI_ECLK2} . ":" . $FLT{$MOSI_FLT1}; 
                	$out_MISO_Data = "-" . $out_MISO_Data . "-";                
                }
                elsif ($out_Command eq 'RD_FILT_SETTINGS') {
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                

       				my %ECLK = ('00' => '4mHz', '01' => '2mHz', '10' => '1mHz');
       				my %FLT = ('00' => '5-20kHz', '01' => '6-18kHz', '10' => '1,2-20kHz', '11' => '5-15kHz');

					my $MISO_FLT1 = substr($dataMISO, 14, 2);
					my $MISO_ECLK2 = substr($dataMISO, 12, 2);
					my $MISO_FLT3 = substr($dataMISO, 10, 2);
					my $MISO_ECLK4 = substr($dataMISO, 8, 2);

                    $out_MISO_Data = $MISO_ECLK4 . ":" . $MISO_FLT3 . ":" . $MISO_ECLK2 . ":" . $MISO_FLT1; 
                    $out_MISO_Value = $ECLK{$MISO_ECLK4} . ":" . $FLT{$MISO_FLT3} . ":" . $ECLK{$MISO_ECLK2} . ":" . $FLT{$MISO_FLT1}; 
                }
                elsif ($out_Command eq 'DE_LINEAR_INTERPOL') {
       				my %LIN = ('0' => 'Off', '1' => 'On');
					my $MOSI_LIN1 = substr($dataMOSI, 15, 1);
					my $MOSI_S2 = substr($dataMOSI, 8, 7);

                    $out_MOSI_Data = "-" . $MOSI_S2 . ":" . $MOSI_LIN1; 
                    $out_MOSI_Value = $LIN{$MOSI_LIN1}; 

                	$out_MISO_Data = "-" . $out_MISO_Data . "-";                
                }
                elsif ($out_Command eq 'PROG_SID') {
					my $MOSI_S1 = substr($dataMOSI, 13, 3);
					my $MOSI_S2 = substr($dataMOSI, 10, 3);
					my $MOSI_S3 = substr($dataMOSI, 8, 2);
                    my $ID_S1 = sprintf("%X", int8($MOSI_S1));
                    my $ID_S2 = sprintf("%X", int8($MOSI_S2));

                    $out_MOSI_Data = "-" . $MOSI_S3 . "-" . $MOSI_S2 . ":" . $MOSI_S1;                
                    $out_MOSI_Value = $ID_S2 . ":" . $ID_S1;

                	$out_MISO_Data = "-" . $out_MISO_Data . "-";                
                }
                elsif ($out_Command eq 'RD_SID')
                {
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                

					my $MISO_S1 = substr($dataMISO, 13, 3);
					my $MISO_S2 = substr($dataMISO, 10, 3);
					my $MISO_S3 = substr($dataMISO, 8, 2);
                    my $ID_S1 = sprintf("%X", int8($MISO_S1));
                    my $ID_S2 = sprintf("%X", int8($MISO_S2));

                    $out_MISO_Data = "-". $MISO_S3 . "-" . $MISO_S2 . ":" . $MISO_S1;                
                    $out_MISO_Value = $ID_S2 . ":" . $ID_S1;
                }
                elsif ($out_Command eq 'RD_NOISE_OFFSET') {					
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                
                    $out_MISO_Value = uint8($out_MISO_Data);
                }
                elsif ($out_Command eq 'PRO_SEL') {
                    $out_MOSI_Value = sprintf("%#02x", int8($out_MOSI_Data));
                	$out_MISO_Data = "-" . $out_MISO_Data . "-";                
                }
                elsif ($out_Command eq 'DE_SOFTRESET') {
                	$out_MISO_Data = "-" . $out_MISO_Data . "-";                
                }
                elsif ($out_Command eq 'END_OF_PROG') {
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                
                	$out_MISO_Data = "-" . $out_MISO_Data . "-";                
                }
                elsif ($out_Command eq 'RD_SELF_TEST_REF1') {					
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                
                    $out_MISO_Value = int8($out_MISO_Data);
                }	
                elsif ($out_Command eq 'RD_SELF_TEST_REF2') {					
                	$out_MOSI_Data = "-" . $out_MOSI_Data . "-";                
                    $out_MISO_Value = int8($out_MISO_Data);
                }
                else {
                    #$grid1->SetRowAttr($RowCnt, $attr_color{light_Red});
                }
}
  
#*********************************************************************
 # CG147 decoder
#*********************************************************************
elsif ($out_sensor eq 'CG147') {                       
                if ($out_Command eq "READ_PSI") {
                    $OutputToGrid = 0;
                }
                if ($out_Command eq "WD2_TRIGGER") {
                    $out_MOSI_Value = sprintf("%#02x", int8($out_MOSI_Data));
                    $out_MISO_Value = sprintf("%#02x", int8( $out_MISO_Data));
                }
                if ($out_Command eq 'END_ENABLE') {
                    $OutputToGrid = 0;
                }
                if ($out_Command eq "ENABLE_PROG") {
                    $out_MOSI_Data = (substr($dataMOSI, 8, 6) . "-" .
                                      substr($dataMOSI, 14, 1) . ":" .
                                      substr($dataMOSI, 15, 1));                
                }
                if ($out_Command eq "PROG_SDIS_CH") {
                    $out_MOSI_Data =~ s/(\d)\B/$1:/g;   
                    $out_MISO_Data =~ s/(\d)\B/$1:/g;   
                }
                if ($out_Command eq "WD3_TRIGGER") {
                    $out_MOSI_Value = sprintf("%#02x", int8($out_MOSI_Data));
                    $out_MISO_Value = sprintf("%#02x", int8( $out_MISO_Data));
                }
                if ($out_Command eq "READ_WD_STATUS") {
                    $out_MISO_Data = substr($dataMISO, 8, 8);
                    $out_MISO_Data =~ s/(\d)\B/$1:/g;   
                }
                if ($out_Command eq "FLM_TEST_SRC") {
                    $out_MOSI_Value = sprintf("%d", int8($out_MOSI_Data));
                    $out_MISO_Value = $out_MOSI_Value . "              ";
                }
                if ($out_Command eq "FLM_TEST_SINK"){
                    $out_MOSI_Value = sprintf("%d", int8($out_MOSI_Data));
                    $out_MISO_Value = $out_MOSI_Value . "              ";
                }
                if ($out_Command eq "AOUT_CTRL") {
    				my %CG147_AOUT_CTRL = (
    					"000000" => "VST33/2",	"000001" => "VST50/2",	"000010" => "VST33/2",
				        "000011" => "Temp",		"000100" => "AGND",		"000101" => "SQREF",
				        "000110" => "AVST33",	"000111" => "VSYNC/8",	"001000" => "PSI1/6",
				        "001001" => "PSI2/6",	"001010" => "PSI3/6",	"001011" => "PSI4/6",
				        "001101" => "VDN/14.6",	"001011" => "PSI4/6",	"010000" => "IGH1",
				 		"010001" => "IGH2",		"010010" => "IGH3",		"010011" => "IGH4",
				 		"010100" => "IGL1",     "010101" => "IGL2",		"010110" => "IGL3",
				 		"010111" => "IGL4",     "011000" => "ER1/10",	"011001" => "ER2/10",
				 		"100000" => "IGH5",		"100001" => "IGH6",		"100010" => "IGH7",
				 		"100011" => "IGH8",		"100100" => "IGL5",		"100101" => "IGL6",
				 		"100110" => "IGL7",     "100111" => "IGL8",		"101000" => "ER3/10",
				 		"101001" => "ER4/10",	"110000" => "IGH9",		"110001" => "IGH10",
				 		"110010" => "IGH11",	"110011" => "IGH12",	"110100" => "IGL9",
				 		"110101" => "IGL10",	"110110" => "IGL11",	"110111" => "IGL12",
				 		"111000" => "ER5/10",	"111001" => "ER6/10");

                    my $ch = substr($dataMOSI, 10, 6);
 
                    if (defined $CG147_AOUT_CTRL{$ch}) {
                        if ($CG147_AOUT_CTRL{$ch} =~ m/IGH/) {
                            #$grid1->SetCellBackgroundColour($RowCnt, $col_MISO_Value, Wx::Colour->new(@light_Blue));
                        }
                        if ($CG147_AOUT_CTRL{$ch} =~ m/IGL/) {
                            #$grid1->SetCellBackgroundColour($RowCnt, $col_MISO_Value, Wx::Colour->new(@light_Blue1));
                        }
                        $out_MOSI_Value = $CG147_AOUT_CTRL{$ch};
                    }
                    else {
                        $out_MOSI_Value = "";
                    }
                	$out_MISO_Data = "-" . $out_MISO_Data . "-";                
                }
                if ($out_Command eq "START_ADC") {
                    $out_MOSI_Data = (substr($dataMOSI,  8, 2) . ":" .
                                      substr($dataMOSI, 10, 1) . "-" .
                                      substr($dataMOSI, 11, 1) . ":" .
                                      substr($dataMOSI, 12, 4));                    
                }                      
                if ($out_Command eq "READ_ADC") {
                    $out_MOSI_Data = (substr($dataMOSI,  8, 7) . "-" .
                                      substr($dataMOSI, 15, 1));                    

                    $out_MISO_Value = int8($out_MISO_Data);
                }                                      
}
            
            #$status = "In Progress! Please wait..";
	  		#$main->update();
            $writtenflag ++;

} 
$sensorOldValue{$out_sensor}{$out_Command} = $dataMISO;           
} # all sensor select

   #*********************************************************************
   # output to grid
   #*********************************************************************

   if ($OutputToGrid != 0) {
 
   			#*********************************************************************
			# Excel handling
			#*********************************************************************	
			# Define the format and add it to the worksheet
			my $format = $workbook->add_format(
				#center_across => 1,
				bold => 0,
				size => 10,
				border => 1,
				color => 'black',
				bg_color => 'white',
				border_color => 'black',
				align => 'vcenter',
				font => 'Segoe UI Light',
				#num_format => 1,
			);
			
			my $format_error = $workbook->add_format(
				#center_across => 1,
				bold => 0,
				size => 10,
				border => 1,
				color => 'black',
				bg_color => 'red',
				border_color => 'black',
				align => 'vcenter',
				font => 'Segoe UI Light',
				#num_format => 1,
			);
        	
        	#*********************************************************************
			# Command Color
			#*********************************************************************	                        
            my $commandColor = $Mapping->{$filetype}{$out_Command}{'color'};
            if (defined $commandColor and defined $attr_color_excel{$commandColor}){
            	$format->set_bg_color($attr_color_excel{$commandColor});
            	$format_error->set_bg_color($attr_color_excel{$commandColor});
            }          	
	        elsif (defined $comColor{$out_sensor}{$out_Command}) {
	            # set color for ASIC specific command
	            my $color = $comColor{$out_sensor}{$out_Command};
    	        $format->set_bg_color($attr_color_excel{$color});
    	        $format_error->set_bg_color($attr_color_excel{$color});
        	}
        	else{
        		$format->set_bg_color($attr_color_excel{white});
        		$format_error->set_bg_color($attr_color_excel{white});
        	}
        	
        	if (defined $out_MISO_Stat and $statOldValue{$out_sensor} ne $out_MISO_Stat) {
                $format_error->set_bg_color($attr_color_excel{Red});
            }
            
            # calculate time between commands
            $out_relTime = sprintf("%.3f", ($out_absTime - $last_absTime));
            $last_absTime = $out_absTime;

            if ( ($out_comLine - $last_comLine) > 1 ) {
                # mark comLine with red if command(s) are not displayed
                #$grid1->SetCellTextColour($RowCnt, $col_comLine, wxRED);
            }
            $last_comLine = $out_comLine;

			$worksheet_decoded->write($RowCnt,$col_absTime, $out_absTime, $format); 
			$worksheet_decoded->write($RowCnt,$col_relTime, $out_relTime, $format);			    
			$worksheet_decoded->write($RowCnt,$col_cycTime, $out_cycTime, $format);
			$worksheet_decoded->write($RowCnt,$col_comLine, $out_comLine, $format);   
			$worksheet_decoded->write($RowCnt,$col_comCnt, $out_comCnt, $format);
			$worksheet_decoded->write($RowCnt,$col_ASIC, $out_sensor, $format);		
			$worksheet_decoded->write($RowCnt,$col_module, $out_module, $format);			
			$worksheet_decoded->write($RowCnt,$col_Command, $out_Command, $format);	
			#print "processing command $out_Command for $out_sensor\n";
			$worksheet_decoded->write($RowCnt,$col_MOSI_Data, "-".$out_MOSI_Data."-", $format) if defined $out_MOSI_Data;	
			$worksheet_decoded->write($RowCnt,$col_MOSI_Value, $out_MOSI_Value, $format);				
			$worksheet_decoded->write($RowCnt,$col_MISO_Stat, $out_MISO_Stat, $format_error);	
			$worksheet_decoded->write($RowCnt,$col_MISO_SID, $out_MISO_SID, $format);	    
			$worksheet_decoded->write($RowCnt,$col_MISO_Data, "-".$out_MISO_Data."-", $format) if defined $out_MISO_Data;	  
			$worksheet_decoded->write($RowCnt,$col_MISO_Value, $out_MISO_Value, $format);	
                 
            $commandCycTime{$out_sensor}{$out_Command} = $out_absTime;
            $statOldValue{$out_sensor} = $out_MISO_Stat;

            $OutputToGrid = 0;
            $RowCnt++; 

   			if ($RowCnt == $maxRows){
   				print "Reached max limit for number of rows in excel sheet. No more lines will be decoded. Rows: $RowCnt";
   				$worksheet_decoded->write($RowCnt+1,$col_absTime, "Reached max number of rows. No further decoding!", $format);
   			}
            
        } 
		
    } #close while
   
if( $self{Statistics} == 1){  
   	 	my $RowCnt1 = 1;

   	 	$worksheet_statistics->write(0,0, "Command", $format_head);
	    $worksheet_statistics->write(0,1, "Counter", $format_head);
	    $worksheet_statistics->write(0,2, "T_0", $format_head);
	    $worksheet_statistics->write(0,3, "T_1", $format_head);
	    $worksheet_statistics->write(0,4, "T_2", $format_head);
	    $worksheet_statistics->write(0,5, "T_3", $format_head);
	    $worksheet_statistics->write(0,6, "T_4", $format_head);
	    $worksheet_statistics->write(0,7, "T_5", $format_head);
	    $worksheet_statistics->write(0,8, "T_6", $format_head);
	    $worksheet_statistics->write(0,9, "T_7", $format_head);
	    $worksheet_statistics->write(0,10, "T_8", $format_head);
	    $worksheet_statistics->write(0,11, "T_last", $format_head);
    
    	while (my ($k1, $v1) = each %commandCounter) {

	        $worksheet_statistics->write($RowCnt1,0, $k1, $format_head);	
	        $RowCnt1++;
	        
	        for my $k2 (sort {$$v1{$a}->[1] <=> $$v1{$b}->[1]} keys %$v1) {         
         		#*********************************************************************
				# Excel handling
				#*********************************************************************	
				# Define the format and add it to the worksheet
				my $format = $workbook->add_format(
				#center_across => 1,
				bold => 0,
				size => 10,
				border => 1,
				color => 'black',
				bg_color => 'white',
				border_color => 'black',
				align => 'vcenter',
				font => 'Segoe UI Light',
				#num_format => 1,
				);
	            
	            #*********************************************************************
				# Command Color
				#*********************************************************************	                        
	            my $commandColor = $Mapping->{$filetype}{$k2}{'color'};
	            if (defined $commandColor and defined $attr_color_excel{$commandColor}){
	            	$format->set_bg_color($attr_color_excel{$commandColor});
	            }          	
		        elsif (defined $comColor{$k1}{$k2}) {
		            # set color for ASIC specific command
		            my $color = $comColor{$k1}{$k2};
	    	        $format->set_bg_color($attr_color_excel{$color});
	        	}
	        	else{
	        		$format->set_bg_color("white");
	        	}
	        	
	            $worksheet_statistics->write($RowCnt1,0, $k2, $format);	
	            my $TimeStamps = $$v1{$k2};
	            my $ColCnt1 = 1;            
	            foreach my $entry (@$TimeStamps) {
	               	$worksheet_statistics->write($RowCnt1,$ColCnt1, $entry, $format);	
	                $ColCnt1++;
	            }
	            $RowCnt1++;
	    	}		
     	} #close while
   	} #close if

 }# close main else 


close(FILEHANDLE);
$workbook->close();

if($writtenflag >= 1){
	$status = "Finished";	
	$main->update();				
}
elsif($writtenflag == 0){
	$status = "No match found :-( \nThe selected module is not present in the spi trace";
	$main->update();
}
	
} #close sub


sub int8 {
    my $int8_ch = shift;
    my $int8_bin = "0b" . $int8_ch;
    my $int8 = oct($int8_bin);
    return ($int8);
}

sub uint8 {
    my $int8_ch = shift;
    my $int8_bin = "0b" . $int8_ch;
    my $int8 = oct($int8_bin);

    my $uint8;
    if ($int8 >= 128) { 
        $uint8 = $int8 - 256;
    } 
    else {
        $uint8 = $int8;
    } 
    return ($uint8);
}

sub int10 {
    my $int10_ch = shift;
    my $int10_bin = "0b" . $int10_ch;
    my $int10 = oct($int10_bin);
    return ($int10);
}

sub uint10 {
    my $int10_ch = shift;
    my $int10_bin = "0b" . $int10_ch;
    my $int10 = oct($int10_bin);

    my $uint10;
    if ($int10 >= 512) { 
        $uint10 = $int10 - 1024;
    } 
    else {
        $uint10 = $int10;
    } 
    return ($uint10);
}


sub int16 {
    my $int16_ch = shift;
    my $int16_bin = "0b" . $int16_ch;
    my $int16 = oct($int16_bin);
    return ($int16);
}

sub uint16 {
    my $int16_ch = shift;
    my $int16_bin = "0b" . $int16_ch;
    my $int16 = oct($int16_bin);

    my $uint16;
    if ($int16 >= 32768) { 
        $uint16 = $int16 - 65536;
    } 
    else {
        $uint16 = $int16;
    } 
    return ($uint16);
}

sub int12 {
    my $int12_ch = shift;
    my $int12_bin = "0b" . $int12_ch;
    my $int12 = oct($int12_bin);
    return ($int12);
}

sub uint12 {
    my $int12_ch = shift;
    my $int12_bin = "0b" . $int12_ch;
    my $int12 = oct($int12_bin);

    my $uint12;
    if ($int12 >= 2048) { 
        $uint12 = $int12 - 4096;
    } 
    else {
        $uint12 = $int12;
    } 
    return ($uint12);
}
	

__END__
