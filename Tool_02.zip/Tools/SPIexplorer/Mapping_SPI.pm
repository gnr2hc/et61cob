package Mapping_SPI;

#$VERSION = q$Revision: 1.12 $;
#$HEADER = q$Header: SPIexplorer/Mapping_SPI.pm 1.12 2014/09/11 13:33:35ICT ver6cob develop  $;

# SPI commands used for decoding of QuaTe and IDEfix SPI monitor traces
$Mapping = {
	
'AB12' => {
	
	  ####################################################################################
      #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<   IXS MAPPING   >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
      ####################################################################################
	
		'IXS_MAPPING' => { # chip select mapping for Idefix and SPImaid (SPI & PAS-line) records
							'CS0'  => 'CG904_SA1', #AB12 system asic 1
							'CS1'  => 'CG904_SA2', #AB12 system asic 2
	                        'CS3'  => 'SMG100',
	                        'CS4'  => 'CF190',
	                        'CS5'  => 'SMB200',
	                        'CS6'  => 'CG143',
	                        'CS7'  => 'SMA560P',
	                        'CS8'  => 'CS8',
	                        'CS9'  => 'CS9',
	                        'CS10' => 'CS10',
	                        'CS11' => 'CS11',
	                        'CS12' => 'EEPROM',
	                        'CS13' => 'EEPROMdata',
	                        'CS15' => 'LA',                   
						},
	  ####################################################################################
      #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< FRAME FORMAT >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
      ####################################################################################		
							
	  #AB12 commands - length in bits
	  'frame_length' => '32',
      'instruction_length' => '10',
      'data_length' => '16',

	  'CG904_SA1_FORMAT' => { #start bit numbers and length (start from LHS bit 0)
	  						'MOSI_data_start' => '11',
	  						'MOSI_data_length' => '16',
	  						'MISO_data_start' => '12',
	  						'MISO_data_length' => '16',
	  						'MISO_SID_start' => '7',
	  						'MISO_SID_length' => '5',
	  						'MISO_Stat_start' => '0',
	  						'MISO_Stat_length' => '6',
	  						
	  					 },
	  					 
	  'CG904_SA2_FORMAT' => { #start bit numbers and length (start from LHS bit 0)
	  						'MOSI_data_start' => '11',
	  						'MOSI_data_length' => '16',
	  						'MISO_data_start' => '12',
	  						'MISO_data_length' => '16',
	  						'MISO_SID_start' => '7',
	  						'MISO_SID_length' => '5',
	  						'MISO_Stat_start' => '0',
	  						'MISO_Stat_length' => '6',
	  						
	  					 },					 	  				
								
	  'CG904_SA3_FORMAT' => { #start bit numbers and length (start from LHS bit 0)
	  						'MOSI_data_start' => '11',
	  						'MOSI_data_length' => '16',
	  						'MISO_data_start' => '12',
	  						'MISO_data_length' => '16',
	  						'MISO_SID_start' => '7',
	  						'MISO_SID_length' => '5',
	  						'MISO_Stat_start' => '0',
	  						'MISO_Stat_length' => '6',
	  						
	  					 },									
	  ####################################################################################
      #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< SENSOR  COMMANDS >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
      ####################################################################################
      
        'CG904_SA1_COMMAND' => {
						'0000000000' =>'READ_DEV_ID',	
						'0000000001' =>'READ_REV_ID',
						'0000000010'=>'READ_MASK_ID',	
						'0000000011'=>'ENABLE_PROG',
						'0000000110'=>'EOP',
						'0000000100'=>'WD2_TRIGGER',
						'0000000101'=>'WD3_TRIGGER',
						'0000000111'=>'WD_STATUS',
						'0000001000'=>'AIO_CURR1',	
						'0000001001'=>'AIO_CURR2',	
						'0000001010'=>'AIO_STATUS',	
						'0000001011'=>'AINO_START_AUTO',
						'0100010000'=>'AINO_READ_AUTO1',
						'0100010001'=>'AINO_READ_AUTO2',
						'0100010010'=>'AINO_READ_AUTO3',
						'0100010011'=>'AINO_READ_AUTO4',
						'0100010100'=>'AINO_READ_AUTO5',
						'0100010101'=>'AINO_READ_AUTO6',
						'0100010110'=>'AINO_READ_AUTO7',
						'0100010111'=>'AINO_READ_AUTO8',
						'0100011000'=>'AINO_READ_AUTO9',
						'0100011001'=>'AINO_READ_AUTO10',
						'0100011010'=>'AINO_READ_AUTO11',
						'0100011011'=>'AINO_READ_AUTO12',
						#'0100011101'=>'AINO_READ_AUTO12',
						'0000001100'=>'AINO_START_BIST',
						'0100100000'=>'AINO_READ_BIST1',
						'0100100001'=>'AINO_READ_BIST2',
						'0100100010'=>'AINO_READ_BIST3',
						'0100100011'=>'AINO_READ_BIST4',
						'0100100100'=>'AINO_READ_BIST5',
						'0100100101'=>'AINO_READ_BIST6',
						'0100100110'=>'AINO_READ_BIST7',
						'0000111000'=>'ADC_START_FLM',	
						'0000111001'=>'ADC_START_AINO',	
						'0000111010'=>'ADC_START_POM',	
						'0000111011'=>'ADC_START_AUX',	
						'0000111100'=>'ADC_READ_FLM',	
						'0000111101'=>'ADC_READ_AINO',	
						'0000111110'=>'ADC_READ_POM',	
						'0000111111'=>'ADC_READ_AUX',	
						'0000001111'=>'READ_MON_ID',
						'0000010000'=>'DISPOSAL',	
						'0000010001'=>'DEMAND_TEST',	
						'0000010010'=>'THRES_TEST_DATA',	
						'0000010011'=>'THRES_TEST_SID',	
						'0000010100'=>'END_ENABLE',	
						'0000110101'=>'DISABLE_STATUS',
						'0000010101'=>'FLM_STATUS',	
						'0000010110'=>'FLM_HS_ON',	
						'0000010111'=>'FLM_LS_ON',	
						'0000011000'=>'FLM_TEST_MAN',	
						'0000011001'=>'FLM_TEST_TG',	
						'0000011010'=>'FLM_UNLOCK',
						'0100110000'=>'FLM_READ_FIRE_CNT1',
						'0100110001'=>'FLM_READ_FIRE_CNT2',
						'0100110010'=>'FLM_READ_FIRE_CNT3',
						'0100110011'=>'FLM_READ_FIRE_CNT4',
						'0100110100'=>'FLM_READ_FIRE_CNT5',
						'0100110101'=>'FLM_READ_FIRE_CNT6',
						'0100110110'=>'FLM_READ_FIRE_CNT7',
						'0100110111'=>'FLM_READ_FIRE_CNT8',
						'0100111000'=>'FLM_READ_FIRE_CNT9',
						'0100111001'=>'FLM_READ_FIRE_CNT10',
						'0100111010'=>'FLM_READ_FIRE_CNT11',
						'0100111011'=>'FLM_READ_FIRE_CNT12',
						'0100111100'=>'FLM_READ_FIRE_CNT13',
						'0100111101'=>'FLM_READ_FIRE_CNT14',
						'0100111110'=>'FLM_READ_FIRE_CNT15',	
						'0100111111'=>'FLM_READ_FIRE_CNT16',
						'0000011011'=>'FLM_CLEAR_FIRE_CNT',	
						'0000011100'=>'FLM_DIAG_MASK',	
						'0000011101'=>'FLM_START_DIAG',	
						'0101000000'=>'FLM_READ_RES1',
						'0101000001'=>'FLM_READ_RES2',
						'0101000010'=>'FLM_READ_RES3',
						'0101000011'=>'FLM_READ_RES4',
						'0101000100'=>'FLM_READ_RES5',
						'0101000101'=>'FLM_READ_RES6',
						'0101000110'=>'FLM_READ_RES7',
						'0101000111'=>'FLM_READ_RES8',
						'0101001000'=>'FLM_READ_RES9',
						'0101001001'=>'FLM_READ_RES10',
						'0101001010'=>'FLM_READ_RES11',
						'0101001011'=>'FLM_READ_RES12',
						'0101001100'=>'FLM_READ_RES13',
						'0101001101'=>'FLM_READ_RES14',
						'0101001110'=>'FLM_READ_RES15',
						'0101001111'=>'FLM_READ_RES16',
						'0101010000'=>'FLM_READ_VH1',
						'0101010001'=>'FLM_READ_VH2',
						'0101010010'=>'FLM_READ_VH3',
						'0101010011'=>'FLM_READ_VH4',
						'0101010100'=>'FLM_READ_VH5',
						'0101010101'=>'FLM_READ_VH6',
						'0101010110'=>'FLM_READ_VH7',
						'0101010111'=>'FLM_READ_VH8',
						'0101011000'=>'FLM_READ_CAP',	
						'0101011100'=>'FLM_READ_PST',	
						'0101011010'=>'FLM_READ_SVR',	
						'0101011011'=>'FLM_READ_CC',
						'0101011001'=>'FLM_READ_SQB',	
						'0001000110'=>'FLM_READ_IGH',
						'0101011111'=>'FLM_READ_MAN',	
						'0101101000'=>'FLM_READ_SHORT1',
						'0101101001'=>'FLM_READ_SHORT2',
						'0101101010'=>'FLM_READ_SHORT3',
						'0101101011'=>'FLM_READ_SHORT4',
						'0000011110'=>'PSI_SUPPLY',
						'0000110100'=>'PSI_READ_LEV',	
						'1000000000'=>'PSI_READ_DATA1',	
						'1000010000'=>'PSI_READ_DATA2',		
						'1000100000'=>'PSI_READ_DATA3',		
						'1000110000'=>'PSI_READ_DATA4',		
						'1001000000'=>'PSI_READ_DATA5',		
						'1001010000'=>'PSI_READ_DATA6',		
						'1001100000'=>'PSI_READ_DATA7',		
						'1001110000'=>'PSI_READ_DATA8',		
						'1010000000'=>'PSI_READ_DATA9',		
						'1010010000'=>'PSI_READ_DATA10',		
						'1010100000'=>'PSI_READ_DATA11',		
						'1010110000'=>'PSI_READ_DATA12',		
						'1011000000'=>'PSI_READ_DATA13',		
						'1011010000'=>'PSI_READ_DATA14',		
						'1011100000'=>'PSI_READ_DATA15',		
						'1011110000'=>'PSI_READ_DATA16',		
						'1100000000'=>'PSI_READ_DATA17',		
						'1100010000'=>'PSI_READ_DATA18',		
						'1100100000'=>'PSI_READ_DATA19',		
						'1100110000'=>'PSI_READ_DATA20',		
						'1101000000'=>'PSI_READ_DATA21',		
						'1101010000'=>'PSI_READ_DATA22',		
						'1101100000'=>'PSI_READ_DATA23',		
						'1101110000'=>'PSI_READ_DATA24',
						'0000011111'=>'PSI_SYNC_GEN',	
						'0000100000'=>'PSI_SYNC_MASK',	
						'0000100001'=>'PSI_IQ_STATUS',	
						'0000100010'=>'PSI_TEST_CONS',	
						'0000100011'=>'PSI_START_CC',
						'0000100100'=>'PSI_READ_CC',
						'0000100101'=>'PSI_READ_SC',	
						'0101100101'=>'PSI_READ_SCALE1',
						'0101100110'=>'PSI_READ_SCALE2',
						'0101100111'=>'PSI_READ_SCALE3',
						'0001000111'=>'POM_CONVERTER',
						'0000100110'=>'POM_CYCL_CAP',	
						'0000100111'=>'POM_STATUS',	
						'0000101000'=>'POM_VER_CURR',	
						'0000101001'=>'POM_START_BIST',	
						'0000101010'=>'POM_READ_BIST',	
						'0000101011'=>'POM_START_AUTO',
						'0101110000'=>'POM_READ_AUTO1',
						'0101110001'=>'POM_READ_AUTO2',
						'0101110010'=>'POM_READ_AUTO3',
						'0101110011'=>'POM_READ_AUTO4',	
						'0101110100'=>'POM_READ_AUTO5',
						'0000101100'=>'LIN_CURR',	
						'0000110110'=>'LIN_STATUS',	
						'0000101101'=>'AOUT_CTRL',	
						'0000101110'=>'OTP_CMD',
						'0000101111'=>'OTP_CONF',	
						'0000110001'=>'TESTMODE',	
						'0000110010'=>'TEST_PLP_THRES',	
						'0000110011'=>'TEST_PLP_DATA',	
						'0000110111'=>'TEST_PSI',	
						'01011011--'=>'TEST_FLM',	
						'0110010000'=>'PROG_AINO_CONF1',
						'0110010001'=>'PROG_AINO_CONF2',
						'0110010010'=>'PROG_AINO_CONF3',
						'0110010011'=>'PROG_AINO_CONF4',
						'0110010100'=>'PROG_AINO_CONF5',
						'0110010101'=>'PROG_AINO_CONF6',
						'0110010110'=>'PROG_AINO_CONF7',
						'0110010111'=>'PROG_AINO_CONF8',
						'0110011000'=>'PROG_AINO_CONF9',
						'0110011001'=>'PROG_AINO_CONF10',
						'0110011010'=>'PROG_AINO_CONF11',
						'0110011011'=>'PROG_AINO_CONF12',
						#'0110011100'=>'PROG_AINO_CONF12',
						'0110000000'=>'PROG_AIO_WL',
						'0110100000'=>'PROG_SAF_CH1',
						'0110100001'=>'PROG_SAF_CH2',
						'0110100010'=>'PROG_SAF_CH3',
						'0110100011'=>'PROG_SAF_CH4',
						'0110100100'=>'PROG_SAF_CH5',
						'0110100101'=>'PROG_SAF_CH6',
						'0110100110'=>'PROG_SAF_CH7',
						'0110100111'=>'PROG_SAF_CH8',
						'0110101000'=>'PROG_SAF_CH9',
						'0110101001'=>'PROG_SAF_CH10',
						'0110101010'=>'PROG_SAF_CH11',
						'0110101011'=>'PROG_SAF_CH12',
						'0110101100'=>'PROG_SAF_CH13',
						'0110101101'=>'PROG_SAF_CH14',
						'0110101110'=>'PROG_SAF_CH15',
						'0110101111'=>'PROG_SAF_CH16',
						'0110000001'=>'PROG_SDIS_X',	
						'0110000010'=>'PROG_SDIS_Y',	
						'0110000011'=>'PROG_SDIS_W',	
						'0110000100'=>'PROG_SDIS_S',
						'0110000101'=>'PROG_SAFETY',
						'0110000110'=>'PROG_SW_MODE',	
						'0110000111'=>'PROG_SW_UP_THRES',	
						'0110001000'=>'PROG_SW_LOW_THRES',	
						'0110001001'=>'PROG_XY45',	
						'0110111000'=>'PROG_PLP_LONG',
						'0110001010'=>'PROG_FLM_CONF',
						'0110001101'=>'PROG_FLM_MODE',
						'0111000001'=>'PROG_PSI_SID1',
						'0111000010'=>'PROG_PSI_SID2',
						'0111000011'=>'PROG_PSI_SID3',
						'0111000100'=>'PROG_PSI_SID4',
						'0111000101'=>'PROG_PSI_SID5',
						'0111000110'=>'PROG_PSI_SID6',
						'0111000111'=>'PROG_PSI_SID7',
						'0111001000'=>'PROG_PSI_SID8',
						'0111001001'=>'PROG_PSI_SID9',
						'0111001010'=>'PROG_PSI_SID10',
						'0111001011'=>'PROG_PSI_SID11',
						'0111001100'=>'PROG_PSI_SID12',
						'0111001101'=>'PROG_PSI_SID13',
						'0111001110'=>'PROG_PSI_SID14',
						'0111001111'=>'PROG_PSI_SID15',
						'0111010000'=>'PROG_PSI_SID16',
						'0111010001'=>'PROG_PSI_SID17',
						'0111010010'=>'PROG_PSI_SID18',
						'0111010011'=>'PROG_PSI_SID19',
						'0111010100'=>'PROG_PSI_SID20',
						'0111010101'=>'PROG_PSI_SID21',
						'0111010110'=>'PROG_PSI_SID22',
						'0111010111'=>'PROG_PSI_SID23',
						'0111011000'=>'PROG_PSI_SID24',						
						'0110110000'=>'PROG_PSI_LINE1',
						'0110110001'=>'PROG_PSI_LINE2',
						'0110110010'=>'PROG_PSI_LINE3',
						'0110110011'=>'PROG_PSI_LINE4',
						'0110110100'=>'PROG_PSI_LINE5',
						'0110110101'=>'PROG_PSI_LINE6',
						'0110001011'=>'PROG_PSI_MODE',	
						'0110001100'=>'PROG_POM',
						'0000000000'=>'READ_DEV_ID',	
						'1---------'=>'READ_SENSOR',
						'1000010000'=>'READ_SENSOR1', #temp
						'1001010000'=>'READ_SENSOR2', #temp
						'1010000000'=>'READ_SENSOR3', #temp	
						'1010010000'=>'READ_SENSOR4', #temp	
						'1010100000'=>'READ_SENSOR5', #temp	
						'1011000000'=>'READ_SENSOR6', #temp	
						'1011010000'=>'READ_SENSOR7', #temp	
						'1011100000'=>'READ_SENSOR8', #temp	
						'0000010001'=>'DEMAND_TEST',	
						'0000000'=>'READ_DEV_ID_16',	
						'1-----0'=>'READ_SENSOR_16',
						'0011100'=>'DEMAND_TEST_16',
						'0001000000'=>'AIO1_STATUS',
						'0001000001'=>'AIO2_STATUS',
						'0001000101'=>'AIO_LIN_EN',
						'0001000100'=>'LIN_PWM',
						'0110001110'=>'PROG_AIO1',
						'0110001111'=>'PROG_AIO2',
						'0110000000'=>'PROG_LIN',

						
                        },
                        
		'CG904_SA2_COMMAND' => {
						'0000000000' =>'READ_DEV_ID',	
						'0000000001' =>'READ_REV_ID',
						'0000000010'=>'READ_MASK_ID',	
						'0000000011'=>'ENABLE_PROG',
						'0000000110'=>'EOP',
						'0000000100'=>'WD2_TRIGGER',
						'0000000101'=>'WD3_TRIGGER',
						'0000000111'=>'WD_STATUS',
						'0000001000'=>'AIO_CURR1',	
						'0000001001'=>'AIO_CURR2',	
						'0000001010'=>'AIO_STATUS',	
						'0000001011'=>'AINO_START_AUTO',
						'0100010000'=>'AINO_READ_AUTO1',
						'0100010001'=>'AINO_READ_AUTO2',
						'0100010010'=>'AINO_READ_AUTO3',
						'0100010011'=>'AINO_READ_AUTO4',
						'0100010100'=>'AINO_READ_AUTO5',
						'0100010101'=>'AINO_READ_AUTO6',
						'0100010110'=>'AINO_READ_AUTO7',
						'0100010111'=>'AINO_READ_AUTO8',
						'0100011000'=>'AINO_READ_AUTO9',
						'0100011001'=>'AINO_READ_AUTO10',
						'0100011010'=>'AINO_READ_AUTO11',
						'0100011011'=>'AINO_READ_AUTO12',
						#'0100011101'=>'AINO_READ_AUTO12',
						'0000001100'=>'AINO_START_BIST',	
						'0100100000'=>'AINO_READ_BIST1',
						'0100100001'=>'AINO_READ_BIST2',
						'0100100010'=>'AINO_READ_BIST3',
						'0100100011'=>'AINO_READ_BIST4',
						'0100100100'=>'AINO_READ_BIST5',
						'0100100101'=>'AINO_READ_BIST6',
						'0100100110'=>'AINO_READ_BIST7',	
						'0000111000'=>'ADC_START_FLM',	
						'0000111001'=>'ADC_START_AINO',	
						'0000111010'=>'ADC_START_POM',	
						'0000111011'=>'ADC_START_AUX',	
						'0000111100'=>'ADC_READ_FLM',	
						'0000111101'=>'ADC_READ_AINO',	
						'0000111110'=>'ADC_READ_POM',	
						'0000111111'=>'ADC_READ_AUX',	
						'0000001111'=>'READ_MON_ID',
						'0000010000'=>'DISPOSAL',	
						'0000010001'=>'DEMAND_TEST',	
						'0000010010'=>'THRES_TEST_DATA',	
						'0000010011'=>'THRES_TEST_SID',	
						'0000010100'=>'END_ENABLE',	
						'0000110101'=>'DISABLE_STATUS',
						'0000010101'=>'FLM_STATUS',	
						'0000010110'=>'FLM_HS_ON',	
						'0000010111'=>'FLM_LS_ON',	
						'0000011000'=>'FLM_TEST_MAN',	
						'0000011001'=>'FLM_TEST_TG',	
						'0000011010'=>'FLM_UNLOCK',
						'0100110000'=>'FLM_READ_FIRE_CNT1',
						'0100110001'=>'FLM_READ_FIRE_CNT2',
						'0100110010'=>'FLM_READ_FIRE_CNT3',
						'0100110011'=>'FLM_READ_FIRE_CNT4',
						'0100110100'=>'FLM_READ_FIRE_CNT5',
						'0100110101'=>'FLM_READ_FIRE_CNT6',
						'0100110110'=>'FLM_READ_FIRE_CNT7',
						'0100110111'=>'FLM_READ_FIRE_CNT8',
						'0100111000'=>'FLM_READ_FIRE_CNT9',
						'0100111001'=>'FLM_READ_FIRE_CNT10',
						'0100111010'=>'FLM_READ_FIRE_CNT11',
						'0100111011'=>'FLM_READ_FIRE_CNT12',
						'0100111100'=>'FLM_READ_FIRE_CNT13',
						'0100111101'=>'FLM_READ_FIRE_CNT14',
						'0100111110'=>'FLM_READ_FIRE_CNT15',	
						'0100111111'=>'FLM_READ_FIRE_CNT16',
						'0000011011'=>'FLM_CLEAR_FIRE_CNT',	
						'0000011100'=>'FLM_DIAG_MASK',	
						'0000011101'=>'FLM_START_DIAG',	
						'0101000000'=>'FLM_READ_RES1',
						'0101000001'=>'FLM_READ_RES2',
						'0101000010'=>'FLM_READ_RES3',
						'0101000011'=>'FLM_READ_RES4',
						'0101000100'=>'FLM_READ_RES5',
						'0101000101'=>'FLM_READ_RES6',
						'0101000110'=>'FLM_READ_RES7',
						'0101000111'=>'FLM_READ_RES8',
						'0101001000'=>'FLM_READ_RES9',
						'0101001001'=>'FLM_READ_RES10',
						'0101001010'=>'FLM_READ_RES11',
						'0101001011'=>'FLM_READ_RES12',
						'0101001100'=>'FLM_READ_RES13',
						'0101001101'=>'FLM_READ_RES14',
						'0101001110'=>'FLM_READ_RES15',
						'0101001111'=>'FLM_READ_RES16',
						'0101010000'=>'FLM_READ_VH1',
						'0101010001'=>'FLM_READ_VH2',
						'0101010010'=>'FLM_READ_VH3',
						'0101010011'=>'FLM_READ_VH4',
						'0101010100'=>'FLM_READ_VH5',
						'0101010101'=>'FLM_READ_VH6',
						'0101010110'=>'FLM_READ_VH7',
						'0101010111'=>'FLM_READ_VH8',
						'0101011000'=>'FLM_READ_CAP',	
						'0101011100'=>'FLM_READ_PST',	
						'0101011010'=>'FLM_READ_SVR',	
						'0101011011'=>'FLM_READ_CC',
						'0101011001'=>'FLM_READ_SQB',	
						'0001000110'=>'FLM_READ_IGH',
						'0101011111'=>'FLM_READ_MAN',	
						'0101101000'=>'FLM_READ_SHORT1',
						'0101101001'=>'FLM_READ_SHORT2',
						'0101101010'=>'FLM_READ_SHORT3',
						'0101101011'=>'FLM_READ_SHORT4',
						'0000011110'=>'PSI_SUPPLY',
						'0000110100'=>'PSI_READ_LEV',	
						'1000000000'=>'PSI_READ_DATA1',	
						'1000010000'=>'PSI_READ_DATA2',		
						'1000100000'=>'PSI_READ_DATA3',		
						'1000110000'=>'PSI_READ_DATA4',		
						'1001000000'=>'PSI_READ_DATA5',		
						'1001010000'=>'PSI_READ_DATA6',		
						'1001100000'=>'PSI_READ_DATA7',		
						'1001110000'=>'PSI_READ_DATA8',		
						'1010000000'=>'PSI_READ_DATA9',		
						'1010010000'=>'PSI_READ_DATA10',		
						'1010100000'=>'PSI_READ_DATA11',		
						'1010110000'=>'PSI_READ_DATA12',		
						'1011000000'=>'PSI_READ_DATA13',		
						'1011010000'=>'PSI_READ_DATA14',		
						'1011100000'=>'PSI_READ_DATA15',		
						'1011110000'=>'PSI_READ_DATA16',		
						'1100000000'=>'PSI_READ_DATA17',		
						'1100010000'=>'PSI_READ_DATA18',		
						'1100100000'=>'PSI_READ_DATA19',		
						'1100110000'=>'PSI_READ_DATA20',		
						'1101000000'=>'PSI_READ_DATA21',		
						'1101010000'=>'PSI_READ_DATA22',		
						'1101100000'=>'PSI_READ_DATA23',		
						'1101110000'=>'PSI_READ_DATA24',	
						'0000011111'=>'PSI_SYNC_GEN',	
						'0000100000'=>'PSI_SYNC_MASK',	
						'0000100001'=>'PSI_IQ_STATUS',	
						'0000100010'=>'PSI_TEST_CONS',	
						'0000100011'=>'PSI_START_CC',
						'0000100100'=>'PSI_READ_CC',
						'0000100101'=>'PSI_READ_SC',	
						'0101100101'=>'PSI_READ_SCALE1',
						'0101100110'=>'PSI_READ_SCALE2',
						'0101100111'=>'PSI_READ_SCALE3',
						'0001000111'=>'POM_CONVERTER',
						'0000100110'=>'POM_CYCL_CAP',	
						'0000100111'=>'POM_STATUS',	
						'0000101000'=>'POM_VER_CURR',	
						'0000101001'=>'POM_START_BIST',	
						'0000101010'=>'POM_READ_BIST',	
						'0000101011'=>'POM_START_AUTO',
						'0101110000'=>'POM_READ_AUTO1',
						'0101110001'=>'POM_READ_AUTO2',
						'0101110010'=>'POM_READ_AUTO3',
						'0101110011'=>'POM_READ_AUTO4',	
						'0101110100'=>'POM_READ_AUTO5',	
						'0000101100'=>'LIN_CURR',	
						'0000110110'=>'LIN_STATUS',	
						'0000101101'=>'AOUT_CTRL',	
						'0000101110'=>'OTP_CMD',
						'0000101111'=>'OTP_CONF',	
						'0000110001'=>'TESTMODE',	
						'0000110010'=>'TEST_PLP_THRES',	
						'0000110011'=>'TEST_PLP_DATA',	
						'0000110111'=>'TEST_PSI',	
						'01011011--'=>'TEST_FLM',	
						'0110010000'=>'PROG_AINO_CONF1',
						'0110010001'=>'PROG_AINO_CONF2',
						'0110010010'=>'PROG_AINO_CONF3',
						'0110010011'=>'PROG_AINO_CONF4',
						'0110010100'=>'PROG_AINO_CONF5',
						'0110010101'=>'PROG_AINO_CONF6',
						'0110010110'=>'PROG_AINO_CONF7',
						'0110010111'=>'PROG_AINO_CONF8',
						'0110011000'=>'PROG_AINO_CONF9',
						'0110011001'=>'PROG_AINO_CONF10',
						'0110011010'=>'PROG_AINO_CONF11',
						'0110011011'=>'PROG_AINO_CONF12',
						#'0110011100'=>'PROG_AINO_CONF12',
						'0110000000'=>'PROG_AIO_WL',
						'0110100000'=>'PROG_SAF_CH1',
						'0110100001'=>'PROG_SAF_CH2',
						'0110100010'=>'PROG_SAF_CH3',
						'0110100011'=>'PROG_SAF_CH4',
						'0110100100'=>'PROG_SAF_CH5',
						'0110100101'=>'PROG_SAF_CH6',
						'0110100110'=>'PROG_SAF_CH7',
						'0110100111'=>'PROG_SAF_CH8',
						'0110101000'=>'PROG_SAF_CH9',
						'0110101001'=>'PROG_SAF_CH10',
						'0110101010'=>'PROG_SAF_CH11',
						'0110101011'=>'PROG_SAF_CH12',
						'0110101100'=>'PROG_SAF_CH13',
						'0110101101'=>'PROG_SAF_CH14',
						'0110101110'=>'PROG_SAF_CH15',
						'0110101111'=>'PROG_SAF_CH16',
						'0110000001'=>'PROG_SDIS_X',	
						'0110000010'=>'PROG_SDIS_Y',	
						'0110000011'=>'PROG_SDIS_W',	
						'0110000100'=>'PROG_SDIS_S',
						'0110000101'=>'PROG_SAFETY',
						'0110000110'=>'PROG_SW_MODE',	
						'0110000111'=>'PROG_SW_UP_THRES',	
						'0110001000'=>'PROG_SW_LOW_THRES',	
						'0110001001'=>'PROG_XY45',	
						'0110001010'=>'PROG_FLM_CONF',
						'0110001101'=>'PROG_FLM_MODE',
						'0111000001'=>'PROG_PSI_SID1',
						'0111000010'=>'PROG_PSI_SID2',
						'0111000011'=>'PROG_PSI_SID3',
						'0111000100'=>'PROG_PSI_SID4',
						'0111000101'=>'PROG_PSI_SID5',
						'0111000110'=>'PROG_PSI_SID6',
						'0111000111'=>'PROG_PSI_SID7',
						'0111001000'=>'PROG_PSI_SID8',
						'0111001001'=>'PROG_PSI_SID9',
						'0111001010'=>'PROG_PSI_SID10',
						'0111001011'=>'PROG_PSI_SID11',
						'0111001100'=>'PROG_PSI_SID12',
						'0111001101'=>'PROG_PSI_SID13',
						'0111001110'=>'PROG_PSI_SID14',
						'0111001111'=>'PROG_PSI_SID15',
						'0111010000'=>'PROG_PSI_SID16',
						'0111010001'=>'PROG_PSI_SID17',
						'0111010010'=>'PROG_PSI_SID18',
						'0111010011'=>'PROG_PSI_SID19',
						'0111010100'=>'PROG_PSI_SID20',
						'0111010101'=>'PROG_PSI_SID21',
						'0111010110'=>'PROG_PSI_SID22',
						'0111010111'=>'PROG_PSI_SID23',
						'0111011000'=>'PROG_PSI_SID24',						
						'0110110000'=>'PROG_PSI_LINE1',
						'0110110001'=>'PROG_PSI_LINE2',
						'0110110010'=>'PROG_PSI_LINE3',
						'0110110011'=>'PROG_PSI_LINE4',
						'0110110100'=>'PROG_PSI_LINE5',
						'0110110101'=>'PROG_PSI_LINE6',
						'0110001011'=>'PROG_PSI_MODE',	
						'0110001100'=>'PROG_POM',
						'0000000000'=>'READ_DEV_ID',	
						'1---------'=>'READ_SENSOR',
						'1000010000'=>'READ_SENSOR1', #temp
						'1001010000'=>'READ_SENSOR2', #temp
						'1010000000'=>'READ_SENSOR3', #temp	
						'1010010000'=>'READ_SENSOR4', #temp	
						'1010100000'=>'READ_SENSOR5', #temp	
						'1011000000'=>'READ_SENSOR6', #temp	
						'1011010000'=>'READ_SENSOR7', #temp	
						'1011100000'=>'READ_SENSOR8', #temp	
						'0000010001'=>'DEMAND_TEST',	
						'0000000'=>'READ_DEV_ID_16',	
						'1-----0'=>'READ_SENSOR_16',
						'0011100'=>'DEMAND_TEST_16',	
						'0001000000'=>'AIO1_STATUS',
						'0001000001'=>'AIO2_STATUS',						
						'0001000101'=>'AIO_LIN_EN',
						'0001000100'=>'LIN_PWM',
						'0110001110'=>'PROG_AIO1',
						'0110001111'=>'PROG_AIO2',
						'0110000000'=>'PROG_LIN',

                        },  

        'CG904_SA3_COMMAND' => {
						'0000000000' =>'READ_DEV_ID',	
						'0000000001' =>'READ_REV_ID',
						'0000000010'=>'READ_MASK_ID',	
						'0000000011'=>'ENABLE_PROG',
						'0000000110'=>'EOP',
						'0000000100'=>'WD2_TRIGGER',
						'0000000101'=>'WD3_TRIGGER',
						'0000000111'=>'WD_STATUS',
						'0000001000'=>'AIO_CURR1',	
						'0000001001'=>'AIO_CURR2',	
						'0000001010'=>'AIO_STATUS',	
						'0000001011'=>'AINO_START_AUTO',
						'0100010000'=>'AINO_READ_AUTO1',
						'0100010001'=>'AINO_READ_AUTO2',
						'0100010010'=>'AINO_READ_AUTO3',
						'0100010011'=>'AINO_READ_AUTO4',
						'0100010100'=>'AINO_READ_AUTO5',
						'0100010101'=>'AINO_READ_AUTO6',
						'0100010110'=>'AINO_READ_AUTO7',
						'0100010111'=>'AINO_READ_AUTO8',
						'0100011000'=>'AINO_READ_AUTO9',
						'0100011001'=>'AINO_READ_AUTO10',
						'0100011010'=>'AINO_READ_AUTO11',
						'0100011011'=>'AINO_READ_AUTO12',
						#'0100011101'=>'AINO_READ_AUTO12',
						'0000001100'=>'AINO_START_BIST',	
						'0100100000'=>'AINO_READ_BIST1',
						'0100100001'=>'AINO_READ_BIST2',
						'0100100010'=>'AINO_READ_BIST3',
						'0100100011'=>'AINO_READ_BIST4',
						'0100100100'=>'AINO_READ_BIST5',
						'0100100101'=>'AINO_READ_BIST6',
						'0100100110'=>'AINO_READ_BIST7',	
						'0000111000'=>'ADC_START_FLM',	
						'0000111001'=>'ADC_START_AINO',	
						'0000111010'=>'ADC_START_POM',	
						'0000111011'=>'ADC_START_AUX',	
						'0000111100'=>'ADC_READ_FLM',	
						'0000111101'=>'ADC_READ_AINO',	
						'0000111110'=>'ADC_READ_POM',	
						'0000111111'=>'ADC_READ_AUX',	
						'0000001111'=>'READ_MON_ID',
						'0000010000'=>'DISPOSAL',	
						'0000010001'=>'DEMAND_TEST',	
						'0000010010'=>'THRES_TEST_DATA',	
						'0000010011'=>'THRES_TEST_SID',	
						'0000010100'=>'END_ENABLE',	
						'0000110101'=>'DISABLE_STATUS',
						'0000010101'=>'FLM_STATUS',	
						'0000010110'=>'FLM_HS_ON',	
						'0000010111'=>'FLM_LS_ON',	
						'0000011000'=>'FLM_TEST_MAN',	
						'0000011001'=>'FLM_TEST_TG',	
						'0000011010'=>'FLM_UNLOCK',
						'0100110000'=>'FLM_READ_FIRE_CNT1',
						'0100110001'=>'FLM_READ_FIRE_CNT2',
						'0100110010'=>'FLM_READ_FIRE_CNT3',
						'0100110011'=>'FLM_READ_FIRE_CNT4',
						'0100110100'=>'FLM_READ_FIRE_CNT5',
						'0100110101'=>'FLM_READ_FIRE_CNT6',
						'0100110110'=>'FLM_READ_FIRE_CNT7',
						'0100110111'=>'FLM_READ_FIRE_CNT8',
						'0100111000'=>'FLM_READ_FIRE_CNT9',
						'0100111001'=>'FLM_READ_FIRE_CNT10',
						'0100111010'=>'FLM_READ_FIRE_CNT11',
						'0100111011'=>'FLM_READ_FIRE_CNT12',
						'0100111100'=>'FLM_READ_FIRE_CNT13',
						'0100111101'=>'FLM_READ_FIRE_CNT14',
						'0100111110'=>'FLM_READ_FIRE_CNT15',	
						'0100111111'=>'FLM_READ_FIRE_CNT16',
						'0000011011'=>'FLM_CLEAR_FIRE_CNT',	
						'0000011100'=>'FLM_DIAG_MASK',	
						'0000011101'=>'FLM_START_DIAG',	
						'0101000000'=>'FLM_READ_RES1',
						'0101000001'=>'FLM_READ_RES2',
						'0101000010'=>'FLM_READ_RES3',
						'0101000011'=>'FLM_READ_RES4',
						'0101000100'=>'FLM_READ_RES5',
						'0101000101'=>'FLM_READ_RES6',
						'0101000110'=>'FLM_READ_RES7',
						'0101000111'=>'FLM_READ_RES8',
						'0101001000'=>'FLM_READ_RES9',
						'0101001001'=>'FLM_READ_RES10',
						'0101001010'=>'FLM_READ_RES11',
						'0101001011'=>'FLM_READ_RES12',
						'0101001100'=>'FLM_READ_RES13',
						'0101001101'=>'FLM_READ_RES14',
						'0101001110'=>'FLM_READ_RES15',
						'0101001111'=>'FLM_READ_RES16',
						'0101010000'=>'FLM_READ_VH1',
						'0101010001'=>'FLM_READ_VH2',
						'0101010010'=>'FLM_READ_VH3',
						'0101010011'=>'FLM_READ_VH4',
						'0101010100'=>'FLM_READ_VH5',
						'0101010101'=>'FLM_READ_VH6',
						'0101010110'=>'FLM_READ_VH7',
						'0101010111'=>'FLM_READ_VH8',
						'0101011000'=>'FLM_READ_CAP',	
						'0101011100'=>'FLM_READ_PST',	
						'0101011010'=>'FLM_READ_SVR',	
						'0101011011'=>'FLM_READ_CC',
						'0101011001'=>'FLM_READ_SQB',	
						'0001000110'=>'FLM_READ_IGH',
						'0101011111'=>'FLM_READ_MAN',	
						'0101101000'=>'FLM_READ_SHORT1',
						'0101101001'=>'FLM_READ_SHORT2',
						'0101101010'=>'FLM_READ_SHORT3',
						'0101101011'=>'FLM_READ_SHORT4',
						'0000011110'=>'PSI_SUPPLY',
						'0000110100'=>'PSI_READ_LEV',	
						'1000000000'=>'PSI_READ_DATA1',	
						'1000010000'=>'PSI_READ_DATA2',		
						'1000100000'=>'PSI_READ_DATA3',		
						'1000110000'=>'PSI_READ_DATA4',		
						'1001000000'=>'PSI_READ_DATA5',		
						'1001010000'=>'PSI_READ_DATA6',		
						'1001100000'=>'PSI_READ_DATA7',		
						'1001110000'=>'PSI_READ_DATA8',		
						'1010000000'=>'PSI_READ_DATA9',		
						'1010010000'=>'PSI_READ_DATA10',		
						'1010100000'=>'PSI_READ_DATA11',		
						'1010110000'=>'PSI_READ_DATA12',		
						'1011000000'=>'PSI_READ_DATA13',		
						'1011010000'=>'PSI_READ_DATA14',		
						'1011100000'=>'PSI_READ_DATA15',		
						'1011110000'=>'PSI_READ_DATA16',		
						'1100000000'=>'PSI_READ_DATA17',		
						'1100010000'=>'PSI_READ_DATA18',		
						'1100100000'=>'PSI_READ_DATA19',		
						'1100110000'=>'PSI_READ_DATA20',		
						'1101000000'=>'PSI_READ_DATA21',		
						'1101010000'=>'PSI_READ_DATA22',		
						'1101100000'=>'PSI_READ_DATA23',		
						'1101110000'=>'PSI_READ_DATA24',
						'0000011111'=>'PSI_SYNC_GEN',	
						'0000100000'=>'PSI_SYNC_MASK',	
						'0000100001'=>'PSI_IQ_STATUS',	
						'0000100010'=>'PSI_TEST_CONS',	
						'0000100011'=>'PSI_START_CC',
						'0000100100'=>'PSI_READ_CC',
						'0000100101'=>'PSI_READ_SC',	
						'0101100101'=>'PSI_READ_SCALE1',
						'0101100110'=>'PSI_READ_SCALE2',
						'0101100111'=>'PSI_READ_SCALE3',
						'0001000111'=>'POM_CONVERTER',
						'0000100110'=>'POM_CYCL_CAP',	
						'0000100111'=>'POM_STATUS',	
						'0000101000'=>'POM_VER_CURR',	
						'0000101001'=>'POM_START_BIST',	
						'0000101010'=>'POM_READ_BIST',	
						'0000101011'=>'POM_START_AUTO',
						'0101110000'=>'POM_READ_AUTO1',
						'0101110001'=>'POM_READ_AUTO2',
						'0101110010'=>'POM_READ_AUTO3',
						'0101110011'=>'POM_READ_AUTO4',	
						'0101110100'=>'POM_READ_AUTO5',
						'0000101100'=>'LIN_CURR',	
						'0000110110'=>'LIN_STATUS',	
						'0000101101'=>'AOUT_CTRL',	
						'0000101110'=>'OTP_CMD',
						'0000101111'=>'OTP_CONF',	
						'0000110001'=>'TESTMODE',	
						'0000110010'=>'TEST_PLP_THRES',	
						'0000110011'=>'TEST_PLP_DATA',	
						'0000110111'=>'TEST_PSI',	
						'01011011--'=>'TEST_FLM',	
						'0110010000'=>'PROG_AINO_CONF1',
						'0110010001'=>'PROG_AINO_CONF2',
						'0110010010'=>'PROG_AINO_CONF3',
						'0110010011'=>'PROG_AINO_CONF4',
						'0110010100'=>'PROG_AINO_CONF5',
						'0110010101'=>'PROG_AINO_CONF6',
						'0110010110'=>'PROG_AINO_CONF7',
						'0110010111'=>'PROG_AINO_CONF8',
						'0110011000'=>'PROG_AINO_CONF9',
						'0110011001'=>'PROG_AINO_CONF10',
						'0110011010'=>'PROG_AINO_CONF11',
						'0110011011'=>'PROG_AINO_CONF12',
						#'0110011100'=>'PROG_AINO_CONF12',
						'0110000000'=>'PROG_AIO_WL',
						'0110100000'=>'PROG_SAF_CH1',
						'0110100001'=>'PROG_SAF_CH2',
						'0110100010'=>'PROG_SAF_CH3',
						'0110100011'=>'PROG_SAF_CH4',
						'0110100100'=>'PROG_SAF_CH5',
						'0110100101'=>'PROG_SAF_CH6',
						'0110100110'=>'PROG_SAF_CH7',
						'0110100111'=>'PROG_SAF_CH8',
						'0110101000'=>'PROG_SAF_CH9',
						'0110101001'=>'PROG_SAF_CH10',
						'0110101010'=>'PROG_SAF_CH11',
						'0110101011'=>'PROG_SAF_CH12',
						'0110101100'=>'PROG_SAF_CH13',
						'0110101101'=>'PROG_SAF_CH14',
						'0110101110'=>'PROG_SAF_CH15',
						'0110101111'=>'PROG_SAF_CH16',
						'0110000001'=>'PROG_SDIS_X',	
						'0110000010'=>'PROG_SDIS_Y',	
						'0110000011'=>'PROG_SDIS_W',	
						'0110000100'=>'PROG_SDIS_S',
						'0110000101'=>'PROG_SAFETY',
						'0110000110'=>'PROG_SW_MODE',	
						'0110000111'=>'PROG_SW_UP_THRES',	
						'0110001000'=>'PROG_SW_LOW_THRES',	
						'0110001001'=>'PROG_XY45',	
						'0110001010'=>'PROG_FLM_CONF',
						'0110001101'=>'PROG_FLM_MODE',
						'0111000001'=>'PROG_PSI_SID1',
						'0111000010'=>'PROG_PSI_SID2',
						'0111000011'=>'PROG_PSI_SID3',
						'0111000100'=>'PROG_PSI_SID4',
						'0111000101'=>'PROG_PSI_SID5',
						'0111000110'=>'PROG_PSI_SID6',
						'0111000111'=>'PROG_PSI_SID7',
						'0111001000'=>'PROG_PSI_SID8',
						'0111001001'=>'PROG_PSI_SID9',
						'0111001010'=>'PROG_PSI_SID10',
						'0111001011'=>'PROG_PSI_SID11',
						'0111001100'=>'PROG_PSI_SID12',
						'0111001101'=>'PROG_PSI_SID13',
						'0111001110'=>'PROG_PSI_SID14',
						'0111001111'=>'PROG_PSI_SID15',
						'0111010000'=>'PROG_PSI_SID16',
						'0111010001'=>'PROG_PSI_SID17',
						'0111010010'=>'PROG_PSI_SID18',
						'0111010011'=>'PROG_PSI_SID19',
						'0111010100'=>'PROG_PSI_SID20',
						'0111010101'=>'PROG_PSI_SID21',
						'0111010110'=>'PROG_PSI_SID22',
						'0111010111'=>'PROG_PSI_SID23',
						'0111011000'=>'PROG_PSI_SID24',						
						'0110110000'=>'PROG_PSI_LINE1',
						'0110110001'=>'PROG_PSI_LINE2',
						'0110110010'=>'PROG_PSI_LINE3',
						'0110110011'=>'PROG_PSI_LINE4',
						'0110110100'=>'PROG_PSI_LINE5',
						'0110110101'=>'PROG_PSI_LINE6',
						'0110001011'=>'PROG_PSI_MODE',	
						'0110001100'=>'PROG_POM',
						'0000000000'=>'READ_DEV_ID',	
						'1---------'=>'READ_SENSOR',
						'1000010000'=>'READ_SENSOR1', #temp
						'1001010000'=>'READ_SENSOR2', #temp
						'1010000000'=>'READ_SENSOR3', #temp	
						'1010010000'=>'READ_SENSOR4', #temp	
						'1010100000'=>'READ_SENSOR5', #temp	
						'1011000000'=>'READ_SENSOR6', #temp	
						'1011010000'=>'READ_SENSOR7', #temp	
						'1011100000'=>'READ_SENSOR8', #temp	
						'0000010001'=>'DEMAND_TEST',	
						'0000000'=>'READ_DEV_ID_16',	
						'1-----0'=>'READ_SENSOR_16',
						'0011100'=>'DEMAND_TEST_16',
						'0001000000'=>'AIO1_STATUS',
						'0001000001'=>'AIO2_STATUS',
						'0001000100'=>'LIN_PWM',
						'0110001110'=>'PROG_AIO1',
						'0110001111'=>'PROG_AIO2',
						'0110000000'=>'PROG_LIN',
				
                        },						
                        
      ####################################################################################
      #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<  COMMAND MAPPING >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
      ####################################################################################    
      
      
      'modules' => ['ALL','SPI','WD','AINO','ADC','POM','MON','SAM','FLM','PSI','LIN','AOUT','OTP','TEST'],                   				

                'READ_DEV_ID_16'=>	{
                                'CODE'=> '0000000',
								'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'SPI',
                                'color'=>'',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
								'platform'=>'AB12',
                                'color' => '',
                                'parameter_1'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                },

                'READ_DEV_ID'=> {
                                'CODE'=> '0000000000',
                                'description'=>'Read device identifier',
                                'datasize'=> '16',
                                'module'=>'SPI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
								'platform'=>'AB12',
                                'color' => 'light_Oker',
                                'parameter_1'=>    {
                                                        'name'=>'device_id', 'startbit'=>'0', 'length'=>'8', 'group'=>'MISO', '11000010'=>'CG902:C2', '11000011'=>'CG903:C3', '11000100'=>'CG904:C4', 
                                                        },
                                 },

                'READ_REV_ID'=> {
                                'CODE'=> '0000000001',
                                'description'=>'Read revision identifier',
                                'datasize'=> '16',
                                'module'=>'SPI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
								'platform'=>'AB12',
                                'color' => 'light_Oker',
                                'parameter_1'=>    {
                                                        'name'=>'revision_id', 'startbit'=>'0', 'length'=>'4', 'group'=>'MISO', '0100' => 'revision_id',
                                                        },
                                },

                'READ_MASK_ID'=>        {
                                'CODE'=> '0000000010',
                                'description'=>'Read mask identifier',
								'datasize'=> '16',
                                'module'=>'SPI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
								'platform'=>'AB12',
                                'color' => 'light_Green',
                                'parameter_1'=>    {
                                                        'name'=>'mask_id', 'startbit'=>'0', 'length'=>'4', 'group'=>'MISO', '0100' => 'mask_id', 
                                                        },
                                },
				
				'EOP'=> {
                                'CODE'=> '0000000110',
                                'description'=>'na',
								'datasize'=> '16',
                                'module'=>'SPI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
								'platform'=>'AB12',
                                'color' => 'light_Green',
                                'parameter_1'=>    {
                                                        'name'=>'e1', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1' => 'release SDIS_X, SDIS_Y, SDIS_W and SDIS_S signals from 0 (EOP1)',
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'e2', 'startbit'=>'1', 'length'=>'1', 'group'=>'MOSI', '1' => 'all programmable SPI registers will be locked (EOP2)', 
														},
								'parameter_3'=>    {
                                                        'name'=>'E1', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1' => 'release SDIS_X, SDIS_Y, SDIS_W and SDIS_S signals from 0 (EOP1)',
                                                        },
                                'parameter_4'=>    {
                                                        'name'=>'E2', 'startbit'=>'1', 'length'=>'1', 'group'=>'MISO', '1' => 'all programmable SPI registers will be locked (EOP2)', 
														},	
								'parameter_5'=>    {
                                                        'name'=>'TM', 'startbit'=>'2', 'length'=>'1', 'group'=>'MISO',
														},							
                                },

                'ENABLE_PROG'=> {
                                'CODE'=> '0000000011',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'na',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Oker',
                                'parameter_1'=>    {
                                                        'name'=>'se', 'startbit'=>'0', 'length'=>'1', 'group'=>'na', '1' => 'single enable = enables programming for the next SPI programming instruction only',
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'ge', 'startbit'=>'1', 'length'=>'1', 'group'=>'na', '1' => 'general enable = enables programming generally (default)',
                                                        },
                                },

                'WD2_TRIGGER'=> {
                                'CODE'=> '0000000100',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'WD',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Oker',
                                'parameter_1'=>    {
                                                        'name'=>'wd2_response', 'startbit'=>'0', 'length'=>'16', 'group'=>'MOSI', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'wd2_checkword', 'startbit'=>'0', 'length'=>'16', 'group'=>'MISO', 
                                                        },
                                },

                'WD3_TRIGGER'=> {
                                'CODE'=> '0000000101',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'WD',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Oker',
                                'parameter_1'=>    {
                                                        'name'=>'wd3_response', 'startbit'=>'0', 'length'=>'16', 'group'=>'MOSI', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'wd3_checkword', 'startbit'=>'0', 'length'=>'16', 'group'=>'MISO', 
                                                        },
                                },

                'WD_STATUS'=>   {
                                'CODE'=> '0000000111',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'WD',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Oker',
                                'parameter_1'=>    {
                                                        'name'=>'u1', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1' => 'underflow watchdog1',
                                                        },
								'parameter_2'=>    {
                                                        'name'=>'o1', 'startbit'=>'1', 'length'=>'1', 'group'=>'MISO', '1' => 'overflow watchdog1',
                                                        },	
								'parameter_3'=>    {
                                                        'name'=>'u2', 'startbit'=>'2', 'length'=>'1', 'group'=>'MISO', '1' => 'underflow watchdog2',
                                                        },	
								'parameter_4'=>    {
                                                        'name'=>'o2', 'startbit'=>'3', 'length'=>'1', 'group'=>'MISO', '1' => 'overflow watchdog2',
                                                        },		
								'parameter_5'=>    {
                                                        'name'=>'r2', 'startbit'=>'4', 'length'=>'1', 'group'=>'MISO', '1' => 'response error watchdog2',
                                                        },		
								'parameter_6'=>    {
                                                        'name'=>'o3', 'startbit'=>'5', 'length'=>'1', 'group'=>'MISO', '1' => 'overflow watchdog3',
                                                        },	
								'parameter_7'=>    {
                                                        'name'=>'r3', 'startbit'=>'6', 'length'=>'1', 'group'=>'MISO',  '1' => 'response error watchdog3',
                                                        },	
								'parameter_8'=>    {
                                                        'name'=>'fco', 'startbit'=>'7', 'length'=>'1', 'group'=>'MISO', '0' => 'fault_counter<3','1' => 'fault_counter=3',
                                                        },						
								'parameter_9'=>    {
                                                        'name'=>'faultcnt', 'startbit'=>'8', 'length'=>'2', 'group'=>'MISO', 
                                                        },						
                                'parameter_10'=>    {
                                                        'name'=>'w1', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1' => 'watchdog1 flag (no reset by N_SYS_RES)',
                                                        },
								'parameter_11'=>    {
                                                        'name'=>'w2', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1' => 'watchdog2 flag (no reset by N_SYS_RES)',
                                                        },
                                'parameter_12'=>    {
                                                        'name'=>'w3', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1' => 'watchdog3 flag (no reset by N_SYS_RES)',
                                                        },
								'parameter_13'=>    {
                                                        'name'=>'cr', 'startbit'=>'13', 'length'=>'1', 'group'=>'MISO', 
                                                        },
                                },

                'AIO_CURR1'=>   {
                                'CODE'=> '0000001000',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'AIO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => '',
                                'parameter_1'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                },

                'AIO_CURR2'=>   {
                                'CODE'=> '0000001001',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'AIO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => '',
                                'parameter_1'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                },

                'AIO_STATUS'=>  {
                                'CODE'=> '0000001010',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'AIO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => '',
                                'parameter_1'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                },

                'AINO_START_AUTO'=>     {
                                'CODE'=> '0000001011',
                                'description'=>'Start AIN/AIO automatic measurement:',
                                'datasize'=> '16',
                                'module'=>'AINO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'Light_Purple2',
                                'parameter_1'=>    {'name'=>'EnableAINCh0', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', },
                                'parameter_2'=>    {'name'=>'EnableAINCh1', 'startbit'=>'1', 'length'=>'1', 'group'=>'MOSI', },
								'parameter_3'=>    {'name'=>'EnableAINCh2', 'startbit'=>'2', 'length'=>'1', 'group'=>'MOSI', },
								'parameter_4'=>    {'name'=>'EnableAINCh3', 'startbit'=>'3', 'length'=>'1', 'group'=>'MOSI', },
								'parameter_5'=>    {'name'=>'EnableAINCh4', 'startbit'=>'4', 'length'=>'1', 'group'=>'MOSI', },
								'parameter_6'=>    {'name'=>'EnableAINCh5', 'startbit'=>'5', 'length'=>'1', 'group'=>'MOSI', },
								'parameter_7'=>    {'name'=>'EnableAINCh6', 'startbit'=>'6', 'length'=>'1', 'group'=>'MOSI', },
								'parameter_8'=>    {'name'=>'EnableAINCh7', 'startbit'=>'7', 'length'=>'1', 'group'=>'MOSI', },
								'parameter_9'=>    {'name'=>'EnableAINCh8', 'startbit'=>'8', 'length'=>'1', 'group'=>'MOSI', },
								'parameter_10'=>    {'name'=>'EnableAINCh9', 'startbit'=>'9', 'length'=>'1', 'group'=>'MOSI', },
								'parameter_11'=>    {'name'=>'EnableAIOCh10', 'startbit'=>'10', 'length'=>'1', 'group'=>'MOSI', },
								'parameter_12'=>    {'name'=>'EnableAIOCh11', 'startbit'=>'11', 'length'=>'1', 'group'=>'MOSI', },
								
                                },

                'AINO_START_BIST'=>     {
                                'CODE'=> '0000001100',
                                'description'=>'Start AIN/AIO build-in self test',
                                'datasize'=> '16',
                                'module'=>'AINO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'Light_Purple2',
                                'parameter_1'=>    {'name'=>'mode', 'startbit'=>'0', 'length'=>'3', 'group'=>'MOSI', '000'=>'stops external cross coupling test slave','001'=>'internal cross coupling test','010'=>'ADC BIST','011'=>'connector capacitor test','100'=>'external cross coupling test master','101'=>'external cross coupling test slave',},
                                'parameter_2'=>    {'name'=>'enableChAIN0', 'startbit'=>'3', 'length'=>'1', 'group'=>'MOSI', },
								'parameter_3'=>    {'name'=>'enableChAIN1', 'startbit'=>'4', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_4'=>    {'name'=>'enableChAIN2', 'startbit'=>'5', 'length'=>'1', 'group'=>'MOSI', },
								'parameter_5'=>    {'name'=>'enableChAIN3', 'startbit'=>'6', 'length'=>'1', 'group'=>'MOSI', },
								'parameter_6'=>    {'name'=>'enableChAIN4', 'startbit'=>'7', 'length'=>'1', 'group'=>'MOSI', },	
								'parameter_7'=>    {'name'=>'enableChAIN5', 'startbit'=>'8', 'length'=>'1', 'group'=>'MOSI', },
								'parameter_8'=>    {'name'=>'enableChAIN6', 'startbit'=>'9', 'length'=>'1', 'group'=>'MOSI', },
								'parameter_9'=>    { 'name'=>'enableChAIN7', 'startbit'=>'10', 'length'=>'1', 'group'=>'MOSI', },
								'parameter_10'=>    {'name'=>'enableChAIN8', 'startbit'=>'11', 'length'=>'1', 'group'=>'MOSI', },
								'parameter_11'=>    { 'name'=>'enableChAIN9', 'startbit'=>'12', 'length'=>'1', 'group'=>'MOSI', },						
                                },

                'READ_MON_ID'=> {
                                'CODE'=> '0000001111',
                                'description'=>'Read monitored identifier',
                                'datasize'=> '16',
                                'module'=>'MON',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'Light_Purple2',
								'parameter_1'=>    {'name'=>'mon_id', 'startbit'=>'0', 'length'=>'8', 'group'=>'MISO',},
                                },

                'DISPOSAL'=>    {
                                'CODE'=> '0000010000',
                                'description'=>'Control disposal function:',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Green',
								'parameter_1'=>    {'name'=>'disposal_code', 'startbit'=>'0', 'length'=>'16', 'group'=>'MOSI', '0000010100000101'=>'DISP1', '0000101000001010'=>'DISP2', '0101000001010000'=>'DISP3', '1010000010100000'=>'DISP4', '1010101010101010'=>'DISP5',},
                                },

                'DEMAND_TEST'=> {
                                'CODE'=> '0000010001',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'TEST',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => '',
								'parameter_1'=>    {'name'=>'thres_test', 'startbit'=>'0', 'length'=>'4', 'group'=>'MOSI', '1111'=>'threshold test for 32 bit frame enabled', '1110'=>'threshold test for 16 bit frame enabled', '0000'=>'disabled'},
								'parameter_2'=>    {'name'=>'pct', 'startbit'=>'4', 'length'=>'1', 'group'=>'MOSI', '0'=>'PSI consistency test mode disabled' , '1'=>'PSI consistency test mode enabled',},
                                },

                'THRES_TEST_DATA'=>     {
                                'CODE'=> '0000010010',
                                'description'=>'Set threshold test data:',
                                'datasize'=> '16',
                                'module'=>'TEST',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => '',
								'parameter_1'=>    {'name'=>'test_data', 'startbit'=>'0', 'length'=>'16', 'group'=>'MOSI','0000000000000000'=>'Default'},
                                },

                'THRES_TEST_SID'=>      {
                                'CODE'=> '0000010011',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'TEST',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => '',
								'parameter_1'=>    {'name'=>'test_sid', 'startbit'=>'0', 'length'=>'5', 'group'=>'MOSI',},
								'parameter_2'=>    {'name'=>'gs', 'startbit'=>'5', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_3'=>    {'name'=>'sd', 'startbit'=>'6', 'length'=>'1', 'group'=>'MOSI', '1'=>'SPI status bit SD is set to zero', '0'=>'SD bit normal function'},
                                },

                'END_ENABLE'=>  {
                                'CODE'=> '0000010100',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Green2',
								'parameter_1'=>    {'name'=>'cf', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '0'=>'clear all low-pass filters of all safety channels'},
								'parameter_2'=>    {'name'=>'tt', 'startbit'=>'1', 'length'=>'1', 'group'=>'MOSI', '0'=>'test timer reduced', '1'=>'test timer not affected'},
                                },

                'FLM_STATUS'=>  {
                                'CODE'=> '0000010101',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'Green',
                                'parameter_1'=>    {'name'=>'d0', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '0'=>'SDIS_S enabled', '1'=>'SDIS_S disabled',},
                                'parameter_2'=>    {'name'=>'d1', 'startbit'=>'1', 'length'=>'1', 'group'=>'MISO', '0'=>'SDIS_W enabled', '1'=>'SDIS_W disabled',},
								'parameter_3'=>    {'name'=>'d2', 'startbit'=>'2', 'length'=>'1', 'group'=>'MISO', '0'=>'SDIS_Y enabled', '1'=>'SDIS_Y disabled',},
								'parameter_4'=>    {'name'=>'d3', 'startbit'=>'3', 'length'=>'1', 'group'=>'MISO', '0'=>'SDIS_X enabled', '1'=>'SDIS_X disabled',},
								'parameter_5'=>    {'name'=>'d4', 'startbit'=>'4', 'length'=>'1', 'group'=>'MISO', '0'=>'DIS_SHP enabled', '1'=>'DIS_SHP disabled',},
								'parameter_6'=>    {'name'=>'d5', 'startbit'=>'5', 'length'=>'1', 'group'=>'MISO', '0'=>'DIS_AHP enabled', '1'=>'DIS_AHP disabled',},
								'parameter_7'=>    {'name'=>'d6', 'startbit'=>'6', 'length'=>'1', 'group'=>'MISO', '0'=>'DIS_ALP enabled', '1'=>'DIS_ALP disabled',},
								'parameter_8'=>    {'name'=>'ulh', 'startbit'=>'7', 'length'=>'1', 'group'=>'MISO', '0'=>'highside locked', '1'=>'highside unlocked',},
								'parameter_9'=>    {'name'=>'ull', 'startbit'=>'8', 'length'=>'1', 'group'=>'MISO', '0'=>'lowside locked', '1'=>'lowside unlocked',},
								'parameter_10'=>    {'name'=>'dh', 'startbit'=>'9', 'length'=>'1', 'group'=>'MISO',},
								'parameter_11'=>    {'name'=>'run', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '0'=>'diagnosis not running', '1'=>'diagnosis running'},
								'parameter_12'=>    {'name'=>'tso', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '0'=>'powerstage testmode not active', '1'=>'powerstage testmode active'},
								'parameter_13'=>    {'name'=>'tss', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '0'=>'powerstage testmode auto switch-off not set', '1'=>'powerstage testmode auto switch-off set'},
                                },

                'FLM_HS_ON'=>   {
                                'CODE'=> '0000010110',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'Green',
                                'parameter_1'=>    {'name'=>'c0', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI',},
                                'parameter_2'=>    {'name'=>'c1', 'startbit'=>'1', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_3'=>    {'name'=>'c2', 'startbit'=>'2', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_4'=>    {'name'=>'c3', 'startbit'=>'3', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_5'=>    {'name'=>'c4', 'startbit'=>'4', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_6'=>    {'name'=>'c5', 'startbit'=>'5', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_7'=>    {'name'=>'c6', 'startbit'=>'6', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_8'=>    {'name'=>'c7', 'startbit'=>'7', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_9'=>    {'name'=>'c8', 'startbit'=>'8', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_10'=>    {'name'=>'c9', 'startbit'=>'9', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_11'=>    {'name'=>'c10', 'startbit'=>'10', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_12'=>    {'name'=>'c11', 'startbit'=>'11', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_13'=>    {'name'=>'c12', 'startbit'=>'12', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_14'=>    {'name'=>'c13', 'startbit'=>'13', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_15'=>    {'name'=>'c14', 'startbit'=>'14', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_16'=>    {'name'=>'c15', 'startbit'=>'15', 'length'=>'1', 'group'=>'MOSI',},
                                },

                'FLM_LS_ON'=>   {
                                'CODE'=> '0000010111',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Green',
                                'parameter_1'=>    {'name'=>'c0', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI',},
                                'parameter_2'=>    {'name'=>'c1', 'startbit'=>'1', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_3'=>    {'name'=>'c2', 'startbit'=>'2', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_4'=>    {'name'=>'c3', 'startbit'=>'3', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_5'=>    {'name'=>'c4', 'startbit'=>'4', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_6'=>    {'name'=>'c5', 'startbit'=>'5', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_7'=>    {'name'=>'c6', 'startbit'=>'6', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_8'=>    {'name'=>'c7', 'startbit'=>'7', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_9'=>    {'name'=>'c8', 'startbit'=>'8', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_10'=>    {'name'=>'c9', 'startbit'=>'9', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_11'=>    {'name'=>'c10', 'startbit'=>'10', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_12'=>    {'name'=>'c11', 'startbit'=>'11', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_13'=>    {'name'=>'c12', 'startbit'=>'12', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_14'=>    {'name'=>'c13', 'startbit'=>'13', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_15'=>    {'name'=>'c14', 'startbit'=>'14', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_16'=>    {'name'=>'c15', 'startbit'=>'15', 'length'=>'1', 'group'=>'MOSI',},
                                },

                'FLM_TEST_MAN'=>        {
                                'CODE'=> '0000011000',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Blue',
                                'parameter_1'=>    {'name'=>'channel', 'startbit'=>'0', 'length'=>'5', 'group'=>'MOSI',},
                                'parameter_2'=>    {'name'=>'src', 'startbit'=>'5', 'length'=>'1', 'group'=>'MOSI', '1'=>'test current source on', '0'=>'test current source off',},
								'parameter_3'=>    {'name'=>'si', 'startbit'=>'6', 'length'=>'1', 'group'=>'MOSI', '1'=>'test current sink on', '0'=>'test current sink off',},
								'parameter_4'=>    {'name'=>'sia', 'startbit'=>'7', 'length'=>'1', 'group'=>'MOSI', '1'=>'all test current sinks on',},
								'parameter_5'=>    {'name'=>'svr', 'startbit'=>'8', 'length'=>'1', 'group'=>'MOSI', '1'=>'svr sink on', '0'=>'svr sink off',},
                                },

                'FLM_TEST_TG'=> {
                                'CODE'=> '0000011001',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Blue',
                                'parameter_1'=>    {'name'=>'channel', 'startbit'=>'0', 'length'=>'4', 'group'=>'MOSI',},
                                'parameter_2'=>    {'name'=>'mode', 'startbit'=>'4', 'length'=>'2', 'group'=>'MOSI', '00'=>'no transmission gate active', '01'=>'IGL transmission gates active', '10'=>'IGH transmission gates active', '11'=>'VHx transmission gates active'},
								'parameter_3'=>    {'name'=>'sqr', 'startbit'=>'6', 'length'=>'1', 'group'=>'MOSI', '1'=>'SQREF transmission gate active'},
								'parameter_4'=>    {'name'=>'adc', 'startbit'=>'7', 'length'=>'2', 'group'=>'MOSI', '00'=>'no ADC measurement', '01'=>'use of FLM sample & hold', '10'=>'normal ADC measurement', '11'=>'ADC measurement with amplification 5 using FLM OPV'},
								'parameter_5'=>    {'name'=>'sh', 'startbit'=>'9', 'length'=>'1', 'group'=>'MOSI', '1'=>'activate FLM sample & hold (sample)', '0'=>'hold'},
                                },

                'FLM_UNLOCK'=>  {
                                'CODE'=> '0000011010',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Red',
                                'parameter_1'=>    {'name'=>'ls', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI','0'=>'lock LS powerstages','1'=>'unlock LS powerstages',},
                                'parameter_2'=>    {'name'=>'hs', 'startbit'=>'1', 'length'=>'1', 'group'=>'MOSI','0'=>'lock HS powerstages','1'=>'unlock HS powerstages',},
                                },

                'FLM_CLEAR_FIRE_CNT'=>  {
                                'CODE'=> '0000011011',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Green',                                
                                },

                'FLM_DIAG_MASK'=>       {
                                'CODE'=> '0000011100',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Oker',
                                'parameter_1'=>    {'name'=>'c0', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI',},
                                'parameter_2'=>    {'name'=>'c1', 'startbit'=>'1', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_3'=>    {'name'=>'c2', 'startbit'=>'2', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_4'=>    {'name'=>'c3', 'startbit'=>'3', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_5'=>    {'name'=>'c4', 'startbit'=>'4', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_6'=>    {'name'=>'c5', 'startbit'=>'5', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_7'=>    {'name'=>'c6', 'startbit'=>'6', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_8'=>    {'name'=>'c7', 'startbit'=>'7', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_9'=>    {'name'=>'c8', 'startbit'=>'8', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_10'=>    {'name'=>'c9', 'startbit'=>'9', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_11'=>    {'name'=>'c10', 'startbit'=>'10', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_12'=>    {'name'=>'c11', 'startbit'=>'11', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_13'=>    {'name'=>'c12', 'startbit'=>'12', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_14'=>    {'name'=>'c13', 'startbit'=>'13', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_15'=>    {'name'=>'c14', 'startbit'=>'14', 'length'=>'1', 'group'=>'MOSI',},
								'parameter_16'=>    {'name'=>'c15', 'startbit'=>'15', 'length'=>'1', 'group'=>'MOSI',},
                                },

                'FLM_START_DIAG'=>      {
                                'CODE'=> '0000011101',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Blue',
                                'parameter_1'=>    {'name'=>'d0', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '0'=>'SDIS_S enabled', '1'=>'SDIS_S disabled',},
                                'parameter_2'=>    {'name'=>'d1', 'startbit'=>'1', 'length'=>'1', 'group'=>'MISO', '0'=>'SDIS_W enabled', '1'=>'SDIS_W disabled',},
								'parameter_3'=>    {'name'=>'d2', 'startbit'=>'2', 'length'=>'1', 'group'=>'MISO', '0'=>'SDIS_Y enabled', '1'=>'SDIS_Y disabled',},
								'parameter_4'=>    {'name'=>'d3', 'startbit'=>'3', 'length'=>'1', 'group'=>'MISO', '0'=>'SDIS_X enabled', '1'=>'SDIS_X disabled',},
								'parameter_5'=>    {'name'=>'d4', 'startbit'=>'4', 'length'=>'1', 'group'=>'MISO', '0'=>'DIS_SHP enabled', '1'=>'DIS_SHP disabled',},
								'parameter_6'=>    {'name'=>'d5', 'startbit'=>'5', 'length'=>'1', 'group'=>'MISO', '0'=>'DIS_AHP enabled', '1'=>'DIS_AHP disabled',},
								'parameter_7'=>    {'name'=>'d6', 'startbit'=>'6', 'length'=>'1', 'group'=>'MISO', '0'=>'DIS_ALP enabled', '1'=>'DIS_ALP disabled',},
								'parameter_8'=>    {'name'=>'ulh', 'startbit'=>'7', 'length'=>'1', 'group'=>'MISO', '0'=>'highside locked', '1'=>'highside unlocked',},
								'parameter_9'=>    {'name'=>'ull', 'startbit'=>'8', 'length'=>'1', 'group'=>'MISO', '0'=>'lowside locked', '1'=>'lowside unlocked',},
								'parameter_10'=>    {'name'=>'dh', 'startbit'=>'9', 'length'=>'1', 'group'=>'MISO',},
								'parameter_11'=>    {'name'=>'run', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '0'=>'diagnosis not running', '1'=>'diagnosis running'},
								'parameter_12'=>    {'name'=>'tso', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '0'=>'powerstage testmode not active', '1'=>'powerstage testmode active'},
								'parameter_13'=>    {'name'=>'tss', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO',},
								'parameter_14'=>    {'name'=>'mode', 'startbit'=>'0', 'length'=>'3', 'group'=>'MOSI', '0000'=>'stop diagnosis', '0001'=>'VHx measurement', '0010'=>'SVR test mode', '0011'=>'Power stage test mode', '0100'=>'Cross coupling test master mode','0101'=>'Cross coupling test slave mode', '0110'=>'Connector capacitor test mode', '1000'=>'firing loop resistor measurement', '1001'=>'firing loop squib detection test', '1010'=>'start mode 0001 and mode 1000', '1011'=>'start mode 0001 and mode 1001', '1100'=>'short circuit diagnosis- flm_tg_line set to low', '1101'=>'short circuit diagnosis- flm_tg_line set to high', '1111'=>'manual diagnosis mode'},
								'parameter_15'=>    {'name'=>'conf', 'startbit'=>'4', 'length'=>'5', 'group'=>'MOSI',},
                                },

                'PSI_SUPPLY'=>  {
                                'CODE'=> '0000011110',
                                'description'=>'Switch PSI supply on/off',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Grey',
								'parameter_1'=>    {'name'=>'s1', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'on', '0'=>'off'},
								'parameter_2'=>    {'name'=>'s2', 'startbit'=>'1', 'length'=>'1', 'group'=>'MOSI', '1'=>'on', '0'=>'off'},
								'parameter_3'=>    {'name'=>'s3', 'startbit'=>'2', 'length'=>'1', 'group'=>'MOSI', '1'=>'on', '0'=>'off'},
								'parameter_4'=>    {'name'=>'s4', 'startbit'=>'3', 'length'=>'1', 'group'=>'MOSI', '1'=>'on', '0'=>'off'},
								'parameter_5'=>    {'name'=>'s5', 'startbit'=>'4', 'length'=>'1', 'group'=>'MOSI', '1'=>'on', '0'=>'off'},
								'parameter_6'=>    {'name'=>'s6', 'startbit'=>'5', 'length'=>'1', 'group'=>'MOSI', '1'=>'on', '0'=>'off'},
                                },

                'PSI_SYNC_GEN'=>        {
                                'CODE'=> '0000011111',
                                'description'=>'Generate PSI sync pulse',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'Green',
                                },

                'PSI_SYNC_MASK'=>       {
                                'CODE'=> '0000100000',
                                'description'=>'Mask PSI sync pulse',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'Blue',
								'parameter_1'=>    {'name'=>'m1', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'sync pulse enabled ', '0'=>'PSI sync pulse disabled'},
								'parameter_2'=>    {'name'=>'m2', 'startbit'=>'1', 'length'=>'1', 'group'=>'MOSI', '1'=>'sync pulse enabled', '0'=>'PSI sync pulse disabled'},
								'parameter_3'=>    {'name'=>'m3', 'startbit'=>'2', 'length'=>'1', 'group'=>'MOSI', '1'=>'sync pulse enabled', '0'=>'PSI sync pulse disabled'},
								'parameter_4'=>    {'name'=>'m4', 'startbit'=>'3', 'length'=>'1', 'group'=>'MOSI', '1'=>'sync pulse enabled', '0'=>'PSI sync pulse disabled'},
								'parameter_5'=>    {'name'=>'m5', 'startbit'=>'4', 'length'=>'1', 'group'=>'MOSI', '1'=>'sync pulse enabled', '0'=>'PSI sync pulse disabled'},
								'parameter_6'=>    {'name'=>'m6', 'startbit'=>'5', 'length'=>'1', 'group'=>'MOSI', '1'=>'sync pulse enabled', '0'=>'PSI sync pulse disabled'},
                                },

                'PSI_IQ_STATUS'=>       {
                                'CODE'=> '0000100001',
                                'description'=>'Read PSI quiescent current control status',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Yellow',
								'parameter_1'=>    {'name'=>'l1', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1'=>'min error ',},
								'parameter_2'=>    {'name'=>'h1', 'startbit'=>'1', 'length'=>'1', 'group'=>'MISO', '1'=>'max error',},
								'parameter_3'=>    {'name'=>'l2', 'startbit'=>'2', 'length'=>'1', 'group'=>'MISO', '1'=>'min error',},
								'parameter_4'=>    {'name'=>'h2', 'startbit'=>'3', 'length'=>'1', 'group'=>'MISO', '1'=>'max error',},
								'parameter_5'=>    {'name'=>'l3', 'startbit'=>'4', 'length'=>'1', 'group'=>'MISO', '1'=>'min error',},
								'parameter_6'=>    {'name'=>'h3', 'startbit'=>'5', 'length'=>'1', 'group'=>'MISO', '1'=>'max error',},
								'parameter_7'=>    {'name'=>'l4', 'startbit'=>'6', 'length'=>'1', 'group'=>'MISO', '1'=>'min error',},
								'parameter_8'=>    {'name'=>'h4', 'startbit'=>'7', 'length'=>'1', 'group'=>'MISO', '1'=>'max error',},
								'parameter_9'=>    {'name'=>'l5', 'startbit'=>'8', 'length'=>'1', 'group'=>'MISO', '1'=>'min error',},
								'parameter_10'=>    {'name'=>'h5', 'startbit'=>'9', 'length'=>'1', 'group'=>'MISO', '1'=>'max error',},
								'parameter_11'=>    {'name'=>'l6', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'min error',},
								'parameter_12'=>    {'name'=>'h6', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'max error',},
                                },

                'PSI_TEST_CONS'=>       {
                                'CODE'=> '0000100010',
                                'description'=>'Test PSI data path consistency:',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Green',
								'parameter_1'=>    {'name'=>'pc0', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'inverting PSI data crc bit 0',},
								'parameter_2'=>    {'name'=>'pc1', 'startbit'=>'1', 'length'=>'1', 'group'=>'MOSI', '1'=>'inverting PSI data crc bit 1',},
								'parameter_3'=>    {'name'=>'pc2', 'startbit'=>'2', 'length'=>'1', 'group'=>'MOSI', '1'=>'inverting PSI data crc bit 2',},
								'parameter_4'=>    {'name'=>'pc3', 'startbit'=>'3', 'length'=>'1', 'group'=>'MOSI', '1'=>'inverting PSI timeslot check bit 0',},
								'parameter_5'=>    {'name'=>'pc4', 'startbit'=>'4', 'length'=>'1', 'group'=>'MOSI', '1'=>'inverting PSI timeslot check bit 1',},
								'parameter_6'=>    {'name'=>'pc5', 'startbit'=>'5', 'length'=>'1', 'group'=>'MOSI', '1'=>'inverting PSI channel check bit 0',},
								'parameter_7'=>    {'name'=>'pc6', 'startbit'=>'6', 'length'=>'1', 'group'=>'MOSI', '1'=>'inverting PSI channel check bit 1',},
								'parameter_8'=>    {'name'=>'pc7', 'startbit'=>'7', 'length'=>'1', 'group'=>'MOSI', '1'=>'inverting PSI channel check bit 2',},
								'parameter_9'=>    {'name'=>'pc8', 'startbit'=>'8', 'length'=>'1', 'group'=>'MOSI', '1'=>'inverting PSI SID parity check bit',},
                                },

                'PSI_START_CC'=>        {
                                'CODE'=> '0000100011',
                                'description'=>'Start PSI cross coupling test',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Green2',
								'parameter_1'=>    {'name'=>'e1', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'enable PSI channel 1 for cross-coupling test',},
								'parameter_2'=>    {'name'=>'e2', 'startbit'=>'1', 'length'=>'1', 'group'=>'MOSI', '1'=>'enable PSI channel 2 for cross-coupling test',},
								'parameter_3'=>    {'name'=>'e3', 'startbit'=>'2', 'length'=>'1', 'group'=>'MOSI', '1'=>'enable PSI channel 3 for cross-coupling test',},
								'parameter_4'=>    {'name'=>'e4', 'startbit'=>'3', 'length'=>'1', 'group'=>'MOSI', '1'=>'enable PSI channel 4 for cross-coupling test',},
								'parameter_5'=>    {'name'=>'e5', 'startbit'=>'4', 'length'=>'1', 'group'=>'MOSI', '1'=>'enable PSI channel 5 for cross-coupling test',},
								'parameter_6'=>    {'name'=>'e6', 'startbit'=>'5', 'length'=>'1', 'group'=>'MOSI', '1'=>'enable PSI channel 6 for cross-coupling test',},
								'parameter_7'=>    {'name'=>'ma', 'startbit'=>'6', 'length'=>'1', 'group'=>'MOSI', '1'=>'master mode', '0'=>'slave mode',},
								'parameter_8'=>    {'name'=>'c1', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1'=>'level > 3.3V', '0'=>'level < 3.3V',},
								'parameter_9'=>    {'name'=>'c2', 'startbit'=>'1', 'length'=>'1', 'group'=>'MISO', '1'=>'level > 3.3V', '0'=>'level < 3.3V',},
								'parameter_10'=>    {'name'=>'c3', 'startbit'=>'2', 'length'=>'1', 'group'=>'MISO', '1'=>'level > 3.3V', '0'=>'level < 3.3V',},
								'parameter_11'=>    {'name'=>'c4', 'startbit'=>'3', 'length'=>'1', 'group'=>'MISO', '1'=>'level > 3.3V', '0'=>'level < 3.3V',},
								'parameter_12'=>    {'name'=>'c5', 'startbit'=>'4', 'length'=>'1', 'group'=>'MISO', '1'=>'level > 3.3V', '0'=>'level < 3.3V',},
								'parameter_13'=>    {'name'=>'c6', 'startbit'=>'5', 'length'=>'1', 'group'=>'MISO', '1'=>'level > 3.3V', '0'=>'level < 3.3V',},
                                },

                'PSI_READ_CC'=> {
                                'CODE'=> '0000100100',
                                'description'=>'Read PSI cross coupling test result',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Blue',
								'parameter_1'=>    {'name'=>'stp', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'stop cross coupling test immediately',},
								'parameter_2'=>    {'name'=>'cc1', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1'=>'cross coupling error in channel 1', '0'=>'no error',},
								'parameter_3'=>    {'name'=>'cc2', 'startbit'=>'1', 'length'=>'1', 'group'=>'MISO', '1'=>'cross coupling error in channel 2', '0'=>'no error',},
								'parameter_4'=>    {'name'=>'cc3', 'startbit'=>'2', 'length'=>'1', 'group'=>'MISO', '1'=>'cross coupling error in channel 3', '0'=>'no error',},
								'parameter_5'=>    {'name'=>'cc4', 'startbit'=>'3', 'length'=>'1', 'group'=>'MISO', '1'=>'cross coupling error in channel 4', '0'=>'no error',},
								'parameter_6'=>    {'name'=>'cc5', 'startbit'=>'4', 'length'=>'1', 'group'=>'MISO', '1'=>'cross coupling error in channel 5', '0'=>'no error',},
								'parameter_7'=>    {'name'=>'cc6', 'startbit'=>'5', 'length'=>'1', 'group'=>'MISO', '1'=>'cross coupling error in channel 6', '0'=>'no error',},
								'parameter_8'=>    {'name'=>'run', 'startbit'=>'6', 'length'=>'1', 'group'=>'MISO', '1'=>'cross coupling test is running',},
								'parameter_9'=>    {'name'=>'rdy', 'startbit'=>'7', 'length'=>'1', 'group'=>'MISO', '1'=>'cross coupling test finished', '0'=>'not started or running',},
								'parameter_10'=>    {'name'=>'vzl', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '1'=>'VZP too low', '0'=>'VZP OK',},
                                },

                'PSI_READ_SC'=> {
                                'CODE'=> '0000100101',
                                'description'=>'Read PSI short circuit status',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Blue1',
								'parameter_1'=>    {'name'=>'sg1', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1'=>'short to gnd', '0'=>'no error',},
								'parameter_2'=>    {'name'=>'sg2', 'startbit'=>'1', 'length'=>'1', 'group'=>'MISO', '1'=>'short to gnd', '0'=>'no error',},
								'parameter_3'=>    {'name'=>'sg3', 'startbit'=>'2', 'length'=>'1', 'group'=>'MISO', '1'=>'short to gnd', '0'=>'no error',},
								'parameter_4'=>    {'name'=>'sg4', 'startbit'=>'3', 'length'=>'1', 'group'=>'MISO', '1'=>'short to gnd', '0'=>'no error',},
								'parameter_5'=>    {'name'=>'sg5', 'startbit'=>'4', 'length'=>'1', 'group'=>'MISO', '1'=>'short to gnd', '0'=>'no error',},
								'parameter_6'=>    {'name'=>'sg6', 'startbit'=>'5', 'length'=>'1', 'group'=>'MISO', '1'=>'short to gnd', '0'=>'no error',},
								'parameter_7'=>    {'name'=>'sb1', 'startbit'=>'6', 'length'=>'1', 'group'=>'MISO', '1'=>'short to battery', '0'=>'no error',},
								'parameter_7'=>    {'name'=>'sb2', 'startbit'=>'7', 'length'=>'1', 'group'=>'MISO', '1'=>'short to battery', '0'=>'no error',},
								'parameter_8'=>    {'name'=>'sb3', 'startbit'=>'8', 'length'=>'1', 'group'=>'MISO', '1'=>'short to battery', '0'=>'no error',},
								'parameter_9'=>    {'name'=>'sb4', 'startbit'=>'9', 'length'=>'1', 'group'=>'MISO', '1'=>'short to battery', '0'=>'no error',},
								'parameter_10'=>    {'name'=>'sb5', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'short to battery', '0'=>'no error',},
								'parameter_11'=>    {'name'=>'sb6', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'short to battery', '0'=>'no error',},								
								'parameter_12'=>    {'name'=>'vzl', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '1'=>'VZP too low  ', '0'=>'VZP OK',}	,							
                                },

                'POM_CYCL_CAP'=>        {
                                'CODE'=> '0000100110',
                                'description'=>'Configure cyclic capacitance test',
                                'datasize'=> '16',
                                'module'=>'POM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'Green',
								'parameter_1'=> {'name'=>'on', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '0' => 'cyclic capacitance test off', '1' => 'cyclic capacitance test on',},
								'parameter_2'=> {'name'=>'aut', 'startbit'=>'1', 'length'=>'1', 'group'=>'MOSI', '0' => 'autarky test off', '1' => 'autarky test on',},
								'parameter_3'=> {'name'=>'aut_time', 'startbit'=>'2', 'length'=>'8', 'group'=>'MOSI',},
								'parameter_4'=> {'name'=>'res', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '0' => 'OK', '1' => 'error',}, 
								'parameter_5'=> {'name'=>'bc', 'startbit'=>'1', 'length'=>'1', 'group'=>'MISO', '0' => 'OK', '1' => 'VER is too low (VER<VER_Lf) and the ER-charger is still active',},
								'parameter_6'=> {'name'=>'ta', 'startbit'=>'2', 'length'=>'1', 'group'=>'MISO', '0' => 'OK', '1' => 'POM BIST running',},
								'parameter_7'=> {'name'=>'err', 'startbit'=>'3', 'length'=>'1', 'group'=>'MISO', '0' => 'test valid', '1' => 'autarky test / cycl. capacitance test canceled',},
								'parameter_8'=> {'name'=>'aky', 'startbit'=>'4', 'length'=>'1', 'group'=>'MISO', '0' => 'OK', '1' => 'error',},
								'parameter_9'=> {'name'=>'sty', 'startbit'=>'5', 'length'=>'1', 'group'=>'MISO', '0' => 'ER fully charged', '1' => 'ER charge current flowing',},
								
								},

                'POM_STATUS'=>  {
                                'CODE'=> '0000100111',
                                'description'=>'Read power supply status',
                                'datasize'=> '16',
                                'module'=>'POM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Pink',
                                'parameter_1'=> {'name'=>'vel', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '0' => 'ok', '1' => 'VER low',},
                                'parameter_2'=> {'name'=>'v50', 'startbit'=>'1', 'length'=>'1', 'group'=>'MISO','0' => 'ok', '1' => 'out of band',},
                                'parameter_3'=> {'name'=>'vzl', 'startbit'=>'2', 'length'=>'1', 'group'=>'MISO','0' => 'ok', '1' => 'VZP low',},
                                'parameter_4'=> {'name'=>'vet', 'startbit'=>'3', 'length'=>'1', 'group'=>'MISO','0' => 'VER < VER test level', '1' => 'VER > VER test level',},
                                'parameter_5'=> {'name'=>'c1', 'startbit'=>'4', 'length'=>'1', 'group'=>'MISO','0' => 'CONF_33_OFF', '1' => 'CONF_33_ON',},
                                'parameter_6'=> {'name'=>'c3', 'startbit'=>'6', 'length'=>'1', 'group'=>'MISO','0' => 'CONF_CORE_OFF', '1' => 'CONF_CORE_ON'},
								'parameter_7'=> {'name'=>'c4', 'startbit'=>'7', 'length'=>'1', 'group'=>'MISO','0' => 'CONF_VC1_OFF', '1' => 'CONF_VC1_ON'},
								'parameter_8'=> {'name'=>'c5', 'startbit'=>'8', 'length'=>'1', 'group'=>'MISO','0' => 'CONF_VC2_OFF', '1' => 'CONF_VC2_ON'},
								'parameter_9'=> {'name'=>'c6', 'startbit'=>'9', 'length'=>'1', 'group'=>'MISO','0' => 'CONF_VBAT_OFF', '1' => 'CONF_VBAT_ON'},
								'parameter_10'=> {'name'=>'ot', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO','0' => 'ok', '1' => 'temperature too high(VUP switched off)'},
								'parameter_11'=> {'name'=>'erc', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO','0' => 'ok', '1' => 'VUP<11.5V'},
								'parameter_12'=> {'name'=>'sl', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO','0' => 'normal mode', '1' => 'sleep mode request'},
								'parameter_13'=> {'name'=>'nok', 'startbit'=>'13', 'length'=>'1', 'group'=>'MISO','0' => 'Voltages In Range', '1' => 'at least one of the monitored voltage is out of range(VUP, VAS, VINT_X, VST33 and VCORE)'},
								'parameter_14'=> {'name'=>'vin', 'startbit'=>'14', 'length'=>'1', 'group'=>'MISO','0' => 'VINT supplied from VAS', '1' => 'VINT supplied from VZP'},
								'parameter_15'=> {'name'=>'sty', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO','0' => 'ER fully charged', '1' => 'ER charge current still flowing'},
                                },

                'POM_VER_CURR'=>        {
                                'CODE'=> '0000101000',
                                'description'=>'Set VER load current',
                                'datasize'=> '16',
                                'module'=>'POM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Turk',
								 'parameter_1'=> {'name'=>'vlm', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI','0' => 'loading up to 11V', '1' => 'loading up to 33V/24V',},
								 'parameter_2'=> {'name'=>'ver_current', 'startbit'=>'1', 'length'=>'3', 'group'=>'MOSI',},
								 'parameter_3'=> {'name'=>'dis', 'startbit'=>'2', 'length'=>'1', 'group'=>'MOSI','0' => 'OFF', '1' => 'discharge VER on (disables VER loading)',},
                                },

                'POM_START_BIST'=>      {
                                'CODE'=> '0000101001',
                                'description'=>'Start power supply build-in self test',
                                'datasize'=> '16',
                                'module'=>'POM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Yellow',
								'parameter_1'=> {'name'=>'i_bist', 'startbit'=>'0', 'length'=>'3', 'group'=>'MOSI',},
								'parameter_2'=> {'name'=>'t_bist', 'startbit'=>'3', 'length'=>'5', 'group'=>'MOSI',},
								'parameter_3'=> {'name'=>'mode', 'startbit'=>'8', 'length'=>'2', 'group'=>'MOSI','00' => 'no BIST', '01' => 'ESR BIST','10' => 'CAP BIST','11' => 'CAP + Discharge BIST',},
								'parameter_4'=> {'name'=>'bc', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO','0' => 'ok', '1' => 'VER is too low(VER<VER_TEST)',},
								'parameter_5'=> {'name'=>'vel', 'startbit'=>'1', 'length'=>'1', 'group'=>'MISO','0' => 'ok', '1' => 'VER low',},
								'parameter_6'=> {'name'=>'ta', 'startbit'=>'2', 'length'=>'1', 'group'=>'MISO','0' => 'ok', '1' => 'POM BIST running',},
								'parameter_7'=> {'name'=>'vzl', 'startbit'=>'3', 'length'=>'1', 'group'=>'MISO','0' => 'ok', '1' => 'VZP low',},
                                },

                'POM_READ_BIST'=>       {
                                'CODE'=> '0000101010',
                                'description'=>'Read power supply build-in self test results',
                                'datasize'=> '16',
                                'module'=>'POM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Green2',
								'parameter_1'=> {'name'=>'delta_ver', 'startbit'=>'0', 'length'=>'7', 'group'=>'MOSI',},
								'parameter_2'=> {'name'=>'et1', 'startbit'=>'7', 'length'=>'1', 'group'=>'MISO','0' => 'VER < ESR_START + 0.6V', '1' => 'VER > ESR_START + 0.6V',},
								'parameter_3'=> {'name'=>'et2', 'startbit'=>'8', 'length'=>'1', 'group'=>'MISO','0' => 'VER < ESR_START + 0.8V', '1' => 'VER > ESR_START + 0.8V',},
								'parameter_4'=> {'name'=>'vel', 'startbit'=>'9', 'length'=>'1', 'group'=>'MISO','0' => 'ok', '1' => 'VER low',},
								'parameter_5'=> {'name'=>'vzl', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO','0' => 'ok', '1' => 'VZP low',},
								'parameter_6'=> {'name'=>'ch', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO','0' => 'ok', '1' => 'no ER charge current flowing',},
								'parameter_7'=> {'name'=>'mis', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO','0' => 'ok', '1' => 'ER capacitance is missing',},
								'parameter_8'=> {'name'=>'vet', 'startbit'=>'13', 'length'=>'1', 'group'=>'MISO','0' => 'ok', '1' => 'VER test level',},								
								'parameter_9'=> {'name'=>'ta', 'startbit'=>'14', 'length'=>'1', 'group'=>'MISO','0' => 'ok', '1' => 'BIST running',},	
								'parameter_10'=> {'name'=>'et0', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO','0' => 'VER < ESR_START + 0.4V', '1' => 'VER > ESR_START + 0.4V',},
                                },

                'POM_START_AUTO'=>      {
                                'CODE'=> '0000101011',
                                'description'=>'Start power supply automatic measurements',
                                'datasize'=> '16',
                                'module'=>'POM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Red',
                                'parameter_1'=> {'name'=>'on', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI','0' => 'automatic measurement off', '1' => 'automatic measurement on',},	
                                },

                'LIN_CURR'=>    {
                                'CODE'=> '0000101100',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'LIN',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => '',
                                'parameter_1'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                },

                'AOUT_CTRL'=>   {
                                'CODE'=> '0000101101',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'AOUT',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => '',
                                'parameter_1'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                },

                'OTP_CMD'=>     {
                                'CODE'=> '0000101110',
                                'description'=>'Execute OTP command',
                                'datasize'=> '16',
                                'module'=>'OTP',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Turk',
                                'parameter_1'=>    {'name'=>'otp_data', 'startbit'=>'0', 'length'=>'8', 'group'=>'MOSI',},
								'parameter_2'=>    {'name'=>'otp_address', 'startbit'=>'8', 'length'=>'5', 'group'=>'MOSI',},
                                'parameter_3'=>    {'name'=>'otp_command', 'startbit'=>'13', 'length'=>'3', 'group'=>'MOSI','000' => 'nop (no operation)','001' => 'read','010' => 'read with margin (margin level defined in otp_data)','011' => 'write latch','100' => 'program','101' => 'restart','110' => 'BIST (mode defined in otp_data)','111' => 'refresh (apply VPROG and set otp_timing before sending refresh command)',},
								'parameter_4'=>    {'name'=>'otp_read_data', 'startbit'=>'0', 'length'=>'8', 'group'=>'MISO',},
								'parameter_5'=>    {'name'=>'vd', 'startbit'=>'8', 'length'=>'1', 'group'=>'MISO',},
								'parameter_6'=>    {'name'=>'bsy', 'startbit'=>'9', 'length'=>'1', 'group'=>'MISO','1' => 'OTP busy',},
								'parameter_7'=>    {'name'=>'crc', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO','1' => 'CRC failed',},
								'parameter_8'=>    {'name'=>'bst', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO','1' => 'BIST failed',},
								'parameter_9'=>    {'name'=>'wrf', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO','1' => 'write failed (because OTP is locked)',},
                                },

                'OTP_CONF'=>    {
                                'CODE'=> '0000101111',
                                'description'=>'Configure OTP memory',
                                'datasize'=> '16',
                                'module'=>'OTP',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Turk',
                                'parameter_1'=>    {'name'=>'otp_timing', 'startbit'=>'0', 'length'=>'9', 'group'=>'MOSI',},
                                },

                'TESTMODE'=>    {
                                'CODE'=> '0000110001',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'TEST',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => '',
                                'parameter_1'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                },

                'TEST_PLP_THRES'=>      {
                                'CODE'=> '0000110010',
                                'description'=>'Read last PLP threshold evaluated',
                                'datasize'=> '16',
                                'module'=>'TEST',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Turk',
                                'parameter_1'=>    {
                                                        'name'=>'plp_threshold', 'startbit'=>'0', 'length'=>'8', 'group'=>'MISO', 
                                                        },
                                },

                'TEST_PLP_DATA'=>       {
                                'CODE'=> '0000110011',
                                'description'=>'last data used in plausibility path (monitoring of READ_SENSOR)',
                                'datasize'=> '16',
                                'module'=>'TEST',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Turk',
                                'parameter_1'=>    {
                                                        'name'=>'plp_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO', 
                                                        },
                                },

                'PSI_READ_LEV'=>        {
                                'CODE'=> '0000110100',
                                'description'=>'Read PSI line level',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Turk',
								'parameter_1'=>    {'name'=>'c1', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1'=>'level > 3.3V', '0'=>'level < 3.3V'},
								'parameter_2'=>    {'name'=>'c2', 'startbit'=>'1', 'length'=>'1', 'group'=>'MISO', '1'=>'level > 3.3V', '0'=>'level < 3.3V'},
								'parameter_3'=>    {'name'=>'c3', 'startbit'=>'2', 'length'=>'1', 'group'=>'MISO', '1'=>'level > 3.3V', '0'=>'level < 3.3V'},
								'parameter_4'=>    {'name'=>'c4', 'startbit'=>'3', 'length'=>'1', 'group'=>'MISO', '1'=>'level > 3.3V', '0'=>'level < 3.3V'},
								'parameter_5'=>    {'name'=>'c5', 'startbit'=>'4', 'length'=>'1', 'group'=>'MISO', '1'=>'level > 3.3V', '0'=>'level < 3.3V'},
								'parameter_6'=>    {'name'=>'c6', 'startbit'=>'5', 'length'=>'1', 'group'=>'MISO', '1'=>'level > 3.3V', '0'=>'level < 3.3V'},
                                },

                'DISABLE_STATUS'=>      {
                                'CODE'=> '0000110101',
                                'description'=>'Read disable line status:',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Blue',
								'parameter_1'=> {'name'=>'DIS_ALP', 'startbit'=>'6', 'length'=>'1', 'group'=>'MISO',},
								'parameter_2'=> {'name'=>'DIS_AHP', 'startbit'=>'5', 'length'=>'1', 'group'=>'MISO',},
								'parameter_3'=> {'name'=>'DIS_SHP', 'startbit'=>'4', 'length'=>'1', 'group'=>'MISO',},
								'parameter_4'=> {'name'=>'SDIS_X', 'startbit'=>'3', 'length'=>'1', 'group'=>'MISO',},
								'parameter_5'=> {'name'=>'SDIS_Y', 'startbit'=>'2', 'length'=>'1', 'group'=>'MISO',},
								'parameter_6'=> {'name'=>'SDIS_W', 'startbit'=>'1', 'length'=>'1', 'group'=>'MISO',},
								'parameter_7'=> {'name'=>'SDIS_S', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO',},
                                },

                'LIN_STATUS'=>  {
                                'CODE'=> '0000110110',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'LIN',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => '',
                                'parameter_1'=>    {
                                                        'name'=>'lin_status', 'startbit'=>'0', 'length'=>'3', 'group'=>'MOSI', 												
                                                   },
                                'parameter_2'=>    {
                                                        'name'=>'on', 'startbit'=>'3', 'length'=>'1', 'group'=>'MOSI', 		'0' => 'DIA is/was not switched on', '1' => 'DIA is/was switched on (since last read)',
                                                   },
														
                                'parameter_3'=>    {
                                                        'name'=>'off', 'startbit'=>'4', 'length'=>'1', 'group'=>'MOSI', 	'0' => 'DIA is/was not switched off', '1' => 'DIA is/was switched off (since last read)',
                                                   },
														
                                'parameter_4'=>    {
                                                        'name'=>'to', 'startbit'=>'5', 'length'=>'1', 'group'=>'MOSI', 		'1' => 'dominant timeout protection is/was active',
                                                   },
														
                                'parameter_5'=>    {
                                                        'name'=>'to', 'startbit'=>'15', 'length'=>'1', 'group'=>'MOSI', 	'1' => 'VZP too low', '0' => 'VZP OK (status at the moment of shortcut evaluation)',
                                                    },
                                },

                'TEST_PSI'=>    {
                                'CODE'=> '0000110111',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'TEST',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Oker',
                                'parameter_1'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                },

                'ADC_START_FLM'=>       {
                                'CODE'=> '0000111000',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'ADC',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => '',
                                'parameter_1'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                },

                'ADC_START_AINO'=>      {
                                'CODE'=> '0000111001',
                                'description'=>'Start manual A/D conversion',
                                'datasize'=> '16',
                                'module'=>'AINO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Green',
                                'parameter_1'=>    {
                                                        'name'=>'channel', 'startbit'=>'0', 'length'=>'4', 'group'=>'MOSI','0000' => 'AIN0','0001' => 'AIN1','0010' => 'AIN2','0011' => 'AIN3','0100' => 'AIN4',
														'0101' => 'AIN5','0110' => 'AIN6','0111' => 'AIN7','1000' => 'AIN8','1001' => 'AIN9','1010' => 'AIO10','10110' => 'AIO11','1111' => 'high impedant',
														},
                                'parameter_2'=>    {'name'=>'mode', 'startbit'=>'0', 'length'=>'4', 'group'=>'MOSI','000' => 'no test active, no source switched on (normal voltage measurement)','001' => 'instruction will be ignored',
													'010' => 'no test active, fixed current source','011' => 'no test active, fixed voltage source (hall mode)','100' => 'test active internal multiplexer test','101' => 'test active, ADC reference voltages',
													'110' => 'test actve, fixed current source', '111' => 'test active, fixed voltage source',
													},
								'parameter_3'=>    {
                                                        'name'=>'ui', 'startbit'=>'8', 'length'=>'1', 'group'=>'MOSI','0' => 'voltage', '1' => 'current', 
                                                        },			
								'parameter_4'=>    {
                                                        'name'=>'test_source', 'startbit'=>'9', 'length'=>'4', 'group'=>'MOSI', '0000' => 'AIN0','0001' => 'AIN1','0010' => 'AIN2','0011' => 'AIN3','0100' => 'AIN4',
														'0101' => 'AIN5','0110' => 'AIN6','0111' => 'AIN7','1000' => 'AIN8','1001' => 'AIN9','1010' => 'AIO10','10110' => 'AIO11','1111' => 'no source',
                                                        },
								'parameter_5'=>    {
                                                        'name'=>'src', 'startbit'=>'13', 'length'=>'1', 'group'=>'MOSI', '0' => VAS, '1' => 'VUP',
                                                        },							
                                },

                'ADC_START_POM'=>       {
                                'CODE'=> '0000111010',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'ADC',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => '',
                                'parameter_1'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                },

                'ADC_START_AUX'=>       {
                                'CODE'=> '0000111011',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'ADC',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => '',
                                'parameter_1'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                },

                'ADC_READ_FLM'=>        {
                                'CODE'=> '0000111100',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'ADC',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => '',
                                'parameter_1'=>    {
                                                        'name'=>'adc_result', 'startbit'=>'0', 'length'=>'10', 'group'=>'na', 
                                                        },
                                },

                'ADC_READ_AINO'=>       {
                                'CODE'=> '0000111101',
                                'description'=>'Read manual A/D conversion result',
                                'datasize'=> '16',
                                'module'=>'AINO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => '',
                                'parameter_1'=>    {
                                                        'name'=>'sds', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '0' => 'no influence on SDIS_S', '1' => 'influence according to PROG_SW_MODE',
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'adc_result', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',
														},
								'parameter_3'=>    {
                                                        'name'=>'vd', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO','1' => 'adc data are valid', '0' => 'adc data are old or invalid',
                                                        },	
								'parameter_4'=>    {
                                                        'name'=>'sup', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO','1' => 'supply for measurement was too low (VUP)',
                                                        },			
								'parameter_4'=>    {
                                                        'name'=>'vzl', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO','1' => 'VZP too low,','0' => 'VZP ok,'
                                                        },															
                                },

                'ADC_READ_POM'=>        {
                                'CODE'=> '0000111110',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'ADC',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Green',
                                'parameter_1'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                },

                'ADC_READ_AUX'=>        {
                                'CODE'=> '0000111111',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'ADC',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => '',
                                'parameter_1'=>    {
                                                        'name'=>'adc_result', 'startbit'=>'0', 'length'=>'10', 'group'=>'na', 
                                                        },
                                               },
											   
                'DEMAND_TEST_16'=>      {
                                'CODE'=> '0011100',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'TEST',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => '',
                                'parameter_1'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                },

                'AINO_READ_AUTO1'=>     {
                                'CODE'=> '0100010000',
                                'description'=>'Read AIN/AIO automatic measurement',
                                'datasize'=> '16',
                                'module'=>'AINO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Green',
                                'parameter_1'=>    {
                                                        'name'=>'adc_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'vd', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '0'=>'adc data are valid','1'=>'adc data are not valid',
                                                        },
								'parameter_3'=>    {
                                                        'name'=>'sup', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'supply for measurement was too low',
                                                        },	
								'parameter_4'=>    {
                                                        'name'=>'s2b', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'1 = short to battery',
                                                        },
								'parameter_5'=>    {
                                                        'name'=>'vzl', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '0'=>'VZP OK','1'=>'VZP too low',
                                                        },
								'parameter_6'=>    {
                                                        'name'=>'sds', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '0'=>'no influence on SDIS_S','1'=>'influence according to PROG_SW_MODE',
                                                        },						
                                },

                'AINO_READ_AUTO2'=>     {
                                'CODE'=> '0100010001',
                                'description'=>'Read AIN/AIO automatic measurement',
                                'datasize'=> '16',
                                'module'=>'AINO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Green',
                                'parameter_1'=>    {
                                                        'name'=>'adc_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'vd', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '0'=>'adc data are valid','1'=>'adc data are not valid',
                                                        },
								'parameter_3'=>    {
                                                        'name'=>'sup', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'supply for measurement was too low',
                                                        },	
								'parameter_4'=>    {
                                                        'name'=>'s2b', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'1 = short to battery',
                                                        },
								'parameter_5'=>    {
                                                        'name'=>'vzl', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '0'=>'VZP OK','1'=>'VZP too low',
                                                        },
								'parameter_6'=>    {
                                                        'name'=>'sds', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '0'=>'no influence on SDIS_S','1'=>'influence according to PROG_SW_MODE',
                                                        },						
                                },
								
				'AINO_READ_AUTO3'=>     {				
                                'CODE'=> '0100010010',
                                'description'=>'Read AIN/AIO automatic measurement',
                                'datasize'=> '16',
                                'module'=>'AINO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Green',
                                'parameter_1'=>    {
                                                        'name'=>'adc_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'vd', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '0'=>'adc data are valid','1'=>'adc data are not valid',
                                                        },
								'parameter_3'=>    {
                                                        'name'=>'sup', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'supply for measurement was too low',
                                                        },	
								'parameter_4'=>    {
                                                        'name'=>'s2b', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'1 = short to battery',
                                                        },
								'parameter_5'=>    {
                                                        'name'=>'vzl', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '0'=>'VZP OK','1'=>'VZP too low',
                                                        },
								'parameter_6'=>    {
                                                        'name'=>'sds', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '0'=>'no influence on SDIS_S','1'=>'influence according to PROG_SW_MODE',
                                                        },						
                                },

                'AINO_READ_AUTO4'=>     {
                                'CODE'=> '0100010011',
                                'description'=>'Read AIN/AIO automatic measurement',
                                'datasize'=> '16',
                                'module'=>'AINO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Green',
                                'parameter_1'=>    {
                                                        'name'=>'adc_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'vd', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '0'=>'adc data are valid','1'=>'adc data are not valid',
                                                        },
								'parameter_3'=>    {
                                                        'name'=>'sup', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'supply for measurement was too low',
                                                        },	
								'parameter_4'=>    {
                                                        'name'=>'s2b', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'1 = short to battery',
                                                        },
								'parameter_5'=>    {
                                                        'name'=>'vzl', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '0'=>'VZP OK','1'=>'VZP too low',
                                                        },
								'parameter_6'=>    {
                                                        'name'=>'sds', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '0'=>'no influence on SDIS_S','1'=>'influence according to PROG_SW_MODE',
                                                        },						
                                },

                'AINO_READ_AUTO5'=>     {
                                'CODE'=> '0100010100',
                                'description'=>'Read AIN/AIO automatic measurement',
                                'datasize'=> '16',
                                'module'=>'AINO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Green',
                                'parameter_1'=>    {
                                                        'name'=>'adc_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'vd', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '0'=>'adc data are valid','1'=>'adc data are not valid',
                                                        },
								'parameter_3'=>    {
                                                        'name'=>'sup', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'supply for measurement was too low',
                                                        },	
								'parameter_4'=>    {
                                                        'name'=>'s2b', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'1 = short to battery',
                                                        },
								'parameter_5'=>    {
                                                        'name'=>'vzl', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '0'=>'VZP OK','1'=>'VZP too low',
                                                        },
								'parameter_6'=>    {
                                                        'name'=>'sds', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '0'=>'no influence on SDIS_S','1'=>'influence according to PROG_SW_MODE',
                                                        },						
                                },

                'AINO_READ_AUTO6'=>     {
                                'CODE'=> '0100010101',
                               'description'=>'Read AIN/AIO automatic measurement',
                                'datasize'=> '16',
                                'module'=>'AINO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Green',
                                'parameter_1'=>    {
                                                        'name'=>'adc_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'vd', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '0'=>'adc data are valid','1'=>'adc data are not valid',
                                                        },
								'parameter_3'=>    {
                                                        'name'=>'sup', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'supply for measurement was too low',
                                                        },	
								'parameter_4'=>    {
                                                        'name'=>'s2b', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'1 = short to battery',
                                                        },
								'parameter_5'=>    {
                                                        'name'=>'vzl', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '0'=>'VZP OK','1'=>'VZP too low',
                                                        },
								'parameter_6'=>    {
                                                        'name'=>'sds', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '0'=>'no influence on SDIS_S','1'=>'influence according to PROG_SW_MODE',
                                                        },						
                                },

                'AINO_READ_AUTO7'=>     {
                                'CODE'=> '0100010110',
                                'description'=>'Read AIN/AIO automatic measurement',
                                'datasize'=> '16',
                                'module'=>'AINO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Green',
                                'parameter_1'=>    {
                                                        'name'=>'adc_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'vd', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '0'=>'adc data are valid','1'=>'adc data are not valid',
                                                        },
								'parameter_3'=>    {
                                                        'name'=>'sup', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'supply for measurement was too low',
                                                        },	
								'parameter_4'=>    {
                                                        'name'=>'s2b', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'1 = short to battery',
                                                        },
								'parameter_5'=>    {
                                                        'name'=>'vzl', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '0'=>'VZP OK','1'=>'VZP too low',
                                                        },
								'parameter_6'=>    {
                                                        'name'=>'sds', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '0'=>'no influence on SDIS_S','1'=>'influence according to PROG_SW_MODE',
                                                        },						
                                },

                'AINO_READ_AUTO8'=>     {
                                'CODE'=> '0100010111',
                                'description'=>'Read AIN/AIO automatic measurement',
                                'datasize'=> '16',
                                'module'=>'AINO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Green',
                                'parameter_1'=>    {
                                                        'name'=>'adc_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'vd', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '0'=>'adc data are valid','1'=>'adc data are not valid',
                                                        },
								'parameter_3'=>    {
                                                        'name'=>'sup', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'supply for measurement was too low',
                                                        },	
								'parameter_4'=>    {
                                                        'name'=>'s2b', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'1 = short to battery',
                                                        },
								'parameter_5'=>    {
                                                        'name'=>'vzl', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '0'=>'VZP OK','1'=>'VZP too low',
                                                        },
								'parameter_6'=>    {
                                                        'name'=>'sds', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '0'=>'no influence on SDIS_S','1'=>'influence according to PROG_SW_MODE',
                                                        },						
                                },

                'AINO_READ_AUTO9'=>     {
                                'CODE'=> '0100011000',
                                'description'=>'Read AIN/AIO automatic measurement',
                                'datasize'=> '16',
                                'module'=>'AINO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Green',
                                'parameter_1'=>    {
                                                        'name'=>'adc_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'vd', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '0'=>'adc data are valid','1'=>'adc data are not valid',
                                                        },
								'parameter_3'=>    {
                                                        'name'=>'sup', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'supply for measurement was too low',
                                                        },	
								'parameter_4'=>    {
                                                        'name'=>'s2b', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'1 = short to battery',
                                                        },
								'parameter_5'=>    {
                                                        'name'=>'vzl', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '0'=>'VZP OK','1'=>'VZP too low',
                                                        },
								'parameter_6'=>    {
                                                        'name'=>'sds', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '0'=>'no influence on SDIS_S','1'=>'influence according to PROG_SW_MODE',
                                                        },						
                                },

                'AINO_READ_AUTO10'=>     {
                                'CODE'=> '0100011001',
                                'description'=>'Read AIN/AIO automatic measurement',
                                'datasize'=> '16',
                                'module'=>'AINO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Green',
                                'parameter_1'=>    {
                                                        'name'=>'adc_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'vd', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '0'=>'adc data are valid','1'=>'adc data are not valid',
                                                        },
								'parameter_3'=>    {
                                                        'name'=>'sup', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'supply for measurement was too low',
                                                        },	
								'parameter_4'=>    {
                                                        'name'=>'s2b', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'1 = short to battery',
                                                        },
								'parameter_5'=>    {
                                                        'name'=>'vzl', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '0'=>'VZP OK','1'=>'VZP too low',
                                                        },
								'parameter_6'=>    {
                                                        'name'=>'sds', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '0'=>'no influence on SDIS_S','1'=>'influence according to PROG_SW_MODE',
                                                        },						
                                },

                'AINO_READ_AUTO11'=>    {
                                'CODE'=> '0100011010',
                                'description'=>'Read AIN/AIO automatic measurement',
                                'datasize'=> '16',
                                'module'=>'AINO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Green',
                                'parameter_1'=>    {
                                                        'name'=>'adc_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'vd', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '0'=>'adc data are valid','1'=>'adc data are not valid',
                                                        },
								'parameter_3'=>    {
                                                        'name'=>'sup', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'supply for measurement was too low',
                                                        },	
								'parameter_4'=>    {
                                                        'name'=>'s2b', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'1 = short to battery',
                                                        },
								'parameter_5'=>    {
                                                        'name'=>'vzl', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '0'=>'VZP OK','1'=>'VZP too low',
                                                        },
								'parameter_6'=>    {
                                                        'name'=>'sds', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '0'=>'no influence on SDIS_S','1'=>'influence according to PROG_SW_MODE',
                                                        },						
                                },

                'AINO_READ_AUTO12'=>    {
                                'CODE'=> '0100011011',
                                'description'=>'Read AIN/AIO automatic measurement',
                                'datasize'=> '16',
                                'module'=>'AINO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Green',
                                'parameter_1'=>    {
                                                        'name'=>'adc_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'vd', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '0'=>'adc data are valid','1'=>'adc data are not valid',
                                                        },
								'parameter_3'=>    {
                                                        'name'=>'sup', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'supply for measurement was too low',
                                                        },	
								'parameter_4'=>    {
                                                        'name'=>'s2b', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'1 = short to battery',
                                                        },
								'parameter_5'=>    {
                                                        'name'=>'vzl', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '0'=>'VZP OK','1'=>'VZP too low',
                                                        },
								'parameter_6'=>    {
                                                        'name'=>'sds', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '0'=>'no influence on SDIS_S','1'=>'influence according to PROG_SW_MODE',
                                                        },						
                                },

                'AINO_READ_BIST1'=>     {
                                'CODE'=> '0100100000',
                                'description'=>'Read AIN/AIO build-in self test results',
                                'datasize'=> '16',
                                'module'=>'AINO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'Green',
                                'parameter_1'=>    {'name'=>'result of internal cross coupling test : S1/S4 error', 'startbit'=>'0', 'length'=>'12', 'group'=>'MISO',},
                               
                                },

                'AINO_READ_BIST2'=>     {
                                'CODE'=> '0100100010',
                                'description'=>'Read AIN/AIO build-in self test results',
                                'datasize'=> '16',
                                'module'=>'AINO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'Green',
                                'parameter_1'=>    {'name'=>'result of internal cross coupling test : S2/S4 error', 'startbit'=>'0', 'length'=>'12', 'group'=>'MISO',},
                               
                                },

                'AINO_READ_BIST3'=>     {
                                'CODE'=> '0100100011',
                                'description'=>'Read AIN/AIO build-in self test results',
                                'datasize'=> '16',
                                'module'=>'AINO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'Green',
                                'parameter_1'=>    {'name'=>'result of internal cross coupling test : cross coupling detected', 'startbit'=>'0', 'length'=>'12', 'group'=>'MISO',},
                               
                                },

                'AINO_READ_BIST4'=>     {
                                'CODE'=> '0100100100',
                                'description'=>'Read AIN/AIO build-in self test results',
                                'datasize'=> '16',
                                'module'=>'AINO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'Green',
                                'parameter_1'=>    {'name'=>'result of ADC bist', 'startbit'=>'0', 'length'=>'12', 'group'=>'MISO',},
                               
                                },

                'AINO_READ_BIST5'=>     {
                                'CODE'=> '0100100101',
                                'description'=>'Read AIN/AIO build-in self test results',
                                'datasize'=> '16',
                                'module'=>'AINO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'Green',
                                'parameter_1'=>    {'name'=>'result of connector capacitor test or result of external cross coupling test master or result of external cross coupling test slave with short to ubat', 'startbit'=>'0', 'length'=>'12', 'group'=>'MISO',},
                               'parameter_2'=>    {'name'=>'vzl', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO','1 '=> 'VZP too low', '0' => 'VZP OK', },
                                },

                'AINO_READ_BIST6'=>     {
                                'CODE'=> '0100100110',
                                'description'=>'Read AIN/AIO build-in self test results',
                                'datasize'=> '16',
                                'module'=>'AINO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'Green',
                                'parameter_1'=>    {'name'=>'result of connector capacitor test or result of external cross coupling test master with short to ground', 'startbit'=>'0', 'length'=>'12', 'group'=>'MISO',},
                               'parameter_2'=>    {'name'=>'vzl', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO','1 '=> 'VZP too low', '0' => 'VZP OK', },
                                },

                'AINO_READ_BIST7'=>     {
                                'CODE'=> '0100100111',
                                'description'=>'Read AIN/AIO build-in self test results',
                                'datasize'=> '16',
                                'module'=>'AINO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'Green',
                                'parameter_1'=>    {'name'=>'result of connector capacitor test or result of external cross coupling test master', 'startbit'=>'0', 'length'=>'12', 'group'=>'MISO',},

								},

               'FLM_READ_FIRE_CNT1'=>  {
                                'CODE'=> '0100110000',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Yellow',
                                'parameter_1'=>    {'name'=>'fire_counter_ll', 'startbit'=>'0', 'length'=>'7', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'fire_counter_hl', 'startbit'=>'8', 'length'=>'7', 'group'=>'MISO',},
                                },

                'FLM_READ_FIRE_CNT2'=>  {
                                'CODE'=> '0100110001',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Yellow',
                                'parameter_1'=>    {'name'=>'fire_counter_ll', 'startbit'=>'0', 'length'=>'7', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'fire_counter_hl', 'startbit'=>'8', 'length'=>'7', 'group'=>'MISO',},
                                },

                'FLM_READ_FIRE_CNT3'=>  {
                                'CODE'=> '0100110010',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Yellow',
                                'parameter_1'=>    {'name'=>'fire_counter_ll', 'startbit'=>'0', 'length'=>'7', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'fire_counter_hl', 'startbit'=>'8', 'length'=>'7', 'group'=>'MISO',},
                                },

                'FLM_READ_FIRE_CNT4'=>  {
                                'CODE'=> '0100110011',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Yellow',
                                'parameter_1'=>    {'name'=>'fire_counter_ll', 'startbit'=>'0', 'length'=>'7', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'fire_counter_hl', 'startbit'=>'8', 'length'=>'7', 'group'=>'MISO',},
                                },

                'FLM_READ_FIRE_CNT5'=>  {
                                'CODE'=> '0100110100',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Yellow',
                                'parameter_1'=>    {'name'=>'fire_counter_ll', 'startbit'=>'0', 'length'=>'7', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'fire_counter_hl', 'startbit'=>'8', 'length'=>'7', 'group'=>'MISO',},
                                },

                'FLM_READ_FIRE_CNT6'=>  {
                                'CODE'=> '0100110101',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Yellow',
                                'parameter_1'=>    {'name'=>'fire_counter_ll', 'startbit'=>'0', 'length'=>'7', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'fire_counter_hl', 'startbit'=>'8', 'length'=>'7', 'group'=>'MISO',},
                                },

                'FLM_READ_FIRE_CNT7'=>  {
                                'CODE'=> '0100110110',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Yellow',
                                'parameter_1'=>    {'name'=>'fire_counter_ll', 'startbit'=>'0', 'length'=>'7', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'fire_counter_hl', 'startbit'=>'8', 'length'=>'7', 'group'=>'MISO',},
                                },

                'FLM_READ_FIRE_CNT8'=>  {
                                'CODE'=> '0100110111',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Yellow',
                                'parameter_1'=>    {'name'=>'fire_counter_ll', 'startbit'=>'0', 'length'=>'7', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'fire_counter_hl', 'startbit'=>'8', 'length'=>'7', 'group'=>'MISO',},
                                },

                'FLM_READ_FIRE_CNT9'=>  {
                                'CODE'=> '0100111000',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Yellow',
                                'parameter_1'=>    {'name'=>'fire_counter_ll', 'startbit'=>'0', 'length'=>'7', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'fire_counter_hl', 'startbit'=>'8', 'length'=>'7', 'group'=>'MISO',},
                                },

                'FLM_READ_FIRE_CNT10'=> {
                                'CODE'=> '0100111001',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Yellow',
                                'parameter_1'=>    {'name'=>'fire_counter_ll', 'startbit'=>'0', 'length'=>'7', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'fire_counter_hl', 'startbit'=>'8', 'length'=>'7', 'group'=>'MISO',},
                                },

                'FLM_READ_FIRE_CNT11'=> {
                                'CODE'=> '0100111010',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Yellow',
                                'parameter_1'=>    {'name'=>'fire_counter_ll', 'startbit'=>'0', 'length'=>'7', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'fire_counter_hl', 'startbit'=>'8', 'length'=>'7', 'group'=>'MISO',},
                                },

                'FLM_READ_FIRE_CNT12'=> {
                                'CODE'=> '0100111011',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Yellow',
                                'parameter_1'=>    {'name'=>'fire_counter_ll', 'startbit'=>'0', 'length'=>'7', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'fire_counter_hl', 'startbit'=>'8', 'length'=>'7', 'group'=>'MISO',},
                                },

                'FLM_READ_FIRE_CNT13'=> {
                                'CODE'=> '0100111100',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Yellow',
                                'parameter_1'=>    {'name'=>'fire_counter_ll', 'startbit'=>'0', 'length'=>'7', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'fire_counter_hl', 'startbit'=>'8', 'length'=>'7', 'group'=>'MISO',},
                                },

                'FLM_READ_FIRE_CNT14'=> {
                                'CODE'=> '0100111101',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Yellow',
                                'parameter_1'=>    {'name'=>'fire_counter_ll', 'startbit'=>'0', 'length'=>'7', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'fire_counter_hl', 'startbit'=>'8', 'length'=>'7', 'group'=>'MISO',},
                                },

                'FLM_READ_FIRE_CNT15'=> {
                                'CODE'=> '0100111110',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Yellow',
                                'parameter_1'=>    {'name'=>'fire_counter_ll', 'startbit'=>'0', 'length'=>'7', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'fire_counter_hl', 'startbit'=>'8', 'length'=>'7', 'group'=>'MISO',},
                                },

                'FLM_READ_FIRE_CNT16'=> {
                                'CODE'=> '0100111111',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Yellow',
                                'parameter_1'=>    {'name'=>'fire_counter_ll', 'startbit'=>'0', 'length'=>'7', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'fire_counter_hl', 'startbit'=>'8', 'length'=>'7', 'group'=>'MISO',},
                                },

                'FLM_READ_RES1'=>       {
                                'CODE'=> '0101000000',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Turk',
                                'parameter_1'=>    {'name'=>'res_value', 'startbit'=>'0', 'length'=>'11', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'vd', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO','1'=>'data are valid', '0'=>'data are old or invalid'},
								'parameter_3'=>    {'name'=>'flt', 'startbit'=>'12', 'length'=>'4', 'group'=>'MISO', '0000'=>'no fault', '0010'=>'SQREF too low', '0011'=>'SQREF too high', '1000'=>'lowside shorted to ground (VBAT OK)', '1001'=>'lowside shorted to battery (VBAT OK)', '1010'=>'highside shorted to ground (VBAT OK)', '1011'=>'highside shorted to battery (VBAT OK)', '1100'=>'lowside shorted to ground (VBAT too low)', '1101'=>'lowside shorted to battery (VBAT too low)', '1110'=>'highside shorted to ground (VBAT too low)', '1111'=>'highside shorted to battery (VBAT too low)', '0100'=>'highside voltage too high', '0101'=>'lowside voltage too high', '0110'=>'res_value too high (internal divider overflow)', '0111'=>'lowside voltage >= highside voltage'},
                                },

                'FLM_READ_RES2'=>       {
                                'CODE'=> '0101000001',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Turk',
                                'parameter_1'=>    {'name'=>'res_value', 'startbit'=>'0', 'length'=>'11', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'vd', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO','1'=>'data are valid', '0'=>'data are old or invalid'},
								'parameter_3'=>    {'name'=>'flt', 'startbit'=>'12', 'length'=>'4', 'group'=>'MISO', '0000'=>'no fault', '0010'=>'SQREF too low', '0011'=>'SQREF too high', '1000'=>'lowside shorted to ground (VBAT OK)', '1001'=>'lowside shorted to battery (VBAT OK)', '1010'=>'highside shorted to ground (VBAT OK)', '1011'=>'highside shorted to battery (VBAT OK)', '1100'=>'lowside shorted to ground (VBAT too low)', '1101'=>'lowside shorted to battery (VBAT too low)', '1110'=>'highside shorted to ground (VBAT too low)', '1111'=>'highside shorted to battery (VBAT too low)', '0100'=>'highside voltage too high', '0101'=>'lowside voltage too high', '0110'=>'res_value too high (internal divider overflow)', '0111'=>'lowside voltage >= highside voltage'},
                                },

                'FLM_READ_RES3'=>       {
                                'CODE'=> '0101000010',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Turk',
                                'parameter_1'=>    {'name'=>'res_value', 'startbit'=>'0', 'length'=>'11', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'vd', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO','1'=>'data are valid', '0'=>'data are old or invalid'},
								'parameter_3'=>    {'name'=>'flt', 'startbit'=>'12', 'length'=>'4', 'group'=>'MISO', '0000'=>'no fault', '0010'=>'SQREF too low', '0011'=>'SQREF too high', '1000'=>'lowside shorted to ground (VBAT OK)', '1001'=>'lowside shorted to battery (VBAT OK)', '1010'=>'highside shorted to ground (VBAT OK)', '1011'=>'highside shorted to battery (VBAT OK)', '1100'=>'lowside shorted to ground (VBAT too low)', '1101'=>'lowside shorted to battery (VBAT too low)', '1110'=>'highside shorted to ground (VBAT too low)', '1111'=>'highside shorted to battery (VBAT too low)', '0100'=>'highside voltage too high', '0101'=>'lowside voltage too high', '0110'=>'res_value too high (internal divider overflow)', '0111'=>'lowside voltage >= highside voltage'},
                                },

                'FLM_READ_RES4'=>       {
                                'CODE'=> '0101000011',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Turk',
                                'parameter_1'=>    {'name'=>'res_value', 'startbit'=>'0', 'length'=>'11', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'vd', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO','1'=>'data are valid', '0'=>'data are old or invalid'},
								'parameter_3'=>    {'name'=>'flt', 'startbit'=>'12', 'length'=>'4', 'group'=>'MISO', '0000'=>'no fault', '0010'=>'SQREF too low', '0011'=>'SQREF too high', '1000'=>'lowside shorted to ground (VBAT OK)', '1001'=>'lowside shorted to battery (VBAT OK)', '1010'=>'highside shorted to ground (VBAT OK)', '1011'=>'highside shorted to battery (VBAT OK)', '1100'=>'lowside shorted to ground (VBAT too low)', '1101'=>'lowside shorted to battery (VBAT too low)', '1110'=>'highside shorted to ground (VBAT too low)', '1111'=>'highside shorted to battery (VBAT too low)', '0100'=>'highside voltage too high', '0101'=>'lowside voltage too high', '0110'=>'res_value too high (internal divider overflow)', '0111'=>'lowside voltage >= highside voltage'},
                                },

                'FLM_READ_RES5'=>       {
                                'CODE'=> '0101000100',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Turk',
                                'parameter_1'=>    {'name'=>'res_value', 'startbit'=>'0', 'length'=>'11', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'vd', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO','1'=>'data are valid', '0'=>'data are old or invalid'},
								'parameter_3'=>    {'name'=>'flt', 'startbit'=>'12', 'length'=>'4', 'group'=>'MISO', '0000'=>'no fault', '0010'=>'SQREF too low', '0011'=>'SQREF too high', '1000'=>'lowside shorted to ground (VBAT OK)', '1001'=>'lowside shorted to battery (VBAT OK)', '1010'=>'highside shorted to ground (VBAT OK)', '1011'=>'highside shorted to battery (VBAT OK)', '1100'=>'lowside shorted to ground (VBAT too low)', '1101'=>'lowside shorted to battery (VBAT too low)', '1110'=>'highside shorted to ground (VBAT too low)', '1111'=>'highside shorted to battery (VBAT too low)', '0100'=>'highside voltage too high', '0101'=>'lowside voltage too high', '0110'=>'res_value too high (internal divider overflow)', '0111'=>'lowside voltage >= highside voltage'},
                                },

                'FLM_READ_RES6'=>       {
                                'CODE'=> '0101000101',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Turk',
                                'parameter_1'=>    {'name'=>'res_value', 'startbit'=>'0', 'length'=>'11', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'vd', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO','1'=>'data are valid', '0'=>'data are old or invalid'},
								'parameter_3'=>    {'name'=>'flt', 'startbit'=>'12', 'length'=>'4', 'group'=>'MISO', '0000'=>'no fault', '0010'=>'SQREF too low', '0011'=>'SQREF too high', '1000'=>'lowside shorted to ground (VBAT OK)', '1001'=>'lowside shorted to battery (VBAT OK)', '1010'=>'highside shorted to ground (VBAT OK)', '1011'=>'highside shorted to battery (VBAT OK)', '1100'=>'lowside shorted to ground (VBAT too low)', '1101'=>'lowside shorted to battery (VBAT too low)', '1110'=>'highside shorted to ground (VBAT too low)', '1111'=>'highside shorted to battery (VBAT too low)', '0100'=>'highside voltage too high', '0101'=>'lowside voltage too high', '0110'=>'res_value too high (internal divider overflow)', '0111'=>'lowside voltage >= highside voltage'},
                                },

                'FLM_READ_RES7'=>       {
                                'CODE'=> '0101000110',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Turk',
                                'parameter_1'=>    {'name'=>'res_value', 'startbit'=>'0', 'length'=>'11', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'vd', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO','1'=>'data are valid', '0'=>'data are old or invalid'},
								'parameter_3'=>    {'name'=>'flt', 'startbit'=>'12', 'length'=>'4', 'group'=>'MISO', '0000'=>'no fault', '0010'=>'SQREF too low', '0011'=>'SQREF too high', '1000'=>'lowside shorted to ground (VBAT OK)', '1001'=>'lowside shorted to battery (VBAT OK)', '1010'=>'highside shorted to ground (VBAT OK)', '1011'=>'highside shorted to battery (VBAT OK)', '1100'=>'lowside shorted to ground (VBAT too low)', '1101'=>'lowside shorted to battery (VBAT too low)', '1110'=>'highside shorted to ground (VBAT too low)', '1111'=>'highside shorted to battery (VBAT too low)', '0100'=>'highside voltage too high', '0101'=>'lowside voltage too high', '0110'=>'res_value too high (internal divider overflow)', '0111'=>'lowside voltage >= highside voltage'},
                                },

                'FLM_READ_RES8'=>       {
                                'CODE'=> '0101000111',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Turk',
                                'parameter_1'=>    {'name'=>'res_value', 'startbit'=>'0', 'length'=>'11', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'vd', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO','1'=>'data are valid', '0'=>'data are old or invalid'},
								'parameter_3'=>    {'name'=>'flt', 'startbit'=>'12', 'length'=>'4', 'group'=>'MISO', '0000'=>'no fault', '0010'=>'SQREF too low', '0011'=>'SQREF too high', '1000'=>'lowside shorted to ground (VBAT OK)', '1001'=>'lowside shorted to battery (VBAT OK)', '1010'=>'highside shorted to ground (VBAT OK)', '1011'=>'highside shorted to battery (VBAT OK)', '1100'=>'lowside shorted to ground (VBAT too low)', '1101'=>'lowside shorted to battery (VBAT too low)', '1110'=>'highside shorted to ground (VBAT too low)', '1111'=>'highside shorted to battery (VBAT too low)', '0100'=>'highside voltage too high', '0101'=>'lowside voltage too high', '0110'=>'res_value too high (internal divider overflow)', '0111'=>'lowside voltage >= highside voltage'},
                                },

                'FLM_READ_RES9'=>       {
                                'CODE'=> '0101001000',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Turk',
                                'parameter_1'=>    {'name'=>'res_value', 'startbit'=>'0', 'length'=>'11', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'vd', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO','1'=>'data are valid', '0'=>'data are old or invalid'},
								'parameter_3'=>    {'name'=>'flt', 'startbit'=>'12', 'length'=>'4', 'group'=>'MISO', '0000'=>'no fault', '0010'=>'SQREF too low', '0011'=>'SQREF too high', '1000'=>'lowside shorted to ground (VBAT OK)', '1001'=>'lowside shorted to battery (VBAT OK)', '1010'=>'highside shorted to ground (VBAT OK)', '1011'=>'highside shorted to battery (VBAT OK)', '1100'=>'lowside shorted to ground (VBAT too low)', '1101'=>'lowside shorted to battery (VBAT too low)', '1110'=>'highside shorted to ground (VBAT too low)', '1111'=>'highside shorted to battery (VBAT too low)', '0100'=>'highside voltage too high', '0101'=>'lowside voltage too high', '0110'=>'res_value too high (internal divider overflow)', '0111'=>'lowside voltage >= highside voltage'},
                                },

                'FLM_READ_RES10'=>      {
                                'CODE'=> '0101001001',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Turk',
                                'parameter_1'=>    {'name'=>'res_value', 'startbit'=>'0', 'length'=>'11', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'vd', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO','1'=>'data are valid', '0'=>'data are old or invalid'},
								'parameter_3'=>    {'name'=>'flt', 'startbit'=>'12', 'length'=>'4', 'group'=>'MISO', '0000'=>'no fault', '0010'=>'SQREF too low', '0011'=>'SQREF too high', '1000'=>'lowside shorted to ground (VBAT OK)', '1001'=>'lowside shorted to battery (VBAT OK)', '1010'=>'highside shorted to ground (VBAT OK)', '1011'=>'highside shorted to battery (VBAT OK)', '1100'=>'lowside shorted to ground (VBAT too low)', '1101'=>'lowside shorted to battery (VBAT too low)', '1110'=>'highside shorted to ground (VBAT too low)', '1111'=>'highside shorted to battery (VBAT too low)', '0100'=>'highside voltage too high', '0101'=>'lowside voltage too high', '0110'=>'res_value too high (internal divider overflow)', '0111'=>'lowside voltage >= highside voltage'},
                                },

                'FLM_READ_RES11'=>      {
                                'CODE'=> '0101001010',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Turk',
                                'parameter_1'=>    {'name'=>'res_value', 'startbit'=>'0', 'length'=>'11', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'vd', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO','1'=>'data are valid', '0'=>'data are old or invalid'},
								'parameter_3'=>    {'name'=>'flt', 'startbit'=>'12', 'length'=>'4', 'group'=>'MISO', '0000'=>'no fault', '0010'=>'SQREF too low', '0011'=>'SQREF too high', '1000'=>'lowside shorted to ground (VBAT OK)', '1001'=>'lowside shorted to battery (VBAT OK)', '1010'=>'highside shorted to ground (VBAT OK)', '1011'=>'highside shorted to battery (VBAT OK)', '1100'=>'lowside shorted to ground (VBAT too low)', '1101'=>'lowside shorted to battery (VBAT too low)', '1110'=>'highside shorted to ground (VBAT too low)', '1111'=>'highside shorted to battery (VBAT too low)', '0100'=>'highside voltage too high', '0101'=>'lowside voltage too high', '0110'=>'res_value too high (internal divider overflow)', '0111'=>'lowside voltage >= highside voltage'},
                                },

                'FLM_READ_RES12'=>      {
                                'CODE'=> '0101001011',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Turk',
                                'parameter_1'=>    {'name'=>'res_value', 'startbit'=>'0', 'length'=>'11', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'vd', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO','1'=>'data are valid', '0'=>'data are old or invalid'},
								'parameter_3'=>    {'name'=>'flt', 'startbit'=>'12', 'length'=>'4', 'group'=>'MISO', '0000'=>'no fault', '0010'=>'SQREF too low', '0011'=>'SQREF too high', '1000'=>'lowside shorted to ground (VBAT OK)', '1001'=>'lowside shorted to battery (VBAT OK)', '1010'=>'highside shorted to ground (VBAT OK)', '1011'=>'highside shorted to battery (VBAT OK)', '1100'=>'lowside shorted to ground (VBAT too low)', '1101'=>'lowside shorted to battery (VBAT too low)', '1110'=>'highside shorted to ground (VBAT too low)', '1111'=>'highside shorted to battery (VBAT too low)', '0100'=>'highside voltage too high', '0101'=>'lowside voltage too high', '0110'=>'res_value too high (internal divider overflow)', '0111'=>'lowside voltage >= highside voltage'},
                                },

                'FLM_READ_RES13'=>      {
                                'CODE'=> '0101001100',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Turk',
                                'parameter_1'=>    {'name'=>'res_value', 'startbit'=>'0', 'length'=>'11', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'vd', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO','1'=>'data are valid', '0'=>'data are old or invalid'},
								'parameter_3'=>    {'name'=>'flt', 'startbit'=>'12', 'length'=>'4', 'group'=>'MISO', '0000'=>'no fault', '0010'=>'SQREF too low', '0011'=>'SQREF too high', '1000'=>'lowside shorted to ground (VBAT OK)', '1001'=>'lowside shorted to battery (VBAT OK)', '1010'=>'highside shorted to ground (VBAT OK)', '1011'=>'highside shorted to battery (VBAT OK)', '1100'=>'lowside shorted to ground (VBAT too low)', '1101'=>'lowside shorted to battery (VBAT too low)', '1110'=>'highside shorted to ground (VBAT too low)', '1111'=>'highside shorted to battery (VBAT too low)', '0100'=>'highside voltage too high', '0101'=>'lowside voltage too high', '0110'=>'res_value too high (internal divider overflow)', '0111'=>'lowside voltage >= highside voltage'},
                                },

                'FLM_READ_RES14'=>      {
                                'CODE'=> '0101001101',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Turk',
                                'parameter_1'=>    {'name'=>'res_value', 'startbit'=>'0', 'length'=>'11', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'vd', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO','1'=>'data are valid', '0'=>'data are old or invalid'},
								'parameter_3'=>    {'name'=>'flt', 'startbit'=>'12', 'length'=>'4', 'group'=>'MISO', '0000'=>'no fault', '0010'=>'SQREF too low', '0011'=>'SQREF too high', '1000'=>'lowside shorted to ground (VBAT OK)', '1001'=>'lowside shorted to battery (VBAT OK)', '1010'=>'highside shorted to ground (VBAT OK)', '1011'=>'highside shorted to battery (VBAT OK)', '1100'=>'lowside shorted to ground (VBAT too low)', '1101'=>'lowside shorted to battery (VBAT too low)', '1110'=>'highside shorted to ground (VBAT too low)', '1111'=>'highside shorted to battery (VBAT too low)', '0100'=>'highside voltage too high', '0101'=>'lowside voltage too high', '0110'=>'res_value too high (internal divider overflow)', '0111'=>'lowside voltage >= highside voltage'},
                                },

                'FLM_READ_RES15'=>      {
                                'CODE'=> '0101001110',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Turk',
                                'parameter_1'=>    {'name'=>'res_value', 'startbit'=>'0', 'length'=>'11', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'vd', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO','1'=>'data are valid', '0'=>'data are old or invalid'},
								'parameter_3'=>    {'name'=>'flt', 'startbit'=>'12', 'length'=>'4', 'group'=>'MISO', '0000'=>'no fault', '0010'=>'SQREF too low', '0011'=>'SQREF too high', '1000'=>'lowside shorted to ground (VBAT OK)', '1001'=>'lowside shorted to battery (VBAT OK)', '1010'=>'highside shorted to ground (VBAT OK)', '1011'=>'highside shorted to battery (VBAT OK)', '1100'=>'lowside shorted to ground (VBAT too low)', '1101'=>'lowside shorted to battery (VBAT too low)', '1110'=>'highside shorted to ground (VBAT too low)', '1111'=>'highside shorted to battery (VBAT too low)', '0100'=>'highside voltage too high', '0101'=>'lowside voltage too high', '0110'=>'res_value too high (internal divider overflow)', '0111'=>'lowside voltage >= highside voltage'},
                                },

                'FLM_READ_RES16'=>      {
                                'CODE'=> '0101001111',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Turk',
                                'parameter_1'=>    {'name'=>'res_value', 'startbit'=>'0', 'length'=>'11', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'vd', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO','1'=>'data are valid', '0'=>'data are old or invalid'},
								'parameter_3'=>    {'name'=>'flt', 'startbit'=>'12', 'length'=>'4', 'group'=>'MISO', '0000'=>'no fault', '0010'=>'SQREF too low', '0011'=>'SQREF too high', '1000'=>'lowside shorted to ground (VBAT OK)', '1001'=>'lowside shorted to battery (VBAT OK)', '1010'=>'highside shorted to ground (VBAT OK)', '1011'=>'highside shorted to battery (VBAT OK)', '1100'=>'lowside shorted to ground (VBAT too low)', '1101'=>'lowside shorted to battery (VBAT too low)', '1110'=>'highside shorted to ground (VBAT too low)', '1111'=>'highside shorted to battery (VBAT too low)', '0100'=>'highside voltage too high', '0101'=>'lowside voltage too high', '0110'=>'res_value too high (internal divider overflow)', '0111'=>'lowside voltage >= highside voltage'},
                                },

                'FLM_READ_VH1'=>        {
                                'CODE'=> '0101010000',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Grey',
                                'parameter_1'=>    {'name'=>'adc_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'vd', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO','1'=>'adc data are valid', '0'=>'adc data are old or invalid'},
                                },

                'FLM_READ_VH2'=>        {
                                'CODE'=> '0101010001',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Grey',
                                'parameter_1'=>    {'name'=>'adc_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'vd', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO','1'=>'adc data are valid', '0'=>'adc data are old or invalid'},
                                },

                'FLM_READ_VH3'=>        {
                                'CODE'=> '0101010010',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Grey',
                                'parameter_1'=>    {'name'=>'adc_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'vd', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO','1'=>'adc data are valid', '0'=>'adc data are old or invalid'},
                                },

                'FLM_READ_VH4'=>        {
                                'CODE'=> '0101010011',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Grey',
                                'parameter_1'=>    {'name'=>'adc_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'vd', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO','1'=>'adc data are valid', '0'=>'adc data are old or invalid'},
                                },

                'FLM_READ_VH5'=>        {
                                'CODE'=> '0101010100',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Grey',
                                'parameter_1'=>    {'name'=>'adc_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'vd', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO','1'=>'adc data are valid', '0'=>'adc data are old or invalid'},
                                },

                'FLM_READ_VH6'=>        {
                                'CODE'=> '0101010101',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Grey',
                                'parameter_1'=>    {'name'=>'adc_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'vd', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO','1'=>'adc data are valid', '0'=>'adc data are old or invalid'},
                                },

                'FLM_READ_VH7'=>        {
                                'CODE'=> '0101010110',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Grey',
                                'parameter_1'=>    {'name'=>'adc_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'vd', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO','1'=>'adc data are valid', '0'=>'adc data are old or invalid'},
                                },

                'FLM_READ_VH8'=>        {
                                'CODE'=> '0101010111',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Grey',
                                'parameter_1'=>    {'name'=>'adc_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'vd', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO','1'=>'adc data are valid', '0'=>'adc data are old or invalid'},
                                },

                'FLM_READ_CAP'=>        {
                                'CODE'=> '0101011000',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'Blue',
                                'parameter_1'=>    {'name'=>'cap_time_min', 'startbit'=>'0', 'length'=>'8', 'group'=>'MISO', '11111111'=>'default',},
                                'parameter_2'=>    {'name'=>'cap_time_max', 'startbit'=>'8', 'length'=>'8', 'group'=>'MISO', '00000000'=>'default',},
                                },

                'FLM_READ_SQB'=>        {
                                'CODE'=> '0101011001',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Pink',
                                'parameter_1'=>    {'name'=>'c0', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'c1', 'startbit'=>'1', 'length'=>'1', 'group'=>'MISO',},
								'parameter_3'=>    {'name'=>'c2', 'startbit'=>'2', 'length'=>'1', 'group'=>'MISO',},
								'parameter_4'=>    {'name'=>'c3', 'startbit'=>'3', 'length'=>'1', 'group'=>'MISO',},
								'parameter_5'=>    {'name'=>'c4', 'startbit'=>'4', 'length'=>'1', 'group'=>'MISO',},
								'parameter_6'=>    {'name'=>'c5', 'startbit'=>'5', 'length'=>'1', 'group'=>'MISO',},
								'parameter_7'=>    {'name'=>'c6', 'startbit'=>'6', 'length'=>'1', 'group'=>'MISO',},
								'parameter_8'=>    {'name'=>'c7', 'startbit'=>'7', 'length'=>'1', 'group'=>'MISO',},
								'parameter_9'=>    {'name'=>'c8', 'startbit'=>'8', 'length'=>'1', 'group'=>'MISO',},
								'parameter_10'=>    {'name'=>'c9', 'startbit'=>'9', 'length'=>'1', 'group'=>'MISO',},
								'parameter_11'=>    {'name'=>'c10', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO',},
								'parameter_12'=>    {'name'=>'c11', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO',},
								'parameter_13'=>    {'name'=>'c12', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO',},
								'parameter_14'=>    {'name'=>'c13', 'startbit'=>'13', 'length'=>'1', 'group'=>'MISO',},
								'parameter_15'=>    {'name'=>'c14', 'startbit'=>'14', 'length'=>'1', 'group'=>'MISO',},
								'parameter_16'=>    {'name'=>'c15', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO',},
                                },
								
				'FLM_READ_IGH'=>        {
                                'CODE'=> '0001000110',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Pink',
                                'parameter_1'=>    {'name'=>'c0', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'c1', 'startbit'=>'1', 'length'=>'1', 'group'=>'MISO',},
								'parameter_3'=>    {'name'=>'c2', 'startbit'=>'2', 'length'=>'1', 'group'=>'MISO',},
								'parameter_4'=>    {'name'=>'c3', 'startbit'=>'3', 'length'=>'1', 'group'=>'MISO',},
								'parameter_5'=>    {'name'=>'c4', 'startbit'=>'4', 'length'=>'1', 'group'=>'MISO',},
								'parameter_6'=>    {'name'=>'c5', 'startbit'=>'5', 'length'=>'1', 'group'=>'MISO',},
								'parameter_7'=>    {'name'=>'c6', 'startbit'=>'6', 'length'=>'1', 'group'=>'MISO',},
								'parameter_8'=>    {'name'=>'c7', 'startbit'=>'7', 'length'=>'1', 'group'=>'MISO',},
								'parameter_9'=>    {'name'=>'c8', 'startbit'=>'8', 'length'=>'1', 'group'=>'MISO',},
								'parameter_10'=>    {'name'=>'c9', 'startbit'=>'9', 'length'=>'1', 'group'=>'MISO',},
								'parameter_11'=>    {'name'=>'c10', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO',},
								'parameter_12'=>    {'name'=>'c11', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO',},
								'parameter_13'=>    {'name'=>'c12', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO',},
								'parameter_14'=>    {'name'=>'c13', 'startbit'=>'13', 'length'=>'1', 'group'=>'MISO',},
								'parameter_15'=>    {'name'=>'c14', 'startbit'=>'14', 'length'=>'1', 'group'=>'MISO',},
								'parameter_16'=>    {'name'=>'c15', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO',},
                                },				

                'FLM_READ_SVR'=>        {
                                'CODE'=> '0101011010',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Yellow',
                                'parameter_1'=>    {'name'=>'adc_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'vd', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO','1'=>'adc data are valid', '0'=>'adc data are old or invalid'},
                                },

                'FLM_READ_CC'=> {
                                'CODE'=> '0101011011',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'Green',
                                'parameter_1'=>    {'name'=>'c0', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'c1', 'startbit'=>'1', 'length'=>'1', 'group'=>'MISO',},
								'parameter_3'=>    {'name'=>'c2', 'startbit'=>'2', 'length'=>'1', 'group'=>'MISO',},
								'parameter_4'=>    {'name'=>'c3', 'startbit'=>'3', 'length'=>'1', 'group'=>'MISO',},
								'parameter_5'=>    {'name'=>'c4', 'startbit'=>'4', 'length'=>'1', 'group'=>'MISO',},
								'parameter_6'=>    {'name'=>'c5', 'startbit'=>'5', 'length'=>'1', 'group'=>'MISO',},
								'parameter_7'=>    {'name'=>'c6', 'startbit'=>'6', 'length'=>'1', 'group'=>'MISO',},
								'parameter_8'=>    {'name'=>'c7', 'startbit'=>'7', 'length'=>'1', 'group'=>'MISO',},
								'parameter_9'=>    {'name'=>'c8', 'startbit'=>'8', 'length'=>'1', 'group'=>'MISO',},
								'parameter_10'=>    {'name'=>'c9', 'startbit'=>'9', 'length'=>'1', 'group'=>'MISO',},
								'parameter_11'=>    {'name'=>'c10', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO',},
								'parameter_12'=>    {'name'=>'c11', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO',},
								'parameter_13'=>    {'name'=>'c12', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO',},
								'parameter_14'=>    {'name'=>'c13', 'startbit'=>'13', 'length'=>'1', 'group'=>'MISO',},
								'parameter_15'=>    {'name'=>'c14', 'startbit'=>'14', 'length'=>'1', 'group'=>'MISO',},
								'parameter_16'=>    {'name'=>'c15', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO',},
                                },

                'FLM_READ_PST'=>        {
                                'CODE'=> '0101011100',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => '',
                                'parameter_1'=>    {'name'=>'diag_result', 'startbit'=>'0', 'length'=>'4', 'group'=>'MISO', '0001'=>'time out', '0010'=>'short to ground during test detected', '0100'=>'short to battery during test detected',},
                                'parameter_2'=>    {'name'=>'short_info', 'startbit'=>'4', 'length'=>'4', 'group'=>'MISO', '0001'=>'lowside short to ground', '0010'=>'lowside short to battery', '0100'=>'highside short to ground', '1000'=>'highside short to battery',},
								'parameter_3'=>    {'name'=>'run', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '0'=>'diagnosis not running', '1'=>'diagnosis is running'},
								'parameter_4'=>    {'name'=>'tso', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '0'=>'powerstage testmode not active', '1'=>'powerstage testmode active'},
								'parameter_5'=>    {'name'=>'tss', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO',},
								'parameter_6'=>    {'name'=>'vzl', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '0'=>'VZP OK', '1'=>'VZP too low'},
                                },

                'FLM_READ_MAN'=>        {
                                'CODE'=> '0101011111',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => '',
                                'parameter_1'=>    {'name'=>'adc_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',},
                                'parameter_2'=>    {'name'=>'vd', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO','1'=>'adc data are valid', '0'=>'adc data are old or invalid'},
								'parameter_3'=>    {'name'=>'c0', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO',},
								'parameter_4'=>    {'name'=>'c1', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO',},
								'parameter_5'=>    {'name'=>'c2', 'startbit'=>'13', 'length'=>'1', 'group'=>'MISO',},
								'parameter_6'=>    {'name'=>'c3', 'startbit'=>'14', 'length'=>'1', 'group'=>'MISO',},
								'parameter_7'=>    {'name'=>'vzl', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '1'=>'VZP too low', '0'=>'VZP OK'},
                                },
				'POM_CONVERTER'=>      {
                                'CODE'=> '0001000111',
                                'description'=>'Control dc/dc converter',
                                'datasize'=> '16',
                                'module'=>'POM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_blue',
                                'parameter_1'=>    {'name'=>'off', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'switch off slope shaping control', '0'=>'switch-on slope shaping control'},
								'parameter_2'=>    {'name'=>'ctrl', 'startbit'=>'1', 'length'=>'1', 'group'=>'MOSI', '1'=>'automatic slope shaping control', '0'=>'always on'},
								'parameter_3'=>    {'name'=>'jit', 'startbit'=>'2', 'length'=>'1', 'group'=>'MOSI', '1'=>'jitter active', '0'=>'no jitter'},
								'parameter_4'=>    {'name'=>'sw', 'startbit'=>'3', 'length'=>'1', 'group'=>'MOSI', '1'=>'jitter sweep active', '0'=>'inactive'},
								'parameter_5'=>    {'name'=>'hlf', 'startbit'=>'4', 'length'=>'1', 'group'=>'MOSI', '1'=>'reduces jitter amplitude to half', '0'=>'full jitter amplitude'},
                                },
								
                'POM_READ_AUTO1'=>      {
                                'CODE'=> '0101110000',
                                'description'=>'Read power supply automatic measurement results(VBAT_MON1)',
                                'datasize'=> '16',
                                'module'=>'POM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_blue2',
                                'parameter_1'=>    {'name'=>'adc_result', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',}
                                },

                'POM_READ_AUTO2'=>      {
                                'CODE'=> '0101110001',
                                'description'=>'Read power supply automatic measurement results(VBAT_MON2)',
                                'datasize'=> '16',
                                'module'=>'POM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_blue2',
                                'parameter_1'=>    {'name'=>'adc_result', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',}
                                },

                'POM_READ_AUTO3'=>      {
                                'CODE'=> '0101110010',
                                'description'=>'Read power supply automatic measurement results(VUP)',
                                'datasize'=> '16',
                                'module'=>'POM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_blue2',
                                'parameter_1'=>    {'name'=>'adc_result', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',}
                                },

                'POM_READ_AUTO4'=>      {
                                'CODE'=> '0101110011',
                                'description'=>'Read power supply automatic measurement results(VER)',
                                'datasize'=> '16',
                                'module'=>'POM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_blue2',
                                'parameter_1'=>    {'name'=>'adc_result', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',} 
                                },
								
				'POM_READ_AUTO5'=>      {
                                'CODE'=> '0101110100',
                                'description'=>'Read power supply automatic measurement results(Temparature)',
                                'datasize'=> '16',
                                'module'=>'POM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_blue2',
                                'parameter_1'=>    {'name'=>'adc_result', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',} 
                                },

                'PSI_READ_SCALE1'=>     {
                                'CODE'=> '0101100101',
                                'description'=>'Read PSI sync pulse scale',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Pink',
								'parameter_1'=>    {'name'=>'amp_scale1 - PSI1/3/5', 'startbit'=>'0', 'length'=>'5', 'group'=>'MISO', },
								'parameter_2'=>    {'name'=>'amp_scale2 - PSI2/4/6', 'startbit'=>'5', 'length'=>'5', 'group'=>'MISO', },
                                },

                'PSI_READ_SCALE2'=>     {
                                'CODE'=> '0101100110',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Pink',
                                'parameter_1'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                },

                'PSI_READ_SCALE3'=>     {
                                'CODE'=> '0101100111',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Pink',
                                'parameter_1'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                },

                'FLM_READ_SHORT1'=>     {
                                'CODE'=> '0101101000',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Green2',
                                'parameter_1'=>    {'name'=>'c0', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1'=>'highside short to ground',},
                                'parameter_2'=>    {'name'=>'c1', 'startbit'=>'1', 'length'=>'1', 'group'=>'MISO', '1'=>'highside short to ground',},
								'parameter_3'=>    {'name'=>'c2', 'startbit'=>'2', 'length'=>'1', 'group'=>'MISO', '1'=>'highside short to ground',},
								'parameter_4'=>    {'name'=>'c3', 'startbit'=>'3', 'length'=>'1', 'group'=>'MISO', '1'=>'highside short to ground',},
								'parameter_5'=>    {'name'=>'c4', 'startbit'=>'4', 'length'=>'1', 'group'=>'MISO', '1'=>'highside short to ground',},
								'parameter_6'=>    {'name'=>'c5', 'startbit'=>'5', 'length'=>'1', 'group'=>'MISO', '1'=>'highside short to ground',},
								'parameter_7'=>    {'name'=>'c6', 'startbit'=>'6', 'length'=>'1', 'group'=>'MISO', '1'=>'highside short to ground',},
								'parameter_8'=>    {'name'=>'c7', 'startbit'=>'7', 'length'=>'1', 'group'=>'MISO', '1'=>'highside short to ground',},
								'parameter_9'=>    {'name'=>'c8', 'startbit'=>'8', 'length'=>'1', 'group'=>'MISO', '1'=>'highside short to ground',},
								'parameter_10'=>    {'name'=>'c9', 'startbit'=>'9', 'length'=>'1', 'group'=>'MISO', '1'=>'highside short to ground',},
								'parameter_11'=>    {'name'=>'c10', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'highside short to ground',},
								'parameter_12'=>    {'name'=>'c11', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'highside short to ground',},
								'parameter_13'=>    {'name'=>'c12', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'highside short to ground',},
								'parameter_14'=>    {'name'=>'c13', 'startbit'=>'13', 'length'=>'1', 'group'=>'MISO', '1'=>'highside short to ground',},
								'parameter_15'=>    {'name'=>'c14', 'startbit'=>'14', 'length'=>'1', 'group'=>'MISO', '1'=>'highside short to ground',},
								'parameter_16'=>    {'name'=>'c15', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '1'=>'highside short to ground',},
                                },

                'FLM_READ_SHORT2'=>     {
                                'CODE'=> '0101101001',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Green2',
                                'parameter_1'=>    {'name'=>'c0', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1'=>'highside short to bat',},
                                'parameter_2'=>    {'name'=>'c1', 'startbit'=>'1', 'length'=>'1', 'group'=>'MISO', '1'=>'highside short to bat',},
								'parameter_3'=>    {'name'=>'c2', 'startbit'=>'2', 'length'=>'1', 'group'=>'MISO', '1'=>'highside short to bat',},
								'parameter_4'=>    {'name'=>'c3', 'startbit'=>'3', 'length'=>'1', 'group'=>'MISO', '1'=>'highside short to bat',},
								'parameter_5'=>    {'name'=>'c4', 'startbit'=>'4', 'length'=>'1', 'group'=>'MISO', '1'=>'highside short to bat',},
								'parameter_6'=>    {'name'=>'c5', 'startbit'=>'5', 'length'=>'1', 'group'=>'MISO', '1'=>'highside short to bat',},
								'parameter_7'=>    {'name'=>'c6', 'startbit'=>'6', 'length'=>'1', 'group'=>'MISO', '1'=>'highside short to bat',},
								'parameter_8'=>    {'name'=>'c7', 'startbit'=>'7', 'length'=>'1', 'group'=>'MISO', '1'=>'highside short to bat',},
								'parameter_9'=>    {'name'=>'c8', 'startbit'=>'8', 'length'=>'1', 'group'=>'MISO', '1'=>'highside short to bat',},
								'parameter_10'=>    {'name'=>'c9', 'startbit'=>'9', 'length'=>'1', 'group'=>'MISO', '1'=>'highside short to bat',},
								'parameter_11'=>    {'name'=>'c10', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'highside short to bat',},
								'parameter_12'=>    {'name'=>'c11', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'highside short to bat',},
								'parameter_13'=>    {'name'=>'c12', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'highside short to bat',},
								'parameter_14'=>    {'name'=>'c13', 'startbit'=>'13', 'length'=>'1', 'group'=>'MISO', '1'=>'highside short to bat',},
								'parameter_15'=>    {'name'=>'c14', 'startbit'=>'14', 'length'=>'1', 'group'=>'MISO', '1'=>'highside short to bat',},
								'parameter_16'=>    {'name'=>'c15', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '1'=>'highside short to bat',},
                                },

                'FLM_READ_SHORT3'=>     {
                                'CODE'=> '0101101010',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Green2',
                                'parameter_1'=>    {'name'=>'c0', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1'=>'lowside short to ground',},
                                'parameter_2'=>    {'name'=>'c1', 'startbit'=>'1', 'length'=>'1', 'group'=>'MISO', '1'=>'lowside short to ground',},
								'parameter_3'=>    {'name'=>'c2', 'startbit'=>'2', 'length'=>'1', 'group'=>'MISO', '1'=>'lowside short to ground',},
								'parameter_4'=>    {'name'=>'c3', 'startbit'=>'3', 'length'=>'1', 'group'=>'MISO', '1'=>'lowside short to ground',},
								'parameter_5'=>    {'name'=>'c4', 'startbit'=>'4', 'length'=>'1', 'group'=>'MISO', '1'=>'lowside short to ground',},
								'parameter_6'=>    {'name'=>'c5', 'startbit'=>'5', 'length'=>'1', 'group'=>'MISO', '1'=>'lowside short to ground',},
								'parameter_7'=>    {'name'=>'c6', 'startbit'=>'6', 'length'=>'1', 'group'=>'MISO', '1'=>'lowside short to ground',},
								'parameter_8'=>    {'name'=>'c7', 'startbit'=>'7', 'length'=>'1', 'group'=>'MISO', '1'=>'lowside short to ground',},
								'parameter_9'=>    {'name'=>'c8', 'startbit'=>'8', 'length'=>'1', 'group'=>'MISO', '1'=>'lowside short to ground',},
								'parameter_10'=>    {'name'=>'c9', 'startbit'=>'9', 'length'=>'1', 'group'=>'MISO', '1'=>'lowside short to ground',},
								'parameter_11'=>    {'name'=>'c10', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'lowside short to ground',},
								'parameter_12'=>    {'name'=>'c11', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'lowside short to ground',},
								'parameter_13'=>    {'name'=>'c12', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'lowside short to ground',},
								'parameter_14'=>    {'name'=>'c13', 'startbit'=>'13', 'length'=>'1', 'group'=>'MISO', '1'=>'lowside short to ground',},
								'parameter_15'=>    {'name'=>'c14', 'startbit'=>'14', 'length'=>'1', 'group'=>'MISO', '1'=>'lowside short to ground',},
								'parameter_16'=>    {'name'=>'c15', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '1'=>'lowside short to ground',},
                                },

                'FLM_READ_SHORT4'=>     {
                                'CODE'=> '0101101011',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Green2',
                                'parameter_1'=>    {'name'=>'c0', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1'=>'lowside short to bat',},
                                'parameter_2'=>    {'name'=>'c1', 'startbit'=>'1', 'length'=>'1', 'group'=>'MISO', '1'=>'lowside short to bat',},
								'parameter_3'=>    {'name'=>'c2', 'startbit'=>'2', 'length'=>'1', 'group'=>'MISO', '1'=>'lowside short to bat',},
								'parameter_4'=>    {'name'=>'c3', 'startbit'=>'3', 'length'=>'1', 'group'=>'MISO', '1'=>'lowside short to bat',},
								'parameter_5'=>    {'name'=>'c4', 'startbit'=>'4', 'length'=>'1', 'group'=>'MISO', '1'=>'lowside short to bat',},
								'parameter_6'=>    {'name'=>'c5', 'startbit'=>'5', 'length'=>'1', 'group'=>'MISO', '1'=>'lowside short to bat',},
								'parameter_7'=>    {'name'=>'c6', 'startbit'=>'6', 'length'=>'1', 'group'=>'MISO', '1'=>'lowside short to bat',},
								'parameter_8'=>    {'name'=>'c7', 'startbit'=>'7', 'length'=>'1', 'group'=>'MISO', '1'=>'lowside short to bat',},
								'parameter_9'=>    {'name'=>'c8', 'startbit'=>'8', 'length'=>'1', 'group'=>'MISO', '1'=>'lowside short to bat',},
								'parameter_10'=>    {'name'=>'c9', 'startbit'=>'9', 'length'=>'1', 'group'=>'MISO', '1'=>'lowside short to bat',},
								'parameter_11'=>    {'name'=>'c10', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'lowside short to bat',},
								'parameter_12'=>    {'name'=>'c11', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'lowside short to bat',},
								'parameter_13'=>    {'name'=>'c12', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'lowside short to bat',},
								'parameter_14'=>    {'name'=>'c13', 'startbit'=>'13', 'length'=>'1', 'group'=>'MISO', '1'=>'lowside short to bat',},
								'parameter_15'=>    {'name'=>'c14', 'startbit'=>'14', 'length'=>'1', 'group'=>'MISO', '1'=>'lowside short to bat',},
								'parameter_16'=>    {'name'=>'c15', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '1'=>'lowside short to bat',},
                                },

                'TEST_FLM'=>    {
                                'CODE'=> '01011011--',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => '',
                                'parameter_1'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                },

                'PROG_AIO_WL'=> {
                                'CODE'=> '0110000000',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'AIO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => '',
                                'parameter_1'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                },

                'PROG_SDIS_X'=> {
                                'CODE'=> '0110000001',
                                'description'=>'Program special x-disable influence',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Blue1',
								'parameter_0'=>    {'name'=>'C0', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 0 is set under control of SDIS_X', '0'=>'firing loop 0 is not set under control of SDIS_X',},
								'parameter_1'=>    {'name'=>'C0', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 0 is set under control of SDIS_X', '0'=>'firing loop 0 is not set under control of SDIS_X',},								
								'parameter_2'=>    {'name'=>'C1', 'startbit'=>'1', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 1 is set under control of SDIS_X', '0'=>'firing loop 1 is not set under control of SDIS_X',},
								'parameter_3'=>    {'name'=>'C1', 'startbit'=>'1', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 1 is set under control of SDIS_X', '0'=>'firing loop 1 is not set under control of SDIS_X',},								
								'parameter_4'=>    {'name'=>'C2', 'startbit'=>'2', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 2 is set under control of SDIS_X', '0'=>'firing loop 2 is not set under control of SDIS_X',},
								'parameter_5'=>    {'name'=>'C2', 'startbit'=>'2', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 2 is set under control of SDIS_X', '0'=>'firing loop 2 is not set under control of SDIS_X',},
								'parameter_6'=>    {'name'=>'C3', 'startbit'=>'3', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 3 is set under control of SDIS_X', '0'=>'firing loop 3 is not set under control of SDIS_X',},
								'parameter_7'=>    {'name'=>'C3', 'startbit'=>'3', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 3 is set under control of SDIS_X', '0'=>'firing loop 3 is not set under control of SDIS_X',},
								'parameter_8'=>    {'name'=>'C4', 'startbit'=>'4', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 4 is set under control of SDIS_X', '0'=>'firing loop 4 is not set under control of SDIS_X',},
								'parameter_9'=>    {'name'=>'C4', 'startbit'=>'4', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 4 is set under control of SDIS_X', '0'=>'firing loop 4 is not set under control of SDIS_X',},
								'parameter_10'=>    {'name'=>'C5', 'startbit'=>'5', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 5 is set under control of SDIS_X', '0'=>'firing loop 5 is not set under control of SDIS_X',},
								'parameter_11'=>    {'name'=>'C5', 'startbit'=>'5', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 5 is set under control of SDIS_X', '0'=>'firing loop 5 is not set under control of SDIS_X',},
								'parameter_12'=>    {'name'=>'C6', 'startbit'=>'6', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 6 is set under control of SDIS_X', '0'=>'firing loop 6 is not set under control of SDIS_X',},
								'parameter_13'=>    {'name'=>'C6', 'startbit'=>'6', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 6 is set under control of SDIS_X', '0'=>'firing loop 6 is not set under control of SDIS_X',},
								'parameter_14'=>    {'name'=>'C7', 'startbit'=>'7', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 7 is set under control of SDIS_X', '0'=>'firing loop 7 is not set under control of SDIS_X',},
								'parameter_15'=>    {'name'=>'C7', 'startbit'=>'7', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 7 is set under control of SDIS_X', '0'=>'firing loop 7 is not set under control of SDIS_X',},
								'parameter_16'=>    {'name'=>'C8', 'startbit'=>'8', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 8 is set under control of SDIS_X', '0'=>'firing loop 8 is not set under control of SDIS_X',},
								'parameter_17'=>    {'name'=>'C8', 'startbit'=>'8', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 8 is set under control of SDIS_X', '0'=>'firing loop 8 is not set under control of SDIS_X',},
								'parameter_18'=>    {'name'=>'C9', 'startbit'=>'9', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 9 is set under control of SDIS_X', '0'=>'firing loop 9 is not set under control of SDIS_X',},
								'parameter_19'=>    {'name'=>'C9', 'startbit'=>'9', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 9 is set under control of SDIS_X', '0'=>'firing loop 9 is not set under control of SDIS_X',},
								'parameter_20'=>   {'name'=>'C10', 'startbit'=>'10', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 10 is set under control of SDIS_X', '0'=>'firing loop 10 is not set under control of SDIS_X',},
								'parameter_21'=>   {'name'=>'C10', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 10 is set under control of SDIS_X', '0'=>'firing loop 10 is not set under control of SDIS_X',},
								'parameter_22'=>   {'name'=>'C11', 'startbit'=>'11', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 11 is set under control of SDIS_X', '0'=>'firing loop 11 is not set under control of SDIS_X',},
								'parameter_23'=>   {'name'=>'C11', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 11 is set under control of SDIS_X', '0'=>'firing loop 11 is not set under control of SDIS_X',},
								'parameter_24'=>   {'name'=>'C12', 'startbit'=>'12', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 12 is set under control of SDIS_X', '0'=>'firing loop 12 is not set under control of SDIS_X',},
								'parameter_25'=>   {'name'=>'C12', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 12 is set under control of SDIS_X', '0'=>'firing loop 12 is not set under control of SDIS_X',},
								'parameter_26'=>   {'name'=>'C13', 'startbit'=>'13', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 13 is set under control of SDIS_X', '0'=>'firing loop 13 is not set under control of SDIS_X',},
								'parameter_27'=>   {'name'=>'C13', 'startbit'=>'13', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 13 is set under control of SDIS_X', '0'=>'firing loop 13 is not set under control of SDIS_X',},
								'parameter_28'=>   {'name'=>'C14', 'startbit'=>'14', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 14 is set under control of SDIS_X', '0'=>'firing loop 14 is not set under control of SDIS_X',},
								'parameter_29'=>   {'name'=>'C14', 'startbit'=>'14', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 14 is set under control of SDIS_X', '0'=>'firing loop 14 is not set under control of SDIS_X',},
								'parameter_30'=>   {'name'=>'C15', 'startbit'=>'15', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 15 is set under control of SDIS_X', '0'=>'firing loop 15 is not set under control of SDIS_X',},
								'parameter_31'=>   {'name'=>'C15', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 15 is set under control of SDIS_X', '0'=>'firing loop 15 is not set under control of SDIS_X',},
                                },

                'PROG_SDIS_Y'=> {
                                'CODE'=> '0110000010',
                                'description'=>'Program special y-disable influence',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Blue1',
								'parameter_0'=>    {'name'=>'C0', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 0 is set under control of SDIS_Y', '0'=>'firing loop 0 is not set under control of SDIS_Y',},
								'parameter_1'=>    {'name'=>'C0', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 0 is set under control of SDIS_Y', '0'=>'firing loop 0 is not set under control of SDIS_Y',},								
								'parameter_2'=>    {'name'=>'C1', 'startbit'=>'1', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 1 is set under control of SDIS_Y', '0'=>'firing loop 1 is not set under control of SDIS_Y',},
								'parameter_3'=>    {'name'=>'C1', 'startbit'=>'1', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 1 is set under control of SDIS_Y', '0'=>'firing loop 1 is not set under control of SDIS_Y',},								
								'parameter_4'=>    {'name'=>'C2', 'startbit'=>'2', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 2 is set under control of SDIS_Y', '0'=>'firing loop 2 is not set under control of SDIS_Y',},
								'parameter_5'=>    {'name'=>'C2', 'startbit'=>'2', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 2 is set under control of SDIS_Y', '0'=>'firing loop 2 is not set under control of SDIS_Y',},
								'parameter_6'=>    {'name'=>'C3', 'startbit'=>'3', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 3 is set under control of SDIS_Y', '0'=>'firing loop 3 is not set under control of SDIS_Y',},
								'parameter_7'=>    {'name'=>'C3', 'startbit'=>'3', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 3 is set under control of SDIS_Y', '0'=>'firing loop 3 is not set under control of SDIS_Y',},
								'parameter_8'=>    {'name'=>'C4', 'startbit'=>'4', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 4 is set under control of SDIS_Y', '0'=>'firing loop 4 is not set under control of SDIS_Y',},
								'parameter_9'=>    {'name'=>'C4', 'startbit'=>'4', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 4 is set under control of SDIS_Y', '0'=>'firing loop 4 is not set under control of SDIS_Y',},
								'parameter_10'=>    {'name'=>'C5', 'startbit'=>'5', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 5 is set under control of SDIS_Y', '0'=>'firing loop 5 is not set under control of SDIS_Y',},
								'parameter_11'=>    {'name'=>'C5', 'startbit'=>'5', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 5 is set under control of SDIS_Y', '0'=>'firing loop 5 is not set under control of SDIS_Y',},
								'parameter_12'=>    {'name'=>'C6', 'startbit'=>'6', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 6 is set under control of SDIS_Y', '0'=>'firing loop 6 is not set under control of SDIS_Y',},
								'parameter_13'=>    {'name'=>'C6', 'startbit'=>'6', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 6 is set under control of SDIS_Y', '0'=>'firing loop 6 is not set under control of SDIS_Y',},
								'parameter_14'=>    {'name'=>'C7', 'startbit'=>'7', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 7 is set under control of SDIS_Y', '0'=>'firing loop 7 is not set under control of SDIS_Y',},
								'parameter_15'=>    {'name'=>'C7', 'startbit'=>'7', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 7 is set under control of SDIS_Y', '0'=>'firing loop 7 is not set under control of SDIS_Y',},
								'parameter_16'=>    {'name'=>'C8', 'startbit'=>'8', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 8 is set under control of SDIS_Y', '0'=>'firing loop 8 is not set under control of SDIS_Y',},
								'parameter_17'=>    {'name'=>'C8', 'startbit'=>'8', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 8 is set under control of SDIS_Y', '0'=>'firing loop 8 is not set under control of SDIS_Y',},
								'parameter_18'=>    {'name'=>'C9', 'startbit'=>'9', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 9 is set under control of SDIS_Y', '0'=>'firing loop 9 is not set under control of SDIS_Y',},
								'parameter_19'=>    {'name'=>'C9', 'startbit'=>'9', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 9 is set under control of SDIS_Y', '0'=>'firing loop 9 is not set under control of SDIS_Y',},
								'parameter_20'=>   {'name'=>'C10', 'startbit'=>'10', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 10 is set under control of SDIS_Y', '0'=>'firing loop 10 is not set under control of SDIS_Y',},
								'parameter_21'=>   {'name'=>'C10', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 10 is set under control of SDIS_Y', '0'=>'firing loop 10 is not set under control of SDIS_Y',},
								'parameter_22'=>   {'name'=>'C11', 'startbit'=>'11', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 11 is set under control of SDIS_Y', '0'=>'firing loop 11 is not set under control of SDIS_Y',},
								'parameter_23'=>   {'name'=>'C11', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 11 is set under control of SDIS_Y', '0'=>'firing loop 11 is not set under control of SDIS_Y',},
								'parameter_24'=>   {'name'=>'C12', 'startbit'=>'12', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 12 is set under control of SDIS_Y', '0'=>'firing loop 12 is not set under control of SDIS_Y',},
								'parameter_25'=>   {'name'=>'C12', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 12 is set under control of SDIS_Y', '0'=>'firing loop 12 is not set under control of SDIS_Y',},
								'parameter_26'=>   {'name'=>'C13', 'startbit'=>'13', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 13 is set under control of SDIS_Y', '0'=>'firing loop 13 is not set under control of SDIS_Y',},
								'parameter_27'=>   {'name'=>'C13', 'startbit'=>'13', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 13 is set under control of SDIS_Y', '0'=>'firing loop 13 is not set under control of SDIS_Y',},
								'parameter_28'=>   {'name'=>'C14', 'startbit'=>'14', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 14 is set under control of SDIS_Y', '0'=>'firing loop 14 is not set under control of SDIS_Y',},
								'parameter_29'=>   {'name'=>'C14', 'startbit'=>'14', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 14 is set under control of SDIS_Y', '0'=>'firing loop 14 is not set under control of SDIS_Y',},
								'parameter_30'=>   {'name'=>'C15', 'startbit'=>'15', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 15 is set under control of SDIS_Y', '0'=>'firing loop 15 is not set under control of SDIS_Y',},
								'parameter_31'=>   {'name'=>'C15', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 15 is set under control of SDIS_Y', '0'=>'firing loop 15 is not set under control of SDIS_Y',},
								},

                'PROG_SDIS_W'=> {
                                'CODE'=> '0110000011',
                                'description'=>'Program special w-disable influence',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Blue1',
								'parameter_0'=>    {'name'=>'C0', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 0 is set under control of SDIS_W', '0'=>'firing loop 0 is not set under control of SDIS_W',},
								'parameter_1'=>    {'name'=>'C0', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 0 is set under control of SDIS_W', '0'=>'firing loop 0 is not set under control of SDIS_W',},								
								'parameter_2'=>    {'name'=>'C1', 'startbit'=>'1', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 1 is set under control of SDIS_W', '0'=>'firing loop 1 is not set under control of SDIS_W',},
								'parameter_3'=>    {'name'=>'C1', 'startbit'=>'1', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 1 is set under control of SDIS_W', '0'=>'firing loop 1 is not set under control of SDIS_W',},								
								'parameter_4'=>    {'name'=>'C2', 'startbit'=>'2', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 2 is set under control of SDIS_W', '0'=>'firing loop 2 is not set under control of SDIS_W',},
								'parameter_5'=>    {'name'=>'C2', 'startbit'=>'2', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 2 is set under control of SDIS_W', '0'=>'firing loop 2 is not set under control of SDIS_W',},
								'parameter_6'=>    {'name'=>'C3', 'startbit'=>'3', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 3 is set under control of SDIS_W', '0'=>'firing loop 3 is not set under control of SDIS_W',},
								'parameter_7'=>    {'name'=>'C3', 'startbit'=>'3', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 3 is set under control of SDIS_W', '0'=>'firing loop 3 is not set under control of SDIS_W',},
								'parameter_8'=>    {'name'=>'C4', 'startbit'=>'4', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 4 is set under control of SDIS_W', '0'=>'firing loop 4 is not set under control of SDIS_W',},
								'parameter_9'=>    {'name'=>'C4', 'startbit'=>'4', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 4 is set under control of SDIS_W', '0'=>'firing loop 4 is not set under control of SDIS_W',},
								'parameter_10'=>    {'name'=>'C5', 'startbit'=>'5', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 5 is set under control of SDIS_W', '0'=>'firing loop 5 is not set under control of SDIS_W',},
								'parameter_11'=>    {'name'=>'C5', 'startbit'=>'5', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 5 is set under control of SDIS_W', '0'=>'firing loop 5 is not set under control of SDIS_W',},
								'parameter_12'=>    {'name'=>'C6', 'startbit'=>'6', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 6 is set under control of SDIS_W', '0'=>'firing loop 6 is not set under control of SDIS_W',},
								'parameter_13'=>    {'name'=>'C6', 'startbit'=>'6', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 6 is set under control of SDIS_W', '0'=>'firing loop 6 is not set under control of SDIS_W',},
								'parameter_14'=>    {'name'=>'C7', 'startbit'=>'7', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 7 is set under control of SDIS_W', '0'=>'firing loop 7 is not set under control of SDIS_W',},
								'parameter_15'=>    {'name'=>'C7', 'startbit'=>'7', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 7 is set under control of SDIS_W', '0'=>'firing loop 7 is not set under control of SDIS_W',},
								'parameter_16'=>    {'name'=>'C8', 'startbit'=>'8', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 8 is set under control of SDIS_W', '0'=>'firing loop 8 is not set under control of SDIS_W',},
								'parameter_17'=>    {'name'=>'C8', 'startbit'=>'8', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 8 is set under control of SDIS_W', '0'=>'firing loop 8 is not set under control of SDIS_W',},
								'parameter_18'=>    {'name'=>'C9', 'startbit'=>'9', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 9 is set under control of SDIS_W', '0'=>'firing loop 9 is not set under control of SDIS_W',},
								'parameter_19'=>    {'name'=>'C9', 'startbit'=>'9', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 9 is set under control of SDIS_W', '0'=>'firing loop 9 is not set under control of SDIS_W',},
								'parameter_20'=>   {'name'=>'C10', 'startbit'=>'10', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 10 is set under control of SDIS_W', '0'=>'firing loop 10 is not set under control of SDIS_W',},
								'parameter_21'=>   {'name'=>'C10', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 10 is set under control of SDIS_W', '0'=>'firing loop 10 is not set under control of SDIS_W',},
								'parameter_22'=>   {'name'=>'C11', 'startbit'=>'11', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 11 is set under control of SDIS_W', '0'=>'firing loop 11 is not set under control of SDIS_W',},
								'parameter_23'=>   {'name'=>'C11', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 11 is set under control of SDIS_W', '0'=>'firing loop 11 is not set under control of SDIS_W',},
								'parameter_24'=>   {'name'=>'C12', 'startbit'=>'12', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 12 is set under control of SDIS_W', '0'=>'firing loop 12 is not set under control of SDIS_W',},
								'parameter_25'=>   {'name'=>'C12', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 12 is set under control of SDIS_W', '0'=>'firing loop 12 is not set under control of SDIS_W',},
								'parameter_26'=>   {'name'=>'C13', 'startbit'=>'13', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 13 is set under control of SDIS_W', '0'=>'firing loop 13 is not set under control of SDIS_W',},
								'parameter_27'=>   {'name'=>'C13', 'startbit'=>'13', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 13 is set under control of SDIS_W', '0'=>'firing loop 13 is not set under control of SDIS_W',},
								'parameter_28'=>   {'name'=>'C14', 'startbit'=>'14', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 14 is set under control of SDIS_W', '0'=>'firing loop 14 is not set under control of SDIS_W',},
								'parameter_29'=>   {'name'=>'C14', 'startbit'=>'14', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 14 is set under control of SDIS_W', '0'=>'firing loop 14 is not set under control of SDIS_W',},
								'parameter_30'=>   {'name'=>'C15', 'startbit'=>'15', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 15 is set under control of SDIS_W', '0'=>'firing loop 15 is not set under control of SDIS_W',},
								'parameter_31'=>   {'name'=>'C15', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 15 is set under control of SDIS_W', '0'=>'firing loop 15 is not set under control of SDIS_W',},
                                },

                'PROG_SDIS_S'=> {
                                'CODE'=> '0110000100',
                                'description'=>'Program special switch-disable influence:',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Blue1',
								'parameter_0'=>    {'name'=>'C0', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 0 is set under control of SDIS_S', '0'=>'firing loop 0 is not set under control of SDIS_S',},
								'parameter_1'=>    {'name'=>'C0', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 0 is set under control of SDIS_S', '0'=>'firing loop 0 is not set under control of SDIS_S',},								
								'parameter_2'=>    {'name'=>'C1', 'startbit'=>'1', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 1 is set under control of SDIS_S', '0'=>'firing loop 1 is not set under control of SDIS_S',},
								'parameter_3'=>    {'name'=>'C1', 'startbit'=>'1', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 1 is set under control of SDIS_S', '0'=>'firing loop 1 is not set under control of SDIS_S',},								
								'parameter_4'=>    {'name'=>'C2', 'startbit'=>'2', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 2 is set under control of SDIS_S', '0'=>'firing loop 2 is not set under control of SDIS_S',},
								'parameter_5'=>    {'name'=>'C2', 'startbit'=>'2', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 2 is set under control of SDIS_S', '0'=>'firing loop 2 is not set under control of SDIS_S',},
								'parameter_6'=>    {'name'=>'C3', 'startbit'=>'3', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 3 is set under control of SDIS_S', '0'=>'firing loop 3 is not set under control of SDIS_S',},
								'parameter_7'=>    {'name'=>'C3', 'startbit'=>'3', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 3 is set under control of SDIS_S', '0'=>'firing loop 3 is not set under control of SDIS_S',},
								'parameter_8'=>    {'name'=>'C4', 'startbit'=>'4', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 4 is set under control of SDIS_S', '0'=>'firing loop 4 is not set under control of SDIS_S',},
								'parameter_9'=>    {'name'=>'C4', 'startbit'=>'4', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 4 is set under control of SDIS_S', '0'=>'firing loop 4 is not set under control of SDIS_S',},
								'parameter_10'=>    {'name'=>'C5', 'startbit'=>'5', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 5 is set under control of SDIS_S', '0'=>'firing loop 5 is not set under control of SDIS_S',},
								'parameter_11'=>    {'name'=>'C5', 'startbit'=>'5', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 5 is set under control of SDIS_S', '0'=>'firing loop 5 is not set under control of SDIS_S',},
								'parameter_12'=>    {'name'=>'C6', 'startbit'=>'6', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 6 is set under control of SDIS_S', '0'=>'firing loop 6 is not set under control of SDIS_S',},
								'parameter_13'=>    {'name'=>'C6', 'startbit'=>'6', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 6 is set under control of SDIS_S', '0'=>'firing loop 6 is not set under control of SDIS_S',},
								'parameter_14'=>    {'name'=>'C7', 'startbit'=>'7', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 7 is set under control of SDIS_S', '0'=>'firing loop 7 is not set under control of SDIS_S',},
								'parameter_15'=>    {'name'=>'C7', 'startbit'=>'7', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 7 is set under control of SDIS_S', '0'=>'firing loop 7 is not set under control of SDIS_S',},
								'parameter_16'=>    {'name'=>'C8', 'startbit'=>'8', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 8 is set under control of SDIS_S', '0'=>'firing loop 8 is not set under control of SDIS_S',},
								'parameter_17'=>    {'name'=>'C8', 'startbit'=>'8', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 8 is set under control of SDIS_S', '0'=>'firing loop 8 is not set under control of SDIS_S',},
								'parameter_18'=>    {'name'=>'C9', 'startbit'=>'9', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 9 is set under control of SDIS_S', '0'=>'firing loop 9 is not set under control of SDIS_S',},
								'parameter_19'=>    {'name'=>'C9', 'startbit'=>'9', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 9 is set under control of SDIS_S', '0'=>'firing loop 9 is not set under control of SDIS_S',},
								'parameter_20'=>   {'name'=>'C10', 'startbit'=>'10', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 10 is set under control of SDIS_S', '0'=>'firing loop 10 is not set under control of SDIS_S',},
								'parameter_21'=>   {'name'=>'C10', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 10 is set under control of SDIS_S', '0'=>'firing loop 10 is not set under control of SDIS_S',},
								'parameter_22'=>   {'name'=>'C11', 'startbit'=>'11', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 11 is set under control of SDIS_S', '0'=>'firing loop 11 is not set under control of SDIS_S',},
								'parameter_23'=>   {'name'=>'C11', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 11 is set under control of SDIS_S', '0'=>'firing loop 11 is not set under control of SDIS_S',},
								'parameter_24'=>   {'name'=>'C12', 'startbit'=>'12', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 12 is set under control of SDIS_S', '0'=>'firing loop 12 is not set under control of SDIS_S',},
								'parameter_25'=>   {'name'=>'C12', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 12 is set under control of SDIS_S', '0'=>'firing loop 12 is not set under control of SDIS_S',},
								'parameter_26'=>   {'name'=>'C13', 'startbit'=>'13', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 13 is set under control of SDIS_S', '0'=>'firing loop 13 is not set under control of SDIS_S',},
								'parameter_27'=>   {'name'=>'C13', 'startbit'=>'13', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 13 is set under control of SDIS_S', '0'=>'firing loop 13 is not set under control of SDIS_S',},
								'parameter_28'=>   {'name'=>'C14', 'startbit'=>'14', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 14 is set under control of SDIS_S', '0'=>'firing loop 14 is not set under control of SDIS_S',},
								'parameter_29'=>   {'name'=>'C14', 'startbit'=>'14', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 14 is set under control of SDIS_S', '0'=>'firing loop 14 is not set under control of SDIS_S',},
								'parameter_30'=>   {'name'=>'C15', 'startbit'=>'15', 'length'=>'1', 'group'=>'MOSI', '1'=>'firing loop 15 is set under control of SDIS_S', '0'=>'firing loop 15 is not set under control of SDIS_S',},
								'parameter_31'=>   {'name'=>'C15', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '1'=>'firing loop 15 is set under control of SDIS_S', '0'=>'firing loop 15 is not set under control of SDIS_S',},
                                },

                'PROG_SAFETY'=> {
                                'CODE'=> '0110000101',
                                'description'=>'Program safety functions',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Blue',
								'parameter_1'=>    {'name'=>'sid_pre', 'startbit'=>'0', 'length'=>'2', 'group'=>'MOSI',},
								'parameter_2'=>    {'name'=>'mon_spi', 'startbit'=>'2', 'length'=>'2', 'group'=>'MOSI', '00'=>'16/17 off', '01'=>'16 on', '10'=>'17 on', '11'=>'16/17 on',},
								'parameter_3'=>    {'name'=>'pu', 'startbit'=>'4', 'length'=>'1', 'group'=>'MOSI', '1'=>'disable pull-up of SO pin', '0'=>'pull-up of SO pin active',},
								'parameter_4'=>    {'name'=>'sl', 'startbit'=>'5', 'length'=>'1', 'group'=>'MOSI', '1'=>'Slave mode', '0'=>'master mode',},								
								'parameter_5'=>    {'name'=>'wd', 'startbit'=>'6', 'length'=>'1', 'group'=>'MOSI', '1'=>'watchdog disable time = 360 ms', '0'=>'watchdog disable time = 1000 ms',},
								'parameter_6'=>    {'name'=>'dm', 'startbit'=>'7', 'length'=>'2', 'group'=>'MOSI', '00'=>'no disposal mode active', '01'=>'ACL (PWM) mode enabled', '10'=>'disposal mode 3/4 enabled', '11'=>'no disposal mode active',},
								'parameter_7'=>    {'name'=>'pwmfreq', 'startbit'=>'9', 'length'=>'2', 'group'=>'MOSI', '00'=>'100 Hz', '01'=>'200 Hz', '10'=>'266 Hz', '11'=>'400 Hz',},
								'parameter_8'=>    {'name'=>'sid_pre', 'startbit'=>'0', 'length'=>'2', 'group'=>'MISO',},
								'parameter_9'=>    {'name'=>'mon_spi', 'startbit'=>'2', 'length'=>'2', 'group'=>'MISO', '00'=>'16/17 off', '01'=>'16 on', '10'=>'17 on', '11'=>'16/17 on',},
								'parameter_10'=>    {'name'=>'pu', 'startbit'=>'4', 'length'=>'1', 'group'=>'MISO', '1'=>'disable pull-up of SO pin', '0'=>'pull-up of SO pin active',},
								'parameter_11'=>    {'name'=>'sl', 'startbit'=>'5', 'length'=>'1', 'group'=>'MISO', '1'=>'Slave mode', '0'=>'master mode',},								
								'parameter_12'=>    {'name'=>'wd', 'startbit'=>'6', 'length'=>'1', 'group'=>'MISO', '1'=>'watchdog disable time = 360 ms', '0'=>'watchdog disable time = 1000 ms',},
								'parameter_13'=>    {'name'=>'dm', 'startbit'=>'7', 'length'=>'2', 'group'=>'MISO', '00'=>'no disposal mode active', '01'=>'ACL (PWM) mode enabled', '10'=>'disposal mode 3/4 enabled', '11'=>'no disposal mode active',},
								'parameter_14'=>    {'name'=>'pwmfreq', 'startbit'=>'9', 'length'=>'2', 'group'=>'MISO', '00'=>'100 Hz', '01'=>'200 Hz', '10'=>'266 Hz', '11'=>'400 Hz',},
                                },

                'PROG_SW_MODE'=>        {
                                'CODE'=> '0110000110',
                                'description'=>'Program switch evaluation mode',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Blue1',
								'parameter_1'=>    {'name'=>'en', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '0'=>'switch evaluation using enable band', '1'=>'switch evaluation using disable band'},
								'parameter_2'=>    {'name'=>'count', 'startbit'=>'1', 'length'=>'3', 'group'=>'MOSI',},
								'parameter_3'=>    {'name'=>'sdis_channel', 'startbit'=>'4', 'length'=>'4', 'group'=>'MOSI', '1111'=>'no channel',},
								'parameter_4'=>    {'name'=>'en', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '0'=>'switch evaluation using enable band', '1'=>'switch evaluation using disable band'},
								'parameter_5'=>    {'name'=>'count', 'startbit'=>'1', 'length'=>'3', 'group'=>'MISO',},
								'parameter_6'=>    {'name'=>'sdis_channel', 'startbit'=>'4', 'length'=>'4', 'group'=>'MISO', '1111'=>'no channel',}, 
                               },

                'PROG_SW_UP_THRES'=>    {
                                'CODE'=> '0110000111',
                                'description'=>'Program switch evaluation upper threshold',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Turk',
								'parameter_1'=>    {'name'=>'sw_up_thres', 'startbit'=>'0', 'length'=>'10', 'group'=>'MOSI',},
                                },

                'PROG_SW_LOW_THRES'=>   {
                                'CODE'=> '0110001000',
                                'description'=>'Program switch evaluation lower threshold',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Oker',
								'parameter_1'=>    {'name'=>'sw_low_thres', 'startbit'=>'0', 'length'=>'10', 'group'=>'MOSI',},
                                },

                'PROG_XY45'=>   {
                                'CODE'=> '0110001001',
                                'description'=>'Program x/y data SID in 45� applications',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Pink',
								'parameter_1'=>    {'name'=>'sid_x45', 'startbit'=>'0', 'length'=>'5', 'group'=>'MOSI',},
								'parameter_2'=>    {'name'=>'sid_y45', 'startbit'=>'5', 'length'=>'5', 'group'=>'MOSI',},
								'parameter_3'=>    {'name'=>'mode', 'startbit'=>'10', 'length'=>'2', 'group'=>'MOSI', '00'=>'sensor data expected in 90� orientation', '01'=>'sensor data rotated by +45� (x = data_x � data_y, y = data_x + data_y)', '10'=>'sensor data rotated by -45� (x = data_x + data_y, y = data_x � data_y)', '11'=>'undefined',},
								'parameter_4'=>    {'name'=>'sid_x45', 'startbit'=>'0', 'length'=>'5', 'group'=>'MISO',},
								'parameter_5'=>    {'name'=>'sid_y45', 'startbit'=>'5', 'length'=>'5', 'group'=>'MISO',},
								'parameter_6'=>    {'name'=>'mode', 'startbit'=>'10', 'length'=>'2', 'group'=>'MISO', '00'=>'sensor data expected in 90� orientation', '01'=>'sensor data rotated by +45� (x = data_x � data_y, y = data_x + data_y)', '10'=>'sensor data rotated by -45� (x = data_x + data_y, y = data_x � data_y)', '11'=>'undefined',},  
                              },
							  
                'PROG_PLP_LONG'=>   {
                                'CODE'=> '0110111000',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Pink',
								'parameter_1'=>    {'name'=>'en_time_long', 'startbit'=>'0', 'length'=>'8', 'group'=>'MOSI',},
								'parameter_2'=>    {'name'=>'en_time_long', 'startbit'=>'0', 'length'=>'8', 'group'=>'MISO',},
								'parameter_3'=>    {'name'=>'sid_long', 'startbit'=>'8', 'length'=>'5', 'group'=>'MOSI',},
								'parameter_4'=>    {'name'=>'sid_long', 'startbit'=>'8', 'length'=>'5', 'group'=>'MISO',},
                              },							  

                'PROG_FLM_CONF'=>       {
                                'CODE'=> '0110001010',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Pink',
                                'parameter_1'=>    {'name'=>'sd_mde', 'startbit'=>'0', 'length'=>'2', 'group'=>'MOSI', '00'=>'continuous short detection diagnosis not running', '01'=>'short detection threshold voltage = 2.5V', '10'=>'short detection threshold voltage = 4.0V', '11'=>'continuous short detection diagnosis not running'},
								'parameter_2'=>    {'name'=>'sd_mde', 'startbit'=>'0', 'length'=>'2', 'group'=>'MISO', '00'=>'continuous short detection diagnosis not running', '01'=>'short detection threshold voltage = 2.5V', '10'=>'short detection threshold voltage = 4.0V', '11'=>'continuous short detection diagnosis not running'},
                                'parameter_3'=>    {'name'=>'tcl', 'startbit'=>'2', 'length'=>'1', 'group'=>'MOSI', '0'=>'low current level (40mA)', '1'=>'high current level (60mA)'},
								'parameter_4'=>    {'name'=>'tcl', 'startbit'=>'2', 'length'=>'1', 'group'=>'MISO', '0'=>'low current level (40mA)', '1'=>'high current level (60mA)'},
								'parameter_5'=>    {'name'=>'tr', 'startbit'=>'3', 'length'=>'1', 'group'=>'MOSI', '0'=>'short turn-on time', '1'=>'long turn-on time (for LEA mode)'},
								'parameter_6'=>    {'name'=>'tr', 'startbit'=>'3', 'length'=>'1', 'group'=>'MISO', '0'=>'short turn-on time', '1'=>'long turn-on time (for LEA mode)'},
                                },

				'PROG_FLM_MODE'=>       {
                                'CODE'=> '0110001101',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'FLM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Turk',							
								'parameter_1'=>    {'name'=>'fire_mode_m1', 'startbit'=>'0', 'length'=>'4', 'group'=>'MOSI',},
								'parameter_2'=>    {'name'=>'fire_mode_m1', 'startbit'=>'0', 'length'=>'4', 'group'=>'MISO',},
								'parameter_3'=>    {'name'=>'fire_mode_m2', 'startbit'=>'4', 'length'=>'4', 'group'=>'MOSI',},
								'parameter_4'=>    {'name'=>'fire_mode_m2', 'startbit'=>'4', 'length'=>'4', 'group'=>'MISO',},
								'parameter_5'=>    {'name'=>'fire_mode_m3', 'startbit'=>'8', 'length'=>'4', 'group'=>'MOSI',},
								'parameter_6'=>    {'name'=>'fire_mode_m3', 'startbit'=>'8', 'length'=>'4', 'group'=>'MISO',},
								'parameter_7'=>    {'name'=>'fire_mode_m4', 'startbit'=>'12', 'length'=>'4', 'group'=>'MOSI',},
								'parameter_8'=>    {'name'=>'fire_mode_m4', 'startbit'=>'12', 'length'=>'4', 'group'=>'MISO',},
                                },				
                
				'PROG_PSI_MODE'=>       {
                                'CODE'=> '0110001011',
                                'description'=>'Program PSI mode',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Turk',
								'parameter_1'=>    {'name'=>'trg ', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI','0'=>'PSI sync pulse generated by falling edge of pin N_SYNC', '1'=>'PSI sync pulse generated by rising edge of pin N_SYNC',},
								'parameter_2'=>    {'name'=>'aut ', 'startbit'=>'1', 'length'=>'1', 'group'=>'MOSI', '0'=>'PSI sync pulse is controlld by pin N_SYNC', '1'=>'automatic PSI sync pulse generation every 500us',},
								'parameter_3'=>    {'name'=>'fil ', 'startbit'=>'2', 'length'=>'1', 'group'=>'MOSI', '0'=>'filter time for VAS- and VUP-undervoltage-monitoring is 0,5�s', '1'=>'filter time for VAS- and VUP-undervoltage-monitoring is 10�s',},
								'parameter_5'=>    {'name'=>'p1 ', 'startbit'=>'3', 'length'=>'1', 'group'=>'MOSI', '1'=>'PSI supply is not switched off in case of current limitation',},
								'parameter_6'=>    {'name'=>'del ', 'startbit'=>'4', 'length'=>'4', 'group'=>'MOSI', '0000'=>'no delay between all channels',},
								'parameter_7'=>    {'name'=>'p2', 'startbit'=>'8', 'length'=>'1', 'group'=>'MOSI',},
                                },

                'PROG_POM'=>    {
                                'CODE'=> '0110001100',
                                'description'=>'Program power supply',
                                'datasize'=> '16',
                                'module'=>'POM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Turk',
                                'parameter_1'=>    {'name'=>'iup', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'low level', '0'=>'high level',},
								'parameter_2'=>    {'name'=>'iup', 'startbit'=>'1', 'length'=>'1', 'group'=>'MOSI', '1'=>'VUP off for VUP>VUP_L and VBAT>10V', '0'=>'OK',},
								'parameter_3'=>    {'name'=>'24v', 'startbit'=>'2', 'length'=>'1', 'group'=>'MOSI', '1'=>'lVUP 24V', '0'=>'VUP 33V',},
								'parameter_4'=>    {'name'=>'iup', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1'=>'low level', '0'=>'high level',},
								'parameter_5'=>    {'name'=>'iup', 'startbit'=>'1', 'length'=>'1', 'group'=>'MISO', '1'=>'VUP off for VUP>VUP_L and VBAT>10V', '0'=>'OK',},
								'parameter_6'=>    {'name'=>'24v', 'startbit'=>'2', 'length'=>'1', 'group'=>'MISO', '1'=>'lVUP 24V', '0'=>'VUP 33V',},
                                },

                'PROG_AINO_CONF1'=>     {
                                'CODE'=> '0110010000',
                                'description'=>'Program AIN/AIO measurement configuration',
                                'datasize'=> '16',
                                'module'=>'AINO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'Light_Purple2',
                                'parameter_1'=>    {
                                                        'name'=>'current_level', 'startbit'=>'0', 'length'=>'4', 'group'=>'MOSI', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'src', 'startbit'=>'4', 'length'=>'1', 'group'=>'MOSI', '0'=>'VAS','1'=>'VUP',
                                                        },
								'parameter_3'=>    {
                                                        'name'=>'ui', 'startbit'=>'5', 'length'=>'1', 'group'=>'MOSI', '0'=>'voltage measurement','1'=>'current measurement',
                                                        },
								'parameter_4'=>    {
                                                        'name'=>'mode', 'startbit'=>'6', 'length'=>'2', 'group'=>'MOSI', '00'=>'no measurement','01'=>'no source','10'=>'fix current','11'=>'fix voltage',
                                                        },	
								'parameter_5'=>    {
                                                        'name'=>'current_level', 'startbit'=>'0', 'length'=>'4', 'group'=>'MISO', 
                                                        },
                                'parameter_6'=>    {
                                                        'name'=>'src', 'startbit'=>'4', 'length'=>'1', 'group'=>'MISO', '0'=>'VAS','1'=>'VUP',
                                                        },
								'parameter_7'=>    {
                                                        'name'=>'ui', 'startbit'=>'5', 'length'=>'1', 'group'=>'MISO', '0'=>'voltage measurement','1'=>'current measurement',
                                                        },
								'parameter_8'=>    {
                                                        'name'=>'mode', 'startbit'=>'6', 'length'=>'2', 'group'=>'MISO', '00'=>'no measurement','01'=>'no source','10'=>'fix current','11'=>'fix voltage',
                                                        },						
                                },

                'PROG_AINO_CONF2'=>     {
                                'CODE'=> '0110010001',
                                'description'=>'Program AIN/AIO measurement configuration',
                                'datasize'=> '16',
                                'module'=>'AINO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'Light_Purple2',
                                'parameter_1'=>    {
                                                        'name'=>'current_level', 'startbit'=>'0', 'length'=>'4', 'group'=>'MOSI', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'src', 'startbit'=>'4', 'length'=>'1', 'group'=>'MOSI', '0'=>'VAS','1'=>'VUP',
                                                        },
								'parameter_3'=>    {
                                                        'name'=>'ui', 'startbit'=>'5', 'length'=>'1', 'group'=>'MOSI', '0'=>'voltage measurement','1'=>'current measurement',
                                                        },
								'parameter_4'=>    {
                                                        'name'=>'mode', 'startbit'=>'6', 'length'=>'2', 'group'=>'MOSI', '00'=>'no measurement','01'=>'no source','10'=>'fix current','11'=>'fix voltage',
                                                        },	
								'parameter_5'=>    {
                                                        'name'=>'current_level', 'startbit'=>'0', 'length'=>'4', 'group'=>'MISO', 
                                                        },
                                'parameter_6'=>    {
                                                        'name'=>'src', 'startbit'=>'4', 'length'=>'1', 'group'=>'MISO', '0'=>'VAS','1'=>'VUP',
                                                        },
								'parameter_7'=>    {
                                                        'name'=>'ui', 'startbit'=>'5', 'length'=>'1', 'group'=>'MISO', '0'=>'voltage measurement','1'=>'current measurement',
                                                        },
								'parameter_8'=>    {
                                                        'name'=>'mode', 'startbit'=>'6', 'length'=>'2', 'group'=>'MISO', '00'=>'no measurement','01'=>'no source','10'=>'fix current','11'=>'fix voltage',
                                                        },						
                                },

                'PROG_AINO_CONF3'=>     {
                                'CODE'=> '0110010010',
                                'description'=>'Program AIN/AIO measurement configuration',
                                'datasize'=> '16',
                                'module'=>'AINO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'Light_Purple2',
                                'parameter_1'=>    {
                                                        'name'=>'current_level', 'startbit'=>'0', 'length'=>'4', 'group'=>'MOSI', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'src', 'startbit'=>'4', 'length'=>'1', 'group'=>'MOSI', '0'=>'VAS','1'=>'VUP',
                                                        },
								'parameter_3'=>    {
                                                        'name'=>'ui', 'startbit'=>'5', 'length'=>'1', 'group'=>'MOSI', '0'=>'voltage measurement','1'=>'current measurement',
                                                        },
								'parameter_4'=>    {
                                                        'name'=>'mode', 'startbit'=>'6', 'length'=>'2', 'group'=>'MOSI', '00'=>'no measurement','01'=>'no source','10'=>'fix current','11'=>'fix voltage',
                                                        },	
								'parameter_5'=>    {
                                                        'name'=>'current_level', 'startbit'=>'0', 'length'=>'4', 'group'=>'MISO', 
                                                        },
                                'parameter_6'=>    {
                                                        'name'=>'src', 'startbit'=>'4', 'length'=>'1', 'group'=>'MISO', '0'=>'VAS','1'=>'VUP',
                                                        },
								'parameter_7'=>    {
                                                        'name'=>'ui', 'startbit'=>'5', 'length'=>'1', 'group'=>'MISO', '0'=>'voltage measurement','1'=>'current measurement',
                                                        },
								'parameter_8'=>    {
                                                        'name'=>'mode', 'startbit'=>'6', 'length'=>'2', 'group'=>'MISO', '00'=>'no measurement','01'=>'no source','10'=>'fix current','11'=>'fix voltage',
                                                        },						
                                },

                'PROG_AINO_CONF4'=>     {
                                'CODE'=> '0110010011',
                                'description'=>'Program AIN/AIO measurement configuration',
                                'datasize'=> '16',
                                'module'=>'AINO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'Light_Purple2',
                                'parameter_1'=>    {
                                                        'name'=>'current_level', 'startbit'=>'0', 'length'=>'4', 'group'=>'MOSI', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'src', 'startbit'=>'4', 'length'=>'1', 'group'=>'MOSI', '0'=>'VAS','1'=>'VUP',
                                                        },
								'parameter_3'=>    {
                                                        'name'=>'ui', 'startbit'=>'5', 'length'=>'1', 'group'=>'MOSI', '0'=>'voltage measurement','1'=>'current measurement',
                                                        },
								'parameter_4'=>    {
                                                        'name'=>'mode', 'startbit'=>'6', 'length'=>'2', 'group'=>'MOSI', '00'=>'no measurement','01'=>'no source','10'=>'fix current','11'=>'fix voltage',
                                                        },	
								'parameter_5'=>    {
                                                        'name'=>'current_level', 'startbit'=>'0', 'length'=>'4', 'group'=>'MISO', 
                                                        },
                                'parameter_6'=>    {
                                                        'name'=>'src', 'startbit'=>'4', 'length'=>'1', 'group'=>'MISO', '0'=>'VAS','1'=>'VUP',
                                                        },
								'parameter_7'=>    {
                                                        'name'=>'ui', 'startbit'=>'5', 'length'=>'1', 'group'=>'MISO', '0'=>'voltage measurement','1'=>'current measurement',
                                                        },
								'parameter_8'=>    {
                                                        'name'=>'mode', 'startbit'=>'6', 'length'=>'2', 'group'=>'MISO', '00'=>'no measurement','01'=>'no source','10'=>'fix current','11'=>'fix voltage',
                                                        },						
                                },

                'PROG_AINO_CONF5'=>     {
                                'CODE'=> '0110010100',
                                'description'=>'Program AIN/AIO measurement configuration',
                                'datasize'=> '16',
                                'module'=>'AINO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'Light_Purple2',
                                'parameter_1'=>    {
                                                        'name'=>'current_level', 'startbit'=>'0', 'length'=>'4', 'group'=>'MOSI', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'src', 'startbit'=>'4', 'length'=>'1', 'group'=>'MOSI', '0'=>'VAS','1'=>'VUP',
                                                        },
								'parameter_3'=>    {
                                                        'name'=>'ui', 'startbit'=>'5', 'length'=>'1', 'group'=>'MOSI', '0'=>'voltage measurement','1'=>'current measurement',
                                                        },
								'parameter_4'=>    {
                                                        'name'=>'mode', 'startbit'=>'6', 'length'=>'2', 'group'=>'MOSI', '00'=>'no measurement','01'=>'no source','10'=>'fix current','11'=>'fix voltage',
                                                        },	
								'parameter_5'=>    {
                                                        'name'=>'current_level', 'startbit'=>'0', 'length'=>'4', 'group'=>'MISO', 
                                                        },
                                'parameter_6'=>    {
                                                        'name'=>'src', 'startbit'=>'4', 'length'=>'1', 'group'=>'MISO', '0'=>'VAS','1'=>'VUP',
                                                        },
								'parameter_7'=>    {
                                                        'name'=>'ui', 'startbit'=>'5', 'length'=>'1', 'group'=>'MISO', '0'=>'voltage measurement','1'=>'current measurement',
                                                        },
								'parameter_8'=>    {
                                                        'name'=>'mode', 'startbit'=>'6', 'length'=>'2', 'group'=>'MISO', '00'=>'no measurement','01'=>'no source','10'=>'fix current','11'=>'fix voltage',
                                                        },						
                                },

                'PROG_AINO_CONF6'=>     {
                                'CODE'=> '0110010101',
                                'description'=>'Program AIN/AIO measurement configuration',
                                'datasize'=> '16',
                                'module'=>'AINO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'Light_Purple2',
                                'parameter_1'=>    {
                                                        'name'=>'current_level', 'startbit'=>'0', 'length'=>'4', 'group'=>'MOSI', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'src', 'startbit'=>'4', 'length'=>'1', 'group'=>'MOSI', '0'=>'VAS','1'=>'VUP',
                                                        },
								'parameter_3'=>    {
                                                        'name'=>'ui', 'startbit'=>'5', 'length'=>'1', 'group'=>'MOSI', '0'=>'voltage measurement','1'=>'current measurement',
                                                        },
								'parameter_4'=>    {
                                                        'name'=>'mode', 'startbit'=>'6', 'length'=>'2', 'group'=>'MOSI', '00'=>'no measurement','01'=>'no source','10'=>'fix current','11'=>'fix voltage',
                                                        },	
								'parameter_5'=>    {
                                                        'name'=>'current_level', 'startbit'=>'0', 'length'=>'4', 'group'=>'MISO', 
                                                        },
                                'parameter_6'=>    {
                                                        'name'=>'src', 'startbit'=>'4', 'length'=>'1', 'group'=>'MISO', '0'=>'VAS','1'=>'VUP',
                                                        },
								'parameter_7'=>    {
                                                        'name'=>'ui', 'startbit'=>'5', 'length'=>'1', 'group'=>'MISO', '0'=>'voltage measurement','1'=>'current measurement',
                                                        },
								'parameter_8'=>    {
                                                        'name'=>'mode', 'startbit'=>'6', 'length'=>'2', 'group'=>'MISO', '00'=>'no measurement','01'=>'no source','10'=>'fix current','11'=>'fix voltage',
                                                        },						
                                },

                'PROG_AINO_CONF7'=>     {
                                'CODE'=> '0110010110',
                                'description'=>'Program AIN/AIO measurement configuration',
                                'datasize'=> '16',
                                'module'=>'AINO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'Light_Purple2',
                                'parameter_1'=>    {
                                                        'name'=>'current_level', 'startbit'=>'0', 'length'=>'4', 'group'=>'MOSI', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'src', 'startbit'=>'4', 'length'=>'1', 'group'=>'MOSI', '0'=>'VAS','1'=>'VUP',
                                                        },
								'parameter_3'=>    {
                                                        'name'=>'ui', 'startbit'=>'5', 'length'=>'1', 'group'=>'MOSI', '0'=>'voltage measurement','1'=>'current measurement',
                                                        },
								'parameter_4'=>    {
                                                        'name'=>'mode', 'startbit'=>'6', 'length'=>'2', 'group'=>'MOSI', '00'=>'no measurement','01'=>'no source','10'=>'fix current','11'=>'fix voltage',
                                                        },	
								'parameter_5'=>    {
                                                        'name'=>'current_level', 'startbit'=>'0', 'length'=>'4', 'group'=>'MISO', 
                                                        },
                                'parameter_6'=>    {
                                                        'name'=>'src', 'startbit'=>'4', 'length'=>'1', 'group'=>'MISO', '0'=>'VAS','1'=>'VUP',
                                                        },
								'parameter_7'=>    {
                                                        'name'=>'ui', 'startbit'=>'5', 'length'=>'1', 'group'=>'MISO', '0'=>'voltage measurement','1'=>'current measurement',
                                                        },
								'parameter_8'=>    {
                                                        'name'=>'mode', 'startbit'=>'6', 'length'=>'2', 'group'=>'MISO', '00'=>'no measurement','01'=>'no source','10'=>'fix current','11'=>'fix voltage',
                                                        },						
                                },

                'PROG_AINO_CONF8'=>     {
                                'CODE'=> '0110010111',
                                'description'=>'Program AIN/AIO measurement configuration',
                                'datasize'=> '16',
                                'module'=>'AINO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'Light_Purple2',
                                'parameter_1'=>    {
                                                        'name'=>'current_level', 'startbit'=>'0', 'length'=>'4', 'group'=>'MOSI', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'src', 'startbit'=>'4', 'length'=>'1', 'group'=>'MOSI', '0'=>'VAS','1'=>'VUP',
                                                        },
								'parameter_3'=>    {
                                                        'name'=>'ui', 'startbit'=>'5', 'length'=>'1', 'group'=>'MOSI', '0'=>'voltage measurement','1'=>'current measurement',
                                                        },
								'parameter_4'=>    {
                                                        'name'=>'mode', 'startbit'=>'6', 'length'=>'2', 'group'=>'MOSI', '00'=>'no measurement','01'=>'no source','10'=>'fix current','11'=>'fix voltage',
                                                        },	
								'parameter_5'=>    {
                                                        'name'=>'current_level', 'startbit'=>'0', 'length'=>'4', 'group'=>'MISO', 
                                                        },
                                'parameter_6'=>    {
                                                        'name'=>'src', 'startbit'=>'4', 'length'=>'1', 'group'=>'MISO', '0'=>'VAS','1'=>'VUP',
                                                        },
								'parameter_7'=>    {
                                                        'name'=>'ui', 'startbit'=>'5', 'length'=>'1', 'group'=>'MISO', '0'=>'voltage measurement','1'=>'current measurement',
                                                        },
								'parameter_8'=>    {
                                                        'name'=>'mode', 'startbit'=>'6', 'length'=>'2', 'group'=>'MISO', '00'=>'no measurement','01'=>'no source','10'=>'fix current','11'=>'fix voltage',
                                                        },						
                                },

                'PROG_AINO_CONF9'=>     {
                                'CODE'=> '0110011000',
                                'description'=>'Program AIN/AIO measurement configuration',
                                'datasize'=> '16',
                                'module'=>'AINO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'Light_Purple2',
                                'parameter_1'=>    {
                                                        'name'=>'current_level', 'startbit'=>'0', 'length'=>'4', 'group'=>'MOSI', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'src', 'startbit'=>'4', 'length'=>'1', 'group'=>'MOSI', '0'=>'VAS','1'=>'VUP',
                                                        },
								'parameter_3'=>    {
                                                        'name'=>'ui', 'startbit'=>'5', 'length'=>'1', 'group'=>'MOSI', '0'=>'voltage measurement','1'=>'current measurement',
                                                        },
								'parameter_4'=>    {
                                                        'name'=>'mode', 'startbit'=>'6', 'length'=>'2', 'group'=>'MOSI', '00'=>'no measurement','01'=>'no source','10'=>'fix current','11'=>'fix voltage',
                                                        },	
								'parameter_5'=>    {
                                                        'name'=>'current_level', 'startbit'=>'0', 'length'=>'4', 'group'=>'MISO', 
                                                        },
                                'parameter_6'=>    {
                                                        'name'=>'src', 'startbit'=>'4', 'length'=>'1', 'group'=>'MISO', '0'=>'VAS','1'=>'VUP',
                                                        },
								'parameter_7'=>    {
                                                        'name'=>'ui', 'startbit'=>'5', 'length'=>'1', 'group'=>'MISO', '0'=>'voltage measurement','1'=>'current measurement',
                                                        },
								'parameter_8'=>    {
                                                        'name'=>'mode', 'startbit'=>'6', 'length'=>'2', 'group'=>'MISO', '00'=>'no measurement','01'=>'no source','10'=>'fix current','11'=>'fix voltage',
                                                        },						
                                },

                'PROG_AINO_CONF10'=>    {
                                'CODE'=> '0110011001',
                                'description'=>'Program AIN/AIO measurement configuration',
                                'datasize'=> '16',
                                'module'=>'AINO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'Light_Purple2',
                                'parameter_1'=>    {
                                                        'name'=>'current_level', 'startbit'=>'0', 'length'=>'4', 'group'=>'MOSI', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'src', 'startbit'=>'4', 'length'=>'1', 'group'=>'MOSI', '0'=>'VAS','1'=>'VUP',
                                                        },
								'parameter_3'=>    {
                                                        'name'=>'ui', 'startbit'=>'5', 'length'=>'1', 'group'=>'MOSI', '0'=>'voltage measurement','1'=>'current measurement',
                                                        },
								'parameter_4'=>    {
                                                        'name'=>'mode', 'startbit'=>'6', 'length'=>'2', 'group'=>'MOSI', '00'=>'no measurement','01'=>'no source','10'=>'fix current','11'=>'fix voltage',
                                                        },	
								'parameter_5'=>    {
                                                        'name'=>'current_level', 'startbit'=>'0', 'length'=>'4', 'group'=>'MISO', 
                                                        },
                                'parameter_6'=>    {
                                                        'name'=>'src', 'startbit'=>'4', 'length'=>'1', 'group'=>'MISO', '0'=>'VAS','1'=>'VUP',
                                                        },
								'parameter_7'=>    {
                                                        'name'=>'ui', 'startbit'=>'5', 'length'=>'1', 'group'=>'MISO', '0'=>'voltage measurement','1'=>'current measurement',
                                                        },
								'parameter_8'=>    {
                                                        'name'=>'mode', 'startbit'=>'6', 'length'=>'2', 'group'=>'MISO', '00'=>'no measurement','01'=>'no source','10'=>'fix current','11'=>'fix voltage',
                                                        },						
                                },

                'PROG_AINO_CONF11'=>    {
                                'CODE'=> '0110011010',
                                'description'=>'Program AIN/AIO measurement configuration',
                                'datasize'=> '16',
                                'module'=>'AINO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'Light_Purple2',
                                'parameter_1'=>    {
                                                        'name'=>'current_level', 'startbit'=>'0', 'length'=>'4', 'group'=>'MOSI', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'src', 'startbit'=>'4', 'length'=>'1', 'group'=>'MOSI', '0'=>'VAS','1'=>'VUP',
                                                        },
								'parameter_3'=>    {
                                                        'name'=>'ui', 'startbit'=>'5', 'length'=>'1', 'group'=>'MOSI', '0'=>'voltage measurement','1'=>'current measurement',
                                                        },
								'parameter_4'=>    {
                                                        'name'=>'mode', 'startbit'=>'6', 'length'=>'2', 'group'=>'MOSI', '00'=>'no measurement','01'=>'no source','10'=>'fix current','11'=>'fix voltage',
                                                        },	
								'parameter_5'=>    {
                                                        'name'=>'current_level', 'startbit'=>'0', 'length'=>'4', 'group'=>'MISO', 
                                                        },
                                'parameter_6'=>    {
                                                        'name'=>'src', 'startbit'=>'4', 'length'=>'1', 'group'=>'MISO', '0'=>'VAS','1'=>'VUP',
                                                        },
								'parameter_7'=>    {
                                                        'name'=>'ui', 'startbit'=>'5', 'length'=>'1', 'group'=>'MISO', '0'=>'voltage measurement','1'=>'current measurement',
                                                        },
								'parameter_8'=>    {
                                                        'name'=>'mode', 'startbit'=>'6', 'length'=>'2', 'group'=>'MISO', '00'=>'no measurement','01'=>'no source','10'=>'fix current','11'=>'fix voltage',
                                                        },						
                                },                     
                                

                'PROG_AINO_CONF12'=>    {
                                'CODE'=> '0110011011',
                               'description'=>'Program AIN/AIO measurement configuration',
                                'datasize'=> '16',
                                'module'=>'AINO',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'Light_Purple2',
                                'parameter_1'=>    {
                                                        'name'=>'current_level', 'startbit'=>'0', 'length'=>'4', 'group'=>'MOSI', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'src', 'startbit'=>'4', 'length'=>'1', 'group'=>'MOSI', '0'=>'VAS','1'=>'VUP',
                                                        },
								'parameter_3'=>    {
                                                        'name'=>'ui', 'startbit'=>'5', 'length'=>'1', 'group'=>'MOSI',  '0'=>'voltage measurement','1'=>'current measurement',
                                                        },
								'parameter_4'=>    {
                                                        'name'=>'mode', 'startbit'=>'6', 'length'=>'2', 'group'=>'MOSI', '00'=>'no measurement','01'=>'no source','10'=>'fix current','11'=>'fix voltage',
                                                        },	
								'parameter_5'=>    {
                                                        'name'=>'current_level', 'startbit'=>'0', 'length'=>'4', 'group'=>'MISO', 
                                                        },
                                'parameter_6'=>    {
                                                        'name'=>'src', 'startbit'=>'4', 'length'=>'1', 'group'=>'MISO', '0'=>'VAS','1'=>'VUP',
                                                        },
								'parameter_7'=>    {
                                                        'name'=>'ui', 'startbit'=>'5', 'length'=>'1', 'group'=>'MISO',  '0'=>'voltage measurement','1'=>'current measurement',
                                                        },
								'parameter_8'=>    {
                                                        'name'=>'mode', 'startbit'=>'6', 'length'=>'2', 'group'=>'MISO', '00'=>'no measurement','01'=>'no source','10'=>'fix current','11'=>'fix voltage',
                                                        },						
                                }, 
								
                'PROG_SAF_CH1'=>        {
                                'CODE'=> '0110100000',
                                'description'=>'Program safety channels',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Grey',
								'parameter_1'=> {'name'=>'saf_thres', 'startbit'=>'0', 'length'=>'8', 'group'=>'MOSI',},
								'parameter_2'=> {'name'=>'f_coeff', 'startbit'=>'8', 'length'=>'2', 'group'=>'MOSI', '00' => '43 Hz', '01' => '60 Hz', '10' => '78 Hz', '11' => '98 Hz'},
								'parameter_3'=> {'name'=>'fon', 'startbit'=>'10', 'length'=>'1', 'group'=>'MOSI', '1'=>'filter on', '0'=>'filter off',},
								'parameter_4'=> {'name'=>'dw', 'startbit'=>'11', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_W influence on', '0'=>'SDIS_W influence off',},
								'parameter_5'=> {'name'=>'dy', 'startbit'=>'12', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_Y influence on', '0'=>'SDIS_Y influence off',},
								'parameter_6'=> {'name'=>'dx', 'startbit'=>'13', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_X influence on', '0'=>'SDIS_X influence off',},
								'parameter_7'=> {'name'=>'zro', 'startbit'=>'14', 'length'=>'1', 'group'=>'MOSI', '1'=>'zeroing (set data to zero if data > +480 / < -480', '0'=>'No zeroing',},
								'parameter_8'=> {'name'=>'shft', 'startbit'=>'15', 'length'=>'1', 'group'=>'MOSI', '1'=>'shift 16 down to 10 bits on (shift 5 bits + clipping to +511/-512)', '0'=>'No shifting',},
								'parameter_9'=> {'name'=>'saf_thres', 'startbit'=>'0', 'length'=>'8', 'group'=>'MISO',},
								'parameter_10'=> {'name'=>'f_coeff', 'startbit'=>'8', 'length'=>'2', 'group'=>'MISO', '00' => '43 Hz', '01' => '60 Hz', '10' => '78 Hz', '11' => '98 Hz'},
								'parameter_11'=> {'name'=>'fon', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'filter on', '0'=>'filter off',},
								'parameter_12'=> {'name'=>'dw', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_W influence on', '0'=>'SDIS_W influence off',},
								'parameter_13'=> {'name'=>'dy', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_Y influence on', '0'=>'SDIS_Y influence off',},
								'parameter_14'=> {'name'=>'dx', 'startbit'=>'13', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_X influence on', '0'=>'SDIS_X influence off',},
								'parameter_15'=> {'name'=>'zro', 'startbit'=>'14', 'length'=>'1', 'group'=>'MISO', '1'=>'zeroing (set data to zero if data > +480 / < -480', '0'=>'No zeroing',},
								'parameter_16'=> {'name'=>'shft', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '1'=>'shift 16 down to 10 bits on (shift 5 bits + clipping to +511/-512)', '0'=>'No shifting',},
								},

                'PROG_SAF_CH2'=>        {
                                'CODE'=> '0110100001',
                                'description'=>'Program safety channels',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Grey',
								'parameter_1'=> {'name'=>'saf_thres', 'startbit'=>'0', 'length'=>'8', 'group'=>'MOSI',},
								'parameter_2'=> {'name'=>'f_coeff', 'startbit'=>'8', 'length'=>'2', 'group'=>'MOSI', '00' => '43 Hz', '01' => '60 Hz', '10' => '78 Hz', '11' => '98 Hz'},
								'parameter_3'=> {'name'=>'fon', 'startbit'=>'10', 'length'=>'1', 'group'=>'MOSI', '1'=>'filter on', '0'=>'filter off',},
								'parameter_4'=> {'name'=>'dw', 'startbit'=>'11', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_W influence on', '0'=>'SDIS_W influence off',},
								'parameter_5'=> {'name'=>'dy', 'startbit'=>'12', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_Y influence on', '0'=>'SDIS_Y influence off',},
								'parameter_6'=> {'name'=>'dx', 'startbit'=>'13', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_X influence on', '0'=>'SDIS_X influence off',},
								'parameter_7'=> {'name'=>'zro', 'startbit'=>'14', 'length'=>'1', 'group'=>'MOSI', '1'=>'zeroing (set data to zero if data > +480 / < -480', '0'=>'No zeroing',},
								'parameter_8'=> {'name'=>'shft', 'startbit'=>'15', 'length'=>'1', 'group'=>'MOSI', '1'=>'shift 16 down to 10 bits on (shift 5 bits + clipping to +511/-512)', '0'=>'No shifting',},
								'parameter_9'=> {'name'=>'saf_thres', 'startbit'=>'0', 'length'=>'8', 'group'=>'MISO',},
								'parameter_10'=> {'name'=>'f_coeff', 'startbit'=>'8', 'length'=>'2', 'group'=>'MISO', '00' => '43 Hz', '01' => '60 Hz', '10' => '78 Hz', '11' => '98 Hz'},
								'parameter_11'=> {'name'=>'fon', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'filter on', '0'=>'filter off',},
								'parameter_12'=> {'name'=>'dw', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_W influence on', '0'=>'SDIS_W influence off',},
								'parameter_13'=> {'name'=>'dy', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_Y influence on', '0'=>'SDIS_Y influence off',},
								'parameter_14'=> {'name'=>'dx', 'startbit'=>'13', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_X influence on', '0'=>'SDIS_X influence off',},
								'parameter_15'=> {'name'=>'zro', 'startbit'=>'14', 'length'=>'1', 'group'=>'MISO', '1'=>'zeroing (set data to zero if data > +480 / < -480', '0'=>'No zeroing',},
								'parameter_16'=> {'name'=>'shft', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '1'=>'shift 16 down to 10 bits on (shift 5 bits + clipping to +511/-512)', '0'=>'No shifting',},
                                },

                'PROG_SAF_CH3'=>        {
                                'CODE'=> '0110100010',
                                'description'=>'Program safety channels',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Grey',
								'parameter_1'=> {'name'=>'saf_thres', 'startbit'=>'0', 'length'=>'8', 'group'=>'MOSI',},
								'parameter_2'=> {'name'=>'f_coeff', 'startbit'=>'8', 'length'=>'2', 'group'=>'MOSI', '00' => '43 Hz', '01' => '60 Hz', '10' => '78 Hz', '11' => '98 Hz'},
								'parameter_3'=> {'name'=>'fon', 'startbit'=>'10', 'length'=>'1', 'group'=>'MOSI', '1'=>'filter on', '0'=>'filter off',},
								'parameter_4'=> {'name'=>'dw', 'startbit'=>'11', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_W influence on', '0'=>'SDIS_W influence off',},
								'parameter_5'=> {'name'=>'dy', 'startbit'=>'12', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_Y influence on', '0'=>'SDIS_Y influence off',},
								'parameter_6'=> {'name'=>'dx', 'startbit'=>'13', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_X influence on', '0'=>'SDIS_X influence off',},
								'parameter_7'=> {'name'=>'zro', 'startbit'=>'14', 'length'=>'1', 'group'=>'MOSI', '1'=>'zeroing (set data to zero if data > +480 / < -480', '0'=>'No zeroing',},
								'parameter_8'=> {'name'=>'shft', 'startbit'=>'15', 'length'=>'1', 'group'=>'MOSI', '1'=>'shift 16 down to 10 bits on (shift 5 bits + clipping to +511/-512)', '0'=>'No shifting',},
								'parameter_9'=> {'name'=>'saf_thres', 'startbit'=>'0', 'length'=>'8', 'group'=>'MISO',},
								'parameter_10'=> {'name'=>'f_coeff', 'startbit'=>'8', 'length'=>'2', 'group'=>'MISO', '00' => '43 Hz', '01' => '60 Hz', '10' => '78 Hz', '11' => '98 Hz'},
								'parameter_11'=> {'name'=>'fon', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'filter on', '0'=>'filter off',},
								'parameter_12'=> {'name'=>'dw', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_W influence on', '0'=>'SDIS_W influence off',},
								'parameter_13'=> {'name'=>'dy', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_Y influence on', '0'=>'SDIS_Y influence off',},
								'parameter_14'=> {'name'=>'dx', 'startbit'=>'13', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_X influence on', '0'=>'SDIS_X influence off',},
								'parameter_15'=> {'name'=>'zro', 'startbit'=>'14', 'length'=>'1', 'group'=>'MISO', '1'=>'zeroing (set data to zero if data > +480 / < -480', '0'=>'No zeroing',},
								'parameter_16'=> {'name'=>'shft', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '1'=>'shift 16 down to 10 bits on (shift 5 bits + clipping to +511/-512)', '0'=>'No shifting',},
                                },

                'PROG_SAF_CH4'=>        {
                                'CODE'=> '0110100011',
                                'description'=>'Program safety channels',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Grey',
								'parameter_1'=> {'name'=>'saf_thres', 'startbit'=>'0', 'length'=>'8', 'group'=>'MOSI',},
								'parameter_2'=> {'name'=>'f_coeff', 'startbit'=>'8', 'length'=>'2', 'group'=>'MOSI', '00' => '43 Hz', '01' => '60 Hz', '10' => '78 Hz', '11' => '98 Hz'},
								'parameter_3'=> {'name'=>'fon', 'startbit'=>'10', 'length'=>'1', 'group'=>'MOSI', '1'=>'filter on', '0'=>'filter off',},
								'parameter_4'=> {'name'=>'dw', 'startbit'=>'11', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_W influence on', '0'=>'SDIS_W influence off',},
								'parameter_5'=> {'name'=>'dy', 'startbit'=>'12', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_Y influence on', '0'=>'SDIS_Y influence off',},
								'parameter_6'=> {'name'=>'dx', 'startbit'=>'13', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_X influence on', '0'=>'SDIS_X influence off',},
								'parameter_7'=> {'name'=>'zro', 'startbit'=>'14', 'length'=>'1', 'group'=>'MOSI', '1'=>'zeroing (set data to zero if data > +480 / < -480', '0'=>'No zeroing',},
								'parameter_8'=> {'name'=>'shft', 'startbit'=>'15', 'length'=>'1', 'group'=>'MOSI', '1'=>'shift 16 down to 10 bits on (shift 5 bits + clipping to +511/-512)', '0'=>'No shifting',},
								'parameter_9'=> {'name'=>'saf_thres', 'startbit'=>'0', 'length'=>'8', 'group'=>'MISO',},
								'parameter_10'=> {'name'=>'f_coeff', 'startbit'=>'8', 'length'=>'2', 'group'=>'MISO', '00' => '43 Hz', '01' => '60 Hz', '10' => '78 Hz', '11' => '98 Hz'},
								'parameter_11'=> {'name'=>'fon', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'filter on', '0'=>'filter off',},
								'parameter_12'=> {'name'=>'dw', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_W influence on', '0'=>'SDIS_W influence off',},
								'parameter_13'=> {'name'=>'dy', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_Y influence on', '0'=>'SDIS_Y influence off',},
								'parameter_14'=> {'name'=>'dx', 'startbit'=>'13', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_X influence on', '0'=>'SDIS_X influence off',},
								'parameter_15'=> {'name'=>'zro', 'startbit'=>'14', 'length'=>'1', 'group'=>'MISO', '1'=>'zeroing (set data to zero if data > +480 / < -480', '0'=>'No zeroing',},
								'parameter_16'=> {'name'=>'shft', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '1'=>'shift 16 down to 10 bits on (shift 5 bits + clipping to +511/-512)', '0'=>'No shifting',},
                                },

                'PROG_SAF_CH5'=>        {
                                'CODE'=> '0110100100',
                                'description'=>'Program safety channels',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Grey',
								'parameter_1'=> {'name'=>'saf_thres', 'startbit'=>'0', 'length'=>'8', 'group'=>'MOSI',},
								'parameter_2'=> {'name'=>'f_coeff', 'startbit'=>'8', 'length'=>'2', 'group'=>'MOSI', '00' => '43 Hz', '01' => '60 Hz', '10' => '78 Hz', '11' => '98 Hz'},
								'parameter_3'=> {'name'=>'fon', 'startbit'=>'10', 'length'=>'1', 'group'=>'MOSI', '1'=>'filter on', '0'=>'filter off',},
								'parameter_4'=> {'name'=>'dw', 'startbit'=>'11', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_W influence on', '0'=>'SDIS_W influence off',},
								'parameter_5'=> {'name'=>'dy', 'startbit'=>'12', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_Y influence on', '0'=>'SDIS_Y influence off',},
								'parameter_6'=> {'name'=>'dx', 'startbit'=>'13', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_X influence on', '0'=>'SDIS_X influence off',},
								'parameter_7'=> {'name'=>'zro', 'startbit'=>'14', 'length'=>'1', 'group'=>'MOSI', '1'=>'zeroing (set data to zero if data > +480 / < -480', '0'=>'No zeroing',},
								'parameter_8'=> {'name'=>'shft', 'startbit'=>'15', 'length'=>'1', 'group'=>'MOSI', '1'=>'shift 16 down to 10 bits on (shift 5 bits + clipping to +511/-512)', '0'=>'No shifting',},
								'parameter_9'=> {'name'=>'saf_thres', 'startbit'=>'0', 'length'=>'8', 'group'=>'MISO',},
								'parameter_10'=> {'name'=>'f_coeff', 'startbit'=>'8', 'length'=>'2', 'group'=>'MISO', '00' => '43 Hz', '01' => '60 Hz', '10' => '78 Hz', '11' => '98 Hz'},
								'parameter_11'=> {'name'=>'fon', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'filter on', '0'=>'filter off',},
								'parameter_12'=> {'name'=>'dw', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_W influence on', '0'=>'SDIS_W influence off',},
								'parameter_13'=> {'name'=>'dy', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_Y influence on', '0'=>'SDIS_Y influence off',},
								'parameter_14'=> {'name'=>'dx', 'startbit'=>'13', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_X influence on', '0'=>'SDIS_X influence off',},
								'parameter_15'=> {'name'=>'zro', 'startbit'=>'14', 'length'=>'1', 'group'=>'MISO', '1'=>'zeroing (set data to zero if data > +480 / < -480', '0'=>'No zeroing',},
								'parameter_16'=> {'name'=>'shft', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '1'=>'shift 16 down to 10 bits on (shift 5 bits + clipping to +511/-512)', '0'=>'No shifting',},
                                },

                'PROG_SAF_CH6'=>        {
                                'CODE'=> '0110100101',
                                'description'=>'Program safety channels',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Grey',
								'parameter_1'=> {'name'=>'saf_thres', 'startbit'=>'0', 'length'=>'8', 'group'=>'MOSI',},
								'parameter_2'=> {'name'=>'f_coeff', 'startbit'=>'8', 'length'=>'2', 'group'=>'MOSI', '00' => '43 Hz', '01' => '60 Hz', '10' => '78 Hz', '11' => '98 Hz'},
								'parameter_3'=> {'name'=>'fon', 'startbit'=>'10', 'length'=>'1', 'group'=>'MOSI', '1'=>'filter on', '0'=>'filter off',},
								'parameter_4'=> {'name'=>'dw', 'startbit'=>'11', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_W influence on', '0'=>'SDIS_W influence off',},
								'parameter_5'=> {'name'=>'dy', 'startbit'=>'12', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_Y influence on', '0'=>'SDIS_Y influence off',},
								'parameter_6'=> {'name'=>'dx', 'startbit'=>'13', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_X influence on', '0'=>'SDIS_X influence off',},
								'parameter_7'=> {'name'=>'zro', 'startbit'=>'14', 'length'=>'1', 'group'=>'MOSI', '1'=>'zeroing (set data to zero if data > +480 / < -480', '0'=>'No zeroing',},
								'parameter_8'=> {'name'=>'shft', 'startbit'=>'15', 'length'=>'1', 'group'=>'MOSI', '1'=>'shift 16 down to 10 bits on (shift 5 bits + clipping to +511/-512)', '0'=>'No shifting',},
								'parameter_9'=> {'name'=>'saf_thres', 'startbit'=>'0', 'length'=>'8', 'group'=>'MISO',},
								'parameter_10'=> {'name'=>'f_coeff', 'startbit'=>'8', 'length'=>'2', 'group'=>'MISO', '00' => '43 Hz', '01' => '60 Hz', '10' => '78 Hz', '11' => '98 Hz'},
								'parameter_11'=> {'name'=>'fon', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'filter on', '0'=>'filter off',},
								'parameter_12'=> {'name'=>'dw', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_W influence on', '0'=>'SDIS_W influence off',},
								'parameter_13'=> {'name'=>'dy', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_Y influence on', '0'=>'SDIS_Y influence off',},
								'parameter_14'=> {'name'=>'dx', 'startbit'=>'13', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_X influence on', '0'=>'SDIS_X influence off',},
								'parameter_15'=> {'name'=>'zro', 'startbit'=>'14', 'length'=>'1', 'group'=>'MISO', '1'=>'zeroing (set data to zero if data > +480 / < -480', '0'=>'No zeroing',},
								'parameter_16'=> {'name'=>'shft', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '1'=>'shift 16 down to 10 bits on (shift 5 bits + clipping to +511/-512)', '0'=>'No shifting',},
                                },

                'PROG_SAF_CH7'=>        {
                                'CODE'=> '0110100110',
                                'description'=>'Program safety channels',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Grey',
								'parameter_1'=> {'name'=>'saf_thres', 'startbit'=>'0', 'length'=>'8', 'group'=>'MOSI',},
								'parameter_2'=> {'name'=>'f_coeff', 'startbit'=>'8', 'length'=>'2', 'group'=>'MOSI', '00' => '43 Hz', '01' => '60 Hz', '10' => '78 Hz', '11' => '98 Hz'},
								'parameter_3'=> {'name'=>'fon', 'startbit'=>'10', 'length'=>'1', 'group'=>'MOSI', '1'=>'filter on', '0'=>'filter off',},
								'parameter_4'=> {'name'=>'dw', 'startbit'=>'11', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_W influence on', '0'=>'SDIS_W influence off',},
								'parameter_5'=> {'name'=>'dy', 'startbit'=>'12', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_Y influence on', '0'=>'SDIS_Y influence off',},
								'parameter_6'=> {'name'=>'dx', 'startbit'=>'13', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_X influence on', '0'=>'SDIS_X influence off',},
								'parameter_7'=> {'name'=>'zro', 'startbit'=>'14', 'length'=>'1', 'group'=>'MOSI', '1'=>'zeroing (set data to zero if data > +480 / < -480', '0'=>'No zeroing',},
								'parameter_8'=> {'name'=>'shft', 'startbit'=>'15', 'length'=>'1', 'group'=>'MOSI', '1'=>'shift 16 down to 10 bits on (shift 5 bits + clipping to +511/-512)', '0'=>'No shifting',},
								'parameter_9'=> {'name'=>'saf_thres', 'startbit'=>'0', 'length'=>'8', 'group'=>'MISO',},
								'parameter_10'=> {'name'=>'f_coeff', 'startbit'=>'8', 'length'=>'2', 'group'=>'MISO', '00' => '43 Hz', '01' => '60 Hz', '10' => '78 Hz', '11' => '98 Hz'},
								'parameter_11'=> {'name'=>'fon', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'filter on', '0'=>'filter off',},
								'parameter_12'=> {'name'=>'dw', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_W influence on', '0'=>'SDIS_W influence off',},
								'parameter_13'=> {'name'=>'dy', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_Y influence on', '0'=>'SDIS_Y influence off',},
								'parameter_14'=> {'name'=>'dx', 'startbit'=>'13', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_X influence on', '0'=>'SDIS_X influence off',},
								'parameter_15'=> {'name'=>'zro', 'startbit'=>'14', 'length'=>'1', 'group'=>'MISO', '1'=>'zeroing (set data to zero if data > +480 / < -480', '0'=>'No zeroing',},
								'parameter_16'=> {'name'=>'shft', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '1'=>'shift 16 down to 10 bits on (shift 5 bits + clipping to +511/-512)', '0'=>'No shifting',},
                                },

                'PROG_SAF_CH8'=>        {
                                'CODE'=> '0110100111',
                                'description'=>'Program safety channels',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Grey',
								'parameter_1'=> {'name'=>'saf_thres', 'startbit'=>'0', 'length'=>'8', 'group'=>'MOSI',},
								'parameter_2'=> {'name'=>'f_coeff', 'startbit'=>'8', 'length'=>'2', 'group'=>'MOSI', '00' => '43 Hz', '01' => '60 Hz', '10' => '78 Hz', '11' => '98 Hz'},
								'parameter_3'=> {'name'=>'fon', 'startbit'=>'10', 'length'=>'1', 'group'=>'MOSI', '1'=>'filter on', '0'=>'filter off',},
								'parameter_4'=> {'name'=>'dw', 'startbit'=>'11', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_W influence on', '0'=>'SDIS_W influence off',},
								'parameter_5'=> {'name'=>'dy', 'startbit'=>'12', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_Y influence on', '0'=>'SDIS_Y influence off',},
								'parameter_6'=> {'name'=>'dx', 'startbit'=>'13', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_X influence on', '0'=>'SDIS_X influence off',},
								'parameter_7'=> {'name'=>'zro', 'startbit'=>'14', 'length'=>'1', 'group'=>'MOSI', '1'=>'zeroing (set data to zero if data > +480 / < -480', '0'=>'No zeroing',},
								'parameter_8'=> {'name'=>'shft', 'startbit'=>'15', 'length'=>'1', 'group'=>'MOSI', '1'=>'shift 16 down to 10 bits on (shift 5 bits + clipping to +511/-512)', '0'=>'No shifting',},
								'parameter_9'=> {'name'=>'saf_thres', 'startbit'=>'0', 'length'=>'8', 'group'=>'MISO',},
								'parameter_10'=> {'name'=>'f_coeff', 'startbit'=>'8', 'length'=>'2', 'group'=>'MISO', '00' => '43 Hz', '01' => '60 Hz', '10' => '78 Hz', '11' => '98 Hz'},
								'parameter_11'=> {'name'=>'fon', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'filter on', '0'=>'filter off',},
								'parameter_12'=> {'name'=>'dw', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_W influence on', '0'=>'SDIS_W influence off',},
								'parameter_13'=> {'name'=>'dy', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_Y influence on', '0'=>'SDIS_Y influence off',},
								'parameter_14'=> {'name'=>'dx', 'startbit'=>'13', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_X influence on', '0'=>'SDIS_X influence off',},
								'parameter_15'=> {'name'=>'zro', 'startbit'=>'14', 'length'=>'1', 'group'=>'MISO', '1'=>'zeroing (set data to zero if data > +480 / < -480', '0'=>'No zeroing',},
								'parameter_16'=> {'name'=>'shft', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '1'=>'shift 16 down to 10 bits on (shift 5 bits + clipping to +511/-512)', '0'=>'No shifting',},
                                },

                'PROG_SAF_CH9'=>        {
                                'CODE'=> '0110101000',
                                'description'=>'Program safety channels',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Grey',
								'parameter_1'=> {'name'=>'saf_thres', 'startbit'=>'0', 'length'=>'8', 'group'=>'MOSI',},
								'parameter_2'=> {'name'=>'f_coeff', 'startbit'=>'8', 'length'=>'2', 'group'=>'MOSI', '00' => '43 Hz', '01' => '60 Hz', '10' => '78 Hz', '11' => '98 Hz'},
								'parameter_3'=> {'name'=>'fon', 'startbit'=>'10', 'length'=>'1', 'group'=>'MOSI', '1'=>'filter on', '0'=>'filter off',},
								'parameter_4'=> {'name'=>'dw', 'startbit'=>'11', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_W influence on', '0'=>'SDIS_W influence off',},
								'parameter_5'=> {'name'=>'dy', 'startbit'=>'12', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_Y influence on', '0'=>'SDIS_Y influence off',},
								'parameter_6'=> {'name'=>'dx', 'startbit'=>'13', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_X influence on', '0'=>'SDIS_X influence off',},
								'parameter_7'=> {'name'=>'zro', 'startbit'=>'14', 'length'=>'1', 'group'=>'MOSI', '1'=>'zeroing (set data to zero if data > +480 / < -480', '0'=>'No zeroing',},
								'parameter_8'=> {'name'=>'shft', 'startbit'=>'15', 'length'=>'1', 'group'=>'MOSI', '1'=>'shift 16 down to 10 bits on (shift 5 bits + clipping to +511/-512)', '0'=>'No shifting',},
								'parameter_9'=> {'name'=>'saf_thres', 'startbit'=>'0', 'length'=>'8', 'group'=>'MISO',},
								'parameter_10'=> {'name'=>'f_coeff', 'startbit'=>'8', 'length'=>'2', 'group'=>'MISO', '00' => '43 Hz', '01' => '60 Hz', '10' => '78 Hz', '11' => '98 Hz'},
								'parameter_11'=> {'name'=>'fon', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'filter on', '0'=>'filter off',},
								'parameter_12'=> {'name'=>'dw', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_W influence on', '0'=>'SDIS_W influence off',},
								'parameter_13'=> {'name'=>'dy', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_Y influence on', '0'=>'SDIS_Y influence off',},
								'parameter_14'=> {'name'=>'dx', 'startbit'=>'13', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_X influence on', '0'=>'SDIS_X influence off',},
								'parameter_15'=> {'name'=>'zro', 'startbit'=>'14', 'length'=>'1', 'group'=>'MISO', '1'=>'zeroing (set data to zero if data > +480 / < -480', '0'=>'No zeroing',},
								'parameter_16'=> {'name'=>'shft', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '1'=>'shift 16 down to 10 bits on (shift 5 bits + clipping to +511/-512)', '0'=>'No shifting',},
                                },

                'PROG_SAF_CH10'=>       {
                                'CODE'=> '0110101001',
                                'description'=>'Program safety channels',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Grey',
								'parameter_1'=> {'name'=>'saf_thres', 'startbit'=>'0', 'length'=>'8', 'group'=>'MOSI',},
								'parameter_2'=> {'name'=>'f_coeff', 'startbit'=>'8', 'length'=>'2', 'group'=>'MOSI', '00' => '43 Hz', '01' => '60 Hz', '10' => '78 Hz', '11' => '98 Hz'},
								'parameter_3'=> {'name'=>'fon', 'startbit'=>'10', 'length'=>'1', 'group'=>'MOSI', '1'=>'filter on', '0'=>'filter off',},
								'parameter_4'=> {'name'=>'dw', 'startbit'=>'11', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_W influence on', '0'=>'SDIS_W influence off',},
								'parameter_5'=> {'name'=>'dy', 'startbit'=>'12', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_Y influence on', '0'=>'SDIS_Y influence off',},
								'parameter_6'=> {'name'=>'dx', 'startbit'=>'13', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_X influence on', '0'=>'SDIS_X influence off',},
								'parameter_7'=> {'name'=>'zro', 'startbit'=>'14', 'length'=>'1', 'group'=>'MOSI', '1'=>'zeroing (set data to zero if data > +480 / < -480', '0'=>'No zeroing',},
								'parameter_8'=> {'name'=>'shft', 'startbit'=>'15', 'length'=>'1', 'group'=>'MOSI', '1'=>'shift 16 down to 10 bits on (shift 5 bits + clipping to +511/-512)', '0'=>'No shifting',},
								'parameter_9'=> {'name'=>'saf_thres', 'startbit'=>'0', 'length'=>'8', 'group'=>'MISO',},
								'parameter_10'=> {'name'=>'f_coeff', 'startbit'=>'8', 'length'=>'2', 'group'=>'MISO', '00' => '43 Hz', '01' => '60 Hz', '10' => '78 Hz', '11' => '98 Hz'},
								'parameter_11'=> {'name'=>'fon', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'filter on', '0'=>'filter off',},
								'parameter_12'=> {'name'=>'dw', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_W influence on', '0'=>'SDIS_W influence off',},
								'parameter_13'=> {'name'=>'dy', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_Y influence on', '0'=>'SDIS_Y influence off',},
								'parameter_14'=> {'name'=>'dx', 'startbit'=>'13', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_X influence on', '0'=>'SDIS_X influence off',},
								'parameter_15'=> {'name'=>'zro', 'startbit'=>'14', 'length'=>'1', 'group'=>'MISO', '1'=>'zeroing (set data to zero if data > +480 / < -480', '0'=>'No zeroing',},
								'parameter_16'=> {'name'=>'shft', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '1'=>'shift 16 down to 10 bits on (shift 5 bits + clipping to +511/-512)', '0'=>'No shifting',},
                                },

                'PROG_SAF_CH11'=>       {
                                'CODE'=> '0110101010',
                                'description'=>'Program safety channels',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Grey',
								'parameter_1'=> {'name'=>'saf_thres', 'startbit'=>'0', 'length'=>'8', 'group'=>'MOSI',},
								'parameter_2'=> {'name'=>'f_coeff', 'startbit'=>'8', 'length'=>'2', 'group'=>'MOSI', '00' => '43 Hz', '01' => '60 Hz', '10' => '78 Hz', '11' => '98 Hz'},
								'parameter_3'=> {'name'=>'fon', 'startbit'=>'10', 'length'=>'1', 'group'=>'MOSI', '1'=>'filter on', '0'=>'filter off',},
								'parameter_4'=> {'name'=>'dw', 'startbit'=>'11', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_W influence on', '0'=>'SDIS_W influence off',},
								'parameter_5'=> {'name'=>'dy', 'startbit'=>'12', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_Y influence on', '0'=>'SDIS_Y influence off',},
								'parameter_6'=> {'name'=>'dx', 'startbit'=>'13', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_X influence on', '0'=>'SDIS_X influence off',},
								'parameter_7'=> {'name'=>'zro', 'startbit'=>'14', 'length'=>'1', 'group'=>'MOSI', '1'=>'zeroing (set data to zero if data > +480 / < -480', '0'=>'No zeroing',},
								'parameter_8'=> {'name'=>'shft', 'startbit'=>'15', 'length'=>'1', 'group'=>'MOSI', '1'=>'shift 16 down to 10 bits on (shift 5 bits + clipping to +511/-512)', '0'=>'No shifting',},
								'parameter_9'=> {'name'=>'saf_thres', 'startbit'=>'0', 'length'=>'8', 'group'=>'MISO',},
								'parameter_10'=> {'name'=>'f_coeff', 'startbit'=>'8', 'length'=>'2', 'group'=>'MISO', '00' => '43 Hz', '01' => '60 Hz', '10' => '78 Hz', '11' => '98 Hz'},
								'parameter_11'=> {'name'=>'fon', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'filter on', '0'=>'filter off',},
								'parameter_12'=> {'name'=>'dw', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_W influence on', '0'=>'SDIS_W influence off',},
								'parameter_13'=> {'name'=>'dy', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_Y influence on', '0'=>'SDIS_Y influence off',},
								'parameter_14'=> {'name'=>'dx', 'startbit'=>'13', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_X influence on', '0'=>'SDIS_X influence off',},
								'parameter_15'=> {'name'=>'zro', 'startbit'=>'14', 'length'=>'1', 'group'=>'MISO', '1'=>'zeroing (set data to zero if data > +480 / < -480', '0'=>'No zeroing',},
								'parameter_16'=> {'name'=>'shft', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '1'=>'shift 16 down to 10 bits on (shift 5 bits + clipping to +511/-512)', '0'=>'No shifting',},
                                },

                'PROG_SAF_CH12'=>       {
                                'CODE'=> '0110101011',
                                'description'=>'Program safety channels',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Grey',
								'parameter_1'=> {'name'=>'saf_thres', 'startbit'=>'0', 'length'=>'8', 'group'=>'MOSI',},
								'parameter_2'=> {'name'=>'f_coeff', 'startbit'=>'8', 'length'=>'2', 'group'=>'MOSI', '00' => '43 Hz', '01' => '60 Hz', '10' => '78 Hz', '11' => '98 Hz'},
								'parameter_3'=> {'name'=>'fon', 'startbit'=>'10', 'length'=>'1', 'group'=>'MOSI', '1'=>'filter on', '0'=>'filter off',},
								'parameter_4'=> {'name'=>'dw', 'startbit'=>'11', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_W influence on', '0'=>'SDIS_W influence off',},
								'parameter_5'=> {'name'=>'dy', 'startbit'=>'12', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_Y influence on', '0'=>'SDIS_Y influence off',},
								'parameter_6'=> {'name'=>'dx', 'startbit'=>'13', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_X influence on', '0'=>'SDIS_X influence off',},
								'parameter_7'=> {'name'=>'zro', 'startbit'=>'14', 'length'=>'1', 'group'=>'MOSI', '1'=>'zeroing (set data to zero if data > +480 / < -480', '0'=>'No zeroing',},
								'parameter_8'=> {'name'=>'shft', 'startbit'=>'15', 'length'=>'1', 'group'=>'MOSI', '1'=>'shift 16 down to 10 bits on (shift 5 bits + clipping to +511/-512)', '0'=>'No shifting',},
								'parameter_9'=> {'name'=>'saf_thres', 'startbit'=>'0', 'length'=>'8', 'group'=>'MISO',},
								'parameter_10'=> {'name'=>'f_coeff', 'startbit'=>'8', 'length'=>'2', 'group'=>'MISO', '00' => '43 Hz', '01' => '60 Hz', '10' => '78 Hz', '11' => '98 Hz'},
								'parameter_11'=> {'name'=>'fon', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'filter on', '0'=>'filter off',},
								'parameter_12'=> {'name'=>'dw', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_W influence on', '0'=>'SDIS_W influence off',},
								'parameter_13'=> {'name'=>'dy', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_Y influence on', '0'=>'SDIS_Y influence off',},
								'parameter_14'=> {'name'=>'dx', 'startbit'=>'13', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_X influence on', '0'=>'SDIS_X influence off',},
								'parameter_15'=> {'name'=>'zro', 'startbit'=>'14', 'length'=>'1', 'group'=>'MISO', '1'=>'zeroing (set data to zero if data > +480 / < -480', '0'=>'No zeroing',},
								'parameter_16'=> {'name'=>'shft', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '1'=>'shift 16 down to 10 bits on (shift 5 bits + clipping to +511/-512)', '0'=>'No shifting',},
                                },

                'PROG_SAF_CH13'=>       {
                                'CODE'=> '0110101100',
                                'description'=>'Program safety channels',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Grey',
								'parameter_1'=> {'name'=>'saf_thres', 'startbit'=>'0', 'length'=>'8', 'group'=>'MOSI',},
								'parameter_2'=> {'name'=>'f_coeff', 'startbit'=>'8', 'length'=>'2', 'group'=>'MOSI', '00' => '43 Hz', '01' => '60 Hz', '10' => '78 Hz', '11' => '98 Hz'},
								'parameter_3'=> {'name'=>'fon', 'startbit'=>'10', 'length'=>'1', 'group'=>'MOSI', '1'=>'filter on', '0'=>'filter off',},
								'parameter_4'=> {'name'=>'dw', 'startbit'=>'11', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_W influence on', '0'=>'SDIS_W influence off',},
								'parameter_5'=> {'name'=>'dy', 'startbit'=>'12', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_Y influence on', '0'=>'SDIS_Y influence off',},
								'parameter_6'=> {'name'=>'dx', 'startbit'=>'13', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_X influence on', '0'=>'SDIS_X influence off',},
								'parameter_7'=> {'name'=>'zro', 'startbit'=>'14', 'length'=>'1', 'group'=>'MOSI', '1'=>'zeroing (set data to zero if data > +480 / < -480', '0'=>'No zeroing',},
								'parameter_8'=> {'name'=>'shft', 'startbit'=>'15', 'length'=>'1', 'group'=>'MOSI', '1'=>'shift 16 down to 10 bits on (shift 5 bits + clipping to +511/-512)', '0'=>'No shifting',},
								'parameter_9'=> {'name'=>'saf_thres', 'startbit'=>'0', 'length'=>'8', 'group'=>'MISO',},
								'parameter_10'=> {'name'=>'f_coeff', 'startbit'=>'8', 'length'=>'2', 'group'=>'MISO', '00' => '43 Hz', '01' => '60 Hz', '10' => '78 Hz', '11' => '98 Hz'},
								'parameter_11'=> {'name'=>'fon', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'filter on', '0'=>'filter off',},
								'parameter_12'=> {'name'=>'dw', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_W influence on', '0'=>'SDIS_W influence off',},
								'parameter_13'=> {'name'=>'dy', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_Y influence on', '0'=>'SDIS_Y influence off',},
								'parameter_14'=> {'name'=>'dx', 'startbit'=>'13', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_X influence on', '0'=>'SDIS_X influence off',},
								'parameter_15'=> {'name'=>'zro', 'startbit'=>'14', 'length'=>'1', 'group'=>'MISO', '1'=>'zeroing (set data to zero if data > +480 / < -480', '0'=>'No zeroing',},
								'parameter_16'=> {'name'=>'shft', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '1'=>'shift 16 down to 10 bits on (shift 5 bits + clipping to +511/-512)', '0'=>'No shifting',},
                                },

                'PROG_SAF_CH14'=>       {
                                'CODE'=> '0110101101',
                                'description'=>'Program safety channels',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Grey',
								'parameter_1'=> {'name'=>'saf_thres', 'startbit'=>'0', 'length'=>'8', 'group'=>'MOSI',},
								'parameter_2'=> {'name'=>'f_coeff', 'startbit'=>'8', 'length'=>'2', 'group'=>'MOSI', '00' => '43 Hz', '01' => '60 Hz', '10' => '78 Hz', '11' => '98 Hz'},
								'parameter_3'=> {'name'=>'fon', 'startbit'=>'10', 'length'=>'1', 'group'=>'MOSI', '1'=>'filter on', '0'=>'filter off',},
								'parameter_4'=> {'name'=>'dw', 'startbit'=>'11', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_W influence on', '0'=>'SDIS_W influence off',},
								'parameter_5'=> {'name'=>'dy', 'startbit'=>'12', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_Y influence on', '0'=>'SDIS_Y influence off',},
								'parameter_6'=> {'name'=>'dx', 'startbit'=>'13', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_X influence on', '0'=>'SDIS_X influence off',},
								'parameter_7'=> {'name'=>'zro', 'startbit'=>'14', 'length'=>'1', 'group'=>'MOSI', '1'=>'zeroing (set data to zero if data > +480 / < -480', '0'=>'No zeroing',},
								'parameter_8'=> {'name'=>'shft', 'startbit'=>'15', 'length'=>'1', 'group'=>'MOSI', '1'=>'shift 16 down to 10 bits on (shift 5 bits + clipping to +511/-512)', '0'=>'No shifting',},
								'parameter_9'=> {'name'=>'saf_thres', 'startbit'=>'0', 'length'=>'8', 'group'=>'MISO',},
								'parameter_10'=> {'name'=>'f_coeff', 'startbit'=>'8', 'length'=>'2', 'group'=>'MISO', '00' => '43 Hz', '01' => '60 Hz', '10' => '78 Hz', '11' => '98 Hz'},
								'parameter_11'=> {'name'=>'fon', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'filter on', '0'=>'filter off',},
								'parameter_12'=> {'name'=>'dw', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_W influence on', '0'=>'SDIS_W influence off',},
								'parameter_13'=> {'name'=>'dy', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_Y influence on', '0'=>'SDIS_Y influence off',},
								'parameter_14'=> {'name'=>'dx', 'startbit'=>'13', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_X influence on', '0'=>'SDIS_X influence off',},
								'parameter_15'=> {'name'=>'zro', 'startbit'=>'14', 'length'=>'1', 'group'=>'MISO', '1'=>'zeroing (set data to zero if data > +480 / < -480', '0'=>'No zeroing',},
								'parameter_16'=> {'name'=>'shft', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '1'=>'shift 16 down to 10 bits on (shift 5 bits + clipping to +511/-512)', '0'=>'No shifting',},
                                },

                'PROG_SAF_CH15'=>       {
                                'CODE'=> '0110101110',
                                'description'=>'Program safety channels',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Grey',
								'parameter_1'=> {'name'=>'saf_thres', 'startbit'=>'0', 'length'=>'8', 'group'=>'MOSI',},
								'parameter_2'=> {'name'=>'f_coeff', 'startbit'=>'8', 'length'=>'2', 'group'=>'MOSI', '00' => '43 Hz', '01' => '60 Hz', '10' => '78 Hz', '11' => '98 Hz'},
								'parameter_3'=> {'name'=>'fon', 'startbit'=>'10', 'length'=>'1', 'group'=>'MOSI', '1'=>'filter on', '0'=>'filter off',},
								'parameter_4'=> {'name'=>'dw', 'startbit'=>'11', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_W influence on', '0'=>'SDIS_W influence off',},
								'parameter_5'=> {'name'=>'dy', 'startbit'=>'12', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_Y influence on', '0'=>'SDIS_Y influence off',},
								'parameter_6'=> {'name'=>'dx', 'startbit'=>'13', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_X influence on', '0'=>'SDIS_X influence off',},
								'parameter_7'=> {'name'=>'zro', 'startbit'=>'14', 'length'=>'1', 'group'=>'MOSI', '1'=>'zeroing (set data to zero if data > +480 / < -480', '0'=>'No zeroing',},
								'parameter_8'=> {'name'=>'shft', 'startbit'=>'15', 'length'=>'1', 'group'=>'MOSI', '1'=>'shift 16 down to 10 bits on (shift 5 bits + clipping to +511/-512)', '0'=>'No shifting',},
								'parameter_9'=> {'name'=>'saf_thres', 'startbit'=>'0', 'length'=>'8', 'group'=>'MISO',},
								'parameter_10'=> {'name'=>'f_coeff', 'startbit'=>'8', 'length'=>'2', 'group'=>'MISO', '00' => '43 Hz', '01' => '60 Hz', '10' => '78 Hz', '11' => '98 Hz'},
								'parameter_11'=> {'name'=>'fon', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'filter on', '0'=>'filter off',},
								'parameter_12'=> {'name'=>'dw', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_W influence on', '0'=>'SDIS_W influence off',},
								'parameter_13'=> {'name'=>'dy', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_Y influence on', '0'=>'SDIS_Y influence off',},
								'parameter_14'=> {'name'=>'dx', 'startbit'=>'13', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_X influence on', '0'=>'SDIS_X influence off',},
								'parameter_15'=> {'name'=>'zro', 'startbit'=>'14', 'length'=>'1', 'group'=>'MISO', '1'=>'zeroing (set data to zero if data > +480 / < -480', '0'=>'No zeroing',},
								'parameter_16'=> {'name'=>'shft', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '1'=>'shift 16 down to 10 bits on (shift 5 bits + clipping to +511/-512)', '0'=>'No shifting',},
                                },

                'PROG_SAF_CH16'=>       {
                                'CODE'=> '0110101111',
                                'description'=>'Program safety channels',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Grey',
								'parameter_1'=> {'name'=>'saf_thres', 'startbit'=>'0', 'length'=>'8', 'group'=>'MOSI',},
								'parameter_2'=> {'name'=>'f_coeff', 'startbit'=>'8', 'length'=>'2', 'group'=>'MOSI', '00' => '43 Hz', '01' => '60 Hz', '10' => '78 Hz', '11' => '98 Hz'},
								'parameter_3'=> {'name'=>'fon', 'startbit'=>'10', 'length'=>'1', 'group'=>'MOSI', '1'=>'filter on', '0'=>'filter off',},
								'parameter_4'=> {'name'=>'dw', 'startbit'=>'11', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_W influence on', '0'=>'SDIS_W influence off',},
								'parameter_5'=> {'name'=>'dy', 'startbit'=>'12', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_Y influence on', '0'=>'SDIS_Y influence off',},
								'parameter_6'=> {'name'=>'dx', 'startbit'=>'13', 'length'=>'1', 'group'=>'MOSI', '1'=>'SDIS_X influence on', '0'=>'SDIS_X influence off',},
								'parameter_7'=> {'name'=>'zro', 'startbit'=>'14', 'length'=>'1', 'group'=>'MOSI', '1'=>'zeroing (set data to zero if data > +480 / < -480', '0'=>'No zeroing',},
								'parameter_8'=> {'name'=>'shft', 'startbit'=>'15', 'length'=>'1', 'group'=>'MOSI', '1'=>'shift 16 down to 10 bits on (shift 5 bits + clipping to +511/-512)', '0'=>'No shifting',},
								'parameter_9'=> {'name'=>'saf_thres', 'startbit'=>'0', 'length'=>'8', 'group'=>'MISO',},
								'parameter_10'=> {'name'=>'f_coeff', 'startbit'=>'8', 'length'=>'2', 'group'=>'MISO', '00' => '43 Hz', '01' => '60 Hz', '10' => '78 Hz', '11' => '98 Hz'},
								'parameter_11'=> {'name'=>'fon', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'filter on', '0'=>'filter off',},
								'parameter_12'=> {'name'=>'dw', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_W influence on', '0'=>'SDIS_W influence off',},
								'parameter_13'=> {'name'=>'dy', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_Y influence on', '0'=>'SDIS_Y influence off',},
								'parameter_14'=> {'name'=>'dx', 'startbit'=>'13', 'length'=>'1', 'group'=>'MISO', '1'=>'SDIS_X influence on', '0'=>'SDIS_X influence off',},
								'parameter_15'=> {'name'=>'zro', 'startbit'=>'14', 'length'=>'1', 'group'=>'MISO', '1'=>'zeroing (set data to zero if data > +480 / < -480', '0'=>'No zeroing',},
								'parameter_16'=> {'name'=>'shft', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '1'=>'shift 16 down to 10 bits on (shift 5 bits + clipping to +511/-512)', '0'=>'No shifting',},
                                },

                'PROG_PSI_LINE1'=>      {
                                'CODE'=> '0110110000',
                                'description'=>'Program PSI lines',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Green',
								'parameter_1'=> {'name'=>'as', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '0'=>'PSI receiver using synchronous mode', '1'=>'PSI receiver using asynchronous mode',},
								'parameter_2'=> {'name'=>'baud', 'startbit'=>'1', 'length'=>'2', 'group'=>'MOSI', '00'=>'PSI receiver using 125kbaud mode', '01'=>'PSI receiver using 189kbaud mode ', '10'=>'PSI receiver using 83.3kbaud mode ',},
								'parameter_3'=> {'name'=>'crc', 'startbit'=>'3', 'length'=>'1', 'group'=>'MOSI', '0'=>'PSI receiver using single bit parity mode', '1'=>'PSI receiver using 3 bit CRC mode',},
								'parameter_4'=> {'name'=>'slot', 'startbit'=>'4', 'length'=>'2', 'group'=>'MOSI', '00'=>'1 sensor mode using single time slot', '01'=>'2 sensor mode using single time slot', '10'=>'3 sensor mode using single time slot', '11'=>'4 sensor mode using single time slot',},
								'parameter_5'=> {'name'=>'qr', 'startbit'=>'6', 'length'=>'1', 'group'=>'MOSI', '0'=>'quiescent regulation - 1 LSB / 8us', '1'=>'quiescent regulation - 1 LSB / 500ns',},
								'parameter_6'=> {'name'=>'filter', 'startbit'=>'7', 'length'=>'2', 'group'=>'MOSI', '00'=>'2 / 3 filter', '01'=>'no filter', '10'=>'3 / 5 filter',},
								'parameter_7'=> {'name'=>'ts', 'startbit'=>'9', 'length'=>'1', 'group'=>'MOSI', '1' => 'PSI data will be ignored if time slot changes during data reception',},
								'parameter_8'=> {'name'=>'p', 'startbit'=>'15', 'length'=>'1', 'group'=>'MOSI', '0'=>'even parity', '1'=>'odd parity',},
								'parameter_9'=> {'name'=>'as', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '0'=>'PSI receiver using synchronous mode', '1'=>'PSI receiver using asynchronous mode',},
								'parameter_10'=> {'name'=>'baud', 'startbit'=>'1', 'length'=>'2', 'group'=>'MISO', '00'=>'PSI receiver using 125kbaud mode', '01'=>'PSI receiver using 189kbaud mode ', '10'=>'PSI receiver using 83.3kbaud mode ',},
								'parameter_11'=> {'name'=>'crc', 'startbit'=>'3', 'length'=>'1', 'group'=>'MISO', '0'=>'PSI receiver using single bit parity mode', '1'=>'PSI receiver using 3 bit CRC mode',},
								'parameter_12'=> {'name'=>'slot', 'startbit'=>'4', 'length'=>'2', 'group'=>'MISO', '00'=>'1 sensor mode using single time slot', '01'=>'2 sensor mode using single time slot', '10'=>'3 sensor mode using single time slot', '11'=>'4 sensor mode using single time slot',},
								'parameter_13'=> {'name'=>'qr', 'startbit'=>'6', 'length'=>'1', 'group'=>'MISO', '0'=>'quiescent regulation - 1 LSB / 8us', '1'=>'quiescent regulation - 1 LSB / 500ns',},
								'parameter_14'=> {'name'=>'filter', 'startbit'=>'7', 'length'=>'2', 'group'=>'MISO', '00'=>'2 / 3 filter', '01'=>'no filter', '10'=>'3 / 5 filter',},
								'parameter_15'=> {'name'=>'ts', 'startbit'=>'9', 'length'=>'1', 'group'=>'MOSI', '1' => 'PSI data will be ignored if time slot changes during data reception',},
								'parameter_16'=> {'name'=>'p', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '0'=>'even parity', '1'=>'odd parity',},
                                },

                'PROG_PSI_LINE2'=>      {
                                'CODE'=> '0110110001',
                                'description'=>'Program PSI lines',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Green',
								'parameter_1'=> {'name'=>'as', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '0'=>'PSI receiver using synchronous mode', '1'=>'PSI receiver using asynchronous mode',},
								'parameter_2'=> {'name'=>'baud', 'startbit'=>'1', 'length'=>'2', 'group'=>'MOSI', '00'=>'PSI receiver using 125kbaud mode', '01'=>'PSI receiver using 189kbaud mode ', '10'=>'PSI receiver using 83.3kbaud mode ',},
								'parameter_3'=> {'name'=>'crc', 'startbit'=>'3', 'length'=>'1', 'group'=>'MOSI', '0'=>'PSI receiver using single bit parity mode', '1'=>'PSI receiver using 3 bit CRC mode',},
								'parameter_4'=> {'name'=>'slot', 'startbit'=>'4', 'length'=>'2', 'group'=>'MOSI', '00'=>'1 sensor mode using single time slot', '01'=>'2 sensor mode using single time slot', '10'=>'3 sensor mode using single time slot', '11'=>'4 sensor mode using single time slot',},
								'parameter_5'=> {'name'=>'qr', 'startbit'=>'6', 'length'=>'1', 'group'=>'MOSI', '0'=>'quiescent regulation - 1 LSB / 8us', '1'=>'quiescent regulation - 1 LSB / 500ns',},
								'parameter_6'=> {'name'=>'filter', 'startbit'=>'7', 'length'=>'2', 'group'=>'MOSI', '00'=>'2 / 3 filter', '01'=>'no filter', '10'=>'3 / 5 filter',},
								'parameter_7'=> {'name'=>'ts', 'startbit'=>'9', 'length'=>'1', 'group'=>'MOSI', '1' => 'PSI data will be ignored if time slot changes during data reception',},
								'parameter_8'=> {'name'=>'p', 'startbit'=>'15', 'length'=>'1', 'group'=>'MOSI', '0'=>'even parity', '1'=>'odd parity',},
								'parameter_9'=> {'name'=>'as', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '0'=>'PSI receiver using synchronous mode', '1'=>'PSI receiver using asynchronous mode',},
								'parameter_10'=> {'name'=>'baud', 'startbit'=>'1', 'length'=>'2', 'group'=>'MISO', '00'=>'PSI receiver using 125kbaud mode', '01'=>'PSI receiver using 189kbaud mode ', '10'=>'PSI receiver using 83.3kbaud mode ',},
								'parameter_11'=> {'name'=>'crc', 'startbit'=>'3', 'length'=>'1', 'group'=>'MISO', '0'=>'PSI receiver using single bit parity mode', '1'=>'PSI receiver using 3 bit CRC mode',},
								'parameter_12'=> {'name'=>'slot', 'startbit'=>'4', 'length'=>'2', 'group'=>'MISO', '00'=>'1 sensor mode using single time slot', '01'=>'2 sensor mode using single time slot', '10'=>'3 sensor mode using single time slot', '11'=>'4 sensor mode using single time slot',},
								'parameter_13'=> {'name'=>'qr', 'startbit'=>'6', 'length'=>'1', 'group'=>'MISO', '0'=>'quiescent regulation - 1 LSB / 8us', '1'=>'quiescent regulation - 1 LSB / 500ns',},
								'parameter_14'=> {'name'=>'filter', 'startbit'=>'7', 'length'=>'2', 'group'=>'MISO', '00'=>'2 / 3 filter', '01'=>'no filter', '10'=>'3 / 5 filter',},
								'parameter_15'=> {'name'=>'ts', 'startbit'=>'9', 'length'=>'1', 'group'=>'MOSI', '1' => 'PSI data will be ignored if time slot changes during data reception',},
								'parameter_16'=> {'name'=>'p', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '0'=>'even parity', '1'=>'odd parity',},
                                },

                'PROG_PSI_LINE3'=>      {
                                'CODE'=> '0110110010',
                                'description'=>'Program PSI lines',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Green',
								'parameter_1'=> {'name'=>'as', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '0'=>'PSI receiver using synchronous mode', '1'=>'PSI receiver using asynchronous mode',},
								'parameter_2'=> {'name'=>'baud', 'startbit'=>'1', 'length'=>'2', 'group'=>'MOSI', '00'=>'PSI receiver using 125kbaud mode', '01'=>'PSI receiver using 189kbaud mode ', '10'=>'PSI receiver using 83.3kbaud mode ',},
								'parameter_3'=> {'name'=>'crc', 'startbit'=>'3', 'length'=>'1', 'group'=>'MOSI', '0'=>'PSI receiver using single bit parity mode', '1'=>'PSI receiver using 3 bit CRC mode',},
								'parameter_4'=> {'name'=>'slot', 'startbit'=>'4', 'length'=>'2', 'group'=>'MOSI', '00'=>'1 sensor mode using single time slot', '01'=>'2 sensor mode using single time slot', '10'=>'3 sensor mode using single time slot', '11'=>'4 sensor mode using single time slot',},
								'parameter_5'=> {'name'=>'qr', 'startbit'=>'6', 'length'=>'1', 'group'=>'MOSI', '0'=>'quiescent regulation - 1 LSB / 8us', '1'=>'quiescent regulation - 1 LSB / 500ns',},
								'parameter_6'=> {'name'=>'filter', 'startbit'=>'7', 'length'=>'2', 'group'=>'MOSI', '00'=>'2 / 3 filter', '01'=>'no filter', '10'=>'3 / 5 filter',},
								'parameter_7'=> {'name'=>'ts', 'startbit'=>'9', 'length'=>'1', 'group'=>'MOSI', '1' => 'PSI data will be ignored if time slot changes during data reception',},
								'parameter_8'=> {'name'=>'p', 'startbit'=>'15', 'length'=>'1', 'group'=>'MOSI', '0'=>'even parity', '1'=>'odd parity',},
								'parameter_9'=> {'name'=>'as', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '0'=>'PSI receiver using synchronous mode', '1'=>'PSI receiver using asynchronous mode',},
								'parameter_10'=> {'name'=>'baud', 'startbit'=>'1', 'length'=>'2', 'group'=>'MISO', '00'=>'PSI receiver using 125kbaud mode', '01'=>'PSI receiver using 189kbaud mode ', '10'=>'PSI receiver using 83.3kbaud mode ',},
								'parameter_11'=> {'name'=>'crc', 'startbit'=>'3', 'length'=>'1', 'group'=>'MISO', '0'=>'PSI receiver using single bit parity mode', '1'=>'PSI receiver using 3 bit CRC mode',},
								'parameter_12'=> {'name'=>'slot', 'startbit'=>'4', 'length'=>'2', 'group'=>'MISO', '00'=>'1 sensor mode using single time slot', '01'=>'2 sensor mode using single time slot', '10'=>'3 sensor mode using single time slot', '11'=>'4 sensor mode using single time slot',},
								'parameter_13'=> {'name'=>'qr', 'startbit'=>'6', 'length'=>'1', 'group'=>'MISO', '0'=>'quiescent regulation - 1 LSB / 8us', '1'=>'quiescent regulation - 1 LSB / 500ns',},
								'parameter_14'=> {'name'=>'filter', 'startbit'=>'7', 'length'=>'2', 'group'=>'MISO', '00'=>'2 / 3 filter', '01'=>'no filter', '10'=>'3 / 5 filter',},
								'parameter_15'=> {'name'=>'ts', 'startbit'=>'9', 'length'=>'1', 'group'=>'MOSI', '1' => 'PSI data will be ignored if time slot changes during data reception',},
								'parameter_16'=> {'name'=>'p', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '0'=>'even parity', '1'=>'odd parity',},
                                },

                'PROG_PSI_LINE4'=>      {
                                'CODE'=> '0110110011',
                                'description'=>'Program PSI lines',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Green',
								'parameter_1'=> {'name'=>'as', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '0'=>'PSI receiver using synchronous mode', '1'=>'PSI receiver using asynchronous mode',},
								'parameter_2'=> {'name'=>'baud', 'startbit'=>'1', 'length'=>'2', 'group'=>'MOSI', '00'=>'PSI receiver using 125kbaud mode', '01'=>'PSI receiver using 189kbaud mode ', '10'=>'PSI receiver using 83.3kbaud mode ',},
								'parameter_3'=> {'name'=>'crc', 'startbit'=>'3', 'length'=>'1', 'group'=>'MOSI', '0'=>'PSI receiver using single bit parity mode', '1'=>'PSI receiver using 3 bit CRC mode',},
								'parameter_4'=> {'name'=>'slot', 'startbit'=>'4', 'length'=>'2', 'group'=>'MOSI', '00'=>'1 sensor mode using single time slot', '01'=>'2 sensor mode using single time slot', '10'=>'3 sensor mode using single time slot', '11'=>'4 sensor mode using single time slot',},
								'parameter_5'=> {'name'=>'qr', 'startbit'=>'6', 'length'=>'1', 'group'=>'MOSI', '0'=>'quiescent regulation - 1 LSB / 8us', '1'=>'quiescent regulation - 1 LSB / 500ns',},
								'parameter_6'=> {'name'=>'filter', 'startbit'=>'7', 'length'=>'2', 'group'=>'MOSI', '00'=>'2 / 3 filter', '01'=>'no filter', '10'=>'3 / 5 filter',},
								'parameter_7'=> {'name'=>'ts', 'startbit'=>'9', 'length'=>'1', 'group'=>'MOSI', '1' => 'PSI data will be ignored if time slot changes during data reception',},
								'parameter_8'=> {'name'=>'p', 'startbit'=>'15', 'length'=>'1', 'group'=>'MOSI', '0'=>'even parity', '1'=>'odd parity',},
								'parameter_9'=> {'name'=>'as', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '0'=>'PSI receiver using synchronous mode', '1'=>'PSI receiver using asynchronous mode',},
								'parameter_10'=> {'name'=>'baud', 'startbit'=>'1', 'length'=>'2', 'group'=>'MISO', '00'=>'PSI receiver using 125kbaud mode', '01'=>'PSI receiver using 189kbaud mode ', '10'=>'PSI receiver using 83.3kbaud mode ',},
								'parameter_11'=> {'name'=>'crc', 'startbit'=>'3', 'length'=>'1', 'group'=>'MISO', '0'=>'PSI receiver using single bit parity mode', '1'=>'PSI receiver using 3 bit CRC mode',},
								'parameter_12'=> {'name'=>'slot', 'startbit'=>'4', 'length'=>'2', 'group'=>'MISO', '00'=>'1 sensor mode using single time slot', '01'=>'2 sensor mode using single time slot', '10'=>'3 sensor mode using single time slot', '11'=>'4 sensor mode using single time slot',},
								'parameter_13'=> {'name'=>'qr', 'startbit'=>'6', 'length'=>'1', 'group'=>'MISO', '0'=>'quiescent regulation - 1 LSB / 8us', '1'=>'quiescent regulation - 1 LSB / 500ns',},
								'parameter_14'=> {'name'=>'filter', 'startbit'=>'7', 'length'=>'2', 'group'=>'MISO', '00'=>'2 / 3 filter', '01'=>'no filter', '10'=>'3 / 5 filter',},
								'parameter_15'=> {'name'=>'ts', 'startbit'=>'9', 'length'=>'1', 'group'=>'MOSI', '1' => 'PSI data will be ignored if time slot changes during data reception',},
								'parameter_16'=> {'name'=>'p', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '0'=>'even parity', '1'=>'odd parity',},
                                },

                'PROG_PSI_LINE5'=>      {
                                'CODE'=> '0110110100',
                                'description'=>'Program PSI lines',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Green',
								'parameter_1'=> {'name'=>'as', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '0'=>'PSI receiver using synchronous mode', '1'=>'PSI receiver using asynchronous mode',},
								'parameter_2'=> {'name'=>'baud', 'startbit'=>'1', 'length'=>'2', 'group'=>'MOSI', '00'=>'PSI receiver using 125kbaud mode', '01'=>'PSI receiver using 189kbaud mode ', '10'=>'PSI receiver using 83.3kbaud mode ',},
								'parameter_3'=> {'name'=>'crc', 'startbit'=>'3', 'length'=>'1', 'group'=>'MOSI', '0'=>'PSI receiver using single bit parity mode', '1'=>'PSI receiver using 3 bit CRC mode',},
								'parameter_4'=> {'name'=>'slot', 'startbit'=>'4', 'length'=>'2', 'group'=>'MOSI', '00'=>'1 sensor mode using single time slot', '01'=>'2 sensor mode using single time slot', '10'=>'3 sensor mode using single time slot', '11'=>'4 sensor mode using single time slot',},
								'parameter_5'=> {'name'=>'qr', 'startbit'=>'6', 'length'=>'1', 'group'=>'MOSI', '0'=>'quiescent regulation - 1 LSB / 8us', '1'=>'quiescent regulation - 1 LSB / 500ns',},
								'parameter_6'=> {'name'=>'filter', 'startbit'=>'7', 'length'=>'2', 'group'=>'MOSI', '00'=>'2 / 3 filter', '01'=>'no filter', '10'=>'3 / 5 filter',},
								'parameter_7'=> {'name'=>'ts', 'startbit'=>'9', 'length'=>'1', 'group'=>'MOSI', '1' => 'PSI data will be ignored if time slot changes during data reception',},
								'parameter_8'=> {'name'=>'p', 'startbit'=>'15', 'length'=>'1', 'group'=>'MOSI', '0'=>'even parity', '1'=>'odd parity',},
								'parameter_9'=> {'name'=>'as', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '0'=>'PSI receiver using synchronous mode', '1'=>'PSI receiver using asynchronous mode',},
								'parameter_10'=> {'name'=>'baud', 'startbit'=>'1', 'length'=>'2', 'group'=>'MISO', '00'=>'PSI receiver using 125kbaud mode', '01'=>'PSI receiver using 189kbaud mode ', '10'=>'PSI receiver using 83.3kbaud mode ',},
								'parameter_11'=> {'name'=>'crc', 'startbit'=>'3', 'length'=>'1', 'group'=>'MISO', '0'=>'PSI receiver using single bit parity mode', '1'=>'PSI receiver using 3 bit CRC mode',},
								'parameter_12'=> {'name'=>'slot', 'startbit'=>'4', 'length'=>'2', 'group'=>'MISO', '00'=>'1 sensor mode using single time slot', '01'=>'2 sensor mode using single time slot', '10'=>'3 sensor mode using single time slot', '11'=>'4 sensor mode using single time slot',},
								'parameter_13'=> {'name'=>'qr', 'startbit'=>'6', 'length'=>'1', 'group'=>'MISO', '0'=>'quiescent regulation - 1 LSB / 8us', '1'=>'quiescent regulation - 1 LSB / 500ns',},
								'parameter_14'=> {'name'=>'filter', 'startbit'=>'7', 'length'=>'2', 'group'=>'MISO', '00'=>'2 / 3 filter', '01'=>'no filter', '10'=>'3 / 5 filter',},
								'parameter_15'=> {'name'=>'ts', 'startbit'=>'9', 'length'=>'1', 'group'=>'MOSI', '1' => 'PSI data will be ignored if time slot changes during data reception',},
								'parameter_16'=> {'name'=>'p', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '0'=>'even parity', '1'=>'odd parity',},
                                },

                'PROG_PSI_LINE6'=>      {
                                'CODE'=> '0110110101',
                                'description'=>'Program PSI lines',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Green',
								'parameter_1'=> {'name'=>'as', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '0'=>'PSI receiver using synchronous mode', '1'=>'PSI receiver using asynchronous mode',},
								'parameter_2'=> {'name'=>'baud', 'startbit'=>'1', 'length'=>'2', 'group'=>'MOSI', '00'=>'PSI receiver using 125kbaud mode', '01'=>'PSI receiver using 189kbaud mode ', '10'=>'PSI receiver using 83.3kbaud mode ',},
								'parameter_3'=> {'name'=>'crc', 'startbit'=>'3', 'length'=>'1', 'group'=>'MOSI', '0'=>'PSI receiver using single bit parity mode', '1'=>'PSI receiver using 3 bit CRC mode',},
								'parameter_4'=> {'name'=>'slot', 'startbit'=>'4', 'length'=>'2', 'group'=>'MOSI', '00'=>'1 sensor mode using single time slot', '01'=>'2 sensor mode using single time slot', '10'=>'3 sensor mode using single time slot', '11'=>'4 sensor mode using single time slot',},
								'parameter_5'=> {'name'=>'qr', 'startbit'=>'6', 'length'=>'1', 'group'=>'MOSI', '0'=>'quiescent regulation - 1 LSB / 8us', '1'=>'quiescent regulation - 1 LSB / 500ns',},
								'parameter_6'=> {'name'=>'filter', 'startbit'=>'7', 'length'=>'2', 'group'=>'MOSI', '00'=>'2 / 3 filter', '01'=>'no filter', '10'=>'3 / 5 filter',},
								'parameter_7'=> {'name'=>'ts', 'startbit'=>'9', 'length'=>'1', 'group'=>'MOSI', '1' => 'PSI data will be ignored if time slot changes during data reception',},
								'parameter_8'=> {'name'=>'p', 'startbit'=>'15', 'length'=>'1', 'group'=>'MOSI', '0'=>'even parity', '1'=>'odd parity',},
								'parameter_9'=> {'name'=>'as', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '0'=>'PSI receiver using synchronous mode', '1'=>'PSI receiver using asynchronous mode',},
								'parameter_10'=> {'name'=>'baud', 'startbit'=>'1', 'length'=>'2', 'group'=>'MISO', '00'=>'PSI receiver using 125kbaud mode', '01'=>'PSI receiver using 189kbaud mode ', '10'=>'PSI receiver using 83.3kbaud mode ',},
								'parameter_11'=> {'name'=>'crc', 'startbit'=>'3', 'length'=>'1', 'group'=>'MISO', '0'=>'PSI receiver using single bit parity mode', '1'=>'PSI receiver using 3 bit CRC mode',},
								'parameter_12'=> {'name'=>'slot', 'startbit'=>'4', 'length'=>'2', 'group'=>'MISO', '00'=>'1 sensor mode using single time slot', '01'=>'2 sensor mode using single time slot', '10'=>'3 sensor mode using single time slot', '11'=>'4 sensor mode using single time slot',},
								'parameter_13'=> {'name'=>'qr', 'startbit'=>'6', 'length'=>'1', 'group'=>'MISO', '0'=>'quiescent regulation - 1 LSB / 8us', '1'=>'quiescent regulation - 1 LSB / 500ns',},
								'parameter_14'=> {'name'=>'filter', 'startbit'=>'7', 'length'=>'2', 'group'=>'MISO', '00'=>'2 / 3 filter', '01'=>'no filter', '10'=>'3 / 5 filter',},
								'parameter_15'=> {'name'=>'ts', 'startbit'=>'9', 'length'=>'1', 'group'=>'MOSI', '1' => 'PSI data will be ignored if time slot changes during data reception',},
								'parameter_16'=> {'name'=>'p', 'startbit'=>'15', 'length'=>'1', 'group'=>'MISO', '0'=>'even parity', '1'=>'odd parity',},
								,
                                },

                'PROG_PSI_SID1'=>       {
                                'CODE'=> '0111000001',
                                'description'=>'Program PSI safety identifier',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Oker',
								'parameter_1'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_2'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MOSI',},
								'parameter_3'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_4'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MISO',},
                                },

                'PROG_PSI_SID2'=>       {
                                'CODE'=> '0111000010',
                                'description'=>'Program PSI safety identifier',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Oker',
								'parameter_1'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_2'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MOSI',},
								'parameter_3'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_4'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MISO',},
                                },

                'PROG_PSI_SID3'=>       {
                                'CODE'=> '0111000011',
                                'description'=>'Program PSI safety identifier',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Oker',
								'parameter_1'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_2'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MOSI',},
								'parameter_3'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_4'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MISO',},
                                },

                'PROG_PSI_SID4'=>       {
                                'CODE'=> '0111000100',
                                'description'=>'Program PSI safety identifier',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Oker',
								'parameter_1'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_2'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MOSI',},
								'parameter_3'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_4'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MISO',},
                                },

                'PROG_PSI_SID5'=>       {
                                'CODE'=> '0111000101',
                                'description'=>'Program PSI safety identifier',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Oker',
								'parameter_1'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_2'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MOSI',},
								'parameter_3'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_4'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MISO',},
                                },

                'PROG_PSI_SID6'=>       {
                                'CODE'=> '0111000110',
                                'description'=>'Program PSI safety identifier',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Oker',
								'parameter_1'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_2'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MOSI',},
								'parameter_3'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_4'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MISO',},
                                },

                'PROG_PSI_SID7'=>       {
                                'CODE'=> '0111000111',
                                'description'=>'Program PSI safety identifier',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Oker',
								'parameter_1'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_2'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MOSI',},
								'parameter_3'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_4'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MISO',},
                                },

                'PROG_PSI_SID8'=>       {
                                'CODE'=> '0111001000',
                                'description'=>'Program PSI safety identifier',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Oker',
								'parameter_1'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_2'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MOSI',},
								'parameter_3'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_4'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MISO',},
                                },

                'PROG_PSI_SID9'=>       {
                                'CODE'=> '0111001001',
                                'description'=>'Program PSI safety identifier',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Oker',
								'parameter_1'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_2'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MOSI',},
								'parameter_3'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_4'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MISO',},
                                },

                'PROG_PSI_SID10'=>      {
                                'CODE'=> '0111001010',
                                'description'=>'Program PSI safety identifier',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Oker',
								'parameter_1'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_2'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MOSI',},
								'parameter_3'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_4'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MISO',},
                                },

                'PROG_PSI_SID11'=>      {
                                'CODE'=> '0111001011',
                                'description'=>'Program PSI safety identifier',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Oker',
								'parameter_1'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_2'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MOSI',},
								'parameter_3'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_4'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MISO',},
                                },

                'PROG_PSI_SID12'=>      {
                                'CODE'=> '0111001100',
                                'description'=>'Program PSI safety identifier',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Oker',
								'parameter_1'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_2'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MOSI',},
								'parameter_3'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_4'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MISO',},
                                },

                'PROG_PSI_SID13'=>      {
                                'CODE'=> '0111001101',
                                'description'=>'Program PSI safety identifier',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Oker',
								'parameter_1'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_2'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MOSI',},
								'parameter_3'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_4'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MISO',},
                                },

                'PROG_PSI_SID14'=>      {
                                'CODE'=> '0111001110',
                                'description'=>'Program PSI safety identifier',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Oker',
								'parameter_1'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_2'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MOSI',},
								'parameter_3'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_4'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MISO',},
                                },

                'PROG_PSI_SID15'=>      {
                                'CODE'=> '0111001111',
                                'description'=>'Program PSI safety identifier',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Oker',
								'parameter_1'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_2'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MOSI',},
								'parameter_3'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_4'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MISO',},
                                },

                'PROG_PSI_SID16'=>      {
                                'CODE'=> '0111010000',
                                'description'=>'Program PSI safety identifier',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Oker',
								'parameter_1'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_2'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MOSI',},
								'parameter_3'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_4'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MISO',},
                                },

                'PROG_PSI_SID17'=>      {
                                'CODE'=> '0111010001',
                                'description'=>'Program PSI safety identifier',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Oker',
								'parameter_1'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_2'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MOSI',},
								'parameter_3'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_4'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MISO',},
                                },

                'PROG_PSI_SID18'=>      {
                                'CODE'=> '0111010010',
                                'description'=>'Program PSI safety identifier',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Oker',
								'parameter_1'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_2'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MOSI',},
								'parameter_3'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_4'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MISO',},
                                },

                'PROG_PSI_SID19'=>      {
                                'CODE'=> '0111010011',
                                'description'=>'Program PSI safety identifier',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Oker',
								'parameter_1'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_2'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MOSI',},
								'parameter_3'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_4'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MISO',},,
                                },

                'PROG_PSI_SID20'=>      {
                                'CODE'=> '0111010100',
                                'description'=>'Program PSI safety identifier',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Oker',
								'parameter_1'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_2'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MOSI',},
								'parameter_3'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_4'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MISO',},
                                },

                'PROG_PSI_SID21'=>      {
                                'CODE'=> '0111010101',
                                'description'=>'Program PSI safety identifier',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Oker',
								'parameter_1'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_2'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MOSI',},
								'parameter_3'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_4'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MISO',},
                                },

                'PROG_PSI_SID22'=>      {
                                'CODE'=> '0111010110',
                                'description'=>'Program PSI safety identifier',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Oker',
								'parameter_1'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_2'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MOSI',},
								'parameter_3'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_4'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MISO',},
                                },

                'PROG_PSI_SID23'=>      {
                                'CODE'=> '0111010111',
                                'description'=>'Program PSI safety identifier',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Oker',
								'parameter_1'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_2'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MOSI',},
								'parameter_3'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_4'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MISO',},
                                },

                'PROG_PSI_SID24'=>      {
                                'CODE'=> '0111011000',
                                'description'=>'Program PSI safety identifier',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Oker',
								'parameter_1'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_2'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MOSI',},
								'parameter_3'=> {'name'=>'p', 'startbit'=>'0', 'length'=>'1', 'group'=>'MISO', '1'=>'odd parity', '0'=>'no parity error for an unprogrammed SID'},
								'parameter_4'=> {'name'=>'psi_sid', 'startbit'=>'1', 'length'=>'5', 'group'=>'MISO',},
                                },

                'READ_SENSOR'=> {
                                'CODE'=> '1---------',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Green',
                                'parameter_1'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                },

                'READ_SENSOR_16'=>      {
                                'CODE'=> '1-----0',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Yellow',
                                'parameter_1'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                },

                'PSI_READ_DATA1'=>  {
                                'CODE'=> '1000000000',
                                'description'=>'Read PSI sensor data',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Pink',
								'parameter_2'=>    {'name'=>'clr', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'clear undervoltage flags vu, vs, vas'},
								'parameter_2'=>    {'name'=>'psi_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',},
								'parameter_3'=>    {'name'=>'vs', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'VSYNC  low', '0'=>'VSYNC  is ok'},
								'parameter_4'=>    {'name'=>'vu', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'VUP low', '0'=>'VUP is ok'},
								'parameter_5'=>    {'name'=>'vas', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'VAS  low', '0'=>'VAS  is ok'},
                                },
								
				'PSI_READ_DATA2'=>  {
                                'CODE'=> '1000010000',
                                'description'=>'Read PSI sensor data',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Pink',
								'parameter_2'=>    {'name'=>'clr', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'clear undervoltage flags vu, vs, vas'},
								'parameter_2'=>    {'name'=>'psi_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',},
								'parameter_3'=>    {'name'=>'vs', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'VSYNC  low', '0'=>'VSYNC  is ok'},
								'parameter_4'=>    {'name'=>'vu', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'VUP low', '0'=>'VUP is ok'},
								'parameter_5'=>    {'name'=>'vas', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'VAS  low', '0'=>'VAS  is ok'},
                                },
								
				'PSI_READ_DATA3'=>  {
                                'CODE'=> '1000100000',
                                'description'=>'Read PSI sensor data',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Pink',
								'parameter_2'=>    {'name'=>'clr', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'clear undervoltage flags vu, vs, vas'},
								'parameter_2'=>    {'name'=>'psi_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',},
								'parameter_3'=>    {'name'=>'vs', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'VSYNC  low', '0'=>'VSYNC  is ok'},
								'parameter_4'=>    {'name'=>'vu', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'VUP low', '0'=>'VUP is ok'},
								'parameter_5'=>    {'name'=>'vas', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'VAS  low', '0'=>'VAS  is ok'},
                                },
								
				'PSI_READ_DATA4'=>  {
                                'CODE'=> '1000110000',
                                'description'=>'Read PSI sensor data',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Pink',
								'parameter_2'=>    {'name'=>'clr', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'clear undervoltage flags vu, vs, vas'},
								'parameter_2'=>    {'name'=>'psi_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',},
								'parameter_3'=>    {'name'=>'vs', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'VSYNC  low', '0'=>'VSYNC  is ok'},
								'parameter_4'=>    {'name'=>'vu', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'VUP low', '0'=>'VUP is ok'},
								'parameter_5'=>    {'name'=>'vas', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'VAS  low', '0'=>'VAS  is ok'},
                                },
								
				'PSI_READ_DATA5'=>  {
                                'CODE'=> '1001000000',
                                'description'=>'Read PSI sensor data',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Pink',
								'parameter_2'=>    {'name'=>'clr', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'clear undervoltage flags vu, vs, vas'},
								'parameter_2'=>    {'name'=>'psi_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',},
								'parameter_3'=>    {'name'=>'vs', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'VSYNC  low', '0'=>'VSYNC  is ok'},
								'parameter_4'=>    {'name'=>'vu', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'VUP low', '0'=>'VUP is ok'},
								'parameter_5'=>    {'name'=>'vas', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'VAS  low', '0'=>'VAS  is ok'},
                                },
								
				'PSI_READ_DATA6'=>  {
                                'CODE'=> '1001010000',
                                'description'=>'Read PSI sensor data',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Pink',
								'parameter_2'=>    {'name'=>'clr', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'clear undervoltage flags vu, vs, vas'},
								'parameter_2'=>    {'name'=>'psi_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',},
								'parameter_3'=>    {'name'=>'vs', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'VSYNC  low', '0'=>'VSYNC  is ok'},
								'parameter_4'=>    {'name'=>'vu', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'VUP low', '0'=>'VUP is ok'},
								'parameter_5'=>    {'name'=>'vas', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'VAS  low', '0'=>'VAS  is ok'},
                                },
								
				'PSI_READ_DATA7'=>  {
                                'CODE'=> '1001100000',
                                'description'=>'Read PSI sensor data',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Pink',
								'parameter_2'=>    {'name'=>'clr', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'clear undervoltage flags vu, vs, vas'},
								'parameter_2'=>    {'name'=>'psi_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',},
								'parameter_3'=>    {'name'=>'vs', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'VSYNC  low', '0'=>'VSYNC  is ok'},
								'parameter_4'=>    {'name'=>'vu', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'VUP low', '0'=>'VUP is ok'},
								'parameter_5'=>    {'name'=>'vas', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'VAS  low', '0'=>'VAS  is ok'},
                                },
								
				'PSI_READ_DATA8'=>  {
                                'CODE'=> '1001110000',
                                'description'=>'Read PSI sensor data',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Pink',
								'parameter_2'=>    {'name'=>'clr', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'clear undervoltage flags vu, vs, vas'},
								'parameter_2'=>    {'name'=>'psi_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',},
								'parameter_3'=>    {'name'=>'vs', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'VSYNC  low', '0'=>'VSYNC  is ok'},
								'parameter_4'=>    {'name'=>'vu', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'VUP low', '0'=>'VUP is ok'},
								'parameter_5'=>    {'name'=>'vas', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'VAS  low', '0'=>'VAS  is ok'},
                                },
								
				'PSI_READ_DATA9'=>  {
                                'CODE'=> '1010000000',
                                'description'=>'Read PSI sensor data',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Pink',
								'parameter_2'=>    {'name'=>'clr', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'clear undervoltage flags vu, vs, vas'},
								'parameter_2'=>    {'name'=>'psi_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',},
								'parameter_3'=>    {'name'=>'vs', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'VSYNC  low', '0'=>'VSYNC  is ok'},
								'parameter_4'=>    {'name'=>'vu', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'VUP low', '0'=>'VUP is ok'},
								'parameter_5'=>    {'name'=>'vas', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'VAS  low', '0'=>'VAS  is ok'},
                                },
								
				'PSI_READ_DATA10'=>  {
                                'CODE'=> '1010010000',
                                'description'=>'Read PSI sensor data',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Pink',
								'parameter_2'=>    {'name'=>'clr', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'clear undervoltage flags vu, vs, vas'},
								'parameter_2'=>    {'name'=>'psi_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',},
								'parameter_3'=>    {'name'=>'vs', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'VSYNC  low', '0'=>'VSYNC  is ok'},
								'parameter_4'=>    {'name'=>'vu', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'VUP low', '0'=>'VUP is ok'},
								'parameter_5'=>    {'name'=>'vas', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'VAS  low', '0'=>'VAS  is ok'},
                                },
								
				'PSI_READ_DATA11'=>  {
                                'CODE'=> '1010100000',
                                'description'=>'Read PSI sensor data',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Pink',
								'parameter_2'=>    {'name'=>'clr', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'clear undervoltage flags vu, vs, vas'},
								'parameter_2'=>    {'name'=>'psi_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',},
								'parameter_3'=>    {'name'=>'vs', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'VSYNC  low', '0'=>'VSYNC  is ok'},
								'parameter_4'=>    {'name'=>'vu', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'VUP low', '0'=>'VUP is ok'},
								'parameter_5'=>    {'name'=>'vas', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'VAS  low', '0'=>'VAS  is ok'},
                                },
								
				'PSI_READ_DATA12'=>  {
                                'CODE'=> '1010110000',
                                'description'=>'Read PSI sensor data',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Pink',
								'parameter_2'=>    {'name'=>'clr', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'clear undervoltage flags vu, vs, vas'},
								'parameter_2'=>    {'name'=>'psi_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',},
								'parameter_3'=>    {'name'=>'vs', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'VSYNC  low', '0'=>'VSYNC  is ok'},
								'parameter_4'=>    {'name'=>'vu', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'VUP low', '0'=>'VUP is ok'},
								'parameter_5'=>    {'name'=>'vas', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'VAS  low', '0'=>'VAS  is ok'},
                                },
								
				'PSI_READ_DATA13'=>  {
                                'CODE'=> '1011000000',
                                'description'=>'Read PSI sensor data',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Pink',
								'parameter_2'=>    {'name'=>'clr', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'clear undervoltage flags vu, vs, vas'},
								'parameter_2'=>    {'name'=>'psi_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',},
								'parameter_3'=>    {'name'=>'vs', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'VSYNC  low', '0'=>'VSYNC  is ok'},
								'parameter_4'=>    {'name'=>'vu', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'VUP low', '0'=>'VUP is ok'},
								'parameter_5'=>    {'name'=>'vas', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'VAS  low', '0'=>'VAS  is ok'},
                                },
								
				'PSI_READ_DATA14'=>  {
                                'CODE'=> '1011010000',
                                'description'=>'Read PSI sensor data',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Pink',
								'parameter_2'=>    {'name'=>'clr', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'clear undervoltage flags vu, vs, vas'},
								'parameter_2'=>    {'name'=>'psi_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',},
								'parameter_3'=>    {'name'=>'vs', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'VSYNC  low', '0'=>'VSYNC  is ok'},
								'parameter_4'=>    {'name'=>'vu', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'VUP low', '0'=>'VUP is ok'},
								'parameter_5'=>    {'name'=>'vas', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'VAS  low', '0'=>'VAS  is ok'},
                                },
								
				'PSI_READ_DATA15'=>  {
                                'CODE'=> '1011100000',
                                'description'=>'Read PSI sensor data',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Pink',
								'parameter_2'=>    {'name'=>'clr', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'clear undervoltage flags vu, vs, vas'},
								'parameter_2'=>    {'name'=>'psi_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',},
								'parameter_3'=>    {'name'=>'vs', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'VSYNC  low', '0'=>'VSYNC  is ok'},
								'parameter_4'=>    {'name'=>'vu', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'VUP low', '0'=>'VUP is ok'},
								'parameter_5'=>    {'name'=>'vas', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'VAS  low', '0'=>'VAS  is ok'},
                                },
								
				'PSI_READ_DATA16'=>  {
                                'CODE'=> '1011110000',
                                'description'=>'Read PSI sensor data',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Pink',
								'parameter_2'=>    {'name'=>'clr', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'clear undervoltage flags vu, vs, vas'},
								'parameter_2'=>    {'name'=>'psi_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',},
								'parameter_3'=>    {'name'=>'vs', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'VSYNC  low', '0'=>'VSYNC  is ok'},
								'parameter_4'=>    {'name'=>'vu', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'VUP low', '0'=>'VUP is ok'},
								'parameter_5'=>    {'name'=>'vas', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'VAS  low', '0'=>'VAS  is ok'},
                                },
								
				'PSI_READ_DATA17'=>  {
                                'CODE'=> '1100000000',
                                'description'=>'Read PSI sensor data',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Pink',
								'parameter_2'=>    {'name'=>'clr', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'clear undervoltage flags vu, vs, vas'},
								'parameter_2'=>    {'name'=>'psi_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',},
								'parameter_3'=>    {'name'=>'vs', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'VSYNC  low', '0'=>'VSYNC  is ok'},
								'parameter_4'=>    {'name'=>'vu', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'VUP low', '0'=>'VUP is ok'},
								'parameter_5'=>    {'name'=>'vas', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'VAS  low', '0'=>'VAS  is ok'},
                                },
								
				'PSI_READ_DATA18'=>  {
                                'CODE'=> '1100010000',
                                'description'=>'Read PSI sensor data',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Pink',
								'parameter_2'=>    {'name'=>'clr', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'clear undervoltage flags vu, vs, vas'},
								'parameter_2'=>    {'name'=>'psi_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',},
								'parameter_3'=>    {'name'=>'vs', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'VSYNC  low', '0'=>'VSYNC  is ok'},
								'parameter_4'=>    {'name'=>'vu', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'VUP low', '0'=>'VUP is ok'},
								'parameter_5'=>    {'name'=>'vas', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'VAS  low', '0'=>'VAS  is ok'},
                                },
								
				'PSI_READ_DATA19'=>  {
                                'CODE'=> '1100100000',
                                'description'=>'Read PSI sensor data',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Pink',
								'parameter_2'=>    {'name'=>'clr', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'clear undervoltage flags vu, vs, vas'},
								'parameter_2'=>    {'name'=>'psi_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',},
								'parameter_3'=>    {'name'=>'vs', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'VSYNC  low', '0'=>'VSYNC  is ok'},
								'parameter_4'=>    {'name'=>'vu', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'VUP low', '0'=>'VUP is ok'},
								'parameter_5'=>    {'name'=>'vas', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'VAS  low', '0'=>'VAS  is ok'},
                                },
								
				'PSI_READ_DATA20'=>  {
                                'CODE'=> '1100110000',
                                'description'=>'Read PSI sensor data',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Pink',
								'parameter_2'=>    {'name'=>'clr', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'clear undervoltage flags vu, vs, vas'},
								'parameter_2'=>    {'name'=>'psi_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',},
								'parameter_3'=>    {'name'=>'vs', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'VSYNC  low', '0'=>'VSYNC  is ok'},
								'parameter_4'=>    {'name'=>'vu', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'VUP low', '0'=>'VUP is ok'},
								'parameter_5'=>    {'name'=>'vas', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'VAS  low', '0'=>'VAS  is ok'},
                                },
								
				'PSI_READ_DATA21'=>  {
                                'CODE'=> '1101000000',
                                'description'=>'Read PSI sensor data',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Pink',
								'parameter_2'=>    {'name'=>'clr', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'clear undervoltage flags vu, vs, vas'},
								'parameter_2'=>    {'name'=>'psi_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',},
								'parameter_3'=>    {'name'=>'vs', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'VSYNC  low', '0'=>'VSYNC  is ok'},
								'parameter_4'=>    {'name'=>'vu', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'VUP low', '0'=>'VUP is ok'},
								'parameter_5'=>    {'name'=>'vas', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'VAS  low', '0'=>'VAS  is ok'},
                                },
								
				'PSI_READ_DATA22'=>  {
                                'CODE'=> '1101010000',
                                'description'=>'Read PSI sensor data',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Pink',
								'parameter_2'=>    {'name'=>'clr', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'clear undervoltage flags vu, vs, vas'},
								'parameter_2'=>    {'name'=>'psi_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',},
								'parameter_3'=>    {'name'=>'vs', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'VSYNC  low', '0'=>'VSYNC  is ok'},
								'parameter_4'=>    {'name'=>'vu', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'VUP low', '0'=>'VUP is ok'},
								'parameter_5'=>    {'name'=>'vas', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'VAS  low', '0'=>'VAS  is ok'},
                                },
								
				'PSI_READ_DATA23'=>  {
                                'CODE'=> '1101100000',
                                'description'=>'Read PSI sensor data',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Pink',
								'parameter_2'=>    {'name'=>'clr', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'clear undervoltage flags vu, vs, vas'},
								'parameter_2'=>    {'name'=>'psi_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',},
								'parameter_3'=>    {'name'=>'vs', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'VSYNC  low', '0'=>'VSYNC  is ok'},
								'parameter_4'=>    {'name'=>'vu', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'VUP low', '0'=>'VUP is ok'},
								'parameter_5'=>    {'name'=>'vas', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'VAS  low', '0'=>'VAS  is ok'},
                                },
								
				'PSI_READ_DATA24'=>  {
                                'CODE'=> '1101110000',
                                'description'=>'Read PSI sensor data',
                                'datasize'=> '16',
                                'module'=>'PSI',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Pink',
								'parameter_2'=>    {'name'=>'clr', 'startbit'=>'0', 'length'=>'1', 'group'=>'MOSI', '1'=>'clear undervoltage flags vu, vs, vas'},
								'parameter_2'=>    {'name'=>'psi_data', 'startbit'=>'0', 'length'=>'10', 'group'=>'MISO',},
								'parameter_3'=>    {'name'=>'vs', 'startbit'=>'10', 'length'=>'1', 'group'=>'MISO', '1'=>'VSYNC  low', '0'=>'VSYNC  is ok'},
								'parameter_4'=>    {'name'=>'vu', 'startbit'=>'11', 'length'=>'1', 'group'=>'MISO', '1'=>'VUP low', '0'=>'VUP is ok'},
								'parameter_5'=>    {'name'=>'vas', 'startbit'=>'12', 'length'=>'1', 'group'=>'MISO', '1'=>'VAS  low', '0'=>'VAS  is ok'},
                                },

                'READ_SENSOR1'=>        {
                                'CODE'=> '1000010000',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Yellow',
                                'parameter_1'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                },

                'READ_SENSOR2'=>        {
                                'CODE'=> '1001010000',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Yellow',
                                'parameter_1'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                },

                'READ_SENSOR3'=>        {
                                'CODE'=> '1010000000',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Yellow',
                                'parameter_1'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                },

                'READ_SENSOR4'=>        {
                                'CODE'=> '1010010000',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Yellow',
                                'parameter_1'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                },

                'READ_SENSOR5'=>        {
                                'CODE'=> '1010100000',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Yellow',
                                'parameter_1'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                },

                'READ_SENSOR6'=>        {
                                'CODE'=> '1011000000',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Yellow',
                                'parameter_1'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                },

                'READ_SENSOR7'=>        {
                                'CODE'=> '1011010000',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Yellow',
                                'parameter_1'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                },

                'READ_SENSOR8'=>        {
                                'CODE'=> '1011100000',
                                'description'=>'na',
                                'datasize'=> '16',
                                'module'=>'SAM',
                                'ASIC'=>'CG904_SA1,CG904_SA2,CG904_SA3',
                                'platform'=>'AB12',
                                'color' => 'light_Yellow',
                                'parameter_1'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                'parameter_2'=>    {
                                                        'name'=>'na', 'startbit'=>'0', 'length'=>'0', 'group'=>'na', 
                                                        },
                                },
								
				'AIO1_STATUS'=>			{
								'CODE'			=>'0001000000',
								'description'	=>'na',
								'datasize'		=>'16',
								'ASIC'			=>'CG904_SA1,CG904_SA2,CG904_SA3',
								'platform'		=>'AB12',
								'color' 		=>'light_Red',
								'parameter_1'	=>	{	
														'name'=>'aio_status', 	'startbit'=>'0', 	'length'=>'3', 	'group'=>'MISO',
													},
								'parameter_2'	=> {
														'name'=>'on', 	'startbit'=>'3', 	'length'=>'1', 	'group'=>'MISO',	'0'=>'AIO is/was not switched on',
																																'1'=>'AIO is/was switched on (since last read)',
													},
								'parameter_3'	=> {
														'name'=>'off', 	'startbit'=>'4', 	'length'=>'1', 	'group'=>'MISO', 	'0'=>'AIO is/was not switched off', 
																																'1' => 'AIO is/was switched off (since last read)',
													},
								'parameter_4'	=> {
														'name'=>'vzl', 	'startbit'=>'15', 	'length'=>'1', 	'group'=>'MISO', 	'0'=>'VZP OK (status at the moment of shortcut evaluation)', '1' => 'VZP too low',
													},
				},
				
				'AIO2_STATUS'=>			{
								'CODE'			=>'0001000001',
								'description'	=>'na',
								'datasize'		=>'16',
								'ASIC'			=>'CG904_SA1,CG904_SA2,CG904_SA3',
								'platform'		=>'AB12',
								'color' 		=>'light_Yellow',
								'parameter_1'	=>	{	
														'name'=>'aio_status', 	'startbit'=>'0', 	'length'=>'3', 	'group'=>'MISO',
													},
								'parameter_2'	=> {
														'name'=>'on', 	'startbit'=>'3', 	'length'=>'1', 	'group'=>'MISO',	'0'=>'AIO is/was not switched on',
																																'1'=>'AIO is/was switched on (since last read)',
													},
								'parameter_3'	=> {
														'name'=>'off', 	'startbit'=>'4', 	'length'=>'1', 	'group'=>'MISO', 	'0'=>'AIO is/was not switched off', 
																																'1' => 'AIO is/was switched off (since last read)',
													},
								'parameter_4'	=> {
														'name'=>'vzl', 	'startbit'=>'15', 	'length'=>'1', 	'group'=>'MISO', 	'0'=>'VZP OK (status at the moment of shortcut evaluation)', '1' => 'VZP too low',
													},
				},
				
				
				'AIO_LIN_EN'=>			{
								'CODE'			=>'0001000101',
								'description'	=>'na',
								'datasize'		=>'16',
								'ASIC'			=>'CG904_SA1,CG904_SA2,CG904_SA3',
								'platform'		=>'AB12',
								'color' 		=>'light_Green',
								'parameter_1'	=>	{	
														'name'=>'a1', 	'startbit'=>'0', 	'length'=>'1', 	'group'=>'MOSI',	'1'=>'re-enable AIO1 after short current switch-off',
													},
								'parameter_2'	=> {
														'name'=>'a2', 	'startbit'=>'1', 	'length'=>'1', 	'group'=>'MOSI',	'1'=>'re-enable AIO2 after short current switch-off',
													},
								'parameter_3'	=> {
														'name'=>'In', 	'startbit'=>'2', 	'length'=>'1', 	'group'=>'MOSI', 	'1'=>'re-enable LIN interface after short current switch-off', 
													},
				},
				
				'LIN_PWM'=>			{
								'CODE'			=>'0001000100',
								'description'	=>'na',
								'datasize'		=>'16',
								'ASIC'			=>'CG904_SA1,CG904_SA2,CG904_SA3',
								'platform'		=>'AB12',
								'color' 		=>'light_Blue',
								'parameter_1'	=>	{	
														'name'=>'pulse_width', 	'startbit'=>'0', 	'length'=>'7', 	'group'=>'MOSI', '0000000' => 'no PWM signal, DIA switched off',
													},
								'parameter_2'	=> {
														'name'=>'fce', 	'startbit'=>'7', 	'length'=>'1', 	'group'=>'MOSI',	'0'=>'a pulse width change is synchronized to the next PWM cycle (default)',
																																'1'=>'DIA reacts instantly to a pulse width change',
													},
				},
				
				
				'PROG_AIO1'=>			{
								'CODE'			=>'0110001110',
								'description'	=>'na',
								'datasize'		=>'16',
								'ASIC'			=>'CG904_SA1,CG904_SA2,CG904_SA3',
								'platform'		=>'AB12',
								'color' 		=>'light_Blue',
								'parameter_1'	=>	{	
														'name'=>'aio_current', 	'startbit'=>'0', 	'length'=>'4', 	'group'=>'MOSI', 	'0000' => 'AIO switched off (default)',
																																		'1111' => 'AIO in PWM mode (controlled by internal PWM signal: 0mA / 70mA)',
																																		
																																		
													},
								'parameter_2'	=> {
														'name'=>'wl_mode', 	'startbit'=>'4', 	'length'=>'2', 	'group'=>'MOSI',		'00'=>'normal mode, no DIS_ALP influence (default 00)',
																																		'11'=>'normal mode, no DIS_ALP influence (default 00)',
																																		'01'=>'non inverted warning lamp mode (DIS_ALP = high => current on)',
																																		'10'=>'inverted warning lamp mode (DIS_ALP = high => current off)',
																																		
													},
													
								'parameter_3'	=> {
														'name'=>'cp', 	'startbit'=>'6', 	'length'=>'1', 	'group'=>'MOSI',		    '0'=>'AIO2 is controlled individually (default)',
																																		'1'=>'AIO2 is coupled to AIO1 (AIO1 and AIO2 connected externally)',
																																		
													},
													
								'parameter_4'	=>	{	
														'name'=>'aio_current', 	'startbit'=>'0', 	'length'=>'4', 	'group'=>'MISO', 	'0000' => 'AIO switched off (default)',
																																		'1111' => 'AIO in PWM mode (controlled by internal PWM signal: 0mA / 70mA)',
													},
								'parameter_5'	=> {
														'name'=>'wl_mode', 	'startbit'=>'4', 	'length'=>'2', 	'group'=>'MISO',		'00'=>'normal mode, no DIS_ALP influence (default 00)',
																																		'11'=>'normal mode, no DIS_ALP influence (default 00)',
																																		'01'=>'non inverted warning lamp mode (DIS_ALP = high => current on)',
																																		'10'=>'inverted warning lamp mode (DIS_ALP = high => current off)',
													},
													
								'parameter_6'	=> {
														'name'=>'cp', 	'startbit'=>'6', 	'length'=>'1', 	'group'=>'MISO',		    '0'=>'AIO2 is controlled individually (default)',
																																		'1'=>'AIO2 is coupled to AIO1 (AIO1 and AIO2 connected externally)',
													},
													
													
				},

				
				
				'PROG_AIO2'=>			{
								'CODE'			=>'0110001111',
								'description'	=>'na',
								'datasize'		=>'16',
								'ASIC'			=>'CG904_SA1,CG904_SA2,CG904_SA3',
								'platform'		=>'AB12',
								'color' 		=>'light_Blue',
								'parameter_1'	=>	{	
														'name'=>'aio_current', 	'startbit'=>'0', 	'length'=>'4', 	'group'=>'MOSI', 	'0000' => 'AIO switched off (default)',
																																		'1111' => 'AIO in PWM mode (controlled by internal PWM signal: 0mA / 70mA)',
																																		
																																		
													},
								'parameter_2'	=> {
														'name'=>'wl_mode', 	'startbit'=>'4', 	'length'=>'2', 	'group'=>'MOSI',		'00'=>'normal mode, no DIS_ALP influence (default 00)',
																																		'11'=>'normal mode, no DIS_ALP influence (default 00)',
																																		'01'=>'non inverted warning lamp mode (DIS_ALP = high => current on)',
																																		'10'=>'inverted warning lamp mode (DIS_ALP = high => current off)',
													},
													
								'parameter_3'	=> {
														'name'=>'cp', 	'startbit'=>'6', 	'length'=>'1', 	'group'=>'MOSI',																			
													},
													
								'parameter_4'	=>	{	
														'name'=>'aio_current', 	'startbit'=>'0', 	'length'=>'4', 	'group'=>'MISO', 	'0000' => 'AIO switched off (default)',
																																		'1111' => 'AIO in PWM mode (controlled by internal PWM signal: 0mA / 70mA)',
													},
								'parameter_5'	=> {
														'name'=>'wl_mode', 	'startbit'=>'4', 	'length'=>'2', 	'group'=>'MISO',		'00'=>'normal mode, no DIS_ALP influence (default 00)',
																																		'11'=>'normal mode, no DIS_ALP influence (default 00)',
																																		'01'=>'non inverted warning lamp mode (DIS_ALP = high => current on)',
																																		'10'=>'inverted warning lamp mode (DIS_ALP = high => current off)',
													},
													
								'parameter_6'	=> {
														'name'=>'cp', 	'startbit'=>'6', 	'length'=>'1', 	'group'=>'MISO',
													},
													
													
				},
				
				'PROG_LIN'=>			{
								'CODE'			=>'0110000000',
								'description'	=>'na',
								'datasize'		=>'16',
								'ASIC'			=>'CG904_SA1,CG904_SA2,CG904_SA3',
								'platform'		=>'AB12',
								'color' 		=>'light_Blue',
								
								'parameter_1'	=>	{	
														'name'=>'lin_current', 	'startbit'=>'0', 	'length'=>'6', 	'group'=>'MOSI', 																				
													},
								'parameter_2'	=> {
														'name'=>'lin', 	'startbit'=>'6', 	'length'=>'1', 	'group'=>'MOSI',	'0'=>'general purpose mode (default)', '1' => 'LIN mode',
																																		
													},
								'parameter_3'	=>	{	
														'name'=>'dt', 	'startbit'=>'7', 	'length'=>'1', 	'group'=>'MOSI', 	'0' => 'off (default)',
																																'1' => 'on',
													},													
								'parameter_4'	=>	{	
														'name'=>'lin_current', 	'startbit'=>'0', 	'length'=>'6', 	'group'=>'MISO', 																				
													},
								'parameter_5'	=> {
														'name'=>'lin', 	'startbit'=>'6', 	'length'=>'1', 	'group'=>'MISO',	'0'=>'general purpose mode (default)', '1' => 'LIN mode',
																																		
													},
								'parameter_6'	=>	{	
														'name'=>'dt', 	'startbit'=>'7', 	'length'=>'1', 	'group'=>'MISO', 	'0' => 'off (default)',
																																'1' => 'on',
													},
				},
},

'AB10' => {
	
	  ####################################################################################
      #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<   IXS MAPPING   >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
      ####################################################################################
	
	'IXS_MAPPING' => { # chip select mapping for Idefix and SPImaid (SPI & PAS-line) records
                        'CS0'  => 'CG103',
                        'CS2'  => 'SMA560',
                        'CS3'  => 'SMG100',
                        'CS4'  => 'CF190',
                        'CS5'  => 'SMB200',
                        'CS6'  => 'CG143',
                        'CS7'  => 'SMA560P',
                        'CS8'  => 'CS8',
                        'CS9'  => 'CS9',
                        'CS10' => 'CS10',
                        'CS11' => 'CS11',
                        'CS12' => 'EEPROM',
                        'CS13' => 'EEPROMdata',
                        'CS15' => 'LA',                   
						},
	 
	  ####################################################################################
      #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< FRAME FORMAT >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
      ####################################################################################		
      
      #AB10 commands - frame length in bits
      'frame_length' => '32',
      'instruction_length' => '8',
      'data_length' => '8',
							
	  'CG904_SA1_FORMAT' => { #start bit numbers and length (start from LHS bit 0)
	  						'MOSI_data_start' => '11',
	  						'MOSI_data_length' => '16',
	  						'MISO_data_start' => '12',
	  						'MISO_data_length' => '16',
	  						'MISO_SID_start' => '7',
	  						'MISO_SID_length' => '5',
	  						'MISO_Stat_start' => '0',
	  						'MISO_Stat_length' => '6',
	  						
	  					 },
																
	  ####################################################################################
      #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< SENSOR  COMMANDS >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>#
      ####################################################################################		
      
      
      'PPS2_COMMAND' => {
                        '0000000000' => 'Sensor_Data',         
                        '1000000000' => 'Block_ID_1',
                        '1000000001' => 'Block_ID_2',
                        '1000000010' => 'Block_ID_3',             
                        '1000000011' => 'Block_ID_4',
                        '1000000100' => 'Block_ID_5',
                        '1000000101' => 'Block_ID_6',             
                        '1000000110' => 'Block_ID_7',             
                        '1000000111' => 'Block_ID_8',             
                        '1000001000' => 'Block_ID_9',               
                        '1000001001' => 'Block_ID_10',               
                        '1000001010' => 'Block_ID_11',              
                        '1000001011' => 'Block_ID_12',               
                        '1000001100' => 'Block_ID_13',               
                        '1000001101' => 'Block_ID_14',              
                        '1000001110' => 'Block_ID_15',               
                        '1000001111' => 'Block_ID_16',               
                        '1000010000' => 'Status_Data',               
                        '1000010001' => 'Status_Data',              
                        '1000010010' => 'Status_Data',              
                        '1000010011' => 'Status_Data',              
                        '1000010100' => 'Status_Data',
                        '1000010101' => 'Status_Data',
                        '1000010110' => 'Status_Data',
                        '1000010111' => 'Status_Data',
                        '1000011000' => 'Status_Data',
                        '1000011001' => 'Status_Data',
                        '1000011010' => 'Status_Data',
                        '1000011011' => 'Status_Data',
                        '1000011100' => 'Status_Data',
                        '1000011101' => 'Status_Data',
                        '1000011110' => 'Status_Data',
                        '1000011111' => 'Status_Data',
                        '0111111100' => 'Manchester_Error',			# error in receiver ASIC                      
                        '0111111000' => 'Parity_Error',				# error in receiver ASIC
                        '0111100100' => 'Sensor_Defect',
                        '0111110000' => 'Buffer_Empty',				# error in receiver ASIC
                        '0111101000' => 'Sensor_Busy',
                        '0111100111' => 'Sensor_Ready',
                        '0111100110' => 'Sensor_Ready_unlocked',
                        },

        'PAS5R_COMMAND' => {
                        '0000000000' => 'Sensor_Data',         
                        '1000000000' => 'Block_ID_1',
                        '1000000001' => 'Block_ID_2',
                        '1000000010' => 'Block_ID_3',             
                        '1000000011' => 'Block_ID_4',
                        '1000000100' => 'Block_ID_5',
                        '1000000101' => 'Block_ID_6',             
                        '1000000110' => 'Block_ID_7',             
                        '1000000111' => 'Block_ID_8',             
                        '1000001000' => 'Block_ID_9',               
                        '1000001001' => 'Block_ID_10',               
                        '1000001010' => 'Block_ID_11',              
                        '1000001011' => 'Block_ID_12',               
                        '1000001100' => 'Block_ID_13',               
                        '1000001101' => 'Block_ID_14',              
                        '1000001110' => 'Block_ID_15',               
                        '1000001111' => 'Block_ID_16',               
                        '1000010000' => 'Status_Data',               
                        '1000010001' => 'Status_Data',              
                        '1000010010' => 'Status_Data',              
                        '1000010011' => 'Status_Data',              
                        '1000010100' => 'Status_Data',
                        '1000010101' => 'Status_Data',
                        '1000010110' => 'Status_Data',
                        '1000010111' => 'Status_Data',
                        '1000011000' => 'Status_Data',
                        '1000011001' => 'Status_Data',
                        '1000011010' => 'Status_Data',
                        '1000011011' => 'Status_Data',
                        '1000011100' => 'Status_Data',
                        '1000011101' => 'Status_Data',
                        '1000011110' => 'Status_Data',
                        '1000011111' => 'Status_Data',
                        '0111111100' => 'Manchester_Error',			# error in receiver ASIC                      
                        '0111111000' => 'Parity_Error',				# error in receiver ASIC
                        '0111100100' => 'Sensor_Defect',
                        '0111110000' => 'Buffer_Empty',				# error in receiver ASIC
                        '0111101000' => 'Sensor_Busy',
                        '0111100111' => 'Sensor_Ready',
                        '0111100110' => 'Sensor_Ready_unlocked',    
                        '0111100101' => 'Sensor_Ready_unlocked_1',     
                        '0111100010' => 'Bidirec_Comm_Error',		# error in receiver ASIC    
                        '0111100001' => 'Bidirec_Comm_OK',			# error in receiver ASIC   
                        },

        'SMA560_COMMAND' => {
                        '1111000' => 'PRO_SEL',					# Protocol selection              
                        '0101110' => 'SEL_G_RANGE', 			# Write coarse gain             
                        '0000101' => 'RD_ACCEL_RANGE',			# Read Accel. Range (coarse gain)              
                        '0101000' => 'RD_OFFSET_CANCEL_I_CHA',	# Read Offset value, Channel A LSB [8:1]  
                        '0101001' => 'RD_OFFSET_CANCEL_II_CHA',	# Read Offset value, Channel A MSB [12:9] 
                        '0101010' => 'RD_OFFSET_CANCEL_I_CHB', 	# Read Offset value, Channel B LSB [8:1]
                        '0101011' => 'RD_OFFSET_CANCEL_II_CHB',	# Read Offset value, Channel B MSB [12:9]     
                        '0000000' => 'RD_DEVICE_ID',  			# Read device identifier
                        '0000011' => 'RD_REVISION_ID',			# Read revision identifier                
                        '0010001' => 'RD_MONITOR_I', 			# Read monitor data I reg        
                        '0010010' => 'RD_MONITOR_II', 			# Read monitor data II reg
                        '1000000' => 'RD_SENSOR_DATA_I',		# Read channel1 acceleration data
                        '1110000' => 'RD_SENSOR_DATA_II',		# Read channel2 acceleration data
                        '0101101' => 'PROG_SID',  				# Program Safety-ID    
                        '0011011' => 'RD_SID',					# Read Safety-ID              
                        '0111100' => 'DE_OFFSET_CANCEL',  		# Switch on/off offset cancellation ch.1/2   
                        '0111101' => 'RD_OFFSET_CANCEL',		# Read offset cancellation settings 
                        '0000010' => 'RD_CLK_CNT',				# Read internal clock counter        
                        '0110101' => 'DE_LINEAR_INTERPOL',		# Switch on/off linear interpolation      
                        '0000110' => 'END_OF_PROG',				# Interlock fast offset cancellation      
                        '0011100' => 'DE_FOR_TEST',				# Trigger built-in-test
                        '0001000' => 'PROG_FOR_TEST_0',			# Program safety-ID 0 threshold
                        '0001001' => 'PROG_FOR_TEST_1',			# Program safety-ID 1 threshold
                        '0001010' => 'PROG_FOR_TEST_2',			# Program safety-ID 2 threshold
                        '0001011' => 'PROG_FOR_TEST_3',			# Program safety-ID 3 threshold           
                        '0001100' => 'PROG_FOR_TEST_4',			# Program safety-ID 4 threshold         
                        '0001101' => 'PROG_FOR_TEST_5',			# Program safety-ID 5 threshold           
                        '0001110' => 'PROG_FOR_TEST_6',			# Program safety-ID 6 threshold         
                        '0001111' => 'PROG_FOR_TEST_7',			# Program safety-ID 7 threshold
                        '0100011' => 'PROG_ENH_SAFETY',			# Activate/Deactivate Parity bit (17 bit)           
                        '0100001' => 'WR_EXT_MODE',				# Switch on extended spi mode           
                        '0100010' => 'WR_EXT_TESTMODE1',		# Extra testmode part1 (FGC)       
                        '0100100' => 'WR_EXT_TESTMODE2',		# Extra testmode part2 (FGC)
                        },

        'SMA560P_COMMAND' => {
                        '1111000' => 'PRO_SEL',					# Protocol selection              
                        '0101110' => 'SEL_G_RANGE', 			# Write coarse gain             
                        '0000101' => 'RD_ACCEL_RANGE',			# Read Accel. Range (coarse gain)              
                        '0101000' => 'RD_OFFSET_CANCEL_I_CHA',	# Read Offset value, Channel A LSB [8:1]  
                        '0101001' => 'RD_OFFSET_CANCEL_II_CHA',	# Read Offset value, Channel A MSB [12:9] 
                        '0101010' => 'RD_OFFSET_CANCEL_I_CHB', 	# Read Offset value, Channel B LSB [8:1]
                        '0101011' => 'RD_OFFSET_CANCEL_II_CHB',	# Read Offset value, Channel B MSB [12:9]     
                        '0000000' => 'RD_DEVICE_ID',  			# Read device identifier
                        '0000011' => 'RD_REVISION_ID',			# Read revision identifier                
                        '0010001' => 'RD_MONITOR_I',	 		# Read monitor data I reg        
                        '0010010' => 'RD_MONITOR_II',	 		# Read monitor data II reg
                        '1000000' => 'RD_SENSOR_DATA_I',		# Read channel1 acceleration data
                        '1110000' => 'RD_SENSOR_DATA_II',		# Read channel2 acceleration data
                        '0101101' => 'PROG_SID',  				# Program Safety-ID    
                        '0011011' => 'RD_SID',					# Read Safety-ID              
                        '0111100' => 'DE_OFFSET_CANCEL',  		# Switch on/off offset cancellation ch.1/2   
                        '0111101' => 'RD_OFFSET_CANCEL',		# Read offset cancellation settings 
                        '0000010' => 'RD_CLK_CNT',				# Read internal clock counter        
                        '0110101' => 'DE_LINEAR_INTERPOL',		# Switch on/off linear interpolation      
                        '0000110' => 'END_OF_PROG',				# Interlock fast offset cancellation      
                        '0011100' => 'DE_FOR_TEST',				# Trigger built-in-test
                        '0001000' => 'PROG_FOR_TEST_0',			# Program safety-ID 0 threshold
                        '0001001' => 'PROG_FOR_TEST_1',			# Program safety-ID 1 threshold
                        '0001010' => 'PROG_FOR_TEST_2',			# Program safety-ID 2 threshold
                        '0001011' => 'PROG_FOR_TEST_3',			# Program safety-ID 3 threshold           
                        '0001100' => 'PROG_FOR_TEST_4',			# Program safety-ID 4 threshold         
                        '0001101' => 'PROG_FOR_TEST_5',			# Program safety-ID 5 threshold           
                        '0001110' => 'PROG_FOR_TEST_6',			# Program safety-ID 6 threshold         
                        '0001111' => 'PROG_FOR_TEST_7',			# Program safety-ID 7 threshold
                        '0100011' => 'PROG_ENH_SAFETY',			# Activate/Deactivate Parity bit (17 bit)           
                        '0100001' => 'WR_EXT_MODE',				# Switch on extended spi mode           
                        '0100010' => 'WR_EXT_TESTMODE1',		# Extra testmode part1 (FGC)       
                        '0100100' => 'WR_EXT_TESTMODE2',		# Extra testmode part2 (FGC)
                        },

        'SMG100_COMMAND' => {                      
                        '0000000' => 'RD_DEVICE_ID',			# Read Device Identifier
                        '0000011' => 'RD_REVISION_ID',			# Read Revision Identifier
                        '0101111' => 'RD_PART_ID_I',			# Read Part ID Bit 7..0
                        '0101110' => 'RD_PART_ID_II',			# Read Part ID Bit 15..8
                        '0101101' => 'RD_PART_ID_III',			# Read Part ID Bit 23..16
                        '0101100' => 'RD_PART_ID_IV',			# Read Part ID Bit 31..24
                        '0101011' => 'RD_PART_ID_V',			# Read Part ID Bit 39..32
                        '0101010' => 'RD_PART_ID_VI',			# Read Part ID Bit 47..40
                        '0011011' => 'RD_SID',					# Read Safety ID
                        '1000000' => 'RD_SENSOR_DATA',			# Read angular rate data (10 Bit)
                        '0111101' => 'RD_OFFSET_CANCEL',		# Read offset cancellation settings
                        '0011101' => 'RD_MONITOR_I',			# Read Monitor Register Bit 7..0
                        '0011110' => 'RD_MONITOR_II',			# Read Monitor Register Bit 15..8
                        '0011111' => 'RD_MONITOR_III',			# Read Monitor Register Bit 23..16
                        '0111100' => 'DE_OFFSET_CANCEL',		# Switch on/off offset controller
                        '0000110' => 'END_OF_PROG',				# Interlock fast offset controller
                        '0011100' => 'DE_FOR_TEST',				# BITE control
                        '0011001' => 'RD_BITE_CAL_VAL_I',		# Read stored BITE calibration value Bit 7..0
                        '0011010' => 'RD_BITE_CAL_VAL_II',		# Read stored BITE calibration value Bit 9..8
                        '0111000' => 'RD_OFFSET_VAL_I',			# Read current offset controller value Bit 7..0
                        '0111001' => 'RD_OFFSET_VAL_II',		# Read current offset controller value Bit 9..8
                        '0111010' => 'RD_SENSOR_CONFIG',		# Read Sensor Config
                        '0100101' => 'WR_SOFT_RESET',			# Perform a software triggered reset
                        '0100011' => 'WR_PARITY',				# Switches to 17. Bit Mode (Parity)
                        },
                        
        'SMB200_COMMAND' => {
                        '0000000' => 'RD_DEVICE_ID',			# Read Device Identifier
                        '0000011' => 'RD_REVISION_ID',			# Read Revision Identifier
                        '0000111' => 'RD_MONITOR_I',			# Read monitor data
                        '1000000' => 'RD_SENSOR_DATA_I',		# Read channel1 acceleration data
                        '1100000' => 'RD_SENSOR_DATA_II',		# Read channel2 acceleration data
                        '0111100' => 'DE_OFFSET_CANCEL',		# switch on/off offset cancellation ch.1/2
                        '0111101' => 'RD_OFFSET_CANCEL',		# read offset cancellation settings
                        '0000110' => 'END_OF_PROG',				# Interlock fast offset cancellation
                        '0011100' => 'DE_FOR_TEST',				# Trigger built-in-test
                        },
                        
		'SMB470_COMMAND' => {                      
                        '1111000' => 'PRO_SEL',					# Protocol selection              
         				'0000000' => 'RD_DEVICE_ID',			# Read Device Identifier
          				'0000011' => 'RD_REVISION_ID',			# Read Revision Identifier
          				'0000101' => 'RD_MONITOR_I',			# Read monitor data I reg
          				'0000110' => 'RD_MONITOR_II',			# Read monitor data II reg
          				'0001001' => 'RD_MONITOR_III',			# Read monitor data III reg
          				'1000000' => 'RD_SENSOR_DATA_I',		# Read channel1 acceleration data
          				'1110000' => 'RD_SENSOR_DATA_II',		# Read channel1 acceleration data
          				'0101000' => 'PROG_SID',				# Program Safety-ID
          				'0001010' => 'RD_SID',					# Read Safety-ID
          				'0111010' => 'DE_OFFSET_CANCEL',		# Switch on/off offset cancellation ch.1/2
         				'0001111' => 'RD_OFFSET_CANCEL',		# Read offset cancellation settings
          				'0111001' => 'DE_LINEAR_INTERPOL',		# Switch on/off linear interpolation
          				'0111111' => 'END_OF_PROG', 			# Interlock fast offset cancellation
          				'0110000' => 'DE_FOR_TEST',				# Trigger built-in-test
          				'0110110' => 'DE_SOFTRESET',			# Perform a software triggered reset
          				'0010001' => 'RD_PART_ID_I',			# Read Part ID Bit 7..0
          				'0010010' => 'RD_PART_ID_II',			# Read Part ID Bit 15..8
          				'0010100' => 'RD_PART_ID_III',			# Read Part ID Bit 23..16
          				'0010111' => 'RD_PART_ID_IV',			# Read Part ID Bit 31..24
          				'0011000' => 'RD_PART_ID_V',			# Read Part ID Bit 39..32
          				'0011011' => 'RD_PART_ID_VI',			# Read Part ID Bit 47..40
          				'0100001' => 'WR_EXT_MODE', 			# Switch to extended spi mode    
          				'0100010' => 'WR_EXT_TESTMODE1',		# Extended testmode part1 (FGC)
          				'0100100' => 'WR_EXT_TESTMODE2',		# Extended testmode part2 (FGC)
						'0101011' => 'PROG_FILT_SETTINGS',		# Select cut-off-frequency of the band pass filter
						'0001100' => 'RD_FILT_SETTINGS',		# Read cut-off-frequency of the band pass filter
          				'0011101' => 'RD_ECLK_CNT',				# Read eclk counter
          				'0101110' => 'RD_NOISE_OFFSET',			# Read noise offset of bss channel
          				'0100111' => 'RD_TEMP',					# Read temperature
          				'0110011' => 'RD_SELF_TEST_REF1',		# Read reference data measured during final Self-Test
          				'0110100' => 'RD_SELF_TEST_REF2',		# Read reference data measured during final Self-Test
          				},

        'AB+_COMMAND' => {
                        '00000' => 'DATA_CAPTURE',
                        '00001' => 'TRG_POS_TEST',
                        '00010' => 'TRG_NEG_TEST',
                        '00011' => 'TRG_ZERO_TEST',
                        '11111' => 'TRG_RESET',
                        '11101' => 'TRG_CONFIRM',
                        '11100' => 'WR_START',
                        '10010' => 'RD_DATA',
                        '10000' => 'RD_STATUS',
                        '01001' => 'RD_INT_DATA',
                        '01010' => 'WR_INT_DATA',
                        '01101' => 'RD_INT_48',
                        '01110' => 'WR_INT_48',
                        },

        'CG103_COMMAND' => {
                        '0000000' => 'READ_DEV_ID',
                        '0000011' => 'READ_REV_ID',
                        '0000001' => 'READ_MON_ID',
                        '0000100' => 'WD2_TRIGGER',
                        '0000101' => 'WD3_TRIGGER',
                        '0000010' => 'READ_WD_STATUS',
                        '0000111' => 'READ_WD_FC',
                        '0000110' => 'EOP',
                        '0001000' => 'PAS_SUPPLY',
                        '0001001' => 'FLM_STATUS',
                        '0001010' => 'END_ENABLE',
                        '0001011' => 'SET_I_AIO',
                        '0001100' => 'READ_THRES',
                        '0001101' => 'SET_I_LIN',
                        '0001110' => 'START_ADC',
                        '0001111' => 'READ_ADC',
                        '0010000' => 'TEST_ANA_HEAD',
                        '0010001' => 'POWER_CTRL',
                        '0010010' => 'POWER_STATUS',
                        '0010011' => 'AOUT_CTRL',
                        '0010100' => 'HS_ON1_4',
                        '0010101' => 'HS_ON5_8',
                        '0010110' => 'HS_ON9_12',
                        '0010111' => 'FLM_TEST_SRC',
                        '0011000' => 'LS_ON1_4',
                        '0011001' => 'LS_ON5_8',
                        '0011010' => 'LS_ON9_12',
                        '0011011' => 'FLM_TEST_SINK',
                        '0011101' => 'FLM_LOCK',
                        '0011110' => 'FLM_LOWLEAK',
                        '0011111' => 'FIRE_COUNTER',
                        '1000000' => 'READ_PAS',
                        '0111100' => 'SELECT_PAS',
                        '0111110' => 'DISPOSAL',
                        '0100000' => 'PROG_GENERAL',
                        '0100001' => 'PROG_UP_THRES',
                        '0100010' => 'PROG_LOW_THRES',
                        '0100011' => 'PROG_AIN1_2',
                        '0100100' => 'PROG_AIN3_4',
                        '0100101' => 'PROG_AIN5_6',
                        '0100110' => 'PROG_AIO_WL',
                        '0100111' => 'PROG_PAS1_CONF',
                        '0101000' => 'PROG_PAS2_CONF',
                        '0101001' => 'PROG_PAS3_CONF',
                        '0101010' => 'PROG_PAS4_CONF',
                        '0101011' => 'PROG_UFS_THRES',
                        '0101100' => 'PROG_PAS_THRES',
                        '0101101' => 'PROG_PRES_THRES',
                        '0101110' => 'PROG_ROLL_THRES',
                        '0101111' => 'PROG_X_THRES',
                        '0110000' => 'PROG_Y_THRES',
                        '0110001' => 'PROG_POWER',
                        '0110010' => 'PROG_INTERPOL',
                        '0110011' => 'PROG_SDIS1_4',
                        '0110100' => 'PROG_SDIS5_8',
                        '0110101' => 'PROG_SDIS9_12',
                        '0110110' => 'PROG_DISXY1_4',
                        '0110111' => 'PROG_DISXY5_8',
                        '0111000' => 'PROG_DISXY9_12',
                        '0111001' => 'PROG_FLM_CONF',
                        '1100001' => 'VER_GENERAL',
                        '1100010' => 'VER_UP_THRES',
                        '1100011' => 'VER_LOW_THRES',
                        '1100100' => 'VER_AIN1_2',
                        '1100101' => 'VER_AIN3_4',
                        '1100110' => 'VER_AIN5_6',
                        '1100111' => 'VER_AIO_WL',
                        '1101001' => 'VER_PAS1_CONF',
                        '1101010' => 'VER_PAS2_CONF',
                        '1101011' => 'VER_PAS3_CONF',
                        '1101100' => 'VER_PAS4_CONF',
                        '1101101' => 'VER_UFS_THRES',
                        '1101110' => 'VER_PAS_THRES',
                        '1101111' => 'VER_PRESS_THRES',
                        '1110001' => 'VER_ROLL_THRES',
                        '1110010' => 'VER_X_THRES',
                        '1110011' => 'VER_Y_THRES',
                        '1110100' => 'VER_POWER',
                        '1110101' => 'VER_INTERPOL',
                        '1110110' => 'VER_SDIS1_4',
                        '1110111' => 'VER_SDIS5_8',
                        '1111001' => 'VER_SDIS9_12',
                        '1111010' => 'VER_DISXY1_4',
                        '1111011' => 'VER_DISXY5_8',
                        '1111100' => 'VER_DISXY9_12',
                        '1111101' => 'VER_FLM_CONF',                     
                        },

        'CG143_COMMAND' => {
                        '0000000' => 'READ_DEV_ID',     #
                        '0000011' => 'READ_REV_ID',     #
                       #'0000001' => 'READ_MON_ID',     #+CG103
                       #'0000100' => 'WD2_TRIGGER',     #+CG103
                       #'0000101' => 'WD3_TRIGGER',     #+CG103
                        '0000010' => 'READ_WD_STATUS',  #
                       #'0000111' => 'READ_WD_FC',      #+CG103
                        '0000110' => 'EOP',             #
                        '0001000' => 'PAS_SUPPLY',      #
                        '0001001' => 'FLM_STATUS',      #
                        '0001010' => 'END_ENABLE',      #
                        '0001011' => 'SET_I_AIO',       #
                       #'0001100' => 'READ_THRES',      #+CG103
                        '0001101' => 'SET_I_LIN',       #
                        '0001110' => 'START_ADC',       #
                        '0001111' => 'READ_ADC',        #
                        '0010000' => 'TEST_ANA_HEAD',   #
                        '0010001' => 'POWER_CTRL',      #
                        '0010010' => 'POWER_STATUS',    #
                        '0010011' => 'AOUT_CTRL',       #
                        '0010100' => 'HS_ON1_4',        #
                        '0010101' => 'HS_ON5_8',        #
                        '0010110' => 'HS_ON9_12',       #
                        '0010111' => 'FLM_TEST_SRC',    #
                        '0011000' => 'LS_ON1_4',        #
                        '0011001' => 'LS_ON5_8',        #
                        '0011010' => 'LS_ON9_12',       #
                        '0011011' => 'FLM_TEST_SINK',   #
                        '0011101' => 'FLM_LOCK',        #
                        '0011110' => 'FLM_LOWLEAK',     #
                        '0011111' => 'FIRE_COUNTER',    #
                        '1000000' => 'READ_PAS',        #
                        '0111100' => 'SELECT_PAS',      #
                        '0111110' => 'DISPOSAL',        #                   
                        '0100000' => 'PROG_GENERAL',    #
                        '0100001' => 'PROG_UP_THRES',   #
                        '0100010' => 'PROG_LOW_THRES',  #
                        '0100011' => 'PROG_AIN1_2',     #
                        '0100100' => 'PROG_AIN3_4',     #
                        '0100101' => 'PROG_AIN5_6',     #
                        '0100110' => 'PROG_AIO_WL',     #
                        '0100111' => 'PROG_PAS1_CONF',  #
                        '0101000' => 'PROG_PAS2_CONF',  #
                        '0101001' => 'PROG_PAS3_CONF',  #
                        '0101010' => 'PROG_PAS4_CONF',  #                       
                        '0101011' => 'PROG_PAS5_CONF',  #-CG103
                        '0101100' => 'PROG_PAS6_CONF',  #-CG103
                       #'0101011' => 'PROG_UFS_THRES',  #+CG103 
                       #'0101100' => 'PROG_PAS_THRES'   #+CG103
                       #'0101101' => 'PROG_PRES_THRES', #+CG103
                       #'0101110' => 'PROG_ROLL_THRES', #+CG103
                       #'0101111' => 'PROG_X_THRES',    #+CG103
                       #'0110000' => 'PROG_Y_THRES',    #+CG103
                        '0110001' => 'PROG_POWER',      #
                        '0110010' => 'PROG_INTERPOL',   #
                        '0110011' => 'PROG_SDIS1_4',    #
                        '0110100' => 'PROG_SDIS5_8',    #
                        '0110101' => 'PROG_SDIS9_12',   #
                        '0110110' => 'PROG_DISXY1_4',   #
                        '0110111' => 'PROG_DISXY5_8',   #
                        '0111000' => 'PROG_DISXY9_12',  #
                        '0111001' => 'PROG_FLM_CONF',   #                      
                        '1100001' => 'VER_GENERAL',     #
                        '1100010' => 'VER_UP_THRES',    #
                        '1100011' => 'VER_LOW_THRES',   #
                        '1100100' => 'VER_AIN1_2',      #
                        '1100101' => 'VER_AIN3_4',      #
                        '1100110' => 'VER_AIN5_6',      #
                        '1100111' => 'VER_AIO_WL',      #
                        '1101001' => 'VER_PAS1_CONF',   #
                        '1101010' => 'VER_PAS2_CONF',   #
                        '1101011' => 'VER_PAS3_CONF',   #
                        '1101100' => 'VER_PAS4_CONF',   #
                        '1101101' => 'VER_PAS5_CONF',   #-CG103
                        '1101110' => 'VER_PAS6_CONF',   #-CG103
                       #'1101101' => 'VER_UFS_THRES',   #+CG103   
                       #'1101110' => 'VER_PAS_THRES',   #+CG103
                       #'1101111' => 'VER_PRESS_THRES', #+CG103
                       #'1110001' => 'VER_ROLL_THRES',  #+CG103
                       #'1110010' => 'VER_X_THRES',     #+CG103
                       #'1110011' => 'VER_Y_THRES',     #+CG103
                        '1110100' => 'VER_POWER',       #
                        '1110101' => 'VER_INTERPOL',    #
                        '1110110' => 'VER_SDIS1_4',     #
                        '1110111' => 'VER_SDIS5_8',     #
                        '1111001' => 'VER_SDIS9_12',    #
                        '1111010' => 'VER_DISXY1_4',    #
                        '1111011' => 'VER_DISXY5_8',    #
                        '1111100' => 'VER_DISXY9_12',   #
                        '1111101' => 'VER_FLM_CONF',    #                     
                        },
                        
        'CG147_COMMAND' => {
                        '0000000' => 'READ_DEV_ID',     #
                        '0000011' => 'READ_REV_ID',     #
                        '0000001' => 'READ_MON_ID',     #
                        '0000100' => 'WD2_TRIGGER',     #
                        '0000101' => 'WD3_TRIGGER',     #
                        '0000010' => 'READ_WD_STATUS',  #
                        '0000111' => 'READ_WD_FC',      #
                        '0000110' => 'EOP',             #
                        '0001000' => 'PSI_SUPPLY',      #
                        '0001001' => 'FLM_STATUS',      #
                        '0001010' => 'END_ENABLE',      #
                        '0001011' => 'SET_I_AIO',       #
                        '0001100' => 'READ_THRES',      # 
                        '0001101' => 'SET_I_LIN',       #
                        '0001110' => 'START_ADC',       #
                        '0001111' => 'READ_ADC',        #
                        '0010000' => 'TEST_ANA_HEAD',   #
                        '0010001' => 'POWER_CTRL',      #
                        '0010010' => 'POWER_STATUS',    #
                        '0010011' => 'AOUT_CTRL',       #
                        '0010100' => 'HS_ON1_4',        #
                        '0010101' => 'HS_ON5_8',        #
                        '0010110' => 'HS_ON9_12',       #
                        '0010111' => 'FLM_TEST_SRC',    #
                        '0011000' => 'LS_ON1_4',        #
                        '0011001' => 'LS_ON5_8',        #
                        '0011010' => 'LS_ON9_12',       #
                        '0011011' => 'FLM_TEST_SINK',   #
                        '0011101' => 'FLM_LOCK',        #
                        '0011110' => 'FLM_LOWLEAK',     #
                        '0011111' => 'FIRE_COUNTER',    #
                        '1000000' => 'READ_PSI',        #
                        '1100001' => 'SELECT_PSI',      #**
                        '1100010' => 'DISPOSAL',        #**
                        '1111111' => 'SET_AIO_PWM',     #-CG103
                        '0011100' => 'DEMAND_TEST',     #-CG103     
                        '1100100' => 'THRES_TEST_DATA', #-CG103
                        '1100101' => 'THRES_TEST_SID',  #-CG103
                        '1100110' => 'ENABLE_PROG',     #-CG103
                        '1100111' => 'SET_MM5_MODE',    #-CG103
                        '1111001' => 'PSI_SYNC_GEN',    #-CG103
                        '1111010' => 'PSI_SYNC_MASK',   #-CG103
                        '1111100' => 'AIO_STATUS',      #-CG103
                        '1101101' => 'SET_PSI_IPP',     #-CG103
                        '1101001' => 'READ_PSI_IPP',    #-CG103
                        '1101010' => 'PSI_IQ_STATUS',   #-CG103
                        '1101011' => 'CLEAR_FIRE_CNT',  #-CG103
                        '1101100' => 'SID_EVALUATE',    #-CG103
                        '1101110' => 'TEST_PSI_CONS',   #-CG103
                        '0100000' => 'PROG_GENERAL',    #
                        '0100001' => 'PROG_UP_THRES',   #
                        '0100010' => 'PROG_LOW_THRES',  # 
                        '0100100' => 'PROG_AIN1_2',     #**
                        '0100101' => 'PROG_AIN3_4',     #**
                        '0100110' => 'PROG_AIN5_6',     #**
                        '0111100' => 'PROG_AIO_WL',     #**
                        '0100111' => 'PROG_PSI1_LINE',  #
                        '0101000' => 'PROG_PSI2_LINE',  # 
                        '0101001' => 'PROG_PSI3_LINE',  # 
                        '0101010' => 'PROG_PSI4_LINE',  # 
                        '0101011' => 'PROG_UFS_THRES',  # 
                        '0101100' => 'PROG_PAS_THRES',  # 
                        '0101101' => 'PROG_PRES_THRES', # 
                        '0101110' => 'PROG_ROLL_THRES', # 
                        '0101111' => 'PROG_X_THRES',    #
                        '0110000' => 'PROG_Y_THRES',    #
                        '0110001' => 'PROG_POWER',      #
                        '0110010' => 'PROG_FLM_ENH',    #-CG103    
                        '0110011' => 'PROG_SDIS1_4',    #
                        '0110100' => 'PROG_SDIS5_8',    #
                        '0110101' => 'PROG_SDIS9_12',   #
                        '0110110' => 'PROG_DISXY1_4',   #
                        '0110111' => 'PROG_DISXY5_8',   #
                        '0111000' => 'PROG_DISXY9_12',  #
                        '0111001' => 'PROG_FLM_CONF',   #
                        '0111010' => 'PROG_PSYNC_MODE', #-CG103  
                        '0111101' => 'PROG_SDIS_CH',    #-CG103 
                        '0111011' => 'PROG_PSI_SID',    #-CG103 
                        '0111111' => 'PROG_MM5_SID',    #-CG103 
                        '0100011' => 'PROG_ENH_SAFETY', #-CG103 
                        },

        'CG147S_COMMAND' => {
                        '0000000' => 'READ_DEV_ID',
                        '0000011' => 'READ_REV_ID',
                        '0000001' => 'READ_MON_ID',
                        '0000100' => 'WD2_TRIGGER',
                        '0000101' => 'WD3_TRIGGER',
                        '0000010' => 'READ_WD_STATUS',
                        '0000111' => 'READ_WD_FC',
                        '0000110' => 'EOP',
                        '0001000' => 'PSI_SUPPLY',
                        '0001001' => 'FLM_STATUS',
                        '0001010' => 'END_ENABLE',
                        '0001011' => 'SET_I_AIO',
                        '0001100' => 'READ_THRES', 
                        '0001101' => 'SET_I_LIN',
                        '0001110' => 'START_ADC',
                        '0001111' => 'READ_ADC',
                        '0010000' => 'TEST_ANA_HEAD',
                        '0010001' => 'POWER_CTRL',
                        '0010010' => 'POWER_STATUS',
                        '0010011' => 'AOUT_CTRL',
                        '0010100' => 'HS_ON1_4',
                        '0010101' => 'HS_ON5_8',
                        '0010110' => 'HS_ON9_12',
                        '0010111' => 'FLM_TEST_SRC',
                        '0011000' => 'LS_ON1_4',
                        '0011001' => 'LS_ON5_8',
                        '0011010' => 'LS_ON9_12',
                        '0011011' => 'FLM_TEST_SINK',
                        '0011101' => 'FLM_LOCK',
                        '0011110' => 'FLM_LOWLEAK',
                        '0011111' => 'FIRE_COUNTER',
                        '1000000' => 'READ_PSI',
                        '1100001' => 'SELECT_PSI',
                        '1100010' => 'DISPOSAL',
                        '1111111' => 'SET_AIO_PWM',
                        '0011100' => 'DEMAND_TEST',
                        '1100100' => 'THRES_TEST_DATA',
                        '1100101' => 'THRES_TEST_SID',
                        '1100110' => 'ENABLE_PROG',
                        '1100111' => 'SET_MM5_MODE',
                        '1111001' => 'PSI_SYNC_GEN',
                        '1111010' => 'PSI_SYNC_MASK',
                        '1111100' => 'AIO_STATUS',
                        '1101101' => 'SET_PSI_IPP',
                        '1101001' => 'READ_PSI_IPP',
                        '1101010' => 'PSI_IQ_STATUS',
                        '1101011' => 'CLEAR_FIRE_CNT',
                        '1101100' => 'SID_EVALUATE',
                        '1101110' => 'TEST_PSI_CONS',
                        '0100000' => 'PROG_GENERAL',
                        '0100001' => 'PROG_UP_THRES',
                        '0100010' => 'PROG_LOW_THRES', 
                        '0100100' => 'PROG_AIN1_2',
                        '0100101' => 'PROG_AIN3_4',
                        '0100110' => 'PROG_AIN5_6',
                        '0111100' => 'PROG_AIO_WL',
                        '0100111' => 'PROG_PSI1_LINE', 
                        '0101000' => 'PROG_PSI2_LINE', 
                        '0101001' => 'PROG_PSI3_LINE', 
                        '0101010' => 'PROG_PSI4_LINE', 
                        '0101011' => 'PROG_UFS_THRES', 
                        '0101100' => 'PROG_PAS_THRES', 
                        '0101101' => 'PROG_PRES_THRES', 
                        '0101110' => 'PROG_ROLL_THRES', 
                        '0101111' => 'PROG_X_THRES',
                        '0110000' => 'PROG_Y_THRES',
                        '0110001' => 'PROG_POWER',
                        '0110010' => 'PROG_FLM_ENH',
                        '0110011' => 'PROG_SDIS1_4',
                        '0110100' => 'PROG_SDIS5_8',
                        '0110101' => 'PROG_SDIS9_12',
                        '0110110' => 'PROG_DISXY1_4',
                        '0110111' => 'PROG_DISXY5_8',
                        '0111000' => 'PROG_DISXY9_12',
                        '0111001' => 'PROG_FLM_CONF',
                        '0111010' => 'PROG_PSYNC_MODE', 
                        '0111101' => 'PROG_SDIS_CH', 
                        '0111011' => 'PROG_PSI_SID', 
                        '0111111' => 'PROG_MM5_SID', 
                        '0100011' => 'PROG_ENH_SAFETY', 
                        },

        'CF190_COMMAND' => {
                        '0000000' => 'READ_DEV_ID',
                        '0000011' => 'READ_REV_ID',
                        '0000110' => 'EOP',
                        '0001000' => 'READ_PSI_SUPPLY',
                        '0001001' => 'WRITE_PSI_SUPPLY',
                        '0001010' => 'READ_SYNC_DELAY',
                        '0001011' => 'WRITE_SYNC_DELAY',
                        '0001110' => 'READ_DOUT1',
                        '0001111' => 'WRITE_DOUT1',
                        '0010010' => 'READ_AOUT',
                        '0010011' => 'WRITE_AOUT',
                        '0010100' => 'WRITE_SYNC_TIME',
                        '0011000' => 'READ_SYNC_TIME',
                        '0100000' => 'SEND_BIDIRECT',
                        '0100010' => 'READ_SPI_PARITY',
                        '0100011' => 'PROG_SPI_PARITY',
                        '0100100' => 'READ_BIDIRECT',                        
                        '0101000' => 'READ_PSI_MODE_L1',
                        '0101001' => 'READ_PSI_MODE_L2',
                        '0101100' => 'PROG_PSI_MODE_L1',
                        '0101101' => 'PROG_PSI_MODE_L2',                        
                        '0110000' => 'READ_DIA1',
                        '0110001' => 'READ_DIA2',
                        '0110100' => 'READ_CURRENT',
                        '0110110' => 'READ_CONFIG',
                        '0110111' => 'PROG_CONFIG',
                        '0111000' => 'READ_SYNC_MODE',
                        '0111001' => 'PROG_SYNC_MODE',
                        '0111010' => 'READ_PSI_SID',
                        '0111011' => 'PROG_PSI_SID',
                        '0111100' => 'READ_PSI_IPP',
                        '0111101' => 'WRITE_PSI_IPP',
                        '1000000' => 'READ_PSI',
                        '1100001' => 'SELECT_PSI',
                        '1101000' => 'THRES_TEST_DATA',
                        '1101100' => 'THRES_TEST_SID',
                        '1111000' => 'PRO_SEL',
                        '1111010' => 'READ_SYNC_MASK',
                        '1111011' => 'WRITE_SYNC_MASK',
                        '1111100' => 'PSI_SYNC_GEN',
                        '1111101' => 'PSI_SYNC_GEN_DELAY',
                        },				
	
}, #close AB10

}, #close Mapping	
1;								