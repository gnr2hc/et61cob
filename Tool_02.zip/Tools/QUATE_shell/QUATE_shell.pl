#! /usr/bin/perl -w
# *****************************************************************************************************
#
#  Copyright (c) 2015  Robert Bosch GmBH
#                      All rights reserved
#
#******************************************************************************************************
#    $Source: QUATE_shell/QUATE_shell.pl $
#    $Revision: 2.4 $
#    $Author: ASR2COB $
#    $State: develop $
#    $Date: 2015/02/17 12:56:33ICT $
#******************************************************************************************************

=head1 NAME

QUATE_shell - Perl shell for QuaTe

=head1 SYNOPSIS

just start the shell by doubleclick

    ->run abplus_config.txt
    ->qt_GetParameter(0, 0, 0, "ERROR")
    ->qt_SetParameter(0, 0, 0, "ERROR",[0,0])
    ->pause
    ->qt_SetParameter(0, 0, 0, "ERROR",[256,0])
    ->wait 2000
    ->quit


=head1 DESCRIPTION

perl shell for QuaTe, will automatically connect to the DLL (InitDLL and FreeDLL is not needed to be called).

all commands entered will be logged in QuaTe_shell_log.txt. You can create own shell scripts using parts from the logfile and re-run them using the run command.
Calling nested scripts is not implemented. You have to do the errorhandling on your own (first return value < 0 means error, use GetErrorString for more information)

B<NOTE: do not run shell in parallel to another QuaTe application e.g. LIFT !>

you will find some example shell scripts in the QUATE_shell folder

=head2 any QuaTe command

any of the low level commands from QUATE.pm will be executed. See QUATE.dll docu for commands and return values.

=for html
<a href='..\..\..\Engine\Documentation\html\modules\QUATE\QUATE.html' target="blank">link to QUATE.pm docu</a><br>
<a href="file://siz1130/aerse$/AB_Sensoren/80_Tools/10.QuaTe/30.DLL/E.Documentation" target="blank">link to QUATE.dll docu folder</a>

=head2 run

    ->run $filename
    e.g. ->run test.txt         ( or optional: call execute )

run a shell script, all lines in this file starting with '->' will be executed as shell command, others will be ignored


=head2 help

    ->help

show small help with list of commands


=head2 pause

    ->pause             ( or optional: sleep )

wait for key pressed, useful for shell scripts


=head2 quit

    ->quit          ( or optional: exit end stop close )

exit shell


=head2 wait

    ->wait $milliseconds
    e.g. ->wait 2000

wait for $milliseconds, useful for shell scripts


=head1 AUTHOR

Frank B�hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl, QUATE, Quate documentation

=cut

#################################################################################
use strict;
use warnings;

# this tool is under version management
my $VERSION = q$Revision: 2.4 $;
my $HEADER  = q$Header: QUATE_shell/QUATE_shell.pl 2.4 2015/02/17 12:56:33ICT ASR2COB develop  $;
#################################################################################

use File::Basename;

BEGIN
{
    use Config;
    use File::Spec;

    my $addpath = File::Spec->rel2abs( dirname(__FILE__) ) . "/../Engine/modules/DLLs/QUATE";
    $addpath =~ s/\//\\/g;    # replace all slashes with backslahes

    # append Engine "modules" folder path to @INC
    my $modulesFolder = File::Spec->rel2abs( dirname(__FILE__) ) . "/../Engine/modules/";
    unshift @INC, ($modulesFolder);

    my $perl56 = $addpath . "\\Perl56";    #perl 5.6(32-bit) DLL directory
    my $win32  = $addpath . "\\Win32";     #perl 5.12, 32-bit DLL directory
    my $win64  = $addpath . "\\Win64";     #perl 5.12, 64-bit DLL directory

    if ( $] =~ m/5.006/i )
    {                                      #if Perl version is 5.6
        unshift @INC, ( $addpath, $perl56 );    #Include QUATE.pm from Root directory, Load QUATE.dll from "Perl56"
        $ENV{PATH} = $win32 . ";$ENV{PATH}";    #Load QuaTe_XX.dll from "Win32"

    }
    elsif ( $] =~ m/5.012/i )
    {                                           #if Perl version is 5.12
        if ( $Config{'archname'} =~ m/x64/i )
        {                                       #check the bitness of perl (32-bit or 64-bit)
            unshift @INC, ( $addpath, $win64 );    #Include QUATE.pm from Root directory, Load QUATE.dll from "Win64"
            $ENV{PATH} = $win64 . ";$ENV{PATH}";   #Load QuaTe_XX.dll from "Win64"
        }
        else
        {
            unshift @INC, ( $addpath, $win32 );    #Include QUATE.pm from Root directory, Load QUATE.dll from "Win32"
            $ENV{PATH} = $win32 . ";$ENV{PATH}";   #Load QuaTe_XX.dll from "Win32"
        }
    }
}

use QUATE;
my ( $status, $DLLversion, $input );

open( LOG, ">QuaTe_shell_log.txt" );               # open shell logfile

$status = qt_InitDLL();
w2log("$status:InitDLL\n");
( $status, $DLLversion ) = qt_GetDLLVersion();
w2log("$status:DLLversion = $DLLversion\n\n");

w2log(" QuaTe shell $VERSION, try help for details\n\n->");

while ( $input = <STDIN> )
{
    print LOG "$input";
    last if ( $input =~ /^(exit|quit|end|stop|close)\s*$/i );
    run_command($input);
}

$status = qt_FreeDLL();
w2log("\n$status:FreeDLL\n");

w2log("\nQuaTsh stopped :o)\n\n");

close(LOG);
system('pause');

################
#  subroutines
################

sub run_command
{
    my $inputcommand = shift;
    chomp($inputcommand);    # cut off newline

    if ( $inputcommand =~ /^(run|call|execute) (.+)/i ) { w2log("\nrunning file '$2'\n\n->"); run_file($2); }
    elsif ( $inputcommand =~ /^(wait|sleep) (.+)/i ) { wait_ms($2); }
    elsif ( $inputcommand =~ /^help/i )              { w2log("  available commands:\n  help, run, wait, pause, quit\n  and all QuaTe functions listed in html help\n->"); }
    elsif ( $inputcommand =~ /^pause/i )             { system('pause'); w2log("\n->"); }
    else
    {
        # execute $input as perl copmmand and get return values
        my @result = eval($inputcommand);

        # if there is an execution error, print the error message and wait for next command
        if ($@)
        {
            w2log("\n? execution error:\n\n $@");
        }
        else
        {
            my ( $val, $refval );

            #check if at least one return value was there
            w2log("\n");
            if ( defined( $result[0] ) )
            {
                # print the possible Quate error string
                if($result[0] < 0) {
                    my $errroString = qt_GetErrorString($result[0]);
                    w2log("QuaTe low level API error : $errroString\n\n");
                }
                
                foreach my $val (@result)
                {
                    # check for array reference and print values inside square brackets
                    if ( ref($val) eq "ARRAY" )
                    {
                        w2log("[ ");
                        foreach my $refval ( @{$val} )
                        {
                            w2log("$refval ");
                        }
                        w2log("] ");
                    }

                    # else print normal value
                    else { w2log("$val "); }
                }
                w2log("\n");
            }
            else { w2log("? unknown command: $inputcommand\n"); }
        }
        w2log("\n->");
    }
    return;
}

sub run_file
{
    my $file = shift;
    my $line;
    if ( open( IN, "<$file" ) )
    {
        while ( $line = <IN> )
        {
            if ( $line =~ /^->(.+)/ ) { w2log( $1 . "\n" ); run_command($1); }
        }
        close(IN);
    }
    else
    {
        w2log("unable to access the file $file . check if the file exists and readable. \n");
    }
    return;
}

sub w2log
{
    my $text = shift;
    print LOG "$text";
    print "$text";
    return;
}

sub wait_ms
{
    my $time = shift;
    w2log("sleeping for $time milliseconds");
    if ( $time > 0 ) { $time = $time / 1000; }
    select( undef, undef, undef, $time );    #sleep for X ms
    w2log("\n->");
    return;
}
