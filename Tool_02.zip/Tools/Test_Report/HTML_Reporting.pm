# *****************************************************************************************************
#                                                                                                      
#  Copyright (c) 2015  Robert Bosch GmBH                                                               
#                      Germany                                                                         
#                      All rights reserved                                                             
#                                                                                                      
#******************************************************************************************************
#    $Revision: 1.3 $
#    $Author: vgr3kor $
#    $Date: 2015/05/04 16:32:55ICT $
#******************************************************************************************************

# :::::::::::::::::::::::::::::::::::::::::::::::: #
# :::::::::::::::::::::::::::::::::::::::::::::::: #
# :::                                          ::: #
# ::: this file is only used for documentation ::: #
# :::                                          ::: #
# :::::::::::::::::::::::::::::::::::::::::::::::: #
# :::::::::::::::::::::::::::::::::::::::::::::::: #

=for html
<font color="Maroon" size = "8">HTML Report Filtering</font>

=head2 Introduction

=for html
<font color="blue">
Feature introduced in new HTML report is filtering which consists of filters
<ul>
<li>TYPE (Table, Graphics, Text, Time)</li>
<li>LOGLEVEL(0 to 5, w2rep, teststep and user defined)</li>
<li>LIBRARY (testcase and module names)</li>
</ul>
LIFT report also supports old reporting format.<br/>
To achieve this filtering option we have to do settings in project constant file in section <font color="green">'REPORTING'</font>.
<br/><br/>
<IMG SRC='..\..\pics\Test_Report\1.png' alt="REPORTING" border="1" />
</font>

=head3 Selection of Old and New Report Formats

=for html
<IMG SRC='..\..\pics\Test_Report\2.png' alt="REPORTING" border="1" />
<br/>
<font color="blue">
a.	The user can select the format of reporting structure by <font color="green"><I>enabling (1)/disabling (0)</I><B>'HTML_FILTER_USE'</B></font> variable.<br/>
b.	If <font color="green">'HTML_FILTER_USE'</font> variable is not defined then old reporting format generates for test execution<br/>
</font>
<br/>
<I><font color="black">Any of below settings generates the Old Format</font></I><br/><br/>
<font color="#aa33ff"><U>#Defining the variable to zero</U></font><br/><br/>
<IMG SRC='..\..\pics\Test_Report\3.png' alt="REPORTING" border="1" />
<br/><br/>
<font color="#aa33ff"><U>#Not defining the variable</U></font><br/><br/>
<IMG SRC='..\..\pics\Test_Report\3_comment.png' alt="REPORTING" border="1" />
<br/><br/>
<I><font color="#330000">Below settings generates the New Format</font></I><br/><br/>
<font color="#aa33ff"><U>#Defining the variable to one</U></font><br/><br/>
<IMG SRC='..\..\pics\Test_Report\2.png' alt="REPORTING" border="1" />

=head3 Old Report Format

=for html
<font color="blue">
1.	In this structure user can filter the loglevels from 0 to 5<br/>
2.	In this structure, all log information is available in HTML report, _main_log.txt <I>(except w2rep information)</I> and console
</font>
<br/><br/>
<IMG SRC='..\..\pics\Test_Report\old_report.png' alt="REPORTING" border="1" />

=head3 New Report Format

=for html
<font color="blue">
The below points works only if  <font color="green">'HTML_FILTER_USE' => 1</font></font>

=head4 Log level filtering

=for html
<font color = "blue">
a.	In new report filtering possible for customized loglevels i.e. user can define his own loglevels based on project requirement
<br/><br/>
<IMG SRC='..\..\pics\Test_Report\loglevels.png' alt="REPORTING" border="1" />
<br/><br/>
b.	If user doesn't want to define the loglevels structure then default loglevels information is considered which contains loglevels 0 to 5, w2rep and teststep.
<br/><br/>
<IMG SRC='..\..\pics\Test_Report\loglevel_default.png' alt="REPORTING" border="1" />
<br/><br/>
c.	In new format, user can do customization to define his own style where level log statements has to be printed<br/>
<font color="red">'TEXT' => 1, 'HTML' => 1, 'CONSOLE' => 1</font><br/>
<font color="#aa33ff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Here<br/>
<ul><li> 'TEXT' defines log text </li>
<li> 'HTML' defines html report </li>
<li> 'CONSOLE' defines standard output</li></ul><br/>
</font>
For example, user can define loglevel 5 should appear only in text file, 3 only on console, 1 only on html report
<br/><br/>
<IMG SRC='..\..\pics\Test_Report\6.png' alt="REPORTING" border="1" />
</font>

=head4 Log Level Section appearance in generated report

=for html
<font color = "blue">
a.	In new report user can customize the loglevel appearance during generation of report based on project requirement.
<br/><br/>
<IMG SRC='..\..\pics\Test_Report\loglevel_selection.png' alt="REPORTING" border="1" />
<br/><br/>
In above example level 3,5 and w2rep log information appears while generating the report and remaining levels are hidden.
<br/><br/>
For example, if user doesn't want to see the 'w2rep' loglevel information during report generation,<br/> then he can specify not to appear related loglevel statements by doing specific settings as below
<br/><br/>
<IMG SRC='..\..\pics\Test_Report\w2rep.png' alt="REPORTING" border="1" />
<br/><br/>
b.	If user doesn't want to define customizable log section appearance, default section is considered.
<br/><br/>
<IMG SRC='..\..\pics\Test_Report\Default_loglevel_selection.png' alt="REPORTING" border="1" />
</font>

=head4 PM module filtering

=for html
<font color = "blue">
a.	During report generation, user can specify not to display related module statements by doing specific settings as below
<br/><br/>
<IMG SRC='..\..\pics\Test_Report\Lib_selection.png' alt="REPORTING" border="1" />
<br/><br/>
For example, if user doesn't want to see the 'LIFT_evaluation'  module information during report generation then he can specify not to appear by doing specific settings as below
<br/><br/>
<IMG SRC='..\..\pics\Test_Report\LIFT_evaluation.png' alt="REPORTING" border="1" />
<br/><br/>
b.	During report generation, user can decide for hiding the required module(s) from filtering selection while generating report.<br/>
For example, 'LIFT_general'  module will not appear in filtering option. This could be achieved by doing specific settings as below
<br/><br/>
<IMG SRC='..\..\pics\Test_Report\LIFT_general.png' alt="REPORTING" border="1" />
<br/><br/>
<IMG SRC='..\..\pics\Test_Report\libSelect_hideFromFilter.png' alt="REPORTING" border="1" />
<br/><br/>
When <i>'hide_from_filter'</i> property is set, <i>'display'</i> property will be ignored.
<br/><br/>
c.	If user doesn't want to customize, then by default all modules log information used in testcase appears<br/>
</font>

=head4 Element filtering

=for html
<font color = "blue">
a.	New feature is provided like user can customize what information to appear during report generation such as text, time, graphics (pictures & graphs) and tables.
<br/><br/>
<IMG SRC='..\..\pics\Test_Report\Element_selection.png' alt="REPORTING" border="1" />
<br/><br/>
b.	b.	If specific element is not provided  in given structure (as shown above), then content wrt that element displays in the report<br/>
For ex, if <font color="green">'TIME'</font> and <font color="green">'TEXT'</font> are not provided in selection option, then time and text contents appears in the report.
<br/><br/>
<IMG SRC='..\..\pics\Test_Report\Element_selection_option.png' alt="REPORTING" border="1" />
<br/><br/>        
c.	If user doesn't want to provide this filtering option, then by default all elements information will appear
<br/><br/>
<IMG SRC='..\..\pics\Test_Report\Default_Element_selection.png' alt="REPORTING" border="1" />
<br/><br/>
So the final generated report will appear based on the filtering options provided or default option.<br/>
Sample user defined reporting format structure
<br/><br/>
<IMG SRC='..\..\pics\Test_Report\FinalStructure.png' alt="REPORTING" border="1" />
<br/><br/>
The new format filtering options in LIFT report as below
<br/><br/>
<IMG SRC='..\..\pics\Test_Report\new_show_Hide.png' alt="REPORTING" border="1" />
<br/><br/>
By clicking on "show", appears as below based on filtering options given in reporting structure
<br/><br/>
<IMG SRC='..\..\pics\Test_Report\new_format.png' alt="REPORTING" border="1" />
</font>

=head4 "Show ALL" option

=for html
<font color = "blue">
If user wants to see all the log information irrespective of filtering properties as shown above, then click on "Show ALL" button. Entire report information appears<br/>
<ol><li>All elements (text, time, table, graphics)</li>
<li>All modules which are used in respective test scenario, including hidden modules</li>
<li>All loglevels</li></ol>
</font>