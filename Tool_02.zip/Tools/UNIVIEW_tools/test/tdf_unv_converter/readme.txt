Steps of Execution:

1.  Perl script Path should be given in command prompt and followed by, type of file conversion and file name (Drag & drop possible/ provide with path).

2.  Enter to execute.

Input:

Usage: 

	<Drive:>\<filepath>\tdf_unv_converter.pl  [-t2u | -u2t] [-f filename]
	
 	-t2u : tdf to unv  file conversion(*.tdf)
	
 	-u2t : unv to tdf  file conversion(*.unv)


Example: 

	tdf to unv conversion:

	D:\>D:\tdf_unv_tool\tdf_unv_converter.pl -t2u -f filename(*.tdf)

	unv to tdf conversion:

	D:\>D:\tdf_unv_tool\tdf_unv_converter.pl -u2t -f filename(*.unv)	


Output:

Output of the particular file conversion will be generated into the same folder from where the source file was loaded. 

-t2u : <Input filename>_report.txt.<extension>  Eg : "outputSignals_CRASH_report.txt.unv"
-u2t : <Input filename>_report.<extension> Eg: "outputSignals_CRASH.tdf"

==============================================================================================

Transient Recorder Data File [*.tdf]:

	�	Binary File Format
	�	Data contains in this file are:

		1.	Version 
		2.	Description
		3.	Sampling rate [ms]
		4.	Total points
		5.	Triggering delay [ms]
		6.	Channel names
		7.	Data [Binary format]


============================================================================================
tdf file in FAMOS Tool(Import Filter) : 

*.tdf file can be view in FAMOS Tool. 

In Famos special filters to import different file types can be created. 

Some file type definitions exist to import e.g. transient recorder data files generated with TestSW. These files have the suffix �.fas�. (TransiDatafile.Fas can be found in test folder)

Before you can use a *.FAS file for importing files into FAMOS, you must first specify a directory for them in FAMOS. All file type definitions must be present in Famos tool installation folder(c:\imc\def ).

It is recommended to copy required format (TransiDatafile.fas) to the standard Famos definition file folder (c:\imc\def) to be able to use Famos� standard file types as well as the specific files 

*Refer : Details steps can be found in Using_Famos.doc in test folder
==============================================================================================

Uniview File [*.txt.unv]:
	�	Text File Format
	�	Data contains in this file are:
		1.	Time
		2.	Channel names
		3.	Points

Univiw File in UNV Tool

==============================================================================================
