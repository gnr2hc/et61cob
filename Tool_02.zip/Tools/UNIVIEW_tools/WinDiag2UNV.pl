#!C:\Perl\bin\Perl.exe -w

#################################################################################
# this tool is under version management
my $VERSION = q$Revision: 1.2 $;
my $HEADER  = q$Header: UNIVIEW_tools/WinDiag2UNV.pl 1.2 2012/08/16 18:37:20ICT Boehm Frank (DC/PAR) (BM7ZSI) develop  $;
#################################################################################

use Tk;
use strict;
use File::Path;
use Getopt::Long;

my $Toolversion = "WinDiag2UNV ($VERSION)";      # Tool version number

my ($scan_file, $out_file);
my ( $main, $ValueFrame, $ButtonFrame, $ValueEntry, $display_txt);


################################
# create those nice TK widgets #
################################

# create main window 'main'
$main = MainWindow -> new();

# define minimum size of window 'main'
$main -> minsize( 400, 300 );

# create title in window 'main'
$main -> title ( "create uniview file out of WinDiag asc trace $VERSION" );

# create label in window 'main'
$main -> Label( "-text" => "create UNV from ASC",
                "-font" => "{MS Sans Serif} 10 bold",
         )
      -> pack( "-pady" => 10 );

# create frame 'ValueFrame' in window 'main'
$ValueFrame = $main -> Frame() -> pack( "-pady" => 5 );

# create frame 'ButtonFrame' in window 'main'
$ButtonFrame = $main -> Frame() -> pack( "-pady" => 5 );

# create label in window 'ValueWindow'
$ValueFrame -> Label( "-text" => "file: ", )
            -> pack( "-side" => 'left', );

# create entry 'ValueEntry' in 'ValueFrame'
$ValueEntry = $ValueFrame -> Entry(
            "-width" => 50,
            "-textvariable" => \$scan_file, #reference to $prj_id
            );
$ValueEntry -> pack( "-side" => 'left', );

          # create 'browse file' button
          $ValueFrame -> Button
            (
            "-text" => "Browse file",
            "-command" => sub
              {
                      # browse for file
                      $scan_file = $main -> getOpenFile
                        (
                        "-filetypes"  =>
                          [
                          ["asc files", '.asc'],
                          ["All files", '.*']
                          ],
                        "-title"      => "choose one of the files to scan (*.asc)",
                        );
                      # if a file was chosen
                      if ( $scan_file )
                        {
                        #extract directory
                        print "\n $scan_file was chosen\n";
                        }
                      else
                        {
                          print "no filename!\n";
                          # prompt user
                          $main->messageBox(
                              '-icon'    => "error",#qw/error info question warning/
                              '-type'    => "OK",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                              '-title'   => 'Attention',
                              '-message' => "!Please select file first!"
                          );


                       }
              },
            )
              -> pack ("-padx" => 5,);


# create 'exit' button
$ButtonFrame -> Button
  (
  "-text" => "E X I T",
  "-command" => sub
    {exit}
  )
-> pack ("-side" => 'left',"-ipadx" => 20,"-ipady" => 20,"-pady" => 30,"-padx" => 50);


# create 'create' button
$ButtonFrame -> Button
  (
  "-text" => "CREATE",
  "-command" => sub
    { # execute when button is pressed  
        if ($scan_file) { # create project if scan_file was given
        scan_file_content($scan_file);
        $scan_file = ""; # set scan_file to undefined

        }
        else{
        # prompt user if scan_file is undefined
            $main->messageBox(
                '-icon'    => "error", #qw/error info question warning/
                '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
                '-message' => "!Please select file first!"
            );
        }
    }
  )
-> pack ("-side" => 'right',"-ipadx" => 20,"-ipady" => 20,"-pady" => 30,"-padx" => 50);

# create label in window 'main'
$main -> Label( "-textvariable" => \$display_txt, #reference to $display_txt
                "-font" => "{MS Sans Serif} 10 bold",
         )
      -> pack( "-pady" => 10 );




#++++++++++++++++++++++++++++++++++++++++++++++
########################## MAIN ###############
# the MainLoop is used by perlTK, when it is called all widgets are created and the
# connected actions are done (e.g. when you press a button)

open ( LOG,">WinDiag2UNV_log.txt" ) or die "Couldn't open logfile.txt : $@";
# create logfile in chosen directory
w2log("######################################################################\n");
w2log("      $Toolversion logfile\n");
w2log("######################################################################\n");

# run with CLI
GetOptions('par=s' => \$scan_file );
if ($scan_file){ # source file
    w2log("running with CLI\n");
    scan_file_content($scan_file);
}
else{
  # if no options, run TK GUI
  w2log("running with TK\n");
  MainLoop;
}

w2log("\n######################################################################\n");
w2log(" END OF LOGFILE\n");

close (LOG);

#-------------------- MAIN end ---------------#
#++++++++++++++++++++++++++++++++++++++++++++++


sub scan_file_content{

my ($line,$i);

    my $scan_file = shift;

    $out_file = $scan_file;
    # replace e.g. C:\myhome\myfile.sad with C:\myhome\myfile
    $out_file =~ s/\.\w+$//; # cut off file extension

    # replace e.g. C:\myhome\myfile with C:\myhome\myfile.txt.unv
    $out_file .= '.txt.unv'; # extend filename


    open ( IN,"<$scan_file" ) or die "Couldn't open $_ : $@";
    open ( OUT,">$out_file" ) or die "Couldn't open $_ : $@";

    my $CHnum=0;
    my @name=();
    $line = <IN>;
    until ($line =~ /END\s+OF\s+HEADER/ or eof){
        #Channel= 1 0 3FF88B8 S_VDCIntChlData_XXR.A_RawDataINTW_S16X(0) 3 0 0 0 0 0.0000
           # print OUT "#".$line;

        if ($line =~ /^Channel=\s+(\d+)\s+\d+\s+\w+\s+(\S+)\s+(\d+)/){
            print $line;
            $CHnum++ if ($1 != 0);
            push (@name,$2);
        }
        $line = <IN>;

    }

    my $labels="";
    my $units="";
    print " CHnum = $CHnum \n";
    for ($i=0;$i<$CHnum;$i++){
        $labels.=$name[$i].";";
        $units.="-;";
    }

    #TIME;A_FLIFltCurrent_U8R(31);A_FLMFltFiltered_U8R(31);A_FLMFltMemCounter_U8R(254);A_FLMFltMemState_U8R(0);trigger;
    #s;-;-;-;-;-;
    print OUT "TIME;".$labels."\n";
    print OUT "s;".$units."\n";

    my ($data,$time);
    while ($line = <IN>){
        #         81          187         6605          -79   0.0020
        if ($line =~ /^\s+(.+)\s+(\d+\.\d+)\s*$/){
            $data=$1;
            $time = $2;
            
            print OUT "$time;".join(';',split(/\s+/,$data)).";\n";

        }
		#         2.1         76           32         5963
		elsif ($line =~ /^\s+(\d+\.\d+)\s+(.+)\s*$/){
            $time = $1;
            $data=$2;
            
            print OUT "$time;".join(';',split(/\s+/,$data)).";\n";

        }
    }


    close (IN);
    close (OUT);
    $display_txt="$out_file created"
}



##################################
# Logfile handling
##################################
sub w2log{
     my $text = shift;
     print LOG $text;
     print $text;
}


# end of program

=head1 usage

create uniview file out of WinDiag fast diagnosis trace file(.asc), to be used for production diagnosis traces

 trace has to be in decimal ascii:
 configure with "Options/Fast Diagnosis -> Store as ASCII File -> dec"
 record with "Functions/Fast Diagnosis" and store with "Actions/Store Screen Continously"

 CLI: WinDiag2UNV.pl --par [file]
 e.g. WinDiag2UNV.pl --par C:/myproject/somefile.asc


use 'EXIT' button to finish logfile properly


=head1 AUTHOR

Frank B�hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=cut
