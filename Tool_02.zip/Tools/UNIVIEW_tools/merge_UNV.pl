#!C:\Perl\bin\Perl.exe -w

#################################################################################
# this tool is under version management
my $VERSION = q$Revision: 1.1 $;
my $HEADER  = q$Header: UNIVIEW_tools/merge_UNV.pl 1.1 2010/09/27 19:51:41ICT Boehm Frank (DC/PAR) (BM7ZSI) develop  $;
#################################################################################

use Tk;
use strict;
use File::Path;
use Getopt::Long;

my $Toolversion = "merge_UNV ($VERSION)";      # Tool version number

my ($scan_file1,$scan_file2, $out_file,$sync1,$sync2);
my ( $main, $File1Frame,$File2Frame,$File3Frame,$ValueFrame, $ButtonFrame, $ValueEntry, $display_txt);

$sync1=$sync2=0;

################################
# create those nice TK widgets #
################################

# create main window 'main'
$main = MainWindow -> new();

# define minimum size of window 'main'
$main -> minsize( 400, 300 );

# create title in window 'main'
$main -> title ( "merge 2 uniview files $VERSION" );

# create label in window 'main'
$main -> Label( "-text" => "merge UNV",
                "-font" => "{MS Sans Serif} 10 bold",
         )
      -> pack( "-pady" => 10 );

# create frame 'ValueFrame' in window 'main'
$File1Frame = $main -> Frame() -> pack( "-pady" => 5 );
$File2Frame = $main -> Frame() -> pack( "-pady" => 5 );
$File3Frame = $main -> Frame() -> pack( "-pady" => 5 );
$ValueFrame = $main -> Frame() -> pack( "-pady" => 5 );

# create frame 'ButtonFrame' in window 'main'
$ButtonFrame = $main -> Frame() -> pack( "-pady" => 5 );

# create label in window 'ValueWindow'
$File1Frame -> Label( "-text" => "infile1: ", )
            -> pack( "-side" => 'left', );

# create entry 'ValueEntry' in 'ValueFrame'
$File1Frame -> Entry(
            "-width" => 50,
            "-textvariable" => \$scan_file1, #reference to $prj_id
            ) -> pack( "-side" => 'left', );

          # create 'browse file' button
          $File1Frame -> Button
            (
            "-text" => "Browse file",
            "-command" => sub
              {
                      # browse for file
                      $scan_file1 = $main -> getOpenFile
                        (
                        "-filetypes"  =>
                          [
                          ["par files", '.txt.unv'],
                          ["All files", '.*']
                          ],
                        "-title"      => "choose one of the files to merge (*.txt.unv)",
                        );
                      # if a file was chosen
                      if ( $scan_file1 )
                        {
                        #extract directory
                        print "\n $scan_file1 was chosen\n";
                        }
                      else
                        {
                          print "no filename!\n";
                          # prompt user
                          $main->messageBox(
                              '-icon'    => "error",#qw/error info question warning/
                              '-type'    => "OK",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                              '-title'   => 'Attention',
                              '-message' => "!Please select file first!"
                          );


                       }
              },
            )
              -> pack ("-padx" => 5,);


# create label in window 'ValueWindow'
$File2Frame -> Label( "-text" => "infile2: ", )
            -> pack( "-side" => 'left', );

# create entry 'ValueEntry' in 'ValueFrame'
$File2Frame -> Entry(
            "-width" => 50,
            "-textvariable" => \$scan_file2, #reference to $prj_id
            ) -> pack( "-side" => 'left', );

          # create 'browse file' button
          $File2Frame -> Button
            (
            "-text" => "Browse file",
            "-command" => sub
              {
                      # browse for file
                      $scan_file2 = $main -> getOpenFile
                        (
                        "-filetypes"  =>
                          [
                          ["par files", '.txt.unv'],
                          ["All files", '.*']
                          ],
                        "-title"      => "choose one of the files to merge (*.txt.unv)",
                        );
                      # if a file was chosen
                      if ( $scan_file2 )
                        {
                        #extract directory
                        print "\n $scan_file1 was chosen\n";
                        }
                      else
                        {
                          print "no filename!\n";
                          # prompt user
                          $main->messageBox(
                              '-icon'    => "error",#qw/error info question warning/
                              '-type'    => "OK",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                              '-title'   => 'Attention',
                              '-message' => "!Please select file first!"
                          );


                       }
              },
            )
              -> pack ("-padx" => 5,);

# create label in window 'ValueWindow'
$File3Frame -> Label( "-text" => "outfile: ", )
            -> pack( "-side" => 'left', );

# create entry 'ValueEntry' in 'ValueFrame'
$File3Frame -> Entry(
            "-width" => 50,
            "-textvariable" => \$out_file, #reference to $prj_id
            ) -> pack( "-side" => 'left', );

          # create 'browse file' button
          $File3Frame -> Button
            (
            "-text" => "Browse file",
            "-command" => sub
              {
                      # browse for file
                      $out_file = $main -> getSaveFile
                        (
                        "-filetypes"  =>
                          [
                          ["par files", '.txt.unv'],
                          ["All files", '.*']
                          ],
                        "-title"      => "choose file to be saved (*.txt.unv)",
                        );
                      # if a file was chosen
                      if ( $out_file )
                        {
                        #extract directory
                        print "\n $scan_file1 was chosen\n";
                        }
                      else
                        {
                          print "no filename!\n";
                          # prompt user
                          $main->messageBox(
                              '-icon'    => "error",#qw/error info question warning/
                              '-type'    => "OK",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                              '-title'   => 'Attention',
                              '-message' => "!Please select file first!"
                          );


                       }
              },
            )
              -> pack ("-padx" => 5,);

# create label in window 'ValueWindow'
$ValueFrame -> Label( "-text" => "time1 in file 1: ", )
            -> pack( "-side" => 'left', );

# create entry 'ValueEntry' in 'ValueFrame'
$ValueFrame -> Entry(
            "-width" => 10,
            "-textvariable" => \$sync1, #reference to $prj_id
            )-> pack( "-side" => 'left', );

# create label in window 'ValueWindow'
$ValueFrame -> Label( "-text" => " MATCHES time2 in file 2: ", )
            -> pack( "-side" => 'left', );

# create entry 'ValueEntry' in 'ValueFrame'
$ValueFrame -> Entry(
            "-width" => 10,
            "-textvariable" => \$sync2, #reference to $prj_id
            )-> pack( "-side" => 'left', );



# create 'exit' button
$ButtonFrame -> Button
  (
  "-text" => "E X I T",
  "-command" => sub
    {exit}
  )
-> pack ("-side" => 'left',"-ipadx" => 20,"-ipady" => 20,"-pady" => 30,"-padx" => 50);


# create 'create' button
$ButtonFrame -> Button
  (
  "-text" => "CREATE",
  "-command" => sub
    { # execute when button is pressed  
        if ($scan_file1 and $scan_file2 and $out_file) { # create project if scan_file was given
        scan_file_content();
        #$scan_file1 = ""; # set scan_file to undefined
        #$scan_file2 = ""; # set scan_file to undefined
        $out_file = ""; # set scan_file to undefined

        }
        else{
        # prompt user if scan_file is undefined
            $main->messageBox(
                '-icon'    => "error", #qw/error info question warning/
                '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
                '-message' => "!Please select file first!"
            );
        }
    }
  )
-> pack ("-side" => 'right',"-ipadx" => 20,"-ipady" => 20,"-pady" => 30,"-padx" => 50);

# create label in window 'main'
$main -> Label( "-textvariable" => \$display_txt, #reference to $display_txt
                "-font" => "{MS Sans Serif} 10 bold",
         )
      -> pack( "-pady" => 10 );




#++++++++++++++++++++++++++++++++++++++++++++++
########################## MAIN ###############
# the MainLoop is used by perlTK, when it is called all widgets are created and the
# connected actions are done (e.g. when you press a button)

open ( LOG,">merge_UNV_log.txt" ) or die "Couldn't open logfile.txt : $@";
# create logfile in chosen directory
w2log("######################################################################\n");
w2log("      $Toolversion logfile\n");
w2log("######################################################################\n");

# run with CLI
GetOptions('in1=s' => \$scan_file1,'in2=s' => \$scan_file2,'out=s' => \$out_file );
if ($scan_file1 and $scan_file2 and $out_file){ # source file
    w2log("running with CLI\n");
    #scan_file_content();
}
else{
  # if no options, run TK GUI
  w2log("running with TK\n");
  MainLoop;
}

w2log("\n######################################################################\n");
w2log(" END OF LOGFILE\n");

close (LOG);

#-------------------- MAIN end ---------------#
#++++++++++++++++++++++++++++++++++++++++++++++


sub scan_file_content{


    my ($line1,$line2,$time1,$time2,$last1,$last2,$val1,$val2,$zeroes1,$zeroes2,$i);
    my $offset2 = $sync1-$sync2;

    open ( IN1,"<$scan_file1" ) or die "Couldn't open $_ : $@";
    open ( IN2,"<$scan_file2" ) or die "Couldn't open $_ : $@";
    open ( OUT,">$out_file" ) or die "Couldn't open $_ : $@";

    #store first two lines (labels and units)
    $line1 = <IN1>;
    $line2 = <IN2>;
    chomp($line1);
    chomp($line2);
    $line2 =~ s/^[^;]+;//;
    print OUT $line1.$line2."\n";

    $line1 = <IN1>;
    chomp($line1);
    $zeroes1= $line1;
    $zeroes1=~s/^[^;]+;//;
    $zeroes1=~s/[^;]+/0/g;

    $line2 = <IN2>;
    chomp($line2);
    $line2 =~ s/^[^;]+;//;
    $zeroes2= $line2;
    $zeroes2=~s/[^;]+/0/g;
    print OUT $line1.$line2."\n";

    $line1 = <IN1>;
    $line2 = <IN2>;
    $last1=$zeroes1;
    $last2=$zeroes2;

    while(defined $line1 or defined $line2){
        if(defined $line1){
            chomp($line1);
            $line1 =~ /^([^;]+);(.+)/;
            $time1=$1;
            $val1=$2;
        }
        else{
            $val1 = $zeroes1;
            $time1 = $time2;
        }

        if(defined $line2){
            chomp($line2);
            $line2 =~ /^([^;]+);(.+)/;
            $time2=$1+$offset2;
            #$time2=$1;
            $val2=$2;
        }
        else{
            $val2 = $zeroes2;
            $time2 = $time1;
        }

        if ($time1 == $time2){
            print OUT $time1.";".$val1.$val2."\n";
            $line1 = <IN1>;
            $line2 = <IN2>;
            $last1=$val1;
            $last2=$val2;
        }
        elsif ($time1 < $time2){
            print OUT $time1.";".$val1.$last2."\n";
            $line1 = <IN1>;
            $last1=$val1;
        }
        else {
            print OUT $time2.";".$last1.$val2."\n";
            $line2 = <IN2>;
            $last2=$val2;
        }

    }

  close (IN1);
  close (IN2);
  close (OUT);

}



##################################
# Logfile handling
##################################
sub w2log{
     my $text = shift;
     print LOG $text;
     print $text;
}


# end of program

=head1 usage

merge 2 uniview files

trace has to be in decimal ascii

 CLI: merge_UNV.pl --in1 [file] --in2 [file] --out [file]
 e.g. merge_UNV.pl --in1 windiag.txt.unv --in2 windiag2.txt.unv --out merged.txt.unv

use 'EXIT' button to finish logfile properly

in GUI you can also define 2 sync times to calculate offset

=head1 AUTHOR

Frank B�hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=cut
