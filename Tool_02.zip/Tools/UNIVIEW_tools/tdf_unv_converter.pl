#!/usr/bin/perl
# *****************************************************************************************************
#                                                                                                       
#  Copyright (c) 2012  Robert Bosch GmBH                                                                
#                      Germany                                                                          
#                      All rights reserved                                                              
#                                                                                                       
#******************************************************************************************************
#    $Source: UNIVIEW_tools/tdf_unv_converter.pl $
#    $Revision: 1.3 $
#    $Author: VTH4KOR $
#    $State: develop $
#******************************************************************************************************

use strict;

use constant INIT_VAL => '3';

my $sampling_rate;
my $points;
my $trigger_delay;
my $outfile;
my $size_line = 0;
my $init_val = INIT_VAL;

my @values;
my @file_lines;

if (@ARGV < 2)
{ 
    &help();
    exit(1);
}

main(); #calling main()
print "\nFile Conversion is completed\n";
exit();

#******************************************************************************************************
#main SubFunction  :
#main()
#This function is used to check and call the sub routines.	
#Should check the file Parsed is correct or not
#Return Values : None
#******************************************************************************************************

sub main
{
    my $filename = $::ARGV[1];	
    $filename =~ s|\\|/|g;
    if ($ARGV[0] eq '-t2u')    #check for which type of file conversion 
    {	
        if($filename !~ /\.tdf$/i)  #check for the proper file extension
        {
            print "Invalid file Input. Parse the tdf File as input\n";
            &help(); 
        }
        else
        {   
            open( my $input, "<", $filename ) || die "Can't open $filename: $!";# Open the parsed input tdf file
            my @file_name = split(/\./,$filename);
            binmode($input);		# Reading the tdf file in binary format
            @file_lines = <$input>;	# Reading the input file lines		
            $size_line = @file_lines;
            $outfile = "$file_name[0]"."_report.txt.unv";	#Open the Output unv file
            open OUTFILE, '>', $outfile or die "can't open $outfile: $!";
            tdf_2_unv();   # Call tdf to unv conversion function
			close OUTFILE;
        }
    }
    elsif($ARGV[0] eq '-u2t')
    {	
        if($filename !~ /\.unv$/i) #check for which type of file conversion 
        {
            print "Invalid file Input. Parse the unv File as input\n";
            &help();
        }
        else
        {
            open( my $input, "<", $filename ) || die "Can't open $filename: $!"; # Open the parsed input unv file
            my @file_name = split(/\./,$filename);
            @file_lines = <$input>;	 # Reading the input file lines
            $outfile = $file_name[0]."_report.tdf";
            open OUTFILE, '>', $outfile or die "can't open $outfile: $!"; #Open the Output tdf file
            binmode(OUTFILE); #File opening in binary mode
            print OUTFILE "V3.1#\n##Comments##\n";				
            unv_2_tdf(@file_lines);  # Call unv to tdf conversion function
			close OUTFILE;
        }
    }
    else
    {
        &help();  # help function to run the tool
    }	
}

#******************************************************************************************************
#help SubFunction  :
#help()
#This function is used to help the user to run the tool.	
#provides the usage of tool for file Conversions.
#Return Values : None
#******************************************************************************************************

sub help() 
{   
    print("Invalid input arguments are parsed\n");
    print("\nUsage: $0 [-t2u | -u2t] [filename]\n\n");
    print(" -t2u : tdf to unv  file conversion(*.tdf)\n");
    print(" -u2t : unv to tdf  file conversion(*.unv)\n");
}

#******************************************************************************************************
#tdf_2_unv SubFunction   :
#tdf_2_unv()
#This function used to check for the line, which contains SamplingRate. 
#Call the function read_values_points() and read_channel_values()
#Return Values : None
#******************************************************************************************************

sub tdf_2_unv
{	
    my $size_value;
    if(!@file_lines) #Check for files lines.
    {
        print("No lines defined in input file. Please verify the file Parsed\n");
    }
    else
    {
        for(my $i = 0; $i<$size_line; $i++)
        {		
            if($file_lines[$i] =~ /\bSamplingRate/) #Checking for the line, which should match with Sampling Rate
            {			
                @values = split(/ /,$file_lines[$i]); # Split the line by Space to get the Sampling Rate, triggerValue and Points
                $size_value = @values;			
                read_values_points($size_value);# To Read 1. Sampling Rate, 2. Points, 3. Triggering delay 
                splice @file_lines,0,$i + 1;
                read_channel_values(@file_lines); # To read the Channel points			
                last;				
            }			
        }
        if($size_value == 0) #If Sampling Rate is not defined in line.
        {
            print("Sampling Rate, Points & trigger value is not defined in input file. Please verify the file Parsed\n");
        }		
    }
}

#******************************************************************************************************
#read_values_points SubFunction :
#read_values_points($size_value)
#Get the file line as input and it will read the sampling rate, points and triggering delay from the input line.
#$size_value : Total values are given as size
#Example : read_values_points('10')
#Return values :Sampling Rate, Points, Triggering delay
#******************************************************************************************************

sub read_values_points
{  
    my $size_value = shift;
    unless (defined $size_value) #Check for Passed Parameter in read_values_points() is correct or incorrect
    {
        print "Error : Parameter Passed for the function read_values_points is too less...\n";
        return;
    }
    while($size_value > 0)
    {
        #Split string by ":" to get the Sampling Rate, triggerValue and Points values.
        #Eg : "Points : 345"  To Get the points "345" .
        my @value = split(/:/,$values[$size_value - 1]); 
        if($size_value == $init_val) 
        {
            $trigger_delay = $value[1];	# To get the trigger Delay
        }
        elsif($size_value == ($init_val - 1))
        {
            $points = $value[1]; #To get the Points 
        }
        elsif($size_value == ($init_val - 2))
        {
            $sampling_rate = $value[1]; # To get the sampling Rate
        }
        else 
        { # Defining the DEfault value as zero for all.
            $sampling_rate = 0;
            $points = 0;
            $trigger_delay = 0;
        }
        $size_value--;				
}   
    return($sampling_rate,$points,$trigger_delay);
}

#******************************************************************************************************
#read_channel_values SubFunction :
#read_channel_values(@file_lines)
#To read the the Channel Name and Channel values from the input lines.
#@file_lines : Channel Name and Channel values are in lines.
#Example : read_channel_values('Channel Name line','Channel Values line')
#Return values : Channel name, channel values
#******************************************************************************************************

sub read_channel_values
{
    my @lines_channel = @_;	
    if(!@lines_channel)# Check for Passed Parameter in read_channel_values() is correct or incorrect
    {
        print "Error : No channels are present in the input file...\n";
    }
    my $size = @lines_channel;	
    my $channel_count = 0;	
    my $i = 1;
    my @channels;
    my @channel_points;	
    my $limit = $points*4; #Points are defined in float values
    my $length = 1;	
    push(@channels,$lines_channel[0]);
    while($i < $size - 1) #Loop will run depends on the number of Channels from input files
    {		
        $length = length($lines_channel[$i]);		
        my $ch_val = '';
        $ch_val = $ch_val.$lines_channel[$i];
        while($length < $limit) #Loop will execute for the Points byte limit and read the Channel values
        {			
            $i++;
            $length = $length + length($lines_channel[$i]) + 1;
            $ch_val = $ch_val.$lines_channel[$i];			
        }
        push(@channel_points,$ch_val);
        push(@channels, $lines_channel[$i+1]);
        $i = $i + 2;		
    }	
    chomp(@channels);
    $channel_count = @channel_points;
    write2unv(\@channels,\@channel_points,$channel_count);
}

#******************************************************************************************************
#write2unv SubFunction :
#write2unv(@channels,@channel_points,$channel_count)
#This function used to open the file and write the channel names, channel values and time in seconds(uniview file format). 
#Calculating the time by using points,sampling rate and triggering delay.
#@channels : Channel Name.
#@channel_points : Channel Values.
#$channel_count = Total channel counts.
#Example : write2unv('Channel Name1','Channel Name2','Channel Value1','Channel Value2','2')
#Return values : None
#******************************************************************************************************

sub write2unv
{ 
    my($ch_ref,$ch_pts_ref,$ch_count) = @_;
    unless (defined $ch_count)# Check for Passed Parameter in write2unv() is correct or incorrect
    {
        print "Error : Parameter Passed for the function write2unv is too less...\n";
        return;
    }
    my @ch = @$ch_ref;
    my @ch_pts = @$ch_pts_ref;	
    my %ch_all_points;	
    my $temp_size = 0;
    my $t;
    print OUTFILE "Time;";	
    for(my $i = 0; $i<$ch_count; $i++) #loop execute till total number of Channel count.
    {
        chop($ch[$i]);		
        print OUTFILE "$ch[$i];";
    }
    print OUTFILE "\ns;";
    for(my $i = 0; $i<$ch_count; $i++)
    {
        print OUTFILE ";";
    }
    print OUTFILE "\n";	
    for(my $i = 0; $i<$ch_count; $i++) #loop execute till total number of Channel count.
    {
        my @ch_val  = unpack("f*",$ch_pts[$i]);	#binary to floating conversion		
        my $size = @ch_val;		
        if($temp_size<$size)
        {
            $temp_size = $size;		
        }		
        for(my $j = 0; $j<$size; $j++)
        {
            my $ch_val = sprintf("%.5f",$ch_val[$j]);
            $ch_all_points{$i,$j} = $ch_val;			
        }			
    }	
    $t= "-".($trigger_delay/1000); # finding the time from trigger delay, sampling rate, points
    my $time = $sampling_rate/1000;	
    for(my $m = 0; $m < $temp_size; $m++)
    {	
        print OUTFILE sprintf("%.5f",$t); #Write floating values into the Output file.
        print OUTFILE ";";
        for(my $n = 0; $n <$ch_count  ;$n++)
        {
            print OUTFILE "$ch_all_points{$n,$m};";
        }
        print OUTFILE "\n";
        $t = $t + $time;
    }		
}

#******************************************************************************************************
#unv_2_tdf SubFunction :
#unv_2_tdf(@file_lines)
#Calculation of sampling rate, Total points and Triggering delay.
#Converting the floating channel points to binary channel values.
#Opening the file and writing the values into opened tdf file(tdf file format).
#@file_lines : lines from the input unv file.
#Example : unv_2_tdf('Line 1', 'Line 2', 'Line 3')
#Return values : None
#******************************************************************************************************

sub unv_2_tdf
{
    my @lines = @_;
    if(!@lines)# Check for Passed Parameter in unv_2_tdf() is correct or incorrect
    {
        print("No lines defined in input file. Please verify the file Parsed\n");
    }
    my $size = @lines;	
    chomp(@lines);	
    my $points = ($size - 2); # To get the points count from total number of lines from input file
    my @channels;
    my @channels_val;
    my $ch_count = 0;	
    my $time;
    my $j;	
    my $offset = 0;
    my $result = index($lines[0],';',$offset);
    while ($result != -1) #To find the total number of channels in input file. Finding the ";" in line using index method.
    {
        $ch_count++;
        $offset = $result + 1;
        $result = index($lines[0], ';', $offset);		
    }
    $ch_count = $ch_count - 1;	
    my @array = split(/;/,$lines[0]); #Split the line by ";" to get the channel name
    my $size_arr = @array;
    while($size_arr - 1 < $ch_count)
    {
        push(@array,"No_channel_Name"); #If channel name is not there, default as "No_channel_Name".
        $size_arr++;
    }
    for(my $i = 1; $i < $#array + 1 ; $i++)
    {   
        push(@channels,$array[$i]);		
    }	
	
		
    my @time_max = split(/;/,$lines[$#lines]); #To get the time maximum and minimum from the file lines.
    my @time_min = split(/;/,$lines[2]);
		
	
	#To check the unview file format 	
	my @time_next = split(/;/,$lines[3]);
	
	my $interval =  $time_next[0] - $time_min[0]; # To get the time interval of first two points
		
	for(my $l = 3; $l < $#lines ; $l = $l + 1) #Looping for all the Points to check time intervals
	{
		my @t1 = split(/;/,$lines[$l]);
		my @t2 = split(/;/,$lines[$l + 1]);		
		my $tnext = $t2[0] - $t1[0];		
		if($tnext != $interval) # If unequal Time interval, it will exit from unv to tdf file conversion function
		{
			print "\nUNIVIEW File has Containing Unequal Time Interval for Channel Points\n";			
			last;
		}
	}	
	
    my $trigger_delay = -($time_min[0]*1000); # Calculating Triggering delay from time Tmin values
    $sampling_rate = (((1000 * $time_max[0])+ $trigger_delay)/$points); # Calculating Sampling points from time Tmax and points.
    for($j = 2; $j < $size; $j++)
    {# To get the points depends on the no of file lines
        my @temp_arr = split(/;/,$lines[$j]);
        my $temp_size = @temp_arr;
        while($temp_size - 1 < $ch_count)
        {
            push(@temp_arr,0);
            $temp_size++;
        }		
        for(my $k = 1; $k < $temp_size; $k++)
        {
            push(@channels_val,$temp_arr[$k]);						
        }		
    }	
    my $sz_ch = @channels_val;
    print OUTFILE "SamplingRate[ms]:$sampling_rate #points:$points trigger-delay[ms]:$trigger_delay";
    for(my $m = 0; $m < $ch_count; $m++) #Loop will execute for total channel counts.
    {	
        my @a;
        my $bin;
        print OUTFILE "\n $channels[$m]\n";
        for(my $n = $m; $n < $sz_ch; $n = $n + $ch_count) 
        {
            $bin = $bin.pack("f",$channels_val[$n]);#Converting the floating values into the Binary values and write into the file.		
        }			
            print OUTFILE "$bin";		
    }
    print OUTFILE "\n END";
}
#####END######

=head1 USAGE

This tool is used for Converting the tdf file to uniview file and vice versa

Note : tdf file is in Binary format & unv file is in text format

tdf file : The Transi-Datafile format is used to save transient data files generated by TestSW

Input(s):
---------
Usage: tdf_unv_Converter.pl [-t2u | -u2t] [-f filename]

-t2u : tdf to unv  file conversion(*.tdf)
-u2t : unv to tdf  file conversion(*.unv)

Example : 

tdf -> unv: \tdf_unv_Converter.pl -t2u -f HW_FuelCuttoff_outputSignals_CRASH_TR03742.tdf 

unv -> tdf :\tdf_unv_Converter.pl -u2t -f HW_FuelCuttoff_outputSignals_CRASH_TR03742.unv

Note : Output will generate in same input folder.

Error Message(s):
-----------------
Error Message will appears when input is not proper.

=head1 AUTHOR

Vanitha Thangavelu, E<lt>Vanitha.Thangavelu@in.bosch.comE<gt>

=cut