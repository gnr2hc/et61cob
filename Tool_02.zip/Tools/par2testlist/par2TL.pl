#!C:\Perl\bin\Perl.exe -w

#################################################################################
# this tool is under version management
my $VERSION = q$Revision: 2.2 $;
my $HEADER  = q$Header: par2testlist/par2TL.pl 2.2 2010/05/03 17:41:14ICT Boehm Frank (DC/PAR) (BM7ZSI) develop  $;
#################################################################################

use Tk;
use strict;
use File::Path;
use Getopt::Long;

my $Toolversion = "par2TL ($VERSION)";      # Tool version number

my %fault_table;

my ($scan_file, $out_file, $tl_file);
my ( $main, $ValueFrame, $ButtonFrame, $ValueEntry, $display_txt);


################################
# create those nice TK widgets #
################################

# create main window 'main'
$main = MainWindow -> new();

# define minimum size of window 'main'
$main -> minsize( 400, 300 );

# create title in window 'main'
$main -> title ( "create testlist out of par file $VERSION" );

# create label in window 'main'
$main -> Label( "-text" => "create testlist and mapfile",
                "-font" => "{MS Sans Serif} 10 bold",
         )
      -> pack( "-pady" => 10 );

# create frame 'ValueFrame' in window 'main'
$ValueFrame = $main -> Frame() -> pack( "-pady" => 5 );

# create frame 'ButtonFrame' in window 'main'
$ButtonFrame = $main -> Frame() -> pack( "-pady" => 5 );

# create label in window 'ValueWindow'
$ValueFrame -> Label( "-text" => "file: ", )
            -> pack( "-side" => 'left', );

# create entry 'ValueEntry' in 'ValueFrame'
$ValueEntry = $ValueFrame -> Entry(
            "-width" => 50,
            "-textvariable" => \$scan_file, #reference to $prj_id
            );
$ValueEntry -> pack( "-side" => 'left', );

          # create 'browse file' button
          $ValueFrame -> Button
            (
            "-text" => "Browse file",
            "-command" => sub
              {
                      # browse for file
                      $scan_file = $main -> getOpenFile
                        (
                        "-filetypes"  =>
                          [
                          ["par files", '.par'],
                          ["All files", '.*']
                          ],
                        "-title"      => "choose one of the files to scan (*.par)",
                        );
                      # if a file was chosen
                      if ( $scan_file )
                        {
                        #extract directory
                        print "\n $scan_file was chosen\n";
                        }
                      else
                        {
                          print "no filename!\n";
                          # prompt user
                          $main->messageBox(
                              '-icon'    => "error",#qw/error info question warning/
                              '-type'    => "OK",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                              '-title'   => 'Attention',
                              '-message' => "!Please select file first!"
                          );


                       }
              },
            )
              -> pack ("-padx" => 5,);


# create 'exit' button
$ButtonFrame -> Button
  (
  "-text" => "E X I T",
  "-command" => sub
    {exit}
  )
-> pack ("-side" => 'left',"-ipadx" => 20,"-ipady" => 20,"-pady" => 30,"-padx" => 50);


# create 'create' button
$ButtonFrame -> Button
  (
  "-text" => "CREATE",
  "-command" => sub
    { # execute when button is pressed  
        if ($scan_file) { # create project if scan_file was given
        scan_file_content($scan_file);
        $scan_file = ""; # set scan_file to undefined

        }
        else{
        # prompt user if scan_file is undefined
            $main->messageBox(
                '-icon'    => "error", #qw/error info question warning/
                '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
                '-message' => "!Please select file first!"
            );
        }
    }
  )
-> pack ("-side" => 'right',"-ipadx" => 20,"-ipady" => 20,"-pady" => 30,"-padx" => 50);

# create label in window 'main'
$main -> Label( "-textvariable" => \$display_txt, #reference to $display_txt
                "-font" => "{MS Sans Serif} 10 bold",
         )
      -> pack( "-pady" => 10 );






#++++++++++++++++++++++++++++++++++++++++++++++
########################## MAIN ###############
# the MainLoop is used by perlTK, when it is called all widgets are created and the
# connected actions are done (e.g. when you press a button)

open ( LOG,">par2TL_log.txt" ) or die "Couldn't open logfile.txt : $@";
# create logfile in chosen directory
w2log("######################################################################\n");
w2log("      $Toolversion logfile\n");
w2log("######################################################################\n");

# run with CLI
GetOptions('par=s' => \$scan_file, 'tl=s' => \$tl_file );
if ($scan_file){ # source file
    w2log("running with CLI\n");
    scan_file_content($scan_file);
}
else{
  # if no options, run TK GUI
  w2log("running with TK\n");
  MainLoop;
}

w2log("\n######################################################################\n");
w2log(" END OF LOGFILE\n");

close (LOG);

#-------------------- MAIN end ---------------#
#++++++++++++++++++++++++++++++++++++++++++++++








###########################################
###########################################
############### SUBROUTINES ###############
###########################################
###########################################

sub scan_file_content
{
  my (@in_file, $line, $key);
  my $scan_file = shift;
  my ($map_file,$ID);
  
  w2log("\nscanning file: <$scan_file>\n\n");


  unless ($tl_file){

      $out_file = $scan_file;
      # replace e.g. C:\myhome\myfile.flt with C:\myhome\myfile
      $out_file =~ s/\.\w+$//; # cut off file extension
      $map_file=$out_file;

      # replace e.g. C:\myhome\myfile with C:\myhome\fault_table_myfile.csv
      $out_file =~ s/([^\/\\]+)$/TL_$1.txt/; # extend filename
      $map_file.='_map.txt';

      # create new files
      open ( OUT,">$out_file" ) or die "Couldn't open $_ : $@";
      open ( MAP,">$map_file" ) or die "Couldn't open $_ : $@";

  }
  else{
      $out_file = $tl_file;
      # replace e.g. C:\myhome\myfile.flt with C:\myhome\myfile
      $out_file =~ s/\.\w+$//; # cut off file extension
      $map_file=$out_file;

      # replace e.g. C:\myhome\myfile with C:\myhome\fault_table_myfile.csv
      $out_file =~ s/([^\/\\]+)$/TL_$1.txt/; # extend filename
      $map_file.='_map.txt';
      
      # append files
      open ( OUT,">>$out_file" ) or die "Couldn't open $_ : $@";
      open ( MAP,">>$map_file" ) or die "Couldn't open $_ : $@";
  }
  
  open ( IN,"<$scan_file" ) or die "Couldn't open $_ : $@";
  print MAP "#ToolVersion : $Toolversion\n";
  print MAP "#PAR file : $scan_file\n";
  print OUT "#ToolVersion : $Toolversion\n";
  print OUT "#PAR file : $scan_file\n";

  while($line = <IN>){ 
    #scan for e.g. [TC_init_sensor_fault.PitchRS_PLL]
    if ($line =~ /^\s*\[([^\]]+)]/) {
        $ID = $1;
        print OUT "$ID\n";
    }

    #scan for e.g. core_asset_ID        = 'SRTP_VDS_262'
    if ($line =~ /^\s*core_asset_ID\s*=\s*(.+)$/) {
        my $IDtext = $1;
        chomp($IDtext);
        $IDtext =~ s/['"\s]//g;    #' remove blanks and quotes 
        print MAP "$ID;$IDtext\n";
    }
    
    
  }

  close (IN);
  close (OUT);
  close (MAP);

  
  w2log("\ncreated file: <$out_file>\n\n");
  

  # loop over all lines
  foreach $line (@in_file){
      # if line contains fault, store in hash 
      # e.g. 8,FltSwitchBLFDShortedToBat,805012
      if ($line =~ /^\d+,(\w+),(\w+)/) {
      $fault_table{$1} = $2;
      w2log ("found  $1 = $2\n");
      }
      else {w2log("skipped $line");}

  } #END foreach $line




    print"... done\n\n";
    $display_txt = "file <$scan_file> created";
}
# END sub scan_faults


##################################
# Logfile handling
##################################
sub w2log{
     my $text = shift;
     print LOG $text;
     print $text;
}


# end of program

=head1 usage

create testlist and core asset mapfile for result import to DOORS from parameter file

 CLI: par2TL.pl --par [file] [--tl [testlist] ]
 e.g. par2TL.pl --par C:/MKS/LIFT/myproject/TC_par/TC_init_sensor_fault.par
 e.g. par2TL.pl --par C:/MKS/LIFT/myproject/TC_par/TC_init_sensor_fault.par --tl mytestlist.txt
 
 if no tl is given, for each parameter file a test list is created
 if tl is given, data will be appended to given test list / map file

a logfile will be written containing all actions.

use 'EXIT' button to finish logfile properly


for core asset mapfile use following notation to assign multiple Doors IDs to one TC ID:

[test1.par1]
core_asset_ID  = 'SRTP_11, SRTP_12, SRTP_13'


=head1 AUTHOR

Frank B�hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=cut
