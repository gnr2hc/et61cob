#!usr\bin\perl.exe -w

#################################################################################
# this tool is under version management
my $VERSION = q$Revision: 1.20 $;
my $HEADER  = q$Header: TSG4/TSG4_bootloader_update.pl 1.20 2019/04/12 17:20:10ICT Schwibus Dirk (CC-PS/EPS2) (SDW2BUE) develop  $;
#################################################################################

use Tk;
use Tk::BrowseEntry;
use strict;
use warnings;
use File::Path;
use Getopt::Long;
use IO::Handle; # for autoflush

my $Toolversion = "TSG4_bootloader ($VERSION)";      # Tool version number

# TRG firmware based on HW revision ! fw03 or fw21 
# hidden option --developer to enable manual selection of firmware, otherwise hide browse button
# removed usage of TSG4_firmware.pm

BEGIN { 
    # add directories to search path for perl modules    
    use File::Spec;
    use File::Basename;
    
    my $addpath = File::Spec->rel2abs(dirname(__FILE__)) . "/../Engine/modules";
    unshift @INC, $addpath;

}

use tsg4;
use tsg4_bl;
use tsg4_canfr;
use tsg4_klin;
use tsg4_dvm;
use tsg4_pas;
use tsg4_rc;
use tsg4_sq;
use tsg4_tr;
use tsg4_trc;
use tsg4_trg;
use tsg4_ubat;
use tsg4_via;
use tsg4_wl;
use tsg4_rdec;
use tsg4_spdt;

my ($status,$ret);

my $DATA;

$DATA->{'RC'}{'text'}="Rack Controller firmware: ";
$DATA->{'SQ'}{'text'}="SQUIB firmware: ";
$DATA->{'BL'}{'text'}="Belt Lock firmware: ";
$DATA->{'PAS'}{'text'}="PAS firmware: ";
$DATA->{'WL'}{'text'}="WL firmware: ";
$DATA->{'REF'}{'text'}="REF firmware: ";
$DATA->{'UBAT'}{'text'}="UBAT firmware: ";
$DATA->{'CANFR'}{'text'}="CANFR firmware: ";
$DATA->{'KLIN'}{'text'}="KLIN firmware: ";
$DATA->{'DVM'}{'text'}="DVM firmware: ";
$DATA->{'TRC'}{'text'}="TRC firmware: ";
$DATA->{'TRG_A'}{'text'}="TRG firmware lot <= 2: ";
$DATA->{'TRG_F'}{'text'}="TRG firmware lot > 2 (FPGA): ";

foreach my $device (keys %$DATA){
	$DATA->{$device}{'update'}=0;
}

my @device_text=();
my @device_file=();
my @device_update=();

my $testrun = 1;
my $update_href;
my $TRG_latest;

my ($Status,$Value,$dmm,$firmware,$HW_ID);

my $PWM_wait = 7000;
my $ini_wait = 2000;
my $comm_wait = 10;

my ($num,$RCnum,$RC_aref);

my ( $main, $SQ_Frame, $BL_Frame, $RC_Frame, $PAS_Frame,$ButtonFrame,$WL_Frame,$REF_Frame,$UBAT_Frame, $display_txt);
my($stat, $HWSerialNumbers, $CANChannels);
my ($SQ_update,$BL_update,$RC_update,$PAS_update,$WL_update,$REF_update,$UBAT_update);
$SQ_update = $BL_update = $RC_update = $PAS_update = $WL_update = $REF_update = $UBAT_update = 1;
my @device_label;
my $estimated_duration_text;
################################
# create those nice TK widgets #
################################

# create main window 'main'
$main = MainWindow -> new();

# define minimum size of window 'main'
$main -> minsize( 400, 300 );

# create title in window 'main'
$main -> title ( "update TSG4 firmware via bootloader $VERSION" );


my $CANHW_Frame = $main -> Frame() -> pack( "-pady" => 5 );

my ($CANHWText,$CANchannelText);
my $developer_mode;

# run with CLI
GetOptions(
  'developer' => \$developer_mode
);
  
# create label in window 'main'
$main -> Label( "-text" => "press 'check for updates' to detect devices\n then press 'UPDATE', unchecked device will be skipped",
                "-font" => "{MS Sans Serif} 10 bold",
         )
      -> pack( "-pady" => 10 );

my $GRID_Frame = $main -> Frame() -> pack( "-pady" => 5 , "-padx" => 10);
	  
# create frame 'ButtonFrame' in window 'main'
$ButtonFrame = $main -> Frame() -> pack( "-pady" => 5 );

my $count=0;

foreach my $device (sort keys %$DATA){
	$GRID_Frame -> Checkbutton( "-variable" => \$DATA->{$device}{'update'}, )
            -> grid(-row=>$count+1,-column=>1,"-pady" => 5);
	$DATA->{$device}{'label'}=$GRID_Frame -> Label( "-text" => $DATA->{$device}{'text'}, )
            -> grid(-row=>$count+1,-column=>2);
	if ($developer_mode){
	$GRID_Frame-> Entry(
	            "-width" => 100,
	            "-textvariable" => \$DATA->{$device}{'firmware'}, 
	            ) -> grid(-row=>$count+1,-column=>3);
	
	          # create 'browse file' button
	          $GRID_Frame -> Button
	            (
	            "-text" => "Browse file",
	            "-command" => sub
	              {
	                      # browse for file
	                      my $temp_file = $main -> getOpenFile
	                        (
	                        "-filetypes"  =>
	                          [
	                          ["hex files", '.hex'],
	                          ["All files", '.*']
	                          ],
	                        "-title"      => "choose firmware files to flash (*.hex)",
	                        );
	                      # if a file was chosen
	                      if ( $temp_file )
	                        {
	                        $DATA->{$device}{'firmware'} = $temp_file;  
	                        print "\n $DATA->{$device}{'firmware'} was chosen\n";
	                        }
	              },
	            )
	              -> grid(-row=>$count+1,-column=>4);
	}
	else{
	$GRID_Frame-> Entry(
	            "-width" => 100,
	            "-textvariable" => \$DATA->{$device}{'firmware'}, 
	            "-state" => 'readonly',
	            ) -> grid(-row=>$count+1,-column=>3);
			
	}
	$count++;
}


my $selectALL_btn=$ButtonFrame -> Button
  (
  "-text" => "select ALL",
  "-state" => 'disabled',
  "-command" => sub
    {
		foreach my $device (keys %$DATA){
			$DATA->{$device}{'update'}=1;
		}
	}
  )
-> pack ("-side" => 'left',"-ipadx" => 10,"-ipady" => 10,"-pady" => 10,"-padx" => 10);

my $clearALL_btn=$ButtonFrame -> Button
  (
  "-text" => "clear ALL",
  "-state" => 'disabled',
  "-command" => sub
    {
		foreach my $device (keys %$DATA){
			$DATA->{$device}{'update'}=0;
		}
	}
  )
-> pack ("-side" => 'left',"-ipadx" => 10,"-ipady" => 10,"-pady" => 10,"-padx" => 10);

# create 'exit' button
$ButtonFrame -> Button
  (
  "-text" => "E X I T",
  "-command" => sub
    {exit}
  )
-> pack ("-side" => 'right',"-ipadx" => 20,"-ipady" => 20,"-pady" => 30,"-padx" => 20);


# create 'UPDATE' button
my $update_btn=$ButtonFrame -> Button
  (
  "-text" => "3. UPDATE",
  "-state" => 'disabled',
  "-command" => sub
    { # execute when button is pressed  
        $testrun = 0;
        w2display("performing update\n");
        update_cards();

    }
  )
-> pack ("-side" => 'right',"-ipadx" => 20,"-ipady" => 20,"-pady" => 30,"-padx" => 20);

if ($developer_mode){
	$ButtonFrame -> Button
	  (
	  "-text" => "TESTRUN",
	  "-background" => "orange",
	  "-command" => sub
	    { # execute when button is pressed  
	        $testrun = 1;
	        w2display("performing testrun\n");
	        update_cards();
	
	    }
	  )
	-> pack ("-side" => 'right',"-ipadx" => 20,"-ipady" => 20,"-pady" => 30,"-padx" => 20);
}

$ButtonFrame -> Button
  (
  "-text" => "2. estimate",
  "-command" => sub
    { # execute when button is pressed  
        w2display("estimating required time\n");
		estimate();
    }
  )
-> pack ("-side" => 'right',"-ipadx" => 20,"-ipady" => 20,"-pady" => 30,"-padx" => 20);


$ButtonFrame -> Button
  (
  "-text" => "1. check for updates",
  "-command" => sub
    { # execute when button is pressed  
        w2display("analyzing firmware of TSG4 cards, please wait ...\n");
		# delete old results in case button is pressed several times
		$update_href=undef;
		foreach my $device (keys %$DATA){
			$DATA->{$device}{'update'}=0;
			$DATA->{$device}{'label'} -> configure ("-background" => "SystemButtonFace");
		}
		$main->update();
        check_cards();
    }
  )
-> pack ("-side" => 'right',"-ipadx" => 20,"-ipady" => 20,"-pady" => 30,"-padx" => 50);


# create label in window 'main'
$main -> Label( "-textvariable" => \$display_txt, #reference to $display_txt
                "-font" => "{MS Sans Serif} 10 bold",
         )
      -> pack( "-pady" => 10 );




#++++++++++++++++++++++++++++++++++++++++++++++
########################## MAIN ###############
# the MainLoop is used by perlTK, when it is called all widgets are created and the
# connected actions are done (e.g. when you press a button)
my $logfile="BOOTLOADER_".time().".txt";
my $bootLOG;
open ( $bootLOG,">",$logfile ) or die "Couldn't open $logfile : $@";
$bootLOG->autoflush(1);
# create logfile in chosen directory
w2log("######################################################################\n");
w2log("      $Toolversion logfile\n");
w2log("######################################################################\n");

# check tsg4.pm version
my $TSG4_error_text = '';
if ($tsg4::VERSION =~ /([\d\.]+)\s*$/){
	my $ver=$1;
	w2log("tsg4.pm version is $ver\n");
	if ($ver =~ /^\d\.(\d+)/){
		my $minor = $1;
		if ($minor < 43){
			$TSG4_error_text="\nERROR: tsg4.pm too old, please update to 1.43 or later\n";

		}

	}
	
}
else{
	$TSG4_error_text="\ncould not determine tsg4.pm version, please contact tool support\n";
}

unless ($TSG4_error_text eq ''){
    w2log($TSG4_error_text);
    $main->messageBox (
      '-icon'    => "error",
      '-type'    => "OK",
      '-title'   => 'Error',
      '-message' => $TSG4_error_text,
    );
    exit;
}

my $latest_FW_href;
($status, $latest_FW_href) = tsg4_latest_firmware();

my $FWdirname = '\\\\bosch.com\dfsrb\DfsDE\DIV\CS\DE_CS$\Prj\PS\Projects\Testing\9.1_TestSystems\9.1.0_Concepts\9.1.0.5_TSG4\FW_files';
my $localFW='C:\temp\FW_files\\';
my $postfix = '.hex';
        w2log( " Copying firmware folder from K drive to local drive.\n"); 

    my $result = system( "xcopy $FWdirname".' C:\temp\FW_files /E /I /H /Q /Y' );     # copy path with DOS command xcopy

    if( $result ){
        w2log( "ERROR: could not copy '$FWdirname' directory locally to C:\\temp\\FW_files\n");
        if( not $developer_mode ) {
            system( 'pause' );
            exit;
        }
    }
    else{
        w2log( " Copied firmware folder locally.\n"); 
		foreach my $device (keys %$DATA){
			$DATA->{$device}{'firmware'}=$localFW.$latest_FW_href->{$device}.$postfix;
		}
    }


my %CANHWChannels;
#get the available CAN hardware details 
$status = tsg4_start( $bootLOG, 1 );
($stat, $HWSerialNumbers, $CANChannels) = tsg4_get_CAN_HW_list();


w2log("$stat @$HWSerialNumbers @$CANChannels\n");

#put the details into Hash , to load the details when a particular Hardware is selected
for(my $i = 0; $i < @$HWSerialNumbers; $i++){
	$CANHWChannels{$$HWSerialNumbers[$i]} = $$CANChannels[$i];
}   

#return if No hardwares found
if(@$HWSerialNumbers > 0){
	
	$CANHWText = $CANchannelText = '';
	# autodetect TSG4
    for(my $i = 0; $i < @$HWSerialNumbers; $i++){
    	for(my $CANch = 1; $CANch <= $$CANChannels[$i]; $CANch++){
			$status  = tsg4_init( $CANch, $$HWSerialNumbers[$i] );
	        ($status,$HW_ID) = rc_get_HW_id(1);
#			w2log("$status $CANch, $$HWSerialNumbers[$i] $HW_ID\n");
			if ($status >= 0){
				$CANHWText = $$HWSerialNumbers[$i];
				$CANchannelText = $CANch;
				$display_txt="detected TSG4 on CAN_HW $CANHWText CH $CANchannelText";
			    w2log("\n$display_txt\n");
				last;
			}
		}
	}
	if ($CANHWText eq ''){
		$CANHWText = $$HWSerialNumbers[0];
		$CANchannelText = 2;
	    w2log("\nWARNING: No TSG4 detected\n");
	    $main->messageBox (
	      '-icon'    => "warning",
	      '-type'    => "OK",
	      '-title'   => 'Warning',
	      '-message' => "! No TSG4 detected !\nplease check connection, switch on TSG4\nand choose CAN settings manually",
	    );		
	}

	update_CAN();
	w2log("running with TK\n");
	MainLoop;

}
else{
    w2log("\nERROR: No CAN Hardware connected\n");
    $main->messageBox (
      '-icon'    => "error",
      '-type'    => "OK",
      '-title'   => 'Error',
      '-message' => "! No CAN Hardware connected !",
    );
}

w2log("\n######################################################################\n");
w2log(" END OF LOGFILE\n");

close ($bootLOG);

#-------------------- MAIN end ---------------#
#++++++++++++++++++++++++++++++++++++++++++++++



sub update_CAN{
	$CANHW_Frame -> Label( "-text" => "TSG4 is connected to CAN HW ID: ", )
            -> pack( "-side" => 'left', );

    my $serial;

	my $CANchannel = $CANHW_Frame -> BrowseEntry
	  (
	  "-variable" => \$CANchannelText,
	  "-autolimitheight"      => 1,
	  "-autolistwidth"        => 1,
	  "-width"        => 5,
	  "-choices"	  => [1..$CANHWChannels{$CANHWText}],
	  "-browsecmd" => sub
	    {
	   # $CANHWText = $serial;
	   print"$CANchannelText\n";
	    }
	  );

	my $CANHW = $CANHW_Frame -> BrowseEntry
	  (
	  "-variable" => \$CANHWText,
	  "-autolimitheight"      => 1,
	  "-autolistwidth"        => 1,
	  "-width"        => 7,
	  "-choices"	  => $HWSerialNumbers,
	  "-browsecmd" => sub
	    {
	   # $CANHWText = $serial;
	   print"$CANHWText\n";
	   $CANchannel -> configure("-choices"	  => [1..$CANHWChannels{$CANHWText}]);
	    }
	  );
	$CANHW
	-> pack
	  (
	  "-side" => 'left',
	  );
	
	$CANHW_Frame -> Label( "-text" => "CAN channel: ", )
            -> pack( "-side" => 'left', );

	$CANchannel
	-> pack
	  (
	  "-side" => 'left',
	  );


}



sub check_cards{

	$status  = tsg4_init( $CANchannelText, $CANHWText );;

	use Data::Dumper;
	open(DUMP,">dump_log.txt");

	my ($status, $card_href) = tsg4_autodetect_cards(3);
	

	# initialize global variable used in update function to request PWM signals
	my @RCs = sort(keys %{$card_href->{RC}});
	$RC_aref = \@RCs;
	
	# check which FW has to be updated and fill $update_href

# handle TRG first and delete from hash

#    TRG => [],  # trigger card
#    'TRG_A' => 'FW_Y0003', # ATMEL board lot <= 2
#    'TRG_F' => 'FW_Y0021', # FPGA board  lot  > 2

	$TRG_latest='TRG_A';
	my $lot=0;
	if (defined $card_href->{'TRG'}{1}){
		$card_href->{'TRG'}{1}{'HW'} =~ /^(\d{3})\w\d{4}$/;
		$lot = $1;
	}
	if ($lot > 0){

		$TRG_latest='TRG_F' if ($lot > 2);

		if ( tsg4_check_update_required($card_href->{'TRG'}{1}{'SW'},$latest_FW_href->{$TRG_latest}) or $developer_mode ){
			# push $update_href->{$device};
			push (@{$update_href->{$TRG_latest}},1);
		}
	}



	delete $card_href->{TRG};
	
	delete $card_href->{RDEC};
	delete $card_href->{SPDT};



	foreach my $device (sort keys %$card_href){
		my $index = 0;
		foreach my $device_number (sort(keys %{$card_href->{$device}})){
			if ( tsg4_check_update_required($card_href->{$device}{$device_number}{'SW'},$latest_FW_href->{$device}) or $developer_mode ){
				# push $update_href->{$device};
				push (@{$update_href->{$device}},$device_number);
			}
			$index++;
		}
	}	

	my $update_num=0;
	my $update_string="";

	foreach my $device2 ('BL','CANFR','KLIN','PAS'){
		if (exists $update_href->{$device2}){
			$DATA->{$device2}{'update'}=1;
			$DATA->{$device2}{'label'} -> configure ("-background" => "yellow");
			$update_num+= scalar(@{$update_href->{$device2}})/2;
			$update_string .= (scalar(@{$update_href->{$device2}})/2)." $device2, ";
		}
	}

	foreach my $device1 ('RC','SQ','WL','REF','UBAT','DVM','TRC',$TRG_latest){
		if (exists $update_href->{$device1}){
			$DATA->{$device1}{'update'}=1;
			$DATA->{$device1}{'label'} -> configure ("-background" => "yellow");
			$update_num+= scalar(@{$update_href->{$device1}});
			$update_string .= scalar(@{$update_href->{$device1}})." $device1, ";
		}
	}

	#remove trailing ,[blank]
	chop($update_string);
	chop($update_string);


	print DUMP Dumper($card_href);
	print DUMP Dumper($update_href);
	close DUMP;

	my $duration = $update_num * 80;
    my ($sec,$min,$hour) = gmtime($duration); 
    $min++;
    $estimated_duration_text = "$hour h $min min";

	
	w2display("$update_num firmware updates required:\n$update_string\n\nestimated duration: $estimated_duration_text\n");

	$selectALL_btn -> configure ("-state" => 'active');
	$clearALL_btn -> configure ("-state" => 'active');
	$update_btn -> configure ("-state" => 'active');

}


sub estimate{

	my $update_num =0;
	my $update_string="";
	foreach my $device2 ('BL','CANFR','KLIN','PAS'){
		if ($DATA->{$device2}{'update'}){
			$update_num+= scalar(@{$update_href->{$device2}})/2;
			$update_string .= (scalar(@{$update_href->{$device2}})/2)." $device2, ";
		}
	}

	foreach my $device1 ('RC','SQ','WL','REF','UBAT','DVM','TRC',$TRG_latest){
		if ($DATA->{$device1}{'update'}){
			$update_num+= scalar(@{$update_href->{$device1}});
			$update_string .= scalar(@{$update_href->{$device1}})." $device1, ";
		}
	}
	my $duration = $update_num * 80;
    my ($sec,$min,$hour) = gmtime($duration); 
    $min++;
    $estimated_duration_text = "$hour h $min min";

	#remove trailing ,[blank]
	chop($update_string);
	chop($update_string);

	w2display("$update_num firmware updates selected:\n$update_string\n\nestimated duration: $estimated_duration_text\n");
	
}



sub update_cards{
	
	my $TC_starttime = time();
	w2log("=>update_cards");

	$status  = tsg4_init( $CANchannelText, $CANHWText );
	# $status  = tsg4_init( 1, 30679 );
	
	#  print"wait until PWM phase is over\n";  
	#  tsg4_wait_ms($PWM_wait); # wait for PWM phase after switching on rack
	
	print"check if any bootloader is active\n";  
	$status = tsg4_bootloader_inactive_check();
	if($status < 0){
	    w2display("error: bootloader still active, please remove spoiled card and reset TSG4\n");
		return;
	}
	
	#tsg4_wait_ms(2000);
	

	
	# send all Rack controllers to standby to save energy and avoid heating
	foreach $num (@$RC_aref){
	#	$status = rc_set_12V_standby($num,1);
	}
	#tsg4_wait_ms(45000);
			
	if ($DATA->{'SQ'}{'firmware'} and $DATA->{'SQ'}{'update'}){
	    update_SQUIBS($update_href->{'SQ'}) or return;
	}
	if ($DATA->{'BL'}{'firmware'} and $DATA->{'BL'}{'update'}){
	    update_BELTLOCKS($update_href->{'BL'}) or return;
	}
	if ($DATA->{'PAS'}{'firmware'} and $DATA->{'PAS'}{'update'}){
	    update_PASES($update_href->{'PAS'}) or return;
	}
	if ($DATA->{'WL'}{'firmware'} and $DATA->{'WL'}{'update'}){
	    update_WARNINGLAMPS($update_href->{'WL'}) or return;
	}
	if ($DATA->{'REF'}{'firmware'} and $DATA->{'REF'}{'update'}){
	    update_REFS($update_href->{'REF'}) or return;
	}
	if ($DATA->{'UBAT'}{'firmware'} and $DATA->{'UBAT'}{'update'}){
	    update_UBATCARDS($update_href->{'UBAT'}) or return;
	}
	if ($DATA->{'CANFR'}{'firmware'} and $DATA->{'CANFR'}{'update'}){
	    update_CANFLEXRAY($update_href->{'CANFR'}) or return;
	}
	if ($DATA->{'KLIN'}{'firmware'} and $DATA->{'KLIN'}{'update'}){
	    update_KlineLIN($update_href->{'KLIN'}) or return;
	}
	if ($DATA->{'DVM'}{'firmware'} and $DATA->{'DVM'}{'update'}){
	    update_DVMscanner($update_href->{'DVM'}) or return;
	}
	if ($DATA->{'TRC'}{'firmware'} and $DATA->{'TRC'}{'update'}){
	    update_TRCscanner($update_href->{'TRC'}) or return;
	}
	if ($DATA->{$TRG_latest}{'firmware'} and $DATA->{$TRG_latest}{'update'}){
	    update_TRIGGER($update_href->{$TRG_latest}) or return;
	}

	# do rack controller update at the very end
	if ($DATA->{'RC'}{'firmware'} and $DATA->{'RC'}{'update'}){
	    update_RACKS($update_href->{'RC'}) or return;
	}

    my $duration = time() - $TC_starttime;
    
    my ($sec,$min,$hour) = gmtime($duration); 
    my $duration_text = "$hour h $min min $sec sec";

	w2display("update done in $duration_text (estimated $estimated_duration_text), please switch TSG4 off and on\n");

}





sub update_SQUIBS{
    my $SQ_aref = shift;
	return unless (defined $SQ_aref);
    w2log("updating all ".scalar(@$SQ_aref)." SQUIBS\n");
    # update all SQUIBS
    foreach $num (@$SQ_aref){
    	tsg4_wait_ms($comm_wait);
        ($status,$HW_ID) = sq_get_HW_id($num);
  		w2display("SQ $num : $HW_ID\n");
        tsg4_wait_ms($comm_wait);
        $status = sq_bootloader_mode($num);
        w2log("->bootloader_mode: $status");

        tsg4_wait_ms($ini_wait);
        $status = tsg4_boot_init();
        w2log("->boot_init: $status");
        tsg4_wait_ms($comm_wait);
        if ($status >= 0){
            if ($testrun != 1){
                my $update  = tsg4_firmware_update($DATA->{'SQ'}{'firmware'});
        		w2log("->firmware_update: $update");
        		unless ($update){
					w2display("update error on SQ $num : $HW_ID\nexiting update, please reset TSG4 and check card display");
        			return 0;
        		} 
            }
        }
        else{
            w2log("error on init bootloader for SQ $num\n");
            #system('pause');
        }

        tsg4_wait_ms($comm_wait);
        $status = tsg4_boot_exit();
        w2log("->boot_exit: $status");
    }

 	tsg4_wait_ms(4000);
	foreach $RCnum (@$RC_aref){
		$status = rc_enable_PWM($RCnum);
	}
    tsg4_wait_ms($PWM_wait);
	foreach $num (@$SQ_aref){
        ($status, $firmware) = sq_get_firmware($num);
	}
	return 1;
}



sub update_PASES{
    my $PAS_aref = shift;
	return unless (defined $PAS_aref);
    w2log("updating all ".(scalar(@$PAS_aref)/2)." PASES\n");
    # update all PASES
    foreach $num (@$PAS_aref){
      	next unless $num % 2; # skip even numbers
    	tsg4_wait_ms($comm_wait);
        ($status,$HW_ID) = pas_get_HW_id($num);
   		w2display("PAS $num : $HW_ID\n");
        tsg4_wait_ms($comm_wait);
        $status = pas_bootloader_mode($num);
        tsg4_wait_ms($ini_wait);
        $status = tsg4_boot_init();
        tsg4_wait_ms($comm_wait);
        if ($status >= 0){
            if ($testrun != 1){
                my $update = tsg4_firmware_update($DATA->{'PAS'}{'firmware'});
        		w2log("->firmware_update: $update");
        		unless ($update){
					w2display("update error on PAS $num : $HW_ID\nexiting update, please reset TSG4 and check card display");
        			return 0;
        		}
            }
        }
        else{
            w2log("error on init bootloader for slot $num\n");
            #system('pause');
        }
    
        tsg4_wait_ms($comm_wait);
        $status = tsg4_boot_exit();
    }
	
    tsg4_wait_ms(4000);
	foreach $RCnum (@$RC_aref){
		$status = rc_enable_PWM($RCnum);
	}
    tsg4_wait_ms($PWM_wait);
    foreach $num (@$PAS_aref){
        ($status, $firmware) = pas_get_firmware($num);
	}
	return 1;
}


sub update_RACKS{
    my $RC_aref = shift;
	return unless (defined $RC_aref);
    w2log("updating all ".scalar(@$RC_aref)." RACK CONTROLLERS\n");
    # update all RACKS
    foreach $num (@$RC_aref){
    	tsg4_wait_ms($comm_wait);
        $status = rc_lock_display($num);
        tsg4_wait_ms($comm_wait);
        ($status,$HW_ID) = rc_get_HW_id($num);
  		w2display("RC $num : $HW_ID\n");
        tsg4_wait_ms($comm_wait);
		
        $status = rc_bootloader_mode($num);
        tsg4_wait_ms($ini_wait);
        $status = tsg4_boot_init();
        tsg4_wait_ms($comm_wait);
        if ($status >= 0){
            if ($testrun != 1){
                my $update = tsg4_firmware_update($DATA->{'RC'}{'firmware'});
        		w2log("->firmware_update: $update");
        		unless ($update){
					w2display("update error on RC $num : $HW_ID\nexiting update, please reset TSG4 and check card display");
        			return 0;
        		}
            }
        }
        else{
            w2log("error on init bootloader for rack $num\n");
            #system('pause');
        }
        tsg4_wait_ms($comm_wait);
        $status = tsg4_boot_exit();
        tsg4_wait_ms(20000);
        ($status, $firmware) = rc_get_firmware($num);
    }   
	return 1;
}


sub update_BELTLOCKS{
    my $BL_aref = shift;
	return unless (defined $BL_aref);
    w2log("updating all ".(scalar(@$BL_aref)/2)." BELT LOCKS\n");
    # update all BELT LOCKS
    foreach $num (@$BL_aref){
    	next unless $num % 2; # skip even numbers
    	tsg4_wait_ms($comm_wait);
        ($status,$HW_ID) = bl_get_HW_id($num);
   		w2display("BL $num : $HW_ID\n");
        tsg4_wait_ms($comm_wait);
        $status = bl_bootloader_mode($num);
        tsg4_wait_ms($ini_wait);
        $status = tsg4_boot_init();
        tsg4_wait_ms($comm_wait);
        if ($status >= 0){
            if ($testrun != 1){
                my $update = tsg4_firmware_update($DATA->{'BL'}{'firmware'});
        		w2log("->firmware_update: $update");
        		unless ($update){
					w2display("update error on BL $num : $HW_ID\nexiting update, please reset TSG4 and check card display");
        			return 0;
        		}
            }
        }
        else{
            w2log("error on init bootloader for slot $num\n");
            #system('pause');
        }
    
        tsg4_wait_ms($comm_wait);
        $status = tsg4_boot_exit();
    }
	
    tsg4_wait_ms(4000);
	foreach $RCnum (@$RC_aref){
		$status = rc_enable_PWM($RCnum);
	}
    tsg4_wait_ms($PWM_wait);
    foreach $num (@$BL_aref){
        ($status, $firmware) = bl_get_firmware($num);
	}	
	return 1;
}

sub update_UBATCARDS{
    my $UBAT_aref = shift;
	return unless (defined $UBAT_aref);
    w2log("updating all ".scalar(@$UBAT_aref)." UBAT CARDS\n");
    # update all UBAT CARDS
    foreach $num (@$UBAT_aref){
    	tsg4_wait_ms($comm_wait);
        ($status,$HW_ID) = ubat_get_HW_id($num);
   		w2display("UBAT $num : $HW_ID\n");
        tsg4_wait_ms($comm_wait);
        $status = ubat_bootloader_mode($num);
        tsg4_wait_ms($ini_wait);
        $status = tsg4_boot_init();
        tsg4_wait_ms($comm_wait);
        if ($status >= 0){
            if ($testrun != 1){
                my $update = tsg4_firmware_update($DATA->{'UBAT'}{'firmware'});
        		w2log("->firmware_update: $update");
        		unless ($update){
					w2display("update error on UBATQ $num : $HW_ID\nexiting update, please reset TSG4 and check card display");
        			return 0;
        		}
            }
        }
        else{
            w2log("error on init bootloader for UBat $num\n");
            #system('pause');
        }
        tsg4_wait_ms($comm_wait);
        $status = tsg4_boot_exit();
        tsg4_wait_ms($PWM_wait);
        ($status, $firmware) = ubat_get_firmware($num);
    }   
	return 1;
}

sub update_WARNINGLAMPS{
    my $WL_aref = shift;
	return unless (defined $WL_aref);
    w2log("updating all ".scalar(@$WL_aref)." WARNINGLAMP CARDS\n");
    # update all WARNINGLAMP CARDS
    foreach $num (@$WL_aref){
    	tsg4_wait_ms($comm_wait);
        ($status,$HW_ID) = wl_get_HW_id($num);
   		w2display("WL $num : $HW_ID\n");
        tsg4_wait_ms($comm_wait);
        $status = wl_bootloader_mode($num);
        tsg4_wait_ms($ini_wait);
        $status = tsg4_boot_init();
        tsg4_wait_ms($comm_wait);
        if ($status >= 0){
            if ($testrun != 1){
                my $update = tsg4_firmware_update($DATA->{'WL'}{'firmware'});
        		w2log("->firmware_update: $update");
        		unless ($update){
					w2display("update error on WL $num : $HW_ID\nexiting update, please reset TSG4 and check card display");
        			return 0;
        		}
            }
        }
        else{
            w2log("error on init bootloader for WL $num\n");
            #system('pause');
        }
        tsg4_wait_ms($comm_wait);
        $status = tsg4_boot_exit();
        tsg4_wait_ms($PWM_wait);
        ($status, $firmware) = wl_get_firmware($num);
    }   
	return 1;
}

sub update_REFS{
    my $REF_aref = shift;
	return unless (defined $REF_aref);
    w2log("updating all ".scalar(@$REF_aref)." REF CARDS\n");
    # update all REF CARDS
    foreach $num (@$REF_aref){
    	tsg4_wait_ms($comm_wait);
        ($status,$HW_ID) = via_get_HW_id($num);
   		w2display("REF $num : $HW_ID\n");
        tsg4_wait_ms($comm_wait);
        $status = via_bootloader_mode($num);
        tsg4_wait_ms($ini_wait);
        $status = tsg4_boot_init();
        if ($status >= 0){
            if ($testrun != 1){
                my $update = tsg4_firmware_update($DATA->{'REF'}{'firmware'});
        		w2log("->firmware_update: $update");
        		unless ($update){
					w2display("update error on REF $num : $HW_ID\nexiting update, please reset TSG4 and check card display");
        			return 0;
        		}
            }
        }
        else{
            w2log("error on init bootloader for REF $num\n");
            #system('pause');
        }
        tsg4_wait_ms($comm_wait);
        $status = tsg4_boot_exit();
        tsg4_wait_ms($PWM_wait);
        ($status, $firmware) = via_get_firmware($num);
    }   
	return 1;
}

sub update_CANFLEXRAY{
    my $CANFR_aref = shift;
	return unless (defined $CANFR_aref);
    w2log("updating all ".(scalar(@$CANFR_aref)/2)." CANFR CARDS\n");
    # update all CANFLEXRAY CARDS
    foreach $num (@$CANFR_aref){
    	next unless $num % 2; # skip even numbers
    	tsg4_wait_ms($comm_wait);
        ($status,$HW_ID) = cf_get_HW_id($num);
   		w2display("CANFR $num : $HW_ID\n");
        tsg4_wait_ms($comm_wait);
        $status = cf_bootloader_mode($num);
        tsg4_wait_ms($ini_wait);
        $status = tsg4_boot_init();
        tsg4_wait_ms($comm_wait);
        if ($status >= 0){
            if ($testrun != 1){
                my $update = tsg4_firmware_update($DATA->{'CANFR'}{'firmware'});
        		w2log("->firmware_update: $update");
        		unless ($update){
					w2display("update error on CANFR $num : $HW_ID\nexiting update, please reset TSG4 and check card display");
        			return 0;
        		}
            }
        }
        else{
            w2log("error on init bootloader for CANFR $num\n");
            #system('pause');
        }
        tsg4_wait_ms($comm_wait);
        $status = tsg4_boot_exit();
        tsg4_wait_ms($PWM_wait);
        ($status, $firmware) = cf_get_firmware($num);
    }   
	return 1;
}

sub update_KlineLIN{
    my $KLIN_aref = shift;
	return unless (defined $KLIN_aref);
    w2log("updating all ".(scalar(@$KLIN_aref)/2)." KLIN CARDS\n");
    # update all KlineLIN CARDS
    foreach $num (@$KLIN_aref){
    	next unless $num % 2; # skip even numbers
    	tsg4_wait_ms($comm_wait);
        ($status,$HW_ID) = kl_get_HW_id($num);
   		w2display("KLIN $num : $HW_ID\n");
        tsg4_wait_ms($comm_wait);
        $status = kl_bootloader_mode($num);
        tsg4_wait_ms($ini_wait);
        $status = tsg4_boot_init();
        tsg4_wait_ms($comm_wait);
        if ($status >= 0){
            if ($testrun != 1){
                my $update = tsg4_firmware_update($DATA->{'KLIN'}{'firmware'});
        		w2log("->firmware_update: $update");
        		unless ($update){
					w2display("update error on KLIN $num : $HW_ID\nexiting update, please reset TSG4 and check card display");
        			return 0;
        		}
            }
        }
        else{
            w2log("error on init bootloader for KLIN $num\n");
            #system('pause');
        }
        tsg4_wait_ms($comm_wait);
        $status = tsg4_boot_exit();
        tsg4_wait_ms($PWM_wait);
        ($status, $firmware) = kl_get_firmware($num);
    }   
	return 1;
}


sub update_DVMscanner{
    my $DVM_aref = shift;
	return unless (defined $DVM_aref);
    w2log("updating all ".scalar(@$DVM_aref)." DVM\n");
    # update all DVMscanner
    foreach $num (@$DVM_aref){
    	tsg4_wait_ms($comm_wait);
        ($status,$HW_ID) = dvm_get_HW_id($num);
  		w2display("DVM $num : $HW_ID\n");
        tsg4_wait_ms($comm_wait);
        $status = dvm_bootloader_mode($num);
        tsg4_wait_ms($ini_wait);
        $status = tsg4_boot_init();
        tsg4_wait_ms($comm_wait);
        if ($status >= 0){
            if ($testrun != 1){
                my $update = tsg4_firmware_update($DATA->{'DVM'}{'firmware'});
        		w2log("->firmware_update: $update");
        		unless ($update){
					w2display("update error on DVM $num : $HW_ID\nexiting update, please reset TSG4 and check card display");
        			return 0;
        		}
            }
        }
        else{
            w2log("error on init bootloader for DVM $num\n");
            #system('pause');
        }

        tsg4_wait_ms($comm_wait);
        $status = tsg4_boot_exit();
    }

 	tsg4_wait_ms(4000);
	foreach $RCnum (@$RC_aref){
		$status = rc_enable_PWM($RCnum);
	}
    tsg4_wait_ms($PWM_wait);
	foreach $num (@$DVM_aref){
        ($status, $firmware) = dvm_get_firmware($num);
	}
	return 1;
}


sub update_TRCscanner{
    my $TRC_aref = shift;
	return unless (defined $TRC_aref);
    w2log("updating all ".scalar(@$TRC_aref)." TRC\n");
    # update all TRCscanner
    foreach $num (@$TRC_aref){
    	tsg4_wait_ms($comm_wait);
        ($status,$HW_ID) = trc_get_HW_id($num);
  		w2display("TRC $num : $HW_ID\n");
        tsg4_wait_ms($comm_wait);
        $status = trc_bootloader_mode($num);
        tsg4_wait_ms($ini_wait);
        $status = tsg4_boot_init();
        tsg4_wait_ms($comm_wait);
        if ($status >= 0){
            if ($testrun != 1){
                my $update = tsg4_firmware_update($DATA->{'TRC'}{'firmware'});
        		w2log("->firmware_update: $update");
        		unless ($update){
					w2display("update error on TRC $num : $HW_ID\nexiting update, please reset TSG4 and check card display");
        			return 0;
        		}
            }
        }
        else{
            w2log("error on init bootloader for TRC $num\n");
            #system('pause');
        }

        tsg4_wait_ms($comm_wait);
        $status = tsg4_boot_exit();
    }

 	tsg4_wait_ms(4000);
	foreach $RCnum (@$RC_aref){
		$status = rc_enable_PWM($RCnum);
	}
    tsg4_wait_ms($PWM_wait);
	foreach $num (@$TRC_aref){
        ($status, $firmware) = trc_get_firmware($num);
	}
	return 1;
}

sub update_TRIGGER{
    my $TRG_aref = shift;
	return unless (defined $TRG_aref);
    w2log("updating all ".scalar(@$TRG_aref)." TRIGGER CARDS with $DATA->{$TRG_latest}{'firmware'}\n");
    # update all TRIGGER CARDS
    foreach $num (@$TRG_aref){
    	next unless $num % 2; # skip even numbers
    	tsg4_wait_ms($comm_wait);
        ($status,$HW_ID) = trg_get_HW_id($num);
   		w2display("TRIGGER $num : $HW_ID\n");
        tsg4_wait_ms($comm_wait);
        $status = trg_bootloader_mode($num);
        tsg4_wait_ms($ini_wait);
        $status = tsg4_boot_init();
        tsg4_wait_ms($comm_wait);
        if ($status >= 0){
            if ($testrun != 1){
                my $update = tsg4_firmware_update($DATA->{$TRG_latest}{'firmware'});
        		w2log("->firmware_update: $update");
        		unless ($update){
					w2display("update error on TRIGGER $num : $HW_ID\nexiting update, please reset TSG4 and check card display");
        			return 0;
        		}
            }
        }
        else{
            w2log("error on init bootloader for TRIGGER $num\n");
            #system('pause');
        }
        tsg4_wait_ms($comm_wait);
        $status = tsg4_boot_exit();
        tsg4_wait_ms($PWM_wait);
        ($status, $firmware) = trg_get_firmware($num);
    }
	return 1;
}

##################################
# Logfile handling
##################################
sub w2log{
     my $text = shift;
     chomp($text);
     $text.="\n";
     print $bootLOG $text;
     print $text;
}


sub w2display{
     my $text = shift;
     w2log($text);
     $display_txt = $text;
     $main->update();
}

# end of program

=head1 usage

 press 'check for updates' to detect devices automatically
 then press 'UPDATE' for flashing firmware to cards
 unchecked device will be skipped"

a logfile will be written containing all actions.

use 'EXIT' button to finish logfile properly


=head1 AUTHOR

Frank B�hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=cut
