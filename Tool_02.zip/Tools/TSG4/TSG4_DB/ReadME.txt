1st method : 
	1. Run Create_TSG4_DB.bat
	2. There will be a folder created in the same path called OutputFile.
	3. There will be a final TSG4 database created in that folder.

2nd method : 
	CreatMsg_DB.pl : 
	---------------------------------------------------------
	1. Pass an empty datbase file without any messages and signals(but has the template -- created with CANdb editor)(template.dbc)
	2. run the script
	3. A database with all the messages for TSG4 is created(tsg4_DB_MsgsOnly.dbc).


	CreateSIG_VTD.pl :
	---------------------------------------------------------
	1. Pass the .dbc file created with the "CreatMsg_DB.pl" script (having all messages for TSG4).
	2. A database with all the signals and value table descriptions is created(tsg4_addedSigAndVTD.dbc).
	3. The signals will be assigned to messages and correcsponding value table descriptions.


