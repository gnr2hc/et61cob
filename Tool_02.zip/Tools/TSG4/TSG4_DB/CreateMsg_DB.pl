use strict;
use warnings;
use Tie::File ;

our ( $VERSION, $HEADER );
$VERSION = q$Revision: 1.3 $;
$HEADER  = q$Header: TSG4/TSG4_DB/CreateMsg_DB.pl 1.3 2017/07/18 15:52:58ICT gha6kor develop  $;

my $hashID = {

	"Ubat" => {
		'ID' => "PSL",
		'range' => [16,23],
	},
	"Bezug" => {
		'ID' => "REF",
		'range' => [32,47],
	},
	"Diag-K" => {
		'ID' => "DIAG_K",
		'range' => [64,79],
	},
	"Diag-can" => {
		'ID' => "DIAG_CAN",
		'range' => [80,95],
	},
	"Warning-Lamp" => {
		'ID' => "WL",
		'range' => [96,111],
	},
	"Digital-IO" =>{
		'ID' => "DIG_IO",
		'range' => [112,127],
	}, 
	"R-Dekade" => {
		'ID' => "R_DEC",
		'range' => [128,143],
	},
	"Schalter" =>{
		'ID' => "SW",
		'range' => [144,159],
	}, 
	"ZK-Dekade" => {
		'ID' => "SQ",
		'range' => [256,383],
	},	
	"PAS-Sensoren"  => {
		'ID' => "PAS",
		'range' => [384,447],
	},
	"Belt_Locks"  => {
		'ID' => "BL",
		'range' => [448,511],
	},
	"DVM_Scanner"  => {
		'ID' => "DVM_SCNR",
		'range' => [512,575],
	},
	"TRC_Scanner"  => {
		'ID' => "TRC_SCNR",
		'range' => [576,639],
	},
	"Trigger_Module"  => {
		'ID' => "TRG_MOD",
		'range' => [640,643],
	},		
	"Rack_Controller"  => {
		'ID' => "RC_CNTLR",
		'range' => [1792,1807],
	},		
	"Test_Rack"  => {
		'ID' => "TEST_RC",
		'range' => [1808,1809],
	},	
	"Broadcast"  => {
		'ID' => "BROADCAST",
		'range' => [2032,2032],
	},		
	"LCT64"  => {
		'ID' => "LCT64",
		'range' => [1600,1601],
	},
	"Manitoo" => {
		'ID' => "MANITOO",
		'range' => [1632,1633],
	},
	"EMV_TriggerBox"  => {
		'ID' => "EMV_TRGBOX",
		'range' => [1616,1617],
	},
	"TestAdapter_PowerPritt"  => {
		'ID' => "TEST_ADPTR_PWRPRT",
		'range' => [1824,1825],
	},
};

my $line_find = "BU_:\n";
my $line;

my $filepath =  $ARGV[0];
open(my $fh, $filepath)
or die "Could not open file '$filepath' $!";

my $fh_copy ;
my $SampFile = $filepath."_Message.dbc";
open($fh_copy, '>',$SampFile);

foreach $line (<$fh>) {
	if($line =~ m/$line_find/){
		print $fh_copy "BU_: TSG4 CONTROL_PC\n";
		foreach my $key (keys(%$hashID)){
			my $id = $hashID->{$key}->{'ID'};
			my $ran = $hashID->{$key}->{'range'};
			my $counter = @$ran[0];
			my $d = 1;
			
			while($counter <= @$ran[1]){
				if((@$ran[1] - @$ran[0]) >1)
				{
					if($counter%2 == 0){
						print $fh_copy "\nBO_ $counter TSG4_$id\_$d\_REQ: 8 CONTROL_PC\n";
					}
					else{
						print $fh_copy "\nBO_ $counter TSG4_$id\_$d\_RESP: 8 TSG4\n";
						$d++;
					}	
				}
				elsif((@$ran[1] == @$ran[0])){
					print $fh_copy "\nBO_ $counter TSG4_$id: 8 Vector__XXX\n";					
				}
				else{
					if($counter%2 == 0){
						print $fh_copy "\nBO_ $counter TSG4_$id\_REQ: 8 CONTROL_PC\n";
					}
					else{
						print $fh_copy "\nBO_ $counter TSG4_$id\_RESP: 8 TSG4\n";
					}	
					
				}		
				$counter++;
			}			
		}
		
	}
	else{
		print $fh_copy $line;		
	}

}

close($fh);
close($fh_copy);

print "done\n\n";
