use strict;
use warnings;
use File::Basename;

our ( $VERSION, $HEADER );
$VERSION = q$Revision: 1.7 $;
$HEADER  = q$Header: TSG4/TSG4_DB/CreateSIG_VTD.pl 1.7 2017/07/18 15:54:21ICT gha6kor develop  $;

my $fh_copy ;
my $filepath;
my $fh;
my $hashID = {

	"Ubat" => {
		'Num_Sig' => 8,
		'Multiplexer_values' => {
			'?'=>["Query_Decade_Var",'ff'],
			'R'=>["Reset",'ff'],
			'C'=>["Add_Displays",'ff'],
			'E'=>["Event_Trig",'ffs'],
			'M'=>["LV124_Microcuts",'ftttt'],
			'F'=>["Free_Microcuts",'ftttt'],
			'B'=>["Use_Trigger_Discon_PS",'ff'],	
		},
		'Multiplex_StartBit' =>16,
		'ID' => "PSL",
		'range' => [16,23], 
	},
	"Bezug" => {
		'ID' => "REF",
		'range' => [32,47],
		'Num_Sig' => 7,
		'Multiplexer_values' => {
			'?'=>["Query_Decade_Var",'ff'],
			'R'=>["Reset",'ff'],
			'C'=>["Add_Displays",'ff'],
			'E'=>["Event_Trig",'ff'],
			'L'=>["FeedLine_Fault_Sim",'ff'],
			'B'=>["Shorts",'ff'],	
		},
		'Multiplex_StartBit' =>16,
	},
#	"Diag-K" => {
#		'ID' => "DIAG_K",
#		'range' => [64,79],
#	},
#	"Diag-can" => {
#		'ID' => "DIAG_CAN",
#		'range' => [80,95],
#	},
	"Warning-Lamp" => {
		'ID' => "WL",
		'range' => [96,111],
		'Num_Sig' => 10,
		'Multiplexer_values' => {
			'?'=>["Query_Prog_Var",'ff'],
			'R'=>["Reset",'ff'],
			'C'=>["Add_Displays",'ff'],
			'E'=>["Event_Trig",'ff'],
			'K'=>["User_Relay",'fff'],
			'P'=>["PWM_Func",'ff'],
			'L'=>["LV124",'ff'],
			'B'=>["Covers",'fff'],
			'U'=>["Interruptions",'ff'],
		},
		'Multiplex_StartBit' =>24,
	},
	"Digital-IO" =>{
		'ID' => "DIG_IO",
		'range' => [112,127],
		'Num_Sig' => 5,
		'Multiplexer_values' => {
			'?'=>["Query_Prog_Var",'ff'],
			'R'=>["Reset",'ff'],
			'C'=>["Add_Displays",'ff'],
			'P'=>["PWM",'f'],
		},
		'Multiplex_StartBit' =>16,
	}, 
	"R-Dekade" => {
		'ID' => "R_DEC",
		'range' => [128,143],
		'Num_Sig' => 4,
		'Multiplexer_values' => {
			'?'=>["Query_Prog_Var",'ff'],
			'R'=>["Reset",'ff'],
			'C'=>["Add_Displays",'ff'],
		},
		'Multiplex_StartBit' =>16,
	},
#	"Schalter" =>{
#		'ID' => "SW",
#		'range' => [144,159],
#	}, 
	"ZK-Dekade" => {
		'ID' => "SQ",
		'range' => [256,383],
		'Num_Sig' => 8,
		'Multiplexer_values' => {
			'?'=>["Query_ZK_Dec_Var",'fff'],
			'R'=>["Reset",'fff	'],
			'C'=>["Add_Displays",'fff'],
			'F'=>["Error_Behavior",'fff'],
			'S'=>["Simulation_IgnitionPulse",'fff'],
			'!'=>["Download_Values",'fff'],
			'B'=>["Error_Add_Cond",'fff'], 
			'L'=>["FeedLine_Fault_Sim",'fff'],
		},
		'Multiplex_StartBit' =>24,
	},	
	"PAS-Sensoren"  => {
		'ID' => "PAS",
		'range' => [384,447],
		'Num_Sig' => 10,
		'Multiplexer_values' => {
			'?'=>["Query_PAS_Var",'ff'],
			'R'=>["Reset",'ff'],
			'C'=>["Add_Displays",'ff'],
			'E'=>["Event_Trig",'ff'],
			'B'=>["Shorts",'ff'],
			'U'=>["Interruptions",'ff'],
			'P'=>["Polarity",'ff'],
			'V'=>["Permutation",'ff'],
			'L'=>["FeedLine_Fault_Sim",'ff'],
		},
		'Multiplex_StartBit' =>24,
	},
	"Belt_Locks"  => {
		'ID' => "BL",
		'range' => [448,511],
		'Num_Sig' => 8,
		'Multiplexer_values' => {
			'?'=>["Query_BL_Var",'ff'],
			'R'=>["Reset",'ff'],
			'C'=>["Add_Displays",'ff'],
			'E'=>["Event_Trig",'ff'],
			'B'=>["Buckle_Shorts",'ff'],
			'U'=>["Buckle_Interruptions",'ff'],
			'L'=>["FeedLine_Fault_Sim",'ff'],
		},
		'Multiplex_StartBit' =>24,
	},
	"DVM_Scanner"  => {
		'ID' => "DVM_SCNR",
		'range' => [512,575],
		'Num_Sig' => 4,
		'Multiplexer_values' => {
			'?'=>["Query_DVM_Var",'ff'],
			'R'=>["Reset",'ff'],
			'C'=>["Add_Displays",'ff'],
		},
		'Multiplex_StartBit' =>24,
	},
	"TRC_Scanner"  => {
		'ID' => "TRC_SCNR",
		'range' => [576,639],
		'Num_Sig' => 4,
		'Multiplexer_values' => {
			'?'=>["Query_TRC_Var",'ff'],
			'R'=>["Reset",'ff'],
			'C'=>["Add_Displays",'ff'],
		},
		'Multiplex_StartBit' =>24,
	},
#	"Trigger_Module"  => {
#		'ID' => "TRG_MOD",
#		'range' => [640,643],
#	},		
#	"Rack_Controller"  => {
#		'ID' => "RC_CNTLR",
#		'range' => [1792,1807],
#	},		
#	"Test_Rack"  => {
#		'ID' => "TEST_RC",
#		'range' => [1808,1809],
#	},	
#	"Broadcast"  => {
#		'ID' => "BROADCAST",
#		'range' => [2032,2032],
#	},		
#	"LCT64"  => {
#		'ID' => "LCT64",
#		'range' => [1600,1601],
#	},
#	"Manitoo" => {
#		'ID' => "MANITOO",
#		'range' => [1632,1633],
#	},
#	"EMV_TriggerBox"  => {
#		'ID' => "EMV_TRGBOX",
#		'range' => [1616,1617],
#	},
#	"TestAdapter_PowerPritt"  => {
#		'ID' => "TEST_ADPTR_PWRPRT",
#		'range' => [1824,1825],
#	},
};

# value table descriptions for the signals
my $VTD = {
	'PSL' => {
		'Query_Decade_Var' => {
			'00' =>	'Test Date',
			'01' =>	'Calibration date',
			'02' =>	'Serial number (8 x ASCII)',
			'03' =>	'EEprom slot 3 (8 x ASCII)',
			'04' =>	'EEprom slot 4 (8 x ASCII)',
			'05' =>	'EEprom slot 5 (8 x ASCII)',
			'06' =>	'EEprom slot 6 (8 x ASCII)',
			'07' =>	'EEprom slot 7 (8 x ASCII)',
			'08' =>	'EEPROM slot 8 (8 x ASCII)',
			'09' =>	'EEprom slot 9 (8 x ASCII)',
			'10' =>	'Program version',
			'11' =>	'ID (DVM 01)',
			'12' =>	'Controller fuses and lock bits  ',
			'13' =>	'Port state Port A, B, F',
			'14' =>	'LV124 function startup time for LV124',
			'15' =>	'UF status',
			'16' =>	'Ubat status 1..4',
			'40' =>	'Bootloader Status',
		},
		'Reset' => {
			'00' =>	'No action',
			'01' =>	'Reset Outputs',
		},
		'Add_Displays'=>{
			'00' =>	'No debug ads',
			'01' =>	'Received command in Line 1',
			'02' =>	'Command sent in row 1',
			'99' =>	'suppress display update',
		},
		'Event_Trig' => {
			'00' =>	'no action',
			'01' =>	'UF normal on / off',
			'02' =>	'UF with reversed polarity on / off',
			'10' =>	'Ubat 1 + B / off',
			'11' =>	'Ubat 1 + UF / off',
			'12' =>	'Ubat 1 B on / off',
			'13' =>	'Ubat 1 UF / off',
			'20' =>	'Ubat 2 + B / off',
			'21' =>	'Ubat 2 + UF / off',
			'22' =>	'Ubat B- 2 on / off',
			'23' =>	'Ubat 2 UF / off',
			'30' =>	'Ubat 3 + B / off',
			'31' =>	'Ubat 3 + UF / off',
			'32' =>	'Ubat 3 B / off',
			'33' =>	'Ubat 3 UF / off',
			'40' =>	'Ubat 4 + B / off',
			'41' =>	'Ubat 4 + UF / off',
			'42' =>	'Ubat 4 B- / off',
			'43' =>	'Ubat 4 UF / off',			
		},
		'LV124_Microcuts' => {
			'01' =>	'S1_closed,S2_open,R=100K',
			'02' =>	'S1 closed, S2 S1 negated, R = 10K',
			'03' =>	'S1 is closed, S2 open, R = 0.1R',
		},
		'Free_Microcuts' => {
			'0' =>	'Ubat 1 + B from',
			'1' =>	'Ubat 1 from UF+',
			'2' =>	'Ubat 1 B of',
			'3' =>	'Ubat 1 from UF',
			'4' =>	'Ubat 2+B from',
			'5' =>	'Ubat 2 UF + from',
			'6' =>	'Ubat 2 B from',
			'7' =>	'Ubat 2 UF from',
			'8' =>	'from Ubat 3 B +',
			'9' =>	'Ubat 3 from UF +',
			'a'	=> 'Ubat 3 B from',
			'b' =>	'Ubat 3 UF from',
			'c'	=> 'Ubat 4 B + from',
			'd'	=> 'Ubat 4 + from UF',
			'e'	=> 'Ubat 4 B- from',
			'f'	=> 'Ubat 4 UF from',
		},		
		'Use_Trigger_Discon_PS' => {
			'11' =>	'Ubat 1(UB+1)Trig disabled',
			'12' =>	'Ubat 1(UB+1)Trig Enabled',
			'21' =>	'Ubat 2(UB+2)Trig disabled',
			'22' =>	'Ubat 2(UB+2)Trig Enabled',
			'31' =>	'Ubat 3(UB+3)Trig disabled',
			'32' =>	'Ubat 3(UB+3)Trig Enabled',
			'41' =>	'Ubat 4(UB+4)Trig disabled',
			'42' =>	'Ubat 4(UB+4)Trig Enabled',
		},	
		'range' => [16,23], 	
		
	},
	'REF' => {
		'Query_Decade_Var' => {
			'00' =>	'Test Date (8 x ASCII)',
			'01' =>	'Calibration (8 x ASCII)',
			'02' =>	'Serial number (8 x ASCII)',
			'03' =>	'EEprom slot 3 (8 x ASCII)',
			'04' =>	'EEprom slot 4 (8 x ASCII)',
			'05' =>	'EEprom slot 5 (8 x ASCII)',
			'06' =>	'EEprom slot 6 (8 x ASCII)',
			'07' =>	'EEprom slot 7 (8 x ASCII)',
			'08' =>	'EEPROM slot 8 (8 x ASCII)',
			'09' =>	'EEprom slot 9 (8 x ASCII)',
			'10' =>	'Program version',
			'11' =>	'ID (GS01)',
			'12' =>	'Controller fuses and lock bits  ',
			'13' =>	'Port State Port A, D, E, F',
			'14' =>	'LV124 function',
			'15' =>	'Value Resistance Decade',
			'16' =>	'Value OP-voltage',
			'17' =>	'Switch positions, reference information',
			'18' =>	'0V offset voltage for OP',
			'19' =>	'event trigger',
			'40' =>	'Bootloader Status',			
		},
		'Reset' => {
			'00' =>	'No action',
			'01' =>	'Reset Outputs',
		},
		'Add_Displays'=>{
			'00' =>	'No debug ads',
			'01' =>	'Received command in Line 1',
			'02' =>	'Command sent in line 1',
			'99' =>	'suppress display update',
		},
		'Event_Trig' =>{
			'00' =>	'no action',
			'01' =>	'decade a',
			'02' =>	'decade of',
			'03' =>	'A voltage offset',
			'04' =>	'Voltage offset from',
			'05' =>	'Reference from 01.02',
			'06' =>	'Reference 2 to UF +',
			'07' =>	'Reference 2 to UF',
			'08' =>	'1 with respect to B +',
			'09' =>	'1 references B-',
			'11' =>	'R Decade interruption for 10 sec.',
			'12' =>	'R Decade for 1ms interrupt without relay',
			'13' =>	'R Decade interruption for 100us with relay',
			'14' =>	'R Decade interruption 1us break 1ms cycle 4sec. ',
			'15' =>	'R Decade interruption 100us break 1ms cycle 4sec. ',
			'16' =>	'OP-voltage interruption for 10 sec.',
			'17' =>	'OP-voltage interruption for 1ms without relay',
			'18' =>	'OP-voltage interruption for 100us with relay',
			'19' =>	'OP-voltage interruption 1us break 1ms cycle 4sec. ',
			'20' =>	'OP-voltage interruption 100us break 1ms cycle 4sec. ',			
		},
		'FeedLine_Fault_Sim' =>{
			'00' =>	'no action',
			'01' =>	'R Decade interruption for 10 sec.',
			'02' =>	'R Decade for 1ms interrupt without relay',
			'03' =>	'R Decade interruption for 100us with relay',
			'04' =>	'R Decade interruption 1us break 1ms cycle 4sec. ',
			'05' =>	'R Decade interruption 100us break 1ms cycle 4sec. ',
			'06' =>	'OP-voltage interruption for 10 sec.',
			'07' =>	'OP-voltage interruption for 1ms without relay',
			'08' =>	'OP-voltage interruption for 100us with relay',
			'09' =>	'OP-voltage interruption 1us break 1ms cycle 4sec. ',
			'10' =>	'OP-voltage interruption 100us break 1ms cycle 4sec. ',			
		},
		'Shorts' =>{
			'00' =>	'purchases from',
			'01' =>	'Reference 2 to UF +',
			'02' =>	'Reference 2 to UF',
			'03' =>	'1 with respect to B +',
			'04' =>	'1 references B-',			
		},
		'range' => [32,47],		
	},
	'WL' => {
		'range' => [96,111],
		'Query_Prog_Var' =>{
			'00' => 'test date (8 x ASCII)',
			'01' => 'Calibration (8 x ASCII)',
			'02' => 'serial number (8 x ASCII)',
			'03' => 'EEPROM slot 3 (8 x ASCII)',
			'04' => 'EEPROM slot 4 (8 x ASCII)',
			'05' => 'EEPROM slot 5 (8 x ASCII)',
			'06' => 'EEPROM slot 6 (8 x ASCII)',
			'07' => 'EEPROM slot 7 (8 x ASCII)',
			'08' => 'EEPROM slot 8 (8 x ASCII)',
			'09' => 'EEPROM slot 9 (8 x ASCII)',
			'10' => 'program version',
			'11' => 'ID (Wala01_01)',
			'12' => 'controller fuses and lock bits',
			'13' => 'Port State AC',
			'14' => 'Port state DF',
			'15' => 'PIO data bytes 1..3',
			'16' => 'WalaNummerCAN, FirstWalaNummer LastWalaNummer',
			'17' => 'Int2 Cnt (event trigger)',
			'18' => 'Event Trigger Mode, Event Trigger Delay',
			'19' => 'fault simulation LV124	',
			'20' => 'Status WL1..WL6',
			'21' => 'Status K1..K8',
			'22' => 'Status External EEPROM',
			'40' => 'Bootloader Status',
			'80' => 'Ext EEProm additional card (8 x ASCII)	Wala addon Customer',
			'81' => 'Ext EEProm additional card (8 x ASCII)	Wala addon Airbag Generation',
			'82' => 'Ext EEProm additional card (8 x ASCII)	Wala addon Vehicle / class',
			'83' => 'Ext EEProm additional card (8 x ASCII)	Wala addon Serial Number',
			'84' => 'Ext EEProm additional card (8 x ASCII)	Wala addon version',
			'85' => 'Ext EEProm additional card (8 x ASCII)	Sample phase',
			'86' => 'Ext EEProm additional card (8 x ASCII)	Production Date',
			'87' => 'Ext EEProm additional card (8 x ASCII)	connected Walas (byte ASCII 1-6) 0 - nc, 1 - GND, 2 - UBAT',
			'88' => 'Ext EEProm additional card (8 x ASCII)	Free text 1',
			'89' => 'Ext EEProm additional card (8 x ASCII)	Free text 2',
		},
		'Reset' => {
			'00' => 'No action',
			'01' => 'Reset Event Counter',
			'02' => 'reset relay outputs',
		},
		'Add_Displays' => {
			'00' => 'No debug ads',
			'01' => 'Received command in Line 1',
			'02' => 'Command sent in row 1',
			'03' => 'PIO data bytes 1..6 line 1/2',
			'99' => 'suppress display update',
		},
		'Event_Trig' => {
			'01' => 'WL interruption',
			'02' => 'WL short Bezug1',
			'03' => 'WL short Bezug2',
			'04' => 'WL interruption for 10 sec',
			'05' => 'WL interruption for 1ms without relay',
			'06' => 'WL interruption for 100us with relay',
			'07' => 'WL interruption 1us break 1ms cycle 4sec',
			'08' => 'WL interruption 100us break 1ms cycle 4sec',
			'51' => 'User relay 1 on',
			'52' => 'User relay 2 on',
			'53' => 'User Relay 3 on',
			'54' => 'User relay 4 on',
			'55' => 'User Relay 5 on',
			'56' => 'User relay 6 on ',
			'57' => 'User relay 7 on ',
			'58' => 'User relay 8 on',
			'61' => 'User relay 1 off',
			'62' => 'User Relay 2 off',
			'63' => 'User relay 3 off',
			'64' => 'User relay 4 off',
			'65' => 'User relay 5 off',
			'66' => 'User relay 6 off',
			'67' => 'User relay 7 off',
			'68' => 'User relay 8 off',
		},
		'User_Relay' => {
			'01e' => 'relay 1 on',
			'01a' => 'relay 1 off',
			'02e' => 'relay 2 on',
			'02a' => 'relay 2 off',
			'03e' => 'relay 3 on',
			'03a' => 'relay 3 off',
			'04e' => 'relay 4 on',
			'04a' => 'relay 4 off',
			'05e' => 'relay 5 on',
			'05a' => 'relay 5 off',
			'06e' => 'relay 6 on',
			'06a' => 'relay 6 off',
			'07e' => 'relay 7 on',
			'07a' => 'relay 7 off',
			'08e' => 'relay 8 on',
			'08a' => 'relay 8 off',
		},
		'PWM_Func' => {
			'00' => 'PWM out off - Function disabled (default)',
			'01' => 'PWM out on - Use parameters (LxxVllhh)',
			'02' => 'PWM out on - Disposal (140ms high, 60ms low)',
			'10' => 'PWM Time Base = 100us (default)',
			'11' => 'PWM Time Base = 200us',
			'12' => 'PWM Time Base = 500us',
			'13' => 'PWM Time Base = 1000US',
		},
		'LV124' => {
			'01' => 'WL interruption for 10 sec.',
			'02' => 'WL interruption for 1ms without relay',
			'03' => 'WL interruption for 100us with relay',
			'04' => 'WL interruption 1us break 1ms cycle 4sec',
			'05' => 'WL interruption 100us break 1ms cycle 4sec'
		},
		'Covers' => {
			'01e' => 'Reference 1 on',
			'01a' => 'Reference 1 off',
			'02e' => 'Reference 2 on',
			'02a' => 'Reference 2 off',
		},
		'Interruptions' => {
			'00' => 'Interruptions FET switch on',
			'01' => 'Interruptions FET switch off',
		},		
	},  
	'DIG_IO' => {
		'Query_Prog_Var'=>{
			'00' =>	'Test Date (8 x ASCII)',
			'01' =>	'Calibration (8 x ASCII)',
			'02' =>	'Serial number (8 x ASCII)',
			'03' =>	'EEprom slot 3 (8 x ASCII)',
			'04' =>	'EEprom slot 4 (8 x ASCII)',
			'05' =>	'EEprom slot 5 (8 x ASCII)',
			'06' =>	'EEprom slot 6 (8 x ASCII)',
			'07' =>	'EEprom slot 7 (8 x ASCII)',
			'08' =>	'EEPROM slot 8 (8 x ASCII)',
			'09' =>	'EEprom slot 9 (8 x ASCII)',
			'10' =>	'Program version',
			'11' =>	'ID (01_01 IO)',
			'12' =>	'Controller fuses and lock bits (FHi, FLo, FEx, Lockbits)  ',
			'13' => 'Port state AC',
			'14' => 'Port state DF',
			'15' => 'PIO data bytes 1..3',
			'16' => 'NummerCAN, first number, load number',
			'17' => 'Int2 Cnt (event trigger)',
			'18' => 'Event Trigger Mode, Event Trigger Delay',
			'19' => 'not used',
			'20' => 'status WL1..WL6',
			'21' => 'status K1..K8',
			'40' => 'Bootloader Status',
		},
		'Reset'=>{
			'00' =>	'No action',
			'01' =>	'Reset Event Counter',
			'02' =>	'reset relay outputs',			
		},
		'Add_Displays'=>{
			'00' =>	'No debug ads',
			'01' =>	'Received command in Line 1',
			'02' =>	'Command sent in row 1',
			'03' =>	'PIO data bytes 1..6 line 1/2',
			'99' =>	'suppress display update',			
		},
		'PWM'=>{
			'0' =>	'PWM signal off. Electronic switch disconnected (Low)',
			'1' =>	'PWM signal off. Electronic switch connected (High)',
			'2' =>	'Disposal activ. (140ms high and 60 ms low)',
			'3' =>	'PWM using parameters. (OxPllhh) ------->',			
		},
		'range' => [112,127],
	},
	'R_DEC' =>{
		'Query_Prog_Var' =>{
			'00' =>	'Test Date (8 x ASCII)',
			'01' =>	'Calibration (8 x ASCII)',
			'02' =>	'Serial number (8 x ASCII)',
			'03' =>	'EEprom slot 3 (8 x ASCII)',
			'04' =>	'EEprom slot 4 (8 x ASCII)',
			'05' =>	'EEprom slot 5 (8 x ASCII)',
			'06' =>	'EEprom slot 6 (8 x ASCII)',
			'07' =>	'EEprom slot 7 (8 x ASCII)',
			'08' =>	'EEPROM slot 8 (8 x ASCII)',
			'09' =>	'EEprom slot 9 (8 x ASCII)',
			'10' =>	'Program version',
			'11' =>	'ID (RD 01)',
			'12' =>	'Controller fuses and lock bits  ',
			'13' =>	'Port state Port A, C, D',
			'14' =>	'PIO data bytes 1..3',
			'15' =>	'PIO data bytes 4..6',
			'16' =>	'PIO data bytes 7..9',
			'17' =>	'PIO data bytes 10..12',
			'18' =>	'PIO data bytes 13..15',
			'19' =>	'Dekade1 resistance 10 Ohm steps',
			'20' =>	'Dekade2 resistance 10 Ohm steps',
			'21' =>	'Dekade3 resistance 10 Ohm steps',
			'22' =>	'Dekade4 resistance 10 Ohm steps',
			'23' =>	'Dekade5 resistance 10 Ohm steps',
			'40' =>	'Bootloader Status',
		},
		'Reset' => {
			'00' =>	'No action',
			'01' =>	'reset relay outputs',
		},
		'Add_Displays' => {
			'00' =>	'No debug ads',
			'01' =>	'Received command in Line 1',
			'02' =>	'Command sent in row 1',
			'99' =>	'suppress display update',			
		},
		'range' => [128,143],
	},
	
	'PAS' => {
		'Query_PAS_Var' => {
			'00' =>	'Test Date (8 x ASCII)',
			'01' =>	'Calibration (8 x ASCII)',
			'02' =>	'Serial number (8 x ASCII)',
			'03' =>	'EEprom slot 3 (8 x ASCII)',
			'04' =>	'EEprom slot 4 (8 x ASCII)',
			'05' =>	'EEprom slot 5 (8 x ASCII)',
			'06' =>	'EEprom slot 6 (8 x ASCII)',
			'07' =>	'EEprom slot 7 (8 x ASCII)',
			'08' =>	'EEPROM slot 8 (8 x ASCII)',
			'09' =>	'EEprom slot 9 (8 x ASCII)',
			'10' =>	'Program version',
			'11' =>	'ID (PAS01)',
			'12' =>	'Controller fuses and lock bits  ',
			'13' =>	'PAS names (PP1FD)',
			'14' =>	'Port state Port A, C, D',
			'15' =>	'PIO data bytes 1..3',
			'16' =>	'PIO data bytes 4..6',
			'17' =>	'Int2 Cnt (event trigger)',
			'18' =>	'PASNummerCAN, PasNummerModul, FirstPasNummer, SecondPasNummer)',
			'19' =>	'Event Trigger Mode, Event Trigger Delay',
			'20' =>	'Fault simulation LV124',
			'40' =>	'Bootloader Status',			
		},
		'Reset' => {
			'00' =>	'No action',
			'01' =>	'Reset Event Counter',
			'02' =>	'reset relay outputs',			
		},
		'Add_Displays' => {
			'00' =>	'No debug ads',
			'01' =>	'Received command in Line 1',
			'02' =>	'Command sent in row 1',
			'03' =>	'PIO data bytes 1..6 line 1/2',
			'99' =>	'suppress display update',			
		},
		'Event_Trig' => {
			'00' =>	'no action',
			'01' =>	'interruption PAS1',
			'02' =>	'Interruption Bus1 PAS1',
			'03' =>	'Interruption Bus1 PAS2',
			'04' =>	'Interruption Bus1 PAS3',
			'05' =>	'interruption PAS2',
			'06' =>	'Interruption Bus2 PAS1',
			'07' =>	'Interruption Bus2 PAS2',
			'08' =>	'Interruption Bus2 PAS3',
			'09' =>	'PAS1- Bezug1',
			'10' =>	'PAS1- Bezug2',
			'11' =>	'PAS1 + Bezug1',
			'12' =>	'PAS1 + Bezug2',
			'13' =>	'Bus 1 Pas1- Bezug1',
			'14' =>	'Bus 1 Pas1- Bezug2',
			'15' =>	'Bus 1 pAS1 + Bezug1',
			'16' =>	'Bus 1 pAS1 + Bezug2',
			'17' =>	'Bus 1 Pas2- Bezug1',
			'18' =>	'Bus 1 Pas2- Bezug2',
			'19' =>	'Bus 1 Pas2 + Bezug1',
			'20' =>	'Bus 1 Pas2 + Bezug2',
			'21' =>	'Bus 1 Pas3- Bezug1',
			'22' =>	'Bus 1 Pas3- Bezug2',
			'23' =>	'Bus 1 PAS3 + Bezug1',
			'24' =>	'Bus 1 PAS3 + Bezug2',
			'25' =>	'PAS2- Bezug1',
			'26' =>	'PAS2- Bezug2',
			'27' =>	'PAS2 + Bezug1',
			'28' =>	'PAS2 + Bezug2',
			'29' =>	'Bus 2 Pas1- Bezug1',
			'30' =>	'Bus 2 Pas1- Bezug2',
			'31' =>	'Bus 2 pAS1 + Bezug1',
			'32' =>	'Bus 2 pAS1 + Bezug2',
			'33' =>	'Bus 2 Pas2- Bezug1',
			'34' =>	'Bus 2 Pas2- Bezug2',
			'35' =>	'Bus 2 Pas2 + Bezug1',
			'36' =>	'Bus 2 Pas2 + Bezug2',
			'37' =>	'Bus 2 Pas3- Bezug1',
			'38' =>	'Bus 2 Pas3- Bezug2',
			'39' =>	'Bus 2 PAS3 + Bezug1',
			'40' =>	'Bus 2 PAS3 + Bezug2',
			'41' =>	'PAS1 interruption for 10 sec.',
			'42' =>	'PAS1 interruption for 1ms without relay',
			'43' =>	'PAS1 interruption for 100us with relay',
			'44' =>	'PAS1 interruption 1us break 1ms cycle 4sec. ',
			'45' =>	'PAS1 interruption 100us break 1ms cycle 4sec. ',
			'46' =>	'PAS2 interruption for 10 sec.',
			'47' =>	'PAS2 interruption for 1ms without relay',
			'48' =>	'PAS2 interruption for 100us with relay',
			'49' =>	'PAS2 interruption 1us break 1ms cycle 4sec. ',
			'50' =>	'PAS2 interruption 100us break 1ms cycle 4sec. ',			
		},
		'Shorts' =>{
			'00' =>	'no action',
			'01' =>	'PAS Bezug1',
			'02' =>	'PAS Bezug2',
			'03' =>	'Pas + Bezug1',
			'04' =>	'Pas + Bezug2',
			'05' =>	'Bus Pas1- Bezug1',
			'06' =>	'Bus Pas1- Bezug2',
			'07' =>	'Bus pAS1 + Bezug1',
			'08' =>	'Bus pAS1 + Bezug2',
			'09' =>	'Bus Pas2- Bezug1',
			'10' =>	'Bus Pas2- Bezug2',
			'11' =>	'Bus Pas2 + Bezug1',
			'12' =>	'Bus Pas2 + Bezug2',
			'13' =>	'Bus Pas3- Bezug1',
			'14' =>	'Bus Pas3- Bezug2',
			'15' =>	'Bus PAS3 + Bezug1',
			'16' =>	'Bus PAS3 + Bezug2',			
		},
		'Interruptions'=> {
			'00' =>	'No action',
			'01' =>	'PAS + FET switch ',
			'02' =>	'bus PAS1',
			'03' =>	'bus PAS2',
			'04' =>	'bus PAS3',			
		},
		'Polarity' => {
			'00' =>	'No action',
			'01' =>	'PAS Plus Minus exchange connection',			
		},
		'Permutation' =>{
			'00' =>	'No action',
			'01' =>	'exchange PAS1 and PAS2',			
		},
		'FeedLine_Fault_Sim' => {
			'00' =>	'no action',
			'01' =>	'PAS1 interruption for 10 sec.',
			'02' =>	'PAS1 interruption for 1ms without relay',
			'03' =>	'PAS1 interruption for 100us with relay',
			'04' =>	'PAS1 interruption 1us break 1ms cycle 4sec. ',
			'05' =>	'PAS1 interruption 100us break 1ms cycle 4sec. ',
			'06' =>	'PAS2 interruption for 10 sec.',
			'07' =>	'PAS2 interruption for 1ms without relay',
			'08' =>	'PAS2 interruption for 100us with relay',
			'09' =>	'PAS2 interruption 1us break 1ms cycle 4sec. ',
			'10' =>	'PAS2 interruption 100us break 1ms cycle 4sec. ',				
		},
		'range' => [384,447],		
		
	},
	
	'BL' => {
		'Query_BL_Var' => {
			'00' =>	'Test Date (8 x ASCII)',
			'01' =>	'Calibration (8 x ASCII)',
			'02' =>	'Serial number (8 x ASCII)',
			'03' =>	'EEprom slot 3 (8 x ASCII)',
			'04' =>	'EEprom slot 4 (8 x ASCII)',
			'05' =>	'EEprom slot 5 (8 x ASCII)',
			'06' =>	'EEprom slot 6 (8 x ASCII)',
			'07' =>	'EEprom slot 7 (8 x ASCII)',
			'08' =>	'EEPROM slot 8 (8 x ASCII)',
			'09' =>	'EEprom slot 9 (8 x ASCII)',
			'10' =>	'Program version',
			'11' =>	'ID (GS01)',
			'12' =>	'Controller fuses and lock bits  ',
			'13' =>	'GS-name (BT1FD)',
			'14' =>	'Port state Port A, C, D',
			'15' =>	'PIO data bytes 1..3',
			'16' =>	'PIO data bytes 4..6',
			'17' =>	'Int2 Cnt (event trigger)',
			'18' =>	'GSNummerCAN, GSNummerModul, FirstGSNummer, SecondGSNummer)',
			'19' =>	'Event Trigger Mode, Event Trigger Delay',
			'20' =>	'Fault simulation LV124',
			'21' =>	'Value decade GS1',
			'22' =>	'Value decade GS2',
			'23' =>	'Value power source GS1',
			'24' =>	'Value power source GS2',
			'25' =>	'reference GS1',
			'26' =>	'reference GS2',
			'40' =>	'Bootloader Status',			
		},
		'Reset' => {
			'00' =>	'No action',
			'01' =>	'Reset Event Counter',
			'02' =>	'reset relay outputs',			
		},
		'Add_Displays' => {
			'00' =>	'No debug ads',
			'01' =>	'Received command in Line 1',
			'02' =>	'Command sent in row 1',
			'03' =>	'PIO data bytes 1..6 line 1/2',			
		},
		'Event_Trig' => {
			'00' =>	'no action',
			'01' =>	'interruption GS1',
			'02' =>	'interruption GS2',
			'03' =>	'GS1 Bezug1',
			'04' =>	'GS1 Bezug2',
			'05' =>	'GS1 + Bezug1',
			'06' =>	'GS1 + Bezug2',
			'07' =>	'GS2 Bezug1',
			'08' =>	'GS2 Bezug2',
			'09' =>	'GS2 + Bezug1',
			'10' =>	'GS2 + Bezug2',
			'11' =>	'GS1 interruption for 10 sec.',
			'12' =>	'GS1 interruption for 1ms without relay',
			'13' =>	'GS1 interruption for 100us with relay',
			'14' =>	'GS1 interruption 1us break 1ms cycle 4sec. ',
			'15' =>	'GS1 interruption 100us break 1ms cycle 4sec. ',
			'16' =>	'GS2 interruption for 10 sec.',
			'17' =>	'GS2 interruption for 1ms without relay',
			'18' =>	'GS2 interruption for 100us with relay',
			'19' =>	'GS2 interruption 1us break 1ms cycle 4sec. ',
			'20' =>	'GS2 interruption 100us break 1ms cycle 4sec. ',			
		},
		'Buckle_Shorts' => {
			'00' =>	'no action',
			'01' =>	'GS Bezug1',
			'02' =>	'GS Bezug2',
			'03' =>	'GS + Bezug1',
			'04' =>	'GS + Bezug2',			
		},
		'Buckle_Interruptions' => {
			'00' =>	'No action',
			'01' =>	'GS FET switch ',			
		},
		'FeedLine_Fault_Sim' => {
			'00' =>	'no action',
			'01' =>	'GS1 interruption for 10 sec.',
			'02' =>	'GS1 interruption for 1ms without relay',
			'03' =>	'GS1 interruption for 100us with relay',
			'04' =>	'GS1 interruption 1us break 1ms cycle 4sec. ',
			'05' =>	'GS1 interruption 100us break 1ms cycle 4sec. ',
			'06' =>	'GS2 interruption for 10 sec.',
			'07' =>	'GS2 interruption for 1ms without relay',
			'08' =>	'GS2 interruption for 100us with relay',
			'09' =>	'GS2 interruption 1us break 1ms cycle 4sec. ',
			'10' =>	'GS2 interruption 100us break 1ms cycle 4sec. ',			
		},
		'range' => [448,511],
		
	},
	
	'DVM_SCNR' => {
		'Query_DVM_Var' => {
			'00' =>	'Test Date (8 x ASCII)',
			'01' =>	'Calibration (8 x ASCII)',
			'02' =>	'Serial number (8 x ASCII)',
			'03' =>	'EEprom slot 3 (8 x ASCII)',
			'04' =>	'EEprom slot 4 (8 x ASCII)',
			'05' =>	'EEprom slot 5 (8 x ASCII)',
			'06' =>	'EEprom slot 6 (8 x ASCII)',
			'07' =>	'EEprom slot 7 (8 x ASCII)',
			'08' =>	'EEPROM slot 8 (8 x ASCII)',
			'09' =>	'EEprom slot 9 (8 x ASCII)',
			'10' =>	'Program version',
			'11' =>	'ID (DVM 01)',
			'12' =>	'Controller fuses and lock bits  ',
			'13' =>	'Port state Port A, C, D',
			'14' =>	'PIO data bytes 1..3',
			'15' =>	'PIO data bytes 4..6',
			'16' =>	'PIO data bytes 7..9',
			'17' =>	'PIO data bytes 10..12',
			'18' =>	'PIO data bytes 13..15',
			'19' =>	'Scanner Pos Hi, Lo',
			'40' =>	'Bootloader Status',			
		},
		'Reset' => {
			'00' =>	'No action',
			'01' =>	'reset relay outputs',			
		},
		'Add_Displays' => {
			'00' =>	'No debug ads',
			'01' =>	'Received command in Line 1',
			'02' =>	'Command sent in row 1',
			'99' =>	'suppress display update',			
		},
		'range' => [512,575],
	},
	
	'TRC_SCNR' => {
		'Query_TRC_Var' => {
			'00' =>	'Test Date (8 x ASCII)',
			'01' =>	'Calibration (8 x ASCII)',
			'02' =>	'Serial number (8 x ASCII)',
			'03' =>	'EEprom slot 3 (8 x ASCII)',
			'04' =>	'EEprom slot 4 (8 x ASCII)',
			'05' =>	'EEprom slot 5 (8 x ASCII)',
			'06' =>	'EEprom slot 6 (8 x ASCII)',
			'07' =>	'EEprom slot 7 (8 x ASCII)',
			'08' =>	'EEPROM slot 8 (8 x ASCII)',
			'09' =>	'EEprom slot 9 (8 x ASCII)',
			'10' =>	'Program version',
			'11' =>	'ID (TRC 01)',
			'12' =>	'Controller fuses and lock bits  ',
			'13' =>	'Port state Port A, C, D',
			'14' =>	'PIO data bytes 1..3',
			'15' =>	'PIO data bytes 4..6',
			'16' =>	'PIO data bytes 7..9',
			'17' =>	'PIO data bytes 10..12',
			'18' =>	'PIO data bytes 13..15',
			'19' =>	'TRC scanner Pos 1..8',
			'20' =>	'DVM-out scanner Pos',
			'40' =>	'Bootloader Status',			
		},
		'Reset' => {
			'00' =>	'No action',
			'01' =>	'reset relay outputs',			
		},
		'Add_Displays' => {
			'00' =>	'No debug ads',
			'01' =>	'Received command in Line 1',
			'02' =>	'Command sent in row 1',
			'99' =>	'suppress display update',			
		},
		'range' => [576,639],
	},	
	'SQ' => {
		'Query_ZK_Dec_Var' => {
			'000' => 'Test Date (8 x ASCII)',
			'001' => 'Calibration (8 x ASCII)',
			'002' => 'Serial number (8 x ASCII)',
			'003' => 'EEprom slot 3 (8 x ASCII)',
			'004' => 'EEprom slot 4 (8 x ASCII)',
			'005' => 'EEprom slot 5 (8 x ASCII)',
			'006' => 'EEprom slot 6 (8 x ASCII)',
			'007' => 'EEprom slot 7 (8 x ASCII)',
			'008' => 'EEPROM slot 8 (8 x ASCII)',
			'009' => 'EEprom slot 9 (8 x ASCII)',
			'010' => 'Program version',
			'011' => 'ID (ZK01)',
			'012' => 'Controller fuses and lock bits  ',
			'013' => 'ZK-name (AB1FD)',
			'014' => 'Port State Port A, E, F',
			'015' => 'recognized threshold voltage integrator state, ignition pulse',
			'016' => 'Current resistance value Decade on / off, fault simulation',
			'017' => 'Gate time, triggering behavior after ignition',
			'018' => 'Zündpillensimulationsmode, fault simulation LV124',
			'019' => 'Timer0 InterruptCnt',
			'020' => 'Interrupt0 Cnt Integrator',
			'021' => 'Interrupt1 Cnt ignition pulse detected / Interrupt2 Cnt event TRG',
			'022' => 'ZP simulation pulse times',
			'023' => 'ZP simulation breaks',
			'024' => 'ZP simulation index resistance',
			'025' => 'ZP simulation download pulse times',
			'026' => 'ZP simulation download breaks',
			'027' => 'ZP simulation download index resistance',
			'028' => 'ZP simulation temp buffer pulse times',
			'029' => 'ZP simulation Temp buffering pauses',
			'030' => 'ZP simulation Temp Buffer index resistance',
			'031' => 'ZP simulation First Delay',
			'040' => 'Bootloader Status',
		},
		'Reset' => {
			'000' => 'No action',
			'001' => 'set ZK-decade on the previous value',
			'002' => 'reset, interrupt Timer0, INT0, INT1, INT2',
			'003' => 'reset, interrupt Timer0',
			'004' => 'reset, interrupt INT0',
			'005' => 'reset, interrupt INT1',
			'006' => 'reset, interrupt INT2',
		},
		'Add_Displays' =>{
			'000' => 'No debug ads',
			'001' => 'Received command in Line 1',
			'002' => 'Command sent in row 1',
			'003' => 'Buffer content at Download at line 1',
		},
		'Error_Behavior' =>{
			'000' => 'no action',
			'001' => 'interrupt ZK by integrator count',
			'002' => 'ZK short-circuit by integrator count',
			'003' => 'ZK- Reference 1 by integrator count',
			'004' => 'ZK + reference 1 by integrator count',
			'005' => 'ZK- Reference 2 by integrator count',
			'006' => 'ZK + cover 2 by integrator count',
			'101' => 'interrupt ZK by time',
			'102' => 'ZK short-circuit by time',
			'103' => 'ZK- Reference 1 by time',
			'104' => 'ZK + reference 1 by time',
			'105' => 'ZK- Reference 2 by time',
			'106' => 'ZK + cover 2 by time',
			'201' => 'interrupt ZK by event trigger',
			'202' => 'ZK short-circuit by event trigger',
			'203' => 'ZK- Reference 1 by event trigger',
			'204' => 'ZK + reference 1 by event trigger',
			'205' => 'ZK- Reference 2 by event trigger',
			'206' => 'ZK + cover 2 by event trigger',
		},
		'Simulation_IgnitionPulse' => {
			'000' => 'no simulation',
			'001' => 'Lead-free simulation -> ZK Decade previous value',
			'002' => 'Lead-free simulation -> ZK-decade interruption',
			'003' => 'Lead-free simulation -> ZK-decade KS',
			'004' => 'Lead-free simulation -> ZK- Reference 1',
			'005' => 'Lead-free simulation -> ZK + cover 1',
			'006' => 'Lead-free simulation -> ZK- Reference 2',
			'007' => 'Lead-free simulation -> ZK + cover 2',
			'100' => 'Interruption for 10 sec.',
			'101' => 'Interruption of 1 ms without relay',
			'102' => 'Interruption of 100us with relay',
			'103' => '1us break interrupt 1ms cycle 4sec. ',
			'104' => 'Interruption 100us break 1ms cycle 4sec. ',
			'900' => 'Test Mode -> Simulation with fixed times',
			'995' => 'Download Buffer output (Download with! Fff)',
			'996' => 'Temp-Buffer Output',
			'997' => 'Save current random numbers in Temp Buffer',
			'998' => 'Random numbers Unignore recalculation',
			'999' => 'Switch random numbers recalculation',
		},
		'Download_Values' => {
			'000' => 'No download',
			'001' => 'Squib-Simu pulse times (as array)',
			'002' => 'Squib-Simu break times (as array)',
			'003' => 'Squib Simu index resistance values ​​(as array)',
			'004' => 'ZP simulation First Delay (only the first byte)',
		},
		'Error_Add_Cond' => {
			'000' => 'No mistake',
			'001' => 'ZK- Reference 1',
			'002' => 'ZK + reference 1',
			'003' => 'ZK- Reference 2',
			'004' => 'ZK + cover 2',
		},
		'FeedLine_Fault_Sim' => {
			'000' => 'no action',
			'001' => 'Interruption for 10 sec.',
			'002' => 'Interruption of 1 ms without relay',
			'003' => 'Interruption of 100us with relay',
			'004' => '1us break interrupt 1ms cycle 4sec. ',
			'005' => 'Interruption 100us break 1ms cycle 4sec. ',
		},
		'range' => [256,383],
	}	
};

# function to convert each character into hex and then concatenating and converting to decimal
sub convert_func
{
	my $given_num = shift;
	my @dat = split("", $given_num);
	
	my $string = "";
	foreach my $val (@dat){
		$string = (unpack "H*", $val).$string ;#converts ascii character to hex
	}
	return hex($string);	
	
}

#******************************************************************************
# * Purpose: 			loops over the lines of the file and creates signals for all the messages
# * Input-Parameter:    none
# * Output-Parameter:   none
# * Return : 			1
#******************************************************************************/	

sub Create_Sig(){
	while (my $line = <$fh>) {
		print $fh_copy $line;
		foreach my $mod (keys(%$hashID)){
			my $id = $hashID->{$mod}->{'ID'};
			if($line =~ m/TSG4_$id\_\d+_REQ/){
				my $Num_Sig = $hashID->{$mod}->{'Num_Sig'};
				my $count= 0;
				my $Mul_val = $hashID->{$mod}->{'Multiplexer_values'};
				my $StartBit = $hashID->{$mod}->{'Multiplex_StartBit'};
				my $lengthofBits;
				my $mult = "Multiplexer";
				my $det;
				print $fh_copy " SG_ SIG_$id\_Mult M : $StartBit|8\@1- (1,0) [0|0] \"\" CONTROL_PC\n";
				foreach my $key (keys(%$Mul_val))
				{
					$det = $Mul_val->{$key};
					$mult = @$det[0];
					$lengthofBits = @$det[1];
					my $start = $StartBit+8;
					my $bit = ord("$key");
					if($lengthofBits =~ m/fff/i){
						
						print $fh_copy " SG_ SIG_$id\_$mult m$bit : $start|24\@1- (1,0) [0|0] \"\" CONTROL_PC\n";	
					}
					elsif($lengthofBits =~ m/ff/i){
						
						print $fh_copy " SG_ SIG_$id\_$mult m$bit : $start|16\@1- (1,0) [0|0] \"\" CONTROL_PC\n";	
					}	
					else{
						
						print $fh_copy " SG_ SIG_$id\_$mult m$bit : $start|8\@1- (1,0) [0|0] \"\" CONTROL_PC\n";	
					}
				}
				$count++;	
				if(($id =~ m/PAS/) || ($id =~ m/BL/) || ($id =~ m/SQ/) || (($id =~ m/WL/))){
					my $bit = ord('M');
					my $start = $StartBit+8;
					print $fh_copy " SG_ SIG_$id\_Microcuts_Time m$bit : $start|32\@1- (1,0) [0|0] \"\" CONTROL_PC\n";
				}		
			}
				
		}
	}
	return 1;
}

#******************************************************************************
# * Purpose: 			creates value tables for all the signals created
# * Input-Parameter:    none
# * Output-Parameter:   none
# * Return : 			1
#******************************************************************************/

sub Create_VTD(){
	foreach my $module (keys(%$VTD)){
		my $hash = %$VTD->{$module};
		my $range = %$hash->{'range'}; 
		my $index_range = @$range[0];
		while ($index_range < @$range[1]){
			foreach my $sub_key(keys(%$hash)){
				unless($sub_key =~ m/range/){
					my $string = "\nVAL_ $index_range SIG_$module\_$sub_key ";
					my $sub_hash = %$hash->{$sub_key};
					foreach my $val (keys(%$sub_hash)){
						$string = $string.convert_func($val)." \"$sub_hash->{$val}\" ";	
					}
					$string = $string.";\n";
					print $fh_copy $string;
					$string = undef;
				}
			}
			$index_range = $index_range + 2;
		}	
	}
return 1;	
}	

# open the file containig only messages
$filepath =  $ARGV[0];
open($fh, $filepath)
or die "Could not open file '$filepath' $!";

#create another file to which the signals and value tables are written
use FindBin qw( $RealBin );
mkdir $RealBin."/OutputFile";
my $SampFile = $RealBin."/OutputFile/tsg4_DB.dbc";
open($fh_copy, '>',$SampFile);

Create_Sig();
Create_VTD();
	
close($fh);
close($fh_copy);
	
	


print "done\n\n";
