#!C:\Perl\bin\Perl.exe -w

#################################################################################
# this tool is under version management
my $VERSION = q$Revision: 1.2 $;
my $HEADER  = q$Header: TSG4/X1X2_map_TSG4.pl 1.2 2013/11/11 18:52:08ICT Boehm Frank (DC/PAR) (BM7ZSI) develop  $;
#################################################################################

use Tk;
use strict;
use Win32::OLE;
use File::Path;
use Getopt::Long;
use Data::Dumper;

my $Toolversion = "X1X2_map_TSG4 ($VERSION)";      # Tool version number

my $mapfile = 'X1X2_TSG4_mapping.txt';

my ($line, @cols, %keys);

open ( IN,"<$mapfile" ) or die "Couldn't open $_ : $@";
  while ($line = <IN>){
    if ($line =~ /^\s*X\d+\//){
    chomp($line);
      @cols = split(/;/,$line);
      $keys{$cols[0]}=$cols[1];
    }
  }
close (IN);


my $scan_file;
my ( $main, $ValueFrame, $WarningFrame, $SettingFrame1, $SettingFrame2, $ButtonFrame, $ValueEntry, $display_txt);

# set start directory to C:\MKS\MLC
my $start_dir = 'C:\MKS\MLC';

my $sheet_name = "Development Harness";
my $start_line = 7;
my $pin_col = "B";
my $label_col = "E";
my $target_col = "S";
my $lastline = 1000;


################################
# create those nice TK widgets #
################################

# create main window 'main'
$main = MainWindow -> new();

# define minimum size of window 'main'
$main -> minsize( 400, 300 );

# create title in window 'main'
$main -> title ( "map MLC labels $VERSION" );

# create frame 'ValueFrame' in window 'main'
$ValueFrame = $main -> Frame() -> pack( "-pady" => 5 );

# create frame 'WarningFrame' in window 'main'
$WarningFrame = $main -> Frame() -> pack( "-pady" => 10 );

# create frame 'SettingFrame1' in window 'main'
$SettingFrame1 = $main -> Frame() -> pack( "-pady" => 5 );

# create frame 'SettingFrame2' in window 'main'
$SettingFrame2 = $main -> Frame() -> pack( "-pady" => 5 );

# create frame 'ButtonFrame' in window 'main'
$ButtonFrame = $main -> Frame() -> pack( "-pady" => 5 );

# create label in window 'ValueWindow'
$ValueFrame -> Label( "-text" => "file: ", )
            -> pack( "-side" => 'left', );

# create entry 'ValueEntry' in 'ValueFrame'
$ValueEntry = $ValueFrame -> Entry(
            "-width" => 50,
            "-textvariable" => \$scan_file, #reference to $prj_id
            );
$ValueEntry -> pack( "-side" => 'left', );

          # create 'browse file' button
          $ValueFrame -> Button
            (
            "-text" => "Browse file",
            "-command" => sub
              {
                      # browse for file
                      $scan_file = $main -> getOpenFile
                        (
                        "-filetypes"  =>
                          [
                          ["XLS files", '.xls'],
                          ["All files", '.*']
                          ],
                        "-title"      => "choose one of the files to scan (*.xls)",
 #                         "-initialdir" => $start_dir,
                        );
                      # if a file was chosen
                      if ( $scan_file )
                        {
                        #extract directory
                        print "\n $scan_file was chosen\n";
                        }
                      else
                        {
                          print "no filename!\n";
                          # prompt user
                          $main->messageBox(
                              '-icon'    => "error",#qw/error info question warning/
                              '-type'    => "OK",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                              '-title'   => 'Attention',
                              '-message' => "!Please select file first!"
                          );


                       }
              },
            )
              -> pack ("-padx" => 5,);

# create label in 'WarningFrame'
$WarningFrame -> Label( "-text" => "change defaults only if necessary :",
                "-font" => "{MS Sans Serif} 10 bold",
         )
      -> pack( "-pady" => 10 );


# create label in 'SettingFrame1'
$SettingFrame1 -> Label( "-text" => "start line: ", )
            -> pack( "-side" => 'left', );
# create entry 'ValueEntry' in 'SettingFrame1'
$SettingFrame1 -> Entry(
            "-width" => 4,
            "-textvariable" => \$start_line, #reference to $start_line
            )-> pack( "-side" => 'left', );

# create label in 'SettingFrame1'
$SettingFrame1 -> Label( "-text" => "   columns for pin: ", )
            -> pack( "-side" => 'left', );
# create entry 'ValueEntry' in 'SettingFrame1'
$SettingFrame1 -> Entry(
            "-width" => 4,
            "-textvariable" => \$pin_col, #reference 
            )-> pack( "-side" => 'left', );

# create label in 'SettingFrame1'
$SettingFrame1 -> Label( "-text" => "   label: ", )
            -> pack( "-side" => 'left', );
# create entry 'ValueEntry' in 'SettingFrame1'
$SettingFrame1 -> Entry(
            "-width" => 4,
            "-textvariable" => \$label_col, #reference 
            )-> pack( "-side" => 'left', );

# create label in 'SettingFrame1'
$SettingFrame1 -> Label( "-text" => "   target: ", )
            -> pack( "-side" => 'left', );
# create entry 'ValueEntry' in 'SettingFrame1'
$SettingFrame1 -> Entry(
            "-width" => 4,
            "-textvariable" => \$target_col, #reference
            )-> pack( "-side" => 'left', );


# create label in 'SettingFrame2'
$SettingFrame2 -> Label( "-text" => "   last line: ", )
            -> pack( "-side" => 'left', );
# create entry 'ValueEntry' in 'SettingFrame'2
$SettingFrame2 -> Entry(
            "-width" => 10,
            "-textvariable" => \$lastline, #reference 
            )-> pack( "-side" => 'left', );

# create label in 'SettingFrame2'
$SettingFrame2 -> Label( "-text" => "   sheet name: ", )
            -> pack( "-side" => 'left', );
# create entry 'ValueEntry' in 'SettingFrame2'
$SettingFrame2 -> Entry(
            "-width" => 30,
            "-textvariable" => \$sheet_name, #reference 
            )-> pack( "-side" => 'left', );



# create 'exit' button
$ButtonFrame -> Button
  (
  "-text" => "E X I T",
  "-command" => sub
    {exit}
  )
-> pack ("-side" => 'left',"-ipadx" => 20,"-ipady" => 20,"-pady" => 30,"-padx" => 30);


# create 'create' button
$ButtonFrame -> Button
  (
  "-text" => "DO_MAPPING",
  "-command" => sub
    { # execute when button is pressed  
        if ($scan_file) { # create project if scan_file was given
        map_labels($scan_file);
        $scan_file = ""; # set scan_file to undefined

        }
        else{
        # prompt user if project_id is undefined
            $main->messageBox(
                '-icon'    => "error", #qw/error info question warning/
                '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
                '-message' => "!Please select file first!"
            );


        }
    
    }
  )
-> pack ("-side" => 'right',"-ipadx" => 20,"-ipady" => 20,"-pady" => 30,"-padx" => 30);

# create label in window 'main'
$main -> Label( "-textvariable" => \$display_txt, #reference to $display_txt
                "-font" => "{MS Sans Serif} 10 bold",
         )
      -> pack( "-pady" => 10 );






#++++++++++++++++++++++++++++++++++++++++++++++
########################## MAIN ###############
# the MainLoop is used by perlTK, when it is called all widgets are created and the
# connected actions are done (e.g. when you press a button)

open ( LOG,">logfile.txt" ) or die "Couldn't open logfile.txt : $@";
# create logfile in chosen directory
w2log("######################################################################\n");
w2log("      $Toolversion logfile\n");
w2log("######################################################################\n");

w2log (" MAPPING : \n\n");
foreach (sort keys %keys){
  w2log ("   <$_> => <$keys{$_}>\n");
} #END foreach 
w2log (" END OF MAPPING : \n\n");

# run with CLI
GetOptions(
  'xls=s' => \$scan_file, 
  'sheet=s' => \$sheet_name,
  'start=i' => \$start_line,
  'pin=s' => \$pin_col,
  'label=s' => \$label_col,
  'target=s' => \$target_col,
  'end=i' => \$lastline,
);
if ($scan_file){ # source file
    w2log("running with CLI\n");
    map_labels($scan_file);
}
else{
  # if no options, run TK GUI
  w2log("running with TK\n");
  MainLoop;
}
w2log("\n######################################################################\n");
w2log(" END OF LOGFILE\n");

close (LOG);

#-------------------- MAIN end ---------------#
#++++++++++++++++++++++++++++++++++++++++++++++




###########################################
###########################################
############### SUBROUTINES ###############
###########################################
###########################################

sub map_labels
{
  my (@in_file, $line, $mask);
  my ($Excel, $workbook, $worksheet);
  
  my $scan_file = shift;
  w2log("\nscanning file: <$scan_file>\n\n");

  # get already active Excel application or open new
  # see C:/Perl/html/site/lib/Win32/OLE.html
  eval {$Excel = Win32::OLE->GetActiveObject('Excel.Application')};
  die "Excel not installed" if $@;
  unless (defined $Excel) {
      $Excel = Win32::OLE->new('Excel.Application', sub {$_[0]->Quit;})
              or die "Oops, cannot start Excel";
  }
  $Excel -> {Visible} = 1;

  # load wokbook and select worksheet
  w2log("opened excel: $Excel\n");
  $workbook = $Excel -> Workbooks -> Open("$scan_file");
  w2log("opened workbook $scan_file : $workbook\n");
  $worksheet = $workbook -> Worksheets("$sheet_name");
  w2log("opened worksheet $sheet_name : $worksheet\n");

  w2log("start line is: $start_line\n");
  w2log("last line is : $lastline\n");
  w2log("pin_col is: $pin_col\n");
  w2log("label_col is: $pin_col\n");
  w2log("target_col is: $target_col\n");

  my $TSG4_struct;
  
  # loop over slected lines
  foreach $line ($start_line .. $lastline){
    # if source _col contains value
    my $old = $worksheet -> Cells($line, "$pin_col") -> {'Value'};
    if ($old){
      #w2log("value in line $line is: <$old>\n");
      # loop over all keywords
      foreach $mask (keys %keys){
          # if keyword found in hash, write corresponding label to target_col
          if ($mask eq uc($old)) {
			  $worksheet -> Cells($line, "$target_col") -> {'Value'} = $keys{$mask};
			  my $label = $worksheet -> Cells($line, "$label_col") -> {'Value'};
			  if (defined $label){
				  $label =~ s/[+-]$//; # remove sign at the end
				  if ($keys{$mask} =~ /^SQ/){
					  $TSG4_struct->{'SQUIBS'}{$keys{$mask}.'_Name'} = $label;
					  $TSG4_struct->{'SQUIBS'}{$keys{$mask}.'_Default'} = 2.2;
				  }
				  elsif ($keys{$mask} =~ /^BL/){
					  $TSG4_struct->{'BELT_LOCKS'}{$keys{$mask}.'_Name'} = $label;
					  $TSG4_struct->{'BELT_LOCKS'}{$keys{$mask}.'_Unit'} = 'R';
					  $TSG4_struct->{'BELT_LOCKS'}{$keys{$mask}.'_Default'} = 100;
				  }
				  elsif ($keys{$mask} =~ /^PSL/){
					  $TSG4_struct->{'POWER_SUPPLY_LINES'}{$keys{$mask}.'_Name'} = $label;
					  $TSG4_struct->{'POWER_SUPPLY_LINES'}{$keys{$mask}.'_Default'} = 'Ubat';
				  }
				  elsif ($keys{$mask} =~ /^PAS/){
					  $TSG4_struct->{'PAS_LINES'}{$keys{$mask}.'_Name'} = $label;
				  }
				  elsif ($keys{$mask} =~ /^CF/){
					  $TSG4_struct->{'CAN_FR'}{$keys{$mask}.'_Name'} = $label;
				  }
				  elsif ($keys{$mask} =~ /^KL/){
					  $TSG4_struct->{'K_LIN'}{$keys{$mask}.'_Name'} = $label;
				  }
				  elsif ($keys{$mask} =~ /^WL/){
					  $TSG4_struct->{'WARNING_LAMPS'}{$keys{$mask}.'_Name'} = $label;
				  }
			      w2log ("mapped $old to $keys{$mask} with label $label\n");
				  
			  }
			  else{
				w2log ("mapped $old to $keys{$mask}, no label\n");
			  }
		  }
      } #END foreach $mask
    } #END if ($old)
  } #END foreach $line

  undef $workbook;
  undef $Excel;

 
open (FILE,">TSG4_const.txt") or warn "could not write TSG4_const: $@\n";

print FILE"add to projects default section and change values if required:\n\n";
print FILE"!!! these settings are only valid for X1X2connector !!!\n";

$Data::Dumper::Indent = 1;
$Data::Dumper::Sortkeys = 1;
$Data::Dumper::Varname = "TSG4_X2X";

print FILE Dumper($TSG4_struct);

close(FILE);
  
  print"... done\n\n";
  $display_txt = "file <$scan_file> scanned";
}


##################################
# Logfile handling
##################################
sub w2log{
     my $text = shift;
     print LOG $text;
     print $text;
}


# end of program

=head1 usage

small script to map MLC/Peribox labels to TSG4 devices using X1X2connector

this tool promts user for <excel_file> which needs pin in X1/F20 format (harness description)

reads map_file X1X2_TSG4_mapping.txt

scan labels from start_line to last_line 
 if pin exists in pin_col write corresponding label to target_col for cross check
 writes project const snippet for TSG4

 sheet  - which sheet contains mapping information e.g. "Development Harness"
 start  - at which line does the mapping start (usually for jack 1) e.g. 7
 pin    - which column contains the Wiring (like x1/F20) information e.g. "B"
 label  - which column contains the project label (like AB1FD+) information e.g. "E"
 target - to which column to write the TSG4 device names for cross check e.g. "S"

by modifying default settings you can adapt tool for your sheet layout

CLI: X1X2_map_TSG4.pl --xls [file] --start [line] --end [line] --pin [col] --label [col] --target [col] --sheet [name]
e.g. X1X2_map_TSG4.pl --xls C:\_work_\Example_Harness.xls --start 20 --end 30 --pin B --label C --target F --sheet Tabelle2

     X1X2_map_TSG4.pl --xls C:\_work_\Example_Harness.xls will use default values

a logfile will be written containing all actions.

use 'EXIT' button to finish logfile properly


=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=cut