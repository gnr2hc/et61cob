#! /usr/bin/perl -w


=head1 NAME

ROBO_client_shell - Perl shell connecting to ROBO server

=head1 SYNOPSIS

just start the shell by doubleclick

    ->run abplus_config.txt
    ->qt_GetParameter(0, 0, 0, "ERROR")
    ->qt_SetParameter(0, 0, 0, "ERROR",[0,0])
    ->pause 
    ->qt_SetParameter(0, 0, 0, "ERROR",[256,0])
    ->wait 2000
    ->quit    
    

=head1 DESCRIPTION

perl shell for ROBO, will automatically start and connect to the ROBO_server.

all commands entered will be logged in ROBO_shell_log.txt. You can create own shell scripts using parts from the logfile and re-run them using the run command. 
Calling nested scripts is not implemented. You have to do the errorhandling on your own (first return value < 0 means error, use GetErrorString for more information)

B<NOTE: do not run shell in parallel to another ROBO application e.g. LIFT !>

=head2 any ROBO command

any of the low level commands from ROBO will be executed. 

=head2 run

    ->run $filename
    e.g. ->run test.txt         ( or optional: call execute )

run a shell script, all lines in this file starting with '->' will be executed as shell command, others will be ignored


=head2 help

    ->help

show small help with list of commands


=head2 pause

    ->pause             ( or optional: sleep )

wait for key pressed, useful for shell scripts


=head2 quit

    ->quit          ( or optional: exit stop close )

exit shell 


=head2 wait

    ->wait $milliseconds
    e.g. ->wait 2000

wait for $milliseconds, useful for shell scripts


=head1 AUTHOR

Frank B�hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl, ROBO, ROBO documentation

=cut 


#################################################################################
# this tool is under version management
my $VERSION = q$Revision: 1.1 $;
my $HEADER  = q$Header: TSG4/ROBO_client_shell.pl 1.1 2013/09/30 21:06:10ICT Boehm Frank (DC/PAR) (BM7ZSI) develop  $;
#################################################################################

BEGIN
{
    # add directories to search path for perl modules    
    unshift @INC, './../Engine/modules/';
}	

use File::Basename;
use staeubli;

use strict;
system("Color 8A");

my ($str,$text);
my ($status, $input);

open ( LOG, ">ROBO_shell_log.txt" );     # open shell logfile
rat_connect('10.10.90.1',22);

w2log(" ROBO shell $VERSION, try help for details\n\n->");

while ($input = <STDIN>){
    print LOG "$input";
    last if ($input =~ /^(exit|quit|stop|close)\s*$/i);
    run_command($input);
}
sleep(3);
#Write_server("exit");
rat_disconnect();

w2log("\nROBO shell stopped :o)\n\n");

close (LOG);
system('pause');

################
#  subroutines
################

sub run_command{
    my $input = shift;
    chomp($input); # cut off newline

    if ($input =~ /^(run|call|execute) (.+)/i){w2log("running file\n->"); run_file($2);w2log("\n->");}
    elsif ($input =~ /^(wait|sleep) (.+)/i){ wait_ms($2);}
    elsif ($input =~ /^help/i){w2log("  available commands:\n  help, run, wait, pause, quit\n  and all ROBO functions listed in html help\n->");}
    elsif ($input =~ /^pause/i){system('pause');w2log("\n->");}
    else{
        # execute $input as perl copmmand and get return values
        #my @result = eval($input);
		
		my $result;
		($status,$result) = rat_transmit($input);
        my ($val,$refval);
        #check if at least one return value was there
        if (defined ($result)) {
                w2log("$result");
        }
        else {w2log("? unknown command: $input");}
        w2log("\n->");
    }
}

sub run_file{
  my $file = shift;
  my $line;
  open ( IN, "<$file" ); 
  while ($line = <IN>){
    if ($line =~ /^->(.+)/) {w2log($1."\n");run_command($1);}
  }
}

sub w2log{
    my $text = shift;
    print LOG "$text";
    print "$text";
}

sub wait_ms{
    my $time = shift;    
    w2log("sleeping for $time milliseconds");
    if ( $time > 0) {$time = $time/1000;}
    select(undef, undef, undef, $time);   #sleep for X ms
    w2log("\n->");
}


