
#################################################################################
# this tool is under version management
my $VERSION = q$Revision: 1.2 $;
my $HEADER  = q$Header: TSG4/TSG4_RFID_writer.pl 1.2 2014/11/04 14:48:07ICT Boehm Frank (DC/PAR) (BM7ZSI) develop  $;
#################################################################################

use Tk;
use Tk::BrowseEntry;
use strict;
use warnings;

my $Toolversion = "TSG4_RFID_writer ($VERSION)";      # Tool version number

BEGIN { 
    # add directories to search path for perl modules    
    use File::Spec;
    use File::Basename;
    
    my $addpath = File::Spec->rel2abs(dirname(__FILE__)) . "/../Engine/modules";
    unshift @INC, $addpath;

}
use tsg4;
use tsg4_bl;
use tsg4_canfr;
use tsg4_dvm;
use tsg4_klin;
use tsg4_pas;
use tsg4_rc;
use tsg4_sq;
use tsg4_tr;
use tsg4_trc;
use tsg4_trg;
use tsg4_ubat;
use tsg4_via;
use tsg4_wl;
#use tsg4_lct64;
#use tsg4_rdec;
#use tsg4_spdt;

my ($status,$ret);
my ($main, $ButtonFrame, $display_txt,$device,$lot,$startnr,$do_print);
my($stat, $HWSerialNumbers, $CANChannels);
my ($text,$cust,$gen,$class,$SN,$ver,$sample,$man);
$text=$cust=$gen=$class=$SN=$ver=$sample=$man='';
	
################################
# create those nice TK widgets #
################################

# create main window 'main'
$main = MainWindow -> new();

# define minimum size of window 'main'
$main -> minsize( 400, 300 );

# create title in window 'main'
$main -> title ( "write TSG4 harness RFID tag information $VERSION" );


my $CANHW_Frame = $main -> Frame() -> pack( "-pady" => 5 );

my ($CANHWText,$CANchannelText);

  
  
# create label in window 'main'
$main -> Label( "-text" => "press READ, edit entries, then press WRITE",
                "-font" => "{MS Sans Serif} 10 bold",
         )
      -> pack( "-pady" => 10 );

my $text_Frame = $main -> Frame() -> pack( "-pady" => 5 , "-padx" => 10);
my $cust_Frame = $main -> Frame() -> pack( "-pady" => 5 , "-padx" => 10);
my $gen_Frame = $main -> Frame() -> pack( "-pady" => 5 , "-padx" => 10);
my $class_Frame = $main -> Frame() -> pack( "-pady" => 5 , "-padx" => 10);
my $SN_Frame = $main -> Frame() -> pack( "-pady" => 5 , "-padx" => 10);
my $ver_Frame = $main -> Frame() -> pack( "-pady" => 5 , "-padx" => 10);
my $sample_Frame = $main -> Frame() -> pack( "-pady" => 5 , "-padx" => 10);
my $man_Frame = $main -> Frame() -> pack( "-pady" => 5 , "-padx" => 10);

my $entry_width=8;
# create frame 'ButtonFrame' in window 'main'
$ButtonFrame = $main -> Frame() -> pack( "-pady" => 5 );

$text_Frame -> Label( "-text" => "ASCII Text (Display)     ", "-font" => "{Courier}",)
            -> pack( "-side" => 'left', );
$text_Frame -> Entry(
            "-width" => $entry_width,
            "-textvariable" => \$text, #reference to variable
            "-font" => "{Courier}",
            )-> pack( "-side" => 'left', );            

$cust_Frame -> Label( "-text" => "Harness Customer         ", "-font" => "{Courier}", )
            -> pack( "-side" => 'left', );
$cust_Frame -> Entry(
            "-width" => $entry_width,
            "-textvariable" => \$cust, #reference to variable
            "-font" => "{Courier}",
            )-> pack( "-side" => 'left', ); 	  

$gen_Frame -> Label( "-text" => "Harness Airbaggeneration ", "-font" => "{Courier}", )
            -> pack( "-side" => 'left', );
$gen_Frame -> Entry(
            "-width" => $entry_width,
            "-textvariable" => \$gen, #reference to variable
            "-font" => "{Courier}",
            )-> pack( "-side" => 'left', ); 	  

$class_Frame -> Label( "-text" => "Harness Vehicle/class    ", "-font" => "{Courier}", )
            -> pack( "-side" => 'left', );
$class_Frame -> Entry(
            "-width" => $entry_width,
            "-textvariable" => \$class, #reference to variable
            "-font" => "{Courier}",
            )-> pack( "-side" => 'left', ); 	  

$SN_Frame -> Label( "-text" => "Harness Serial Number    ", "-font" => "{Courier}", )
            -> pack( "-side" => 'left', );
$SN_Frame -> Entry(
            "-width" => $entry_width,
            "-textvariable" => \$SN, #reference to variable
            "-font" => "{Courier}",
            )-> pack( "-side" => 'left', ); 	  

$ver_Frame -> Label( "-text" => "Harness Version          ", "-font" => "{Courier}", )
            -> pack( "-side" => 'left', );
$ver_Frame -> Entry(
            "-width" => $entry_width,
            "-textvariable" => \$ver, #reference to variable
            "-font" => "{Courier}",
            )-> pack( "-side" => 'left', ); 	  

$sample_Frame -> Label( "-text" => "Sample Phase             ", "-font" => "{Courier}", )
            -> pack( "-side" => 'left', );
$sample_Frame -> Entry(
            "-width" => $entry_width,
            "-textvariable" => \$sample, #reference to variable
            "-font" => "{Courier}",
            )-> pack( "-side" => 'left', ); 	  

$man_Frame -> Label( "-text" => "Manufacturing Date       ", "-font" => "{Courier}", )
            -> pack( "-side" => 'left', );
$man_Frame -> Entry(
            "-width" => $entry_width,
            "-textvariable" => \$man, #reference to variable
            "-font" => "{Courier}",
            )-> pack( "-side" => 'left', ); 	  


# create 'exit' button
$ButtonFrame -> Button
  (
  "-text" => "E X I T",
  "-command" => sub
    {exit}
  )
-> pack ("-side" => 'right',"-ipadx" => 20,"-ipady" => 20,"-pady" => 30,"-padx" => 50);


# create button
$ButtonFrame -> Button
  (
  "-text" => "READ TAG",
  "-command" => sub
    { # execute when button is pressed  
        w2display("reading TAG data\n");
        read_TAG();

    }
  )
-> pack ("-side" => 'left',"-ipadx" => 20,"-ipady" => 20,"-pady" => 30,"-padx" => 50);

# create button
$ButtonFrame -> Button
  (
  "-text" => "WRITE TAG",
  "-command" => sub
    { # execute when button is pressed  
    
      my $answer = $main->messageBox(
                '-icon'    => "question", #qw/error info question warning/
                '-type'    => "YesNo", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'please confirm overwriting of TAG data',
                '-message' => "do you really want to overwrite existing TAG data ?"
            );
      
      if ($answer eq "Yes"){
        w2display("writing TAG data\n");
        write_TAG();
      }

    }
  )
-> pack ("-side" => 'right',"-ipadx" => 20,"-ipady" => 20,"-pady" => 30,"-padx" => 50);

# create label in window 'main'
$main -> Label( "-textvariable" => \$display_txt, #reference to $display_txt
                "-font" => "{MS Sans Serif} 10 bold",
         )
      -> pack( "-pady" => 10 );




#++++++++++++++++++++++++++++++++++++++++++++++
########################## MAIN ###############
# the MainLoop is used by perlTK, when it is called all widgets are created and the
# connected actions are done (e.g. when you press a button)

open ( LOG,">TSG4_RFID_writer_log.txt" ) or die "Couldn't open >TSG4_RFID_writer_log.txt : $@";
LOG->autoflush(1);
# create logfile in chosen directory
w2log("######################################################################\n");
w2log("      $Toolversion logfile\n");
w2log("######################################################################\n");

my %CANHWChannels;
#get the available CAN hardware details 
$status = tsg4_start( );
($stat, $HWSerialNumbers, $CANChannels) = tsg4_get_CAN_HW_list();


w2log("$stat @$HWSerialNumbers @$CANChannels\n");
  
         #put the details into Hash , to load the details when a particular Hardware is selected
        for(my $i = 0; $i < @$HWSerialNumbers; $i++){
            $CANHWChannels{$$HWSerialNumbers[$i]} = $$CANChannels[$i];
        }   
    
        #return if No hardwares found
if($stat >= 0){
	$CANHWText = $$HWSerialNumbers[0];
	$CANchannelText = 2;
	update_CAN();
	w2log("running with TK\n");
	MainLoop;
}
else{
    w2log("\nERROR: No CAN Hardware connected\n");
}

w2log("\n######################################################################\n");
w2log(" END OF LOGFILE\n");

close (LOG);

#-------------------- MAIN end ---------------#
#++++++++++++++++++++++++++++++++++++++++++++++


sub update_CAN{
	$CANHW_Frame -> Label( "-text" => "TSG4 is connected to CAN HW ID: ", )
            -> pack( "-side" => 'left', );

# better with BrowseEntry?
	   my $serial;

	my $CANchannel = $CANHW_Frame -> BrowseEntry
	  (
	  "-variable" => \$CANchannelText,
	  "-autolimitheight"      => 1,
	  "-autolistwidth"        => 1,
	  "-width"        => 5,
	  "-choices"	  => [1..$CANHWChannels{$CANHWText}],
	  "-browsecmd" => sub
	    {
	   # $CANHWText = $serial;
	   print"$CANchannelText\n";
	    }
	  );

	my $CANHW = $CANHW_Frame -> BrowseEntry
	  (
	  "-variable" => \$CANHWText,
	  "-autolimitheight"      => 1,
	  "-autolistwidth"        => 1,
	  "-width"        => 7,
	  "-choices"	  => $HWSerialNumbers,
	  "-browsecmd" => sub
	    {
	   # $CANHWText = $serial;
	   print"$CANHWText\n";
	   $CANchannel -> configure("-choices"	  => [1..$CANHWChannels{$CANHWText}]);
	    }
	  );
	$CANHW
	-> pack
	  (
	  "-side" => 'left',
	  );
	
	$CANHW_Frame -> Label( "-text" => "CAN channel: ", )
            -> pack( "-side" => 'left', );

	$CANchannel
	-> pack
	  (
	  "-side" => 'left',
	  );

	
}


sub write_TAG{
	my $lot = shift;
	my $device = shift;
	my $start = shift;
	
	my $UID;

	$status  = tsg4_init( $CANchannelText, $CANHWText );
	tsg4_wait_ms(100);
	if (check_reader() ){
		tsg4_wait_ms(100);
		
		($status,$UID) = rc_write_RFID_text(1,$text,$cust,$gen,$class,$SN,$ver,$sample,$man);
	
		w2log("\nwriting RFID tag ID      - $UID\n");
		w2log("--------------------------------------\n");
		w2log("ASCII Text (Display)     - $text\n");
		w2log("Harness Customer         - $cust\n");
		w2log("Harness Airbaggeneration - $gen\n");
		w2log("Harness Vehicle/class    - $class\n");
		w2log("Harness Serial Number    - $SN\n");
		w2log("Harness Version          - $ver\n");
		w2log("Sample Phase             - $sample\n");
		w2log("Manufacturing Date       - $man\n\n");
		 	
		w2display("wrote TAG\n"); 	
	}
}

sub read_TAG{
	my $lot = shift;
	my $device = shift;
	my $start = shift;
	
	my $UID;

	$status  = tsg4_init( $CANchannelText, $CANHWText );
	tsg4_wait_ms(100);
	if (check_reader() ){
		tsg4_wait_ms(100);
		($status,$text,$cust,$gen,$class,$SN,$ver,$sample,$man,$UID) = rc_read_RFID_text(1);
		 
		w2log("\nreading RFID tag ID      - $UID\n");
		w2log("--------------------------------------\n");
		w2log("ASCII Text (Display)     - $text\n");
		w2log("Harness Customer         - $cust\n");
		w2log("Harness Airbaggeneration - $gen\n");
		w2log("Harness Vehicle/class    - $class\n");
		w2log("Harness Serial Number    - $SN\n");
		w2log("Harness Version          - $ver\n");
		w2log("Sample Phase             - $sample\n");
		w2log("Manufacturing Date       - $man\n\n");
		 	
		w2display("read TAG $UID\n"); 	
	}
}

sub check_reader{
	my ($status, $UID, $SN, $SW, $Type) = rc_read_RFID_info(1);
	# check reader is ok
	if ( $Type =~ /Error/){
	    w2log("RFID reader error, trying to configure reader...\n");	
	    tsg4_wait_ms(500);	
		($status,$text) = rc_write_RFID_transponder_type(1);
		w2log("configuration result: $text\n");
	    tsg4_wait_ms(500);	
		($status, $UID, $SN, $SW, $Type) = rc_read_RFID_info(1);
		if ( $Type =~ /Error/){
	        w2display( "RFID reader error");
			return 0;
		}
	}
	w2log("RFID reader: UID $UID, SN $SN, SW $SW, type $Type\n");
	#check tag detected (harness connected)
	if($UID =~ /Error/){
		w2display("NO TAG detected\n"); 
		return 0;	
	}	
	return 1;
}
	






#################################
# Logfile handling
##################################
sub w2log{
     my $text = shift;
     print LOG $text;
     print $text;
}


sub w2display{
     my $text = shift;
     print LOG $text;
     print $text;
     $display_txt = $text;
     $main->update();
}


    
