

#################################################################################
# this tool is under version management
my $VERSION = q$Revision: 1.9 $;
my $HEADER  = q$Header: TSG4/TSG4_SN_writer.pl 1.9 2016/06/07 22:06:39ICT Boehm Frank (DC/PAR) (BM7ZSI) develop  $;
#################################################################################

package LIFT_config;
our $LIFT_Testbench;
1;

use Tk;
use Tk::BrowseEntry;
use strict;
use warnings;
use Win32::OLE;

my $Toolversion = "TSG4_SN_writer ($VERSION)";      # Tool version number

BEGIN { 
    # add directories to search path for perl modules    
    use File::Spec;
    use File::Basename;
    
    my $addpath = File::Spec->rel2abs(dirname(__FILE__)) . "/../Engine/modules";
    unshift @INC, $addpath;

}
use LIFT_general;
use LIFT_stub;

use tsg4;
use tsg4_bl;
use tsg4_canfr;
use tsg4_dvm;
use tsg4_klin;
use tsg4_pas;
use tsg4_rc;
use tsg4_sq;
use tsg4_tr;
use tsg4_trc;
use tsg4_trg;
use tsg4_ubat;
use tsg4_via;
use tsg4_wl;
use tsg4_lct64;
#use tsg4_rdec;
#use tsg4_spdt;

my $log_path = dirname($0);

# just define some Engine variables
#our $ProjectDefaults = $LIFT_config::LIFT_ProjectDefaults;
our $ProjectDefaults = '';
our $opt_offline     = 0;    # $opt_offline = 1; # set offline mode
our $opt_silent      = 0;    # $opt_silent = 1; # set silent mode (logging will not print)
our $save_name;              # name of log/report/result-files, given from user or Testlist will be taken
our $CURRENT_TC = 'test';

STUB_init();

my ($status,$ret);
my ($main, $ButtonFrame, $display_txt,$device,$lot,$startnr,$do_print);
my($stat, $HWSerialNumbers, $CANChannels);
my $printer_config_file = '.\TSG4_label.lbx';

    use constant {
        PAS  => 'PAS',
        DVM  => 'DVMscanner',
        TRC  => 'TRCscanner',
        SQ   => 'SQUIBdecade',
        RC   => 'RackCPU(1)',
        BL   => 'BeltLock',
        WL   => 'WL/DIO(1)',
        WLEE   => 'WLextender(1)',
        WLFULL => 'WL + extender(2*1)',
        UBAT   => 'Ubat(1)',
        VIA   => 'REFerence(1)',
        CAN   => 'CAN/Flexray(1)',
        KLIN   => 'Kline/LIN(1)',
        TRG   => 'TRIGGER(1)',
        LCT   => 'LCT64(1)',
        PRITT   => 'PRITT(read SN)',
    };


	my $singledevice=1;
	
################################
# create those nice TK widgets #
################################

# create main window 'main'
$main = MainWindow -> new();

# define minimum size of window 'main'
$main -> minsize( 400, 300 );

# create title in window 'main'
$main -> title ( "write TSG4 device serial number $VERSION" );


my $CANHW_Frame = $main -> Frame() -> pack( "-pady" => 5 );

my ($CANHWText,$CANchannelText);

  
  
# create label in window 'main'
$main -> Label( "-text" => "select lot number, devicetype and starting number and press WRITE",
                "-font" => "{MS Sans Serif} 10 bold",
         )
      -> pack( "-pady" => 10 );

my $SN_Frame = $main -> Frame() -> pack( "-pady" => 5 , "-padx" => 10);
my $device_Frame = $main -> Frame() -> pack( "-pady" => 5 , "-padx" => 10);
my $OptionFrame = $main -> Frame() -> pack( "-pady" => 20 );
	  
# create frame 'ButtonFrame' in window 'main'
$ButtonFrame = $main -> Frame() -> pack( "-pady" => 5 );

	$SN_Frame -> Label( "-text" => "LOT number: ", )
            -> pack( "-side" => 'left', );
   $SN_Frame -> Entry(
            "-width" => 3,
            "-textvariable" => \$lot, #reference to variable
            )-> pack( "-side" => 'left', );            
	$SN_Frame -> Label( "-text" => "starting number: ", )
            -> pack( "-side" => 'left', );
   $SN_Frame -> Entry(
            "-width" => 5,
            "-textvariable" => \$startnr, #reference to variable
            )-> pack( "-side" => 'left', ); 	  

	$SN_Frame -> Label( "-text" => "device: ", )
            -> pack( "-side" => 'left', );
	$SN_Frame -> BrowseEntry
	  (
	  "-variable" => \$device,
	  "-autolimitheight"      => 1,
	  "-autolistwidth"        => 1,
	  "-width"        => 20,
	  "-listheight"        => 13,
	  "-choices"	  => [PAS,DVM,TRC,SQ,BL,RC,WL,WLEE,WLFULL,UBAT,VIA,CAN,KLIN,TRG,LCT,PRITT]
	  )	-> pack
	  (
	  "-side" => 'left',
	  );


	$device_Frame -> Label( "-text" => "single device number, for deviced tagged with (1): ", )
            -> pack( "-side" => 'left', );
   $device_Frame -> Entry(
            "-width" => 2,
            "-textvariable" => \$singledevice, #reference to variable
            )-> pack( "-side" => 'left', ); 	  
  


   $OptionFrame -> Checkbutton(
            "-text" => "print labels",
            "-variable" => \$do_print, #reference to variable
            )-> pack( "-side" => 'left', ); 	

   $OptionFrame -> Radiobutton(
            "-text" => "normal",
            "-variable" => \$printer_config_file, #reference to variable
            "-value" => '.\TSG4_label.lbx',
            )-> pack( "-side" => 'left', ); 	

   $OptionFrame -> Radiobutton(
            "-text" => "small",
            "-variable" => \$printer_config_file, #reference to variable
            "-value" => '.\TSG4_label_small.lbx',
            )-> pack( "-side" => 'left', ); 	
                        
#my $printer_config_file = '.\TSG4_label.lbx';            

# create 'exit' button
$ButtonFrame -> Button
  (
  "-text" => "E X I T",
  "-command" => sub
    {exit}
  )
-> pack ("-side" => 'right',"-ipadx" => 20,"-ipady" => 20,"-pady" => 10,"-padx" => 50);


# create 'create' button
$ButtonFrame -> Button
  (
  "-text" => "WRITE SN",
  "-command" => sub
    { # execute when button is pressed  
        w2display("writing serial numbers\n");
        write_SN($lot,$device,$startnr);

    }
  )
-> pack ("-side" => 'right',"-ipadx" => 20,"-ipady" => 20,"-pady" => 10,"-padx" => 50);


# create label in window 'main'
$main -> Label( "-textvariable" => \$display_txt, #reference to $display_txt
                "-font" => "{MS Sans Serif} 10 bold",
         )
      -> pack( "-pady" => 10 );




#++++++++++++++++++++++++++++++++++++++++++++++
########################## MAIN ###############
# the MainLoop is used by perlTK, when it is called all widgets are created and the
# connected actions are done (e.g. when you press a button)

open ( LOG,">SN_writer_log.txt" ) or die "Couldn't open >SN_writer_log.txt : $@";
LOG->autoflush(1);
# create logfile in chosen directory
w2log("######################################################################\n");
w2log("      $Toolversion logfile\n");
w2log("######################################################################\n");

my %CANHWChannels;
#get the available CAN hardware details 
$status = tsg4_start( );
($stat, $HWSerialNumbers, $CANChannels) = tsg4_get_CAN_HW_list();


w2log("$stat @$HWSerialNumbers @$CANChannels\n");
  
         #put the details into Hash , to load the details when a particular Hardware is selected
        for(my $i = 0; $i < @$HWSerialNumbers; $i++){
            $CANHWChannels{$$HWSerialNumbers[$i]} = $$CANChannels[$i];
        }   
    
        #return if No hardwares found
if($stat >= 0){
	$CANHWText = $$HWSerialNumbers[0];
	$CANchannelText = 1;
	update_CAN();
	w2log("running with TK\n");
	MainLoop;
}
else{
    w2log("\nERROR: No CAN Hardware connected\n");
}

w2log("\n######################################################################\n");
w2log(" END OF LOGFILE\n");

close (LOG);

#-------------------- MAIN end ---------------#
#++++++++++++++++++++++++++++++++++++++++++++++


sub update_CAN{
	$CANHW_Frame -> Label( "-text" => "TSG4 is connected to CAN HW ID: ", )
            -> pack( "-side" => 'left', );

# better with BrowseEntry?
	   my $serial;

	my $CANchannel = $CANHW_Frame -> BrowseEntry
	  (
	  "-variable" => \$CANchannelText,
	  "-autolimitheight"      => 1,
	  "-autolistwidth"        => 1,
	  "-width"        => 5,
	  "-choices"	  => [1..$CANHWChannels{$CANHWText}],
	  "-browsecmd" => sub
	    {
	   # $CANHWText = $serial;
	   print"$CANchannelText\n";
	    }
	  );

	my $CANHW = $CANHW_Frame -> BrowseEntry
	  (
	  "-variable" => \$CANHWText,
	  "-autolimitheight"      => 1,
	  "-autolistwidth"        => 1,
	  "-width"        => 7,
	  "-choices"	  => $HWSerialNumbers,
	  "-browsecmd" => sub
	    {
	   # $CANHWText = $serial;
	   print"$CANHWText\n";
	   $CANchannel -> configure("-choices"	  => [1..$CANHWChannels{$CANHWText}]);
	    }
	  );
	$CANHW
	-> pack
	  (
	  "-side" => 'left',
	  );
	
	$CANHW_Frame -> Label( "-text" => "CAN channel: ", )
            -> pack( "-side" => 'left', );

	$CANchannel
	-> pack
	  (
	  "-side" => 'left',
	  );

	
}


sub write_SN{
	my $lot = shift;
	my $device = shift;
	my $start = shift;
	
	my $HW_ID;
	my $printer_handle;
	my %deviceIDs;

	%deviceIDs=();

	 $status  = tsg4_init( $CANchannelText, $CANHWText );
	 tsg4_wait_ms(1000);
	 ($status,$HW_ID) = rc_get_HW_id(1);
	
	 if ($device eq PAS){
		my $pas;
		for($pas=1;$pas<=18;$pas=$pas+2){
		    my $idtext= sprintf("%03dP%04d",$lot,$start);
		     tsg4_wait_ms(10);
		     $status = pas_write_SN( $pas,$idtext);
		     $start++;
		}
		for($pas=1;$pas<=18;$pas++){
		     tsg4_wait_ms(10);
		     ($status, $HW_ID) = pas_get_HW_id($pas);
		     if($HW_ID =~ /^\d{3}\w\d{4}$/){
		     	$deviceIDs{$HW_ID}=1;
		     }
#		     tsg4_wait_ms(10);
#		     ($status, $HW_ID) = pas_get_firmware($pas);
		}
		tsg4_wait_ms(10); 	
	 }

	 elsif ($device eq SQ){
		my $sq;
		for($sq=1;$sq<=28;$sq=$sq+2){
			my $idtext= sprintf("%03dZ%04d",$lot,$start);
		     tsg4_wait_ms(20);
		     $status = sq_write_SN( $sq,$idtext);
		     tsg4_wait_ms(20);
		     $status = sq_write_SN( $sq+1,$idtext);
		     $start++;
		}
		for($sq=1;$sq<=28;$sq++){
		     tsg4_wait_ms(20);
		     ($status, $HW_ID) = sq_get_HW_id($sq);
		     if($HW_ID =~ /^\d{3}\w\d{4}$/){
		     	$deviceIDs{$HW_ID}=1;
		     }
#		     tsg4_wait_ms(20);
#		     ($status, $HW_ID) = sq_get_firmware($sq);
		}
		tsg4_wait_ms(10);	 	
	 }	


	 elsif ($device eq DVM){
		my $dev;
		for($dev=1;$dev<=2;$dev++){
			my $idtext= sprintf("%03dD%04d",$lot,$start);
		     tsg4_wait_ms(50);
		     $status = dvm_write_SN( $dev,$idtext);
		     $start++;
		}
		for($dev=1;$dev<=2;$dev++){
		     tsg4_wait_ms(50);
		     ($status, $HW_ID) = dvm_get_HW_id($dev);
		     if($HW_ID =~ /^\d{3}\w\d{4}$/){
		     	$deviceIDs{$HW_ID}=1;
		     }
#		     tsg4_wait_ms(20);
#		     ($status, $HW_ID) = dvm_get_firmware($dev);
		}
		tsg4_wait_ms(10);	 	
	 }	

	 elsif ($device eq TRC){
		my $dev;
		for($dev=1;$dev<=8;$dev++){
			my $idtext= sprintf("%03dT%04d",$lot,$start);
		     tsg4_wait_ms(50);
		     $status = trc_write_SN( $dev,$idtext);
		     $start++;
		}
		for($dev=1;$dev<=8;$dev++){
		     tsg4_wait_ms(50);
		     ($status, $HW_ID) = trc_get_HW_id($dev);
		     if($HW_ID =~ /^\d{3}\w\d{4}$/){
		     	$deviceIDs{$HW_ID}=1;
		     }
#		     tsg4_wait_ms(20);
#		     ($status, $HW_ID) = trc_get_firmware($dev);
		}
		tsg4_wait_ms(10);	 	
	 }	

	 elsif ($device eq TRG){
		my $dev=$singledevice;
			my $idtext= sprintf("%03dY%04d",$lot,$start);
		     tsg4_wait_ms(50);
		     $status = trg_write_SN( $dev,$idtext);
		     $start++;
		     tsg4_wait_ms(50);
		     ($status, $HW_ID) = trg_get_HW_id($dev);
		     if($HW_ID =~ /^\d{3}\w\d{4}$/){
		     	$deviceIDs{$HW_ID}=1;
		     }
#		     tsg4_wait_ms(20);
#		     ($status, $HW_ID) = trg_get_firmware($dev);
		tsg4_wait_ms(10);	 	
	 }	

	 elsif ($device eq BL){
		my $bl;
		for($bl=1;$bl<=18;$bl=$bl+2){
		    my $idtext= sprintf("%03dG%04d",$lot,$start);
		     tsg4_wait_ms(10);
		     $status = bl_write_SN( $bl,$idtext);
		     $start++;
		}
		for($bl=1;$bl<=18;$bl++){
		     tsg4_wait_ms(10);
		     ($status, $HW_ID) = bl_get_HW_id($bl);;
		     if($HW_ID =~ /^\d{3}\w\d{4}$/){
		     	$deviceIDs{$HW_ID}=1;
		     }
#		     tsg4_wait_ms(10);
#		     ($status, $HW_ID) = bl_get_firmware($bl);
		}
		tsg4_wait_ms(10); 	
	 }

	 elsif ($device eq CAN){
		my $dev=$singledevice;
			my $idtext= sprintf("%03dC%04d",$lot,$start);
		     tsg4_wait_ms(10);
		     $status = cf_write_SN( $dev,$idtext);
		     $start++;
		     tsg4_wait_ms(20);
		     ($status, $HW_ID) = cf_get_HW_id($dev);
		     if($HW_ID =~ /^\d{3}\w\d{4}$/){
		     	$deviceIDs{$HW_ID}=1;
		     }
#		     tsg4_wait_ms(20);
#		     ($status, $HW_ID) = cf_get_firmware($dev);
		tsg4_wait_ms(10);	 	
	 }	

	 
	 elsif ($device eq KLIN){
		my $dev=$singledevice;
			my $idtext= sprintf("%03dK%04d",$lot,$start);
		     tsg4_wait_ms(10);
		     $status = kl_write_SN( $dev,$idtext);
		     $start++;
		     tsg4_wait_ms(20);
		     ($status, $HW_ID) = kl_get_HW_id($dev);
		     if($HW_ID =~ /^\d{3}\w\d{4}$/){
		     	$deviceIDs{$HW_ID}=1;
		     }
#		     tsg4_wait_ms(20);
#		     ($status, $HW_ID) = kl_get_firmware($dev);
		tsg4_wait_ms(10);	 	
	 }	 

  
	 elsif ($device eq RC){
		my $dev=$singledevice;
			my $idtext= sprintf("%03dX%04d",$lot,$start);
		     tsg4_wait_ms(10);
		     $status = rc_write_SN( $dev,$idtext);
		     $start++;
		     tsg4_wait_ms(20);
		     ($status, $HW_ID) = rc_get_HW_id($dev);
		     if($HW_ID =~ /^\d{3}\w\d{4}$/){
		     	$deviceIDs{$HW_ID}=1;
		     }
#		     tsg4_wait_ms(20);
#		     ($status, $HW_ID) = rc_get_firmware($dev);
		tsg4_wait_ms(10);	 	
	 }	


	 elsif ($device eq UBAT){
		my $dev=$singledevice;
			my $idtext= sprintf("%03dU%04d",$lot,$start);
		     tsg4_wait_ms(10);
		     $status = ubat_write_SN( $dev,$idtext);
		     $start++;
		     tsg4_wait_ms(20);
		     ($status, $HW_ID) = ubat_get_HW_id($dev);
		     if($HW_ID =~ /^\d{3}\w\d{4}$/){
		     	$deviceIDs{$HW_ID}=1;
		     }
#		     tsg4_wait_ms(20);
#		     ($status, $HW_ID) = ubat_get_firmware($dev);
		tsg4_wait_ms(10);	 	
	 }	
    
  
	 elsif ($device eq VIA){
		my $dev=$singledevice;
			my $idtext= sprintf("%03dB%04d",$lot,$start);
		     tsg4_wait_ms(10);
		     $status = via_write_SN( $dev,$idtext);
		     $start++;
		     tsg4_wait_ms(20);
		     ($status, $HW_ID) = via_get_HW_id($dev);
		     if($HW_ID =~ /^\d{3}\w\d{4}$/){
		     	$deviceIDs{$HW_ID}=1;
		     }
#		     tsg4_wait_ms(20);
#		     ($status, $HW_ID) = via_get_firmware($dev);
		tsg4_wait_ms(10);	 	
	 }	

	 elsif ($device eq WL){
		my $dev=$singledevice;
			my $idtext= sprintf("%03dL%04d",$lot,$start);
		     tsg4_wait_ms(10);
		     $status = wl_write_SN( $dev,$idtext);
		     $start++;
		     tsg4_wait_ms(20);
		     ($status, $HW_ID) = wl_get_HW_id($dev);
		     if($HW_ID =~ /^\d{3}\w\d{4}$/){
		     	$deviceIDs{$HW_ID}=1;
		     }
#		     tsg4_wait_ms(20);
#		     ($status, $HW_ID) = wl_get_firmware($dev);
		tsg4_wait_ms(10);	 	
	 }	

	 elsif ($device eq WLEE){
		my $dev=$singledevice;
		my $extEEsn = 83; # above FW002 it's 83 below FW003 it's 43
			my $EEidtext= sprintf("%03dH%04d",$lot,$start);
	     	$start++;
			tsg4_wait_ms(10);
			$status = tsg4_wl::wl_write_EE($dev,$extEEsn,$EEidtext);
			tsg4_wait_ms(100);
			($status, $HW_ID) = wl_get_INFO($dev,$extEEsn);	 
			tsg4_wait_ms(100);
		     if($HW_ID =~ /^\d{3}\w\d{4}$/){
		     	$deviceIDs{$HW_ID}=1;
		     }
#		     tsg4_wait_ms(20);
#		     ($status, $HW_ID) = wl_get_firmware($dev);
		tsg4_wait_ms(10);	 	
	 }	

	 elsif ($device eq WLFULL){
		my $dev=$singledevice;
		my $idtext= sprintf("%03dL%04d",$lot,$start);
	    tsg4_wait_ms(10);
	    $status = wl_write_SN( $dev,$idtext);
	    tsg4_wait_ms(20);
	    ($status, $HW_ID) = wl_get_HW_id($dev);
	    if($HW_ID =~ /^\d{3}\w\d{4}$/){
	    	$deviceIDs{$HW_ID}=1;
	    }
		tsg4_wait_ms(10);	 	
		my $extEEsn = 83; # above FW002 it's 83 below FW003 it's 43
		my $EEidtext= sprintf("%03dH%04d",$lot,$start);
		tsg4_wait_ms(10);
		$status = tsg4_wl::wl_write_EE($dev,$extEEsn,$EEidtext);
		tsg4_wait_ms(100);
		($status, $HW_ID) = wl_get_INFO($dev,$extEEsn);	 
		tsg4_wait_ms(100);
	    if($HW_ID =~ /^\d{3}\w\d{4}$/){
	    	$deviceIDs{$HW_ID}=1;
	    }
	    $start++;
		tsg4_wait_ms(10);	 	
	 }	
	 elsif ($device eq LCT){
		my $dev=$singledevice;
			my $idtext= sprintf("%03dA%04d",$lot,$start);
		     tsg4_wait_ms(10);
		     $status = lct_write_SN( $dev,$idtext);
		     $start++;
		     tsg4_wait_ms(20);
		     ($status, $HW_ID) = lct_get_HW_id($dev);
		     if($HW_ID =~ /^\d{3}\w\d{4}$/){
		     	$deviceIDs{$HW_ID}=1;
		     }
#		     tsg4_wait_ms(20);
#		     ($status, $HW_ID) = wl_get_firmware($dev);
		tsg4_wait_ms(10);	 	 	
	 }	
	 elsif ($device eq PRITT){
		$HW_ID = get_PRITT_serial();
		if(defined $HW_ID){
			$deviceIDs{$HW_ID}=1;
		}
		tsg4_wait_ms(10);
	 }	

	 else {
	 	w2display("unknown device $device\n"); 	
	 	return;
	 }
	 

	if ($do_print){
		$printer_handle = Win32::OLE -> new ('BrssCom.Document');
		#load configuration
		print "config: $printer_config_file\n";
		$printer_handle -> Open( $printer_config_file );

		foreach my $ID (sort keys %deviceIDs){
		     	$printer_handle -> SetText( 0, $ID );
				$printer_handle -> DoPrint( 0, '0' );
				# print 2 labels for LCT64
				if ($device eq LCT or $device eq VIA){
					$printer_handle -> DoPrint( 0, '0' );
				}
		}
	
		$printer_handle -> Close();
		$printer_handle = undef;
	}
	 	
	w2display("wrote ".join(' ',sort keys %deviceIDs)."\n"); 	
	$startnr+=scalar(keys %deviceIDs);
	$startnr-- if ($device eq WLFULL);
}

#

sub get_PRITT_serial{
	
	use LIFT_PRITT;
	my ($serial,$devInfo_href);

	PRT_init();

	$devInfo_href = PRT_get_device_info();
	 $serial = $devInfo_href->{Serial};
	PRT_exit();
	
	return $serial;
}






#################################
# Logfile handling
##################################
sub w2log{
     my $text = shift;
#     print LOG $text;
     print $text;
}


sub w2display{
     my $text = shift;
#     print LOG $text;
     print $text;
     $display_txt = $text;
     $main->update();
}


    
