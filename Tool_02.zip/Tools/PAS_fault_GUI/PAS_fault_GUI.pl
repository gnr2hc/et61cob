#! /opt/perl5/bin/perl

#################################################################################
# this tool is under version management
my $VERSION = q$Revision: 2.4 $;
my $HEADER  = q$Header: PAS_fault_GUI/PAS_fault_GUI.pl 2.4 2012/02/28 17:20:41ICT Boehm Frank (DC/PAR) (BM7ZSI) develop  $;
#################################################################################

my $addpath;
use File::Basename;
BEGIN
{
    use Config;
    use File::Spec;
    
    $addpath = File::Spec->rel2abs(dirname(__FILE__)) . "/../Engine/modules/DLLs/IDEFIX";
    $addpath =~ s/\//\\/g; # replace all slashes with backslahes
    
    my $perl56 = $addpath . "\\Perl56";     #perl 5.6(32-bit) DLL directory
    my $win32 = $addpath . "\\Win32";       #perl 5.12, 32-bit DLL directory
    my $win64 = $addpath . "\\Win64";       #perl 5.12, 64-bit DLL directory

    if($] =~ m/5.006/i){        #if Perl version is 5.6
        unshift @INC, ($addpath, $perl56);      #Include IDEFIX.pm from Root directory, Load IDEFIX.dll from "Perl56" 
        $ENV{PATH} = $win32 . ";$ENV{PATH}";    #Load IdefixInterface.dll from "Win32"
        
    } elsif($] =~ m/5.012/i) {  #if Perl version is 5.12
        if ($Config{'archname'} =~ m/x64/i){        #check the bitness of perl (32-bit or 64-bit)
            unshift @INC, ($addpath, $win64);       #Include IDEFIX.pm from Root directory, Load IDEFIX.dll from "Win64"
            $ENV{PATH} = $win64 . ";$ENV{PATH}";    #Load IdefixInterface.dll from "Win64"
        }
        else{
            unshift @INC, ($addpath, $win32);       #Include IDEFIX.pm from Root directory, Load IDEFIX.dll from "Win32"
            $ENV{PATH} = $win32 . ";$ENV{PATH}";    #Load IdefixInterface.dll from "Win32"
        }
    }
}
 
#Add libraries
use strict;
#use warnings;
use IDEFIX;
use Tk;
use Tk::BrowseEntry;
use Switch;

#Main Window
my $main;

#browse Open File Entries
my ($ButtonBrowseFile,$HelpString,$OpenFileString,$TextBoxOpenFile);
my ($value, $FaultValue, $Sel_Button);
my (@LabelsVar,@BackgrVar);

#Radion Buttons
my @RadioButtons;

my $IdefixSelected;
my $IdefixInitFlag;
my $IDXNumber;

my @VarToHideButtons;

my @PPSConfiguredValues;
my $MaxValuerOfFault = 0xffff;

#Buttons
my ($Button_1_Block_1,$Button_2_Block_1,$Button_3_Block_1,$Button_4_Block_1, $Button_5_Block_1,$Button_6_Block_1,$Button_7_Block_1,$Button_8_Block_1,$Button_9_Block_1,$Button_10_Block_1,$Button_11_Block_1,$Button_12_Block_1,$Button_13_Block_1);
my ($Button_1_Block_2,$Button_2_Block_2,$Button_3_Block_2,$Button_4_Block_2, $Button_5_Block_2,$Button_6_Block_2,$Button_7_Block_2,$Button_8_Block_2,$Button_9_Block_2,$Button_10_Block_2,$Button_11_Block_2,$Button_12_Block_2,$Button_13_Block_2);
my ($Button_1_Block_3,$Button_2_Block_3,$Button_3_Block_3,$Button_4_Block_3, $Button_5_Block_3,$Button_6_Block_3,$Button_7_Block_3,$Button_8_Block_3,$Button_9_Block_3,$Button_10_Block_3,$Button_11_Block_3,$Button_12_Block_3,$Button_13_Block_3);
my ($Button_1_Block_4,$Button_2_Block_4,$Button_3_Block_4,$Button_4_Block_4, $Button_5_Block_4,$Button_6_Block_4,$Button_7_Block_4,$Button_8_Block_4,$Button_9_Block_4,$Button_10_Block_4,$Button_11_Block_4,$Button_12_Block_4,$Button_13_Block_4);
my ($Button_1_Block_5,$Button_2_Block_5,$Button_3_Block_5,$Button_4_Block_5, $Button_5_Block_5,$Button_6_Block_5,$Button_7_Block_5,$Button_8_Block_5,$Button_9_Block_5,$Button_10_Block_5,$Button_11_Block_5,$Button_12_Block_5,$Button_13_Block_5);
my ($Button_1_Block_6,$Button_2_Block_6,$Button_3_Block_6,$Button_4_Block_6, $Button_5_Block_6,$Button_6_Block_6,$Button_7_Block_6,$Button_8_Block_6,$Button_9_Block_6,$Button_10_Block_6,$Button_11_Block_6,$Button_12_Block_6,$Button_13_Block_6);
my ($Button_1_Block_7,$Button_2_Block_7,$Button_3_Block_7,$Button_4_Block_7, $Button_5_Block_7,$Button_6_Block_7,$Button_7_Block_7,$Button_8_Block_7,$Button_9_Block_7,$Button_10_Block_7,$Button_11_Block_7,$Button_12_Block_7,$Button_13_Block_7);
my ($Button_1_Block_8,$Button_2_Block_8,$Button_3_Block_8,$Button_4_Block_8, $Button_5_Block_8,$Button_6_Block_8,$Button_7_Block_8,$Button_8_Block_8,$Button_9_Block_8,$Button_10_Block_8,$Button_11_Block_8,$Button_12_Block_8,$Button_13_Block_8);

#Buttons Variables
my (@SelectedButtons, @ButtonTextVars);
my $Buttonswidth = 18;

my $LOG;
my $Toolversion = "PAS_Fault_GUI ($VERSION)";      # Tool version number

# create main window 'main'
$main = MainWindow -> new();

# create title in window 'main'
$main -> title ( "Create PAS Faults GUI $VERSION" );

# create 'browse open file' button for ifc Files
$ButtonBrowseFile = $main -> Button
(
"-text" => "Browse Idefix Config file ","-width" => $Buttonswidth,
"-command" => sub
  {
      #store old variable's value
      $HelpString =  $OpenFileString;
      my $ReadHelp;
      my $index=0;

      my $help;
      
      # browse for file
      $OpenFileString = $main ->getOpenFile
      (
            "-filetypes"  =>
            [
            ["Idefix Config Files", '.ifc'],
            ["All files", '.*']
            ],
            "-title"      => "Select file to load Idefix Configurations",
            "-defaultextension" => 'ifc',
      );
    if ($OpenFileString)    {
        w2log( "\n $OpenFileString was chosen \n");
        if(open(IN,"<$OpenFileString")) {                 
            while(<IN>) {   
                #search for <pasName> e.g. <pasName>PAS1_UFSL</pasName>
                # empty = <pasName />
                if( $_ =~ /<pasName>(.*)<\/pasName>/ or $_ =~ /<pasName(.*)\/>/)    {    
                    $help = $1;
                    
                    #check for pasEnable 

                    #    <pasName>PAS3</pasName>
                    #    <pasScript>pas5.c</pasScript>
                    #    <pasEnabled>false</pasEnabled>

                    my $line=<IN>;
                    $line=<IN>;
                    if( $line=~ /<pasEnabled>(.*)<\/pasEnabled>/ )    {
                        if (lc($1) eq "false"){
                            w2log( "setting PAS $help to disabled");
                            $BackgrVar[$index]="gray";
                        }
                        else{w2log( "setting PAS $help to active");$BackgrVar[$index]="green";}
                    }
                    else{w2log( "could not find PAS enable staus for $help");}
                    
                    #store Name of found Passes
                    $LabelsVar[$index] = $help;                                         
                    
                    if($help =~ /(PPS)(\w+)/)
                    {   
                        if($help =~ /(PPS1)(\w+)/)
                        {   
                            $VarToHideButtons[$index] = 1;
                            w2log( "found PAS: $help (PPS 1)");
                        }
                        else {
                            if($help =~ /(PPS2)(\w+)/)
                            {   
                                $VarToHideButtons[$index] = 2;
                                w2log( "found PAS: $help (PPS 2 )");
                            }
                            else {
                                $VarToHideButtons[$index] = 2;
                                w2log( "found PAS: $help (PPS x?)");
                            }
                        }    
                    }                    
                    else{
                        $VarToHideButtons[$index] = 0;
                        w2log( "found PAS: $help"); 
                    }
                    $index++;
                }
            }
            close (IN);
            ShowNewLabelText();
            showHideButtons();
        }   
        else {
            w2log( "File: $OpenFileString cannot be open");
        }
    }
    else  {
        #restore old variable value
        $OpenFileString = $HelpString;
        w2log( "no filename inserted!");
    }
  }
);      

#Open File Textbox
$TextBoxOpenFile = $main -> Entry( "-textvariable" => \$OpenFileString,"-width" => $Buttonswidth*3 );

#create Labels
my $label1 = $main -> Label (-text=>'PAS 0',-relief=>'groove',-background=>"green");
my $label2 = $main -> Label (-text=>'PAS 1',-relief=>'groove',-background=>"green");
my $label3 = $main -> Label (-text=>'PAS 2',-relief=>'groove',-background=>"green");
my $label4 = $main -> Label (-text=>'PAS 3',-relief=>'groove',-background=>"green");
my $label5 = $main -> Label (-text=>'PAS 4',-relief=>'groove',-background=>"green");
my $label6 = $main -> Label (-text=>'PAS 5',-relief=>'groove',-background=>"green");
my $label7 = $main -> Label (-text=>'PAS 6',-relief=>'groove',-background=>"green");
my $label8 = $main -> Label (-text=>'PAS 7',-relief=>'groove',-background=>"green");

#create Buttons, 8 Blocks x 9 Faults = 72
$Button_1_Block_1=$main ->Button("-textvariable"=>\$ButtonTextVars[0],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(1,1+($IdefixSelected*8));});
$Button_2_Block_1=$main ->Button("-textvariable"=>\$ButtonTextVars[1],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(2,1+($IdefixSelected*8));});
$Button_3_Block_1=$main ->Button("-textvariable"=>\$ButtonTextVars[2],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(3,1+($IdefixSelected*8));});
$Button_4_Block_1=$main ->Button("-textvariable"=>\$ButtonTextVars[3],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(4,1+($IdefixSelected*8));});
$Button_5_Block_1=$main ->Button("-textvariable"=>\$ButtonTextVars[4],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(5,1+($IdefixSelected*8));});
$Button_6_Block_1=$main ->Button("-textvariable"=>\$ButtonTextVars[5],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(6,1+($IdefixSelected*8));});
$Button_7_Block_1=$main ->Button("-textvariable"=>\$ButtonTextVars[6],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(7,1+($IdefixSelected*8));});
$Button_8_Block_1=$main ->Button("-textvariable"=>\$ButtonTextVars[7],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(8,1+($IdefixSelected*8));});
$Button_9_Block_1=$main ->Button("-textvariable"=>\$ButtonTextVars[8],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(9,1+($IdefixSelected*8));});
$Button_10_Block_1=$main->Button("-textvariable"=>\$ButtonTextVars[9],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(10,1+($IdefixSelected*8));});
$Button_11_Block_1=$main->Button("-textvariable"=>\$ButtonTextVars[10],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(11,1+($IdefixSelected*8));});
$Button_12_Block_1=$main->Button("-textvariable"=>\$ButtonTextVars[11],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(12,1+($IdefixSelected*8));});
$Button_13_Block_1=$main->Button("-textvariable"=>\$ButtonTextVars[12],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(13,1+($IdefixSelected*8));});

$Button_1_Block_2=$main ->Button("-textvariable"=>\$ButtonTextVars[0],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(1,2+($IdefixSelected*8));});
$Button_2_Block_2=$main ->Button("-textvariable"=>\$ButtonTextVars[1],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(2,2+($IdefixSelected*8));});
$Button_3_Block_2=$main ->Button("-textvariable"=>\$ButtonTextVars[2],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(3,2+($IdefixSelected*8));});
$Button_4_Block_2=$main ->Button("-textvariable"=>\$ButtonTextVars[3],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(4,2+($IdefixSelected*8));});
$Button_5_Block_2=$main ->Button("-textvariable"=>\$ButtonTextVars[4],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(5,2+($IdefixSelected*8));});
$Button_6_Block_2=$main ->Button("-textvariable"=>\$ButtonTextVars[5],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(6,2+($IdefixSelected*8));});
$Button_7_Block_2=$main ->Button("-textvariable"=>\$ButtonTextVars[6],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(7,2+($IdefixSelected*8));});
$Button_8_Block_2=$main ->Button("-textvariable"=>\$ButtonTextVars[7],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(8,2+($IdefixSelected*8));});
$Button_9_Block_2=$main ->Button("-textvariable"=>\$ButtonTextVars[8],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(9,2+($IdefixSelected*8));});
$Button_10_Block_2=$main->Button("-textvariable"=>\$ButtonTextVars[9],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(10,2+($IdefixSelected*8));});
$Button_11_Block_2=$main->Button("-textvariable"=>\$ButtonTextVars[10],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(11,2+($IdefixSelected*8));});
$Button_12_Block_2=$main->Button("-textvariable"=>\$ButtonTextVars[11],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(12,2+($IdefixSelected*8));});
$Button_13_Block_2=$main->Button("-textvariable"=>\$ButtonTextVars[12],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(13,2+($IdefixSelected*8));});
                                                                   
$Button_1_Block_3=$main ->Button("-textvariable"=>\$ButtonTextVars[0],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(1,3+($IdefixSelected*8));});
$Button_2_Block_3=$main ->Button("-textvariable"=>\$ButtonTextVars[1],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(2,3+($IdefixSelected*8));});
$Button_3_Block_3=$main ->Button("-textvariable"=>\$ButtonTextVars[2],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(3,3+($IdefixSelected*8));});
$Button_4_Block_3=$main ->Button("-textvariable"=>\$ButtonTextVars[3],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(4,3+($IdefixSelected*8));});
$Button_5_Block_3=$main ->Button("-textvariable"=>\$ButtonTextVars[4],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(5,3+($IdefixSelected*8));});
$Button_6_Block_3=$main ->Button("-textvariable"=>\$ButtonTextVars[5],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(6,3+($IdefixSelected*8));});
$Button_7_Block_3=$main ->Button("-textvariable"=>\$ButtonTextVars[6],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(7,3+($IdefixSelected*8));});
$Button_8_Block_3=$main ->Button("-textvariable"=>\$ButtonTextVars[7],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(8,3+($IdefixSelected*8));});
$Button_9_Block_3=$main ->Button("-textvariable"=>\$ButtonTextVars[8],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(9,3+($IdefixSelected*8));});
$Button_10_Block_3=$main->Button("-textvariable"=>\$ButtonTextVars[9],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(10,3+($IdefixSelected*8));});
$Button_11_Block_3=$main->Button("-textvariable"=>\$ButtonTextVars[10],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(11,3+($IdefixSelected*8));});
$Button_12_Block_3=$main->Button("-textvariable"=>\$ButtonTextVars[11],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(12,3+($IdefixSelected*8));});
$Button_13_Block_3=$main->Button("-textvariable"=>\$ButtonTextVars[12],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(13,3+($IdefixSelected*8));});
                                                                   
                                                                   
$Button_1_Block_4=$main ->Button("-textvariable"=>\$ButtonTextVars[0],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(1,4+($IdefixSelected*8));});
$Button_2_Block_4=$main ->Button("-textvariable"=>\$ButtonTextVars[1],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(2,4+($IdefixSelected*8));});
$Button_3_Block_4=$main ->Button("-textvariable"=>\$ButtonTextVars[2],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(3,4+($IdefixSelected*8));});
$Button_4_Block_4=$main ->Button("-textvariable"=>\$ButtonTextVars[3],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(4,4+($IdefixSelected*8));});
$Button_5_Block_4=$main ->Button("-textvariable"=>\$ButtonTextVars[4],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(5,4+($IdefixSelected*8));});
$Button_6_Block_4=$main ->Button("-textvariable"=>\$ButtonTextVars[5],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(6,4+($IdefixSelected*8));});
$Button_7_Block_4=$main ->Button("-textvariable"=>\$ButtonTextVars[6],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(7,4+($IdefixSelected*8));});
$Button_8_Block_4=$main ->Button("-textvariable"=>\$ButtonTextVars[7],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(8,4+($IdefixSelected*8));});
$Button_9_Block_4=$main ->Button("-textvariable"=>\$ButtonTextVars[8],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(9,4+($IdefixSelected*8));});
$Button_10_Block_4=$main->Button("-textvariable"=>\$ButtonTextVars[9],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(10,4+($IdefixSelected*8));});
$Button_11_Block_4=$main->Button("-textvariable"=>\$ButtonTextVars[10],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(11,4+($IdefixSelected*8));});
$Button_12_Block_4=$main->Button("-textvariable"=>\$ButtonTextVars[11],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(12,4+($IdefixSelected*8));});
$Button_13_Block_4=$main->Button("-textvariable"=>\$ButtonTextVars[12],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(13,4+($IdefixSelected*8));});


$Button_1_Block_5=$main ->Button("-textvariable"=>\$ButtonTextVars[0],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(1,5+($IdefixSelected*8));});
$Button_2_Block_5=$main ->Button("-textvariable"=>\$ButtonTextVars[1],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(2,5+($IdefixSelected*8));});
$Button_3_Block_5=$main ->Button("-textvariable"=>\$ButtonTextVars[2],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(3,5+($IdefixSelected*8));});
$Button_4_Block_5=$main ->Button("-textvariable"=>\$ButtonTextVars[3],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(4,5+($IdefixSelected*8));});
$Button_5_Block_5=$main ->Button("-textvariable"=>\$ButtonTextVars[4],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(5,5+($IdefixSelected*8));});
$Button_6_Block_5=$main ->Button("-textvariable"=>\$ButtonTextVars[5],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(6,5+($IdefixSelected*8));});
$Button_7_Block_5=$main ->Button("-textvariable"=>\$ButtonTextVars[6],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(7,5+($IdefixSelected*8));});
$Button_8_Block_5=$main ->Button("-textvariable"=>\$ButtonTextVars[7],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(8,5+($IdefixSelected*8));});
$Button_9_Block_5=$main ->Button("-textvariable"=>\$ButtonTextVars[8],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(9,5+($IdefixSelected*8));});
$Button_10_Block_5=$main->Button("-textvariable"=>\$ButtonTextVars[9],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(10,5+($IdefixSelected*8));});
$Button_11_Block_5=$main->Button("-textvariable"=>\$ButtonTextVars[10],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(11,5+($IdefixSelected*8));});
$Button_12_Block_5=$main->Button("-textvariable"=>\$ButtonTextVars[11],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(12,5+($IdefixSelected*8));});
$Button_13_Block_5=$main->Button("-textvariable"=>\$ButtonTextVars[12],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(13,5+($IdefixSelected*8));});


$Button_1_Block_6=$main ->Button("-textvariable"=>\$ButtonTextVars[0],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(1,6+($IdefixSelected*8));});
$Button_2_Block_6=$main ->Button("-textvariable"=>\$ButtonTextVars[1],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(2,6+($IdefixSelected*8));});
$Button_3_Block_6=$main ->Button("-textvariable"=>\$ButtonTextVars[2],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(3,6+($IdefixSelected*8));});
$Button_4_Block_6=$main ->Button("-textvariable"=>\$ButtonTextVars[3],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(4,6+($IdefixSelected*8));});
$Button_5_Block_6=$main ->Button("-textvariable"=>\$ButtonTextVars[4],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(5,6+($IdefixSelected*8));});
$Button_6_Block_6=$main ->Button("-textvariable"=>\$ButtonTextVars[5],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(6,6+($IdefixSelected*8));});
$Button_7_Block_6=$main ->Button("-textvariable"=>\$ButtonTextVars[6],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(7,6+($IdefixSelected*8));});
$Button_8_Block_6=$main ->Button("-textvariable"=>\$ButtonTextVars[7],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(8,6+($IdefixSelected*8));});
$Button_9_Block_6=$main ->Button("-textvariable"=>\$ButtonTextVars[8],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(9,6+($IdefixSelected*8));});
$Button_10_Block_6=$main->Button("-textvariable"=>\$ButtonTextVars[9],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(10,6+($IdefixSelected*8));});
$Button_11_Block_6=$main->Button("-textvariable"=>\$ButtonTextVars[10],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(11,6+($IdefixSelected*8));});
$Button_12_Block_6=$main->Button("-textvariable"=>\$ButtonTextVars[11],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(12,6+($IdefixSelected*8));});
$Button_13_Block_6=$main->Button("-textvariable"=>\$ButtonTextVars[12],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(13,6+($IdefixSelected*8));});


$Button_1_Block_7=$main ->Button("-textvariable"=>\$ButtonTextVars[0],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(1,7+($IdefixSelected*8));});
$Button_2_Block_7=$main ->Button("-textvariable"=>\$ButtonTextVars[1],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(2,7+($IdefixSelected*8));});
$Button_3_Block_7=$main ->Button("-textvariable"=>\$ButtonTextVars[2],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(3,7+($IdefixSelected*8));});
$Button_4_Block_7=$main ->Button("-textvariable"=>\$ButtonTextVars[3],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(4,7+($IdefixSelected*8));});
$Button_5_Block_7=$main ->Button("-textvariable"=>\$ButtonTextVars[4],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(5,7+($IdefixSelected*8));});
$Button_6_Block_7=$main ->Button("-textvariable"=>\$ButtonTextVars[5],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(6,7+($IdefixSelected*8));});
$Button_7_Block_7=$main ->Button("-textvariable"=>\$ButtonTextVars[6],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(7,7+($IdefixSelected*8));});
$Button_8_Block_7=$main ->Button("-textvariable"=>\$ButtonTextVars[7],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(8,7+($IdefixSelected*8));});
$Button_9_Block_7=$main ->Button("-textvariable"=>\$ButtonTextVars[8],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(9,7+($IdefixSelected*8));});
$Button_10_Block_7=$main->Button("-textvariable"=>\$ButtonTextVars[9],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(10,7+($IdefixSelected*8));});
$Button_11_Block_7=$main->Button("-textvariable"=>\$ButtonTextVars[10],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(11,7+($IdefixSelected*8));});
$Button_12_Block_7=$main->Button("-textvariable"=>\$ButtonTextVars[11],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(12,7+($IdefixSelected*8));});
$Button_13_Block_7=$main->Button("-textvariable"=>\$ButtonTextVars[12],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(13,7+($IdefixSelected*8));});


$Button_1_Block_8=$main ->Button("-textvariable"=>\$ButtonTextVars[0],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(1,8+($IdefixSelected*8));});
$Button_2_Block_8=$main ->Button("-textvariable"=>\$ButtonTextVars[1],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(2,8+($IdefixSelected*8));});
$Button_3_Block_8=$main ->Button("-textvariable"=>\$ButtonTextVars[2],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(3,8+($IdefixSelected*8));});
$Button_4_Block_8=$main ->Button("-textvariable"=>\$ButtonTextVars[3],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(4,8+($IdefixSelected*8));});
$Button_5_Block_8=$main ->Button("-textvariable"=>\$ButtonTextVars[4],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(5,8+($IdefixSelected*8));});
$Button_6_Block_8=$main ->Button("-textvariable"=>\$ButtonTextVars[5],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(6,8+($IdefixSelected*8));});
$Button_7_Block_8=$main ->Button("-textvariable"=>\$ButtonTextVars[6],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(7,8+($IdefixSelected*8));});
$Button_8_Block_8=$main ->Button("-textvariable"=>\$ButtonTextVars[7],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(8,8+($IdefixSelected*8));});
$Button_9_Block_8=$main ->Button("-textvariable"=>\$ButtonTextVars[8],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(9,8+($IdefixSelected*8));});
$Button_10_Block_8=$main->Button("-textvariable"=>\$ButtonTextVars[9],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(10,8+($IdefixSelected*8));});
$Button_11_Block_8=$main->Button("-textvariable"=>\$ButtonTextVars[10],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(11,8+($IdefixSelected*8));});
$Button_12_Block_8=$main->Button("-textvariable"=>\$ButtonTextVars[11],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(12,8+($IdefixSelected*8));});
$Button_13_Block_8=$main->Button("-textvariable"=>\$ButtonTextVars[12],-background=>"white","-width"=>$Buttonswidth,"-command"=>sub{Handle_Buttons(13,8+($IdefixSelected*8));});


#Place Elements in the Main Window
$ButtonBrowseFile -> grid(-row=>'0', -column=>'1', -columnspan=>'2');
$TextBoxOpenFile  -> grid(-row=>'0', -column=>'3', -columnspan=>'3');

$label1  -> grid(-row=>'1', -column=>'1');
$label2  -> grid(-row=>'1', -column=>'2');
$label3  -> grid(-row=>'1', -column=>'3');
$label4  -> grid(-row=>'1', -column=>'4');
$label5  -> grid(-row=>'1', -column=>'5');
$label6  -> grid(-row=>'1', -column=>'6');
$label7  -> grid(-row=>'1', -column=>'7');
$label8  -> grid(-row=>'1', -column=>'8');

$Button_1_Block_1 -> grid(-row=>'3', -column=>'1');
$Button_2_Block_1 -> grid(-row=>'4', -column=>'1');
$Button_3_Block_1 -> grid(-row=>'5', -column=>'1');
$Button_4_Block_1 -> grid(-row=>'6', -column=>'1');
$Button_5_Block_1 -> grid(-row=>'7', -column=>'1');
$Button_6_Block_1 -> grid(-row=>'8', -column=>'1');
$Button_7_Block_1 -> grid(-row=>'9', -column=>'1');
$Button_8_Block_1 -> grid(-row=>'10',-column=>'1');
$Button_9_Block_1 -> grid(-row=>'11',-column=>'1');  
$Button_10_Block_1-> grid(-row=>'12',-column=>'1'); 
$Button_11_Block_1-> grid(-row=>'13',-column=>'1'); 
$Button_12_Block_1-> grid(-row=>'14',-column=>'1'); 
$Button_13_Block_1-> grid(-row=>'15',-column=>'1'); 

$Button_1_Block_2 -> grid(-row=>'3', -column=>'2');
$Button_2_Block_2 -> grid(-row=>'4', -column=>'2');
$Button_3_Block_2 -> grid(-row=>'5', -column=>'2');
$Button_4_Block_2 -> grid(-row=>'6', -column=>'2');
$Button_5_Block_2 -> grid(-row=>'7', -column=>'2');
$Button_6_Block_2 -> grid(-row=>'8', -column=>'2');
$Button_7_Block_2 -> grid(-row=>'9', -column=>'2');
$Button_8_Block_2-> grid(-row=>'10', -column=>'2');
$Button_9_Block_2-> grid(-row=>'11', -column=>'2');
$Button_10_Block_2-> grid(-row=>'12',-column=>'2'); 
$Button_11_Block_2-> grid(-row=>'13',-column=>'2'); 
$Button_12_Block_2-> grid(-row=>'14',-column=>'2'); 
$Button_13_Block_2-> grid(-row=>'15',-column=>'2'); 


$Button_1_Block_3 -> grid(-row=>'3', -column=>'3');
$Button_2_Block_3 -> grid(-row=>'4', -column=>'3');
$Button_3_Block_3 -> grid(-row=>'5', -column=>'3');
$Button_4_Block_3 -> grid(-row=>'6', -column=>'3');
$Button_5_Block_3 -> grid(-row=>'7', -column=>'3');
$Button_6_Block_3 -> grid(-row=>'8', -column=>'3');
$Button_7_Block_3 -> grid(-row=>'9', -column=>'3');
$Button_8_Block_3 -> grid(-row=>'10',-column=>'3');
$Button_9_Block_3 -> grid(-row=>'11',-column=>'3');
$Button_10_Block_3-> grid(-row=>'12',-column=>'3'); 
$Button_11_Block_3-> grid(-row=>'13',-column=>'3');
$Button_12_Block_3-> grid(-row=>'14',-column=>'3');
$Button_13_Block_3-> grid(-row=>'15',-column=>'3');

$Button_1_Block_4 -> grid(-row=>'3', -column=>'4');
$Button_2_Block_4 -> grid(-row=>'4', -column=>'4');
$Button_3_Block_4 -> grid(-row=>'5', -column=>'4');
$Button_4_Block_4 -> grid(-row=>'6', -column=>'4');
$Button_5_Block_4 -> grid(-row=>'7', -column=>'4');
$Button_6_Block_4 -> grid(-row=>'8', -column=>'4');
$Button_7_Block_4 -> grid(-row=>'9', -column=>'4');
$Button_8_Block_4 -> grid(-row=>'10',-column=>'4');
$Button_9_Block_4 -> grid(-row=>'11',-column=>'4');
$Button_10_Block_4-> grid(-row=>'12',-column=>'4'); 
$Button_11_Block_4-> grid(-row=>'13',-column=>'4');
$Button_12_Block_4-> grid(-row=>'14',-column=>'4');
$Button_13_Block_4-> grid(-row=>'15',-column=>'4');

$Button_1_Block_5 -> grid(-row=>'3', -column=>'5');
$Button_2_Block_5 -> grid(-row=>'4', -column=>'5');
$Button_3_Block_5 -> grid(-row=>'5', -column=>'5');
$Button_4_Block_5 -> grid(-row=>'6', -column=>'5');
$Button_5_Block_5 -> grid(-row=>'7', -column=>'5');
$Button_6_Block_5 -> grid(-row=>'8', -column=>'5');
$Button_7_Block_5 -> grid(-row=>'9', -column=>'5');
$Button_8_Block_5 -> grid(-row=>'10',-column=>'5');
$Button_9_Block_5 -> grid(-row=>'11',-column=>'5');
$Button_10_Block_5-> grid(-row=>'12',-column=>'5'); 
$Button_11_Block_5-> grid(-row=>'13',-column=>'5');
$Button_12_Block_5-> grid(-row=>'14',-column=>'5');
$Button_13_Block_5-> grid(-row=>'15',-column=>'5');

$Button_1_Block_6 -> grid(-row=>'3', -column=>'6');
$Button_2_Block_6 -> grid(-row=>'4', -column=>'6');
$Button_3_Block_6 -> grid(-row=>'5', -column=>'6');
$Button_4_Block_6 -> grid(-row=>'6', -column=>'6');
$Button_5_Block_6 -> grid(-row=>'7', -column=>'6');
$Button_6_Block_6 -> grid(-row=>'8', -column=>'6');
$Button_7_Block_6 -> grid(-row=>'9', -column=>'6');
$Button_8_Block_6 -> grid(-row=>'10',-column=>'6');
$Button_9_Block_6 -> grid(-row=>'11',-column=>'6');
$Button_10_Block_6-> grid(-row=>'12',-column=>'6'); 
$Button_11_Block_6-> grid(-row=>'13',-column=>'6');
$Button_12_Block_6-> grid(-row=>'14',-column=>'6');
$Button_13_Block_6-> grid(-row=>'15',-column=>'6');


$Button_1_Block_7 -> grid(-row=>'3', -column=>'7');
$Button_2_Block_7 -> grid(-row=>'4', -column=>'7');
$Button_3_Block_7 -> grid(-row=>'5', -column=>'7');
$Button_4_Block_7 -> grid(-row=>'6', -column=>'7');
$Button_5_Block_7 -> grid(-row=>'7', -column=>'7');
$Button_6_Block_7 -> grid(-row=>'8', -column=>'7');
$Button_7_Block_7 -> grid(-row=>'9', -column=>'7');
$Button_8_Block_7 -> grid(-row=>'10',-column=>'7');
$Button_9_Block_7 -> grid(-row=>'11',-column=>'7');
$Button_10_Block_7-> grid(-row=>'12',-column=>'7'); 
$Button_11_Block_7-> grid(-row=>'13',-column=>'7');
$Button_12_Block_7-> grid(-row=>'14',-column=>'7');
$Button_13_Block_7-> grid(-row=>'15',-column=>'7');

$Button_1_Block_8 -> grid(-row=>'3', -column=>'8');
$Button_2_Block_8 -> grid(-row=>'4', -column=>'8');
$Button_3_Block_8 -> grid(-row=>'5', -column=>'8');
$Button_4_Block_8 -> grid(-row=>'6', -column=>'8');
$Button_5_Block_8 -> grid(-row=>'7', -column=>'8');
$Button_6_Block_8 -> grid(-row=>'8', -column=>'8');
$Button_7_Block_8 -> grid(-row=>'9', -column=>'8');
$Button_8_Block_8 -> grid(-row=>'10',-column=>'8');
$Button_9_Block_8 -> grid(-row=>'11',-column=>'8'); 
$Button_10_Block_8-> grid(-row=>'12',-column=>'8');
$Button_11_Block_8-> grid(-row=>'13',-column=>'8');
$Button_12_Block_8-> grid(-row=>'14',-column=>'8');
$Button_13_Block_8-> grid(-row=>'15',-column=>'8');


sub Init
{        
    my $i;
    
    #Set Buttons Text
    $ButtonTextVars[0] = "Manchester Error";
    $ButtonTextVars[1] = "Parity Error";
    $ButtonTextVars[2] = "Manchester and \n Parity Error";
    $ButtonTextVars[3] = "Buffer empty";
    $ButtonTextVars[4] = "Sensor defect";
    $ButtonTextVars[5] = "Plausi Error";
    $ButtonTextVars[6] = "Rectangular Pulse";
    $ButtonTextVars[7] = "Test Pulse \n Old New Value";
    $ButtonTextVars[8] = "Skip Init2 message";
    $ButtonTextVars[9] = "Communication \n Fault";
    $ButtonTextVars[10] = "Absolute \n Pressure Low"; 
    $ButtonTextVars[11] = "Absolute \n Pressure High";  
    $ButtonTextVars[12] = "Difference of \n Absolute \n Pressure High"; 
    
    #Set Labels default values    
    for($i =0; $i<16; $i++)
    {
        $LabelsVar[$i] = "PAS $i";
        $VarToHideButtons[$i] = 0;        
    }
    showHideButtons();
    #start Idefix 
    if(IntIdefix()<= 0)
    {
       #ShowMessageBox("No Idefix found, Please connect an Idefix first!");            
       #return;
    }
    
}

sub Handle_Buttons
{
    my $FaultNr = shift;
    my $PASNr = shift;
    my $test = shift;
    
    #if no Idefix is found 
    if($IdefixInitFlag<0)
    {   
        #try still starts Idefix
        $IdefixInitFlag = IntIdefix();
        
        #break, if not possible Starts Idefix
        if($IdefixInitFlag<0)
        {
            ShowMessageBox("No Idefix found, Please connect an Idefix first!");            
            return;
        }        
    }
    
#handle Buttons    
    w2log( "selected -> "."Pas-Number: ".($PASNr-1)." Fault: $FaultNr\n");
        
    if(defined($PASNr))
    {
        my $ScrachtOffset = 0x00507980;         
        my $PasAddr = $ScrachtOffset + (0x54 * ($PASNr - 1 - ($IdefixSelected*8) ));
        
        my $AddressHelp;
        my $PasFault; 
        my $FaultValue;     
        
        my $U32_SAPulseValueHi = 0x00;
        my $U16_SAPulseValueLo = 0x04;
        my $U16_SANumberOfPulses = 0x06;
        my $U16_SAPulseLengthHi = 0x08;
        my $U16_SAPulseLengthLo = 0x0A;
        my $U16_SANumErrorMsg = 0x0C;
        my $U16_SAFaultFlag = 0x0E; 
        my $U32_SAInit2MissingMsgFlag = 0x10;
        my $U16_SAPlausiDuration = 0x14;
        my $U8_assignedTimeSlot = 0x16;
        my $U32_PPS_x_Pattern = 0x18;
        
        my ($stat, $value);
        
        w2log( "Idefix Nr: $IdefixSelected, Pas-Nr: ".($PASNr-1).", Fault: $FaultNr, \"".$ButtonTextVars[$FaultNr-1]."\"  ");
        
        switch($FaultNr)
        {
            case 1 { #Manchester Error                    
                if($SelectedButtons[$PASNr-1] == $FaultNr)    {
                    $FaultValue = 0x00;
                    w2log("Write: SANumErrorMsg -> 0x0000, SAFaultFlag -> 0x00");
                }
                else {
                    $FaultValue = $MaxValuerOfFault + (0x01<<16);     
                    w2log("Write: SANumErrorMsg -> 0xFFFF, SAFaultFlag -> 0x01");
                } 
                
                #write Value with compare option
                WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SANumErrorMsg, $FaultValue,1);                               
            }
            case 2 { #Parity Error                    
                if($SelectedButtons[$PASNr-1] == $FaultNr)    {
                    $FaultValue = 0x00;
                    w2log("Write: SANumErrorMsg -> 0x0000, SAFaultFlag -> 0x00");
                }
                else {
                    $FaultValue = $MaxValuerOfFault + (0x02<<16);
                    w2log("Write: SANumErrorMsg -> 0xFFFF, SAFaultFlag -> 0x02");
                }
                
                WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SANumErrorMsg, $FaultValue,1);
            }
            case 3 { #Manchester and Parity Error                    
                if($SelectedButtons[$PASNr-1] == $FaultNr)    {
                    $FaultValue = 0x00;
                    w2log("Write: SANumErrorMsg -> 0x0000, SAFaultFlag -> 0x00");
                }
                else {
                    $FaultValue = $MaxValuerOfFault + (0x03<<16);  
                    w2log("Write: SANumErrorMsg -> 0xFFFF, SAFaultFlag -> 0x03");
                }
                WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SANumErrorMsg, $FaultValue,1);
            }
            case 4 { #Buffer empty
                    
                if($SelectedButtons[$PASNr-1] == $FaultNr)    {
                    $FaultValue = 0x00;
                    w2log("Write: SANumErrorMsg -> 0x0000, SAFaultFlag -> 0x00");
                }
                else {
                    $FaultValue = $MaxValuerOfFault + (0x04<<16); 
                    w2log("Write: SANumErrorMsg -> 0xFFFF, SAFaultFlag -> 0x04)");
                }
                WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SANumErrorMsg, $FaultValue,1);
            }
            case 5 { #Sensor defect
                    
                if($SelectedButtons[$PASNr-1] == $FaultNr)    {
                    $FaultValue = 0x00;
                    w2log("Write: SANumErrorMsg -> 0x0000, SAFaultFlag -> 0x00");
                }
                else {
                    $FaultValue = $MaxValuerOfFault + (0x08<<16);   
                    w2log("Write: SANumErrorMsg -> 0xFFFF, SAFaultFlag -> 0x08");
                }
                WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SANumErrorMsg, $FaultValue,1);
            }
            case 6 { #Plausi Error                     
                
                #read current value
                w2log("read current value for SAPlausiDuration ...");
                ($stat, $value) = ReadIdefixByAddress($IdefixSelected, $PasAddr+$U16_SAPlausiDuration);
                
                #delete fault
                if($SelectedButtons[$PASNr-1] == $FaultNr)    {
                
                    $FaultValue =  hex($value)& 0xffff0000;
                    
                    w2log("Write: SAPlausiDuration -> 0x0000");                    
                    #write plausibility fault duration 
                    WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SAPlausiDuration, $FaultValue,1);
                    #read current value
                    ($stat, $value) = ReadIdefixByAddress($IdefixSelected, $PasAddr+$U16_SAFaultFlag);
                    $FaultValue  = hex($value) & 0x0000ffff;    
                    w2log("Write: SAFaultFlag-> 0x0000");  
                    WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SAFaultFlag, $FaultValue,1);
                }
                else {
                    #plausibility fault duration 
                    $FaultValue = hex($value)| 0xffff;
                    w2log("Write: SAPlausiDuration -> 0xFFFF");                     
                    #write plausibility fault duration 
                    WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SAPlausiDuration, $FaultValue,1);
                    
                    #read current value
                    ($stat, $value) = ReadIdefixByAddress($IdefixSelected, $PasAddr+$U16_SAFaultFlag);
                    $FaultValue = (hex($value) & 0xffff)+ (0x10<<16);   
                    w2log("Write: SAFaultFlag-> 0x0010");     
                    WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SAFaultFlag, $FaultValue,1);
                }                
                
            }
            case 7 {  #Rectangular Pulse
                 
                 #read current value               
                ($stat, $value) = ReadIdefixByAddress($IdefixSelected, $PasAddr+$U16_SAFaultFlag);               
                
                if($SelectedButtons[$PASNr-1] == $FaultNr)    {                                       
                    #WriteIdefixByAddress($IdefixSelected, $PasAddr, 0x00,1);
                    WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SAPulseValueLo, 0x00000000,1); 
                    WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SAPulseLengthHi,0x00000000,1);                     
                    $FaultValue  = hex($value) & 0x0000ffff;                                                           
                    WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SAFaultFlag, $FaultValue,1);
                }
                else {
                    #WriteIdefixByAddress($IdefixSelected, $PasAddr, 0x20,1);
                    WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SAPulseValueLo, 0x00200000,1); 
                    WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SAPulseLengthHi,0x0fa00fa0,1);                     
                    $FaultValue = (hex($value) & 0x0000ffff)+(0x20<<16);   
                    WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SAFaultFlag, $FaultValue,1);
                }
                
            }
            case 8 { #Test Pulse Old New Value
                      
                ($stat, $value) = ReadIdefixByAddress($IdefixSelected, $PasAddr+$U16_SAFaultFlag);
                
                if($SelectedButtons[$PASNr-1] == $FaultNr)    {
                    $FaultValue =  (hex($value) & 0x0000ffff);
                    WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SAFaultFlag, $FaultValue,1);  
                }
                else {
                    $FaultValue = (hex($value)& 0x0000ffff) + (0x20<<16);
                    WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SAFaultFlag, $FaultValue,1);  
                }                   
            }            
            case 9 { #Skip Init2 message           
            
                if($SelectedButtons[$PASNr-1] == $FaultNr)    {                                        
                    WriteIdefixByAddress($IdefixSelected, $PasAddr + $U32_SAInit2MissingMsgFlag, 0x00,1);                     
                    WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SANumErrorMsg, 0x00,1);                    
                }
                else {
                    WriteIdefixByAddress($IdefixSelected, $PasAddr + $U32_SAInit2MissingMsgFlag, 0xff,1);  
                    $FaultValue = $MaxValuerOfFault + (0x01<<16);  
                    WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SANumErrorMsg, $FaultValue,1);
                }
            }
            case 10 { #Communication Fault                       
                               
                if($SelectedButtons[$PASNr-1] == $FaultNr)    {
                    $FaultValue = 0x00;
                    w2log("Write: SANumErrorMsg -> 0x0000, SAFaultFlag-> 0x00");
                }
                else {
                    $FaultValue = $MaxValuerOfFault + (0x80<<16);
                    w2log("Write: SANumErrorMsg -> 0xFFFF, SAFaultFlag-> 0x80");
                }
                                
                WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SANumErrorMsg, $FaultValue,1);
            }
            case 11 { # Absolute Pressure Low         
                # Absolute Pressure Low 0x08B for PPS2
                # Absolute Pressure Low 0x37 for PPS1                
                switch ($VarToHideButtons[$PASNr -1])
                {
                    case 1{ #8Bit 0x37
                       if($SelectedButtons[$PASNr-1] == $FaultNr)    {
                            
                            w2log("Write: SANumErrorMsg -> 0x0000, SAFaultFlag-> 0x00");
                            WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SANumErrorMsg, $FaultValue,1);                                                        
                           
                            w2log("Write SAAbsPressure -> ".ToHex($PPSConfiguredValues[$PASNr -1]>>16) ); 
                            WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SAPlausiDuration, $PPSConfiguredValues[$PASNr -1],1);   
                        }
                        else {
                            
                            $FaultValue = $MaxValuerOfFault + (0x100<<16);
                            
                            w2log("Write: SANumErrorMsg -> ".ToHex($MaxValuerOfFault).", SAFaultFlag-> ".ToHex($FaultValue>>16));
                            WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SANumErrorMsg, $FaultValue,1);     
                            
                            #read current value
                            ($stat, $value) = ReadIdefixByAddress($IdefixSelected, $PasAddr+$U16_SAPlausiDuration);                            
                            
                            $PPSConfiguredValues[$PASNr -1] = ( (hex($value) & 0xffff0000) >> 16 )+ ((hex($value) & 0xffff)<<16);                            
                            w2log("PPS Value found -> ".ToHex((hex($value) & 0xffff)));
                            
                            $FaultValue = ( (hex($value) & 0xffff0000) >> 16 )+ (0x37<<16);                                 
                            w2log("Write SAAbsPressure -> ".ToHex($FaultValue>>16) ); 
                            WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SAPlausiDuration, $FaultValue,1);
                        }                                                 
                    }
                    case 2{ #10 Bit
                        if($SelectedButtons[$PASNr-1] == $FaultNr)    {
                            
                            w2log("Write: SANumErrorMsg -> 0x0000, SAFaultFlag-> 0x00");
                            WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SANumErrorMsg, $FaultValue,1);                                                        
                           
                            w2log("Write SAAbsPressure -> ".ToHex($PPSConfiguredValues[$PASNr -1]>>16) ); 
                            WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SAPlausiDuration, $PPSConfiguredValues[$PASNr -1],1);   
                        }
                        else {
                            
                            $FaultValue = $MaxValuerOfFault + (0x100<<16);
                            
                            w2log("Write: SANumErrorMsg -> ".ToHex($MaxValuerOfFault).", SAFaultFlag-> ".ToHex($FaultValue>>16));
                            WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SANumErrorMsg, $FaultValue,1);     
                            
                            #read current value
                            ($stat, $value) = ReadIdefixByAddress($IdefixSelected, $PasAddr+$U16_SAPlausiDuration);                            
                            
                            $PPSConfiguredValues[$PASNr -1] = ( (hex($value) & 0xffff0000) >> 16 )+ ((hex($value) & 0xffff)<<16);                            
                            w2log("PPS Value found -> ".ToHex((hex($value) & 0xffff)));
                            
                            $FaultValue = ( (hex($value) & 0xffff0000) >> 16 )+ (0x08B<<16);                                 
                            w2log("Write SAAbsPressure -> ".ToHex($FaultValue>>16) ); 
                            WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SAPlausiDuration, $FaultValue,1);
                        }                                
                    }
                    else {
                        if($SelectedButtons[$PASNr-1] == $FaultNr)    {
                        
                            $FaultValue = 0;
                            w2log("Write: SANumErrorMsg -> ".ToHex($MaxValuerOfFault).", SAFaultFlag-> ".ToHex($FaultValue>>16));
                            WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SANumErrorMsg, $FaultValue,1);                                                        

                            w2log("Write SAAbsPressure -> ".ToHex($PPSConfiguredValues[$PASNr -1]>>16) ); 
                            WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SAPlausiDuration, $PPSConfiguredValues[$PASNr -1],1);   
                        }
                        else {

                            $FaultValue = $MaxValuerOfFault + (0x100<<16);

                            w2log("Write: SANumErrorMsg -> ".ToHex($MaxValuerOfFault).", SAFaultFlag-> ".ToHex($FaultValue>>16));
                            WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SANumErrorMsg, $FaultValue,1);     

                            #read current value
                            ($stat, $value) = ReadIdefixByAddress($IdefixSelected, $PasAddr+$U16_SAPlausiDuration);                            

                            $PPSConfiguredValues[$PASNr -1] = ( (hex($value) & 0xffff0000) >> 16 )+ ((hex($value) & 0xffff)<<16);                            
                            w2log("PPS Value found -> ".ToHex((hex($value) & 0xffff)));

                            $FaultValue = ( (hex($value) & 0xffff0000) >> 16 )+ (0x37<<16);                                 
                            w2log("Write SAAbsPressure -> ".ToHex($FaultValue>>16) ); 
                            WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SAPlausiDuration, $FaultValue,1);
                        }     
                        
                    }
                }
            }
            case 12 { #Absolute Pressure High  - 0x73 (PPS1) or 0xC8C (PPS2).                           
                switch ($VarToHideButtons[$PASNr -1])
                {
                    case 1{ #8Bit
                       if($SelectedButtons[$PASNr-1] == $FaultNr)    {
                            $FaultValue = 0;
                            w2log("Write: SANumErrorMsg -> ".ToHex($MaxValuerOfFault).", SAFaultFlag-> ".ToHex($FaultValue>>16));
                            WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SANumErrorMsg, $FaultValue,1);                                                        
                           
                            w2log("Write SAAbsPressure -> ".ToHex($PPSConfiguredValues[$PASNr -1]>>16) ); 
                            WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SAPlausiDuration, $PPSConfiguredValues[$PASNr -1],1);   
                        }
                        else {
                            
                            $FaultValue = $MaxValuerOfFault + (0x200<<16);
                            
                            w2log("Write: SANumErrorMsg -> ".ToHex($MaxValuerOfFault).", SAFaultFlag-> ".ToHex($FaultValue>>16));
                            WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SANumErrorMsg, $FaultValue,1);     
                            
                            #read current value
                            ($stat, $value) = ReadIdefixByAddress($IdefixSelected, $PasAddr+$U16_SAPlausiDuration);                            
                            
                            $PPSConfiguredValues[$PASNr -1] = ( (hex($value) & 0xffff0000) >> 16 )+ ((hex($value) & 0xffff)<<16);                            
                            w2log("PPS Value found -> ".ToHex((hex($value) & 0xffff)));
                            
                            $FaultValue = ( (hex($value) & 0xffff0000) >> 16 )+ (0x73<<16);                                 
                            w2log("Write SAAbsPressure -> ".ToHex($FaultValue>>16) ); 
                            WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SAPlausiDuration, $FaultValue,1);
                        }                                                 
                    }
                    case 2{ #10 Bit
                        if($SelectedButtons[$PASNr-1] == $FaultNr)    {
                            $FaultValue = 0;
                            w2log("Write: SANumErrorMsg -> ".ToHex($MaxValuerOfFault).", SAFaultFlag-> ".ToHex($FaultValue>>16));
                            WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SANumErrorMsg, $FaultValue,1);                                                        
                           
                            w2log("Write SAAbsPressure -> ".ToHex($PPSConfiguredValues[$PASNr -1]>>16) ); 
                            WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SAPlausiDuration, $PPSConfiguredValues[$PASNr -1],1);   
                        }
                        else {
                            
                            $FaultValue = $MaxValuerOfFault + (0x200<<16);
                            
                            w2log("Write: SANumErrorMsg -> ".ToHex($MaxValuerOfFault).", SAFaultFlag-> ".ToHex($FaultValue>>16));
                            WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SANumErrorMsg, $FaultValue,1);     
                            
                            #read current value
                            ($stat, $value) = ReadIdefixByAddress($IdefixSelected, $PasAddr+$U16_SAPlausiDuration);                            
                            
                            $PPSConfiguredValues[$PASNr -1] = ( (hex($value) & 0xffff0000) >> 16 )+ ((hex($value) & 0xffff)<<16);                            
                            w2log("PPS Value found -> ".ToHex((hex($value) & 0xffff)));
                            
                            $FaultValue = ( (hex($value) & 0xffff0000) >> 16 )+ (0xC8C<<16);                                 
                            w2log("Write SAAbsPressure -> ".ToHex($FaultValue>>16) ); 
                            WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SAPlausiDuration, $FaultValue,1);
                        }                                
                    }
                    else {
                        if($SelectedButtons[$PASNr-1] == $FaultNr)    {
                            $FaultValue = 0;
                            w2log("Write: SANumErrorMsg -> ".ToHex($MaxValuerOfFault).", SAFaultFlag-> ".ToHex($FaultValue>>16));
                            WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SANumErrorMsg, $FaultValue,1);                                                        

                            w2log("Write SAAbsPressure -> ".ToHex($PPSConfiguredValues[$PASNr -1]>>16) ); 
                            WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SAPlausiDuration, $PPSConfiguredValues[$PASNr -1],1);   
                        }
                        else {

                            $FaultValue = $MaxValuerOfFault + (0x200<<16);

                            w2log("Write: SANumErrorMsg -> ".ToHex($MaxValuerOfFault).", SAFaultFlag-> ".ToHex($FaultValue>>16));
                            WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SANumErrorMsg, $FaultValue,1);     

                            #read current value
                            ($stat, $value) = ReadIdefixByAddress($IdefixSelected, $PasAddr+$U16_SAPlausiDuration);                            

                            $PPSConfiguredValues[$PASNr -1] = ( (hex($value) & 0xffff0000) >> 16 )+ ((hex($value) & 0xffff)<<16);                            
                            w2log("PPS Value found -> ".ToHex((hex($value) & 0xffff)));

                            $FaultValue = ( (hex($value) & 0xffff0000) >> 16 )+ (0x73<<16);                                 
                            w2log("Write SAAbsPressure -> ".ToHex($FaultValue>>16) ); 
                            WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SAPlausiDuration, $FaultValue,1);
                        }                             
                    }
                }                
            }
            case 13 { # Difference of Absolute Pressure High - 0x06 (PPS1),  0x109 (PPS2). 
                switch ($VarToHideButtons[$PASNr -1])
                {
                    case 1{ #8Bit
                       if($SelectedButtons[$PASNr-1] == $FaultNr)    {
                            $FaultValue = 0;
                            w2log("Write: SANumErrorMsg -> ".ToHex($MaxValuerOfFault).", SAFaultFlag-> ".ToHex($FaultValue>>16));
                            WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SANumErrorMsg, $FaultValue,1);                                                        
                           
                            w2log("Write SAAbsPressure -> ".ToHex($PPSConfiguredValues[$PASNr -1]>>16) ); 
                            WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SAPlausiDuration, $PPSConfiguredValues[$PASNr -1],1);   
                        }
                        else {
                            
                            $FaultValue = $MaxValuerOfFault + (0x400<<16);
                            
                            w2log("Write: SANumErrorMsg -> ".ToHex($MaxValuerOfFault).", SAFaultFlag-> ".ToHex($FaultValue>>16));
                            WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SANumErrorMsg, $FaultValue,1);     
                            
                            #read current value
                            ($stat, $value) = ReadIdefixByAddress($IdefixSelected, $PasAddr+$U16_SAPlausiDuration);                            
                            
                            $PPSConfiguredValues[$PASNr -1] = ( (hex($value) & 0xffff0000) >> 16 )+ ((hex($value) & 0xffff)<<16);                            
                            w2log("PPS Value found -> ".ToHex((hex($value) & 0xffff)));
                            
                            $FaultValue = ( (hex($value) & 0xffff0000) >> 16 )+ (0x73<<16);                                 
                            w2log(" Write SAAbsPressure -> ".ToHex($FaultValue>>16) ); 
                            WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SAPlausiDuration, $FaultValue,1);
                        }                                                 
                    }
                    case 2{ #10 Bit
                        if($SelectedButtons[$PASNr-1] == $FaultNr)    {
                            $FaultValue = 0;
                            w2log("Write: SANumErrorMsg -> ".ToHex($MaxValuerOfFault).", SAFaultFlag-> ".ToHex($FaultValue>>16));
                            WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SANumErrorMsg, $FaultValue,1);                                                        
                           
                            w2log("Write SAAbsPressure -> ".ToHex($PPSConfiguredValues[$PASNr -1]>>16) ); 
                            WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SAPlausiDuration, $PPSConfiguredValues[$PASNr -1],1);   
                        }
                        else {
                            
                            $FaultValue = $MaxValuerOfFault + (0x400<<16);
                            
                            w2log("Write: SANumErrorMsg -> ".ToHex($MaxValuerOfFault).", SAFaultFlag-> ".ToHex($FaultValue>>16));
                            WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SANumErrorMsg, $FaultValue,1);     
                            
                            #read current value
                            ($stat, $value) = ReadIdefixByAddress($IdefixSelected, $PasAddr+$U16_SAPlausiDuration);                            
                            
                            $PPSConfiguredValues[$PASNr -1] = ( (hex($value) & 0xffff0000) >> 16 )+ ((hex($value) & 0xffff)<<16);                            
                            w2log("PPS Value found -> ".ToHex((hex($value) & 0xffff)));
                            
                            $FaultValue = ( (hex($value) & 0xffff0000) >> 16 )+ ( ( (hex($value) & 0xffff)+0x109)<<16) ; 
                            
                            w2log("Write SAAbsPressure -> ".ToHex($FaultValue>>16) ); 
                            WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SAPlausiDuration, $FaultValue,1);
                        }                                
                    }
                    else {
                        if($SelectedButtons[$PASNr-1] == $FaultNr)    {
                            $FaultValue = 0;
                            w2log("Write: SANumErrorMsg -> ".ToHex($MaxValuerOfFault).", SAFaultFlag-> ".ToHex($FaultValue>>16));
                            WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SANumErrorMsg, $FaultValue,1);                                                        

                            w2log("Write SAAbsPressure -> ".ToHex($PPSConfiguredValues[$PASNr -1]>>16) ); 
                            WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SAPlausiDuration, $PPSConfiguredValues[$PASNr -1],1);   
                        }
                        else {

                            $FaultValue = $MaxValuerOfFault + (0x400<<16);

                            w2log("Write: SANumErrorMsg -> ".ToHex($MaxValuerOfFault).", SAFaultFlag-> ".ToHex($FaultValue>>16));
                            WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SANumErrorMsg, $FaultValue,1);     

                            #read current value
                            ($stat, $value) = ReadIdefixByAddress($IdefixSelected, $PasAddr+$U16_SAPlausiDuration);                            

                            $PPSConfiguredValues[$PASNr -1] = ( (hex($value) & 0xffff0000) >> 16 )+ ((hex($value) & 0xffff)<<16);                            
                            w2log("PPS Value found -> ".ToHex((hex($value) & 0xffff)));

                            $FaultValue = ( (hex($value) & 0xffff0000) >> 16 )+ (0x73<<16);                                 
                            w2log("Write SAAbsPressure -> ".ToHex($FaultValue>>16) ); 
                            WriteIdefixByAddress($IdefixSelected, $PasAddr + $U16_SAPlausiDuration, $FaultValue,1);
                        }                             
                    }
                }                            
            }
            else { 
                
                w2log( "An Error is occurred") 
            }            
        }        
    }
    SetState($FaultNr,$PASNr);  
}

sub ToHex
{
    my $Value = shift;
    my $Help =  sprintf "0x%x",$Value; 
    return $Help;
}

sub WriteIdefixByAddress
{
    my $IdefixNumber = shift;
    my $AddressToWrite = shift;
    my $ValueToWrite = shift;
    my $CompareOption = shift;
    

#�nderung Anfang
#Fix big/little Endian Problem
    my $help = ($ValueToWrite&0x0000ffff)<<16;
    $ValueToWrite = $help +( ($ValueToWrite&0xffff0000)>>16 ); 
# �nderung Ende


    #my $Addhelp = ToHex( $AddressToWrite );
    #my $Valuehelp =  ToHex( $ValueToWrite );
    my $stat;
    
    $stat = idx_WriteByAddress($IdefixNumber, $AddressToWrite, $ValueToWrite);
    
    w2log( "(".ToHex( $AddressToWrite ).") func write: ".ToHex( $ValueToWrite )." (".$stat.")");
    #if comparison is wished
    if($CompareOption)  {
        ($stat, $value) = ReadIdefixByAddress($IdefixNumber, $AddressToWrite, $ValueToWrite); 
    }
}

sub SetState    {
    my $SelectedRow = shift;  
    my $SelectedColumn= shift;          
    my $Sel_Button;        
    
    #the first time 
    unless($SelectedButtons[$SelectedColumn-1]) {
        $SelectedButtons[$SelectedColumn-1] = $SelectedRow;
        $Sel_Button = "\$Button_".($SelectedRow)."_Block_".($SelectedColumn-($IdefixSelected*8))."->configure(-background => \"red\", -activebackground => \"red\")";        
        eval $Sel_Button;
        if($@)  {
            w2log( "*** Error: $@ ");
        }
        else {
            w2log( "Fault Set: ".$ButtonTextVars[$SelectedRow-1]."\n");
        }
    }
    else {
        if($SelectedButtons[$SelectedColumn-1] == $SelectedRow) {
            $Sel_Button = "\$Button_".$SelectedRow."_Block_".($SelectedColumn-($IdefixSelected*8))."->configure(-background => \"white\", -activebackground => \"white\")";
            
            eval $Sel_Button;
            
            w2log( "Fault disabled: ".$ButtonTextVars[$SelectedButtons[$SelectedColumn-1]-1]."\n");
            $SelectedButtons[$SelectedColumn-1]= undef;
        }
        else {                
            #disable old button
            $Sel_Button = "\$Button_".$SelectedButtons[$SelectedColumn-1]."_Block_".($SelectedColumn-($IdefixSelected*8))."->configure(-background => \"white\", -activebackground => \"white\")";
            eval $Sel_Button;
            w2log( "Fault disabled: ".$ButtonTextVars[$SelectedButtons[$SelectedColumn-1]-1]."\n");            
            
            #enable new Button
            $Sel_Button = "\$Button_".$SelectedRow."_Block_".($SelectedColumn-($IdefixSelected*8))."->configure(-background => \"red\", -activebackground => \"red\")";
            
            eval $Sel_Button;
            w2log( "Fault Set: ".$ButtonTextVars[$SelectedRow-1]."\n");
            
            $SelectedButtons[$SelectedColumn-1] = $SelectedRow;
        }
    }   
}

sub EraseOldFaults()
{
    my $i;
    my $j=0;
    my $ScrachtOffset = 0x00507980;   
    my $PASNr = 0;
    my $PasAddr; #= $ScrachtOffset + (0x30 * ($PASNr - ($i*8) ));
        
    for($i=0; $i<$IDXNumber; $i++)
    {
        for($j=0;$j<8; $j++)
        {            
            $PasAddr = $ScrachtOffset + (0x50 * ($PASNr - ($i*8) ));
            
            #write Value with compare option
            WriteIdefixByAddress($i, $PasAddr + 0x0c, $FaultValue,1);
            $PASNr++;
        }        
    }
}
sub ReadIdefixByAddress
{   
    my ($stat, $value);
    my $IdefixToRead =shift; 
    my $AddressToRead = shift;
    my $ExpectedValue = shift;    
    my $stringHelp;
    
     
    ($stat, $value) = idx_ReadByAddress($IdefixToRead, $AddressToRead);
    
    if($ExpectedValue ) {           
        $stringHelp =ToHex($ExpectedValue);
        checkValues ($value,$stringHelp);
        $ExpectedValue = sprintf " Expected: 0x%x", ($ExpectedValue);
    }    
    w2log( "(".ToHex($AddressToRead).") Idefix Nr: $IdefixToRead, func read: $value $ExpectedValue");   
    
    return ($stat, $value);
}

sub IntIdefix
{   
     w2log("starting Idefix...");
     $IdefixInitFlag = 1;
     my $version;
     my $ret = idx_getPMrevision();
     w2log( "PM $ret");
     $ret = idx_getXSrevision();
     w2log( "XS $ret");
     $ret = idx_getCWrevision();
     w2log( "CW $ret");

     my $status = idx_Start();
     w2log("perl: ($status) Start");
     checkError($status);

     $IdefixInitFlag = idx_IniUSB();
     w2log("perl: ($IdefixInitFlag) IniUSB");
     checkError($IdefixInitFlag);
     
     my $i=0;
     my $IdefixSerNr;
     
     if($IdefixInitFlag>0)  {
         
         $IDXNumber = $IdefixInitFlag;
         
         for($i=0; $i<$IDXNumber; $i++)    {   
             ($status,$version) = idx_GetDescription($i);
             w2log("\n\nperl: ($status) Idefix Nr: ".($i).": $version");
             
             $IdefixSerNr = $version;  
             
             checkError($status);

             ($status, $version) = idx_GetFirmware($i);
             w2log("perl: ($status) Idefix Nr: ".($i).": Firmware: $version ");
             checkError($status);

             ($status, $version) = idx_GetVersion();
             w2log("perl: ($status) Idefix Nr: ".($i).": Version: $version");             
             
             #create radio buttons
             $RadioButtons[$i] = $main-> Radiobutton(-text=>"Idefix Nr. ".($i).": ".$IdefixSerNr,-variable=>\$IdefixSelected,-value=>"$i", -state =>"normal", -command => \&ShowNewLabelText ); 
             $RadioButtons[$i]-> grid(-row=>$i+3, -column=>'0');
         }
         $IdefixSelected = 0;
         w2log("\nIdefix start done... \nfound devices = ".($i)."\n\n"); 
         
         #EraseOldFaults();
     }   
     else {
        w2log("Idefix not found, please check your connections!\n\n");
     }
     return $IdefixInitFlag;     
}

sub checkValues
{
    my $value1 = shift;
    my $value2 = shift;
    if(hex($value1)== hex($value2) )    {
        w2log( "checkValues: ok ");
    }
    else    {
        w2log( "checkValues: nok ");
    }
}

sub checkError{
    my $stat = shift;
    w2log( "ERROR:".idx_GetErrortext($stat)) if $stat<0;
}

sub ShowNewLabelText
{    
    $label1  -> configure (-text=>$LabelsVar[0 + ($IdefixSelected*8) ],-background=>$BackgrVar[0 + ($IdefixSelected*8) ]);
    $label2  -> configure (-text=>$LabelsVar[1 + ($IdefixSelected*8) ],-background=>$BackgrVar[1 + ($IdefixSelected*8) ]);
    $label3  -> configure (-text=>$LabelsVar[2 + ($IdefixSelected*8) ],-background=>$BackgrVar[2 + ($IdefixSelected*8) ]);
    $label4  -> configure (-text=>$LabelsVar[3 + ($IdefixSelected*8) ],-background=>$BackgrVar[3 + ($IdefixSelected*8) ]);
    $label5  -> configure (-text=>$LabelsVar[4 + ($IdefixSelected*8) ],-background=>$BackgrVar[4 + ($IdefixSelected*8) ]);
    $label6  -> configure (-text=>$LabelsVar[5 + ($IdefixSelected*8) ],-background=>$BackgrVar[5 + ($IdefixSelected*8) ]);
    $label7  -> configure (-text=>$LabelsVar[6 + ($IdefixSelected*8) ],-background=>$BackgrVar[6 + ($IdefixSelected*8) ]);
    $label8  -> configure (-text=>$LabelsVar[7 + ($IdefixSelected*8) ],-background=>$BackgrVar[7 + ($IdefixSelected*8) ]);
       
    checkIdefixSelected();
    showHideButtons();
    
}

#change the button States for any Idefix
sub checkIdefixSelected
{
    my $columnHelp = 1;
    my $rowHelp = 1;
    my $i;
    my $j;
    my $flag = 0;
    
    if($IdefixSelected == 0)    {    
        for($j=1; $j<9; $j++)   {
            for($i=1; $i<14; $i++)  {
                if($SelectedButtons[$j-1] == $i)    {
                    $Sel_Button = "\$Button_".($i)."_Block_".($j)."->configure(-background => \"red\", -activebackground => \"red\")";  
                } 
                else {
                    $Sel_Button = "\$Button_".($i)."_Block_".($j)."->configure(-background => \"white\", -activebackground => \"red\")";
                } 
                eval $Sel_Button;    
                if($@) { w2log ("Fehler: $@"); w2log($Sel_Button." Cannot be programmed!!! "); }
            }   
        }
    }
    else {  #if($IdefixSelected == 1)    {    
        for($j=1; $j<9; $j++)   {
            for($i=14; $i<27; $i++)  {                
                if($SelectedButtons[$j-1+8] == ($i-13) ) {
                    $Sel_Button = "\$Button_".($i-13)."_Block_".($j)."->configure(-background => \"red\", -activebackground => \"red\")"; 
                } 
                else {
                    $Sel_Button = "\$Button_".($i-13)."_Block_".($j)."->configure(-background => \"white\", -activebackground => \"red\")"; 
                }      
                eval $Sel_Button; 
                if($@) { w2log ("Fehler: $@"); w2log($Sel_Button." Cannot be programmed!!! "); }
            } 
         }
    }    
    w2log("Idefix ".$IdefixSelected." selected ");
}
sub showHideButtons
{
    my $i;
    my $j;    
    my $Sel_Button ;
    
    if($IdefixSelected == 0)
    {
        for($i=1; $i<9;$i++)
        {
            if($VarToHideButtons[$i-1]==0)
            {
                for($j =11; $j<14; $j++)
                {
                    $Sel_Button = "\$Button_".($j)."_Block_".($i)."->configure(-state => \"disabled\")";
                    eval $Sel_Button; 
                    if($@) { w2log ("Fehler: $@"); w2log($Sel_Button." Cannot be programmed!!! "); }
                }
            }
            else {
                for($j =11; $j<14; $j++)
                {                            
                    $Sel_Button = "\$Button_".($j)."_Block_".($i)."->configure(-state => \"normal\")";                    
                    eval $Sel_Button; 
                    if($@) { w2log ("Fehler: $@"); w2log($Sel_Button." Cannot be programmed!!! "); }
                }

            }
        }
    }
    else
    {
        for($i=8; $i<16 ;$i++)
        {
            if($VarToHideButtons[$i]==0)
            {
                for($j =11; $j<14; $j++)
                {
                    $Sel_Button = "\$Button_".($j)."_Block_".($i-7)."->configure(-state => \"disabled\")";
                    eval $Sel_Button; 
                    if($@) { w2log ("Fehler: $@"); w2log($Sel_Button." Cannot be programmed "); }
                }
            }
            else {
                for($j =11; $j<14; $j++)
                {
                    $Sel_Button = "\$Button_".($j)."_Block_".($i-7)."->configure(-state => \"normal\")";
                    eval $Sel_Button; 
                    if($@) { w2log ("Fehler: $@"); w2log($Sel_Button." Cannot be programmed "); }
                }                    
            }
        }
    }
}

sub ShowMessageBox
{
    my $Message = shift;
    $main->messageBox(
                        '-icon'    => "error", #qw/error info question warning/
                        '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                        '-title'   => 'Attention',
                        '-message' => $Message
    );
    
}
sub w2log
{
    my $Message = shift;
    print $LOG $Message."\n";
    print"$Message \n";    
}

open ( $LOG,">PAS_fault_GUI_log.txt" ) or die "Couldn't open PAS_fault_GUI_log.txt : $@";

w2log("######################################################################");
w2log("### PAS Faults GUI");
w2log("### Date: ".localtime(time));
w2log("### ".$Toolversion);
w2log("### ".$HEADER);
w2log("######################################################################\n\n");

#call init function bevor
Init();

MainLoop;

idx_End();


w2log("\n######################################################################\n");
w2log(" END OF LOGFILE\n");
close ($LOG);

=head1 DESCRIPTION

very simple GUI for creating PAS protocol faults with IDEFIX. 

=head1 AUTHOR

Luis Salvatierra

=cut
