#!perl -w

use strict;
use warnings;
use Tk;
use Tk::Frame;
use Win32::File;
use File::Copy;
use File::Basename;
use Win32::OLE;
use Win32::OLE::Const;
use File::Find;
use File::Path;
use Getopt::Long;
use File::Glob ':glob';
use Cwd; 
use Tk::LabFrame;
my $Next_Element_Y_position =50;
my $DBC_Element_Number =20;
my $Space_between_Elements=60;
sub Creatre_About_Window()
{

my $mw = MainWindow->new("-background" => "#888888");
$mw->minsize(100,25);
$mw->title("About");

#Making a text area
my $txt = $mw -> Scrolled('Text',-width => 100,-scrollbars=>'e') -> pack ();

$txt->delete('1.0','end');
    $txt->insert('end','
#****************************************************************************
#                                                                           *
# Copyright (c) 2011 Robert Bosch GmbH, Germany                             *
#               All rights reserved                                         *
#                                                                           *
#****************************************************************************
#                                                                           *
# $Author: Reddivari Devendra Kumar (RBEI/ESA-PP) (dvn2kor) $                         *
# $Revision : 1.0 $                                                         *
#                                                                           *
# Hardware_label:                                                           *
#   This tool will provide the Decoder template based                       *
#   on the exported AKLV (*xls) sheet from doors                            *
#   File Needed :                                                           *
#   1)Expored doors AKLV XLS Files (.xls )                                  *
#            This files are provided by  the customer for each project      *
#                                                                           *
#                                                                           *
#  Remarks: -                                                               *
#           - Perl Version 5.6 and greater are needed to run this script    *
#       - Perl TK                                                           *
#                                                                           *
#****************************************************************************
'
);

 }
my ($main,$end_frame,$path_frame,$entry);
my ($Designation_path,$File_Name_Path,@File_Select_Arr,$status,);
my ($EDID_Doors_File_Name,$EDID_Start_Byte_From_Panel,$EDR_Service_IDs,$Diag_Request_ID_From_Panel,$Diag_Response_ID_From_Panel);
# Default Designation Path
$Designation_path='C:';
$main = MainWindow->new("-background" => "#888888");

# Size to the TK window 
$main->minsize(450,100);

$main->title("AKLV Decoder Generator ");
# Get the current path 
my $pwd = cwd();
#print "$pwd","\n";
my @path_structure;
@path_structure =split(/\//,$pwd); 
# Remove the last Folder 
#pop(@path_structure);
# Add the string with \\ to get the complete path
my $File_With_Path=join("\\",@path_structure);
print "File_With_Path =$File_With_Path","\n";
$pwd =~ s/\//\\/g;
$pwd =~ s/\//\\/;

#Remove the files if is already present in the canoe folder


#Declare that there is a menu
my $mbar = $main -> Menu();
$main -> configure(-menu => $mbar);

#The Main Buttons
my $file = $mbar -> cascade(-label=>"File", -underline=>0, -tearoff => 0);
my $help = $mbar -> cascade(-label =>"Help", -underline=>0, -tearoff => 0);


## File Menu ##
$file -> command(-label =>"Exit", -underline => 1,
        -command => sub { exit } );
 
#******************************************************************************************** 
$help -> command(-label =>"About",  -command=>sub {Creatre_About_Window()});

$main->Label(
    -text=>'AKLV Decoder Generator ',
    -font=>'{Segoe UI} 15 bold',
    -background => '#888888',
    -foreground => 'white',
    -height=>'001')->pack(-side=>'top',-pady=>'003');

my $shot = $main->Photo(-file => "$File_With_Path\\logo\\Team_Logo.gif");
$main->Label(-image => $shot)->pack(-side => 'top');

 $main->Label(
            -text=>'NOTE: Select .xls file form Doors Export function ',
            -font=>'{Segoe UI Semibold} 8 bold',
            -background => "#888888",
            -foreground => "white",
             )->pack(-side=>'left',-padx=>'75',-pady=>'02',-side=>'top',-anchor=>'w');

$path_frame = $main->Frame("-background" => "#888888")->pack(-pady=>'0',-padx=>'05' );

$path_frame->Label(
        -text=>'  File  :',
        -background => "#888888",
         -foreground => "blue1",
        -font=>'{Segoe UI bold} 15 ')->pack(-side=>'left', -pady=>'0',-padx=>'05');

$status= ' Not Started ';
$entry = $path_frame->Entry(
        -width=>'50',
        -textvariable=>\$File_Name_Path,
        -background => "white",
        -foreground  => "black",
        )->pack(-side=>'left',
                -pady=>'0');

                $path_frame->Button(
                        -text=>"Browse",
                        -width=>'8',
                        -relief => 'groove',
                        -background => "#333366",
                        -foreground  => "white",
                         -font=>'{Segoe UI Semibold} 12 ',
                        -command=>sub
                        {
                            $File_Name_Path = $main->getOpenFile(
                                        -filetypes=>[
                                            ["xls|xlsx files",'*.xls']
                                            ],
                                        -title=>"Choose the xls file ",
                        );
                
                            if($File_Name_Path)
                            {
                               @File_Select_Arr=split(/\[/, $File_Name_Path);
                               $EDID_Doors_File_Name=$File_Select_Arr[-1];
                               print "EDID_Doors_File_Name =$EDID_Doors_File_Name";
                               $Designation_path = dirname($File_Name_Path); 
                               $Designation_path=$Designation_path."/";
                             
                            }
                                                    
                        }
        )->pack(-side=>'left',-pady=>'0',-padx=>'05',-pady=>'02');
#**************************************************************************************************************
#                   DID Value Entry in text Box                                           *
#**************************************************************************************************************

my $name_frame1 = $main->Frame("-background" => "#888888")->pack(-pady=>'02',-side=>'top',-anchor=>'w');

$name_frame1->Label(
        -text=>"        NOTE: Enter the EDR DID's seprated by comma Ex: 02B1,F10B",
        -background => "#888888",
        -foreground => "white",
        -font=>'{Segoe UI Semibold} 8 bold ')->pack(-side=>'top',-pady=>'02',-ipadx=>'50');

$name_frame1->Label(
        -text=>'     EDR Service ID:    ',
        -background => "#888888",
        -foreground => "blue1",
        -font=>'{Segoe UI Semibold} 10 bold')->pack(-side=>'left',-padx=>'8',-pady=>'1',-anchor=>'w');
      
$name_frame1->Entry(
        -width=>'35',
        -background => "white",
        -textvariable=>\$EDR_Service_IDs)->pack(-side=>'left',-padx=>'1',-pady=>'1',-anchor=>'w');
        
#**************************************************************************************************************
#                   Start Byte Entry in text Box                                            *
#**************************************************************************************************************

my $name_frame2 = $main->Frame("-background" => "#888888")->pack(-pady=>'02',-side=>'top',-anchor=>'nw');

$name_frame2->Label(
    
     -text=>"  NOTE: Enter the Start Byte of EDID in text Box",
    -background => "#888888",
    -foreground => "white",
    -font=>'{Segoe UI Semibold} 8 bold ')->pack(-side=>'top',-pady=>'02',-ipadx=>'50');

$name_frame2->Label(
    -text=>'      Start Byte:           ',
    -background => "#888888",
    -foreground => "blue1",
    -font=>'{Segoe UI Semibold} 10 bold')->pack(-side=>'left',-padx=>'7',-pady=>'02' );

$name_frame2->Entry(
    -width=>'35',
    -background => "white",
    -textvariable=>\$EDID_Start_Byte_From_Panel)->pack(-side=>'left',-ipadx=>'2',-pady=>'02' );

#**************************************************************************************************************
#                   Diagnostics Request ID                                *
#**************************************************************************************************************

 my$name_frame3 = $main->Frame("-background" => "#888888")->pack(-pady=>'02',-side=>'top',-anchor=>'nw');

$name_frame3->Label(
        -text=>"NOTE: Enter the Diagnostics Request ID  ",
        -background => "#888888",
        -foreground => "white",
        -font=>'{Segoe UI Semibold} 8 bold ')->pack(-side=>'top',-pady=>'02',-padx=>'10');

$name_frame3->Label(
        -text=>'     Diag Request ID:',
        -background => "#888888",
        -foreground => "blue1",
        -font=>'{Segoe UI Semibold} 10 bold')->pack(-side=>'left',-padx=>'10',-pady=>'02' );
      
$name_frame3->Entry(
        -width=>'35',
        -background => "white",
        -textvariable=>\$Diag_Request_ID_From_Panel)->pack(-side=>'left',-ipadx=>'2',-anchor=>'nw');
        
#**************************************************************************************************************
#                   Diagnostics Response ID                                       *
#**************************************************************************************************************

my $name_frame4 = $main->Frame("-background" => "#888888")->pack(-pady=>'02',-side=>'top',-anchor=>'nw');

$name_frame4->Label(
        -text=>"NOTE: Enter theDiagnostics Response ID  ",
        -background => "#888888",
        -foreground => "white",
        -font=>'{Segoe UI Semibold} 8 bold ')->pack(-side=>'top',-pady=>'02',-ipadx=>'4');

$name_frame4->Label(
        -text=>'     Diag Response ID:',
        -background => "#888888",
        -foreground => "blue1",
        -font=>'{Segoe UI Semibold} 10 bold')->pack(-side=>'left',-padx=>'7',-pady=>'02' );
      
$name_frame4->Entry(
        -width=>'35',
        -background => "white",
        -textvariable=>\$Diag_Response_ID_From_Panel)->pack(-side=>'left',-ipadx=>'2',-anchor=>'nw');
        
        
#**************************************************************************************************************
#                   End Button Frame                             *
#**************************************************************************************************************


$end_frame = $main->Frame("-background" => "#888888")->pack(-ipadx=>'10', -padx=>'2');
$end_frame->Button(
        -text=>'Exit',
        -width=>'8',
        -font=>'{Segoe UI Semibold} 12 ',
         -background => "Red4",
         -foreground => "white",
          -relief => 'groove',
        -command=>[$main=>'destroy']
        )->pack(-pady=> 10,  -side=>'right');


$end_frame->Button(
        -text=>'Generate',
        -width=>'8',
        -font=>'{Segoe UI Semibold} 12 ',
        -foreground => "white",
        -relief => 'groove',
        -background => "ForestGreen",
        -command=>sub {Generate_File()}
        )->pack(-pady=> 10, -padx=> 10,  -side=>'right');   
        
 # create label in window 'main'
 $main -> Label(
        -textvariable => \$status, #reference to display the status
         -font=>'{Segoe UI Semibold} 12 bold',
        -background  => "#888888",
        -foreground  => "white",
        )-> pack( "-pady" => 6,-side=>'top' );
        
MainLoop;

 
  
 sub Generate_File()
{   
     
    &F_Delete_Old_Files();
    my @EDR_Services_DID_Array =split(/,/,$EDR_Service_IDs);
    #@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    #            Error Handling from the GUI   
     #@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    if(!$EDID_Doors_File_Name)
     {
                  $main->messageBox(
                           '-icon'    => "error", #qw/error info question warning/
                           '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                           '-title'   => 'Attention',
                           '-title'   => 'Attention',
                           '-message' => "Select the xls files exported from doors  !"
                             );
                             
      $status = "!Enter the DID in the Textbo1.";
      $main->update();
    }
  elsif(!$EDR_Service_IDs)
   {
                $main->messageBox(
                         '-icon'    => "error", #qw/error info question warning/
                         '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                         '-title'   => 'Attention',
                         '-title'   => 'Attention',
                         '-message' => "Enter the DID in the Textbox1 !"
                           );
                           
    $status = "!Enter the DID in the Textbo1.";
    $main->update();
    }
    
    elsif(!$EDID_Start_Byte_From_Panel)
       {
                    $main->messageBox(
                             '-icon'    => "error", #qw/error info question warning/
                             '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                             '-title'   => 'Attention',
                             '-title'   => 'Attention',
                             '-message' => "Enter the Start Byte of the EDID in TextBox2 !"
                               );
                               
        $status = "Enter the Start Byte of the EDID in Text Box2 !!.";
        $main->update();
    }
    
    elsif(!$Diag_Request_ID_From_Panel)
           {
        $main->messageBox(
             '-icon'    => "error", #qw/error info question warning/
             '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
             '-title'   => 'Attention',
             '-title'   => 'Attention',
             '-message' => "Enter the  Request ID in TextBox3 !"
               );
                                   
            $status = "Enter the Request ID of the EDID in Text Box3 !!.";
            $main->update();
    }
    
    elsif(!$Diag_Response_ID_From_Panel)
           {
        $main->messageBox(
             '-icon'    => "error", #qw/error info question warning/
             '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
             '-title'   => 'Attention',
             '-title'   => 'Attention',
             '-message' => "Enter the Response ID in Text Box4 !"
               );
                                   
            $status = "Enter the Response ID in Text Box4 !!.";
            $main->update();
    }
    
   
  
   

  else
  {
    my $error_flag= 0;
        foreach my $DID_Value(@EDR_Services_DID_Array)
          {
            if(length($DID_Value)!=4)
            {
              $error_flag=1;
            
            }
           }
            if($error_flag==1)
            {
            $main->messageBox(
             '-icon'    => "error", #qw/error info question warning/
             '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
             '-title'   => 'Attention',
             '-title'   => 'Attention',
             '-message' => "Each DID Length should be 4 bytes !"
                                   );
                                                       
           $status = "Enter the Each DID Length with 4 bytes  !!.";
              $main->update();

    $status= ' Not Started ';
    $main->update();
    }
    
    else
    {
    
     my $RowCnt1 = 0;
          
           my  $Byte_Bit;     
           my  $Description;
           my  $Conversion_Type;
           my  $Default;
           my  $Size_Byte_Bit; 
           my  $Encoding_Name;
           my  $Conversion_ID;
           my  $Encoding_value;
           my  $Conversion_name;
           my  $Linear_Conversion_Unit;
           my  $Raw_value;
           my  $row;      
           my  $row_encoding;
           my  $LastRow;
           my %EDR_Data_Sheet;
           
           my $project_name = "AKLV_Decoder";
           #Remove the 0x in the TK Button 
           $EDR_Service_IDs =~ s/0x//g;
         
           my $DID_count;
          
       
         #SheetName of the Exported Decoder sheet
         %EDR_Data_Sheet = (
               '22_Services_Data'=>"Sheet1",
              );
    
    
          # Start row of the output xls Files        
          my $SRS_Start_Row=4;
        #===========================================================================================
              # column description of the output xls Files  
     
            
        my $DDT_TableSheet;
        my $SRS_WorkSheet;
        my $SRS_WorkBook;
        my $DDT_Summary_Services_Sheet;
        my  $excel;
        my  $DDT_WorkBook;
        my  $DDT_WorkSheet;
        my $Service22_Current_WorkSheet;
        my  $DDT_Audience_Sheet;
        
                  
               # Open the xls using the WIN OLE package  
          use Win32::OLE qw(in with);
          use Win32::OLE::Const 'Microsoft Excel';
          $Win32::OLE::Warn = 3;
          
        # die on errors...
    
        # get already active Excel application or open new
        $excel = Win32::OLE->GetActiveObject('Excel.Application') || Win32::OLE->new('Excel.Application', 'Quit');  
        #$excel->{DisplayAlerts}=0;
        $excel->{Visible} =1;
    
        # open Excel file which comtain  the decoder information 
        $DDT_WorkBook = $excel->Workbooks->Open("$EDID_Doors_File_Name");
        # select workSheet number 1 (you can also select a workSheet by name)
        $DDT_WorkSheet = $DDT_WorkBook->WorkSheets(1);
        
        $excel->{SheetsInNewWorkBook} = 1;
        $SRS_WorkBook = $excel->Workbooks->Add();
      
        
            #^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ Finding the Last Row and Coloumn of the doors Document ^^^^^^^^^^^^^^^^^^^^^^^^
            my $LastRow_EDR_data = $DDT_WorkSheet->UsedRange->Find({What=>"*",
            SearchDirection=>xlPrevious,
            SearchOrder=>xlByRows})->{Row};
            print "Last Row of EDR File =",$LastRow_EDR_data,"\n";
            
            my $LastColoumn_EDR_data = $DDT_WorkSheet->UsedRange->Find({What=>"*",
                SearchDirection=>xlPrevious,
                SearchOrder=>xlByColumns})->{Column};
            print "Last Coloumn of EDR File =",$LastColoumn_EDR_data,"\n";
            
        #^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^Declaration for  the coloumn cells of doors doccuments  ^^^^^^^^^^^^^^^^^^^^^^^^
        my $Xls_EDID_column ;
        my $Xls_Header_column ;
        my $Xls_DataElement_Description_column ;
        my $Xls_Bytes_per_Data_sample_column ;
        my $Xls_Total_Data_Length_column ;
        my $Xls_Unit_column ;
        my $Xls_Factor_column ;
         my $Xls_Offset_column ;
        my $Xls_Data_Value_to_Convert_column ;
        my $Xls_InvalidValue_column ;
        my $Xls_SNA_column ;
		my $Xls_Samplerate_column ;
        
    #^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^Status update in the GUI Window ^^^^^^^^^^^^^^^^^^^^^^^^       
           $status = "Convertion in progress!!!.";
            $main->update();
            
    #^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^Assigning the coloumn attrributes for  the column cells of doors doccuments  ^^^^^^^^^^^^^^^^^^^^^^^^
            my $Header_Filter_Row =1;
            my  $firstrowcoloumn =1;
            my  $FirstRowColoumn_Read;
                foreach $firstrowcoloumn(1..$LastColoumn_EDR_data)
                {
                    $FirstRowColoumn_Read=""; # clear the old data 
                    # Read the bit byte cell value from xls File 
                     $FirstRowColoumn_Read =$DDT_WorkSheet->Cells($Header_Filter_Row,$firstrowcoloumn)->{'Value'};
                     if($FirstRowColoumn_Read =~ m /EDID/)
                     {
                       $Xls_EDID_column = $firstrowcoloumn;
                     }
                     if($FirstRowColoumn_Read =~ m/Data element/)
                      {
                        $Xls_DataElement_Description_column = $firstrowcoloumn;
                     }
                      
                      if($FirstRowColoumn_Read =~ m/Header/)
              {
                $Xls_Header_column = $firstrowcoloumn;
                     }
                 if($FirstRowColoumn_Read =~ m/Data sample/)
                     {
                       $Xls_Bytes_per_Data_sample_column = $firstrowcoloumn;
                     }
                      if($FirstRowColoumn_Read =~ m/Data Length /)
                      {
                        $Xls_Total_Data_Length_column = $firstrowcoloumn;
                     }
                      if($FirstRowColoumn_Read =~ m/Unit/)
                      {
                       $Xls_Unit_column = $firstrowcoloumn;
                     }
                       if($FirstRowColoumn_Read =~ m/Factor /)
                      {
                        $Xls_Factor_column = $firstrowcoloumn;
                     }
                       if($FirstRowColoumn_Read =~ m/Offset /)
                     {
                       $Xls_Offset_column = $firstrowcoloumn;
                     }
                    if($FirstRowColoumn_Read =~ m/invalid data/)
                      {
                        $Xls_InvalidValue_column = $firstrowcoloumn;
                     }
                     if($FirstRowColoumn_Read =~ m/Data value to convert/)
                      {
                        $Xls_Data_Value_to_Convert_column = $firstrowcoloumn;
                     }
                       if($FirstRowColoumn_Read =~ m/data not available/)
                      {
                        $Xls_SNA_column = $firstrowcoloumn;
                     }
					    if($FirstRowColoumn_Read =~ m/Sample Rate /i)
                      {
                        $Xls_Samplerate_column = $firstrowcoloumn;
                     }
                    
                 }
                                      
          ##################################  Coloumn find is completed ########################################
    
         foreach my $edr_did(@EDR_Services_DID_Array)
       {
           print" EDR DID $DID_count = $edr_did","\n";
           my $Services_22_Sheet_Name = "$EDR_Services_DID_Array[$DID_count]";
           $DID_count++;
                # Update the Sheet name based on DDT Doccument . hence it is different for the Each project 
        # ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^Create New Workbook Started ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
      
        $Service22_Current_WorkSheet = $SRS_WorkBook->WorkSheets->Add;
        $Service22_Current_WorkSheet->Activate();    
        $Service22_Current_WorkSheet->{Name} = "$Services_22_Sheet_Name";
        
        
        $SRS_Start_Row=4;
    #^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ Writing the Header in the SRS Doccument ^^^^^^^^^^^^^^^^^^^
           
                    $Service22_Current_WorkSheet->Range("A1:A1")->{'Value'}= "Byte-Bit";
    
                    $Service22_Current_WorkSheet->Range("B1:B1")->{'Value'}= "Byte / Bit Description";
    
                    $Service22_Current_WorkSheet->Range("C1:C1")->{'Value'}= "Size";
                    
                    $Service22_Current_WorkSheet->Range("D1:D1")->{'Value'}= "Header";
                    
                    $Service22_Current_WorkSheet->Range("E1:E1")->{'Value'}= "Type";                
    
                    $Service22_Current_WorkSheet->Range("F1:F1")->{'Value'}= "Name";
                    
                    $Service22_Current_WorkSheet->Range("G1:G1")->{'Value'}= "ID";
    
                    $Service22_Current_WorkSheet->Range("H1:H1")->{'Value'}= "Encoding Value";
    
                    $Service22_Current_WorkSheet->Range("I1:I1")->{'Value'}= "Encoding Name";
					
					 $Service22_Current_WorkSheet->Range("J1:J1")->{'Value'}= "Sample Rate";
                     
                      $Service22_Current_WorkSheet->Range("A2:J2")->{MergeCells} ="True" ;
                     $Service22_Current_WorkSheet->Range("A2:J2")->{'Value'}= "Conversion";            
                    
                    $Service22_Current_WorkSheet->Range("A3:J3")->{MergeCells} ="True" ;
                    $Service22_Current_WorkSheet->Range("A3:J3")->{'Value'}= "Service Response Format";
    
                    $Service22_Current_WorkSheet->Range("A1:J1")->Interior->{ColorIndex} = 36;#    LightYellow = 36 Blue = 5 
                    $Service22_Current_WorkSheet->Range("A2:J2")->Interior->{ColorIndex} = 35;#    LightYellow = 36 Blue = 5 
                    $Service22_Current_WorkSheet->Range("A1:J3")->Font->{FontStyle}="Bold";
                    $Service22_Current_WorkSheet->Range("A1:J2")->{HorizontalAlignment} = xlHAlignCenter;
                    
                    $Service22_Current_WorkSheet->Range("A3:J3")->{HorizontalAlignment} = xlHAlignLeft;
                    $Service22_Current_WorkSheet->Range("A3:J3")->Interior->{ColorIndex} = 33;#    LightYellow = 36 Blue = 5 
    
    #^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ Writing the Header in the SRS Doccument  Completed ^^^^^^^^^^^^^^^^^^^
       my $Xls_EDID_Data_Read ;
        my $Xls_DataElement_Description_Data_Read ;
        my $Xls_Bytes_per_Data_sample_Data_Read ;
        my $Xls_Total_Data_Length_Data_Read ;
        my $Xls_Header_Read;
        my $Xls_Unit_Data_Read ;
        my $Xls_Factor_Data_Read ;
         my $Xls_Offset_Data_Read ;
        my $Xls_Data_Value_to_Convert_Data_Read ;
        my $Xls_InvalidValue_Data_Read ;
        my $Xls_SNA_Data_Read ;
		my $Xls_SampleRate_Data_Read ;
        
        my $Next_EDID_Data_Start_Byte;
        
    my $Byte_Bit_column = 1;
    my $Description_column = 2;
    my $Size_Byte_Bit_column = 3;
    my $Header_column = 4;
    my $Conversion_Type_column = 5;
    my $Conversion_name_column = 6;
    my $Conversion_ID_column = 7;
    my $Encoding_Value_column = 8;
    my $Encoding_Name_column = 9;
	my $SampleRate_column = 10;
        
        # This info have to get from the GUI window (TK) value box
        my $EDID_Start_Byte = 3; # Default value is 3
        $EDID_Start_Byte =$EDID_Start_Byte_From_Panel;# Start Byte will be updated based on the valus provided by the panel
    
                                                foreach $row(2..$LastRow_EDR_data) #From EDID Srart to END which is mentioned in SRS doccuments 
                                                #foreach $row(2..21) #From EDID Srart to END which is mentioned in SRS doccuments 
                                                    {
                                                             # Set All the values to 00
                                                               $Xls_EDID_Data_Read =  "";
                                                                $Xls_DataElement_Description_Data_Read =  "";
                                                                 $Xls_Bytes_per_Data_sample_Data_Read =  "";
                                                                 $Xls_Total_Data_Length_Data_Read =  "";
                                                                  $Xls_Header_Read =  "";
                                                                 $Xls_Unit_Data_Read =  "";
                                                                 $Xls_Factor_Data_Read =  "";
                                                                  $Xls_Offset_Data_Read =  "";
                                                                 $Xls_Data_Value_to_Convert_Data_Read =  "";
                                                                 $Xls_InvalidValue_Data_Read =  "";
                                                                 $Xls_SNA_Data_Read =  "";
																 $Xls_SampleRate_Data_Read="";
    
                                                             # Read the EDID value from xls File 
                                                             $Xls_EDID_Data_Read=$DDT_WorkSheet->Cells($row,$Xls_EDID_column)->{'Value'};
    
                                                             #Read the Description value from xls File
                                                             $Xls_DataElement_Description_Data_Read=$DDT_WorkSheet->Cells($row,$Xls_DataElement_Description_column)->{'Value'};
    
                                                              #Read the Bytes / Data sample value from xls File
                                                             $Xls_Bytes_per_Data_sample_Data_Read=$DDT_WorkSheet->Cells($row,$Xls_Bytes_per_Data_sample_column)->{'Value'};
    
                                                              # Read the Size of Data Length (Byte) cell value from xls File 
                                                             $Xls_Total_Data_Length_Data_Read=$DDT_WorkSheet->Cells($row,$Xls_Total_Data_Length_column)->{'Value'};
    
                                                             # Read the Header cell value from xls File 
                                                                 $Xls_Header_Read=$DDT_WorkSheet->Cells($row,$Xls_Header_column)->{'Value'};
    
                                                               # Read the Unit cell value from xls File 
                                                             $Xls_Unit_Data_Read=$DDT_WorkSheet->Cells($row,$Xls_Unit_column)->{'Value'};
    
                                                              # Read the Factor (Data) cell value from xls File 
                                                             $Xls_Factor_Data_Read=$DDT_WorkSheet->Cells($row,$Xls_Factor_column)->{'Value'};
                                                             
                                                              # Read the Offset (Data)  cell value from xls File 
                                                             $Xls_Offset_Data_Read=$DDT_WorkSheet->Cells($row,$Xls_Offset_column)->{'Value'}; 
                                                              
                                                              # Read theData value to convert cell value from xls File 
                                                             $Xls_Data_Value_to_Convert_Data_Read=$DDT_WorkSheet->Cells($row,$Xls_Data_Value_to_Convert_column)->{'Value'};
    
                                                              # Read the Data value "invalid data" cell value from xls File 
                                                             $Xls_InvalidValue_Data_Read=$DDT_WorkSheet->Cells($row,$Xls_InvalidValue_column)->{'Value'};
                                                             
                                                              # Read the Data value "data not available" cell value from xls File 
                                                             $Xls_SNA_Data_Read=$DDT_WorkSheet->Cells($row,$Xls_SNA_column)->{'Value'}; 
															 
															    # Read the Data value "Sample Rate (Hz) cell value from xls File 
                                                             $Xls_SampleRate_Data_Read=$DDT_WorkSheet->Cells($row,$Xls_Samplerate_column)->{'Value'}; 
                                                             
                                                            print "*************************************************************","\n";
                                                            print "$Xls_EDID_Data_Read =  ","\n";
                                                            print "*************************************************************","\n";
                                                        print "Xls_DataElement_Description_Data_Read =$Xls_DataElement_Description_Data_Read   ","\n";
                                                         print "Xls_Bytes_per_Data_sample_Data_Read =$Xls_Bytes_per_Data_sample_Data_Read   ","\n";
                                                         print "Xls_Total_Data_Length_Data_Read =$Xls_Total_Data_Length_Data_Read ","\n";
                                                          print "Xls_Header_Read =$Xls_Header_Read   ","\n";
                                                         print "Xls_Unit_Data_Read=$Xls_Unit_Data_Read  ","\n";
                                                         print "Xls_Factor_Data_Read=$Xls_Factor_Data_Read  ","\n";
                                                          print "Xls_Offset_Data_Read=$Xls_Offset_Data_Read  ","\n";
                                                         print "Xls_Data_Value_to_Convert_Data_Read=$Xls_Data_Value_to_Convert_Data_Read   ","\n";
                                                          print "Xls_InvalidValue_Data_Read =$Xls_InvalidValue_Data_Read   ","\n";
                                                          print "Xls_SNA_Data_Read =$Xls_SNA_Data_Read ","\n";
														  print "Xls_SampleRate_Data_Read =$Xls_SampleRate_Data_Read ","\n";
    
                                                         # Write in  the SRS Doccument 
                                                        #  Declaration for column for SRS Write doccument
                                                        
                                                        
                                                        my $EDID_Data_Length = 2;
                                                      my %Conversion_Name_Select;
                                                    %Conversion_Name_Select = (
                                                   '1'=>"Hex 1 (1Byte)",
                                                    '2'=>"Hex 2 (2Byte)",
                                                    '3'=>"Hex 3 (3Byte)",
                                                    '4'=>"Hex 4 (4Byte)",
                                                         
                                                  );
                                                        
                                                        if( ($Xls_EDID_Data_Read ) &&($Xls_Bytes_per_Data_sample_Data_Read)&&($Xls_Total_Data_Length_Data_Read))
                                                        {
                                                        print "Enter Loop";
                                                            # If  all the Data from the xls Sheet data are read 
                                                            if( $row==2)
                                                                {
                                                                    $Byte_Bit =$EDID_Start_Byte+$EDID_Data_Length." [0]";
                                                                    $Next_EDID_Data_Start_Byte= $EDID_Start_Byte+$Xls_Header_Read+$EDID_Data_Length+$Xls_Total_Data_Length_Data_Read;
                                                                }
                                                            else
                                                            {
                                                                    my $Data_Read_Byte=$Next_EDID_Data_Start_Byte+$EDID_Data_Length;
                                                                    $Byte_Bit =$Data_Read_Byte." [0]";
                                                                    $Next_EDID_Data_Start_Byte=$Next_EDID_Data_Start_Byte+$Xls_Header_Read+$EDID_Data_Length+$Xls_Total_Data_Length_Data_Read;
                                                            }
                                                         $Service22_Current_WorkSheet->Cells($SRS_Start_Row,$Byte_Bit_column)->{'Value'}=["$Byte_Bit"];
                                                         
                                                         
                                                         $Service22_Current_WorkSheet->Cells($SRS_Start_Row,$Description_column)->{'Value'}=["$Xls_DataElement_Description_Data_Read"];
                                                        my $Number_Of_Samples =($Xls_Total_Data_Length_Data_Read/$Xls_Bytes_per_Data_sample_Data_Read);
                                                         $Size_Byte_Bit= "$Number_Of_Samples"." [0]"."-"."$Xls_Bytes_per_Data_sample_Data_Read";
                                                         $Service22_Current_WorkSheet->Cells($SRS_Start_Row,$Size_Byte_Bit_column)->{'Value'}=["$Size_Byte_Bit"];
                                                         
                                                         if( $Xls_Data_Value_to_Convert_Data_Read  eq  '1' )
                                                                {
                                                                    $Conversion_Type ="Linear";                                                             
                                                                }
                                                         elsif( ($Xls_Data_Value_to_Convert_Data_Read  eq  '1' ) &&$Xls_Unit_Data_Read  ne  '1' )
                                                                {
                                                                    $Conversion_Type ="Identical";
                                                                    $Conversion_name=$Conversion_Name_Select{$Xls_Bytes_per_Data_sample_Data_Read};
                                                                    
                                                                }
                                                            else
                                                            {
                                                                            $Conversion_Type ="Table";
                                                                            $Conversion_name ="Table Values";
                                                            }
                                                            print "Conversion_Type =$Conversion_Type","\n";
                                                            print "Conversion_name =$Conversion_name","\n";
                                                         $Service22_Current_WorkSheet->Cells($SRS_Start_Row,$Header_column)->{'Value'}=["$Xls_Header_Read"];
                                                         $Service22_Current_WorkSheet->Cells($SRS_Start_Row,$Conversion_Type_column)->{'Value'}=["$Conversion_Type"];
                                                         $Service22_Current_WorkSheet->Cells($SRS_Start_Row,$Conversion_name_column)->{'Value'}=["$Conversion_name"];
                                                         $Service22_Current_WorkSheet->Cells($SRS_Start_Row,$Conversion_ID_column)->{'Value'}=["$Xls_EDID_Data_Read"];
														  $Service22_Current_WorkSheet->Cells($SRS_Start_Row,$SampleRate_column)->{'Value'}=["$Xls_SampleRate_Data_Read"];
														  $Service22_Current_WorkSheet->Cells($SRS_Start_Row,$SampleRate_column)->{HorizontalAlignment} = xlHAlignCenter;
                                                            
                                                       
                                                         if($Conversion_Type eq 'Table')
                                                         {
                                                                $Xls_Data_Value_to_Convert_Data_Read=~ s/\'//g; # Remove the comma from the lines
                                                                $Xls_Data_Value_to_Convert_Data_Read=~ s/\"//g; # Remove the comma from the lines
                                                                my @Data_value=split(/\n/,$Xls_Data_Value_to_Convert_Data_Read);
    
                                                                    my %hash = ();
                                                                    foreach my $Linedata(@Data_value)
                                                                    {
                                                                        if($Linedata)
                                                                           {
                                                                                my ($Data_Encoding_value,$Data_Encoding_Name) =split(/:/,$Linedata);
                                                                                $Data_Encoding_Name=~ s/^ //g;
                                                                                #print " $Data_Encoding_value =$Data_Encoding_Name \n";
                                                                                $hash{ $Data_Encoding_value } = $Data_Encoding_Name;
                                                                            }
                                                                     } # End Foor Loop
                                                                   # Add the Invalid Values to the Table 
                                                                   $hash{ "0xFE" } = "invalid data";
                                                                   # Add the SNA Values to the Table 
                                                                   $hash{ "0xFF"} = "data not available";
                                                                   for my $Encoding_value ( sort keys %hash )
                                                                   {
                                                                           my $Encoding_Name = $hash{$Encoding_value};
                                                                           #print "$Encoding_value => $Encoding_Name\n";
                                                                             $Service22_Current_WorkSheet->Cells($SRS_Start_Row,$Encoding_Name_column)->{'Value'}=[$Encoding_Name];
                                                                            $Service22_Current_WorkSheet->Cells($SRS_Start_Row,$Encoding_Value_column)->{NumberFormat} = "@";
                                                                           $Service22_Current_WorkSheet->Cells($SRS_Start_Row,$Encoding_Value_column)->{'Value'}=[$Encoding_value];
                                                                           $SRS_Start_Row++;
                                                                    }
                                                                } # Table IF
                                                            # Search for the received value and corresponding Description
                                                      
                                                          if($Conversion_Type eq 'Linear')
                                                          {
                                                                    if($Xls_Factor_Data_Read)
                                                                    {
                                                                        $Xls_Factor_Data_Read=~ s/,/./g; # Remove the comma from the lines
                                                                       $Xls_Offset_Data_Read=~ s/,/./g; # Remove the comma from the lines
                                                                        my $Conversion_Factor_Structure ="$Xls_Unit_Data_Read ( $Xls_Factor_Data_Read,$Xls_Offset_Data_Read)";
                                                                        $Service22_Current_WorkSheet->Cells($SRS_Start_Row,$Conversion_name_column)->{'Value'}=["$Conversion_Factor_Structure"];
                                                                        # Read the Unit cell value from xls File 
                                                                        $SRS_Start_Row++;
                                                                    }
                                                                    else
                                                                    {
                                                                        my $Conversion_Factor_Structure ="$Xls_Unit_Data_Read ( $Xls_Factor_Data_Read,$Xls_Offset_Data_Read)";
                                                                        $Service22_Current_WorkSheet->Cells($SRS_Start_Row,$Conversion_name_column)->{'Value'}=["ERROR:Specified conversion Factor is 0 in  SRS, Correct and Generate the Decoder Again"];
                                                                        $Service22_Current_WorkSheet->Cells($SRS_Start_Row,$Conversion_name_column)->Interior->{ColorIndex} = 3;#    Red
                                                                        $Service22_Current_WorkSheet->Cells($SRS_Start_Row,$Conversion_name_column)->Font->{FontStyle}="Bold";
                                                                        $Service22_Current_WorkSheet->Cells($SRS_Start_Row,$Conversion_name_column)->{HorizontalAlignment} = xlHAlignCenter;
                                                                        # Read the Unit cell value from xls File 
                                                                        $SRS_Start_Row++;
                                                                    
                                                                    }
                                                                    
    
                                                        }
    
                                                         if($Conversion_Type eq 'Identical')
                                                              {
                                                                 # print "Identical Loop =","\n";
                                                                 #print "SRS_Start_Rowt =",$SRS_Start_Row,"\n";
                                                                $SRS_Start_Row++;
    
                                                            }
                                             }#End  IF EDID and Other data are present
                                                    #End Next Loop
                                                    #Increment the cells in the xls File and do the same Operation              
    
    
    } # End For loop    
    $Service22_Current_WorkSheet->Cells($SRS_Start_Row,$Byte_Bit_column)->{'Value'}=["END_OF_EDID"];
    $Service22_Current_WorkSheet->Cells($SRS_Start_Row,$Byte_Bit_column)->Interior->{ColorIndex} = 10;#    Red
    $Service22_Current_WorkSheet->Cells($SRS_Start_Row,$Byte_Bit_column)->Font->{FontStyle}="Bold";
    $Service22_Current_WorkSheet->Cells($SRS_Start_Row,$Byte_Bit_column)->{HorizontalAlignment} = xlHAlignCenter;
} # End loop for Each Service
    
    
      # ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^Clean up and Saving ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
      my $Final_Xls_File; 
      print "Designation_path =$Designation_path"."\n";
      $Final_Xls_File = "$File_With_Path\\".$project_name.".xls";
      $Final_Xls_File =~ s/\//\\/g;
       $Final_Xls_File =~ s/\//\\/;
      print "Final_Xls_File =$Final_Xls_File"."\n";            
      $SRS_WorkBook->SaveAs({Filename =>"$Final_Xls_File",FileFormat => xlWorkbookNormal}); 
      $SRS_WorkBook->Close();
     
     ##################  Save File is completed ###############################
        

  #%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  #%%%%%%%%%%%%%%%%%%%%%%%%%        CAPL FIle  Updation Started     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  #%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  
  
  # Get the Number of EDID's

  # to write the CAPL File Name
  my $Read_CAPL_File_Name_With_Path ="$File_With_Path\\Template\\"."Generic_Script_Template.can";
   $Read_CAPL_File_Name_With_Path =~ s/\//\\/g;
   $Read_CAPL_File_Name_With_Path =~ s/\//\\/;
  print "CAPL Template File name with Path (INPUT)  =$Read_CAPL_File_Name_With_Path"."\n";            
  my $Write_CAPL_File_Name_With_Path ="$File_With_Path\\canoe\\"."AKLV_EDR_CAPL.can";
   $Write_CAPL_File_Name_With_Path =~ s/\//\\/g;
   $Write_CAPL_File_Name_With_Path =~ s/\//\\/;
  print "CAPL Template File name with Path (OUTPUT)  =$Write_CAPL_File_Name_With_Path"."\n";
  unlink($Write_CAPL_File_Name_With_Path); # Delete the OLD Files 
  
    open (READ,"<$Read_CAPL_File_Name_With_Path") || die("$Read_CAPL_File_Name_With_Path could not open file \n $_!");
    open (WRITE,">$Write_CAPL_File_Name_With_Path") || die("$Write_CAPL_File_Name_With_Path could not be created file \n $_!");
    
    my @Read_File_Array =<READ>;
    $Diag_Request_ID_From_Panel ="0x"."$Diag_Request_ID_From_Panel";
    $Diag_Response_ID_From_Panel="0x"."$Diag_Response_ID_From_Panel";
    foreach my $read_line  (@Read_File_Array)
    {
        $read_line=~ s/0xABCD/$Diag_Request_ID_From_Panel/g; # Replace the 0xABCD with request ID
        $read_line=~ s/0xFEDC/$Diag_Response_ID_From_Panel/g; # Replace the 0xFEDC with Response ID
        print WRITE $read_line;
    
    }
     
      #%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            #%%%%%%%%%%%%%%%%%%%%%%%%%      Update the values in the panel    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            #%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            
            # Get the Number of EDID's
          
            # to write the CAPL File Name
            my $Read_PANEL_File_Name_With_Path ="$File_With_Path\\Template\\"."AKLV_EDR_Daig_Panel_Template.cnp";
             $Read_PANEL_File_Name_With_Path =~ s/\//\\/g;
             $Read_PANEL_File_Name_With_Path =~ s/\//\\/;
            print "Panel Template File name with Path (INPUT)  =$Read_PANEL_File_Name_With_Path"."\n";            
            my $Write_PANEL_File_Name_With_Path ="$File_With_Path\\canoe\\"."AKLV_EDR_Daig_Panel.cnp.";
             $Write_PANEL_File_Name_With_Path =~ s/\//\\/g;
             $Write_PANEL_File_Name_With_Path =~ s/\//\\/;
            print "Panel  File name with Path (OUTPUT)  =$Write_PANEL_File_Name_With_Path"."\n";
            unlink($Write_PANEL_File_Name_With_Path); # Delete the OLD Files 
            
              open (READ_PANEL,"<$Read_PANEL_File_Name_With_Path") || die("$Read_PANEL_File_Name_With_Path could not open file \n $_!");
              open (WRITE_PANEL,">$Write_PANEL_File_Name_With_Path") || die("$Write_PANEL_File_Name_With_Path could not be created file \n $_!");
              
             my @Read_File_PANEL_Array =<READ_PANEL>;
            foreach my $read_line_Panel  (@Read_File_PANEL_Array)
                    {
                
                    if(  $read_line_Panel=~ m/Diag Request/)
                    {
                        print WRITE_PANEL $read_line_Panel;                     
                        last;

                    }
                        
                           
             print WRITE_PANEL $read_line_Panel;
            
             } #my $read_line_Panel  (@Read_File_PANEL_Array)
    
    
     #%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                #%%%%%%%%%%%%%%%%%%%%%%%%%      Update the values in the Data Base Files    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                #%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                
                # Get the Number of EDID's
              
                # to write the CAPL File Name
                my $Read_DBC_File_Name_With_Path ="$File_With_Path\\Template\\"."Diag_Database.dbc";
                 $Read_DBC_File_Name_With_Path =~ s/\//\\/g;
                 $Read_DBC_File_Name_With_Path =~ s/\//\\/;
                print "DBC Template File name with Path (INPUT)  =$Read_DBC_File_Name_With_Path"."\n";            
                my $Write_DBC_File_Name_With_Path ="$File_With_Path\\canoe\\"."AKLV_Database.dbc";
                 $Write_DBC_File_Name_With_Path =~ s/\//\\/g;
                 $Write_DBC_File_Name_With_Path =~ s/\//\\/;
                print "DBC  File name with Path (OUTPUT)  =$Write_DBC_File_Name_With_Path"."\n";
                unlink($Write_DBC_File_Name_With_Path); # Delete the OLD Files 
                
                  open (READ_DBC,"<$Read_DBC_File_Name_With_Path") || die("$Read_DBC_File_Name_With_Path could not open file \n $_!");
                  open (WRITE_DBC,">$Write_DBC_File_Name_With_Path") || die("$Write_DBC_File_Name_With_Path could not be created file \n $_!");
                  
                 my @Read_File_DBC_Array =<READ_DBC>;
             foreach my $read_line_dbc  (@Read_File_DBC_Array)
                        {
                    
                        if(  $read_line_dbc=~ m/BU_:/)
                        {
                            print WRITE_DBC $read_line_dbc,"\n";                        
                            last;
    
                        }
                            
                               
                 print WRITE_DBC $read_line_dbc;
                
    
             } #my $read_line_Panel  (@Rea
     print" EDR DIDEDR_Services_DID_Array = $@EDR_Services_DID_Array","\n";
    foreach my $edr_did(@EDR_Services_DID_Array)
       {
               print" EDR DID edr_did = $edr_did","\n";
               print" EDR DID edr_did = $edr_did","\n";
               my $Services_22_Sheet_Name = "$EDR_Services_DID_Array[$DID_count]";
               my $Xls_ServiceLength_Read =03;
               my $DID_HB= substr($edr_did,0,2);
               my $DID_LB= substr($edr_did,2,2);
               $DID_HB= uc( $DID_HB);
               $DID_LB= uc( $DID_LB);
               my $Xls_ServiceName_Read ="Service22_$DID_HB$DID_LB";
                $DID_HB= "0x".$DID_HB;
                $DID_LB= "0x".$DID_LB;
               my $Xls_ServiceData_Read="0x22,$DID_HB,$DID_LB";
               my $return_Env = &ADD_ENV_Data_TO_CAPL_Files($Xls_ServiceName_Read,$Xls_ServiceData_Read,$Xls_ServiceLength_Read);
                &ADD_Request_TO_Panel_Files($Xls_ServiceData_Read,$return_Env);
                &ADD_EnvNames_TO_DBC_Files($return_Env);

   }
&F_Close_Database();
&F_Close_Panel();
# Close the File Handle of CAPL
close READ;
close WRITE;
   
   
   
   ################################# Sub Routine  to CAPL ###########################################
   sub ADD_ENV_Data_TO_CAPL_Files
   {
        my ($diag_name,$diag_data,$diag_resp_length) =@_;
           
        my  @Diag_Services_Array =split(/,/,$diag_data);
        my $diag_request_length=scalar(@Diag_Services_Array);
        my $env_Name =  "EvTx_"."$diag_name";
        print WRITE  'on envVar '.$env_Name."\n";
        print WRITE  "  {                                                                                                                   ","\n";
        print WRITE "     if(getvalue($env_Name) == 1)                                                              ","\n";
        print WRITE "       {                                                                                                                       ","\n";
        print WRITE "        putvalue(EvClearRxData ,1);                                                                ","\n";
        my $element_index=0;                                                                    
        foreach  my $diag_element(@Diag_Services_Array)                 
        {                                                                                                                   
        print WRITE "           A_TxArray_U8[$element_index]=$diag_element;                                          ","\n";
        $element_index++;
        }                                                                                                           
        print WRITE "           putvalue(EvDispTxLen, $diag_request_length);                                              ","\n";
        print WRITE "           putvalue(EvTxMesgBox, A_TxArray_U8,$diag_request_length);              ","\n";
        print WRITE "           putvalue(EvTxButton,1);                                                                    ","\n";          
        print WRITE "           settimer(T_EDR_Decoder_Timer,15000);                                                                    ","\n";          
        print WRITE "           putvalue($env_Name, 0);                                                                        ","\n";                                      
        print WRITE "       }                                                                                                                        ","\n";        
        print WRITE "   }                                                                                                                           ","\n";     
    return ($env_Name);
   }
  
  
   ################################# Sub Routine  To panel ###########################################
     sub ADD_Request_TO_Panel_Files
     {
        my ($diag_data,$env_name) =@_;
            $diag_data=~ s/,0x/_/g ;
            $diag_data=~ s/^0x//g ;
        my  @Diag_Services_Array =split(/,/,$diag_data);
        
        print WRITE_PANEL "ElemBN 610 "."$Next_Element_Y_position".' 215 35 EnvVar:'."$env_name".' <PE> EnvVar:'."$env_name".' 0 0 0 -16 0 0 0 600 0 0 0 0 3 2 1 34"Segoe UI Semibold""'."$diag_data".'"',"\n";
        $Next_Element_Y_position= $Next_Element_Y_position+$Space_between_Elements;
                                                                                                                    
     }
     
      ################################# Sub Routine  DBC###########################################
          sub ADD_EnvNames_TO_DBC_Files
          {
            my ($env_name) =@_;
                            
             print WRITE_DBC "EV_ $env_name".' : 0 [0|255] "" 0 '."$DBC_Element_Number".' DUMMY_NODE_VECTOR0 Vector__XXX;',"\n\n";
             $DBC_Element_Number++;
                                                                                                                        
          }
 
       print "=================================================================","\n";
       print "  Update in CAPL Files created in path"."$Write_CAPL_File_Name_With_Path","\n";
       print "=================================================================","\n";
   
      
          #$Diag_Request_ID_From_Panel ="0x"."$Diag_Request_ID_From_Panel";
          #$Diag_Response_ID_From_Panel="0x"."$Diag_Response_ID_From_Panel";
        

sub F_Close_Panel
{
print WRITE_PANEL '@
    
[OCX1]
Name=Alarm_States_Indicator


[OCX1_Properties]
1=0700010004000100000000000100ffffff000400010000000000010000ff000004000100000000000100ffffff00110200009502000001000000c0c0c000
',"\n";

# Close the File Handle
close READ_PANEL;
close WRITE_PANEL;

print "=================================================================","\n";
print "  Update in Panel Files created in path","\n";
print "=================================================================","\n\n";
} 

sub F_Close_Database
{
print WRITE_DBC 'EV_ EvNodeIdFromECU: 0 [0|65535] "" 0 1 DUMMY_NODE_VECTOR0 Vector__XXX;

EV_ EvOutWindow3: 0 [0|0] "100" 0 2 DUMMY_NODE_VECTOR8000 Vector__XXX;

EV_ EvOutWindow2: 0 [0|0] "100" 0 3 DUMMY_NODE_VECTOR8000 Vector__XXX;

EV_ EvOutWindow1: 0 [0|0] "100" 0 4 DUMMY_NODE_VECTOR8000 Vector__XXX;

EV_ EvIndLED: 0 [0|0] "" 0 5 DUMMY_NODE_VECTOR0 Vector__XXX;

EV_ EvTxBSMax: 0 [0|255] "" 0 6 DUMMY_NODE_VECTOR0 Vector__XXX;

EV_ EvTxSTMin: 0 [0|255] "" 0 7 DUMMY_NODE_VECTOR0 Vector__XXX;

EV_ EvECUNodeID: 0 [0|255] "" 0 8 DUMMY_NODE_VECTOR3 Vector__XXX;

EV_ EvECUIDEnable: 0 [0|1] "" 0 9 DUMMY_NODE_VECTOR0 Vector__XXX;

EV_ EvDispRxLen: 0 [0|0] "" 0 10 DUMMY_NODE_VECTOR1 Vector__XXX;

EV_ EvDispTxLen: 0 [0|0] "" 0 11 DUMMY_NODE_VECTOR1 Vector__XXX;

EV_ EvClearRxData: 0 [0|1] "" 0 12 DUMMY_NODE_VECTOR0 Vector__XXX;

EV_ EvClearTxData: 0 [0|1] "" 0 13 DUMMY_NODE_VECTOR0 Vector__XXX;

EV_ EvRxMesgBox: 0 [0|0] "" 0 14 DUMMY_NODE_VECTOR1 Vector__XXX;

EV_ EvTxMesgBox: 0 [0|0] "" 0 15 DUMMY_NODE_VECTOR0 Vector__XXX;

EV_ EvTxButton: 0 [0|255] "" 0 16 DUMMY_NODE_VECTOR0 Vector__XXX;

EV_ EvRxMesgID: 0 [0|536871000] "" 0 17 DUMMY_NODE_VECTOR3 Vector__XXX;

EV_ EvTxMesgID: 0 [0|536870911] "" 0 18 DUMMY_NODE_VECTOR3 Vector__XXX;

EV_ EvVariableDLCEnable: 0 [0|0] "" 0 19 DUMMY_NODE_VECTOR0 Vector__XXX;

ENVVAR_DATA_ EvRxMesgBox: 2048;
ENVVAR_DATA_ EvTxMesgBox: 255;

',"\n";

# Close the File Handle
close WRITE_DBC;
close READ_DBC;

print "=================================================================","\n";
print "  Update in DBC Files created in path"."","\n";
print "=================================================================","\n\n";
} 
       
    #%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    #%%%%%%%%%%%%%%%%%%%%%%%%%      Update in perl Script with SRS Doors Files %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    #%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
        #! /usr/bin/perl -w
        
        open (PERLFILE, "+<$File_With_Path\\Generic_Diagnostics_Decoder.pl");
        my @PerlFile_Arr = <PERLFILE>;
        my $xls_file=$EDID_Doors_File_Name;
        my $input_File_Name;
        my   @name_Select_Arr;
        
        if(  $xls_file =~ m/\\/)
        {
           @name_Select_Arr=split(/\\/, $xls_file);
       
            $input_File_Name=$name_Select_Arr[-1];
        }
         if(  $xls_file =~ m/\//)
            {
              @name_Select_Arr=split(/\//, $xls_file);
           
                $input_File_Name=$name_Select_Arr[-1];
        }
        
        seek PERLFILE,0,0;
        
        foreach my $perlfile_line (@PerlFile_Arr)
        {
        #if($file = ~m /AKLV_Doors_Export_File_Name = /)
          if(  $perlfile_line =~ m/(AKLV_Doors_Export_File_Name =)/)
        {
         
         print PERLFILE '$AKLV_Doors_Export_File_Name ='.'"'."$input_File_Name",'";';
         print PERLFILE "\n";
        }
        else
        {
        print PERLFILE $perlfile_line;
        }
        }
    close PERLFILE;
   
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#%%%%%%%%%%%%%%%%%%%%%%%%%      Update in perl Script  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      
            my $Canoe_File_Name_With_Path ="$File_With_Path\\"."AKLV.cfg";
            
            $Canoe_File_Name_With_Path =~ s/\//\\/g;
              $Canoe_File_Name_With_Path =~ s/\//\\/;
             my $return_Value_ofcalling_canoe = system("$Canoe_File_Name_With_Path" );
                if($return_Value_ofcalling_canoe==0)
                {
                  print "=================================================================","\n";
                  print " $Canoe_File_Name_With_Path  is opened ","\n";
                  print "=================================================================","\n";
              }
                else
                {
                $main->messageBox(
                             '-icon'    => "error", #qw/error info question warning/
                             '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                             '-title'   => 'Attention',
                             '-title'   => 'Attention',
                             '-message' => "$Canoe_File_Name_With_Path  is not opened !"
                               );

              $status = "$Canoe_File_Name_With_Path  is not opened.";
            $main->update();
             }     

    # Close Workbook
    $DDT_WorkBook->close();
    $status = "Completed  Press Exit.";
    $main->update();
    print "=================================================================","\n";
    print "=================================================================","\n";
        
    print "All done.";
   
   }

  sub F_Delete_Old_Files
  {
      if("$File_With_Path\\canoe\\"."AKLV_EDR_Daig_Panel.cnp")
    {
        unlink("$File_With_Path\\canoe\\"."AKLV_EDR_Daig_Panel.cnp");
    }
      if("$File_With_Path\\canoe\\"."AKLV_EDR_CAPL.cbf")
        {
            unlink("$File_With_Path\\canoe\\"."AKLV_EDR_CAPL.cbf");
    }
      if("$File_With_Path\\canoe\\"."AKLV_EDR_CAPL.can")
    {
        unlink("$File_With_Path\\canoe\\"."AKLV_EDR_CAPL.can");
    }
      if("$File_With_Path\\canoe\\"."Consecutive_Frame.cbf")
        {
            unlink("$File_With_Path\\canoe\\"."Consecutive_Frame.cbf");
    }
      if("$File_With_Path\\"."AKLV_Decoder.xls")
        {
            unlink("$File_With_Path\\"."AKLV_Decoder.xls");
    }
   }

  } #Else for file is selected
} # sub 


# create
__END__
