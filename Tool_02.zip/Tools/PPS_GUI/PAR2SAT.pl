#!C:\Perl\bin\Perl.exe -w

#################################################################################
# this tool is under version management
my $VERSION = q$Revision: 1.1 $;
my $HEADER  = q$Header: PPS_GUI/PAR2SAT.pl 1.1 2011/05/31 22:15:28ICT ASR2COB develop  $;
#################################################################################

use Tk;
use strict;
use File::Basename;
use Tk::DirTree;
use Getopt::Long;

my $Toolversion = "PAR2SAT ($VERSION)";      # Tool version number

my ($scan_file, $target_folder);
my ( $main, $ValueFrame, $ButtonFrame, $ValueEntry, $display_txt,$DirectoryFrame, $DirectoryEntry ,$DirectoryCheck, $DirectoryButton );

##################################
##Call back function for Checkbox
##################################

sub DisableDirectoryOption
{
    #if checkbox is checked
    if($DirectoryCheck == 1)
    {
        #Disable the Entry and Button for Target folder name
        $DirectoryButton->configure('-state' => 'disabled');
        $DirectoryEntry->configure('-state' => 'disabled',);
        $target_folder = undef;
    }
    else    #if checkbox is not checked
    {
        #Enable the Entry and Button for Target folder name
        $DirectoryButton->configure('-state' => 'normal');
        $DirectoryEntry->configure('-state' => 'normal');
    }
    
}


################################
# create those nice TK widgets #
################################

# create main window 'main'
$main = MainWindow -> new();

# define minimum size of window 'main'
$main -> minsize( 500, 300 );

# create title in window 'main'
$main -> title ( "Convert PAR file to SAT file $VERSION" );

# create label in window 'main'
$main -> Label( "-text" => "Create SAT file from PAR file",
                "-font" => "{MS Sans Serif} 10 bold",
         )
      -> pack( "-pady" => 10 );

# create frame 'ValueFrame' in window 'main'
$ValueFrame = $main -> Frame() -> pack( "-pady" => 5 );

# create frame 'DirectoryFrame' in window 'main'
$DirectoryFrame = $main -> Frame() -> pack( "-pady" => 5 );

# create frame 'ButtonFrame' in window 'main'
$ButtonFrame = $main -> Frame() -> pack( "-pady" => 5 );

# create label in window 'ValueWindow'
$ValueFrame -> Label( "-text" => "PAR file :    ", )
            -> pack( -side => 'left', );

# create entry 'ValueEntry' in 'ValueFrame'
$ValueEntry = $ValueFrame -> Entry(
            "-width" => 50,
            "-textvariable" => \$scan_file, #reference to $prj_id
            );
$ValueEntry -> pack( "-side" => 'left', );

# create 'browse file' button
my $browse = $ValueFrame -> Button
            (
            "-text" => "Browse file",
            "-command" => sub
              {
                      # browse for file
                      $scan_file = $main -> getOpenFile
                        (
                        "-filetypes"  =>
                          [
                          ["par files", '.par'],
                          ["All files", '.*']
                          ],
                        "-title"      => "choose one of the files to scan (*.par)",
                        );
                      # if a file was chosen
                      if ( $scan_file )
                        {
                        #extract directory
                        print "\n $scan_file was chosen\n";
                        }
                      else
                        {
                          print "no filename!\n";
                          # prompt user
                          $main->messageBox(
                              '-icon'    => "error",#qw/error info question warning/
                              '-type'    => "OK",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                              '-title'   => 'Attention',
                              '-message' => "!Please select file first!"
                          );


                       }
              },
            )
              -> pack (-side => 'right',);




# create checkBox for choice of Target folder
my $checkButton = $DirectoryFrame -> Checkbutton( "-text" => "Use same directory as of PAR file", -command => \&DisableDirectoryOption,-variable => \$DirectoryCheck, -onvalue => 1, -offvalue => 0, -indicatoron => 1, )
            -> pack();
        
$checkButton -> select();
         
# create label in 'DirectoryFrame'
my $label = $DirectoryFrame -> Label( "-text" => "SAT File directory : ", )
            -> pack( -side => 'left' );

# create entry 'DirectoryEntry' in 'DirectoryFrame'
$DirectoryEntry = $DirectoryFrame -> Entry(
            "-width" => 55,
            "-textvariable" => \$target_folder,
            '-state' => 'disabled',
            );
$DirectoryEntry -> pack("-side" => 'right',);


# create 'browse folder' button in 'DirectoryFrame'
$DirectoryButton = $DirectoryFrame -> Button
            (
            "-text" => "Browse Folder",
            '-state' => 'disabled',
            "-command" => sub
              {
                           # prompt user
                          $main->messageBox(
                              '-icon'    => "info",#qw/error info question warning/
                              '-type'    => "OK",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                              '-title'   => 'Attention',
                              '-message' => "!Not implemented! Please Enter the directory name If you wish!"
                                           )
  
              },
            )
              -> pack ("-padx" => 5,);

#currently it is not implemented, hence hidden from Window
$DirectoryButton -> packForget();

# create 'exit' button
$ButtonFrame -> Button
  (
  "-text" => "E X I T",
  "-command" => sub
    {
        w2log("\n######################################################################\n");
        w2log(" END OF LOGFILE\n");
        exit
    }
  )
-> pack ("-side" => 'left',"-ipadx" => 10,"-ipady" => 10,"-pady" => 20,"-padx" => 50);


# create 'CREATE' button
$ButtonFrame -> Button
  (
  "-text" => "CREATE",
  "-command" => sub
    { # execute when button is pressed  
        if ($scan_file) { # create project if scan_file was given
            if($DirectoryCheck == 0 && ($target_folder eq "" || !defined($target_folder)))
            {
                $main->messageBox(
                '-icon'    => "error", #qw/error info question warning/
                '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
                '-message' => "!Please enter the target folder!"
            );
            }
            else
            {
                parsePARandConvert2SATFile($scan_file, $target_folder);
                #$scan_file = ""; # set scan_file to undefined
            }
        }
        else{
        # prompt user if scan_file is undefined
            $main->messageBox(
                '-icon'    => "error", #qw/error info question warning/
                '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
                '-message' => "!Please select file first!"
            );
        }
    }
  )
-> pack ("-side" => 'right',"-ipadx" => 10,"-ipady" => 10,"-pady" => 30,"-padx" => 50);

# create label in window 'main'
$main -> Label( "-textvariable" => \$display_txt, #reference to $display_txt
                "-font" => "{MS Sans Serif} 10 bold",
         )
      -> pack( "-pady" => 10 );




########################## MAIN ###############


# the MainLoop is used by perlTK, when it is called all widgets are created and the
# connected actions are done (e.g. when you press a button)

open ( LOG,">PAR2SAT_log.txt" ) or die "Couldn't open PAR2SAT_log.txt : $@";
# create logfile in chosen directory
w2log("######################################################################\n");
w2log("      $Toolversion logfile\n");
w2log("######################################################################\n");

# run with CLI
GetOptions('scan=s' => \$scan_file, 'target:s' => \$target_folder );
if ($scan_file){ # source file & target folder
    w2log("running with CLI\n");
    parsePARandConvert2SATFile($scan_file, $target_folder);
}
else{
  # if no options or less options provided, run TK GUI
  w2log("running with TK\n");
  MainLoop;
}

w2log("\n######################################################################\n");
w2log(" END OF LOGFILE\n");

close (LOG);

########################### MAIN end ################

##################################
# Logfile handling
##################################
sub w2log{
     my $text = shift;
     print LOG $text;
     print $text;
}


###########################################
###########################################
############### SUBROUTINES ###############
###########################################
###########################################
sub digitCheck
{
    my $arrayref = shift;
    my @array = @$arrayref ;
    my $retValue = 0;
    foreach my $item(@array)
    {
        unless($item =~ /^\d*\.*\d+$/i)
        {
            $retValue = 1;
        }
    }
    return $retValue;
}

sub parsePARandConvert2SATFile
{
    my ($voltValue,$time);

    my $PARfile = shift;
    my $TargetFolder = shift;
    my $PARfileContent ;

    #check whether the given .par file is existing
    unless(-e "$PARfile")
    {
        $display_txt = "$PARfile doesn't exists!";
	w2log("$PARfile doesn't exists!\n");
	return;
    }
    
    #check whether the target folder is given by user, else initiate with the folder name of PAR file
    unless(defined($TargetFolder) and $TargetFolder ne "")
    {
	$TargetFolder = dirname($PARfile);
    }

    #check if target folder is existing
    unless(-d "$TargetFolder")
    {
        $display_txt = "$TargetFolder doesn't exists!";
	w2log("$TargetFolder doesn't exists!\n");
	return;
    }

    #open .par file for reading
    open (PARFILE, "<$PARfile") or die "Couldn't open $PARfile!";

    my $temp = "";
    while($temp = <PARFILE>)
    {
      $PARfileContent .= $temp;  
    };
    
    close(PARFILE);

    #split the content based on the expression [MLC_on_off_sequence.*\]
    my @ParsedContent = split (m!(\[MLC_on_off_sequence.*\])! , $PARfileContent);

    my $arrayLength = @ParsedContent;

    #parse through all splitted blocks and extract the info, and print them in .sat file
    for(my $i = 0; $i <  $arrayLength - 1; )
    {
        if($ParsedContent[$i] =~ /\[MLC_on_off_sequence\.(.*)\]/i)
        {
            my $SATfileName = $1;
            
            $TargetFolder =~ s/[\/\\]*$//; # drop trailing slashes
            
            my $TargetFile =  $TargetFolder."\\".$SATfileName.".sat";
            $TargetFile =~ s/\//\\/g;	#replace all forward slashes with backward slashes
            
            my $block = $ParsedContent[$i+1];
            chomp($block);
        
            #get Voltages
            my $volts = "";
            $block =~ /volts\s*=\s*@\((.*?)\)/i and $volts = $1;
            #delete the single quotes/double quotes
            $volts =~ s/['"]//gi;        
            my @voltsArray = split(/,/,$volts);
    
            #get ONtime
            my $ONtime = "";
            $block =~ /ONtime\s*=\s*@\((.*?)\)/i and $ONtime = $1;
            #delete the single quotes/double quotes
            $ONtime =~ s/['"]//gi;        
            my @ONtimeArray = split(/,/,$ONtime);
    
             #get OFFtime
            my $OFFtime = "";
            $block =~ /OFFtime\s*=\s*@\((.*?)\)/i and $OFFtime = $1;
            #delete the single quotes/double quotes
            $OFFtime =~ s/['"]//gi;        
            my @OFFtimeArray = split(/,/,$OFFtime);
    
            my $numOfVolts = @voltsArray;
            my $numOfONtime = @ONtimeArray;
            my $numOfOFFtime = @OFFtimeArray;
        
            if(digitCheck(\@voltsArray))    #check volts contains all digits
            {
                w2log("\nvolts contains invalid characters in $SATfileName! Please check PAR file!\n");
                         $i+= 2;
            }
            elsif(digitCheck(\@ONtimeArray))    #check ONtime contains all digits
            {
                w2log("\nONtime contains invalid characters in $SATfileName! Please check PAR file!\n");
                         $i+= 2;
            }
            elsif(digitCheck(\@OFFtimeArray))    #check OFFtime contains all digits
            {
                w2log("\nOFFtime contains invalid characters in $SATfileName! Please check PAR file!\n");
                        $i+= 2;
            }
            elsif($numOfONtime != $numOfVolts || $numOfOFFtime != $numOfVolts)  #check if volts, ONtime, OFFtime contains same number of data
            {
                w2log("\nvolts, ONtime, OFFtime counts are not same for $SATfileName! Please check PAR file!\n");
                        $i+= 2;
            }
            else
            {
                open(SATFILE, ">$TargetFile") or die "Couldn't open $TargetFile for writing!";
         
                #Print the Header information
                print SATFILE "File name           : $TargetFile\n";
                print SATFILE "Points              : ". $numOfVolts*2 . "\n";    
                print SATFILE "Current Limitations : 5.00\n";
                print SATFILE "Repetitions         : 1\n";
                print SATFILE "\n  U[V] \t t[s]\n";
        
format SATFILE =
@##.###  @###.####
$voltValue, $time
.
                #print the volts and ON/OFFtime in correct format
                for(my $i = 0;$i<$numOfVolts; $i++)
                {
                    $voltValue = $voltsArray[$i];
                    $time = $ONtimeArray[$i] * 0.001;
                    write(SATFILE);
                           
                    $voltValue = 0.000;
                    $time = $OFFtimeArray[$i] * 0.001;
                    write(SATFILE);
                }  
            
                close(SATFILE);
            
                w2log("\n$TargetFile created! \n");
                $display_txt = "$TargetFile created";
                $i+= 2;
            }
        }   
        else
        {
            $i++;
        }
    }
}

# end of program

=head1 usage

Convert MLC_on_off_sequence.par file to .sat file(s).
i.e. It will create a seperate curve file (e.g: "seq_12345.sat") for each parameter set [MLC_on_off_sequence.seq_12345] in .par file.

 CLI: PAR2SAT.pl --scan PARfile [--target [TargetFolder]]

 e.g. PAR2SAT.pl --scan Kline.par
      PAR2SAT.pl --scan Kline.par --target C:\MyFolder
      

If no (or Less) arguments are provided through CLI, GUI will be opened.

A logfile will be written containing all actions.

use 'EXIT' button to finish logfile properly

Note: The parameter set names [MLC_on_off_sequence.seq_12345] must be unique. Else, Overwriting of files will occur.

=head1 AUTHOR

Arulkumar S, E<lt>Arulkumar.S@in.bosch.comE<gt>

=cut
