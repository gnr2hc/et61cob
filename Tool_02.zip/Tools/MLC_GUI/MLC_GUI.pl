#!usr\bin\perl.exe -w
# *****************************************************************************************************
#                                                                                                       
#  Copyright (c) 2012  Robert Bosch GmBH                                                                
#                      Germany                                                                          
#                      All rights reserved                                                              
#                                                                                                       
#******************************************************************************************************
#    $Source: MLC_GUI/MLC_GUI.pl $
#    $Revision: 2.10 $
#    $Author: Rathore Upendra Singh (RBEI/ESA-PP3) (upe1cob) $
#    $State: develop $
#    $Date: 2019/07/05 12:35:04ICT $
#******************************************************************************************************

#################################################################################
# this tool is under MKS version management
my $VERSION = q$Revision: 2.10 $;
my $HEADER  = q$Header: MLC_GUI/MLC_GUI.pl 2.10 2019/07/05 12:35:04ICT Rathore Upendra Singh (RBEI/ESA-PP3) (upe1cob) develop  $;
#################################################################################

my $addpath;
BEGIN
{
    
	unless ( defined $ENV{TURBOLIFT_PERL_HOME} ) {
        print "ENVIRONMET VARIABLE %TURBOLIFT_PERL_HOME% not defined\nplease execute Engine/run_once/_run_once.bat !!!\n\7";
        sleep(10);
        exit;
    }
    if ( uc($^X) ne uc("$ENV{TURBOLIFT_PERL_HOME}\\bin\\perl.exe") ) {
        print "wrong perl, recalling engine with TURBOLIFT_PERL %TURBOLIFT_PERL_HOME% = $ENV{TURBOLIFT_PERL_HOME} ...\n";
        system("%TURBOLIFT_PERL_HOME%\\bin\\perl.exe $0 @ARGV");
        print "recalling done\n";
        exit;
    }
	
	
    use Config;
    use File::Spec;
    use File::Basename;

    # find the LIFT engine path (LIFT_engine_path = ./../)
    my $LIFT_exec_path = File::Spec->rel2abs(dirname(__FILE__)) . '/../Engine';    
    
    # add directories to search path for perl modules    
    $addpath = "$LIFT_exec_path/modules/DLLs/MLC";

    my $perl56 = $addpath . "/Perl56";     #perl 5.6(32-bit) DLL directory
    my $win32 = $addpath . "/Win32";       #perl 5.12, 32-bit DLL directory
    my $win64 = $addpath . "/Win64";       #perl 5.12, 64-bit DLL directory

    if($] =~ m/5.006/i){        #if Perl version is 5.6
        unshift @INC, ($addpath, $perl56);      #Include MLC.pm from Root directory, Load MLC.dll from "Perl56" 
        $ENV{PATH} = $win32 . ";$ENV{PATH}";    #Load MLC_Control.dll from "Win32"
        
    } elsif($] =~ m/5.012/i) {  #if Perl version is 5.12
        if ($Config{'archname'} =~ m/x64/i){     #check the bitness of perl (32-bit or 64-bit)
            unshift @INC, ($addpath, $win64);    #Include MLC.pm from Root directory, Load MLC.dll from "Win64"
            $ENV{PATH} = $win64 . ";$ENV{PATH}"; #Load MLC_Control.dll from "Win64"
        }
        else{
            unshift @INC, ($addpath, $win32);    #Include MLC.pm from Root directory, Load MLC.dll from "Win32"
            $ENV{PATH} = $win32 . ";$ENV{PATH}"; #Load MLC_Control.dll from "Win32"
        }
    }

	push(@INC, "$LIFT_exec_path/modules");
}


use strict;
use MLC;
use Tk;
require Tk::Pane;

#constants for MLC components
use constant SQ_PER_MLC => 32;  #32 squibs per MLC
use constant SW_PER_MLC => 10;  #10 switches per MLC
use constant WL_PER_MLC => 5;   #5 warning lamps per MLC
use constant CAN_PER_MLC => 2;  #2 CAN lines per MLC
use constant FS_PER_MLC => 8;   #8 Freely usable switches per MLC
use constant PAS_PER_MLC => 12; #12 PASes per MLC

my ($main, $display_txt, $FileFrame_1_1, $MLC_in,$stat,$voltage,$MLCwindow,$SQwindow,$SQpane,$WLwindow,$SWwindow);
my ($Registry,$LIFT_exec_path,$isIniFile, $isOldPMfile);

#sections for different Pins present in a MLC
my @MLCSections = ('POWER_SUPPLY_LINES', 'SQUIBS', 'SWITCHES', 'CAN', 'PAS', 'WARNING_LAMPS', 'FREELY_USABLE_SWITCHES');
my (%MLC, %MLCNames);
my($SQcount,$PAScount, $SWcount,$WLcount,$FScount,$CANcount); #declaration of variables to hold count
my (@SQflagShort,@PASflagShort,@SWflagShort,@SWflag,@SWstate,@WLflagShort,@CANflagShort);
my(@PASLabels1, @PASLabels2,@SWLabels1, @SWLabels2,@SQLabels1, @SQLabels2, @WLLabels1, @WLLabels2, @CANLabels1, @CANLabels2);
my ($CANwindow, @HWnumbers,@channels,@tempFrame,$NumOfMLCs,$OldNumOfMLCs, $doneButton,@tbCAN, @tbDEVICE, %CANHWChannels, $CANWindowMsg);
my (@SWlist, @undoShort);

#initialize flags
$isIniFile = 0; $isOldPMfile = 0;

#assign colors for indication of different states
my $opencol = "yellow";
my $shortcol = "red";
$addpath =~ s/^;//; # drop leading semicolon

#initialize values appropriately
$voltage=sprintf("%.3f",13.5);

my $voltstep=0.1;
my $leakage=0;
my $resistance=0;
my $current=0;
$NumOfMLCs = $OldNumOfMLCs = 1;

my $Toolversion = "MLC_GUI ($VERSION)";      # Tool version number

################################
# create those nice TK widgets #
################################

# create main window 'main'
$main = MainWindow -> new("-background"=> "lightgreen");
$main->MoveToplevelWindow (0,0);
# define minimum size of window 'main'
$main -> minsize( 400, 100 );

# create title in window 'main'
$main -> title ( "MLC_GUI $VERSION" );
my $sw = $main->screenwidth;
my $sh = $main->screenheight;

# create label in window 'main'
 
$main -> Label( "-textvariable" => \$display_txt,
                "-font" => "{MS Sans Serif} 10 bold",
         )
      -> grid("-","-","-",'-sticky' => 'n', "-row"=> 0, "-column"=> 0,);



#frame for containing File selection widgets
$FileFrame_1_1 = $main -> Frame("-width" => int($sw * 0.45),
                                "-background" => "lightgreen"
                                
                                )
-> grid();

#label creation
my $lab = $FileFrame_1_1 -> Label( "-text" => "MLC data: ", )
-> grid ( # create entry in 'FileFrame_1_1'
$FileFrame_1_1 -> Entry(
            "-width" => 80,
            "-textvariable" => \$MLC_in, #reference 
            ));
######## connection


# create 'browse file' button in 'FileFrame_1_1'
$FileFrame_1_1 -> Button
  (
  "-text" => "Browse file",
  "-command" => sub
    {
      # browse for file
      $MLC_in = $main -> getOpenFile
        (
        "-filetypes"  =>
          [
          ["MLC files", '.ini'],
          ["MLC files", '.pm'],
          ["All files", '.*']
          ],
        "-title"      => "choose MLC data file",
        );
      # if a file was chosen
      if ( $MLC_in )
        {

        $MLC_in =~ s/\//\\/g; # replace all slashes with backslahes
        w2log("\n $MLC_in was chosen\n");
        
        # drop previous configuration settings
        $MLCwindow -> gridForget() if $MLCwindow;
        $SQwindow -> withdraw() if $SQwindow;
        $WLwindow -> gridForget() if $WLwindow ;

        #close MLC hardware
        $stat = mlc_CloseHW();

        #if .ini file is selected, just get number of MLCs to be used and proceed  
        if ( $MLC_in =~ /\.ini$/){
            $isIniFile = 1;
            loadHWini();
            
        } #if .pm file is selected, get MLC numbers , Hardware details(CAN HW number, CAN channel)
        elsif ( $MLC_in =~ /\.pm$/){
            $isIniFile = 0;
            loadProjectConst();
        }
      else
        {
          print "no filename!\n";
          # prompt user
          $main->messageBox(
              '-icon'    => "error", #qw/error info question warning/
              '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
              '-title'   => 'Attention',
              '-message' => "!Please select file first!"
          );


       }
      }
    },
  )
   -> grid("-","-","-");




#++++++++++++++++++++++++++++++++++++++++++++++
########################## MAIN ###############
# the MainLoop is used by perlTK, when it is called all widgets are created and the
# connected actions are done (e.g. when you press a button)


open ( LOG,">MLC_GUI_log.txt" ) or die "Couldn't open MLC_GUI_log.txt : $@";
w2log("######################################################################\n");
w2log("### MiniLabCar GUI ###\n"); 
w2log("######################################################################\n");
w2log("$Toolversion logfile\n");

$stat = mlc_Start();
w2log("perl: ($stat) started\n");
if($stat<0){print"error loading MLC dll";system("pause");}
else{
    #load default configuration
    $MLC_in='.\MLC_ProjectConst_default.pm';
    loadProjectConst();
    
    #while minimizing, every widget shoould be resized
    my ($columns, $rows) = $main->gridSize( );
    for (my $i = 0; $i < $columns; $i++) {
      $main->gridColumnconfigure($i, -weight => 1);
    }
    for (my $i = 0; $i < $rows; $i++) {
      $main->gridRowconfigure($i, -weight => 1);
    }
    
    MainLoop;
}
w2log("\n######################################################################\n");
w2log(" END OF LOGFILE\n");
close (LOG);

#-------------------- MAIN end ---------------#
#++++++++++++++++++++++++++++++++++++++++++++++
#********************************************************************************************
# Name              : loadHWini
# Description       : function if .ini file is selected
# Parameters        : ---
# Return Values     : ---
#********************************************************************************************
sub loadHWini{
    my $result = system( "copy \"$MLC_in\" \"$addpath\\MLC.ini\" /Y/A" );     # copy single file with DOS command xcopy
    if( $result ){
        $display_txt="could not copy file $MLC_in to $addpath\\MLC.ini";
        return;
    }
    
    loadProjectConst();
}

#********************************************************************************************
# Name              : loadProjectConst
# Description       : function if .pm file is selected
# Parameters        : ---
# Return Values     : ---
#********************************************************************************************
sub loadProjectConst{
            
    my ($section,$key,$MLCs);
    
    unless( $isIniFile)
    {
        # MLC.ini
        $LIFT_PROJECT::Defaults=();
        do "$MLC_in";          #package LIFT_PROJECT
    
        #if 'POWER_SUPPLY_LINES' section is in outside , its time for Backward compatibility
        if(exists $LIFT_PROJECT::Defaults->{'MLC'}->{'POWER_SUPPLY_LINES'}){
    
            #Copy all the sections existing sections in {'MLC'} to {'MLC'}->{'MLC1'}
            foreach my $section (@MLCSections) { 
                %{$LIFT_PROJECT::Defaults->{'MLC'}->{'MLC1'}->{$section}} = %{$LIFT_PROJECT::Defaults->{'MLC'}->{$section}} if(exists $LIFT_PROJECT::Defaults->{'MLC'}->{$section});
            }
            
            $isOldPMfile = 1;
            
        }
        else
        {
            $isOldPMfile = 0; #reset the indicator for old pm file
        }
     
        unless (defined $LIFT_PROJECT::Defaults->{'MLC'}{'MLC1'}{'POWER_SUPPLY_LINES'}){
            $display_txt= "No MLC settings found in $MLC_in";return;
        }
        $display_txt= "loaded $MLC_in";
    }
    #update MLC settings with CAN settings from user
    $NumOfMLCs = 1;
    
    #if $CANwindow is not created, create the window
    unless ($CANwindow)
    {
        $CANwindow = $main->Toplevel("-title" => "CAN settings");
        $CANwindow -> minsize( 400, 100 );
        
        #disable close option of the window
        $CANwindow->protocol('WM_DELETE_WINDOW',sub{return;});
        
        $CANwindow->Label(-textvariable=>\$CANWindowMsg , "-font" => "{MS Sans Serif} 10 bold",)->grid(-sticky=>"nsew", -pady => 10);           
        my $NumMLCFrame = $CANwindow -> Frame() -> grid(-pady => 10);
         
        Tk::grid("x",$NumMLCFrame->Button(-text=> "+","-command" => sub{
            #only increment/decrement if new type pm files are used
            unless($isOldPMfile && !$isIniFile){
                $NumOfMLCs++;
                createMLCFrames();
            }else{
               $CANWindowMsg = "only one MLC can be used with old .pm file format"; 
            }
        }), -sticky => "nsew" );
        
        $NumMLCFrame -> Label(-text=>"Number of MLCs used:", "-background" => "yellow")
            -> grid(  $MLCs = $NumMLCFrame -> Optionmenu
            (
                "-textvariable" => \$NumOfMLCs,
                "-variable" => \$NumOfMLCs,
                
            ));
        Tk::grid("x",$NumMLCFrame->Button(-text=> "-","-command" => sub{
            #only increment/decrement if new type pm files are used
            unless($isOldPMfile  && !$isIniFile){
                if($NumOfMLCs > 1){
                    $NumOfMLCs--;
                }
                createMLCFrames();
            }
        }), -sticky => "nsew", );
    }
    
    $CANwindow->deiconify();
    createMLCFrames();

    #send back the main window
    $main->lower();
    
    #focus the CAN Window
    $CANwindow->focus();
  
}

#********************************************************************************************
# Name              : createMLCFrames
# Description       : create MLC CAN HW number, CAN channel frames for getting input from the user
#                           And checks the validness of the input from the user
# Parameters        : ---
# Return Values     : ---
#********************************************************************************************
sub createMLCFrames{
    $CANWindowMsg = "";
    
    #delete the already created frames , if any
    foreach my $mlcNum(0..$OldNumOfMLCs-1){
         $tempFrame[$mlcNum]->gridForget() if($tempFrame[$mlcNum]);
    }    
    
    #delete the "done" button
    $doneButton-> gridForget() if($doneButton);
    
    #show the CAN frames only if PM file is used. i.e., for INI file, the user has to mention CAN details directly in INI file
    unless($isIniFile)
    {
        #get the available CAN hardware details 
        my ($stat, $HWSerialNumbers, $CANChannels) = mlc_GetCANHWList();
    
        #return if No hardwares found
        if(scalar(@$HWSerialNumbers) <= 0){
            $CANWindowMsg = "No CAN Hardwares connected";
            return;        
        }
        
        #put the details into Hash , to load the details when a particular Hardware is selected
        for(my $i = 0; $i < @$HWSerialNumbers; $i++){
            $CANHWChannels{$$HWSerialNumbers[$i]} = $$CANChannels[$i];
        }   
        
        #create CAN details frames,equal to the Number of MLCs
        foreach my $mlcNum(0..$NumOfMLCs-1) {
            $tempFrame[$mlcNum] = $CANwindow -> Frame()->grid(-pady => 5); 
            $tempFrame[$mlcNum]  -> Label( "-text" => "MLC-". ($mlcNum + 1). " CAN HW number: ", ) -> grid(
                $HWnumbers[$mlcNum] = $tempFrame[$mlcNum]-> Optionmenu (
                    "-textvariable" => \$tbDEVICE[$mlcNum],                                                    
                    "-variable" => \$tbDEVICE[$mlcNum],
                    "-relief"       => 'groove',
                    "-options" => [@$HWSerialNumbers],
                )
                ,
            
                $tempFrame[$mlcNum] -> Label( "-text" => "MLC". ($mlcNum + 1). " CAN channel: ", ),
                $channels[$mlcNum] = $tempFrame[$mlcNum]-> Optionmenu
                (
                "-textvariable" => \$tbCAN[$mlcNum],
                "-variable" => \$tbCAN[$mlcNum],
                "-relief"       => 'groove',
                "-options" => [1..$CANHWChannels{$tbDEVICE[$mlcNum]}],
                )
            );
            
            #load channel numbers based on selected Hardware number
            $HWnumbers[$mlcNum]->configure("-command" => sub{
                        my $selectedHW = $tbDEVICE[$mlcNum];
                        if(exists($CANHWChannels{$selectedHW})){
                            $channels[$mlcNum]->configure(-options=>[]);
                            for(my $tempChannel = 0; $tempChannel < $CANHWChannels{$selectedHW}; $tempChannel++)
                            {
                                $channels[$mlcNum]->addOptions([$tempChannel+1 => $tempChannel+1]);
                            }
                        }
                    }
            );
        }
    }
     
     #insert "Done" button
    $doneButton = $CANwindow -> Button
     (
        "-text" => "Done",
        "-command" => sub
        {
            #prepare ini file only for pm file input
            unless($isIniFile)
            {
                foreach my $mlcNum1(0..$NumOfMLCs-1){
                    unless (defined $tbCAN[$mlcNum1] && defined $tbDEVICE[$mlcNum1])
                    {
                        $CANWindowMsg = "CAN Hardware or CAN channel number not selected for MLC-" . ($mlcNum1+1);
                         return;
                    }
                    
                    foreach my $mlcNum2($mlcNum1+1..$NumOfMLCs-1)
                    {
                        unless (defined $tbCAN[$mlcNum2]  && defined $tbDEVICE[$mlcNum2] ){
                            $CANWindowMsg = "CAN Hardware or CAN channel number not selected for MLC-" . ($mlcNum2 + 1);
                            return;
                        }
                        if(($tbCAN[$mlcNum1] == $tbCAN[$mlcNum2]) && ($tbDEVICE[$mlcNum1] == $tbDEVICE[$mlcNum2])){
                            $CANWindowMsg = "same CAN Hardware and CAN channel selected for MLC-" . ($mlcNum1 + 1) ." & MLC-" . ($mlcNum2 + 1);
                            return;
                        }
                        
                    }
                    
               }
                
                #write MLC.ini file in proper format
                open ( OUT, ">$addpath\\MLC.ini" );
                foreach my $mlcNum(0..$NumOfMLCs-1)
                {
                    #if a common "General" section is provided, the individual "General" sections will be overridden
                    if(exists $LIFT_PROJECT::Defaults->{'MLC'}->{'General'}) {
                        %{$LIFT_PROJECT::Defaults->{'MLC'}->{"MLC". ($mlcNum+1)}->{'General'}} = %{$LIFT_PROJECT::Defaults->{'MLC'}->{'General'}};
                    }
                    
                    $LIFT_PROJECT::Defaults->{'MLC'}->{"MLC". ($mlcNum+1)}->{'General'}->{'CAN'} = $tbCAN[$mlcNum];
                    $LIFT_PROJECT::Defaults->{'MLC'}->{"MLC". ($mlcNum+1)}->{'General'}->{'CANHWSERIALNUMBER'} = $tbDEVICE[$mlcNum];
                    foreach my $section (sort keys %{$LIFT_PROJECT::Defaults->{'MLC'}{"MLC". ($mlcNum+1)}}){
                        print OUT "\n[". "MLC". ($mlcNum+1). "_$section]\n";
                        foreach my $key (sort keys %{$LIFT_PROJECT::Defaults->{'MLC'}->{"MLC". ($mlcNum+1)}->{$section}}){
                            print OUT "$key = " . $LIFT_PROJECT::Defaults->{'MLC'}->{"MLC". ($mlcNum+1)}->{$section}->{$key} ."\n";
                        }
                    }
                }

                close (OUT);
            }
            $CANwindow -> withdraw();
            MLCstart();
        }
     ) -> grid(-pady => 20); 

    #keep a copy of current number of MLCs
    $OldNumOfMLCs = $NumOfMLCs;
}


#********************************************************************************************
# Name              : MLCstart
# Description       : This function is used to create the UIs for MLC components
# Parameters        : ---
# Return Values     : ---
#********************************************************************************************
sub MLCstart{

    my $MLC_ini = "$addpath\\MLC.ini";
    my ($Label,$line);
    my (@PSLlist,@FSlist,@SWopen,@SWclose,@FSopen,@FSclose,@SQlist,@WLlist,@PASlist,@FSca,@FScb,@FSnc,@CANlist);
    my ($resistanceEntry, $leakageEntry, $currentEntry);
    @PSLlist=("nc")x5;
    @SWlist=("nc")x((SW_PER_MLC+1)*$NumOfMLCs);
    @SWopen=("open")x((SW_PER_MLC+1)*$NumOfMLCs);
    @SWclose=("close")x((SW_PER_MLC+1)*$NumOfMLCs);
    @SQlist=("nc")x((SQ_PER_MLC+1)*$NumOfMLCs);
    @WLlist=("nc")x((WL_PER_MLC+1)*$NumOfMLCs);
    @PASlist=("nc")x((PAS_PER_MLC+1)*$NumOfMLCs);
    @FSlist=("nc")x((FS_PER_MLC+1)*$NumOfMLCs);
    @FSca=("CA")x((FS_PER_MLC+1)*$NumOfMLCs);
    @FScb=("CB")x((FS_PER_MLC+1)*$NumOfMLCs);
    @FSnc=("NC")x((FS_PER_MLC+1)*$NumOfMLCs);
    @CANlist=("nc")x((CAN_PER_MLC+1)*$NumOfMLCs);
    
    #calculate counts of squibs, switches, CAN, Warninglamps, Freely usable switches based on MLC number
    $SQcount = SQ_PER_MLC * $NumOfMLCs;
    $PAScount = PAS_PER_MLC * $NumOfMLCs;
    $SWcount= SW_PER_MLC * $NumOfMLCs;
    $WLcount= WL_PER_MLC * $NumOfMLCs;
    $FScount= FS_PER_MLC * $NumOfMLCs;
    $CANcount= CAN_PER_MLC * $NumOfMLCs;

    %MLC = ();
    %MLCNames = ();
    
    my ($SQframe, $FSframe, $SWframe,$WLframe,$CANframe,$PASframe);
    open ( IN,"<$MLC_ini" ) or die "Couldn't open $_ : $@";
    my ($mlcKey, $mlcNumber);
    
    #parse the ini file
    while($line = <IN>){
        #adapted for accepting old ini file
        $mlcKey = 'MLC1' if($NumOfMLCs == 1 && !defined($mlcKey));
        
        #scan for line labels
        if($line =~ /^\[(MLC(\d+))_(\w+)\]/) {
            
            $mlcKey = $1;
            $mlcNumber = $2;
            $MLC{$mlcKey}{'MLCNUMBER'} = $mlcNumber;
        }
        
        if ($line =~ /^\s*(\w+)\s*=\s*(\w+)/) {
            unless(defined($mlcKey)) {
                $display_txt = "configuration file is not written in correct format";
                return;
            } 
            $MLC{$mlcKey}{$1}=$2;
        }
    }
    close(IN);
    
    #get the names of components and save it in hash
    foreach my $tempmlcNum (1..$NumOfMLCs){
        foreach my $name(sort keys%{$MLC{"MLC$tempmlcNum"}}){
            if ($name =~ /^SW(\d+)_Name/){
                w2log("MLC$tempmlcNum $name $MLC{\"MLC$tempmlcNum\"}{$name}  ");
                
                #check the uniqueness of the Label in configuration file
                $Label = $MLC{"MLC$tempmlcNum"}{$name};
                return unless(validateLabel($Label));

                w2log("$MLC{\"MLC$tempmlcNum\"}{$Label.'_CLOSED'} ");
                w2log("$MLC{\"MLC$tempmlcNum\"}{$Label.'_OPEN'}\n");  
                $SWlist[($tempmlcNum-1)* SW_PER_MLC + $1]= $Label;
                $SWopen[($tempmlcNum-1)*SW_PER_MLC + $1]=$MLC{"MLC$tempmlcNum"}{$Label.'_OPEN'} if($MLC{"MLC$tempmlcNum"}{$Label.'_OPEN'});
                $SWclose[($tempmlcNum-1)*SW_PER_MLC + $1]=$MLC{"MLC$tempmlcNum"}{$Label.'_CLOSED'} if($MLC{"MLC$tempmlcNum"}{$Label.'_CLOSED'});
            }
            elsif ($name =~ /^SQ(\d+)_Name/){
                w2log("MLC$tempmlcNum $name $MLC{\"MLC$tempmlcNum\"}{$name} \n");
                
                 #check the uniqueness of the Label in configuration file
                 $Label = $MLC{"MLC$tempmlcNum"}{$name};
                 return unless(validateLabel($Label));
                
                $SQlist[($tempmlcNum-1) * SQ_PER_MLC + $1] = $Label;
            }
            elsif ($name =~ /^FS(\d+)_Name/){
                w2log("MLC$tempmlcNum $name $MLC{\"MLC$tempmlcNum\"}{$name}  ");
                
                #check the uniqueness of the Label in configuration file
                $Label = $MLC{"MLC$tempmlcNum"}{$name};
                return unless(validateLabel($Label));
                
                w2log("$MLC{\"MLC$tempmlcNum\"}{$Label.'_STATE_CA'} ");
                w2log("$MLC{\"MLC$tempmlcNum\"}{$Label.'_STATE_CB'} ");
                w2log("$MLC{\"MLC$tempmlcNum\"}{$Label.'_STATE_NC'}\n");
                $FSlist[($tempmlcNum-1)*FS_PER_MLC + $1]= $Label;
                $FSca[($tempmlcNum-1)*FS_PER_MLC+ $1]=$MLC{"MLC$tempmlcNum"}{$Label.'_STATE_CA'} if($MLC{"MLC$tempmlcNum"}{$Label.'_STATE_CA'});
                $FScb[($tempmlcNum-1)*FS_PER_MLC + $1]=$MLC{"MLC$tempmlcNum"}{$Label.'_STATE_CB'} if($MLC{"MLC$tempmlcNum"}{$Label.'_STATE_CB'});
                $FSnc[($tempmlcNum-1)*FS_PER_MLC + $1]=$MLC{"MLC$tempmlcNum"}{$Label.'_STATE_NC'} if($MLC{"MLC$tempmlcNum"}{$Label.'_STATE_NC'});
            }
            elsif ($name =~ /^PAS(\d+)_Name/){
                w2log("MLC$tempmlcNum $name $MLC{\"MLC$tempmlcNum\"}{$name}\n");
                
                #check the uniqueness of the Label in configuration file
                $Label = $MLC{"MLC$tempmlcNum"}{$name};
                return unless(validateLabel($Label));

                $PASlist[($tempmlcNum-1)*PAS_PER_MLC + $1]=$MLC{"MLC$tempmlcNum"}{$name};
            }
            elsif ($name =~ /^WL(\d+)_Name/){
                w2log("MLC$tempmlcNum $name $MLC{\"MLC$tempmlcNum\"}{$name}\n");
                
                #check the uniqueness of the Label in configuration file
                $Label = $MLC{"MLC$tempmlcNum"}{$name};
                return unless(validateLabel($Label));    
                
                $WLlist[($tempmlcNum-1)*WL_PER_MLC + $1]=$Label;
            }
            elsif ($name =~ /^CAN(\d+)_Name/){
                w2log("MLC$tempmlcNum $name $MLC{\"MLC$tempmlcNum\"}{$name}\n");
                
                #check the uniqueness of the Label in configuration file
                $Label = $MLC{"MLC$tempmlcNum"}{$name};
                return unless(validateLabel($Label));

                $CANlist[($tempmlcNum-1)*CAN_PER_MLC + $1]=$Label;
            }
            elsif ($name =~ /^PSL(\d+)_Name/){
                w2log("MLC$tempmlcNum $name $MLC{\"MLC$tempmlcNum\"}{$name}\n");
                
                 #check the uniqueness of the Label in configuration file
                $Label = $MLC{"MLC1"}{$name};
                return unless(validateLabel($Label));

                $PSLlist[$1]=$MLC{"MLC1"}{$name};
            }
        }
    }
    w2log("\n\n");

    #default switch state is "closed"
    @SWstate = @SWclose;
    my ($PSLframe,$Vframe,$Lframe,$VLframe  );


    $MLCwindow = $main->Scrolled("Pane", Name => 'MLCPower',
        -scrollbars => 'osoe',
        -gridded => 'y',
        -sticky => 'nsew',
        -background => "lightblue",
        -width => int($sw * 0.55),
        -height => int($sh * 0.85),
    );



    $MLCwindow->grid($WLwindow = $main->Scrolled("Pane", Name => 'MLCPower',
        -scrollbars => 'osoe',
        -sticky => 'nsew',
        -gridded => 'y',
        -background => "lightblue",
        -width => int($sw * 0.45),
        -height => int($sh * 0.85),
    ), -sticky => 'nw', -padx => 5 ); 


    $PSLframe = $MLCwindow -> Frame()->grid();
    $Vframe = $PSLframe -> Frame() -> grid(
    $Lframe = $PSLframe -> Frame(), -padx => 10, -pady => 10) ;
    
    $VLframe = $MLCwindow -> Frame()->grid(-pady => 20);
    
    my (@PLShandle,@SWhandle,@FShandle,$PSLall);
    my $count;
    my ($Vframe1,$Vframe2,$Vframe3);

    #create entries for leakage resistor, set_resistance resistor, and current value
    $Lframe  -> Label("-text" => "leakage resistor for all shorts:")
     -> grid ( $leakageEntry = $Lframe -> Entry("-width" => 5,"-textvariable" => \$leakage, ),
            $Lframe -> Label("-text" => " Ohms")
             );

    $Lframe  -> Label("-text" => "resistor value for set_resistance:")
     -> grid ($resistanceEntry = $Lframe -> Entry("-width" => 5, "-textvariable" => \$resistance, ),
            $Lframe -> Label("-text" => " Ohms")
             );

    $Lframe -> Label("-text" => "current value for set_current:")
    -> grid ( $currentEntry = $Lframe -> Entry("-width" => 5,"-textvariable" => \$current, ),
            $Lframe -> Label("-text" => " mA")
            );

    $Vframe1 = $Vframe -> Frame() -> grid();
    $Vframe2 = $Vframe -> Frame() -> grid(); 
    $Vframe3 = $Vframe -> Frame() -> grid(); 


    #frames for voltage manipulation
    $Vframe1 -> Button("-text" => "+","-command" => sub{ $voltage+=10;  setVoltage();})
    -> grid(
            $Vframe1 -> Button("-text" => "+", "-command" => sub{ $voltage+=1; setVoltage();}),
            $Vframe1 -> Label("-text" => "."),
            $Vframe1 -> Button("-text" => "+","-command" => sub{ $voltage+=0.1; setVoltage(); }),
            $Vframe1 -> Button("-text" => "+","-command" => sub{ $voltage+=0.01; setVoltage();}),
            $Vframe1 -> Button( "-text" => "+", "-command" => sub{$voltage+=0.001; setVoltage();}),
        );
    
    $Vframe2 -> Button( "-text" => "SET voltage:","-command" => sub{ setVoltage(); })
    -> grid( $Vframe2 -> Entry("-width" => 6, "-textvariable" => \$voltage,));

    $Vframe3 -> Button( "-text" => "- ", "-command" => sub{$voltage-=10; setVoltage(); })
    -> grid(
            $Vframe3 -> Button( "-text" => "- ", "-command" => sub{ $voltage-=1; setVoltage(); }),
            $Vframe3 -> Label("-text" => "."),
            $Vframe3 -> Button("-text" => "- ","-command" => sub{ $voltage-=0.1; setVoltage(); }),
            $Vframe3 -> Button("-text" => "- ", "-command" => sub{ $voltage-=0.01; setVoltage(); }),
            $Vframe3 -> Button("-text" => "- ","-command" => sub{$voltage-=0.001;setVoltage(); })
        );

    #power supply lines button
     foreach $count (1..4){

        $PLShandle[$count]=$VLframe -> Button(
          "-text" => $PSLlist[$count],
          "-command" => sub
            {
                if ($PLShandle[$count] -> cget("-background") ne "green"){
                    $PLShandle[$count] -> configure( "-background" => "green");
                    $PLShandle[$count] -> configure( "-activebackground" => "green");
                    
                    #PS will be connected/disconnected only in MCL1
                    $stat = mlc_PSconnect($PSLlist[$count], 1);
                    w2log("($stat) mlc_PSconnect($PSLlist[$count])\n");
                      check_status($stat);
                }    
                else{
                    $PLShandle[$count] -> configure( "-background" => "SystemButtonFace");
                    $PLShandle[$count] -> configure( "-activebackground" => "SystemButtonFace");
                    $stat = mlc_PSdisconnect($PSLlist[$count], 1);
                    w2log("($stat) mlc_PSdisconnect($PSLlist[$count])\n");
                      check_status($stat);
                }

            }
          );
        
        #disable PS button if name is not given
        if ($PSLlist[$count] eq "nc"){
            $PLShandle[$count] -> configure( "-state" => "disabled");
        };
     }
       
       
    #All PS lines button 
    $PSLall=$VLframe -> Button(
      "-text" => "ALL PS lines",
      "-command" => sub
        {
            if ($PSLall -> cget("-background") ne "green"){
                $PSLall -> configure( "-background" => "green");
                $PSLall -> configure( "-activebackground" => "green");
                foreach $count (1..4){
                    if ($PSLlist[$count] ne "nc"){
                        $PLShandle[$count] -> configure( "-background" => "green");
                        $PLShandle[$count] -> configure( "-activebackground" => "green");
                        $stat = mlc_PSconnect($PSLlist[$count], 1);
                        w2log("($stat) mlc_PSconnect($PSLlist[$count])\n");
                      check_status($stat);
                    }
                }
            }    
            else{
                $PSLall -> configure( "-background" => "SystemButtonFace");
                $PSLall -> configure( "-activebackground" => "SystemButtonFace");
                foreach $count (1..4){
                    if ($PSLlist[$count] ne "nc"){
                        $PLShandle[$count] -> configure( "-background" => "SystemButtonFace");
                        $PLShandle[$count] -> configure( "-activebackground" => "SystemButtonFace");
                        $stat = mlc_PSdisconnect($PSLlist[$count], 1);
                        w2log("($stat) mlc_PSdisconnect($PSLlist[$count])\n");
                      check_status($stat);
                    }
                }
            }

        }
      )
    -> grid($PLShandle[1] , $PLShandle[2] , $PLShandle[3], $PLShandle[4] );
    



    my ($SWframe1,$SWframe2);

    $SWwindow = $MLCwindow -> Frame("-relief" => 'solid',  "-borderwidth" => 1,) -> grid(); 

    $SWwindow -> Label("-text" => "switches")-> grid(-pady => 10); 
    $SWframe = $SWwindow -> Frame(  "-relief" => 'solid',  "-borderwidth" => 1,) -> grid();
    $SWframe1 = $SWframe -> Frame(  "-relief" => 'solid',  "-borderwidth" => 1,) -> grid( $SWframe2 = $SWframe -> Frame(  "-relief" => 'solid',  "-borderwidth" => 1,));
    
    foreach $count (1..$SWcount){
        #calculate MLC number of component, which will be passed to low level DLL
       my $calcMLCNumber = ($count % SW_PER_MLC)==0 ? ($count / SW_PER_MLC) : int($count / SW_PER_MLC) + 1;
       if ($SWlist[$count] ne "nc"){
            $SWLabels1[$count] = $SWframe1-> Label("-text" => $SWlist[$count]);
            $SWLabels2[$count] = $SWframe2-> Label("-text" => $SWlist[$count]);
           
            $SWflag[$count]=0;
            $SWflagShort[$count]=0;
           
           # create Switch options
           #connect, disconnect, no_short, set_resistance, set_current, connect to GND, connect to UBATT
            $SWLabels1[$count]->grid(
                     #close SW
                    $SWframe1 -> Radiobutton("-text"     => $SWclose[$count], "-value"    => 0, "-variable" => \$SWflag[$count],
                                        "-command"  => sub{
                                                    $stat = mlc_UndoInterruptLine( $SWlist[$count] ,$calcMLCNumber); 
                                                    w2log("($stat) mlc_UndoInterruptLine( $SWlist[$count], $calcMLCNumber )\n");
                                                    check_status($stat);
                                                    $stat = mlc_SetLogicalState( $SWlist[$count], $SWclose[$count],$calcMLCNumber);
                                                    w2log("($stat) mlc_SetLogicalState( $SWlist[$count], $SWclose[$count], $calcMLCNumber)\n");
                                                    check_status($stat);
                                                    $SWLabels1[$count] -> configure ("-background" => "SystemButtonFace");
                            $SWstate[$count]=$SWclose[$count];
                                                }
                                        ),
                     #open SW
                    $SWframe1 -> Radiobutton("-text"     => $SWopen[$count], "-value"    => 1, "-variable" => \$SWflag[$count],
                                        "-command"  => sub{
                                                    $stat = mlc_UndoInterruptLine( $SWlist[$count],$calcMLCNumber ); 
                                                    w2log("($stat) mlc_UndoInterruptLine( $SWlist[$count], $calcMLCNumber )\n");
                                                    check_status($stat);
                                                    $stat = mlc_SetLogicalState( $SWlist[$count], $SWopen[$count],$calcMLCNumber);
                                                    w2log("($stat) mlc_SetLogicalState( $SWlist[$count], $SWopen[$count], $calcMLCNumber)\n");
                                                    check_status($stat);
                                                    $SWLabels1[$count] -> configure ("-background" => "SystemButtonFace");
                            $SWstate[$count]=$SWopen[$count];
                                                }
                                        ),
                     #disconnect the SW
                    $SWframe1 -> Radiobutton  ("-text"     => "disconnected",  "-value"    => 2,  "-variable" => \$SWflag[$count],
                                        "-command"  => sub { 
                                                    $stat = mlc_InterruptLine( $SWlist[$count],$calcMLCNumber ); 
                                                    w2log("($stat) mlc_InterruptLine( $SWlist[$count], $calcMLCNumber )\n");
                                                    check_status($stat);
                                                    $SWLabels1[$count] -> configure ("-background" => $opencol);
                                                }
                                        ),
                     #set resistance between SW+, (SW- or GND) pins
                    $SWframe1 -> Radiobutton("-text"     => "set_resistance", "-value"    => 3, "-variable" => \$SWflag[$count],
                                        "-command"  => sub { 
                                                    reset_switches();
                                                    reset_shorts();
                                                    $SWflag[$count]=3;
                                                    $stat = UndoShortLine();
                                                    check_status($stat);
                                                    
                                                     #validate the resistance and return if invalid
                                                    return unless(validateEntry($resistanceEntry, $resistance, "resistance"));
                                                    
                                                    $stat = mlc_SetResistance( $SWlist[$count], $resistance, $calcMLCNumber); 
                                                    w2log("($stat) mlc_SetResistance( $SWlist[$count], $resistance , $calcMLCNumber)\n");
                                                    check_status($stat);
                                                    
                                                    $SWLabels1[$count] -> configure ("-background" => $shortcol);
                                                }
                                        ),
                    
                    #set current between SW+, (SW- or GND) pins
                    $SWframe1 -> Radiobutton( "-text"     => "set_current", "-value"    => 4, "-variable" => \$SWflag[$count],
                                    "-command"  => sub { 
                                                    reset_switches();
                                                    reset_shorts();
                                                    $SWflag[$count]=4;
                                                    $stat = UndoShortLine();
                                                    check_status($stat);
                                                    
                                                     #validate the current and return if invalid
                                                    return unless(validateEntry($currentEntry, $current, "current"));
                                                    
                                                    $stat = mlc_SetCurrent( $SWlist[$count], $current, $calcMLCNumber ); 
                                                    w2log("($stat) mlc_SetCurrent( $SWlist[$count], $current, $calcMLCNumber )\n");
                                                    check_status($stat);
                                                    $SWLabels1[$count] -> configure ("-background" => $shortcol);
                                                }
                                            ),
                    -sticky => "nw"
       
                                    );

            $SWLabels2[$count]->grid(
                    #unshort the SW or MLC
                    $SWframe2 -> Radiobutton("-text"     => "no_short", "-value"    => 0,"-variable" => \$SWflagShort[$count],
                                        "-command"  => sub{
                                                    reset_switches();
                                                    reset_shorts();
                                                    $stat = UndoShortLine();
                                                    check_status($stat);
                                                }
                                        ),
                    #short the SW+ to GND
                    $SWframe2 -> Radiobutton  ("-text"     => "SWpGND", "-value"    => 1, "-variable" => \$SWflagShort[$count],
                                        "-command"  => sub    {
                                                    reset_switches();
                                                    reset_shorts();
                                                    $SWflagShort[$count]=1;
                                                    $stat = UndoShortLine();
                                                    check_status($stat);
                                                    
                                                     #validate the leakage resistance and return if invalid
                                                    return unless(validateEntry($leakageEntry, $leakage, "leakage_resistance"));
                                                    
                                                    $stat = ShortLine( $SWlist[$count]."+", "GND", $leakage, $calcMLCNumber ); 
                                                    w2log("($stat) mlc_ShortLine( $SWlist[$count]+, GND, $leakage, $calcMLCNumber )\n");
                                                    check_status($stat);
                                                    $SWLabels2[$count] -> configure ("-background" => $shortcol);
                                                }
                                        ),
                    #short the SW+ to VBAT
                    $SWframe2 -> Radiobutton  ( "-text"     => "SWpUbatt", "-value"    => 2, "-variable" => \$SWflagShort[$count],
                                        "-command"  => sub    {
                                                    reset_switches();
                                                    reset_shorts();
                                                    $SWflagShort[$count]=2;
                                                    $stat = UndoShortLine($calcMLCNumber);
                                                    check_status($stat);
                                                    
                                                     #validate the leakage resistance and return if invalid
                                                    return unless(validateEntry($leakageEntry,$leakage, "leakage_resistance"));
                                                    
                                                    $stat = ShortLine( $SWlist[$count]."+", "VBAT", $leakage ,$calcMLCNumber); 
                                                    w2log("($stat) mlc_ShortLine( $SWlist[$count]+, VBAT, $leakage , $calcMLCNumber)\n");
                                                    check_status($stat);
                                                    $SWLabels2[$count] -> configure ("-background" => $shortcol);
                                                },
                                        ),
                    -sticky => "nw"
                                    );

        } # end if
    } # end foreach

    my (@FSLabels,@FSflag);
    $SWwindow -> Label("-text" => "freely usable switches")-> grid(-pady => 10);
    $FSframe = $SWwindow -> Frame(  "-relief" => 'solid',  "-borderwidth" => 1,) -> grid();
    
    # create Switch options
    #CA, CB, NC
    foreach $count (1..$FScount){
        #calculate MLC number of component, which will be passed to low level DLL
        my $calcMLCNumber = ($count % FS_PER_MLC)==0 ? ($count/FS_PER_MLC) : int($count/FS_PER_MLC) + 1;
        if ($FSlist[$count] ne "nc"){
            $FSLabels[$count] = $FSframe -> Label("-text" => $FSlist[$count]); 

           $FSflag[$count]=0;
            $FSLabels[$count]-> grid(
                    $FSframe -> Radiobutton( "-text"     => $FSca[$count], "-value"    => 0, "-variable" => \$FSflag[$count],
                                        "-command"  => sub{
                                                    $stat = mlc_SetLogicalState( $FSlist[$count], $FSca[$count], $calcMLCNumber);
                                                    w2log("($stat) mlc_SetLogicalState( $FSlist[$count], $FSca[$count], $calcMLCNumber)\n");
                                                    check_status($stat);
                                                    $FSLabels[$count] -> configure ("-background" => "SystemButtonFace");
                                                },
                                        ),

                    $FSframe -> Radiobutton("-text"     => $FScb[$count],"-value"    => 1, "-variable" => \$FSflag[$count],
                                        "-command"  => sub{
                                                    $stat = mlc_SetLogicalState( $FSlist[$count], $FScb[$count], $calcMLCNumber);
                                                    w2log("($stat) mlc_SetLogicalState( $FSlist[$count], $FScb[$count], $calcMLCNumber)\n");
                                                    check_status($stat);
                                                    $FSLabels[$count] -> configure ("-background" => "SystemButtonFace");
                                                },
                                        ),

                    $FSframe -> Radiobutton  ( "-text"     => $FSnc[$count], "-value"    => 2, "-variable" => \$FSflag[$count],
                                        "-command"  => sub { 
                                                    $stat = mlc_SetLogicalState( $FSlist[$count], $FSnc[$count], $calcMLCNumber);
                                                    w2log("($stat) mlc_SetLogicalState( $FSlist[$count], $FSnc[$count], $calcMLCNumber)\n");
                                                    check_status($stat);
                                                    $FSLabels[$count] -> configure ("-background" => $opencol);
                                                },
                                        ),
                    -sticky => "nw"
                                    );

          #init FS state with 'open'
          $FSflag[$count]=2;
          $FSLabels[$count] -> configure ("-background" => $opencol);

        } # end if
    } # end foreach


    #creating seperate SQUIB window
    my ($SQframe1,$SQframe2,@SQflag,);
    $SQwindow = $main->Toplevel("-background"=> "lightgreen");
    $SQwindow->MoveToplevelWindow (0,0);
    $SQwindow->protocol('WM_DELETE_WINDOW',sub{return;});
    $SQwindow->geometry (join('x',$sw,int($sh*0.95)));
    $SQwindow -> title ( "SQ manipulation" );
    
    $SQpane = $SQwindow -> Scrolled("Pane", Name => 'SQwindow',
        -scrollbars => 'osoe',
        -sticky => 'n',
        -gridded => 'y',
        -background => "lightblue",
        -width => $sw,
        -height => int($sh*0.9)
    )->grid();

    $SQframe = $SQpane -> Frame(  "-relief" => 'solid',  "-borderwidth" => 1,) -> grid();
    $SQframe1 = $SQframe -> Frame(  "-relief" => 'solid',  "-borderwidth" => 1,) -> grid($SQframe2 = $SQframe -> Frame(  "-relief" => 'solid',  "-borderwidth" => 1,));
    # create Squib options
    #connect, disconnect, no_short, connect +ve to GND, connect +ve to UBATT, connect -ve to GND, connect -ve to UBATT , set_resistance 
    foreach $count (1..$SQcount){
        #calculate MLC number of component, which will be passed to low level DLL
        my $calcMLCNumber = ($count % SQ_PER_MLC)==0 ? ($count / SQ_PER_MLC) : int($count/SQ_PER_MLC) + 1;
        if ($SQlist[$count] ne "nc"){
            $SQLabels1[$count] =  $SQframe1 -> Label("-text" => $SQlist[$count]);
            $SQLabels2[$count] =  $SQframe2 -> Label("-text" => $SQlist[$count]);
            
            $SQflag[$count]=0;
            $SQflagShort[$count]=0;
             
            $SQLabels1[$count]->grid(
                #connect the SQ
                $SQframe1 -> Radiobutton("-text"     => "connected", "-value"    => 0, "-variable" => \$SQflag[$count],
                                    "-command"  => sub{
                                                $stat = mlc_UndoInterruptLine( $SQlist[$count],$calcMLCNumber ); 
                                                w2log("($stat) mlc_UndoInterruptLine( $SQlist[$count], $calcMLCNumber )\n");
                                                check_status($stat);
                                                $SQLabels1[$count] -> configure ("-background" => "SystemButtonFace");
                                            }
                                    ),
                #disconnect the SQ
                $SQframe1 -> Radiobutton("-text"     => "disconnected","-value"    => 1, "-variable" => \$SQflag[$count],
                                    "-command"  => sub {
                                                $stat = mlc_InterruptLine( $SQlist[$count],$calcMLCNumber ); 
                                                w2log("($stat) mlc_InterruptLine( $SQlist[$count], $calcMLCNumber )\n");
                                                check_status($stat);
                                                $SQLabels1[$count] -> configure ("-background" => $opencol);
                                                
                                                #if the squib is used for set_resistance, then make it to no_short
                                                if($SQflagShort[$count] == 5){
                                                    $SQflagShort[$count] = 0;
                                                    $SQLabels2[$count] -> configure ("-background" => "SystemButtonFace");
                                                }                                                
                                            },
                                    ),
                -sticky => "nw"
            );
     
           
            $SQLabels2[$count]->grid(
                                     
                 #unshort the SQ or particular MLC
                $SQframe2 -> Radiobutton( "-text"     => "no_short", "-value"    => 0, "-variable" => \$SQflagShort[$count],
                                     "-command"  => sub{
                                                 reset_shorts();
                                                 $stat = UndoShortLine($calcMLCNumber);
                                                 check_status($stat);
                                             }
                                     ),
                 
                  #connect the SQ+ to GND
                $SQframe2 -> Radiobutton( "-text"     => "SQpGND", "-value"    => 1, "-variable" => \$SQflagShort[$count],
                                     "-command"  => sub    {
                                                 reset_switches();
                                                 reset_shorts();
                                                 $SQflagShort[$count]=1;
                                                 $stat = UndoShortLine();
                                                 check_status($stat);
                                                 
                                                  #validate the leakage resistance and return if invalid
                                                 return unless(validateEntry($leakageEntry,$leakage, "leakage_resistance"));
                                                 
                                                 $stat = ShortLine( $SQlist[$count]."+", "GND", $leakage,$calcMLCNumber ); 
                                                 w2log("($stat) mlc_ShortLine( $SQlist[$count]+, GND, $leakage,$calcMLCNumber )\n");
                                                 check_status($stat);
                                                 $SQLabels2[$count] -> configure ("-background" => $shortcol);
                                             },
                                     ),
                #connect the SQ+ to VBAT
                $SQframe2 -> Radiobutton  ( "-text"     => "SQpUbatt", "-value"    => 2, "-variable" => \$SQflagShort[$count],
                                     "-command"  => sub    {
                                                 reset_switches();
                                                 reset_shorts();
                                                 $SQflagShort[$count]=2;
                                                 $stat = UndoShortLine();
                                                 check_status($stat);
                                                 
                                                  #validate the leakage resistance and return if invalid
                                                 return unless(validateEntry($leakageEntry,$leakage, "leakage_resistance"));

                                                 $stat = ShortLine( $SQlist[$count]."+", "VBAT", $leakage,$calcMLCNumber ); 
                                                 w2log("($stat) mlc_ShortLine( $SQlist[$count]+, VBAT, $leakage, $calcMLCNumber )\n");
                                                 check_status($stat);
                                                 $SQLabels2[$count] -> configure ("-background" => $shortcol);
                                             },
                                     ),
                #connect the SQ- to GND
                $SQframe2 -> Radiobutton  ( "-text"     => "SQmGND", "-value"    => 3, "-variable" => \$SQflagShort[$count],
                                     "-command"  => sub    {
                                                 reset_switches();
                                                 reset_shorts();
                                                 $SQflagShort[$count]=3;
                                                 $stat = UndoShortLine();
                                                 check_status($stat);
                                                 
                                                  #validate the leakage resistance and return if invalid
                                                 return unless(validateEntry($leakageEntry,$leakage, "leakage_resistance"));
                                                 
                                                 #call Shortline function, for shorting two pins
                                                 $stat = ShortLine( $SQlist[$count]."-", "GND", $leakage,$calcMLCNumber ); 
                                                 w2log("($stat) mlc_ShortLine( $SQlist[$count]-, GND, $leakage, $calcMLCNumber )\n");
                                                 check_status($stat);
                                                 $SQLabels2[$count] -> configure ("-background" => $shortcol);
                                             },
                                     ),
                #connect the SQ- to VBAT
                $SQframe2 -> Radiobutton  ( "-text"     => "SQmUbatt",  "-value"    => 4, "-variable" => \$SQflagShort[$count],
                                     "-command"  => sub    {
                                                 reset_switches();
                                                 reset_shorts();
                                                 $SQflagShort[$count]=4;
                                                 $stat = UndoShortLine();
                                                 check_status($stat);
                                                 
                                                  #validate the leakage resistance and return if invalid
                                                 return unless(validateEntry($leakageEntry,$leakage, "leakage_resistance"));
                                                 
                                                 #call Shortline function, for shorting two pins
                                                 $stat = ShortLine( $SQlist[$count]."-", "VBAT", $leakage,$calcMLCNumber ); 
                                                 w2log("($stat) mlc_ShortLine( $SQlist[$count]-, VBAT, $leakage, $calcMLCNumber )\n");
                                                 check_status($stat);
                                                 $SQLabels2[$count] -> configure ("-background" => $shortcol);
                                             },
                                     ),
                #set resistance between SQ+ and SQ-
                $SQframe2 -> Radiobutton( "-text"     => "set_resistance",  "-value"    => 5,  "-variable" => \$SQflagShort[$count],
                                     "-command"  => sub { 
                                                 reset_switches();
                                                 reset_shorts();
                                                 
                                                 $SQflagShort[$count]=5;
                                                 $stat = UndoShortLine();
                                                 check_status($stat);
                                                 
                                                  #validate the resistance and return if invalid
                                                 return unless(validateEntry($resistanceEntry,$resistance, "resistance"));

                                                 $stat = mlc_SetResistance( $SQlist[$count], $resistance ,$calcMLCNumber); 
                                                 w2log("($stat) mlc_SetResistance( $SQlist[$count], $resistance, $calcMLCNumber )\n");
                                                 check_status($stat);
                                                if($stat >= 0)
                                                {
                                                    unshift(@undoShort, "$calcMLCNumber");
                                                }                                                 
                                                 $SQLabels2[$count] -> configure ("-background" => $shortcol);
                                                 
                         #make the squib as connected
                                                 $SQflag[$count] = 0; 
                        $SQLabels1[$count] -> configure ("-background" => "SystemButtonFace");
                                             }
                                     ),
                 -sticky => "nw"
                     
            );
        } # end if
    } # end foreach





    my ($WLframe1,$WLframe2,@WLflag);
    my ($CANframe1,$CANframe2,@CANflag);

    $WLwindow -> Label("-text" => "warning lamps")-> grid(-pady => 10); 
    $WLframe = $WLwindow -> Frame(  "-relief" => 'solid',  "-borderwidth" => 1,)->grid();
    $WLframe1 = $WLframe -> Frame(  "-relief" => 'solid',  "-borderwidth" => 1,)->grid($WLframe2 = $WLframe -> Frame(  "-relief" => 'solid',  "-borderwidth" => 1,));
    # create WL options
    #connect, disconnect, no_short, connect +ve to GND, connect +ve to UBATT
       foreach $count (1..$WLcount){
        #calculate MLC number of component, which will be passed to low level DLL
        my $calcMLCNumber = ($count% WL_PER_MLC)==0 ? ($count/WL_PER_MLC) : int($count/WL_PER_MLC) + 1;
        if ($WLlist[$count] ne "nc"){
            $WLflag[$count]=0;
            $WLflagShort[$count]=0;
            
            $WLLabels1[$count] = $WLframe1-> Label("-text" => $WLlist[$count]);
            $WLLabels2[$count] = $WLframe2-> Label("-text" => $WLlist[$count]);
            
            $WLLabels1[$count]-> grid(
                #connect the WL
                $WLframe1 -> Radiobutton("-text"     => "connected","-value"    => 0,"-variable" => \$WLflag[$count],
                                    "-command"  => sub {
                                                $stat = mlc_UndoInterruptLine( $WLlist[$count] ,$calcMLCNumber); 
                                                w2log("($stat) mlc_UndoInterruptLine( $WLlist[$count] , $calcMLCNumber)\n");
                                                check_status($stat);
                                                $WLLabels1[$count] -> configure ("-background" => "SystemButtonFace");
                                            }
                                    ),
                #disconnect the WL
                $WLframe1 -> Radiobutton  ("-text"     => "disconnected", "-value"    => 1,"-variable" => \$WLflag[$count],
                                    "-command"  => sub { 
                                                $stat = mlc_InterruptLine( $WLlist[$count] ,$calcMLCNumber); 
                                                w2log("($stat) mlc_InterruptLine( $WLlist[$count], $calcMLCNumber)\n");
                                                check_status($stat);
                                                $WLLabels1[$count] -> configure ("-background" => $opencol);
                                            }
                                    ),
                -sticky => "nw",
                                 );
            
            $WLLabels2[$count]->grid(
                #unshort the WL or particular MLC
                $WLframe2 -> Radiobutton("-text"     => "no_short","-value"    => 0, "-variable" => \$WLflagShort[$count],
                                    "-command"  => sub{
                                                reset_shorts();
                                                $stat = UndoShortLine();
                                                check_status($stat);
                                            }
                                    ),
                #connect the WL to GND
                $WLframe2 -> Radiobutton  ("-text"     => "WLpGND", "-value"    => 1, "-variable" => \$WLflagShort[$count],
                                    "-command"  => sub    {
                                                reset_switches();
                                                reset_shorts();
                                                $WLflagShort[$count]=1;
                                                $stat = UndoShortLine();
                                                check_status($stat);
                                                
                                                #validate the leakage resistance and return if invalid
                                                return unless(validateEntry($leakageEntry,$leakage, "leakage_resistance"));
                                                
                                                #call Shortline function, for shorting two pins
                                                $stat = ShortLine( $WLlist[$count]."+", "GND", $leakage , $calcMLCNumber); 
                                                w2log("($stat) mlc_ShortLine( $WLlist[$count]+, GND, $leakage , $calcMLCNumber)\n");
                                                check_status($stat);
                                                $WLLabels2[$count] -> configure ("-background" => $shortcol);
                                            }
                                    ),
                #connect the WL to VBAT
                $WLframe2 -> Radiobutton  ("-text"     => "WLpUbatt","-value"    => 2, "-variable" => \$WLflagShort[$count],
                                    "-command"  => sub    {
                                                reset_switches();
                                                reset_shorts();
                                                $WLflagShort[$count]=2;
                                                $stat = UndoShortLine();
                                                check_status($stat);
                                                
                                                 #validate the leakage resistance and return if invalid
                                                return unless(validateEntry($leakageEntry,$leakage, "leakage_resistance"));

                                                #call Shortline function, for shorting two pins
                                                $stat = ShortLine( $WLlist[$count]."+", "VBAT", $leakage , $calcMLCNumber); 
                                                w2log("($stat) mlc_ShortLine( $WLlist[$count]+, VBAT, $leakage , $calcMLCNumber)\n");
                                                check_status($stat);
                                                $WLLabels2[$count] -> configure ("-background" => $shortcol);
                                            }
                                    ),
                -sticky => "nw",

                );


        } # end if
    } # end foreach

   $WLwindow -> Label("-text" => "CAN")-> grid(-pady => 10); 

    $CANframe = $WLwindow -> Frame(  "-relief" => 'solid',  "-borderwidth" => 1,) -> grid();
    $CANframe1 = $CANframe -> Frame(  "-relief" => 'solid',  "-borderwidth" => 1,) -> grid( $CANframe2 = $CANframe -> Frame(  "-relief" => 'solid',  "-borderwidth" => 1,)    );

    # create CAN options
    #connect, disconnect, no_short, connect +ve to GND, connect +ve to UBATT, connect -ve to GND
       
    foreach $count (1..$CANcount){
        #calculate MLC number of component, which will be passed to low level DLL
        my $calcMLCNumber = ($count % CAN_PER_MLC)==0 ? ($count/CAN_PER_MLC) : int($count/CAN_PER_MLC) + 1;
        if ($CANlist[$count] ne "nc"){

            $CANLabels1[$count] = $CANframe1  -> Label("-text" => $CANlist[$count]);
            $CANLabels2[$count] = $CANframe2  -> Label("-text" => $CANlist[$count]);
            
            $CANflag[$count]=0;
            $CANflagShort[$count]=0;
            
            $CANLabels1[$count]->grid(
                    #connect the CAN
                    $CANframe1 -> Radiobutton("-text"     => "connected", "-value"    => 0, "-variable" => \$CANflag[$count],
                                        "-command"  => sub {
                                                    $stat = mlc_UndoInterruptLine( $CANlist[$count] ,$calcMLCNumber); 
                                                    w2log("($stat) mlc_UndoInterruptLine( $CANlist[$count], $calcMLCNumber )\n");
                                                    check_status($stat);
                                                    $CANLabels1[$count] -> configure ("-background" => "SystemButtonFace");
                                                }
                                        ),
                    #disconnect the CAN
                    $CANframe1 -> Radiobutton ("-text"     => "disconnected","-value"    => 1, "-variable" => \$CANflag[$count],
                                        "-command"  => sub { 
                                                    $stat = mlc_InterruptLine( $CANlist[$count] ,$calcMLCNumber); 
                                                    w2log("($stat) mlc_InterruptLine( $CANlist[$count], $calcMLCNumber )\n");
                                                    check_status($stat);
                                                    $CANLabels1[$count] -> configure ("-background" => $opencol);
                                                }
                                        ),
                    -sticky => "nw"
                                     );

            $CANLabels2[$count]->grid(
                    #unshort the CAN or particular MLC
                    $CANframe2 -> Radiobutton("-text"     => "no_short", "-value"    => 0, "-variable" => \$CANflagShort[$count],
                                        "-command"  => sub{
                                                    reset_shorts();
                                                    $stat = UndoShortLine();
                                                    check_status($stat);
                                                }
                                        ),
                    #connect the CAN to GND
                    $CANframe2 -> Radiobutton  ("-text"     => "CANpGND", "-value"    => 1, "-variable" => \$CANflagShort[$count],
                                        "-command"  => sub    {
                                                    reset_switches();
                                                    reset_shorts();
                                                    $CANflagShort[$count]=1;
                                                    $stat = UndoShortLine();
                                                    check_status($stat);
                                                    
                                                     #validate the leakage resistance and return if invalid
                                                    return unless(validateEntry($leakageEntry,$leakage, "leakage_resistance"));
                                                    
                                                    $stat = ShortLine( $CANlist[$count]."+", "GND", $leakage,$calcMLCNumber); 
                                                    w2log("($stat) mlc_ShortLine( $CANlist[$count]+, GND, $leakage , $calcMLCNumber)\n");
                                                    check_status($stat);
                                                    $CANLabels2[$count] -> configure ("-background" => $shortcol);
                                                }
                                        ) ,
                    #connect the CAN to VBAT
                   $CANframe2 -> Radiobutton  ("-text"     => "CANpUbatt", "-value"    => 2, "-variable" => \$CANflagShort[$count],
                                        "-command"  => sub    {
                                                    reset_switches();
                                                    reset_shorts();
                                                    
                                                    #set flag to indicate in GUI
                                                    $CANflagShort[$count]=2;
                                                    
                                                    #undo shorts previously done
                                                    $stat = UndoShortLine();
                                                    check_status($stat);
                                                    
                                                     #validate the leakage resistance and return if invalid
                                                    return unless(validateEntry($leakageEntry,$leakage, "leakage_resistance"));
                                                    
                                                    $stat = ShortLine( $CANlist[$count]."+", "VBAT", $leakage ,$calcMLCNumber); 
                                                    w2log("($stat) mlc_ShortLine( $CANlist[$count]+, VBAT, $leakage , $calcMLCNumber)\n");
                                                    check_status($stat);
                                                    $CANLabels2[$count] -> configure ("-background" => $shortcol);
                                                }
                                        ),
                   -sticky => "nw"
                   );


        } # end if
    } # end foreach




    my ($PASframe1,$PASframe2,@PASflag);

   $WLwindow -> Label("-text" => "peripheral sensors")-> grid(-pady => 10); 
    $PASframe= $WLwindow -> Frame(  "-relief" => 'solid',  "-borderwidth" => 1,) -> grid(); 
    $PASframe1 = $PASframe -> Frame(  "-relief" => 'solid',  "-borderwidth" => 1,) -> grid($PASframe2 = $PASframe -> Frame(  "-relief" => 'solid',  "-borderwidth" => 1,)); 
    
    # create PAS options
    #connect, disconnect, no_short, connect +ve to GND, connect +ve to UBATT, connect -ve to GND
   
    foreach $count (1..$PAScount){
        #calculate MLC number of component, which will be passed to low level DLL
        my $calcMLCNumber = ($count % PAS_PER_MLC)==0 ? ($count/PAS_PER_MLC) : int($count/PAS_PER_MLC) + 1;
        if ($PASlist[$count] ne "nc"){
            $PASLabels1[$count] =  $PASframe1 -> Label("-text" => $PASlist[$count]);
            $PASLabels2[$count] =  $PASframe2 -> Label("-text" => $PASlist[$count]);
            
            $PASflag[$count]=0;
            $PASflagShort[$count]=0;
            
            $PASLabels1[$count]->grid(
                    #connect the PAS
                    $PASframe1 -> Radiobutton( "-text"     => "connected", "-value"    => 0, "-variable" => \$PASflag[$count],
                                        "-command"  => sub{
                                                    $stat = mlc_UndoInterruptLine( $PASlist[$count] ,$calcMLCNumber); 
                                                    w2log("($stat) mlc_UndoInterruptLine( $PASlist[$count], $calcMLCNumber )\n");
                                                    check_status($stat);
                                                    $PASLabels1[$count] -> configure ("-background" => "SystemButtonFace");
                                                },
                                        ),

                     #disconnect the PAS
                    $PASframe1 -> Radiobutton  ("-text"     => "disconnected", "-value"    => 1, "-variable" => \$PASflag[$count],
                                        "-command"  => sub { 
                                                    $stat = mlc_InterruptLine( $PASlist[$count] ,$calcMLCNumber); 
                                                    w2log("($stat) mlc_InterruptLine( $PASlist[$count], $calcMLCNumber )\n");
                                                    check_status($stat);
                                                    $PASLabels1[$count] -> configure ("-background" => $opencol);
                                                },
                                        ),
                    -sticky => "nw"
                                     );
            
            $PASLabels2[$count]->grid(
                     #unshort the PAS or particular MLC
                    $PASframe2 -> Radiobutton( "-text"     => "no_short", "-value"    => 0, "-variable" => \$PASflagShort[$count],
                                        "-command"  => sub{
                                                    reset_shorts();
                                                    $stat = UndoShortLine();
                                                    check_status($stat);
                                                },
                                        ),
                    #connect PAS to GND
                    $PASframe2 -> Radiobutton  ("-text"     => "PASpGND","-value"    => 1, "-variable" => \$PASflagShort[$count],
                                        "-command"  => sub    {
                                                reset_switches();
                                                reset_shorts();
                                                $PASflagShort[$count]=1;
                                                $stat = UndoShortLine();
                                                check_status($stat);
                                                
                                                 #validate the leakage resistance and return if invalid
                                                return unless(validateEntry($leakageEntry,$leakage, "leakage_resistance"));

                                                $stat = ShortLine( $PASlist[$count]."+", "GND", $leakage , $calcMLCNumber); 
                                                w2log("($stat) mlc_ShortLine( $PASlist[$count]+, GND, $leakage, $calcMLCNumber )\n");
                                                check_status($stat);
                                                $PASLabels2[$count] -> configure ("-background" => $shortcol);
                                            },
                                        ),
                    #connect PAS to VBAT
                    $PASframe2 -> Radiobutton  ( "-text"     => "PASpUbatt","-value"    => 2, "-variable" => \$PASflagShort[$count],
                                        "-command"  => sub    {
                                                reset_switches();
                                                reset_shorts();
                                                $PASflagShort[$count]=2;
                                                $stat = UndoShortLine();
                                                check_status($stat);
                                                
                                                 #validate the leakage resistance and return if invalid
                                                return unless(validateEntry($leakageEntry,$leakage, "leakage_resistance"));

                                                $stat = ShortLine( $PASlist[$count]."+", "VBAT", $leakage ,$calcMLCNumber); 
                                                w2log("($stat) mlc_ShortLine( $PASlist[$count]+, VBAT, $leakage , $calcMLCNumber)\n");
                                                check_status($stat);
                                                $PASLabels2[$count] -> configure ("-background" => $shortcol);
                                            },
                                        ),
                    -sticky => "nw"
                                     );


        } # end if
    } # end foreach



    my ($stat,@version,$mlcID,$mlcVersion);

    $stat = mlc_InitHW($MLC_ini, $NumOfMLCs);
    w2log("perl: ($stat) init\n");
    check_status($stat);
    if($stat<0){$display_txt = "error connecting to MLC"};

    ($stat,@version) = mlc_GetVersion();
    w2log("perl: ($stat) MLC DLL version @version\n");
    check_status($stat);

    ($stat, $mlcID, $mlcVersion) = mlc_GetDeviceID();
    w2log("MLC details: ($stat)\n");
    if($stat > 0){ w2log("MLC$_ : ID - $$mlcID[$_-1], Version - $$mlcVersion[$_-1] \n") foreach(1..$stat);}
    check_status($stat);
    
    $stat = mlc_PSvoltage($voltage, 1);
    w2log("($stat) voltage $voltage\n");
    check_status($stat);

    foreach my $tempmlcNum(1..$NumOfMLCs)
    {
        $stat = mlc_SWMinus( "PinGnd", $tempmlcNum);
        w2log("($stat) mlc_SWMinus( PinGnd, $tempmlcNum )\n");
        check_status($stat);
    }

    $SQwindow->lower($main);
    $main->focus();

}

#********************************************************************************************
# Name              : validateLabel
# Description       : validate the uniqueness of given label with already existing labels
# Parameters        : label = label to be checked
# Return Values     : status code of operation, 0 = if label is redundant, 1 = if label is unique
#********************************************************************************************
sub validateLabel
{
    my $Label = shift;
    
    #check if Label is already existing
    if(exists $MLCNames{$Label}){
        #if Label already exists, return error
        $display_txt = "Redundant name \"$Label\" found in the configuration file";
        return 0;;
    }
    else{
        #if Label is not already existing, put the Lable into Hash
        $MLCNames{$Label} = 1;
        return 1;
    }
}

#********************************************************************************************
# Name              : validateEntry
# Description       : This function is used to validate the number in entry field such as resistance, current values
# Parameters        : Entry = The variable for entry, value = value present in the entry, description = description for entry
# Return Values     : status code of operation, 0 = if value is invalid, 1 = if value is valid
#********************************************************************************************
sub validateEntry{
    #parameter acquisition
    my $Entry = shift;
    my $value = shift;
    my $description = shift;

    #if value is not a valid number, then print the error into log and return 0
    unless($value =~ /^(\d+)*.?(\d+)$/){
        w2log("$value is not a valid $description value\n");
        $Entry->configure("-background"=> "red");
        return 0;
    }
    else{
        #if value is a valid number, return 1
        $Entry->configure("-background"=> "white"); return 1;
    }
}

#********************************************************************************************
# Name              : ShortLine
# Description       : This function is used to short two pins in MLC (Same MLC or from different MLCs)
# Parameters        : line1 = name of the component to be shorted, line2 = GND or VBAT, leakage resistor, MLC number
# Return Values     : status code of operation
#********************************************************************************************
sub ShortLine()
{
    my $line1 = shift;
    my $line2 = shift;
    my $leakresistor = shift;
    my $tempMLCNumber = shift;
    my $stat ;
    
    #if short is requested for MLCs(except MLC1), then connect second parameter (VBAT or GND) to reference of MLC1
    #and connect line2 of other MLC to reference  line
    if(defined($tempMLCNumber) && $tempMLCNumber != 1){
        $stat = mlc_ShortLine($line2, "REFERENCE", $leakresistor, 1); #connect VBAT/GND to reference line from 1st MLC
        w2log(" - ($stat) mlc_ShortLine( $line2, REFERENCE, $leakresistor, 1 )\n");

        if($stat >= 0)
        {
            $stat = mlc_ShortLine($line1, "REFERENCE", 0, $tempMLCNumber);
            w2log(" - ($stat) mlc_ShortLine( $line1, REFERENCE, 0, $tempMLCNumber )\n");
            check_status($stat);
            
            #if second short is not successfull, do undoShortLine for MLC1
            unless($stat >= 0)
            {
                 my $rollbackstat = mlc_UndoShortLine(1);
                w2log("Rollback MLC1 ($rollbackstat) mlc_UndoShortLine(1)\n");
            }
            else    #if second short in successful, insert MLC numbers for Unshorting later
            {
                unshift(@undoShort, "1,$tempMLCNumber");
            }
        }
    }
    else
    {
        #if short is requested for 1st MLC, call mlc_ShortLine() function directly for MLC1
        $stat = mlc_ShortLine($line1, $line2, $leakresistor, 1);
        if($stat >= 0){
            unshift(@undoShort, "$tempMLCNumber");
        }
    }    
    
    return $stat;
}


#********************************************************************************************
# Name              : UndoShortLine
# Description       : This function is used to disable short in MLCs
# Parameters        : ---
# Return Values     : status code of operation
#********************************************************************************************
sub UndoShortLine()
{
    my $stat = 0;
    
    #for the MLCs which are involved in previous short, call mlc_UndoShortLine()
    foreach my $tempMLCNumber (@undoShort)
    {
       my @mlcs = split(/,/,  $tempMLCNumber);
       foreach my $tempmlcNum(@mlcs){
           $stat = mlc_UndoShortLine($tempmlcNum);
           w2log("($stat) mlc_UndoShortLine($tempmlcNum)\n");
       }
    }
    @undoShort = ();
    return $stat;
}

#********************************************************************************************
# Name              : reset_shorts
# Description       : reset the short flags and colors of Labels
# Parameters        : ---
# Return Values     : None
#********************************************************************************************
sub reset_shorts{
    #reset the short flags and colors of Labels to default
    w2log("reset_shorts:\n");
    my $val;
     foreach $val (1..$SQcount){
        $SQflagShort[$val]=0;
        $SQLabels2[$val] -> configure ("-background" => "SystemButtonFace") if defined $SQLabels2[$val];
     }
     foreach $val (1..$SWcount){
        $SWflagShort[$val]=0;
        $SWLabels2[$val] -> configure ("-background" => "SystemButtonFace") if defined $SWLabels2[$val];
     }
     foreach $val (1..$WLcount){
        $WLflagShort[$val]=0;
        $WLLabels2[$val] -> configure ("-background" => "SystemButtonFace") if defined $WLLabels2[$val];
     }
     foreach $val (1..$CANcount){
        $CANflagShort[$val]=0;
        $CANLabels2[$val] -> configure ("-background" => "SystemButtonFace") if defined $CANLabels2[$val];
     }
     foreach $val (1..$PAScount){
        $PASflagShort[$val]=0;
        $PASLabels2[$val] -> configure ("-background" => "SystemButtonFace") if defined $PASLabels2[$val];
     }
}


#********************************************************************************************
# Name              : reset_switches
# Description       : reset the switch flags and colors of Labels
# Parameters        : ---
# Return Values     : None
#********************************************************************************************
sub reset_switches{
    my $val;
     w2log("reset_switches:\n");
     foreach $val (1..$SWcount){
        #reset to default state of switches
        my $SWperMLC = ($SWcount/$NumOfMLCs);
        #calculate MLC number of component, which will be passed to low level DLL
        my $calcMLCNumber = ($val%$SWperMLC)==0 ? ($val/$SWperMLC) : int($val/$SWperMLC) + 1;
        if (defined($SWflag[$val]) && $SWflag[$val]>2){
            $SWflag[$val]=0;
            
            $stat = mlc_SetLogicalState( $SWlist[$val], $SWstate[$val], $calcMLCNumber);
            w2log("($stat) mlc_SetLogicalState($SWlist[$val], $SWstate[$val], $calcMLCNumber)\n");
            check_status($stat);
            
            #reset to default color
            $SWLabels1[$val] -> configure ("-background" => "SystemButtonFace") if defined $SWLabels1[$val];
        }
     }

}

#********************************************************************************************
# Name              : setVoltage
# Description       : set voltage only for MLC1
# Parameters        : ---
# Return Values     : None
#********************************************************************************************
sub setVoltage{
    if($voltage < 0){
        $display_txt = "voltage cannot be negative";
        $voltage = 0;
    }
   
    $voltage=sprintf("%.3f",($voltage));
    
    #set voltage only for MLC1
    $stat = mlc_PSvoltage($voltage,1);
    w2log("($stat) mlc_PSvoltage($voltage, 1)\n");
    
    check_status($stat);
    if ($stat >= 0){
        $display_txt="voltage was set to $voltage";
    }
    else{
        $display_txt="error ($stat) ".mlc_GetErrorString($stat);
    }

}

##################################
# Logfile handling
##################################
sub w2log{
     my $text = shift;
     
     #log to standard output
     print $text;
     
     #log to logfile
     print LOG $text;
}

#Function to get the error text if the negative status is obtained
sub check_status{
    my $status = shift;

    if ($status<0){
      my $errortext = mlc_GetErrorString($status);
      w2log( "MLC ($status): $errortext\n" );
     
    }

}



=head1 DESCRIPTION

very simple GUI for controlling MLC, you can either load MLC_HW.ini and operate switches, squibs, PAS, CAN, Freely usable switches, power lines, voltage

or you can load project defaults file and select CAN settings manually. 

To load other MLC settings, you have to select the file using "Browse file" button . 

=cut

=head2 MULTIPLE MLC SETUP

Incase if Multiple MLCs should be used with MLC GUI, the pins should be connected as mentioned below for proper working of the tool.

=for html
<img src="..\..\pics\multipleMLCsetup.jpg" align="center" alt="Multiple MLC setup" width=800 height=400><br/>

=head2 MULTIPLE MLC CONFIGURATION FILE

=for html
<a href="..\..\..\MLC_GUI\MLC_ProjectConst_MultipleMLC.pm" target="blank">.pm file example</a> <br/>


=for html 
<a href="..\..\..\MLC_GUI\MLC_IniFile_MultipleMLC.ini" target="blank">.ini file example</a> <br/>


=head1 AUTHOR

Frank B�hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

Arulkumar S, E<lt>Arulkumar.S@in.bosch.comE<gt>

=head1 SEE ALSO

perl, activeDSO documentation, LeCroy manual.

=cut
