#!/bin/env/perl -w

## MODULES ##
use strict;
use Getopt::Long;
use File::Basename;
use File::Copy;
use Tk;

##------------------------------------------------------------------
## VARIABLES OF MAIN
##------------------------------------------------------------------
use vars qw($VERSION $HEADER $ProjectDefaults $CURRENT_TC );
# next 2 lines edited by CVS, DO NOT MODIFY
$VERSION = q$Revision: 1.9 $;
$HEADER = q$Header: Mappingfile_Generators/CANMapping/LIFT_prepare_CAN_mapping.pl 1.9 2019/08/09 14:19:24ICT Prosch Christian (CC-PS/EPS2) (PHC2SI) develop  $;

my $LPCM_VERSION = "LIFT prepare CAN mapping $VERSION";

my $tool = $HEADER;
$tool =~ s/^Header: //;

my $output_CAN_mapping = "Project_XY_CAN_mapping.pm"; ## proposal output file name

our ( $opt_dbc_file_1, $opt_msg_list, $opt_output_file, $opt_dbc_file_2, $dbc_can_bus_mapping_hash );
our $selected_CAN_engine     = "CAN_engine";
our $selected_CAN_bus_number = "1";
our $selected_CAN_bus_number_2 = "1";
our $opt_verbose = 3;  ## preset of verbose level to max
our $opt_varType = 1;  ## 0 - System variable , 1 - Environment variable
our $opt_sut_node = 'Airbag';

my $verbose;  # local verbose variable
my $msg_list_file; # test list file given from command option $opt_dbc_file

# TK vars:
my ( $main, $F1, $F2, $F1_1, $F1_0, $F1_1ESP, $F1_1_CanEngine, $F1_1_CanBusNbr, $F1_2, $F1_3, $F1_4, $F1_VarType, $entry, $F1_CB, $Cb_Selected, $F1_1_CBN , $can_bus_nr_menu);
my ( $verbose_menu, $varType_menu, $first_log_text, $temp, $start_button, %ALL_signals_count, @Identical_Msg_Sig_Name, $button );

my ($StausWindow,@status_msg,$S_F1,$S_F2,$S_F1_1);

# main loop
LPCM_init();
MainLoop;

sub check_state {
    if ( defined $opt_dbc_file_1 && $opt_dbc_file_1 ne '' && $Cb_Selected == 1 ) {
        $button->configure( -state => 'normal' );
        $entry->configure( -state => 'normal' );
        $can_bus_nr_menu->configure( -state => 'normal' );
        
    }
    else {
        $button->configure( -state => 'disabled' );
        $entry->configure( -state => 'disabled' );
        $can_bus_nr_menu->configure( -state => 'disabled' );
    }
}

# main loop end

##------------------------------------------------------------------
## LPCM_engine
##------------------------------------------------------------------
sub LPCM_engine {
    S_w2log(1, "STARTING : LPCM_engine ($VERSION)\n");

    @Identical_Msg_Sig_Name =();
    %ALL_signals_count = undef;
    
    open( LOG , ">CANmapping_log.txt") || die ("Open file: $!\n");
    open( OUTFILE , "> $opt_output_file" )  || die ("Open file $opt_output_file : $!\n");

    my %UsedMessages = read_msg_list_file( $opt_msg_list ) if $opt_msg_list;
    
    my @dbc_file_array;
    push @dbc_file_array, $opt_dbc_file_1 if ($opt_dbc_file_1 && $opt_dbc_file_1 ne '');
    push @dbc_file_array, $opt_dbc_file_2 if ($opt_dbc_file_2 && $opt_dbc_file_2 ne '' && $Cb_Selected);
    my %DBC_content;
    foreach my $dbc_file_name (@dbc_file_array)
    {
        %DBC_content  = process_dbc_file( $dbc_file_name , \%DBC_content ) if ($dbc_file_name && $dbc_file_name ne '');
    }
   
    if( %UsedMessages )
    {
        S_w2log(1, " Create Mapping just for Signals of CAN msg list defined in $opt_msg_list\n");
        my %FoundReqMsg = check_req_msg_in_dbc( \%DBC_content , \%UsedMessages );
        write_CAN_mapping( $opt_sut_node , \%DBC_content , \%FoundReqMsg );
    }
    else
    {
        S_w2log(1, " Create Mapping for all Signals of DBC file \n");
        write_CAN_mapping( $opt_sut_node , \%DBC_content );
    }
    
    #Set an approriate error when the message name and the signal name are same in the database
    if( scalar @Identical_Msg_Sig_Name)
    {       
        my $msg = "DBC E R R O R : Below found have same Message and Signal name in file - '".basename($opt_dbc_file_1)."'\n\n";
        foreach my $iden_msg_signal (@Identical_Msg_Sig_Name)
        {
            $msg = $msg . " => $iden_msg_signal\n";
        }
        $msg = $msg . "\nWarning : functionalities like read and write signals may not work as intended.\n".
                     "\nSuggestions :\n".
                     "1. use CAN Database Editor (the official tool from Vector included in CANoe) in order to avoid mistakes and inconsistencies.\n".
                     "2. use the modified DBC as database in the CANoe cfg for testing instead of the original.\n";
        S_w2log( 1, $msg);
                $main -> messageBox(-icon => "error", -message=>$msg, -title => 'DBC E R R O R - Identical message(s) and signal(s) name !!' );     
    }
    
    close ( OUTFILE );  
    close( LOG );
    return 1;
}

##------------------------------------------------------------------
## write_CAN_mapping (  )
##------------------------------------------------------------------
sub write_CAN_mapping {
    my $sut_node = shift;
    my $DBC = shift;
    my $UsedMsg = shift;

    my %ValidMsg = %$UsedMsg if defined $UsedMsg;
    my %DbcMsg = %$DBC;

    my %ValidDecMsg;
#    my ($MsgLCControl , $MsgLC_DLC);
    my ( $Message_Text , $Header_text , $ValidMsgName , $ValidMsgId , $DbcMsgId , $MsgName , $msg_cnt , $MsgIdHex , $MsgSender , $MsgDLC , $MsgCycleTime );
    my ( %sut_snd_msg_ids, %sut_rcv_msg_ids );
    my ( $SignalMapping_Text , $CAN_tool_signal_name , $DbcSignalName , $DbcSig_short_name , $VectorVarSignalName , $DbcSig_Pos , $DbcSig_Length , $DbcSig_Format , $DbcSig_Type , $DbcSig_Factor , $DbcSig_Offset , $DbcSig_Unit , $DbcSig_Multiplex , $Multiplex_Master , $Multiplex_Code);
    my ( $LC_ReadPhys , $LC_ReadHex , $LC_WritePhys , $LC_WriteHex , );
    my ( $Edit_Bytes );
    my ( $MsgCanoeDisable , $MsgCanoeDlc , $MsgCanoeTiming );   
    my $VarType;#System or Environment variable

    my ($hash_MsgNames, @Msg_Duplicates_Array);
    S_w2outfile( 1 ,  "### file generated with $tool\n" );
    S_w2outfile( 1 ,  "### input dbc files:\n" );   
    S_w2outfile( 1 ,  "### $opt_dbc_file_1\n" );  
    S_w2outfile( 1 ,  "### $opt_dbc_file_2\n" ) if $opt_dbc_file_2;
    S_w2outfile( 1 ,  "package LIFT_PROJECT;\n\n" );


    $Header_text =<<HEADER_TEST;
#
#
#  The CAN Mapping collects all test relevant informations of CAN interface of LabCarNG simulator used in LIFT test automation.
#
#  It has different chapters for
#
#  1. NODE_UNDER_TEST
#  2. ABSTRACT_SIGNALS
#  3. CAN_MESSAGES
#  4. <all CAN SIGNALS>
#
#  -----------------------------------------------------------------------------------------------------------------
#
#  1. NODE_UNDER_TEST is necessary to decide between send / receive messages
#
#   'NODE_UNDER_TEST'       => 'ITT_ESP',
#
#  2. The first chapter is for special tests which dont want to know how is the real CAN signal.
#     This tests just want to verify typical functions og brake ECU
#
#               'EBD_active'       => 'BR1_EBV_Eingriff',
#               'ABS_active'       => 'BR1_ABS_Bremsung',
#               'ESP_passive'      => 'BR1_ESP_passivgetastet',
#               'lamp_ESP_defect'  => 'BR1_Lampe_ASR_ESP',
#
#
# ---------------------------------------------------------------------------------------------------------------------------------------------------
#
#  3. The chapter with CAN messages have to organize in main function the names of LC signals to enable/disable CAN messages
#     These signal names are automatically generated for messages from CS CAN block.
#
#     e.g.:
#
#       'Motor_2'  =>
#     {
#       'ID'         => 648,
#       'DLC'        => 8,
#       'SENDER'     => 'Otto',
#       'CAN_BUS_NBR'=> 1,                                      ##  <<<-- Bus-Nbr 1 is default
#       'CYCLE'      => 10,
#       'LC_CONTROL' => 'Motor_2_USED.Motor_2.CAN_engine',      ##  <<<-- CAN_engine is default
#       'LC_DLC'     => 'Motor_2_DLC.Motor_2.CAN_engine',       ##  <<<-- CAN_engine is default
#     },
#
#
# ---------------------------------------------------------------------------------------------------------------------------------------------------
#
#       But especially Sensor messages have to be edited manually
#
#     e.g.:
#
#       'from_DRS'  =>
#      {
#        'ID'         => 200,
#        'DLC'        => 8,
#        'SENDER'     => 'DRS',
#        'CAN_BUS_NBR'=> 2,                               ##  <<<-- if CAN Bus number = 2 was selected
#        'CYCLE'      => 10,
#        'LC_CONTROL' => 'YRS_TrmMsg_MSG_USED.SENS_YR'    ##  <<<-- if LabCar CAN engine = SENS_YR was given
#        'LC_DLC'     => 'from_DRS_DLC.SENS_YR',          ##  <<<-- if LabCar CAN engine = SENS_YR was given
#      },
#
# ---------------------------------------------------------------------------------------------------------------------------------------------------
#
#     If you are using CAN_PRIVATE , the 'CAN_engine' have to be given as 'CAN_PRIVATE' in LPCM GUI
#     Additionally the CAN_BUS_NBR on the CAN tool (e.g.CANalyzer) have to be given.
#
#       'LENKRADWINKEL_OBEN'  =>
#   {
#     'ID'         => 200,
#     'DLC'        => 8,
#     'SENDER'     => 'SZL',
#     'CAN_BUS_NBR'=> 2,      ##  <<<-- if CAN Bus number = 2 was selected
#     'CYCLE'      => 10,
#     'LC_CONTROL' => 'LENKRADWINKEL_OBEN_USED.LENKRADWINKEL_OBEN.CAN_PRIVATE',   ##  <<<-- if LabCar CAN engine = CAN_PRIVATE was given
#     'LC_DLC'     => 'LENKRADWINKEL_OBEN_DLC.LENKRADWINKEL_OBEN.CAN_PRIVATE',    ##  <<<-- if LabCar CAN engine = CAN_PRIVATE was given
#   },
#
#
#  4. This chapter collects all CAN signal relevant informations
#
#  Some entries are automatically generated from DBC file and are used from normal signal read/write operations.
#  Some special entries have to be filled out manually.
#
#  -----------------------------------------------------------------------------------------------------------------
#
#  Here is one example for a signal send from (Brake ECU) System under Test
#
# 'BR1_ABS_Bremsung'       =>
#                         {
#                         'SIGNAL_NAME'   => 'BR1_ABS_Bremsung',
#                         'SENDER'        => 'ITT_ESP',
#                         'MESSAGE'       => 'Bremse_1',
#                         'MULTIPLEX'     => undef,
#                         'STARTBIT'      => 2, 'LENGTH' => 1, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
#                         'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
#                         'LC_READ_PHYS'  => 'BR1_ABS_Bremsung_phys.Bremse_1.CAN_engine',     # verify LC signal names with CAN block implemetation
#                         'LC_READ_HEX'   => 'BR1_ABS_Bremsung_hex.Bremse_1.CAN_engine',     # set both to 0 if signal not part of CAN block in LC NG
#                         'INIT'          => 0,     ## verify INIT value with specifications
#                         },
#
#  Signals with special meaning for typical testing of Brake ECU's can have the following entries additionally:
#                          'NEUTRAL'      => 0,
#                          'EBD_ACTIVE'   => 0, 'ABS_ACTIVE'     => 0, 'TCS_ACTIVE'     => 0, 'ESP_ACTIVE'     => 0,
#                          'EBD_DEFECT'   => 0, 'ABS_DEFECT'     => 0, 'TCS_DEFECT'     => 0, 'ESP_DEFECT'     => 0,
#
#  Signals which represent a counter can have also the following entries:
#
#                         'START_VALUE' => 0,
#                         'STEP_WIDTH'  => 1,
#                         'MAX_VALUE'   => 15,
#
#  -----------------------------------------------------------------------------------------------------------------
#
#  Here is one example for a signal send from LC Simulator when it is a static signal
#
# 'KO2_Aussentemperatur_gefiltert'       =>
#                         {
#                         'SIGNAL_NAME'   => 'KO2_Aussentemperatur_gefiltert',
#                         'SENDER'        => 'Kombi',
#                         'MESSAGE'       => 'Kombi_2',
#                         'MULTIPLEX'     => undef,
#                         'STARTBIT'      => 8, 'LENGTH' => 8, 'OFFSET' => -50.000000, 'FACTOR' => 0.500000,
#                         'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => '�C',
#                         'LC_READ_PHYS'  => 'KO2_Aussentemperatur_gefiltert.Kombi_2.CAN_engine',     # verify LC signal names with CAN block parameters in DC
#                         'LC_WRITE_PHYS' => 'KO2_Aussentemperatur_gefiltert.Kombi_2.CAN_engine',     # set to 0 if LC model controlled and
#                         'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
#                         'LC_EDIT_BYTES' => { 1 => '0b11111111' },   # affected Byte(s) & BitMask(s)
#                         },
#
#  -----------------------------------------------------------------------------------------------------------------
#
#  Here is one example for a signal send from LC Simulator which is controlled directly from LC model
#  ( typical for dynamic signals with influence from LC model to brake ECU )
#  ( additionally Alive Counter Signals and Checksum Signals )
#
# 'MO1_Wunschmoment'       =>
#                         {
#                         'SIGNAL_NAME'   => 'MO1_Wunschmoment',
#                         'SENDER'        => 'Otto',
#                         'MESSAGE'       => 'Motor_1',
#                         'MULTIPLEX'     => undef,
#                         'STARTBIT'      => 56, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 0.390000,
#                         'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => 'MDI',
#                         'LC_READ_PHYS'  => 'MO1_Wunschmoment.Motor_1.CAN_engine',     ## verify LC signal names with CAN block parameters in DC
# ##                        'LC_WRITE_PHYS' => 'MO1_Wunschmoment.Motor_1.CAN_engine',     ## set to 0 or comment out if LC model controlled and
#                         'LC_MODEL_CTRL' => 1,                               ## set to 1 if LC model controlled
#                         'LC_EDIT_BYTES' => { 7 => '0b11111111' },   ## affected Byte(s) & BitMask(s)
#                         },
#
#
# ---------------------------------------------------------------------------------------------------------------------------------------------------
#
# The CAN Mapping which will be included into LIFT Exec Engine over LIFT Config starts here:

HEADER_TEST

#    S_w2outfile( 3 ,  $Header_text );

    S_w2outfile( 1 ,  "\$Defaults->{\"Mapping_CAN\"} = {\n" );
    S_w2outfile( 1 ,  "'NODE_UNDER_TEST'       => '$sut_node',\n\n" );

    my $abstract_sig_text =<<ABSTRACT;
'ABSTRACT_SIGNALS'      =>
               {
               ## just type here the signal names from Signal Mapping Section below
               ## some special testcases are using this abstract signal names
               'EBD_active'       => '',
               'ABS_active'       => '',
               'TCS_active'       => '',
               'ESP_active'       => '',
               'BVK_active'       => '',
               'MSR_active'       => '',
               'EDS_active'       => '',
               'lamp_EBD_defect'  => '',
               'lamp_ABS_defect'  => '',
               'lamp_ESP_defect'  => '',
               'TCS_request'      => '',
               'MSR_request'      => '',
               'ESP_passive'      => '',
               },

ABSTRACT

#    S_w2outfile( 1 ,  "$abstract_sig_text\n" );


    my $PD_text =<<PD;
'Diag_Byte_1'  =>
               {
               'SIGNAL_NAME'   => 'Diag_Byte_1',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Can_ABECU_2_Diag',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 7, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               },

'Diag_Byte_2'  =>
               {
               'SIGNAL_NAME'   => 'Diag_Byte_2',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Can_ABECU_2_Diag',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 15, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               },
'Diag_Byte_3'  =>
               {
               'SIGNAL_NAME'   => 'Diag_Byte_3',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Can_ABECU_2_Diag',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 23, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               },
'Diag_Byte_4'  =>
               {
               'SIGNAL_NAME'   => 'Diag_Byte_4',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Can_ABECU_2_Diag',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 31, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               },
'Diag_Byte_5'  =>
               {
               'SIGNAL_NAME'   => 'Diag_Byte_5',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Can_ABECU_2_Diag',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 39, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               },
'Diag_Byte_6'  =>
               {
               'SIGNAL_NAME'   => 'Diag_Byte_6',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Can_ABECU_2_Diag',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 47, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               },
'Diag_Byte_7'  =>
               {
               'SIGNAL_NAME'   => 'Diag_Byte_7',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Can_ABECU_2_Diag',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 55, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               },
'Diag_Byte_8'  =>
               {
               'SIGNAL_NAME'   => 'Diag_Byte_8',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Can_ABECU_2_Diag',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 63, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               },

'PD_req_2' =>
               {
               'SIGNAL_NAME'   => 'PD_req_2',  
               'SENDER'        => 'Tester',
               'MESSAGE'       => 'Can_PDiag_2_ABECU',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 15, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               },
PD

    S_w2outfile( 1 ,  "$PD_text\n" );

    S_w2outfile( 1 ,  "'CAN_MESSAGES'  => {\n" );

    my $mlc_idefix_text =<<MLC_IDEFIX;
       'MLC_A3'  =>
                      {
                        'ID'            => 163,
                        'DLC'           => 6,
                        'SENDER'        => 'MLC',
                        'CAN_BUS_NBR'   => 2,
                        'CYCLE'         => 10,
                      },
       'MLC_A2'  =>
                      {
                        'ID'            => 162,
                        'DLC'           => 6,
                        'SENDER'        => 'MLC',
                        'CAN_BUS_NBR'   => 2,
                        'CYCLE'         => 10,
                      },
       'MLC_A1'  =>
                      {
                        'ID'            => 161,
                        'DLC'           => 6,
                        'SENDER'        => 'MLC',
                        'CAN_BUS_NBR'   => 2,
                        'CYCLE'         => 10,
                      },
       'MLC_A4'  =>
                      {
                        'ID'            => 164,
                        'DLC'           => 6,
                        'SENDER'        => 'MLC',
                        'CAN_BUS_NBR'   => 2,
                        'CYCLE'         => 10,
                      },
       'MLC_110'  =>
                      {
                        'ID'            => 272,
                        'DLC'           => 6,
                        'SENDER'        => 'MLC',
                        'CAN_BUS_NBR'   => 2,
                        'CYCLE'         => 10,
                      },
       'IDX_101'  =>
                      {
                        'ID'            => 257,
                        'DLC'           => 6,
                        'SENDER'        => 'IDX',
                        'CAN_BUS_NBR'   => 2,
                        'CYCLE'         => 10,
                      },
       'IDX_102'  =>
                      {
                        'ID'            => 258,
                        'DLC'           => 6,
                        'SENDER'        => 'IDX',
                        'CAN_BUS_NBR'   => 2,
                        'CYCLE'         => 10,
                      },
       'IDX_201'  =>
                      {
                        'ID'            => 513,
                        'DLC'           => 6,
                        'SENDER'        => 'IDX',
                        'CAN_BUS_NBR'   => 2,
                        'CYCLE'         => 10,
                      },
       'IDX_202'  =>
                      {
                        'ID'            => 514,
                        'DLC'           => 6,
                        'SENDER'        => 'IDX',
                        'CAN_BUS_NBR'   => 2,
                        'CYCLE'         => 10,
                      },
MLC_IDEFIX


    S_w2outfile( 1 ,  "$mlc_idefix_text\n" );
    
    #Build a hash having dbc file name and CAN bus number associated with it
    my ( $dbc_file_base_1 , $dbc_file_path_1 , $suffix_1 ) = fileparse ( $opt_dbc_file_1 , '\.dbc' , '.DBC' , '\.Dbc' );
    $dbc_can_bus_mapping_hash->{$dbc_file_base_1} = $selected_CAN_bus_number ? $selected_CAN_bus_number : 1 ;
    
    if ($opt_dbc_file_2){
    my ( $dbc_file_base_2 , $dbc_file_path_2 , $suffix_2 ) = fileparse ( $opt_dbc_file_2 , '\.dbc' , '.DBC' , '\.Dbc' );
    $dbc_can_bus_mapping_hash->{$dbc_file_base_2} = $selected_CAN_bus_number_2 ? $selected_CAN_bus_number_2 : 1 ;
    }

foreach my $dbc_file_name (keys %DbcMsg ){

    foreach $DbcMsgId ( sort {$a<=>$b} keys %{$DbcMsg{$dbc_file_name}{"BOTSCHAFTEN"}} )
    {
        

        $MsgSender = $DbcMsg{$dbc_file_name}{"BOTSCHAFTEN"}{$DbcMsgId}{"BO_SENDER"};
        $MsgName = $DbcMsg{$dbc_file_name}{"BOTSCHAFTEN"}{$DbcMsgId}{"BO_NAME"};
        
        if (exists $hash_MsgNames->{$MsgName} ){
            #Store thr duplicate entry into hash
            push ( @Msg_Duplicates_Array, $MsgName);
                             ##------------------------------------------------------------------
                             ## inform user that options are missing
                             ##------------------------------------------------------------------
        } else {
            #store thr msg names
            $hash_MsgNames->{$MsgName} = 1;
        }
        
        
        $MsgDLC = $DbcMsg{$dbc_file_name}{"BOTSCHAFTEN"}{$DbcMsgId}{"BO_DLC"};
        unless( $MsgCycleTime = $DbcMsg{$dbc_file_name}{"BOTSCHAFTEN"}{$DbcMsgId}{"CycleTime"} ) {
           $MsgCycleTime = 10;
        }
        

        if( %ValidMsg and not $ValidMsg{ $DbcMsgId } )
        {
            S_w2log(1, " CAN message: $DbcMsgId ('$MsgName') not selected in CAN message list -> skipped in CAN mapping\n");
            next;
        }

        if( $MsgSender eq $sut_node )
        {
            ## no LC control for messages from SUT
#            $MsgLCControl    = "undef";
#            $MsgLC_DLC       = "undef";

            ## no CANoe control for messages from SUT
            $MsgCanoeDisable = "undef";
            $MsgCanoeDlc     = "undef";
            $MsgCanoeTiming  = "undef";

            push( @{$sut_snd_msg_ids{$dbc_file_name}} , $DbcMsgId);
        }
        else
        {
            ## LC control for messages not from SUT
 #           $MsgLCControl    = "'".$MsgName."_USED.".$MsgName.".$selected_CAN_engine'";
 #           $MsgLC_DLC       = "'".$MsgName."_DLC.".$MsgName.".$selected_CAN_engine'";
            
            ## CANoe control for messages not from SUT            
             if($opt_varType == 0)
            {
                $MsgCanoeDisable = "'LIFT_CAN_access::SysVar".$MsgName."To_'";
                $MsgCanoeDlc     = "'LIFT_CAN_access::SysVar".$MsgName."Dlc_'";
                $MsgCanoeTiming  = "'LIFT_CAN_access::SysVar".$MsgName."Time_'";
            }
            else #By default environment varibales will be created 
            {
                $MsgCanoeDisable = "'Env".$MsgName."To_'";
                $MsgCanoeDlc     = "'Env".$MsgName."Dlc_'";
                $MsgCanoeTiming  = "'Env".$MsgName."Time_'";
            }

            push( @{$sut_rcv_msg_ids{$dbc_file_name}} , $DbcMsgId);
        }

       
# cut form MESSAGE_TEXT
#                        'LC_CONTROL'    => $MsgLCControl,
#                        'LC_DLC'        => $MsgLC_DLC,
       
        $Message_Text =<<MESSAGE_TEXT;
       '$MsgName'  =>
                      {
                        'ID'            => $DbcMsgId,
                        'DLC'           => $MsgDLC,
                        'SENDER'        => '$MsgSender',
                        'CAN_BUS_NBR'   => $dbc_can_bus_mapping_hash->{$dbc_file_name},
                        'CYCLE'         => $MsgCycleTime,
                        'CANOE_DISABLE' => $MsgCanoeDisable ,
                        'CANOE_DLC'     => $MsgCanoeDlc ,
                        'CANOE_TIMING'  => $MsgCanoeTiming ,
                      },
MESSAGE_TEXT

        S_w2outfile( 2 ,  $Message_Text);
    }
}
    S_w2outfile( 2 ,  "           },\n\n" );

    S_w2outfile( 3 ,  "############################################# \n\n" );
    S_w2outfile( 1 ,  "## --- Signal List (msg by msg , IDs ascending) of System under Test node \n\n" );
    S_w2outfile( 3 ,  "############################################# \n\n" );

foreach my $dbc_file_name (keys %DbcMsg ){
    next unless ( defined $sut_snd_msg_ids{$dbc_file_name});
    foreach $DbcMsgId ( sort {$a<=>$b} @{$sut_snd_msg_ids{$dbc_file_name}} )
    {
        $MsgSender = $DbcMsg{$dbc_file_name}{"BOTSCHAFTEN"}{$DbcMsgId}{"BO_SENDER"};
        $MsgName = $DbcMsg{$dbc_file_name}{"BOTSCHAFTEN"}{$DbcMsgId}{"BO_NAME"};
        $MsgIdHex = sprintf( "0x%x", int $DbcMsgId );

        if( %ValidMsg and not $ValidMsg{ $DbcMsgId } )
        {
            S_w2log(1, " CAN message: $DbcMsgId ('$MsgName') not selected in CAN message list -> skipped in CAN mapping\n");
            next;
        }

        S_w2outfile( 3 ,  "# -------------------------------------------------------------------------------------- \n\n" );
        S_w2outfile( 1 ,  "# ----------- CAN MESSAGE: $MsgName ($MsgSender) ID: $DbcMsgId ($MsgIdHex), DBC File name :$dbc_file_name ------------- \n\n" );
        S_w2outfile( 3 ,  "# -------------------------------------------------------------------------------------- \n\n" );
        foreach $DbcSignalName ( sort keys %{$DbcMsg{$dbc_file_name}{"BOTSCHAFTEN"}{$DbcMsgId}{"SIGNALS"}} )
        {

            $DbcSig_Pos = $DbcMsg{$dbc_file_name}{"BOTSCHAFTEN"}{$DbcMsgId}{"SIGNALS"}{$DbcSignalName}{"SG_POSITION"};
            $DbcSig_Length = $DbcMsg{$dbc_file_name}{"BOTSCHAFTEN"}{$DbcMsgId}{"SIGNALS"}{$DbcSignalName}{"SG_LENGTH"};
            $DbcSig_Type = $DbcMsg{$dbc_file_name}{"BOTSCHAFTEN"}{$DbcMsgId}{"SIGNALS"}{$DbcSignalName}{"SG_TYPE"};
            $DbcSig_Factor = $DbcMsg{$dbc_file_name}{"BOTSCHAFTEN"}{$DbcMsgId}{"SIGNALS"}{$DbcSignalName}{"SG_FACTOR"};
            $DbcSig_Offset = $DbcMsg{$dbc_file_name}{"BOTSCHAFTEN"}{$DbcMsgId}{"SIGNALS"}{$DbcSignalName}{"SG_OFFSET"};
            $DbcSig_Unit = $DbcMsg{$dbc_file_name}{"BOTSCHAFTEN"}{$DbcMsgId}{"SIGNALS"}{$DbcSignalName}{"SG_UNIT"};
            $DbcSig_Format = $DbcMsg{$dbc_file_name}{"BOTSCHAFTEN"}{$DbcMsgId}{"SIGNALS"}{$DbcSignalName}{"SG_FORMAT"};

            $Multiplex_Master = $DbcMsg{$dbc_file_name}{"BOTSCHAFTEN"}{$DbcMsgId}{"SIGNALS"}{$DbcSignalName}{"SG_MULTIPLEXER"};
            $Multiplex_Code = $DbcMsg{$dbc_file_name}{"BOTSCHAFTEN"}{$DbcMsgId}{"SIGNALS"}{$DbcSignalName}{"SG_MULTIPLEX_VALUE"};

            if( defined $Multiplex_Master ) {
                $DbcSig_Multiplex = "{ 'MASTER' => '$DbcSignalName' }";
            }
            elsif(  defined $Multiplex_Code ) {
                if ( $Multiplex_Master = $DbcMsg{$dbc_file_name}{"BOTSCHAFTEN"}{$DbcMsgId}{"MULTIPLEXER"} ) {
                   $DbcSig_Multiplex = "{ 'MASTER' => '$Multiplex_Master' , 'CODE' => $Multiplex_Code }";
                }
                else  { $DbcSig_Multiplex = "{ 'ERROR' => 'NO_MASTER_FOUND' }"; }
            }
            else { $DbcSig_Multiplex = 'undef'; }


            $DbcSig_short_name = $DbcMsg{$dbc_file_name}{"BOTSCHAFTEN"}{$DbcMsgId}{"SIGNALS"}{$DbcSignalName}{'SHORT_SG_NAME'};

            if( defined $DbcSig_short_name ) {
               $CAN_tool_signal_name = $DbcSig_short_name;
            }
            else {
               $CAN_tool_signal_name = $DbcSignalName;
            }

            my $UniqueSignalName;
            if ($ALL_signals_count{$DbcSignalName} > 1){
                $UniqueSignalName = $MsgName.'::'.$DbcSignalName;
            }
            else{
                $UniqueSignalName = $DbcSignalName;
            }

            $LC_ReadPhys = $DbcSignalName."_phys.".$MsgName.".$selected_CAN_engine";
            $LC_ReadHex = $DbcSignalName."_hex.".$MsgName.".$selected_CAN_engine";

            $SignalMapping_Text =<<SIGMAPTXT;
'$UniqueSignalName'  =>
               {
               'SIGNAL_NAME'   => '$CAN_tool_signal_name',
               'SENDER'        => '$MsgSender',
               'MESSAGE'       => '$MsgName',
               'MULTIPLEX'     => $DbcSig_Multiplex,
               'STARTBIT'      => $DbcSig_Pos, 'LENGTH' => $DbcSig_Length, 'OFFSET' => $DbcSig_Offset, 'FACTOR' => $DbcSig_Factor,
               'FORMAT'        => '$DbcSig_Format', 'TYPE' => '$DbcSig_Type', 'UNIT' => '$DbcSig_Unit',
               'LC_READ_PHYS'  => '$LC_ReadPhys',     # verify with CAN block implemetation
               'LC_READ_HEX'   => '$LC_ReadHex',     # set both to 0 if signal not part of CAN block in LC NG
               'INIT'          => 0,     ## verify INIT value with specifications
               },

SIGMAPTXT
            S_w2outfile( 3 ,  $SignalMapping_Text );

        }
    }
}
    S_w2outfile( 1 ,  "## Signal List (msg by msg , IDs ascending) from Simulator \n\n" );
    
foreach my $dbc_file_name (keys %DbcMsg ){
    next unless ( defined $sut_rcv_msg_ids{$dbc_file_name});
    foreach $DbcMsgId ( sort {$a<=>$b} @{$sut_rcv_msg_ids{$dbc_file_name}} )
    {
        $MsgSender = $DbcMsg{$dbc_file_name}{"BOTSCHAFTEN"}{$DbcMsgId}{"BO_SENDER"};
        $MsgName   = $DbcMsg{$dbc_file_name}{"BOTSCHAFTEN"}{$DbcMsgId}{"BO_NAME"};
        $MsgDLC    = $DbcMsg{$dbc_file_name}{"BOTSCHAFTEN"}{$DbcMsgId}{"BO_DLC"};
        $MsgIdHex  = sprintf( "0x%x", int $DbcMsgId );

        if( %ValidMsg and not $ValidMsg{ $DbcMsgId } )
        {
            S_w2log(1, " CAN message: $DbcMsgId ('$MsgName') not selected in CAN message list -> skipped in CAN mapping\n");
            next;
        }

        S_w2outfile( 3 ,  "# -------------------------------------------------------------------------------------- \n\n" );
        S_w2outfile( 1 ,  "# ----------- CAN MESSAGE: $MsgName ($MsgSender) ID: $DbcMsgId ($MsgIdHex), DBC File name :$dbc_file_name ------------- \n\n" );
        S_w2outfile( 3 ,  "# -------------------------------------------------------------------------------------- \n\n" );
        foreach $DbcSignalName ( sort keys %{$DbcMsg{$dbc_file_name}{"BOTSCHAFTEN"}{$DbcMsgId}{"SIGNALS"}} )
        {

            $DbcSig_Pos    = $DbcMsg{$dbc_file_name}{"BOTSCHAFTEN"}{$DbcMsgId}{"SIGNALS"}{$DbcSignalName}{"SG_POSITION"};
            $DbcSig_Length = $DbcMsg{$dbc_file_name}{"BOTSCHAFTEN"}{$DbcMsgId}{"SIGNALS"}{$DbcSignalName}{"SG_LENGTH"};
            $DbcSig_Format = $DbcMsg{$dbc_file_name}{"BOTSCHAFTEN"}{$DbcMsgId}{"SIGNALS"}{$DbcSignalName}{"SG_FORMAT"};
            $DbcSig_Type   = $DbcMsg{$dbc_file_name}{"BOTSCHAFTEN"}{$DbcMsgId}{"SIGNALS"}{$DbcSignalName}{"SG_TYPE"};
            $DbcSig_Factor = $DbcMsg{$dbc_file_name}{"BOTSCHAFTEN"}{$DbcMsgId}{"SIGNALS"}{$DbcSignalName}{"SG_FACTOR"};
            $DbcSig_Offset = $DbcMsg{$dbc_file_name}{"BOTSCHAFTEN"}{$DbcMsgId}{"SIGNALS"}{$DbcSignalName}{"SG_OFFSET"};
            $DbcSig_Unit   = $DbcMsg{$dbc_file_name}{"BOTSCHAFTEN"}{$DbcMsgId}{"SIGNALS"}{$DbcSignalName}{"SG_UNIT"};

            $Multiplex_Master = $DbcMsg{$dbc_file_name}{"BOTSCHAFTEN"}{$DbcMsgId}{"SIGNALS"}{$DbcSignalName}{"SG_MULTIPLEXER"};
            $Multiplex_Code = $DbcMsg{$dbc_file_name}{"BOTSCHAFTEN"}{$DbcMsgId}{"SIGNALS"}{$DbcSignalName}{"SG_MULTIPLEX_VALUE"};

            if( defined $Multiplex_Master ) {
                $DbcSig_Multiplex = "{ 'MASTER' => '$DbcSignalName' }";
            }
            elsif(  defined $Multiplex_Code ) {
                if ( $Multiplex_Master = $DbcMsg{$dbc_file_name}{"BOTSCHAFTEN"}{$DbcMsgId}{"MULTIPLEXER"} ) {
                   $DbcSig_Multiplex = "{ 'MASTER' => '$Multiplex_Master' , 'CODE' => $Multiplex_Code }";
                }
                else  { $DbcSig_Multiplex = "{ 'ERROR' => 'NO_MASTER_FOUND' }"; }
            }
            else { $DbcSig_Multiplex = 'undef'; }

            $DbcSig_short_name = $DbcMsg{$dbc_file_name}{"BOTSCHAFTEN"}{$DbcMsgId}{"SIGNALS"}{$DbcSignalName}{'SHORT_SG_NAME'};

            if( defined $DbcSig_short_name ) {
               $CAN_tool_signal_name = $DbcSig_short_name;
            }
            else {
               $CAN_tool_signal_name = $DbcSignalName;
            }

            my $UniqueSignalName;
            if ($ALL_signals_count{$DbcSignalName} > 1){
                $UniqueSignalName = $MsgName.'::'.$DbcSignalName;
            }
            else{
                $UniqueSignalName = $DbcSignalName;
            }

            if($opt_varType == 0)
            {
                $VectorVarSignalName = "LIFT_CAN_access::SysVar_".$CAN_tool_signal_name."_";
                $VarType = "CANOE_SYS_VAR";
            }
            elsif($opt_varType == 1)
            {
                $VectorVarSignalName = "Env".$CAN_tool_signal_name."_";
                $VarType = "CANOE_ENV_VAR";
            }

            $LC_ReadPhys = $DbcSignalName.".".$MsgName.".$selected_CAN_engine";
            $LC_WritePhys = $DbcSignalName.".".$MsgName.".$selected_CAN_engine";

            $Edit_Bytes = CalculateEditBytes( $MsgDLC , $DbcSig_Pos , $DbcSig_Length , $DbcSig_Format , $DbcSig_Type , $DbcSig_Factor , $DbcSig_Offset );

            $SignalMapping_Text =<<SIGMAPTXT;
'$UniqueSignalName' =>
               {
               'SIGNAL_NAME'   => '$CAN_tool_signal_name',      '$VarType' => '$VectorVarSignalName',
               'SENDER'        => '$MsgSender',
               'MESSAGE'       => '$MsgName',
               'MULTIPLEX'     => $DbcSig_Multiplex,
               'STARTBIT'      => $DbcSig_Pos, 'LENGTH' => $DbcSig_Length, 'OFFSET' => $DbcSig_Offset, 'FACTOR' => $DbcSig_Factor,
               'FORMAT'        => '$DbcSig_Format', 'TYPE' => '$DbcSig_Type', 'UNIT' => '$DbcSig_Unit',
               'LC_READ_PHYS'  => '$LC_ReadPhys',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => '$LC_WritePhys',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { $Edit_Bytes },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

SIGMAPTXT
            S_w2outfile( 3 ,  $SignalMapping_Text );

        }
    }
}


    S_w2outfile( 1 ,  "};\n# end of CAN mapping\n\n1;\n" );

if (scalar @Msg_Duplicates_Array){
#set the array seperator
my $duplicate_msgs = join ("\n",@Msg_Duplicates_Array);

#Promt the user about the duplicate message names
                             $main->messageBox (
                              '-icon'    => "error",
                              '-type'    => "OK",
                              '-title'   => 'Error',
                              '-message' => "! Thsese Msgs were found in both dbc files :\n $duplicate_msgs \n Written those to mapping files!!!! ",
                             );
}
    return 1;
}

##------------------------------------------------------------------
## CalculateEditBytes (  )
##------------------------------------------------------------------
sub CalculateEditBytes
{
    my (
       $MsgDLC ,
       $DbcSig_Pos ,
       $DbcSig_Length ,
       $DbcSig_Format ,
       $DbcSig_Type ,
       $DbcSig_Factor ,
       $DbcSig_Offset
     ) = @_;            # whole paramter array

     my ( @raw_all , $index , $byte_index , $start_byte , $end_byte , $mask , $EditBytes , $msb_index , $lsb_index, $msb_position, $lsb_position, );

   # create array with 0 foreach bit
   # bit: 0 1 2 .. 62 63
   # val: 0 0 0 .. 0  0
   my $last_index = $MsgDLC*8 - 1;
   for $index ( 0 .. $last_index ) { $raw_all[$index] = 0 }

   if( $DbcSig_Format eq 'INTEL' )
   {
      # set 1 for the relevant signal ( e.g. Pos=3 Length=2 )
      # bit: 0 1 2 3 4 5 6 .. 62 63
      # val: 0 0 0 1 1 0 0 .. 0  0
      for $index ( $DbcSig_Pos .. $DbcSig_Pos+$DbcSig_Length-1 ) { $raw_all[$index] = 1 }

      # calculate start_byte and end_byte
      if( $DbcSig_Pos == 0 ) { $start_byte = 0 }
      else                   { $start_byte = int( ( $DbcSig_Pos ) / 8 ) }
      $end_byte   = int( ( $DbcSig_Pos + $DbcSig_Length - 1 ) / 8);

      for $byte_index ( $start_byte .. $end_byte )
      {
        $mask = join( '' ,
                            # reverse all bits because bit order is right to left
                            reverse (
                                  # take a sublist with 8 bits from the whole bitstream
                                  @raw_all[
                                            $byte_index * 8                 # first bit position ( 0 , 8 , 16, ...)
                                                 ..                         # to
                                                     $byte_index * 8 + 7    # last bit position ( 7 , 15 , 23, ...)
                                  ]
                               )
                       ); # end of join
        $EditBytes .= "$byte_index => '0b$mask' , "
      }
      $EditBytes =~ s/ , $//;
      return $EditBytes;
   }
   elsif ( $DbcSig_Format eq 'MOTOROLA' )
   {
      $msb_position = $DbcSig_Pos;
      my @bit_order_type_1 =   (  7 ,  6 ,  5 ,  4 ,  3 ,  2 ,  1 ,  0 ,
                                 15 , 14 , 13 , 12 , 11 , 10 ,  9 ,  8 ,
                                 23 , 22 , 21 , 20 , 19 , 18 , 17 , 16 ,
                                 31 , 30 , 29 , 28 , 27 , 26 , 25 , 24 ,
                                 39 , 38 , 37 , 36 , 35 , 34 , 33 , 32 ,
                                 47 , 46 , 45 , 44 , 43 , 42 , 41 , 40 ,
                                 55 , 54 , 53 , 52 , 51 , 50 , 49 , 48 ,
                                 63 , 62 , 61 , 60 , 59 , 58 , 57 , 56 ,
                              );
      # find index of StartPos in Bit_order_list
      for $index ( 0 .. $last_index ) {
          $msb_index = $index if $bit_order_type_1[ $index ] == $msb_position ;
      }
      $lsb_index = $msb_index + $DbcSig_Length - 1;
      $lsb_position = $bit_order_type_1[ $lsb_index ];

#      S_w2log(3, " MSB: Pos [$msb_position] Idx [$msb_index] LSB: Pos [$lsb_position] Idx [$lsb_index]\n");

      # write the raw_all new
      for ( 0 .. $msb_index -1 ) { $raw_all[$_] = 0 }
      for ( $msb_index .. $lsb_index ) { $raw_all[$_] = 1 }
      for ( $lsb_index+1 .. $last_index ) { $raw_all[$_] = 0 }
      if( $DbcSig_Pos == 0 ) { $start_byte = 0 }
      else                   { $start_byte = int( ( $DbcSig_Pos ) / 8 ) }
      $end_byte   = int( $lsb_index / 8 );

#      S_w2log(1, " START_BYTE: $start_byte END_BYTE: $end_byte\n");

      for $byte_index ( $start_byte .. $end_byte )
      {
        $mask = join( '' ,
                                  # take a sublist with 8 bits from the whole bitstream
                                  @raw_all[
                                            $byte_index * 8               # first bit position ( 0 , 8 , 16, ...)
                                                 ..                       # to
                                                     $byte_index * 8 + 7  # last bit position ( 7 , 15 , 23, ...)
                                  ]
      #                                        )
                       ); # end of join
        $EditBytes .= "$byte_index => '0b$mask' , "
      }
      $EditBytes =~ s/ , $//;
      return $EditBytes;
   }
   else { return "DBC_ERROR INVALID BYTE FORMAT" }

   return "$start_byte .. $end_byte";
}


##------------------------------------------------------------------
## check_req_msg_in_dbc (  )
##------------------------------------------------------------------
sub check_req_msg_in_dbc {
    my $DBC = shift;
    my $UsedMsg = shift;

    S_w2log(1, " Sub: check_req_msg_in_dbc \n");

    my %ValidMsg = %$UsedMsg if defined $UsedMsg;
    my %DbcMsg = %$DBC;

    my %ValidDecMsg;
    my ( $ValidMsgName , $ValidMsgId , $DbcMsgId , $msg_cnt , $MsgIdHex , $MsgName );

    S_w2log( 2, "   Search MsgIds for messages just given with name in CAN msg list \n");
    foreach $msg_cnt ( keys %ValidMsg )
    {
       if ( $ValidMsgName = $ValidMsg{ $msg_cnt }{ 'OTHER' } )
       {
        foreach my $dbc_file_name (keys %DbcMsg ){          
          foreach $DbcMsgId ( keys %{$DbcMsg{$dbc_file_name}{"BOTSCHAFTEN"}} )
          {
              if( $ValidMsgName eq $DbcMsg{$dbc_file_name}{"BOTSCHAFTEN"}{ $DbcMsgId }{"BO_NAME"} )
              {
                  $MsgIdHex = sprintf( "%x", int $DbcMsgId );
                  S_w2log(2, "   Found Id   '$DbcMsgId'\t (0x$MsgIdHex)  \t for Msg '$ValidMsgName' \n");
                  $ValidMsg{ $msg_cnt }{ 'DEC' } = $DbcMsgId;
                  $ValidMsg{ $msg_cnt }{ 'FOUND' } = 1;
                  $ValidDecMsg{ $DbcMsgId } = 1;
              }
          }
        }
          unless( $ValidMsg{ $msg_cnt }{ 'FOUND' } )
          {
              S_w2log(1, "  !! ERROR !!  Could not find '$ValidMsgName' in DBC file \n");
          }
       }
       elsif ( $ValidMsgId = $ValidMsg{ $msg_cnt }{ 'DEC' } )
       {
        foreach my $dbc_file_name (keys %DbcMsg ){
          foreach $DbcMsgId ( keys %{$DbcMsg{$dbc_file_name}{"BOTSCHAFTEN"}} )
          {
              if( $ValidMsgId == $DbcMsgId )
              {
                  $MsgName = $DbcMsg{$dbc_file_name}{"BOTSCHAFTEN"}{ $DbcMsgId }{"BO_NAME"};
                  $MsgIdHex = sprintf( "%x", int $DbcMsgId );
                  S_w2log(2, "   Found Id   '$DbcMsgId'\t (0x$MsgIdHex)  \t for Msg '$MsgName'\n");
                  $ValidMsg{ $msg_cnt }{ 'DEC' } = $DbcMsgId;
                  $ValidMsg{ $msg_cnt }{ 'FOUND' } = 1;
                  $ValidDecMsg{ $DbcMsgId } = 1;
              }
          }
        }
          unless( $ValidMsg{ $msg_cnt }{ 'FOUND' } )
          {
              S_w2log(1, "  !! ERROR !!  Could not find '$ValidMsgId' in DBC file \n");
          }
       }
       else
       {
           S_w2log(1, "  !! ERROR !!  Processing Error - no item for 'DEC' or 'OTHER' found\n");
       }
    }
    ## end of searching requested messages in DBC file

    return %ValidDecMsg;
}


##------------------------------------------------------------------
## process_dbc_file ( file_name )
##------------------------------------------------------------------
sub process_dbc_file {
   my $dbc_file = shift;
   my $dbc_content = shift;

   S_w2log(1, "Sub: process_dbc_file: $dbc_file\n");

   my %ALL = %$dbc_content;
   my ( $BO_ID , $BO_NAME , $BO_DLC , $BO_SENDER , $BO_Time );
   my ( $SG_NAME , $SG_POSITION , $SG_LENGTH , $SG_FORMAT , $SG_TYPE , $SG_FACTOR , $SG_OFFSET , $SG_UNIT , $SG_MODULS , $SG_MINIMUM , $SG_MAXIMUM );
   my $SG_MULTIPLEX_VALUE;
   my $SG_MULTIPLEXER;
   my $SHORT_SG_NAME; my @ORIG_DBC ; my @NEW_DBC; my @TEMP_DBC; my $ToBeReplaced;
   my ( $dbc_file_base , $dbc_file_path , $suffix ) = fileparse ( $dbc_file , '\.dbc' , '.DBC' , '\.Dbc' );
   my $msg_cnt=0; my $sig_cnt;

   open( DBCIN , "< $dbc_file") || die ("Open file $dbc_file: $!\n");
   while (<DBCIN>) {

         push( @ORIG_DBC , $_ );

         # delete LINES marked with "___NOT_USED___"
         next if /___NOT_USED___/;

         ###### ANALYSIS #######
         #
         # if: "BO_ 844 NAV_GPS2: 8 CCC_MASK"
         #      KEY  ID  NAME    DLC  TRANSMITTER NODE
         if( /BO_    # BO_ keyword
          \s+    # some white char
          (\d+)  # match BOTSCHAFTS ID
          \s+    # some white char
          (\w+)  # match BOTSCHAFTS NAME
          \s*    # may be some white char
          :      # the ":"
          \s+    # some white char
          (\d+)  # the DLC (byte count)
          \s+    # some white char
          (\w+)  # match TRANSMITTER NODE NAME
          \s*    # may be some white char
         /x) {

            undef $BO_ID;
            undef $BO_NAME;
            undef $BO_DLC;
            undef $BO_SENDER;

            S_w2log( 2, "\n$_" ) ;

            $msg_cnt++;

            $sig_cnt=0;

            $BO_ID = $1;
            $BO_NAME = $2;
            $BO_DLC = $3;
            $BO_SENDER = $4;
            S_w2log(3, "\n- $msg_cnt - BO_ID: $BO_ID BO_NAME: $BO_NAME  BO_DLC: $BO_DLC BO_SENDER: $BO_SENDER\n" );
            $ALL{$dbc_file_base}{"BOTSCHAFTEN"}{$BO_ID}{"BO_NAME"}=$BO_NAME;
            $ALL{$dbc_file_base}{"BOTSCHAFTEN"}{$BO_ID}{"BO_DLC"}=$BO_DLC;
            $ALL{$dbc_file_base}{"BOTSCHAFTEN"}{$BO_ID}{"BO_SENDER"}=$BO_SENDER;
         }
         # END OF if: "BO_ 844 NAV_GPS2: 8 CCC_MASK"

         # if: " SG_ ST_QUAL_GPS : 56|8@1+ (0.5,0) [0|0] "%"  ACC,EGS_SSG"
         #       KEY   |            | | ||   |  |   | |   |        |
         #       NAME -+            | | ||   |  |   | |   |        |
         #       POSITION ----------+ | ||   |  |   | |   |        |
         #       LENGTH --------------+ ||   |  |   | |   |        |
         #       FORMAT-----------------+|   |  |   | |   |        |
         #       SIGNED/UNSIGNED --------+   |  |   | |   |        |
         #       QUANTIZATION/FACTOR --------+  |   | |   |        |
         #       OFFSET ------------------------+   | |   |        |
         #       MINIMUM ---------------------------+ |   |        |
         #       MAXIMUM -----------------------------+   |        |
         #       UNIT ------------------------------------+        |
         #       RECEIVE NODES ------------------------------------+
         if( /
           SG_    # match the KEY
           \s+    # some white char
           (\w+)  # match the NAME
           \s*    # maybe some white char
           m?     # maybe multiplexed signal
           \d*    # maybe multiplexed signal
           \s*    # may be some white char
           :      # the ":"
           \s*    # some white char
           (\d+)  # the start POSITION (bit)
           \|     # the "|"
           (\d+)  # the LENGTH of signal in bit
           @      # some any char
           (\d)   # FORMAT : 1 (Intel) or 0 (Motorola)
           (\+|-) # the "+" or the "-"
           \s+    # some white char
           \(     # match the "("
           (
               [+-]?\d*\.?\d*[Ee][+-]\d+|
               [+-]?\d+\.\d+|
               [+-]?\d+\.|
               [+-]?\.\d+|
               [+-]?\d+
           ) # match the FACTOR
           ,    # match the ","
           (
               [+-]?\d*\.?\d*[Ee][+-]\d+|
               [+-]?\d+\.\d+|
               [+-]?\d+\.|
               [+-]?\.\d+|
               [+-]?\d+
           ) # match the OFFSET
           \)    # match the ")"
           \s*    # some white char
           \[    # match the "["
           (
               [+-]?\d*\.?\d*[Ee][+-]\d+|
               [+-]?\d+\.\d+|
               [+-]?\d+\.|
               [+-]?\.\d+|
               [+-]?\d+
           ) # match the MINIMUM
           \|    # match the "|"
           (
               [+-]?\d*\.?\d*[Ee][+-]\d+|
               [+-]?\d+\.\d+|
               [+-]?\d+\.|
               [+-]?\.\d+|
               [+-]?\d+
           ) # match the MAXIMUM
           \]    # match the "["
           \s*    # some white char
           \"    # match the "["
           (.*)     # match the UNIT
           \"    # match the "["
           \s*    # some white char
           (\S+)    # network elements
         /xi    # the allowance of comments:-)
         ) {

            undef $SG_NAME;
            undef $SG_POSITION;
            undef $SG_LENGTH;
            undef $SG_FORMAT;
            undef $SG_TYPE;
            undef $SG_FACTOR;
            undef $SG_OFFSET;
            undef $SG_UNIT;
            undef $SG_MODULS;
            undef $SG_MINIMUM;
            undef $SG_MAXIMUM;
            undef $SG_MULTIPLEX_VALUE;
            undef $SG_MULTIPLEXER;
            undef $SHORT_SG_NAME;

            $sig_cnt++;

            #    ASSIGN ALL FOUND ITEMS
            $SG_NAME = $1;
            $SG_POSITION = $2;
            $SG_LENGTH = $3;

            $SG_FORMAT = "INTEL"    if ($4 == 1);
            $SG_FORMAT = "MOTOROLA" if ($4 == 0);
            $SG_FORMAT = "DBC_ERROR" unless defined $SG_FORMAT;

            $SG_TYPE   = "UNSIGNED" if ($5 eq "+");
            $SG_TYPE   = "SIGNED"   if ($5 eq "-");
            $SG_TYPE   = "DBC_ERROR" unless defined $SG_TYPE;

            $SG_FACTOR = sprintf("%f", $6);
            $SG_OFFSET = sprintf("%f", $7);
            $SG_UNIT = $10;
            $SG_UNIT =~ s/\'//g;   # replace the ' character in case that is part of UNIT (eg. 'C instead of �C)
            $SG_MODULS = $11;

            $SG_MINIMUM = sprintf("%f", $8);
            $SG_MAXIMUM = sprintf("%f", $9);

            # increase signal counter
            $ALL_signals_count{$SG_NAME}++;
            
            # match  "SG_ MF_Zaehler M ..."
            if( /
              SG_    # match the KEY
              \s+    # some white char
              \w+    # match the NAME
              \s+    # maybe some white char
              M      # multiplexed signal
              \s+
              /ix
              )
            {
              $SG_MULTIPLEXER = "yes";
            }

            # match  "SG_ MF_IntervallWmax m3 ..."
            if( /
              SG_    # match the KEY
              \s+    # some white char
              \w+    # match the NAME
              \s+    # maybe some white char
              M      # multiplexed signal
              (\d+)  # multiplexed signal code
              \s+
              /ix
              )
            {
              $SG_MULTIPLEX_VALUE = $1;
            }

            $SG_MINIMUM =~ s/\.d*0+$//g;
            $SG_MAXIMUM =~ s/\.d*0+$//g;

            #    SOME PRINTOUTS FOR DEBUG
            S_w2log( 3, "\n - $msg_cnt - ($sig_cnt) - $_" );
            S_w2log( 3, "  ->  SG_NAME : $SG_NAME\n");
            S_w2log( 3, "  ->  SG_POSITION : $SG_POSITION\n");
            S_w2log( 3, "  ->  SG_LENGTH : $SG_LENGTH\n");
            S_w2log( 3, "  ->  SG_FORMAT : $SG_FORMAT\n");
            S_w2log( 3, "  ->  SG_TYPE : $SG_TYPE\n");
            S_w2log( 3, "  ->  SG_FACTOR : $SG_FACTOR\n");
            S_w2log( 3, "  ->  SG_OFFSET : $SG_OFFSET\n");
            S_w2log( 3, "  ->  SG_MINIMUM : $SG_MINIMUM\n");
            S_w2log( 3, "  ->  SG_MAXIMUM : $SG_MAXIMUM\n");
            S_w2log( 3, "  ->  SG_UNIT : $SG_UNIT\n");
            S_w2log( 3, "  ->  SG_MODULS : $SG_MODULS\n");

            S_w2log( 3, "  ->  SG_MULTIPLEXER : $SG_MULTIPLEXER\n") if defined $SG_MULTIPLEXER;
            S_w2log( 3, "  ->  SG_MULTIPLEX_VALUE : $SG_MULTIPLEX_VALUE\n") if defined $SG_MULTIPLEX_VALUE;
            
            if(($BO_NAME cmp $SG_NAME) == 0)
            {
                push (@Identical_Msg_Sig_Name, $BO_NAME);
            }
            
            

            $ALL{$dbc_file_base}{"BOTSCHAFTEN"}{$BO_ID}{"SIGNALS"}{$SG_NAME}{"SG_POSITION"} = $SG_POSITION;
            $ALL{$dbc_file_base}{"BOTSCHAFTEN"}{$BO_ID}{"SIGNALS"}{$SG_NAME}{"SG_LENGTH"} = $SG_LENGTH;
            $ALL{$dbc_file_base}{"BOTSCHAFTEN"}{$BO_ID}{"SIGNALS"}{$SG_NAME}{"SG_FORMAT"} = $SG_FORMAT;
            $ALL{$dbc_file_base}{"BOTSCHAFTEN"}{$BO_ID}{"SIGNALS"}{$SG_NAME}{"SG_TYPE"} = $SG_TYPE;
            $ALL{$dbc_file_base}{"BOTSCHAFTEN"}{$BO_ID}{"SIGNALS"}{$SG_NAME}{"SG_FACTOR"} = $SG_FACTOR;
            $ALL{$dbc_file_base}{"BOTSCHAFTEN"}{$BO_ID}{"SIGNALS"}{$SG_NAME}{"SG_OFFSET"} = $SG_OFFSET;
            $ALL{$dbc_file_base}{"BOTSCHAFTEN"}{$BO_ID}{"SIGNALS"}{$SG_NAME}{"SG_MINIMUM"} = $SG_MINIMUM;
            $ALL{$dbc_file_base}{"BOTSCHAFTEN"}{$BO_ID}{"SIGNALS"}{$SG_NAME}{"SG_MAXIMUM"} = $SG_MAXIMUM;
            $ALL{$dbc_file_base}{"BOTSCHAFTEN"}{$BO_ID}{"SIGNALS"}{$SG_NAME}{"SG_UNIT"} = $SG_UNIT;
            $ALL{$dbc_file_base}{"BOTSCHAFTEN"}{$BO_ID}{"SIGNALS"}{$SG_NAME}{"SG_MODULS"} = $SG_MODULS;
            $ALL{$dbc_file_base}{"BOTSCHAFTEN"}{$BO_ID}{"SIGNALS"}{$SG_NAME}{"SG_MULTIPLEXER"} = 1 if defined $SG_MULTIPLEXER;
            $ALL{$dbc_file_base}{"BOTSCHAFTEN"}{$BO_ID}{"SIGNALS"}{$SG_NAME}{"SG_MULTIPLEX_VALUE"} = $SG_MULTIPLEX_VALUE if defined $SG_MULTIPLEX_VALUE;

            if( defined $SG_MULTIPLEXER ) {
               unless( $ALL{$dbc_file_base}{"BOTSCHAFTEN"}{$BO_ID}{"MULTIPLEXER"} )
               {  $ALL{$dbc_file_base}{"BOTSCHAFTEN"}{$BO_ID}{"MULTIPLEXER"} = $SG_NAME;  }
               else
               {  S_w2log( 1, "  DBC ERROR ! more then 1 Multiplexer in Message $BO_ID !\n"); }
            }

            if( length( $SG_NAME ) > 255 ) { # Maximum no of characters allowed for a signal name in database is 256
               $SHORT_SG_NAME = Create_Short_Signal_name( $SG_NAME , $SG_POSITION , $SG_MULTIPLEX_VALUE  );
               $ALL{$dbc_file_base}{"BOTSCHAFTEN"}{$BO_ID}{"SIGNALS"}{$SG_NAME}{'SHORT_SG_NAME'} = $SHORT_SG_NAME;
               $ToBeReplaced->{$SG_NAME} = $SHORT_SG_NAME;
            }

         }
         # END OF " SG_ ST_QUAL_GPS : 56|8@1+ (0.5,0) [0|0] "%"  ACC,EGS_SSG"

         ## COLLECT CYCLETIME
         ## BA_ "CycleTime" BO_ 431 20;
         if( /BA_\s*\".*CycleTime.*\"\s*BO_\s*(\d+)\s*(\d+)\s*;/) {
            $BO_ID = $1;
            $BO_Time = $2;
            S_w2log( 2 , "$BO_ID => CycleTime: $BO_Time\n" );
            $ALL{$dbc_file_base}{"BOTSCHAFTEN"}{$BO_ID}{"CycleTime"} = $BO_Time;
         }


   }
   close DBCIN;

   @TEMP_DBC = @ORIG_DBC;
   foreach $SG_NAME ( keys %$ToBeReplaced ) {
      @NEW_DBC = ();
      foreach ( @TEMP_DBC ) {
         if( /$SG_NAME/ ) {
            $SHORT_SG_NAME = $ToBeReplaced->{$SG_NAME};
            s/$SG_NAME/$SHORT_SG_NAME/g ;
         }
         push( @NEW_DBC , $_ );
      }
      @TEMP_DBC = @NEW_DBC;
   }

   my ( $new_canoe_file ) = $dbc_file_path."/".$dbc_file_base."_4RBS".$suffix;

   if ( %$ToBeReplaced ) {    
       open( DBCOUT , "> $new_canoe_file") || die ("Open file $new_canoe_file: $!\n");
       print DBCOUT @NEW_DBC;
       close DBCOUT;
   }
   else {
       copy( $dbc_file , $new_canoe_file ) || die ( "Copy $dbc_file , $new_canoe_file : $!\n" );
        system("ATTRIB -R $new_canoe_file");     
   }

   return %ALL;
}

##------------------------------------------------------------------
## Create_Short_Signal_name (  )
##------------------------------------------------------------------
sub Create_Short_Signal_name {
   my( $SG_NAME , $SG_POSITION , $SG_MULTIPLEX_VALUE  ) = @_;

   my (
         $M_CODE , $new_signal_short , $extension , $signal_cut , $return_signal_short ,
      );
   if( defined $SG_MULTIPLEX_VALUE ) {
      $M_CODE = "M".$SG_MULTIPLEX_VALUE;
   }
   else {
      $M_CODE = "";
   }

   $extension = "_P".$SG_POSITION.$M_CODE."cut";

   $signal_cut = 255 - length( $extension ); # Maximum no of characters allowed for a signal name in database is 256

   $new_signal_short = substr( $SG_NAME , 0 , $signal_cut );

   $return_signal_short = $new_signal_short.$extension;

   S_w2log( 2, " Create_Short_Signal_name : $SG_NAME -> $return_signal_short \n");

   return $return_signal_short;
}

##------------------------------------------------------------------
## read_msg_list_file ( file_name )
##------------------------------------------------------------------
sub read_msg_list_file {
    my $msg_list_file = shift;

    S_w2log(1, "Sub: read_msg_list_file ($msg_list_file) \n");

    my ( %MSG_LIST , $hex_value , $dec_value , $other_value );
    my $msg_cnt=1;

    open( MSG_LIST_FILE, $msg_list_file) || die "Opening $msg_list_file \n";

    while ( <MSG_LIST_FILE> )
    {
       next if /^\s*#/;
       next if /^\W+$/;
       if ( /^\s*(0x[0-9a-f]+)/i )
       {
          $hex_value = $1;
          $dec_value = sprintf( "%d", hex $hex_value);
          S_w2log(3, " $msg_cnt \t Found Hex Value : $hex_value -> '$dec_value' (Dec)\n");
          $MSG_LIST{ $msg_cnt }{ 'DEC' } = $dec_value;
          $msg_cnt++;
       }
       elsif ( /^\s*(\d+)/i )
       {
          $dec_value = $1;
          S_w2log(3, " $msg_cnt \t Found Dec Value : '$dec_value' \n");
          $MSG_LIST{ $msg_cnt }{ 'DEC' } = $dec_value;
          $msg_cnt++;
       }
       elsif (  /^\s*(\S+)/i  )
       {
          $other_value = $1;
          S_w2log(3, " $msg_cnt \t Found Other     : '$other_value' \n");
          $MSG_LIST{ $msg_cnt }{ 'OTHER' } = $other_value;
          $msg_cnt++;
       }
       else
       {
          S_w2log(3, "   Found Nothing   : '$_' \n");
       }
    }
    close MSG_LIST_FILE;

    return %MSG_LIST;
}

##------------------------------------------------------------------
sub S_w2log {
##------------------------------------------------------------------
    my $level = shift;
    my $text = shift;

    if ($opt_verbose >= $level) { print $text; }
    print LOG $text;
}

##------------------------------------------------------------------
sub S_w2outfile {
##------------------------------------------------------------------
    my $level = shift;
    my $text = shift;

    if ($opt_verbose >= $level) { print "OUT : $text"; }
    print OUTFILE $text;
    print LOG "OUT : $text";
}


##------------------------------------------------------------------
## LPCM_init
##   (GUI)
##------------------------------------------------------------------
sub LPCM_init {

    ##------------------------------------------------------------------
    ## create main window 'main'
    ##------------------------------------------------------------------
    # create main window 'main'
    $main = MainWindow->new("-background" => "#888888");

    # define minimum size of main window 'main'
    $main -> minsize(800,300);

    # create title in main window 'main'
    $main -> title
      ( $LPCM_VERSION );
      
    ##------------------------------------------------------------------
    ## create frame 'F1' in main window 'main'
    ##------------------------------------------------------------------
    $F1 = $main -> Frame("-background" => "#333546")
    -> pack
      (
      "-side"   => 'top',
      "-expand" => 1,
      "-fill"   => 'both',
      );

    ##------------------------------------------------------------------
    ## create frame 'F2' in main window 'main'
    ##------------------------------------------------------------------
    $F2 = $main -> Frame("-background" => "#333546")
    -> pack
      (
      "-side"   => 'bottom',
      "-fill"   => 'x',
      );

    ##------------------------------------------------------------------
    ## write head line in frame 'F1'
    ##------------------------------------------------------------------
    $F1 -> Label
      (
      "-text" => 'LIFT prepare CAN mapping : configuration window',
      -font=>'{Segoe UI Semibold} 13 bold ',
      -background => "#333546",
      -foreground => "white",
      -width => 50,
      -relief => 'groove',
      )
    -> pack ("-side"   => "top");

    ##------------------------------------------------------------------
    ## create exit and start buttons in frame 'F2'
    ##------------------------------------------------------------------
    $F2 -> Button
      (
      "-text"    => "Quit",
      -width=>'8',
      -font=>'{Segoe UI Semibold} 12 ',
      -background => "Red4",
      -foreground => "white",
      -relief => 'groove',
      "-command" => sub { print " QUIT pressed -> Exit\n"; exit; }
      )
    -> pack
      (
      "-side"  => 'left',
      "-pady"  => 20,
      "-padx"  => 20,
      "-ipady" => 5,
      "-ipadx" => 5,
      );

    $start_button = $F2 -> Button
      (
      "-text"    => "Start LPCM",
      -width=>'8',
      -font=>'{Segoe UI Semibold} 12 ',
      -foreground => "white",
      -relief => 'groove',
      -background => "ForestGreen",
      "-command" => sub
                 {
#                        if ($opt_dbc_file_1 and $opt_msg_list and $opt_output_file ){
#                        if ( $opt_dbc_file_1 and $opt_sut_node ){
                        if ( $opt_dbc_file_1 and $opt_output_file){
                            #execute LPCM_engine
                            LPCM_engine();
                            S_w2log(1, " Finished -> Press QUIT \n");
                        }
                        else
                        {
                             ##------------------------------------------------------------------
                             ## inform user that options are missing
                             ##------------------------------------------------------------------
                             $main->messageBox (
                              '-icon'    => "error",
                              '-type'    => "OK",
                              '-title'   => 'Error',
                              '-message' => "! not enough options defined ! at least DBC and output file needed ",
                             );
                        }
                 }
      )
    -> pack
      (
      "-side"  => 'right',
      "-pady"  => 20,
      "-padx"  => 20,
      "-ipady" => 5,
      "-ipadx" => 5,
      );

##  update_staus();

    ##------------------------------------------------------------------
    ## GET OPTIONS : check if enough options were passed
    ##------------------------------------------------------------------
    if (GetOptions(
                "msg_list=s",    # file with list of CAN messages
                "dbc_file=s",    # dbc file
                "output_file=s", # CAN mapping output file
                "sut_node=s",    # node under test
                "verbose=i",     # verbose level
                )
          && $opt_dbc_file_1    # dbc file is mandatory
          && $opt_sut_node    # node under test is mandatory
        ){
        # run with option
        exec_options ();
    }
    else { no_options(); } # ask user for options
}

##------------------------------------------------------------------
## exec_options
##------------------------------------------------------------------
sub exec_options {

    $F1 -> Label
      (
      "-text" => "params:\nDBC file = $opt_dbc_file_1\nCAN msg list = $opt_msg_list\nCAN mapping output = $opt_output_file\nSUT node = $opt_output_file\nverbose = $opt_verbose",
      )
    -> pack ("-side"   => "top");

    #press start button
    $start_button -> invoke();
    exit;
}

##------------------------------------------------------------------
## no_options
##------------------------------------------------------------------
sub no_options {

    $F1 -> Label( "-text" => 'started without/too less params -> using GUI',  -foreground => "white",-background=> "#333546",-font=>'{Segoe UI Semibold} 13 bold',-width => 50,) -> pack ("-side"   => "top");

    #Frame for keeping 1st dbc file and CAN bus number
    my $F1_dbc_bus_grp_1 = $F1 -> Frame("-background" => "#888888", -relief=>'solid',-borderwidth => 1,)
    -> pack
      (
      "-side"   => 'top',
      "-expand" => 1,
      "-fill"   => 'both',
      "-pady"   => 5,
      "-padx"   => 5,
      );
      
    ##------------------------------------------------------------------
    ## create Frame for choosing DBC file with label, entry and button
    ##------------------------------------------------------------------
    $F1_1 = $F1_dbc_bus_grp_1 -> Frame("-background" => "#888888")->pack(-pady=>'2', "-fill"   => 'x',  );

    $F1_1 -> Label ( "-text" => "1st DBC input file : ", -background => "#888888", -foreground => 'white', -font=>'{Segoe UI Semibold} 10 bold',-width=>'26', ) -> pack ("-side"   => 'left');

    $F1_1->Entry( "-textvariable" => \$opt_dbc_file_1, -validate => 'focusout', -vcmd => [ \&check_state ], -background => "grey",)->pack( "-side" => 'left', "-fill" => 'x', "-expand" => 1,"-padx" => 5 );

    # create 'browse file' button
    $F1_1 -> Button       (
      "-text" => "Browse...",
      -relief => 'groove',
      -background => "#333366",
      -foreground  => "white",
      -font=>'{Segoe UI Semibold} 10 ',
      "-command" => sub{
                        my $temp = $opt_dbc_file_1;       # store old value
                        $opt_dbc_file_1 = $main -> getOpenFile (
                            "-filetypes"  => [ ["DBC files", '.dbc'], ["All files", '.*'] ],
                            "-title"      => "DBC file which have to be scanned" ,
                            "-initialdir" => '.',
                        );
                        unless ($opt_dbc_file_1) {$opt_dbc_file_1 = $temp;} # if no new value, restore old one
                        if ( defined $opt_dbc_file_2 && $opt_dbc_file_1 eq $opt_dbc_file_2 ){
                            #Promt the user about the duplicate message names
                                         $main->messageBox (
                                          '-icon'    => "error",
                                          '-type'    => "OK",
                                          '-title'   => 'Warning!',
                                          '-message' => "! File $opt_dbc_file_1 has aleady been selected for Mapping file generation!!!\n Please choose different file! ",
                                         );
                           $opt_dbc_file_1 = undef;
                        }
                    },
      )
    -> pack ("-side"   => 'right',"-ipadx" => 5,"-ipady" => 2,"-pady" => 5,"-padx" => 5);
    
    ##------------------------------------------------------------------
    ## create Frame for choosing CAN bus number for 1st DBC file
    ##------------------------------------------------------------------
    $F1_1_CanBusNbr = $F1_dbc_bus_grp_1 -> Frame("-background" => "#888888")->pack(-pady=> 2 , -fill => 'x', );

    $F1_1_CanBusNbr -> Label (
       "-text" => "CAN Bus number : ",-background => "#888888", -foreground => 'white',-font=>'{Segoe UI Semibold} 10 bold',-width=>'26', 
       ) -> pack ("-side"   => 'left');

     #create menubutton 'CAN bus number dropdown' in frame $F1_1_CanBusNbr
     $verbose_menu = $F1_1_CanBusNbr -> Menubutton
       (
       "-textvariable" => \$selected_CAN_bus_number,
       "-relief"       => 'groove',
       "-borderwidth"  => 2,
       "-tearoff"      => 0,
       "-width"        => 3,
       -background => "grey",
       );

     #create entries in menu
     foreach $temp (1..32)
     {
       $verbose_menu -> command
         (
         "-label"   => $temp,
         "-command" => sub { $selected_CAN_bus_number = $temp; $verbose = $selected_CAN_bus_number; }
         );
     }

     $verbose_menu -> pack ( "-side" => 'left', );

    #Frame for keeping 2nd dbc file and CAN bus number
    my $F1_dbc_bus_grp_2 = $F1 -> Frame("-background" => "#888888", -relief=>'solid', -borderwidth => 1)
    -> pack
      (
      "-side"   => 'top',
      "-expand" => 1,
      "-fill"   => 'both',
      "-pady"   => 5,
      "-padx"   => 5,
      );
    #check box to enable/dosable second dbc file selection
    $F1_CB = $F1_dbc_bus_grp_2->Frame("-background" => "#888888")->pack(-pady=> 2 ,"-fill"   => 'x',  );    
    
    $F1_CB->Checkbutton(-text => '(optional) 2nd DBC input file',-variable => \$Cb_Selected, -command  => \&check_state,-font=>'{Segoe UI Semibold} 10 bold ', -indicatoron => 'true', -selectcolor => 'black', -activeforeground => "white",-foreground  => "white", -activebackground => "#888888",-background => "#888888", -width=>'23',)->pack("-side"  => 'left');
  
    $entry = $F1_CB->Entry( "-textvariable" => \$opt_dbc_file_2, "-state" => 'disabled', -background => "grey", -disabledbackground => "grey60",  )->pack( "-side" => 'left', "-fill" => 'x', "-expand" => 1, "-padx" => 5, );

    # create 'browse file' button
    $button = $F1_CB->Button(
        "-text"    => "Browse...",
        "-state"   => "disabled",
        -relief => 'groove',
        -background => "#333366",
        -foreground  => "white",
        -font=>'{Segoe UI Semibold} 10 ',
        "-command" => sub {
            my $temp = $opt_dbc_file_2;    # store old value
            $opt_dbc_file_2 = $main->getOpenFile(
                "-filetypes" => [ [ "DBC files", '.dbc' ], [ "All files", '.*' ] ],
                "-title" => "DBC file which have to be scanned",
                "-initialdir" => '.',
            );
            unless ($opt_dbc_file_2) { $opt_dbc_file_2 = $temp; }    # if no new value, restore old one
            
            if ( defined $opt_dbc_file_1 &&  $opt_dbc_file_2 eq $opt_dbc_file_1 ){
                #Promt the user about the duplicate message names
                             $main->messageBox (
                              '-icon'    => "error",
                              '-type'    => "OK",
                              '-title'   => 'Warning!',
                              '-message' => "! File $opt_dbc_file_2 has aleady been selected for Mapping file generation!!!\n Please choose different file! ",
                             );
               $opt_dbc_file_2 = undef;
            } 
        },
    )->pack( "-side" => 'right', "-ipadx" => 5, "-ipady" => 2, "-pady" => 5,"-padx" => 5 );
    
    ##------------------------------------------------------------------
    ## create Frame for choosing CAN bus number for 2nd DBC file
    ##------------------------------------------------------------------
    $F1_1_CBN = $F1_dbc_bus_grp_2 -> Frame("-background" => "#888888")->pack(-pady=> 2,"-fill"   => 'x',  );

    $F1_1_CBN -> Label ( -text => "CAN Bus number : ", -background => "#888888", -foreground => 'white',,-font=>'{Segoe UI Semibold} 10 bold',-width=>'26', ) -> pack ("-side"   => 'left');
       
    #create menubutton 'CAN bus number dropdown' in frame $F1_1_CanBusNbr
    $can_bus_nr_menu = $F1_1_CBN -> Menubutton
       (
       "-textvariable" => \$selected_CAN_bus_number_2,
       "-relief"       => 'groove',
       "-borderwidth"  => 2,
       "-tearoff"      => 0,
       "-width"        => 3,
       -background => "grey",
       "-state"   => "disabled",
       );

     #create entries in menu
     foreach $temp (1..32)
     {
       $can_bus_nr_menu -> command
         (
         "-label"   => $temp,
         "-command" => sub { $selected_CAN_bus_number_2 = $temp; $verbose = $selected_CAN_bus_number_2; }
         );
     }

     $can_bus_nr_menu -> pack ( "-side" => 'left', );


    ##------------------------------------------------------------------
    ## create Frame for choosing output file CAN mapping with label, entry and button
    ##------------------------------------------------------------------
    $F1_4 = $F1 -> Frame("-background" => "#888888")->pack(-pady=> 5,"-fill"   => 'x',"-pady"   => 5,"-padx"   => 5,  );

    $F1_4 -> Label ( "-text" => "CAN mapping output file (*.pm):     ", -background => "#888888", -foreground => 'white',-font=>'{Segoe UI Semibold} 10 bold',-width=>'26',  ) -> pack ("-side"   => 'left');

    $F1_4 -> Entry (  "-textvariable" => \$opt_output_file, -background => "grey", )
            -> pack ( "-side"   => 'left', "-fill"   => 'x', "-expand" => 1,"-padx" => 5, );

#    create 'browse file' button
    $F1_4 -> Button
      (
      "-text" => "Browse...",
      -relief => 'groove',
      -background => "#333366",
      -foreground  => "white",
      -font=>'{Segoe UI Semibold} 10 ',
      "-command" => sub{
                        my $temp = $opt_output_file;    #   store old value
                        $opt_output_file = $main -> getSaveFile (
                            "-filetypes"  => [ ["Perl modules", '.pm'] , ["All files", '.*'] ],
                            "-title"      => "CAN mapping output file (normally in ProjectDefaults Folder)" ,
                            "-initialdir" => '.',
                            "-initialfile" => $output_CAN_mapping,
                        );
                        unless ($opt_output_file) {$opt_output_file = $temp;}  # if no new value, restore old one
                    },
      )
   -> pack ("-side"   => 'right',"-ipadx" => 5,"-ipady" => 2,"-pady" => 5,"-padx" => 5);

    ##------------------------------------------------------------------
    ## create Frame for choosing type of CAN_engine
    ##------------------------------------------------------------------
#    $F1_1_CanEngine = $F1 -> Frame
#    -> pack
#      (
#      "-side"   => 'bottom',
#      "-fill"   => 'x',
#      );

#    $F1_1_CanEngine -> Label (
#       "-text" => "LabCar CAN engine (e.g. CAN_PRIVATE, default is CAN_engine ) : ",
#       ) -> pack ("-side"   => 'left');

#    $F1_1_CanEngine -> Entry (  "-textvariable" => \$selected_CAN_engine , )
#         -> pack ( "-side"   => 'left', "-fill"   => 'x', "-expand" => 1, );

    ##------------------------------------------------------------------
    ## create Frame for choosing definition of CAN Node under Test with label, entry and button
    ##------------------------------------------------------------------
    $F1_1ESP = $F1 -> Frame("-background" => "#888888")->pack(-pady=> 5,"-fill"   => 'x', "-pady"   => 5,"-padx"   => 5, );

    $F1_1ESP -> Label (
       "-text" => "CAN node under test \n( default = Airbag ) :     ", -background => "#888888", -foreground => 'white',-font=>'{Segoe UI Semibold} 10 bold',-width=>'26', -wraplength =>  350 
       ) -> pack ("-side"   => 'left');

    $F1_1ESP -> Entry (  "-textvariable" => \$opt_sut_node, -background => "grey", )
         -> pack ( "-side"   => 'left', "-fill"   => 'x', "-expand" => 1, "-padx" => 5,);

    ##------------------------------------------------------------------
    ## create Frame for choosing CAN msg list with label, entry and button
    ##------------------------------------------------------------------
    $F1_2 = $F1 -> Frame("-background" => "#888888")->pack(-pady=> 5,"-fill"   => 'x', "-pady"   => 5,"-padx"   => 5, );

    $F1_2 -> Label ( "-text" => "CAN message list (optional): ", -background => "#888888", -foreground => 'white',-font=>'{Segoe UI Semibold} 10 bold', -width=>'26',  ) -> pack ("-side"   => 'left');

    $F1_2 -> Entry (  "-textvariable" => \$opt_msg_list, -background => "grey", )
            -> pack ( "-side"   => 'left', "-fill"   => 'x', "-expand" => 1, "-padx" => 5,);

    # create 'browse file' button
    $F1_2 -> Button
      (
      "-text" => "Browse...",
      -relief => 'groove',
      -background => "#333366",
      -foreground  => "white",
      -font=>'{Segoe UI Semibold} 10 ',
      "-command" => sub{
                        my $temp = $opt_msg_list;       # store old value
                        $opt_msg_list = $main -> getOpenFile (
                            "-filetypes"  => [ ["All files", '.*'], ["Perl modules", '.pm'] ],
                            "-title"      => "CAN messages list (temp file with list of CAN IDs or message names)" ,
                            "-initialdir" => '.',
                        );
                        unless ($opt_msg_list) {$opt_msg_list = $temp;} # if no new value, restore old one
                    },
      )
    -> pack ("-side"   => 'right',"-ipadx" => 5,"-ipady" => 2,"-pady" => 5,"-padx" => 5);


    ##------------------------------------------------------------------
    ## create Frame for choosing verbose level with label and menubutton
    ##------------------------------------------------------------------
     $F1_3 = $F1 -> Frame("-background" => "#888888")->pack(-pady=> '5',"-fill"   => 'x',"-pady"   => 5,"-padx"   => 5,  );

     $F1_3 -> Label ( "-text" => "logging level: ", -background => "#888888", -foreground => 'white',-font=>'{Segoe UI Semibold} 10 bold',-width=>'26' ) -> pack ("-side"   => 'left');

     #create menubutton 'verbose menu' in frame $F1
     $verbose_menu = $F1_3 -> Menubutton
       (
       "-textvariable" => \$opt_verbose,
       "-relief"       => 'groove',
       "-borderwidth"  => 2,
       "-tearoff"      => 0,
       "-width"        => 3,
       -background => "grey",
       );

     #create entries in menu
     foreach $temp (0..$opt_verbose)
     {
       $verbose_menu -> command
         (
         "-label"   => $temp,
         "-command" => sub { $opt_verbose = $temp; $verbose = $opt_verbose; }
         );
     }

     $verbose_menu -> pack ( "-side" => 'left', );
     
     ##------------------------------------------------------------------
    ## create Frame for choosing Type of Variable(Environment/System)
    ##------------------------------------------------------------------
     $F1_VarType = $F1 -> Frame("-background" => "#888888")->pack(-pady=>'10',"-fill"   => 'x',"-pady"   => 5,"-padx"   => 5,  );

     $F1_VarType -> Label ( "-text" => "Type of Variable\n(0 - System/1 - Environment): ", -background => "#888888", -foreground => 'white',-font=>'{Segoe UI Semibold} 10 bold', -width=>'26', -wraplength =>  350 ) -> pack ("-side"   => 'left');

     #create menubutton 'verbose menu' in frame $F1
     $varType_menu = $F1_VarType -> Menubutton
       (
       "-textvariable" => \$opt_varType,
       "-relief"       => 'groove',
       "-borderwidth"  => 2,
       "-tearoff"      => 0,
       "-width"        => 3,
       -background => "grey",
       );

     #create entries in menu
     foreach $temp (0..$opt_varType)
     {
       $varType_menu -> command
         (
         "-label"   => $temp,
         "-command" => sub { $opt_varType = $temp; $verbose = $opt_varType; }
         );
     }

     $varType_menu -> pack ( "-side" => 'left', );
     
     #Note to select the Type Of Variable(System/Environment)
     $F1 -> Label( "-text" => 'Note :By default Environment variable will be created in CAN mapping file ,So to change the type of variable(System/Environment) please select appro option in "Type Of Variable"',-background => "#888888", -foreground => "#333366",-font=>'{Segoe UI Semibold} 10 ',) -> pack ("-side"   => "bottom","-pady"   => 5,"-padx"   => 5,);

}

##------------------------------------------------------------------
## USAGE, HELP if invalid program call
##------------------------------------------------------------------
sub Usage {
my $help=<<"EOF";
------------------------------------------------------------------------------
PROGRAM: $0
 call program with options:

 EXAMPLE:
 perl $0

------------------------------------------------------------------------------
EOF

print $help;
exit(0);
}

