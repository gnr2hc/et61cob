use strict;
use warnings;
use Data::Dumper;
use LIFT_general;
use Sys::Hostname;
use File::Basename;

my $input_mapping = $ARGV[0]; #mapping file name old style as input.

my $actual_name = $input_mapping; #store name for internal processing

require "$input_mapping";

my $trig_hash = {};
my $pre_trig_hash = {};
my $write_hash = {};

my $trig_cmd_nbr;
my $pre_trig_cmd_nbr;
my $write_cmd_nbr;
my $write_arr_size_check;
my $test = $LIFT_PROJECT::Defaults->{'MANITOO_TEMP'}{'TESTCASES'};

 foreach my $test_case ( keys %$test ) {
    my $sequence = $test->{ $test_case }{CMD_sequence};
    foreach my $cmd_nbr ( sort { $a <=> $b } keys %$sequence) {
        my $cmd_code_string = $sequence->{$cmd_nbr}{cmd};

         $cmd_code_string =~ s/-/ /g;    # replace "01 - 02" -> "01 02"

        my @cmd_code_bytes = split( /\s+/ , $cmd_code_string);

        my $service_id = shift @cmd_code_bytes; #split the command for service ID

        #service SPI selection and chip select mask
        if ( $service_id == 31 ) {

            #SPI manipulation module as argument
            my $spi_manipulation_module_hex = shift (@cmd_code_bytes);

            my $spi_manipulation_module_int = hex ($spi_manipulation_module_hex);
            $trig_hash = {};
            $trig_hash->{'trigger_cfg'}{'spi_manipulation_module'} = $spi_manipulation_module_int;

            #don't care byte
            my $dont_care = shift (@cmd_code_bytes);

            # higher nibble represents the SPI selection 00 -> '0'0
            my @spi_selection_arr = split ('', shift (@cmd_code_bytes));

            #SPI selection as argument
            my $spi_selection_int = int ($spi_selection_arr[0]);
            $trig_hash->{'trigger_cfg'}{'spi_selection'} = $spi_selection_int;


           #convert the values from hexadecimal to integer
            my $cs_selection_hex = $spi_selection_arr[1].shift (@cmd_code_bytes).shift (@cmd_code_bytes);
            my $cs_selection_bin = unpack('B20', pack('H5', $cs_selection_hex));

            my @cs_count = $cs_selection_bin =~ /1/g; #to check if more than one chip select selected

            my $cs_selection_int;
            $cs_selection_int = "@-"  if ($cs_selection_bin =~ /1/g);
            $cs_selection_int    = 20 - $cs_selection_int;

            $trig_hash->{'trigger_cfg'}{'chip_select'} = $cs_selection_int;

            $trig_cmd_nbr = $cmd_nbr;
        }

        #service Frame Mask
        elsif ($service_id == 32) {

            #SPI manipulation module as argument
            my $spi_manipulation_module_hex = shift (@cmd_code_bytes);
            my $spi_manipulation_module_int = hex($spi_manipulation_module_hex);

            #pass frame mask as a hexadecimal argument to manitoo basic function MANITOO_cmd_trigger_FrameMask
            my $frame_mask_hex = shift (@cmd_code_bytes).shift (@cmd_code_bytes).shift (@cmd_code_bytes).shift (@cmd_code_bytes);
            $trig_hash->{'trigger_cfg'}{'frame_mask'} = $frame_mask_hex;
            delete $sequence->{$cmd_nbr};
        }

        #service Frame Pattern
        elsif ($service_id == 33) {

            #SPI manipulation module as argument
            my $spi_manipulation_module_hex = shift (@cmd_code_bytes);
            my $spi_manipulation_module_int = hex($spi_manipulation_module_hex);


            #pass frame pattern as a hexadecimal argument to ManiToo basic function MANITOO_cmd_trigger_FramePattern
            my $frame_pattern_hex = shift (@cmd_code_bytes).shift (@cmd_code_bytes).shift (@cmd_code_bytes).shift (@cmd_code_bytes);
            $trig_hash->{'trigger_cfg'}{'frame_pattern'} = $frame_pattern_hex;
            $sequence->{ $trig_cmd_nbr } = $trig_hash;
            delete $sequence->{$cmd_nbr};
        }

        #service mode and time
        elsif ($service_id == 41) {

            #function name for service service mode and time
            my $function_name = 'MANITOO_cmd_write_DataCtrl_ModeTime';

            $write_hash = {};

            #SPI manipulation module as argument - nn
            my $spi_manipulation_module_hex = shift ( @cmd_code_bytes );
            my $spi_manipulation_module_int = hex ( $spi_manipulation_module_hex );

            #number of manipulation data sets that has to be sent - mm
            my $no_of_manipu_data_sets_hex =  shift ( @cmd_code_bytes );
            my $no_of_manipu_data_sets_int = hex ( $no_of_manipu_data_sets_hex );

            my $mode_waiting_time_aref = [];
            my $waiting_time_hex;
            my $SPI_flag = 0;
            my $TIM_flag = 0;

            foreach my $waiting_time (@cmd_code_bytes) { $waiting_time_hex .= $waiting_time; }

            push ( @{ $mode_waiting_time_aref }, split (/(.{8})/, $waiting_time_hex ) );

            @{ $mode_waiting_time_aref } = grep { $_ ne '' } @{ $mode_waiting_time_aref };

            $write_arr_size_check =  @{ $mode_waiting_time_aref } if ( $$mode_waiting_time_aref[-1] eq '00000000' );
            
            if ( $$mode_waiting_time_aref[-1] eq '00000000' ) {
                delete $$mode_waiting_time_aref[-1];
            }
            
            foreach my $mode_time ( @{ $mode_waiting_time_aref } ) {
                my $mode = hex substr ( $mode_time, 0, 1 );

                if ( $mode == 1 ) {
                    $SPI_flag = 1;
                }

                if ( $mode == 4 ) {
                    $TIM_flag = 1;
                }

            }
            my ($mode, $time_or_frames);
            my $manipu_mode = {
                                 1 => 'SPI',
                                 2 => 'RTI',
                                 4 => 'TIM',
                              };
            $write_hash->{ 'write_cfg' }{'spi_manipulation_module'} = $spi_manipulation_module_int;
            my @frames;
            my @time_us;
            my $arr_flag = 0;

            if ( scalar @{ $mode_waiting_time_aref } == 1 ) {

                $mode = hex substr ( $$mode_waiting_time_aref[0], 0, 1 );  #convert manipulation mode to integer
                $time_or_frames = hex substr ( $$mode_waiting_time_aref[0], 1 );

                $write_hash->{ 'write_cfg' }{'frames'} =
                    $time_or_frames if ( $$manipu_mode { $mode } eq 'SPI' );

                $write_hash->{ 'write_cfg' }{'time_us'} =
                    $time_or_frames if ( $$manipu_mode { $mode } eq 'TIM' );
            }
            else {
                foreach my $mode_time ( @{ $mode_waiting_time_aref } ) {

                     $mode = hex substr ( $mode_time, 0, 1 );  #convert manipulation mode to integer

                     if ( defined $$manipu_mode { $mode } ) {

                        $arr_flag = 1;
                        $time_or_frames = hex substr ( $mode_time, 1 );
                        if ( $SPI_flag == 1 and $TIM_flag == 1 ) {
                                if ( $$manipu_mode { $mode } eq 'SPI' ) {
                                    push ( @frames, $time_or_frames );
                                    push ( @time_us, 'FRAMES' );
                                }
                                if ( $$manipu_mode { $mode } eq 'TIM' ) {
                                    push ( @time_us, $time_or_frames );
                                    push ( @frames, 'TIME_US' );
                                }
                         }
                         else {
                            
                            push ( @frames, $time_or_frames )   if ( $$manipu_mode { $mode } eq 'SPI' );
                            push ( @time_us, $time_or_frames )   if ( $$manipu_mode { $mode } eq 'TIM' );

                         }
                     }
                }
            }
            if ( $arr_flag == 1 ) {

                if ( defined @frames ) {
                    $write_hash->{ 'write_cfg' }{'frames'} = \@frames;
                }
                if ( defined @time_us ) {
                    $write_hash->{ 'write_cfg' }{'time_us'} = \@time_us;
                }
            }
           $write_cmd_nbr = $cmd_nbr;
        }

        #service control
        elsif ($service_id == 42) {

            #function name for service data
            my $function_name = 'MANITOO_cmd_write_DataCtrl_1';

            #SPI manipulation module as argument - nn
            my $spi_manipulation_module_hex = shift ( @cmd_code_bytes );
            my $spi_manipulation_module_int = hex ( $spi_manipulation_module_hex );

            #number of manipulation data sets that has to be sent - mm
            my $no_of_manipu_data_sets_hex =  shift ( @cmd_code_bytes );
            my $no_of_manipu_data_sets_int = hex ( $no_of_manipu_data_sets_hex );

            my $manipulation_ctrl_selection;

            foreach my $ele(@cmd_code_bytes)
            {
              $manipulation_ctrl_selection .= $ele;
            }
            my $manipulation_ctrl_selection_aref = [];

            push ( @{ $manipulation_ctrl_selection_aref }, split ( /(.{8})/, $manipulation_ctrl_selection ) );

            @{ $manipulation_ctrl_selection_aref } = grep { $_ ne '' } @{ $manipulation_ctrl_selection_aref };

            if ( @{ $manipulation_ctrl_selection_aref }  > 1 ) {

                if ( $$manipulation_ctrl_selection_aref[-1] eq '00000000' and
                    ( scalar @{ $manipulation_ctrl_selection_aref } == $write_arr_size_check ) ) {
                    delete $$manipulation_ctrl_selection_aref[-1];
                }
                $write_hash->{ 'write_cfg' }{'data_control_1'} = \@{ $manipulation_ctrl_selection_aref };
            }
            $write_hash->{ 'write_cfg' }{'data_control_1'} = $$manipulation_ctrl_selection_aref[0]
                if ( @{ $manipulation_ctrl_selection_aref }  == 1 );
            delete $sequence->{$cmd_nbr};
        }
        #service data
        elsif ($service_id == 43) {

            #function name for service data
            my $function_name = 'MANITOO_cmd_write_DataCtrl_2';

            #SPI manipulation module as argument - nn
            my $spi_manipulation_module_hex = shift ( @cmd_code_bytes );
            my $spi_manipulation_module_int = hex ( $spi_manipulation_module_hex );

            #number of manipulation data sets that has to be sent - mm
            my $no_of_manipu_data_sets_hex =  shift ( @cmd_code_bytes );
            my $no_of_manipu_data_sets_int = hex ( $no_of_manipu_data_sets_hex );

            my $manipulation_data_selection;
            foreach my $ele( @cmd_code_bytes )
            {
              $manipulation_data_selection .= $ele;
            }
            my $manipulation_data_selection_aref = [];

            push ( @{ $manipulation_data_selection_aref }, split ( /(.{8})/, $manipulation_data_selection ) );

            @{ $manipulation_data_selection_aref } = grep { $_ ne '' } @{ $manipulation_data_selection_aref };

            if ( @{ $manipulation_data_selection_aref }  > 1 ) {

               if ( $$manipulation_data_selection_aref[-1] eq '00000000' and
                    ( scalar @{ $manipulation_data_selection_aref } == $write_arr_size_check ) ) {
                    delete $$manipulation_data_selection_aref[-1];
                }
                $write_hash->{ 'write_cfg' }{'data_control_2'} = \@{ $manipulation_data_selection_aref };
            }

            $write_hash->{ 'write_cfg' }{'data_control_2'} = $$manipulation_data_selection_aref[0]
                if ( @{ $manipulation_data_selection_aref }  == 1 );

            $sequence->{ $write_cmd_nbr } = $write_hash;
            delete $sequence->{$cmd_nbr};
            $write_arr_size_check = 0;
        }

        #service for Pre Trigger SPI selection and CS mask
        elsif ($service_id == 61) {

            #Pre Trigger module nn --> 00 � 03
            my $pre_trigger_module_hex = shift (@cmd_code_bytes);

            #convert the hex number to integer
            my $pre_trigger_module_int = hex ($pre_trigger_module_hex);

            $pre_trig_hash = {};

            #don't care two nibbles
            my $dont_care = shift (@cmd_code_bytes);

            #1 nibble for SPI selection
            my @split_nibble = split ('', shift (@cmd_code_bytes));
            my $spi_selection_int = int ($split_nibble[0]);

            #converting CS from hexadecimal to decimal
            my $cs_selection_hex = $split_nibble[1].shift (@cmd_code_bytes).shift (@cmd_code_bytes);
            my $cs_selection_bin = unpack('B20', pack('H5', $cs_selection_hex)); #converting to 20 bit binary value

            my @cs_count = $cs_selection_bin =~ /1/g; #to check if more than one chip select selected

            my $cs_selection_int;
            $cs_selection_int = "@-"  if ($cs_selection_bin =~ /1/g); #position of the bit set to 1 in binary string
            $cs_selection_int    = 20 - $cs_selection_int; #decimal value of CS

            $pre_trig_hash->{'pretrigger_cfg'}{'nbr'} = $pre_trigger_module_int;
            $pre_trig_hash->{'pretrigger_cfg'}{'spi_selection'} = $spi_selection_int;
            $pre_trig_hash->{'pretrigger_cfg'}{'chip_select'} = $cs_selection_int;

            $pre_trig_cmd_nbr = $cmd_nbr;
        }

        #service for Pre Trigger Frame Mask
        elsif ($service_id == 62) {

            #function name for service Pre Trigger Frame Mask
            my $function_name = 'MANITOO_cmd_PT_FrameMask';


            #Pre Trigger module nn --> 00 � 03
            my $pre_trigger_module_hex = shift (@cmd_code_bytes);

            my $pre_trigger_module_int = hex ($pre_trigger_module_hex); #convert to integer value to pass as a argument to basic ManiToo function


            my $frame_mask_hex = shift (@cmd_code_bytes).shift (@cmd_code_bytes).shift (@cmd_code_bytes).shift (@cmd_code_bytes);

            $pre_trig_hash->{'pretrigger_cfg'}{'frame_mask'} = $frame_mask_hex;

            delete $sequence->{$cmd_nbr};
        }

        #service for Pre Trigger Frame pattern
        elsif($service_id == 63) {


            #Pre Trigger module nn --> 00 � 03
            my $pre_trigger_module_hex = shift (@cmd_code_bytes);

            #convert to integer value to pass as a argument to basic ManiToo function
            my $pre_trigger_module_int = hex ($pre_trigger_module_hex);

            my $frame_pattern_hex = shift (@cmd_code_bytes).shift (@cmd_code_bytes).shift (@cmd_code_bytes).shift (@cmd_code_bytes);

            $pre_trig_hash->{'pretrigger_cfg'}{'frame_pattern'} = $frame_pattern_hex;

            delete $sequence->{$cmd_nbr};

        }

        #service for Pre Trigger Time
        elsif($service_id == 64) {

            #Pre Trigger module nn --> 00 � 03
            my $pre_trigger_module_hex = shift (@cmd_code_bytes);

            #convert the hex number to integer
            my $pre_trigger_module_int = hex ($pre_trigger_module_hex);

            my $waiting_time_for_PT_timer_hex;

            foreach my $hexbyte (@cmd_code_bytes) {
                $waiting_time_for_PT_timer_hex .= $hexbyte;
            }

            #convert the hex number to integer
            my $waiting_time_for_PT_timer_us = hex ($waiting_time_for_PT_timer_hex);

            $pre_trig_hash->{'pretrigger_cfg'}{'trigger_active_time_us'} = $waiting_time_for_PT_timer_us;
            $sequence->{ $write_cmd_nbr } = $pre_trig_hash;

            delete $sequence->{$cmd_nbr};
        }

        #service for Pre Trigger Status Mask
        elsif($service_id == 65) {

            #function name for service Pre Trigger Status Mask
            my $function_name = 'MANITOO_cmd_PT_StatusMask';

            #SPI selection
            my $spi_selection_hex = shift (@cmd_code_bytes);

            my $spi_selection_int = hex ($spi_selection_hex); #convert to integer value to pass as a argument to basic manitoo function

            my @pt_last_two_nibbles = split ('', pop @cmd_code_bytes);

            #last nibble for selection of status mask
            my $pre_trigger_module_int =  $pt_last_two_nibbles[1] ;

               $pre_trigger_module_int = unpack( 'B4', pack( 'H*' , $pre_trigger_module_int ) );

            my @hex_arr = split( //, $pre_trigger_module_int );

            my $pre_trigger_module = 3; #max pre-trigger module supported (4) count starting with 0
            my @pretrigger;

            foreach my $ele ( @hex_arr ) {
                push ( @pretrigger, $pre_trigger_module) if ( $ele == 1 );
                $pre_trigger_module--;
            }
            my $pre_trig_aref = \@pretrigger;

            $trig_hash->{'trigger_cfg'}{'pre_trigger'} = $pre_trig_aref;
            $sequence->{ $trig_cmd_nbr } = $trig_hash;

            delete $sequence->{$cmd_nbr};
        }

        #service for SMI7 SPI Mask and SMI7 CS Mask
        elsif($service_id == 71) {

            #function name for service SMI7 SPI Mask and SMI7 CS Mask
            my $function_name = 'MANITOO_cmd_SMI7_SPI_CS';

            #don't care two nibbles
            my $dont_care = shift (@cmd_code_bytes);

            #smi7 SPI selection
            my @smi7_spi_selection = split ('', shift @cmd_code_bytes);

            #first nibble for selection of status mask
            my $spi_selection_int = int ($smi7_spi_selection[0]);

            #convert the values from hexadecimal to integer
            my $cs_selection_hex = $smi7_spi_selection[1].shift (@cmd_code_bytes).shift (@cmd_code_bytes);
            my $cs_selection_bin = unpack('B20', pack('H5', $cs_selection_hex));

            my @cs_count = $cs_selection_bin =~ /1/g; #to check if more than one chip select selected

            my $cs_selection_int;

            $cs_selection_int = "@-"  if ($cs_selection_bin =~ /1/g);
            $cs_selection_int    = 20 - $cs_selection_int;
        }

        #service for SMI7 Page Mask
        elsif($service_id == 72) {

            #SPI manipulation module
            my $spi_manipulation_module_hex = shift (@cmd_code_bytes);
            my $spi_manipulation_module_int = hex($spi_manipulation_module_hex);

            my @module_collect;
            my $module_count = 3; #max number of modules(4) starting with 0

            #collect the module and page number for SMI7
            foreach my $smi7_module (@cmd_code_bytes) {
               ($smi7_module =~/00/)? $module_count-- : push(@module_collect, $smi7_module.'#'.$module_count--);
            }

            my ($smi7_page_number_hex, $smi7_module_number_int) = split('#', $module_collect[0]);

            #converting to 8 bit binary value
            #
            #   See : http://perldoc.perl.org/perlpacktut.html #The Basic Principle,
            #
            my $smi7_page_number_bin = unpack(
                                                'B8',            # 8 bit bin value
                                                pack(
                                                        'H2',    # 1 byte hex value
                                                        $smi7_page_number_hex
                                                    )
                                             );

            my @page_count = $smi7_page_number_bin =~ /1/g; # collect number of pages selected

            my $smi7_page_number_int;
            #collect position of the bit set to 1 in binary string
            $smi7_page_number_int = "@-"  if ($smi7_page_number_bin =~ /1/g);  # Pre-defined Perl variable "@-" stores the position of the match (count starts from left)

            $smi7_page_number_int = (8 - $smi7_page_number_int) - 1; #integer value of Page number with range 0 - 7

            $trig_hash->{'trigger_cfg'}{'smi7_module'} = int $smi7_module_number_int;
            $trig_hash->{'trigger_cfg'}{'smi7_page'} = $smi7_page_number_int;
            $sequence->{ $trig_cmd_nbr } = $trig_hash;

            delete $sequence->{$cmd_nbr};

        }
    }
 }
open (FILE1, "<$input_mapping");

$input_mapping =~s/.pm/_buffer.pm/;

open (FILE, ">$input_mapping");
my $flag = 0;
my $univ_flag = 0;
my $count;
my $c_flag = 0;
my $match_flag = 0;
while ( <FILE1> ) {
    
    if ( $univ_flag == 0 ) {
        if ($flag == 0) {
    
            print FILE $_;
        }
        if ( $_ =~/'TESTCASES'/) {
            $flag = 1;
            $count = 1;
            $c_flag = 1;
            
            next;
        }
        if ( $c_flag == 1 ) {
            if ( $_ =~ /\.*{(\s*#.*)?$/ ) {
            $count++ ;
            }
            if ( $_ =~ /^\s*\}[\,,;]$/ ) {
                $count-- ;
                if ( $count == 0 ) {
                    $match_flag = 1;
                }
            }
        }
        if ( $count == 0 and $match_flag == 1 ) {
            $univ_flag = 1;
        }
    }

    if ( $univ_flag ) {
        print FILE $_;
    }
}
close FILE;
my $temp_flag = 0;
my $rm_flag = 0;



open (FILE1, "<$input_mapping");

$input_mapping =~s/_buffer.pm/_new.pm/;

open (FILE, ">$input_mapping");

while ( <FILE1> ) {

    if ( $_ =~/\$Defaults->{'MANITOO_TEMP'}{'TESTCASES'}/ ) {
        
        $rm_flag = 1;
        next;
    }
    if ( $rm_flag == 1 and $_ =~/^}[\,,;]$/ ) {
        
        $_ = Dumper $test;
        $_=~s/\$var1 = //i;
        print FILE "\$Defaults->{'MANITOO_TEMP'}{'TESTCASES'} = ".$_;
        $temp_flag = 1;
        $rm_flag = 0;
    }
    if ( $temp_flag == 0 ) {
        print FILE $_;
    }
    
    $temp_flag = 0;
    
}
close FILE;
close FILE1;
$actual_name =~s/.pm/_buffer.pm/;
unlink $actual_name;
# print FILE Dumper( $test );
