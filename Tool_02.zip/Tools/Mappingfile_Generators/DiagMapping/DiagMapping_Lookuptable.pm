#### This file is required as input to the Diag mapping generator tool. Project adaptation required. #### 

package DIAG_LOOKUPTABLE; 

$TABLE = {

	'Service_Supported_NRCs' => {	
		'Service_10'	=> ['12','13','21','22','78','7E','7F','88','92','93'],
		'Service_11'	=> ['12','13','21','22','31','33','78','7E','7F','88','92','93'],
		'Service_14'	=> ['11','13','21','22','31','72','78','7F','88','92','93'],
		'Service_19'	=> ['11','12','13','21', '22','31','78','7E','7F','88','92','93'],
		'Service_22'	=> ['13','14','21','22','31','33','78','7F','88','92','93'],
		'Service_23'	=> ['11','13','21','31','78','7F','88','92','93'],
		'Service_27'	=> ['12','13','21','22','24','31','35','36','37','78','7E','7F','88','92','93'],
		'Service_28'	=> ['11','12','13','21','22','31','78','7E','7F','88','92','93'],
		'Service_2E'	=> ['13','21','22','31','33','72','78','7F','88','92','93'],
		'Service_2F'	=> ['11','12','13','21','22','31','33','78','7F','88','92','93'],
		'Service_31'	=> ['12','13','21','22','24','31','33','72','78','7E','7F','88','92','93'],
		'Service_34'	=> ['11','12','13','21','22','78','7F','88','92','93'],
		'Service_36'	=> ['11','12','13','21','22','78','7F','88','92','93'],
		'Service_37'	=> ['11','12','13','21','22','78','7F','88','92','93'],
		'Service_3E'	=> ['12','13'],
		'Service_85'	=> ['11','12','13','21','22','31','78','7E','7F','88','92','93'],
		'Service_86'	=> ['11','12','13','21','22','24','31','78','7F','88','92','93'],
	},
	
	'NRC_Supported_AddressingModes' => {
		'NRC_10'		=> ['physical', 'functional'],
		'NRC_11'		=> ['physical'],
		'NRC_12'		=> ['physical'],
		'NRC_13'		=> ['physical', 'functional'],
		'NRC_14'		=> ['physical', 'functional'],
		'NRC_21'		=> ['physical', 'functional'],
		'NRC_22'		=> ['physical', 'functional'],
		'NRC_24'		=> ['physical', 'functional'],
		'NRC_31'		=> ['physical', 'functional'], #configurable in project
		'NRC_33'		=> ['physical', 'functional'],
		'NRC_35'		=> ['physical', 'functional'],
		'NRC_36'		=> ['physical', 'functional'],
		'NRC_37'		=> ['physical', 'functional'],
		'NRC_72'		=> ['physical', 'functional'],
		'NRC_78'		=> ['physical', 'functional'],
		'NRC_7E'		=> ['physical', 'functional'], #configurable in project
		'NRC_7F'		=> ['physical', 'functional'], #configurable in project
		'NRC_88'		=> ['physical', 'functional'], 
		'NRC_92'		=> ['physical', 'functional'], 
		'NRC_93'		=> ['physical', 'functional'], 
	},


#For diagnostic requests which do not have all bytes defined in SPR_ConfigTable, the additional bytes need to be defined as confiurable parameters/labels in the request input string.
#Example request 'ReadDTCInformation_ReportDtcsByStatusMask': 
#	Request format in SPR					: 19 02
#	Complete request format in Mapping_DIAG	: 19 02 StatusMask
#In the below table, add all configurable parameters which should be appended to the request string from SPR

	'Request_Input_Parameters' => {
		'19 01'			=> 'StatusMask',
		'19 02'			=> 'StatusMask',
		'19 04'			=> 'DTC DTCSnapshotRecordNumber',
		'19 06'			=> 'DTC DTCExtendedDataRecordNumber',
		'2E' 			=> 'Data',
		'27 02' 		=> 'Key',
		'27 04' 		=> 'Key',
		'28' 			=> 'CommunicationType',
		#'2F' 			=> 'IOControlState', #only if not already included in the request
		'31 01' 		=> 'RoutineControlOption',
		'31 02' 		=> 'RoutineControlOption',
		# '86' 			=> 'EventWindow EventTypeRecord DTC',
	},

};
1;

