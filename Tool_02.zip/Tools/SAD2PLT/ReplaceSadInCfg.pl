#################################################################################
# this tool is under version management
my $VERSION = q$Revision: 1.2 $;
my $HEADER  = q$Header: SAD2PLT/ReplaceSadInCfg.pl 1.2 2016/09/07 15:38:18ICT Boehm Frank (DC/PAR) (BM7ZSI) develop  $;
#################################################################################
use strict;
use warnings;
use Getopt::Long;
use File::Spec;
use File::Basename;

my ($SAD_dir,$CFG_file);

GetOptions('sad_dir=s' =>\$SAD_dir, 'cfgr=s' =>\$CFG_file);

die "CLI: ReplaceSadInCfg.pl --sad_dir [folder] --cfg [file]" unless ($SAD_dir and $CFG_file);

my $CFG_temp = $CFG_file . "_tmp";

chdir($SAD_dir);

my @SAD_list = glob("*.sad");
die "ERROR: no SAD file found\n" if (@SAD_list < 1);
die "ERROR: too many SAD files found: @SAD_list \n" if (@SAD_list > 1);

my $SAD_file = $SAD_list[0];
$SAD_file = File::Spec->rel2abs( dirname($SAD_file) ).'\\'.$SAD_file;
print("This is the full SAD file: $SAD_file\n");

die "SAD file error: sad file = $SAD_file\n" unless ($SAD_file =~ m/\.sad$/);

# Replace SAD file name in CFG file.
print("open $CFG_file\n");
open(CFG, $CFG_file) or die("Could not open config file.");
open(CFG_TEMP, "> $CFG_temp") or die("Could not open temp file.");

while(my $line = <CFG>) {
	#$SAD_file = 'C:/TurboLift/AB12_CI/config/SW/AB1200_BD_087_BB000000_Cat2.sad';


	if ($line =~ m/^\s*\$SAD_file\s*=\s*/) {
		print("Replacing SAD file name with current SAD file.\n");
		$line = '$SAD_file = '."'$SAD_file';\n";
	}

	print CFG_TEMP $line;
}

close(CFG);
close(CFG_TEMP);

unlink($CFG_file);
rename($CFG_temp, $CFG_file);

=head1 usage

search for SAD file in folder and replace SAD file in LIFT CFG file.

there should be only one *.sad file in folder, otherwise the script will exit

 CLI: ReplaceSadInCfg.pl --sad_dir [folder] --cfg [file]
 
 e.g. ReplaceSadInCfg.pl --sad_dir=C:/TurboLift/AB12_CI/config/SW --cfg=C:/TurboLift/AB12_CI/config/AB12_CI_CFG.pm

=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=cut
