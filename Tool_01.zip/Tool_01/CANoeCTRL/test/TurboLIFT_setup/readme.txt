Input
- file containing crash codes (empty lines and comment lines starting with ; are allowed)
- number of iterations
- offlineTraceFilePath (path or NA for online test)

Output

1) parameter file for testcase start

   C:\TurboLIFT\MLB\TC_par\_MLB\PSP\PSP_start.par

   Offline-Format:
   [PSP_start.TF_INT_0055_PCR_Ausloesung_Vollstraff_OUT_I1]
   CrashCode_IN   = 'TF_INT_0055_PCR_Ausloesung_Vollstraff_IN;4'
   StateNumber    = '0'
   CrashToEvaluate  = 'OUT'
   OfflineBusTraceFile   = 'N:\Projekte\Audi_VW\AB10\AB10.44_MLB_Evo\65.System_Testing\CREIS\PSP\PreSense\05.SCI_PreS_AB1044_C02_C15_0010\02.From_CREIS\DCI_AB1044_C2_C15_PreSense_0010_No_3_CANoeCtrl\CANoeTrace_C1_S0_I1.asc'

   Online-Format: Line 'OfflineBusTraceFile' can be omitted
   [PSP_start.TF_INT_0055_PCR_Ausloesung_Vollstraff_IN_I1]
   CrashCode_IN   = 'TF_INT_0055_PCR_Ausloesung_Vollstraff_IN;5'
   StateNumber   = '0'
   CrashToEvaluate   = 'IN'
   
2) Test list

   C:\TurboLIFT\MLB\Testlists\PSP.txt

   Format
   PSP_start.TF_INT_0055_PCR_Ausloesung_Vollstraff_IN_I1


  Notes for TurboLIFT
  ===================

  Control online or offline selection (default: use offline [testrog finished test before evaluation], optional: online [TurboLIFT remote controls testprog])
  -----------------------------------------------------------------------------------------------------------------------------------------------------------
     1. PSP_start.par: Before automatic generation of this file, specify above parameter 'offlineTraceFilePath' as
            - valid path => offline trace files *.asc
            - NA => online test
     2. \TurboLIFT\MLB\config\MLB_ProjectConst.pm
        'PSP'   =>   {
                'EVALUATION_MODE'    => 'NoTestprog',  # 'NoTestprog' (or) 'UseTestprog'

  Control tstLog-Header Information
  ---------------------------------
     \TurboLIFT\MLB\config\CFG_MLB.pm contains header information for tstLog:
      # $LIFT_ProjectDescription = "Audi MLBevo 10.44 : C2 sample phase";
      # $SAD_file = 'c:\Program Files (x86)\Windiag\SAD\au1044_BB00000_c16_Cat2_20131107.sad';
      # $EEPROM_file = 'D:\MLBEVO\AU1044_BB00000_C16_Cat2_20131107\Initialised_EEPROM.hex';

  Running the test
  ----------------
     1. Copy generated files (PSP.txt and PSP_start.par) to
        - \TurboLIFT\MLB\Testlists\PSP.txt
        - \TurboLIFT\MLB\TC_par\_MLB\PSP\PSP_start.par
     2. Before running OFFLINE evaluation, switch on ECU, since PSP evaluation reads ECU identification
     3. Run: \TurboLIFT\MLB\start_PSP.bat

  Archiving test reports
  ----------------------
     How to archive test reports after test has finished
        a) Open testreports.html with Windows Explorer (C:\TurboLIFT\MLB\Reports.html)
        b) Use Archive Button, which creates a zip-file (name and place is fixed and will be below C:\TurboLIFT\MLB\reports)
        c) Delete inside same zip-file all unnecessary files ():
           - -snapshot- (all testcases, configuration files, all files in config-folder
           - IC and EC (start with two __)
           - 3 files (...eval.txt, ...log.txt, ...result.txt, but keep ...result.html)

     Note: With next checkpoint (~E11/2013) same files will be placed differently (inside the root folder at one single place)

