#!/usr/bin/perl -w

#################################################################################
# this tool is under version management
my $VERSION = q$Revision: 1.10 $;
my $HEADER  = q$Header: CANoeCTRL/KMatrixExtract.pl 1.10 2014/07/03 21:01:09ICT Weissflog Peter (CC-PS/EPS2) (WGP2SI) develop  $;
#################################################################################

=head1 usage

Create extract of K-Matrix for later usage in CANoeCtrl-setup

 KMatrixExtract.pl <file>.xls FR|CAN
 
 e.g. for FlexRay:
 KMatrixExtract.pl \\siz1130\aerse$\Projekte\Audi_VW\AB10\AB10.44_MLB_Evo\60.Software\I.Com\Flexray\newFibex_2013_02_01_IStufe5\MLBevo_FlexRay_KMatrix_V8_05_01F_20130206_BP Copy saved as xls.xls FR
 e.g. for CAN:
 KMatrixExtract.pl \\siz1130\aerse$\Projekte\Audi_VW\AB10\AB10.44_MLB_Evo\60.Software\I.Com\CAN\MLBevo_SCCAN_KMatrix_IS5_V8.05F_20130201_SE\MLBevo_SCCAN_KMatrix_V8.05F_20130201_JH.xls CAN
 
 Output will be:
 KMatrixExtract_CAN.txt or KMatrixExtract_FR.txt (depending on input flag "CAN" or "FR" as 2nd parameter)

 Notes:
 Will only work with K-Matrix saved as xls, not as xlsx!
 For convenience there exist two cmd-files for DRAGGING & DROPPING of <K-Matrix-CAN or FR>.xls over them: KMatrixExtract_CAN.cmd, KMatrixExtract_FR.cmd.


=head1 AUTHOR

Peter WeiE<szlig>flog, E<lt>Peter.Weissflog@de.bosch.comE<gt>

=cut

####################################################################### 
# 1. First tested with MLBevo K-Matrix.
# 2. Relevant head keys are distributed over two lines.
# 3. The hash key is not the left most (PDU/Botschaft), but a more inner key (Signal).
# The last two points require a special logic:
# a) column no. != index no. in headKeys for keys in 2nd line => offset compensation
# b) first full line of values has to be read and later saved to hash with "Signal" as key
########################################################################

use strict;
use warnings;

use Spreadsheet::ParseExcel;
use Spreadsheet::XLSX;

my @errorMessages;


# List of PDUs/messages (PM) with their properties
# PM	P1 P2	P3	P4	P5	P6	P7	P8	P9	P10
# pm1	0	0	2	2	0	0	0	4	1	1
# pm2	2	0	0	2	0	0	0	4	2	0
# pm3	0	4	0	0	0	0	0	4	0	0
# pm4	0	0	4	0	0	4	0	0	2	2
# pm5	0	0	2	0	4	0	1	0	1	0
#
# Examples:
# PM "pm3" => (P2=>4, P8=>4, P10=>0)
# PM "pm5" => (P3=>2, P5=>4, P7=>1, P10=>0)
#
# my %HoH = (
# 	pm3 => {
# 		P2	=> 4,
# 		P8	=> 4,
# 		P10	=> 0,
#         },
# 	pm5 => {
# 		P3	=> 2,
# 		P5	=> 4,
# 		P7	=> 1,
# 		P10	=> 0,
#         },
#  );

my %HoH; # Hash of hash for signal names and its properties
my $worksheetName = "";
my $outputFile = "";
my $colName_pduOrMsg = "";
my $colName_signal = "Signal";
my $colName_cycleNormal_ms = "Zykluszeit normal [ms]";
my $colName_cycleFast_ms = "Zykluszeit schnell [ms]";
my $colName_signalSendType = "Signalsendeart";
my $colName_numRepetitions_active = "Wiederholungen aktiv";
my $colName_initValRaw = "InitWert roh [dez]";
my $colName_wcBhvrKL15off = "Worst Case Verhalten bei KL15 Aus"; # last property, which is in line 2
my $colName_offset = "Offset";
my $colName_factor = "Skalierung";
my $colName_description = "Beschreibung"; # last relevant column

# zero-based index:
my $colIndex_signal;
my $colIndex_cycleNormal_ms;
my $colIndex_cycleFast_ms;
my $colIndex_signalSendType;
my $colIndex_numRepetitions_active;
my $colIndex_initValRaw;
my $colIndex_wcBhvrKL15off = -1;
my $colIndex_offset;
my $colIndex_factor;
my $colIndex_description = -1;
my $rowOfHeadKeys = -2;

####################################################################### 
# 1. Read array of headline keywords (note: their are two relevant headlines 2 and 3)
#
#  FR: Line 2: PDU	...	Zykluszeit normal [ms]	Zykluszeit schnell [ms]	...	Signal	...	Signalsendeart	Wiederholungen aktiv ... InitWert roh [dez] ...
#      Line 3:                                            Offset	Skalierung	...
#
# CAN: Line 2: Botschaft	...	Zykluszeit normal [ms]	Zykluszeit schnell [ms]	...	Signal	... Signalsendeart	Wiederholungen aktiv ... InitWert roh [dez] ...
#      Line 3:                                            Offset	Skalierung	...
#
#######################################################################
#check usage
if (@ARGV != 2) 
{
	my $numArgs = scalar(@ARGV);
	printf "numArgs = $numArgs (2 exptected, check your commandline)\n";
	if ( $numArgs > 0 )
	{
		printf "File = $ARGV[0]\n";
	}
	if ( $numArgs > 1 )
	{
		printf "BusType = $ARGV[1]\n";
	}
	die "usage: KMatrixExtract.pl KMatrix_File.xls CAN|FR\n";
}
my $KMatrixFile = $ARGV[0];
my $busType = $ARGV[1];

#printf "KMatrixFile = $KMatrixFile\n";
#printf "Processing KMatrixFile . . .\n";
#__END__

# FlexRay
if ( $busType eq "FR" )
{
	$worksheetName = 'MLBevo_FlexRay'; # FR: MLBevo_FlexRay, CAN: MLBevo_SCCAN
	$outputFile = "KMatrixExtract_FR.txt";
	$colName_pduOrMsg = "PDU"; # FR: PDU, CAN: Botschaft
}
# CAN
else
{
	$worksheetName = 'MLBevo_SCCAN'; # FR: MLBevo_FlexRay, CAN: MLBevo_SCCAN
	$outputFile = "KMatrixExtract_CAN.txt";
	$colName_pduOrMsg = "Botschaft"; # FR: PDU, CAN: Botschaft
}
my $isXLSX = 0;
my ( $row_min, $row_max );
my ( $col_min, $col_max );
my $sheet;

($isXLSX, $sheet, $row_min, $row_max, $col_min, $col_max) = getExcelSheetWithRanges ($KMatrixFile, $worksheetName);

my @headKeys;
my $idxHdKey = 0;
my $exitLoops = 0;

for my $row ( $row_min .. $row_max )
{
	for my $col ( $col_min .. $col_max )
	{
		my $cell = getExcelCell($isXLSX, $sheet, $row, $col);
		next unless $cell;
					
		# If row number containing PDU/Message-Key found for the first time
		if ( $rowOfHeadKeys < 0 && getExcelCellVal($isXLSX, $cell) =~ m/^\s*$colName_pduOrMsg\s*$/ )
		{
			$rowOfHeadKeys = $row;
		}
		# If row is inside the two headline lines (line 2 or line 3)
		if ( $row == $rowOfHeadKeys )
		{
			if ( $colIndex_wcBhvrKL15off < 0 || $colIndex_wcBhvrKL15off > 0 && $col >= $colIndex_wcBhvrKL15off )
			{
				# If NOT ($row in 2nd head line AND $col == $colIndex_wcBhvrKL15off)
				if ( !( $colIndex_wcBhvrKL15off > 0 && $col == $colIndex_wcBhvrKL15off ) )
				{
					# Save property name into array
					$headKeys[$idxHdKey] = getExcelCellVal($isXLSX, $cell);
					chomp($headKeys[$idxHdKey]);
				}
						
				if ($headKeys[$idxHdKey] eq $colName_signal)
				{
					$colIndex_signal = $col;
				}
				if ($headKeys[$idxHdKey] eq $colName_cycleNormal_ms)
				{
					$colIndex_cycleNormal_ms = $col;
				}
				if ($headKeys[$idxHdKey] eq $colName_cycleFast_ms)
				{
					$colIndex_cycleFast_ms = $col;
				}
				if ($headKeys[$idxHdKey] eq $colName_signalSendType)
				{
					$colIndex_signalSendType = $col;
				}
				if ($headKeys[$idxHdKey] eq $colName_numRepetitions_active)
				{
					$colIndex_numRepetitions_active = $col;
				}
				if ($headKeys[$idxHdKey] eq $colName_initValRaw)
				{
					$colIndex_initValRaw = $col;
				}
				if ($headKeys[$idxHdKey] eq $colName_offset)
				{
					$colIndex_offset = $col;
				}
				if ($headKeys[$idxHdKey] eq $colName_factor)
				{
					$colIndex_factor = $col;
				}
				if ($headKeys[$idxHdKey] eq $colName_wcBhvrKL15off)
				{
					$colIndex_wcBhvrKL15off = $col;
					$rowOfHeadKeys++; # prepare for next line 3
					$row = $rowOfHeadKeys;
				}
				if ($headKeys[$idxHdKey] eq $colName_description)
				{
					$colIndex_description = $col;
				}
				$idxHdKey++;
			}
			if ( $col == $colIndex_description )
			{
				$exitLoops = 1;
				last;
			}
		}
	}
	
	last if ( $exitLoops || $rowOfHeadKeys > 0 && $row > $rowOfHeadKeys );
}

$idxHdKey = 0;
#foreach my $headKey (@headKeys)
#{
#	$idxHdKey++;
#	print "$idxHdKey. Head-Key: $headKey\n";
#}

#printf "colIndex_signal = $colIndex_signal\n";
#printf "colIndex_cycleNormal_ms = $colIndex_cycleNormal_ms\n";
#printf "colIndex_cycleFast_ms = $colIndex_cycleFast_ms\n";
#printf "colIndex_signalSendType = $colIndex_signalSendType\n";
#printf "colIndex_numRepetitions_active = $colIndex_numRepetitions_active\n";
#printf "colIndex_initValRaw = $colIndex_initValRaw\n";
#printf "colIndex_offset = $colIndex_offset\n";
#printf "colIndex_factor = $colIndex_factor\n";
#print "Press return\n";

#__END__

#######################################################################
# 2. Read each PDU/Message line into HoH
#######################################################################
my $numSignals = 0;
my @signals;
my @properties; # one line of properties
my $cell;

# data area starts after the two head lines (+ 2)
for my $row ( $rowOfHeadKeys + 1 .. $row_max )
{
	my $propertyCnt = 0;
	for my $col ( $col_min .. $col_max )
	{
		$cell = getExcelCell($isXLSX, $sheet, $row, $col);
		if ( $col == $colIndex_signal )
		{
			$signals[$numSignals] = getExcelCellVal($isXLSX, $cell);
			chomp($signals[$numSignals]);
			last if ($signals[$numSignals] =~ /^void$/); # ignore void signals and leave column loop
		}
		my $propertyValue = getExcelCellVal($isXLSX, $cell);
		if ( defined $propertyValue )
		{
			chomp($propertyValue);
		}
		else
		{
			$propertyValue = "";	
		}
		$properties[$propertyCnt] = $propertyValue;
		$propertyCnt++;
		last if ( $col > $colIndex_factor );
	}
	next if ($signals[$numSignals] =~ /^void$/); # ignore void signals and continue with next row
	my $i = 0;
	while ( exists $HoH{$signals[$numSignals]} )
	{
		$i++;
		$signals[$numSignals] =~ s/\[\d+\]//;
		$signals[$numSignals] .= "[$i]";
		#printf "Double entry: $signals[$numSignals]\n";
	}
	
	for my $idxProperty ( 0 .. scalar(@properties) )
	{
		$HoH{$signals[$numSignals]}{$headKeys[$idxProperty]} = $properties[$idxProperty];
	}
	$numSignals++;
	last if ( !$cell );
}
#printf "numSignals = $numSignals\n";
#__END__
#######################################################################
# Save hash to file
#######################################################################
my $fileHandle;
my $fileLine = "";

unlink $outputFile if ( -e $outputFile ); # delete old outputFile, if it exists already
open($fileHandle, ">", $outputFile)     or die "Can't open $outputFile: $!";
binmode($fileHandle, ":utf8"); # Avoid message 'Wide character in print at...' in line print $fileHandle "$signal";

print $fileHandle "Format: PDU/MSG::Signal=idx#cycleTime_ms(signalSendType:...)#initVal_phys#\n";
print $fileHandle "- idx is a place holder for a later usage as running index\n";
print $fileHandle "- if fast cycle time exists, it will be appended after the normal cycle time\n";
print $fileHandle "- initVal_phys = factor * initValRaw + offset (or with headline names: \"Skalierung\" * \"InitWert roh [dez]\" + \"Offset\")\n";
print $fileHandle "- ? is written, if value (or related value, like factor or offset) does not exist in K-Matrix\n";
print $fileHandle "--------------------------------END_OF_HEADER-----------------------------------------------\n";

#foreach my $signal ( sort keys %HoH )
foreach my $signal ( @signals ) # write signals in same order as in xls-headline (not as in hash!)
{
    foreach my $propertyName ( @headKeys ) # write properties in same order as in xls-headline (not as in hash!)
    {
    	if ( exists $HoH{$signal}{$propertyName} )
    	{
    		if ( $propertyName eq $colName_pduOrMsg )
			{
				my $signalCopy = $signal;
				$signalCopy =~ s/\[\d+\]//;
				$fileLine = "$HoH{$signal}{$propertyName}"."::$signalCopy=idx";	
			}
			if ( $propertyName eq $colName_cycleNormal_ms )
			{
				if ( exists $HoH{$signal}{$colName_cycleNormal_ms} && $HoH{$signal}{$colName_cycleNormal_ms} ne "" )
				{
					$fileLine .= "#$HoH{$signal}{$propertyName}";
				}
				else
				{
					$fileLine .= "#?cycleNormal_ms";
				}
					
				if ( exists $HoH{$signal}{$colName_cycleFast_ms} && $HoH{$signal}{$colName_cycleFast_ms} ne "" )
				{
					$fileLine .= ">Fast>$HoH{$signal}{$colName_cycleFast_ms}";
				}
				else
				{
					# no error, allowed
				}	
			}
			if ( $propertyName eq $colName_signalSendType )
			{
				$fileLine .= "(signalSendType:$HoH{$signal}{$propertyName}";
				if ( exists $HoH{$signal}{$colName_numRepetitions_active} && $HoH{$signal}{$colName_numRepetitions_active} ne "" )
				{
					$fileLine .= ",numRepetitions:$HoH{$signal}{$colName_numRepetitions_active}";
				}
				$fileLine .= ")";
			}
			if ( $propertyName eq $colName_initValRaw )
			{
				my $warningFlag = "";
				# multiply with factor to get the phys. value (columns "Offset", "Skalierung"). phys = factor * raw + offset
				if ( exists $HoH{$signal}{$colName_initValRaw} && $HoH{$signal}{$colName_initValRaw} ne "" )
				{
					if ( exists $HoH{$signal}{$colName_factor} && $HoH{$signal}{$colName_factor} ne "" )
					{
						$HoH{$signal}{$propertyName} *= $HoH{$signal}{$colName_factor};
						#printf "$signal: initValRaw = $HoH{$signal}{$propertyName}, factor = $HoH{$signal}{$colName_factor}\n";
					}
					else
					{
						$warningFlag = "?factor";
					}
					if ( exists $HoH{$signal}{$colName_offset} && $HoH{$signal}{$colName_offset} ne "" )
					{
						$HoH{$signal}{$propertyName} += $HoH{$signal}{$colName_offset};
						#printf "$signal: initValRaw = $HoH{$signal}{$propertyName}, offset = $HoH{$signal}{$colName_offset}\n";
					}
					else
					{
						$warningFlag .= "?offset";
					}
					if ( abs($HoH{$signal}{$propertyName}) < 1E-9 )
					{
						$HoH{$signal}{$propertyName} = 0.0;
					}
				}
				else
				{
					$warningFlag = "?initValRaw";
				}
				#printf "colName_factor = $HoH{$signal}{$colName_factor}\n";
				#printf "colName_offset = $HoH{$signal}{$colName_offset}\n";
				#print $fileHandle " | $propertyName = $HoH{$signal}{$propertyName}";
				$fileLine .= "#$HoH{$signal}{$propertyName}$warningFlag#";
			}
    	}
    }
    print $fileHandle "$fileLine\n";
}
close ($fileHandle);

# write error messages, if they exist
writeErrorLog("Error Messages", @errorMessages);


#######################################################################
print "DONE testprog-Setup (See: $outputFile)\n";

# Write any error messages to log file
# Usage: writeErrorLog($headline, @errorMessages)
# If no error messages exist, calling this function will just delete any old error log file
sub writeErrorLog {
	my $headline = shift;
	my @errorMessages = @_;
	my $errorOutputFile = "ErrorLog_KMatrixExtract_$busType.txt";
	unlink $errorOutputFile if ( -e $errorOutputFile ); # delete old errorOutputFile, if it exists already
	
	my $numErrorMessages = scalar(@errorMessages);
	if ( $numErrorMessages > 0) {
		my $fhErrorOutputFile;
		print "numErrorMessages = $numErrorMessages (see: $errorOutputFile)\n";
		open($fhErrorOutputFile, ">", $errorOutputFile)     or die "Can't open $errorOutputFile: $!";
		#binmode($fhErrorOutputFile, ":utf8"); # Avoid message 'Wide character in print at...'
		print $fhErrorOutputFile "$headline\n";
		foreach my $message ( @errorMessages )
		{
			print $fhErrorOutputFile "$message";
		}
		close ($fhErrorOutputFile);
	}
}

# Usage: getExcelCell($isXLSX, $sheet, $row, $col)
sub getExcelCell {
	my $isXLSX = shift;
	my $sheet = shift;
	my $row = shift;
	my $col = shift;
	my $cell;
	
	if ( $isXLSX ) {	
		$cell = $sheet -> {Cells} [$row] [$col]; # xlsx
		}
	else {
		 $cell = $sheet->get_cell( $row, $col ); # xls
		}

	return $cell;
}

# Usage: getExcelCellVal($isXLSX, $cell)
sub getExcelCellVal {
	my $isXLSX = shift;
	my $cell = shift;
	my $value;
		
	if ( $isXLSX ) {	
		$value = $cell -> {Val};
		}
	else {
		$value = $cell->value();
		}
		
	return $value;
}

# Usage: ($isXLSX, $sheet, $row_min, $row_max, $col_min, $col_max) = getExcelSheetWithRanges ($ExcelFile, $worksheetName)
sub getExcelSheetWithRanges {
	my $ExcelFile = shift;
	my $worksheetName = shift;
	my ($isXLSX, $sheet, $row_min, $row_max, $col_min, $col_max);
		
	if ( $ExcelFile =~ /.xlsx$/i ) { $isXLSX = 1; }
	
	if ( $isXLSX ) {
		my $excel = Spreadsheet::XLSX -> new ($ExcelFile);
		$sheet = $excel -> {Worksheet}[0]; 
		if ( !defined $sheet ) {
			push(@errorMessages, "Unable to open Excel worksheet");
			writeErrorLog("Problem with KMatrix-File: $ExcelFile", @errorMessages);
			die "Unable to open Excel worksheet";
			}
		#$sheet -> {MaxRow} ||= $sheet -> {MinRow};
		$row_min = $sheet -> {MinRow};
		$row_max = $sheet -> {MaxRow};
		$col_min = $sheet -> {MinCol};
		$col_max = $sheet -> {MaxCol};
		}
	else {
		my $parser   = Spreadsheet::ParseExcel->new();
		my $workbook = $parser->parse($ExcelFile);
		
		if ( !defined $workbook ) {
			push(@errorMessages, $parser->error());
			writeErrorLog("Problem with KMatrix-File: $ExcelFile", @errorMessages);
			die $parser->error(), ".\n";
			}
		
		$sheet = $workbook->worksheet($worksheetName);
		( $row_min, $row_max ) = $sheet->row_range();
		( $col_min, $col_max ) = $sheet->col_range();
	}
	return ($isXLSX, $sheet, $row_min, $row_max, $col_min, $col_max);
}