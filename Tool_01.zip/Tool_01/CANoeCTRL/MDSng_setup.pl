#!/usr/bin/perl -w

#################################################################################
# this tool is under version management
my $VERSION = q$Revision: 1.17 $;
my $HEADER  = q$Header: CANoeCTRL/MDSng_setup.pl 1.17 2014/07/03 20:45:30ICT Weissflog Peter (CC-PS/EPS2) (WGP2SI) develop  $;
#################################################################################

=head1 usage

Generates MDSng input files

 MDSng_setup.pl <CrashCodeList>.txt <Default>.design.xml

 e.g.: MDSng_setup.pl C:\TurboLIFT\Tools\CANoeCTRL\test\MDSng_copyMapping\crashCodeList1.txt C:\TurboLIFT\Tools\CANoeCTRL\test\MDSng_setup\AU1044_C08_CAT2_52R.design.xml

 Input:
 <CrashCodeList>.txt   contains full crash code with optional version after semicolon (only crashCodes marked with _IN are read)
 <Default>.design.xml  contains a default MDSng setup, which is used as signal exclusion list

 Output:
 AnyPrj.design.xml
 AnyPrj.crashset.xml
 AnyPrj.mapping.xml
 Excluded_Locations.txt (for information only, no MDS input)


=head1 AUTHOR

Peter WeiE<szlig>flog, E<lt>Peter.Weissflog@de.bosch.comE<gt>

=cut

use strict;
use warnings;
use DBI;

my @errorMessages;

#check usage
if (@ARGV != 2) 
{
	my $numArgs = scalar(@ARGV);
	printf "numArgs = $numArgs (2 exptected, check your commandline)\n";
	if ( $numArgs > 0 )
	{
		printf "<CrashCodeList>.txt = $ARGV[0]\n";
	}
	if ( $numArgs > 1 )
	{
		printf "<Default>.design.xml = $ARGV[1]\n";
	}
	die "usage: MDSng_setup.pl <CrashCodeList>.txt <Default>.design.xml\n";
}
my $CrashCodeListFile = $ARGV[0];
my $MDSngDesignDefaultFile = $ARGV[1];

#printf "CrashCodeListFile  = $CrashCodeListFile\n";
#printf "<Default>.design.xml = $MDSngDesignDefaultFile\n";
#__END__

my $fileHandle;
my $fhMDSngDesignFileDefault;
my $fhMDSngDesignFileNew;
my $designFileLine;
my $outputFile;
my $outputFileExcludedLocs;

#######################################################################
# Get relevant crash codes named with "_IN" or "_IN;digits" at the end
#######################################################################

unless ( open($fileHandle, "<", $CrashCodeListFile) ) {
	push(@errorMessages, "Can't open $CrashCodeListFile: $!\n");
	writeErrorLog("Wrong file path", @errorMessages);
	die "Can't open $CrashCodeListFile: $!";
	}

my $CrashCodeLine;
my @crashCodesJob;
while ( $CrashCodeLine = <$fileHandle> )
{ 
	chomp($CrashCodeLine);
	# if line ends with "_IN" or contains "_IN;" and if it isn't a comment line
	if ( $CrashCodeLine =~ /(_IN$|_IN;)/ && $CrashCodeLine !~ /^;/ )
	{
		push(@crashCodesJob, $CrashCodeLine);
#		printf "crashCode: $CrashCodeLine\n";
	}
}
close ($fileHandle);
my $numCrashCodesInJob = scalar(@crashCodesJob);
#__END__

#######################################################################
# Read <Default>.design.xml and copy top-part to AnyPrj.design.xml
#######################################################################
$outputFile = "AnyPrj.design.xml";
unlink $outputFile if ( -e $outputFile ); # delete old outputFile, if it exists already
open($fhMDSngDesignFileNew, ">", $outputFile)     or die "Can't open $outputFile: $!";
#binmode($fhMDSngDesignFileNew, ":utf8"); # Avoid message 'Wide character in print at...'

my %locations2Exclude;
my $AlgoInChIdxOfs = 0;

if ( $MDSngDesignDefaultFile =~ /\.design\.xml$/ )
{
    unless ( open ( $fhMDSngDesignFileDefault,"<", "$MDSngDesignDefaultFile" ) ) {
		push(@errorMessages, "Can't open $MDSngDesignDefaultFile: $!\n");
		writeErrorLog("Wrong file path", @errorMessages);
		die "Can't open $MDSngDesignDefaultFile: $!";
		}

    while ( $designFileLine = <$fhMDSngDesignFileDefault> )
	{ 
		# End condition at line:
		#    <CommunicationInputChannel name="UFS_L" syncDelay="0.006" type="PAS4" index="0" sensorLocation="UFS_D">
		if ( $designFileLine =~ /\s*<CommunicationInputChannel/ )
		{
			last;
        }
		
		print $fhMDSngDesignFileNew $designFileLine; # copy line to AnyPrj.design.xml
				
		#    <AlgoInputChannel invert="true" sensorLocation="Acc_HG_X"
		if ( $designFileLine =~ /\s+<AlgoInputChannel.+sensorLocation="(\S+)"/ )
		{
			$locations2Exclude{$1} = $AlgoInChIdxOfs;
			$AlgoInChIdxOfs++;
        }
	}
}
else {
	push(@errorMessages, "Unknown file format $MDSngDesignDefaultFile: $!\n");
	writeErrorLog("Wrong file name", @errorMessages);
	die "Unknown file format $MDSngDesignDefaultFile\n"
	}

#printf "AlgoInChIdxOfs  = $AlgoInChIdxOfs\n";

$outputFileExcludedLocs = "Excluded_Locations.txt";
unlink $outputFileExcludedLocs if ( -e $outputFileExcludedLocs ); # delete old outputFileExcludedLocs, if it exists already
open($fileHandle, ">", $outputFileExcludedLocs)     or die "Can't open $outputFileExcludedLocs: $!";
#binmode($fileHandle, ":utf8"); # Avoid message 'Wide character in print at...'


printf $fileHandle "Excluded Locations (already present in <Default>.design.xml):\n";
foreach my $key (sort { $locations2Exclude{$a} <=> $locations2Exclude{$b} } keys %locations2Exclude)
{
        printf $fileHandle "%4d %s\n", $locations2Exclude{$key}, $key;
}

print "\n\nDONE MDSng-Setup (See: $outputFileExcludedLocs)\n";

#######################################################################
# Read Crash DB
#######################################################################
# Relevant columns: CHANNELTAB: CHANNELNR_CN, CRASHCODE_CN, LOCATION_CN, DIRECTION_CN, CRASHTAB: VERSION

#SELECT CHANNELTAB.CHANNELNR_CN, CHANNELTAB.CRASHCODE_CN, CHANNELTAB.DIRECTION_CN, CHANNELTAB.LOCATION_CN, CRASHTAB.VERSION
#FROM CHANNELTAB INNER JOIN CRASHTAB ON CHANNELTAB.CRASHCODE_CN = CRASHTAB.CRASHCODE_CH
#ORDER BY CHANNELTAB.CRASHCODE_CN;

# Each crashcode has a time stamp and many locations. Each location has a number and a direction
# 
# my %HoH = (
# 	TF_INT_0055_PCR_Ausloesung_Vollstraff_IN => {
# 			timeStamp	                                => 2013-09-06 13:25:39,
# 			FXR__SDF_PSF_Obj_01__SDF_PSF_MessZeitpunkt	=>	{
#															no =>  1,
#															dir => "n/a"
#															}
# 			CAN__RGS_VL_02__RGS_L_Bauteilfehler	        => {
#															no =>  10,
#															dir => "n/a"
#															}
#       	...
#         	},
# 	TF_INT_0065_PCB070201_IN => {
# 			timeStamp	                                => 2013-09-06 14:35:48,
# 			FXR__Motor_20__MO_Fahrpedalrohwert_01	    => {
#															no =>  1,
#															dir => "n/a"
#															}
# 			s_SC_Accel_Y_010	                        => {
#															no =>  10,
#															dir => "n/a"
#															}
# 			...
#         	}

my %HoH; # Hash of hash for crash codes and its properties
my %locations;
my $numLocs = 0;
my $numCodes = 0;

my $dsn               = "mdsnglocal";
my $database          = "DBI:ODBC:$dsn";
my $db_user           = "";
my $db_password       = "";

# connect to the Access db.
my $dbh;
$dbh = DBI->connect($database,$db_user,$db_password) or die $dbh->errstr;

# Create SQL-Statement
my $sqlStatement =
"SELECT CHANNELTAB.CHANNELNR_CN, CHANNELTAB.CRASHCODE_CN, CHANNELTAB.DIRECTION_CN, CHANNELTAB.LOCATION_CN, CRASHTAB.VERSION
FROM CHANNELTAB INNER JOIN CRASHTAB ON CHANNELTAB.CRASHCODE_CN = CRASHTAB.CRASHCODE_CH\n";

# Append condition for 1st crash code
if ( $numCrashCodesInJob > 0 ) {
	$sqlStatement .= "WHERE CRASHTAB.CRASHCODE_CH = '$crashCodesJob[0]'\n";
	}
# Append conditions for remaining crash codes
for (my $i = 1; $i < $numCrashCodesInJob; $i++) {
	$sqlStatement .= "OR CRASHTAB.CRASHCODE_CH = '$crashCodesJob[$i]'\n";
	}

$sqlStatement .= "ORDER BY CHANNELTAB.CRASHCODE_CN;\n";

#print $sqlStatement;

my $sth = $dbh->prepare($sqlStatement);

my $chNr;
my $crashCode;
my $direction;
my $location;
my $timeStamp;

$sth->execute;
while (($chNr, $crashCode, $direction, $location, $timeStamp) = $sth->fetchrow_array) {
	# Assumption: DB-Location: FXR__PSF_01__PSF_Obj_Klasse => MDS: PSF_Obj_Klasse
	$location =~ s/^\S+__\S+__//;
	
	# new location
	if ( !exists $locations{$location} )
	{
		$locations{$location}{'dir'} = $direction;
		if ($direction ne 'ignoreSignal')
		{
			$locations{$location}{'no'} = $chNr;
		}
		else
		{
			$locations{$location}{'no'} = -1; # set to ZEROEMULATION
		}
		$numLocs++;
	}
	# new crash code
	if ( !exists $HoH{$crashCode} )
	{
		$HoH{$crashCode}{'timeStamp'} = $timeStamp;
		$numCodes++;
	}
	# new location
	if ( !exists $HoH{$crashCode}{$location} )
	{	
		$HoH{$crashCode}{$locations{$location}}{'dir'} = $direction;
		if ($direction ne 'ignoreSignal')
		{
			$HoH{$crashCode}{$locations{$location}}{'no'} = $chNr;		
		}
		else
		{
			$HoH{$crashCode}{$locations{$location}}{'no'} = -1; # set to ZEROEMULATION
		}
	}
}
my $rc  = $dbh->disconnect;
#if ( $rc == 1 ) {print "Crash DB disconnected\n\n";}
#else {print "Crash DB disconnection F A I L E D\n\n";}

# Check whether all crash codes were found in DB
if ( $numCrashCodesInJob > $numCodes ) {
	printf "Number of crash codes requested: $numCrashCodesInJob\nNumber of crash codes found in DB: $numCodes\n";
	for (my $i = 0; $i < $numCrashCodesInJob; $i++) {
		if ( !exists $HoH{$crashCodesJob[$i]} ) { push(@errorMessages, "Crash code not found in DB: $crashCodesJob[$i]\n"); }
		}
	}
	
#printf "numCodes = $numCodes\n";
#printf "numLocs = $numLocs\n";	
if ( $numCodes == 0 ) {
	close ($fhMDSngDesignFileDefault);
	writeErrorLog("None of the requested drashcodes found in local crash DB", @errorMessages);
	die "None of the requested drashcodes found in local crash DB";
	}

#######################################################################
# AnyPrj.design.xml (append new AlgoInputChannels)
#######################################################################
# Entries to be filled:
# 1. sensorLocation: DB channel from Crash-DB (DB-Column: LOCATION_CN). ATTENTION: DB: "FXR__PSF_01__PSF_Obj_Klasse", MDS without prefixes: "PSF_Obj_Klasse".
# 2. index:          Consecutively (to be appended to given setup => start with offset value required)
# 3. name:           (DB), Same as sensorLocation
# 4. dir:            DB, Direction from Crash-DB (examples: "X", "n/a", ...)
# Pseudo-Code: Over all locations write one block below with 2 parameters above read from crash DB
my $index = $AlgoInChIdxOfs;
for my $crashCode (sort (keys %HoH))
{
	foreach my $location ( sort (keys %locations) )
	{
		if ( !exists $locations2Exclude{$location} )
		{
			if ( exists $HoH{$crashCode}{$locations{$location}}{'dir'} )
			{
				my $direction = $HoH{$crashCode}{$locations{$location}}{'dir'};
				#$direction =~ s/ignoreSignal/Bus/; # replace "ignoreSignal" by "Bus" for design.xml
				# Do not indent the text block below (keep it in 1st column)! 
				print $fhMDSngDesignFileNew
'    <AlgoInputChannel invert="false" sensorLocation="'.$location.'" samplingInterrupt="Algorithm" rotator="" index="'.$index.'" name="'.$location.'" dir="'.$direction.'" samplingIndex = "LAST" inSimCoreOnly="true">
      <FilterElement type="NoFilter_For_Bus_Signals" version="1" enable="true" />
      <FilterElement type="Nullfilter: transfer function = 1" version="1" enable="false" />
      <ADC identifier="ADC10BIT" resolution="10" supplyVoltage="16384" min="0.00000" max="16384" tolerance="1.00000" offset="0" enable="false" />
      <SCONConnection thdType="" enable="false" />
      <Communication sensorHwName="" syncDelay="0" commCycle="" />
    </AlgoInputChannel>
';
				$index++;
			}
		}
	}
	last; # all crash codes should/have to(!) have same locations, i.e. finish after first crash code
}
#######################################################################
# AnyPrj.design.xml: Copy remaining lines from <Default>.design.xml after inserted new block
#######################################################################
print $fhMDSngDesignFileNew $designFileLine; # Copy above skipped line to AnyPrj.design.xml, before continuation to following lines
while ( $designFileLine = <$fhMDSngDesignFileDefault> )
{ 
	print $fhMDSngDesignFileNew $designFileLine; # copy line to AnyPrj.design.xml
}
close ($fhMDSngDesignFileNew);
close ($fhMDSngDesignFileDefault);
print "DONE MDSng-Setup (See: $outputFile)\n";

#######################################################################
# Create AnyPrj.crashset.xml
#######################################################################
# Entries to be filled:
# 1. crashcode: DB, Crash-DB column CHANNELTAB: CRASHCODE_CN
# 2. crashversion: DB, Crash-DB column CRASHTAB: VERSION
# Pseudo-Code: Over all crash codes, over all locations write assignment lines with 3 parameters from crash-DB
$outputFile = "AnyPrj.crashset.xml";
unlink $outputFile if ( -e $outputFile ); # delete old outputFile, if it exists already
open($fileHandle, ">", $outputFile)     or die "Can't open $outputFile: $!";
#binmode($fileHandle, ":utf8"); # Avoid message 'Wide character in print at...'

# Do not indent the text block below (keep it in 1st column)!
print $fileHandle
'<?xml version="1.0"?>
<CrashSetDescription xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
  <Info creatorVersion="CrashAssignmentTool" fileVersion="1.0" />
  <CrashSet name="AnyPrj">';
for my $crashCode (sort (keys %HoH))
{
# Do not indent the text block below (keep it in 1st column)!
	print $fileHandle
	'
    <crash crashcode="'.$crashCode.'" crashversion="'.$HoH{$crashCode}{'timeStamp'}.'" assignmentComment="" />';
}
# Do not indent the text block below (keep it in 1st column)!
print $fileHandle
'
    <query>
      <field name="Manufacturer" value="" />
      <field name="Crashcode" value="C226651*" />
      <field name="Crash Type" value="" />
      <field name="Vehicle Type" value="" />
      <field name="SpeedMin" value="0" />
      <field name="SpeedMax" value="999" />
      <field name="endDate" value="" />
      <field name="database" value="mdsglobal" />
    </query>
  </CrashSet>
</CrashSetDescription>
';

close ($fileHandle);
print "DONE MDSng-Setup (See: $outputFile)\n";
	
#######################################################################
# Create AnyPrj.mapping.xml
#######################################################################
# Entries to be filled:
# 1. crashcode: DB, Crash-DB column CHANNELTAB: CRASHCODE_CN
# 2. channelNumber:  DB, Index in Crash-DB (DB-column: CHANNELTAB: CHANNELNR_CN, channelNumber="-1" is ZEROEMULATION)
# 3. sensorLocation: DB, See in design.xml above, DB channel from Crash-DB (DB-Column: CHANNELTAB: LOCATION_CN)
# Pseudo-Code: Over all crash codes, over all locations write assignment lines with 3 parameters from crash-DB
$outputFile = "AnyPrj.mapping.xml";
unlink $outputFile if ( -e $outputFile ); # delete old outputFile, if it exists already
open($fileHandle, ">", $outputFile)     or die "Can't open $outputFile: $!";
#binmode($fileHandle, ":utf8"); # Avoid message 'Wide character in print at...'
# Do not indent the text block below (keep it in 1st column)!
print $fileHandle
'<?xml version="1.0"?>
<AssignmentList xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
  <Info creatorVersion="CrashAssignmentTool" fileVersion="1.0" />
  <Assignments>
';
for my $crashCode (sort (keys %HoH))
{
	# Do not indent the text block below (keep it in 1st column)!
	print $fileHandle
'    <crash crashcode="'.$crashCode.'" assignmentComment="" crashversion="'.$HoH{$crashCode}{'timeStamp'}.'">
';
	foreach my $location ( sort (keys %locations) )
	{  
		# Do not indent the text block below (keep it in 1st column)!
		#if ( $location ne "" && exists $HoH{$crashCode} && exists $HoH{$crashCode}{$locations{$location}} && $HoH{$crashCode}{$locations{$location}} ne "" && exists $HoH{$crashCode}{$locations{$location}}{'no'})
		if ( exists $HoH{$crashCode}{$locations{$location}}{'no'} )
		{
			print $fileHandle
'      <Assignment channelNumber="'.$HoH{$crashCode}{$locations{$location}}{'no'}.'" sensorLocation="'.$location.'" />
';
		}
	}
	# Do not indent the text block below (keep it in 1st column)!
	print $fileHandle
'    </crash>
';
}	
# Do not indent the text block below (keep it in 1st column)!
print $fileHandle
'  </Assignments>
</AssignmentList>';

close ($fileHandle);
print "DONE MDSng-Setup (See: $outputFile)\n\n";

# write error messages, if they exist
writeErrorLog("Error Messages", @errorMessages);

#######################################################################
   
# Write any error messages to log file
# Usage: writeErrorLog($headline, @errorMessages)
# If no error messages exist, calling this function will just delete any old error log file
sub writeErrorLog {
	my $headline = shift;
	my @errorMessages = @_;
	my $errorOutputFile = "ErrorLog_MDSng_setup.txt";
	unlink $errorOutputFile if ( -e $errorOutputFile ); # delete old errorOutputFile, if it exists already
	
	my $numErrorMessages = scalar(@errorMessages);
	if ( $numErrorMessages > 0) {
		my $fhErrorOutputFile;
		print "numErrorMessages = $numErrorMessages (see: $errorOutputFile)\n";
		open($fhErrorOutputFile, ">", $errorOutputFile)     or die "Can't open $errorOutputFile: $!";
		#binmode($fhErrorOutputFile, ":utf8"); # Avoid message 'Wide character in print at...'
		print $fhErrorOutputFile "$headline\n";
		foreach my $message ( @errorMessages )
		{
			print $fhErrorOutputFile "$message";
		}
		close ($fhErrorOutputFile);
	}
}
