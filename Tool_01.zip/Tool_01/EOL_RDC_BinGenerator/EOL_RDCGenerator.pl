 #!/usr/bin/perl -w
    use Tk;
    use strict;
	use Encode;
	#use Tk::BrowseEntry;
	require Tk::Pane;
	
	my ($Request_1, $Request_2);
	my ($request, $line, $file, $path, $name);
	my ($in_file, $out_file, $file_name, $display_txt, $FileFrame_1_1);
	my ($dir);
    my $mw = MainWindow->new;
	
	
	$mw->Button(
			"-text" => "Load files in path MQB_A0\\config\\Tools\\Canoe\\EOLFiles",
			"-command" => sub{
				$dir = $mw->chooseDirectory;
				$dir = encode("windows-1252", $dir);
			}
			
	)->pack;
  
	$mw->Button(
		  "-text" => "Browse RDC \.xml file",
			"-command" => sub
			{
				# browse for file
				$in_file = $mw -> getOpenFile
				 (
				"-filetypes"  =>
				[
				["RDC files", '.xml'],
				["All files", '.*'],
				],
				"-title"      => "choose RDC file",
				);
				# if a file was chosen
				if ( $in_file ){

					$in_file =~ s/\//\\/g; # replace all slashes with backslahes
					w2log("\n $in_file was chosen\n");
				}
			},
	)->pack;

	
    $mw->Button(
        -text => 'RequestDownload',
        -command => sub{generate_Download($in_file)}
    )->pack;

    $mw->Button(
        -text => 'RequestTransfer',
        -command => sub{generate_Transfer($in_file)}
    )->pack;

    MainLoop;

    sub generate_Download {
		if($in_file =~ m'(.*)\\(.*?).xml'){
			$path = $1;
			$name = $2;
		}
		
		$file_name = "Download_$name".".txt";
		$out_file = "$dir\\$file_name";
		
		open (OUT1, ">>","$dir\\FileNames.txt") or die "Cant open out file";
		print OUT1 $file_name,"\n";
		close OUT1;

		open (IN, "<$in_file") or die "Can't open $in_file: $!\n";
		open (OUT, ">$out_file") or die "Can't open $out_file: $!\n";
		
		
		my ($Request_1, $Request_2);

		while ( $line = <IN> ){
			if($line =~ m'<START-ADR>0x(.*?)</START-ADR>'){
				$Request_1 = "340044$1";
				}
			elsif($line =~ m'<GROESSE-DEKOMPRIMIERT>0x(.*?)</GROESSE-DEKOMPRIMIERT>'){	
				#print OUT $1;
				if(length $1 == 6){
					$Request_2 = "00$1";
				}
				if(length $1 == 5){
					$Request_2 = "000$1";
				}
				if(length $1 == 4){
					$Request_2 = "0000$1";
				}
				if(length $1 == 3){
					$Request_2 = "00000$1";
				}
				if(length $1 == 2){
					$Request_2 = "000000$1";
				}
				if(length $1 == 1){
					$Request_2 = "0000000$1";
				}
			}
		}

		$request = $Request_1.$Request_2;
		$request =~ s/([a-fA-F0-9][a-fA-F0-9])/chr(hex($1))/eg;

		print OUT $request;

		close IN;
		close OUT;
		
    }

    sub generate_Transfer {

		# Variables#####
		my ($outline, $count, $count_hex, $request_1, $request_2, $Request, $line, $length, $blockcount);

		open (IN, "<$in_file") or die "Can't open $in_file: $!\n";

		while ( $line = <IN> ){
			if($line =~ m'<DATEN>(.*?)</DATEN>'){
				my $count = 0;
				my $initial = 0;
				$outline = $1;
				$outline =~ s/0x//g;
				$outline =~ s/,//g;
		
				print $outline,"\n";
		
				$length = length $outline;
				print "Length : $length\n";
		
				$blockcount = int($length/506);
				print "BlockCount : $blockcount\n";
		
				
				if($in_file =~ m'(.*)\\(.*?).xml'){
				
				$path = $1;
				$name = $2;
				
				for (; $blockcount>=$count;){	
					$count = $count+1;
					
				
					$file_name = "Transfer_$name"."_".$count.".txt";
					$out_file = "$dir\\".$file_name;
					
					open (OUT1, ">>","$dir\\FileNames.txt") or die "Cant open out file";
					print OUT1 $file_name,"\n";
					close OUT1;
				
					open (OUT, ">$out_file") or die "Can't open $out_file: $!\n";
					binmode OUT;
				
					#Forming the Request Transfer request
					if($count <= 15){
					$count_hex = sprintf("%x", $count);
					$request_1 = "36"."0".$count_hex;
					}
					else{
					$count_hex = sprintf("%x", $count);
					$request_1 = "36".$count_hex;
					}
				
					$request_2 = substr($outline, $initial, 506);
					$Request = $request_1.$request_2;
					print("Request :  $Request\n");
					print "Length : ", length($Request),"\n\n";
				
					#Converting request in ASCII format
					$Request =~ s/([a-fA-F0-9][a-fA-F0-9])/chr(hex($1))/eg;
					print OUT $Request;
				
					$initial = $initial+506;
					close OUT;
				}
				}
				
		
			}
		}


close IN;
		
		
    }