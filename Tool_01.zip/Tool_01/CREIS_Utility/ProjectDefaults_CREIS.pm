package LIFT_PROJECT;

$Defaults->{'MDSRESULT'} = {
    "RESULTS" => {
        "DEFAULT"       => { "PATH" => 'DUMMY_DEFAULT.mdb',       "MDSTYPE" => "MDSNG" },
        "RUNTIME"       => { "PATH" => 'DUMMY_RUNTIME.mdb',       "MDSTYPE" => "MDSNG" },
        "MINIMALLOOPS"  => { "PATH" => 'DUMMY_MINIMALLOOPS.mdb',  "MDSTYPE" => "MDSNG" },
        "NOFIRE"        => { "PATH" => 'DUMMY_NOFIRE.mdb',        "MDSTYPE" => "MDSNG" },
        "FRONT_CRASHES" => { "PATH" => 'DUMMY_FRONT_CRASHES.mdb', "MDSTYPE" => "MDSNG" },
    },
};

$Defaults->{'CREIS'} = {

    "DEVICES_USED"  => [    #you can use PD, POWER, QuaTe, TRC, CANoeCtrl
        'MDSRESULT',
        'POWER',      # for powering ECU
        'QUATE',    # for sensor emulation
    	'TRC',      # for Squib firing measurement
    	'CANOECTRL',# for Bus signal emulation and analysis
    	'PD'
    ],

        	
	"Mapping" => {
		"INPUT" => {

			#Module: Sensor: Direction: Type:Version
			#'ECU: Acc_HG: -X: SMA560_SYNC' 				=> { 'device' => 'ECU_Acc_HG',	'Simulator' => 'Quate'	},
		
		},
		"OUTPUT" => {
            # Simdevices & crash outputs
			# 'AB1FD'      => { 'MeasureBy' => 'TRANSI', 'Evaluation' => \&CREIS_EvaluateSquibFiring},  
		},

		"ENVIRONMENT"  => {
		    # environment states
		    #'BLFD_State' =>
		    #{
            #    '0' => sub {
            #        MLC_SetLogicalState('BLFD', 'UNLOCKED');
            #    },
            #    '1' => sub {
            #        MLC_SetLogicalState('BLFD', 'LOCKED');
            #    },
		    #},

		},
	},
};

1;
