#!usr\bin\perl.exe -w
# *****************************************************************************************************
#                                                                                                       
#  Copyright (c) 2012  Robert Bosch GmBH                                                                
#                      Germany                                                                          
#                      All rights reserved                                                              
#                                                                                                       
#******************************************************************************************************
#    $Source: CREIS_Utility/CREIS_Utility.pl $
#    $Revision: 1.10 $
#    $Author: Schwibus Dirk (CC-PS/EPS2) (SDW2BUE) $
#    $State: develop $
#    $Date: 2016/07/25 18:00:17ICT $
#******************************************************************************************************

#################################################################################
# this tool is under MKS version management
my $VERSION = q$Revision: 1.10 $;
my $HEADER  = q$Header: CREIS_Utility/CREIS_Utility.pl 1.10 2016/07/25 18:00:17ICT Schwibus Dirk (CC-PS/EPS2) (SDW2BUE) develop  $;
#################################################################################

use strict;
use Tk;
use Tk::Table;
use Tk::DirTree;
use Data::Dumper;
use warnings;
use File::Basename;
use Data::Dumper;
use Win32::Console::ANSI;
use Term::ANSIColor;

my $addpath;
BEGIN
{
    use Config;
    use File::Spec;
    use File::Basename;

    # find the LIFT engine path (LIFT_engine_path = ./../)
    my $LIFT_exec_path = File::Spec->rel2abs(dirname(dirname(__FILE__))) . "/Engine";

    unshift @INC, "$LIFT_exec_path/modules/";
    unshift @INC, "$LIFT_exec_path/modules/TC_FunctionLib";
    unshift @INC, "$LIFT_exec_path/modules/TC_FunctionLib/TC_CustLib";
    unshift @INC, "$LIFT_exec_path/modules/TC_FunctionLib/TC_Project";
    unshift @INC, "$LIFT_exec_path/modules/TC_FunctionLib/TC_TNT";

    # add directories to search path for perl modules    
    $addpath = "$LIFT_exec_path/modules/DLLs/MDSResult";
    my $perl56 = $addpath . "/Perl56";     #perl 5.6(32-bit) DLL directory
    my $win32 = $addpath . "/Win32";       #perl 5.12, 32-bit DLL directory
    my $win64 = $addpath . "/Win64";       #perl 5.12, 64-bit DLL directory

    if($] =~ m/5.006/i)
    { #if Perl version is 5.6
        unshift @INC, ($addpath, $perl56);      #Include MDSResult.pm from Root directory, Load MDSResult.dll from "Perl56" 
        $ENV{PATH} = $win32 . ";$ENV{PATH}";    #Load MDSResult.dll from "Win32"
    } 
    elsif($] =~ m/5.012/i) 
    {  #if Perl version is 5.12
        if ($Config{'archname'} =~ m/x64/i)
        {     #check the bitness of perl (32-bit or 64-bit)
            unshift @INC, ($addpath, $win64);    #Include MDSResult.pm from Root directory, Load MDSResult.dll from "Win64"
            $ENV{PATH} = $win64 . ";$ENV{PATH}"; #Load MDSResult.dll from "Win64"
        }
        else{
            unshift @INC, ($addpath, $win32);    #Include MDSResult.pm from Root directory, Load MDSResult.dll from "Win32"
            $ENV{PATH} = $win32 . ";$ENV{PATH}"; #Load MDSResult.dll from "Win32"
        }
    }
}

my $proj_const_creis_template_href;
my $proj_const_mdsresult_template_href;

use MDSResult;
{
    no warnings;
    require '.\ProjectDefaults_CREIS.pm';
    unless( $proj_const_creis_template_href = $LIFT_PROJECT::Defaults->{'CREIS'} ) {
        print "Missing section Defaults->{'CREIS'}"; sleep 10;
        die   "Missing section Defaults->{'CREIS'}"
    }
     
    unless( $proj_const_mdsresult_template_href = $LIFT_PROJECT::Defaults->{'MDSRESULT'} ) {
        print "Missing section Defaults->{'MDSRESULT'}"; sleep 10;
        die   "Missing section Defaults->{'MDSRESULT'}"
    }
    
}

###########declare all variables used  
my ($MDB_file_selected, $curr_dir, $output_file,$opt_output_file,$ID,$mapping, $user_entered_output_file); #global variables which are shared by subroutines for creating TL, Par, ProjConst, Display Window 
my ($start_status, $InitResult_status, $GetSensorDetails_status, $ModuleName, $SensorName, $SensorDirection, $SensorType);
my ($GetSimDevices_status, $SimDevices_aref,$GetConstantEnvParams_status, $EnvName_Const, $EnvVals, $GetDynamicEnvParams_status, $EnvName_Dynamic);
my ($GetCrashEntityIterations_status, $CrashEntityIDs,    $CrashEntityNames, $State_Number, $exit_status);
my (@output_data,@parameter_array) = undef;
my ($output_project_const_file, $output_parameter_file, $output_TestList_file);
my $Prj_const_file = 'CREIS_ProjectConst'; #default project const file name
my $TC_name = 'TC_CREIS_StandardTest';#default TC name, also it is default par file name
my $TL_file = 'TL_CREIS'; #default TL file name
my $G_iteration = 10; #global iteration value 
my ($Iteration, $rows, $update_G_iteration, $update_iteration);
my (@CrashEntityNames_intermediate, @CrashEntityIDs_intermediate, @State_Number_intermediate, @Iteration_intermediate);  #contents of TL table
my $testlist_gen_flag = 0; # flag to signify the creation of TL successfully
my $display_PJ_const_flag = 0; #flag to avoid multiple opening of windows
my $display_TL_flag = 0; #flag to avoid multiple opening of windows
my $display_para_flag = 0; #flag to avoid multiple opening of windows
my $errortext;

#create a LOG file
open (LOG, ">CREIS_Utility_Log.txt") || die ("couldnot open CREIS_Utility_Log.txt\n");
print LOG "######################################################################\n";
print LOG "### CREIS CONFIGURATION GENERATOR GUI REPORT ###\n";
print LOG "######################################################################\n";

############################### Start Tk Window ################################
#Create Main window
my $mainwindow = new MainWindow;
$mainwindow->resizable(0,0);

#Size of main window display
$mainwindow->geometry("700x325");

################### Start Create frames in main window ############################
my $Headframe = $mainwindow -> Frame()->pack(-padx=>10,-pady=>10); #Frame contains the heading
my $Inputfileframe = $mainwindow -> Frame()->pack(-padx=>8,-pady=>8); #Frame contains the mdb file path
my $ProjectPathframe = $mainwindow -> Frame()->pack(-padx=>8,-pady=>8); #Frame contains the project folder path
my $Proj_const_file_frame = $mainwindow -> Frame()->pack(-padx=>8,-pady=>8); #Frame contains the Project Constant file Name and create button
my $TestList_file_frame = $mainwindow -> Frame()->pack(-padx=>8,-pady=>8); #Frame contains the Test List file Name and create button
my $Parameter_file_frame = $mainwindow -> Frame()->pack(-padx=>8,-pady=>8); #Frame contains the Parameter file Name and create button
my $ActionButtonframe = $mainwindow -> Frame->pack(-padx=>8,-pady=>8); #Frame contains Close and ResetAll buttons

my $Note_mainwindow_frame = $mainwindow -> Label(-text=>" Note : Create TestList first then Testcase Parameter file",
    -font=>"Courier 12") -> pack(-side => "bottom");

################### Header frame label in main window ############################
$Headframe->Label(-text => 'CREIS Configuration Generator ',-font=>"Verdana 12 bold italic underline")->pack();

######################### .mdb file frame ###########################
$Inputfileframe->Label(-text => '.mdb file path ')->pack(-side=>"left");
$Inputfileframe -> Entry("-width" => 70,"-textvariable" => \$MDB_file_selected,)->pack (-side=>"left");

$Inputfileframe -> Button
            ( "-text" => "Browse file",
              "-borderwidth"=> 3,
              "-command" => sub
                {
                  # browse for file
                  $MDB_file_selected = $mainwindow -> getOpenFile
                    (
                     "-filetypes"  =>
                      [
                      ["MDS DataBase", '.mdb'],
                      ["All files", '.*']
                      ],
                     "-title"      => "choose a .mdb file(*.mdb)",
                    );
                    if ( $MDB_file_selected )
                        {
                         # first check if the .mdb file is selected else throw a message asking for the .mdb file    
                            if ($MDB_file_selected =~ /\.mdb$/)
                            {
                              print LOG "mdb File Chosen :: $MDB_file_selected \n";

                            }
                            else
                            {
                                $mainwindow->messageBox(
                                                          '-icon'    => "error",#qw/error info question warning/
                                                          '-type'    => "OK",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                                                          '-title'   => 'Attention',
                                                          '-message' => "!Select .mdb file!"
                                                          ); 
                                $MDB_file_selected = "";
                            }
                        }
                    else
                        {
                          print "no filename!\n";
                          # prompt user
                          $mainwindow->messageBox(
                              '-icon'    => "error",#qw/error info question warning/
                              '-type'    => "OK",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                              '-title'   => 'Attention',
                              '-message' => "!Select .mdb file!"
                          );
                       }                     
                },
            )
->pack (-side=>'right',-padx=>'05');

######################### Project Folder Path frame ###########################
$ProjectPathframe->Label(-text => 'Project Folder Path ')->pack(-side=>"left");
$ProjectPathframe -> Entry("-width" => 50,"-textvariable" => \$curr_dir,)->pack (-side=>"left");
my $browse_flag =0;
$curr_dir = 'C:';
$ProjectPathframe -> Button
            ( "-text" => "Browse Folder",
              "-borderwidth"=> 3,
              "-command" => sub
                {
                    unless($browse_flag == 1)
                    {
                        $browse_flag = 1;
                        my $top = $mainwindow -> Toplevel();
                        $top->withdraw;

                        my $t = $top->Toplevel;
                        $t->title("Choose directory:");
                        my $ok = 0;

                        my $f = $t->Frame->pack(-fill => "x", -side => "bottom");

                        my $d;
                        $d = $t->Scrolled('DirTree',
                                          -scrollbars => 'osoe',
                                          -width => 35,
                                          -height => 20,
                                          -selectmode => 'browse',
                                          -exportselection =>1,
                                          -browsecmd => sub { $curr_dir = shift },
                                          -command => sub { $ok = 1; },
                                         )->pack(-fill => "both", -expand => 1);

                        $d->chdir($curr_dir);

                        $f->Button(-text => 'Ok',
                                   -command => sub { $browse_flag = 0;
                                                        $ok = 1;
                                                        destroy $top;
                                                        
                                                    })->pack(-side => 'left');
                        $f->Button(-text => 'Cancel',
                                   -command => sub { 
                                                    $browse_flag = 0;            
                                                    destroy $top; 
                                                    print "Project folder path is not selected\n";
                                                    if($curr_dir eq 'C:')
                                                    {
                                                    $mainwindow->messageBox(
                                                                              '-icon'    => "error",#qw/error info question warning/
                                                                              '-type'    => "OK",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                                                                              '-title'   => 'Attention',
                                                                              '-message' => "!Select Project folder path!");
                                                    }})->pack(-side => 'left');

                        $f->waitVariable(\$ok);

                        if ($ok == 1) {print LOG "The Project directory chosen :: '$curr_dir'\n"; }                        
                        
                        unless( -d "$curr_dir\\config")
                            {
                                print "$curr_dir\\config doesnot exists\n";

                                $mainwindow->messageBox(
                                                      '-icon'    => "error",#qw/error info question warning/
                                                      '-type'    => "OK",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                                                      '-title'   => 'Attention',
                                                      '-message' => "Project doesnot contain Config folder. Select valid LIFT project path"
                                                      );            
                            }
                        unless( -d "$curr_dir\\Testlists")
                            {
                                print "$curr_dir\\Testlists doesnot exists\n";

                                $mainwindow->messageBox(
                                                      '-icon'    => "error",#qw/error info question warning/
                                                      '-type'    => "OK",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                                                      '-title'   => 'Attention',
                                                      '-message' => "Project doesnot contain Testlists folder. Select valid LIFT project path"
                                                      );            
                            }
                        unless( -d "$curr_dir\\TC_par")
                            {
                                print "$curr_dir\\TC_par doesnot exists\n";

                                $mainwindow->messageBox(
                                                      '-icon'    => "error",#qw/error info question warning/
                                                      '-type'    => "OK",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                                                      '-title'   => 'Attention',
                                                      '-message' => "Project doesnot contain TC_par folder. Select valid LIFT project path"
                                                      );
                            }
                
                   }
                },
            )
->pack (-side=>'right',-padx=>'05');

######################### Create Project Constant File button ###########################
$Proj_const_file_frame->Label(-text=>"Project Const file name")->pack(-side=>"left");
$Proj_const_file_frame -> Entry("-width" => 30,"-textvariable" => \$Prj_const_file,)->pack(-side=>'left', -padx=>'0');
$Proj_const_file_frame->Label(-text=>".pm",-font=>"Verdana 8 bold")->pack(-side => "left",-padx=>'05',-pady=>'05');    

$Proj_const_file_frame -> Button
  (
  "-text" => "Create ProjConst File",
  "-borderwidth"=> 3,
  "-command" => sub
    { 
        # check if .mdb file is selected first or else throw message asking for the .mdb file selection 
        if(defined $MDB_file_selected)
        {
            # check if proj folder path is selected if not throw message asking for the path selection 
            if( $curr_dir ne 'C:' )
            {
                unless($display_PJ_const_flag)
                {
                    $display_PJ_const_flag = 1;
                    &CREIS_proj_constants ();
                }
            }                
            else
            {
                $mainwindow->messageBox(
                              '-icon'    => "error",#qw/error info question warning/
                              '-type'    => "OK",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                              '-title'   => 'Attention',
                              '-message' => "!Select Project Folder Path!"
                              );
            }
        }
        else 
        {    
            $mainwindow->messageBox(
                                      '-icon'    => "error",#qw/error info question warning/
                                      '-type'    => "OK",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                                      '-title'   => 'Attention',
                                      '-message' => "!Select .mdb file!"
                                      );    
        }                      
     }
  )
->pack (-side=>"right");    

######################### TestList file creation button function ###########################
$TestList_file_frame->Label(-text=>"Test List file name")->pack(-side=>"left");
$TestList_file_frame -> Entry("-width" => 30,"-textvariable" => \$TL_file,)->pack(-side=>'left', -padx=>'0');
$TestList_file_frame->Label(-text=>".txt",-font=>"Verdana 8 bold")->pack(-side => "left",-padx=>'05',-pady=>'03');

$TestList_file_frame -> Button
  (
  "-text" => "Create TestList FIle",
  "-borderwidth"=> 3,
  "-command" => sub { # execute when button is pressed  
            
        if(defined $MDB_file_selected)
        {
            if( $curr_dir ne 'C:')
            {
                unless($display_TL_flag)
                {
                    $display_TL_flag = 1;
                    &CREIS_TestList_gen ();
                }
            }                
            else
            {
                $mainwindow->messageBox(
                              '-icon'    => "error",#qw/error info question warning/
                              '-type'    => "OK",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                              '-title'   => 'Attention',
                              '-message' => "!Select Folder Path!"
                              );
            }
        }
        else 
        {                                      
            $mainwindow->messageBox(
                '-icon'    => "error", #qw/error info question warning/
                '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
                '-message' => "!Select .mdb file!"
            );
        }
    }
  )
->pack (-side=>"right");

######################### Parameter file creation function ###########################
$Parameter_file_frame->Label(-text=>"Parameter file name")->pack(-side=>'left');
$Parameter_file_frame -> Entry("-width" => 30,"-textvariable" => \$TC_name,'-state' => 'disabled')->pack (-side=>'left', -padx=>'0');
$Parameter_file_frame->Label(-text=>".par",-font=>"Verdana 8 bold")->pack(-side => "left",-padx=>'05',-pady=>'03');

$Parameter_file_frame -> Button
  (
  "-text" => "Create Parameter FIle",
  "-borderwidth"=> 3,
  "-command" => sub { # execute when button is pressed  
                        if(defined $MDB_file_selected)
                        {
                            if( defined $curr_dir)
                                {
                                    unless($display_para_flag)
                                    {
                                        $display_para_flag = 1;
                                        &CREIS_para_gen();
                                    }
                                }                
                                else
                                {
                                    $mainwindow->messageBox(
                                                  '-icon'    => "error",#qw/error info question warning/
                                                  '-type'    => "OK",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                                                  '-title'   => 'Attention',
                                                  '-message' => "!Select Folder Path!"
                                                  );
                                }                    
                        }
                        else 
                        {                                      
                            $mainwindow->messageBox(
                                '-icon'    => "error", #qw/error info question warning/
                                '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                                '-title'   => 'Attention',
                                '-message' => "!Select .mdb file first!"
                            );
                        }
                    }
    
  )
->pack (-side=>"right");

######################### close function ###########################
$ActionButtonframe -> Button
                        ( -text=>"Close","-borderwidth"=> 3,
                          -command => sub { destroy $mainwindow; } ) ->pack (-side=>"left");
                          
######################### ResetAll function ###########################
$ActionButtonframe -> Button
                        ( -text=>"ResetAll","-borderwidth"=> 3,
                            "-command" => sub
                                    { # execute when button is pressed  
                                        $MDB_file_selected = ""; # set scan_file to undefined
                                        $curr_dir = 'C:';
                                        $Prj_const_file = 'CREIS_ProjectConst'; #default project const file name
                                        $TC_name = 'TC_CREIS_StandardTest'; #default para file name
                                        $TL_file = 'TL_CREIS';#default testlist file name
                                        $G_iteration = 10;#back to default value
                                    }
    )->pack (-side=>"left");

MainLoop;

############################################################################################

=head CREIS_proj_constants

    Function Name    :: CREIS_proj_constants
    Description      :: This function reads Sensor Details, SIMDevice Details, Env Params from MDS database and creats creats proj_const_hash by.  
                        Default file name is CREIS_ProjectConst.pm and is saved at .\config\ in LIFT Project.

%creats proj_const_hash => "Mapping" => {
                                            "INPUT" => 
                                            {
                                                #Module: Sensor: Direction: Type:Version
                                                'ECU: Acc_HG: -X: SMA560_SYNC'                 => { 'device' => 'ECU_Acc_HG',    'Simulator' => 'Quate'    },
                                            },
                                            "OUTPUT" => 
                                            {
                                                # Simdevices & crash outputs
                                                'AB1FD'      => { 'MeasureBy' => 'TRANSI', 'Evaluation' => \&CREIS_EvaluateSquibFiring},  
                                            },

                                            "ENVIRONMENT"  => 
                                            {
                                                # environment states
                                                'BLFD_State' =>
                                                {
                                                   '0' => sub {
                                                       MLC_SetLogicalState('BLFD', 'UNLOCKED');
                                                   },
                                                   '1' => sub {
                                                       MLC_SetLogicalState('BLFD', 'LOCKED');
                                                   },
                                                },
                                            },
                                        };

=cut

############################################################################################

sub CREIS_proj_constants
{
    my $MDB_file_processed = $MDB_file_selected;
    $MDB_file_processed =~ s/\//\\/g;
    
    my $proj_const_creis_gen_hash; 
    my $proj_const_mdsresult_gen_hash; 

    print LOG "\n\n######################################################################\n";
    print LOG "### Creating Project Constants ###\n";
    print LOG "######################################################################\n";

    #Start the MDS database
    print LOG "CREIS_proj_constants :: Start mdsresult\n";
    $start_status = mdsresult_Start();
    if ( $start_status<0)
    {
        $errortext = mdsresult_GetErrorString($start_status<0);

        $mainwindow->messageBox(
        '-icon'    => "error", #qw/error info question warning/
        '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
        '-title'   => 'Attention',
        '-message' => "!Couldnot start MDS database!"
        );    

        print LOG "CREIS_proj_constants Failed :: Error Description :: $errortext \n";
        close (LOG);        
        destroy $mainwindow;     #close the GUI tool
    }    
    print LOG "CREIS_proj_constants :: mdsresult_Start :: status :: $start_status\n";
    #Loads the mdb file
    print LOG "CREIS_proj_constants :: Initialise mdsresult\n";

    $InitResult_status = mdsresult_InitResult($MDB_file_processed);
    if ( $InitResult_status <0)
    {
        $errortext = mdsresult_GetErrorString($InitResult_status<0);

        $mainwindow->messageBox(
        '-icon'    => "error", #qw/error info question warning/
        '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
        '-title'   => 'Attention',
        '-message' => "!Coundnot load the mdb file!"
        );    

        print LOG "CREIS_proj_constants Failed :: Error Description :: $errortext \n";
        close (LOG);        
        destroy $mainwindow;     #close the GUI tool
    }    
    print LOG "CREIS_proj_constants :: mdsresult_InitResult :: status :: $InitResult_status\n";
    #Fetch all Sensor Details from database
    print LOG "CREIS_proj_constants :: Fetch Sensor Details from database\n";
    ($GetSensorDetails_status, $ModuleName, $SensorName, $SensorDirection,$SensorType) = mdsresult_GetSensorDetails();

    if ( $GetSensorDetails_status<0)
    {
        $errortext = mdsresult_GetErrorString($GetSensorDetails_status);

        $mainwindow->messageBox(
        '-icon'    => "error", #qw/error info question warning/
        '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
        '-title'   => 'Attention',
        '-message' => "!Couldnot fetch Sensor Details from database!"
        );    

        print LOG "CREIS_proj_constants Failed :: Error Description :: $errortext \n";
        close (LOG);        
        destroy $mainwindow;     #close the GUI tool
    } 
    print LOG "CREIS_proj_constants :: mdsresult_GetSensorDetails :: status :: $GetSensorDetails_status\n";
    print LOG "CREIS_proj_constants :: mdsresult_GetSensorDetails :: ModuleName :: @$ModuleName \n";
    print LOG "CREIS_proj_constants :: mdsresult_GetSensorDetails :: SensorName :: @$SensorName \n";
    print LOG "CREIS_proj_constants :: mdsresult_GetSensorDetails :: SensorDirection :: @$SensorDirection \n";
    print LOG "CREIS_proj_constants :: mdsresult_GetSensorDetails :: SensorType :: @$SensorType \n";
    
    #Get all SIMDevice Details from database
    print LOG "CREIS_proj_constants :: Get all SIMDevice Details from database\n";
    ($GetSimDevices_status, $SimDevices_aref) = mdsresult_GetSimDevices();
    
    if ( $GetSimDevices_status<0)
    {
        $errortext = mdsresult_GetErrorString($GetSimDevices_status);

        $mainwindow->messageBox(
        '-icon'    => "error", #qw/error info question warning/
        '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
        '-title'   => 'Attention',
        '-message' => "!Couldnot fetch all SIMDevice Details from database!"
        );    
        print LOG "CREIS_proj_constants :: mdsresult_GetSimDevices :: status :: $GetSimDevices_status\n";
        print LOG "CREIS_proj_constants Failed :: Error Description :: $errortext \n";
        close (LOG);
        destroy $mainwindow;     #close the GUI tool
    } 

    print LOG "CREIS_proj_constants :: mdsresult_GetSimDevices :: status :: $GetSimDevices_status\n";
    print LOG "CREIS_proj_constants :: mdsresult_GetSimDevices :: SimDevices :: @{$SimDevices_aref} \n";
    
    #Get all Constant Env Params from database
    print LOG "CREIS_proj_constants :: Get all Constant Env Params from database\n";    
    ( $GetConstantEnvParams_status, $EnvName_Const, $EnvVals  ) = mdsresult_GetConstantEnvParams();

    if ( $GetConstantEnvParams_status < 0)
    {
        $errortext = mdsresult_GetErrorString($GetConstantEnvParams_status);

        $mainwindow->messageBox(
        '-icon'    => "error", #qw/error info question warning/
        '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
        '-title'   => 'Attention',
        '-message' => "!Couldnot fetch all Constant Env Params from database!"
        );    

        print LOG "CREIS_proj_constants Failed :: Error Description :: $errortext \n";
        close (LOG);
        destroy $mainwindow;     #close the GUI tool
    }
    print LOG "CREIS_proj_constants :: mdsresult_GetConstantEnvParams :: status :: $GetConstantEnvParams_status\n";    
    print LOG "CREIS_proj_constants :: mdsresult_GetConstantEnvParams :: EnvName_Const :: @$EnvName_Const \n";
    print LOG "CREIS_proj_constants :: mdsresult_GetConstantEnvParams :: EnvVals :: @$EnvVals \n";    

    ($GetDynamicEnvParams_status, $EnvName_Dynamic) = mdsresult_GetDynamicEnvParams();
    if ( $GetDynamicEnvParams_status < 0)
    {
        $errortext = mdsresult_GetErrorString($GetDynamicEnvParams_status);

        $mainwindow->messageBox(
        '-icon'    => "error", #qw/error info question warning/
        '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
        '-title'   => 'Attention',
        '-message' => "!Couldnot fetch all Dynamic Env Params from database!"
        );    

        print LOG "CREIS_proj_constants Failed :: Error Description :: $errortext \n";
        close (LOG);
        destroy $mainwindow;     #close the GUI tool
    }
    print LOG "CREIS_proj_constants :: mdsresult_GetDynamicEnvParams :: status :: $GetDynamicEnvParams_status\n";    
    print LOG "CREIS_proj_constants :: mdsresult_GetDynamicEnvParams :: EnvName_Dynamic :: @$EnvName_Dynamic \n";
    
    # Unloads the MDSResult Process DLL
    print LOG "CREIS_proj_constants :: Unload MDSResult DLL\n";
    $exit_status = mdsresult_CloseResult();
    if ( $exit_status<0)
    {
        $errortext = mdsresult_GetErrorString($exit_status);

        $mainwindow->messageBox(
        '-icon'    => "error", #qw/error info question warning/
        '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
        '-title'   => 'Attention',
        '-message' => "!Couldnot unload MDSResult DLL!"
        );    
        print LOG "CREIS_proj_constants Failed :: Error Description :: $errortext \n";
        close (LOG);
        destroy $mainwindow;     #close the GUI tool
    }
    print LOG "CREIS_proj_constants :: mdsresult_CloseResult :: status :: $exit_status\n";

    # hash slice ; is copying the hashes completely
    @{ $proj_const_creis_gen_hash }     { keys   %$proj_const_creis_template_href } 
                                        = values %$proj_const_creis_template_href;
                                        
    @{ $proj_const_mdsresult_gen_hash } { keys   %$proj_const_mdsresult_template_href } 
                                        = values %$proj_const_mdsresult_template_href;
    

    unless( defined $proj_const_mdsresult_gen_hash->{ "RESULTS" } { "DEFAULT" } ) {
        $errortext = "Missing key { MDSRESULT }{ RESULTS }{ DEFAULT }";
        $mainwindow->messageBox(
            '-icon'    => "error", #qw/error info question warning/
            '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
            '-title'   => 'Attention' ,
            '-message' => $errortext ,
        );    
        print LOG "CREIS_proj_constants Failed :: Error Description :: $errortext \n";
        close (LOG);
        destroy $mainwindow;
    }
    
    $proj_const_mdsresult_gen_hash->{ "RESULTS" } { "DEFAULT" }{ "PATH" }       = $MDB_file_processed;
    $proj_const_mdsresult_gen_hash->{ "RESULTS" } { "DEFAULT" }{ "MDSTYPE" }    = "MDSNG";
    
    my $sub = 'sub{}'; #to print 'sub' in the mapping hash
    for ( my $ndx = 0 ; $ndx < scalar(@$SensorDirection) ; $ndx++ ) 
    {

        my $Input_keys = qq/$$ModuleName[$ndx]: $$SensorName[$ndx]: $$SensorDirection[$ndx]: $$SensorType[$ndx]/;
        my $Input_values = qq/$$ModuleName[$ndx]_$$SensorName[$ndx]/;
        
        $proj_const_creis_gen_hash -> {'Mapping'}{'INPUT'}{$Input_keys}= { 'device' => $Input_values,'Simulator' => 'Quate'};
    };
    
    foreach my $Output_Device ( @$SimDevices_aref )
    {
        $proj_const_creis_gen_hash -> {'Mapping'}{'OUTPUT'}{$Output_Device} = { 'MeasureBy' => 'TRANSI', 'Evaluation' => 'XXXXX' };
    };    
    
    my @env_array_temp = (@$EnvName_Const,@$EnvName_Dynamic);#join both the environment parameters arrays
    for (my $ndx = 0 ; $ndx < scalar(@env_array_temp); $ndx++ ) 
    {
        $proj_const_creis_gen_hash -> {'Mapping'}{'ENVIRONMENT'}{$env_array_temp[$ndx]}= {  '0' => $sub, '1' => $sub },
    };

    $curr_dir =~ s/\\/\\/g;

    my $temp = $Prj_const_file.".pm";
    $output_project_const_file = "$curr_dir\\config\\$temp";
    
    if (-e $output_project_const_file)
    {
        print "$output_project_const_file exists\n";

        my $type_button = $mainwindow->messageBox(
                                                  '-icon'    => "question",#qw/error info question warning/
                                                  '-type'    => "YesNo",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                                                  '-title'   => 'Attention',
                                                  '-message' => "File $temp Exists, Do you want to over write it ?"
                                                  );    
        if ($type_button eq 'Yes')
        {
            open (PROJCONST, ">$output_project_const_file") || die "could not Overwrite $output_project_const_file file\n";
            print PROJCONST "## This file is generated using CREIS Configuration Generator Tool - $VERSION ##\n";
            print PROJCONST "## This file is generated from *.mdb: $MDB_file_selected ##\n\n";
            print PROJCONST "package LIFT_PROJECT;\n\n";
            $Data::Dumper::Terse = 1;
            $Data::Dumper::Useqq = 1;
            
            print PROJCONST '$Defaults -> {\'MDSRESULT\'} = '; 
            $Data::Dumper::Sortkeys = \&hash_sorter( $proj_const_mdsresult_gen_hash );    #sort the hash keys in alphabetical order
            print PROJCONST Dumper ( $proj_const_mdsresult_gen_hash );
            print PROJCONST "\;\n\n";

            
            print PROJCONST '$Defaults -> {\'CREIS\'} = '; 
            $Data::Dumper::Sortkeys = \&hash_sorter( $proj_const_creis_gen_hash );    #sort the hash keys in alphabetical order
            print PROJCONST Dumper ( $proj_const_creis_gen_hash );
            print PROJCONST "\;\n\n";
            print PROJCONST "1\;";
            
            close (PROJCONST);
        
            &Display_window($output_project_const_file);
        }
        else
        {
            &Display_window($output_project_const_file);
        }        
    }
    else
    {
        open (PROJCONST, ">$output_project_const_file") || die "couldnot Overwrite $output_project_const_file file\n";
        print PROJCONST "## This file is generated using CREIS Configuration Generator Tool - $VERSION ##\n";
        print PROJCONST "## This file is generated from *.mdb: $MDB_file_selected ##\n\n";
        print PROJCONST "package LIFT_PROJECT;\n\n";
        $Data::Dumper::Terse = 1;
        $Data::Dumper::Useqq = 1;

        print PROJCONST '$Defaults -> {\'MDSRESULT\'} = '; 
        $Data::Dumper::Sortkeys = \&hash_sorter( $proj_const_mdsresult_gen_hash );    #sort the hash keys in alphabetical order
        print PROJCONST Dumper ( $proj_const_mdsresult_gen_hash );
        print PROJCONST "\;\n\n";
        
        print PROJCONST '$Defaults -> {\'CREIS\'} = '; 
        $Data::Dumper::Sortkeys = \&hash_sorter( $proj_const_creis_gen_hash );    #sort the hash keys in alphabetical order
        print PROJCONST Dumper ( $proj_const_creis_gen_hash );
        print PROJCONST "\;\n\n";
        print PROJCONST "1\;";

        &Display_window($output_project_const_file);
    }
}

############################################################################################

=head CREIS_TestList_gen

    Function Name    :: CREIS_TestList_gen
    Description      :: This function fetches all Crash Entity details from database and creates testlist for the user required crashes.
                        Default file name is TL_CREIS.txt and is saved at .\Testlists\ in LIFT Project.

Eg : TC_Name.CrashEntityIDsCrashEntityNames_State_State_Number

=cut

############################################################################################

sub CREIS_TestList_gen
{
    my $MDB_file_processed = $MDB_file_selected;
    $MDB_file_processed =~ s/\//\\/g;

    print LOG "\n\n######################################################################\n";
    print LOG "### Creating TestList ###\n";
    print LOG "######################################################################\n";
    
    #open second window
    my $top = $mainwindow -> Toplevel(); 
                        
################################ TC frame in top window #####################
    my $TC_name_frm = $top->Frame()->pack(-padx=>8,-pady=>8);
    $TC_name_frm->Label(-text=>"TC Name")->pack(-side => "top")->pack(-side=>"left");
    $TC_name_frm -> Entry("-width" => 30,"-textvariable" => \$TC_name,)->pack (-side=>"left");
    my $TC_name_frm2 = $top->Frame()->pack(-padx=>8,-pady=>8);
    $TC_name_frm2->Label(-text=>"Global_Iteration")->pack(-side => "top")->pack(-side=>"left");
    $TC_name_frm2 -> Entry("-width" => 5,"-textvariable" => \$G_iteration,)->pack (-side=>"left");
    
    $TC_name_frm2->Label(-text=>"Check to Update Iteration column")->pack(-side => "top")->pack(-side=>"left");
    $update_G_iteration = $TC_name_frm2->Checkbutton(-variable => \$update_iteration,
                                                -command=>\&update_iteration_column)->pack(-anchor=>'w')->pack(-side=>"left");

################################ Test List frame in top window #####################                        
    my $TL_frm = $top->Frame()->pack(-padx=>8,-pady=>8);
    $TL_frm->Label(-text=>"Crash Details")->pack(-side => "top")->pack(-side=>"left");
    
    
################################ Test List frame in top window end #####################

    #Start the MDS database
    print LOG "CREIS_TestList_gen :: Start mdsresult\n";
    $start_status = mdsresult_Start();

    if ( $start_status<0)
    {
        $errortext = mdsresult_GetErrorString($start_status<0);

        $mainwindow->messageBox(
        '-icon'    => "error", #qw/error info question warning/
        '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
        '-title'   => 'Attention',
        '-message' => "!Couldnot start MDS database!"
        );    

        print LOG "CREIS_TestList_gen Failed :: Error Description :: $errortext \n";
        close (LOG);        
        destroy $mainwindow;     #close the GUI tool
    }    

    #Loads the mdb file
    print LOG "CREIS_TestList_gen :: Initialise mdsresult\n";
    $InitResult_status = mdsresult_InitResult($MDB_file_processed);
    if ( $InitResult_status <0)
    {
        $errortext = mdsresult_GetErrorString($InitResult_status<0);

        $mainwindow->messageBox(
        '-icon'    => "error", #qw/error info question warning/
        '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
        '-title'   => 'Attention',
        '-message' => "!Coundnot load the mdb file!"
        );    

        print LOG "CREIS_TestList_gen Failed :: Error Description :: $errortext \n";
        close (LOG);        
        destroy $mainwindow;     #close the GUI tool
    }    

    #Get all Crash Entity details from database
    print LOG "CREIS_TestList_gen :: fetch all Crash Entity details from database\n";

    ($GetCrashEntityIterations_status, $CrashEntityIDs, $CrashEntityNames, $State_Number) = mdsresult_GetCrashEntityIterations();

    if ( $GetCrashEntityIterations_status<0)
    {
        $errortext = mdsresult_GetErrorString($GetCrashEntityIterations_status);

        $mainwindow->messageBox(
        '-icon'    => "error", #qw/error info question warning/
        '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
        '-title'   => 'Attention',
        '-message' => "!Couldnot fetch all Crash Entity details from database!"
        );    

        print LOG "CREIS_TestList_gen Failed :: Error Description :: $errortext \n";
        close (LOG);        
        destroy $mainwindow;     #close the GUI tool
    }
    print LOG "CREIS_TestList_gen :: mdsresult_GetCrashEntityIterations :: CrashEntityIDs :: @$CrashEntityIDs \n";
    print LOG "CREIS_TestList_gen :: mdsresult_GetCrashEntityIterations :: CrashEntityNames :: @$CrashEntityNames \n";
    print LOG "CREIS_TestList_gen :: mdsresult_GetCrashEntityIterations :: State_Number :: @$State_Number \n";

    # Unloads the MDSResult Process DLL
    print LOG "CREIS_TestList_gen :: Unload MDSResult DLL\n";
    $exit_status = mdsresult_CloseResult();
    if ( $exit_status<0)
    {
        $errortext = mdsresult_GetErrorString($exit_status);

        $mainwindow->messageBox(
        '-icon'    => "error", #qw/error info question warning/
        '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
        '-title'   => 'Attention',
        '-message' => "!Couldnot unload MDSResult DLL!"
        );    

        print LOG "CREIS_TestList_gen Failed :: Error Description :: $errortext \n";
        close (LOG);
        destroy $mainwindow;     #close the GUI tool
    }
    
    my @cnames = ('Checkbox','CrashName','CrashID','StateNumber','Iteration');

    my $cols = $#cnames; #column size of the table

    my $rows_intermediate = scalar(@$State_Number); #row size intermediate calculated to create below intermediate arrays
    
    $rows = undef;
    for( my $p = 0; $p < scalar(@$State_Number);$p++)
    {
    $rows += $$State_Number[$p]; #row size of the table
    }
    for( my $i = 0; $i < $rows ;$i++)
    {
        $$Iteration[$i] = $G_iteration;
    }

    (@CrashEntityNames_intermediate, @CrashEntityIDs_intermediate, @State_Number_intermediate, @Iteration_intermediate) = (); #empty the array before use
    for( my $p = 0; $p < $rows_intermediate;$p++)
    {
        if ($$State_Number[$p] > 1)
        {
            for (my $c = 1; $c <= $$State_Number[$p];$c++)
            {
                $$CrashEntityNames[$p] =~ s/\W/\_/g;
                push (@CrashEntityNames_intermediate ,$$CrashEntityNames[$p]);
                push (@CrashEntityIDs_intermediate ,$$CrashEntityIDs[$p]);
                push (@State_Number_intermediate ,$c); #states shall be displayed in table as 1,2,... n if n>1
                push (@Iteration_intermediate ,$$Iteration[$p]);
            }
        }
        else
        {
            $$CrashEntityNames[$p] =~ s/\W/\_/g;
            push (@CrashEntityNames_intermediate ,$$CrashEntityNames[$p]);
            push (@CrashEntityIDs_intermediate ,$$CrashEntityIDs[$p]);
            push (@State_Number_intermediate ,$$State_Number[$p]);
            push (@Iteration_intermediate ,$$Iteration[$p]);;
        }
    }    

    #create table frame to display --> @cnames
    my $tableFrame = $top->Frame(-borderwidth => 2,
                                -relief => 'raised')->pack;
    $top->resizable(0,0);
    # allocate a table to the frame
    my $table = $tableFrame->Table(-columns => 8,
                                   -rows => 10,
                                   -fixedrows => 1,
                                   -scrollbars => 'se',
                                   -relief => 'raised');

    # column headings
    foreach my $c (0..$cols)
     {
            my $tmp = $table->Label(-text => $cnames[$c],
                                    -width => 16,
                                    -relief => 'raised');
            $table->put( 0, $c, $tmp );
    }

    # populate the cells and bind an action to each one
    my ($chk,@check,@select_temp);
    (@check,@select_temp) = ();
    foreach my $r ( 1 .. $rows )
    {
        my $tmp;
            foreach my $c ( 0 .. $cols )
            {
                if($c == 0)
                {
                    $chk = $table->Checkbutton(-variable => \$check[$r-1],
                                                 -onvalue => 'CHECKED',
                                                 -offvalue => 'NOT_CHECKED')->pack(-anchor=>'w')->pack(-side=>"left");
                    $select_temp[$r][$c] = $chk; 
                    $chk->bind('text', [ $table ]);
                     $table->put( $r, $c, $chk );
                }
                if($c == 1)    
                {
                    $tmp = $table->Label(-text => $CrashEntityNames_intermediate[$r-1], -padx => 2,
                                            -background => 'white',
                                           );
                    $select_temp[$r][$c] = $chk; 
                    $tmp->bind('text', [ $table ]);
                    $table->put( $r, $c, $tmp );
                }
                if($c == 2)    
                {
                    $tmp = $table->Label(-text => $CrashEntityIDs_intermediate[$r-1], -padx => 2,
                                            -background => 'white',
                                           );
                    $select_temp[$r][$c] = $chk; 
                    $tmp->bind('text', [ $table ]);
                    $table->put( $r, $c, $tmp );
                }
                if($c == 3)    
                {
                    $tmp = $table->Label(-text => $State_Number_intermediate[$r-1], -padx => 2,
                                            -background => 'white',
                                            );
                    $select_temp[$r][$c] = $chk; 
                    $tmp->bind('text', [ $table ]);
                    $table->put( $r, $c, $tmp );
                }    
                if($c == 4)    
                {
                    $tmp = $table->Entry("-width" => 5,"-textvariable" => \$$Iteration[$r-1],-state => 'normal')->pack (-side=>"left");
                    $select_temp[$r][$c] = $chk; 
                    $tmp->bind('text', [ $table ]);
                    $table->put( $r, $c, $tmp );

                }                
            }
    }
    $table->pack( -expand => 'yes', -fill => 'both');

################################ Preview frame in top window #####################
    my $preview_frm = $top->Frame()->pack(-padx=>8,-pady=>8);
    
    $preview_frm->Button( -text => "Check All",
                                    -width => 10,
                                    -command => sub 
                                                { for (my $r = 0; $r < $rows; $r++)
                                                    {$check[$r] = "CHECKED";}
                                                }
                        ) ->pack (-side=>"left");
                        
    $preview_frm->Button( -text => "uncheck All",
                                    -width => 10,
                                    -command => sub 
                                                { for (my $r = 0; $r < $rows; $r++)
                                                    {$check[$r] = "NOT_CHECKED";}
                                                }
                        ) ->pack (-side=>"left");
                
    $preview_frm -> Button
                        ( -text=>"Create",
                          -command => sub { 
                                            no warnings;
                                            if (grep {$_ eq  "CHECKED" } @check)
                                            {
                                              if ($TC_name)
                                                {
                                                    my $temp = $TL_file.'.txt';
                                                    $output_TestList_file = "$curr_dir\\Testlists\\$temp";    
                                                        if (-e $output_TestList_file)
                                                        {
                                                            print "$output_TestList_file exists\n";

                                                            my $type_button = $mainwindow->messageBox(
                                                                                                        '-icon'    => "question",#qw/error info question warning/
                                                                                                        '-type'    => "YesNo",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                                                                                                        '-title'   => 'Attention',
                                                                                                        '-message' => "File $temp Exists, Do you want to over write it ?"
                                                                                                    ); 
                                                            if ($type_button eq 'Yes')
                                                            {
                                                                open (TLFILE, ">$output_TestList_file") || die ("cannot Overwrite $output_TestList_file file\n");
                                                                print TLFILE "## This file is generated using CREIS Configuration Generator Tool - $VERSION ##\n";
                                                                print TLFILE "## This file is generated from *.mdb: $MDB_file_selected ##\n";
                                                                print TLFILE "# TestList structure : TC_name.CrashEntityIDs_CrashEntityNames_State_State_Number\n\n";
                                                                print TLFILE "ParameterTransferTest\n";
                                                                for (my $i = 0; $i < $rows;$i++)
                                                                {
                                                                    no warnings;    
                                                                    if($check[$i] eq "CHECKED")
                                                                    {
                                                                        for (my $j = 0; $j < $$Iteration[$i];$j++)
                                                                        {
                                                                            print TLFILE $TC_name.".".$CrashEntityIDs_intermediate[$i]."_".$CrashEntityNames_intermediate[$i]."_State_".$State_Number_intermediate[$i]."\n";
                                                                        }
                                                                    }
                                                                }
                                                                close(TLFILE);    
                                                                $testlist_gen_flag = 1; 
                                                                &Display_window($output_TestList_file);
                                                            }
                                                            else
                                                            {
                                                                &Display_window($output_TestList_file);
                                                            }
                                                        }
                                                        else
                                                        {
                                                            open (TLFILE, ">$output_TestList_file") || die ("cannot Overwrite $output_TestList_file file\n");
                                                                print TLFILE "## This file is generated using CREIS Configuration Generator Tool - $VERSION ##\n";
                                                                print TLFILE "## This file is generated from *.mdb: $MDB_file_selected ##\n";
                                                                print TLFILE "# TestList structure : TC_name.CrashEntityIDs_CrashEntityNames_State_State_Number\n\n";
                                                                for (my $i = 0; $i < $rows;$i++)
                                                                {
                                                                    no warnings;    
                                                                    if($check[$i] eq "CHECKED")
                                                                    {
                                                                        for (my $j = 0; $j < $$Iteration[$i];$j++)
                                                                        {
                                                                            print TLFILE $TC_name.".".$CrashEntityIDs_intermediate[$i]."_".$CrashEntityNames_intermediate[$i]."_State_".$State_Number_intermediate[$i],"\n";
                                                                        }
                                                                    }
                                                                }
                                                                close(TLFILE);    
                                                                $testlist_gen_flag = 1; 
                                                                &Display_window($output_TestList_file);
                                                        }        
                                                }
                                                else
                                                {
                                                    $mainwindow->messageBox(
                                                        '-icon'    => "error", #qw/error info question warning/
                                                        '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                                                        '-title'   => 'Attention',
                                                        '-message' => "!Enter TC Name!"
                                                        );
                                                }
                                            }
                                            else
                                            {
                                                $mainwindow->messageBox(
                                                        '-icon'    => "error", #qw/error info question warning/
                                                        '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                                                        '-title'   => 'Attention',
                                                        '-message' => "Please select the Crash Name(s) !"
                                                        );
                                            } 
                                   }
                        ) ->pack (-side=>"left");

    $preview_frm->Button( -text => "Close",
                                    -width => 10,
                                    -command => sub {$display_TL_flag = 0; destroy $top; }
                        ) ->pack (-side=>"left");                          
                        
}
############################################################################################

=head CREIS_para_gen

    Function Name    :: CREIS_para_gen
    Description      :: This function creates parameter file corresponding to the Testlist created.
                        This function shall be called after creating Testlist.
                        Default file name is TC_CREIS_StandardTest.par and is saved at .\TC_par\ in LIFT Project.
                        If the test case name is changed then the file name is automatically updated to the new name.

Eg : TC Name.CrashEntityIDsCrashEntityNames_State_State_Number
     CrashNumber = '1'
     CrashName = '102036'
     IterationNumber = '1'

=cut

############################################################################################

sub CREIS_para_gen
{
    my $MDB_file_processed = $MDB_file_selected;
    $MDB_file_processed =~ s/\//\\/g;

    print LOG "\n\n######################################################################\n";
    print LOG "### Creating Parameter File ###\n";
    print LOG "######################################################################\n";
    if($testlist_gen_flag)
    {
        my $temp = $TC_name.'.par';
        $output_parameter_file = "$curr_dir\\TC_par\\$temp";
        if (-e $output_parameter_file)
        {
            print "$output_parameter_file exists\n";

            my $type_button = $mainwindow->messageBox(
                                                        '-icon'    => "question",#qw/error info question warning/
                                                        '-type'    => "YesNo",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                                                        '-title'   => 'Attention',
                                                        '-message' => "File $temp Exists, Do you want to over write it ?"
                                                        );            
            if($type_button eq 'Yes')
            {
                open (PARAM, ">$output_parameter_file") || die ("cannot Overwrite file $output_parameter_file : $!\n");
            
                print PARAM "## This file is generated using CREIS Configuration Generator Tool - $VERSION ##\n";
                print PARAM "## This file is generated from *.mdb: $MDB_file_selected ##\n\n";
                for (my $i = 0; $i < scalar(@State_Number_intermediate);$i++)
                {
                    no warnings;
                    $parameter_array[$i] = $TC_name.".".$CrashEntityIDs_intermediate[$i]."_".$CrashEntityNames_intermediate[$i]."_State_".$State_Number_intermediate[$i],"\n";
                    print PARAM "[$parameter_array[$i]]\n";
                    print PARAM "MDSDB = '$MDB_file_processed'\n";
                    print PARAM "CrashNumber = '$CrashEntityIDs_intermediate[$i]'\n";
                    print PARAM "CrashName = '$CrashEntityNames_intermediate[$i]'\n";
                    print PARAM "IterationNumber = '$State_Number_intermediate[$i]'\n\n";
                }

                close(PARAM);
            
                &Display_window($output_parameter_file);
            }
            else
            {
                &Display_window($output_parameter_file);
            }
        }    
        else
        {
            open (PARAM, ">$output_parameter_file") || die ("cannot Overwrite file $output_parameter_file : $!\n");
        
            print PARAM "## This file is generated using CREIS Configuration Generator Tool - $VERSION ##\n";
            print PARAM "## This file is generated from *.mdb: $MDB_file_selected ##\n\n";

            for (my $i = 0; $i < scalar(@State_Number_intermediate);$i++)
            {
                no warnings;
                $parameter_array[$i] = $TC_name.".".$CrashEntityIDs_intermediate[$i]."_".$CrashEntityNames_intermediate[$i]."_State_".$State_Number_intermediate[$i],"\n";
                print PARAM "[$parameter_array[$i]]\n";
                print PARAM "MDSDB = '$MDB_file_processed'\n";
                print PARAM "CrashNumber = '$CrashEntityIDs_intermediate[$i]'\n";
                print PARAM "CrashName = '$CrashEntityNames_intermediate[$i]'\n";
                print PARAM "IterationNumber = '$State_Number_intermediate[$i]'\n\n";
            }

            close(PARAM);
        
            &Display_window($output_parameter_file);
        }  
        
    }
    else
    {
        $mainwindow->messageBox(
                                  '-icon'    => "error",#qw/error info question warning/
                                  '-type'    => "OK",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                                  '-title'   => 'Attention',
                                  '-message' => "!Create Test List First!"
                                  );        
    
    }
}

############################################################################################

=head Display_window

    Function Name    :: Display_window
    Description      :: This function opens the given file and displayes it on the window.
                        User cannot edit the contents displayed in this window. 

=cut

############################################################################################

sub Display_window
{
my $opt_output_file = shift;    
    
######################### Create Toplevel window ###########################
my $top = $mainwindow -> Toplevel();
$top->resizable(0,0);    
######################### Toplevel window label ###########################    
my $top_lab = $top -> Label(-text=>"Preview window",
    -font=>"ansi 12 bold") -> pack;

######################### Toplevel window text ###########################        
my $txt = $top -> Text(-width=>150, -height=>50)-> pack;

######################### Close button for Toplevel window  ###########################
my $top_CloseButton_frame = $top -> Frame()->pack(-padx=>8,-pady=>8);
    
    $top_CloseButton_frame -> Button
                        ( -text=>"Close",
                          -command => sub { 
                                            if($display_PJ_const_flag)
                                            {
                                                $display_PJ_const_flag = 0;
                                            }
                                            if($display_TL_flag)
                                            {
                                                $display_TL_flag = 0;
                                            }
                                            if($display_para_flag)
                                            {
                                                $display_para_flag = 0;
                                            }                            
                                            destroy $top;} 
                        ) ->pack (-side=>"left");

######################### Toplevel window label ###########################    
my $top_lab_botton = $top -> Label(-text=>" File Location : $opt_output_file",
    -font=>"Courier 12") -> pack(-side => "bottom");            
    {
        
        no warnings;
        open( TEMP , "$opt_output_file" )  || die ("cannot Open file $opt_output_file : $!\n");
        my @file = <TEMP>;

        for my $line (@file) 
        {
            $txt->insert('end', $line);
        }
        print TEMP $txt;
        close (TEMP);
        print color 'green';
        print "The $opt_output_file successfully Created\n";
        print LOG "successfully Created --> $opt_output_file \n";
        print color 'reset';
    }    
}

sub update_iteration_column
{
    if ($update_iteration)
    {
        for( my $i = 0; $i < $rows ;$i++)
        {
            $$Iteration[$i] = $G_iteration;
        }
        $update_iteration = 0;
    }
}
###################################################################################

=head hash_sorter

    Function Name    :: hash_sorter
    Description      :: This function returns an hash ref containing the hash keys to dump
                        in alphabetical order .

=cut

###################################################################################

sub hash_sorter 
{
        my ($hash) = @_;
        return (sort keys %$hash);    
}

###################################################################################


print LOG "\n######################################################################\n";
print LOG "END OF LOGFILE\n\n\n";    

close (LOG);