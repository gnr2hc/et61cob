#!usr\bin\perl.exe -w
# *****************************************************************************************************
#
#  Copyright (c) 2012  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#    $Source: EDR/EDR_Report_Validation/EDR_Report_Validation.pl $
#    $Revision: 1.4 $
#    $Author: Baeuerle Katharina (CC-PS/EPS2) (ZIK1ABT) $
#    $State: develop $
#    $Date: 2019/04/01 23:00:12ICT $
#******************************************************************************************************

#################################################################################
# this tool is under MKS version management
my $VERSION = q$Revision: 1.4 $;
my $HEADER  = q$Header: EDR/EDR_Report_Validation/EDR_Report_Validation.pl 1.4 2019/04/01 23:00:12ICT Baeuerle Katharina (CC-PS/EPS2) (ZIK1ABT) develop  $;
#################################################################################

use strict;
use warnings;
use Tk;
use Tk::Table;
use Tk::DirTree;
use Data::Dumper;
use warnings;
use File::Basename;
use File::Find;
use File::Path;
use Win32::File;
use Win32::Process;
use Win32;
use Data::Dumper;
use Win32::Console::ANSI;
use Term::ANSIColor;
use XML::LibXML;

#create a LOG file
open( LOG, ">EDR_Report_Validation_Log.txt" ) || die("could not open EDR_Report_Validation_Log.txt\n");
print LOG "######################################################################\n";
print LOG "### EDR REPORT VALIDATION PARAMETER GENERATOR LOG ###\n";
print LOG "######################################################################\n";

# gloabal variable testlist generation
my $allCrashes_aref;

# global variables for directories and file paths
my $projectConfigDirectory;
my $configFilePath;
my $creisXMLfilePath;
my $creisReportDirectory;
my $mdbFilePath;
my $mdbDirectory;
my $reportValidationParaDirectory;
my $validationPartOfTestlist_String;
my $batchFilePath;
my $processObj;
my $comProtocol;

# set above defined global variables
ReadConfigFile();


############################### Start Tk Window ################################
#Create Main window
my $main = MainWindow->new("-background" => "#888888");

# Size to the TK window 
$main->minsize(450,100);

$main->title("EDR Report Validation Parameter Generator ");

#Declare that there is a menu
my $mbar = $main -> Menu();
$main -> configure(-menu => $mbar);

#--- Main Buttons ---

    ## File Menu ##
my $file = $mbar -> cascade(-label=>"File", -underline=>0, -tearoff => 0);
$file -> command(-label =>"Exit", -underline => 1,
        -command => sub { exit } );

    ## Help Menu ##
my $help = $mbar -> cascade(-label =>"Help", -underline=>0, -tearoff => 0);
$help -> command(-label =>"ReadMe", -underline => 0, -command=>sub {CreateHelpWindow()});

# --- Project Config File path ---
my $frame_file_path_project_config = $main->Frame("-background" => "#888888")->pack(-pady=>'1',-padx=>'03', -anchor=>'nw' );

$frame_file_path_project_config -> Label(
        -text=>'',
        -background => "#888888",
         -foreground => "blue1",
        -font=>'{Segoe UI} 11 ') -> pack(-side=>'left');

$frame_file_path_project_config -> Entry(
									        -width=>'68',
									        -textvariable=>\$configFilePath,
									        -background => "grey",
									        ) -> pack(-side=>'right',-padx=>'05', -pady=>'03');

$frame_file_path_project_config -> Button(
					                        -text=>"Select project CFG",
					                        -width=>'18',
					                        -background => "DodgerBlue1",
					                        -foreground  => "white",
					                        -font=>'{Segoe UI Semibold} 10 ',
					                        -command=> sub{GetConfigFileName()}
                                            )->pack(-side => "left",-padx=>'05',-pady=>'03');

# --- CREIS XML ---
my $frame_file_path_CREIS_xml = $main->Frame("-background" => "#888888")->pack(-pady=>'1',-padx=>'03', -anchor=>'nw' );

$frame_file_path_CREIS_xml -> Label(
        -text=>'',
        -background => "#888888",
         -foreground => "blue1",
        -font=>'{Segoe UI} 11 ')->pack(-side=>'left');

$frame_file_path_CREIS_xml -> Entry(
                                            -width=>'68',
                                            -textvariable=>\$creisXMLfilePath,
                                            -background => "grey",
                                            ) -> pack(-side=>'right',-padx=>'05', -pady=>'03');

$frame_file_path_CREIS_xml -> Button(
                                            -text=>"Select CREIS XML",
                                            -width=>'18',
                                            -background => "DodgerBlue1",
                                            -foreground  => "white",
                                            -font=>'{Segoe UI Semibold} 10 ',
                                            -command=> sub{GetCREISxmlFileName()}
                                            )->pack(-side => "left",-padx=>'05',-pady=>'03');

# --- MDB File ---
my $frame_file_path_MDB = $main->Frame("-background" => "#888888")->pack(-pady=>'1',-padx=>'03', -anchor=>'nw' );
$frame_file_path_MDB -> Label(
        -text=>'',
        -background => "#888888",
         -foreground => "blue1",
        -font=>'{Segoe UI} 11 ')->pack(-side=>'left');

$frame_file_path_MDB -> Entry(
                                -width=>'68',
                                -textvariable=>\$mdbFilePath,
                                -background => "grey",
                              ) -> pack(-side=>'right',-padx=>'05', -pady=>'03');

$frame_file_path_MDB -> Button(
                                -text=>"Select crash MDB",
                                -width=>'18',
                                -background => "DodgerBlue1",
                                -foreground  => "white",
                                -font=>'{Segoe UI Semibold} 10 ',
                                -command=> sub{GetMdbFileName()}
                                ) -> pack(-side => "left",-padx=>'05',-pady=>'03');

# --- Report validation parameters ---
my $report_validation_para_path = $main->Frame("-background" => "#888888")->pack(-pady=>'1',-padx=>'03', -anchor=>'nw' );
$report_validation_para_path -> Label(
        -text=>'',
        -background => "#888888",
         -foreground => "blue1",
        -font=>'{Segoe UI} 11 ')->pack(-side=>'left');

$report_validation_para_path -> Entry(
                                -width=>'68',
                                -textvariable=>\$reportValidationParaDirectory,
                                -background => "grey",
                              ) -> pack(-side=>'right',-padx=>'05', -pady=>'03');

$report_validation_para_path -> Button(
                                -text=>"Select PAR folder",
                                -width=>'18',
                                -background => "DodgerBlue1",
                                -foreground  => "white",
                                -font=>'{Segoe UI Semibold} 10 ',
                                -command=> sub{GetReportValidationDirectory()} #GetReportValidationDirectory
                                ) -> pack(-side => "left",-padx=>'05',-pady=>'03');

my $comProtocolAndOptimizationSetting = $main->Frame("-background" => "#888888")->pack(-pady=>'1',-padx=>'03', -anchor=>'nw' );
$comProtocolAndOptimizationSetting -> Label(
        -text=>'Select COM Protocol ->',
        -width=>'21',
        -background => "DodgerBlue1",
         -foreground => "white",
        -font=>'{Segoe UI} 10.5 ')-> pack(-side => "left",-padx=>'10',-pady=>'03');

$comProtocolAndOptimizationSetting -> Optionmenu(
	-options => ['CAN', 'Flexray'],
#	-variable => \$comProtocol,
	-textvariable => \$comProtocol,
) -> pack(-side=>'left',-padx=>'05', -pady=>'03');

$comProtocolAndOptimizationSetting -> Label(
        -text=>'Optimize runtime',
        -width=>'21',
        -background => "DodgerBlue1",
         -foreground => "white",
        -font=>'{Segoe UI} 10.5 ')-> pack(-side => "left",-padx=>'10',-pady=>'03');


my $optimizeExecutionTime;
$comProtocolAndOptimizationSetting -> Checkbutton (
	-variable => \$optimizeExecutionTime,
)->pack(-side=>'left',-padx=>'05', -pady=>'03');

# --- Generate Paramters ---
my $frame_generate_params_button = $main->Frame("-background" => "#888888")->pack( -side => "right", -pady=>'03',-padx=>'05', -anchor=>'nw' );
my $crashParamsButton = $frame_generate_params_button -> Button(
                                -text=>"1. Generate Crash Parameters",
                                -width=>'25',
                                -background => "DarkMagenta",
                                -foreground  => "white",
                                -font=>'{Segoe UI Semibold} 10 ',
                                -command=> sub{GenerateParameterFile()},
                                ) -> pack(-side => "left", -padx=>'05',-pady=>'03');

# --- Generate Validation Testlist ---
my $testListButton = $frame_generate_params_button -> Button(
                                -text=>"2. Generate Validation Testlist",
                                -width=>'25',
                                -background => "DarkMagenta",
                                -foreground  => "white",
                                -font=>'{Segoe UI Semibold} 10 ',
                                -command=> sub{PrepareValidationTestlist()},
                                -state => 'disabled',
                                ) -> pack(-side => "left", -padx=>'05',-pady=>'03');

# --- Execute ---
my $executionButton = $frame_generate_params_button -> Button(
                                -text=>"3. Execute!",
                                -width=>'16',
                                -background => "DarkMagenta",
                                -foreground  => "white",
                                -font=>'{Segoe UI Semibold} 10 ',
                                -command=> sub{$processObj = ExecuteBatchFile()},
                                -state => 'disabled',
                                ) -> pack(-side => "right", -padx=>'05',-pady=>'03');

my $timer_id = $main -> repeat(500, \&check_running_execution);

MainLoop;


print LOG "\n######################################################################\n";
print LOG "END OF LOGFILE\n\n\n";

close(LOG);


################################ Sub functions ######################################
sub EnableAllButtons {
    $testListButton -> configure(-state => 'normal');
    $crashParamsButton -> configure(-state => 'normal');
    $executionButton -> configure(-state => 'normal');
    return 1;
}

sub DisableAllButtons {
    $testListButton -> configure(-state => 'disabled');
    $crashParamsButton -> configure(-state => 'disabled');
    $executionButton -> configure(-state => 'disabled');
    return 1;
}

sub check_running_execution {
    if($processObj){
        my $exitcode;
        $processObj -> GetExitCode($exitcode);
        if ( $exitcode != 259 ) {
            EnableAllButtons();
            kill -9,$processObj->GetProcessID();
        }
    }
    return 1;
}
###########################################
# Help Window Function
###########################################

sub CreateHelpWindow {
	my $mw = MainWindow->new("-background" => "#888888");
    $mw->minsize(100,25);
    $mw->title("Help");

    #Making a text area
    my $txt = $mw -> Scrolled('Text',-width => 100,-scrollbars=>'e') -> pack ();

    $txt->delete('1.0','end');
        $txt->insert('end','
#
#    DESCRIPTION:                               
#    This tool will generate parameter files and testlist
#    for report validation of PD EDR dumps taken during CREIS.           
#                                       
    '
    );

    return 1;
}

###########################################
# File Chooser Button functions
###########################################
sub GetFilePathAndDirectory {
	my $filetypes_aref = shift;
	my $fileOpenTitle = shift;
	my $initialDirectory = shift;

    if(not defined $initialDirectory){
        $initialDirectory = '.';
    }

    if(not defined $fileOpenTitle){
    	$fileOpenTitle = "Open File";
    }

    my $thisFilePath = $main -> getOpenFile(
                                    "-filetypes"  => $filetypes_aref,
                                    "-title"      => $fileOpenTitle ,
                                    "-initialdir" => $initialDirectory,
                                );

    my $thisDirectory;
    if($thisFilePath){
       my $path = dirname($thisFilePath);
       $thisDirectory = $path."/";
    }
    else {
    	return;
    }

	return ($thisFilePath, $thisDirectory);
}

sub GetConfigFileName {

    my $fileTypes = [["CFG file", '.pm'], ["All files", '.*']];
    my ($thisFilePath, $thisDirectory) = GetFilePathAndDirectory($fileTypes, "Select project CFG file", $projectConfigDirectory);
    if($thisFilePath){
        $configFilePath = $thisFilePath;
        $projectConfigDirectory = $thisDirectory;
    }
    UpdateConfigFile();

    return 1;
}

sub GetCREISxmlFileName {

    my $fileTypes = [["XML file", '.xml'], ["All files", '.*']];
    my ($thisFilePath, $thisDirectory) = GetFilePathAndDirectory($fileTypes, "Select CREIS XML file", $creisReportDirectory);
    if($thisFilePath){
        $creisXMLfilePath = $thisFilePath;
        $creisReportDirectory = $thisDirectory;
    }
    UpdateConfigFile();

    return 1;
}

sub GetMdbFileName {

    my $fileTypes = [["MDB file", '.mdb'], ["All files", '.*']];
    my ($thisMdbFilePath, $thisMdbDirectory) = GetFilePathAndDirectory($fileTypes, "Open crash database", $mdbDirectory);
    if($thisMdbFilePath){
    	$mdbFilePath = $thisMdbFilePath;
    	$mdbDirectory = $thisMdbDirectory;
    }
    UpdateConfigFile();

	return 1;
}

sub GetReportValidationDirectory {

    $reportValidationParaDirectory = $main->chooseDirectory();
    UpdateConfigFile();

    return 1;
}


###########################################
# Parameter file generation
###########################################
sub GenerateParameterFile {
	print LOG "Creating parameter file...\n";
	my $tcName = "TC_EDR_CREIS_DataRetrieval";
	my $paraFileName = $tcName.".par";

    print LOG "\tCheck whether TC_par exists\n";
	unless(-e $reportValidationParaDirectory){
	    $main -> messageBox(
	                '-icon'    => "error",                                           #qw/error info question warning/
	                '-type'    => "OK",                                              #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
	                '-title'   => 'ERROR',
	                '-message' => "Project config directory is not valid.\n".
	                              "Please check whether the chosen project config file is part of a TurboLIFT sandbox.\n".
	                              "Config file must lie in 'config' folder of sandbox!");
        print LOG "\tTC_par doesn't exist, abort parameter file generation\n";
	    return 1;
	}

    # CREIS XML
    unless(-e $creisXMLfilePath){
        $main -> messageBox(
                    '-icon'    => "error",                                           #qw/error info question warning/
                    '-type'    => "OK",                                              #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                    '-title'   => 'ERROR',
                    '-message' => "CREIS XML file not valid.\n".
                                  "Please select a valid CREIS XML file before continuing!");
        return 1;
    }

    # Crash mdb
    unless(-e $mdbFilePath){
       $main -> messageBox(
                    '-icon'    => "error",                                           #qw/error info question warning/
                    '-type'    => "OK",                                              #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                    '-title'   => 'ERROR',
                    '-message' => "MDB file path not valid.\n".
                                  "Please select a valid MDB XML file before continuing!");
        return 1;
    }

    my $paraFilePath = $reportValidationParaDirectory."\\".$paraFileName;
    if(-e $paraFilePath){
        my $messageResponse = $main -> messageBox(
                    '-icon'    => "question",                                           #qw/error info question warning/
                    '-type'    => "YesNo",                                              #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                    '-title'   => 'Parameter file exists',
                    '-message' => "The parameter file $paraFileName already exists.\n".
                                  "Do you want to overwrite it?");
       print LOG "\t$paraFileName exists, overwrite existing parameter file: $messageResponse\n";
       return 1 if($messageResponse eq 'No');
    }

    print LOG "\tGet parameter and testlist info from CREIS XML\n";
    my $paraFileText;
    ($paraFileText, $allCrashes_aref) = GetParamsAndTestlistFromXML($tcName);

    print LOG "\tOpen file $paraFilePath\n";
    open(PARA, ">$paraFilePath") || die("could not open $paraFilePath\n");
    print PARA "# Parameter file generated with EDR_Report_Validation.pl\n";
    print PARA "# $paraFileName\n";
    print PARA "\n";
    print PARA "\n";
    print PARA $paraFileText;
    close(PARA);

    print LOG "Finish creating parameter file...\n";

    $testListButton -> configure(-state => 'normal');

	return 1;
}

sub GetParamsAndTestlistFromXML {
	my $tcName = shift;

    my $parser = XML::LibXML->new();

    # important for formatting
    $parser->keep_blanks(0);
    # load the existing XML file
    my $creisSummaryXML = $parser->load_xml( location => $creisXMLfilePath );
    # get the reference to root element
    my $rootElement = $creisSummaryXML->documentElement;
    my $xpc         = XML::LibXML::XPathContext->new($rootElement);

    my @crashNodes = $xpc -> findnodes("./Crash");
    my $paraFileText;
    my @allCrashes;
    foreach my $crashNode (@crashNodes)
    {
        my $crashName = $crashNode -> getAttribute('name');
        my $crashID = $crashNode -> getAttribute('id');
        my $envState = $crashNode -> getAttribute('envstate');
        my $iteration = $crashNode -> getAttribute('iteration');
        my $cleanedCrashName = $crashName; # clean crash name for par file
        $cleanedCrashName =~ s/�/ae/g;
	    $cleanedCrashName =~ s/�/oe/g;
	    $cleanedCrashName =~ s/�/ue/g;
	    $cleanedCrashName =~ s/�/Ae/g;
	    $cleanedCrashName =~ s/�/Oe/g;
	    $cleanedCrashName =~ s/�/Ue/g;
	    $cleanedCrashName =~ s/�/ss/g;
	    $cleanedCrashName =~ s/\W/\_/g;
	    $cleanedCrashName =~ s/_+/_/g;

        my $testcaseLabel = "$crashID\_$cleanedCrashName\_State_$envState\_Iteration_$iteration";
        my $length = length($testcaseLabel);
        if(length($testcaseLabel) > 60){ #allow max 60 characters for par name
        	$testcaseLabel = "CrashNumber_$crashID\_State_$envState\_Iteration_$iteration";
        	print LOG "New test case label for crash $crashName due to length: $testcaseLabel\n";
        }
        $testcaseLabel =~ s/;/_/g;
        $paraFileText .= "[$tcName\.$testcaseLabel]\n".
                         "MDSDB = '$mdbFilePath'\n".
                         "CrashNumber = '$crashID'\n".
                         "CrashName = '$crashName'\n".
                         "IterationNumber = '$iteration'\n".
                         "EnvironmentState = '$envState'\n".
                         "CREISTest_summary_XML = '$creisXMLfilePath'\n".
                         "COM_Protocol = '$comProtocol'\n".
                         "\n";
        push(@allCrashes, $testcaseLabel);
    }

    return ($paraFileText, \@allCrashes);
}

###########################################
# Testlist generation
###########################################
sub PrepareValidationTestlist {
	if(not defined $allCrashes_aref){
        $main -> messageBox(
                    '-icon'    => "error",                                           #qw/error info question warning/
                    '-type'    => "OK",                                              #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                    '-title'   => 'ERROR',
                    '-message' => "Generate crash parameters first!\n");
		return 1;
	}

    unless(-e $reportValidationParaDirectory){
        $main -> messageBox(
                    '-icon'    => "error",                                           #qw/error info question warning/
                    '-type'    => "OK",                                              #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                    '-title'   => 'ERROR',
                    '-message' => "Select folder where validation parameters are stored!\n");
        return 1;
    }

    # Start creation of parameters for validation
    # For each crash, 1 testlist with all the .par entries from Report_Validation folder will be created
    # Batch file created which calls all testlists
    opendir (PARA_DIR, $reportValidationParaDirectory) || die("could not open report validation parameter directory '$reportValidationParaDirectory'\n");
    my @allFiles = readdir(PARA_DIR);
    closedir(PARA_DIR);

    my $allValidationTestCasesEDID_href;
    $validationPartOfTestlist_String = undef;
    foreach my $file (@allFiles){
        my $fileNameFull = $reportValidationParaDirectory."\\".$file;
        print LOG "Loading $fileNameFull\n";
        if( open( PAR_FILE, "<$fileNameFull")){
        	my $currentValidationTestCase;
            while (my $row = <PAR_FILE>) {
              chomp $row;
              next if($row =~ m/\[TC_EDR_CREIS_DataRetrieval(.*)/);
              if($row =~ m/^\[(.*)\]/){
              	  if($currentValidationTestCase){
                    print LOG "EDID is unknown for TC $currentValidationTestCase \n";
              	  	$allValidationTestCasesEDID_href -> {$currentValidationTestCase} = 0;
              	  	$currentValidationTestCase = undef;
              	  }
                  $currentValidationTestCase = $1;
              }
              if($row =~ /^EDID\s/){
              	$row =~ m/^EDID\s=\s'(\d+)'(.*)/;
              	my $edidID = $1;
              	unless($edidID){
                    $row =~ m/^EDID\s=\s(\d+)(.*)/;
                    $edidID = $1;
                    next unless($edidID);
              	}
              	print LOG "EDID is $edidID for TC $currentValidationTestCase \n";
              	$allValidationTestCasesEDID_href -> {$currentValidationTestCase} = $edidID;
              	$currentValidationTestCase = undef;
              }
            }
            close( PAR_FILE );
        }
        else{
            print LOG "Could not open $fileNameFull";
        }
    }

    foreach my $testCase (sort {$allValidationTestCasesEDID_href->{$a} <=> $allValidationTestCasesEDID_href->{$b}} keys %{$allValidationTestCasesEDID_href})
    {
    	$validationPartOfTestlist_String .= $testCase."\n";
    }

    my $testList_Window = MainWindow->new("-background" => "#888888");
    my $listbox_object = $testList_Window ->Scrolled("Listbox", -width => 80, -height => 50, -scrollbars => "e",
                    -selectmode => "extended")->pack( );

    $testList_Window->bind('<MouseWheel>',=>[sub{$listbox_object->yview('scroll', -($_[1] / 120) * 3, 'units')}, Ev('D')]); #Listbox reacts to scrolling with mouse wheel (on Windows only)

    $listbox_object -> insert('end', @{$allCrashes_aref});

    $testList_Window -> Button( -text=>"Create Testlist!!",
                                -width=>'10',
                                -background => "DarkMagenta",
                                -foreground  => "white",
                                -font=>'{Segoe UI Semibold} 10 ',
                                -command=> sub{GenerateValidationTestlist($listbox_object); $testList_Window -> destroy;}
                                ) -> pack(-padx=>'05',-pady=>'03', -side => 'bottom', -expand => 1, -fill => 'x');
    my $entryRandNbr = $testList_Window -> Entry( -width => '4' );
    $testList_Window -> Button( -text=>"Random Nbr",
                                -width=>'10',
                                -background => "DarkMagenta",
                                -foreground  => "white",
                                -font=>'{Segoe UI Semibold} 10 ',
                                -command=> sub{SelectNbrOfRandomCrashes($listbox_object, $entryRandNbr);}
                                ) -> pack(-side => 'left',-pady=>'03', -padx=>'05');
    $entryRandNbr -> pack(-side => 'left', -expand => 0,-pady=>'03');

    my $entryIterationNbr = $testList_Window -> Entry( -width => '4' );
    $testList_Window -> Button( -text=>"Iteration Nbr",
                                -width=>'10',
                                -background => "DarkMagenta",
                                -foreground  => "white",
                                -font=>'{Segoe UI Semibold} 10 ',
                                -command=> sub{SelectOneIterationOfEach($listbox_object, $entryIterationNbr);}
                                ) -> pack(-side => 'left', -padx=>'05',-pady=>'03', -anchor => 'center');
    $entryIterationNbr ->pack(-side => 'left', -expand => 0,-pady=>'03');

   $testList_Window -> Button(  -text=>"Deselect all",
                                -width=>'10',
                                -background => "DarkMagenta",
                                -foreground  => "white",
                                -font=>'{Segoe UI Semibold} 10 ',
                                -command=> sub{DeselectAllCrashes($listbox_object);}
                                ) -> pack(-side => 'right', -expand => 0,-padx=>'05',-pady=>'03');



	return 1;
}

sub DeselectAllCrashes {
    my $listbox_object = shift; #list box object

    $listbox_object -> selection('clear', 0, 'end');
    return 1;
}

sub SelectNbrOfRandomCrashes{
    my $listbox_object = shift; #list box object
    my $entryRandomNbr_object = shift;

    my $nbrOfRandom = $entryRandomNbr_object -> get();
    return 1 unless($nbrOfRandom);
    my $nbrOfElements = $listbox_object -> index('end');
    foreach my $number (1..$nbrOfRandom)
    {
        my $listBoxIndex = rand($nbrOfElements - 1);
        $listbox_object -> selection('set', $listBoxIndex);
    }

    return 1;
}

sub SelectOneIterationOfEach {
    my $listbox_object = shift; #list box object
    my $entryIteration_object = shift;

    my $selectedIterationNumber = $entryIteration_object -> get();
    unless($selectedIterationNumber){
        $selectedIterationNumber = 1;
    }

    my $listBoxIndex = 0;
    foreach my $listBoxElement($listbox_object->get(0,'end'))
    {
        my @crashName = split(/Iteration_/, $listBoxElement);
        my $iterationNbr = $crashName[1];
        my $firstPartOfCrashName = $crashName[0];
        if( $iterationNbr !=  $selectedIterationNumber){
            $listBoxIndex++;
            next;
        }
        print $firstPartOfCrashName."\n";
        $listbox_object -> selection('set', $listBoxIndex);
        $listBoxIndex++;
    }

    return 1;
}

sub GenerateValidationTestlist {
    my $listbox_object = shift; #list box object

    my @selectedCrashes;
    @selectedCrashes = $listbox_object->curselection;

    my $testlistDirectory = $projectConfigDirectory."\\..\\Testlists\\Report_Validation\\";
    mkdir($testlistDirectory) unless(-e $testlistDirectory);
    my $batchFileDirectory = $projectConfigDirectory."\\..\\";

    my @createdTestLists;
    my $nbrOfCrashes = @selectedCrashes;
    my $lastCrashIndex = $selectedCrashes[-1]; 
    $optimizeExecutionTime = 0 unless(defined $optimizeExecutionTime);

    foreach my $crashIndex (@selectedCrashes)
    {
        # Create Testlist
        my $testListLabel = $allCrashes_aref -> [$crashIndex];
        my $thisCrashNumber = $crashIndex + 1;
        push(@createdTestLists, $testListLabel.".txt");
        open (TESTLIST, ">".$testlistDirectory.$testListLabel.".txt");
        print TESTLIST "TC_EDR_CREIS_DataRetrieval".".".$testListLabel."\n";
        print TESTLIST "$validationPartOfTestlist_String";
        print TESTLIST "TC_EDR_CREIS_Generate_XLSX_Report\n" if($optimizeExecutionTime == 0);
        print TESTLIST "TC_EDR_CREIS_Generate_XLSX_Report\n" if($optimizeExecutionTime == 1 and $crashIndex == $lastCrashIndex);
        close (TESTLIST);
    }

    unless(-e $configFilePath){
        $main -> messageBox(
                    '-icon'    => "error",                                           #qw/error info question warning/
                    '-type'    => "OK",                                              #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                    '-title'   => 'ERROR',
                    '-message' => "Project config file does not exist\n".
                                  "Batch file for automated execution can't be created!");
        print LOG "\tConfig file doesn't exist - batch file can't be created\n";
        return 1;
    }
    my @configFilePath = split(/\//, $configFilePath);
    my $thisConfigFileName = $configFilePath[-1];

    open (BATFILE, ">".$batchFileDirectory."EDR_Offline_Report_Validation.bat");
    print BATFILE 'cd /d %~dp0';
    print BATFILE "\n\n";
    foreach my $testList (@createdTestLists)
    {
        print BATFILE "rem #### $testList ####\n";
        print BATFILE "call .\\Engine\\LIFT_exec_engine.pl ^\n";
        print BATFILE "\t-tc_para ".$reportValidationParaDirectory." ^\n";
        print BATFILE "\t-testlist .\\Testlists\\Report_Validation\\".$testList." ^\n";
        print BATFILE "\t-conf .\\config\\".$thisConfigFileName." ^\n";
        print BATFILE "\t-IC IC_Only_Eval ^\n\t-EC EC_Only_Eval ^\n\t-minimalsnapshot ^\n";
        print BATFILE "\t-exec_options_file .\\config\\LIFT_ExecOptions.pm ^\n\t-use_exec_options \"EDR\" ^\n";
        print BATFILE "\t-polite ^\n";
        print BATFILE "\n\n";
    }
    close (BATFILE);
    $batchFilePath = $batchFileDirectory."EDR_Offline_Report_Validation.bat";
    $executionButton -> configure(-state => 'normal');
    return 1;
}

###########################################
# Read and update config file default.cfg
###########################################
sub UpdateConfigFile {
       open( CFG, ">default.cfg" ) || die("could not open default.cfg\n");
       print CFG '$PRJ_CFG_DIR = \''.$projectConfigDirectory."\';\n";
       print CFG '$CFG_FILE_PATH = \''.$configFilePath."\';\n";
       print CFG '$CREIS_REPORT_DIR = \''.$creisReportDirectory."\';\n";
       print CFG '$CREIS_XML_PATH = \''.$creisXMLfilePath."\';\n";
       print CFG '$CRASH_MDB_DIR = \''.$mdbDirectory."\';\n";
       print CFG '$CRASH_MDB_PATH = \''.$mdbFilePath."\';\n";
       print CFG '$VALIDATION_PARA_DIR = \''.$reportValidationParaDirectory."\';\n";
       close(CFG);
       return 1;
}

sub ReadConfigFile {
	{ package Config; do "default.cfg" };
    $projectConfigDirectory = $Config::PRJ_CFG_DIR;
    $configFilePath = $Config::CFG_FILE_PATH;
    $creisReportDirectory = $Config::CREIS_REPORT_DIR;
    $creisXMLfilePath = $Config::CREIS_XML_PATH;
    $mdbDirectory = $Config::CRASH_MDB_DIR;
    $mdbFilePath = $Config::CRASH_MDB_PATH;
    $reportValidationParaDirectory = $Config::VALIDATION_PARA_DIR;
    return 1;
}

sub ExecuteBatchFile {

    no strict;
    my $ProcessObj;
    Win32::Process::Create($ProcessObj,
        $batchFilePath,
        $batchFilePath,0,
        NORMAL_PROIRITY_CLASS,
        ".") || die;

    my $child_pid = $ProcessObj -> GetProcessID();

    if($child_pid!=0) {
        print LOG "Started execution process id $child_pid\n";
        $main -> messageBox(
                    '-icon'    => "info",                                           #qw/error info question warning/
                    '-type'    => "OK",                                              #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                    '-title'   => 'EXECUTION STARTED',
                    '-message' => "Execution now started with selected testlist and parameters\n".
                                  "Have fun with the results :)\n".
                                  "\n".
                                  "Note: You will not be able to generate EDR offline parameters or execute any TurboLIFT script until the current execution is finished!");
        print LOG "\tExecution started!\n";
        DisableAllButtons();
        return($ProcessObj)
    }
    else{
        $main -> messageBox(
                    '-icon'    => "error",                                           #qw/error info question warning/
                    '-type'    => "OK",                                              #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                    '-title'   => 'ERROR',
                    '-message' => "Test Execution could not be started successfully :(");
        print LOG "\tExecution could not be started!\n";
    }
    return 1;
}

__END__
