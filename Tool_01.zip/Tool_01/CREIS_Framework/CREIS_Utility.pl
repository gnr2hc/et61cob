#!usr\bin\perl.exe -w
# *****************************************************************************************************
#
#  Copyright (c) 2012  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#    $Source: CREIS_Framework/CREIS_Utility.pl $
#    $Revision: 1.38 $
#    $Author: Schwibus Dirk (CC-PS/EPS2) (SDW2BUE) $
#    $State: develop $
#    $Date: 2019/07/12 16:04:15ICT $
#******************************************************************************************************

#################################################################################
# this tool is under MKS version management
my $VERSION = q$Revision: 1.38 $;
my $HEADER  = q$Header: CREIS_Framework/CREIS_Utility.pl 1.38 2019/07/12 16:04:15ICT Schwibus Dirk (CC-PS/EPS2) (SDW2BUE) develop  $;
#################################################################################

use strict;
use Tk;
use Tk::Table;
use Tk::DirTree;
use Data::Dumper;
use warnings;
use File::Basename;
use Data::Dumper;
use Win32::Console::ANSI;
use Term::ANSIColor;

my $addpath;

BEGIN {
    use Config;
    use File::Spec;
    use File::Basename;

    # find the LIFT engine path (LIFT_engine_path = ./../)
    my $LIFT_exec_path = File::Spec->rel2abs( dirname( dirname(__FILE__) ) ) . "/Engine";

    unshift @INC, "$LIFT_exec_path/modules/";
    unshift @INC, "$LIFT_exec_path/modules/TC_FunctionLib";
    unshift @INC, "$LIFT_exec_path/modules/TC_FunctionLib/TC_CustLib";
    unshift @INC, "$LIFT_exec_path/modules/TC_FunctionLib/TC_Project";
    unshift @INC, "$LIFT_exec_path/modules/TC_FunctionLib/TC_TNT";

    # add directories to search path for perl modules
    $addpath = "$LIFT_exec_path/modules/DLLs/MDSResult";
    my $perl56 = $addpath . "/Perl56";    #perl 5.6(32-bit) DLL directory
    my $win32  = $addpath . "/Win32";     #perl 5.12, 32-bit DLL directory
    my $win64  = $addpath . "/Win64";     #perl 5.12, 64-bit DLL directory

    if ( $] =~ m/5.006/i ) {              #if Perl version is 5.6
        unshift @INC, ( $addpath, $perl56 );    #Include MDSResult.pm from Root directory, Load MDSResult.dll from "Perl56"
        $ENV{PATH} = $win32 . ";$ENV{PATH}";    #Load MDSResult.dll from "Win32"
    }
    elsif ( $] =~ m/5.012/i ) {                 #if Perl version is 5.12
        if ( $Config{'archname'} =~ m/x64/i ) {    #check the bitness of perl (32-bit or 64-bit)
            unshift @INC, ( $addpath, $win64 );    #Include MDSResult.pm from Root directory, Load MDSResult.dll from "Win64"
            $ENV{PATH} = $win64 . ";$ENV{PATH}";   #Load MDSResult.dll from "Win64"
        }
        else {
            unshift @INC, ( $addpath, $win32 );    #Include MDSResult.pm from Root directory, Load MDSResult.dll from "Win32"
            $ENV{PATH} = $win32 . ";$ENV{PATH}";   #Load MDSResult.dll from "Win32"
        }
    }
}

my $proj_const_crash_simulation_template_href;
my $proj_const_crash_meas_eval_template_href;
my $proj_const_mdsresult_template_href;

use MDSResult;

###########declare all variables used
my ( $MDB_file_selected, $cREIS_Mapping_selected, $curr_dir, $output_file, $opt_output_file, $ID, $mapping, $user_entered_output_file );    #global variables which are shared by subroutines for creating TL, Par, ProjConst, Display Window
my ( $start_status,         $InitResult_status, $GetSensorDetails_status,     $ModuleName,    $SensorName, $SensorDirection,            $SensorType );
my ( $GetSimDevices_status, $SimDevices_aref,   $GetConstantEnvParams_status, $EnvName_Const, $EnvVals,    $GetDynamicEnvParams_status, $EnvName_Dynamic );
my ( $GetCrashEntityIterations_status, $CrashEntityIDs, $CrashEntityNames, $State_Number, $exit_status );
my ( @output_data, @parameter_array ) = undef;
my ( $output_project_const_file, $output_parameter_file, $output_TestList_file );
my $Prj_const_file = 'Mapping_CREIS';                                                                                                       #default project const file name
my $TC_name        = 'TC_CREIS_StandardTest';                                                                                               #default TC name, also it is default par file name
my $TL_file        = 'TL_CREIS';                                                                                                            #default TL file name
my $G_iteration    = 1;                                                                                                                     #global iteration value
my ( $Iteration, $rows, $update_G_iteration, $update_iteration );
my ( @CrashEntityCleanNames_intermediate, @CrashEntityNames_intermediate, @CrashEntityIDs_intermediate, @State_Number_intermediate, @Iteration_intermediate );    #contents of TL table
my $testlist_gen_flag     = 0;            # flag to signify the creation of TL successfully
my $display_PJ_const_flag = 0;            #flag to avoid multiple opening of windows
my $display_TL_flag       = 0;            #flag to avoid multiple opening of windows
my $display_para_flag     = 0;            #flag to avoid multiple opening of windows
my $forceNewMapping       = 0;
my $buttonlock            = "disabled";
my $errortext;
my $proj_const_mdsresult_gen_href;
my $proj_const_crash_simulation_gen_href;
my $proj_const_crash_meas_eval_gen_href;
my $remainingSections_href;

#create a LOG file
my $LOG_file_name = File::Spec->rel2abs("CREIS_Utility_Log.txt");
open( LOG, ">$LOG_file_name" ) || die("couldnot open CREIS_Utility_Log.txt\n");
print LOG "######################################################################\n";
print LOG "### CREIS CONFIGURATION GENERATOR GUI REPORT ###\n";
print LOG "######################################################################\n";

my $TODO_file_name = File::Spec->rel2abs("CREIS_TODO.txt");
open( TODO, ">$TODO_file_name" ) || die("couldnot open CREIS_TODO.txt\n");
print TODO "######################################################################\n";
print TODO "###            CREIS CONFIGURATION GENERATOR - TODO List           ###\n";
print TODO "######################################################################\n";

############################### Start Tk Window ################################
#Create Main window
my $mainwindow = new MainWindow;
$mainwindow->resizable( 0, 0 );

#Size of main window display
$mainwindow->geometry("700x325");

#Declare that there is a menu
my $mbar = $mainwindow->Menu();
$mainwindow->configure( -menu => $mbar );

#--- Main Buttons ---

## File Menu ##
my $file = $mbar->cascade( -label => "File", -underline => 0, -tearoff => 0 );
$file->command(
    -label     => "Exit",
    -underline => 1,
    -command   => sub { exit }
);

## Help Menu ##
my $help = $mbar->cascade( -label => "Help", -underline => 0, -tearoff => 0 );
$help->command( -label => "ReadMe", -underline => 0, -command => sub { openurl('https://inside-docupedia.bosch.com/confluence/display/aeos/CREIS+utility+tool') } );

################### Start Create frames in main window ############################
my $Headframe             = $mainwindow->Frame()->pack( -padx => 3, -pady => 10 );    #Frame contains the heading
my $Inputfileframe        = $mainwindow->Frame()->pack( -padx => 3, -pady => 8 );     #Frame contains the mdb file path
my $ProjectPathframe      = $mainwindow->Frame()->pack( -padx => 3, -pady => 8 );     #Frame contains the project folder path
my $Proj_const_file_frame = $mainwindow->Frame()->pack( -padx => 3, -pady => 8 );     #Frame contains the Project Constant file Name and create button
my $TestList_file_frame   = $mainwindow->Frame()->pack( -padx => 3, -pady => 8 );     #Frame contains the Test List file Name and create button
my $Parameter_file_frame  = $mainwindow->Frame()->pack( -padx => 3, -pady => 8 );     #Frame contains the Parameter file Name and create button
my $ActionButtonframe     = $mainwindow->Frame()->pack( -padx => 3, -pady => 8 );     #Frame contains Close and ResetAll buttons

my $Note_mainwindow_frame = $mainwindow->Label(
    -text => " Note : Create TestList first then Testcase Parameter file",
    -font => "Courier 12"
)->pack( -side => "bottom" );

################### Header frame label in main window ############################
$Headframe->Label( -text => 'CREIS Configuration Generator ', -font => "Verdana 12 bold italic underline" )->pack();

######################### .mdb file frame ###########################
$Inputfileframe->Label( -width => 25, -text => '.mdb file path ' )->pack( -side => "left" );
$Inputfileframe->Entry( -width => 70, "-textvariable" => \$MDB_file_selected, )->pack( -side => "left" );

$Inputfileframe->Button(
    -width         => 10,
    "-text"        => "Browse...",
    "-borderwidth" => 3,
    "-command"     => sub {

        # browse for file
        $MDB_file_selected = $mainwindow->getOpenFile(
            "-filetypes" => [ [ "MDS DataBase", '.mdb' ], [ "All files", '.*' ] ],
            "-title" => "choose a .mdb file(*.mdb)",
        );
        if ($MDB_file_selected) {

            # first check if the .mdb file is selected else throw a message asking for the .mdb file
            if ( $MDB_file_selected =~ /\.mdb$/ ) {
                print LOG "mdb File Chosen :: $MDB_file_selected \n";
                my $type    = cleanStrings( basename( dirname($MDB_file_selected) ) );
                my $variant = cleanStrings( basename( dirname( dirname($MDB_file_selected) ) ) );
                $TL_file = "TL_CREIS_" . $variant . "_" . $type;
            }
            else {
                $mainwindow->messageBox(
                    '-icon'    => "error",               #qw/error info question warning/
                    '-type'    => "OK",                  #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                    '-title'   => 'Attention',
                    '-message' => "!Select .mdb file!"
                );
                $MDB_file_selected = "";
            }
        }
        else {
            print "no filename!\n";

            # prompt user
            $mainwindow->messageBox(
                '-icon'    => "error",                   #qw/error info question warning/
                '-type'    => "OK",                      #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
                '-message' => "!Select .mdb file!"
            );
        }
    },
)->pack( -side => 'right' );

######################### Project Folder Path frame ###########################
$ProjectPathframe->Label( -width => 25, -text => 'CREIS Mapping ' )->pack( -side => "left" );
$ProjectPathframe->Entry( -width => 70, "-textvariable" => \$cREIS_Mapping_selected, )->pack( -side => "left" );
my $browse_flag = 0;
$ProjectPathframe->Button(
    -width         => 10,
    "-text"        => "Browse...",
    "-borderwidth" => 3,
    "-command"     => sub {

        # browse for file
        $cREIS_Mapping_selected = $mainwindow->getOpenFile(
            "-filetypes" => [ [ "CREIS_Mapping", '.pm' ], [ "All files", '.*' ] ],
            "-title" => "choose a CREIS_Mapping.pm file(*.pm)",
        );
        if ($cREIS_Mapping_selected) {

            # first check if the .mdb file is selected else throw a message asking for the .mdb file
            if ( $cREIS_Mapping_selected =~ /\.pm$/ ) {
                print LOG "*.pm File Chosen :: $cREIS_Mapping_selected \n";
                $Prj_const_file = basename( $cREIS_Mapping_selected, ".pm" );
                $curr_dir = dirname($cREIS_Mapping_selected);
                $curr_dir .= "/..";

                Check_CREIS_proj_constants();
            }
            else {
                $mainwindow->messageBox(
                    '-icon'    => "error",                            #qw/error info question warning/
                    '-type'    => "OK",                               #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                    '-title'   => 'Attention',
                    '-message' => "!Select *CREIS_Mapping.pm file!"
                );
                $cREIS_Mapping_selected = "";
            }
        }
        else {
            print "no filename!\n";

            # prompt user
            $mainwindow->messageBox(
                '-icon'    => "error",                                #qw/error info question warning/
                '-type'    => "OK",                                   #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
                '-message' => "!Select *CREIS_Mapping.pm file!"
            );
        }
    },
)->pack( -side => 'right' );

######################### Create Project Constant File button ###########################
$Proj_const_file_frame->Label( -width => 25, -text => "new name for CREIS mapping" )->pack( -side => "left" );
$Proj_const_file_frame->Entry( -width => 65, -textvariable => \$Prj_const_file, )->pack( -side => 'left' );
$Proj_const_file_frame->Label( -width => 3, -text => ".pm", -font => "Verdana 8 bold" )->pack( -side => "left" );

$Proj_const_file_frame->Button(
    -width         => 10,
    "-text"        => "Create...",
    "-borderwidth" => 3,
    "-command"     => sub {

        # check if .mdb file is selected first or else throw message asking for the .mdb file selection
        if ( defined $MDB_file_selected ) {

            # check if proj folder path is selected if not throw message asking for the path selection
            if ( $curr_dir ne 'C:' ) {
                unless ($display_PJ_const_flag) {
                    $display_PJ_const_flag = 1;
                    CREIS_proj_constants();
                }
            }
            else {
                $mainwindow->messageBox(
                    '-icon'    => "error",                         #qw/error info question warning/
                    '-type'    => "OK",                            #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                    '-title'   => 'Attention',
                    '-message' => "!Select Project Folder Path!"
                );
            }
        }
        else {
            $mainwindow->messageBox(
                '-icon'    => "error",                             #qw/error info question warning/
                '-type'    => "OK",                                #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
                '-message' => "!Select .mdb file!"
            );
        }
    }
)->pack( -side => "right" );

######################### TestList file creation button function ###########################
$TestList_file_frame->Label( -width => 25, -text => "Test List file name" )->pack( -side => "left" );
$TestList_file_frame->Entry( -width => 65, "-textvariable" => \$TL_file, )->pack( -side => 'left' );
$TestList_file_frame->Label( -width => 3, -text => ".txt", -font => "Verdana 8 bold" )->pack( -side => "left" );

$TestList_file_frame->Button(
    -width         => 10,
    "-text"        => "Create...",
    "-borderwidth" => 3,
    "-command"     => sub {          # execute when button is pressed

        if ( defined $MDB_file_selected ) {
            if ( $curr_dir ne 'C:' ) {
                unless ($display_TL_flag) {
                    $display_TL_flag = 1;
                    &CREIS_TestList_gen();
                }
            }
            else {
                $mainwindow->messageBox(
                    '-icon'    => "error",                 #qw/error info question warning/
                    '-type'    => "OK",                    #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                    '-title'   => 'Attention',
                    '-message' => "!Select Folder Path!"
                );
            }
        }
        else {
            $mainwindow->messageBox(
                '-icon'    => "error",                     #qw/error info question warning/
                '-type'    => "OK",                        #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
                '-message' => "!Select .mdb file!"
            );
        }
    }
)->pack( -side => "right" );

######################### Parameter file creation function ###########################
$Parameter_file_frame->Label( -width => 25, -text => "Parameter file name" )->pack( -side => 'left' );
$Parameter_file_frame->Entry( -width => 65, "-textvariable" => \$TC_name, '-state' => 'disabled' )->pack( -side => 'left' );
$Parameter_file_frame->Label( -width => 3, -text => ".par", -font => "Verdana 8 bold" )->pack( -side => "left" );

$Parameter_file_frame->Button(
    -width         => 10,
    "-text"        => "Create...",
    "-borderwidth" => 3,
    "-command"     => sub {          # execute when button is pressed
        if ( defined $MDB_file_selected ) {
            if ( defined $curr_dir ) {
                unless ($display_para_flag) {
                    $display_para_flag = 1;
                    &CREIS_para_gen();
                }
            }
            else {
                $mainwindow->messageBox(
                    '-icon'    => "error",                 #qw/error info question warning/
                    '-type'    => "OK",                    #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                    '-title'   => 'Attention',
                    '-message' => "!Select Folder Path!"
                );
            }
        }
        else {
            $mainwindow->messageBox(
                '-icon'    => "error",                     #qw/error info question warning/
                '-type'    => "OK",                        #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
                '-message' => "!Select .mdb file first!"
            );
        }
      }

)->pack( -side => "right" );

######################### close function ###########################
$ActionButtonframe->Button(
    -text          => "Close and show ToDo list",
    "-borderwidth" => 3,
    -command       => sub { close(LOG); close(TODO); system("explorer.exe \"$TODO_file_name\""); destroy $mainwindow; }
)->pack( -side => "left" );
######################### close function ###########################
$ActionButtonframe->Button(
    -text          => "Close",
    "-borderwidth" => 3,
    -command       => sub { destroy $mainwindow; }
)->pack( -side => "left" );
######################### ResetAll function ###########################
$ActionButtonframe->Button(
    -text          => "ResetAll",
    "-borderwidth" => 3,
    "-command"     => sub {         # execute when button is pressed
        $MDB_file_selected = "";                         # set scan_file to undefined
        $curr_dir          = 'C:';
        $Prj_const_file    = 'CREIS_ProjectConst';       #default project const file name
        $TC_name           = 'TC_CREIS_StandardTest';    #default para file name
        $TL_file           = 'TL_CREIS';                 #default testlist file name
        $G_iteration       = 1;                          #back to default value
    }
)->pack( -side => "left" );

MainLoop;

############################################################################################

=head CREIS_proj_constants

    Function Name    :: CREIS_proj_constants
    Description      :: This function reads Sensor Details, SIMDevice Details, Env Params from MDS database and creats creats proj_const_hash by.  
                        Default file name is CREIS_ProjectConst.pm and is saved at .\config\ in LIFT Project.

%creats proj_const_hash => "Mapping" => {
                                            "INPUT" => 
                                            {
                                                #Module: Sensor: Direction: Type:Version
                                                'ECU: Acc_HG: -X: SMA560_SYNC'                 => { 'device' => 'ECU_Acc_HG',    'Simulator' => 'Quate'    },
                                            },
                                            "OUTPUT" => 
                                            {
                                                # Simdevices & crash outputs
                                                'AB1FD'      => { 'MeasureBy' => 'TRANSI', 'Evaluation' => \&CREIS_EvaluateSquibFiring},  
                                            },

                                            "ENVIRONMENT"  => 
                                            {
                                                # environment states
                                                'BLFD_State' =>
                                                {
                                                   '0' => sub {
                                                       MLC_SetLogicalState('BLFD', 'UNLOCKED');
                                                   },
                                                   '1' => sub {
                                                       MLC_SetLogicalState('BLFD', 'LOCKED');
                                                   },
                                                },
                                            },
                                        };

=cut

############################################################################################
sub Check_CREIS_proj_constants {
    my $MDB_file_processed = $MDB_file_selected;
    my $template_href;
    my @sectionList = qw(CRASH_SIMULATION CRASH_MEASUREMENT_AND_EVALUATION MDSRESULT);
    $MDB_file_processed =~ s/\//\\/g;

    eval( require $cREIS_Mapping_selected );

    if ($@) {
        print LOG "Selected CREIS mapping could not be loaded \n$@";
    }

    foreach my $mappingSectionKey ( keys %{$LIFT_PROJECT::Defaults} ) {
        next if $mappingSectionKey eq 'CRASH_SIMULATION';
        next if $mappingSectionKey eq 'CRASH_MEASUREMENT_AND_EVALUATION';
        next if $mappingSectionKey eq 'MDSRESULT';
        $remainingSections_href->{$mappingSectionKey} = $LIFT_PROJECT::Defaults->{$mappingSectionKey};
    }

    foreach my $sectionKey (@sectionList) {
        next if ( $template_href->{$sectionKey} = $LIFT_PROJECT::Defaults->{$sectionKey} );

        $mainwindow->messageBox(
            '-icon'    => "warning",                                                                               #qw/error info question warning/
            '-type'    => "OK",                                                                                    #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
            '-title'   => 'Attention',
            '-message' => "Missing section Defaults->{'$sectionKey'}. A new CREIS Mapping file will be created!"
        );

        print LOG "Missing section Defaults->{'$sectionKey'}. A new CREIS Mapping file will be created! \n";
        $forceNewMapping = 1;
        $Prj_const_file .= time();
        last;
    }

    if ($forceNewMapping) {
        $remainingSections_href = {};
        no warnings;
        require '.\ProjectDefaults_CREIS.pm';

        foreach my $sectionKey (@sectionList) {
            next if ( $template_href->{$sectionKey} = $LIFT_PROJECT::Defaults->{$sectionKey} );

            $mainwindow->messageBox(
                '-icon'    => "error",                                       #qw/error info question warning/
                '-type'    => "OK",                                          #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
                '-message' => "Missing section Defaults->{'$sectionKey'}."
            );

            print LOG "Missing section Defaults->{'$sectionKey'}.\n";
            close(LOG);
            close(TODO);
            destroy $mainwindow;
            last;
        }
    }

    print LOG "\n\n######################################################################\n";
    print LOG "### Creating Project Constants ###\n";
    print LOG "######################################################################\n";

    #Start the MDS database
    print LOG "CREIS_proj_constants :: Start mdsresult\n";
    $start_status = mdsresult_Start();
    if ( $start_status < 0 ) {
        $errortext = mdsresult_GetErrorString( $start_status < 0 );

        $mainwindow->messageBox(
            '-icon'    => "error",                          #qw/error info question warning/
            '-type'    => "OK",                             #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
            '-title'   => 'Attention',
            '-message' => "!Couldnot start MDS database!"
        );

        print LOG "CREIS_proj_constants Failed :: Error Description :: $errortext \n";
        close(LOG);
        close(TODO);
        destroy $mainwindow;                                #close the GUI tool
    }
    print LOG "CREIS_proj_constants :: mdsresult_Start :: status :: $start_status\n";

    #Loads the mdb file
    print LOG "CREIS_proj_constants :: Initialise mdsresult\n";
    my $status = mdsresult_SetFlagPrintDbgInfosEnabled( 1, dirname(__FILE__) );
    $InitResult_status = mdsresult_InitResult($MDB_file_processed);
    if ( $InitResult_status < 0 ) {
        $errortext = mdsresult_GetErrorString( $InitResult_status < 0 );

        $mainwindow->messageBox(
            '-icon'    => "error",                          #qw/error info question warning/
            '-type'    => "OK",                             #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
            '-title'   => 'Attention',
            '-message' => "!Coundnot load the mdb file!"
        );

        print LOG "CREIS_proj_constants Failed :: Error Description :: $errortext \n";
        close(LOG);
        close(TODO);
        destroy $mainwindow;                                #close the GUI tool
    }
    print LOG "CREIS_proj_constants :: mdsresult_InitResult :: status :: $InitResult_status\n";

    #Fetch all Sensor Details from database
    print LOG "CREIS_proj_constants :: Fetch Sensor Details from database\n";
    ( $GetSensorDetails_status, $ModuleName, $SensorName, $SensorDirection, $SensorType ) = mdsresult_GetSensorDetails();

    if ( $GetSensorDetails_status < 0 ) {
        $errortext = mdsresult_GetErrorString($GetSensorDetails_status);

        $mainwindow->messageBox(
            '-icon'    => "error",                                          #qw/error info question warning/
            '-type'    => "OK",                                             #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
            '-title'   => 'Attention',
            '-message' => "!Couldnot fetch Sensor Details from database!"
        );

        print LOG "CREIS_proj_constants Failed :: Error Description :: $errortext \n";
        close(LOG);
        close(TODO);
        destroy $mainwindow;                                                #close the GUI tool
    }
    print LOG "CREIS_proj_constants :: mdsresult_GetSensorDetails :: status :: $GetSensorDetails_status\n";
    print LOG "CREIS_proj_constants :: mdsresult_GetSensorDetails :: ModuleName :: @$ModuleName \n";
    print LOG "CREIS_proj_constants :: mdsresult_GetSensorDetails :: SensorName :: @$SensorName \n";
    print LOG "CREIS_proj_constants :: mdsresult_GetSensorDetails :: SensorDirection :: @$SensorDirection \n";
    print LOG "CREIS_proj_constants :: mdsresult_GetSensorDetails :: SensorType :: @$SensorType \n";

    #Get all SIMDevice Details from database
    print LOG "CREIS_proj_constants :: Get all SIMDevice Details from database\n";
    ( $GetSimDevices_status, $SimDevices_aref ) = mdsresult_GetSimDevices();

    if ( $GetSimDevices_status < 0 ) {
        $errortext = mdsresult_GetErrorString($GetSimDevices_status);

        $mainwindow->messageBox(
            '-icon'    => "error",                                                 #qw/error info question warning/
            '-type'    => "OK",                                                    #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
            '-title'   => 'Attention',
            '-message' => "!Couldnot fetch all SIMDevice Details from database!"
        );
        print LOG "CREIS_proj_constants :: mdsresult_GetSimDevices :: status :: $GetSimDevices_status\n";
        print LOG "CREIS_proj_constants Failed :: Error Description :: $errortext \n";
        close(LOG);
        close(TODO);
        destroy $mainwindow;                                                       #close the GUI tool
    }

    print LOG "CREIS_proj_constants :: mdsresult_GetSimDevices :: status :: $GetSimDevices_status\n";
    print LOG "CREIS_proj_constants :: mdsresult_GetSimDevices :: SimDevices :: @{$SimDevices_aref} \n";

    #Get all Constant Env Params from database
    print LOG "CREIS_proj_constants :: Get all Constant Env Params from database\n";
    ( $GetConstantEnvParams_status, $EnvName_Const, $EnvVals ) = mdsresult_GetConstantEnvParams();

    if ( $GetConstantEnvParams_status < 0 ) {
        $errortext = mdsresult_GetErrorString($GetConstantEnvParams_status);

        $mainwindow->messageBox(
            '-icon'    => "error",                                                   #qw/error info question warning/
            '-type'    => "OK",                                                      #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
            '-title'   => 'Attention',
            '-message' => "!Couldnot fetch all Constant Env Params from database!"
        );

        print LOG "CREIS_proj_constants Failed :: Error Description :: $errortext \n";
        close(LOG);
        close(TODO);
        destroy $mainwindow;                                                         #close the GUI tool
    }
    print LOG "CREIS_proj_constants :: mdsresult_GetConstantEnvParams :: status :: $GetConstantEnvParams_status\n";
    print LOG "CREIS_proj_constants :: mdsresult_GetConstantEnvParams :: EnvName_Const :: @$EnvName_Const \n";
    print LOG "CREIS_proj_constants :: mdsresult_GetConstantEnvParams :: EnvVals :: @$EnvVals \n";

    ( $GetDynamicEnvParams_status, $EnvName_Dynamic ) = mdsresult_GetDynamicEnvParams();
    if ( $GetDynamicEnvParams_status < 0 ) {
        $errortext = mdsresult_GetErrorString($GetDynamicEnvParams_status);

        $mainwindow->messageBox(
            '-icon'    => "error",                                                   #qw/error info question warning/
            '-type'    => "OK",                                                      #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
            '-title'   => 'Attention',
            '-message' => "!Couldnot fetch all Dynamic Env Params from database!"
        );

        print LOG "CREIS_proj_constants Failed :: Error Description :: $errortext \n";
        close(LOG);
        close(TODO);
        destroy $mainwindow;                                                         #close the GUI tool
    }
    print LOG "CREIS_proj_constants :: mdsresult_GetDynamicEnvParams :: status :: $GetDynamicEnvParams_status\n";
    print LOG "CREIS_proj_constants :: mdsresult_GetDynamicEnvParams :: EnvName_Dynamic :: @$EnvName_Dynamic \n";

    # Unloads the MDSResult Process DLL
    print LOG "CREIS_proj_constants :: Unload MDSResult DLL\n";
    $exit_status = mdsresult_CloseResult();
    if ( $exit_status < 0 ) {
        $errortext = mdsresult_GetErrorString($exit_status);

        $mainwindow->messageBox(
            '-icon'    => "error",                                                   #qw/error info question warning/
            '-type'    => "OK",                                                      #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
            '-title'   => 'Attention',
            '-message' => "!Couldnot unload MDSResult DLL!"
        );
        print LOG "CREIS_proj_constants Failed :: Error Description :: $errortext \n";
        close(LOG);
        close(TODO);
        destroy $mainwindow;                                                         #close the GUI tool
    }
    print LOG "CREIS_proj_constants :: mdsresult_CloseResult :: status :: $exit_status\n";

    # hash slice ; is copying the hashes completely
    @{$proj_const_crash_simulation_gen_href}{ keys %{ $template_href->{CRASH_SIMULATION} } } = values %{ $template_href->{CRASH_SIMULATION} };

    @{$proj_const_crash_meas_eval_gen_href}{ keys %{ $template_href->{CRASH_MEASUREMENT_AND_EVALUATION} } } = values %{ $template_href->{CRASH_MEASUREMENT_AND_EVALUATION} };

    @{$proj_const_mdsresult_gen_href}{ keys %{ $template_href->{MDSRESULT} } } = values %{ $template_href->{MDSRESULT} };

    unless ( defined $proj_const_mdsresult_gen_href->{"RESULTS"}{"DEFAULT"} ) {
        $errortext = "Missing key { MDSRESULT }{ RESULTS }{ DEFAULT }";
        $mainwindow->messageBox(
            '-icon'    => "error",       #qw/error info question warning/
            '-type'    => "OK",          #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
            '-title'   => 'Attention',
            '-message' => $errortext,
        );
        print LOG "CREIS_proj_constants Failed :: Error Description :: $errortext \n";
        close(LOG);
        close(TODO);
        destroy $mainwindow;
    }

    $proj_const_mdsresult_gen_href->{"RESULTS"}{"DEFAULT"}{"PATH"}    = $MDB_file_processed;
    $proj_const_mdsresult_gen_href->{"RESULTS"}{"DEFAULT"}{"MDSTYPE"} = "MDSNG";

    my $newEntriesDetected;

    for ( my $ndx = 0 ; $ndx < scalar(@$SensorDirection) ; $ndx++ ) {

        my $Input_keys   = qq/$$ModuleName[$ndx]: $$SensorName[$ndx]: $$SensorDirection[$ndx]: $$SensorType[$ndx]/;
        my $Input_values = qq/<<TODO: $$ModuleName[$ndx]_$$SensorName[$ndx] >>/;

        next if ( exists $proj_const_crash_simulation_gen_href->{'STIMULATION'}{'CRASH_SENSORS'}{$Input_keys} );
        next if ( exists $proj_const_crash_simulation_gen_href->{'STIMULATION'}{'NETWORK_DYNAMIC'}{$Input_keys} );

        if ( $$SensorDirection[$ndx] eq "Bus" ) {
            $proj_const_crash_simulation_gen_href->{'STIMULATION'}{'NETWORK_DYNAMIC'}{$Input_keys} = $Input_values;
            print TODO "TODO :: NETWORK_DYNAMIC - Fill mapping for NETWORK_DYNAMIC '$Input_keys' \n";
        }
        else {
            $proj_const_crash_simulation_gen_href->{'STIMULATION'}{'CRASH_SENSORS'}{$Input_keys} = $Input_values;
            print TODO "TODO :: CRASH_SENSOR - Fill mapping for CRASH_SENSOR '$Input_keys' \n";
        }

        $newEntriesDetected = 1;

    }

    my %allEnv;
    my @missingMandatoryEnv;

    @allEnv{@$EnvName_Dynamic} = 1;
    @allEnv{@$EnvName_Const}   = 1;

    if ( exists $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{'RESET'} ) {
        delete $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{'RESET'};
        print TODO "TODO :: ENVIRONMENT - Section 'RESET' is obsolete and has been removed!!!\n";
        $newEntriesDetected = 1;
    }

    if ( exists $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{'SENSORS'} ) {
        delete $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{'SENSORS'};
        print TODO "TODO :: ENVIRONMENT - Section 'SENSORS' is obsolete and has been removed!!!\n";
        $newEntriesDetected = 1;
    }

    foreach my $envName ( sort keys %{ $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'} } ) {
        next unless exists $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName}{Mandatory};
        next unless $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName}{Mandatory};
        next if exists $allEnv{$envName};
        print TODO "TODO :: ENVIRONMENT - Mandatory Environment '$envName' not selected as 'CREIS relevant'. Given MDB should not be used without clarification! \n";
        push( @missingMandatoryEnv, $envName );

    }

    if (@missingMandatoryEnv) {
        my $type_button = $mainwindow->messageBox(
            '-icon'    => "info",                                                                                            #qw/error info question warning/
            '-type'    => "OK",                                                                                              #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
            '-title'   => 'Attention',
            '-message' => "Missing mandarory environments detected. Given MDB should not be used without clarification! ",
        );
    }

    my $environmentsTemplatesTODO_href = {
        "EnvAmbientTemp" => {
            "EnvType"              => "NetSignal",
            "EnvUnit_Mdb"          => "degC",
            "Force4eachIteration"  => 1,
            "Mandatory"            => 1,
            "NetworkType"          => "<<TODO: CAN|FR|LIN>>",
            "SignalFactor_Mdb2Net" => "<<TODO: conversion factor between MDB (degCelsius) to NET signal>>",
            "SignalUnit_Net"       => "<<TODO: unit of NET signal>>",
            "SignalName"           => "<<TODO: name of NET signal as in CAN|FR|LIN mapping>>",
            "SourceEnvironment"    => "EnvAmbientTemp_Source",
            "SourceMapping"        => {
                0 => "TEMPERATURE_degCelsius",
                1 => "EnvAmbientTemp"
            },
            "Verify" => {
                "EnvVerificationType"       => "PdLabel",
                "PdLabel"                   => "rb_cia_AmbientTemp_s8",
                "Factor_LsbPdLabel2Mdb"     => 1,
                "Tolerance"                 => 1,
                "SignalMapping_Mdb2PdLabel" => {
                    INVALID => 65534,
                },
                "ValidityEnvironment" => "EnvAmbientTempValid",
            },
        },
        "EnvAmbientTempValid" => {
            "EnvType"               => "NetSignal",
            "Force4eachIteration"   => 1,
            "Mandatory"             => 1,
            "NetworkType"           => "<<TODO: CAN|FR|LIN>>",
            "SignalMapping_Mdb2Net" => {
                0 => "<<TODO: NET value for signal invalid>>",
                1 => "<<TODO: NET value for signal valid>>",
            },
            "SignalName" => "<<TODO: name of NET signal as in CAN|FR|LIN mapping>>",
            "Verify"     => {
                "EnvVerificationType" => "Parameter",
                "Text"                => "Verified with verification of 'EnvAmbientTemp'",
            },
        },
        "EnvEgoVelocity" => {
            "EnvType"              => "NetSignal",
            "EnvUnit_Mdb"          => "km/h",
            "Force4eachIteration"  => 1,
            "Mandatory"            => 1,
            "NetworkType"          => "<<TODO: CAN|FR|LIN>>",
            "SignalFactor_Mdb2Net" => "<<TODO: conversion factor between MDB (km/h) to NET signal>>",
            "SignalUnit_Net"       => "<<TODO: unit of NET signal>>",
            "SignalName"           => "<<TODO: name of NET signal as in CAN|FR|LIN mapping>>",
            "SourceEnvironment"    => "EnvEgoVelocity_Source",
            "SourceMapping"        => {
                0 => "VELOCITY_X_kmh",
                1 => "VELOCITY_kmh",
                2 => "EnvEgoVelocity",
                3 => undef
            },
            "ResetValue" => 0,
            "Verify"     => {
                "EnvVerificationType"       => "PdLabel",
                "PdLabel"                   => "rb_cia_EgoVelocity_u16",
                "Factor_LsbPdLabel2Mdb"     => 0.125,
                "Tolerance"                 => 0.125,
                "SignalMapping_Mdb2PdLabel" => {
                    INVALID => 65534,
                },
                "ValidityEnvironment" => "EnvEgoVelocityValid",
            },
        },
        "EnvEgoVelocityValid" => {
            "EnvType"               => "NetSignal",
            "Force4eachIteration"   => 1,
            "Mandatory"             => 1,
            "NetworkType"           => "<<TODO: CAN|FR|LIN>>",
            "SignalMapping_Mdb2Net" => {
                0 => "<<TODO: NET value for signal invalid>>",
                1 => "<<TODO: NET value for signal valid>>",
            },
            "SignalName" => "<<TODO: name of NET signal as in CAN|FR|LIN mapping>>",
            "Verify"     => {
                "EnvVerificationType" => "Parameter",
                "Text"                => "Verified with verification of 'EnvEgoVelocity'",
            },
        },
        "EnvVehicleSpeed" => {
            "EnvType"              => "NetSignal",
            "EnvUnit_Mdb"          => "km/h",
            "Force4eachIteration"  => 1,
            "Mandatory"            => 1,
            "NetworkType"          => "<<TODO: CAN|FR|LIN>>",
            "SignalFactor_Mdb2Net" => "<<TODO: conversion factor between MDB (km/h) to NET signal>>",
            "SignalUnit_Net"       => "<<TODO: unit of NET signal>>",
            "SignalName"           => "<<TODO: name of NET signal as in CAN|FR|LIN mapping>>",
            "SourceEnvironment"    => "EnvVelocity_Source",
            "SourceMapping"        => {
                0 => "VELOCITY_kmh",
                1 => "EnvVehicleSpeed",
                2 => undef
            },
            "ResetValue" => 0,
            "Verify"     => {
                "EnvVerificationType"       => "PdLabel",
                "PdLabel"                   => "rb_cia_EgoVelocity_u16",
                "Factor_LsbPdLabel2Mdb"     => 0.125,
                "Tolerance"                 => 0.125,
                "SignalMapping_Mdb2PdLabel" => {
                    INVALID => 65534,
                },
                "ValidityEnvironment" => "EnvVehicleSpeedValid",
            },
        },
        "EnvVehicleSpeedValid" => {
            "EnvType"               => "NetSignal",
            "Force4eachIteration"   => 1,
            "Mandatory"             => 1,
            "NetworkType"           => "<<TODO: CAN|FR|LIN>>",
            "SignalMapping_Mdb2Net" => {
                0 => "<<TODO: NET value for signal invalid>>",
                1 => "<<TODO: NET value for signal valid>>",
            },
            "SignalName" => "<<TODO: name of NET signal as in CAN|FR|LIN mapping>>",
            "Verify"     => {
                "EnvVerificationType" => "Parameter",
                "Text"                => "Verified with verification of 'EnvVehicleSpeed'",
            },
        },
        "EnvVehicleDrivingDir" => {
            "EnvType"               => "NetSignal",
            "Force4eachIteration"   => 1,
            "Mandatory"             => 1,
            "NetworkType"           => "CAN",
            "SignalName"            => "VSD_VehicleDrivingDirection",
            "SignalMapping_Mdb2Net" => {
                0 => "<<TODO: NET value for forward>>",
                1 => "<<TODO: NET value for backward>>",
            },
            "Verify" => {
                "EnvVerificationType"       => "PdLabel",
                "PdLabel"                   => "rb_cia_DrivingDirection_u8",
                "SignalMapping_Mdb2PdLabel" => {
                    0       => 0,
                    1       => 1,
                    INVALID => 3,
                },
                "ValidityEnvironment" => "EnvVehicleDrivingDirValid",
            },
        },
        "EnvVehicleDrivingDirValid" => {
            "EnvType"               => "NetSignal",
            "Force4eachIteration"   => 1,
            "Mandatory"             => 1,
            "NetworkType"           => "<<TODO: CAN|FR|LIN>>",
            "SignalMapping_Mdb2Net" => {
                0 => "<<TODO: NET value for signal invalid>>",
                1 => "<<TODO: NET value for signal valid>>",
            },
            "SignalName" => "<<TODO: name of NET signal as in CAN|FR|LIN mapping>>",
            "Verify"     => {
                "EnvVerificationType" => "Parameter",
                "Text"                => "Verified with verification of 'EnvVehicleDrivingDir'",
            },
        },
        "Switch_OCS_Configured" => {
            "EnvType" => "<<TODO: Find a EnvironmentType for implementing OCS configuration. Check CREIS Wiki>>",
        },
        "Switch_OCS_State" => {
            "EnvType" => "<<TODO: Find a EnvironmentType for implementing OCS States. Check CREIS Wiki>>",
        },
        "Switch_OCS_Diagnosable" => {
            "EnvType" => "<<TODO: Find a EnvironmentType for implementing OCS Diagnosable. Check CREIS Wiki>>",
        },
    };

    my $environmentsTemplatesDONE_href = {
        "Config_RightHandDriver" => {
            "EnvType"        => "SpecialBehaviourBit",
            "Mandatory"      => 1,
            "SpecialBitName" => "IsRightHandDriver",
            "Verify"         => {
                "EnvVerificationType"       => "PdLabel",
                "PdLabel"                   => "rb_siam_DriverConfigSign_s8",
                "SignalMapping_Mdb2PdLabel" => {
                    0 => 1,
                    1 => -1,
                },
            },
        },
        "FCLConfSystem_DriverRight" => {
            "EnvType"        => "SpecialBehaviourBit",
            "Mandatory"      => 1,
            "SpecialBitName" => "IsRightHandDriver",
            "Verify"         => {
                "EnvVerificationType"       => "PdLabel",
                "PdLabel"                   => "rb_siam_DriverConfigSign_s8",
                "SignalMapping_Mdb2PdLabel" => {
                    0 => 1,
                    1 => -1,
                },
            },
        },
    };

    foreach my $envName ( sort keys %allEnv ) {

        next if ( exists $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName} );

        # environments defined in TODO template mapping will be directly copied from template
        if ( exists $environmentsTemplatesTODO_href->{$envName} ) {
            $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName} = $environmentsTemplatesTODO_href->{$envName};

            print TODO "TODO :: ENVIRONMENT - Fill mapping for Environment '$envName'.\n";
            $newEntriesDetected = 1;
        }

        # environments defined in DONE template mapping will be directly copied from template
        elsif ( exists $environmentsTemplatesDONE_href->{$envName} ) {
            $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName} = $environmentsTemplatesDONE_href->{$envName};

            print TODO "TODO :: ENVIRONMENT - Mapping updated with Environment '$envName'. Use updated Mapping!!!\n";
            $newEntriesDetected = 1;
        }

        # elements ending with ErrStart or ErrEnd or OverloadStart or OverloadEnd can be ignored
        elsif ( $envName =~ /(ErrStart|ErrEnd|OverloadStart|OverloadEnd|Source)$/ ) {
            $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName}{EnvType}   = "Parameter";
            $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName}{Mandatory} = 1;
            $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName}{Text}      = "Parameter for other environments.";

            print TODO "TODO :: ENVIRONMENT - Mapping updated with Environment '$envName'. Use updated Mapping!!!\n";
            $newEntriesDetected = 1;
        }

        # check for 'Env...'
        elsif ( $envName =~ /^ Env (\w+) $/ix ) {
            $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName}{EnvType}             = "NetSignal";
            $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName}{Mandatory}           = 1;
            $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName}{NetworkType}         = "<<TODO>>";
            $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName}{SignalName}          = "<<TODO>>";
            $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName}{Force4eachIteration} = 1;

            if ( $envName =~ /^ Env (\w+) Valid $/ix ) {
                $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName}{SignalMapping_Mdb2Net} = {
                    0 => "<<TODO: NET value for signal invalid>>",
                    1 => "<<TODO: NET value for signal valid>>"
                };
            }
            else {
                $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName}{SignalMapping_Mdb2Net} = {};
            }
            print TODO "TODO :: ENVIRONMENT - Fill mapping for Environment '$envName'. \n";
            $newEntriesDetected = 1;
        }

        # check for 'Switch_..._State'
        elsif ( $envName =~ /^ Switch_ (\w+) _State $/ix ) {
            $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName}{EnvType}                     = "SwitchState";
            $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName}{Mandatory}                   = 1;
            $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName}{SwitchName}                  = $1;
            $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName}{Source4SwitchValue}          = 'SYC';
            $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName}{Verify}{EnvVerificationType} = 'SwitchState';

            print TODO "TODO :: ENVIRONMENT - Mapping updated with Environment '$envName'. Use updated Mapping!!!\n";
            $newEntriesDetected = 1;
        }

        # check for 'Switch_..._Diagnosable'
        elsif ( $envName =~ /^ Switch_ (\w+) _Diagnosable $/ix ) {
            $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName}{EnvType}                     = "Parameter";
            $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName}{Text}                        = "Diagnosable attribute of a switch is a variant configuration and should not be changed during testing.";
            $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName}{Mandatory}                   = 1;
            $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName}{SwitchName}                  = $1;
            $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName}{Verify}{EnvVerificationType} = 'SwitchDiagnosable';

            print TODO "TODO :: ENVIRONMENT - Mapping updated with Environment '$envName'. Use updated Mapping!!!\n";
            $newEntriesDetected = 1;
        }

        # check for 'Switch_..._Configured'
        elsif ( $envName =~ /^ Switch_ (\w+) _Configured $/ix ) {
            $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName}{EnvType}                     = "SwitchConfiguration";
            $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName}{Mandatory}                   = 1;
            $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName}{SwitchName}                  = $1;
            $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName}{Verify}{EnvVerificationType} = 'SwitchConfiguration';

            print TODO "TODO :: ENVIRONMENT - Mapping updated with Environment '$envName'. Use updated Mapping!!!\n";
            $newEntriesDetected = 1;
        }

        # check for 'Ps...ErrBehaviour'
        elsif ( $envName =~ /^ Ps (\w+) ErrBehaviour $/ix ) {
            $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName}{EnvType}    = "ExternalSensorError";
            $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName}{Mandatory}  = 0;
            $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName}{SensorName} = $1;

            print TODO "TODO :: ENVIRONMENT - Mapping updated with Environment '$envName'. Use updated Mapping!!!\n";
            $newEntriesDetected = 1;
        }

        # check for 'Ps...Configured'
        elsif ( $envName =~ /^ Ps (\w+) Configured $/ix ) {
            $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName}{EnvType}    = "ExternalSensorConfiguration";
            $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName}{Mandatory}  = 0;
            $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName}{SensorName} = $1;

            print TODO "TODO :: ENVIRONMENT - Mapping updated with Environment '$envName'. Use updated Mapping!!!\n";
            $newEntriesDetected = 1;
        }

        # check for 'CsEcu...OverloadBhvr'
        elsif ( $envName =~ /^ CsEcu (\w+) OverloadBhvr $/ix ) {
            $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName}{EnvType}   = "<<TODO>>";
            $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName}{Mandatory} = 0;

            print TODO "TODO :: ENVIRONMENT - Fill mapping for Environment '$envName'. \n";
            $newEntriesDetected = 1;
        }
        else {
            $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName}{EnvType}   = "<<TODO>>";
            $proj_const_crash_simulation_gen_href->{'ENVIRONMENT'}{$envName}{Mandatory} = 0;

            print TODO "TODO :: ENVIRONMENT - Fill mapping for Environment '$envName'. \n";
            $newEntriesDetected = 1;
        }
    }

    foreach my $Output_Device (@$SimDevices_aref) {
        next if ( exists $proj_const_crash_meas_eval_gen_href->{'SimDevices'}{$Output_Device} );

        $proj_const_crash_meas_eval_gen_href->{'SimDevices'}{$Output_Device} = "<<TODO>>";
        print TODO "TODO :: Fill mapping for SimDevices '$Output_Device'. \n";
        $newEntriesDetected = 1;
    }

    my $generalSettingsTemplate = {
        "SamplingFrequency_Hz"              => 20 * 1000,
        "DisposalTime_ms"                   => 300,
        "EDRnumberOfEvents"                 => "SAD",
        "EDRnumberOfEventsPEP"              => "SAD",
        "FiringCurrentThresholdTolerance_A" => "0.2",
        "FiringCurrentThreshold_A"          => "SYC"
    };

    foreach my $generalSettingsKey ( keys %$generalSettingsTemplate ) {
        next if ( exists $proj_const_crash_meas_eval_gen_href->{'General_Settings'}{$generalSettingsKey} );

        $proj_const_crash_meas_eval_gen_href->{'General_Settings'}{$generalSettingsKey} = $generalSettingsTemplate->{$generalSettingsKey};
        print TODO "TODO :: General_Settings - Mapping updated with General_Setting '$generalSettingsKey'. Check content and use updated Mapping!!!\n";
        $newEntriesDetected = 1;
    }

    if ( $proj_const_crash_meas_eval_gen_href->{'General_Settings'}{'EDRnumberOfEventsPEP'} eq 'SYC' ) {
        $proj_const_crash_meas_eval_gen_href->{'General_Settings'}{'EDRnumberOfEventsPEP'} = $generalSettingsTemplate->{'EDRnumberOfEventsPEP'};
        print TODO "TODO :: General_Settings - Mapping updated with General_Setting 'EDRnumberOfEventsPEP'. Check content and use updated Mapping!!!\n";
        $newEntriesDetected = 1;
    }

    if ( $proj_const_crash_meas_eval_gen_href->{'General_Settings'}{'EDRnumberOfEvents'} eq 'SYC' ) {
        $proj_const_crash_meas_eval_gen_href->{'General_Settings'}{'EDRnumberOfEvents'} = $generalSettingsTemplate->{'EDRnumberOfEvents'};
        print TODO "TODO :: General_Settings - Mapping updated with General_Setting 'EDRnumberOfEvents'. Check content and use updated Mapping!!!\n";
        $newEntriesDetected = 1;
    }

    my $faultEvaluationSettingsTemplate = {
        "BeforeCrash" => {
            "Generic"              => [],
            "EnvironmentDependent" => {     # "mandatory" faults before crash
                rb_swm_OpenLineBLFD_flt    => '#Switch_BLFD_Configured|1 == 1 and #Switch_BLFD_State == 3',
                rb_swm_UndefinedBLFD_flt   => '#Switch_BLFD_State == 2',
                rb_swm_UnexpectedBLFD_flt  => '#Switch_BLFD_Configured|1 == 0 and not #Switch_BLFD_State == 3',
                rb_swm_OpenLineBLFP_flt    => '#Switch_BLFP_Configured|1 == 1 and #Switch_BLFP_State == 3',
                rb_swm_UndefinedBLFP_flt   => '#Switch_BLFP_State == 2',
                rb_swm_UnexpectedBLFP_flt  => '#Switch_BLFP_Configured|1 == 0 and not #Switch_BLFP_State == 3',
                rb_swm_OpenLineBLRC_flt    => '#Switch_BLRC_Configured|1 == 1 and #Switch_BLRC_State == 3',
                rb_swm_UndefinedBLRC_flt   => '#Switch_BLRC_State == 2',
                rb_swm_UnexpectedBLRC_flt  => '#Switch_BLRC_Configured|1 == 0 and not #Switch_BLRC_State == 3',
                rb_swm_OpenLineBLRD_flt    => '#Switch_BLRD_Configured|1 == 1 and #Switch_BLRD_State == 3',
                rb_swm_UndefinedBLRD_flt   => '#Switch_BLRD_State == 2',
                rb_swm_UnexpectedBLRD_flt  => '#Switch_BLRD_Configured|1 == 0 and not #Switch_BLRD_State == 3',
                rb_swm_OpenLineBLRP_flt    => '#Switch_BLRP_Configured|1 == 1 and #Switch_BLRP_State == 3',
                rb_swm_UndefinedBLRP_flt   => '#Switch_BLRP_State == 2',
                rb_swm_UnexpectedBLRP_flt  => '#Switch_BLRP_Configured|1 == 0 and not #Switch_BLRP_State == 3',
                rb_swm_OpenLineOPSFP_flt   => '#Switch_OPSFP_Configured|1 == 1 and #Switch_OPSFP_State == 3',
                rb_swm_UndefinedOPSFP_flt  => '#Switch_OPSFP_State == 2',
                rb_swm_UnexpectedOPSFP_flt => '#Switch_OPSFP_Configured|1 == 0 and not #Switch_OPSFP_State == 3',
                rb_swm_OpenLinePADS1_flt   => '#Switch_PADS_Configured|1 == 1 and #Switch_PADS_State == 3',
                rb_swm_UndefinedPADS1_flt  => '#Switch_PADS_State == 2',
                rb_swm_UnexpectedPADS1_flt => '#Switch_PADS_Configured|1 == 0 and not #Switch_PADS_State == 3',
                rb_swm_OpenLineSPSFD_flt   => '#Switch_SPSFD_Configured|1 == 1 and #Switch_SPSFD_State == 3',
                rb_swm_UndefinedSPSFD_flt  => '#Switch_SPSFD_State == 2',
                rb_swm_UnexpectedSPSFD_flt => '#Switch_SPSFD_Configured|1 == 0 and not #Switch_SPSFD_State == 3',
            },
        },
        "AdditionalAfterCrash" => {
            "Generic"        => {
                "EventManagerFault" => {
                    "FaultName" => "rb_evm_.*CrashDetected_flt"
                },
                "CsemMonTempFaults_Clipping" => {
                    "EventDebugData" => "0b0000000100000000",
                    "FaultName"      => "rb_csem_MonTemp.*_flt"
                },
            },
            "CrashDependent" => {},
        },
    };

    foreach my $faultEvaluationSettingsKey ( keys %$faultEvaluationSettingsTemplate ) {

        next if ( exists $proj_const_crash_meas_eval_gen_href->{'Faults'}{$faultEvaluationSettingsKey});

        $proj_const_crash_meas_eval_gen_href->{'Faults'}{$faultEvaluationSettingsKey} = $faultEvaluationSettingsTemplate->{$faultEvaluationSettingsKey};
        print TODO "TODO :: Faults - Mapping updated with settings template for 'Faults'. Check content and use updated Mapping!!!\n";
        $newEntriesDetected = 1;
    }

    if ( ref( $proj_const_crash_meas_eval_gen_href->{'Faults'}{'AdditionalAfterCrash'}{'Generic'}) eq 'ARRAY' ) {
        $proj_const_crash_meas_eval_gen_href->{'Faults'}{'AdditionalAfterCrash'}{'Generic'} = $faultEvaluationSettingsTemplate->{AdditionalAfterCrash}{Generic};
        print TODO "TODO :: Faults - Mapping section updated: 'AdditionalAfterCrash - Generic'. Check content and adapt if needed!!!\n";
        print TODO "                                        : ".'https://inside-docupedia.bosch.com/confluence/display/aeos/Faults#Faults-new(CREIS_V6_x)'."\n";
        $newEntriesDetected = 1;
    }    

    my $fastDiagSettingsTemplate = {
        "NbrOfCanIDs"    => 4,
        "Configurations" => {
            "AlgoActive" => {
                "rb_fcl_StatusFirCtrl_u8" => "U8",
            },
        },
    };

    foreach my $fastDiagSettingsKey ( keys %$fastDiagSettingsTemplate ) {
        next if ( exists $proj_const_crash_meas_eval_gen_href->{'FastDiagTrace'}{$fastDiagSettingsKey} );

        $proj_const_crash_meas_eval_gen_href->{'FastDiagTrace'}{$fastDiagSettingsKey} = $fastDiagSettingsTemplate->{$fastDiagSettingsKey};
        print TODO "TODO :: FastDiagTrace - Mapping updated with settings template for 'FastDiagTrace'. Check content and use updated Mapping!!!\n";
        $newEntriesDetected = 1;
    }

    my $additionalPdLabelsReaderSettingsTemplate = {
        "Configurations" => {
            "PomAdcData" => {
                "VBat1" => {
                    "PdLabel" => "rb_pomv_PomAdcData_st.AdcValuesConverted_ast(0).Vbat1_u16",
                    "Mode"    => "dec",
                    "Factor"  => 0.01,
                    "Unit"    => "V",
                },
                "Ver" => {
                    "PdLabel" => "rb_pomv_PomAdcData_st.AdcValuesConverted_ast(0).Ver_u16",
                    "Mode"    => "dec",
                    "Factor"  => 0.01,
                    "Unit"    => "V",
                },
                "Temperature_ASIC1" => {
                    "PdLabel" => "rb_pomv_PomAdcData_st.AdcValuesConverted_ast(0).Temperature_s32",
                    "Mode"    => "dec",
                    "Factor"  => 0.1,
                    "Unit"    => "C",
                },
                "Temperature_ASIC2" => {
                    "PdLabel" => "rb_pomv_PomAdcData_st.AdcValuesConverted_ast(1).Temperature_s32",
                    "Mode"    => "dec",
                    "Factor"  => 0.1,
                    "Unit"    => "C",
                },
                "Vup" => {
                    "PdLabel" => "rb_pomv_PomAdcData_st.AdcValuesConverted_ast(0).Vup_u16",
                    "Mode"    => "dec",
                    "Factor"  => 0.01,
                    "Unit"    => "V",
                },
            },
        },
    };

    foreach my $additionalPdLabelsReaderSettingsKey ( keys %$additionalPdLabelsReaderSettingsTemplate ) {
        next if ( exists $proj_const_crash_meas_eval_gen_href->{'AdditionalPdLabels'}{$additionalPdLabelsReaderSettingsKey} );

        $proj_const_crash_meas_eval_gen_href->{'AdditionalPdLabels'}{$additionalPdLabelsReaderSettingsKey} = $additionalPdLabelsReaderSettingsTemplate->{$additionalPdLabelsReaderSettingsKey};
        print TODO "TODO :: AdditionalPdLabels - Mapping updated with settings template for 'AdditionalPdLabels'. Check content and use updated Mapping!!!\n";
        $newEntriesDetected = 1;
    }

    unless ( exists $proj_const_crash_meas_eval_gen_href->{'AdditionalMeasurements'} ) {
        $proj_const_crash_meas_eval_gen_href->{'AdditionalMeasurements'} = {};
        print TODO "TODO :: AdditionalMeasurements - Mapping updated with settings template for 'AdditionalMeasurements'. Check content and use updated Mapping!!!\n";
        $newEntriesDetected = 1;
    }

    if ( $newEntriesDetected and not $forceNewMapping ) {
        my $type_button = $mainwindow->messageBox(
            '-icon'    => "info",                                                                                                                                            #qw/error info question warning/
            '-type'    => "OK",                                                                                                                                              #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
            '-title'   => 'Attention',
            '-message' => "There are <<TODOs>> in your Mapping. You should create the mapping and check for the <<TODOs>>. All changes are documented in the LOG - File.",
        );
    }
}

sub CREIS_proj_constants {

    $curr_dir =~ s/\\/\\/g;

    my $temp       = $Prj_const_file . ".pm";
    my $createFile = 1;
    $output_project_const_file = "$curr_dir\\config\\$temp";

    if ( -e $output_project_const_file ) {
        print "$output_project_const_file exists\n";

        if ( $forceNewMapping and basename($output_project_const_file) eq basename($cREIS_Mapping_selected) ) {
            $output_project_const_file = dirname($output_project_const_file) . "\\" . basename( $output_project_const_file, ".pm" ) . time() . ".pm";

            my $newName = basename($output_project_const_file);

            my $type_button = $mainwindow->messageBox(
                '-icon'    => "info",                                                                                                                               #qw/error info question warning/
                '-type'    => "OK",                                                                                                                                 #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
                '-message' => "Selected name is the same as the actual file, but this should not be overwriten. Therefore a new file will be created '$newName'",
            );

            $createFile = 1;

        }
        else {
            my $type_button = $mainwindow->messageBox(
                '-icon'    => "question",                                                                                                                           #qw/error info question warning/
                '-type'    => "YesNo",                                                                                                                              #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
                '-message' => "File $temp Exists, Do you want to over write it ?"
            );
            if ( $type_button eq 'Yes' ) {
                $createFile = 1;
            }
            else {
                $createFile = 0;
            }
        }
    }

    if ($createFile) {
        open( PROJCONST, ">$output_project_const_file" ) || die "could not Overwrite $output_project_const_file file\n";
        print PROJCONST "## This file is generated using CREIS Configuration Generator Tool - $VERSION ##\n";
        print PROJCONST "## This file is generated from *.mdb: $MDB_file_selected ##\n\n";
        print PROJCONST "package LIFT_PROJECT;\n\n";
        $Data::Dumper::Terse = 1;
        $Data::Dumper::Useqq = 1;

        print PROJCONST '$Defaults -> {\'MDSRESULT\'} = ';
        $Data::Dumper::Sortkeys = \&hash_sorter($proj_const_mdsresult_gen_href);    #sort the hash keys in alphabetical order
        print PROJCONST Dumper($proj_const_mdsresult_gen_href);
        print PROJCONST "\;\n\n";

        print PROJCONST '$Defaults -> {\'CRASH_SIMULATION\'} = ';
        $Data::Dumper::Sortkeys = \&hash_sorter($proj_const_crash_simulation_gen_href);    #sort the hash keys in alphabetical order
        print PROJCONST Dumper($proj_const_crash_simulation_gen_href);
        print PROJCONST "\;\n\n";

        print PROJCONST '$Defaults -> {\'CRASH_MEASUREMENT_AND_EVALUATION\'} = ';
        $Data::Dumper::Sortkeys = \&hash_sorter($proj_const_crash_meas_eval_gen_href);     #sort the hash keys in alphabetical order
        print PROJCONST Dumper($proj_const_crash_meas_eval_gen_href);
        print PROJCONST "\;\n\n";

        foreach my $mappingSectionKey ( keys %{$remainingSections_href} ) {
            print PROJCONST '$Defaults -> {\'' . $mappingSectionKey . '\'} = ';
            $Data::Dumper::Sortkeys = \&hash_sorter( $remainingSections_href->{$mappingSectionKey} );    #sort the hash keys in alphabetical order
            print PROJCONST Dumper( $remainingSections_href->{$mappingSectionKey} );
            print PROJCONST "\;\n\n";
        }

        print PROJCONST "1\;";

        close(PROJCONST);
    }

    &Display_window($output_project_const_file);

}

############################################################################################

=head CREIS_TestList_gen

    Function Name    :: CREIS_TestList_gen
    Description      :: This function fetches all Crash Entity details from database and creates testlist for the user required crashes.
                        Default file name is TL_CREIS.txt and is saved at .\Testlists\ in LIFT Project.

Eg : TC_Name.CrashEntityIDsCrashEntityNames_State_State_Number

=cut

############################################################################################

sub CREIS_TestList_gen {
    my $MDB_file_processed = $MDB_file_selected;
    $MDB_file_processed =~ s/\//\\/g;

    print LOG "\n\n######################################################################\n";
    print LOG "### Creating TestList ###\n";
    print LOG "######################################################################\n";

    #open second window
    my $top = $mainwindow->Toplevel();

################################ TC frame in top window #####################
    my $TC_name_frm = $top->Frame()->pack( -padx => 8, -pady => 8 );
    $TC_name_frm->Label( -text => "TC Name" )->pack( -side => "top" )->pack( -side => "left" );
    $TC_name_frm->Entry( "-width" => 30, "-textvariable" => \$TC_name, )->pack( -side => "left" );

    #    my $TC_name_frm2 = $top->Frame()->pack( -padx => 8, -pady => 8 );
    #    $TC_name_frm2->Label( -text => "Global_Iteration" )->pack( -side => "top" )->pack( -side => "left" );
    #    $TC_name_frm2->Entry( "-width" => 5, "-textvariable" => \$G_iteration, )->pack( -side => "left" );
    #
    #    $TC_name_frm2->Label( -text => "Check to Update Iteration column" )->pack( -side => "top" )->pack( -side => "left" );
    #    $update_G_iteration = $TC_name_frm2->Checkbutton(
    #        -variable => \$update_iteration,
    #        -command  => \&update_iteration_column
    #    )->pack( -anchor => 'w' )->pack( -side => "left" );

################################ Test List frame in top window #####################
    my $TL_frm = $top->Frame()->pack( -padx => 8, -pady => 8 );
    $TL_frm->Label( -text => "Crash Details" )->pack( -side => "top" )->pack( -side => "left" );

################################ Test List frame in top window end #####################

    #Start the MDS database
    print LOG "CREIS_TestList_gen :: Start mdsresult\n";
    $start_status = mdsresult_Start();

    if ( $start_status < 0 ) {
        $errortext = mdsresult_GetErrorString( $start_status < 0 );

        $mainwindow->messageBox(
            '-icon'    => "error",                          #qw/error info question warning/
            '-type'    => "OK",                             #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
            '-title'   => 'Attention',
            '-message' => "!Couldnot start MDS database!"
        );

        print LOG "CREIS_TestList_gen Failed :: Error Description :: $errortext \n";
        close(LOG);
        close(TODO);
        destroy $mainwindow;                                #close the GUI tool
    }

    #Loads the mdb file
    print LOG "CREIS_TestList_gen :: Initialise mdsresult\n";
    my $status = mdsresult_SetFlagPrintDbgInfosEnabled( 1, dirname(__FILE__) );
    $InitResult_status = mdsresult_InitResult($MDB_file_processed);
    if ( $InitResult_status < 0 ) {
        $errortext = mdsresult_GetErrorString( $InitResult_status < 0 );

        $mainwindow->messageBox(
            '-icon'    => "error",                          #qw/error info question warning/
            '-type'    => "OK",                             #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
            '-title'   => 'Attention',
            '-message' => "!Coundnot load the mdb file!"
        );

        print LOG "CREIS_TestList_gen Failed :: Error Description :: $errortext \n";
        close(LOG);
        close(TODO);
        destroy $mainwindow;                                #close the GUI tool
    }

    #Get all Crash Entity details from database
    print LOG "CREIS_TestList_gen :: fetch all Crash Entity details from database\n";

    ( $GetCrashEntityIterations_status, $CrashEntityIDs, $CrashEntityNames, $State_Number ) = mdsresult_GetCrashEntityIterations();

    if ( $GetCrashEntityIterations_status < 0 ) {
        $errortext = mdsresult_GetErrorString($GetCrashEntityIterations_status);

        $mainwindow->messageBox(
            '-icon'    => "error",                                                    #qw/error info question warning/
            '-type'    => "OK",                                                       #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
            '-title'   => 'Attention',
            '-message' => "!Couldnot fetch all Crash Entity details from database!"
        );

        print LOG "CREIS_TestList_gen Failed :: Error Description :: $errortext \n";
        close(LOG);
        close(TODO);
        destroy $mainwindow;                                                          #close the GUI tool
    }
    print LOG "CREIS_TestList_gen :: mdsresult_GetCrashEntityIterations :: CrashEntityIDs :: @$CrashEntityIDs \n";
    print LOG "CREIS_TestList_gen :: mdsresult_GetCrashEntityIterations :: CrashEntityNames :: @$CrashEntityNames \n";
    print LOG "CREIS_TestList_gen :: mdsresult_GetCrashEntityIterations :: State_Number :: @$State_Number \n";

    # Unloads the MDSResult Process DLL
    print LOG "CREIS_TestList_gen :: Unload MDSResult DLL\n";
    $exit_status = mdsresult_CloseResult();
    if ( $exit_status < 0 ) {
        $errortext = mdsresult_GetErrorString($exit_status);

        $mainwindow->messageBox(
            '-icon'    => "error",                            #qw/error info question warning/
            '-type'    => "OK",                               #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
            '-title'   => 'Attention',
            '-message' => "!Couldnot unload MDSResult DLL!"
        );

        print LOG "CREIS_TestList_gen Failed :: Error Description :: $errortext \n";
        close(LOG);
        close(TODO);
        destroy $mainwindow;                                  #close the GUI tool
    }

    my @cnames = ( 'Checkbox', 'CrashName', 'CrashID', 'StateNumber' );

    my $cols = $#cnames;                                      #column size of the table

    my $rows_intermediate = scalar(@$State_Number);           #row size intermediate calculated to create below intermediate arrays

    $rows = undef;
    for ( my $p = 0 ; $p < scalar(@$State_Number) ; $p++ ) {
        $rows += $$State_Number[$p];                          #row size of the table
    }
    for ( my $i = 0 ; $i < $rows ; $i++ ) {
        $$Iteration[$i] = $G_iteration;
    }

    ( @CrashEntityCleanNames_intermediate, @CrashEntityNames_intermediate, @CrashEntityIDs_intermediate, @State_Number_intermediate, @Iteration_intermediate ) = ();    #empty the array before use
    for ( my $p = 0 ; $p < $rows_intermediate ; $p++ ) {
        if ( $$State_Number[$p] > 1 ) {
            for ( my $c = 1 ; $c <= $$State_Number[$p] ; $c++ ) {
                push( @CrashEntityCleanNames_intermediate, cleanStrings( $$CrashEntityNames[$p] ) );
                push( @CrashEntityNames_intermediate,      $$CrashEntityNames[$p] );
                push( @CrashEntityIDs_intermediate,        $$CrashEntityIDs[$p] );
                push( @State_Number_intermediate,          $c );                                                                                                        #states shall be displayed in table as 1,2,... n if n>1
                push( @Iteration_intermediate,             $$Iteration[$p] );
            }
        }
        else {
            push( @CrashEntityCleanNames_intermediate, cleanStrings( $$CrashEntityNames[$p] ) );
            push( @CrashEntityNames_intermediate,      $$CrashEntityNames[$p] );
            push( @CrashEntityIDs_intermediate,        $$CrashEntityIDs[$p] );
            push( @State_Number_intermediate,          $$State_Number[$p] );
            push( @Iteration_intermediate,             $$Iteration[$p] );
        }
    }

    #create table frame to display --> @cnames
    my $tableFrame = $top->Frame(
        -borderwidth => 2,
        -relief      => 'raised'
    )->pack;
    $top->resizable( 0, 0 );

    # allocate a table to the frame
    my $table = $tableFrame->Table(
        -columns    => 8,
        -rows       => 10,
        -fixedrows  => 1,
        -scrollbars => 'se',
        -relief     => 'raised'
    );

    # column headings
    foreach my $c ( 0 .. $cols ) {
        my $tmp = $table->Label(
            -text   => $cnames[$c],
            -width  => 16,
            -relief => 'raised'
        );
        $table->put( 0, $c, $tmp );
    }

    # populate the cells and bind an action to each one
    my ( $chk, @check );
    (@check) = ();

    foreach my $r ( 1 .. $rows ) {
        my $tmp;
        foreach my $c ( 0 .. $cols ) {
            if ( $c == 0 ) {
                $chk = $table->Checkbutton(
                    -variable => \$check[ $r - 1 ],
                    -onvalue  => 'CHECKED',
                    -offvalue => 'NOT_CHECKED'
                )->pack( -anchor => 'w' )->pack( -side => "left" );
                $chk->bind( 'text', [$table] );
                $table->put( $r, $c, $chk );
                $chk->select;
            }
            if ( $c == 1 ) {
                $tmp = $table->Label(
                    -text       => $CrashEntityNames_intermediate[ $r - 1 ],
                    -padx       => 2,
                    -background => 'white',
                );
                $tmp->bind( 'text', [$table] );
                $table->put( $r, $c, $tmp );
            }
            if ( $c == 2 ) {
                $tmp = $table->Label(
                    -text       => $CrashEntityIDs_intermediate[ $r - 1 ],
                    -padx       => 2,
                    -background => 'white',
                );
                $tmp->bind( 'text', [$table] );
                $table->put( $r, $c, $tmp );
            }
            if ( $c == 3 ) {
                $tmp = $table->Label(
                    -text       => $State_Number_intermediate[ $r - 1 ],
                    -padx       => 2,
                    -background => 'white',
                );
                $tmp->bind( 'text', [$table] );
                $table->put( $r, $c, $tmp );
            }
        }
    }
    $table->pack( -expand => 'yes', -fill => 'both' );

################################ Preview frame in top window #####################
    my $preview_frm = $top->Frame()->pack( -padx => 8, -pady => 8 );

    $preview_frm->Button(
        -text    => "Check All",
        -width   => 10,
        -command => sub {
            for ( my $r = 0 ; $r < $rows ; $r++ ) { $check[$r] = "CHECKED"; }
        }
    )->pack( -side => "left" );

    $preview_frm->Button(
        -text    => "uncheck All",
        -width   => 10,
        -command => sub {
            for ( my $r = 0 ; $r < $rows ; $r++ ) { $check[$r] = "NOT_CHECKED"; }
        }
    )->pack( -side => "left" );

    $preview_frm->Button(
        -text    => "Create",
        -command => sub {
            no warnings;
            if ( grep { $_ eq "CHECKED" } @check ) {
                if ($TC_name) {
                    my $temp = $TL_file . '.txt';
                    $output_TestList_file = dirname($MDB_file_selected) . "\\$temp";
                    if ( -e $output_TestList_file ) {
                        print "$output_TestList_file exists\n";

                        my $type_button = $mainwindow->messageBox(
                            '-icon'    => "question",                                           #qw/error info question warning/
                            '-type'    => "YesNo",                                              #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                            '-title'   => 'Attention',
                            '-message' => "File $temp Exists, Do you want to over write it ?"
                        );
                        if ( $type_button eq 'Yes' ) {
                            open( TLFILE, ">$output_TestList_file" ) || die("cannot Overwrite $output_TestList_file file\n");
                            print TLFILE "## This file is generated using CREIS Configuration Generator Tool - $VERSION ##\n";
                            print TLFILE "## This file is generated from *.mdb: $MDB_file_selected ##\n";
                            print TLFILE "# TestList structure : TC_name.CrashEntityIDs_CrashEntityNames_State_State_Number\n\n";

                            for ( my $i = 0 ; $i < $rows ; $i++ ) {
                                no warnings;
                                if ( $check[$i] eq "CHECKED" ) {
                                    for ( my $j = 0 ; $j < $$Iteration[$i] ; $j++ ) {
                                        print TLFILE $TC_name . "." . $CrashEntityIDs_intermediate[$i] . "_" . $CrashEntityCleanNames_intermediate[$i] . "_State_" . $State_Number_intermediate[$i] . "\n";
                                    }
                                }
                            }
                            close(TLFILE);
                            $testlist_gen_flag = 1;
                            &Display_window($output_TestList_file);
                        }
                        else {
                            &Display_window($output_TestList_file);
                        }
                    }
                    else {
                        open( TLFILE, ">$output_TestList_file" ) || die("cannot Overwrite $output_TestList_file file\n");
                        print TLFILE "## This file is generated using CREIS Configuration Generator Tool - $VERSION ##\n";
                        print TLFILE "## This file is generated from *.mdb: $MDB_file_selected ##\n";
                        print TLFILE "# TestList structure : TC_name.CrashEntityIDs_CrashEntityNames_State_State_Number\n\n";
                        for ( my $i = 0 ; $i < $rows ; $i++ ) {
                            no warnings;
                            if ( $check[$i] eq "CHECKED" ) {
                                for ( my $j = 0 ; $j < $$Iteration[$i] ; $j++ ) {
                                    print TLFILE $TC_name . "." . $CrashEntityIDs_intermediate[$i] . "_" . $CrashEntityCleanNames_intermediate[$i] . "_State_" . $State_Number_intermediate[$i], "\n";
                                }
                            }
                        }
                        close(TLFILE);
                        $testlist_gen_flag = 1;
                        &Display_window($output_TestList_file);
                    }
                }
                else {
                    $mainwindow->messageBox(
                        '-icon'    => "error",            #qw/error info question warning/
                        '-type'    => "OK",               #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                        '-title'   => 'Attention',
                        '-message' => "!Enter TC Name!"
                    );
                }
            }
            else {
                $mainwindow->messageBox(
                    '-icon'    => "error",                              #qw/error info question warning/
                    '-type'    => "OK",                                 #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                    '-title'   => 'Attention',
                    '-message' => "Please select the Crash Name(s) !"
                );
            }
        }
    )->pack( -side => "left" );

    $preview_frm->Button(
        -text    => "Close",
        -width   => 10,
        -command => sub { $display_TL_flag = 0; destroy $top; }
    )->pack( -side => "left" );

}
############################################################################################

=head CREIS_para_gen

    Function Name    :: CREIS_para_gen
    Description      :: This function creates parameter file corresponding to the Testlist created.
                        This function shall be called after creating Testlist.
                        Default file name is TC_CREIS_StandardTest.par and is saved at .\TC_par\ in LIFT Project.
                        If the test case name is changed then the file name is automatically updated to the new name.

Eg : TC Name.CrashEntityIDsCrashEntityNames_State_State_Number
     CrashNumber = '1'
     CrashName = '102036'
     IterationNumber = '1'

=cut

############################################################################################

sub CREIS_para_gen {
    my $MDB_file_processed = $MDB_file_selected;
    $MDB_file_processed =~ s/\//\\/g;

    print LOG "\n\n######################################################################\n";
    print LOG "### Creating Parameter File ###\n";
    print LOG "######################################################################\n";
    if ($testlist_gen_flag) {
        my $temp = $TC_name . '.par';
        $output_parameter_file = dirname($MDB_file_selected) . "\\$temp";
        if ( -e $output_parameter_file ) {
            print "$output_parameter_file exists\n";

            my $type_button = $mainwindow->messageBox(
                '-icon'    => "question",                                           #qw/error info question warning/
                '-type'    => "YesNo",                                              #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
                '-message' => "File $temp Exists, Do you want to over write it ?"
            );
            if ( $type_button eq 'Yes' ) {
                open( PARAM, ">$output_parameter_file" ) || die("cannot Overwrite file $output_parameter_file : $!\n");

                print PARAM "## This file is generated using CREIS Configuration Generator Tool - $VERSION ##\n";
                print PARAM "## This file is generated from *.mdb: $MDB_file_selected ##\n\n";

                for ( my $i = 0 ; $i < scalar(@State_Number_intermediate) ; $i++ ) {
                    no warnings;
                    $parameter_array[$i] = $TC_name . "." . $CrashEntityIDs_intermediate[$i] . "_" . $CrashEntityCleanNames_intermediate[$i] . "_State_" . $State_Number_intermediate[$i], "\n";
                    print PARAM "[$parameter_array[$i]]\n";
                    print PARAM "Ubat               = 'U_BATT_DEFAULT'\n";
                    print PARAM "CreisInputFile     = '$MDB_file_processed'\n";
                    print PARAM "CrashNumber        = '$CrashEntityIDs_intermediate[$i]'\n";
                    print PARAM "CrashName          = '$CrashEntityNames_intermediate[$i]'\n";
                    print PARAM "State              = '$State_Number_intermediate[$i]'\n";
                }

                close(PARAM);

                &Display_window($output_parameter_file);
            }
            else {
                &Display_window($output_parameter_file);
            }
        }
        else {
            open( PARAM, ">$output_parameter_file" ) || die("cannot Overwrite file $output_parameter_file : $!\n");

            print PARAM "## This file is generated using CREIS Configuration Generator Tool - $VERSION ##\n";
            print PARAM "## This file is generated from *.mdb: $MDB_file_selected ##\n\n";
            for ( my $i = 0 ; $i < scalar(@State_Number_intermediate) ; $i++ ) {
                no warnings;
                $parameter_array[$i] = $TC_name . "." . $CrashEntityIDs_intermediate[$i] . "_" . $CrashEntityCleanNames_intermediate[$i] . "_State_" . $State_Number_intermediate[$i], "\n";
                print PARAM "[$parameter_array[$i]]\n";
                print PARAM "Ubat               = 'U_BATT_DEFAULT'\n";
                print PARAM "CreisInputFile     = '$MDB_file_processed'\n";
                print PARAM "CrashNumber        = '$CrashEntityIDs_intermediate[$i]'\n";
                print PARAM "CrashName          = '$CrashEntityNames_intermediate[$i]'\n";
                print PARAM "State              = '$State_Number_intermediate[$i]'\n";
            }

            close(PARAM);

            &Display_window($output_parameter_file);
        }

    }
    else {
        $mainwindow->messageBox(
            '-icon'    => "error",                     #qw/error info question warning/
            '-type'    => "OK",                        #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
            '-title'   => 'Attention',
            '-message' => "!Create Test List First!"
        );

    }
}

############################################################################################

=head Display_window

    Function Name    :: Display_window
    Description      :: This function opens the given file and displayes it on the window.
                        User cannot edit the contents displayed in this window. 

=cut

############################################################################################

sub Display_window {
    my $opt_output_file = shift;

######################### Create Toplevel window ###########################
    my $top = $mainwindow->Toplevel();
    $top->resizable( 0, 0 );
######################### Toplevel window label ###########################
    my $top_lab = $top->Label(
        -text => "Preview window",
        -font => "ansi 12 bold"
    )->pack;

######################### Toplevel window text ###########################
    my $txt = $top->Text( -width => 150, -height => 50 )->pack;

######################### Close button for Toplevel window  ###########################
    my $top_CloseButton_frame = $top->Frame()->pack( -padx => 8, -pady => 8 );

    $top_CloseButton_frame->Button(
        -text    => "Close",
        -command => sub {
            if ($display_PJ_const_flag) {
                $display_PJ_const_flag = 0;
            }
            if ($display_TL_flag) {
                $display_TL_flag = 0;
            }
            if ($display_para_flag) {
                $display_para_flag = 0;
            }
            destroy $top;
        }
    )->pack( -side => "left" );

######################### Toplevel window label ###########################
    my $top_lab_botton = $top->Label(
        -text => " File Location : $opt_output_file",
        -font => "Courier 12"
    )->pack( -side => "bottom" );
    {

        no warnings;
        open( TEMP, "$opt_output_file" ) || die("cannot Open file $opt_output_file : $!\n");
        my @file = <TEMP>;

        for my $line (@file) {
            $txt->insert( 'end', $line );
        }
        print TEMP $txt;
        close(TEMP);
        print color 'green';
        print "The $opt_output_file successfully Created\n";
        print LOG "successfully Created --> $opt_output_file \n";
        print color 'reset';
    }
}

sub update_iteration_column {
    if ($update_iteration) {
        for ( my $i = 0 ; $i < $rows ; $i++ ) {
            $$Iteration[$i] = $G_iteration;
        }
        $update_iteration = 0;
    }
}

###################################################################################

=head cleanStrings

    Function Name    :: cleanStrings
    Description      :: This function replaces german umlauts and cleans all other special signs.

=cut

###################################################################################

sub cleanStrings {
    my $string = shift;

    $string =~ s/�/ae/g;
    $string =~ s/�/oe/g;
    $string =~ s/�/ue/g;
    $string =~ s/�/Ae/g;
    $string =~ s/�/Oe/g;
    $string =~ s/�/Ue/g;
    $string =~ s/�/ss/g;
    $string =~ s/\W/\_/g;
    $string =~ s/_+/_/g;

    return $string;
}

###################################################################################

=head hash_sorter

    Function Name    :: hash_sorter
    Description      :: This function returns an hash ref containing the hash keys to dump
                        in alphabetical order .

=cut

###################################################################################

sub hash_sorter {
    my ($hash) = @_;
    return ( sort keys %$hash );
}

###################################################################################

# SYNOPSIS
#   openurl <url>
# DESCRIPTION
#   Opens the specified URL in the system's default browser.
# COMPATIBILITY
#   OSX, Windows (including MSYS, Git Bash, and Cygwin), as well as Freedesktop-compliant
#   OSs, which includes many Linux distros (e.g., Ubuntu), PC-BSD, OpenSolaris...
sub openurl {
    my $url      = shift;
    if ( -e 'C:\Program Files (x86)\Mozilla Firefox\firefox.exe' ) {

            # workaround with 'CMD' because just calling 'start' causes MKS error 'wrong OS' (there is a start.exe in MKS subfolder)
            system( 'CMD /C start "C:\Program Files (x86)\Mozilla Firefox\firefox.exe" ' . "$url" );    # open in Firefox Win7
        }
        elsif ( -e 'C:\Program Files\Mozilla Firefox\firefox.exe' ) {
            system( 'start "C:\Program Files\Mozilla Firefox\firefox.exe" ' . "$url" );                 # open in Firefox
        }
}

print LOG "\n######################################################################\n";
print LOG "END OF LOGFILE\n\n\n";

close(LOG);
close(TODO);
