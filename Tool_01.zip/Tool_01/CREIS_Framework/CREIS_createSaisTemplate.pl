#!usr\bin\perl.exe -w
# *****************************************************************************************************
#
#  Copyright (c) 2012  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#    $Source: CREIS_Framework/CREIS_createSaisTemplate.pl $
#    $Revision: 1.1 $
#    $Author: Schwibus Dirk (CC-PS/EPS2) (SDW2BUE) $
#    $State: develop $
#    $Date: 2017/07/07 13:55:05ICT $
#******************************************************************************************************
use warnings;
use strict;
#################################################################################
# this tool is under MKS version management
my $VERSION = q$Revision: 1.1 $;
my $HEADER  = q$Header: CREIS_Framework/CREIS_createSaisTemplate.pl 1.1 2017/07/07 13:55:05ICT Schwibus Dirk (CC-PS/EPS2) (SDW2BUE) develop  $;
#################################################################################

use Tk;
use Tk::Table;
use Tk::DirTree;
use Data::Dumper;
use Excel::Writer::XLSX;
use Excel::Writer::XLSX::Utility;
use Font::TTFMetrics;
use File::Basename;
use Data::Dumper;
use Win32::Console::ANSI;
use Term::ANSIColor;

my $addpath;
my $calibri = Font::TTFMetrics->new('c:\windows\fonts\calibri.ttf');

BEGIN {
    use Config;
    use File::Spec;
    use File::Basename;

    # find the LIFT engine path (LIFT_engine_path = ./../)
    my $lift_exec_path = File::Spec->rel2abs( dirname( dirname(__FILE__) ) ) . "/Engine";

    unshift @INC, "$lift_exec_path/modules/";
    unshift @INC, "$lift_exec_path/modules/TC_FunctionLib";
    unshift @INC, "$lift_exec_path/modules/TC_FunctionLib/TC_CustLib";
    unshift @INC, "$lift_exec_path/modules/TC_FunctionLib/TC_Project";
    unshift @INC, "$lift_exec_path/modules/TC_FunctionLib/TC_TNT";

    # add directories to search path for perl modules
    $addpath = "$lift_exec_path/modules/DLLs/MDSResult";
    my $perl56 = $addpath . "/Perl56";    #perl 5.6(32-bit) DLL directory
    my $win32  = $addpath . "/Win32";     #perl 5.12, 32-bit DLL directory
    my $win64  = $addpath . "/Win64";     #perl 5.12, 64-bit DLL directory

    if ( $] =~ m/5.006/i ) {              #if Perl version is 5.6
        unshift @INC, ( $addpath, $perl56 );    #Include MDSResult.pm from Root directory, Load MDSResult.dll from "Perl56"
        $ENV{PATH} = $win32 . ";$ENV{PATH}";    #Load MDSResult.dll from "Win32"
    }
    elsif ( $] =~ m/5.012/i ) {                 #if Perl version is 5.12
        if ( $Config{'archname'} =~ m/x64/i ) {    #check the bitness of perl (32-bit or 64-bit)
            unshift @INC, ( $addpath, $win64 );    #Include MDSResult.pm from Root directory, Load MDSResult.dll from "Win64"
            $ENV{PATH} = $win64 . ";$ENV{PATH}";   #Load MDSResult.dll from "Win64"
        }
        else {
            unshift @INC, ( $addpath, $win32 );    #Include MDSResult.pm from Root directory, Load MDSResult.dll from "Win32"
            $ENV{PATH} = $win32 . ";$ENV{PATH}";   #Load MDSResult.dll from "Win32"
        }
    }
}

use MDSResult;
use POSIX qw/strftime/;

###########declare all variables used

# new variables after rework
my $saisTemplateFileSelected = "";
my $mdbFileSelected          = "";
my ( $formatAlgoPC, $formatProjectTeam, $formatSubSectionHeadline, $formatHeadlineLeft, $formatHeadlineCentral, $formatHeadlineRight, $formatContentLeft, $formatContentCentral, $formatContentRight, $formatGenericContent, $formatLastRow, );

#create a LOG file
open( LOG, ">CREIS_createSaisTemplate_Log.txt" ) || die("couldnot open CREIS_createSaisTemplate_Log.txt\n");
print LOG "######################################################################\n";
print LOG "### CREIS SAIS Template GENERATOR GUI REPORT ###\n";
print LOG "######################################################################\n";

############################### Start Tk Window ################################
#Create Main window
my $mainWindow = MainWindow->new;
$mainWindow->resizable( 0, 0 );

#Size of main window display
$mainWindow->geometry("700x175");

################### Start Create frames in main window ############################
my $headFrame         = $mainWindow->Frame()->pack( -padx => 3, -pady => 10, -fill => 'x' );    #Frame contains the heading
my $inputFileFrame    = $mainWindow->Frame()->pack( -padx => 3, -pady => 8,  -fill => 'x' );    #Frame contains the mdb file path
my $outputFileFrame   = $mainWindow->Frame()->pack( -padx => 3, -pady => 8,  -fill => 'x' );    #Frame contains the project folder path
my $actionButtonFrame = $mainWindow->Frame()->pack( -padx => 3, -pady => 8,  -fill => 'x' );    #Frame contains Close and ResetAll buttons

################### Header frame label in main window ############################
$headFrame->Label( -text => 'CREIS - SAIS template generator', -font => "Verdana 12 bold italic underline" )->pack();

######################### Action Button Frame with Create and Close Button ###########################
my $createButton = $actionButtonFrame->Button(
    -text          => "Create",
    -state         => "disabled",
    "-borderwidth" => 3,
    -command       => sub { &CreateSaisTemplate }
)->pack( -side => "left", -expand => 1, -fill => 'x' );

######################### .mdb file frame ###########################
$inputFileFrame->Label( -width => 25, -text => '.mdb file path ' )->pack( -side => "left" );
$inputFileFrame->Entry( -width => 70, "-textvariable" => \$mdbFileSelected, -state => "readonly" )->pack( -side => "left" );

$inputFileFrame->Button(
    -width         => 10,
    "-text"        => "Browse...",
    "-borderwidth" => 3,
    "-command"     => sub {

        # browse for file
        $mdbFileSelected = $mainWindow->getOpenFile(
            "-filetypes" => [ [ "MDS DataBase", '.mdb' ], [ "All files", '.*' ] ],
            "-title" => "choose a .mdb file(*.mdb)",
        );
        if ($mdbFileSelected) {

            # first check if the .mdb file is selected else throw a message asking for the .mdb file
            if ( $mdbFileSelected =~ /\.mdb$/ ) {
                print LOG "*.mdb File chosen :: $mdbFileSelected \n";
                if ( $saisTemplateFileSelected =~ /\.xlsx$/ ) {
                    $createButton->configure( -state => "normal" );
                }
                else {
                    $createButton->configure( -state => "disabled" );
                }
            }
            else {
                $mainWindow->messageBox(
                    '-icon'    => "error",               #qw/error info question warning/
                    '-type'    => "OK",                  #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                    '-title'   => 'Attention',
                    '-message' => "!Select .mdb file!"
                );
                $mdbFileSelected = "";
            }
        }
        else {
            print "no filename!\n";

            # prompt user
            $mainWindow->messageBox(
                '-icon'    => "error",                   #qw/error info question warning/
                '-type'    => "OK",                      #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
                '-message' => "!Select .mdb file!"
            );
        }
    },
)->pack( -side => 'right' );

######################### Project Folder Path frame ###########################
$outputFileFrame->Label( -width => 25, -text => 'SAIS Template ' )->pack( -side => "left" );
$outputFileFrame->Entry( -width => 70, -textvariable => \$saisTemplateFileSelected, -state => "readonly" )->pack( -side => "left" );

$outputFileFrame->Button(
    -width         => 10,
    "-text"        => "Browse...",
    "-borderwidth" => 3,
    "-command"     => sub {

        # browse for file
        $saisTemplateFileSelected = $mainWindow->getSaveFile(
            -defaultextension => "xlsx",
            -initialfile      => "SAIS_ProjectXYZ.xlsx",
            -filetypes        => [ [ "SAIS_Template", '.xlsx' ], [ "All files", '.*' ] ],
            -title            => "Store SAIS template as (*.xlsx)",
        );
        if ($saisTemplateFileSelected) {

            if ( $saisTemplateFileSelected =~ /\.xlsx$/ ) {
                print LOG "*.xlsx File chosen :: $saisTemplateFileSelected \n";
                if ( $mdbFileSelected =~ /\.mdb$/ ) {
                    $createButton->configure( -state => "normal" );
                }
                else {
                    $createButton->configure( -state => "disabled" );
                }
            }
            else {
                $mainWindow->messageBox(
                    '-icon'    => "error",                              #qw/error info question warning/
                    '-type'    => "OK",                                 #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                    '-title'   => 'Attention',
                    '-message' => "!Select *SAIS_Template.xlsx file!"
                );
                $saisTemplateFileSelected = "";
            }
        }
        else {
            print "no filename!\n";

            # prompt user
            $mainWindow->messageBox(
                '-icon'    => "error",                                  #qw/error info question warning/
                '-type'    => "OK",                                     #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
                '-message' => "!Select *SAIS_Template.xlsx file!"
            );
        }
    },
)->pack( -side => 'right' );

MainLoop;

sub CreateSaisTemplate {
    my $MDB_file_processed = $mdbFileSelected;

    print LOG "\n\n######################################################################\n";
    print LOG "### Creating SAIS Template ###\n";
    print LOG "######################################################################\n";

    my ( $start_status, $errortext, $initResultStatus );

    #Start the MDS database
    print LOG "CreateSaisTemplate :: Start mdsresult\n";
    $start_status = mdsresult_Start();
    if ( $start_status < 0 ) {
        $errortext = mdsresult_GetErrorString( $start_status < 0 );

        $mainWindow->messageBox(
            '-icon'    => "error",                          #qw/error info question warning/
            '-type'    => "OK",                             #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
            '-title'   => 'Attention',
            '-message' => "!Couldnot start MDS database!"
        );

        print LOG "CreateSaisTemplate Failed :: Error Description :: $errortext \n";
        close(LOG);
        destroy $mainWindow;                                #close the GUI tool
    }
    print LOG "CreateSaisTemplate :: mdsresult_Start :: status :: $start_status\n";

    #Loads the mdb file
    print LOG "CreateSaisTemplate :: Initialise mdsresult\n";

    $initResultStatus = mdsresult_InitResult($MDB_file_processed);
    if ( $initResultStatus < 0 ) {
        $errortext = mdsresult_GetErrorString( $initResultStatus < 0 );

        $mainWindow->messageBox(
            '-icon'    => "error",                          #qw/error info question warning/
            '-type'    => "OK",                             #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
            '-title'   => 'Attention',
            '-message' => "!Coundnot load the mdb file!"
        );

        print LOG "CreateSaisTemplate Failed :: Error Description :: $errortext \n";
        close(LOG);
        destroy $mainWindow;                                #close the GUI tool
    }
    print LOG "CreateSaisTemplate :: mdsresult_InitResult :: status :: $initResultStatus\n";

    #Fetch all Sensor Details from database
    print LOG "CreateSaisTemplate :: Fetch Sensor Details from database\n";
    my ( $GetSensorDetails_status, $ModuleName, $SensorName, $SensorDirection, $SensorType ) = mdsresult_GetSensorDetails();

    if ( $GetSensorDetails_status < 0 ) {
        $errortext = mdsresult_GetErrorString($GetSensorDetails_status);

        $mainWindow->messageBox(
            '-icon'    => "error",                                          #qw/error info question warning/
            '-type'    => "OK",                                             #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
            '-title'   => 'Attention',
            '-message' => "!Couldnot fetch Sensor Details from database!"
        );

        print LOG "CreateSaisTemplate Failed :: Error Description :: $errortext \n";
        close(LOG);
        destroy $mainWindow;                                                #close the GUI tool
    }
    print LOG "CreateSaisTemplate :: mdsresult_GetSensorDetails :: status :: $GetSensorDetails_status\n";
    print LOG "CreateSaisTemplate :: mdsresult_GetSensorDetails :: ModuleName :: @$ModuleName \n";
    print LOG "CreateSaisTemplate :: mdsresult_GetSensorDetails :: SensorName :: @$SensorName \n";
    print LOG "CreateSaisTemplate :: mdsresult_GetSensorDetails :: SensorDirection :: @$SensorDirection \n";
    print LOG "CreateSaisTemplate :: mdsresult_GetSensorDetails :: SensorType :: @$SensorType \n";

    #Get all SIMDevice Details from database
    print LOG "CreateSaisTemplate :: Get all SIMDevice Details from database\n";
    my ( $GetSimDevices_status, $SimDevices_aref ) = mdsresult_GetSimDevices();

    if ( $GetSimDevices_status < 0 ) {
        $errortext = mdsresult_GetErrorString($GetSimDevices_status);

        $mainWindow->messageBox(
            '-icon'    => "error",                                                 #qw/error info question warning/
            '-type'    => "OK",                                                    #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
            '-title'   => 'Attention',
            '-message' => "!Couldnot fetch all SIMDevice Details from database!"
        );
        print LOG "CreateSaisTemplate :: mdsresult_GetSimDevices :: status :: $GetSimDevices_status\n";
        print LOG "CreateSaisTemplate Failed :: Error Description :: $errortext \n";
        close(LOG);
        destroy $mainWindow;                                                       #close the GUI tool
    }

    print LOG "CreateSaisTemplate :: mdsresult_GetSimDevices :: status :: $GetSimDevices_status\n";
    print LOG "CreateSaisTemplate :: mdsresult_GetSimDevices :: SimDevices :: @{$SimDevices_aref} \n";

    #Get all Constant Env Params from database
    print LOG "CreateSaisTemplate :: Get all Constant Env Params from database\n";
    my ( $GetConstantEnvParams_status, $EnvName_Const, $EnvVals ) = mdsresult_GetConstantEnvParams();

    if ( $GetConstantEnvParams_status < 0 ) {
        $errortext = mdsresult_GetErrorString($GetConstantEnvParams_status);

        $mainWindow->messageBox(
            '-icon'    => "error",                                                   #qw/error info question warning/
            '-type'    => "OK",                                                      #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
            '-title'   => 'Attention',
            '-message' => "!Couldnot fetch all Constant Env Params from database!"
        );

        print LOG "CreateSaisTemplate Failed :: Error Description :: $errortext \n";
        close(LOG);
        destroy $mainWindow;                                                         #close the GUI tool
    }
    print LOG "CreateSaisTemplate :: mdsresult_GetConstantEnvParams :: status :: $GetConstantEnvParams_status\n";
    print LOG "CreateSaisTemplate :: mdsresult_GetConstantEnvParams :: EnvName_Const :: @$EnvName_Const \n";
    print LOG "CreateSaisTemplate :: mdsresult_GetConstantEnvParams :: EnvVals :: @$EnvVals \n";

    my ( $GetDynamicEnvParams_status, $EnvName_Dynamic ) = mdsresult_GetDynamicEnvParams();
    if ( $GetDynamicEnvParams_status < 0 ) {
        $errortext = mdsresult_GetErrorString($GetDynamicEnvParams_status);

        $mainWindow->messageBox(
            '-icon'    => "error",                                                   #qw/error info question warning/
            '-type'    => "OK",                                                      #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
            '-title'   => 'Attention',
            '-message' => "!Couldnot fetch all Dynamic Env Params from database!"
        );

        print LOG "CreateSaisTemplate Failed :: Error Description :: $errortext \n";
        close(LOG);
        destroy $mainWindow;                                                         #close the GUI tool
    }
    print LOG "CreateSaisTemplate :: mdsresult_GetDynamicEnvParams :: status :: $GetDynamicEnvParams_status\n";
    print LOG "CreateSaisTemplate :: mdsresult_GetDynamicEnvParams :: EnvName_Dynamic :: @$EnvName_Dynamic \n";

    # Unloads the MDSResult Process DLL
    print LOG "CreateSaisTemplate :: Unload MDSResult DLL\n";
    my $exit_status = mdsresult_CloseResult();
    if ( $exit_status < 0 ) {
        $errortext = mdsresult_GetErrorString($exit_status);

        $mainWindow->messageBox(
            '-icon'    => "error",                                                   #qw/error info question warning/
            '-type'    => "OK",                                                      #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
            '-title'   => 'Attention',
            '-message' => "!Couldnot unload MDSResult DLL!"
        );
        print LOG "CreateSaisTemplate Failed :: Error Description :: $errortext \n";
        close(LOG);
        destroy $mainWindow;                                                         #close the GUI tool
    }
    print LOG "CreateSaisTemplate :: mdsresult_CloseResult :: status :: $exit_status\n";

    # start preparing the excel sheet

    my $workbook = Excel::Writer::XLSX->new($saisTemplateFileSelected);
    die "Problems creating new Excel file: $!" unless defined $workbook;

    unless ( defined $workbook ) {

        $mainWindow->messageBox(
            '-icon'    => "error",                                                   #qw/error info question warning/
            '-type'    => "OK",                                                      #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
            '-title'   => 'Attention',
            '-message' => "!Could not create xlsx - File!"
        );
        print LOG "CreateSaisTemplate Failed :: Error creating selected SAIS Template File \n";
        close(LOG);
        destroy $mainWindow;                                                         #close the GUI tool
    }

    $formatAlgoPC             = $workbook->add_format( bold => 1, bg_color => '#A9D08E', border => 2, valign => 'vcenter', align => 'center' );
    $formatProjectTeam        = $workbook->add_format( bold => 1, bg_color => '#8EA9DB', border => 2, valign => 'vcenter', align => 'center', );
    $formatSubSectionHeadline = $workbook->add_format( bold => 1, bg_color => '#C0C0C0', border => 2, valign => 'vcenter', align => 'center', );
    $formatHeadlineLeft       = $workbook->add_format( bold => 1, bottom   => 2,         top    => 2, left   => 2,         right => 1 );
    $formatHeadlineCentral    = $workbook->add_format( bold => 1, bottom   => 2,         top    => 2, left   => 1,         right => 1 );
    $formatHeadlineRight      = $workbook->add_format( bold => 1, bottom   => 2,         top    => 2, left   => 1,         right => 2 );
    $formatContentLeft    = $workbook->add_format( bottom   => 1,         left   => 2, right => 1 );
    $formatContentCentral = $workbook->add_format( bottom   => 1,         left   => 1, right => 1 );
    $formatContentRight   = $workbook->add_format( bottom   => 1,         left   => 1, right => 2 );
    $formatGenericContent = $workbook->add_format( bg_color => '#D9D9D9', bottom => 1, left  => 1, right => 2 );
    $formatLastRow = $workbook->add_format( top => 2 );

    CreateCoverSheet($workbook);
    CreateSensorsSheet( $workbook, $ModuleName, $SensorName, $SensorDirection, $SensorType );
    CreateEnvironmentalParametersSheet( $workbook, [ @$EnvName_Dynamic, @$EnvName_Const ] );
    CreateSimDevicesSheet( $workbook, $SimDevices_aref );
    return 1;
}

sub CreateSimDevicesSheet {
    my $workbook        = shift;
    my $simDevices_aref = shift;

    my $worksheet = $workbook->add_worksheet("SimDevices");
    my ( $row, );

    $worksheet->set_row( 1, 20 );
    $worksheet->write( 1, 1, "Algo PC", $formatAlgoPC );
    $worksheet->merge_range( 1, 2, 1, 3, "Project Team (Algo Mentor, SW Mentor, System Architect, ...)", $formatProjectTeam );

    AutofitStartStoringStringWidths($worksheet);

    $worksheet->set_row( 2, 15 );
    $worksheet->merge_range( 2, 1, 2, 3, "Squibs", $formatSubSectionHeadline );

    $row = 3;
    $worksheet->write( $row, 1, "SimDevice Name", $formatHeadlineLeft );

    $worksheet->write( $row, 2, "", $formatHeadlineLeft );
    $worksheet->write( $row, 3, "", $formatHeadlineRight );

    foreach my $simDevice (@$simDevices_aref) {
        $row++;
        $worksheet->write( $row, 1, $simDevice, $formatContentLeft );
        $worksheet->write( $row, 2, "",         $formatContentLeft );
        $worksheet->write( $row, 3, "",         $formatContentRight );
    }

    $row++;
    $worksheet->write( $row, 1, "", $formatLastRow );
    $worksheet->write( $row, 2, "", $formatLastRow );
    $worksheet->write( $row, 3, "", $formatLastRow );

    $row++;
    $worksheet->set_row( $row, 15 );
    $worksheet->merge_range( $row, 1, $row, 3, "Analog Output", $formatSubSectionHeadline );

    $row++;
    $worksheet->write( $row, 1, "SimDevice Name", $formatHeadlineLeft );

    $worksheet->write( $row, 2, "Device Name",        $formatHeadlineLeft );
    $worksheet->write( $row, 3, "Signal description", $formatHeadlineRight );

    $row++;
    $worksheet->write( $row, 1, "", $formatContentLeft );
    $worksheet->write( $row, 2, "", $formatContentLeft );
    $worksheet->write( $row, 3, "", $formatContentRight );

    $row++;
    $worksheet->write( $row, 1, "", $formatContentLeft );
    $worksheet->write( $row, 2, "", $formatContentLeft );
    $worksheet->write( $row, 3, "", $formatContentRight );

    $row++;
    $worksheet->write( $row, 1, "", $formatLastRow );
    $worksheet->write( $row, 2, "", $formatLastRow );
    $worksheet->write( $row, 3, "", $formatLastRow );

    $row++;
    $worksheet->set_row( $row, 15 );
    $worksheet->merge_range( $row, 1, $row, 3, "Bus Signals", $formatSubSectionHeadline );

    $row++;
    $worksheet->write( $row, 1, "SimDevice Name", $formatHeadlineLeft );

    $worksheet->write( $row, 2, "full signal name (Bus::Message::SignalName)", $formatHeadlineLeft );
    $worksheet->write( $row, 3, "Value", $formatHeadlineRight );

    $row++;
    $worksheet->write( $row, 1, "", $formatContentLeft );
    $worksheet->write( $row, 2, "", $formatContentLeft );
    $worksheet->write( $row, 3, "", $formatContentRight );

    $row++;
    $worksheet->write( $row, 1, "", $formatContentLeft );
    $worksheet->write( $row, 2, "", $formatContentLeft );
    $worksheet->write( $row, 3, "", $formatContentRight );

    $row++;
    $worksheet->write( $row, 1, "", $formatLastRow );
    $worksheet->write( $row, 2, "", $formatLastRow );
    $worksheet->write( $row, 3, "", $formatLastRow );

    $row++;
    $worksheet->set_row( $row, 15 );
    $worksheet->merge_range( $row, 1, $row, 3, "Fault Entry", $formatSubSectionHeadline );

    $row++;
    $worksheet->write( $row, 1, "SimDevice Name", $formatHeadlineLeft );

    $worksheet->write( $row, 2, "Fault Name", $formatHeadlineLeft );
    $worksheet->write( $row, 3, "DebugData",  $formatHeadlineRight );

    $row++;
    $worksheet->write( $row, 1, "", $formatContentLeft );
    $worksheet->write( $row, 2, "", $formatContentLeft );
    $worksheet->write( $row, 3, "", $formatContentRight );

    $row++;
    $worksheet->write( $row, 1, "", $formatContentLeft );
    $worksheet->write( $row, 2, "", $formatContentLeft );
    $worksheet->write( $row, 3, "", $formatContentRight );

    $row++;
    $worksheet->write( $row, 1, "", $formatLastRow );
    $worksheet->write( $row, 2, "", $formatLastRow );
    $worksheet->write( $row, 3, "", $formatLastRow );

    AutofitColumns($worksheet);

}

sub CreateSensorsSheet {
    my $workbook              = shift;
    my $moduleNames_aref      = shift;
    my $sensorNames_aref      = shift;
    my $sensorDirections_aref = shift;

    my $worksheet = $workbook->add_worksheet("Sensors");
    my ( $column, $row, @internalSensors, @externalSensors, @busSensors );

    for my $i ( 0 .. $#$moduleNames_aref ) {
        if ( $moduleNames_aref->[$i] ne "ECU" ) {
            push( @externalSensors, $i );
            next;
        }
        elsif ( $sensorDirections_aref->[$i] ne "Bus" ) {
            push( @internalSensors, $i );
            next;
        }
        else {
            push( @busSensors, $i );
        }
    }

    $worksheet->set_row( 1, 20 );
    $worksheet->merge_range( 1, 1, 1, 3, "Algo PC", $formatAlgoPC );
    $worksheet->merge_range( 1, 4, 1, 6, "Project Team (Algo Mentor, SW Mentor, System Architect, ...)", $formatProjectTeam );

    AutofitStartStoringStringWidths($worksheet);

    $worksheet->set_row( 2, 15 );
    $worksheet->merge_range( 2, 1, 2, 6, "Internal Sensors", $formatSubSectionHeadline );

    $row = 3;
    $worksheet->write( $row, 1, "Module",      $formatHeadlineLeft );
    $worksheet->write( $row, 2, "Sensor Name", $formatHeadlineCentral );
    $worksheet->write( $row, 3, "Direction",   $formatHeadlineRight );

    $worksheet->write( $row, 4, "Device Type",  $formatHeadlineLeft );
    $worksheet->write( $row, 5, "Channel Nbr.", $formatHeadlineCentral );
    $worksheet->write( $row, 6, "Channel Name", $formatHeadlineRight );

    my $startingRow = $row + 1;
    my $lastRow     = $row + 1;
    foreach my $internSensorNbr (@internalSensors) {
        $row++;
        $worksheet->write( $row, 1, "", $formatContentLeft );
        $worksheet->write( $row, 2, $sensorNames_aref->[$internSensorNbr], $formatContentCentral );
        $worksheet->write_string( $row, 3, $sensorDirections_aref->[$internSensorNbr], $formatContentRight );

        $worksheet->merge_range( $row, 4, $row, 6, "GENERIC: Input from SYC", $formatGenericContent );
        $lastRow = $row;
    }

    $worksheet->merge_range( $startingRow, 1, $lastRow, 1, "ECU", $formatContentLeft ) unless $startingRow == $lastRow;
    $row++;
    $worksheet->write( $row, 1, "", $formatLastRow );
    $worksheet->write( $row, 2, "", $formatLastRow );
    $worksheet->write( $row, 3, "", $formatLastRow );
    $worksheet->write( $row, 4, "", $formatLastRow );
    $worksheet->write( $row, 5, "", $formatLastRow );
    $worksheet->write( $row, 6, "", $formatLastRow );

    $row++;
    $worksheet->set_row( $row, 15 );
    $worksheet->merge_range( $row, 1, $row, 6, "External Sensors", $formatSubSectionHeadline );

    $row++;
    $worksheet->write( $row, 1, "Module",      $formatHeadlineLeft );
    $worksheet->write( $row, 2, "Sensor Name", $formatHeadlineCentral );
    $worksheet->write( $row, 3, "Direction",   $formatHeadlineRight );

    $worksheet->write( $row, 4, "Device Type", $formatHeadlineLeft );
    $worksheet->merge_range( $row, 5, $row, 6, "Device Name (as per SYC)", $formatHeadlineRight );

    foreach my $externalSensorNbr (@externalSensors) {
        $row++;
        $worksheet->write( $row, 1, $moduleNames_aref->[$externalSensorNbr], $formatContentLeft );
        $worksheet->write( $row, 2, $sensorNames_aref->[$externalSensorNbr], $formatContentCentral );
        $worksheet->write_string( $row, 3, $sensorDirections_aref->[$externalSensorNbr], $formatContentRight );

        $worksheet->merge_range( $row, 4, $row, 6, "GENERIC: Input from SYC", $formatGenericContent );
    }
    $row++;
    $worksheet->write( $row, 1, "", $formatLastRow );
    $worksheet->write( $row, 2, "", $formatLastRow );
    $worksheet->write( $row, 3, "", $formatLastRow );
    $worksheet->write( $row, 4, "", $formatLastRow );
    $worksheet->write( $row, 5, "", $formatLastRow );
    $worksheet->write( $row, 6, "", $formatLastRow );

    $row++;
    $worksheet->set_row( $row, 15 );
    $worksheet->merge_range( $row, 1, $row, 6, "Bus Signals", $formatSubSectionHeadline );

    $row++;
    $worksheet->write( $row, 1, "Module",      $formatHeadlineLeft );
    $worksheet->write( $row, 2, "Sensor Name", $formatHeadlineCentral );
    $worksheet->write( $row, 3, "Direction",   $formatHeadlineRight );

    $worksheet->write( $row, 4, "Network",      $formatHeadlineLeft );
    $worksheet->write( $row, 5, "Message Name", $formatHeadlineCentral );
    $worksheet->write( $row, 6, "Signal Name",  $formatHeadlineRight );

    $startingRow = $row + 1;
    $lastRow     = $row + 1;
    foreach my $busSensorNbr (@busSensors) {
        $row++;
        $worksheet->write( $row, 1, "",                                 $formatContentLeft );
        $worksheet->write( $row, 2, $sensorNames_aref->[$busSensorNbr], $formatContentCentral );
        $worksheet->write( $row, 3, "",                                 $formatContentRight );

        $worksheet->write( $row, 1, "", $formatContentLeft );
        $worksheet->write( $row, 2, "", $formatContentCentral );
        $worksheet->write( $row, 3, "", $formatContentRight );

        $lastRow = $row;
    }

    $worksheet->merge_range( $startingRow, 1, $lastRow, 1, "ECU", $formatContentLeft )  unless $startingRow == $lastRow;
    $worksheet->merge_range( $startingRow, 1, $lastRow, 1, "Bus", $formatContentRight ) unless $startingRow == $lastRow;

    $row++;
    $worksheet->write( $row, 1, "", $formatLastRow );
    $worksheet->write( $row, 2, "", $formatLastRow );
    $worksheet->write( $row, 3, "", $formatLastRow );
    $worksheet->write( $row, 4, "", $formatLastRow );
    $worksheet->write( $row, 5, "", $formatLastRow );
    $worksheet->write( $row, 6, "", $formatLastRow );

    AutofitColumns($worksheet);

}

sub CreateCoverSheet {
    my $workbook = shift;

    my $worksheet = $workbook->add_worksheet("CoverSheet");
    my ( $column, $row );

    # local formats
    my $formatHeadline            = $workbook->add_format( bold   => 1, border => 2, valign => 'vcenter', align => 'center', size => 18 );
    my $formatContentFull         = $workbook->add_format( border => 2 );
    my $formatBold                = $workbook->add_format( bold   => 1, );
    my $formatContentRightWrapped = $workbook->add_format( bottom => 1, left => 1, right => 2, text_wrap => 1 );

    # handle worksheet ProjectData
    $worksheet->set_row( 1, 40 );
    $worksheet->set_column( 0, 0, 2 );
    $worksheet->set_column( 1, 2, 13 );
    $worksheet->set_column( 3, 3, 60 );

    $worksheet->merge_range( 1, 1, 1, 3, "Software / Algorithm Interface Specification (SAIS)", $formatHeadline );

    $column = 1;
    $row    = 4;
    $worksheet->merge_range( $row, $column, $row, $column + 1, "Project/Platform Name:", $formatBold );
    $worksheet->write( $row, $column + 2, "", );
    $row++;
    $worksheet->merge_range( $row, $column, $row, $column + 1, "Algo-Project ID:", $formatBold );
    $worksheet->write( $row, $column + 2, "", );

    $row++;
    $row++;
    $row++;
    $worksheet->merge_range( $row, $column, $row, $column + 1, "Affected Roles:", $formatHeadlineLeft );
    $worksheet->write( $row, $column + 2, "Name:", $formatHeadlineRight );
    $row++;
    $worksheet->merge_range( $row, $column, $row, $column + 1, "Algo PC:", $formatContentLeft );
    $worksheet->write( $row, $column + 2, "", $formatContentRight );
    $row++;
    $worksheet->merge_range( $row, $column, $row, $column + 1, "Algo Mentor:", $formatContentLeft );
    $worksheet->write( $row, $column + 2, "", $formatContentRight );
    $row++;
    $worksheet->merge_range( $row, $column, $row, $column + 1, "SW PC:", $formatContentLeft );
    $worksheet->write( $row, $column + 2, "", $formatContentRight );
    $row++;
    $worksheet->merge_range( $row, $column, $row, $column + 1, "SW Mentor:", $formatContentLeft );
    $worksheet->write( $row, $column + 2, "", $formatContentRight );
    $row++;
    $worksheet->merge_range( $row, $column, $row, $column + 1, "Testing Engineer:", $formatContentLeft );
    $worksheet->write( $row, $column + 2, "", $formatContentRight );
    $row++;
    $worksheet->write( $row, $column,     "", $formatLastRow );
    $worksheet->write( $row, $column + 1, "", $formatLastRow );
    $worksheet->write( $row, $column + 2, "", $formatLastRow );

    $row++;
    $row++;
    $row++;
    $worksheet->write( $row, $column, "Document Change History:", $formatBold );
    $row++;
    $worksheet->write( $row, $column,     "Date",    $formatHeadlineLeft );
    $worksheet->write( $row, $column + 1, "Version", $formatHeadlineCentral );
    $worksheet->write( $row, $column + 2, "Changes", $formatHeadlineRight );

    my $datum = strftime "%d.%m.%Y", localtime;
    my $changesContent = "Initial Version \ncreated from '" . basename($mdbFileSelected) . "'";

    $row++;
    $worksheet->write( $row, $column, $datum, $formatContentLeft );
    $worksheet->write_string( $row, $column + 1, "1.0", $formatContentCentral );
    $worksheet->write( $row, $column + 2, $changesContent, $formatContentRightWrapped );

    $row++;
    $worksheet->write( $row, $column,     "", $formatContentLeft );
    $worksheet->write( $row, $column + 1, "", $formatContentCentral );
    $worksheet->write( $row, $column + 2, "", $formatContentRightWrapped );

    $row++;
    $worksheet->write( $row, $column,     "", $formatLastRow );
    $worksheet->write( $row, $column + 1, "", $formatLastRow );
    $worksheet->write( $row, $column + 2, "", $formatLastRow );

}

sub CreateEnvironmentalParametersSheet {
    my $workbook      = shift;
    my $envNames_aref = shift;

    my $worksheet = $workbook->add_worksheet("Environmental Parameters");
    my ( $column, $row );

    # handle worksheet ProjectData
    AutofitStartStoringStringWidths($worksheet);
    $worksheet->set_row( 1, 20 );
    $worksheet->merge_range( 1, 1, 1, 4, "Algo PC", $formatAlgoPC );
    $worksheet->merge_range( 1, 5, 1, 8, "Project Team (Algo Mentor, SW Mentor, System Architect, ...)", $formatProjectTeam );

    $column = 1;
    $row    = 2;
    $worksheet->set_row( $row, 20 );
    $worksheet->write( $row, $column++, "Environment Parameter", $formatHeadlineLeft );
    $worksheet->write( $row, $column++, "States / Range",        $formatHeadlineCentral );
    $worksheet->write( $row, $column++, "Description",           $formatHeadlineCentral );
    $worksheet->write( $row, $column++, "Comment",               $formatHeadlineRight );

    $worksheet->write( $row, $column++, "System Manipulation (network signals, special behaviour bits etc.)", $formatHeadlineLeft );
    $worksheet->write( $row, $column++, "Values / Ranges",                                                    $formatHeadlineCentral );
    $worksheet->write( $row, $column++, "SW-Labels for checking",                                             $formatHeadlineCentral );
    $worksheet->write( $row, $column++, "expected values / conversion",                                       $formatHeadlineRight );

    foreach my $envName ( sort @$envNames_aref ) {
        $row++;
        $column = 1;
        my $genericSolutionAvailable = CheckGenericSolution($envName);
        $worksheet->write( $row, $column++, $envName, $formatContentLeft );
        if ($genericSolutionAvailable) {
            $worksheet->write( $row, $column++, "", $formatContentCentral );
            $worksheet->write( $row, $column++, "", $formatContentCentral );
            $worksheet->write( $row, $column++, "", $formatContentRight );
            $worksheet->merge_range( $row, $column, $row, $column + 3, "generic solution...", $formatGenericContent );
        }
        else {
            $worksheet->write( $row, $column++, "", $formatContentCentral );
            $worksheet->write( $row, $column++, "", $formatContentCentral );
            $worksheet->write( $row, $column++, "", $formatContentRight );

            $worksheet->write( $row, $column++, "", $formatContentLeft );
            $worksheet->write( $row, $column++, "", $formatContentCentral );
            $worksheet->write( $row, $column++, "", $formatContentCentral );
            $worksheet->write( $row, $column++, "", $formatContentRight );
        }
    }

    $row++;
    $column = 1;
    $worksheet->write( $row, $column++, "", $formatContentLeft );
    $worksheet->write( $row, $column++, "", $formatContentCentral );
    $worksheet->write( $row, $column++, "", $formatContentCentral );
    $worksheet->write( $row, $column++, "", $formatContentRight );

    $worksheet->write( $row, $column++, "", $formatContentLeft );
    $worksheet->write( $row, $column++, "", $formatContentCentral );
    $worksheet->write( $row, $column++, "", $formatContentCentral );
    $worksheet->write( $row, $column++, "", $formatContentRight );

    $row++;
    $column = 1;
    $worksheet->write( $row, $column++, "", $formatLastRow );
    $worksheet->write( $row, $column++, "", $formatLastRow );
    $worksheet->write( $row, $column++, "", $formatLastRow );
    $worksheet->write( $row, $column++, "", $formatLastRow );

    $worksheet->write( $row, $column++, "", $formatLastRow );
    $worksheet->write( $row, $column++, "", $formatLastRow );
    $worksheet->write( $row, $column++, "", $formatLastRow );
    $worksheet->write( $row, $column++, "", $formatLastRow );

    AutofitColumns($worksheet);

}

sub CheckGenericSolution {
    my $env = shift;

    # check for 'Switch_..._State'
    return 1 if ( $env =~ /^ Switch_ (\w+) _State $/ix );

    # check for 'Switch_..._Configured'
    return 1 if ( $env =~ /^ Switch_ (\w+) _Configured $/ix );

    # check for 'Ps...ErrBehaviour'
    return 1 if ( $env =~ /^ Ps (\w+) ErrBehaviour $/ix );

    # check for 'Ps...Configured'
    return 1 if ( $env =~ /^ Ps (\w+) Configured $/ix );

    # check for 'CsEcu...OverloadBhvr'
    return 1 if ( $env =~ /^ CsEcu (\w+) OverloadBhvr $/ix );

    return 0;
}
###############################################################################
#
# Functions used for Autofit.
#
###############################################################################

sub AutofitStartStoringStringWidths {

    my $worksheet = shift;

    $worksheet->add_write_handler( qr/\w/, \&StoreStringWidths );

    return 1;
}

###############################################################################
#
# Adjust the column widths to fit the longest string in the column.
#
sub AutofitColumns {

    my $worksheet = shift;
    my $col       = 0;

    for my $width ( @{ $worksheet->{__col_widths} } ) {

        $worksheet->set_column( $col, $col, $width ) if $width;
        $col++;
    }

    return 1;
}

###############################################################################
#
# The following function is a callback that was added via add_write_handler()
# above. It modifies the write() function so that it stores the maximum
# unwrapped width of a string in a column.
#
sub StoreStringWidths {
    my @args      = @_;
    my $worksheet = shift @args;
    my $col       = $args[1];
    my $token     = $args[2];

    # Ignore some tokens that we aren't interested in.
    return if not defined $token;       # Ignore undefs.
    return if $token eq '';             # Ignore blank cells.
    return if ref $token eq 'ARRAY';    # Ignore array refs.
    return if $token =~ /^=/;           # Ignore formula

    # Ignore numbers
    return if $token =~ /^([+-]?)(?=\d|\.\d)\d*(\.\d*)?([Ee]([+-]?\d+))?$/;

    # Ignore various internal and external hyperlinks. In a real scenario
    # you may wish to track the length of the optional strings used with
    # urls.
    return if $token =~ m{^[fh]tt?ps?://};
    return if $token =~ m{^mailto:};
    return if $token =~ m{^(?:in|ex)ternal:};

    # We store the string width as data in the worksheet_appl object. We use
    # a double underscore key name to avoid conflicts with future names.
    #
    my $old_width    = $worksheet->{__col_widths}->[$col];
    my $string_width = StringWidth($token);

    if ( not defined $old_width or $string_width > $old_width ) {

        # You may wish to set a minimum column width as follows.
        $string_width = 3 if $string_width < 3;

        $worksheet->{__col_widths}->[$col] = $string_width;
    }

    # Return control to write();
    return;
}

###############################################################################
#
# This function uses an external module to get a more accurate width for a
# string.
sub StringWidth {
    my @args = @_;

    my $font_size    = 11;
    my $dpi          = 96;
    my $units_per_em = $calibri->get_units_per_em();
    my $font_width   = $calibri->string_width( $args[0] );

    # Convert to pixels as per TTFMetrics docs.
    my $pixel_width = 6 + $font_width * $font_size * $dpi / ( 72 * $units_per_em );

    # Add extra pixels for border around text.
    $pixel_width += 6;

    # Convert to cell width (for Arial) and for cell widths > 1.
    my $cell_width = ( $pixel_width - 5 ) / 7;

    return $cell_width;

}

print LOG "\n######################################################################\n";
print LOG "END OF LOGFILE\n\n\n";

close(LOG);
