## This file is generated using CREIS Configuration Generator Tool - Revision: 1.9  ##

package LIFT_PROJECT;

$Defaults->{'MDSRESULT'} = {
    "RESULTS" => {
        "DEFAULT" => {
            "MDSTYPE" => "MDSNG",
            "PATH"    => "DUMMY_DEFAULT.mdb"
        },
    }
};

$Defaults->{'CRASH_SIMULATION'} = {
    "ENVIRONMENT" => {},
    "STIMULATION" => { "CRASH_SENSORS" => {} }
};

$Defaults->{'CRASH_MEASUREMENT_AND_EVALUATION'} = {
    "General_Settings"       => {},
    "SimDevices"             => {},
    "AdditionalMeasurements" => {},
};

1;
