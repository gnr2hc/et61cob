=head1 NAME
ExtractLog_Pdu4mFrames.pl - Extracts the PDU data from the trace file which has only the FRAMES as per AUTOSAR 4.2

=head1 SYNOPSIS

Process_lookup_file.pl

=head1 VERSION

$Revision: 1.1 $

=head1 DESCRIPTION

ExtractLog_Pdu4mFrames.pl is a tool that extracts the PDU information from the CANoe .asc files which has only the FRAME data.
Since AUTOSAR database version 4.2 onwards only Frames are logged in .asc file (this has been changed from the vector side.)

=cut

use strict;
use warnings;
use Data::Dumper;
use POSIX;
use Tk;
my ( $lookup_hash, $main, $lookup_file, $src_asc_file );



my $target_asc_file = "target_canoe_log.asc";

sub Process_lookup_file {
    my $lookup_file = shift();
    open( my $lookup_fh, '<', $lookup_file )
      or die "Could not open file '$lookup_file' $!";
    while ( my $line = <$lookup_fh> ) {
        my ( $pdu_ID, $pdu_name, $length_hex ) = split( ';', $line );
        $pdu_ID =~ s/^\s+|\s+$//g;
        $pdu_name =~ s/^\s+|\s+$//g;
		$length_hex =~ s/^\s+|\s+$//g if ( defined $length_hex );
        my $new_pdu_ID = join( ' ', ( $pdu_ID =~ m/../g ) );
        $lookup_hash->{$new_pdu_ID}{'NAME'} = $pdu_name;
        $lookup_hash->{$new_pdu_ID}{'LENGTH'} = $length_hex if ( defined $length_hex );		
    }
    close($lookup_fh);
    return 1;
}

sub Exract_asc_and_generate_log {
    my $src_asc_file    = shift();
    my $target_asc_file = shift();
    open( my $asc_fh, '<', $src_asc_file )
      or die "Could not open file '$src_asc_file' $!";    #READ file
    open( my $log_fh, '+>', $target_asc_file )
      or die "Could not open file '$target_asc_file' $!";    #WRITE file

    my $line_count = 0;
    while ( my $line = <$asc_fh> ) {
        chomp $line;
        $line_count++;
        if ( $line_count ~~ ( 1 .. 4 ) ) {

            #keep the first 4 lines as it is
            print $log_fh $line . "\n";
        }
        else {
            #Process the asc file
            # ex: 4.523177 Fr RMSG  0 0 1 1 8 6 Rx 0 e 5  20  6f8 ORC_CHASSIS_Container_ST3
            my $line_data_prefix;
            if (
                $line =~ /^(
                \s*(?:\d+\.\d+)
                \s+(?:Fr)
                \s+(?:RMSG)
                \s+(?:\w+\s+\w+\s+\w+\s+\w+\s+\w+\s+\w+)
                \s+(?:Tx|Rx|TxRq)
                \s+(?:\d+)
                \s+(?:[0-9a-f]+)
                \s+(?:\d+)
                \s+(?:[0-9a-f]+)
                \s+(?:[0-9a-f]+)
                \s+)(?:\w+)
                \s+(?:[0-9a-f]+)
                \s+(?:[0-9a-f]+)
                (.*)/ix
              )
            {
                $line_data_prefix = $1;
                my $remaining_string = $2;
                $line_data_prefix =~ s/RMSG/PDU/;
                my @pdu_hash = ( sort keys %$lookup_hash );
                my $size     = scalar @pdu_hash;
                my $i        = 0;
                my $check    = 1;
                my ( $length_hex, $length_dec );

                for ( $i = 0 ; $i < $size; $i++ ) {

                    my $pdu_ID            = $pdu_hash[$i];
                    my $length_hex_lookup = $lookup_hash->{$pdu_ID}{'LENGTH'};

                    if ( $check == 1 ) {

                        # if PDU found at the start of the raw data
                        if ( defined $length_hex_lookup && $length_hex_lookup ne '' ) {
                            $length_dec = hex($length_hex_lookup);
                            $length_hex = $length_hex_lookup;
                        }
                        elsif ( $remaining_string =~ /^\s*$pdu_ID\s([0-9a-f]+)/i ) {
                            $length_hex = $1;
                            $length_dec = hex($length_hex);
                        }

                        if (   $length_dec
                            && $remaining_string =~ /^\s*$pdu_ID\s$length_hex\s((..\s){$length_dec})(.*)?/i )
                        {
                            $remaining_string = $3;
                            my $pdu_name  = $lookup_hash->{$pdu_ID}{'NAME'};
                            my $line_data = $line_data_prefix . "$pdu_name $length_hex $length_hex $1" . "0  0  0   0\n";
                            $i = -1;    #start parsing again for the remaining data
                            print $log_fh $line_data;
                        }
                    }
                    else {

                        # if anonther PDU found anywhere of the raw data

                        if ( defined $length_hex_lookup && $length_hex_lookup ne '' ) {
                            $length_dec = hex($length_hex_lookup);
                            $length_hex = $length_hex_lookup;
                        }
                        elsif ( $remaining_string =~ /\s*$pdu_ID\s([0-9a-f]+)/i ) {
                            $length_hex = $1;
                            $length_dec = hex($length_hex);
                        }
                        if (   $length_dec
                            && $remaining_string =~ /\s*$pdu_ID\s$length_hex\s((..\s){$length_dec})(.*)?/i )
                        {
                            $remaining_string = $3;
                            my $pdu_name  = $lookup_hash->{$pdu_ID}{'NAME'};
                            my $line_data = $line_data_prefix . "$pdu_name $length_hex $length_hex $1" . "0  0  0   0\n";
                            print $log_fh $line_data;
                            $i     = -1;
                            $check = 1;
                        }

                    }

                    if ( $i + 1 == $size && $check == 1 ) {
                        $check = 2;
                        $i     = -1;
                    }
                }
            }
            elsif (
                (
                    $line =~ /^
          \s*        # leading spaces
          (?:\d+\.\d+)    # timestamp
          \s+        # spaces
          \d+     # bus ID must be right !!!
          \s+        # spaces
          (?:\w+)
          x?
          \s+        # spaces
          [TxRq]+      # match Rx or Tx or TxRq
          \s+        # spaces
          d
          \s+        # spaces
          (?:\d+)      # DLC
          \s+        # spaces
          (.+)$      # all Data and aditional info unil end of line  (e.g. 2A 34 42 FF 20 00  Length = 192000 BitCount = 100)
          /ix
                )
                || (
                    $line =~ m/^ 
            \s*        # leading spaces
            (\d+\.\d+) # timestamp          
            \s+        # some spaces
            SV:        # keyword for system variable    
            \s+        # some spaces
            (?:\d+\s+){3} # some digits followed by spaces
            [\:\:]+
            /x
                )
                || (
                    $line =~ m/^
            \s*
            (\d+\.\d+)
            \s+
            \w+
            \s+
            :=
            /x
                )
              )
            {
                print $log_fh $line . "\n";
            }
        }
    }
    $main->messageBox(
        -icon    => "info",
        -message => "Generated the log file",
        -title   => 'Finished'
    );
    close($asc_fh);
    close($target_asc_file);
}

sub Init_GUI {

    ##------------------------------------------------------------------
    ## create main window 'main'
    ##------------------------------------------------------------------
    # create main window 'main'
    $main = MainWindow->new( -background => "#888888" );

    # define minimum size of main window 'main'
    $main->minsize( 800, 300 );

    # create title in main window 'main'
    $main->title("Extract PDU from Frames (*.asc generated via ARXML for AUTOSAR > 4.2 ) ");

    #create frame 'F1' in main window 'main'
    my $frame1 = $main->Frame( -background => "#333546" )->pack(
        -side   => 'top',
        -expand => 1,
        -fill   => 'both',
    );

    # create frame 'F2' in main window 'main'
    my $frame2 = $main->Frame( -background => "#333546" )->pack(
        -side => 'bottom',
        -fill => 'x',
    );

    # write head line in frame 'F1'
    $frame1->Label(
        -text       => 'Extract PDU from Frames : Configuration window',
        -font       => '{Segoe UI Semibold} 13 bold ',
        -background => "#333546",
        -foreground => "white",
        -width      => 50,
        -relief     => 'groove',
    )->pack( -side => "top" );

    # create exit and start buttons in frame 'F2'
    $frame2->Button(
        -text       => "Quit",
        -width      => '8',
        -font       => '{Segoe UI Semibold} 12 ',
        -background => "Red4",
        -foreground => "white",
        -relief     => 'groove',
        -command    => sub { print " QUIT pressed -> Exit\n"; exit; }
      )->pack(
        -side  => 'left',
        -pady  => 20,
        -padx  => 20,
        -ipady => 5,
        -ipadx => 5,
      );

    #Mapping file generation starts on clicking the Start button
    my $start_button = $frame2->Button(
        -text       => "Start",
        -width      => '8',
        -font       => '{Segoe UI Semibold} 12 ',
        -foreground => "white",
        -relief     => 'groove',
        -background => "ForestGreen",
        -command    => sub {
            if ( $lookup_file and $src_asc_file && $target_asc_file ) {

                #execute LPCM_engine
                Process_lookup_file($lookup_file);
                Exract_asc_and_generate_log( $src_asc_file, $target_asc_file );
            }
            else {
                my $error_text = "! not enough options defined ! ";
                Create_ErrorMsgBox($error_text);
            }
        }
      )->pack(
        -side  => 'right',
        -pady  => 20,
        -padx  => 20,
        -ipady => 5,
        -ipadx => 5,
      );

###################################################################################
    # Select Lookup file
    my $lookup_file_entry = $frame1->Frame( -background => "#888888" )->pack( -pady => 5, -fill => 'x', -padx => 5, );

    $lookup_file_entry->Label(
        -text       => "Lookup file: ",
        -background => "#888888",
        -foreground => 'white',
        -font       => '{Segoe UI Semibold} 10 bold',
        -width      => '33.95',
        -wraplength => 260
    )->pack( -side => 'left' );
    $lookup_file_entry->Entry(
        -textvariable => \$lookup_file,
        -validate     => 'focusout',
        -background   => "grey",
    )->pack( -side => 'left', -fill => 'x', -expand => 1, -padx => 5 );

    # create 'browse file' button
    $lookup_file_entry->Button(
        -text       => "Browse...",
        -relief     => 'groove',
        -background => "#333366",
        -foreground => "white",
        -font       => '{Segoe UI Semibold} 10 ',
        -command    => sub {
            my $temp = $lookup_file;    # store old value
            $lookup_file = $main->getOpenFile(
                -filetypes => [ [ "lookup file ", [ '.txt', '.csv' ] ], [ "All files", '.*' ] ],
                -title => "Select lookup file",
                -initialdir => '.',
            );
            unless ($lookup_file) {
                $lookup_file = $temp;
            }                           # if no new value, restore old one
        },
      )->pack(
        -side  => 'right',
        -ipadx => 5,
        -ipady => 2,
        -pady  => 5,
        -padx  => 5
      );

###################################################################################
    # Select Lookup file
    my $src_asc_file_entry_1 = $frame1->Frame( -background => "#888888" )->pack( -pady => 5, -fill => 'x', -padx => 5, );

    $src_asc_file_entry_1->Label(
        -text       => "Source asc file: ",
        -background => "#888888",
        -foreground => 'white',
        -font       => '{Segoe UI Semibold} 10 bold',
        -width      => '33.95',
        -wraplength => 260
    )->pack( -side => 'left' );
    $src_asc_file_entry_1->Entry(
        -textvariable => \$src_asc_file,
        -validate     => 'focusout',
        -background   => "grey",
    )->pack( -side => 'left', -fill => 'x', -expand => 1, -padx => 5 );

    # create 'browse file' button
    $src_asc_file_entry_1->Button(
        -text       => "Browse...",
        -relief     => 'groove',
        -background => "#333366",
        -foreground => "white",
        -font       => '{Segoe UI Semibold} 10 ',
        -command    => sub {
            my $temp = $src_asc_file;    # store old value
            $src_asc_file = $main->getOpenFile(
                -filetypes => [ [ "Asc files", ['.asc'] ], [ "All files", '.*' ] ],
                -title => "Select source ASC file",
                -initialdir => '.',
            );
            unless ($src_asc_file) {
                $src_asc_file = $temp;
            }                            # if no new value, restore old one
        },
      )->pack(
        -side  => 'right',
        -ipadx => 5,
        -ipady => 2,
        -pady  => 5,
        -padx  => 5
      );

###################################################################################
    # Select Lookup file
    my $src_asc_file_entry_2 = $frame1->Frame( -background => "#888888" )->pack( -pady => 5, -fill => 'x', -padx => 5, );

    $src_asc_file_entry_2->Label(
        -text       => "Target asc file: ",
        -background => "#888888",
        -foreground => 'white',
        -font       => '{Segoe UI Semibold} 10 bold',
        -width      => '33.95',
        -wraplength => 260
    )->pack( -side => 'left' );
    $src_asc_file_entry_2->Entry(
        -textvariable => \$target_asc_file,
        -background   => "grey",
    )->pack( -side => 'left', -fill => 'x', -expand => 1, -padx => 5 );

    # create 'browse file' button
    $src_asc_file_entry_2->Button(
        -text       => "Browse...",
        -relief     => 'groove',
        -background => "#333366",
        -foreground => "white",
        -font       => '{Segoe UI Semibold} 10 ',
        -command    => sub {
            my $temp = $target_asc_file;    # store old value
            $target_asc_file = $main->getSaveFile(
                -filetypes => [ [ "Asc files", ['.asc'] ], [ "All files", '.*' ] ],
                -title => "Select target ASC file",
                -initialdir  => '.',
                -initialfile => "$target_asc_file",
            );
            unless ($target_asc_file) {
                $target_asc_file = $temp;
            }                               # if no new value, restore old one
        },
      )->pack(
        -side  => 'right',
        -ipadx => 5,
        -ipady => 2,
        -pady  => 5,
        -padx  => 5
      );
    return;
}

sub Create_ErrorMsgBox {
    my $error_msg = shift;
    $main->messageBox(
        '-icon'    => "error",
        '-type'    => "OK",
        '-title'   => 'Error',
        '-message' => $error_msg,
    );
    return 1;
}

Init_GUI();
MainLoop;

print "Completed logfile generation";

=POD

Lookup file format
PDU NAME;PDU_ID; PDU_data_length(hex)
1e8000;ORC_CHASSIS_Container_ST3_IS1_Stat_ST3;29

=CUT
