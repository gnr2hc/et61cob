use strict;
use warnings;
use REST::Client;
use LWP::UserAgent;
use JSON;
use Data::Dumper;
use HTTP::Cookies;
use Crypt::RC4;
use XML::LibXML;

$ENV{HTTPS_VERSION} = 3;
$ENV{PERL_LWP_SSL_VERIFY_HOSTNAME} = 0;

# Examples URLs for ALM RQM
#https://rb-ubk-clm-04.de.bosch.com:9443/qm/auth/authrequired
#https://rb-ubk-clm-04.de.bosch.com:9443/qm/authenticated/identity
#https://rb-ubk-clm-04.de.bosch.com:9443/qm/process/project-areas

my $host = 'https://rb-ubk-clm-04.de.bosch.com:9443';
my $context = 'qm';
my $projectAlias = 'ProjectPlay_RM+%28Qualit%C3%A4tsmanagement%29';
my $user = 'phc2si';
my $pwdFilename = 'U:\ALM\pwd.txt';
#CreatePwdFile(); exit;

my $cookie_jar = HTTP::Cookies->new( file => "alm_cookies.dat", autosave => 1 );
my $userAgent = LWP::UserAgent->new( agent => 'perl get' );
$userAgent->cookie_jar( $cookie_jar );
my $client = REST::Client->new({useragent => $userAgent});

LoginRQM() or die "Error on Login to RQM";

#my $feedUrl = BuildFeedUrl('testcase', 'testscript', 66);
#my $feedUrl = BuildFeedUrl('testplan', 'testcase', 62);
#my $feedUrl = BuildFeedUrl('testsuite', 'testcase', 62);
my $feedUrl = BuildFeedUrl('testsuite', 'testcase', 8);
$client->GET($feedUrl);
my $feed_href = CreateLastArtifactHref('feed');

#my $datafile = 'ts55_mod.txt';
#open(my $datafh, '<', $datafile)
#  or die "Could not open file '$datafile' $!";
#my $data = <$datafh>;
#close $datafh;   
#$client->PUT($testscriptUrl, $data);
#PrintResponse();

my $testscriptUrl = BuildUrl('testscript', 55);
$client->GET($testscriptUrl);
my $testscript_href = CreateLastArtifactHref('testscript');
my $datapoolUrl = $testscript_href -> {datapool}{href};
$client->GET($datapoolUrl);
my $datapool_href = CreateLastArtifactHref('datapool');
my $testData_href;
my $variables_href = $datapool_href -> {variables};
foreach my $key ( sort keys %{ $variables_href } ) {
    next if $key !~ /^variable/;
    $testData_href -> {$key}{name} = $variables_href -> {$key}{name};
}
my $attachmentUrl = $datapool_href -> {attachment}{href};
$client->GET($attachmentUrl);
my $attachment_href = CreateLastArtifactHref('attachment');



#my $testcaseUrl = BuildUrl('testcase', 8);
#$client->GET($testcaseUrl);
#my $testcase_href = CreateLastArtifactHref('testcase');

#my $testsuiteUrl = BuildUrl('testsuite', 12);
#$client->GET($testsuiteUrl);
#my $testsuite_href = CreateLastArtifactHref('testsuite');

#my $suiteelements_href = $testsuite_href -> {suiteelements};
#my $suitescripts_href;
#foreach my $element ( keys %{ $suiteelements_href } ) {
#    next if ref( $suiteelements_href -> {$element} ) ne 'HASH';    
#    my $elementindex = $suiteelements_href -> {$element}{elementindex};
#    my $scriptUrl = $suiteelements_href -> {$element}{remotescript}{href};
#    $client->GET($scriptUrl);
#    my $script_href = CreateLastArtifactHref('remotescript');
#    $suitescripts_href -> {$elementindex} = '';
#    my $variableName = $script_href -> {variables}{variable}{name}{textContent};
#    my $variableValue;
#    if( $variableName eq 'TurboLIFT_testcase' ) {
#        $variableValue = $script_href -> {variables}{variable}{value}{textContent};
#    }
#    $suitescripts_href -> {$elementindex} = $variableValue;
#}
#
#print Dumper($suitescripts_href)."\n";

my $dummy;

sub LoginRQM{
    $client->GET("$host/$context/auth/authrequired");
    PrintResponse();
    FollowRedirect();
    $client->GET("$host/$context/authenticated/identity");
    PrintResponse();
    FollowRedirect();
    my $postRequest = "$host/$context/j_security_check";
    $client->POST($postRequest, "j_username=$user&j_password=".GetPwd(), {"Content-Type" => "application/x-www-form-urlencoded; charset=utf-8"});
    PrintResponse();
    RedirectManual();
    FollowRedirect();
    $client->GET("$host/$context/service/com.ibm.team.repository.service.internal.webuiInitializer.IWebUIInitializerRestService/initializationData");
    PrintResponse();
    my $responseCode = $client->responseCode();
    #my $responseStr = $client->responseContent();
    #my $jsondecoder = JSON->new->allow_nonref; # --- decode the JSON result,
    #my $result = $jsondecoder->decode( $responseStr );
    
    return if $responseCode != 200;
    return 1;
}

sub PrintResponse{
#    print 'Response: ' . $client->responseContent() . "\n";
    print 'Response status: ' . $client->responseCode() . "\n";
#    foreach ( $client->responseHeaders() ) {
#        print 'Header: ' . $_ . '=' . $client->responseHeader($_) . "\n";
#    }
#    print "\n";
}

sub FollowRedirect{
    my $location = $client->responseHeader("Location");
    my $responseCode = $client->responseCode();
    while( $responseCode == 302 and defined $location ) {
        $client->GET($location);
        PrintResponse();
        $location = $client->responseHeader("Location");
        $responseCode = $client->responseCode();
    }
}

sub RedirectManual{
    my $location = $client->responseHeader("Location");
    if( defined $location ) {
        $client->GET($location);  
        PrintResponse();
    }    
}

sub GetPwd{
    my $passphrase = 'MySecretRQMPassword_42';
    open(my $fh, '<', $pwdFilename)
      or die "Could not open file '$pwdFilename' $!";
    my $encrypted = <$fh>;
    close $fh;   
    return RC4( $passphrase, $encrypted );    
}

sub CreatePwdFile{
    my $passphrase = 'MySecretRQMPassword_42';
    my $plaintext = 'password';
    my $encrypted = RC4( $passphrase, $plaintext ); 
    open(my $fh, '>', $pwdFilename)
      or die "Could not open file '$pwdFilename' $!";
    print $fh $encrypted;
    close $fh;   
}

sub BuildUrl{
    my $artifactType = shift;
    my $internalID = shift;

    #$restURL example: https://rb-ubk-clm-04.de.bosch.com:9443/qm/service/com.ibm.rqm.integration.service.IIntegrationService/resources/ProjectPlay_RM+%28Qualit%C3%A4tsmanagement%29/testcase/urn:com.ibm.rqm:testcase:50
    my $integrationURL = "$host/$context/service/com.ibm.rqm.integration.service.IIntegrationService";
    my $singleProjectFeedUrl = "$integrationURL/resources/$projectAlias";
    my $artifact = "$artifactType/urn:com.ibm.rqm:$artifactType:$internalID";
    my $restURL = "$singleProjectFeedUrl/$artifact";
    print("URL for $artifactType $internalID built: $restURL\n");

    return $restURL;
}

sub BuildFeedUrl{
    my $primaryArtifact = shift;
    my $filterArtifact = shift;
    my $filterID = shift;

    #$restURL example: https://rb-ubk-clm-04.de.bosch.com:9443/qm/service/com.ibm.rqm.integration.service.IIntegrationService/resources/ProjectPlay_RM+%28Qualit%C3%A4tsmanagement%29/testcase/urn:com.ibm.rqm:testcase:50
    my $integrationURL = "$host/$context/service/com.ibm.rqm.integration.service.IIntegrationService";
    my $singleProjectFeedUrl = "$integrationURL/resources/$projectAlias";
    my $resourceUrl = "$singleProjectFeedUrl/$filterArtifact/urn:com.ibm.rqm:$filterArtifact:$filterID";
    my $href = '@href';
    my $testsuiteExtra = '';
    $testsuiteExtra = 'suiteelements/suiteelement/' if( $primaryArtifact eq 'testsuite' );
    my $restURL = "$singleProjectFeedUrl/$primaryArtifact?fields=feed/entry/content/$primaryArtifact/$testsuiteExtra$filterArtifact"."[$href='$resourceUrl']";
    print("URL for feed $primaryArtifact linked to $filterArtifact $filterID built: $restURL\n");

    return $restURL;
}

sub CreateLastArtifactHref{
    my $type = shift;
    
    my $responseCode = $client->responseCode();
    my $responseContent = $client->responseContent();
    if( $responseCode != 200 ) {
        print "ERROR: Response code $responseCode received. Full response is: $responseContent\n";
        return;
    }
    my @responseHeaders = $client->responseHeaders();
    my $contentType;
    foreach my $header ( @responseHeaders ) {
        if( $header eq 'Content-Type' ) {
            $contentType = $client->responseHeader($header);
            last;
        }
    }
    
    open OUT, ">last_artifact.txt";
    print OUT $responseContent;
    close OUT;

    my $artifact_href;
    if( $contentType =~ /xml/ ){
        $artifact_href = Xml2href( $type, $responseContent );
    }
    elsif( $contentType =~ /excel/ ){
        $artifact_href = Csv2href( $type, $responseContent );
    }
    else{
        print "ERROR: content type $contentType is not supported.\n";
    }
    return $artifact_href;
}

sub Xml2href{
    my $type = shift;
    my $responseContent = shift;
    
    my $xmlParser = XML::LibXML->new();
    my $xmlObject = $xmlParser->load_xml( string => $responseContent );
    
    my @items;
    if( $type eq 'feed' ) {
        @items = $xmlObject->findnodes("/");
    }
    else{
        @items = $xmlObject->findnodes("/ns2:$type");    
    }
    
    my $item = shift @items;

    my $artifact_href = {};
    ProcessChildNodes( $item, $artifact_href );

    if( $type eq 'feed' ) {
        my $entries_href = {};
        my $counter = 0;
        foreach my $entry ( keys %{ $artifact_href->{feed} } ) {
            if( $entry =~ /^entry/ ) {
                my $url = $artifact_href->{feed}{$entry}{id}{textContent};
                my $artifact = 'unknown';
                my $id;
                if( $url =~ /:(\w+):(\d+)$/ ) {
                    $artifact = $1;
                    $id = $2
                }
                $entries_href -> {$artifact}{$counter}{id} = $id;
                $entries_href -> {$artifact}{$counter}{url} = $url;
                $counter++;
            }
        }
        $artifact_href = $entries_href;
        print("feed results: $counter\n");
    }
    else{
        my $webId = $artifact_href -> {'webId'}{'textContent'};
        my $title = $artifact_href -> {'title'}{'textContent'};
        print("$type $webId $title\n");
    }
    return $artifact_href;
}

sub ProcessChildNodes{
    my $item = shift;
    my $itemData_href = shift;
    
    my @childnodes = $item->childNodes;
    my $numberOfChildNodes = @childnodes;
    foreach my $counter ( 0 .. $numberOfChildNodes-1 ) {
        my $node = $childnodes[$counter];
        my $name = $node->nodeName;
        $name =~ s/^\w+://;
        if( defined $itemData_href -> {$name} ) {            
            $name .= $counter;
        }
        next if $name eq '#text';
        my $textContent = $node -> textContent;
        if( defined $textContent and $textContent ne '' ) {
            $itemData_href -> {$name}{'textContent'} = $textContent;
        }
        my @attributelist = $node->attributes();
        foreach my $attribute ( @attributelist ) {
            next if not defined $attribute;
            my $attrName = $attribute -> getName;
            my $attrValue = $attribute -> getValue;
            $itemData_href -> {$name}{$attrName} = $attrValue;
        }
        my @furtherChildNodes = $node->childNodes;
        if( @furtherChildNodes ) {
            ProcessChildNodes( $node, $itemData_href -> {$name} ); # recursive call!
        }
    }

    return 1;
}

sub Csv2href{
    my $type = shift;
    my $responseContent = shift;

    my $artifact_href;
    my @lines = split /\n/, $responseContent;
    my $headerline = shift @lines;
    chop $headerline;
    my @variables = split /,/, $headerline;
    foreach my $rowIndex ( 0 .. @lines-1 ) {
        my $line = $lines[ $rowIndex ];
        chop $line;
        my @data = split /,/, $line;
        foreach my $columnIndex ( 0 .. @data-1 ) {
            my $variable = $variables[$columnIndex];
            $artifact_href -> {$rowIndex}{$variable} = $data[$columnIndex];
        }
        
    }
    return $artifact_href;
}

1;