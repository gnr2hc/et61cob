#! /usr/bin/perl -w


=head1 NAME

LIFT_shell - Perl shell connecting to LIFT server

=head1 SYNOPSIS

just start the shell by doubleclick

	->ServerLoadLIFTconfig("C:\TurboLIFT\TSG4\config\TSG4_CFG.pm")
	->TSG4_InitHW()
	->TSG4_SetVoltage( 12.5 )
    ->wait 2000
    ->quit    
    

=head1 DESCRIPTION

perl shell for LIFT, will automatically start LIFT_server and connect to it.

all commands entered will be logged in LIFT_shell_log.txt. You can create own shell scripts using parts from the logfile and re-run them using the run command. 
Calling nested scripts is not implemented. You have to do the errorhandling on your own (first return value is verdict, INCONC means error)

B<NOTE: do not run shell in parallel to another LIFT application e.g. LIFT !>

=head2 any LIFT command

any of the high level commands from LIFT will be executed. 

=head2 run

    ->run $filename
    e.g. ->run test.txt         ( or optional: call execute )

run a shell script, all lines in this file starting with '->' will be executed as shell command, others will be ignored


=head2 help

    ->help

show small help with list of commands


=head2 pause

    ->pause             ( or optional: sleep )

wait for key pressed, useful for shell scripts


=head2 quit

    ->quit          ( or optional: exit end stop close )

exit shell 


=head2 wait

    ->wait $milliseconds
    e.g. ->wait 2000

wait for $milliseconds, useful for shell scripts


=head1 CLI

 there is a simple command line interface:
 if you run 'LIFT_shell.pl --run shellscript.txt' the file will be executed by run command, then shell exits
 

=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl, LIFT documentation

=cut 


#################################################################################
# this tool is under version management
my $VERSION = q$Revision: 1.3 $;
my $HEADER  = q$Header: LIFT_shell/LIFT_shell.pl 1.3 2014/08/07 17:05:32ICT Boehm Frank (DC/PAR) (BM7ZSI) develop  $;
#################################################################################

use File::Basename;

use strict;
use Getopt::Long;
system("Color 8A");
my $PORT = 9000;
my $timeout = 5000;
my ($str,$server,$text);
my ($status, $input);

my $run_file='';
GetOptions('run=s' => \$run_file );

open ( LOG, ">LIFT_shell_log.txt" );     # open shell logfile
system('CMD /C start .\..\Engine\LIFT_server.pl');
sleep(2);
Open_server_Connection();

w2log(" LIFT shell $VERSION\n");

if ($run_file){ # source file
    w2log("running with CLI, executing <$run_file>\n->");
    run_file($run_file);
    w2log("exit\n");
}
else{
	w2log("try help for details\n\n->");
	while ($input = <STDIN>){
	    print LOG "$input";
	    last if ($input =~ /^(exit|quit|end|stop|close)\s*$/i);
	    run_command($input);
	}
}
sleep(3);
Write_server("exit");
Close_server_Connection();

w2log("\nLIFT shell stopped :o)\n\n");

print"\nall actions were logged to LIFT_shell_log.txt\nthis file will be overwritten by starting shell again!\n\n\n";

close (LOG);
system('pause');

################
#  subroutines
################

sub run_command{
    my $input = shift;
    chomp($input); # cut off newline

    if ($input =~ /^(run|call|execute) (.+)/i){w2log("running file\n->"); run_file($2);w2log("\n->");}
    elsif ($input =~ /^(wait|sleep) (.+)/i){ wait_ms($2);}
    elsif ($input =~ /^help/i){w2log("  available commands:\n  help, run, wait, pause, quit\n  and all LIFT functions listed in html help\n->");}
    elsif ($input =~ /^pause/i){system('pause');w2log("\n->");}
    else{
        # execute $input as perl copmmand and get return values
        #my @result = eval($input);
		
		Write_server($input);
		my $result=Read_server();
		
        my ($val,$refval);
        #check if at least one return value was there
        if (defined ($result)) {
                w2log("$result");
        }
        else {w2log("? unknown command: $input");}
        w2log("\n->");
    }
}

sub run_file{
  my $file = shift;
  my $line;
  open ( IN, "<$file" ); 
  while ($line = <IN>){
    if ($line =~ /^->(.+)/) {w2log($1."\n");run_command($1);}
  }
}

sub w2log{
    my $text = shift;
    print LOG "$text";
    print "$text";
}

sub wait_ms{
    my $time = shift;    
    w2log("sleeping for $time milliseconds");
    if ( $time > 0) {$time = $time/1000;}
    select(undef, undef, undef, $time);   #sleep for X ms
    w2log("\n->");
}


sub Open_server_Connection
{
 my ($Connect_Count,$socket);
    use IO::Socket;
    # Set up the server object
    
    $server = IO::Socket::INET->new(    Proto     => 'tcp',
                                        PeerAddr => 'localhost',
                                        PeerPort => $PORT,
                                        Timeout   => $timeout
                                        );

    die "can't setup TCP server" unless $server;
    
    print "Server port: $PORT Timeout value: $timeout\n";
    
    $server->autoflush(1);
    print "communication started \n";
    
}


sub Close_server_Connection
{
    close($server);
}

sub Write_server
{ 
    if ($server) 
    {
        $text=shift;
 #       print $server $text."\r\n";      # Send command     
        print $server $text."\015\012";      # Send command     
        print "S-> $text\n";       
    } 
    else 
    {
        return 0;
    }
    
}


sub Read_server
{
    while ($text=<$server>) 
    {
        next unless $text =~ /\S/;             # ignore blank lines
        $text =~ s/\r\n$//;
        print "<-R $text\n";       
        return $text;
    }
}

