use strict;
use warnings;

#################################################################################
# this tool is under version management
my $VERSION = q$Revision: 1.10 $;
my $HEADER  = q$Header: AB12flash/AB12flash.pl 1.10 2018/05/02 18:26:27ICT Okrusch Thomas (CC-PS/EPS2) (OUT2SI) develop  $;
#################################################################################

=head1 usage

flash AB12 SW via renesas flashtool

based on ab12_CoreAsset/ab12_develop/ttols/tools_uC/Debug/ecuflash.pl 1.6

requires C:\Program Files (x86)\Renesas Electronics\Programming Tools\Renesas Flash Programmer V2.05\RFP.exe

 E1serial is written on flashtool e.g. 3es049632c
 
 uC can be R1L, R1L1MB, D4 or D3 or D3A

	RenesasR1xTypeB = "R1L"
	RenesasR1x10623 = "R1L"
	RenesasR1xTypeC = "R1L1MB"
	RenesasR1x10643 = "R1L1MB"
	RenesasP1xD3    = "D3"
	RenesasP1xD3A   = "D3A"  # AB12.1
	RenesasP1xD4    = "D4"

	you can also use your own configuration by giving it as uc string in this format 'rwsProj;needsCleanHex;extendCodeFlash'
	e.g.: geely;1;1 where geely has to be a folder below AB12flash with same structure like R1L1MB_ecuFlash

 if nvmfile file is skipped, <hexfile_name>_dflash.hex will be taken

 CLI: AB12flash.pl --E1serial [string] --hexfile [file] --uC [string]          optional --nvmfile [file]
 
 e.g. for ISU C:\TurboLIFT\Tools\AB12flash\AB12flash.pl --E1serial=3es049632c --hexfile=AB1210_BD_0031_BB000000_Cat2.hex --uC=D3
	  for Geely C:\TurboLIFT\Tools\AB12flash\AB12flash.pl --E1serial=3es049632c --hexfile=GY1201_C1_097_BB70031_Cat2.hex --uC=geely;1;1

=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=cut

use Cwd;
use File::Basename;
use Getopt::Long;
use Switch;

my $tool_path = dirname(__FILE__);

# taken from MKS ab12_CoreAsset/ab12_develop/ttols/tools_uC/Debug/ecuflash.pl 1.6
our ( $opt_hexfile, $opt_E1serial, $opt_nvmfile, $opt_uC );

my $rfpExec    = 'C:\Program Files (x86)\Renesas Electronics\Programming Tools\Renesas Flash Programmer V2.05\RFP.exe';
my $tmpDir     = 'c:\temp\LIFT';
my $rfpLogFile = 'ecuFlash.log';

my $rwsTemplate = $tool_path . '\ecuFlash_allDevices.rws';    # workspace for RFP
my $rwsFileName = $tool_path . '\ecuFlash.rws';               # workspace for RFP

main();                                                       # Call main function
exit();

sub main {
	unless ( -e $rfpExec ) {
		print "ERROR! Couldn't find installation of Renesas Flash Programmer (RFP). Looking for $rfpExec\nplease install RFP 2.05 (needs admin rights) from following location:\n";
		system('timeout /t 10');
		system('explorer \"\\bosch.com\dfsrb\DfsDE\DIV\CS\DE_CS$\Prj\PS\Support\Tools\Renesas\RFP\Renesas_Flash_Programmer_Package_V20500_free\Renesas_Flash_Programmer_Package_V20500\"');
		exit;
	}

	unless ( GetOptions( 'E1serial=s', 'hexfile=s', 'nvmfile:s', 'uC=s', )	&&  $opt_E1serial &&  $opt_hexfile	&&  $opt_uC )
	{
		print "parameter error ! please call AB12flash.pl with serial_number, hexfile_path and uC type\n";
		print 'e.g. CA from TC system(\'call C:\TurboLIFT\Tools\AB12flash\AB12flash.pl \'." --E1serial=3es049632c --hexfile=AB1225_BB00000_F05_Cat2_20150422.hex --uC=R1L");';
		print 'e.g. ISU from TC system(\'call C:\TurboLIFT\Tools\AB12flash\AB12flash.pl \'." --E1serial=3es049632c --hexfile=AB1210_BD_0031_BB000000_Cat2.hex --uC=D3");';
		exit;
	}

	unless ( defined $opt_nvmfile ) {
		$opt_nvmfile = $opt_hexfile;
		$opt_nvmfile =~ s/\.hex/\_dflash.hex/;
	}

	print "Starting with following options:\n";
	print " E1serial => $opt_E1serial\n";
	print " uC => $opt_uC\n";
	print " hexfile => $opt_hexfile\n";
	print " nvmfile => $opt_nvmfile\n";
	

	my $rwsActiveProj = "NOT_DEFINED";
    my $needsCleanHex = 0;
    my $extendCodeFlash = 0;

	# Select RFP workspace for device
	switch ($opt_uC) {
		case "R1L"    { $rwsActiveProj = "R1L512k_ecuFlash"; $needsCleanHex = 1; $extendCodeFlash = 1; }
		case "R1L1MB" { $rwsActiveProj = "R1L1MB_ecuFlash";  $needsCleanHex = 1; $extendCodeFlash = 1; }
		case "D4"     { $rwsActiveProj = "P1xD4_ecuFlash";   $needsCleanHex = 0; }
		case "D3"     { $rwsActiveProj = "P1xD3_ecuFlash";   $needsCleanHex = 0; }
		case "D3A"    { $rwsActiveProj = "P1xD3A_ecuFlash";   $needsCleanHex = 0; }
		else {
			( $rwsActiveProj, $needsCleanHex, $extendCodeFlash ) = split( /;/, $opt_uC );
		}
	}

	print "Using uC device settings $rwsActiveProj\n";
	die "settings missing or incomplete\n" unless ( -f $tool_path . "\\$rwsActiveProj\\$rwsActiveProj.rpj" );

	unless ( -e $opt_hexfile ) { die "ERROR! Couldn't find hexfile. Looking for $opt_hexfile\n"; }
	unless ( -e $opt_nvmfile ) { die "ERROR! Couldn't nvm file. Looking for $opt_nvmfile\n"; }
	
	unless ( -d $tmpDir ) { mkdir($tmpDir) || die "Error creating dir $tmpDir: $!"; }

	if ( $needsCleanHex == 1 ) {
		# Clean the hex file if required (only for R1x)
		$opt_hexfile = prepareHexFile($opt_hexfile);

		# prepareHexFile needs temp dir, so run after CheckEnvironment()   -> TODO 
	}

	prepareRFPworkspace( $rwsTemplate, $rwsActiveProj, $rwsFileName );    # Create workspace file (rws) for RFP tool

	launchRFP($extendCodeFlash);                                          # Prepare config files and launch RFP in batch mode
	print "ecuflash ends.\n";
}    # end of main

###############################################################################
# Subs
###############################################################################
sub prepareHexFile

  # Check if hex file contains any information which RFP can't understand,
  # e.g. "Consolidated hex" header
  # If so, create a clean copy of hex file and flash the copy instead of original
  # returns path/filename of original or cleaned file
{
	my $oriFile   = shift();
	my $cleanFile = $tmpDir . '\\cleanHexFile.hex';
	my $state     = 'clean';

	open ORI,   "$oriFile"    or die "ERROR! Couldn't open $oriFile for reading ";
	open CLEAN, ">$cleanFile" or die "ERROR ! Couldn't open $cleanFile for writing ";

	do {
		my $line = <ORI>;
		if ( $line =~ /Consolidated HEX/ ) {
			$state = 'dirty';
		}
		else {
			print CLEAN $line;
		}
	} until ( eof(ORI) );
	close(ORI);
	close(CLEAN);

	if ( $state eq 'clean' ) {
		return ($oriFile);
	}
	else {
		return ($cleanFile);
	}
}

sub prepareRFPworkspace

  # Prepare RFP workspace (.rws) file
  # Version from tools subproject must be patched to select device
{
	my $rwsTemplate   = shift;
	my $rwsActiveProj = shift;
	my $rwsFileName   = shift;

	my $rwsFileContent;
	my $line;

	open RWS, $rwsTemplate or die "Couldn't open file $rwsTemplate !";
	while ( $line = <RWS> ) {

		# replace dummy with current project data
		$line =~ s/dummy_to_be_replaced/$rwsActiveProj/g;
		if ( $line =~ /<ActiveProjectName>/ ) {

			# Line contains the active project, replace by desired value
			$rwsFileContent .= "  <ActiveProjectName>$rwsActiveProj</ActiveProjectName>\n";
		}
		else {
			$rwsFileContent .= $line;
		}
	}
	close RWS;

	# remove write protection for rws file
	chmod 0777, $rwsFileName;

	# Write updated file
	open RWS, ">$rwsFileName" or die "Couldn't open file $rwsFileName for writing !";
	print RWS $rwsFileContent;
	close RWS;
}

sub launchRFP

  # Prepare necessary config and log files, then start RFP programmer in batch mode
{
	my $extendCodeFlash = shift;

	# Record startime
	my $starttime = time();

	# Delete previous logfile
	unlink "$tmpDir\\$rfpLogFile";    # both defined global

	# Create RFP script file
	my $rfpScript;

	$rfpScript = <<EOF_RSC;
// Script for Renesas Flash Programmer
// Created by AB12flash.pl
// Hint: All files must be given with ABSOLUTE path !
log "<LOGFILE>"
workspace "<WORKSPACE>"
serial e1 <SerialNumE1>
connect
// If data flash write is enabled, erase complete device first
// to make sure that no previous data flash content remains
<DF_ENABLE>erase device
// Program flash area
programfile "<HEXFILE>" userdata
program
// verify
// Extended user area (program flash)
// Not needed for P1x
<EXTEND_ENABLE>programfile "<HEXFILE>" userboot
<EXTEND_ENABLE>program
// verify
// Data flash area
<DF_ENABLE>programfile "<DATAHEXFILE>" userdata
<DF_ENABLE>program
// verify
disconnect
EOF_RSC

	# Put in variables
	my $absLogFileName = rel2AbsPath("$tmpDir\\$rfpLogFile");
	$rfpScript =~ s/<LOGFILE>/$absLogFileName/;

	my $absHexFileName = rel2AbsPath($opt_hexfile);
	$rfpScript =~ s/<HEXFILE>/$absHexFileName/g;
	$rfpScript =~ s/<SerialNumE1>/$opt_E1serial/;    # Fill in serial number from ini file

	my $absWorkSpace = rel2AbsPath($rwsFileName);
	$rfpScript =~ s/<WORKSPACE>/$absWorkSpace/;

	# Extended code flash programming (only R1x)
	if ( $extendCodeFlash == 1 ) {
		$rfpScript =~ s/<EXTEND_ENABLE>//g;          # Remove place holder to enable command
	}
	else {

		# Disable extended code flash file in RFP script by commenting out the lines
		$rfpScript =~ s/<EXTEND_ENABLE>/\/\/ /g;
	}

	# Data flash file (only if needed)
	if ( defined($opt_nvmfile) ) {
		my $absDataFlashFile = rel2AbsPath($opt_nvmfile);
		$rfpScript =~ s/<DATAHEXFILE>/$absDataFlashFile/g;
		$rfpScript =~ s/<DF_ENABLE>//g;                      # Remove place holder to enable command
	}
	else {

		# Disable data flash file in RFP script by commenting out the lines
		$rfpScript =~ s/<DF_ENABLE>/\/\/ /g;
	}

	open RSC, ">$tmpDir\\ecuFlash.rsc" or die "Couldn't write rsc file! ";
	print RSC $rfpScript;
	close(RSC);

	print "Starting Flash procedure, please be patient...\n";

	my $cmd = '"' . $rfpExec . '" ' . rel2AbsPath("$tmpDir\\ecuFlash.rsc");
	print "Execute $cmd\n";
	my $ret = system($cmd);

	unless ( $ret == 0 ) {
		print "\nERROR! Flashing failed. Log file below. ERROR!\n\n";
		open( LOG, $absLogFileName ) or die "Couldn't open log file";
		while (<LOG>) { print $_; }
		close(LOG);
		print "\nERROR! Flashing failed. Log file above. ERROR!\n\n";
		die "ERROR! Flashing failed";
	}

	calculateElapsedTime($starttime);
	print "Flashing successfull, ECU will now be reset!\n";

	return 1;
}

sub rel2AbsPath {

	# Takes a relative file path, prepends with current dir to make absolute path
	my $file       = shift();
	my $currentDir = getcwd();

	$file =~ s/\A\./$currentDir/;
	$file =~ s/\//\\/g;
	return ($file);
}

# -----------------------------------------------------------------------------------------------------------
# Calculate the elapsed time from beginnig of build until the end
# -----------------------------------------------------------------------------------------------------------
sub calculateElapsedTime {
	my $starttime = shift;
	my $endtime   = time();
	my $duration  = $endtime - $starttime;
	my ( $sec, $min, $hour, $mday, $mon, $year, $wday, $yday ) = gmtime($duration);
	printf( "Flashing done in %d seconds\n", $sec );
}

__END__
