﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.IO;
using System.Runtime.InteropServices;

namespace GDCOM_Configurator
{
    static class Program
    {
        
        [DllImport("kernel32.dll")]
        private static extern bool AttachConsole(int dwProcessId);
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {           
            if (args.Length > 0)
            {
                Read_ODX_File rodx = new Read_ODX_File();
                Write_ODX_Mapping wodx = new Write_ODX_Mapping();
                Unzip unz = new Unzip();

                AttachConsole(-1);             
                Console.Out.WriteLine("\nLoading PDX file and Unzipping...");

                string pdx_path = args[0];                
                string directory = Environment.CurrentDirectory;
                
                string g_path = directory + "\\Settings\\Global_Data_Settings.xml";
                
                //PDX to ODX
                DirectoryInfo in_dir = new DirectoryInfo(Path.GetDirectoryName(pdx_path));
                string odx_file = in_dir + "\\" + Path.GetFileNameWithoutExtension(pdx_path);

                            
                String ODX_path = unz.extractFileFromZip(pdx_path, odx_file);
                Console.Out.WriteLine("\nUnzipped Successfully");
                if (ODX_path == "null")
                {
                    Environment.Exit(0);                   
                }
                Console.Out.WriteLine("\nReading the ODX Files..");
                //Read ODX files               
                rodx.file_path = ODX_path;
                if (File.Exists(g_path))
                {
                    rodx.global_data_path = g_path;
                }
                else
                    rodx.global_data_path = null;
                
                rodx.flag = 1;
                rodx.Read_ODX();
                Console.Out.WriteLine("\nRead Successfully");
                Console.Out.WriteLine("\nCreating Diagnostic Mapping File...");
                //Creating Diag_Mapping File  
                wodx.flag = 1;
                wodx.Write_odx_Contents(rodx);
                Console.Out.WriteLine("\nDiag_Mapping file Created Successfully");
                System.Windows.Forms.SendKeys.SendWait("{ENTER}");
                Application.Exit();
            }
            else
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new gui_gdcom());
            }         
            
        }       
    }
}
