using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;

using System.Windows.Forms;

using System.Threading;

namespace GDCOM_Configurator
{
    /// <summary>
    /// CSCRM00362011
    /// </summary>
    class ProcessExecutor
    {
        private string execPath, param;
        public bool success = false;
        public string output = "";

        public ProcessExecutor(string execPath, string param)
        {
            this.execPath = execPath;
            this.param = param;
        }

        public void startProcess()
        {
            try
            {
                Process p = new Process();
                p.EnableRaisingEvents = false;
                p.StartInfo.UseShellExecute = false;
                p.StartInfo.CreateNoWindow = true;
                p.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                p.StartInfo.FileName = execPath;
                p.StartInfo.Arguments = param;
                p.StartInfo.RedirectStandardOutput = true;
                p.StartInfo.RedirectStandardError = true;
                p.Start();

               // RBLogManager.getInstance().logDebug("Start process.");

                output = p.StandardOutput.ReadToEnd();
                output += p.StandardError.ReadToEnd();

                if (p != null)
                {
                    p.WaitForExit();
                }
                success = true;

                //RBLogManager.getInstance().logDebug("End ZIP Programm (7ZIP) output: " + output + ", ExitCode:" + p.ExitCode);

                if (p != null) p.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Cannot zip files! " + ex.Message + "\nNot Found.", "Error.",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
            }
         }
    }
}
