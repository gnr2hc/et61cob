#!/bin/env/perl -w

## MODULES ##
use strict;
use Getopt::Long;
use File::Basename;
use File::Copy;
use Tk;

##------------------------------------------------------------------
## VARIABLES OF MAIN
##------------------------------------------------------------------
use vars qw( $VERSION $HEADER );
# next 2 lines edited by CVS, DO NOT MODIFY
$VERSION = q$Revision: 1.5 $;
$HEADER = q$Header: Mappingfile_Generators/LINMapping/LIFT_prepare_LIN_mapping.pl 1.5 2016/08/04 23:25:48ICT Prosch Christian (CC-PS/EPS2) (PHC2SI) develop  $;

my $LPLM_VERSION = "LIFT prepare LIN mapping $VERSION";

my $tool = $HEADER; $tool =~ s/^Header: //;
my $fileName_LIN_mapping_proposed = "Mapping_LIN_ProjectXY.pm";    ## proposal output file name

# our ($opt_ldf_file, $opt_msg_list, $opt_output_file);
our ($opt_ldf_file, $opt_output_file);
# our $selected_LIN_engine = "LIN_engine";
our $selected_LIN_bus_number    = "1";
our $opt_verbose                = 3;  ## preset of verbose level to max
our $opt_sut_node               = 'Airbag';

my $verbose;  # local verbose variable

# TK vars:
my ($main,$F1,$F2,$F1_1,$F1_1ESP,$F1_1_LinEngine,$F1_1_LinBusNbr,$F1_2,$F1_3,$F1_4);
my ($verbose_menu,$temp,$start_button,%ALL_signals_count);

# my (@status_msg,$S_F1,$S_F2,$S_F1_1);

# main loop
LPLM_init();
MainLoop;
# main loop end

##------------------------------------------------------------------
## LPLM_engine
##------------------------------------------------------------------
sub LPLM_engine {
    my $working_dir = dirname ( $0 );
    my $log_file = $working_dir."\\"."LPLM_log_file.txt";
    open( LOG , ">> $log_file" ) || die ("Open file: $!\n");

    S_w2log(1, "STARTING : LPLM_engine ($VERSION)\n");


    open( OUTFILE , "> $opt_output_file" )  || die ("Open file $opt_output_file : $!\n");

#     my %UsedMessages = read_msg_list_file( $opt_msg_list ) if $opt_msg_list;
    my $LDF_content  = process_ldf_file( $opt_ldf_file );

#     if( %UsedMessages )
#     {
#         S_w2log(1, " Create Mapping just for Signals of LIN msg list defined in $opt_msg_list\n");
#         my %FoundReqMsg = check_req_msg_in_ldf( \%LDF_content , \%UsedMessages );
#         write_LIN_mapping( $opt_sut_node , \%LDF_content , \%FoundReqMsg );
#     }
#     else
#     {

    S_w2log(1, " Create Mapping for all Signals of LDF file \n");
    write_LIN_mapping( $opt_sut_node , $LDF_content );

#     }

    close ( OUTFILE );
    close( LOG );
    return 1;
}

##------------------------------------------------------------------
## write_LIN_mapping (  )
##------------------------------------------------------------------
sub write_LIN_mapping {
    my $sut_node = shift;
    my $LDF = shift;
    my $UsedMsg = shift;

    my %ValidMsg = %$UsedMsg if defined $UsedMsg;

    my %ValidDecMsg;
#    my ($MsgLCControl , $MsgLC_DLC);
    my ( $Message_Text , $ValidMsgName , $ValidMsgId , $FrameId , $LinFrameName , $msg_cnt , $MsgIdHex , $MsgSender , $MsgDLC , $MsgCycleTime );
    my ( @sut_snd_msg_ids, @sut_rcv_msg_ids );
    my ( $SignalMapping_Text , $LIN_tool_signal_name , $LdfSignalName , $LdfSig_short_name , $VectorEnvVarSignalName , $LdfSig_Pos , $LdfSig_Length , $LdfSig_DefMax , $LdfSig_Format , $LdfSig_Type , $LdfSig_Factor , $LdfSig_Offset , $LdfSig_Unit , $LdfSig_Multiplex , $Multiplex_Master , $Multiplex_Code);
#     my ( $LC_ReadPhys , $LC_ReadHex , $LC_WritePhys , $LC_WriteHex , );
#     my ( $Edit_Bytes );
    my ( $MsgCanoeDisable , $MsgCanoeDlc , $MsgCanoeTiming );

    S_w2outfile( 1 ,  "### file generated with $tool\n" );
    S_w2outfile( 1 ,  "### input ldf file: $opt_ldf_file\n" );   
    S_w2outfile( 1 ,  "package LIFT_PROJECT;\n\n" );
    S_w2outfile( 1 ,  "\$Defaults->{\"Mapping_LIN\"} = {\n" );
    S_w2outfile( 1 ,  "'NODE_UNDER_TEST'       => '$sut_node',\n\n" );

    S_w2outfile( 1 ,  "'LIN_MESSAGES'  => {\n" );

    foreach $FrameId ( sort {$a<=>$b} keys %{$LDF->{"FRAMES"}} )
    {

        $MsgSender = $LDF->{"FRAMES"}{$FrameId}{"FRAME_SENDER"};
        $LinFrameName = $LDF->{"FRAMES"}{$FrameId}{"FRAME_NAME"};
        $MsgDLC = $LDF->{"FRAMES"}{$FrameId}{"FRAME_DLC"};
        unless( $MsgCycleTime = $LDF->{"FRAMES"}{$FrameId}{"GenMsgCycleTime"} ) {
           $MsgCycleTime = 10;
        }
        

        if( %ValidMsg and not $ValidMsg{ $FrameId } )
        {
            S_w2log(1, " LIN message: $FrameId ('$LinFrameName') not selected in LIN message list -> skipped in LIN mapping\n");
            next;
        }

        if( $MsgSender eq $sut_node )
        {
            ## no LC control for messages from SUT
#            $MsgLCControl    = "undef";
#            $MsgLC_DLC       = "undef";

            ## no CANoe control for messages from SUT
            $MsgCanoeDisable = "undef";
            $MsgCanoeDlc     = "undef";
            $MsgCanoeTiming  = "undef";

            push( @sut_snd_msg_ids , $FrameId);
        }
        else
        {
            ## LC control for messages not from SUT
 #           $MsgLCControl    = "'".$LinFrameName."_USED.".$LinFrameName.".$selected_LIN_engine'";
 #           $MsgLC_DLC       = "'".$LinFrameName."_DLC.".$LinFrameName.".$selected_LIN_engine'";
            
            ## CANoe control for messages not from SUT            
            $MsgCanoeDisable = "'Env".$LinFrameName."To_'";
            $MsgCanoeDlc     = "'Env".$LinFrameName."Dlc_'";
            $MsgCanoeTiming  = "'Env".$LinFrameName."Time_'";

            push( @sut_rcv_msg_ids , $FrameId);
        }
      
# cut form MESSAGE_TEXT
#                        'LC_CONTROL'    => $MsgLCControl,
#                        'LC_DLC'        => $MsgLC_DLC,
       
        $Message_Text =<<MESSAGE_TEXT;
       '$LinFrameName'  =>
                      {
                        'ID'            => $FrameId,
                        'DLC'           => $MsgDLC,
                        'SENDER'        => '$MsgSender',
                        'LIN_BUS_NBR'   => $selected_LIN_bus_number,
                        'CYCLE'         => $MsgCycleTime,
                        'CANOE_DISABLE' => $MsgCanoeDisable ,
                        'CANOE_DLC'     => $MsgCanoeDlc ,
                        'CANOE_TIMING'  => $MsgCanoeTiming ,
                      },
MESSAGE_TEXT

        S_w2outfile( 2 ,  $Message_Text);
    }
    S_w2outfile( 2 ,  "           },\n\n" );

    S_w2outfile( 3 ,  "############################################# \n\n" );
    S_w2outfile( 1 ,  "## --- Signal List (msg by msg , IDs ascending) of System under Test node \n\n" );
    S_w2outfile( 3 ,  "############################################# \n\n" );

    foreach $FrameId ( sort {$a<=>$b} @sut_snd_msg_ids )
    {
        $MsgSender = $LDF->{"FRAMES"}{$FrameId}{"FRAME_SENDER"};
        $LinFrameName = $LDF->{"FRAMES"}{$FrameId}{"FRAME_NAME"};
        $MsgIdHex = sprintf( "0x%x", int $FrameId );

        if( %ValidMsg and not $ValidMsg{ $FrameId } )
        {
            S_w2log(1, " LIN message: $FrameId ('$LinFrameName') not selected in LIN message list -> skipped in LIN mapping\n");
            next;
        }

        S_w2outfile( 3 ,  "# -------------------------------------------------------------------------------------- \n\n" );
        S_w2outfile( 1 ,  "# ----------- LIN FRAME: $LinFrameName ($MsgSender) ID: $FrameId ($MsgIdHex) ------------- \n\n" );
        S_w2outfile( 3 ,  "# -------------------------------------------------------------------------------------- \n\n" );
        foreach $LdfSignalName ( sort keys %{$LDF->{"FRAMES"}{$FrameId}{"SIGNALS"}} )
        {
            #
            # shifting elements from SIGNALS section to FRAMES section 
            #  because definition came later when LDF read
            #                                
            foreach my $elt ( keys %{$LDF->{"SIGNALS"}{$LdfSignalName}} ) {
                $LDF->{"FRAMES"}{$FrameId}{"SIGNALS"}{$LdfSignalName}{$elt} 
                    = $LDF->{"SIGNALS"}{$LdfSignalName}{$elt}; 
            }
                
            $LdfSig_Pos     = $LDF->{"FRAMES"}{$FrameId}{"SIGNALS"}{$LdfSignalName}{"SG_POSITION"};
            $LdfSig_Length  = $LDF->{"FRAMES"}{$FrameId}{"SIGNALS"}{$LdfSignalName}{"SG_LENGTH"};
            $LdfSig_Type    = $LDF->{"FRAMES"}{$FrameId}{"SIGNALS"}{$LdfSignalName}{"SG_TYPE"};
            $LdfSig_Factor  = $LDF->{"FRAMES"}{$FrameId}{"SIGNALS"}{$LdfSignalName}{"SG_FACTOR"};
            $LdfSig_Offset  = $LDF->{"FRAMES"}{$FrameId}{"SIGNALS"}{$LdfSignalName}{"SG_OFFSET"};
            $LdfSig_Unit    = $LDF->{"FRAMES"}{$FrameId}{"SIGNALS"}{$LdfSignalName}{"SG_UNIT"};
            $LdfSig_Format  = $LDF->{"FRAMES"}{$FrameId}{"SIGNALS"}{$LdfSignalName}{"SG_FORMAT"};
            $LdfSig_DefMax  = $LDF->{"FRAMES"}{$FrameId}{"SIGNALS"}{$LdfSignalName}{"SG_DEFINED_MAXIMUM"};

            $Multiplex_Master   = $LDF->{"FRAMES"}{$FrameId}{"SIGNALS"}{$LdfSignalName}{"SG_MULTIPLEXER"};
            $Multiplex_Code     = $LDF->{"FRAMES"}{$FrameId}{"SIGNALS"}{$LdfSignalName}{"SG_MULTIPLEX_VALUE"};

            if( defined $Multiplex_Master ) {
                $LdfSig_Multiplex = "{ 'MASTER' => '$LdfSignalName' }";
            }
            elsif(  defined $Multiplex_Code ) {
                if ( $Multiplex_Master = $LDF->{"FRAMES"}{$FrameId}{"MULTIPLEXER"} ) {
                   $LdfSig_Multiplex = "{ 'MASTER' => '$Multiplex_Master' , 'CODE' => $Multiplex_Code }";
                }
                else  { $LdfSig_Multiplex = "{ 'ERROR' => 'NO_MASTER_FOUND' }"; }
            }
            else { $LdfSig_Multiplex = 'undef'; }


            $LdfSig_short_name = $LDF->{"FRAMES"}{$FrameId}{"SIGNALS"}{$LdfSignalName}{'SHORT_SG_NAME'};

            if( defined $LdfSig_short_name ) {
               $LIN_tool_signal_name = $LdfSig_short_name;
            }
            else {
               $LIN_tool_signal_name = $LdfSignalName;
            }

            my $UniqueSignalName;
            if ($ALL_signals_count{$LdfSignalName} > 1){
                $UniqueSignalName = $LinFrameName.'::'.$LdfSignalName;
            }
            else{
                $UniqueSignalName = $LdfSignalName;
            }

            $SignalMapping_Text =<<SIGMAPTXT;
'$UniqueSignalName'  =>
               {
               'SIGNAL_NAME'   => '$LIN_tool_signal_name',
               'SENDER'        => '$MsgSender',
               'MESSAGE'       => '$LinFrameName',
               'MULTIPLEX'     => $LdfSig_Multiplex,
               'STARTBIT'      => $LdfSig_Pos, 
               'LENGTH'        => $LdfSig_Length, 
               'OFFSET'        => $LdfSig_Offset, 
               'FACTOR'        => $LdfSig_Factor,
               'DEFINED_MAX'   => $LdfSig_DefMax,      # Raw Value / from LDF 
               'FORMAT'        => '$LdfSig_Format', 
               'TYPE'          => '$LdfSig_Type', 
               'UNIT'          => '$LdfSig_Unit',
               'INIT'          => 0,     ## verify INIT value with specifications
               },

SIGMAPTXT
            S_w2outfile( 3 ,  $SignalMapping_Text );

        }
    }

    S_w2outfile( 1 ,  "## Signal List (msg by msg , IDs ascending) from Simulator \n\n" );
    foreach $FrameId ( sort {$a<=>$b} @sut_rcv_msg_ids )
    {
        $MsgSender = $LDF->{"FRAMES"}{$FrameId}{"FRAME_SENDER"};
        $LinFrameName   = $LDF->{"FRAMES"}{$FrameId}{"FRAME_NAME"};
        $MsgDLC    = $LDF->{"FRAMES"}{$FrameId}{"FRAME_DLC"};
        $MsgIdHex  = sprintf( "0x%x", int $FrameId );

        if( %ValidMsg and not $ValidMsg{ $FrameId } )
        {
            S_w2log(1, " LIN message: $FrameId ('$LinFrameName') not selected in LIN message list -> skipped in LIN mapping\n");
            next;
        }

        S_w2outfile( 3 ,  "# -------------------------------------------------------------------------------------- \n\n" );
        S_w2outfile( 1 ,  "# ----------- LIN FRAME: $LinFrameName ($MsgSender) ID: $FrameId ($MsgIdHex) ------------- \n\n" );
        S_w2outfile( 3 ,  "# -------------------------------------------------------------------------------------- \n\n" );
        foreach $LdfSignalName ( sort keys %{$LDF->{"FRAMES"}{$FrameId}{"SIGNALS"}} )
        {

            #
            # shifting elements from SIGNALS section to FRAMES section 
            #  because definition came later when LDF read
            #                                
            foreach my $elt ( keys %{$LDF->{"SIGNALS"}{$LdfSignalName}} ) {
                $LDF->{"FRAMES"}{$FrameId}{"SIGNALS"}{$LdfSignalName}{$elt} 
                    = $LDF->{"SIGNALS"}{$LdfSignalName}{$elt}; 
            }

            $LdfSig_Pos    = $LDF->{"FRAMES"}{$FrameId}{"SIGNALS"}{$LdfSignalName}{"SG_POSITION"};
            $LdfSig_Length = $LDF->{"FRAMES"}{$FrameId}{"SIGNALS"}{$LdfSignalName}{"SG_LENGTH"};
            $LdfSig_Format = $LDF->{"FRAMES"}{$FrameId}{"SIGNALS"}{$LdfSignalName}{"SG_FORMAT"};
            $LdfSig_Type   = $LDF->{"FRAMES"}{$FrameId}{"SIGNALS"}{$LdfSignalName}{"SG_TYPE"};
            $LdfSig_Factor = $LDF->{"FRAMES"}{$FrameId}{"SIGNALS"}{$LdfSignalName}{"SG_FACTOR"};
            $LdfSig_Offset = $LDF->{"FRAMES"}{$FrameId}{"SIGNALS"}{$LdfSignalName}{"SG_OFFSET"};
            $LdfSig_Unit   = $LDF->{"FRAMES"}{$FrameId}{"SIGNALS"}{$LdfSignalName}{"SG_UNIT"};
            $LdfSig_DefMax = $LDF->{"FRAMES"}{$FrameId}{"SIGNALS"}{$LdfSignalName}{"SG_DEFINED_MAXIMUM"};

            $Multiplex_Master = $LDF->{"FRAMES"}{$FrameId}{"SIGNALS"}{$LdfSignalName}{"SG_MULTIPLEXER"};
            $Multiplex_Code = $LDF->{"FRAMES"}{$FrameId}{"SIGNALS"}{$LdfSignalName}{"SG_MULTIPLEX_VALUE"};

            if( defined $Multiplex_Master ) {
                $LdfSig_Multiplex = "{ 'MASTER' => '$LdfSignalName' }";
            }
            elsif(  defined $Multiplex_Code ) {
                if ( $Multiplex_Master = $LDF->{"FRAMES"}{$FrameId}{"MULTIPLEXER"} ) {
                   $LdfSig_Multiplex = "{ 'MASTER' => '$Multiplex_Master' , 'CODE' => $Multiplex_Code }";
                }
                else  { $LdfSig_Multiplex = "{ 'ERROR' => 'NO_MASTER_FOUND' }"; }
            }
            else { $LdfSig_Multiplex = 'undef'; }

            $LdfSig_short_name = $LDF->{"FRAMES"}{$FrameId}{"SIGNALS"}{$LdfSignalName}{'SHORT_SG_NAME'};

            if( defined $LdfSig_short_name ) {
               $LIN_tool_signal_name = $LdfSig_short_name;
            }
            else {
               $LIN_tool_signal_name = $LdfSignalName;
            }

            my $UniqueSignalName;
            if ($ALL_signals_count{$LdfSignalName} > 1){
                $UniqueSignalName = $LinFrameName.'::'.$LdfSignalName;
            }
            else{
                $UniqueSignalName = $LdfSignalName;
            }

            $VectorEnvVarSignalName = "Env".$LIN_tool_signal_name."_";

            $SignalMapping_Text =<<SIGMAPTXT;
'$UniqueSignalName' =>
               {
               'SIGNAL_NAME'   => '$LIN_tool_signal_name',
               'SENDER'        => '$MsgSender',
               'MESSAGE'       => '$LinFrameName',
               'MULTIPLEX'     => $LdfSig_Multiplex,
               'STARTBIT'      => $LdfSig_Pos, 
               'LENGTH'        => $LdfSig_Length, 
               'OFFSET'        => $LdfSig_Offset, 
               'FACTOR'        => $LdfSig_Factor,
               'DEFINED_MAX'   => $LdfSig_DefMax,      # Raw Value / from LDF
               'FORMAT'        => '$LdfSig_Format', 
               'TYPE'          => '$LdfSig_Type', 
               'UNIT'          => '$LdfSig_Unit',
               'CANOE_ENV_VAR' => '$VectorEnvVarSignalName',
               },

SIGMAPTXT
            S_w2outfile( 3 ,  $SignalMapping_Text );

        }
    }


    S_w2outfile( 1 ,  "};\n# end of LIN mapping\n\n1;\n" );

    return 1;
}


##------------------------------------------------------------------
## process_ldf_file ( file_name )
##------------------------------------------------------------------
sub process_ldf_file {
    my $ldf_file = shift;
    
    S_w2log(1, "Sub: process_ldf_file: $ldf_file\n");
    
    my $LDF = {};  # will be returned
    my ( $FRAME_ID , $FRAME_NAME , $FRAME_DLC , $FRAME_SENDER , $FRAME_Time );
    my ( $SG_NAME , $SG_POSITION , $SG_LENGTH , $SG_FORMAT , $SG_TYPE , $SG_FACTOR , $SG_OFFSET , $SG_UNIT , $SG_MODULS , $SG_MINIMUM , $SG_MAXIMUM , $SG_DEFINED_MAXIMUM );
    my ( $SG_MULTIPLEX_VALUE, $SG_MULTIPLEXER, $SHORT_SG_NAME); 
    my ( $SIG_ENCOD_TYPE , $SIG_ENCOD_LOGICAL_VALUE , $SIG_ENCOD_LOGICAL_LABEL );
    my ( $SIG_ENCOD_PHYSICAL_MIN_VALUE_RAW , $SIG_ENCOD_PHYSICAL_MAX_VALUE_RAW , $SIG_ENCOD_PHYSICAL_FACTOR , $SIG_ENCOD_PHYSICAL_OFFSET , $SIG_ENCOD_PHYSICAL_UNIT );
    my ( $Frames_match , $Signals_match , $Signal_encoding_types_match  );
    my ( $temp_ALL_ASSIGNED_SIGNALS , @all_assigned_signals );
        
    my $msg_cnt=0; my $sig_cnt;
   
    open( LDFIN , "< $ldf_file") || die ("Open file $ldf_file: $!\n");
    while (<LDFIN>) {

        S_w2log( 4 , " Line : $_ " );

        if ( /^Nodes\s*\{/i .. /\}/i ) {
            S_w2log( 1 , "BLOCK ---> 'Nodes' --> " );
            S_w2log( 1 , "$_\n" );
        }

        #
        # Matching BLOCK : Signals
        #
        #         Signals {
        #         	Bckl_Sw_D_Stat : 2, 3, ORC, OCM;
        #         	Bckl_Sw_FP_Stat : 2, 3, ORC, OCM;
        #           ...
        #         }
        #
        if ( /^Signals\s*\{/i .. /\}/i ) {
            unless( $Signals_match ) { 
                S_w2log( 2 , "BLOCK ---> 'Signals' <-- BEGIN \n" );
                $Signals_match = 1;
                next 
            }
            if( 
                /
                    \s*     # ...
                    (\w+)   # the SIGNAL NAME
                    \s*     # ...
                    :       # the ':'
                    \s*     # ...
                    (\d+)   # the SIGNAL LENGTH
                    \s*     # ...
                    ,       # the ','
                    \s*     # ...
                    (\d+)   # the SIGNAL DEFINED MAXIMUM
                    \s*     # ...
                    ,       # the ','
                    \s*     # ...
                    (.+)    # all NODES (with ',') until ';'
                    ;                
                /x
                ) {
            
                $sig_cnt++; 
                
                S_w2log( 3, "\n - $msg_cnt - ($sig_cnt) - $_" );
                
                $SG_NAME     = $1;
                $SG_LENGTH   = $2;
                $SG_DEFINED_MAXIMUM  = $3;

                S_w2log( 3, "  ->  SG_NAME : $SG_NAME\n");
                S_w2log( 3, "  ->  SG_LENGTH : $SG_LENGTH\n");
                S_w2log( 3, "  ->  SG_DEFINED_MAXIMUM : $SG_DEFINED_MAXIMUM\n");

                $LDF->{"SIGNALS"}{$SG_NAME}{"SG_LENGTH"} = $SG_LENGTH;
                $LDF->{"SIGNALS"}{$SG_NAME}{"SG_DEFINED_MAXIMUM"} = $SG_DEFINED_MAXIMUM;  # it's just the defined maximum , error value can be greater
                $LDF->{"SIGNALS"}{$SG_NAME}{"SG_MINIMUM"} = 0;            # <--- might be changed later
                $LDF->{"SIGNALS"}{$SG_NAME}{"SG_OFFSET"} = 0;             # <--- might be changed later
                $LDF->{"SIGNALS"}{$SG_NAME}{"SG_FACTOR"} = 1;             # <--- might be changed later
                $LDF->{"SIGNALS"}{$SG_NAME}{"SG_UNIT"} = "";              # <--- might be changed later
                $LDF->{"SIGNALS"}{$SG_NAME}{"SG_TYPE"} = "UNSIGNED";      # <--- might be changed later
                $LDF->{"SIGNALS"}{$SG_NAME}{"SG_FORMAT"} = "INTEL";       # <--- just define something

                next;
            }
        } 

        #
        # Matching BLOCK BEGIN : Frames
        #
        #         Frames {                                       <<<<--------
        #         	ORC_STAT_Frm1_AR2 : 5, ORC, 8 {
        #         		Bckl_Sw_D_Stat, 0;
        #         		Parity_Bckl_Sw_D_Stat, 2;
        #                 ....
        #         	}
        #             ....
        #         }
        #         
        if ( /^Frames\s*\{/i and not $Frames_match ) {
            S_w2log( 1 , "BLOCK ---> 'Frames' <-- BEGIN \n" );
            $Frames_match = 1;
            next;
        }

        if( $Frames_match ) {

            if( not $FRAME_NAME and /\}/ ) {
                S_w2log( 1 , "BLOCK ---> 'Frames' <-- END \n" );
                undef $Frames_match;
                next;
            }
        
            #
            # Matching BLOCK BEGIN : <FRAME>
            #
            #         	ORC_STAT_Frm1_AR2 : 5, ORC, 8 {               <<<-------
            #         		Bckl_Sw_D_Stat, 0;
            #         		Parity_Bckl_Sw_D_Stat, 2;
            #                 ....
            #         	}
            if ( not $FRAME_NAME and 
                /
                    \s*     # ...
                    (\w+)   # the FRAME NAME
                    \s*     # ...
                    :       # the ':'
                    \s*     # ...
                    (\w+)   # the FRAME ID (can be dec or hex)
                    \s*     # ...
                    ,       # the ','
                    \s*     # ...
                    (\w+)   # the FRAME SENDER
                    \s*     # ...
                    ,       # the ','
                    \s*     # ...
                    (\d+)   # the FRAME DLC (LENGTH)
                    \s*     # ...
                    \{      # the '{'
                /x 
                ) {
                
                $msg_cnt++;
                $sig_cnt=0;
    
                $FRAME_NAME    = $1;
                $FRAME_ID      = $2;
                $FRAME_SENDER  = $3;
                $FRAME_DLC     = $4;
                
                S_w2log( 2 , "BLOCK ---> <FRAME: $FRAME_NAME> <-- BEGIN \n" );
                
                S_w2log( 3 , "\n- $msg_cnt - FRAME_ID: $FRAME_ID FRAME_NAME: $FRAME_NAME  FRAME_DLC: $FRAME_DLC FRAME_SENDER: $FRAME_SENDER\n" );
                $LDF->{"FRAMES"}{$FRAME_ID}{"FRAME_NAME"}   = $FRAME_NAME;
                $LDF->{"FRAMES"}{$FRAME_ID}{"FRAME_DLC"}    = $FRAME_DLC;
                $LDF->{"FRAMES"}{$FRAME_ID}{"FRAME_SENDER"} = $FRAME_SENDER;
                
                next;                
            }

            if( $FRAME_NAME and /\}/ ) {
                S_w2log( 1 , "BLOCK ---> <FRAME: $FRAME_NAME> <-- END \n" );
                undef $FRAME_NAME;
                next;
            }
            
            #
            # Matching : <SIGNAL>   in FRAME BLOCK
            #
            #         	ORC_STAT_Frm1_AR2 : 5, ORC, 8 {              
            #         		Bckl_Sw_D_Stat, 0;                        <<<-------
            if( $FRAME_NAME and 
                /
                    \s*     # ...
                    (\w+)   # the SIGNAL NAME
                    \s*     # ...
                    ,       # the ','
                    \s*     # ...
                    (\d+)   # the SIGNAL POSITION
                    \s*     # ...
                    ;       # the ';'                
                /x
                ) {
                
                $SG_NAME     = $1;
                $SG_POSITION = $2;

                S_w2log( 1 , "BLOCK ---> <SIGNAL: $SG_NAME> <-- \n" );
                
                $LDF->{"FRAMES"}{$FRAME_ID}{"SIGNALS"}{$SG_NAME}{"SG_POSITION"}  = $SG_POSITION;

                # increase signal counter for later plausibility check
                $ALL_signals_count{$SG_NAME}++;

                next;                
            }
            
        }
        
        
        if ( /^Diagnostic_signals\s*\{/i .. /\}/i ) {
            S_w2log( 1 , "BLOCK ---> 'Diagnostic_signals' --> " );
            S_w2log( 1 , "$_\n" );
        }

        if ( /^Diagnostic_frames\s*\{/i .. /\}/i ) {
            S_w2log( 1 , "BLOCK ---> 'Diagnostic_frames' --> " );
            S_w2log( 1 , "$_\n" );
        }

        if ( /^Node_attributes\s*\{/i .. /\}/i ) {
            S_w2log( 1 , "BLOCK ---> 'Node_attributes' --> " );
            S_w2log( 1 , "$_\n" );
        }

        #
        # Matching BLOCK BEGIN : Signal_encoding_types
        #
        #         Signal_encoding_types {                           <<<<--------
        #         	c01_FalseTrue {
        #         		logical_value, 0, "FALSE";
        #         		logical_value, 1, "TRUE";
        #         	}
        #         	c02_ActvComf_Stat {
        #         		logical_value, 0, "ACTV_COMF_OFF";
        #         }
        #         
        if ( /^Signal_encoding_types\s*\{/i and not $Signal_encoding_types_match ) {
            S_w2log( 2 , "BLOCK ---> 'Signal_encoding_types' <-- BEGIN \n" );
            $Signal_encoding_types_match = 1;
            next;
        }

        if( $Signal_encoding_types_match ) {

            if( not $SIG_ENCOD_TYPE and /\}/ ) {
                S_w2log( 1 , "BLOCK ---> 'Signal_encoding_types' <-- END \n" );
                undef $Signal_encoding_types_match;
                next;
            }
        
            #
            # Matching BLOCK BEGIN : <SIG_ENCOD_TYPE>
            #
            #         Signal_encoding_types {                 
            #         	c01_FalseTrue {                             <<<<--------
            #         		logical_value, 0, "FALSE";
            #         		logical_value, 1, "TRUE";
            #         	}
            #         	c02_ActvComf_Stat {
            if ( not $SIG_ENCOD_TYPE and 
                /
                    \s*     # ...
                    (\w+)   # the SIG ENCOD TYPE
                    \s*     # ...
                    \{      # the '{'
                /x 
                ) {
                
                $SIG_ENCOD_TYPE    = $1;

                S_w2log( 2 , "BLOCK ---> <SIG_ENCOD_TYPE: $SIG_ENCOD_TYPE> <-- BEGIN \n" );

                $LDF->{"SIG_ENCODINGS"}{$SIG_ENCOD_TYPE} = {};  # just to create the key
                next;
            }

            if( $SIG_ENCOD_TYPE and /\}/ ) {
                S_w2log( 1 , "BLOCK ---> <SIG_ENCOD_TYPE: $SIG_ENCOD_TYPE> <-- END \n" );
                undef $SIG_ENCOD_TYPE;
                next;
            }

            #
            # Matching SIG ENCODING logical_value in  : <SIG_ENCOD_TYPE>
            #
            #         Signal_encoding_types {                 
            #         	c01_FalseTrue {                             
            #         		logical_value, 0, "FALSE";            <<<<--------
            #         		logical_value, 1, "TRUE";
            #         	}
            if( $SIG_ENCOD_TYPE and 
                /
                    \s*     # ...
                    logical_value   # the 'logical_value'
                    \s*     # ...
                    ,       # the ','
                    \s*     # ...
                    (\d+)   # the SIG VALUE
                    \s*     # ...
                    ,       # the ','
                    \s*     # ...
                    \"      # the "
                    (.+)    # the SIG LABEL
                    \"      # the "
                    \s*     # ...
                    ;       # the ';'                
                /x
                ) {
                
                $SIG_ENCOD_LOGICAL_VALUE     = $1;
                $SIG_ENCOD_LOGICAL_LABEL     = $2;

                $LDF->{"SIG_ENCODINGS"}{$SIG_ENCOD_TYPE}{'LOGICAL_VALUE'}{$SIG_ENCOD_LOGICAL_VALUE} = $SIG_ENCOD_LOGICAL_LABEL;
                                
                S_w2log( 3 , "\n - SIG_ENCOD_TYPE: $SIG_ENCOD_TYPE --- logical_value : $SIG_ENCOD_LOGICAL_VALUE => $SIG_ENCOD_LOGICAL_LABEL\n" );
                next;
            }


            #
            # Matching SIG ENCODING physical_value in  : <SIG_ENCOD_TYPE>
            #
            #         Signal_encoding_types {                 
            #         	c12_g_m2_2_0k001 {
            #         		physical_value, 0, 4000, 0.001, -2, "g";   <----
            #         		logical_value, 4094, "FAULT";
            #         		logical_value, 4095, "SNA";
            #         	}
            if( $SIG_ENCOD_TYPE and 
                /
                    \s*     # ...
                    physical_value   # the 'logical_value'
                    \s*     # ...
                    ,       # the ','
                    \s*     # ...
                    (\d+)   # the SIG MIN VALUE RAW   (e.g. 0)
                    \s*     # ...
                    ,       # the ','
                    \s*     # ...
                    (\d+)   # the SIG MAX VALUE RAW   (e.g. 4000)
                    \s*     # ...
                    ,       # the ','
                    \s*     # ...
                    (
                       [+-]?\d*\.?\d*[Ee][+-]\d+|
                       [+-]?\d+\.\d+|
                       [+-]?\d+\.|
                       [+-]?\.\d+|
                       [+-]?\d+
                    ) # match the FACTOR
                    \s*     # ...
                    ,       # the ','
                    \s*     # ...
                    (
                       [+-]?\d*\.?\d*[Ee][+-]\d+|
                       [+-]?\d+\.\d+|
                       [+-]?\d+\.|
                       [+-]?\.\d+|
                       [+-]?\d+
                    ) # match the OFFSET
                    \s*     # ...
                    ,       # the ','                    
                    \s*     # ...
                    \"      # the "
                    (.+)    # the UNIT
                    \"      # the "
                    \s*     # ...
                    ;       # the ';'                
                /x
                ) {
                
                $SIG_ENCOD_PHYSICAL_MIN_VALUE_RAW   = $1;
                $SIG_ENCOD_PHYSICAL_MAX_VALUE_RAW   = $2;
                $SIG_ENCOD_PHYSICAL_FACTOR          = $3;
                $SIG_ENCOD_PHYSICAL_OFFSET          = $4;
                $SIG_ENCOD_PHYSICAL_UNIT            = $5;

                $LDF->{"SIG_ENCODINGS"}{$SIG_ENCOD_TYPE}{'PHYSICAL_VALUE'}{'SG_FACTOR'}  = $SIG_ENCOD_PHYSICAL_FACTOR;
                $LDF->{"SIG_ENCODINGS"}{$SIG_ENCOD_TYPE}{'PHYSICAL_VALUE'}{'SG_OFFSET'}  = $SIG_ENCOD_PHYSICAL_OFFSET;
                $LDF->{"SIG_ENCODINGS"}{$SIG_ENCOD_TYPE}{'PHYSICAL_VALUE'}{'SG_UNIT'}    = $SIG_ENCOD_PHYSICAL_UNIT;
                $LDF->{"SIG_ENCODINGS"}{$SIG_ENCOD_TYPE}{'PHYSICAL_VALUE'}{'SG_MIN_RAW'} = $SIG_ENCOD_PHYSICAL_MIN_VALUE_RAW;
                $LDF->{"SIG_ENCODINGS"}{$SIG_ENCOD_TYPE}{'PHYSICAL_VALUE'}{'SG_MAX_RAW'} = $SIG_ENCOD_PHYSICAL_MAX_VALUE_RAW;
                                
                S_w2log( 3 , "\n - SIG_ENCOD_TYPE: $SIG_ENCOD_TYPE --- physical_value : FACTOR '$SIG_ENCOD_PHYSICAL_FACTOR' , OFFSET '$SIG_ENCOD_PHYSICAL_OFFSET' UNIT '$SIG_ENCOD_PHYSICAL_UNIT' \n" );
                next;
            }

        }

        # MATCHING BLOCK : Signal_representation
        #
        #         Signal_representation {
        #         	c02_ActvComf_Stat : MCMS_ActvComf_FL_Stat, MCMS_ActvComf_FR_Stat;
        #         	c02_Bckl_Sw_Stat : Bckl_Sw_D_Stat, Bckl_Sw_FP_Stat;
        #             ....
        
        if ( /^Signal_representation\s*\{/i .. /\}/i ) {
            if( 
                /
                    (\w+)   # the SIG ENCODING TYPE 
                    \s*     # ...
                    :       # the ':'
                    \s*     # ...
                    (.+)    # everything (all SIGNALS) until ..
                    ;       # .. the ';' 
                /x 
                ) {
            
                $SIG_ENCOD_TYPE             = $1;    # e.g. c02_ActvComf_Stat
                $temp_ALL_ASSIGNED_SIGNALS  = $2;    # e.g. MCMS_ActvComf_FL_Stat, MCMS_ActvComf_FR_Stat

                $temp_ALL_ASSIGNED_SIGNALS =~ s/\s+//g;   # remove all spaces
                @all_assigned_signals = split( /,/ , $temp_ALL_ASSIGNED_SIGNALS );
                
                # copy now all attributes from signal encoding type to the specific signals
                foreach my $SG_NAME ( @all_assigned_signals ) {
                    if( $LDF->{"SIG_ENCODINGS"}{$SIG_ENCOD_TYPE}{'PHYSICAL_VALUE'} ) {
                        S_w2log( 4, " Signal_representation: $SIG_ENCOD_TYPE -> '$SG_NAME' (assigned physical values)\n" );
                        # assign SG_FACTOR 
                        $LDF->{"SIGNALS"}{$SG_NAME}{'SG_FACTOR'} = $LDF->{"SIG_ENCODINGS"}{$SIG_ENCOD_TYPE}{'PHYSICAL_VALUE'}{'SG_FACTOR'};
                            
                        # assign SG_OFFSET 
                        $LDF->{"SIGNALS"}{$SG_NAME}{'SG_OFFSET'} = $LDF->{"SIG_ENCODINGS"}{$SIG_ENCOD_TYPE}{'PHYSICAL_VALUE'}{'SG_OFFSET'};
                            
                        # assign SG_UNIT 
                        $LDF->{"SIGNALS"}{$SG_NAME}{'SG_UNIT'} = $LDF->{"SIG_ENCODINGS"}{$SIG_ENCOD_TYPE}{'PHYSICAL_VALUE'}{'SG_UNIT'};
                            
                        # assign SG_MIN_RAW 
                        $LDF->{"SIGNALS"}{$SG_NAME}{'SG_MIN_RAW'} = $LDF->{"SIG_ENCODINGS"}{$SIG_ENCOD_TYPE}{'PHYSICAL_VALUE'}{'SG_MIN_RAW'};
                            
                        # assign SG_MAX_RAW 
                        $LDF->{"SIGNALS"}{$SG_NAME}{'SG_MAX_RAW'} = $LDF->{"SIG_ENCODINGS"}{$SIG_ENCOD_TYPE}{'PHYSICAL_VALUE'}{'SG_MAX_RAW'};
                            
                    }
                    
                    if( $LDF->{"SIG_ENCODINGS"}{$SIG_ENCOD_TYPE}{'LOGICAL_VALUE'} ) {
                        # TODO: VALUE TABLE
                    }        
                }                            
            }
        }
        
        
   }
   close LDFIN;

   return $LDF;
}

##------------------------------------------------------------------
sub S_w2log {
##------------------------------------------------------------------
    my $level = shift;
    my $text = shift;

    if ($opt_verbose >= $level) { print $text; }
    print LOG $text;
}

##------------------------------------------------------------------
sub S_w2outfile {
##------------------------------------------------------------------
    my $level = shift;
    my $text = shift;

    if ($opt_verbose >= $level) { print "OUT : $text"; }
    print OUTFILE $text;
    print LOG "OUT : $text";
}


##------------------------------------------------------------------
## LPLM_init
##   (GUI)
##------------------------------------------------------------------
sub LPLM_init {

    ##------------------------------------------------------------------
    ## create main window 'main'
    ##------------------------------------------------------------------
    # create main window 'main'
    $main = MainWindow -> new();

    # define minimum size of main window 'main'
    $main -> minsize(800,300);

    # create title in main window 'main'
    $main -> title
      ( $LPLM_VERSION );

    ##------------------------------------------------------------------
    ## create frame 'F1' in main window 'main'
    ##------------------------------------------------------------------
    $F1 = $main -> Frame
    -> pack
      (
      "-side"   => 'top',
      "-expand" => 1,
      "-fill"   => 'both',
      );

    ##------------------------------------------------------------------
    ## create frame 'F2' in main window 'main'
    ##------------------------------------------------------------------
    $F2 = $main -> Frame
    -> pack
      (
      "-side"   => 'bottom',
      "-fill"   => 'x',
      );

    ##------------------------------------------------------------------
    ## write head line in frame 'F1'
    ##------------------------------------------------------------------
    $F1 -> Label
      (
      "-text" => 'LIFT prepare LIN mapping : configuration window',
      "-font" => "{MS Sans Serif} 13 bold",
      )
    -> pack ("-side"   => "top");

    ##------------------------------------------------------------------
    ## create exit and start buttons in frame 'F2'
    ##------------------------------------------------------------------
    $F2 -> Button
      (
      "-text"    => "Quit",
      "-font" => "{MS Sans Serif} 13 bold",
      "-background" => "red",
      "-command" => sub { print " QUIT pressed -> Exit\n"; exit; }
      )
    -> pack
      (
      "-side"  => 'left',
      "-pady"  => 20,
      "-padx"  => 20,
      "-ipady" => 5,
      "-ipadx" => 5,
      );

    $start_button = $F2 -> Button
      (
      "-text"    => "Start LPLM",
      "-font" => "{MS Sans Serif} 13 bold",
      "-background" => "green",
      "-command" => sub
             {
                if ( $opt_ldf_file and $opt_output_file){
                    #execute LPLM_engine
                    LPLM_engine();
                    S_w2log(1, " Finished -> Press QUIT \n");
                }
                else
                {
                     ##------------------------------------------------------------------
                     ## inform user that options are missing
                     ##------------------------------------------------------------------
                     $main->messageBox (
                      '-icon'    => "error",
                      '-type'    => "OK",
                      '-title'   => 'Error',
                      '-message' => "! not enough options defined ! at least LDF and output file needed ",
                     );
                }
             }
      )
    -> pack
      (
      "-side"  => 'right',
      "-pady"  => 20,
      "-padx"  => 20,
      "-ipady" => 5,
      "-ipadx" => 5,
      );

    ##------------------------------------------------------------------
    ## GET OPTIONS : check if enough options were passed
    ##------------------------------------------------------------------
    if (GetOptions(
                "ldf_file=s",    # ldf file
                "output_file=s", # LIN mapping output file
                "sut_node=s",    # node under test
                "verbose=i",     # verbose level
                )
          && $opt_ldf_file    # ldf file is mandatory
          && $opt_sut_node    # node under test is mandatory
        ){
        # run with option
        exec_options ();
    }
    else { no_options(); } # ask user for options
}

##------------------------------------------------------------------
## exec_options
##------------------------------------------------------------------
sub exec_options {

    $F1 -> Label
      (
#       "-text" => "params:\nLDF file = $opt_ldf_file\nLIN msg list = $opt_msg_list\nLIN mapping output = $opt_output_file\nSUT node = $opt_output_file\nverbose = $opt_verbose",
      "-text" => "params:\nLDF file = $opt_ldf_file\nLIN mapping output = $opt_output_file\nSUT node = $opt_output_file\nverbose = $opt_verbose",
      )
    -> pack ("-side"   => "top");

    #press start button
    $start_button -> invoke();
    exit;
}

##------------------------------------------------------------------
## no_options
##------------------------------------------------------------------
sub no_options {

    $F1 -> Label( "-text" => 'started without/too less params -> using GUI', ) -> pack ("-side"   => "top");

    ##------------------------------------------------------------------
    ## create Frame for choosing LDF file with label, entry and button
    ##------------------------------------------------------------------
    $F1_1 = $F1 -> Frame -> pack ( "-side"   => 'top', "-fill"   => 'x', );

    $F1_1 -> Label ( "-text" => "LDF input file : ", ) -> pack ("-side"   => 'left');

    $F1_1 -> Entry (  "-textvariable" => \$opt_ldf_file , )
            -> pack ( "-side"   => 'left', "-fill"   => 'x', "-expand" => 1, );

    # create 'browse file' button
    $F1_1 -> Button       (
      "-text" => "Browse...",
      "-command" => sub{
                        my $temp = $opt_ldf_file;       # store old value
                        $opt_ldf_file = $main -> getOpenFile (
                            "-filetypes"  => [ ["LDF files", '.ldf'], ["All files", '.*'] ],
                            "-title"      => "LDF file which have to be scanned" ,
                            "-initialdir" => '.',
                        );
                        unless ($opt_ldf_file) {$opt_ldf_file = $temp;} # if no new value, restore old one
                    },
      )
    -> pack ("-side"   => 'right',"-ipadx" => 5,"-ipady" => 2,"-pady" => 10,"-padx" => 5,);

    ##------------------------------------------------------------------
    ## create Frame for choosing output file LIN mapping with label, entry and button
    ##------------------------------------------------------------------
    $F1_4 = $F1 -> Frame -> pack ( "-side"   => 'top', "-fill"   => 'x', );

    $F1_4 -> Label ( "-text" => "LIN mapping output file (*.pm):     ",  ) -> pack ("-side"   => 'left');

    $F1_4 -> Entry (  "-textvariable" => \$opt_output_file , )
            -> pack ( "-side"   => 'left', "-fill"   => 'x', "-expand" => 1, );

#    create 'browse file' button
    $F1_4 -> Button
      (
      "-text" => "Browse...",
      "-command" => sub{
                        my $temp = $opt_output_file;    #   store old value
                        $opt_output_file = $main -> getSaveFile (
                            "-filetypes"  => [ ["All files", '.*'] , ["Perl modules", '.pm'] ],
                            "-title"      => "LIN mapping output file (normally in ProjectDefaults Folder)" ,
                            "-initialdir" => '.',
                            "-initialfile" => $fileName_LIN_mapping_proposed,
                        );
                        unless ($opt_output_file) {$opt_output_file = $temp;}  # if no new value, restore old one
                    },
      )
   -> pack ("-side"   => 'right',"-ipadx" => 5,"-ipady" => 2,"-pady" => 10,"-padx" => 5,);

    ##------------------------------------------------------------------
    ## create Frame for choosing type of LIN_engine
    ##------------------------------------------------------------------
    $F1_1_LinBusNbr = $F1 -> Frame -> pack ( "-side"   => 'top', "-fill"   => 'x', );

    $F1_1_LinBusNbr -> Label (
       "-text" => "LIN Bus number on LIN tool ( default = 1 ) : ",
       ) -> pack ("-side"   => 'left');

    $F1_1_LinBusNbr -> Entry (  "-textvariable" => \$selected_LIN_bus_number , )
                     -> pack  ( "-side"   => 'left', "-fill"   => 'x', "-expand" => 1, -pady => '5m');

    ##------------------------------------------------------------------
    ## create Frame for choosing definition of LIN Node under Test with label, entry and button
    ##------------------------------------------------------------------
    $F1_1ESP = $F1 -> Frame -> pack ( "-side"   => 'top', "-fill"   => 'x', );

    $F1_1ESP -> Label (
       "-text" => "LIN node under test ( default = Airbag ) :     ",
       ) -> pack ("-side"   => 'left');

    $F1_1ESP -> Entry (  "-textvariable" => \$opt_sut_node , )
         -> pack ( "-side"   => 'left', "-fill"   => 'x', "-expand" => 1, );


    ##------------------------------------------------------------------
    ## create Frame for choosing verbose level with label and menubutton
    ##------------------------------------------------------------------
     $F1_3 = $F1 -> Frame -> pack  ( "-side"   => 'top', "-fill"   => 'x', );

     $F1_3 -> Label ( "-text" => "logging level: ", ) -> pack ("-side"   => 'left');

     #create menubutton 'verbose menu' in frame $F1
     $verbose_menu = $F1_3 -> Menubutton
       (
       "-textvariable" => \$opt_verbose,
       "-relief"       => 'groove',
       "-borderwidth"  => 2,
       "-tearoff"      => 0,
       "-width"        => 3,
       );

     #create entries in menu
     foreach $temp (0..$opt_verbose)
     {
       $verbose_menu -> command
         (
         "-label"   => $temp,
         "-command" => sub { $opt_verbose = $temp; $verbose = $opt_verbose; }
         );
     }

     $verbose_menu -> pack ( "-side" => 'left', );

}

##------------------------------------------------------------------
## USAGE, HELP if invalid program call
##------------------------------------------------------------------
sub Usage {
my $help=<<"EOF";
------------------------------------------------------------------------------
PROGRAM: $0
 call program with options:

 EXAMPLE:
 perl $0

------------------------------------------------------------------------------
EOF

print $help;
exit(0);
}

