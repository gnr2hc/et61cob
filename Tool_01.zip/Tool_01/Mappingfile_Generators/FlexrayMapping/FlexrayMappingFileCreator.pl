use strict;
use warnings;
use Getopt::Long;
use File::Basename;
use File::Copy;
use Tk;
use POSIX;

##------------------------------------------------------------------
## VARIABLES OF MAIN
##------------------------------------------------------------------
use vars qw($VERSION $HEADER $ProjectDefaults $CURRENT_TC );

# next 2 lines edited by CVS, DO NOT MODIFY
$VERSION = q$Revision: 1.7 $;
$HEADER  = q$Header: Mappingfile_Generators/FlexrayMapping/FlexrayMappingFileCreator.pl 1.7 2018/12/13 17:25:35ICT NGH5KOR develop  $;

my $MAPP_FILE_VERSION = "LIFT Prepare FlexRay Mapping $VERSION";

my $tool = $HEADER;
$tool =~ s/^Header: //;

my $output_FlexRay_mapping = "Project_XY_FlexRay_mapping.pm";    ## proposal output file name
my $log_File               = "FlexRaymapping_log.txt";

my ( $main, $Frame1, $Frame2, $Frame1_1, $start_button, $button );
my ( $opt_csv_file, $opt_output_file, $error_txt, $is_error );
my $global_data;

my @PDU;
my @FRAMES;
my @SIGNAL;

GUI();
MainLoop;

###########################################################################################

#    GUI( );

#    Initiliazes GUI settings.

##########################################################################################
sub GUI {

##------------------------------------------------------------------
	## create main window 'main'
	##------------------------------------------------------------------
	# create main window 'main'
	$main = MainWindow->new( "-background" => "#888888" );

	# define minimum size of main window 'main'
	$main->minsize( 800, 100 );

	# create title in main window 'main'
	$main->title($MAPP_FILE_VERSION);

	##------------------------------------------------------------------
	## create frame 'F1' in main window 'main'
	##------------------------------------------------------------------
	$Frame1 = $main->Frame( "-background" => "honeydew4" )->pack(
																  "-side"   => 'top',
																  "-expand" => 1,
																  "-fill"   => 'both',
	);

	##------------------------------------------------------------------
	## create frame 'F2' in main window 'main'
	##------------------------------------------------------------------
	$Frame2 = $main->Frame( "-background" => "honeydew4" )->pack( "-side" => 'bottom',
																  "-fill" => 'x', );

	##------------------------------------------------------------------
	## write head line in frame 'F1'
	##------------------------------------------------------------------
	$Frame1->Label(
					"-text"     => 'LIFT Prepare Flexray Mapping : Configuration Window',
					-font       => '{Segoe UI Semibold} 13 bold ',
					-background => "#333546",
					-foreground => "white",
					-width      => 50,
					-relief     => 'groove',
	)->pack( "-side" => "top" );

	#Frame for keeping .csv file generated from Fibex/Autosar explorer and frame based
	my $frame1_csv = $Frame1->Frame( "-background" => "#888888", -relief => 'solid', -borderwidth => 1, )->pack(
																												 "-side"   => 'top',
																												 "-expand" => 0,
																												 "-fill"   => 'both',
																												 "-pady"   => 5,
																												 "-padx"   => 5,
	);

	##------------------------------------------------------------------
	## create Frame for choosing database file(.csv) for flexray with label, entry and button
	##------------------------------------------------------------------
	$Frame1_1 = $frame1_csv->Frame( "-background" => "#888888" )->pack( -pady => '2', "-fill" => 'x', );

	$Frame1_1->Label( "-text" => "Enter the *.csv file generated from FIBEX/AUTOSAR Explorer ", -background => "#888888", -foreground => 'white', -font => '{Segoe UI Semibold} 10 bold', -width => '33.95', -wraplength => 260 )->pack( "-side" => 'left' );

	$Frame1_1->Entry( "-textvariable" => \$opt_csv_file, -validate => 'focusout', -vcmd => [ \&Check_state ], -background => "grey", )->pack( "-side" => 'left', "-fill" => 'x', "-expand" => 1, "-padx" => 5 );

	# create 'browse file' button
	$Frame1_1->Button(
		"-text"     => "Browse...",
		-relief     => 'groove',
		-background => "#333366",
		-foreground => "white",
		-font       => '{Segoe UI Semibold} 10 ',
		"-command"  => sub {
			my $temp = $opt_csv_file;    # store old value
			$opt_csv_file = $main->getOpenFile(
				"-filetypes" => [ [ "Fibex/Autosar files", '.csv' ], [ "All files", '.*' ] ],
				"-title" => "Fibex/Autosar file which have to be scanned",
				"-initialdir" => '.',
			);
			unless ($opt_csv_file) { $opt_csv_file = $temp; }    # if no new value, restore old one
		},
	)->pack( "-side" => 'right', "-ipadx" => 5, "-ipady" => 2, "-pady" => 5, "-padx" => 5 );

	##------------------------------------------------------------------
	## create Frame for choosing output mapping file(.pm) for flexray with label, entry and button
	##------------------------------------------------------------------
	$Frame1_1 = $frame1_csv->Frame( "-background" => "#888888" )->pack( -pady => '2', "-fill" => 'x', );

	$Frame1_1->Label( "-text" => "Flexray Mapping Output File(*.pm) ", -background => "#888888", -foreground => 'white', -font => '{Segoe UI Semibold} 10 bold', -width => '33.95' )->pack( "-side" => 'left' );

	$Frame1_1->Entry( "-textvariable" => \$opt_output_file, -validate => 'focusout', -vcmd => [ \&Check_state ], -background => "grey", )->pack( "-side" => 'left', "-fill" => 'x', "-expand" => 1, "-padx" => 5 );

	# create 'browse file' button
	$button = $Frame1_1->Button(
		"-text"     => "Browse...",
		-relief     => 'groove',
		-background => "#333366",
		-foreground => "white",
		-font       => '{Segoe UI Semibold} 10 ',
		"-command"  => sub {
			if ( -f $opt_csv_file ) {

				my $temp = $opt_output_file;    # store old value
				$opt_output_file = $main->getSaveFile(
					"-filetypes" => [ [ "Perl modules", '.pm' ], [ "All files", '.*' ] ],
					"-title" => "Flexray Mapping Output Files",
					"-initialdir"  => '.',
					"-initialfile" => $output_FlexRay_mapping,
				);

				$opt_output_file = $opt_output_file . ".pm" if ( $opt_output_file && $opt_output_file !~ /^.+\.pm$/ );

				unless ($opt_output_file) { $opt_output_file = $temp; }    # if no new value, restore old one
			}
			else {
				$main->messageBox(
								   '-icon'    => "error",
								   '-type'    => "OK",
								   '-title'   => 'Error',
								   '-message' => "The .csv file entered is invalid ",
				);

			}
		},
	)->pack( "-side" => 'right', "-ipadx" => 5, "-ipady" => 2, "-pady" => 5, "-padx" => 5 );

	##------------------------------------------------------------------
	## create exit and start buttons in frame 'F2'
	##------------------------------------------------------------------
	$Frame2->Button(
					 "-text"     => "Quit",
					 -width      => '8',
					 -font       => '{Segoe UI Semibold} 12 ',
					 -background => "Red4",
					 -foreground => "white",
					 -relief     => 'groove',
					 "-command"  => sub { print " QUIT pressed -> Exit\n"; exit; }
	  )->pack(
			   "-side"  => 'left',
			   "-pady"  => 20,
			   "-padx"  => 20,
			   "-ipady" => 5,
			   "-ipadx" => 5,
	  );

	$start_button = $Frame2->Button(
		"-text"     => "Create",
		-width      => '8',
		-font       => '{Segoe UI Semibold} 12 ',
		-foreground => "white",
		-relief     => 'groove',
		-background => "ForestGreen",
		"-command"  => sub {
			if ( -f $opt_csv_file and $opt_output_file ) {

				$opt_output_file = $opt_output_file . ".pm" if ( $opt_output_file && $opt_output_file !~ /^.+\.pm$/ );

				#execute LPCM_engine
				LPCM_engine();
				S_w2log(" Finished -> Press QUIT \n");
			}
			else {
				##------------------------------------------------------------------
				## inform user that options are missing
				##------------------------------------------------------------------
				$main->messageBox(
								   '-icon'    => "error",
								   '-type'    => "OK",
								   '-title'   => 'Error',
								   '-message' => "! not enough options defined ! at least .csv file generated from FIBEX/AUTOSAR Explorer and Output File are needed ",
				);
			}
		}
	  )->pack(
			   "-side"  => 'right',
			   "-pady"  => 20,
			   "-padx"  => 20,
			   "-ipady" => 5,
			   "-ipadx" => 5,
	  );

}

###########################################################################################

#    LPCM_engine( );

#    Initiliazes GUI settings.

##########################################################################################
sub LPCM_engine() {

	#STEP Launch the FlexRay Mapping File generator tool
	#STEP Enter the mandatory fields
	#COMMENT-START
	# Mandatory
	# - .csv filepath(generated by AUTOSAR/FIBEX explorer)
	# - FlexRay Mapping Output Filepath
	#COMMENT-END
	#STEP Click on 'Create' button to generate the mapping file
	#IF Mandatory Parameter given
	#IF-YES-START
	#IF .csv file format is correct(; separated fields) and it contains the required fields(Ex: Signal name, PDU name...)
	#IF-YES-START
	#STEP Generate the Flexray Mapping File
	#IF-YES-END
	#IF-NO-START
	#STEP Throw an Error that .csv file if of wrong format
	#IF-NO-END
	#IF-YES-END
	#IF-NO-START
	#STEP Throw an error that mandatory fields are not provided
	#IF-NO-END
	#STEP Exit

	open( LOG, "> $log_File" ) || die("Open file: $!\n");

	open( OUTFILE, "> $opt_output_file" ) || die("Open file $opt_output_file : $!\n");

	S_w2log("STARTING : Engine ($VERSION)\n\n");

	undef $global_data;
	undef @PDU;
	undef @FRAMES;
	undef @SIGNAL;

	$is_error = 0;

	my $csv_file_name = $opt_csv_file;

	S_w2log("The CSV File used for generating Mapping File is : $csv_file_name\n\n");

	Process_csv_file($csv_file_name) if ( $csv_file_name && $csv_file_name ne '' );

	if ($is_error) {

		S_w2log("$error_txt\n");
		$main->messageBox( -icon => "error", -message => "Failed to Create the FlexRay Mapping File, Please check the log file (" . File::Spec->rel2abs($log_File) . ") for more info", -title => 'Finished' );

		close(OUTFILE);
		close(LOG);
		return;
	}

	S_w2log("The Ouput FlexRay Mapping File is : $opt_csv_file\n\n");

	Write_Flexray_mapping($opt_csv_file) if ( $opt_csv_file && $opt_csv_file ne '' );

	$main->messageBox( -icon => "info", -message => 'Created Flexray Mapping file', -title => 'Finished' );

	close(OUTFILE);
	close(LOG);

	return 1;

}

###########################################################################################

#    S_w2log( );

#    Writes to Log file.

##########################################################################################
##------------------------------------------------------------------
sub S_w2log {
##------------------------------------------------------------------
	my $text = shift;

	print $text;
	print LOG $text;
}

###########################################################################################

#    S_w2log( );

#    Writes to Output file.

##########################################################################################
##------------------------------------------------------------------
sub S_w2outfile {
##------------------------------------------------------------------
	my $text = shift;

	print "OUT : $text";
	print OUTFILE $text;

	print LOG "OUT : $text";
}

###########################################################################################

#    Process_csv_file( );
#    Reads the .csv file and extracts the raw content and stores it in hash reference.

##########################################################################################
sub Process_csv_file {

	my $csv_file = shift;

	#my @mandatory_fields = ( 'SIGNAL', 'PDU', 'BYTES', 'LENGTH', 'BITPOS', 'CYCLE', 'TYPE', 'FORMAT', 'SCALE_OFFSET', 'TRANSMITTER', 'FRAME', 'DEFAULTVALUE' );
	my %mandatory_fields = (
							 'SIGNAL'       => 'Name or Signal',
							 'PDU'          => 'PDU',
							 'FRAME'        => 'Frame',
							 'BITPOS'       => 'Signal Pos. [Bit] or Signal Position',
							 'LENGTH'       => 'Length [Bit]',
							 'FORMAT'       => 'Byte Order',
							 'SCALE_OFFSET' => 'Computation or Computation Method',
							 'TRANSMITTER'  => 'Transmitter',
							 'BYTES'        => 'Slot',
							 'CYCLE'        => 'ms or Cycle Time [ms]',
	);

	S_w2log("Sub: Process_csv_file: $csv_file\n\n");

	my @columns;
	my $i = 0;    #For extracting the column ie the First row

	#Opens the .csv file
	open( my $csv_FH, "<", $csv_file ) or die "Could not open '$csv_file' $!\n";

	while ( my $line = <$csv_FH> ) {

		if ( $i == 0 ) {
			map { $_ =~ s/"//g; $_ =~ s/﻿//g; push( @columns, $_ ); } split( ';', $line );    #Fetch the data and remove the invisible unwanted characters like ﻿

			if ( ( scalar(@columns) <= 1 ) ) {
				$error_txt = "ERROR : Please check the format of the .csv file generated from FIBEX/AUTOSAR explorer, It should be a ';' separated file\n\n ";
				$is_error  = 1;
				return;
			}

			# manipulate the required column name for better readability
			map {

				$_ =~ s/^Name$/SIGNAL/;
				$_ =~ s/^Signal$/SIGNAL/;
				$_ =~ s/^Slot$/BYTES/;
				$_ =~ s/^Length \[Bit\]$/LENGTH/;
				$_ =~ s/^Signal\sPos\.\s\[Bit\]$/BITPOS/;
				$_ =~ s/^Signal\sPosition$/BITPOS/;
				$_ =~ s/^ms$/CYCLE/;
				$_ =~ s/^Cycle\sTime\s\[ms\]$/CYCLE/;
				$_ =~ s/^Coded\sType$/TYPE/;
				$_ =~ s/^Byte\sOrder$/FORMAT/;
				$_ =~ s/^Computation$/SCALE_OFFSET/;
				$_ =~ s/^Computation\sMethod$/SCALE_OFFSET/;
				$_ =~ s/^Transmitter$/TRANSMITTER/;
				$_ =~ s/^Senders$/TRANSMITTER/;
				$_ =~ s/^Frame$/FRAME/;
				$_ =~ s/^Default\sValue$/DEFAULTVALUE/;
			} @columns;

			$i = 1;
			next;
		}

		my @fields;
		my (%flexray_data_href);
		map { $_ =~ s/"//g; $_ =~ s/﻿//g; push( @fields, $_ ); } split( ';', $line );    #Fetch the data and remove the invisible unwanted characters like ﻿

		if ( ( scalar(@fields) <= 1 ) ) {
			$error_txt = "ERROR : *.csv file is not semicolan ';' seperated. Please recreate it using Fibex / Autosar Explorer\n\n ";
			$is_error  = 1;
			return;
		}

		my @validate_fields = grep {
			my $x = $_;
			not grep { $x =~ /^$_$/ } @columns
		} keys %mandatory_fields;

		#validate whether the required columns needed for flexray mapping file is present in the .csv file
		if ( scalar(@validate_fields) ) {

			$error_txt = "ERROR : Mandatory Columns ";
			map { $error_txt = $error_txt . "'" . $mandatory_fields{$_} . "', " } @validate_fields;
			$error_txt = $error_txt . " are not present in the .csv file. Please recreate it using Fibex / Autosar Explorer \n\n";

			$is_error = 1;
			return;
		}

		#Synchronise the column and the data
		@flexray_data_href{@columns} = @fields;

		# store the data in a format that has to be written in the Mapping File generator
		Process_data( \%flexray_data_href );
		undef %flexray_data_href;
	}
	close $csv_FH;

}

###########################################################################################

#    Process_data( );

#    Process the data obtained from the .csv file and store in a hash which can be used later for writing to Mapping File

##########################################################################################
sub Process_data {
	my $flexray_data_href = shift;

	my $factor;
	my $offset;

	$factor = "1.0";
	$offset = "0";
	
	if ( $flexray_data_href->{'PDU'} =~ // && $flexray_data_href->{'FRAME'} =~ /PDU/ ) {
			$flexray_data_href->{'PDU'} = $flexray_data_href->{'FRAME'};
		}

	#Store the PDU information obtained from the .csv file in a hash
	unless ( grep( /^$flexray_data_href->{'PDU'}$/, @{ $global_data->{'RECIEVE_PDU'} } ) ) {
		push( @PDU, $flexray_data_href->{'PDU'} );
		$global_data->{'RECIEVE_PDU'}                                       = \@PDU;
		$global_data->{'RECIEVE_PDU_CYCLE'}{ $flexray_data_href->{'PDU'} }  = $flexray_data_href->{'CYCLE'};
		$global_data->{'RECIEVE_PDU_SENDER'}{ $flexray_data_href->{'PDU'} } = $flexray_data_href->{'TRANSMITTER'};
	}

	#Store the Signal information obtained from the .csv file in a hash
	unless ( grep( /^$flexray_data_href->{'SIGNAL'}$/, @{ $global_data->{'RECIEVE_SIGNAL'} } ) ) {
		push( @SIGNAL, $flexray_data_href->{'SIGNAL'} );
		$global_data->{'RECIEVE_SIGNAL'} = \@SIGNAL;
		$global_data->{'RECIEVE_SIGNAL_PDU'}{ $flexray_data_href->{'SIGNAL'} } = $flexray_data_href->{'PDU'};

		$global_data->{'RECIEVE_SIGNAL_LENGTH'}{ $flexray_data_href->{'SIGNAL'} } = $flexray_data_href->{'LENGTH'};
		$global_data->{'RECIEVE_SIGNAL_FORMAT'}{ $flexray_data_href->{'SIGNAL'} } = $flexray_data_href->{'FORMAT'};

		my $data_type;
		$data_type = $flexray_data_href->{'TYPE'};
		if ( $data_type =~ /^int/ ) {
			$data_type = "SIGNED";
		}
		else {
			$data_type = "UNSIGNED";
		}
		$global_data->{'RECIEVE_SIGNAL_TYPE'}{ $flexray_data_href->{'SIGNAL'} } = $data_type;

		my $data_bitpos;
		$data_bitpos = $flexray_data_href->{'BITPOS'};
		my @start_bit = split( '\/', $data_bitpos );
		my $leng_comp;

		$start_bit[1] =~ s/\"//g;
		$start_bit[1] =~ s/\s*//g;    #remove if any space is present
		$leng_comp = $start_bit[1];
		$flexray_data_href->{'SIGNAL'} =~ s/\"//g;
		$leng_comp = $leng_comp + $global_data->{'RECIEVE_SIGNAL_LENGTH'}{ $flexray_data_href->{'SIGNAL'} };
		my $len = ceil( $leng_comp / 8 );
		if ( $global_data->{'RECIEVE_PDU_BYTE'}{ $flexray_data_href->{'PDU'} } ) {
			my $temp;
			$temp = $global_data->{'RECIEVE_PDU_BYTE'}{ $flexray_data_href->{'PDU'} };

			if ( $temp < $len ) {
				$global_data->{'RECIEVE_PDU_BYTE'}{ $flexray_data_href->{'PDU'} } = $len;

			}
		}
		else {
			$global_data->{'RECIEVE_PDU_BYTE'}{ $flexray_data_href->{'PDU'} } = $len;
		}

		#Offset and Factor calculation
		$global_data->{'RECIEVE_SIGNAL_START_BIT'}{ $flexray_data_href->{'SIGNAL'} } = $start_bit[1];
		my $data_computation;
		$data_computation = $flexray_data_href->{'SCALE_OFFSET'};

		my $num_regex = '([-+]?\d+(\.\d+([eE][-+]?\d+)?)?)' ;
		$data_computation =~ /.+=\(?$num_regex\)?\*raw$num_regex\)?/;    #[0..250(phys)] phys=(1)*raw+0 or  phys=(1.0*raw+0) / 1.0 or [-30..30(phys)] phys=0.00390625*raw+0
		$factor = $1;
		$offset = $4;

		unless ( defined $factor ) { $factor = "1"; }
		unless ( defined $offset ) { $offset = "0"; }

		$factor =~ s/\+//;
		$offset =~ s/\+//;

		$global_data->{'RECIEVE_SIGNAL_FACTOR'}{ $flexray_data_href->{'SIGNAL'} } = $factor;
		$global_data->{'RECIEVE_SIGNAL_OFFSET'}{ $flexray_data_href->{'SIGNAL'} } = $offset;

	}

}

###########################################################################################

#    Write_Flexray_mapping( );

#    Writes the Data obtained from the.csv file to the Mapping File

##########################################################################################
sub Write_Flexray_mapping {

	S_w2outfile("package LIFT_PROJECT;\n\n");
	S_w2outfile( "\$Defaults->{" . '"' . "Mapping_FLEXRAY" . '"' . "}" . " = { \n" );

	S_w2outfile("################################################################################ \n");
	S_w2outfile("# \n");
	S_w2outfile("    'FR_PDU'  => { \n");
	S_w2outfile("################################################################################ \n");
	S_w2outfile("################################################################################ \n");
	S_w2outfile("# \n");
	S_w2outfile("# 1. Begin Definition of Received PDU's \n");
	S_w2outfile("# \n");
	S_w2outfile("################################################################################ \n");

	foreach my $item ( @{ $global_data->{'RECIEVE_PDU'} } ) {
		S_w2outfile( "      '" . $item . "'  => { \n" );
		S_w2outfile( "                         'DLC'        => " . $global_data->{'RECIEVE_PDU_BYTE'}{$item} . ", \n" );
		S_w2outfile( "                         'SENDER'     => '" . $global_data->{'RECIEVE_PDU_SENDER'}{$item} . "', \n" );
		S_w2outfile( "                         'CYCLE'        => " . $global_data->{'RECIEVE_PDU_CYCLE'}{$item} . ", \n" );
		S_w2outfile( "                         'CANOE_DISABLE'      => 'EnvStart" . $item . "', \n" );
		S_w2outfile("                         },\n");
	}

	S_w2outfile("################################################################################ \n");
	S_w2outfile("# \n");
	S_w2outfile("# 1. End Definition Received PDU's \n");
	S_w2outfile("# \n");
	S_w2outfile("################################################################################ \n");
	S_w2outfile("              }, \n");
	S_w2outfile("# \n");
	S_w2outfile("################################################################################ \n");

	S_w2outfile("################################################################################ \n");
	S_w2outfile("# \n");
	S_w2outfile("# 2. Beginning of RECIEVE signal Definition \n");
	S_w2outfile("# \n");
	S_w2outfile("################################################################################ \n");

	foreach my $item ( @{ $global_data->{'RECIEVE_SIGNAL'} } ) {

		S_w2outfile( "        '" . $item . "'  => { \n" );
		S_w2outfile( "                           'SIGNAL_NAME'        =>  '" . $item . "', \n" );
		S_w2outfile( "                           'FR_PDU_NAME'        => '" . $global_data->{'RECIEVE_SIGNAL_PDU'}{$item} . "', \n" );
		S_w2outfile( "                           'SENDER'             =>  '" . $global_data->{'RECIEVE_PDU_SENDER'}{ $global_data->{'RECIEVE_SIGNAL_PDU'}{$item} } . "', \n" );
		S_w2outfile("                           'MULTIPLEX'          => undef, \n");
		S_w2outfile( "                           'STARTBIT'           => '" . $global_data->{'RECIEVE_SIGNAL_START_BIT'}{$item} . "', \n" );
		S_w2outfile( "                           'LENGTH'          => '" . $global_data->{'RECIEVE_SIGNAL_LENGTH'}{$item} . "', \n" );
		S_w2outfile( "                           'OFFSET'          => '" . $global_data->{'RECIEVE_SIGNAL_OFFSET'}{$item} . "', \n" );
		S_w2outfile( "                           'FACTOR'          => '" . $global_data->{'RECIEVE_SIGNAL_FACTOR'}{$item} . "', \n" );
		S_w2outfile( "                           'FORMAT'             => '" . $global_data->{'RECIEVE_SIGNAL_FORMAT'}{$item} . "', \n" );
		S_w2outfile( "                           'TYPE'          => '" . $global_data->{'RECIEVE_SIGNAL_TYPE'}{$item} . "', \n" );
		S_w2outfile("                           'UNIT'          => '', \n");
		S_w2outfile( "                           'CANOE_ENV_VAR'      => 'Env" . $global_data->{'RECIEVE_SIGNAL_PDU'}{$item} . "_" . $item . "', \n" );
		S_w2outfile("                                            }, \n");

	}
	S_w2outfile("################################################################################ \n");
	S_w2outfile("# \n");
	S_w2outfile("# 2. End of RECIEVE signal Definition \n");
	S_w2outfile("# \n");
	S_w2outfile("################################################################################ \n");

	S_w2outfile("}; \n");
	S_w2outfile("################################################################################ \n");
	S_w2outfile("####################### end of FlexRay mapping ################################## \n");
	S_w2outfile("################################################################################# \n");
	S_w2outfile("1; \n");

}

sub Check_state {
	if ( defined $opt_csv_file && $opt_csv_file ne '' ) {
		$button->configure( -state => 'normal' );

	}
	else {
		$button->configure( -state => 'disabled' );
	}
}
