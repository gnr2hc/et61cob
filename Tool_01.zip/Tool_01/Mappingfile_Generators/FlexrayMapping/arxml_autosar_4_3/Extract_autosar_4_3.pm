package Extract_autosar_4_3;

# *****************************************************************************************************
#
#  Copyright (c) 2018  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#    $Source: Mappingfile_Generators/FlexrayMapping/arxml_autosar_4_3/Extract_autosar_4_3.pm $
#    $Revision: 1.16 $
#    $Author: Rathore Upendra Singh (RBEI/ESA-PP3) (upe1cob) $
#    $State: develop $
#    $Date: 2018/11/15 18:27:38ICT $
#******************************************************************************************************

#################################################################################
# this tool is under MKS version management
our ( $VERSION, $HEADER );
$VERSION = q$Revision: 1.16 $;
$HEADER  = q$Header: Mappingfile_Generators/FlexrayMapping/arxml_autosar_4_3/Extract_autosar_4_3.pm 1.16 2018/11/15 18:27:38ICT Rathore Upendra Singh (RBEI/ESA-PP3) (upe1cob) develop  $;
#################################################################################

use vars qw($VERSION $HEADER @ISA @EXPORT);
use Exporter;

use strict;
use warnings;
use XML::Hash::LX;
use File::Slurp;
use Data::Dumper;
use File::Basename;
use File::Path qw( make_path );

# next 2 lines edited by CVS, DO NOT MODIFY

@ISA    = qw(Exporter);
@EXPORT = qw(

  GetFlexrayMappingContents_fromARXML
  GetSignalCounts_href

);

# =====================================================
# TODO:         Documentation
# =====================================================
# In order to get the required information for Signals, PDU's and frames, few packages has to be read:
# ex Packages : Frames, Pdus, SystemSignals, ISignals, CompuMethods.
# below information are read from respective packages:
#
# Package <Frames> :
#
# Package <Pdus> :
#
# Package <SystemSignals> :
#
# Package <ISignals> :
#
# Package <CompuMethods> :
#  <signal name>

# <ISignals>:

# STEPS or order:
#   - Get all the signals name from package <ISignals>
#      Read below attributes or properties from <ISignals> :
#      - a) signal name
#      - b)
#   - Get  below signals properties from package <SytemSignals>
#      Read below attributes or properties from <SytemSignals> :
#      - a)
#      - b)
#   - Get below signals properties from package <CompuMethods>
#      Read below attributes or properties from <CompuMethods> :
#      - a)
#      - b)
#   - Get below signals properties from package <Pdus>
#      Read below attributes or properties from <Pdus> :
#      - a)
#      - b)
#   - Get below signals properties from package <Frames>
#      Read below attributes or properties from <Frames> :
#      - a)
#      - b)

# =====================================================
#           variables
# =====================================================

# =================================================
#                       ADMINS
# =================================================

# SWITCH FOR DEBUG PRINTOUT'S in the log file:
# - 1 : helpful for developers for debugging, as it print outs a lot of logs. Exection time increases by ~10 sec more.
# - 0 : for users, just switch off.
my $FLAG_EN_DEBUG_PRINT_OUTS = 0;

my $arxml_filePath;
my $log_File = "FlxrArxml_log.txt";

my $signal_count_href;

# =================================================
# FETCH the SIGNAL INFO from below three packages
# =================================================
my $arxmlContents_href;

my $pkg_ISignals_signalsInfo_href;                    # get the signal info from package ISignals
my $pkg_SystemSignals_signalsInfo_href;               # get the signal info from package SystemSignals
my $pkg_CompuMethods_signalsInfo_href;                # get the signal info from package CompuMethods
my $pkg_Pdus_pduAndSignalsInfo_href;                  # get the signal & PDu info from package Pdus
my $pkg_Frames_pduAndFrameInfo_href;                  # get the signal & PDu info from package Frames
my $pkg_ComClusters_secAndiSignal_pduMapping_href;    # get the secured & iSignal pdu mapping info from package CommunicationClusters

# GetFlexrayMappingContents_fromARXML('C:\TurboLIFT\Tools\Mappingfile_Generators\FlexrayMapping\arxml_autosar_4_3\test_arxml\ORC_STAR_3_2020_Ecu_Extract_2018_29a2_AR43.arxml');

#=================================================================
#
# Get the flexRay mapping contents from the arxml autosar 4.3.0.
#
#================================================================
sub GetFlexrayMappingContents_fromARXML {

    my @args          = shift @_;
    my $arxmlFilepath = shift @args;

    # delete the log file..
    unlink($log_File);

    # check existence of the file
    unless ( -e $arxmlFilepath ) {
        S_wr2log( " ERROR : file = '$arxmlFilepath' not found, exiting this ..", 2 );
        return;
    }
    $arxml_filePath = $arxmlFilepath;    # set the file path, used inside this module.

    my $mappingInfo_arxml;

    S_wr2log( "Getting the mapping contensts from the file '$arxmlFilepath' \n", 4 );
    my $autosar_version = ARXML_getAutosarSchemaVersion();
    unless ( $autosar_version =~ /AUTOSAR_4-3-0/i ) {
        S_wr2log( " mismatch between the autosar file versions read = '$autosar_version' and supported = 'AUTOSAR_4-3-0'. Its unknown how it will behave with other autosar verisons, please raise support ticket if this doesnot work.", 3 );
    }

    ARXML_getAll_ARPACKAGE_types() if ( $FLAG_EN_DEBUG_PRINT_OUTS == 1 );    # dump all the package contents in order to analyze more in details

    $mappingInfo_arxml->{ARXML_VERSION} = ARXML_getAutosarSchemaVersion();
    $mappingInfo_arxml->{PDUINFO}       = Extract_all_pdusInfo();
    $mappingInfo_arxml->{SIGNALINFO}    = Extract_all_signalInfo();
    S_dump_2File( 1, 'All_Mappng_generated', $mappingInfo_arxml );

    S_wr2log( "end : mapping contensts from the file '$arxmlFilepath' generated ... \n", 4 );
    return $mappingInfo_arxml;
}

sub GetSignalCounts_href {
    return $signal_count_href;
}

# ==================================================================================
#
#              Data processing for usable mapping file generation
#
# ==================================================================================

sub Extract_all_signalInfo {

    my $all_signalsInfo_href;    # hash containing all the signal(s) info at the end

    my $iSignalsInfo_href   = PKG_ISignals_extractSignalInfo();
    my $system_signals_href = Process_SystemSignals_getArttributes();
    my $pdu_pkg_href        = PKG_Pdus_get_pdu_and_signalInfo();

    # loop over the signals hash and get the desired info
    foreach my $signal_long_name ( keys %{$iSignalsInfo_href} ) {

        my $isignal_href = $iSignalsInfo_href->{$signal_long_name};

        my $signals_short_name = $isignal_href->{'SHORT-NAME'}                   if exists $isignal_href->{'SHORT-NAME'};
        my $pduName            = $isignal_href->{'PDUNAME'}                      if exists $isignal_href->{'PDUNAME'};
        my $signal_length      = $isignal_href->{'LENGTH'}                       if exists $isignal_href->{'LENGTH'};
        my $type_arxml         = $isignal_href->{'NETWORK-REPRESENTATION-PROPS'} if exists $isignal_href->{'NETWORK-REPRESENTATION-PROPS'};

        $all_signalsInfo_href->{'SIGNALS'}{$signal_long_name}{'SIGNAL_NAME'} = $signals_short_name;
        $all_signalsInfo_href->{'SIGNALS'}{$signal_long_name}{'FR_PDU_NAME'} = $pduName;
        $all_signalsInfo_href->{'SIGNALS'}{$signal_long_name}{'LENGTH'}      = $signal_length;
        $all_signalsInfo_href->{'SIGNALS'}{$signal_long_name}{'TYPE'}        = Get_type($type_arxml) // 'UNSIGNED';

        #
        # extract signal data from system signals
        #
        $all_signalsInfo_href->{'SIGNALS'}{$signal_long_name}{'OFFSET'}   = $system_signals_href->{$signals_short_name}{'OFFSET'};
        $all_signalsInfo_href->{'SIGNALS'}{$signal_long_name}{'FACTOR'}   = $system_signals_href->{$signals_short_name}{'FACTOR'};
        $all_signalsInfo_href->{'SIGNALS'}{$signal_long_name}{'MinValue'} = $system_signals_href->{$signals_short_name}{'MIX_VALUE'};
        $all_signalsInfo_href->{'SIGNALS'}{$signal_long_name}{'MaxValue'} = $system_signals_href->{$signals_short_name}{'MAX_VALUE'};

        #
        #  EXTRACT the data from the pdu package..
        #
        my ( $start_position, $format_arxml );

        # start position
        $start_position = $pdu_pkg_href->{$pduName}{$signals_short_name}{'START-POSITION'} if exists $pdu_pkg_href->{$pduName}{$signals_short_name}{'START-POSITION'};
        $all_signalsInfo_href->{'SIGNALS'}{$signal_long_name}{'STARTBIT'} = $start_position;

        # byte order
        $format_arxml = $pdu_pkg_href->{$pduName}{$signals_short_name}{'PACKING-BYTE-ORDER'} if exists $pdu_pkg_href->{$pduName}{$signals_short_name}{'PACKING-BYTE-ORDER'};
        $all_signalsInfo_href->{'SIGNALS'}{$signal_long_name}{'FORMAT'} = Get_format($format_arxml);

    }

    S_dump_2File( 1, 'FinalSignalsInfo_extract', $all_signalsInfo_href );

    return $all_signalsInfo_href;
}

sub Process_SystemSignals_getArttributes {

    my $systemSignals_href = PKG_SystemSignals_extractSignalInfo();
    my $comuMethod_href    = PKG_CompuMethods_extractSignalInfo();

    my @signalAttibutes = qw (OFFSET FACTOR MIX_VALUE MAX_VALUE);
    foreach my $systemSignal ( keys %{$systemSignals_href} ) {
        my $comuMehtodName = $systemSignals_href->{$systemSignal}{'CompuMethods'};
        if ( defined $comuMehtodName ) {
            foreach my $attr (@signalAttibutes) {
                $systemSignals_href->{$systemSignal}{$attr} = $comuMethod_href->{$comuMehtodName}{$attr};
            }
        }

        # STEP : fill some default values
        $systemSignals_href->{$systemSignal}{'OFFSET'}    = 0 if not defined $systemSignals_href->{$systemSignal}{'OFFSET'};
        $systemSignals_href->{$systemSignal}{'FACTOR'}    = 1 if not defined $systemSignals_href->{$systemSignal}{'FACTOR'};
        $systemSignals_href->{$systemSignal}{'MIX_VALUE'} = 0 if not defined $systemSignals_href->{$systemSignal}{'MIX_VALUE'};
        $systemSignals_href->{$systemSignal}{'MAX_VALUE'} = 0 if not defined $systemSignals_href->{$systemSignal}{'MAX_VALUE'};

        # delete $systemSignals_href->{$systemSignal}{'CompuMethods'} if exists $systemSignals_href->{$systemSignal}{'CompuMethods'};
    }

    S_dump_2File( 1, 'ProcessedSystemSignals_CompuMethods', $systemSignals_href );

    return $systemSignals_href;
}

sub Extract_all_pdusInfo {

    my $all_pdusInfo_href;    # hash containing all the signal(s) info at the end

    my $pdu_pkg_href            = PKG_Pdus_get_pdu_and_signalInfo();
    my $processedFrameData_href = PKG_Frames_getPDUdata( PKG_Frames_get_pdu_and_signalInfo() );

    foreach my $pdu_name ( keys %{$pdu_pkg_href} ) {
        if ( not defined $pdu_pkg_href->{$pdu_name}{'FRAME_NAME'} ) {
            if ( my ($frameContaingPdu) = grep { $processedFrameData_href->{$_}{'SHORT-NAME'} =~ /$pdu_name/i } keys %{$processedFrameData_href} ) {
                my @fr_name = split( '::', $frameContaingPdu );
                $pdu_pkg_href->{$pdu_name}{'FRAME_NAME'} = $fr_name[0];    # only one frame is expected
            }
        }

        # for secured Pdu
        if ( my ($frameContaingPdu) = grep { $processedFrameData_href->{$_}{'PDU_REF'} =~ /$pdu_name/i } keys %{$processedFrameData_href} ) {
            $pdu_pkg_href->{$pdu_name}{'PDU_REF'}                        = $processedFrameData_href->{$frameContaingPdu}{'PDU_REF'};
            $pdu_pkg_href->{$pdu_name}{'UPDATE-INDICATION-BIT-POSITION'} = $processedFrameData_href->{$frameContaingPdu}{'UPDATE-INDICATION-BIT-POSITION'};
            $pdu_pkg_href->{$pdu_name}{'START-POSITION'}                 = $processedFrameData_href->{$frameContaingPdu}{'START-POSITION'};
        }

    }

    Fix_pdu_length_and_headerID($pdu_pkg_href);

    foreach my $eachProcessedPdu ( keys %{$pdu_pkg_href} ) {
        $all_pdusInfo_href->{'FR_PDU'}{$eachProcessedPdu}{'FRAME_NAME'}   = $pdu_pkg_href->{$eachProcessedPdu}{'FRAME_NAME'};
        $all_pdusInfo_href->{'FR_PDU'}{$eachProcessedPdu}{'DLC'}          = $pdu_pkg_href->{$eachProcessedPdu}{'LENGTH'};
        $all_pdusInfo_href->{'FR_PDU'}{$eachProcessedPdu}{'CYCLE_TIME_S'} = $pdu_pkg_href->{$eachProcessedPdu}{'CYCLE_TIME_S'};    # not known yet

        my $header_id = $pdu_pkg_href->{$eachProcessedPdu}{'HEADER-ID-SHORT-HEADER'};
        $all_pdusInfo_href->{'FR_PDU'}{$eachProcessedPdu}{'PDU_ID_SHORT_HEADER'} = dec2Hex($header_id) if defined $header_id;

        my $pdu_ref = $pdu_pkg_href->{$eachProcessedPdu}{'PDU_REF'};
        $all_pdusInfo_href->{'FR_PDU'}{$eachProcessedPdu}{'PDU_REF'} = $pdu_ref if defined $pdu_ref;

        my $update_bit_position = $pdu_pkg_href->{$eachProcessedPdu}{'UPDATE-INDICATION-BIT-POSITION'};
        $all_pdusInfo_href->{'FR_PDU'}{$eachProcessedPdu}{'UPDATE-INDICATION-BIT-POSITION'} = $update_bit_position if defined $update_bit_position;

        my $pdu_start_positition = $pdu_pkg_href->{$eachProcessedPdu}{'START-POSITION'};
        $all_pdusInfo_href->{'FR_PDU'}{$eachProcessedPdu}{'START-POSITION'} = $pdu_start_positition if defined $pdu_start_positition;

    }

    S_dump_2File( 1, 'FinalPdusInfo_extract', $all_pdusInfo_href );
    return $all_pdusInfo_href;

}

sub Fix_pdu_length_and_headerID {
    my $pdu_pkg_href = shift;

    # ============================
    #   B E F O R E
    # ============================
    # PKG_Pdus_Processed.txt
    # ======================
    #     'EIS_CHASSIS_GW_Container01_ST3_DI_OdoSpeedometer_ST3' => {
    #                    'SHORT-NAME' => 'EIS_CHASSIS_GW_Container01_ST3_DI_OdoSpeedometer_ST3',
    #                    'LENGTH' => '8',
    #                    'HEADER-ID-SHORT-HEADER' => undef,
    #                    'FRAME_NAME' => 'EIS_CHASSIS_GW_Container01_ST3',
    #                  },

    #          'EIS_CHASSIS_GW_Container01_ST3_EIS_CHASSIS_GW_Container01_ST3_DI_OdoSpeedometer_ST3_secured' => {
    #                       'HEADER-ID-SHORT-HEADER' => '0x320400',
    #                       'LENGTH' => '12',
    #                       'MAP_SEC-PDU_ISIGNAL-PDU' => 'EIS_CHASSIS_GW_Container01_ST3_EIS_CHASSIS_GW_Container01_ST3_DI_OdoSpeedometer_ST3_5yqkdrffu0x6uqyubepzpf3cb',
    #                     },

    # PKG_CommunicationClusters_Processed.txt
    # ======================================
    #          'EIS_CHASSIS_GW_Container01_ST3_EIS_CHASSIS_GW_Container01_ST3_DI_OdoSpeedometer_ST3_5yqkdrffu0x6uqyubepzpf3cb' => {
    #                             'PDU_MAPPED' => 'EIS_CHASSIS_GW_Container01_ST3_DI_OdoSpeedometer_ST3',
    #                             'PDU_TYPE' => 'I-SIGNAL-I-PDU'
    #                           },

    # ============================
    #   A F T E R
    # ============================
    #          'EIS_CHASSIS_GW_Container01_ST3_DI_OdoSpeedometer_ST3' => {
    #                                  'CYCLE' => '',
    #                                  'DLC' => '12',
    #                                  'FRAME_NAME' => 'EIS_CHASSIS_GW_Container01_ST3',
    #                                  'PDU_ID_SHORT_HEADER' => '0x320400'
    #                           },

    # Summary :
    # - Pdu length is taken now from the secured PDU
    # - and also the PDU header ID from the secured PDU
    my $processedCommClustersPduInfo_href = PKG_CommunicationClusters_get_secured_iSignalPDUmappingInfo();
    foreach my $pdu_name ( keys %{$pdu_pkg_href} ) {

        if ( exists $pdu_pkg_href->{$pdu_name}{'MAP_SEC-PDU_ISIGNAL-PDU'} ) {
            my $secured_pdu_link = $pdu_pkg_href->{$pdu_name}{'MAP_SEC-PDU_ISIGNAL-PDU'};
            my $iSignalPdu       = $processedCommClustersPduInfo_href->{$secured_pdu_link}{'PDU_MAPPED'};
            if ( defined $iSignalPdu and exists $pdu_pkg_href->{$iSignalPdu} ) {
                $pdu_pkg_href->{$iSignalPdu}{'LENGTH'}                 = $pdu_pkg_href->{$pdu_name}{'LENGTH'};
                $pdu_pkg_href->{$iSignalPdu}{'HEADER-ID-SHORT-HEADER'} = $pdu_pkg_href->{$pdu_name}{'HEADER-ID-SHORT-HEADER'};

                # Delete the secured pdu, we will not add this into the mapping file. as this is not required.
                delete $pdu_pkg_href->{$pdu_name};
            }
        }
    }

    return 1;
}

# ==================================================================================
#
#       ****   DATA   M U N G I N G  *****   or Extract usable data from ARXML  FILE
#
# ==================================================================================

# =====================================================
#           PACKAGE ISignals
# =====================================================

# package name : ISignals
# $package_href     = ISignals
# $cluster_aref     = $package_href     :: 'AR-PACKAGES;AR-PACKAGES'
# $pdu_signals_aref = $cluster_aref     :: [mappedPdu_aref => 'AR-PACKAGES;AR-PACKAGE;AR-PACKAGES;AR-PACKAGE', pduName => 'SHORT-NAME' ]
# $iSignals_ref     = $pdu_signals_aref :: 'ELEMENTS;I-SIGNAL'
# $iSIGNAL_href     = $iSignals_ref     :: [ 'SHORT-NAME', 'LENGTH', 'INIT-VALUE;NUMERICAL-VALUE-SPECIFICATION;VALUE', 'NETWORK-REPRESENTATION-PROPS;SW-DATA-DEF-PROPS-VARIANTS;SW-DATA-DEF-PROPS-CONDITIONAL;BASE-TYPE-REF;#text' ]

sub PKG_ISignals_extractSignalInfo {

    # for faster processing do not proccess again the data if already filled, just return the hash
    return $pkg_ISignals_signalsInfo_href if defined $pkg_ISignals_signalsInfo_href;

    my $iSignalsPkg_href = ARXML_getPkgTypHash('ISignals') || return;

    # STEP : get the cluster package type:
    my $cluster_ISignals_aref = GetObject_Property( $iSignalsPkg_href, 'AR-PACKAGES;AR-PACKAGE' );

    # STEP Get the cluster package type:
    foreach my $cluster ( @{$cluster_ISignals_aref} ) {

        S_wr2log( "from cluster array '$cluster_ISignals_aref' => fetch  data for '$cluster' :- ", 5 );
        if ( my $pdu_signals_aref = GetObject_Property( $cluster, 'AR-PACKAGES;AR-PACKAGE;AR-PACKAGES;AR-PACKAGE' ) ) {

            foreach my $pdu_signals ( @{$pdu_signals_aref} ) {
                S_wr2log( " fetch signals '$pdu_signals_aref' => '$pdu_signals' :- ", 5 );

                # Get the PDU name
                my $pduName = GetObject_Property( $pdu_signals, 'SHORT-NAME' );

                # For all PDU ,fetch the signal and its properties
                my $iSignals_ref = GetObject_Property( $pdu_signals, 'ELEMENTS;I-SIGNAL' );
                my $properties_aref = [ 'SHORT-NAME', 'LENGTH', 'INIT-VALUE;NUMERICAL-VALUE-SPECIFICATION;VALUE', 'NETWORK-REPRESENTATION-PROPS;SW-DATA-DEF-PROPS-VARIANTS;SW-DATA-DEF-PROPS-CONDITIONAL;BASE-TYPE-REF;#text' ];
                if ( $iSignals_ref =~ /ARRAY/ ) {
                    foreach my $signal_href (@$iSignals_ref) {
                        PKG_ISignals_getSignalInfo( $pduName, $signal_href, $properties_aref, \$pkg_ISignals_signalsInfo_href );
                    }
                }
                else {
                    PKG_ISignals_getSignalInfo( $pduName, $iSignals_ref, $properties_aref, \$pkg_ISignals_signalsInfo_href );
                }

                S_wr2log( "extraction done for '$pduName' .. \n", 5 );
            }
        }
    }

    S_wr2log("");
    S_wr2log( "pkg = ISignals - Nbr of  signals are : " . keys( %{$pkg_ISignals_signalsInfo_href} ) );
    S_dump_2File( 1, 'ISignals_Processed', $pkg_ISignals_signalsInfo_href );

    # STEP : for each the cluster get the mapped pdu and the signals
    S_wr2log( "end Process package 'ISignals'..\n\n ", 4 );

    return $pkg_ISignals_signalsInfo_href;
}

sub PKG_ISignals_getSignalInfo {
    my @args                 = @_;
    my $pduName              = shift @args;
    my $iSignals_href        = shift @args;
    my $properties_aref      = shift @args;
    my $iSignal_extract_href = shift @args;

    my $signalName;
    $signalName = $iSignals_href->{'SHORT-NAME'} if exists $iSignals_href->{'SHORT-NAME'};
    my $unique_signal_name = $pduName . "~~" . $signalName;

    $signal_count_href->{$signalName}++;    # remember the count of the signal

    S_wr2log( "Get the signal properties for '$properties_aref' :  @{$properties_aref} ' :- ", 5 );

    foreach my $property ( @{$properties_aref} ) {
        my @propertyArray = split( /;/, $property );
        my $propertyValue = GetObject_Property( $iSignals_href, $property );

        $$iSignal_extract_href->{$unique_signal_name}{ $propertyArray[0] } = $propertyValue;
        $$iSignal_extract_href->{$unique_signal_name}{'PDUNAME'} = $pduName;
    }
    return 1;

}

# =====================================================
#           PACKAGE SystemSignals
# =====================================================

# package name : SystemSignals
# $package_href         = SystemSignals
# $systemSignals_aref   = $package_href       :: 'ELEMENTS;SYSTEM-SIGNAL'
# $system_signals_href  = $systemSignals_aref :: [comuMethodName => 'PHYSICAL-PROPS;SW-DATA-DEF-PROPS-VARIANTS;SW-DATA-DEF-PROPS-CONDITIONAL;COMPU-METHOD-REF;#text', $sigName => 'SHORT-NAME' ]

sub PKG_SystemSignals_extractSignalInfo {

    # for faster processing do not proccess again the data if already filled, just return the hash
    return $pkg_SystemSignals_signalsInfo_href if defined $pkg_SystemSignals_signalsInfo_href;

    my $systemSignalsPkg_href = ARXML_getPkgTypHash('SystemSignals') || return;

    my $systemSignals_aref = GetObject_Property( $systemSignalsPkg_href, 'ELEMENTS;SYSTEM-SIGNAL' );
    foreach my $sysSignal ( @{$systemSignals_aref} ) {
        my $sigName = GetObject_Property( $sysSignal, 'SHORT-NAME' );
        if ( defined $sigName ) {
            $pkg_SystemSignals_signalsInfo_href->{$sigName}{'SHORT-NAME'}   = $sigName;
            $pkg_SystemSignals_signalsInfo_href->{$sigName}{'CompuMethods'} = GetCompuMethods($sysSignal);
        }
    }

    S_wr2log("\n\n");
    S_wr2log( "pkg = SystemSignals - Nbr of  signals are : " . keys( %{$pkg_SystemSignals_signalsInfo_href} ) );
    S_dump_2File( 1, 'SystemSignals_Processed', $pkg_SystemSignals_signalsInfo_href );

    # STEP : for each the cluster get the mapped pdu and the signals
    S_wr2log( "end Process package 'SystemSignals'..\n\n ", 4 );

    return $pkg_SystemSignals_signalsInfo_href;

}

sub GetCompuMethods {
    my @args           = @_;
    my $systemSig_href = shift @args;

    my $compuMethod;
    unless ( defined $systemSig_href ) {
        S_wr2log( "SystemSignal reference is not defiend to get the CompuMethod for factor & offset calculation", 1 );
        return;
    }

    $compuMethod = GetObject_Property( $systemSig_href, 'PHYSICAL-PROPS;SW-DATA-DEF-PROPS-VARIANTS;SW-DATA-DEF-PROPS-CONDITIONAL;COMPU-METHOD-REF;#text' );
    return unless defined $compuMethod;

    # example $CompuMethod =  '/CompuMethods/c02_ABS_Actv_Stat_EDR'
    my @methodName = split( /\//, $compuMethod );
    return $methodName[2];
}

# =====================================================
#           PACKAGE CompuMethods
# =====================================================

# package name : CompuMethods
# $pkgCompuMethod_href      = CompuMethods
# $compuMethods_aref'       = $pkgCompuMethod_href :: 'ELEMENTS;COMPU-METHOD',
# $compuScales_ref          = $compuMethods_aref   :: [ $compuMethodName => 'SHORT-NAME', $compuScales_ref => 'COMPU-INTERNAL-TO-PHYS;COMPU-SCALES;COMPU-SCALE' ],
#'$compuMethodInfo_href'    = $compuScales_ref     :: [$max_value => 'UPPER-LIMIT;#text',  $min_value => 'LOWER-LIMIT;#text', $factor_offset => 'COMPU-RATIONAL-COEFFS;COMPU-NUMERATOR;V' ],

sub PKG_CompuMethods_extractSignalInfo {

    # for faster processing do not proccess again the data if already filled, just return the hash
    return $pkg_CompuMethods_signalsInfo_href if defined $pkg_CompuMethods_signalsInfo_href;

    my $CompuMethodsPkg_href = ARXML_getPkgTypHash('CompuMethods') || return;
    my $compuMethods_aref = GetObject_Property( $CompuMethodsPkg_href, 'ELEMENTS;COMPU-METHOD' );

    foreach my $compuMethod ( @{$compuMethods_aref} ) {

        my $compuMethodName = GetObject_Property( $compuMethod, 'SHORT-NAME' );    # method name

        if ( my $compuScales_ref = GetObject_Property( $compuMethod, 'COMPU-INTERNAL-TO-PHYS;COMPU-SCALES;COMPU-SCALE' ) ) {
            if ( $compuScales_ref =~ /ARRAY/ ) {
                foreach my $compuScale_href ( @{$compuScales_ref} ) {
                    FetchCompuAttributes( $compuMethodName, $compuScale_href, \$pkg_CompuMethods_signalsInfo_href );
                }
            }
            else {
                FetchCompuAttributes( $compuMethodName, $compuScales_ref, \$pkg_CompuMethods_signalsInfo_href );
            }
        }
    }

    S_wr2log("\n\n");
    S_wr2log( "pkg = CompuMethods - Nbr of  packages are : " . keys( %{$pkg_CompuMethods_signalsInfo_href} ) );
    S_dump_2File( 1, 'CompuMethods_Processed', $pkg_CompuMethods_signalsInfo_href );

    # STEP : for each the cluster get the mapped pdu and the signals
    S_wr2log( "end Process package 'CompuMethods'..\n\n ", 4 );

    return $pkg_CompuMethods_signalsInfo_href;
}

sub FetchCompuAttributes {
    my @args                 = @_;
    my $compuMethodName      = shift @args;
    my $compuScale_href      = shift @args;
    my $compuMethodInfo_href = shift @args;    # output parameter

    # my $property_aref = ['COMPU_METHOD_ATTR_HREF' => ['UPPER-LIMIT;#text', 'LOWER-LIMIT;#text', 'COMPU-RATIONAL-COEFFS;COMPU-NUMERATOR;V']];
    if ( defined GetObject_Property( $compuScale_href, 'COMPU-RATIONAL-COEFFS;COMPU-NUMERATOR;V' ) ) {

        # STEP get the Min, max value
        my $min = GetObject_Property( $compuScale_href, 'LOWER-LIMIT;#text' ) // 0;
        my $max = GetObject_Property( $compuScale_href, 'UPPER-LIMIT;#text' ) // 0;
        $$compuMethodInfo_href->{$compuMethodName}{'MIX_VALUE'} = $min;
        $$compuMethodInfo_href->{$compuMethodName}{'MAX_VALUE'} = $max;

        # STEP get the factor and offset
        my $factor_offset = GetObject_Property( $compuScale_href, 'COMPU-RATIONAL-COEFFS;COMPU-NUMERATOR;V' );
        my $factor_offset_denominator = GetObject_Property( $compuScale_href, 'COMPU-RATIONAL-COEFFS;COMPU-DENOMINATOR;V' ) // 1;
        my $factor = $factor_offset->[1] / $factor_offset_denominator;
        my $offset = $factor_offset->[0] / $factor_offset_denominator;
        $$compuMethodInfo_href->{$compuMethodName}{'FACTOR'} = $factor // 1;
        $$compuMethodInfo_href->{$compuMethodName}{'OFFSET'} = $offset // 0;
        S_wr2log( " $compuMethodName = [min,max, factor, offset =  $min, $max, $factor, $offset ] " . "\n", 5 );
    }

    return 1;
}

=head2 PKG_Pdus_get_pdu_and_signalInfo

    $extractPduInfo_href = PKG_Pdus_get_pdu_and_signalInfo ( );

Read the PDU package and fetches the signal infomation

B<STEPS:>

    package name : Pdus
    $pduPkg_href                = Pdus
    $pdusCluster_aref           = $pduPkg_href         :: 'AR-PACKAGES;AR-PACKAGE',
    $iSignal_to_PDUMapping_href = $pdusCluster_aref    :: 'AR-PACKAGES;AR-PACKAGE;ELEMENTS;I-SIGNAL-I-PDU'
    $frames_aref                = $pdusCluster_aref    :: 'AR-PACKAGES;AR-PACKAGE;AR-PACKAGES;AR-PACKAGE'
    $iSignal_to_PDUMapping_href = $frames_aref         :: 'ELEMENTS;I-SIGNAL-I-PDU',
    $extractPduInfo_href        = $iSignal_to_PDUMapping_href :: [START-POSITION, PACKING-BYTE-ORDER, HEADER-ID-SHORT-HEADER, LENGTH],

=cut

sub PKG_Pdus_get_pdu_and_signalInfo {

    # for faster processing do not proccess again the data if already filled, just return the hash
    return $pkg_Pdus_pduAndSignalsInfo_href if defined $pkg_Pdus_pduAndSignalsInfo_href;

    my $PdusPkg_href = ARXML_getPkgTypHash('Pdus') || return;
    my $pdusCluster_aref = GetObject_Property( $PdusPkg_href, 'AR-PACKAGES;AR-PACKAGE' );
    foreach my $cluster ( @{$pdusCluster_aref} ) {
        if ( exists $cluster->{'AR-PACKAGES'}{'AR-PACKAGE'}{'ELEMENTS'}{'I-SIGNAL-I-PDU'} ) {
            PKG_Pdus_getPduSignals4m_ISIGNALIPDU( GetObject_Property( $cluster, 'AR-PACKAGES;AR-PACKAGE;ELEMENTS;I-SIGNAL-I-PDU' ), undef, \$pkg_Pdus_pduAndSignalsInfo_href );
        }

        if ( exists $cluster->{'AR-PACKAGES'}{'AR-PACKAGE'}{'ELEMENTS'}{'SECURED-I-PDU'} ) {
            PKG_Pdus_getInfo_SECURED_I_PDU( GetObject_Property( $cluster, 'AR-PACKAGES;AR-PACKAGE;ELEMENTS;SECURED-I-PDU' ), undef, \$pkg_Pdus_pduAndSignalsInfo_href );
        }

        if ( exists $cluster->{'AR-PACKAGES'}{'AR-PACKAGE'}{'AR-PACKAGES'}{'AR-PACKAGE'} ) {
            my $frames_aref = GetObject_Property( $cluster, 'AR-PACKAGES;AR-PACKAGE;AR-PACKAGES;AR-PACKAGE' );
            foreach my $frame ( @{$frames_aref} ) {
                my $frame_name = $frame->{'SHORT-NAME'};
                PKG_Pdus_getPduSignals4m_ISIGNALIPDU( GetObject_Property( $frame, 'ELEMENTS;I-SIGNAL-I-PDU' ), $frame_name, \$pkg_Pdus_pduAndSignalsInfo_href );
            }
        }
    }

    S_wr2log("\n\n");
    S_wr2log( "pkg = Pdus - Nbr of  packages are : " . keys( %{$pkg_Pdus_pduAndSignalsInfo_href} ) );
    S_dump_2File( 1, 'Pdus_Processed', $pkg_Pdus_pduAndSignalsInfo_href );

    # STEP : for each the cluster get the mapped pdu and the signals
    S_wr2log( "end Process package 'Pdus'..\n\n ", 4 );

    return $pkg_Pdus_pduAndSignalsInfo_href;

}

sub PKG_Pdus_getInfo_SECURED_I_PDU {

    my @args                = @_;
    my $secured_pdu_ref     = shift @args;
    my $frame_name          = shift @args;    # dummy
    my $extractPduInfo_href = shift @args;

    if ( $secured_pdu_ref =~ /ARRAY/ ) {
        foreach my $secured_i_pdu ( @{$secured_pdu_ref} ) {

            my $sec_pdu_name            = $secured_i_pdu->{'SHORT-NAME'};
            my $sec_pdu_len             = $secured_i_pdu->{'LENGTH'};
            my $sec_pdu_header_id       = GetObject_Property( $secured_i_pdu, 'CONTAINED-I-PDU-PROPS;HEADER-ID-SHORT-HEADER' );
            my $sec_pdu_payloadRef_text = GetObject_Property( $secured_i_pdu, 'PAYLOAD-REF;#text' );
            my $found_payloadRef        = getElementAfterSplit( $sec_pdu_payloadRef_text, '/' );                                  # /CommunicationClusters/CHASSIS/CHASSIS/CHASSIS_CHANNEL_A/EIS_CHASSIS_COM_Container01_ST3_EIS_CHASSIS_COM_Container01_ST3_Ign_Stat_ST3_24sp4xyvmeq8obkk9nlt9jsug

            $$extractPduInfo_href->{$sec_pdu_name}{'PDU_NAME'}                = $sec_pdu_name;
            $$extractPduInfo_href->{$sec_pdu_name}{'LENGTH'}                  = $sec_pdu_len;
            $$extractPduInfo_href->{$sec_pdu_name}{'HEADER-ID-SHORT-HEADER'}  = $sec_pdu_header_id if defined $sec_pdu_header_id;
            $$extractPduInfo_href->{$sec_pdu_name}{'MAP_SEC-PDU_ISIGNAL-PDU'} = $found_payloadRef if defined $found_payloadRef;

            S_wr2log( "[PDU-Name:'$sec_pdu_name', HEADER-ID-SHORT-HEADER:'$sec_pdu_header_id', MAP_SEC-PDU_ISIGNAL-PDU:$found_payloadRef, FRAME_NAME:'$sec_pdu_name'] ", 5 );
        }
    }
    else {
        my $sec_pdu_name            = $secured_pdu_ref->{'SHORT-NAME'};
        my $sec_pdu_len             = $secured_pdu_ref->{'LENGTH'};
        my $sec_pdu_header_id       = GetObject_Property( $secured_pdu_ref, 'CONTAINED-I-PDU-PROPS;HEADER-ID-SHORT-HEADER' );
        my $sec_pdu_payloadRef_text = GetObject_Property( $secured_pdu_ref, 'PAYLOAD-REF;#text' );
        my $found_payloadRef        = getElementAfterSplit( $sec_pdu_payloadRef_text, '/' );                                    # /CommunicationClusters/CHASSIS/CHASSIS/CHASSIS_CHANNEL_A/EIS_CHASSIS_COM_Container01_ST3_EIS_CHASSIS_COM_Container01_ST3_Ign_Stat_ST3_24sp4xyvmeq8obkk9nlt9jsug

        $$extractPduInfo_href->{$sec_pdu_name}{'FRAME_NAME'}              = $sec_pdu_name;
        $$extractPduInfo_href->{$sec_pdu_name}{'LENGTH'}                  = $sec_pdu_len;
        $$extractPduInfo_href->{$sec_pdu_name}{'HEADER-ID-SHORT-HEADER'}  = $sec_pdu_header_id if defined $sec_pdu_header_id;
        $$extractPduInfo_href->{$sec_pdu_name}{'MAP_SEC-PDU_ISIGNAL-PDU'} = $found_payloadRef if defined $found_payloadRef;

        S_wr2log( "[PDU-Name:'$sec_pdu_name', HEADER-ID-SHORT-HEADER:'$sec_pdu_header_id', MAP_SEC-PDU_ISIGNAL-PDU:$found_payloadRef, FRAME_NAME:'$sec_pdu_name'] ", 5 );
    }

    return 1;
}

sub PKG_Pdus_getPduSignals4m_ISIGNALIPDU {

    my @args                      = @_;
    my $iSignal_to_PDUMapping_ref = shift @args;
    my $frame_name                = shift @args;
    my $extractPduInfo_href       = shift @args;

    # CALL PKG_Pdus_getOneMappedPduSignals
    if ( $iSignal_to_PDUMapping_ref =~ /ARRAY/ ) {
        foreach my $iSignalPDUMapping ( @{$iSignal_to_PDUMapping_ref} ) {
            PKG_Pdus_getOneMappedPduSignals( $iSignalPDUMapping, $frame_name, $extractPduInfo_href );
        }
    }
    elsif ( $iSignal_to_PDUMapping_ref =~ /HASH/ ) {
        PKG_Pdus_getOneMappedPduSignals( $iSignal_to_PDUMapping_ref, $frame_name, $extractPduInfo_href );
    }

    return 1;
}

sub PKG_Pdus_getOneMappedPduSignals {
    my @args                       = @_;
    my $iSignal_to_PDUMapping_href = shift @args;
    my $frameName                  = shift @args;
    my $extractPduInfo_href        = shift @args;

    my $iSignalMapped2IPDU_aref = GetObject_Property( $iSignal_to_PDUMapping_href, 'I-SIGNAL-TO-PDU-MAPPINGS;I-SIGNAL-TO-I-PDU-MAPPING' );
    my $cycleTime_s             = GetObject_Property( $iSignal_to_PDUMapping_href, 'I-PDU-TIMING-SPECIFICATIONS;I-PDU-TIMING;TRANSMISSION-MODE-DECLARATION;TRANSMISSION-MODE-TRUE-TIMING;CYCLIC-TIMING;TIME-PERIOD;VALUE' );

    my $signals_aref;

    # STEP Fetch the pdu name
    # STEP Fetch mapped signal(s) to the PDU
    # STEP for each signal get START-POSITION, PACKING-BYTE-ORDER, LENGTH, PDU-ID 'HEADER-ID-SHORT-HEADER', 'FRAME_NAME'
    my $pduName = $iSignal_to_PDUMapping_href->{'SHORT-NAME'};
    if ( $iSignalMapped2IPDU_aref =~ /ARRAY/ ) {
        foreach my $mappedSignal ( @{$iSignalMapped2IPDU_aref} ) {
            my ( $signal_name, $start_position, $byte_order );
            $signal_name    = $mappedSignal->{'SHORT-NAME'} if ( exists $mappedSignal->{'SHORT-NAME'} );
            $start_position = $mappedSignal->{'START-POSITION'};
            $byte_order     = $mappedSignal->{'PACKING-BYTE-ORDER'};

            $$extractPduInfo_href->{$pduName}{$signal_name}{'START-POSITION'}     = $start_position;
            $$extractPduInfo_href->{$pduName}{$signal_name}{'PACKING-BYTE-ORDER'} = $byte_order;
            push( @$signals_aref, $signal_name );
            S_wr2log( "$mappedSignal -> '$signal_name' -> [START-POSITION, PACKING-BYTE-ORDER] : [$start_position, $byte_order] ", 5 );
        }
    }
    else {
        my ( $signal_name, $start_position, $byte_order );
        $signal_name    = $iSignalMapped2IPDU_aref->{'SHORT-NAME'} if ( exists $iSignalMapped2IPDU_aref->{'SHORT-NAME'} );
        $start_position = $iSignalMapped2IPDU_aref->{'START-POSITION'};
        $byte_order     = $iSignalMapped2IPDU_aref->{'PACKING-BYTE-ORDER'};

        $$extractPduInfo_href->{$pduName}{$signal_name}{'START-POSITION'}     = $start_position;
        $$extractPduInfo_href->{$pduName}{$signal_name}{'PACKING-BYTE-ORDER'} = $byte_order;
        S_wr2log( "$iSignalMapped2IPDU_aref -> '$signal_name' -> [START-POSITION, PACKING-BYTE-ORDER] : [$start_position, $byte_order] ", 5 );
        push( @$signals_aref, $signal_name );

    }

    if ( defined $pduName ) {
        $$extractPduInfo_href->{$pduName}{'SIGNALS'}    = $signals_aref;
        $$extractPduInfo_href->{$pduName}{'SHORT-NAME'} = $pduName;
        $$extractPduInfo_href->{$pduName}{'LENGTH'}     = $iSignal_to_PDUMapping_href->{'LENGTH'} if exists $iSignal_to_PDUMapping_href->{'LENGTH'};

        my $pduHeader_ID = $iSignal_to_PDUMapping_href->{'CONTAINED-I-PDU-PROPS'}{'HEADER-ID-SHORT-HEADER'};
        $$extractPduInfo_href->{$pduName}{'HEADER-ID-SHORT-HEADER'} = $pduHeader_ID;
        $$extractPduInfo_href->{$pduName}{'START-POSITION'}         = $iSignal_to_PDUMapping_href->{'START-POSITION'} if exists $iSignal_to_PDUMapping_href->{'START-POSITION'};
        $$extractPduInfo_href->{$pduName}{'FRAME_NAME'}             = $frameName;
        $$extractPduInfo_href->{$pduName}{'CYCLE_TIME_S'}           = $cycleTime_s if defined $cycleTime_s;

        S_wr2log( "$iSignalMapped2IPDU_aref -> [PDU-Name:'$pduName', CYCLE_TIME = '$cycleTime_s', HEADER-ID-SHORT-HEADER:'$pduHeader_ID', FRAME_NAME:'$frameName', SIGNALS:'@$signals_aref'] ", 5 );
    }

    return 1;
}

# =====================================================
#           PACKAGE CommunicationClusters
# =====================================================
sub PKG_CommunicationClusters_get_secured_iSignalPDUmappingInfo {

    # for faster processing do not proccess again the data if already filled, just return the hash
    return $pkg_ComClusters_secAndiSignal_pduMapping_href if defined $pkg_ComClusters_secAndiSignal_pduMapping_href;

    my $comClustersPkg_href = ARXML_getPkgTypHash('CommunicationClusters') || return;

    my $comClusters_aref = GetObject_Property( $comClustersPkg_href, 'AR-PACKAGES;AR-PACKAGE' );
    foreach my $cluster_href ( @{$comClusters_aref} ) {
        my $pduTriggerings_aref = GetObject_Property( $cluster_href, 'ELEMENTS;FLEXRAY-CLUSTER;FLEXRAY-CLUSTER-VARIANTS;FLEXRAY-CLUSTER-CONDITIONAL;PHYSICAL-CHANNELS;FLEXRAY-PHYSICAL-CHANNEL;PDU-TRIGGERINGS;PDU-TRIGGERING' );

        if ( $pduTriggerings_aref =~ /ARRAY/ ) {
            foreach my $pduTriggering_href ( @{$pduTriggerings_aref} ) {

                my $pduRef_dest = GetObject_Property( $pduTriggering_href, 'I-PDU-REF;-DEST' );
                if ( $pduRef_dest ~~ [ 'I-SIGNAL-I-PDU', 'SECURED-I-PDU' ] ) {

                    # Get the secured pdu name
                    my $pduRef_text = GetObject_Property( $pduTriggering_href, 'I-PDU-REF;#text' );
                    my $found_pdu = getElementAfterSplit( $pduRef_text, '/' );    # /Pdus/CHASSIS/PKG_CHASSIS_CHANNEL_A/BCS_Brk_Stat_ST3_secured

                    # get the linking between secured pdu to iSignal pdu
                    my $sec_iSignal_pdu_link = GetObject_Property( $pduTriggering_href, 'SHORT-NAME' );
                    my $found_link = getElementAfterSplit( $sec_iSignal_pdu_link, '/' );    # EIS_CHASSIS_COM_Container01_ST3_EIS_CHASSIS_COM_Container01_ST3_Immobilizer_KeyID_ST3_dnshfznc9sejz6hs1uidta2cc

                    # fill the elements
                    $pkg_ComClusters_secAndiSignal_pduMapping_href->{$found_link}{'PDU_MAPPED'} = $found_pdu;
                    $pkg_ComClusters_secAndiSignal_pduMapping_href->{$found_link}{'PDU_TYPE'}   = $pduRef_dest;
                }
            }
        }
    }

    S_wr2log("\n\n");
    S_wr2log( "pkg = CommunicationClusters - Nbr of  data are : " . keys( %{$pkg_ComClusters_secAndiSignal_pduMapping_href} ) );
    S_dump_2File( 1, 'CommunicationClusters_Processed', $pkg_ComClusters_secAndiSignal_pduMapping_href );
    S_wr2log( "end Process package 'CommunicationClusters'..\n\n ", 4 );

    return $pkg_ComClusters_secAndiSignal_pduMapping_href;
}

# =====================================================
#           PACKAGE Frames
# =====================================================

# package name : Frames
# $framePkg_href         = Frames
# $famesCluster_aref     = $framePkg_href       :: 'AR-PACKAGES;AR-PACKAGE',
# $fames_ref             = $famesCluster_aref   :: 'AR-PACKAGES;AR-PACKAGE;ELEMENTS;FLEXRAY-FRAME'
# $framesData_arxml_href = $fames_ref :: ['SHORT-NAME', 'PDU-TO-FRAME-MAPPINGS;PDU-TO-FRAME-MAPPING;PDU-REF', 'FRAME-LENGTH' ]

sub PKG_Frames_get_pdu_and_signalInfo {

    # for faster processing do not proccess again the data if already filled, just return the hash
    return $pkg_Frames_pduAndFrameInfo_href if defined $pkg_Frames_pduAndFrameInfo_href;
    my $FramesPkg_href = ARXML_getPkgTypHash('Frames') || return;

    my $famesCluster_aref = GetObject_Property( $FramesPkg_href, 'AR-PACKAGES;AR-PACKAGE' );
    foreach my $cluster_href ( @{$famesCluster_aref} ) {
        my $frames_ref = GetObject_Property( $cluster_href, 'AR-PACKAGES;AR-PACKAGE;ELEMENTS;FLEXRAY-FRAME' );
        next if not defined $frames_ref;

        if ( $frames_ref =~ /ARRAY/ ) {
            foreach my $framedata ( @{$frames_ref} ) {
                PKG_Frames_fetchFrameAttr( $framedata, \$pkg_Frames_pduAndFrameInfo_href );
            }
        }
        else {
            PKG_Frames_fetchFrameAttr( $frames_ref, \$pkg_Frames_pduAndFrameInfo_href );
        }
    }

    S_wr2log("\n\n");
    S_wr2log( "pkg = Frames - Nbr of  frames data are : " . keys( %{$pkg_Frames_pduAndFrameInfo_href} ) );
    S_dump_2File( 1, 'Frames_Processed', $pkg_Frames_pduAndFrameInfo_href );
    S_wr2log( "end Process package 'Frames'..\n\n ", 4 );

    return $pkg_Frames_pduAndFrameInfo_href;
}

sub PKG_Frames_fetchFrameAttr {
    my $frame_href           = shift;
    my $frame_arxml_href_out = shift;

    unless ( defined $frame_href ) {
        S_wr2log( "Error while fetching the FrameHref for frame attributes \n", 2 );
        return;
    }

    my $framesProperties_href = {
        "FRAME_SHORT-NAME"      => 'SHORT-NAME',
        "PDU-TO-FRAME-MAPPINGS" => 'PDU-TO-FRAME-MAPPINGS;PDU-TO-FRAME-MAPPING',
        "FRAME-LENGTH"          => 'FRAME-LENGTH',
    };

    my $frameName = GetObject_Property( $frame_href, 'SHORT-NAME' );
    PKG_Frames_getPkgProperites( $frameName, $frame_href, $framesProperties_href, $frame_arxml_href_out );
    return 1;
}

sub PKG_Frames_getPkgProperites {
    my $frameName       = shift;
    my $pkg_href        = shift;
    my $properties_href = shift;
    my $pkg_href_out    = shift;

    if ( not $properties_href =~ 'HASH' ) {
        S_wr2log( " ERROR : '\$properties_href' is not hash reference ..", 2 );
        return;
    }

    foreach my $property_key ( keys %{$properties_href} ) {
        my $propertyValue = GetObject_Property( $pkg_href, $properties_href->{$property_key} );
        $$pkg_href_out->{$frameName}{$property_key} = $propertyValue;
    }

    return 1;
}

##============================================================
#
# Get the required frame types that contain pdu type:
# I-SIGNAL-I-PDU and SECURED-I-PDU
#
## ============================================================

sub PKG_Frames_getPDUdata {
    my @args                  = @_;
    my $framesData_arxml_href = shift @args;

    my $frType_iSignalIpdu_href;
    my @validframesTypes = ('I-SIGNAL-I-PDU');
    foreach my $frameData_arxml ( keys %{$framesData_arxml_href} ) {

        my $frame_to_pdu_mapping_ref = GetObject_Property( $framesData_arxml_href->{$frameData_arxml}, 'PDU-TO-FRAME-MAPPINGS' );
        my $frame_name               = GetObject_Property( $framesData_arxml_href->{$frameData_arxml}, 'FRAME_SHORT-NAME' );

        if ( $frame_to_pdu_mapping_ref =~ /ARRAY/ ) {
            foreach my $eachframe_to_pdu_mapping_ref (@$frame_to_pdu_mapping_ref) {
                PKG_Frames_filterdesiredPDUtype( $frame_name, $eachframe_to_pdu_mapping_ref, \$frType_iSignalIpdu_href );
            }
        }
        else {
            PKG_Frames_filterdesiredPDUtype( $frame_name, $frame_to_pdu_mapping_ref, \$frType_iSignalIpdu_href );
        }

    }
    S_dump_2File( 1, 'FramesAndPDU_Processed', $frType_iSignalIpdu_href );
    return $frType_iSignalIpdu_href;
}

sub PKG_Frames_filterdesiredPDUtype {
    my @args                        = @_;
    my $frame_name                  = shift @args;
    my $frame_to_pdu_mapping_href   = shift @args;
    my $frType_iSignalIpdu_href_out = shift @args;

    my $frame_type = GetObject_Property( $frame_to_pdu_mapping_href, 'PDU-REF;-DEST' );
    my @validframesTypes = ( 'I-SIGNAL-I-PDU', 'SECURED-I-PDU' );

    if ( $frame_type ~~ @validframesTypes ) {
        my $pdu_short_name = GetObject_Property( $frame_to_pdu_mapping_href, 'SHORT-NAME' );
        my $pdu_ref        = GetObject_Property( $frame_to_pdu_mapping_href, 'PDU-REF;#text' );
        my @pdu_reference = split( /\//, $pdu_ref );    # this is the case to find if a secured pdu reference to another pdu eg # example :   '#text' => '/Pdus/CHASSIS/PKG_CHASSIS_CHANNEL_A/IS1_Stat_ST3_secured',
        $$frType_iSignalIpdu_href_out->{ $frame_name . "::" . $pdu_short_name } = $frame_to_pdu_mapping_href;
        $$frType_iSignalIpdu_href_out->{ $frame_name . "::" . $pdu_short_name }{'PDU_REF'} = $pdu_reference[-1];
    }

}

# =====================================================
#           ARXML Gnereic pakage type FUNCTIONS
# =====================================================

sub ARXML_rdArxmlToHash {
    my @args           = @_;
    my $arxml_filePath = shift @args;

    S_wr2log("start reading file '$arxml_filePath' ");
    if ( not -e $arxml_filePath ) {
        S_wr2log( "ERROR : file '$arxml_filePath' doesn't not exists.", 2 );
        return;
    }

    # STEP read Flexray database file into hash_ref
    my $xml_contents = read_file($arxml_filePath);
    my $arxml_href   = xml2hash $xml_contents;

    unless ( defined $arxml_href ) {
        S_wr2log( "ERROR -  in getting the file contents to hash for file - '$arxml_filePath' ", 2 );
        return;
    }

    S_wr2log("End .. reading file to '$arxml_filePath' to hash \n");

    # STEP return Hash reference '$arxml_href' contents
    return $arxml_href;
}

sub ARXML_getARXML_Hash {

    # STEP get the contents of arxml file to hash if not read before
    if ( defined $arxmlContents_href ) {
        S_wr2log("Skipped reading again the arxml file content to hash. Arxml content hash is :- $arxmlContents_href");
        return $arxmlContents_href;
    }
    else {
        $arxmlContents_href = ARXML_rdArxmlToHash($arxml_filePath);
        return $arxmlContents_href;
    }
}

sub ARXML_getPkgTypHash_4mArxmlhash {
    my @args           = @_;
    my $arxml_href     = shift @args;
    my $pkgType        = shift @args;
    my $flagDumpPkgTyp = shift @args;

    # STEP Get referneces of all Package Type mentioned in arxml
    my $pkg_aref = $arxml_href->{'AUTOSAR'}{'AR-PACKAGES'}{'AR-PACKAGE'};

    # STEP Get ref of specified $packageType as user wants ex .. hash ref of type 'PDUs'
    my @pkgType_href = grep { $_->{'SHORT-NAME'} =~ /^$pkgType/i } @{$pkg_aref};

    # STEP optional : dump the package data into file
    S_dump_2File( 1, $pkgType, \@pkgType_href ) if $flagDumpPkgTyp;
    S_wr2log( "Hash from Parent : '$arxml_href' -> package :'$pkgType' =  '$pkgType_href[0]' *** ", 5 );

    return $pkgType_href[0];
}

sub ARXML_getPkgTypHash {
    my @args    = @_;
    my $pkgType = shift @args;

    S_wr2log( "Process package '$pkgType' and get the data :- ", 4 );
    my $arxml_href = ARXML_getARXML_Hash() || return;

    my $pkgType_href = ARXML_getPkgTypHash_4mArxmlhash( $arxml_href, $pkgType, 0 );
    if ( not defined $pkgType_href ) {
        S_wr2log( "ERROR : Fetching the reference for package '$pkgType'", 2 );
        return;
    }

    return $pkgType_href;
}

sub ARXML_getAll_ARPACKAGE_types {

    my $arxml_href = ARXML_getARXML_Hash() || return;

    S_wr2log( "start dump all packges to the file", 4 );

    # STEP Get the all pakage name
    my $pkg_aref = $arxml_href->{'AUTOSAR'}{'AR-PACKAGES'}{'AR-PACKAGE'};

    # LOOP all package and dump of file
    foreach my $pkg_name ( @{$pkg_aref} ) {
        ARXML_getPkgTypHash_4mArxmlhash( $arxml_href, $pkg_name->{'SHORT-NAME'}, 1 );
    }

    S_wr2log( "end dumping all packges to the file \n", 4 );
    return 1;
}

sub ARXML_getAutosarSchemaVersion {

    S_wr2log("getting the AutosarSchemaVersion ..");
    my $arxml_href = ARXML_getARXML_Hash() || return;
    my $autosar_schema_string = GetObject_Property( $arxml_href, 'AUTOSAR;-xsi:schemaLocation' );    # 'http://autosar.org/schema/r4.0 AUTOSAR_4-3-0.xsd';

    my $autosar_schema_Nbr;
    if ( $autosar_schema_string =~ /(AUTOSAR.+).xsd/ ) {
        $autosar_schema_Nbr = $1;
    }

    S_wr2log("end = $autosar_schema_Nbr\n");
    return $autosar_schema_Nbr;
}

#----------------------------
# Helper functions
#----------------------------

sub S_wr2log {
    my @args = @_;

    my $text         = shift @args;
    my $loggingLevel = shift @args;

    $text = $text . "\n";
    my $date_time = S_get_date_extension();

    my $callingFunction = ( caller(1) )[3];
    if ( $callingFunction =~ /^(\w+)::(\w+)$/ ) {
        $callingFunction = $2;
    }

    $loggingLevel = 4 if not defined $loggingLevel;
    return if ( $loggingLevel == 5 and $FLAG_EN_DEBUG_PRINT_OUTS == 0 );    # no logging to file.

    my $loggingLevels_href = {
        1 => 'CRITICAL',
        2 => 'ERROR',
        3 => 'WARNING',
        4 => 'INFO',
        5 => 'DEBUG',
    };

    write_file( $log_File, { append => 1 }, "[$date_time] [$loggingLevels_href->{$loggingLevel}]:" . "$callingFunction: $text" );
    print $text;
    return 1;
}

sub S_dump_2File {
    my @args = @_;

    my $flag_dumpFile = shift @args // 0;
    my $packageName   = shift @args // 'NO_package';
    my $data_2_dump   = shift @args;
    my $fileName      = shift @args;

    my $dirPath = "C:\\Temp\\mapping_data_dumper\\";
    if ( !-d $dirPath ) {
        make_path $dirPath or print "Failed to create path: $dirPath \n";
    }

    $fileName = "PKG_" . $packageName . '.txt' if not defined $fileName;

    my $filename_withPath = $dirPath . $fileName;

    if ($filename_withPath) {
        write_file $filename_withPath, Dumper($data_2_dump);
        S_wr2log( "Data Dumped for '$packageName' : generated file is '$filename_withPath'. ", 4 );
    }
    return 1;
}

sub S_get_date_extension {
    my $given_time = shift;

    my ( $sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst );

    if ( defined $given_time ) {
        ( $sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst ) = localtime($given_time);
    }
    else {
        ( $sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst ) = localtime( time() );
    }

    return sprintf( "%04d%02d%02d_%02d%02d%02d", $year + 1900, $mon + 1, $mday, $hour, $min, $sec );
}

sub GetObject_Property {
    my $parentObject_href = shift;
    my $objectHirarchy    = shift;

    # STEP get the parent object and split object tree as objectArray
    # CALL GetObject( $parentObject_href, \@objArray ) : $property_value
    my @objArray = split( /;/, $objectHirarchy );    # example :   $str = 'PACKAGES_A1;PACKAGE_A1;PACKAGES_A2;PACKAGE_A2' ;
    my $property_value = GetObject( $parentObject_href, \@objArray );

    # STEP return the property value
    return $property_value;

}

sub GetObject {
    my @args = @_;

    my $parentObj            = shift @args;
    my $objectHierarchy_aref = shift @args;

    # STEP error if parent object is not defiend
    S_wr2log( "ERROR: parent obj not defined ", 2 ) if ( not defined $parentObj );

    my $returnObject;
    my $nbrObjHierarchy = scalar @$objectHierarchy_aref;
    if ( $nbrObjHierarchy < 1 ) {
        S_wr2log( "Invalid params ! atleast one COM object is expected", 2 );
        return;
    }

    # STEP trace until required object is fetched from objectHierarchy_aref
    my $firstObject = 1;
    foreach my $searchObjects (@$objectHierarchy_aref) {
        if ( $firstObject == 1 ) {
            $returnObject = $parentObj->{$searchObjects} if ( $parentObj =~ /HASH/ );
            $firstObject = 0;
        }
        else {
            $returnObject = $returnObject->{$searchObjects} if ( defined $returnObject and $returnObject =~ /HASH/ );
        }
    }

    S_wr2log( "Return value for '$parentObj' -> '@$objectHierarchy_aref' = $returnObject. ", 5 ) if defined $returnObject;

    # STEP return the required object
    return $returnObject;
}

sub Get_type {
    my $type_arxml = shift;
    my $type;
    if ( defined $type_arxml ) {
        my @baseTypes = split( /\//, $type_arxml );
        if ( $baseTypes[$#baseTypes] =~ /uint/i or $baseTypes[$#baseTypes] =~ /boolean/i ) {
            $type = 'UNSIGNED';
        }
    }

    return $type;
}

sub Get_format {
    my $format_arxml = shift;

    my $byte_order;

    if ( defined $format_arxml ) {
        if ( $format_arxml =~ /^MOST-SIGNIFICANT-BYTE-LAST$/i ) {
            $byte_order = 'Intel';
        }
        else {
            $byte_order = 'Motorola';
        }
    }
    return $byte_order;
}

sub dec2Hex {
    my $hexordec = shift;
    return unless ($hexordec);
    return $hexordec if ( $hexordec =~ /^0x/i );
    my $hexval = sprintf( "0x%0X", $hexordec );
    return $hexval;
}

sub getElementAfterSplit {
    my $inputStr            = shift;
    my $delimiter_for_split = shift;
    my $pos                 = shift;

    $pos = 'end' if not defined;

    my @after_split_elements = split( /$delimiter_for_split/, $inputStr );
    if ( $pos eq 'end' ) {
        return $after_split_elements[-1];
    }
    elsif ( $pos eq 'beg' ) {
        return $after_split_elements[0];
    }

    # if position not known
    else {
        return $delimiter_for_split;
    }

}

1;
