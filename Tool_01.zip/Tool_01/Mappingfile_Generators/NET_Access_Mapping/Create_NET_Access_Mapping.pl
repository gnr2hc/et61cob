use strict;
use Getopt::Long;
use File::Basename;
use Data::Dumper;
use File::Copy;
use Clone qw(clone);
use POSIX;
use Tk;
use RBS_2_CAPL;

##------------------------------------------------------------------
## VARIABLES OF MAIN
##------------------------------------------------------------------
use vars qw($VERSION $HEADER $ProjectDefaults $CURRENT_TC );

# next 2 lines edited by CVS, DO NOT MODIFY
$VERSION = q$Revision: 1.18 $;
$HEADER  = q$Header: Mappingfile_Generators/NET_Access_Mapping/Create_NET_Access_Mapping.pl 1.18 2019/08/09 14:49:18ICT Prosch Christian (CC-PS/EPS2) (PHC2SI) develop  $;

my $generator_version = "Mapping file generator - CAN|LIN|FlexRay - $VERSION";

my $tool = $HEADER;
$tool =~ s/^Header: //;

my $output_mapping_file   = "NET_Access_mapping.pm";    ## proposal output file name
my $output_sysenvvar_file = 'NET_Access_EnvVar.dbc';    ## Set the default file name

#list of global variables
my ( $main, $opt_db_file_1, $opt_db_file_2, $cb_Selected, $db_file2_entry, $db_file2_browse, $busNum_2_dropdown, $bus_type, @db_file_info );
my ( $capl_gen_label, $capl_gen_entry, $capl_gen_button, $CAPL_template );
my $can_or_canfd_dropdown;
my $can_or_canfd_type = 'CAN';
my %cycle_time_attribute;
my $var_type        = 'Environment';
my $yesOrno         = 'No';
my $capl_gen_option = 'No';
my ( $busNum_1, $busNum_2 ) = ( 1, 2 );                 # Set default bus number to 1
my $capl_file;
my $cut = 0;

# main loop
Init_GUI();
MainLoop;

# main loop end

sub capl_generation_enable_disable_checkbox {
    if ( $capl_gen_option eq 'Yes' ) {
        $capl_gen_label->configure( -state => 'normal' );
        $capl_gen_entry->configure( -state => 'normal' );
        $capl_gen_button->configure( -state => 'normal' );
    }
    else {
        $capl_gen_label->configure( -state => 'disabled' );
        $capl_gen_entry->configure( -state => 'disabled' );
        $capl_gen_button->configure( -state => 'disabled' );
    }
}

sub Enable_disable_checkbox {
    if ( defined $opt_db_file_1 && $opt_db_file_1 ne '' && $cb_Selected == 1 ) {
        $db_file2_browse->configure( -state => 'normal' );
        $db_file2_entry->configure( -state => 'normal' );
        $busNum_2_dropdown->configure( -state => 'normal' );

    }
    else {
        $db_file2_browse->configure( -state => 'disabled' );
        $db_file2_entry->configure( -state => 'disabled' );
        $busNum_2_dropdown->configure( -state => 'disabled' );
    }
    return;
}

sub Enable_disable_canfd {

    if ( $opt_db_file_1 =~ /dbc$/i ) {
        $can_or_canfd_dropdown->configure( -state => 'normal' );
    }
    else {
        $can_or_canfd_dropdown->configure( -state => 'disabled' );
    }
    return;
}

#Inits the genrator by loading GUI
sub Init_GUI {

    # STEP Load the GUI
    # STEP get the user input from GUI (db files,Bus number,Output mapping file)
    # IF Is required Mandatory arguments are supplied?
    # 	IF-YES-START
    #		STEP Start the mapping file generator engine
    #   	CALL Start_generator_engine
    # 	IF-YES-END
    # 	IF-NO-START
    #		STEP Throw an error to the user - Not enough arguments
    # 	IF-NO-END
    # STEP END

    ##------------------------------------------------------------------
    ## create main window 'main'
    ##------------------------------------------------------------------
    # create main window 'main'
    $main = MainWindow->new( -background => "#888888" );

    # define minimum size of main window 'main'
    $main->minsize( 800, 300 );

    # create title in main window 'main'
    $main->title($generator_version);

    #create frame 'F1' in main window 'main'
    my $frame1 = $main->Frame( -background => "#333546" )->pack(
        -side   => 'top',
        -expand => 1,
        -fill   => 'both',
    );

    # create frame 'F2' in main window 'main'
    my $frame2 = $main->Frame( -background => "#333546" )->pack(
        -side => 'bottom',
        -fill => 'x',
    );

    # write head line in frame 'F1'
    $frame1->Label(
        -text       => 'LIFT prepare mapping : configuration window',
        -font       => '{Segoe UI Semibold} 13 bold ',
        -background => "#333546",
        -foreground => "white",
        -width      => 50,
        -relief     => 'groove',
    )->pack( -side => "top" );

    # create exit and start buttons in frame 'F2'
    $frame2->Button(
        -text       => "Quit",
        -width      => '8',
        -font       => '{Segoe UI Semibold} 12 ',
        -background => "Red4",
        -foreground => "white",
        -relief     => 'groove',
        -command    => sub { print " QUIT pressed -> Exit\n"; exit; }
      )->pack(
        -side  => 'left',
        -pady  => 20,
        -padx  => 20,
        -ipady => 5,
        -ipadx => 5,
      );

    #Mapping file generation starts on clicking the Start button
    my $start_button = $frame2->Button(
        -text       => "Start",
        -width      => '8',
        -font       => '{Segoe UI Semibold} 12 ',
        -foreground => "white",
        -relief     => 'groove',
        -background => "ForestGreen",
        -command    => sub {
            if ( $opt_db_file_1 and $output_mapping_file ) {

                #execute LPCM_engine
                Start_generator_engine();
                S_w2log(" Finished -> Press QUIT \n");
                close(LOG);
            }
            else {
                my $error_text = "! not enough options defined ! at least database file and output file needed ";
                Create_ErrorMsgBox($error_text);
            }
        }
      )->pack(
        -side  => 'right',
        -pady  => 20,
        -padx  => 20,
        -ipady => 5,
        -ipadx => 5,
      );

###################################################################################
    # create Frame for choosing DB file with label, entry and button
    my $db_file_1 = $frame1->Frame( -background => "#888888" )->pack( -pady => 5, -fill => 'x', -padx => 5, );

    $db_file_1->Label( -text => "Database file (*.dbc,*.ldf,*.csv): ", -background => "#888888", -foreground => 'white', -font => '{Segoe UI Semibold} 10 bold', -width => '33.95', -wraplength => 260 )->pack( -side => 'left' );
    $db_file_1->Entry( -textvariable => \$opt_db_file_1, -validate => 'focusout', -background => "grey", -vcmd => [ \&Enable_disable_checkbox ] )->pack( -side => 'left', -fill => 'x', -expand => 1, -padx => 5 );

    # create 'browse file' button
    $db_file_1->Button(
        -text       => "Browse...",
        -relief     => 'groove',
        -background => "#333366",
        -foreground => "white",
        -font       => '{Segoe UI Semibold} 10 ',
        -command    => sub {
            my $temp = $opt_db_file_1;    # store old value
            $opt_db_file_1 = $main->getOpenFile(
                -filetypes => [ [ "database files", [ '.dbc', '.ldf', '.csv' ] ], [ "All files", '.*' ] ],
                -title => "Database files which have to be scanned",
                -initialdir => '.',
            );
            unless ($opt_db_file_1) { $opt_db_file_1 = $temp; }    # if no new value, restore old one
            Validate_arguments();
            Enable_disable_canfd();
        },
    )->pack( -side => 'right', -ipadx => 5, -ipady => 2, -pady => 5, -padx => 5 );

    #create Frame for choosing bus number for 1st DBC file
    my $busNum_1_Frame = $frame1->Frame( -background => "#888888" )->pack( -pady => 5, -fill => 'x', -padx => 5, );
    $busNum_1_Frame->Label(
        -text       => "Bus number : ",
        -background => "#888888",
        -foreground => 'white',
        -font       => '{Segoe UI Semibold} 10 bold',
        -width      => '34',
    )->pack( -side => 'left' );

    my $busNum_1_dropdown = $busNum_1_Frame->Optionmenu(
        -variable    => \$busNum_1,
        -relief      => 'groove',
        -borderwidth => 2,
        -width       => 3,
        -background  => "grey",
        -options     => [ 1 .. 32 ],
        -command     => [
            sub {
                Validate_arguments();
              }
        ],
    );
    $busNum_1_dropdown->pack( -side => 'left', );

    $busNum_1_Frame->Label(
        -text       => "(.dbc type ?)  ",
        -background => "#888888",
        -foreground => 'white',
        -font       => '{Segoe UI Semibold} 10 bold',
        -width      => '20',
    )->pack( -side => 'left' );

    $can_or_canfd_dropdown = $busNum_1_Frame->Optionmenu(
        -variable    => \$can_or_canfd_type,
        -relief      => 'groove',
        -borderwidth => 2,
        -width       => 3,
        -background  => "grey",
        -options     => [ 'CAN', 'CANFD' ],
        -command     => [
            sub {
                Validate_arguments();
              }
        ],
    );
    $can_or_canfd_dropdown->pack( -side => 'left', );

########################################################################################################
    # create Frame for choosing 2nd DB file with label, entry and button
    my $db_file_2 = $frame1->Frame( -background => "#888888" )->pack( -pady => 5, -fill => 'x', -padx => 5, );
    $db_file_2->Checkbutton(
        -text             => "(optional) 2nd Database file:\n(.dbc,*.ldf,*.csv)",
        -variable         => \$cb_Selected,
        -command          => \&Enable_disable_checkbox,
        -font             => '{Segoe UI Semibold} 10 bold ',
        -indicatoron      => 'true',
        -selectcolor      => 'black',
        -activeforeground => "white",
        -foreground       => "white",
        -activebackground => "#888888",
        -background       => "#888888",
        -width            => '30.98',
    )->pack( -side => 'left' );
    $db_file2_entry = $db_file_2->Entry( -textvariable => \$opt_db_file_2, -state => 'disabled', -validate => 'focusout', -background => "grey", )->pack( -side => 'left', -fill => 'x', -expand => 1, -padx => 5 );

    # create 'browse file' button
    $db_file2_browse = $db_file_2->Button(
        -text       => "Browse...",
        -state      => "disabled",
        -relief     => 'groove',
        -background => "#333366",
        -foreground => "white",
        -font       => '{Segoe UI Semibold} 10 ',
        -command    => sub {
            my $temp = $opt_db_file_2;    # store old value
            $opt_db_file_2 = $main->getOpenFile(
                -filetypes => [ [ "database files", [ '.dbc', '.ldf', '.csv' ] ], [ "All files", '.*' ] ],
                -title => "Database file which have to be scanned",
                -initialdir => '.',
            );
            unless ($opt_db_file_2) { $opt_db_file_2 = $temp; }    # if no new value, restore old one
            Validate_arguments();
            Enable_disable_canfd();
        },
    )->pack( -side => 'right', -ipadx => 5, -ipady => 2, -pady => 5, -padx => 5 );

    #create Frame for choosing bus number for 2nd database file
    my $busNum_2_Frame = $frame1->Frame( -background => "#888888" )->pack( -pady => 5, -fill => 'x', -padx => 5, );
    $busNum_2_Frame->Label(
        -text       => "Bus number for 2nd database file: ",
        -background => "#888888",
        -foreground => 'white',
        -font       => '{Segoe UI Semibold} 10 bold',
        -width      => '34.2',
    )->pack( -side => 'left' );

    $busNum_2_dropdown = $busNum_2_Frame->Optionmenu(
        -variable    => \$busNum_2,
        -relief      => 'groove',
        -borderwidth => 2,
        -width       => 3,
        -background  => "grey",
        -options     => [ 1 .. 32 ],
        -state       => "disabled",
        -command     => [
            sub {
                Validate_arguments();
              }
        ],
    );
    $busNum_2_dropdown->pack( -side => 'left', );

##########################################################################################################
    #create Frame for choosing Type of Variable(Environment/System)
    my $f1_VarType = $frame1->Frame( "-background" => "#888888" )->pack( -pady => '10', "-fill" => 'x', "-padx" => 5, );
    $f1_VarType->Label( -text => "Type of Variable\n( Environment/System ): ", -background => "#888888", -foreground => 'white', -font => '{Segoe UI Semibold} 10 bold', -width => '34', -wraplength => 350 )->pack( "-side" => 'left' );

    my $varTye_dropdown = $f1_VarType->Optionmenu(
        -variable    => \$var_type,
        -relief      => 'groove',
        -borderwidth => 2,
        -width       => 3,
        -background  => "grey",
        -options     => [ 'Environment', 'System' ],
    );
    $varTye_dropdown->pack( -side => 'left', );
########################################################################################################

    # create Frame for choosing output file mapping with label, entry and button
    my $out_file = $frame1->Frame( -background => "#888888" )->pack( -pady => 5, -fill => 'x', -padx => 5 );
    $out_file->Label( -text => "Mapping output file (*.pm):     ", -background => "#888888", -foreground => 'white', -font => '{Segoe UI Semibold} 10 bold', -width => '33.95', )->pack( -side => 'left' );
    $out_file->Entry( -textvariable => \$output_mapping_file, -background => "grey", )->pack( -side => 'left', -fill => 'x', -expand => 1, -padx => 5, );

    # create 'browse file' button
    $out_file->Button(
        -text       => "Browse...",
        -relief     => 'groove',
        -background => "#333366",
        -foreground => "white",
        -font       => '{Segoe UI Semibold} 10 ',
        -command    => sub {
            my $temp = $output_mapping_file;    #   store old value
            $output_mapping_file = $main->getSaveFile(
                -filetypes => [ [ "Perl modules", '.pm' ], [ 'All files', '.*' ], ],
                -title => "Mapping output file",
                -initialdir  => '.',
                -initialfile => $output_mapping_file,
            );
            unless ($output_mapping_file) { $output_mapping_file = $temp; }    # if no new value, restore old one
        },
    )->pack( -side => 'right', -ipadx => 5, -ipady => 2, -pady => 5, -padx => 5 );

##########################################################################################################
    #create Frame for selecting Sys/Env variable file generation
    my $f1_YesNo = $frame1->Frame( "-background" => "#888888" )->pack( -pady => '10', "-fill" => 'x', "-padx" => 5, );
    $f1_YesNo->Label( -text => "Do you want to generate\n System/Env Variable file? : ", -background => "#888888", -foreground => 'white', -font => '{Segoe UI Semibold} 10 bold', -width => '34', -wraplength => 350 )->pack( "-side" => 'left' );

    my $yesNo_dropdown = $f1_YesNo->Optionmenu(
        -variable    => \$yesOrno,
        -relief      => 'groove',
        -borderwidth => 2,
        -width       => 3,
        -background  => "grey",
        -options     => [ 'Yes', 'No' ],
    );
    $yesNo_dropdown->pack( -side => 'left', );

#######################################################################################################
    # create Frame for Selecting CAPL file Generation
    my $f2_YesNo = $frame1->Frame( "-background" => "#888888" )->pack( -pady => '10', "-fill" => 'x', "-padx" => 5, );
    $f2_YesNo->Label( -text => "Do you want to generateCAPL file : ", -background => "#888888", -foreground => 'white', -font => '{Segoe UI Semibold} 10 bold', -width => '34', -wraplength => 350 )->pack( "-side" => 'left' );

    my $yesNo_dropdown1 = $f2_YesNo->Optionmenu(
        -command     => \&capl_generation_enable_disable_checkbox,
        -variable    => \$capl_gen_option,
        -relief      => 'groove',
        -borderwidth => 2,
        -width       => 3,
        -background  => "grey",
        -options     => [ 'Yes', 'No' ],
    );
    $yesNo_dropdown1->pack( -side => 'left', );

########################################################################################################
    # create a browse button for selecting CAN

    $capl_file = $frame1->Frame( -background => "#888888" )->pack( -pady => 5, -fill => 'x', -padx => 5 );
    $capl_gen_label = $capl_file->Label( -text => "CAPL template (*.can):     ", -background => "#888888", -foreground => 'white', -font => '{Segoe UI Semibold} 10 bold', -width => '33.95', )->pack( -side => 'left' );
    $capl_gen_entry = $capl_file->Entry( -textvariable => \$CAPL_template, -background => "grey", -validate => 'focusout', )->pack( -side => 'left', -fill => 'x', -expand => 1, -padx => 5, );

    # create 'browse file' button
    $capl_gen_button = $capl_file->Button(
        -text       => "Browse...",
        -relief     => 'groove',
        -state      => 'disabled',
        -background => "#333366",
        -state      => "disabled",
        -foreground => "white",
        -font       => '{Segoe UI Semibold} 10 ',

        -command => sub {
            my $temp = $CAPL_template;    # store old value
            $CAPL_template = $main->getOpenFile(
                -filetypes => [ [ "Template CAPL", ['.can'] ], [ "All files", '.*' ] ],
                -title => "CAPL Template to be used",
                -initialdir => '.',
            );
          }

    )->pack( -side => 'right', -ipadx => 5, -ipady => 2, -pady => 5, -padx => 5, );
    return;
}

sub Start_generator_engine {

    # STEP Validate the input arguments
    # IF Is validation successful?
    # 	IF-YES-START
    #		STEP Process the db file and store the data in an hash
    #	    CALL Process_db_file
    #		STEP Process the db hash and build the mapping file structure
    #		CALL Create_mapping_structure
    # 		STEP Store the mapping file the user specified location
    #       IF Generate SysVar file?
    #           IF-YES-START
    #               STEP Fetch the SysVar data
    #               CALL Write_to_sysvar_xml_file
    #           IF-YES-END
    #           IF-NO-START
    #               IF Generate EnvVar file?
    #                   IF-YES-START
    #                      STEP Fetch the EnvVar data
    #                      CALL Write_envvar_to_database_file
    #                   IF-YES-END
    #                   IF-NO-START
    #                   IF-NO-END
    #           IF-NO-END
    #	IF-YES-END
    #   IF-NO-START
    #		STEP Throw an error to the user
    #	IF-NO-END
    # STEP END

    open( LOG, ">NET_Access_Mapping_log.txt" ) || die("Open file: $!\n");

    my $status = Validate_arguments( $opt_db_file_1, $opt_db_file_2 );
    if ( $status == 1 ) {

        $output_mapping_file = $output_mapping_file . '.pm' unless ( $output_mapping_file =~ /.pm$/ );
        open( OUTFILE, ">$output_mapping_file" ) || die("Open file $output_mapping_file : $!\n");

        #Prepare the array of database files to be read
        my (%db_content);
        push @db_file_info, [ $opt_db_file_1, $busNum_1 ] if ( $opt_db_file_1 && $opt_db_file_1 ne '' );
        push @db_file_info, [ $opt_db_file_2, $busNum_2 ] if ( $opt_db_file_2 && $opt_db_file_2 ne '' && $cb_Selected );

        if ( $opt_db_file_1 =~ /.dbc$/i ) {
            $bus_type = 'CAN';
            $bus_type = 'CANFD' if $can_or_canfd_type eq 'CANFD';
        }
        elsif ( $opt_db_file_1 =~ /.csv$/i ) {
            $bus_type = 'FLEXRAY';
        }
        elsif ( $opt_db_file_1 =~ /.ldf$/i ) {
            $bus_type = 'LIN';
        }

        foreach my $row (@db_file_info) {
            my ( $db_file_name, $bus_num ) = @$row;
            %db_content = Process_db_file( { 'db_file' => $db_file_name, 'bus_number' => $bus_num, 'db_content_hash' => \%db_content } ) if ( $db_file_name && $db_file_name ne '' );
        }

        Write_mapping_structure( \%db_content );

        if ( $capl_gen_option eq 'Yes' ) {
            BlockCode_generateCAPL( \%db_content, \@db_file_info, $bus_type, $CAPL_template, \%cycle_time_attribute );
        }

        undef @db_file_info;
        my $message_to_display;
        $message_to_display = "Created $bus_type Mapping file";
        $message_to_display .= "\n\nGenerated $var_type variable file : " . getcwd() . "\\$output_sysenvvar_file " if ( $yesOrno eq 'Yes' );

        $message_to_display .= "\n\nGenerated CAPL file : " . getcwd() . "\\nodes\\MSG_SIGNALS.can" if ( $capl_gen_option eq 'Yes' );

        $message_to_display .= "\nNOTE : File content will be overwritten if already exists!";

        $main->messageBox( -icon => "info", -message => $message_to_display, -title => 'Finished' );

        close(OUTFILE);
        $cut = 0;    #Reset the cut value
        undef %db_content;
    }

    return 1;
}

sub Process_db_file {

    # STEP Get the db file to be processed
    # STEP Identify the type of the db file (CAN|LIN|FR)
    # IF Is the db is CAN dbc file?
    #	IF-YES-START
    #		STEP process the CAN dbc file and store the data in a hash
    #		CALL Process_CAN_dbc_file
    #	IF-YES-END
    #	IF-NO-START
    #	IF-NO-END
    # IF Is the db is LIN ldf file?
    #	IF-YES-START
    #		STEP process the LIN ldf file and store the data in a hash
    #		CALL Process_LIN_ldf_file
    #	IF-YES-END
    #	IF-NO-START
    #	IF-NO-END
    # IF Is the db is FlexRay csv(exported from XML & ARXML) file?
    #	IF-YES-START
    #		STEP process the FlexRay csv file and store the data in a hash
    #		CALL Process_FR_csv_file
    #	IF-YES-END
    #	IF-NO-START
    #	IF-NO-END
    # Return the Processed hash
    # STEP END

    my $params          = shift;
    my $db_file         = $params->{'db_file'};
    my $bus_number      = $params->{'bus_number'};
    my $db_content_href = $params->{'db_content_hash'};

    S_w2log("Process_db_file: Processing database file = '$db_file'\n");
    my ( $db_file_base, $db_file_path, $suffix );
    if ( $bus_type =~ /^CAN|CANFD$/i ) {
        ( $db_file_base, $db_file_path, $suffix ) = fileparse( $db_file, '\.dbc', '.DBC', '\.Dbc' );
        $db_content_href = Process_CAN_dbc_file( { 'db_file' => $db_file, 'bus_number' => $bus_number, 'db_file_base' => $db_file_base, 'db_content_hash' => $db_content_href } );
    }
    elsif ( $bus_type =~ /^LIN$/i ) {
        ( $db_file_base, $db_file_path, $suffix ) = fileparse( $db_file, '\.ldf', '.LDF', '\.Ldf' );
        $db_content_href = Process_LIN_ldf_file( { 'db_file' => $db_file, 'bus_number' => $bus_number, 'db_file_base' => $db_file_base, 'db_content_hash' => $db_content_href } );
    }
    elsif ( $bus_type =~ /^FLEXRAY$/i ) {
        ( $db_file_base, $db_file_path, $suffix ) = fileparse( $db_file, '\.csv', '.CSV', '\.Csv' );
        $db_content_href = Process_FR_csv_file( { 'db_file' => $db_file, 'bus_number' => $bus_number, 'db_file_base' => $db_file_base, 'db_content_hash' => $db_content_href } );
    }

    my ($new_canoe_file) = $db_file_path . "/" . $db_file_base . "_4RBS" . $suffix;
    copy( $db_file, $new_canoe_file ) || die("Copy $db_file , $new_canoe_file : $!\n");
    system("ATTRIB -R $new_canoe_file");

    return %$db_content_href;
}

sub Process_CAN_dbc_file {
    my $params          = shift;
    my $db_file         = $params->{'db_file'};
    my $bus_number      = $params->{'bus_number'};
    my $db_file_base    = $params->{'db_file_base'};
    my $db_content_href = $params->{'db_content_hash'};

    my $msg_cnt = 0;
    my ( $sig_cnt, %all_signals_count );
    my %db_content_hash = %$db_content_href;
    my ( $msg_ID, $msgName, $msgDlc, $msgSender, $msg_Time );
    my $isBusTypeCANFD_detected = 0;

    open( DBIN, "< $db_file" ) || die("Open file $db_file: $!\n");

    while (<DBIN>) {

        # Ignore LINES marked with "___NOT_USED___"
        next if /___NOT_USED___/;

        # Match the Message part ad extract the Message data
        # if: "BO_ 844 NAV_GPS2: 8 CCC_MASK"
        #      KEY  ID  NAME    DLC  TRANSMITTER NODE
        if (
            /BO_    # BO_ keyword
          \s+    # some white char
          (\d+)  # match BOTSCHAFTS ID
          \s+    # some white char
          (\w+)  # match BOTSCHAFTS NAME
          \s*    # may be some white char
          :      # the ":"
          \s+    # some white char
          (\d+)  # the DLC (byte count)
          \s+    # some white char
          (\w+)  # match TRANSMITTER NODE NAME
          \s*    # may be some white char
         /x
          )
        {
            ( $msg_ID, $msgName, $msgDlc, $msgSender, $msg_Time ) = ( undef, undef, undef, undef, undef );
            S_w2log("\n$_");

            $msg_cnt++;
            $sig_cnt = 0;

            $msg_ID    = $1;
            $msgName   = $2;
            $msgDlc    = $3;
            $msgSender = $4;

            $isBusTypeCANFD_detected = 1 if ( $msgDlc > 8 );    # CANFD if message DLC is greater than 8.

            S_w2log("\n- $msg_cnt - MSG_ID: $msg_ID MSG_NAME: $msgName  MDG_DLC: $msgDlc MSG_SENDER: $msgSender\n");
            $db_content_hash{$bus_number}{$db_file}{$msg_ID}{"NAME"}   = $msgName;
            $db_content_hash{$bus_number}{$db_file}{$msg_ID}{"DLC"}    = $msgDlc;
            $db_content_hash{$bus_number}{$db_file}{$msg_ID}{"SENDER"} = $msgSender;
        }

        # END OF if: "BO_ 844 NAV_GPS2: 8 CCC_MASK"
        # Match the Signal part ad extract the Signal data
        # if: " SG_ ST_QUAL_GPS : 56|8@1+ (0.5,0) [0|0] "%"  ACC,EGS_SSG"
        #       KEY   |            | | ||   |  |   | |   |        |
        #       NAME -+            | | ||   |  |   | |   |        |
        #       POSITION ----------+ | ||   |  |   | |   |        |
        #       LENGTH --------------+ ||   |  |   | |   |        |
        #       FORMAT-----------------+|   |  |   | |   |        |
        #       SIGNED/UNSIGNED --------+   |  |   | |   |        |
        #       QUANTIZATION/FACTOR --------+  |   | |   |        |
        #       OFFSET ------------------------+   | |   |        |
        #       MINIMUM ---------------------------+ |   |        |
        #       MAXIMUM -----------------------------+   |        |
        #       UNIT ------------------------------------+        |
        #       RECEIVE NODES ------------------------------------+
        if (
            /
           SG_    # match the KEY
           \s+    # some white char
           (\w+)  # match the NAME
           \s*    # maybe some white char
           m?     # maybe multiplexed signal
           \d*    # maybe multiplexed signal
           \s*    # may be some white char
           :      # the ":"
           \s*    # some white char
           (\d+)  # the start POSITION (bit)
           \|     # the "|"
           (\d+)  # the LENGTH of signal in bit
           @      # some any char
           (\d)   # FORMAT : 1 (Intel) or 0 (Motorola)
           (\+|-) # the "+" or the "-"
           \s+    # some white char
           \(     # match the "("
           (
               [+-]?\d*\.?\d*[Ee][+-]\d+|
               [+-]?\d+\.\d+|
               [+-]?\d+\.|
               [+-]?\.\d+|
               [+-]?\d+
           ) # match the FACTOR
           ,    # match the ","
           (
               [+-]?\d*\.?\d*[Ee][+-]\d+|
               [+-]?\d+\.\d+|
               [+-]?\d+\.|
               [+-]?\.\d+|
               [+-]?\d+
           ) # match the OFFSET
           \)    # match the ")"
           \s*    # some white char
           \[    # match the "["
           (
               [+-]?\d*\.?\d*[Ee][+-]\d+|
               [+-]?\d+\.\d+|
               [+-]?\d+\.|
               [+-]?\.\d+|
               [+-]?\d+
           ) # match the MINIMUM
           \|    # match the "|"
           (
               [+-]?\d*\.?\d*[Ee][+-]\d+|
               [+-]?\d+\.\d+|
               [+-]?\d+\.|
               [+-]?\.\d+|
               [+-]?\d+
           ) # match the MAXIMUM
           \]    # match the "["
           \s*    # some white char
           \"    # match the "["
           (.*)     # match the UNIT
           \"    # match the "["
           \s*    # some white char
           (\S+)    # network elements
         /xi    # the allowance of comments:-)
          )
        {
            $sig_cnt++;

            #    ASSIGN ALL FOUND ITEMS
            my $sig_name     = $1;
            my $sig_position = $2;
            my $sig_length   = $3;

            my $sig_format;
            $sig_format = "INTEL"    if ( $4 == 1 );
            $sig_format = "MOTOROLA" if ( $4 == 0 );
            $sig_format = "DBC_ERROR" unless defined $sig_format;

            my $sig_type;
            $sig_type = "UNSIGNED" if ( $5 eq "+" );
            $sig_type = "SIGNED"   if ( $5 eq "-" );
            $sig_type = "DBC_ERROR" unless defined $sig_type;

            my $sig_factor = sprintf( "%f", $6 );
            my $sig_offset = sprintf( "%f", $7 );
            my $sig_unit   = $10;
            $sig_unit =~ s/\'//g;    # replace the ' character in case that is part of UNIT (eg. 'C instead of °C)
            my $sig_modules = $11;

            my $sig_minimum = sprintf( "%f", $8 );
            my $sig_maximum = sprintf( "%f", $9 );

            # increase signal counter
            $all_signals_count{$sig_name}++;

            my $sig_multiplex_value;
            my $sig_multiplexer;

            # match  "SG_ MF_Zaehler M ..."
            if (
                /
              SG_    # match the KEY
              \s+    # some white char
              \w+    # match the NAME
              \s+    # maybe some white char
              M      # multiplexed signal
              \s+
              /ix
              )
            {
                $sig_multiplexer = "yes";
            }

            # match  "SG_ MF_IntervallWmax m3 ..."
            if (
                /
              SG_    # match the KEY
              \s+    # some white char
              \w+    # match the NAME
              \s+    # maybe some white char
              M      # multiplexed signal
              (\d+)  # multiplexed signal code
              \s+
              /ix
              )
            {
                $sig_multiplex_value = $1;
            }

            $sig_minimum =~ s/\.d*0+$//g;
            $sig_maximum =~ s/\.d*0+$//g;

            #    SOME PRINTOUTS FOR DEBUG
            S_w2log("\n - $msg_cnt - ($sig_cnt) - $_");
            S_w2log("  ->  SG_NAME : $sig_name\n");
            S_w2log("  ->  SG_POSITION : $sig_position\n");
            S_w2log("  ->  SG_LENGTH : $sig_length\n");
            S_w2log("  ->  SG_FORMAT : $sig_format\n");
            S_w2log("  ->  SG_TYPE : $sig_type\n");
            S_w2log("  ->  SG_FACTOR : $sig_factor\n");
            S_w2log("  ->  SG_OFFSET : $sig_offset\n");
            S_w2log("  ->  SG_MINIMUM : $sig_minimum\n");
            S_w2log("  ->  SG_MAXIMUM : $sig_maximum\n");
            S_w2log("  ->  SG_UNIT : $sig_unit\n");
            S_w2log("  ->  SG_MODULS : $sig_modules\n");

            S_w2log("  ->  SG_MULTIPLEXER : $sig_multiplexer\n")         if defined $sig_multiplexer;
            S_w2log("  ->  SG_MULTIPLEX_VALUE : $sig_multiplex_value\n") if defined $sig_multiplex_value;

            $db_content_hash{$bus_number}{$db_file}{$msg_ID}{"SIGNALS"}{$sig_name}{"POSITION"}        = $sig_position;
            $db_content_hash{$bus_number}{$db_file}{$msg_ID}{"SIGNALS"}{$sig_name}{"LENGTH"}          = $sig_length;
            $db_content_hash{$bus_number}{$db_file}{$msg_ID}{"SIGNALS"}{$sig_name}{"FORMAT"}          = $sig_format;
            $db_content_hash{$bus_number}{$db_file}{$msg_ID}{"SIGNALS"}{$sig_name}{"TYPE"}            = $sig_type;
            $db_content_hash{$bus_number}{$db_file}{$msg_ID}{"SIGNALS"}{$sig_name}{"FACTOR"}          = $sig_factor;
            $db_content_hash{$bus_number}{$db_file}{$msg_ID}{"SIGNALS"}{$sig_name}{"OFFSET"}          = $sig_offset;
            $db_content_hash{$bus_number}{$db_file}{$msg_ID}{"SIGNALS"}{$sig_name}{"MINIMUM"}         = $sig_minimum;
            $db_content_hash{$bus_number}{$db_file}{$msg_ID}{"SIGNALS"}{$sig_name}{"MAXIMUM"}         = $sig_maximum;
            $db_content_hash{$bus_number}{$db_file}{$msg_ID}{"SIGNALS"}{$sig_name}{"UNIT"}            = $sig_unit;
            $db_content_hash{$bus_number}{$db_file}{$msg_ID}{"SIGNALS"}{$sig_name}{"MODULS"}          = $sig_modules;
            $db_content_hash{$bus_number}{$db_file}{$msg_ID}{"SIGNALS"}{$sig_name}{"MULTIPLEXER"}     = 1 if defined $sig_multiplexer;
            $db_content_hash{$bus_number}{$db_file}{$msg_ID}{"SIGNALS"}{$sig_name}{"MULTIPLEX_VALUE"} = $sig_multiplex_value if defined $sig_multiplex_value;

            if ( defined $sig_multiplexer ) {
                unless ( $db_content_hash{$bus_number}{$db_file}{$msg_ID}{"MULTIPLEXER"} ) { $db_content_hash{$bus_number}{$db_file}{$msg_ID}{"MULTIPLEXER"} = $sig_name; }
                else                                                                       { S_w2log("  DB ERROR ! more then 1 Multiplexer in Message $msg_ID !\n"); }
            }

        }

        # END OF " SG_ ST_QUAL_GPS : 56|8@1+ (0.5,0) [0|0] "%"  ACC,EGS_SSG"

        ## COLLECT CYCLETIME
        ## BA_ "CycleTime" BO_ 431 20;
        if (/BA_\s*\"(.*CycleTime.*)\"\s*BO_\s*(\d+)\s*(\d+)\s*;/) {
            $cycle_time_attribute{$bus_number}{CYCLE_TIME_ATTR} = $1;
            $msg_ID                                             = $2;
            $msg_Time                                           = $3;
            S_w2log("$msg_ID => CycleTime: $msg_Time\n");
            $db_content_hash{$bus_number}{$db_file}{$msg_ID}{"CycleTime"} = $msg_Time;
        }

    }

    $bus_type = 'CANFD' if ( $isBusTypeCANFD_detected == 1 );    # considered bustype as CANFD if the dlc is greater that 8

    close DBIN;
    return \%db_content_hash;
}

sub Process_LIN_ldf_file {
    my $params          = shift;
    my $db_file         = $params->{'db_file'};
    my $bus_number      = $params->{'bus_number'};
    my $db_file_base    = $params->{'db_file_base'};
    my $db_content_href = $params->{'db_content_hash'};

    my $msg_cnt = 0;
    my ( $sig_cnt, %all_signals_count, $signal_info_href, %sig_mapped_msg );
    my ( $msg_ID, $msgName, $msgDlc, $msgSender, $msg_Time, $signals_match, $messages_match, $found_signal_encoding_types, $sig_encoding_type );
    open( LDFIN, "< $db_file" ) || die("Open file $db_file: $!\n");
    while (<LDFIN>) {

        S_w2log(" Line : $_ ");
        print "LINE: $_\n";

        if ( /^Nodes\s*\{/i .. /\}/i ) {
            S_w2log("BLOCK ---> 'Nodes' --> ");
            S_w2log("$_\n");
        }

        # Matching BLOCK : Signals
        #
        #         Signals {
        #         	Bckl_Sw_D_Stat : 2, 3, ORC, OCM;
        #         	Bckl_Sw_FP_Stat : 2, 3, ORC, OCM;
        #           ...
        #         }
        #
        if ( /^Signals\s*\{/i .. /\}/i ) {
            unless ($signals_match) {
                S_w2log("BLOCK ---> 'Signals' <-- BEGIN \n");
                $signals_match = 1;
                next;
            }
            if (
                /
                    \s*     # ...
                    (\w+)   # the SIGNAL NAME
                    \s*     # ...
                    :       # the ':'
                    \s*     # ...
                    (\d+)   # the SIGNAL LENGTH
                    \s*     # ...
                    ,       # the ','
                    \s*     # ...
                    (\d+)   # the SIGNAL DEFINED MAXIMUM
                    \s*     # ...
                    ,       # the ','
                    \s*     # ...
                    (.+)    # all NODES (with ',') until ';'
                    ;                
                /x
              )
            {

                $sig_cnt++;

                S_w2log("\n - $msg_cnt - ($sig_cnt) - $_");

                my $sig_name    = $1;
                my $sig_length  = $2;
                my $sig_maximum = $3;

                S_w2log( 3, "  ->  SG_NAME : $sig_name\n" );
                S_w2log( 3, "  ->  SG_LENGTH : $sig_length\n" );
                S_w2log( 3, "  ->  SG_DEFINED_MAXIMUM : $sig_maximum\n" );

                $signal_info_href->{$sig_name}{"LENGTH"}  = $sig_length;
                $signal_info_href->{$sig_name}{"MAXIMUM"} = $sig_maximum;    # it's just the defined maximum , error value can be greater
                $signal_info_href->{$sig_name}{"MINIMUM"} = 0;               # <--- might be changed later
                $signal_info_href->{$sig_name}{"OFFSET"}  = 0;               # <--- might be changed later
                $signal_info_href->{$sig_name}{"FACTOR"}  = 1;               # <--- might be changed later
                $signal_info_href->{$sig_name}{"UNIT"}    = "";              # <--- might be changed later
                $signal_info_href->{$sig_name}{"TYPE"}    = "UNSIGNED";      # <--- might be changed later
                $signal_info_href->{$sig_name}{"FORMAT"}  = "INTEL";         # <--- just define something

                next;
            }
        }

        # Matching BLOCK BEGIN : Frames
        #
        #         Frames {
        #         	ORC_STAT_Frm1_AR2 : 5, ORC, 8 {
        #         		Bckl_Sw_D_Stat, 0;
        #         		Parity_Bckl_Sw_D_Stat, 2;
        #                 ....
        #         	}
        #             ....
        #         }
        #
        if ( /^Frames\s*\{/i and not $messages_match ) {
            S_w2log( 1, "BLOCK ---> 'Frames' <-- BEGIN \n" );
            $messages_match = 1;
            next;
        }

        if ( $messages_match and not $msgName ) {

            if (/\}/) {
                S_w2log( 1, "BLOCK ---> 'Frames' <-- END \n" );
                undef $messages_match;
                next;
            }

            # Matching BLOCK BEGIN : <FRAME>
            #
            #           ORC_STAT_Frm1_AR2 : 5, ORC, 8 {
            #               Bckl_Sw_D_Stat, 0;
            #               Parity_Bckl_Sw_D_Stat, 2;
            #                 ....
            #           }
            if (
                /
							\s*     # ...
							(\w+)   # the FRAME NAME
							\s*     # ...
							:       # the ':'
							\s*     # ...
							(\w+)   # the FRAME ID (can be dec or hex)
							\s*     # ...
							,       # the ','
							\s*     # ...
							(\w+)   # the FRAME SENDER
							\s*     # ...
							,       # the ','
							\s*     # ...
							(\d+)   # the FRAME DLC (LENGTH)
							\s*     # ...
							\{      # the '{'
						/x
              )
            {

                $msg_cnt++;
                $sig_cnt = 0;

                $msgName   = $1;
                $msg_ID    = $2;
                $msgSender = $3;
                $msgDlc    = $4;

                S_w2log( 2, "BLOCK ---> <FRAME: $msgName> <-- BEGIN \n" );

                S_w2log( 3, "\n- $msg_cnt - FRAME_ID: $msg_ID FRAME_NAME: $msgName  FRAME_DLC: $msgDlc FRAME_SENDER: $msgSender\n" );
                $db_content_href->{$bus_number}{$db_file}{$msg_ID}{"NAME"}   = $msgName;
                $db_content_href->{$bus_number}{$db_file}{$msg_ID}{"DLC"}    = $msgDlc;
                $db_content_href->{$bus_number}{$db_file}{$msg_ID}{"SENDER"} = $msgSender;

                next;
            }
        }

        if ( $messages_match && $msgName ) {

            if (/\}/) {
                S_w2log( 1, "BLOCK ---> <FRAME: $msgName <-- END \n" );
                undef $msgName;
                next;
            }

            #
            # Matching : <SIGNAL>   in FRAME BLOCK
            #
            #           ORC_STAT_Frm1_AR2 : 5, ORC, 8 {
            #               Bckl_Sw_D_Stat, 0;                        <<<-------
            if (
                /
							\s*     # ...
							(\w+)   # the SIGNAL NAME
							\s*     # ...
							,       # the ','
							\s*     # ...
							(\d+)   # the SIGNAL POSITION
							\s*     # ...
							;       # the ';'                
						/x
              )
            {

                my $sig_name     = $1;
                my $sig_position = $2;

                S_w2log( 1, "BLOCK ---> <SIGNAL: $sig_name> <-- \n" );

                $db_content_href->{$bus_number}{$db_file}{$msg_ID}{"SIGNALS"}{$sig_name} = clone( $signal_info_href->{$sig_name} );
                $db_content_href->{$bus_number}{$db_file}{$msg_ID}{"SIGNALS"}{$sig_name}{"POSITION"} = $sig_position;

                # increase signal counter
                $all_signals_count{$sig_name}++;

                $sig_mapped_msg{$sig_name}{$msg_ID} = 1;

                next;
            }
        }
        if ( /^Diagnostic_signals\s*\{/i .. /\}/i ) {
            S_w2log("BLOCK ---> 'Diagnostic_signals' --> ");
            S_w2log("$_\n");
        }

        if ( /^Diagnostic_frames\s*\{/i .. /\}/i ) {
            S_w2log("BLOCK ---> 'Diagnostic_frames' --> ");
            S_w2log("$_\n");
        }

        if ( /^Node_attributes\s*\{/i .. /\}/i ) {
            S_w2log("BLOCK ---> 'Node_attributes' --> ");
            S_w2log("$_\n");
        }

        # Matching BLOCK BEGIN : Signal_encoding_types
        #
        #         Signal_encoding_types {                           <<<<--------
        #         	c01_FalseTrue {
        #         		logical_value, 0, "FALSE";
        #         		logical_value, 1, "TRUE";
        #         	}
        #         	c02_ActvComf_Stat {
        #         		logical_value, 0, "ACTV_COMF_OFF";
        #         }
        #
        if ( /^Signal_encoding_types\s*\{/i and not $found_signal_encoding_types ) {
            S_w2log( 2, "BLOCK ---> 'Signal_encoding_types' <-- BEGIN \n" );
            $found_signal_encoding_types = 1;
            next;
        }
        if ( $found_signal_encoding_types and not $sig_encoding_type ) {
            if (/\}/) {
                S_w2log( 1, "BLOCK ---> 'Signal_encoding_types' <-- END \n" );
                undef $found_signal_encoding_types;
                next;
            }

            # Matching BLOCK BEGIN : <SIG_ENCOD_TYPE>
            #
            #         Signal_encoding_types {
            #         	c01_FalseTrue {                             <<<<--------
            #         		logical_value, 0, "FALSE";
            #         		logical_value, 1, "TRUE";
            #         	}
            #         	c02_ActvComf_Stat {
            if (
                /
                    \s*     # ...
                    (\w+)   # the SIG ENCOD TYPE
                    \s*     # ...
                    \{      # the '{'
                /x
              )
            {

                $sig_encoding_type = $1;

                S_w2log( 2, "BLOCK ---> <SIG_ENCOD_TYPE: $sig_encoding_type> <-- BEGIN \n" );

                $signal_info_href->{"SIG_ENCODINGS"}{$sig_encoding_type} = {};    # just to create the key
                next;
            }
        }

        if ( $found_signal_encoding_types && $sig_encoding_type ) {

            if (/\}/) {
                S_w2log( 1, "BLOCK ---> <SIG_ENCOD_TYPE: $sig_encoding_type> <-- END \n" );
                undef $sig_encoding_type;
                next;
            }

            # Matching SIG ENCODING logical_value in  : <SIG_ENCOD_TYPE>
            #
            #         Signal_encoding_types {
            #         	c01_FalseTrue {
            #         		logical_value, 0, "FALSE";            <<<<--------
            #         		logical_value, 1, "TRUE";
            #         	}
            if (
                /
                    \s*     # ...
                    logical_value   # the 'logical_value'
                    \s*     # ...
                    ,       # the ','
                    \s*     # ...
                    (\d+)   # the SIG VALUE
                    \s*     # ...
                    ,       # the ','
                    \s*     # ...
                    \"      # the "
                    (.+)    # the SIG LABEL
                    \"      # the "
                    \s*     # ...
                    ;       # the ';'                
                /x
              )
            {

                my $sig_encod_logical_val   = $1;
                my $sig_encod_logical_label = $2;

                $signal_info_href->{"SIG_ENCODINGS"}{$sig_encoding_type}{'LOGICAL_VALUE'}{$sig_encod_logical_val} = $sig_encod_logical_label;

                S_w2log( 3, "\n - SIG_ENCOD_TYPE: $sig_encoding_type --- logical_value : $sig_encod_logical_val => $sig_encod_logical_label\n" );
                next;
            }

            # Matching SIG ENCODING physical_value in  : <SIG_ENCOD_TYPE>
            #
            #         Signal_encoding_types {
            #         	c12_g_m2_2_0k001 {
            #         		physical_value, 0, 4000, 0.001, -2, "g";   <----
            #         		logical_value, 4094, "FAULT";
            #         		logical_value, 4095, "SNA";
            #         	}
            if (
                /
                    \s*     # ...
                    physical_value   # the 'logical_value'
                    \s*     # ...
                    ,       # the ','
                    \s*     # ...
                    (\d+)   # the SIG MIN VALUE RAW   (e.g. 0)
                    \s*     # ...
                    ,       # the ','
                    \s*     # ...
                    (\d+)   # the SIG MAX VALUE RAW   (e.g. 4000)
                    \s*     # ...
                    ,       # the ','
                    \s*     # ...
                    (
                       [+-]?\d*\.?\d*[Ee][+-]\d+|
                       [+-]?\d+\.\d+|
                       [+-]?\d+\.|
                       [+-]?\.\d+|
                       [+-]?\d+
                    ) # match the FACTOR
                    \s*     # ...
                    ,       # the ','
                    \s*     # ...
                    (
                       [+-]?\d*\.?\d*[Ee][+-]\d+|
                       [+-]?\d+\.\d+|
                       [+-]?\d+\.|
                       [+-]?\.\d+|
                       [+-]?\d+
                    ) # match the OFFSET
                    \s*     # ...
                    ,       # the ','                    
                    \s*     # ...
                    \"      # the "
                    (.+)    # the UNIT
                    \"      # the "
                    \s*     # ...
                    ;       # the ';'                
                /x
              )
            {

                my $sig_encod_phy_minval = $1;
                my $sig_encod_phy_maxval = $2;
                my $sig_encod_phy_factor = $3;
                my $sig_encod_phy_offset = $4;
                my $sig_encod_phy_unit   = $5;

                $signal_info_href->{"SIG_ENCODINGS"}{$sig_encoding_type}{'PHYSICAL_VALUE'}{'FACTOR'}  = $sig_encod_phy_factor;
                $signal_info_href->{"SIG_ENCODINGS"}{$sig_encoding_type}{'PHYSICAL_VALUE'}{'OFFSET'}  = $sig_encod_phy_offset;
                $signal_info_href->{"SIG_ENCODINGS"}{$sig_encoding_type}{'PHYSICAL_VALUE'}{'UNIT'}    = $sig_encod_phy_unit;
                $signal_info_href->{"SIG_ENCODINGS"}{$sig_encoding_type}{'PHYSICAL_VALUE'}{'MIN_RAW'} = $sig_encod_phy_minval;
                $signal_info_href->{"SIG_ENCODINGS"}{$sig_encoding_type}{'PHYSICAL_VALUE'}{'MAX_RAW'} = $sig_encod_phy_maxval;

                S_w2log( 3, "\n - SIG_ENCOD_TYPE: $sig_encoding_type --- physical_value : FACTOR '$sig_encod_phy_factor' , OFFSET '$sig_encod_phy_offset' UNIT '$sig_encod_phy_unit' \n" );
                next;
            }
        }

        # MATCHING BLOCK : Signal_representation
        #
        #         Signal_representation {
        #         	c02_ActvComf_Stat : MCMS_ActvComf_FL_Stat, MCMS_ActvComf_FR_Stat;
        #         	c02_Bckl_Sw_Stat : Bckl_Sw_D_Stat, Bckl_Sw_FP_Stat;
        #             ....

        if ( /^Signal_representation\s*\{/i .. /\}/i ) {
            if (
                /
                    (\w+)   # the SIG ENCODING TYPE 
                    \s*     # ...
                    :       # the ':'
                    \s*     # ...
                    (.+)    # everything (all SIGNALS) until ..
                    ;       # .. the ';' 
                /x
              )
            {

                $sig_encoding_type = $1;    # e.g. c02_ActvComf_Stat
                my $assigned_signas_temp = $2;        # e.g. MCMS_ActvComf_FL_Stat, MCMS_ActvComf_FR_Stat
                $assigned_signas_temp =~ s/\s+//g;    # remove all spaces
                                                      # copy now all attributes from signal encoding type to the specific signals
                foreach my $signal_name ( split( /,/, $assigned_signas_temp ) ) {
                    if ( $signal_info_href->{"SIG_ENCODINGS"}{$sig_encoding_type}{'PHYSICAL_VALUE'} ) {
                        foreach my $msgID ( keys %{ $sig_mapped_msg{$signal_name} } ) {
                            S_w2log( 4, " Signal_representation: $sig_encoding_type -> '$signal_name' (assigned physical values)\n" );

                            # assign FACTOR
                            $db_content_href->{$bus_number}{$db_file}{$msgID}{"SIGNALS"}{$signal_name}{'FACTOR'} = $signal_info_href->{"SIG_ENCODINGS"}{$sig_encoding_type}{'PHYSICAL_VALUE'}{'FACTOR'};

                            # assign OFFSET
                            $db_content_href->{$bus_number}{$db_file}{$msgID}{"SIGNALS"}{$signal_name}{'OFFSET'} = $signal_info_href->{"SIG_ENCODINGS"}{$sig_encoding_type}{'PHYSICAL_VALUE'}{'OFFSET'};

                            # assign UNIT
                            $db_content_href->{$bus_number}{$db_file}{$msgID}{"SIGNALS"}{$signal_name}{'UNIT'} = $signal_info_href->{"SIG_ENCODINGS"}{$sig_encoding_type}{'PHYSICAL_VALUE'}{'UNIT'};

                            # assign MIN_RAW
                            $db_content_href->{$bus_number}{$db_file}{$msgID}{"SIGNALS"}{$signal_name}{'MINIMUM'} = $signal_info_href->{"SIG_ENCODINGS"}{$sig_encoding_type}{'PHYSICAL_VALUE'}{'MIN_RAW'};

                            # assign MAX_RAW
                            $db_content_href->{$bus_number}{$db_file}{$msgID}{"SIGNALS"}{$signal_name}{'MAXIMUM'} = $signal_info_href->{"SIG_ENCODINGS"}{$sig_encoding_type}{'PHYSICAL_VALUE'}{'MAX_RAW'};
                        }

                    }
                    if ( $signal_info_href->{"SIG_ENCODINGS"}{$sig_encoding_type}{'LOGICAL_VALUE'} ) {

                        # TODO: VALUE TABLE
                    }
                }
            }
        }
    }
    close LDFIN;
    return $db_content_href;
}

sub Process_FR_csv_file {
    my $params          = shift;
    my $db_file         = $params->{'db_file'};
    my $bus_number      = $params->{'bus_number'};
    my $db_file_base    = $params->{'db_file_base'};
    my $db_content_href = $params->{'db_content_hash'};

    my $fr_csv_dataref = Validate_and_process_csv_file($db_file);

    my $pduFrame_href;
    foreach my $line_num ( sort keys %$fr_csv_dataref ) {
        my $line_dataref = $fr_csv_dataref->{$line_num};

        if ( $line_dataref->{'PDU'} =~ // && $line_dataref->{'FRAME'} =~ /PDU/ ) {
            $line_dataref->{'PDU'} = $line_dataref->{'FRAME'};
        }

        my $fr_pdu = $line_dataref->{'PDU'};

        #Store the PDU information obtained from the .csv file in a hash
        unless ( grep( {/^$fr_pdu$/i} keys %{$pduFrame_href} ) ) {
            $pduFrame_href->{$fr_pdu}                                         = $line_num;
            $db_content_href->{$bus_number}{$db_file}{$line_num}{'NAME'}      = $fr_pdu;
            $db_content_href->{$bus_number}{$db_file}{$line_num}{'CycleTime'} = $line_dataref->{'CYCLE'};
            $db_content_href->{$bus_number}{$db_file}{$line_num}{'SENDER'}    = $line_dataref->{'TRANSMITTER'};
            $db_content_href->{$bus_number}{$db_file}{$line_num}{'SLOT'}      = $line_dataref->{'BYTES'};
        }
        else {
            #If already found, get data from hash
            $line_num = $pduFrame_href->{$fr_pdu};
        }
        my $signal_name = $line_dataref->{'SIGNAL'};
        my $signal_href->{$signal_name}{'LENGTH'} = $line_dataref->{'LENGTH'};
        $signal_href->{$signal_name}{'FORMAT'} = $line_dataref->{'FORMAT'};
        my $data_type = $line_dataref->{'TYPE'};
        if ( $data_type =~ /^int/ ) {
            $data_type = "SIGNED";
        }
        else {
            $data_type = "UNSIGNED";
        }
        $signal_href->{$signal_name}{'TYPE'} = $data_type;
        my $data_bitpos = $line_dataref->{'BITPOS'};
        my @start_bit = split( '\/', $data_bitpos );

        #DLC calculation
        $start_bit[1] =~ s/\"//g;
        $start_bit[1] =~ s/\s*//g;    #remove if any space is present
        my $leng_comp = $start_bit[1];
        $signal_name =~ s/\"//g;
        $leng_comp = $leng_comp + $signal_href->{$signal_name}{'LENGTH'};
        my $len = ceil( $leng_comp / 8 );
        if ( $db_content_href->{$bus_number}{$db_file}{$line_num}{'DLC'} ) {
            my $temp = $db_content_href->{$bus_number}{$db_file}{$line_num}{'DLC'};

            if ( $temp < $len ) {
                $db_content_href->{$bus_number}{$db_file}{$line_num}{'DLC'} = $len;
            }
        }
        else {
            $db_content_href->{$bus_number}{$db_file}{$line_num}{'DLC'} = $len;
        }

        #Offset and Factor calculation
        $signal_href->{$signal_name}{'POSITION'} = $start_bit[1];
        my $data_computation = $line_dataref->{'SCALE_OFFSET'};

        my $num_regex = '([-+]?\d+(\.\d+([eE][-+]?\d+)?)?)';
        $data_computation =~ /.+=\(?$num_regex\)?\*raw$num_regex\)?/;    #[0..250(phys)] phys=(1)*raw+0 or  phys=(1.0*raw+0) / 1.0 or [-30..30(phys)] phys=0.00390625*raw+0
        my ( $factor, $offset ) = ( $1, $4 );

        unless ( defined $factor ) { $factor = "1"; }
        unless ( defined $offset ) { $offset = "0"; }

        $factor =~ s/\+//;
        $offset =~ s/\+//;

        $signal_href->{$signal_name}{'FACTOR'}                                                          = $factor;
        $signal_href->{$signal_name}{'OFFSET'}                                                          = $offset;
        $db_content_href->{$bus_number}{$db_file}{ $pduFrame_href->{$fr_pdu} }{'SIGNALS'}{$signal_name} = clone( $signal_href->{$signal_name} );
    }

    return $db_content_href;
}

sub Write_mapping_structure {
    my @args           = @_;
    my $db_content_hef = shift @args;

    my ( %msg_hash, @duplicate_msgs_arr, $sysEnvvar_arr );
    S_w2outfile("### file generated with $tool\n");
    S_w2outfile("### input dbc files:\n");
    S_w2outfile("### => $opt_db_file_1\n");
    S_w2outfile("### => $opt_db_file_2\n") if $opt_db_file_2;
    S_w2outfile("package LIFT_PROJECT;\n\n");

    S_w2outfile("\$Defaults->{\"Mapping_NET_Access_$bus_type\"} = {\n");

    S_w2outfile("'MSGS_OR_PDUS_OR_FRAMES'  => {\n");
    foreach my $bus_number ( sort keys %$db_content_hef ) {
        foreach my $db_file_name ( keys %{ $db_content_hef->{$bus_number} } ) {
            foreach my $msg_ID ( sort { $a <=> $b } keys %{ $db_content_hef->{$bus_number}{$db_file_name} } ) {
                my $db_msg_info = $db_content_hef->{$bus_number}{$db_file_name}{$msg_ID};
                my $msg_name    = $db_msg_info->{'NAME'};
                my ( $msgCanoeEnable, $msgCanoeDlc, $msgCanoeTiming, $msgCanoeCrc, $msgCanoeCnt );
                if ( $var_type =~ /^System$/i ) {
                    $msgCanoeEnable = "LIFT_NET_Access::SysVar_" . $bus_type . $bus_number . "_" . $msg_name . "_Enable";
                    $msgCanoeDlc    = "LIFT_NET_Access::SysVar_" . $bus_type . $bus_number . "_" . $msg_name . "_Dlc";
                    $msgCanoeTiming = "LIFT_NET_Access::SysVar_" . $bus_type . $bus_number . "_" . $msg_name . "_CycleTime";
                    $msgCanoeCrc    = "LIFT_NET_Access::SysVar_" . $bus_type . $bus_number . "_" . $msg_name . "_ValidCRC";
                    $msgCanoeCnt    = "LIFT_NET_Access::SysVar_" . $bus_type . $bus_number . "_" . $msg_name . "_ValidCnt";
                }
                else {

                    my $unique_msg_envvar = "E_" . uc( substr( $bus_type, 0, 1 ) ) . $bus_number . $msg_name;
                    $msgCanoeEnable = Create_short_Env_name( $unique_msg_envvar, '_Enable' );
                    $msgCanoeDlc    = Create_short_Env_name( $unique_msg_envvar, '_Dlc' );
                    $msgCanoeTiming = Create_short_Env_name( $unique_msg_envvar, '_CycleTime' );
                    $msgCanoeCrc    = Create_short_Env_name( $unique_msg_envvar, '_ValidCRC' );
                    $msgCanoeCnt    = Create_short_Env_name( $unique_msg_envvar, '_ValidCnt' );
                }
                push @$sysEnvvar_arr, [ $msgCanoeEnable, 'int' ];
                push @$sysEnvvar_arr, [ $msgCanoeDlc,    'int' ];
                push @$sysEnvvar_arr, [ $msgCanoeTiming, 'int' ];
                push @$sysEnvvar_arr, [ $msgCanoeCrc,    'int' ];
                push @$sysEnvvar_arr, [ $msgCanoeCnt,    'int' ];

                $db_msg_info->{'CycleTime'} = 10 unless ( $db_msg_info->{'CycleTime'} );
                my $msg_in_mapping = "$bus_type$bus_number\:\:$msg_name";

                #Store the Env/Sysvar in the hash
                $db_msg_info->{'CANOE_ENABLE'}    = $msgCanoeEnable;
                $db_msg_info->{'CANOE_DLC'}       = $msgCanoeDlc;
                $db_msg_info->{'CANOE_CYCLETIME'} = $msgCanoeTiming;
                $db_msg_info->{'CANOE_VALIDCRC'}  = $msgCanoeCrc;
                $db_msg_info->{'CANOE_VALIDCNT'}  = $msgCanoeCnt;

                S_w2outfile("      '$msg_in_mapping' => { \n");
                if ( $bus_type =~ /^FlexRay$/i ) {

                    #In case of flexray ID => Slot id(can be identical for multiple PDU's).
                    S_w2outfile("                                'ID'                => $db_msg_info->{'SLOT'}, \n");
                }
                else {
                    S_w2outfile("                                'ID'                => $msg_ID, \n");
                }
                S_w2outfile("                                'DLC'               => $db_msg_info->{'DLC'}, \n");
                S_w2outfile("                                'SENDER'            => '$db_msg_info->{'SENDER'}', \n");
                S_w2outfile("                                'CYCLE'             => $db_msg_info->{'CycleTime'}, \n");
                S_w2outfile("                                'CANOE_ENABLE'      => '$msgCanoeEnable', \n");
                S_w2outfile("                                'CANOE_DLC'         => '$msgCanoeDlc', \n");
                S_w2outfile("                                'CANOE_CYCLETIME'   => '$msgCanoeTiming', \n");
                S_w2outfile("                                'CANOE_VALIDCRC'    => '$msgCanoeCrc', \n");
                S_w2outfile("                                'CANOE_VALIDCNT'    => '$msgCanoeCnt', \n");
                S_w2outfile("                            },\n\n");

                if ( exists $msg_hash{$msg_in_mapping} ) {

                    #Store thr duplicate entry into hash
                    push( @duplicate_msgs_arr, $msg_in_mapping );
                }
                else {
                    #store thr msg names
                    $msg_hash{$msg_in_mapping} = 1;
                }
            }
            S_w2outfile("      },\n");    #End of Message section
        }
    }

    S_w2outfile("## --- Signal List (msg by msg , IDs ascending) of System under Test node \n\n");
    S_w2outfile("############################################# \n\n");
    foreach my $bus_number ( sort keys %$db_content_hef ) {
        foreach my $db_file_name ( keys %{ $db_content_hef->{$bus_number} } ) {
            foreach my $msg_ID ( sort { $a <=> $b } keys %{ $db_content_hef->{$bus_number}{$db_file_name} } ) {
                my $db_msg_info = $db_content_hef->{$bus_number}{$db_file_name}{$msg_ID};
                my $msg_name    = $db_msg_info->{'NAME'};
                my $msgIdHex    = sprintf( "0x%x", int $msg_ID );

                S_w2outfile("# -------------------------------------------------------------------------------------- \n\n");
                S_w2outfile("# ----------- $bus_type MESSAGE: $bus_type$bus_number\:\:$msg_name ID: $msg_ID ($msgIdHex), DB File name :$db_file_name ------------- \n\n");
                S_w2outfile("# -------------------------------------------------------------------------------------- \n\n");

                foreach my $signalName ( sort keys %{ $db_msg_info->{'SIGNALS'} } ) {
                    my $full_qualified_signal_name = "$bus_type$bus_number\:\:$msg_name\:\:$signalName" ; 
                    
                    my $multiplex_Master = $db_msg_info->{'SIGNALS'}{$signalName}{'MULTIPLEXER'};
                    my $multiplex_Code   = $db_msg_info->{'SIGNALS'}{$signalName}{'MULTIPLEX_VALUE'};

                    my $dbcSig_Multiplex;
                    if ( defined $multiplex_Master ) {
                        $dbcSig_Multiplex = "{ 'MASTER' => '$full_qualified_signal_name' }";
                    }
                    elsif ( defined $multiplex_Code ) {
                        if ( $multiplex_Master = $db_msg_info->{"MULTIPLEXER"} ) {
                            my $multiplex_Master_qualSigName = "$bus_type$bus_number\:\:$msg_name\:\:$multiplex_Master" ; 
                            $dbcSig_Multiplex = "{ 'MASTER' => '$multiplex_Master_qualSigName' , 'CODE' => $multiplex_Code }";
                        }
                        else { $dbcSig_Multiplex = "{ 'ERROR' => 'NO_MASTER_FOUND' }"; }
                    }
                    else { $dbcSig_Multiplex = 'undef'; }
                    my $vectorVarSignalName;
                    if ( $var_type =~ /^System$/i ) {
                        $vectorVarSignalName = "LIFT_NET_Access::SysVar_" . $bus_type . $bus_number . "_" . $msg_name . "_" . $signalName;
                    }
                    elsif ( $var_type =~ /^Environment$/i ) {
                        my $unique_sig_envvar = "E_" . uc( substr( $bus_type, 0, 1 ) ) . $bus_number . "ID$msg_ID" . $signalName;
                        $vectorVarSignalName = Create_short_Env_name($unique_sig_envvar);
                    }
                    push @$sysEnvvar_arr, [ $vectorVarSignalName, 'double' ];
                    $db_msg_info->{'SIGNALS'}{$signalName}{'CANOE_WR_SIGNAL'} = $vectorVarSignalName;

                    S_w2outfile("  '$full_qualified_signal_name'  => { \n");
                    S_w2outfile("           'CANOE_WR_SIGNAL'  => '$vectorVarSignalName', \n");
                    S_w2outfile("           'MULTIPLEX'     =>  $dbcSig_Multiplex, \n");
                    S_w2outfile("           'STARTBIT'      =>  $db_msg_info->{'SIGNALS'}{$signalName}{'POSITION'}, \n");
                    S_w2outfile("           'LENGTH'        =>  $db_msg_info->{'SIGNALS'}{$signalName}{'LENGTH'}, \n");
                    S_w2outfile("           'OFFSET'        =>  $db_msg_info->{'SIGNALS'}{$signalName}{'OFFSET'}, \n");
                    S_w2outfile("           'FACTOR'        =>  $db_msg_info->{'SIGNALS'}{$signalName}{'FACTOR'}, \n");
                    S_w2outfile("           'FORMAT'        => '$db_msg_info->{'SIGNALS'}{$signalName}{'FORMAT'}', \n");
                    S_w2outfile("           'TYPE'          => '$db_msg_info->{'SIGNALS'}{$signalName}{'TYPE'}', \n");
                    S_w2outfile("           'UNIT'          => '$db_msg_info->{'SIGNALS'}{$signalName}{'UNIT'}', \n");
                    S_w2outfile("       },\n\n");
                }
            }
        }
    }
    S_w2outfile("};\n# end of $bus_type mapping\n\n1;\n");

    S_w2log( "Mapping Datastructure: " . Dumper($db_content_hef) );

    if ( $var_type eq 'System' && $yesOrno eq 'Yes' ) {
        $output_sysenvvar_file = 'NET_Access_SysVar.xml';
        Write_to_sysvar_xml_file( $sysEnvvar_arr, $output_sysenvvar_file );
    }
    elsif ( $var_type eq 'Environment' && $yesOrno eq 'Yes' ) {
        $output_sysenvvar_file = 'NET_Access_EnvVar.dbc';
        Write_envvar_to_database_file( $sysEnvvar_arr, $output_sysenvvar_file );
    }

    if ( scalar @duplicate_msgs_arr ) {
        my $error_text = "! Thsese Msgs/Frames/PDUs were found in both database files :\n " . join( "\n", @duplicate_msgs_arr ) . " \n Written those to mapping files!!!! ";
        S_w2log($error_text);
        Create_ErrorMsgBox($error_text);
    }
    return;
}

sub S_w2log {
    my $text = shift;
    print LOG $text;
    return;
}

sub S_w2outfile {
    my $text = shift;
    print OUTFILE $text;
    return;
}

sub Create_short_Env_name {
    my $msgOrsignal_name = shift;
    my $suffix           = shift;

    my $max_size       = 32;
    my $shortened_size = $max_size - length($suffix);
    my $short_env_name;
    if ( length($msgOrsignal_name) > $shortened_size ) {

        #add a unique cut value
        $cut++;
        $short_env_name = substr( $msgOrsignal_name, 0, ( $shortened_size - length($cut) ) );
        $short_env_name .= $cut;
    }
    else {
        $short_env_name = $msgOrsignal_name;
    }
    $short_env_name = $short_env_name . $suffix if ($suffix);
    S_w2log(" Create_short_Env_name : $msgOrsignal_name -> $short_env_name \n");
    return $short_env_name;
}

###########################################################################################

#    Process_csv_file( );
#    Reads the .csv file and extracts the raw content and stores it in hash reference.

##########################################################################################
sub Validate_and_process_csv_file {

    my $csv_file = shift;

    #my @mandatory_fields = ( 'SIGNAL', 'PDU', 'BYTES', 'LENGTH', 'BITPOS', 'CYCLE', 'TYPE', 'FORMAT', 'SCALE_OFFSET', 'TRANSMITTER', 'FRAME', 'DEFAULTVALUE' );
    my %mandatory_fields = (
        'SIGNAL'       => 'Name or Signal',
        'PDU'          => 'PDU',
        'FRAME'        => 'Frame',
        'BITPOS'       => 'Signal Pos. [Bit] or Signal Position',
        'LENGTH'       => 'Length [Bit]',
        'FORMAT'       => 'Byte Order',
        'SCALE_OFFSET' => 'Computation or Computation Method',
        'TRANSMITTER'  => 'Transmitter',
        'BYTES'        => 'Slot',
        'CYCLE'        => 'ms or Cycle Time [ms]',
    );

    S_w2log("Sub: Validate_and_process_csv_file: $csv_file\n\n");

    my ( @columns, %flexray_data_href );
    my $line_num = 0;    #For extracting the column i.e. the First row

    #Opens the .csv file
    open( my $csv_FH, "<", $csv_file ) or die "Could not open '$csv_file' $!\n";

    while ( my $line = <$csv_FH> ) {
        if ( $line_num == 0 ) {
            map { $_ =~ s/"//g; push( @columns, $_ ); } split( /;/, $line );
            if ( ( scalar(@columns) <= 1 ) ) {
                my $error_txt = "ERROR : Please check the format of the .csv file generated from FIBEX/AUTOSAR explorer, It should be a ';' separated file\n\n ";
                Create_ErrorMsgBox($error_txt);
                return;
            }

            # manipulate the required column name for better readability
            map {
                $_ =~ s/^(.{3})?Name$/SIGNAL/;
                $_ =~ s/^(.{3})?Signal$/SIGNAL/;
                $_ =~ s/^Slot$/BYTES/;
                $_ =~ s/^Length \[Bit\]$/LENGTH/;
                $_ =~ s/^Signal\sPos\.\s\[Bit\]$/BITPOS/;
                $_ =~ s/^Signal\sPosition$/BITPOS/;
                $_ =~ s/^ms$/CYCLE/;
                $_ =~ s/^Cycle\sTime\s\[ms\]$/CYCLE/;
                $_ =~ s/^Coded\sType$/TYPE/;
                $_ =~ s/^Byte\sOrder$/FORMAT/;
                $_ =~ s/^Computation$/SCALE_OFFSET/;
                $_ =~ s/^Computation\sMethod$/SCALE_OFFSET/;
                $_ =~ s/^Transmitter$/TRANSMITTER/;
                $_ =~ s/^Senders$/TRANSMITTER/;
                $_ =~ s/^Frame$/FRAME/;
                $_ =~ s/^Default\sValue$/DEFAULTVALUE/;
            } @columns;

            $line_num++;
            next;
        }

        my @fields;
        map { $_ =~ s/"//g; push( @fields, $_ ); } split( /;/, $line );    #Fetch the data and remove the invisible unwanted characters like ï»¿  $_ =~ s/ï»¿//g;

        if ( ( scalar(@fields) <= 1 ) ) {
            my $error_txt = "ERROR : *.csv file is not semicolan ';' seperated. Please recreate it using Fibex / Autosar Explorer\n\n ";
            Create_ErrorMsgBox($error_txt);
            return;
        }

        my @validate_fields = grep {
            my $x = $_;
            not grep { $x =~ /^$_$/ } @columns
        } keys %mandatory_fields;

        #validate whether the required columns needed for flexray mapping file is present in the .csv file
        if ( scalar(@validate_fields) ) {

            my $error_txt = "ERROR : Mandatory Columns ";
            map { $error_txt = $error_txt . "'" . $mandatory_fields{$_} . "', " } @validate_fields;
            $error_txt = $error_txt . " are not present in the .csv file. Please recreate it using Fibex / Autosar Explorer \n\n";
            Create_ErrorMsgBox($error_txt);
            return;
        }

        #Synchronise the column and the data
        my %data_hash;
        @data_hash{@columns} = @fields;
        $flexray_data_href{ $line_num++ } = \%data_hash;

    }
    close $csv_FH;

    return \%flexray_data_href;
}

sub Create_ErrorMsgBox {
    my $error_msg = shift;
    $main->messageBox(
        '-icon'    => "error",
        '-type'    => "OK",
        '-title'   => 'Error',
        '-message' => $error_msg,
    );
    return 1;
}

sub Validate_arguments {
    my @args = shift;
    $opt_db_file_1 =~ s/\s+//g;
    $opt_db_file_2 =~ s/\s+//g;

    my $error_text;
    if ( defined $opt_db_file_1 && $opt_db_file_1 ne '' ) {
        unless ( -f $opt_db_file_1 ) {
            $error_text = "Error!! database file($opt_db_file_1) doesnt exists!!..\n";
            S_w2log($error_text);
            Create_ErrorMsgBox($error_text);
            $opt_db_file_1 = undef;
            return;
        }
        if ( $opt_db_file_1 !~ /.(dbc|csv|ldf)$/i ) {
            $error_text = "Invalid database file ($opt_db_file_1) specified. It can be one among .dbc,.csv and .ldf!!..\n";
            S_w2log($error_text);
            Create_ErrorMsgBox($error_text);
            $opt_db_file_1 = undef;
            return;
        }
        if ( defined $opt_db_file_2 && $opt_db_file_2 ne '' ) {
            unless ( -f $opt_db_file_2 ) {
                $error_text = "Error!! database file($opt_db_file_2) doesnt exists!!..\n";
                S_w2log($error_text);
                Create_ErrorMsgBox($error_text);
                $opt_db_file_2 = undef;
                return;
            }
            if ( $opt_db_file_2 eq $opt_db_file_1 && $busNum_2 eq $busNum_1 ) {
                $error_text = "! File $opt_db_file_1 with BUS Number $busNum_1 has already been selected for Mapping file generation!!!\n Please choose different database file/bus number! ";
                Create_ErrorMsgBox($error_text);
                $opt_db_file_2 = undef;
                return;
            }
            if ( $opt_db_file_2 !~ /.(dbc|csv|ldf)$/i ) {
                $error_text = "Invalid database file($opt_db_file_2) specified. It can be one among .dbc,.csv and .ldf!!..\n";
                S_w2log($error_text);
                Create_ErrorMsgBox($error_text);
                $opt_db_file_2 = undef;
                return;
            }
            my ( $suffix1, $suffix2 );
            $opt_db_file_1 =~ /\.(.+)$/;
            $suffix1 = $1;
            $opt_db_file_2 =~ /\.(.+)$/;
            $suffix2 = $1;
            unless ( $suffix1 =~ /^$suffix2$/i ) {
                $error_text = "! Both the database file should have the same extension!!!\n Please choose different files! ";
                Create_ErrorMsgBox($error_text);
                $opt_db_file_2 = undef;
                return;
            }

        }
    }
    return 1;
}

sub Write_to_sysvar_xml_file {
    my $sysvar_aref = shift;
    my $sysvar_file = shift;

    # STEP Validate SysVar out file (.xml) to be generated
    # STEP Open the SysVar out file(.xml) in the write mode
    # STEP Fetch each System variable available
    # STEP Identify the data type of the System variable
    # STEP Write the System variable information into the xml output file
    # STEP Close the out file handle
    # STEP END

    my $xmlheader = <<XMLHEADER;
<?xml version="1.0" encoding="utf-8"?>
<systemvariables version="4">
    <namespace name="" comment="">
        <namespace name="LIFT_NET_Access" comment="">
XMLHEADER
    open( my $sysvar_fh, '+>', $sysvar_file ) or die "Could not open file '$sysvar_file' $!";    #SYSVAR file
    print $sysvar_fh $xmlheader;

    foreach my $sysvar_data (@$sysvar_aref) {
        my ( $sysvar, $datatype ) = @$sysvar_data;
        my ( $namespace, $sysvar_name ) = split( /::/, $sysvar );

        my $sysvar_line;
        if ( $datatype =~ /^int$/i ) {
            $sysvar_line = <<INILINE;
                <variable anlyzLocal="2" readOnly="false" valueSequence="false" unit="" name="$sysvar_name" comment="" bitcount="32" isSigned="false" encoding="65001" type="int" />
INILINE
        }
        else {
            $sysvar_line = <<DOUBLELINE;
                <variable anlyzLocal="2" readOnly="false" valueSequence="false" unit="" name="$sysvar_name" comment="" bitcount="64" isSigned="true" encoding="65001" type="float" />
DOUBLELINE

        }
        print $sysvar_fh $sysvar_line;

    }
    my $xmlfooter = <<XMLFOOTER;
        </namespace>
    </namespace>
</systemvariables>
XMLFOOTER
    print $sysvar_fh $xmlfooter;
    close($sysvar_fh);
    return 1;

}

sub Write_envvar_to_database_file {
    my $envvar_aref = shift;
    my $envvar_file = shift;

    # STEP Validate Env out file (.dbc) to be generated
    # STEP Open the Env out file(.dbc) in the write mode
    # STEP Fetch each Env variable available
    # STEP Identify the data type of the Env variable
    # STEP Write the ENV variable information into the dbc output file
    # STEP Close the out file handle
    # STEP END

    my $dbcdata = <<DBCDATA;
VERSION ""


NS_ : 
    NS_DESC_
    CM_
    BA_DEF_
    BA_
    VAL_
    CAT_DEF_
    CAT_
    FILTER
    BA_DEF_DEF_
    EV_DATA_
    ENVVAR_DATA_
    SGTYPE_
    SGTYPE_VAL_
    BA_DEF_SGTYPE_
    BA_SGTYPE_
    SIG_TYPE_REF_
    VAL_TABLE_
    SIG_GROUP_
    SIG_VALTYPE_
    SIGTYPE_VALTYPE_
    BO_TX_BU_
    BA_DEF_REL_
    BA_REL_
    BA_DEF_DEF_REL_
    BU_SG_REL_
    BU_EV_REL_
    BU_BO_REL_
    SG_MUL_VAL_

BS_:

BU_:

DBCDATA
    open( my $envvar_fh, '+>', $envvar_file ) or die "Could not open file '$envvar_file' $!";    #ENVVAR file
    my $datatype_lookup = { 'int' => 0, 'double' => 1 };
    print $envvar_fh $dbcdata;
    my $env_id = 1;
    foreach my $envvar_data (@$envvar_aref) {
        my ( $envvar, $datatype ) = @$envvar_data;
        my $envvar_line = <<ENVVARLINE;
EV_ $envvar: $datatype_lookup->{$datatype} [0|0] "" 0 $env_id DUMMY_NODE_VECTOR0 Vector__XXX;
ENVVARLINE
        $env_id++;
        print $envvar_fh $envvar_line;
    }
    close($envvar_fh);
    return 1;

}

1;
