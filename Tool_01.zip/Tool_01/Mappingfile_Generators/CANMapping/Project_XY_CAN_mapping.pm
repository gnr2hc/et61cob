### file generated with Mappingfile_Generators/CANMapping/LIFT_prepare_CAN_mapping.pl 1.8 2017/06/15 15:29:22IST Prabhu Pallavi Maruti (RBEI/ESA-PP3) (RBP6KOR) release  
### input dbc files:
### C:/TurboLIFT/Tools/Mappingfile_Generators/CANMapping/COMDemo.dbc
package LIFT_PROJECT;

$Defaults->{"Mapping_CAN"} = {
'NODE_UNDER_TEST'       => 'Airbag',

'Diag_Byte_1'  =>
               {
               'SIGNAL_NAME'   => 'Diag_Byte_1',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Can_ABECU_2_Diag',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 7, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               },

'Diag_Byte_2'  =>
               {
               'SIGNAL_NAME'   => 'Diag_Byte_2',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Can_ABECU_2_Diag',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 15, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               },
'Diag_Byte_3'  =>
               {
               'SIGNAL_NAME'   => 'Diag_Byte_3',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Can_ABECU_2_Diag',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 23, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               },
'Diag_Byte_4'  =>
               {
               'SIGNAL_NAME'   => 'Diag_Byte_4',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Can_ABECU_2_Diag',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 31, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               },
'Diag_Byte_5'  =>
               {
               'SIGNAL_NAME'   => 'Diag_Byte_5',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Can_ABECU_2_Diag',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 39, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               },
'Diag_Byte_6'  =>
               {
               'SIGNAL_NAME'   => 'Diag_Byte_6',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Can_ABECU_2_Diag',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 47, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               },
'Diag_Byte_7'  =>
               {
               'SIGNAL_NAME'   => 'Diag_Byte_7',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Can_ABECU_2_Diag',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 55, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               },
'Diag_Byte_8'  =>
               {
               'SIGNAL_NAME'   => 'Diag_Byte_8',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Can_ABECU_2_Diag',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 63, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               },

'PD_req_2' =>
               {
               'SIGNAL_NAME'   => 'PD_req_2',  
               'SENDER'        => 'Tester',
               'MESSAGE'       => 'Can_PDiag_2_ABECU',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 15, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               },

'CAN_MESSAGES'  => {
       'MLC_A3'  =>
                      {
                        'ID'            => 163,
                        'DLC'           => 6,
                        'SENDER'        => 'MLC',
                        'CAN_BUS_NBR'   => 2,
                        'CYCLE'         => 10,
                      },
       'MLC_A2'  =>
                      {
                        'ID'            => 162,
                        'DLC'           => 6,
                        'SENDER'        => 'MLC',
                        'CAN_BUS_NBR'   => 2,
                        'CYCLE'         => 10,
                      },
       'MLC_A1'  =>
                      {
                        'ID'            => 161,
                        'DLC'           => 6,
                        'SENDER'        => 'MLC',
                        'CAN_BUS_NBR'   => 2,
                        'CYCLE'         => 10,
                      },
       'MLC_A4'  =>
                      {
                        'ID'            => 164,
                        'DLC'           => 6,
                        'SENDER'        => 'MLC',
                        'CAN_BUS_NBR'   => 2,
                        'CYCLE'         => 10,
                      },
       'MLC_110'  =>
                      {
                        'ID'            => 272,
                        'DLC'           => 6,
                        'SENDER'        => 'MLC',
                        'CAN_BUS_NBR'   => 2,
                        'CYCLE'         => 10,
                      },
       'IDX_101'  =>
                      {
                        'ID'            => 257,
                        'DLC'           => 6,
                        'SENDER'        => 'IDX',
                        'CAN_BUS_NBR'   => 2,
                        'CYCLE'         => 10,
                      },
       'IDX_102'  =>
                      {
                        'ID'            => 258,
                        'DLC'           => 6,
                        'SENDER'        => 'IDX',
                        'CAN_BUS_NBR'   => 2,
                        'CYCLE'         => 10,
                      },
       'IDX_201'  =>
                      {
                        'ID'            => 513,
                        'DLC'           => 6,
                        'SENDER'        => 'IDX',
                        'CAN_BUS_NBR'   => 2,
                        'CYCLE'         => 10,
                      },
       'IDX_202'  =>
                      {
                        'ID'            => 514,
                        'DLC'           => 6,
                        'SENDER'        => 'IDX',
                        'CAN_BUS_NBR'   => 2,
                        'CYCLE'         => 10,
                      },

       'MsgStimulus1_CAN'  =>
                      {
                        'ID'            => 0,
                        'DLC'           => 8,
                        'SENDER'        => 'Stimulus1_CAN',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 100,
                        'CANOE_DISABLE' => 'EnvMsgStimulus1_CANTo_' ,
                        'CANOE_DLC'     => 'EnvMsgStimulus1_CANDlc_' ,
                        'CANOE_TIMING'  => 'EnvMsgStimulus1_CANTime_' ,
                      },
       'MsgResponse1_CAN'  =>
                      {
                        'ID'            => 1,
                        'DLC'           => 1,
                        'SENDER'        => 'Response1_CAN',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 10,
                        'CANOE_DISABLE' => 'EnvMsgResponse1_CANTo_' ,
                        'CANOE_DLC'     => 'EnvMsgResponse1_CANDlc_' ,
                        'CANOE_TIMING'  => 'EnvMsgResponse1_CANTime_' ,
                      },
       'MsgStimulus2_CAN'  =>
                      {
                        'ID'            => 2,
                        'DLC'           => 2,
                        'SENDER'        => 'Stimulus2_CAN',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 100,
                        'CANOE_DISABLE' => 'EnvMsgStimulus2_CANTo_' ,
                        'CANOE_DLC'     => 'EnvMsgStimulus2_CANDlc_' ,
                        'CANOE_TIMING'  => 'EnvMsgStimulus2_CANTime_' ,
                      },
       'MsgStimulus3_CAN'  =>
                      {
                        'ID'            => 3,
                        'DLC'           => 2,
                        'SENDER'        => 'Stimulus2_CAN',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 20,
                        'CANOE_DISABLE' => 'EnvMsgStimulus3_CANTo_' ,
                        'CANOE_DLC'     => 'EnvMsgStimulus3_CANDlc_' ,
                        'CANOE_TIMING'  => 'EnvMsgStimulus3_CANTime_' ,
                      },
       'MsgStimulus4_CAN'  =>
                      {
                        'ID'            => 4,
                        'DLC'           => 5,
                        'SENDER'        => 'Stimulus2_CAN',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 20,
                        'CANOE_DISABLE' => 'EnvMsgStimulus4_CANTo_' ,
                        'CANOE_DLC'     => 'EnvMsgStimulus4_CANDlc_' ,
                        'CANOE_TIMING'  => 'EnvMsgStimulus4_CANTime_' ,
                      },
       'Msg_chk_IL'  =>
                      {
                        'ID'            => 5,
                        'DLC'           => 1,
                        'SENDER'        => 'Check_IL',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 20,
                        'CANOE_DISABLE' => 'EnvMsg_chk_ILTo_' ,
                        'CANOE_DLC'     => 'EnvMsg_chk_ILDlc_' ,
                        'CANOE_TIMING'  => 'EnvMsg_chk_ILTime_' ,
                      },
       'MSG_MULTIPLEXER_CHECK'  =>
                      {
                        'ID'            => 6,
                        'DLC'           => 8,
                        'SENDER'        => 'Stimulus1_CAN',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 200,
                        'CANOE_DISABLE' => 'EnvMSG_MULTIPLEXER_CHECKTo_' ,
                        'CANOE_DLC'     => 'EnvMSG_MULTIPLEXER_CHECKDlc_' ,
                        'CANOE_TIMING'  => 'EnvMSG_MULTIPLEXER_CHECKTime_' ,
                      },
       'MSG_same_CAN_LIN'  =>
                      {
                        'ID'            => 7,
                        'DLC'           => 1,
                        'SENDER'        => 'Vector__XXX',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 10,
                        'CANOE_DISABLE' => 'EnvMSG_same_CAN_LINTo_' ,
                        'CANOE_DLC'     => 'EnvMSG_same_CAN_LINDlc_' ,
                        'CANOE_TIMING'  => 'EnvMSG_same_CAN_LINTime_' ,
                      },
           },

############################################# 

## --- Signal List (msg by msg , IDs ascending) of System under Test node 

############################################# 

## Signal List (msg by msg , IDs ascending) from Simulator 

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: MsgStimulus1_CAN (Stimulus1_CAN) ID: 0 (0x0), DBC File name :COMDemo ------------- 

# -------------------------------------------------------------------------------------- 

'SigStimulus1_CAN' =>
               {
               'SIGNAL_NAME'   => 'SigStimulus1_CAN',      'CANOE_ENV_VAR' => 'EnvSigStimulus1_CAN_',
               'SENDER'        => 'Stimulus1_CAN',
               'MESSAGE'       => 'MsgStimulus1_CAN',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 0, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 2.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'SigStimulus1_CAN.MsgStimulus1_CAN.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'SigStimulus1_CAN.MsgStimulus1_CAN.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'SigTimed1_CAN' =>
               {
               'SIGNAL_NAME'   => 'SigTimed1_CAN',      'CANOE_ENV_VAR' => 'EnvSigTimed1_CAN_',
               'SENDER'        => 'Stimulus1_CAN',
               'MESSAGE'       => 'MsgStimulus1_CAN',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 16, 'LENGTH' => 16, 'OFFSET' => 10.000000, 'FACTOR' => 0.100000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'SigTimed1_CAN.MsgStimulus1_CAN.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'SigTimed1_CAN.MsgStimulus1_CAN.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 2 => '0b11111111' , 3 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'SigTimed2_CAN' =>
               {
               'SIGNAL_NAME'   => 'SigTimed2_CAN',      'CANOE_ENV_VAR' => 'EnvSigTimed2_CAN_',
               'SENDER'        => 'Stimulus1_CAN',
               'MESSAGE'       => 'MsgStimulus1_CAN',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 32, 'LENGTH' => 32, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'SigTimed2_CAN.MsgStimulus1_CAN.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'SigTimed2_CAN.MsgStimulus1_CAN.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 4 => '0b11111111' , 5 => '0b11111111' , 6 => '0b11111111' , 7 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'MsgStimulus1_CAN::Signal_sameName_CAN_LIN_FR_1' =>
               {
               'SIGNAL_NAME'   => 'Signal_sameName_CAN_LIN_FR_1',      'CANOE_ENV_VAR' => 'EnvSignal_sameName_CAN_LIN_FR_1_',
               'SENDER'        => 'Stimulus1_CAN',
               'MESSAGE'       => 'MsgStimulus1_CAN',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 8, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Signal_sameName_CAN_LIN_FR_1.MsgStimulus1_CAN.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Signal_sameName_CAN_LIN_FR_1.MsgStimulus1_CAN.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: MsgResponse1_CAN (Response1_CAN) ID: 1 (0x1), DBC File name :COMDemo ------------- 

# -------------------------------------------------------------------------------------- 

'SigResponse1_CAN' =>
               {
               'SIGNAL_NAME'   => 'SigResponse1_CAN',      'CANOE_ENV_VAR' => 'EnvSigResponse1_CAN_',
               'SENDER'        => 'Response1_CAN',
               'MESSAGE'       => 'MsgResponse1_CAN',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 0, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'SigResponse1_CAN.MsgResponse1_CAN.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'SigResponse1_CAN.MsgResponse1_CAN.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: MsgStimulus2_CAN (Stimulus2_CAN) ID: 2 (0x2), DBC File name :COMDemo ------------- 

# -------------------------------------------------------------------------------------- 

'SigStimulus2_CAN' =>
               {
               'SIGNAL_NAME'   => 'SigStimulus2_CAN',      'CANOE_ENV_VAR' => 'EnvSigStimulus2_CAN_',
               'SENDER'        => 'Stimulus2_CAN',
               'MESSAGE'       => 'MsgStimulus2_CAN',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 0, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'SigStimulus2_CAN.MsgStimulus2_CAN.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'SigStimulus2_CAN.MsgStimulus2_CAN.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'MsgStimulus2_CAN::Signal_sameName_CAN_LIN_FR_1' =>
               {
               'SIGNAL_NAME'   => 'Signal_sameName_CAN_LIN_FR_1',      'CANOE_ENV_VAR' => 'EnvSignal_sameName_CAN_LIN_FR_1_',
               'SENDER'        => 'Stimulus2_CAN',
               'MESSAGE'       => 'MsgStimulus2_CAN',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 8, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Signal_sameName_CAN_LIN_FR_1.MsgStimulus2_CAN.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Signal_sameName_CAN_LIN_FR_1.MsgStimulus2_CAN.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: MsgStimulus3_CAN (Stimulus2_CAN) ID: 3 (0x3), DBC File name :COMDemo ------------- 

# -------------------------------------------------------------------------------------- 

'SigStimulus3_CAN' =>
               {
               'SIGNAL_NAME'   => 'SigStimulus3_CAN',      'CANOE_ENV_VAR' => 'EnvSigStimulus3_CAN_',
               'SENDER'        => 'Stimulus2_CAN',
               'MESSAGE'       => 'MsgStimulus3_CAN',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 0, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'SigStimulus3_CAN.MsgStimulus3_CAN.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'SigStimulus3_CAN.MsgStimulus3_CAN.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'MsgStimulus3_CAN::Signal_sameName_CAN_LIN_FR_1' =>
               {
               'SIGNAL_NAME'   => 'Signal_sameName_CAN_LIN_FR_1',      'CANOE_ENV_VAR' => 'EnvSignal_sameName_CAN_LIN_FR_1_',
               'SENDER'        => 'Stimulus2_CAN',
               'MESSAGE'       => 'MsgStimulus3_CAN',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 8, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Signal_sameName_CAN_LIN_FR_1.MsgStimulus3_CAN.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Signal_sameName_CAN_LIN_FR_1.MsgStimulus3_CAN.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: MsgStimulus4_CAN (Stimulus2_CAN) ID: 4 (0x4), DBC File name :COMDemo ------------- 

# -------------------------------------------------------------------------------------- 

'SigStimulus4_CAN' =>
               {
               'SIGNAL_NAME'   => 'SigStimulus4_CAN',      'CANOE_ENV_VAR' => 'EnvSigStimulus4_CAN_',
               'SENDER'        => 'Stimulus2_CAN',
               'MESSAGE'       => 'MsgStimulus4_CAN',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 32, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'SigStimulus4_CAN.MsgStimulus4_CAN.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'SigStimulus4_CAN.MsgStimulus4_CAN.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 4 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'MsgStimulus4_CAN::Signal_sameName_CAN_LIN_FR_1' =>
               {
               'SIGNAL_NAME'   => 'Signal_sameName_CAN_LIN_FR_1',      'CANOE_ENV_VAR' => 'EnvSignal_sameName_CAN_LIN_FR_1_',
               'SENDER'        => 'Stimulus2_CAN',
               'MESSAGE'       => 'MsgStimulus4_CAN',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 0, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Signal_sameName_CAN_LIN_FR_1.MsgStimulus4_CAN.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Signal_sameName_CAN_LIN_FR_1.MsgStimulus4_CAN.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: Msg_chk_IL (Check_IL) ID: 5 (0x5), DBC File name :COMDemo ------------- 

# -------------------------------------------------------------------------------------- 

'Sig_ChkIL_CAN' =>
               {
               'SIGNAL_NAME'   => 'Sig_ChkIL_CAN',      'CANOE_ENV_VAR' => 'EnvSig_ChkIL_CAN_',
               'SENDER'        => 'Check_IL',
               'MESSAGE'       => 'Msg_chk_IL',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 0, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Sig_ChkIL_CAN.Msg_chk_IL.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Sig_ChkIL_CAN.Msg_chk_IL.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: MSG_MULTIPLEXER_CHECK (Stimulus1_CAN) ID: 6 (0x6), DBC File name :COMDemo ------------- 

# -------------------------------------------------------------------------------------- 

'Sig_Test_Muliplexed_01' =>
               {
               'SIGNAL_NAME'   => 'Sig_Test_Muliplexed_01',      'CANOE_ENV_VAR' => 'EnvSig_Test_Muliplexed_01_',
               'SENDER'        => 'Stimulus1_CAN',
               'MESSAGE'       => 'MSG_MULTIPLEXER_CHECK',
               'MULTIPLEX'     => { 'MASTER' => 'Sig_Test_Muliplexor' , 'CODE' => 1 },
               'STARTBIT'      => 8, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Sig_Test_Muliplexed_01.MSG_MULTIPLEXER_CHECK.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Sig_Test_Muliplexed_01.MSG_MULTIPLEXER_CHECK.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'Sig_Test_Muliplexed_02' =>
               {
               'SIGNAL_NAME'   => 'Sig_Test_Muliplexed_02',      'CANOE_ENV_VAR' => 'EnvSig_Test_Muliplexed_02_',
               'SENDER'        => 'Stimulus1_CAN',
               'MESSAGE'       => 'MSG_MULTIPLEXER_CHECK',
               'MULTIPLEX'     => { 'MASTER' => 'Sig_Test_Muliplexor' , 'CODE' => 2 },
               'STARTBIT'      => 8, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Sig_Test_Muliplexed_02.MSG_MULTIPLEXER_CHECK.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Sig_Test_Muliplexed_02.MSG_MULTIPLEXER_CHECK.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'Sig_Test_Muliplexor' =>
               {
               'SIGNAL_NAME'   => 'Sig_Test_Muliplexor',      'CANOE_ENV_VAR' => 'EnvSig_Test_Muliplexor_',
               'SENDER'        => 'Stimulus1_CAN',
               'MESSAGE'       => 'MSG_MULTIPLEXER_CHECK',
               'MULTIPLEX'     => { 'MASTER' => 'Sig_Test_Muliplexor' },
               'STARTBIT'      => 0, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Sig_Test_Muliplexor.MSG_MULTIPLEXER_CHECK.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Sig_Test_Muliplexor.MSG_MULTIPLEXER_CHECK.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: MSG_same_CAN_LIN (Vector__XXX) ID: 7 (0x7), DBC File name :COMDemo ------------- 

# -------------------------------------------------------------------------------------- 

'MSG_same_CAN_LIN::Signal_sameName_CAN_LIN_FR_1' =>
               {
               'SIGNAL_NAME'   => 'Signal_sameName_CAN_LIN_FR_1',      'CANOE_ENV_VAR' => 'EnvSignal_sameName_CAN_LIN_FR_1_',
               'SENDER'        => 'Vector__XXX',
               'MESSAGE'       => 'MSG_same_CAN_LIN',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 0, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Signal_sameName_CAN_LIN_FR_1.MSG_same_CAN_LIN.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Signal_sameName_CAN_LIN_FR_1.MSG_same_CAN_LIN.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

};
# end of CAN mapping

1;
