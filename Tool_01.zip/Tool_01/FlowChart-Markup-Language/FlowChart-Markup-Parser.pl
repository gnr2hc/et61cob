package main;

# *****************************************************************************************************
#
#  Copyright (c) 2016  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#    $Source: FlowChart-Markup-Language/FlowChart-Markup-Parser.pl $
#    $Revision: 1.16 $
#    $Author: Prosch Christian (CC-PS/EPS2) (PHC2SI) $
#    $State: develop $
#    $Date: 2019/04/30 23:54:11ICT $
#******************************************************************************************************

use strict;
use warnings;
use Graphviz::DSL;
use Getopt::Long;
use File::Basename;
use File::Find;
use Text::Wrap;

our ( $VERSION, $HEADER );
$VERSION = q$Revision: 1.16 $;
$HEADER  = q$Header: FlowChart-Markup-Language/FlowChart-Markup-Parser.pl 1.16 2019/04/30 23:54:11ICT Prosch Christian (CC-PS/EPS2) (PHC2SI) develop  $;

$Text::Wrap::columns = 30;

my ( $markupTree_href, $nodeIndex, $markupIndex, $edgeIndex, @ifStack, @loopStack, @lastOpenStackCopy, $commentText, $commentStart );
my ( $podSection, $podSectionEndFound, $podText );

my $markupKeys = "STEP|IF|LOOP|CALL|COMMENT|END";

my $DefaultFilename = basename(__FILE__);

#COMMENT-START
# Usage:
# FlowChart-Markup-Parser.pl --file|-f <inputfile path> [ --output|-o <output format> ]
#
# inputfile path: if it is a file then it will be parsed
#                   if it is a folder then all .pl/.pm files in that folder and all sub-folders will be parsed
# output format: 'svg' (default), 'jpg', 'gif', 'pdf', ...
#
#
#Used global data structures:
#
#$markupTree_href holds all the found markups and the nodes and edges of the graph.
#$markupTree_href = {
#    'markups' => {
#    # all markups in the function with complete markup (type + text)
#        0 => { 'markup' => ...,},
#        1 => { 'markup' => ...,},
#        ...
#    },
#    'nodes' => {
#    # all nodes in the flowchart with markup type in 'markup' and text in 'text'
#        0 => { 'markup' => ..., 'text' => ...,},
#        1 => { 'markup' => ..., 'text' => ...,},
#        ...
#    },
#    'edges' => {
#    # all edges in the flowchart with start node, end node and tag
#        0 => { 'start' => ..., 'end' => ..., 'tag' => ...,},
#        1 => { 'start' => ..., 'end' => ..., 'tag' => ...,},
#        ...
#    },
#};
#
#@ifStack holds a list of nested if-conditions as stack.
#@ifStack = ($ifStackEntry1_href, $ifStackEntry2_href, ...);
#$ifStackEntry1_href = {
#   0 => { 'start' => ..., 'end' => ..., 'tag' => ...,}, # left branch of the if-condition
#   1 => { 'start' => ..., 'end' => ..., 'tag' => ...,}, # right branch of the if-condition
#};
#
#@loopStack holds a list of nested loop-conditions as stack.
#@loopStack = ($loopStackEntry1_href, $loopStackEntry2_href, ...);
#$loopStackEntry1_href = {
#    'start' => ...,
#};
#
#COMMENT-END

#STEP get command line options
my $options_href = { 'output' => 'svg' };
my $optionsFound = GetOptions( $options_href, "file=s", "output:s" );

if ( not $optionsFound or not defined $options_href->{'file'} ) {
    die("\n\nError in command line arguments!  run\n\n    $DefaultFilename --file|-f <inputfile path> [ --output|-o <output format> ]\n");
}

my $file   = $options_href->{'file'};
my $output = $options_href->{'output'};

#IF given inputfile path is a folder?
if ( -d $file ) {

    #IF-YES-START
    #CALL ProcessFileInDirectory for all files in the folder and its subfolders
    find( { wanted => \&ProcessFileInDirectory, no_chdir => 1 }, $file );

    #STEP remove all generated folders that are empty
    finddepth( sub { rmdir }, '.' );

    #IF-YES-END
}

#IF-NO-START
#IF given inputfile path is a file?
elsif ( -f $file ) {

    #IF-YES-START
    #CALL ProcessOneFile for the given given inputfile
    ProcessOneFile($file);

    #IF-YES-END
}
else {
    #IF-NO-START
    #STEP error and exit
    print "ERROR: Given input file '$file' does not exist!";
    exit(0);

    #IF-NO-END
}

#IF-NO-END
#STEP end
print("READY.\n");

#
# Subroutines
#

sub ProcessFileInDirectory {
    my $fileToProcess = $File::Find::name;

    #IF file extension is .pl or .pm?
    #IF-NO-START
    return if $fileToProcess !~ /\.p(l|m|y)/i;

    #IF-NO-END
    #IF-YES-START
    #CALL ProcessOneFile for the current file
    ProcessOneFile($fileToProcess);

    #IF-YES-END
    #STEP end
    return 1;
}

sub ProcessOneFile {
    my $fileToProcess = shift;

    print("Processing file '$fileToProcess'...\n");

    #STEP create a folder for output files for each input file
    my $directoryName = basename($fileToProcess);
    $directoryName =~ s/(\..*?)$//i;
    $directoryName = TrimString($directoryName);

    $directoryName =~ s/^(\s*)//;
    $directoryName =~ s/(\s*)$//;

    mkdir($directoryName);

    ResetDataStructures();

    #CALL ParseFile with file name and output folder name
    ParseFile( $fileToProcess, $directoryName );

    return 1;
}

sub ResetDataStructures {
    $markupTree_href                         = {};
    $nodeIndex                               = 0;
    $markupIndex                             = 0;
    $edgeIndex                               = 0;
    $markupTree_href->{'nodes'}{0}{'markup'} = 'START';
    $markupTree_href->{'nodes'}{0}{'text'}   = 'Start';
    @ifStack                                 = ();
    @loopStack                               = ();

    return 1;
}

sub ParseFile {

    my $fileToProcess = shift;
    my $directoryName = shift;

    #STEP get all lines from file
    open FILE, "<$fileToProcess" or die "Could not open file '$fileToProcess' $!";
    my @lines = <FILE>;
    close(FILE);

    my $currentSubName = "main";
    my $currentClassName;
    my $currentPodText;

    #LOOP-START loop over all lines in the file
    foreach my $line (@lines) {

        #CALL GetPOD4Function with the current line
        GetPOD4Function($line);

        #STEP store class name if 'class' is found in line
        if( $line =~ /^class\s+(\w+)/ ) {        	
            $currentClassName = $1;
        }

        #IF 'sub' or 'def' found in line?
        if ( $line =~ /^\s*(sub|def)\s+(\w+)/ ) {

            #IF-YES-START
            #CALL CreateGraph with name of last sub
            CreateGraph( $currentSubName, $directoryName, $currentPodText );

            #STEP reset data structures for new sub
            ResetDataStructures();

            my $subName = $2;
            $subName = TrimString($subName);            
            $subName = $currentClassName.'.'.$subName if defined $currentClassName;

            $currentSubName     = $subName;
            $currentPodText     = $podText;
            $podText            = undef;
            $podSection         = undef;
            $podSectionEndFound = undef;

            #IF-YES-END
        }

        #IF-NO-START
        #IF-NO-END

        if ($commentStart) {
            my $text = $line;
            $text =~ s/^\s*#//;
            $commentText .= $text;
        }

        next if $line !~ /^\s*#\s*($markupKeys)/;

        #STEP extract markup from line
        $line =~ m/^\s*#\s*($markupKeys)(.*)/;
        my $markup        = $1;
        my $extractedLine = $2;

        # special handling for IF case
        #IF markup == IF?
        if ( $markup eq "IF" ) {

            #IF-YES-START
            my ( $ifTag, $ifTagStartOrEnd, $description );

            #STEP extract TAG, START/END and DESCRIPTION from markup line
            $extractedLine =~ /\s*(-(\w*))?(-(\w*))?\s*(.*)/;
            $ifTag           = $2;
            $ifTagStartOrEnd = $4;
            $description     = $5;

            if ( not defined $ifTag ) {

                #CALL AddNormalIf if no TAG
                AddNormalIf($description);
            }
            elsif ( $ifTagStartOrEnd =~ /start/i ) {

                #CALL AddIfStart if START/END == START
                AddIfStart($ifTag);
            }
            elsif ( $ifTagStartOrEnd =~ /end/i ) {

                #CALL AddIfEnd if START/END == END
                AddIfEnd($ifTag);
            }
            else {
                # error
            }

            #IF-YES-END
        }

        #IF-NO-START
        #IF markup == LOOP?
        elsif ( $markup eq "LOOP" ) {

            #IF-YES-START
            my ( $loopStartOrEnd, $description );

            #STEP extract START/END and DESCRIPTION from markup line
            $extractedLine =~ /\s*-(START|END)\s*(.*)/i;
            $loopStartOrEnd = $1;
            $description    = $2;

            if ( $loopStartOrEnd =~ /start/i ) {

                #CALL AddLoopStart if START/END == START
                AddLoopStart($description);
            }
            elsif ( $loopStartOrEnd =~ /end/i ) {

                #CALL AddLoopEnd if START/END == END
                AddLoopEnd($description);
            }
            else {
                # error
            }

            #IF-YES-END
        }

        #IF-NO-START
        #IF markup == COMMENT?
        elsif ( $markup eq "COMMENT" ) {

            #IF-YES-START
            #STEP extract START/END from markup line
            $extractedLine =~ /\s*-(START|END)/i;
            my $commentStartOrEnd = $1;
            if ( $commentStartOrEnd =~ /start/i ) {

                #STEP set comment start flag if START/END == START
                $commentStart = 1;
                $commentText  = '';
            }
            else {
                #CALL AddComment if START/END == END
                AddComment();
            }

            #IF-YES-END
        }

        #IF-NO-START
        else {
            #CALL AddOther
            AddOther( $markup, $extractedLine );
        }

        #IF-NO-END
        #IF-NO-END
        #IF-NO-END

        $markupIndex++;
        $markupTree_href->{'markups'}{$markupIndex}{'markup'} = $markup . $extractedLine;

        #LOOP-END last line?
    }

    #CALL CreateGraph with name of current sub (for the last sub in the file)
    CreateGraph( $currentSubName, $directoryName, $currentPodText );

    return 1;
}

sub GetPOD4Function {
    my $line = shift;

    #STEP Find the start of a POD section and store the function name
    if ( not defined $podSection and $line =~ /^\s*=head2\s+(\w+)/ ) {
        $podText    = '';
        $podSection = $1;
        return 1;
    }

    #STEP Find the end of a POD section and set a marker for end found
    if ( defined $podSection and not defined $podSectionEndFound and $line =~ /^\s*=cut\s*$/ ) {
        $podSectionEndFound = 1;
    }

    #STEP Collect POD lines if we are between start and end of a POD section
    if ( defined $podSection and not defined $podSectionEndFound ) {
        $line = ReplacePodMarkups($line);
        $podText .= $line;
    }

    return 1;
}

sub ReplacePodMarkups {
    my $line = shift;

    # replace B<whatever> with whatever
    $line =~ s/B<(.+?)>/$1/g;

    # replace =over or =back with nothing
    if ( $line =~ /^\s*=(over|back)/ ) {
        return '';
    }

    # replace =item with -
    $line =~ s/=item/-/g;

    return $line;
}

# trim the given string
sub TrimString {
    my $string = shift;

    if ( defined $string ) {

        # trim the name
        $string =~ s/^(\s*)//;
        $string =~ s/(\s*)$//;

    }
    return $string;
}

sub AddNormalIf {
    my $description = shift;

    #STEP increment node index and add a new node with 'markup' = 'IF' and 'text' = current description
    $nodeIndex++;
    $markupTree_href->{'nodes'}{$nodeIndex}{'markup'} = 'IF';
    $markupTree_href->{'nodes'}{$nodeIndex}{'text'}   = $description;

    # add first the edges
    #CALL AddEdges
    AddEdges();

    # add then another entry to ifStack to avoid that the current if finds itself as parent
    #STEP add a new entry to if-stack with left branch 'start' = current node
    my $ifStackEntry_href->{0}{'start'} = $nodeIndex;

    #$ifStackEntry_href->{'branch'} = 0;
    push( @ifStack, $ifStackEntry_href );

    return 1;
}

sub AddIfStart {
    my $ifTag = shift;

    #STEP get last open entry from if-stack
    my $ifStackEntry_href = GetLastOpenStackEntry();

    #IF first branch of entry has no 'end'?
    if ( not defined $ifStackEntry_href->{0}{'end'} ) {

        #IF-YES-START
        #STEP set for first branch of entry 'start' = current node and 'tag' = current tag
        $ifStackEntry_href->{0}{'start'} = $nodeIndex;
        $ifStackEntry_href->{0}{'tag'}   = $ifTag;

        #IF-YES-END
    }
    else {
        #IF-NO-START
        #STEP set for second branch of entry 'start' = start of first branch and 'tag' = current tag
        $ifStackEntry_href->{1}{'start'} = $ifStackEntry_href->{0}{'start'};
        $ifStackEntry_href->{1}{'tag'}   = $ifTag;

        #IF-NO-END
    }

    #STEP write back entry to if-stack
    SetLastOpenStackEntry($ifStackEntry_href);

    return 1;
}

sub AddIfEnd {
    my $ifTag = shift;

    #STEP get last open entry from if-stack
    my $ifStackEntry_href = GetLastOpenStackEntry();

    #IF first branch of entry has no 'end'?
    if ( not defined $ifStackEntry_href->{0}{'end'} ) {

        #IF-YES-START
        #IF last markup was IF-...-START?
        if ( $markupTree_href->{'markups'}{$markupIndex}{'markup'} =~ /IF-\w+-START/i ) {

            #IF-YES-START
            #STEP set for first branch of entry 'end' = start of first branch
            $ifStackEntry_href->{0}{'end'} = $ifStackEntry_href->{0}{'start'};

            #IF-YES-END
        }
        else {
            #IF-NO-START
            #STEP set for first branch of entry 'end' = current node
            $ifStackEntry_href->{0}{'end'} = $nodeIndex;

            #IF-NO-END
        }

        #IF-YES-END
    }
    else {
        #IF-NO-START
        #IF last markup was IF-...-START?
        if ( $markupTree_href->{'markups'}{$markupIndex}{'markup'} =~ /IF-\w+-START/i ) {

            #IF-YES-START
            #STEP set for second branch of entry 'end' = start of second branch
            $ifStackEntry_href->{1}{'end'} = $ifStackEntry_href->{1}{'start'};

            #IF-YES-END
        }
        else {
            #IF-NO-START
            #STEP set for second branch of entry 'end' = current node
            $ifStackEntry_href->{1}{'end'} = $nodeIndex;

            #IF-NO-END
        }

        #IF-NO-END
    }

    #STEP write back entry to if-stack
    SetLastOpenStackEntry($ifStackEntry_href);

    return 1;
}

sub AddOther {
    my $markup = shift;
    my $text   = shift;

    #STEP increment node index and add a new node with 'markup' = current markup and 'text' = current description
    $nodeIndex++;
    $markupTree_href->{'nodes'}{$nodeIndex}{'markup'} = $markup;
    $markupTree_href->{'nodes'}{$nodeIndex}{'text'}   = $text;

    #CALL AddEdges
    AddEdges();

    return 1;
}

sub AddLoopStart {
    my $description = shift;

    #STEP increment node index and add a new node with 'markup' = LOOP-START and 'text' = current description
    $nodeIndex++;
    $markupTree_href->{'nodes'}{$nodeIndex}{'markup'} = 'LOOP-START';
    $markupTree_href->{'nodes'}{$nodeIndex}{'text'}   = $description;

    # add first edges
    #CALL AddEdges
    AddEdges();

    # add then another entry to loopStack to avoid that the current loop finds itself as parent
    #STEP add a new entry to loop-stack with 'start' = current node
    my $loopStackEntry_href->{'start'} = $nodeIndex;
    push( @loopStack, $loopStackEntry_href );

    return 1;
}

sub AddLoopEnd {
    my $description = shift;

    #STEP increment node index and add a new node with 'markup' = LOOP-END and 'text' = current description
    $nodeIndex++;
    $markupTree_href->{'nodes'}{$nodeIndex}{'markup'} = 'LOOP-END';
    $markupTree_href->{'nodes'}{$nodeIndex}{'text'}   = $description;

    #CALL AddEdges with argument 'LOOP-END'
    AddEdges('LOOP-END');

    pop(@loopStack);

    return 1;
}

sub AddComment {
    $commentStart = 0;

    #STEP remove markup 'COMMENT-END' from the comment
    $commentText =~ s/COMMENT-END\s*\n//g;

    #STEP increment node index and add a new node with 'markup' = COMMENT and 'text' = current description
    $nodeIndex++;
    $markupTree_href->{'nodes'}{$nodeIndex}{'markup'} = 'COMMENT';
    $markupTree_href->{'nodes'}{$nodeIndex}{'text'}   = $commentText;

    #CALL AddEdges
    AddEdges();

    return 1;
}

sub AddEdges {
    my $markup = shift;

    #STEP get last open entry from if-stack
    my $lastIfStackEntry_href = GetLastOpenStackEntry();
    SetLastOpenStackEntry($lastIfStackEntry_href);

    my @ifStackCopy;
    my $parents_href;

    # get parents from ifStack if previous markup was an IF-x-END
    my $previousMarkup = $markupTree_href->{'markups'}{$markupIndex}{'markup'};

    #IF previous markup was an IF-x-END?
    if ( defined $previousMarkup and $previousMarkup =~ /IF-\w+-END/i ) {

        #IF-YES-START
        #LOOP-START loop over if-stack entries
        while ( @ifStack > 0 ) {

            #STEP get last entry from if-stack
            my $ifStackEntry_href = pop(@ifStack);

            #STEP get both parent IDs from 'end' left and right branch of if-stack entry
            my $parent0 = $ifStackEntry_href->{0}{'end'};
            my $parent1 = $ifStackEntry_href->{1}{'end'};

            #IF both parent IDs defined?
            if ( defined $parent0 and defined $parent1 ) {

                #IF-YES-START
                #STEP add both parent IDs with their tags to parents-hash
                $parents_href->{$parent0} = $ifStackEntry_href->{0}{'tag'};
                $parents_href->{$parent1} = $ifStackEntry_href->{1}{'tag'};

                # no unshift, i.e. this if statement is finished and the $ifStackEntry_href will be deleted
                #STEP if-stack entry is not pushed back to stack because this entry is finished
                #IF-YES-END
            }
            else {
                #IF-NO-START
                #STEP push back if-stack entry to stack
                unshift( @ifStackCopy, $ifStackEntry_href );

                #IF-NO-END
            }

            #LOOP-END last if-stack entry?
        }
        @ifStack = @ifStackCopy;

        #IF-YES-END
        #IF-NO-START
        #IF-NO-END
    }

    # get parent from markup sequence if previous markup was an IF-x-START
    #IF previous markup was an IF-x-START?
    if ( keys %{$parents_href} == 0 and defined $previousMarkup and $previousMarkup =~ /IF-\w+-START/i ) {

        #IF-YES-START
        #STEP get parent ID from 'start' of last if-stack entry
        my $parentIndex = $lastIfStackEntry_href->{0}{'start'};
        my $tag         = $lastIfStackEntry_href->{1}{'tag'};
        $tag = $lastIfStackEntry_href->{0}{'tag'} if not defined $tag;

        #STEP add parent ID with tag to parents-hash
        $parents_href->{$parentIndex} = $tag;

        #IF-YES-END
        #IF-NO-START
        #IF-NO-END
    }

    # get parent from predecessor if not already found before
    #IF parents hash is still empty?
    if ( keys %{$parents_href} == 0 ) {

        #IF-YES-START
        #STEP add predecessor node to parents-hash
        $parents_href->{ $nodeIndex - 1 } = "";

        #IF-YES-END
        #IF-NO-START
        #IF-NO-END
    }

    # create edges from parents to current node
    #LOOP-START loop over parents in parents-hash
    foreach my $parentIndex ( sort { $a <=> $b } keys %{$parents_href} ) {
        my $tag;
        my $parentMarkup = $markupTree_href->{'nodes'}{$parentIndex}{'markup'};

        #IF parent is an IF?
        if ( defined $parentMarkup and $parentMarkup eq 'IF' ) {

            #IF-YES-START
            #STEP get tag from last if-stack entry if parent tag is not defined
            if ( $parents_href->{$parentIndex} eq "" ) {
                $tag = $lastIfStackEntry_href->{0}{'tag'};
                $tag = $lastIfStackEntry_href->{1}{'tag'} if defined $lastIfStackEntry_href->{1}{'tag'};
            }

            #STEP get tag from parent tag if parent tag is defined
            else {
                $tag = $parents_href->{$parentIndex};
            }

            #IF-YES-END
            #IF-NO-START
            #STEP tag is empty
            #IF-NO-END
        }

        #STEP increment edge index and add a new edge with 'start' = parent index, 'end' = current node index and 'tag' = tag as defined above
        $edgeIndex++;
        $markupTree_href->{'edges'}{$edgeIndex}{'start'} = $parentIndex;
        $markupTree_href->{'edges'}{$edgeIndex}{'end'}   = $nodeIndex;
        $markupTree_href->{'edges'}{$edgeIndex}{'tag'}   = $tag;
        $markupTree_href->{'edges'}{$edgeIndex}{'invisible'} = 1 if $parentMarkup eq 'END';

        #LOOP-end last parent?
    }

    # create edge from current node to child; get child from loop stack if markup is a LOOP-END
    #IF given markup is LOOP-END and loop-stack is not empty?
    if ( defined $markup and $markup =~ /LOOP-END/i and @loopStack > 0 ) {

        #IF-YES-START
        #STEP get child index from last loop stack entry
        my $loopStackEntry_href = $loopStack[-1];
        my $childIndex          = $loopStackEntry_href->{'start'};

        #STEP increment edge index and add a new edge with 'start' = current node index, 'end' = child index and 'tag' = 'NO'
        $edgeIndex++;
        $markupTree_href->{'edges'}{$edgeIndex}{'start'} = $nodeIndex;
        $markupTree_href->{'edges'}{$edgeIndex}{'end'}   = $childIndex;
        $markupTree_href->{'edges'}{$edgeIndex}{'tag'}   = 'NO';

        #IF-YES-END
        #IF-NO-START
        #IF-NO-END
    }

    #STEP end

    return 1;
}

sub GetLastOpenStackEntry {

    # loop over all stack entries and find the last one that is not yet closed; this entry must be modified
    while ( @ifStack > 0 ) {
        my $ifStackEntry_href = pop(@ifStack);
        if ( not defined $ifStackEntry_href->{1}{'end'} ) {
            return $ifStackEntry_href;
        }
        unshift( @lastOpenStackCopy, $ifStackEntry_href );
    }

    return;
}

sub SetLastOpenStackEntry {
    my $ifStackEntry_href = shift;

    push( @ifStack, $ifStackEntry_href ) if defined $ifStackEntry_href;

    while ( @lastOpenStackCopy > 0 ) {
        my $copiedIfStackEntry_href = shift(@lastOpenStackCopy);
        push( @ifStack, $copiedIfStackEntry_href );
    }

    return 1;
}

sub CreateGraph {
    my $subName         = shift;
    my $directoryName   = shift;
    my $functionPodText = shift;

    return if $nodeIndex == 0;

    #STEP add title to nodes
    $markupTree_href->{'nodes'}{-2}{'markup'} = 'TITLE';
    $markupTree_href->{'nodes'}{-2}{'text'}   = "Function: $subName";

    #STEP add POD documentation text as comment node if defined
    if ( defined $functionPodText ) {
        $markupTree_href->{'nodes'}{-1}{'markup'}   = 'COMMENT';
        $markupTree_href->{'nodes'}{-1}{'text'}     = "POD documentation:\n$functionPodText";
        $markupTree_href->{'edges'}{0}{'start'}     = -1;
        $markupTree_href->{'edges'}{0}{'end'}       = 0;
        $markupTree_href->{'edges'}{0}{'invisible'} = 1;
    }
    else {
        $markupTree_href->{'edges'}{1}{'start'} = 0;
    }

    my $graphvizElements_href = {
        'default'    => { 'shape' => "box",     'color' => 2 },
        'START'      => { 'shape' => "circle",  'color' => 1 },
        'END'        => { 'shape' => "ellipse", 'color' => 1 },
        'IF'         => { 'shape' => "diamond", 'color' => 3 },
        'LOOP-START' => { 'shape' => "box",     'color' => 4 },
        'LOOP-END'   => { 'shape' => "diamond", 'color' => 6 },
        'CALL'       => { 'shape' => "box3d",   'color' => 7 },
        'COMMENT'    => { 'shape' => "note",    'color' => 8 },
        'TITLE'      => { 'shape' => "box3d",   'color' => 1 },
    };

    #CALL CheckStacks with current sub name
    CheckStacks($subName);

    my $graph = graph {
        name "$subName";

        #STEP set the global parameters of the graph: name, edge type, color scheme
        edges arrowhead => 'onormal', color => 'magenta4';
        global center => 'true', outputorder => 'nodefirst', bgcolor => 'white';
        nodes( nodesep => 23 );

        #LOOP-START loop over nodes
        my ( $shape, $color );
        foreach my $nodeIndex ( sort { $a <=> $b } keys %{ $markupTree_href->{'nodes'} } ) {

            next if not defined $markupTree_href->{'nodes'}{$nodeIndex}{'markup'};

            #STEP get markup and text from node
            my $markup = $markupTree_href->{'nodes'}{$nodeIndex}{'markup'};
            my $text   = $markupTree_href->{'nodes'}{$nodeIndex}{'text'};

            #STEP replace " with ' to avoid syntax errors in dot
            $text =~ s/"/'/g;

            #STEP get shape and color from graphviz table with markup
            $shape = $graphvizElements_href->{'default'}{'shape'};
            $color = $graphvizElements_href->{'default'}{'color'};

            if ( defined $graphvizElements_href->{$markup} ) {
                $shape = $graphvizElements_href->{$markup}{'shape'};
                $color = $graphvizElements_href->{$markup}{'color'};
            }

            #IF markup is 'COMMENT' or 'CALL'
            if ( $markup eq 'COMMENT' or $markup eq 'CALL' ) {

                #IF-YES-START
                #STEP replace \\n with \\l to make the text left aligned
                $text =~ s/\n/\\l/g;

                #STEP remove last line with COMMENT-END
                $text =~ s/\\lCOMMENT-END\\l//;

                #IF-YES-END
            }
            else {
                #IF-NO-START
                #STEP wrap the text
                $text = wrap( '', '', $text );

                #IF-NO-END
            }

            #IF markup is 'CALL'?
            if ( $markup eq 'CALL' ) {

                #IF-YES-START
                #STEP create graphviz node with node index, text, shape, color and URL
                my $url = '';
                if( $text =~ /^\s*(\w+)::(\w+)/ ){
                    $url =  "../$1/$2.$output";
                }
                elsif ( $text =~ /^\s*(\w+)/ ) {
                    $url = $1 . ".$output";
                }
                node( $nodeIndex, label => $text, shape => $shape, fixedsize => 'false', center => 'true', fillcolor => $color, URL => $url );

                #IF-YES-END
            }
            else {
                #IF-NO-START
                #STEP create graphviz node with node index, text, shape and color
                node( $nodeIndex, label => $text, shape => $shape, fixedsize => 'false', center => 'true', fillcolor => $color );

                #IF-NO-END
            }

            #LOOP-END last node?
        }

        nodes colorscheme => 'set312', style => 'filled';

        #LOOP-START loop over edges
        foreach my $edgeIndex ( sort { $a <=> $b } keys %{ $markupTree_href->{'edges'} } ) {

            #STEP get start, end and tag from edge
            my $start     = $markupTree_href->{'edges'}{$edgeIndex}{'start'};
            my $end       = $markupTree_href->{'edges'}{$edgeIndex}{'end'};
            my $tag       = $markupTree_href->{'edges'}{$edgeIndex}{'tag'};
            my $invisible = $markupTree_href->{'edges'}{$edgeIndex}{'invisible'};

            #IF tag defined?
            if ( defined $tag ) {

                #IF-YES-START
                #STEP create graphviz edge from start to end with tag
                edge( [ $start, $end ], "label" => $tag );

                #IF-YES-END
            }

            #IF-NO-START
            #IF invisible flag set?
            elsif ($invisible) {

                #IF-YES-START
                #STEP create graphviz edge from start to end with white arrow
                edge( [ $start, $end ], color => 'white' );

                #IF-YES-END
            }
            else {
                #IF-NO-START
                #STEP create graphviz edge from start to end without tag
                edge( [ $start, $end ] );

                #IF-NO-END
            }

            #IF-NO-END

            #LOOP-END last edge?
        }

    };

    #STEP create and save graph (by default as svg)
    $graph->save( dpi => 700, path => "$directoryName/$subName", type => $output, encoding => 'utf-8' );

    return 1;
}

sub CheckStacks {
    my $subName = shift;

    #IF a COMMENT-START has no COMMENT-END
    if ($commentStart) {

        #IF-YES-START
        #STEP print error message about no matching #COMMENT-END
        print("ERROR in function $subName: one instance of #COMMENT-START has no matching #COMMENT-END.\n");
        $commentStart = 0;

        #IF-YES-END
        #IF-NO-START
        #IF-NO-END
    }

    #LOOP-START loop over if-stack entries if any
    while ( @ifStack > 0 ) {
        my $ifStackEntry_href = pop(@ifStack);
        my $startIndex        = $ifStackEntry_href->{0}{'start'};
        my $markup            = $markupTree_href->{'nodes'}{$startIndex}{'markup'};
        my $text              = $markupTree_href->{'nodes'}{$startIndex}{'text'};

        #STEP print error message about not properly closed IF
        print("ERROR in function $subName: IF statement at '$markup $text' is not properly closed.\n");
    }

    #LOOP-END last entry?
    #LOOP-START loop over loop-stack entries if any
    while ( @loopStack > 0 ) {
        my $loopStackEntry_href = pop(@loopStack);
        my $startIndex          = $loopStackEntry_href->{'start'};
        my $markup              = $markupTree_href->{'nodes'}{$startIndex}{'markup'};
        my $text                = $markupTree_href->{'nodes'}{$startIndex}{'text'};

        #STEP print error message about not properly closed LOOP
        print("ERROR in function $subName: LOOP statement at '$markup $text' is not properly closed.\n");
    }

    #LOOP-END last entry?

    return 1;
}

1;
