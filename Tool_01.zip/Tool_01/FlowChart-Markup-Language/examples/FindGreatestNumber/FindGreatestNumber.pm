
sub FindGreatestNumber
{
    #STEP receive the three input integers (a,b,c)
    #STEP validate whether all the inputs are within accepted range <1000)
    #IF Is (a<b)?
        #IF-YES-START
         #STEP as b is greater, now, we should check whether b<c
              #IF Is (b<c)?
                 #IF-YES-START
                     #STEP conclude that c is greater!
                 #IF-YES-END
                 #IF-NO-START
                     #STEP conclude that b is greater!
                 #IF-NO-END
        #IF-YES-END
        #IF-NO-START
            #STEP as a is greater, now, we should check whether a<c
              #IF Is (a<c)?
                 #IF-YES-START
                     #STEP conclude that c is greater!
                 #IF-YES-END
                 #IF-NO-START
                     #STEP conclude that a is greater!
                 #IF-NO-END
        #IF-NO-END
     #STEP we have the greatest integer now
     #STEP return the integer

}
