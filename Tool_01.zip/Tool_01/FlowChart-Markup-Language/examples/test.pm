sub if_nested_good{

#IF if 1
#IF-YES-START
#STEP if 1 yes
#IF-YES-END
#IF-NO-START
	#IF if 2
	#IF-YES-START
	#IF-YES-END
	#IF-NO-START
		#IF if 3
		#IF-YES-START
		#STEP if 3 yes
		#IF-YES-END
		#IF-NO-START
		#STEP if 3 no
		#IF-NO-END
	#IF-NO-END
#IF-NO-END
#STEP end


}

sub if_loop_nested_good{

#IF if 1
#IF-YES-START
	#LOOP-START loop 1
		#STEP action 1
		#LOOP-START loop 2
			#LOOP-START loop 3
				#IF if 3
				#IF-YES-START
					#STEP if 3 yes
				#IF-YES-END
				#IF-NO-START
					#STEP if 3 no
				#IF-NO-END
			#LOOP-END loop 3 done?
		#STEP action 2
		#LOOP-END loop 2 done?
	#LOOP-END loop 1 done?
#IF-YES-END
#IF-NO-START
	#IF if 2
	#IF-YES-START
	#IF-YES-END
	#IF-NO-START
		#IF if 3
		#IF-YES-START
			#STEP if 3 yes
		#IF-YES-END
		#IF-NO-START
			#STEP if 3 no
		#IF-NO-END
	#IF-NO-END
#IF-NO-END
#STEP end

}

sub if_missing_path{

#IF if 1
#IF-YES-START
#STEP if 1 yes
#IF-YES-END
#STEP end

}

sub if_nested_missing_path{

#IF if 1
#IF-YES-START
#STEP if 1 yes
	#IF if 2
	#IF-NO-START
	#STEP if 2 yes
	#IF-NO-END
#STEP if 1 end

#IF-YES-END
#STEP end

}

sub if_wrong_end{

#IF if 1
#IF-YES-START
#STEP if 1 yes
#IF-NO-END
#IF-NO-START
#STEP if 1 no
#IF-YES-END
#STEP end

}

sub if_missing_end{

#IF if 1
#IF-YES-START
#STEP if 1 yes
#IF-NO-START
#STEP if 1 no
#IF-NO-END
#STEP end

}

sub loop_nested_good{

#LOOP-START loop 1
#STEP action 1
	#LOOP-START loop 2
		#LOOP-START loop 3
		#STEP action 3
		#LOOP-END loop 3 done?
	#STEP action 2
	#LOOP-END loop 2 done?
#LOOP-END loop 1 done?

#STEP end

}

sub loop_missing_end{

#LOOP-START loop 1
#STEP action 1
	#LOOP-START loop 2
		#LOOP-START loop 3
		#STEP action 3
	#STEP action 2
	#LOOP-END loop 2 done?
#LOOP-END loop 1 done?

#STEP end

}

sub if_loop_nested_wrong{

#IF if 1
#IF-YES-START
	#LOOP-START loop 1
	#STEP action 1
#IF-YES-END
#IF-NO-START
#IF-NO-END
#STEP action 2
#LOOP-END loop 1 done?
#STEP end

}

sub call_good1{
#CALL call_good2 test comment
}

sub call_good2{
#CALL call_good1
}