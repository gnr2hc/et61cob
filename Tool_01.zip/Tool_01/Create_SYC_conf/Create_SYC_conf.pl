#!perl -w

#****************************************************************************************************
#                                                                           						*
# Copyright (c) 2013 Robert Bosch GmbH, Germany                             						*
#               All rights reserved                                         						*
#                                                                           						*
#****************************************************************************************************
# $Author: Schwibus Dirk (CC-PS/EPS2) (SDW2BUE) $                         						*
# $Revision : 1.0 $        																			*
#                     																				*
#****************************************************************************************************

use strict;
use warnings;
use Tk;
use Tk::Frame;
use Win32::File;
use File::Copy;
use File::Basename;
use Win32::OLE;
use Win32::OLE::Const;
use File::Find;
use File::Path;
use Getopt::Long;
use File::Glob ':glob';
use Cwd;
use Tk::LabFrame;
use File::Copy qw(copy);
use XML::Simple;
use XML::Twig;
use Data::Dumper;

sub Creatre_About_Window {
	my $mw = MainWindow->new( "-background" => "#888888" );
	$mw->minsize( 100, 25 );
	$mw->title("Help");

	#Making a text area
	my $txt = $mw->Scrolled( 'Text', -width => 100, -scrollbars => 'e' )->pack();

	$txt->delete( '1.0', 'end' );
	$txt->insert(
		'end', '
#	DESCRIPTION:                               
#	This tool will generate a hash from an exported SYC xml.
#
#	FOLLOW THESE STEPS:
#	1. Open a test specification in Doors (TS)
#       2. Select CC-OS-Utilities -> Requirement-Test -> xml export
#	3. Click Export, select a path to save .pm files to and click GENERATE                                
#  
#	REMARKS:                                    
#	1. Perl Version 5.12 32 bit (installed using Peacy package) is required
#	2. Perl TK has to be installed                
#       3. Have fun!                        
	'
	);
	return;
}
my ( $main, $end_frame, $SYC_Variant_Name, $input_excel_File_Name, $status );

# Default Designation Path
my $TK_ERROR_INDICATION_FLAG_i = 0;
my $project_name               = "";
$main = MainWindow->new( "-background" => "DodgerBlue1" );

# Size to the TK window
$main->minsize( 450, 100 );

##########################################################
##########################################################
#$input_excel_File_Name = $ARGV[0];
$input_excel_File_Name = 'N:\Projekte\Testing_exchange\RB_SI\4_dirk\SYC_Export\SYC_Exp.xml';

#$input_excel_File_Name = 'N:\Projekte\Testing_exchange\RB_SI\4_dirk\SYC_Export\SYC_Export_MQB.xml';

#$input_excel_File_Name='XML_export_SYC_2.xml';

#$SYC_Variant_Name = $ARGV[1];
$SYC_Variant_Name = 'V_AB12Base_2015A';

#$SYC_Variant_Name = 'V_MQB_A0_High_H1';

#$SYC_Variant_Name='XML_export_SYC_2.xml';
##########################################################
##########################################################

$main->title("SYC exporter - conversion to a perl hash");

my ( $filename, $output_path, $extension ) = fileparse($input_excel_File_Name);

#print "Directory: " . $output_path . "\n";
#print "File:      " . $filename . "\n";
#print "Suffix:    " . $extension . "\n\n";
#$output_path = "C:\\Users\\gem1si\\Desktop\\test\\";
print "Output path = $output_path\n";

#create output filename
$filename =~ s/\..+$//;
$filename = "$output_path$filename.pm";
print "Output file = $filename\n";

#Declare that there is a menu
my $mbar = $main->Menu();
$main->configure( -menu => $mbar );

#The Main Buttons
my $file = $mbar->cascade( -label => "File", -underline => 0, -tearoff => 0 );
my $help = $mbar->cascade( -label => "Help", -underline => 0, -tearoff => 0 );

## File Menu ##
$file->command(
	-label     => "Exit",
	-underline => 1,
	-command   => sub { exit }
);

#********************************************************************************************
$help->command(
	-label   => "ReadMe",
	-command => sub { Creatre_About_Window() }
);

$main->Label(
	-text       => 'SYC exporter',
	-font       => '{Segoe UI light} 20',
	-background => 'DodgerBlue1',
	-foreground => 'white',
	-height     => '001'
)->pack( -side => 'top', -pady => '003' );

my $labeled_frame1 = $main->Frame(
	-borderwidth => 2,
	-relief      => 'groove',
	-background  => "DodgerBlue1",
)->pack( -side => "top", -padx => '150', -anchor => 'nw' );

$main->Label(
	-text       => "SYC file save path='$output_path'",
	-background => "DodgerBlue1",
	-foreground => "white",
	-font       => '{Segoe UI light} 11 '
)->pack( -side => 'top', -pady => '02' );

$status = ' Not Started';

# create label in window 'main'
$main->Label(
	-textvariable => \$status,                #reference to display the status
	-font         => '{Segoe UI light} 11',
	-background   => "DodgerBlue1",
	-foreground   => "gray90",
)->pack( "-pady" => 6, -side => 'top' );

$end_frame = $main->Frame( "-background" => "DodgerBlue1" )->pack( -ipadx => '10', -padx => '2' );
$end_frame->Button(
	-text       => 'Exit',
	-width      => '8',
	-font       => '{Segoe UI light} 12 ',
	-background => "orange",
	-foreground => "white",
	-relief     => 'groove',
	-command    => [ $main => 'destroy' ]
)->pack( -side => 'top', -pady => '02' );

Generate_File();

MainLoop;

sub Generate_File {

	#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	#            Error Handling from the GUI
	#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

	$output_path
	  || ( $status = "Please select the output path."
		&& die("output path $output_path is not found!\n") );

	$status = ' Not Started ';
	my ( @error_messages, @warning_messages );

	# create object
	my $xml  = XML::Simple->new();
	my $data = $xml->XMLin($input_excel_File_Name);

	# access XML data
	#print "$data->{name} is $data->{age} years old and works in the $data->{department} section\n";

	#^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^Status update in the GUI Window ^^^^^^^^^^^^^^^^^^^^^^^^
	$status = "Conversion in progress!";
	$main->update();

	#^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^Assigning the coloumn attrributes for  the column cells of doors doccuments  ^^^^^^^^^^^^^^^^^^^^^^^^

	#	sdw2bue: local changes starting from here...

	my ( $syc_hash, @headline_collection, @configId_collection, $configIds_href );
	my $syc_export->{Content} = {};
	my $object_level_last_headline = 0;

	# put all objects in new hash with hierarchy as key
	foreach my $object ( @{ $data->{module}{object} } ) {
		$syc_hash->{ $object->{object_hierarchy} } = $object;
	}

	# go through SYC in order of doors hierarchy
	foreach my $syc_column ( sort keys %$syc_hash ) {

		my $config_id        = $syc_hash->{$syc_column}{ConfigID};
		$config_id           = undef if ref($config_id);
		my $object_level     = $syc_hash->{$syc_column}{object_level};
		my $object_type      = $syc_hash->{$syc_column}{Type};
		my $object_hierarchy = $syc_hash->{$syc_column}{object_hierarchy};
		my $item_heading     = $syc_hash->{$syc_column}{Object___Heading};
		my $object_content   = $syc_hash->{$syc_column}{$SYC_Variant_Name};
		$object_content = $$object_content[0] if ref($object_content) eq 'ARRAY';
		my $nbr              = 1;

		# set curent_position to the beginning of the syc_export
		my $curent_position = $syc_export->{Content};

		next unless defined $object_type;

		# update curent_position to give ($object_level - 1) headline
		foreach my $hierarchy_level ( 1 .. $object_level - 1 ) {
			$curent_position = $curent_position->{ $headline_collection[$hierarchy_level] };
		}

		if ( $object_type eq "Heading" ) {
			$headline_collection[$object_level] = $item_heading;
			$configId_collection[$object_level] = $config_id;
			$curent_position->{$item_heading}   = {};
			$curent_position                    = $curent_position->{$item_heading};
			splice( @headline_collection, $object_level+1 ) if @headline_collection > $object_level;
			splice( @configId_collection, $object_level+1 ) if @configId_collection > $object_level;
			next if not defined $config_id;
		}elsif( $object_type eq "Configuration" ) {
			next if not defined $config_id;
			next if ref($object_content) eq 'HASH';
			$object_content =~ s/\n/ /g;    # maybe not necessary
			$curent_position->{$config_id} = $object_content;
		}else{
			next;
		}

		$nbr = $configIds_href->{$config_id}{Nbr} + 1 if ( exists $configIds_href->{$config_id} ); 
		foreach my $curent_obj_lvl ( 1 .. $object_level ) {
			$configIds_href->{$config_id}{$nbr}{headline_Collection}{$curent_obj_lvl} = $headline_collection[$curent_obj_lvl];
			$configIds_href->{$config_id}{$nbr}{ConfigId_Collection}{$curent_obj_lvl} = $configId_collection[$curent_obj_lvl];
		}
		if ($object_type eq "Configuration"){
			$configIds_href->{$config_id}{$nbr}{headline_Collection}{$object_level} = $config_id;
			$configIds_href->{$config_id}{$nbr}{ConfigId_Collection}{$object_level} = $config_id;			
		}
		$configIds_href->{$config_id}{Nbr} = $nbr;
	}

	open( SYC_EXPORT, ">$output_path/LIFT_SYC_EXPORT_$SYC_Variant_Name.pm" )
	  || die("LIFT_SYC_EXPORT_$SYC_Variant_Name.pm could not be created!\n");

	$Data::Dumper::Sortkeys = 1;
	$Data::Dumper::Varname  = "syc_export";
	print SYC_EXPORT "package LIFT_SYC_EXPORT;\n\n";
	print SYC_EXPORT Dumper( $syc_export->{Content} );
	$Data::Dumper::Varname = "ConfigIds";
	print SYC_EXPORT Dumper($configIds_href);
	close SYC_EXPORT;

	# 	sdw2bue: end of local changes

	open( TCFILE, ">$filename" )
	  || die("$filename could not be created!\n");

	print TCFILE "#### Syc data based on '$input_excel_File_Name'\n";

	#print TCFILE Data::Dumper->Dump($data);
	print TCFILE Dumper($data);

	close TCFILE;

	open( ERRORLOG, ">$output_path/ErrorLog.txt" )
	  || die("ErrorLog.txt could not be created!\n");

	my $errorcount = 0;
	print ERRORLOG "!!!!!!!!!!!!!!!!!!!!!!!!ERRORS!!!!!!!!!!!!!!!!!!!!!!!!\n\n";
	if ( defined $error_messages[0] ) {
		foreach my $error (@error_messages) {
			$errorcount++;
			print ERRORLOG "$errorcount. $error";
		}
	}
	else { print ERRORLOG "No Errors! :-)"; }

	my $warningcount = 0;
	print ERRORLOG "\n\n!!!!!!!!!!!!!!!!!!!!!!!!WARNINGS!!!!!!!!!!!!!!!!!!!!!!\n\n";
	if ( defined $warning_messages[0] ) {
		foreach my $warning (@warning_messages) {
			$warningcount++;
			print ERRORLOG "$warningcount. $warning";
		}
	}
	else { print ERRORLOG "No Warnings! :-)"; }

	close ERRORLOG;

	##################  Save File is completed ##############################

	$status = "Completed, you can press 'Exit'.\n(Or have a look at ErrorLog.txt file for Errors and Warnings.)";

	#add button to show directory
	my $convertedpath = $output_path;
	$convertedpath =~ s/\//\\/g;
	my $explorercommand = $convertedpath;    #."\\ErrorLog.txt";

	#print "Explorer command: $explorercommand\n";
	$main->Button(
		-text => 'Open the SYC directory',

		#-width=>'8',
		-font       => '{Segoe UI light} 12 ',
		-background => "orange",
		-foreground => "white",
		-relief     => 'groove',
		-command    => sub {
			my @args = ( "Explorer.exe", $explorercommand );
			system(@args);
		}
	)->pack( -pady => 6, -side => 'top' );

	#make generate button unusable
	#$generate_button->configure( -state => 'disabled');

	$main->update();    # sub
	return;
}

# create
__END__
